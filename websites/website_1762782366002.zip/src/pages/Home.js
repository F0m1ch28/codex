// @ts-check
import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const featuredEssays = [
  {
    title: "Why Context Switching Drains Engineering Momentum",
    excerpt:
      "We unpack cognitive residue, task management heuristics, and the structural patterns that erode focus in distributed teams.",
    to: "/blog/why-context-switching-kills-productivity",
    image: "https://picsum.photos/800/600?random=2",
    tags: ["developer workflows", "engineering psychology"]
  },
  {
    title: "Cloud Patterns for Elastic Scale",
    excerpt:
      "A pragmatic look at multi-region deployment strategies, resilience playbooks, and observability gradients for platform teams.",
    to: "/blog/cloud-patterns-for-scale",
    image: "https://picsum.photos/800/600?random=5",
    tags: ["software systems", "cloud infrastructure"]
  },
  {
    title: "The Evolution of DevOps Culture",
    excerpt:
      "Tracing the lineage of build pipelines, runbooks, and feedback rituals that shape modern platform engineering habits.",
    to: "/blog/the-evolution-of-devops-culture",
    image: "https://picsum.photos/800/600?random=6",
    tags: ["devops culture", "platform engineering"]
  }
];

const workflowPatterns = [
  "Continuous delivery cadences anchored in smaller, auditable releases.",
  "Incident review frameworks that translate failure into shared learning.",
  "Async collaboration pulses balancing alignment and deep focus.",
  "Developer experience dashboards tuned for actionable insight."
];

const toolingSignals = [
  {
    title: "IDE Telemetry Narratives",
    detail:
      "Tracking cursor journeys, compile friction, and plugin sprawl to highlight opportunities for sustainable developer ergonomics."
  },
  {
    title: "Pipeline Latency Storylines",
    detail:
      "Interpreting CI/CD lead times to translate automation health into executive narratives grounded in data."
  },
  {
    title: "Runtime Diagnostics Choreography",
    detail:
      "Linking tracing, profiling, and live debugging to the cognitive bandwidth of teams on-call."
  }
];

const developerMindset = [
  {
    title: "Cognitive Load Mapping",
    detail:
      "Visual frameworks that transform architectural complexity into digestible layers for new contributors."
  },
  {
    title: "Resilience Routines",
    detail:
      "Rituals that integrate pause, reflection, and lightweight retrospectives to guard against burnout."
  },
  {
    title: "Communicative Clarity",
    detail:
      "Editorial techniques that keep technical updates traceable, respectful, and anchored in shared vocabulary."
  }
];

const codeHistory = [
  {
    title: "RFC 1094: NFS",
    summary:
      "The remote file system specification that paved the way for collaborative codebases across networks."
  },
  {
    title: "Smalltalk-80 System Design",
    summary:
      "A manifesto on object messaging whose ideas still inform modern platform engineering."
  },
  {
    title: "UNIX Research Papers",
    summary:
      "Historical perspectives illustrating the cultural roots of modular tooling and composability."
  }
];

const editorialHighlights = [
  {
    title: "Platform Choreography Playbook",
    description:
      "How orchestration, release naming, and shared dashboards sustain confidence across delivery teams."
  },
  {
    title: "Distributed Decision Journals",
    description:
      "A narrative approach to capturing architectural reasoning in hybrid organizations."
  },
  {
    title: "Incident Storycraft",
    description:
      "Editorial strategies that transform outage repairs into accessible, empathetic knowledge."
  }
];

const readingQueue = [
  {
    title: "Cognitive Dimensions of Dev Tooling",
    summary:
      "Analyzing how design choices in developer platforms influence problem solving bandwidth.",
    tags: ["engineering psychology", "tooling"]
  },
  {
    title: "Adaptive Capacity in Cloud Infrastructure",
    summary:
      "A research roundup on responsive scaling, chaos exercises, and the language of reliability agreements.",
    tags: ["cloud infrastructure", "distributed computing"]
  },
  {
    title: "Workflow Literacy in Hybrid Teams",
    summary:
      "Curated references on agreements, knowledge gardens, and meeting architecture for async collaboration.",
    tags: ["developer workflows", "devops culture"]
  }
];

const processSteps = [
  {
    title: "Discover",
    description:
      "We immerse ourselves in your existing workflows, tooling choices, and communication rituals to understand friction."
  },
  {
    title: "Synthesize",
    description:
      "Cross-disciplinary editors translate observations into structured storylines coupled with data-backed insights."
  },
  {
    title: "Illuminate",
    description:
      "We deliver narrative briefs, visual frameworks, and annotated references that catalyze confident engineering decisions."
  },
  {
    title: "Evolve",
    description:
      "Through iterative reviews, we refine documentation, knowledge bases, and onboarding experiences with measurable clarity."
  }
];

const testimonials = [
  {
    quote:
      "DevLayer reframed our deployment story from a tangle of scripts into an accessible narrative our entire studio trusts.",
    name: "Maya Chen",
    role: "Director of Platform Enablement, Northern Labs"
  },
  {
    quote:
      "The editorial depth on developer cognition helped us redesign incident rituals with psychological safety in mind.",
    name: "Luis Hernández",
    role: "Principal Site Reliability Engineer, Aurora Mesh"
  },
  {
    quote:
      "Their research on distributed collaboration brought a shared language to our workflow improvement council.",
    name: "Anika Patel",
    role: "Head of Engineering Operations, HoloStack"
  }
];

const projects = [
  {
    title: "Observability Narrative Atlas",
    category: "Systems",
    description:
      "A layered editorial guide aligning tracing dashboards with executive briefings for unified strategy.",
    image: "https://picsum.photos/1200/800?random=4"
  },
  {
    title: "Developer Ergonomics Studio",
    category: "Workflow",
    description:
      "Interactive field reports capturing IDE usage, pair-programming etiquette, and remote-first routines.",
    image: "https://picsum.photos/1200/800?random=7"
  },
  {
    title: "Platform Reliability Chronicles",
    category: "Tooling",
    description:
      "A living history of incident remediations connected to documentation, training, and roadmap evolution.",
    image: "https://picsum.photos/1200/800?random=8"
  }
];

const faqItems = [
  {
    question: "What kinds of teams benefit from DevLayer editorial work?",
    answer:
      "We collaborate with platform engineering groups, infrastructure specialists, and research-oriented developer experience teams seeking narrative clarity for complex systems."
  },
  {
    question: "How do you ensure technical accuracy?",
    answer:
      "Our editors pair with subject matter experts, review architecture diagrams, and run validation passes with maintainers before publication."
  },
  {
    question: "Can DevLayer support ongoing knowledge programs?",
    answer:
      "Yes. We offer recurring editorial cadences, workflow audits, and coaching to keep internal knowledge gardens vibrant."
  }
];

const blogPreview = [
  {
    title: "Maintaining Clarity in Multi-Cloud Architectures",
    date: "October 12, 2023",
    link: "/blog/cloud-patterns-for-scale"
  },
  {
    title: "Designing Work Journals for Engineering Focus",
    date: "September 20, 2023",
    link: "/blog/why-context-switching-kills-productivity"
  },
  {
    title: "DevOps Culture Signals to Watch",
    date: "August 30, 2023",
    link: "/blog/the-evolution-of-devops-culture"
  }
];

const statsTargets = [
  { label: "Editorial Briefs Published", value: 128 },
  { label: "Workflow Patterns Documented", value: 42 },
  { label: "Cloud Playbooks Crafted", value: 36 },
  { label: "Engineering Teams Engaged", value: 24 }
];

const ServicesCards = [
  {
    title: "Editorial Strategy Labs",
    description:
      "Collaborative workshops translating technical insights into shareable narratives tailored for engineering leaders and practitioners."
  },
  {
    title: "Workflow Intelligence Reports",
    description:
      "Cross-analysis of process telemetry, developer interviews, and research-backed heuristics to identify sustainable improvements."
  },
  {
    title: "Platform Enablement Libraries",
    description:
      "Curated documentation sets, modular templates, and annotated diagrams that accelerate onboarding and knowledge transfer."
  }
];

const TeamMembers = [
  {
    name: "Elena Marquez",
    role: "Editor-in-Chief",
    bio: "Former platform engineer turned narrative strategist. Elena anchors DevLayer’s voice across systems and people stories.",
    image: "https://picsum.photos/400/400?random=3"
  },
  {
    name: "Thierry Ouellet",
    role: "Research Lead",
    bio: "Data ethnographer focused on developer cognition, ritual design, and information architecture.",
    image: "https://picsum.photos/400/400?random=9"
  },
  {
    name: "Sahana Iyer",
    role: "Workflow Analyst",
    bio: "Maps automation journeys, tooling ergonomics, and governance rhythms to create actionable field notes.",
    image: "https://picsum.photos/400/400?random=10"
  }
];

const Home = () => {
  const [statValues, setStatValues] = useState(statsTargets.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("All");

  useEffect(() => {
    const animations = statsTargets.map((target, index) => {
      let start = 0;
      const increment = Math.ceil(target.value / 80);
      const interval = window.setInterval(() => {
        start += increment;
        if (start >= target.value) {
          start = target.value;
          window.clearInterval(interval);
        }
        setStatValues((prev) =>
          prev.map((val, idx) => (idx === index ? start : val))
        );
      }, 20);
      return interval;
    });
    return () => animations.forEach((interval) => window.clearInterval(interval));
  }, []);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => window.clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === "All") return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  return (
    <>
      <Helmet>
        <title>DevLayer | Editorial Platform for Developer Workflows</title>
        <meta
          name="description"
          content="DevLayer helps engineering teams illuminate developer workflows, software systems, and cloud infrastructure through editorial depth and research-driven storytelling."
        />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "DevLayer",
            url: "https://www.devlayer.ca",
            logo: "https://www.devlayer.ca/logo.png",
            description:
              "Editorial platform dedicated to developer workflows, software systems, and cloud infrastructure.",
            address: {
              "@type": "PostalAddress",
              streetAddress: "333 Bay St",
              addressLocality: "Toronto",
              addressRegion: "ON",
              postalCode: "M5H 2R2",
              addressCountry: "Canada"
            },
            contactPoint: {
              "@type": "ContactPoint",
              telephone: "+1-416-905-6621",
              contactType: "editorial"
            },
            sameAs: [
              "https://github.com/devlayer",
              "https://www.linkedin.com/company/devlayer"
            ]
          })}
        </script>
      </Helmet>

      <section
        id="main"
        className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950"
      >
        <div className="container mx-auto px-4 py-16 lg:py-24 grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <motion.span
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 rounded-full border border-slate-700 px-4 py-2 text-xs uppercase tracking-widest text-blue-400"
            >
              Every Layer Tells a Story
            </motion.span>
            <motion.h1
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-6 font-satoshi text-4xl sm:text-5xl lg:text-6xl text-slate-100 leading-tight"
            >
              Editorial intelligence for developer workflows, software systems, and cloud infrastructure.
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="mt-6 text-lg text-slate-300"
            >
              DevLayer partners with platform teams to capture nuance, document reliable practices, and translate complexity into narratives that inspire confident engineering decisions.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="mt-10 flex flex-col sm:flex-row gap-4"
            >
              <Link
                to="/services"
                className="inline-flex items-center justify-center rounded-md bg-blue-500 px-6 py-3 text-sm font-semibold text-slate-900 shadow-lg shadow-blue-500/30 transition hover:bg-blue-400"
              >
                Explore Services
              </Link>
              <Link
                to="/about"
                className="inline-flex items-center justify-center rounded-md border border-slate-700 px-6 py-3 text-sm font-semibold text-slate-200 transition hover:border-blue-400 hover:text-blue-400"
              >
                Meet the Editors
              </Link>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="relative"
          >
            <div className="absolute -inset-6 rounded-3xl bg-blue-500/10 blur-3xl" />
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Engineers collaborating with layered system diagrams"
              loading="lazy"
              className="relative rounded-3xl border border-slate-800 shadow-2xl"
            />
          </motion.div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <h2 className="font-satoshi text-3xl text-slate-100">Impact in Numbers</h2>
        <p className="mt-3 text-slate-400 max-w-2xl">
          Our editorial research distills complex platform engineering realities into actionable insight across distributed teams.
        </p>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {statsTargets.map((stat, index) => (
            <div
              key={stat.label}
              className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-lg shadow-slate-900/30"
            >
              <p className="text-3xl font-semibold text-blue-400">
                {statValues[index]}
              </p>
              <p className="mt-2 text-sm text-slate-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid gap-12 lg:grid-cols-2 items-start">
          <div>
            <h2 className="font-satoshi text-3xl text-slate-100">What We Explore</h2>
            <p className="mt-3 text-slate-400">
              DevLayer is rooted in primary research, long-form documentation, and the belief that every engineering layer deserves narrative clarity.
            </p>
            <div className="mt-8 space-y-6">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
                <h3 className="text-xl font-semibold text-slate-100">Systems</h3>
                <p className="mt-3 text-sm text-slate-400">
                  From distributed computing foundations to runtime observability, we bring dimensional context to evolving platforms.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
                <h3 className="text-xl font-semibold text-slate-100">Workflows</h3>
                <p className="mt-3 text-sm text-slate-400">
                  We decode rituals, cadence, and tools that power sustainable developer workflows in hybrid environments.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
                <h3 className="text-xl font-semibold text-slate-100">Cognition</h3>
                <p className="mt-3 text-sm text-slate-400">
                  Engineering psychology informs our editorial practice, ensuring readability and empathy without sacrificing technical truth.
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-10">
            <h3 className="font-satoshi text-2xl text-slate-100">Workflow Process</h3>
            <p className="mt-3 text-slate-400">
              We move from discovery to evolution with collaborative checkpoints that keep your engineering community aligned.
            </p>
            <div className="mt-8 space-y-6">
              {processSteps.map((step) => (
                <div key={step.title} className="flex gap-4">
                  <div className="h-10 w-10 flex-none rounded-full border border-blue-500/30 text-blue-400 flex items-center justify-center font-semibold">
                    {processSteps.indexOf(step) + 1}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-slate-100">
                      {step.title}
                    </h4>
                    <p className="mt-2 text-sm text-slate-400">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <Link
              to="/services"
              className="mt-10 inline-flex items-center gap-2 rounded-md border border-blue-400 px-5 py-3 text-sm font-medium text-blue-300 hover:bg-blue-500/10"
            >
              See how we collaborate →
            </Link>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <h2 className="font-satoshi text-3xl text-slate-100">Featured Essays</h2>
            <p className="mt-3 text-slate-400 max-w-xl">
              Deep editorial explorations bridging developer workflows, systems architecture, and team cognition.
            </p>
          </div>
          <Link
            to="/blog"
            className="inline-flex items-center gap-2 text-sm font-medium text-blue-300 hover:text-blue-200"
          >
            View all essays →
          </Link>
        </div>

        <div className="mt-10 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {featuredEssays.map((essay) => (
            <article
              key={essay.title}
              className="group rounded-3xl border border-slate-800 bg-slate-900/60 overflow-hidden transition hover:-translate-y-2 hover:border-blue-500/40"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={essay.image}
                  alt={essay.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <div className="flex gap-2 flex-wrap text-xs uppercase tracking-widest text-blue-400">
                  {essay.tags.map((tag) => (
                    <span key={tag} className="rounded-full border border-blue-400/40 px-3 py-1">
                      {tag}
                    </span>
                  ))}
                </div>
                <h3 className="mt-4 font-satoshi text-xl text-slate-100">
                  {essay.title}
                </h3>
                <p className="mt-3 text-sm text-slate-400">{essay.excerpt}</p>
                <Link
                  to={essay.to}
                  className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-blue-300 hover:text-blue-200"
                >
                  Read essay →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24 grid gap-12 lg:grid-cols-2">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-10">
          <h2 className="font-satoshi text-3xl text-slate-100">Workflow Patterns</h2>
          <p className="mt-3 text-slate-400">
            Field-tested approaches that help distributed engineering teams sustain momentum.
          </p>
          <ul className="mt-6 space-y-4 text-sm text-slate-300">
            {workflowPatterns.map((pattern) => (
              <li key={pattern} className="flex gap-3">
                <span className="mt-1 h-2 w-2 rounded-full bg-blue-400" />
                {pattern}
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-10">
          <h2 className="font-satoshi text-3xl text-slate-100">Tooling Signals</h2>
          <p className="mt-3 text-slate-400">
            The diagnostics we surface to inform confident platform stewardship.
          </p>
          <div className="mt-6 space-y-6">
            {toolingSignals.map((signal) => (
              <div key={signal.title} className="rounded-2xl border border-slate-800 p-6 hover:border-blue-400/40 transition">
                <h3 className="text-lg font-semibold text-slate-100">{signal.title}</h3>
                <p className="mt-2 text-sm text-slate-400">{signal.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="font-satoshi text-3xl text-slate-100">Developer Mindset</h2>
            <p className="mt-3 text-slate-400">
              Editorial research infused with behavioral science to support mindful engineering.
            </p>
            <div className="mt-6 space-y-6">
              {developerMindset.map((item) => (
                <div key={item.title} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
                  <h3 className="text-lg font-semibold text-slate-100">{item.title}</h3>
                  <p className="mt-2 text-sm text-slate-400">{item.detail}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-10">
            <h2 className="font-satoshi text-3xl text-slate-100">Code History</h2>
            <p className="mt-3 text-slate-400">
              Honoring the references that shaped modern platform engineering practice.
            </p>
            <div className="mt-6 space-y-4">
              {codeHistory.map((item) => (
                <div key={item.title} className="rounded-2xl border border-slate-800 p-6">
                  <h3 className="text-lg font-semibold text-slate-100">{item.title}</h3>
                  <p className="mt-2 text-sm text-slate-400">{item.summary}</p>
                </div>
              ))}
            </div>
            <Link
              to="/archives"
              className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-blue-300 hover:text-blue-200"
            >
              Dive into archives →
            </Link>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <h2 className="font-satoshi text-3xl text-slate-100">Editorial Highlights</h2>
        <p className="mt-3 text-slate-400 max-w-2xl">
          A snapshot of ongoing narratives powering developer workflows, software systems, and cloud infrastructure.
        </p>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {editorialHighlights.map((item) => (
            <div key={item.title} className="group rounded-3xl border border-slate-800 bg-slate-900/60 p-8 transition hover:border-blue-400/40">
              <h3 className="text-xl font-semibold text-slate-100 group-hover:text-blue-300">
                {item.title}
              </h3>
              <p className="mt-3 text-sm text-slate-400">{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="font-satoshi text-3xl text-slate-100">Reading Queue</h2>
            <p className="mt-3 text-slate-400">
              Curated references we are analyzing next, with concise summaries and research tags.
            </p>
            <div className="mt-6 space-y-6">
              {readingQueue.map((item) => (
                <div key={item.title} className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
                  <h3 className="text-lg font-semibold text-slate-100">{item.title}</h3>
                  <p className="mt-2 text-sm text-slate-400">{item.summary}</p>
                  <div className="mt-4 flex flex-wrap gap-2 text-xs uppercase tracking-widest text-blue-400">
                    {item.tags.map((tag) => (
                      <span key={tag} className="rounded-full border border-blue-400/40 px-3 py-1">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <Link
              to="/queue"
              className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-blue-300 hover:text-blue-200"
            >
              View full queue →
            </Link>
          </div>
          <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-10">
            <h2 className="font-satoshi text-3xl text-slate-100">Testimonials</h2>
            <p className="mt-3 text-slate-400">
              Perspectives from teams that trust DevLayer with their platform narratives.
            </p>
            <div className="mt-8">
              <motion.blockquote
                key={currentTestimonial}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="text-lg text-slate-200"
              >
                “{testimonials[currentTestimonial].quote}”
              </motion.blockquote>
              <div className="mt-6 text-sm text-slate-400">
                <p className="font-medium text-slate-200">
                  {testimonials[currentTestimonial].name}
                </p>
                <p>{testimonials[currentTestimonial].role}</p>
              </div>
              <div className="mt-8 flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentTestimonial(index)}
                    aria-label={`Show testimonial ${index + 1}`}
                    className={`h-2 w-8 rounded-full transition ${
                      index === currentTestimonial
                        ? "bg-blue-400"
                        : "bg-slate-700"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-10">
          <div className="lg:w-1/2">
            <h2 className="font-satoshi text-3xl text-slate-100">Services Snapshot</h2>
            <p className="mt-3 text-slate-400">
              Our editorial services help you align workflows, systems, and culture with narratives that resonate.
            </p>
          </div>
          <div className="lg:w-1/2 flex gap-3">
            {["All", "Workflow", "Systems", "Tooling"].map((category) => (
              <button
                key={category}
                onClick={() => setProjectFilter(category === "All" ? "All" : category)}
                className={`rounded-full border px-4 py-2 text-sm transition ${
                  projectFilter === category
                    ? "border-blue-400 bg-blue-500/10 text-blue-300"
                    : "border-slate-700 text-slate-300 hover:border-blue-400/40"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-10 grid gap-10 lg:grid-cols-3">
          {ServicesCards.map((service) => (
            <div key={service.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8 hover:border-blue-400/40 transition">
              <h3 className="text-xl font-semibold text-slate-100">{service.title}</h3>
              <p className="mt-3 text-sm text-slate-400">{service.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          {filteredProjects.map((project) => (
            <div key={project.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 overflow-hidden">
              <div className="relative h-60 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-500 hover:scale-105"
                />
              </div>
              <div className="p-8">
                <span className="inline-flex text-xs uppercase tracking-widest text-blue-400">
                  {project.category}
                </span>
                <h3 className="mt-3 text-2xl font-semibold text-slate-100">
                  {project.title}
                </h3>
                <p className="mt-3 text-sm text-slate-400">{project.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <h2 className="font-satoshi text-3xl text-slate-100">Meet the Team</h2>
            <p className="mt-3 text-slate-400">
              Our editors blend platform engineering experience with research-backed storytelling to elevate developer discourse.
            </p>
            <Link
              to="/about"
              className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-blue-300 hover:text-blue-200"
            >
              Learn more about our mission →
            </Link>
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            {TeamMembers.map((member) => (
              <div key={member.name} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 text-center hover:border-blue-400/40 transition">
                <img
                  src={member.image}
                  alt={member.name}
                  loading="lazy"
                  className="mx-auto h-24 w-24 rounded-full object-cover"
                />
                <h3 className="mt-4 text-lg font-semibold text-slate-100">
                  {member.name}
                </h3>
                <p className="text-xs uppercase tracking-widest text-blue-400">
                  {member.role}
                </p>
                <p className="mt-3 text-sm text-slate-400">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <h2 className="font-satoshi text-3xl text-slate-100">Frequently Asked Questions</h2>
        <p className="mt-3 text-slate-400 max-w-2xl">
          Answers to the questions we hear most when teams consider DevLayer as an editorial ally.
        </p>
        <div className="mt-8 space-y-4">
          {faqItems.map((item, index) => (
            <details
              key={item.question}
              className="group rounded-3xl border border-slate-800 bg-slate-900/60 p-6"
            >
              <summary className="flex cursor-pointer items-center justify-between text-lg font-semibold text-slate-100">
                {item.question}
                <span className="text-blue-400 group-open:rotate-45 transition">+</span>
              </summary>
              <p className="mt-4 text-sm text-slate-400">{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <h2 className="font-satoshi text-3xl text-slate-100">Latest Editorial Signals</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {blogPreview.map((post) => (
            <div key={post.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-6 hover:border-blue-400/40 transition">
              <p className="text-xs uppercase tracking-widest text-blue-400">{post.date}</p>
              <h3 className="mt-3 text-lg font-semibold text-slate-100">{post.title}</h3>
              <Link
                to={post.link}
                className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-blue-300 hover:text-blue-200"
              >
                Continue reading →
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="rounded-3xl border border-blue-500/30 bg-blue-500/10 p-10 text-center shadow-lg shadow-blue-500/20">
          <h2 className="font-satoshi text-3xl text-slate-100">Join the DevLayer Newsletter</h2>
          <p className="mt-3 text-slate-200">
            Monthly editorial briefings on developer workflows, software systems, cloud infrastructure, and engineering psychology.
          </p>
          <form className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <label className="sr-only" htmlFor="newsletter-email">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              required
              placeholder="you@company.com"
              className="w-full sm:w-96 rounded-md border border-blue-400/40 bg-slate-900/80 px-4 py-3 text-sm text-slate-100 placeholder:text-slate-500 focus:border-blue-400 focus:outline-none"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center rounded-md bg-blue-500 px-6 py-3 text-sm font-semibold text-slate-900 transition hover:bg-blue-400"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>

      <section className="container mx-auto px-4 py-16">
        <p className="text-center text-xs text-slate-500">
          DevLayer content is for educational use only.
        </p>
      </section>
    </>
  );
};

export default Home;