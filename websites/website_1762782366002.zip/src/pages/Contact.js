// @ts-check
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";

const Contact = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState({ name: "", email: "", message: "" });

  const validate = () => {
    const newErrors = { name: "", email: "", message: "" };
    if (!form.name.trim()) newErrors.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      newErrors.email = "Please provide a valid email.";
    if (form.message.trim().length < 10)
      newErrors.message = "Please share a bit more context.";
    setErrors(newErrors);
    return !newErrors.name && !newErrors.email && !newErrors.message;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      navigate("/contact/thanks", { state: { name: form.name } });
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact DevLayer | Editorial Partnerships</title>
        <meta
          name="description"
          content="Connect with DevLayer to explore editorial partnerships focused on developer workflows, software systems, and cloud infrastructure."
        />
      </Helmet>
      <section className="container mx-auto px-4 py-16 lg:py-24">
        <h1 className="font-satoshi text-4xl text-slate-100">Contact</h1>
        <p className="mt-4 text-slate-300 max-w-3xl">
          We welcome conversations with engineering leaders, technical writers, and research partners. Share your context and we will respond within two business days.
        </p>

        <div className="mt-12 grid gap-12 lg:grid-cols-2">
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8 space-y-6"
            noValidate
          >
            <div>
              <label className="block text-sm font-medium text-slate-300" htmlFor="name">
                Name
              </label>
              <input
                id="name"
                name="name"
                value={form.name}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, name: e.target.value }))
                }
                className="mt-2 w-full rounded-md border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-slate-100 focus:border-blue-400 focus:outline-none"
                placeholder="Your full name"
              />
              {errors.name && (
                <p className="mt-2 text-xs text-red-400">{errors.name}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, email: e.target.value }))
                }
                className="mt-2 w-full rounded-md border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-slate-100 focus:border-blue-400 focus:outline-none"
                placeholder="you@company.com"
              />
              {errors.email && (
                <p className="mt-2 text-xs text-red-400">{errors.email}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300" htmlFor="message">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={6}
                value={form.message}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, message: e.target.value }))
                }
                className="mt-2 w-full rounded-md border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-slate-100 focus:border-blue-400 focus:outline-none"
                placeholder="Tell us about your workflows, systems, or editorial needs."
              />
              {errors.message && (
                <p className="mt-2 text-xs text-red-400">{errors.message}</p>
              )}
            </div>
            <button
              type="submit"
              className="inline-flex items-center justify-center rounded-md bg-blue-500 px-6 py-3 text-sm font-semibold text-slate-900 transition hover:bg-blue-400"
            >
              Send Message
            </button>
          </form>

          <div className="space-y-6">
            <div className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
              <h2 className="text-xl font-semibold text-slate-100">Contact Details</h2>
              <ul className="mt-4 space-y-3 text-sm text-slate-400">
                <li>Address: 333 Bay St, Toronto, ON M5H 2R2, Canada</li>
                <li>Phone: <a className="text-blue-300" href="tel:+14169056621">+1 (416) 905-6621</a></li>
                <li>Email: <a className="text-blue-300" href="mailto:editorial@devlayer.ca">editorial@devlayer.ca</a></li>
                <li>
                  GitHub:{" "}
                  <a
                    className="text-blue-300"
                    href="https://github.com/devlayer"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    github.com/devlayer
                  </a>
                </li>
                <li>
                  LinkedIn:{" "}
                  <a
                    className="text-blue-300"
                    href="https://www.linkedin.com/company/devlayer"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    linkedin.com/company/devlayer
                  </a>
                </li>
              </ul>
            </div>
            <div className="overflow-hidden rounded-3xl border border-slate-800">
              <iframe
                title="DevLayer Toronto office location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.5488665080284!2d-79.380695!3d43.648704!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d2e0db7537%3A0x6af3c41c6f0efa7!2s333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2!5e0!3m2!1sen!2sca!4v1699900000000!5m2!1sen!2sca"
                width="100%"
                height="260"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;