// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const sections = [
  {
    title: "CI/CD Rituals",
    description:
      "We translate complex CI/CD pipelines into approachable narratives that highlight branching strategies, artifact management, and release gates."
  },
  {
    title: "Build Pipelines",
    description:
      "Detailed documentation of build automation, dependency governance, and security scanning integrated with workflow diagrams."
  },
  {
    title: "IDE Ergonomics",
    description:
      "Research-backed guidance on IDE configuration, pairing techniques, and plugin selection that respect developer cognition."
  },
  {
    title: "Team Rituals",
    description:
      "Facilitation frameworks for stand-ups, backlog curation, demos, and retrospectives aligned with asynchronous collaboration."
  }
];

const Workflows = () => (
  <>
    <Helmet>
      <title>Developer Workflows | DevLayer</title>
      <meta
        name="description"
        content="DevLayer documents CI/CD practices, build pipelines, IDE ergonomics, and team rituals to strengthen developer workflows."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Workflows</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        Our workflow practice analyzes how engineering teams operate daily—from automation pipelines to communication rituals—and documents patterns that foster consistent delivery.
      </p>
      <div className="mt-10 grid gap-8 md:grid-cols-2">
        {sections.map((section) => (
          <div key={section.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
            <h2 className="text-xl font-semibold text-slate-100">{section.title}</h2>
            <p className="mt-3 text-sm text-slate-400">{section.description}</p>
          </div>
        ))}
      </div>
    </section>
  </>
);

export default Workflows;