// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use | DevLayer</title>
      <meta
        name="description"
        content="Review DevLayer’s terms of use covering platform usage, intellectual property, disclaimers, and jurisdiction."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Terms of Use</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        These terms govern your access to DevLayer content and services. By exploring our website, you agree to the principles outlined below.
      </p>
      <div className="mt-10 space-y-8 text-sm text-slate-400">
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Platform Usage</h2>
          <p className="mt-3">
            DevLayer provides editorial material for educational purposes. You may reference our work with attribution. Unauthorized reproduction or redistribution is prohibited without written consent.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Intellectual Property</h2>
          <p className="mt-3">
            All articles, design assets, and research summaries are original works owned by DevLayer unless otherwise noted. Third-party trademarks remain the property of their respective owners.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Disclaimer</h2>
          <p className="mt-3">
            Content on DevLayer is for educational use only. We do not provide legal or financial advice. Technical decisions should be validated against your organization’s governance policies.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Jurisdiction</h2>
          <p className="mt-3">
            DevLayer operates from Ontario, Canada. Any disputes will be resolved under the laws of Ontario and the laws of Canada applicable therein.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Changes</h2>
          <p className="mt-3">
            We may update these terms to reflect evolving editorial practices. Updates will be timestamped and effective upon publication.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Terms;