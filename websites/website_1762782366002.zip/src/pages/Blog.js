// @ts-check
import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

const posts = [
  {
    title: "Why Context Switching Kills Productivity",
    excerpt:
      "Investigating cognitive load and strategies to protect focus within distributed teams using research from engineering psychology.",
    tags: ["Workflow", "engineering psychology"],
    link: "/blog/why-context-switching-kills-productivity"
  },
  {
    title: "Cloud Patterns for Scale",
    excerpt:
      "A synthesis of cloud infrastructure principles, platform engineering tactics, and distributed computing lessons.",
    tags: ["Systems", "cloud infrastructure"],
    link: "/blog/cloud-patterns-for-scale"
  },
  {
    title: "The Evolution of DevOps Culture",
    excerpt:
      "Tracing the history of devops culture, workflow agreements, and tooling cooperation shaping modern platform engineering.",
    tags: ["Culture", "devops culture"],
    link: "/blog/the-evolution-of-devops-culture"
  }
];

const filters = ["All", "Workflow", "Systems", "Tooling", "Culture"];

const Blog = () => {
  const [filter, setFilter] = useState("All");
  const filtered = posts.filter((post) =>
    filter === "All" ? true : post.tags.map((tag) => tag.toLowerCase()).includes(filter.toLowerCase())
  );

  return (
    <>
      <Helmet>
        <title>DevLayer Blog | Essays on Developer Workflows and Systems</title>
        <meta
          name="description"
          content="Browse DevLayer’s editorial essays exploring developer workflows, software systems, tooling signals, and devops culture."
        />
      </Helmet>
      <section className="container mx-auto px-4 py-16 lg:py-24">
        <h1 className="font-satoshi text-4xl text-slate-100">Editorial Essays</h1>
        <p className="mt-4 text-slate-300 max-w-3xl">
          Dive into research-backed insights where platform engineering practice meets thoughtful storytelling.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          {filters.map((item) => (
            <button
              key={item}
              onClick={() => setFilter(item)}
              className={`rounded-full border px-4 py-2 text-sm transition ${
                filter === item
                  ? "border-blue-400 bg-blue-500/10 text-blue-200"
                  : "border-slate-700 text-slate-300 hover:border-blue-400/40"
              }`}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="mt-10 grid gap-8 md:grid-cols-2">
          {filtered.map((post) => (
            <article
              key={post.title}
              className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8 hover:border-blue-400/40 transition"
            >
              <div className="text-xs uppercase tracking-widest text-blue-400">
                {post.tags.join(" • ")}
              </div>
              <h2 className="mt-4 text-2xl font-semibold text-slate-100">
                {post.title}
              </h2>
              <p className="mt-3 text-sm text-slate-400">{post.excerpt}</p>
              <Link
                to={post.link}
                className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-blue-300 hover:text-blue-200"
              >
                Read essay →
              </Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;