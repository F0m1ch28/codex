// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const notes = [
  {
    title: "Editorial Infrastructure Upgrade",
    content:
      "We introduced a new knowledge garden template to make internal documentation more discoverable across teams."
  },
  {
    title: "Research Residency Launch",
    content:
      "A rotating residency invites platform engineers to co-author essays on emerging distributed computing practices."
  },
  {
    title: "Field Report Template Refresh",
    content:
      "Updated our workflow field report format to include ritual cadence, signal hygiene, and decision journaling prompts."
  }
];

const Notes = () => (
  <>
    <Helmet>
      <title>Notes | DevLayer</title>
      <meta
        name="description"
        content="DevLayer notes highlight quick editorial updates, platform improvements, and internal commentary."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Notes</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        Short editorial updates documenting experiments, platform improvements, and upcoming initiatives within DevLayer.
      </p>
      <div className="mt-10 space-y-6">
        {notes.map((note) => (
          <div key={note.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
            <h2 className="text-xl font-semibold text-slate-100">{note.title}</h2>
            <p className="mt-3 text-sm text-slate-400">{note.content}</p>
          </div>
        ))}
      </div>
    </section>
  </>
);

export default Notes;