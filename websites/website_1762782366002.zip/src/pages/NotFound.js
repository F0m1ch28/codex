// @ts-check
import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";

const NotFound = () => (
  <>
    <Helmet>
      <title>Page Not Found | DevLayer</title>
      <meta
        name="description"
        content="The page you are looking for could not be found on DevLayer."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-32 text-center">
      <h1 className="font-satoshi text-5xl text-slate-100">404</h1>
      <p className="mt-4 text-slate-300">
        We couldn’t find that layer. Try heading back to the main flow.
      </p>
      <Link
        to="/"
        className="mt-6 inline-flex items-center justify-center rounded-md bg-blue-500 px-6 py-3 text-sm font-semibold text-slate-900 hover:bg-blue-400"
      >
        Return Home
      </Link>
    </section>
  </>
);

export default NotFound;