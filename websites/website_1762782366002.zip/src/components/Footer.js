// @ts-check
import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={`${styles.footer} bg-slate-900 border-t border-slate-800`}>
      <div className="container mx-auto px-4 py-12 grid gap-10 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <h3 className="font-satoshi text-xl text-slate-100">DevLayer</h3>
          <p className="mt-4 text-sm text-slate-400">
            Independent editorial platform decoding developer workflows, software
            systems, cloud infrastructure, and the psychology of resilient engineering teams.
          </p>
        </div>

        <div>
          <h4 className="font-semibold text-slate-200">Navigation</h4>
          <ul className="mt-4 space-y-2 text-sm text-slate-400">
            <li><Link to="/about" className="hover:text-blue-400">About</Link></li>
            <li><Link to="/services" className="hover:text-blue-400">Services</Link></li>
            <li><Link to="/workflows" className="hover:text-blue-400">Workflows</Link></li>
            <li><Link to="/mindset" className="hover:text-blue-400">Mindset</Link></li>
            <li><Link to="/blog" className="hover:text-blue-400">Blog</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-slate-200">Resources</h4>
          <ul className="mt-4 space-y-2 text-sm text-slate-400">
            <li><Link to="/queue" className="hover:text-blue-400">Reading Queue</Link></li>
            <li><Link to="/archives" className="hover:text-blue-400">Archives</Link></li>
            <li><Link to="/notes" className="hover:text-blue-400">Notes</Link></li>
            <li><Link to="/privacy" className="hover:text-blue-400">Privacy</Link></li>
            <li><Link to="/terms" className="hover:text-blue-400">Terms</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-slate-200">Contact</h4>
          <ul className="mt-4 text-sm text-slate-400 space-y-2">
            <li>333 Bay St, Toronto, ON M5H 2R2, Canada</li>
            <li>+1 (416) 905-6621</li>
            <li>
              <a href="mailto:editorial@devlayer.ca" className="hover:text-blue-400">
                editorial@devlayer.ca
              </a>
            </li>
            <li>
              <a
                href="https://github.com/devlayer"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-blue-400"
              >
                GitHub
              </a>
            </li>
            <li>
              <a
                href="https://www.linkedin.com/company/devlayer"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-blue-400"
              >
                LinkedIn
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} DevLayer. Crafted in Toronto for developer communities.
      </div>
    </footer>
  );
};

export default Footer;