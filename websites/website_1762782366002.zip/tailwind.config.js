module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      colors: {
        slate: {
          900: "#111827",
          950: "#0b1220"
        }
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        satoshi: ["Satoshi", "Inter", "system-ui", "sans-serif"]
      }
    }
  },
  plugins: []
};