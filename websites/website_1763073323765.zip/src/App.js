import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';

import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import RouteScrollToTop from './components/RouteScrollToTop';

import Home from './pages/Home';
import Services from './pages/Services';
import Portfolio from './pages/Portfolio';
import About from './pages/About';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import NotFound from './pages/NotFound';

const App = () => {
  return (
    <div className="app">
      <Helmet>
        <html lang="ru" />
        <title>ArtVision Studio — дизайн-студия в Москве</title>
        <meta
          name="description"
          content="ArtVision Studio создает креативные бренды, визуальные системы и цифровые продукты, которые усиливают бизнес."
        />
        <meta
          name="keywords"
          content="креативный дизайн, брендинг, UI UX, графический дизайн, веб-дизайн, ArtVision Studio"
        />
      </Helmet>
      <Header />
      <RouteScrollToTop />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;