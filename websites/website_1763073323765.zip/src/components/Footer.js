import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div>
            <h3 className={styles.title}>ArtVision Studio</h3>
            <p className={styles.text}>
              Мы создаем визуальные решения, которые работают на рост вашего бренда и помогают бизнесу звучать ярче.
            </p>
            <div className={styles.contacts}>
              <a href="tel:+74951234567" className={styles.link}>
                +7 (495) 123-45-67
              </a>
              <a href="mailto:hello@artvision.ru" className={styles.link}>
                hello@artvision.ru
              </a>
              <p className={styles.text}>ул. Творческая, 15, Москва, Россия</p>
            </div>
          </div>
          <div>
            <h4 className={styles.subtitle}>Навигация</h4>
            <ul className={styles.list}>
              <li>
                <Link to="/services" className={styles.link}>
                  Услуги
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className={styles.link}>
                  Портфолио
                </Link>
              </li>
              <li>
                <Link to="/about" className={styles.link}>
                  О студии
                </Link>
              </li>
              <li>
                <Link to="/contact" className={styles.link}>
                  Контакты
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className={styles.subtitle}>Правовая информация</h4>
            <ul className={styles.list}>
              <li>
                <Link to="/privacy" className={styles.link}>
                  Политика конфиденциальности
                </Link>
              </li>
              <li>
                <Link to="/cookie-policy" className={styles.link}>
                  Cookie policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className={styles.link}>
                  Условия использования
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <span>© {new Date().getFullYear()} ArtVision Studio. Все права защищены.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;