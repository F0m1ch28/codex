import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'artvision_cookie_consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner}>
      <div className={styles.content}>
        <p>
          Мы используем cookies, чтобы сделать взаимодействие со студией еще удобнее. Продолжая пользоваться сайтом, вы соглашаетесь с{' '}
          <Link to="/cookie-policy">политикой использования cookies</Link>.
        </p>
      </div>
      <button className={styles.button} onClick={handleAccept}>
        Согласен
      </button>
    </div>
  );
};

export default CookieBanner;