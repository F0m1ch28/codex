import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const team = [
  {
    name: 'Екатерина Лебедева',
    role: 'Арт-директор',
    description: 'Курирует креативные концепции и обеспечивает целостность визуальных решений брендов и продуктов.',
    image: 'https://picsum.photos/seed/av-team-1/360/360'
  },
  {
    name: 'Илья Соколов',
    role: 'Lead UX-стратег',
    description: 'Проводит исследовательские спринты, формирует пользовательские сценарии и метрики успешности.',
    image: 'https://picsum.photos/seed/av-team-2/360/360'
  },
  {
    name: 'Марина Коваль',
    role: 'Head of Design Ops',
    description: 'Отвечает за процессы, синхронизацию команд и внедрение дизайн-систем в продуктах клиентов.',
    image: 'https://picsum.photos/seed/av-team-3/360/360'
  }
];

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>О студии ArtVision — команда и подход</title>
        <meta
          name="description"
          content="ArtVision Studio — команда стратегов, дизайнеров и исследователей. Узнайте о нашей философии, процессах и экспертизе."
        />
      </Helmet>

      <section className="container">
        <div className={styles.hero}>
          <div>
            <h1>ArtVision Studio</h1>
            <p>
              Мы объединяем креатив и стратегию, чтобы бренды звучали убедительно на всех точках контакта. Студия основана в 2011 году и
              выросла из небольшого креативного бюро в партнерскую команду специалистов по брендингу, цифровому дизайну и коммуникациям.
            </p>
          </div>
          <div className={styles.mission}>
            <h2>Миссия</h2>
            <p>
              Помогать бизнесу создавать впечатляющие визуальные истории, которые поддерживаются данными, исследованиями и точным
              исполнением.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.values} container`}>
        <h2>Наши принципы</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Прозрачность и партнерство</h3>
            <p>
              Работаем в тесной связке с командами клиентов. Строим проект на честном диалоге, регулярной отчетности и совместном принятии
              решений.
            </p>
          </article>
          <article>
            <h3>Фокус на результат</h3>
            <p>
              Дизайн — это не только визуальная эстетика. Мы измеряем эффективность через метрики бизнеса и адаптируем решения исходя из
              обратной связи.
            </p>
          </article>
          <article>
            <h3>Непрерывное развитие</h3>
            <p>
              Внедряем новые инструменты, дизайн-системы и методики. Обучаем команды клиентов, чтобы решения были устойчивыми.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2>Команда, которая влюблена в детали</h2>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name}>
                <img src={member.image} alt={`${member.name}, ${member.role}`} />
                <div>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;