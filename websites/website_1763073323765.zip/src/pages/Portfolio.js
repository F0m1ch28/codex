import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Portfolio.module.css';

const projects = [
  {
    id: 1,
    title: 'Nordic Essence',
    category: 'Брендинг',
    description: 'Премиальная айдентика и упаковка для бренда ароматов, отражающего чистоту северной природы.',
    image: 'https://picsum.photos/seed/portfolio-1/720/540'
  },
  {
    id: 2,
    title: 'FlowBank App',
    category: 'UI/UX',
    description: 'Дизайн мобильного банка с расширенной аналитикой и персональными рекомендациями.',
    image: 'https://picsum.photos/seed/portfolio-2/720/540'
  },
  {
    id: 3,
    title: 'FutureLab Conference',
    category: 'Графический дизайн',
    description: 'Коммуникационная платформа и визуальная кампания для международного форума.',
    image: 'https://picsum.photos/seed/portfolio-3/720/540'
  },
  {
    id: 4,
    title: 'Mirovoy Agro',
    category: 'Брендинг',
    description: 'Ребрендинг агрохолдинга с акцентом на инновационные технологии и устойчивость.',
    image: 'https://picsum.photos/seed/portfolio-4/720/540'
  },
  {
    id: 5,
    title: 'Vista CRM',
    category: 'UI/UX',
    description: 'Продуктовый дизайн SaaS-сервиса с оптимизацией ключевых сценариев продаж.',
    image: 'https://picsum.photos/seed/portfolio-5/720/540'
  },
  {
    id: 6,
    title: 'ArtVibe Motion',
    category: 'Графический дизайн',
    description: 'Motion-дизайн и визуальные эффекты для digital-кампании музыкального фестиваля.',
    image: 'https://picsum.photos/seed/portfolio-6/720/540'
  }
];

const filters = ['Все', 'Брендинг', 'UI/UX', 'Графический дизайн'];

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState('Все');

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Все') return projects;
    return projects.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Портфолио ArtVision Studio — реализованные проекты</title>
        <meta
          name="description"
          content="Избранные проекты ArtVision Studio: брендинг, UI/UX и графический дизайн. Узнайте, как мы решаем задачи клиентов."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <div>
            <h1>Портфолио</h1>
            <p>
              От стартапов до крупных экосистем — каждая работа отражает партнерский подход, глубокую аналитику и точную визуальную
              стратегию.
            </p>
          </div>
          <div className={styles.filters}>
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={activeFilter === filter ? styles.activeFilter : ''}
              >
                {filter}
              </button>
            ))}
          </div>
        </header>

        <div className={styles.grid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.card}>
              <img src={project.image} alt={`Проект ArtVision Studio — ${project.title}`} />
              <div className={styles.cardBody}>
                <span>{project.category}</span>
                <h2>{project.title}</h2>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Portfolio;