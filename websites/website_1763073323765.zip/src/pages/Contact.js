import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [status, setStatus] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('Спасибо! Мы свяжемся с вами в течение рабочего дня.');
    event.target.reset();
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты ArtVision Studio — обсудить проект</title>
        <meta
          name="description"
          content="Свяжитесь с ArtVision Studio: телефон, email, адрес в Москве. Заполните форму, чтобы обсудить проект по дизайну и брендингу."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <div>
            <h1>Контакты</h1>
            <p>
              Расскажите о своей задаче — команда ArtVision подготовит концепцию сотрудничества и предложит персональную стратегию
              дизайна.
            </p>
          </div>

          <div className={styles.info}>
            <div>
              <span>Телефон</span>
              <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            </div>
            <div>
              <span>Email</span>
              <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
            </div>
            <div>
              <span>Адрес</span>
              <p>ул. Творческая, 15, Москва, Россия</p>
            </div>
          </div>
        </header>

        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit}>
            <label>
              Имя
              <input type="text" name="name" placeholder="Как к вам обращаться?" required />
            </label>
            <label>
              Email
              <input type="email" name="email" placeholder="you@company.com" required />
            </label>
            <label>
              Компания
              <input type="text" name="company" placeholder="Название компании" />
            </label>
            <label>
              Сообщение
              <textarea name="message" rows="5" placeholder="Кратко опишите задачу, сроки и желаемый результат." required />
            </label>
            <button type="submit" className="buttonPrimary">
              Отправить заявку
            </button>
            {status && <p className={styles.status}>{status}</p>}
          </form>

          <div className={styles.mapWrapper}>
            <iframe
              title="Карта проезда ArtVision Studio"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1998.844899255994!2d37.62039331632927!3d55.75396098055239!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x414aa5eab8f0ca5d%3A0xaca3f29cd0d0b2b4!2z0JzQvtGB0LrQstCw0YAg0J3QvtCy0LDRgNC40Y8g0LjQvdGB0LrQsNGPINCb0LXQvdGC0YAg0KPQvdC40LLQtdGA0YHQvtCy0YHQutCw!5e0!3m2!1sru!2sru!4v1678900000000!5m2!1sru!2sru"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;