import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const CookiePolicy = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Политика использования cookies — ArtVision Studio</title>
        <meta name="description" content="Информация о том, как ArtVision Studio использует файлы cookies на сайте." />
      </Helmet>
      <section className="container">
        <h1>Политика использования cookies</h1>
        <p>
          Cookies помогают нам улучшать работу сайта и делать взаимодействие с ним более удобным. Продолжая использовать сайт, вы
          соглашаетесь с использованием cookies.
        </p>
        <h2>1. Что такое cookies</h2>
        <p>
          Cookies — это небольшие текстовые файлы, которые сохраняются на вашем устройстве. Они позволяют распознавать вас и сохранять
          настройки при повторных посещениях.
        </p>
        <h2>2. Какие cookies мы используем</h2>
        <ul>
          <li>Технические cookies — обеспечивают корректную работу сайта</li>
          <li>Аналитические cookies — помогают понять, как пользователи взаимодействуют с контентом</li>
          <li>Функциональные cookies — сохраняют ваши предпочтения</li>
        </ul>
        <h2>3. Управление cookies</h2>
        <p>
          Вы можете настроить использование cookies в параметрах браузера или удалить существующие файлы. Ограничение использования
          cookies может повлиять на корректность работы отдельных функций сайта.
        </p>
      </section>
    </div>
  );
};

export default CookiePolicy;