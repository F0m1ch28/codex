import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const NotFound = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Страница не найдена — ArtVision Studio</title>
      </Helmet>
      <section className="container">
        <h1>404 — Страница не найдена</h1>
        <p>Запрошенная страница не существует или была перемещена. Вернитесь на главную или изучите наши проекты.</p>
        <Link to="/" className="buttonPrimary">
          На главную
        </Link>
      </section>
    </div>
  );
};

export default NotFound;