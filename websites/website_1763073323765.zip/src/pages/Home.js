import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>ArtVision Studio — креативный брендинг и дизайн</title>
        <meta
          name="description"
          content="ArtVision Studio создает узнаваемые бренды и впечатляющие цифровые продукты. Креативный дизайн, UI/UX и графика на одной волне с вашим бизнесом."
        />
      </Helmet>

      <section className={`${styles.hero} container`}>
        <div className={styles.heroContent}>
          <span className={styles.badge}>Дизайн-студия полного цикла</span>
          <h1>ArtVision Studio — дизайн, который усиливает бренды</h1>
          <p>
            Мы объединяем стратегию, креатив и технологии, чтобы создавать визуальные решения, которые вдохновляют клиентов и
            масштабируют бизнес. От айдентики до цифровых продуктов — каждая деталь продумана и подкреплена исследованием.
          </p>
          <div className={styles.cta}>
            <Link className="buttonPrimary" to="/contact">
              Связаться с командой
            </Link>
            <Link className="buttonGhost" to="/portfolio">
              Смотреть портфолио
            </Link>
          </div>
          <dl className={styles.metrics}>
            <div>
              <dt>12+</dt>
              <dd>лет опыта в брендинге и цифровом дизайне</dd>
            </div>
            <div>
              <dt>180+</dt>
              <dd>успешных проектов для лидеров рынка и стартапов</dd>
            </div>
            <div>
              <dt>4.9/5</dt>
              <dd>уровень удовлетворенности клиентов студии</dd>
            </div>
          </dl>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/seed/artvision-hero/720/540"
            alt="Команда ArtVision Studio работает над креативной концепцией"
          />
        </div>
      </section>

      <section className={`${styles.servicesPreview} container`}>
        <header>
          <h2>Ключевые направления</h2>
          <p>
            Создаем целостные визуальные коммуникации: от стратегии бренда до цифровых интерфейсов и печатных материалов. Каждое решение
            сочетает эстетику и измеримые бизнес-результаты.
          </p>
        </header>
        <div className={styles.serviceGrid}>
          <article className={styles.serviceCard}>
            <h3>Брендинг и айдентика</h3>
            <p>
              Формируем визуальный язык бренда, включая нейминг, логотипы, гайдлайны и tone of voice. Помогаем компаниям звучать ярко и
              последовательно.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <h3>UI/UX дизайн</h3>
            <p>
              Проектируем пользовательские сценарии, прототипы и визуальные концепты цифровых продуктов, которые обеспечивают высокий
              уровень вовлеченности и конверсии.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <h3>Графический и рекламный дизайн</h3>
            <p>
              Создаем промо-материалы, презентации, печатную продукцию и иллюстрации, поддерживающие ваши маркетинговые активности.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <h2>Методология ArtVision</h2>
          <div className={styles.processGrid}>
            <div>
              <span>01</span>
              <h3>Стратегический анализ</h3>
              <p>
                Изучаем ваш бренд, аудиторию и контекст рынка, чтобы сформулировать дизайн-задачу и ключевые метрики успеха.
              </p>
            </div>
            <div>
              <span>02</span>
              <h3>Креативная разработка</h3>
              <p>
                Генерируем идеи, прототипируем и тестируем визуальные решения. Ищем баланс между эстетикой, функциональностью и
                эффективностью.
              </p>
            </div>
            <div>
              <span>03</span>
              <h3>Внедрение и поддержка</h3>
              <p>
                Сопровождаем запуск, адаптируем дизайн к разным носителям и помогаем командам внедрить новые визуальные стандарты.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.portfolioPreview} container`}>
        <header>
          <h2>Последние проекты</h2>
          <p>Каждый проект — результат партнерства, аналитики и стремления создать незабываемый пользовательский опыт.</p>
        </header>
        <div className={styles.portfolioGrid}>
          <article>
            <img src="https://picsum.photos/seed/av-portfolio-1/600/420" alt="Айдентика ароматического бренда Nordic Essence" />
            <div>
              <h3>Nordic Essence</h3>
              <p>Комплексная айдентика и упаковка для премиального бренда ароматов, вдохновленного северной природой.</p>
            </div>
          </article>
          <article>
            <img src="https://picsum.photos/seed/av-portfolio-2/600/420" alt="Интерфейс мобильного приложения FlowBank" />
            <div>
              <h3>FlowBank App</h3>
              <p>UI/UX дизайн мобильного банка с расширенной аналитикой и интуитивной навигацией для частных клиентов.</p>
            </div>
          </article>
          <article>
            <img src="https://picsum.photos/seed/av-portfolio-3/600/420" alt="Динамическая digital-кампания для конференции FutureLab" />
            <div>
              <h3>FutureLab Conference</h3>
              <p>Digital-платформа и рекламная кампания для международного технологического форума о будущем инноваций.</p>
            </div>
          </article>
        </div>
        <div className={styles.portfolioCta}>
          <Link to="/portfolio" className="buttonPrimary">
            Полное портфолио
          </Link>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Готовы усилить визуальный образ бренда?</h2>
              <p>
                Расскажите нам о задаче, а мы предложим стратегию и дизайн-решения, которые помогут вам выделиться и добиться нужных
                бизнес-результатов.
              </p>
            </div>
            <Link to="/contact" className="buttonGhost">
              Обсудить проект
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;