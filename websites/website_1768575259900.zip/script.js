document.addEventListener('DOMContentLoaded', function () {
    var menuToggle = document.querySelector('.menu-toggle');
    var navLinks = document.querySelector('.nav-links');
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function () {
            var isOpen = navLinks.classList.toggle('open');
            menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navLinks.classList.contains('open')) {
                    navLinks.classList.remove('open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
        window.addEventListener('resize', function () {
            if (window.innerWidth > 900 && navLinks.classList.contains('open')) {
                navLinks.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    var cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        var cookieAccept = cookieBanner.querySelector('[data-cookie-accept]');
        var cookieDecline = cookieBanner.querySelector('[data-cookie-decline]');
        var consent = localStorage.getItem('interagerv-cookie-consent');

        if (!consent) {
            cookieBanner.classList.remove('hidden');
        }

        function setConsent(value) {
            localStorage.setItem('interagerv-cookie-consent', value);
            cookieBanner.classList.add('hidden');
        }

        if (cookieAccept) {
            cookieAccept.addEventListener('click', function () {
                setConsent('accepted');
            });
        }

        if (cookieDecline) {
            cookieDecline.addEventListener('click', function () {
                setConsent('declined');
            });
        }
    }
});