document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const navigation = document.getElementById("primary-navigation");
  const navLinks = navigation ? navigation.querySelectorAll("a") : [];
  const currentYearElements = document.querySelectorAll(".current-year");
  const toast = document.getElementById("global-toast");
  const cookieBanner = document.getElementById("cookie-banner");
  const acceptCookie = document.getElementById("cookie-accept");
  const declineCookie = document.getElementById("cookie-decline");
  const cookieKey = "cargostreamCookieChoice";

  if (currentYearElements.length) {
    const year = new Date().getFullYear();
    currentYearElements.forEach((el) => {
      el.textContent = year;
    });
  }

  if (navToggle && navigation) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      body.classList.toggle("nav-open");
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 992) {
          navToggle.setAttribute("aria-expanded", "false");
          body.classList.remove("nav-open");
        }
      });
    });
  }

  const revealElements = document.querySelectorAll(".reveal-on-scroll");
  if (revealElements.length) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            obs.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.18,
      }
    );

    revealElements.forEach((element) => observer.observe(element));
  }

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 2800);
  }

  const forms = document.querySelectorAll("form[data-redirect]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const redirectTarget = form.dataset.redirect || form.getAttribute("action") || "thank-you.html";
      showToast("Mesaj transmis. Veți fi redirecționat curând.");
      setTimeout(() => {
        window.location.href = redirectTarget;
      }, 1600);
    });
  });

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (!storedChoice) {
      cookieBanner.classList.add("active");
    }

    const handleChoice = (value) => {
      localStorage.setItem(cookieKey, value);
      cookieBanner.classList.remove("active");
      showToast("Preferințele privind cookie-urile au fost salvate.");
    };

    if (acceptCookie) {
      acceptCookie.addEventListener("click", () => handleChoice("acceptat"));
    }

    if (declineCookie) {
      declineCookie.addEventListener("click", () => handleChoice("respins"));
    }
  }
});