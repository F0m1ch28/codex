document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.getElementById("nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const isOpen = navMenu.classList.toggle("open");
            navToggle.classList.toggle("open", isOpen);
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });

        navMenu.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (window.innerWidth < 960) {
                    navMenu.classList.remove("open");
                    navToggle.classList.remove("open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const acceptButton = cookieBanner.querySelector(".accept-cookies");
        const declineButton = cookieBanner.querySelector(".decline-cookies");
        const consent = localStorage.getItem("wcCookieConsent");

        if (!consent) {
            setTimeout(function () {
                cookieBanner.classList.add("show");
            }, 800);
        }

        if (acceptButton) {
            acceptButton.addEventListener("click", function () {
                localStorage.setItem("wcCookieConsent", "accepted");
                cookieBanner.classList.remove("show");
            });
        }

        if (declineButton) {
            declineButton.addEventListener("click", function () {
                localStorage.setItem("wcCookieConsent", "declined");
                cookieBanner.classList.remove("show");
            });
        }
    }

    const layerButtons = document.querySelectorAll("[data-layer]");
    const layerCards = document.querySelectorAll(".layer-card");

    if (layerButtons.length && layerCards.length) {
        layerButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                const target = button.getAttribute("data-layer");
                layerButtons.forEach(function (btn) {
                    btn.classList.toggle("active", btn === button);
                });
                layerCards.forEach(function (card) {
                    const matches = card.getAttribute("data-layer");
                    card.classList.toggle("active", matches === target);
                });
            });
        });
    }

    const mapButtons = document.querySelectorAll("[data-region]");
    const mapRegions = document.querySelectorAll(".region");
    const regionPanels = document.querySelectorAll(".region-panel");

    function activateRegion(regionId) {
        mapRegions.forEach(function (region) {
            region.classList.toggle("active", region.id === regionId);
        });
        regionPanels.forEach(function (panel) {
            panel.classList.toggle("active", panel.getAttribute("data-region") === regionId);
        });
        mapButtons.forEach(function (button) {
            button.classList.toggle("active", button.getAttribute("data-region") === regionId);
        });
    }

    if (mapButtons.length && mapRegions.length && regionPanels.length) {
        mapButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                const regionId = button.getAttribute("data-region");
                activateRegion(regionId);
            });
        });

        mapRegions.forEach(function (region) {
            region.addEventListener("mouseenter", function () {
                activateRegion(region.id);
            });
            region.addEventListener("focus", function () {
                activateRegion(region.id);
            });
        });

        activateRegion(mapRegions[0].id);
    }

    const timelineContainer = document.querySelector(".timeline-items");
    const timelineItems = document.querySelectorAll(".timeline-item");
    const prevButton = document.querySelector(".timeline-prev");
    const nextButton = document.querySelector(".timeline-next");
    let activeIndex = 0;

    function updateTimeline(newIndex) {
        if (!timelineItems.length) {
            return;
        }
        activeIndex = Math.max(0, Math.min(newIndex, timelineItems.length - 1));
        timelineItems.forEach(function (item, index) {
            item.classList.toggle("active", index === activeIndex);
        });
        if (timelineContainer) {
            const activeItem = timelineItems[activeIndex];
            activeItem.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
        }
    }

    if (prevButton && nextButton && timelineItems.length) {
        prevButton.addEventListener("click", function () {
            updateTimeline(activeIndex - 1);
        });
        nextButton.addEventListener("click", function () {
            updateTimeline(activeIndex + 1);
        });
        updateTimeline(0);
    }

    const counters = document.querySelectorAll("[data-target]");
    if (counters.length) {
        const observer = new IntersectionObserver(function (entries, obs) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    const counter = entry.target;
                    const targetValue = parseInt(counter.getAttribute("data-target"), 10);
                    let current = 0;
                    const increment = Math.ceil(targetValue / 120);

                    const updateCounter = function () {
                        current += increment;
                        if (current >= targetValue) {
                            counter.textContent = targetValue.toLocaleString("en-CA");
                            obs.unobserve(counter);
                        } else {
                            counter.textContent = current.toLocaleString("en-CA");
                            requestAnimationFrame(updateCounter);
                        }
                    };
                    requestAnimationFrame(updateCounter);
                }
            });
        }, { threshold: 0.4 });

        counters.forEach(function (counter) {
            observer.observe(counter);
        });
    }
});