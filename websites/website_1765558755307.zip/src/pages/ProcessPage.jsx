import React from 'react';
import { Helmet } from 'react-helmet-async';
import layoutStyles from '../styles/Layout.module.css';
import styles from './ProcessPage.module.css';

const stages = [
  {
    title: '01. Исследование',
    description: 'Встречаемся с командой, уточняем стратегические цели, проводим интервью, изучаем аналитику и создаем портрет аудитории.',
    deliverables: ['Бриф и roadmap проекта', 'Карта заинтересованных пользователей', 'Анализ конкурентов', 'Гипотезы для проверки']
  },
  {
    title: '02. Концепция и прототип',
    description: 'Структурируем контент, создаем пользовательские сценарии, собираем прототипы и проводим тестирование с участниками.',
    deliverables: ['Информационная архитектура', 'Прототип высокого уровня', 'UX-аналитика', 'План контента']
  },
  {
    title: '03. Дизайн и разработка',
    description: 'Формируем визуальный язык, подготавливаем дизайн-систему, согласовываем экраны и передаем в разработку.',
    deliverables: ['Дизайн-система и UI-кит', 'Экранные макеты', 'Спецификации для разработчиков', 'Анимации и micro-interactions']
  },
  {
    title: '04. Запуск и сопровождение',
    description: 'Тестируем функционал, подключаем аналитику, обучаем команду клиента и поддерживаем развитие продукта.',
    deliverables: ['Тест-кейсы и отладка', 'Настройка аналитики и событий', 'Обучение команды', 'План развития']
  }
];

const ProcessPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Процесс работы — 🎨 Сколько вариантов сайта создать?</title>
      <meta
        name="description"
        content="Этапы работы агентства «🎨 Сколько вариантов сайта создать?»: от исследования и прототипирования до запуска и поддержки проекта."
      />
      <meta
        name="keywords"
        content="процесс разработки сайта, этапы создания сайта, UX процесс, дизайн-процесс"
      />
    </Helmet>

    <section className={`${layoutStyles.sectionPadding} ${styles.hero}`}>
      <div className={layoutStyles.container}>
        <h1>Как мы работаем</h1>
        <p>
          Прозрачный процесс дает уверенность в результате. Мы фиксируем этапы, артефакты и зоны ответственности —
          чтобы команда клиента всегда знала, на каком шаге находится проект.
        </p>
      </div>
    </section>

    <section className={layoutStyles.sectionPadding}>
      <div className={layoutStyles.container}>
        <div className={styles.timeline}>
          {stages.map((stage, index) => (
            <article key={stage.title} className={styles.stage}>
              <div className={styles.marker} aria-hidden="true">
                <span>{index + 1}</span>
              </div>
              <div className={styles.stageContent}>
                <h2>{stage.title}</h2>
                <p>{stage.description}</p>
                <div className={styles.deliverables}>
                  <span>Что получаете:</span>
                  <ul>
                    {stage.deliverables.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default ProcessPage;
