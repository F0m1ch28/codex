import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { casinos } from '../data/casinos';

const CasinoReviews = () => {
  const [ratingFilter, setRatingFilter] = useState('all');
  const [bonusFilter, setBonusFilter] = useState('all');
  const [licenseFilter, setLicenseFilter] = useState('all');

  const licenseOptions = useMemo(() => {
    const uniqueLicenses = new Set(casinos.map((casino) => casino.license));
    return Array.from(uniqueLicenses);
  }, []);

  const filteredCasinos = useMemo(() => {
    return casinos.filter((casino) => {
      const matchesRating =
        ratingFilter === 'all'
          ? true
          : ratingFilter === '4.5'
          ? casino.rating >= 4.5
          : ratingFilter === '4.0'
          ? casino.rating >= 4.0
          : true;

      const matchesBonus = bonusFilter === 'all' ? true : casino.bonusCategory === bonusFilter;
      const matchesLicense = licenseFilter === 'all' ? true : casino.license === licenseFilter;

      return matchesRating && matchesBonus && matchesLicense;
    });
  }, [ratingFilter, bonusFilter, licenseFilter]);

  return (
    <div className="page">
      <Helmet>
        <title>Обзоры казино — GamblePro</title>
        <meta
          name="description"
          content="Читайте проверенные обзоры казино от GamblePro. Фильтруйте по рейтингу, бонусам и лицензии, чтобы найти идеальную площадку."
        />
        <meta
          name="keywords"
          content="обзоры казино, рейтинг казино, бонусы казино, лицензия казино, сравнение казино"
        />
      </Helmet>

      <section className="page-hero">
        <div className="container">
          <h1>Обзоры казино</h1>
          <p>
            Наши эксперты тщательно анализируют каждое казино, проверяя лицензии, изучая отзывы игроков и оценивая
            качество обслуживания. Мы собираем только проверенную информацию, чтобы вы могли сосредоточиться на игре,
            а не на поиске.
          </p>
        </div>
      </section>

      <section className="filters-section">
        <div className="container filters-grid">
          <div className="filter-control">
            <label htmlFor="rating-filter">Рейтинг</label>
            <select
              id="rating-filter"
              value={ratingFilter}
              onChange={(event) => setRatingFilter(event.target.value)}
            >
              <option value="all">Все</option>
              <option value="4.5">4.5+</option>
              <option value="4.0">4.0+</option>
            </select>
          </div>
          <div className="filter-control">
            <label htmlFor="bonus-filter">Бонус</label>
            <select id="bonus-filter" value={bonusFilter} onChange={(event) => setBonusFilter(event.target.value)}>
              <option value="all">Все предложения</option>
              <option value="premium">Премиальные</option>
              <option value="enhanced">Усиленные</option>
              <option value="standard">Стартовые</option>
            </select>
          </div>
          <div className="filter-control">
            <label htmlFor="license-filter">Лицензия</label>
            <select
              id="license-filter"
              value={licenseFilter}
              onChange={(event) => setLicenseFilter(event.target.value)}
            >
              <option value="all">Все лицензии</option>
              {licenseOptions.map((license) => (
                <option key={license} value={license}>
                  {license}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      <section className="casinos-list-section">
        <div className="container casinos-list">
          {filteredCasinos.map((casino) => (
            <div key={casino.id} className="casino-list-card">
              <div className="casino-list-image">
                <img src={casino.image} alt={`${casino.name} обзор`} loading="lazy" />
              </div>
              <div className="casino-list-content">
                <div className="casino-list-header">
                  <h2>{casino.name}</h2>
                  <span className="rating-chip">
                    <i className="fa-solid fa-star" aria-hidden="true"></i>
                    {casino.rating.toFixed(1)} / 5
                  </span>
                </div>
                <p>{casino.shortDescription}</p>
                <div className="casino-list-meta">
                  <span>
                    <i className="fa-solid fa-badge-check" aria-hidden="true"></i>
                    Лицензия: {casino.license}
                  </span>
                  <span>
                    <i className="fa-solid fa-coins" aria-hidden="true"></i>
                    {casino.bonus}
                  </span>
                  <span>
                    <i className="fa-solid fa-clock" aria-hidden="true"></i>
                    Вывод: {casino.withdrawTime}
                  </span>
                </div>
                <div className="casino-list-footer">
                  <Link to={`/casino/${casino.slug}`} className="btn btn-secondary">
                    Подробнее
                  </Link>
                  <span className="reviews-count">{casino.reviewsCount} отзывов</span>
                </div>
              </div>
            </div>
          ))}
          {filteredCasinos.length === 0 && (
            <div className="empty-state">
              <h3>Не найдено казино по выбранным фильтрам</h3>
              <p>Попробуйте изменить параметры поиска.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default CasinoReviews;