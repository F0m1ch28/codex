import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { casinos } from '../data/casinos';
import { articles } from '../data/articles';

const Home = () => {
  const topCasinos = casinos.slice(0, 5);
  const comparisonCasinos = casinos.slice(0, 4);
  const latestArticles = articles.slice(0, 3);

  const [email, setEmail] = useState('');
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);

  const handleSubscribe = (event) => {
    event.preventDefault();
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      setSubscriptionStatus('Введите корректный email.');
      return;
    }
    setSubscriptionStatus('Спасибо! Вы подписаны на рассылку GamblePro.');
    setEmail('');
  };

  const faqs = [
    {
      question: 'Как выбрать казино?',
      answer:
        'Оцените лицензии, репутацию и условия бонусов. Проверьте вывод средств и убедитесь, что казино работает с надежными провайдерами.'
    },
    {
      question: 'Что такое RTP?',
      answer:
        'RTP — это возврат игроку. Процент показывает, какую часть ставок автомат возвращает на длинной дистанции. Чем выше RTP, тем стабильнее результаты игры.'
    },
    {
      question: 'Как проверить лицензию?',
      answer:
        'Посетите сайт регулятора и введите номер лицензии, указанный в подвале сайта казино. Так вы убедитесь, что оператор контролируется официальным органом.'
    },
    {
      question: 'На что обратить внимание в бонусах?',
      answer:
        'Изучите вейджер, срок отыгрыша, максимальную ставку и список игр, участвующих в бонусе. Это поможет избежать неприятных сюрпризов.'
    },
    {
      question: 'Какие методы оплаты безопасны?',
      answer:
        'Используйте банковские карты, проверенные электронные кошельки или платежные системы с двухфакторной аутентификацией. Никогда не передавайте свои данные третьим лицам.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>GamblePro — лучшие обзоры казино и сравнения</title>
        <meta
          name="description"
          content="GamblePro — ваш надежный гид по онлайн-казино. Экспертные обзоры, честные рейтинги, бонусы и сравнения лучших платформ."
        />
        <meta
          name="keywords"
          content="гэмблинг, казино, обзоры казино, условия казино, сравнение казино, бонусы, фриспины, лицензии казино, рейтинг казино, лучшие казино"
        />
      </Helmet>

      <section className="hero-section">
        <div className="container hero-content">
          <div className="hero-text">
            <span className="hero-badge">Лидеры рынка обзоров</span>
            <h1>Лучшие обзоры гэмблинг продуктов</h1>
            <p>
              GamblePro — ваш надежный гид в мире онлайн-казино. Мы предоставляем исчерпывающие обзоры, честные рейтинги
              и детальные сравнения лучших гэмблинг продуктов. Наша цель — помочь вам сделать осознанный выбор,
              предоставляя актуальную информацию о бонусах, лицензиях, RTP и условиях. С нами вы всегда в курсе последних
              новостей и трендов индустрии.
            </p>
            <div className="hero-actions">
              <Link to="/casino-reviews" className="btn btn-primary">
                Смотреть казино
              </Link>
              <Link to="/articles" className="btn btn-outline">
                Читать статьи
              </Link>
            </div>
          </div>
          <div className="hero-visual" role="presentation">
            <img
              src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80"
              alt="Игровые столы и казино"
            />
          </div>
        </div>
      </section>

      <section className="advantages-section">
        <div className="container">
          <h2 className="section-title">Почему игроки выбирают GamblePro</h2>
          <div className="advantages-grid">
            <div className="advantage-card">
              <i className="fa-solid fa-user-tie" aria-hidden="true"></i>
              <h3>Экспертные обзоры</h3>
              <p>Команда аналитиков изучает каждое казино: лицензии, софт, поддержка и отзывы игроков.</p>
            </div>
            <div className="advantage-card">
              <i className="fa-solid fa-scale-balanced" aria-hidden="true"></i>
              <h3>Честные рейтинги</h3>
              <p>Объективные оценки на основе реальных критериев — без рекламного давления и скрытых соглашений.</p>
            </div>
            <div className="advantage-card">
              <i className="fa-solid fa-gift" aria-hidden="true"></i>
              <h3>Актуальные бонусы</h3>
              <p>Мы обновляем информацию о приветственных пакетах, фриспинах и кэшбэках ежедневно.</p>
            </div>
            <div className="advantage-card">
              <i className="fa-solid fa-table-list" aria-hidden="true"></i>
              <h3>Детальные сравнения</h3>
              <p>Сводные таблицы по депозитам, вейджерам, лицензиям и скорости выплат помогают сделать выбор.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="top-casinos-section">
        <div className="container">
          <div className="section-heading">
            <h2 className="section-title">Топ-5 казино месяца</h2>
            <p className="section-subtitle">Подборка лучших площадок по отзывам игроков и условиям обслуживания.</p>
          </div>
          <div className="casino-card-grid">
            {topCasinos.map((casino) => (
              <div key={casino.id} className="casino-card">
                <div className="casino-card-image">
                  <img src={casino.image} alt={`${casino.name} — казино`} loading="lazy" />
                  <span className="rating-badge">
                    <i className="fa-solid fa-star" aria-hidden="true"></i>
                    {casino.rating.toFixed(1)}
                  </span>
                </div>
                <div className="casino-card-body">
                  <h3>{casino.name}</h3>
                  <p>{casino.shortDescription}</p>
                  <ul className="casino-meta">
                    <li>
                      <i className="fa-solid fa-gift" aria-hidden="true"></i>
                      {casino.bonus}
                    </li>
                    <li>
                      <i className="fa-solid fa-shield-halved" aria-hidden="true"></i>
                      Лицензия: {casino.license}
                    </li>
                    <li>
                      <i className="fa-solid fa-coins" aria-hidden="true"></i>
                      Мин. депозит: {casino.minDeposit}
                    </li>
                  </ul>
                  <Link to={`/casino/${casino.slug}`} className="btn btn-secondary">
                    Читать обзор
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="comparison-section">
        <div className="container">
          <div className="section-heading">
            <h2 className="section-title">Сравнение лучших предложений</h2>
            <p className="section-subtitle">
              Сэкономьте время — мы собрали ключевые параметры по бонусам, лицензиям и выплатам в одном месте.
            </p>
          </div>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Казино</th>
                  <th>Приветственный бонус</th>
                  <th>Фриспины</th>
                  <th>Лицензия</th>
                  <th>Мин. депозит</th>
                  <th>Скорость вывода</th>
                </tr>
              </thead>
              <tbody>
                {comparisonCasinos.map((casino) => (
                  <tr key={casino.id}>
                    <td>
                      <span className="table-casino-name">{casino.name}</span>
                    </td>
                    <td>{casino.bonus}</td>
                    <td>{casino.freespins}</td>
                    <td>{casino.license}</td>
                    <td>{casino.minDeposit}</td>
                    <td>{casino.withdrawTime}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="table-cta">
            <Link to="/compare-casinos" className="btn btn-primary">
              Полное сравнение
            </Link>
          </div>
        </div>
      </section>

      <section className="articles-section">
        <div className="container">
          <div className="section-heading">
            <h2 className="section-title">Последние статьи</h2>
            <p className="section-subtitle">Свежие новости индустрии, аналитика и практические рекомендации.</p>
          </div>
          <div className="article-grid">
            {latestArticles.map((article) => (
              <article key={article.id} className="article-card">
                <div className="article-image">
                  <img src={article.image} alt={article.title} loading="lazy" />
                </div>
                <div className="article-content">
                  <span className="article-date">{article.date}</span>
                  <h3>{article.title}</h3>
                  <p>{article.excerpt}</p>
                  <Link to={`/articles/${article.slug}`} className="link-arrow">
                    Читать
                    <i className="fa-solid fa-arrow-right" aria-hidden="true"></i>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section">
        <div className="container">
          <div className="section-heading">
            <h2 className="section-title">Часто задаваемые вопросы</h2>
            <p className="section-subtitle">Ответы экспертов GamblePro на популярные вопросы игроков.</p>
          </div>
          <div className="faq-list">
            {faqs.map((item, index) => (
              <details key={item.question} className="faq-item" open={index === 0}>
                <summary>
                  <span>{item.question}</span>
                  <i className="fa-solid fa-chevron-down" aria-hidden="true"></i>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="newsletter-section">
        <div className="container newsletter-container">
          <div className="newsletter-text">
            <h2>Подписка на новости GamblePro</h2>
            <p>
              Получайте свежие обзоры, рейтинги и бонусные предложения первыми. Только актуальная информация — никакого спама.
            </p>
          </div>
          <form className="newsletter-form" onSubmit={handleSubscribe}>
            <label htmlFor="newsletter-email" className="sr-only">
              Email
            </label>
            <input
              id="newsletter-email"
              type="email"
              placeholder="Введите ваш email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
            />
            <button type="submit" className="btn btn-primary">
              Подписаться
            </button>
            {subscriptionStatus && <span className="newsletter-feedback">{subscriptionStatus}</span>}
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;