import React from 'react';
import { Helmet } from 'react-helmet';

const CookiePolicy = () => {
  return (
    <div className="page legal-page">
      <Helmet>
        <title>Cookie Policy — GamblePro</title>
        <meta
          name="description"
          content="Политика использования файлов cookie на сайте GamblePro. Узнайте, как и зачем мы применяем cookie."
        />
      </Helmet>

      <section className="page-hero">
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>Мы используем файлы cookie, чтобы сделать работу сайта более удобной и аналитически точной.</p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container">
          <h2>1. Что такое cookie</h2>
          <p>
            Cookie — это небольшие текстовые файлы, которые сохраняются в браузере, чтобы запоминать ваши предпочтения и
            улучшать функциональность сайта.
          </p>

          <h2>2. Какие cookie мы используем</h2>
          <ul>
            <li>Технические cookie — необходимы для работы сайта.</li>
            <li>Аналитические cookie — помогают понимать, как пользователи взаимодействуют с контентом.</li>
            <li>Функциональные cookie — запоминают выбранный язык и настройки.</li>
          </ul>

          <h2>3. Управление cookie</h2>
          <p>
            Вы можете отключить cookie в настройках браузера. Однако часть функций сайта может работать некорректно. Также
            вы можете изменить выбор, принятый в баннере cookie.
          </p>

          <h2>4. Контакты</h2>
          <p>По вопросам использования cookie свяжитесь с нами: info@gamblepro.ru.</p>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;