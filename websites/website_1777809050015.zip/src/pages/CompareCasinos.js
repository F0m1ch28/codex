import React from 'react';
import { Helmet } from 'react-helmet';
import { casinos } from '../data/casinos';

const CompareCasinos = () => {
  const comparisonCasinos = casinos.slice(0, 6);

  return (
    <div className="page">
      <Helmet>
        <title>Сравнение казино — GamblePro</title>
        <meta
          name="description"
          content="Сравните 6 лучших казино по бонусам, RTP, вейджеру, лицензии, минимальному депозиту и методам вывода на GamblePro."
        />
        <meta
          name="keywords"
          content="сравнение казино, бонусы казино, RTP, лицензии казино, вейджер, лучшие казино"
        />
      </Helmet>

      <section className="page-hero">
        <div className="container">
          <h1>Сравнение казино</h1>
          <p>
            Сводная таблица по ключевым параметрам поможет быстро выбрать площадку с подходящими условиями.
            Сравните бонусы, RTP, вейджер, лицензии и минимальные депозиты.
          </p>
        </div>
      </section>

      <section className="comparison-table-section">
        <div className="container table-wrapper">
          <table className="compare-table">
            <thead>
              <tr>
                <th>Казино</th>
                <th>Бонус</th>
                <th>RTP</th>
                <th>Вейджер</th>
                <th>Лицензия</th>
                <th>Мин. депозит</th>
                <th>Методы вывода</th>
              </tr>
            </thead>
            <tbody>
              {comparisonCasinos.map((casino) => (
                <tr key={casino.id}>
                  <td>{casino.name}</td>
                  <td>{casino.bonus}</td>
                  <td>{casino.rtp}</td>
                  <td>{casino.wager}</td>
                  <td>{casino.license}</td>
                  <td>{casino.minDeposit}</td>
                  <td>{casino.methods.join(', ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="table-hint">
            Информация обновляется регулярно. Уточняйте актуальные условия на официальном сайте казино перед регистрацией.
          </p>
        </div>
      </section>
    </div>
  );
};

export default CompareCasinos;