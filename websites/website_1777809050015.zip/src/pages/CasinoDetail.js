import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { getCasinoBySlug } from '../data/casinos';

const CasinoDetail = () => {
  const { slug } = useParams();
  const casino = getCasinoBySlug(slug);

  if (!casino) {
    return (
      <div className="page">
        <Helmet>
          <title>Казино не найдено — GamblePro</title>
          <meta name="robots" content="noindex" />
        </Helmet>
        <section className="page-hero">
          <div className="container">
            <h1>Казино не найдено</h1>
            <p>Возможно, предложение было обновлено или удалено. Вернитесь к списку обзоров.</p>
            <Link to="/casino-reviews" className="btn btn-primary">
              К обзорам казино
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page">
      <Helmet>
        <title>{casino.name} — обзор казино на GamblePro</title>
        <meta
          name="description"
          content={`Обзор ${casino.name}: лицензия ${casino.license}, бонус ${casino.bonus}, условия вывода ${casino.withdrawTime}. Оценка ${casino.overallRating}/10.`}
        />
        <meta
          name="keywords"
          content={`${casino.name}, обзор казино, бонусы казино, лицензия ${casino.license}, условия вывода`}
        />
      </Helmet>

      <section className="casino-detail-hero">
        <div className="container casino-detail-hero-inner">
          <div className="casino-detail-visual">
            <img src={casino.image} alt={`${casino.name} интерфейс`} />
            <span className="detail-rating">
              <i className="fa-solid fa-star" aria-hidden="true"></i>
              {casino.overallRating.toFixed(1)} / 10
            </span>
          </div>
          <div className="casino-detail-summary">
            <h1>{casino.name}</h1>
            <p>{casino.shortDescription}</p>
            <div className="casino-summary-grid">
              <div>
                <span className="summary-label">Приветственный бонус</span>
                <span className="summary-value">{casino.bonus}</span>
              </div>
              <div>
                <span className="summary-label">Фриспины</span>
                <span className="summary-value">{casino.freespins}</span>
              </div>
              <div>
                <span className="summary-label">Минимальный депозит</span>
                <span className="summary-value">{casino.minDeposit}</span>
              </div>
              <div>
                <span className="summary-label">Вейджер</span>
                <span className="summary-value">{casino.wager}</span>
              </div>
            </div>
            <div className="summary-tags">
              <span><i className="fa-solid fa-shield" aria-hidden="true"></i> Лицензия: {casino.license}</span>
              <span><i className="fa-solid fa-clock-rotate-left" aria-hidden="true"></i> Вывод: {casino.withdrawTime}</span>
              <span><i className="fa-solid fa-tachometer-alt" aria-hidden="true"></i> RTP: {casino.rtp}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="casino-detail-section">
        <div className="container">
          <h2>Обзор казино</h2>
          <div className="detail-grid">
            <div className="detail-card">
              <h3>История и репутация</h3>
              <p>{casino.history}</p>
            </div>
            <div className="detail-card">
              <h3>Софт и провайдеры</h3>
              <p>{casino.software}</p>
            </div>
            <div className="detail-card">
              <h3>Игровой ассортимент</h3>
              <p>{casino.games}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="casino-detail-section">
        <div className="container">
          <h2>Условия бонусов и платежей</h2>
          <div className="detail-grid detail-grid-conditions">
            <div className="detail-card">
              <h3>Бонусы</h3>
              <ul className="detail-list">
                <li><strong>Приветственный бонус:</strong> {casino.welcomeBonus}</li>
                <li><strong>Бездепозитный бонус:</strong> {casino.noDepositBonus}</li>
                <li><strong>Дополнительные акции:</strong> {casino.additionalBonuses}</li>
              </ul>
            </div>
            <div className="detail-card">
              <h3>Оплата и вывод</h3>
              <ul className="detail-list">
                <li><strong>Методы оплаты:</strong> {casino.payments.join(', ')}</li>
                <li><strong>Методы вывода:</strong> {casino.methods.join(', ')}</li>
                <li><strong>Лимиты:</strong> {casino.withdrawalLimits}</li>
              </ul>
            </div>
            <div className="detail-card">
              <h3>Лицензия и безопасность</h3>
              <ul className="detail-list">
                <li><strong>Регулятор:</strong> {casino.license}</li>
                <li><strong>Номер лицензии:</strong> {casino.licenseNumber}</li>
                <li><strong>Средства защиты:</strong> Шифрование SSL, проверенные RNG</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="casino-detail-section">
        <div className="container pros-cons-grid">
          <div className="pros-card">
            <h3><i className="fa-solid fa-thumbs-up" aria-hidden="true"></i> Плюсы</h3>
            <ul>
              {casino.pros.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div className="cons-card">
            <h3><i className="fa-solid fa-thumbs-down" aria-hidden="true"></i> Минусы</h3>
            <ul>
              {casino.cons.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="casino-detail-section">
        <div className="container final-rating-card">
          <h2>Итоговая оценка GamblePro</h2>
          <p>
            Мы оцениваем {casino.name} на {casino.overallRating.toFixed(1)} из 10. Казино показывает устойчивые результаты по
            безопасности, бонусам и разнообразию игр. Перед регистрацией обязательно изучите актуальные условия på сайте оператора.
          </p>
          <div className="rating-progress">
            <div className="rating-progress-bar" style={{ width: `${casino.overallRating * 10}%` }}></div>
            <span className="rating-score">{casino.overallRating.toFixed(1)} / 10</span>
          </div>
          <Link to="/casino-reviews" className="btn btn-outline">
            Вернуться к списку обзоров
          </Link>
        </div>
      </section>
    </div>
  );
};

export default CasinoDetail;