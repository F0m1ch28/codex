import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { getArticleBySlug } from '../data/articles';

const ArticleDetail = () => {
  const { slug } = useParams();
  const article = getArticleBySlug(slug);

  if (!article) {
    return (
      <div className="page">
        <Helmet>
          <title>Статья не найдена — GamblePro</title>
          <meta name="robots" content="noindex" />
        </Helmet>
        <section className="page-hero">
          <div className="container">
            <h1>Статья не найдена</h1>
            <p>Материал был перемещен или удален. Вернитесь к списку публикаций.</p>
            <Link to="/articles" className="btn btn-primary">
              К статьям
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page article-detail-page">
      <Helmet>
        <title>{article.title} — GamblePro</title>
        <meta name="description" content={article.excerpt} />
        <meta name="keywords" content={article.keywords} />
      </Helmet>

      <section className="article-detail-hero">
        <div className="container">
          <span className="article-date">{article.date}</span>
          <h1>{article.title}</h1>
          <div className="article-detail-image">
            <img src={article.image} alt={article.title} />
          </div>
        </div>
      </section>

      <section className="article-detail-content">
        <div className="container article-body">
          {article.content.map((block, index) => {
            if (block.type === 'paragraph') {
              return <p key={index}>{block.text}</p>;
            }
            if (block.type === 'heading') {
              return <h2 key={index}>{block.text}</h2>;
            }
            if (block.type === 'list') {
              return (
                <ul key={index}>
                  {block.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              );
            }
            return null;
          })}
          <Link to="/articles" className="btn btn-outline back-link">
            Вернуться к статьям
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ArticleDetail;