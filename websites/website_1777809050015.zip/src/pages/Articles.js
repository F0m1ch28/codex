import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { articles } from '../data/articles';

const Articles = () => {
  return (
    <div className="page">
      <Helmet>
        <title>Статьи о казино — GamblePro</title>
        <meta
          name="description"
          content="Полезные статьи о выборе казино, бонусах, лицензиях и слотах с высоким RTP. Обновления отрасли от экспертов GamblePro."
        />
        <meta
          name="keywords"
          content="статьи казино, советы казино, RTP, лицензии казино, бонусы казино"
        />
      </Helmet>

      <section className="page-hero">
        <div className="container">
          <h1>Статьи</h1>
          <p>
            Аналитика, инструкции и обзоры трендов гэмблинг-индустрии. Получайте знания, которые помогут принимать
            осознанные решения и играть ответственно.
          </p>
        </div>
      </section>

      <section className="articles-list-section">
        <div className="container article-grid">
          {articles.map((article) => (
            <article key={article.id} className="article-card">
              <div className="article-image">
                <img src={article.image} alt={article.title} loading="lazy" />
              </div>
              <div className="article-content">
                <span className="article-date">{article.date}</span>
                <h2>{article.title}</h2>
                <p>{article.excerpt}</p>
                <Link to={`/articles/${article.slug}`} className="link-arrow">
                  Читать
                  <i className="fa-solid fa-arrow-right" aria-hidden="true"></i>
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Articles;