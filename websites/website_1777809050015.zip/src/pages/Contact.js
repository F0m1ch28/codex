import React, { useState } from 'react';
import { Helmet } from 'react-helmet';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [feedback, setFeedback] = useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setFeedback('Заполните все поля формы.');
      return;
    }
    setFeedback('Спасибо! Мы получили ваше сообщение и ответим в ближайшее время.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="page">
      <Helmet>
        <title>Контакты — GamblePro</title>
        <meta
          name="description"
          content="Свяжитесь с командой GamblePro для партнерств, вопросов и уточнений. Мы ответим в течение рабочего дня."
        />
        <meta name="keywords" content="контакты GamblePro, служба поддержки казино, партнерство казино" />
      </Helmet>

      <section className="page-hero">
        <div className="container">
          <h1>Контакты</h1>
          <p>
            Мы открыты для обратной связи, партнерств и предложений. Задайте вопрос через форму или свяжитесь с нами любым удобным способом.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="contact-name">Имя</label>
              <input
                id="contact-name"
                type="text"
                name="name"
                placeholder="Ваше имя"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="contact-email">Email</label>
              <input
                id="contact-email"
                type="email"
                name="email"
                placeholder="name@example.com"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="contact-message">Сообщение</label>
              <textarea
                id="contact-message"
                name="message"
                placeholder="Напишите ваш запрос..."
                rows="6"
                value={formData.message}
                onChange={handleChange}
                required
              ></textarea>
            </div>
            <button type="submit" className="btn btn-primary">
              Отправить
            </button>
            {feedback && <p className="form-feedback">{feedback}</p>}
          </form>
          <div className="contact-info">
            <h2>Контактные данные</h2>
            <ul>
              <li>
                <i className="fa-solid fa-location-dot" aria-hidden="true"></i>
                ул. Мира, д. 10, офис 5, Москва, Россия
              </li>
              <li>
                <i className="fa-solid fa-phone" aria-hidden="true"></i>
                +7 (495) 123-45-67
              </li>
              <li>
                <i className="fa-solid fa-envelope" aria-hidden="true"></i>
                info@gamblepro.ru
              </li>
            </ul>
            <p>
              Мы отвечаем в рабочие дни с 10:00 до 19:00 (MSK). Пожалуйста, указывайте тему обращений и контактные данные
              для обратной связи.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;