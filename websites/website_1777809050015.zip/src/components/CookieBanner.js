import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem('gamblepro_cookie_consent');
    if (!storedConsent) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (consent) => {
    window.localStorage.setItem('gamblepro_cookie_consent', consent);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-text">
        <strong>Мы используем файлы cookie.</strong>
        <p>
          Этот сайт использует файлы cookie для улучшения работы. Принимая, вы соглашаетесь с{' '}
          <Link to="/cookie-policy">Cookie Policy</Link>.
        </p>
      </div>
      <div className="cookie-actions">
        <button type="button" className="btn btn-primary" onClick={() => handleConsent('accepted')}>
          Принять
        </button>
        <button type="button" className="btn btn-outline" onClick={() => handleConsent('declined')}>
          Отклонить
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;