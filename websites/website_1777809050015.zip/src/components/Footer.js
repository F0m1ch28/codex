import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="main-footer">
      <div className="container footer-grid">
        <div className="footer-column">
          <h3>GamblePro</h3>
          <p>
            GamblePro — международный эксперт по обзорам онлайн-казино. Мы собираем достоверную информацию о лицензиях,
            бонусах и условиях, чтобы вы принимали взвешенные решения.
          </p>
          <p className="footer-contact">
            <i className="fa-solid fa-location-dot" aria-hidden="true"></i>
            ул. Мира, д. 10, офис 5, Москва, Россия
          </p>
          <p className="footer-contact">
            <i className="fa-solid fa-phone" aria-hidden="true"></i>
            +7 (495) 123-45-67
          </p>
          <p className="footer-contact">
            <i className="fa-solid fa-envelope" aria-hidden="true"></i>
            info@gamblepro.ru
          </p>
        </div>
        <div className="footer-column">
          <h4>Навигация</h4>
          <ul className="footer-links">
            <li><Link to="/">Главная</Link></li>
            <li><Link to="/casino-reviews">Обзоры казино</Link></li>
            <li><Link to="/compare-casinos">Сравнение казино</Link></li>
            <li><Link to="/articles">Статьи</Link></li>
            <li><Link to="/contact">Связаться с нами</Link></li>
          </ul>
        </div>
        <div className="footer-column">
          <h4>Правовая информация</h4>
          <ul className="footer-links">
            <li><Link to="/terms-of-service">Terms of Service</Link></li>
            <li><Link to="/privacy-policy">Privacy Policy</Link></li>
            <li><Link to="/cookie-policy">Cookie Policy</Link></li>
          </ul>
          <p className="footer-note">
            Информация на сайте носит ознакомительный характер и не является призывом к участию в азартных играх.
            Пожалуйста, играйте ответственно и соблюдайте законодательство вашей страны.
          </p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} GamblePro. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;