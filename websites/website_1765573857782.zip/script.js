document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("primaryNav");
  const body = document.body;

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      body.classList.toggle("nav-open", isOpen);
    });

    nav.querySelectorAll(".nav-link").forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
        body.classList.remove("nav-open");
      });
    });
  }

  document.querySelectorAll(".current-year").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });

  const cookieBanner = document.getElementById("cookieBanner");
  const cookieKey = "qazaqlearn-consent";

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(cookieKey);

    if (!storedConsent) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add("is-visible");
      });
    }

    cookieBanner.querySelectorAll("button[data-cookie-action]").forEach((button) => {
      button.addEventListener("click", () => {
        const action = button.dataset.cookieAction;
        localStorage.setItem(cookieKey, action);
        cookieBanner.classList.remove("is-visible");
      });
    });
  }
});