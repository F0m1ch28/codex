import React, { useState } from 'react';
import Helmet from '../components/Helmet';
import styles from './Services.module.css';

const Services = () => {
  const programs = [
    {
      title: 'Базова підготовка та соціалізація',
      summary: 'Перші команди, самоконтроль, робота в різних середовищах.',
      details: [
        'Формування контактності та уваги на власника.',
        'Опрацювання базових команд: «до мене», «поруч», «місце», «лежати».',
        'Побудова стабільного ходіння на повідку без ривків.'
      ]
    },
    {
      title: 'Курс керування поведінкою',
      summary: 'Допомога собакам, що реагують на подразники або мають тривожність.',
      details: [
        'Розбір тригерів, план десенсибілізації та контрумовлення.',
        'Розвиток альтернативних реакцій та емоційна стабілізація.',
        'Домашні завдання з відеопідтримкою тренера.'
      ]
    },
    {
      title: 'Спортивна та службова підготовка',
      summary: 'Індивідуальні програми для IGP, obedience, nosework.',
      details: [
        'Розвиток драйву та точності виконання вправ.',
        'Побудова фази захисту та апортів під змагання.',
        'Підготовка до іспитів разом із тестами та міні-стартою.'
      ]
    },
    {
      title: 'Програма для сімей із дітьми',
      summary: 'Вчимо вівчарку взаємодіяти з дітьми, знімаємо напругу в побуті.',
      details: [
        'Правила взаємодії дитини та собаки.',
        'Створення безпечних ритуалів і рутини вдома.',
        'Навчання власників читати сигнали собаки.'
      ]
    }
  ];

  const [openIndex, setOpenIndex] = useState(0);

  return (
    <>
      <Helmet
        title="Послуги — Професійне дресирування німецьких вівчарок"
        description="Послуги дресирування німецьких вівчарок у Варшаві та Кракові: базова підготовка, корекція поведінки, спортивні програми."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Послуги дресирування</h1>
          <p>
            Ми створюємо програми, які відповідають темпераменту собаки, очікуванням родини та умовам життя у великому
            місті.
          </p>
        </div>
      </section>

      <section className={`container ${styles.programs}`}>
        <div className={styles.programList}>
          {programs.map((program, index) => (
            <article key={program.title} className={styles.programCard}>
              <button
                type="button"
                onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
                className={styles.programToggle}
                aria-expanded={openIndex === index}
              >
                <div>
                  <h2>{program.title}</h2>
                  <p>{program.summary}</p>
                </div>
                <span>{openIndex === index ? '−' : '+'}</span>
              </button>
              {openIndex === index && (
                <ul className={styles.details}>
                  {program.details.map((detail) => (
                    <li key={detail}>{detail}</li>
                  ))}
                </ul>
              )}
            </article>
          ))}
        </div>
        <aside className={styles.aside}>
          <div className={styles.asideCard}>
            <h3>Що входить у кожну програму</h3>
            <ul>
              <li>Діагностика та постановка цілей.</li>
              <li>Індивідуальний план занять із корекцією кожні 2 тижні.</li>
              <li>Комунікація з тренером між заняттями.</li>
              <li>Післякурсова підтримка у чаті випускників.</li>
            </ul>
          </div>
          <div className={styles.callout}>
            <p>
              Не впевнені, з чого почати? Напишіть нам — допоможемо підібрати оптимальний формат під ваші задачі та
              графік.
            </p>
            <a href="mailto:info@shepherd-training.pl" className={styles.ctaLink}>
              info@shepherd-training.pl
            </a>
          </div>
        </aside>
      </section>
    </>
  );
};

export default Services;