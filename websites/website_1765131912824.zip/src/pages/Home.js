import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Helmet from '../components/Helmet';
import styles from './Home.module.css';

const Home = () => {
  const advantages = useMemo(
    () => [
      {
        title: 'Індивідуальний підхід',
        description:
          'Кожна програма на 100% адаптується до темпераменту, здоров’я та цілей конкретної німецької вівчарки.',
        icon: '🎯'
      },
      {
        title: 'Глибокий досвід з вівчарками',
        description:
          'Понад два десятиліття роботи з робочими та домашніми лініями дає розуміння нюансів поведінки породи.',
        icon: '🐾'
      },
      {
        title: 'Варшава та Краків',
        description:
          'Команда тренерів доступна у двох найбільших містах південної Польщі, щоб бути поруч із клієнтами.',
        icon: '📍'
      },
      {
        title: 'Сучасні методики',
        description:
          'Науково обґрунтовані техніки позитивного підкріплення, без зайвого стресу та з чітким результатом.',
        icon: '🧠'
      }
    ],
    []
  );

  const statsTargets = useMemo(() => [250, 98, 15], []);
  const statsLabels = useMemo(
    () => ['Навчених вівчарок', 'Клієнтів рекомендують нас', 'Років тренерської практики'],
    []
  );
  const [stats, setStats] = useState([0, 0, 0]);

  useEffect(() => {
    const duration = 2600;
    const intervalTime = 60;
    const increments = statsTargets.map((target) => Math.ceil(target / (duration / intervalTime)));

    const interval = setInterval(() => {
      setStats((prev) =>
        prev.map((value, index) => {
          if (value < statsTargets[index]) {
            return Math.min(value + increments[index], statsTargets[index]);
          }
          return value;
        })
      );
    }, intervalTime);

    return () => clearInterval(interval);
  }, [statsTargets]);

  const services = [
    {
      title: 'Базова підкорість',
      description:
        'Формуємо фундаментальні навички — витримка, контакт, керування енергією. Фокус на безпеці та контролі.'
    },
    {
      title: 'Корекція поведінки',
      description:
        'Працюємо з реактивністю, агресією, тривожністю, вибудовуємо нові реакції на тригери через послідовні тренування.'
    },
    {
      title: 'Спеціальна підготовка',
      description:
        'Розвиваємо захисну, пошукову та спортивну роботу: IGP, obedience, nosework. Підтримка спортсменів та служб.'
    }
  ];

  const process = [
    {
      step: '01',
      title: 'Глибинна діагностика',
      text: 'Збираємо історію, оцінюємо поведінковий фон, тестуємо реакції собаки в контрольованому середовищі.'
    },
    {
      step: '02',
      title: 'Індивідуальний план',
      text: 'Створюємо календар тренувань, вправи для дому, підбираємо мотивації та інструменти під конкретні задачі.'
    },
    {
      step: '03',
      title: 'Практика та коригування',
      text: 'Проводимо регулярні заняття, аналізуємо прогрес, коригуємо план відповідно до реакції собаки.'
    },
    {
      step: '04',
      title: 'Підтримка власника',
      text: 'Навчаємо родину, як підтримувати результат, надаємо матеріали та супровід після завершення курсу.'
    }
  ];

  const testimonials = [
    {
      name: 'Олена та Рекс',
      city: 'Варшава',
      quote:
        'Через три місяці ми отримали стабільний контакт і відгук від собаки навіть у насиченому міському середовищі. Команда зробила неможливе — Рекс став слухняним і врівноваженим.',
      image: 'https://picsum.photos/400/400?random=301'
    },
    {
      name: 'Марцін і Хельга',
      city: 'Краків',
      quote:
        'Захисна підготовка для спортивних стартів пройшла на найвищому рівні. Детальний підхід, увага до техніки та безпеки порадували.',
      image: 'https://picsum.photos/400/400?random=302'
    },
    {
      name: 'Ірина та Лютар',
      city: 'Варшава',
      quote:
        'Після курсів корекції поведінки наш Лютар спокійно реагує на інших собак і більше не тягне повід. Дякуємо за терпіння та підтримку.',
      image: 'https://picsum.photos/400/400?random=303'
    }
  ];
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setActiveTestimonial((prev) => (prev + 1) % testimonials.length),
      7000
    );
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const projects = [
    {
      title: 'IGP-підготовка для енергичного кобеля',
      category: 'sport',
      description: 'Комплексна програма для виходу на міжнародні старти у Варшаві.',
      image: 'https://picsum.photos/1200/800?random=401'
    },
    {
      title: 'Реабілітація після травми',
      category: 'obedience',
      description: 'М’яка програма повернення до роботи з акцентом на стабілізацію нервової системи.',
      image: 'https://picsum.photos/1200/800?random=402'
    },
    {
      title: 'Службова підготовка для охорони',
      category: 'special',
      description: 'Робота над послухом та захисними навичками для охоронної структури у Кракові.',
      image: 'https://picsum.photos/1200/800?random=403'
    }
  ];
  const [projectFilter, setProjectFilter] = useState('all');
  const filteredProjects = projectFilter === 'all' ? projects : projects.filter((item) => item.category === projectFilter);

  const team = [
    {
      name: 'Святослав Гнатюк',
      role: 'Головний тренер, Варшава',
      description:
        'Сертифікований тренер IGP з 15-річним досвідом. Спеціалізується на робочих лініях німецьких вівчарок.',
      image: 'https://picsum.photos/400/400?random=501'
    },
    {
      name: 'Анна Вишневська',
      role: 'Кінолог-поведінковід, Краків',
      description:
        'Працює з реактивністю, соціалізацією та домашніми собаками. Впроваджує позитивні методи навчання.',
      image: 'https://picsum.photos/400/400?random=502'
    },
    {
      name: 'Томаш Боровський',
      role: 'Коуч власників',
      description:
        'Проводить інтенсиви для власників, пояснює логіку тренувань і допомагає підтримувати результат удома.',
      image: 'https://picsum.photos/400/400?random=503'
    }
  ];

  const faq = [
    {
      question: 'З якого віку варто починати дресирування німецької вівчарки?',
      answer:
        'Ми рекомендуємо починати соціалізацію з 3-4 місяців, а структуровані заняття — з 5-6 місяців. Для дорослих собак ми також створюємо окремі програми.'
    },
    {
      question: 'Чи можливі заняття англійською або польською?',
      answer:
        'Так, команда володіє українською, польською та англійською мовами. Ми підбираємо тренера залежно від зручності власника.'
    },
    {
      question: 'Як часто проходять заняття?',
      answer:
        'Стандартно — 1-2 рази на тиждень. Однак інтенсивність коригується залежно від задачі та прогресу собаки.'
    }
  ];
  const [openFaq, setOpenFaq] = useState(null);

  const blog = [
    {
      title: 'Чому німецькі вівчарки потребують структурованої активності',
      excerpt:
        'Розбираємо ключові причини, чому інтелектуальна та фізична активність — основа врівноваженої поведінки.',
      link: '/posluhy'
    },
    {
      title: '5 сигналів, що вашій вівчарці потрібна корекція поведінки',
      excerpt:
        'Розповідаємо, які поведінкові маркери свідчать про необхідність втручання професіонала та як діяти власнику.',
      link: '/pro-nas'
    }
  ];

  return (
    <>
      <Helmet
        title="Професійне дресирування німецьких вівчарок — Варшава та Краків"
        description="Професійні тренери з дресирування німецьких вівчарок у Варшаві та Кракові. Індивідуальні програми, корекція поведінки, спеціальна підготовка."
      />
      <article id="main-content">
        <section className={styles.hero}>
          <div className="container">
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>Кінологічний центр у Варшаві та Кракові</span>
              <h1>
                Дресирування німецьких вівчарок, яке розкриває потенціал і створює надійний тандем «людина-собака»
              </h1>
              <p>
                Професійна команда тренерів перетворює спільні тренування на системну подорож до дисципліни, впевненості
                та взаєморозуміння.
              </p>
              <div className={styles.heroActions}>
                <Link to="/kontakty" className={styles.primaryButton}>
                  Записатися на консультацію
                </Link>
                <Link to="/posluhy" className={styles.secondaryButton}>
                  Дізнатися про програми
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.advantages} container`}>
          <div className={styles.sectionHeader}>
            <h2>Наші переваги</h2>
            <p>Команда, методи та досвід, які допомагають досягати результату з повагою до собаки.</p>
          </div>
          <div className={styles.cardsGrid}>
            {advantages.map((item) => (
              <div key={item.title} className={styles.card}>
                <div className={styles.cardIcon} aria-hidden="true">
                  {item.icon}
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
          <div className={styles.stats}>
            {stats.map((value, index) => (
              <div key={statsLabels[index]} className={styles.statItem}>
                <span className={styles.statValue} aria-live="polite">
                  {value}+
                </span>
                <span className={styles.statLabel}>{statsLabels[index]}</span>
              </div>
            ))}
          </div>
        </section>

        <section className={`${styles.services} container`}>
          <div className={styles.sectionHeader}>
            <h2>Основні послуги</h2>
            <p>Створюємо збалансовані програми, що поєднують послух, емоційну стабільність і спеціальні навички.</p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <div key={service.title} className={styles.serviceCard}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/posluhy" className={styles.moreLink}>
                  Детальніше
                </Link>
              </div>
            ))}
          </div>
        </section>

        <section className={`${styles.breed} container`}>
          <div className={styles.breedImgWrapper}>
            <img
              src="https://picsum.photos/800/600?random=201"
              alt="Німецька вівчарка на тренуванні"
              loading="lazy"
            />
          </div>
          <div className={styles.breedContent}>
            <h2>Про породу</h2>
            <p>
              Німецька вівчарка — інтелектуальна, енергійна і неймовірно віддана порода. Вони прагнуть задач і чітких
              правил. Без системного навчання ці собаки можуть проявляти надмірну реактивність або стрес.
            </p>
            <p>
              Ми балансуємо фізичне навантаження, інтелектуальні вправи та соціалізацію, щоб вівчарка почувалася
              упевнено у міському ритмі Варшави чи Кракова, і водночас зберігала робоче мислення.
            </p>
            <ul>
              <li>Фокус на стабільності нервової системи.</li>
              <li>Розвиток потягу та самоконтролю через сучасні методики.</li>
              <li>Тісна співпраця з власником для закріплення результату.</li>
            </ul>
          </div>
        </section>

        <section className={`${styles.process} container`}>
          <div className={styles.sectionHeader}>
            <h2>Як ми працюємо</h2>
            <p>Кожен етап тренувань допомагає вибудувати довіру і послідовність.</p>
          </div>
          <div className={styles.processGrid}>
            {process.map((item) => (
              <div key={item.step} className={styles.processCard}>
                <span className={styles.processStep}>{item.step}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className={styles.testimonials}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2>Живі історії успіху</h2>
              <p>Клієнти діляться тим, як змінилося їхнє життя зі слухняною та щасливою вівчаркою.</p>
            </div>
            <div className={styles.testimonialWrapper}>
              {testimonials.map((testimonial, index) => (
                <article
                  key={testimonial.name}
                  className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.active : ''}`}
                  aria-hidden={index !== activeTestimonial}
                >
                  <img src={testimonial.image} alt={`Клієнт ${testimonial.name}`} loading="lazy" />
                  <blockquote>«{testimonial.quote}»</blockquote>
                  <p className={styles.testimonialAuthor}>
                    {testimonial.name} — {testimonial.city}
                  </p>
                </article>
              ))}
            </div>
            <div className={styles.sliderControls} role="tablist" aria-label="Перемикання відгуків">
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`${styles.sliderDot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Відгук від ${testimonial.name}`}
                  aria-selected={index === activeTestimonial}
                >
                  <span />
                </button>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.geography} container`}>
          <div className={styles.geoContent}>
            <h2>Географія роботи</h2>
            <p>
              Ми проводимо тренування на майданчиках у Варшаві (Бемово, Мокотув) та Кракові (Подгуже, Новий Світ), а також
              виїжджаємо на індивідуальні заняття до клієнтів.
            </p>
            <div className={styles.geoList}>
              <div>
                <h3>Варшава</h3>
                <p>Варшава, вул. Собача, 10</p>
              </div>
              <div>
                <h3>Краків</h3>
                <p>Краків, вул. Пастуша, 5</p>
              </div>
            </div>
          </div>
          <div className={styles.geoProjects}>
            <div className={styles.sectionHeader}>
              <h3>Наші проєкти</h3>
              <p>Оберіть напрям, щоб переглянути приклади реалізованих програм.</p>
            </div>
            <div className={styles.filterButtons}>
              <button
                type="button"
                onClick={() => setProjectFilter('all')}
                className={`${styles.filterButton} ${projectFilter === 'all' ? styles.filterActive : ''}`}
              >
                Усі
              </button>
              <button
                type="button"
                onClick={() => setProjectFilter('obedience')}
                className={`${styles.filterButton} ${projectFilter === 'obedience' ? styles.filterActive : ''}`}
              >
                Послух
              </button>
              <button
                type="button"
                onClick={() => setProjectFilter('sport')}
                className={`${styles.filterButton} ${projectFilter === 'sport' ? styles.filterActive : ''}`}
              >
                Спорт
              </button>
              <button
                type="button"
                onClick={() => setProjectFilter('special')}
                className={`${styles.filterButton} ${projectFilter === 'special' ? styles.filterActive : ''}`}
              >
                Спеціальна підготовка
              </button>
            </div>
            <div className={styles.projectsGrid}>
              {filteredProjects.map((project) => (
                <article key={project.title} className={styles.projectCard}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                  <div>
                    <span className={styles.projectTag}>{project.category}</span>
                    <h4>{project.title}</h4>
                    <p>{project.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.teamSection} container`}>
          <div className={styles.sectionHeader}>
            <h2>Команда та експертиза</h2>
            <p>Наші тренери — спеціалісти, які постійно підвищують кваліфікацію і діляться досвідом між містами.</p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={`${styles.faqBlog} container`}>
          <div className={styles.faqWrapper}>
            <div className={styles.sectionHeader}>
              <h2>Питання та відповіді</h2>
              <p>Ми зібрали найпоширеніші питання від власників німецьких вівчарок.</p>
            </div>
            <div className={styles.faqList}>
              {faq.map((item, index) => (
                <div key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => setOpenFaq(openFaq === index ? null : index)}
                    aria-expanded={openFaq === index}
                  >
                    {item.question}
                    <span>{openFaq === index ? '−' : '+'}</span>
                  </button>
                  {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
                </div>
              ))}
            </div>
          </div>
          <div className={styles.blogWrapper}>
            <div className={styles.sectionHeader}>
              <h2>Останні матеріали</h2>
              <p>Практичні поради та спостереження з наших тренувань.</p>
            </div>
            <div className={styles.blogList}>
              {blog.map((post) => (
                <article key={post.title} className={styles.blogCard}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.moreLink}>
                    Читати
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.cta}>
          <div className="container">
            <div className={styles.ctaContent}>
              <h2>Готові зробити крок до нової якості співпраці з вашою вівчаркою?</h2>
              <p>
                Залиште заявку, і ми підкажемо, з чого почати, як побудувати план та які результати можна отримати вже
                в перші тижні.
              </p>
              <div className={styles.ctaContacts}>
                <a href="tel:+48123456789" className={styles.ctaPhone}>
                  +48 123 456 789
                </a>
                <a href="mailto:info@shepherd-training.pl" className={styles.ctaEmail}>
                  info@shepherd-training.pl
                </a>
              </div>
              <Link to="/kontakty" className={styles.ctaButton}>
                Зв’язатися з тренером
              </Link>
            </div>
          </div>
        </section>
      </article>
    </>
  );
};

export default Home;