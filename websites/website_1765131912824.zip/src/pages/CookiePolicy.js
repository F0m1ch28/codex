import React from 'react';
import Helmet from '../components/Helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet
      title="Політика щодо файлів cookie — Професійне дресирування німецьких вівчарок"
      description="Читати політику щодо cookie на сайті Професійне дресирування німецьких вівчарок."
    />
    <section className={styles.legal}>
      <div className="container">
        <h1>Політика щодо файлів cookie</h1>
        <p>Оновлено: {new Date().toLocaleDateString('uk-UA')}</p>
        <h2>1. Що таке cookie</h2>
        <p>Cookie — це невеликі текстові файли, які зберігаються у вашому браузері для покращення роботи сайту.</p>
        <h2>2. Які cookie ми використовуємо</h2>
        <ul>
          <li>Технічні cookie — забезпечують базові функції сайту.</li>
          <li>Аналітичні cookie — допомагають зрозуміти, як користувачі взаємодіють із сайтом (без ідентифікації).</li>
        </ul>
        <h2>3. Як керувати cookie</h2>
        <p>
          Ви можете змінити налаштування браузера, щоб блокувати або видаляти cookie. Врахуйте, що це може вплинути на
          роботу сайту.
        </p>
        <h2>4. Згода</h2>
        <p>Продовжуючи користуватися сайтом або приймаючи банер, ви погоджуєтесь на використання cookie.</p>
        <h2>5. Контакти</h2>
        <p>
          Питання щодо cookie надсилайте на <a href="mailto:info@shepherd-training.pl">info@shepherd-training.pl</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;