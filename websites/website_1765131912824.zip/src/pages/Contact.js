import React, { useState } from 'react';
import Helmet from '../components/Helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    city: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Вкажіть ім'я.";
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Вкажіть email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email має некоректний формат.';
    }
    if (!formData.city.trim()) {
      newErrors.city = 'Вкажіть місто.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Напишіть коротке повідомлення.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setStatus('Дякуємо! Ми зв’яжемося з вами найближчим часом.');
      setFormData({ name: '', email: '', city: '', message: '' });
    } else {
      setStatus('');
    }
  };

  return (
    <>
      <Helmet
        title="Контакти — Професійне дресирування німецьких вівчарок"
        description="Зв’яжіться з тренерами з дресирування німецьких вівчарок у Варшаві та Кракові. Телефон, email, контактна форма."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Контакти</h1>
          <p>Заплануйте першу консультацію і дізнайтеся, як ми можемо допомогти вашій вівчарці.</p>
        </div>
      </section>

      <section className={`container ${styles.content}`}>
        <div className={styles.details}>
          <h2>Як нас знайти</h2>
          <ul>
            <li>
              <strong>Варшава:</strong> вул. Собача, 10
            </li>
            <li>
              <strong>Краків:</strong> вул. Пастуша, 5
            </li>
            <li>
              <strong>Телефон:</strong> <a href="tel:+48123456789">+48 123 456 789</a>
            </li>
            <li>
              <strong>Email:</strong> <a href="mailto:info@shepherd-training.pl">info@shepherd-training.pl</a>
            </li>
          </ul>
          <p>
            Ми працюємо за попереднім записом. Надішліть коротке повідомлення або зателефонуйте, щоб обрати зручний час
            діагностичної зустрічі.
          </p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Залиште заявку</h2>
          <label htmlFor="name">Ім’я</label>
          <input
            id="name"
            name="name"
            type="text"
            value={formData.name}
            onChange={handleChange}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? 'name-error' : undefined}
          />
          {errors.name && (
            <span id="name-error" className={styles.error}>
              {errors.name}
            </span>
          )}

          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? 'email-error' : undefined}
          />
          {errors.email && (
            <span id="email-error" className={styles.error}>
              {errors.email}
            </span>
          )}

          <label htmlFor="city">Місто</label>
          <input
            id="city"
            name="city"
            type="text"
            value={formData.city}
            onChange={handleChange}
            aria-invalid={Boolean(errors.city)}
            aria-describedby={errors.city ? 'city-error' : undefined}
          />
          {errors.city && (
            <span id="city-error" className={styles.error}>
              {errors.city}
            </span>
          )}

          <label htmlFor="message">Повідомлення</label>
          <textarea
            id="message"
            name="message"
            rows="5"
            value={formData.message}
            onChange={handleChange}
            aria-invalid={Boolean(errors.message)}
            aria-describedby={errors.message ? 'message-error' : undefined}
          />
          {errors.message && (
            <span id="message-error" className={styles.error}>
              {errors.message}
            </span>
          )}

          <button type="submit" className={styles.submitButton}>
            Надіслати
          </button>
          {status && (
            <p className={styles.success} role="status" aria-live="polite">
              {status}
            </p>
          )}
        </form>
      </section>
    </>
  );
};

export default Contact;