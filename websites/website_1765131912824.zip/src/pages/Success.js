import React from 'react';
import Helmet from '../components/Helmet';
import styles from './Success.module.css';

const Success = () => {
  const stories = [
    {
      title: 'Краківська команда «Лютар»',
      description:
        'Піврічний супровід спортивної пари: підготовка до змагань, робота над апортами і витримкою. Результат — стабільний контакт і вихід на регіональний чемпіонат.',
      image: 'https://picsum.photos/900/600?random=701'
    },
    {
      title: 'Реактивна вівчарка з Варшави',
      description:
        'Собака реагувала на кожного пішохода. Через 12 тижнів роботи — впевнені прогулянки в центрі міста, соціалізація з іншими собаками під контролем.',
      image: 'https://picsum.photos/900/600?random=702'
    },
    {
      title: 'Програма сімейної адаптації',
      description:
        'Молода сука переїхала до родини з двома дітьми. Ми вибудували правила взаємодії, запровадили ритуали і запобігли небажаним звичкам.',
      image: 'https://picsum.photos/900/600?random=703'
    }
  ];

  const testimonials = [
    {
      quote:
        'Тренери завжди пояснювали, що і навіщо ми робимо. Для нас головним було навчитися самостійно керувати собакою — ми цього досягли.',
      author: 'Катажина, Варшава'
    },
    {
      quote:
        'Польові заняття у різних районах Кракова показали, як адаптувати вівчарку до реального життя. Тепер прогулянки — задоволення.',
      author: 'Пшемислав, Краків'
    }
  ];

  return (
    <>
      <Helmet
        title="Наші успіхи — Професійне дресирування німецьких вівчарок"
        description="Приклади успішних програм дресирування німецьких вівчарок у Варшаві та Кракові, відгуки клієнтів."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Наші успіхи</h1>
          <p>Розповідаємо про історії, які надихають нас щоденно працювати ще краще.</p>
        </div>
      </section>

      <section className={`container ${styles.stories}`}>
        {stories.map((story) => (
          <article key={story.title} className={styles.storyCard}>
            <img src={story.image} alt={story.title} loading="lazy" />
            <div>
              <h2>{story.title}</h2>
              <p>{story.description}</p>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <h2>Відгуки клієнтів</h2>
          <div className={styles.testimonialsGrid}>
            {testimonials.map((item) => (
              <blockquote key={item.author}>
                <p>«{item.quote}»</p>
                <cite>{item.author}</cite>
              </blockquote>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Success;