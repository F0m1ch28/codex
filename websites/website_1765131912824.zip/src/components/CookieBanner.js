import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'shepherdTrainingCookieConsent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Ми використовуємо cookie-файли для покращення взаємодії з сайтом. Деталі у{' '}
        <a href="/polityka-cookie">Політиці щодо файлів cookie</a>.
      </p>
      <button type="button" className={styles.button} onClick={acceptCookies}>
        Погоджуюся
      </button>
    </div>
  );
};

export default CookieBanner;