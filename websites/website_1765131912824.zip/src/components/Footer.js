import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.container}`}>
      <div className={styles.brand}>
        <h3>Професійне дресирування німецьких вівчарок</h3>
        <p>
          Професійна кінологічна команда, що допомагає німецьким вівчаркам реалізовувати потенціал із любов’ю,
          дисципліною та сучасними методами.
        </p>
      </div>
      <div className={styles.links}>
        <h4>Навігація</h4>
        <ul>
          <li>
            <Link to="/posluhy">Послуги</Link>
          </li>
          <li>
            <Link to="/pro-nas">Про нас</Link>
          </li>
          <li>
            <Link to="/nashi-uspikhy">Наші успіхи</Link>
          </li>
          <li>
            <Link to="/kontakty">Контакти</Link>
          </li>
        </ul>
      </div>
      <div className={styles.links}>
        <h4>Правова інформація</h4>
        <ul>
          <li>
            <Link to="/umovy-vykorystannya">Умови використання</Link>
          </li>
          <li>
            <Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link>
          </li>
          <li>
            <Link to="/polityka-cookie">Політика щодо файлів cookie</Link>
          </li>
        </ul>
      </div>
      <div className={styles.contact}>
        <h4>Контакти</h4>
        <p>Варшава, вул. Собача, 10</p>
        <p>Краків, вул. Пастуша, 5</p>
        <p>Телефон: <a href="tel:+48123456789">+48 123 456 789</a></p>
        <p>Email: <a href="mailto:info@shepherd-training.pl">info@shepherd-training.pl</a></p>
      </div>
    </div>
    <div className={styles.bottom}>
      &copy; {new Date().getFullYear()} Професійне дресирування німецьких вівчарок. Усі права захищено.
    </div>
  </footer>
);

export default Footer;