import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen((prev) => !prev);
  const closeMenu = () => setOpen(false);

  return (
    <header className={styles.header} role="banner">
      <a href="#main-content" className={styles.skipLink}>
        Перейти до основного контенту
      </a>
      <div className={`container ${styles.wrapper}`}>
        <div className={styles.logo} aria-label="Професійне дресирування німецьких вівчарок">
          Професійне дресирування німецьких вівчарок
        </div>
        <button
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={open}
          aria-controls="primary-navigation"
          aria-label="Меню"
        >
          <span />
          <span />
          <span />
        </button>
        <nav id="primary-navigation" className={`${styles.nav} ${open ? styles.open : ''}`} aria-label="Головна навігація">
          <NavLink to="/" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`} onClick={closeMenu}>
            Головна
          </NavLink>
          <NavLink
            to="/posluhy"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Послуги
          </NavLink>
          <NavLink
            to="/pro-nas"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Про нас
          </NavLink>
          <NavLink
            to="/nashi-uspikhy"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Наші успіхи
          </NavLink>
          <NavLink
            to="/kontakty"
            className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Контакти
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;