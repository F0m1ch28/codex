import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const COOKIE_KEY = "devlayer-consent";

const CookieBanner: React.FC = () => {
  const [visible, setVisible] = React.useState<boolean>(false);

  React.useEffect(() => {
    const storedConsent = localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    localStorage.setItem(COOKIE_KEY, "accepted");
    setVisible(false);
  };

  const decline = () => {
    localStorage.setItem(COOKIE_KEY, "declined");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed bottom-6 left-1/2 z-[60] w-[95%] max-w-3xl -translate-x-1/2 rounded-2xl border border-slate-800 bg-primary/95 px-6 py-5 text-surface shadow-soft"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 40 }}
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="font-display text-lg font-semibold">
                Cookie Notice
              </p>
              <p className="mt-2 text-sm text-slate-300">
                We use minimal cookies to understand reader flow and to improve
                the storytelling experience. Analytics are anonymous and
                aggregated.
              </p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <button
                onClick={decline}
                className="rounded-full border border-slate-600 px-5 py-2 text-sm font-semibold text-slate-200 transition hover:border-slate-400"
              >
                Decline
              </button>
              <button
                onClick={accept}
                className="rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
              >
                Accept
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieBanner;