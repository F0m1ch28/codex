import React from "react";
import { NavLink, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Programs" },
  { to: "/blog", label: "Blog" },
  { to: "/workflows", label: "Workflows" },
  { to: "/mindset", label: "Mindset" },
  { to: "/queue", label: "Reading Queue" },
  { to: "/archives", label: "Archives" },
  { to: "/notes", label: "Notes" },
  { to: "/contact", label: "Contact" }
];

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState<boolean>(false);
  const [isScrolled, setIsScrolled] = React.useState<boolean>(false);

  React.useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    handleScroll();
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  React.useEffect(() => {
    if (isMenuOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
  }, [isMenuOpen]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-shadow duration-300 ${
        isScrolled ? "bg-primary/95 shadow-xl backdrop-blur" : "bg-primary/80"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent text-white shadow-soft">
            <span className="text-lg font-semibold">DL</span>
          </div>
          <div className="hidden flex-col text-surface md:flex">
            <span className="font-display text-lg font-semibold tracking-wide">
              DevLayer
            </span>
            <span className="text-xs uppercase tracking-widest text-slate-300">
              Every Layer Tells a Story
            </span>
          </div>
        </Link>
        <nav className="hidden items-center gap-6 lg:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `text-sm font-medium transition-colors ${
                  isActive
                    ? "text-accent"
                    : "text-slate-200 hover:text-accent focus:text-accent"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="hidden lg:block">
          <Link
            to="/contact"
            className="rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white shadow-soft transition-transform hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-accent/80"
          >
            Connect with Editors
          </Link>
        </div>
        <button
          className="flex items-center justify-center rounded-md border border-slate-600 p-2 text-slate-200 transition hover:border-accent hover:text-accent lg:hidden"
          onClick={() => setIsMenuOpen((prev) => !prev)}
          aria-label="Toggle navigation"
        >
          <span className="sr-only">Open navigation</span>
          <div className="space-y-1.5">
            {[0, 1, 2].map((bar) => (
              <span
                key={bar}
                className={`block h-0.5 w-6 rounded-full bg-current transition-transform ${
                  isMenuOpen && bar === 0
                    ? "translate-y-2 rotate-45"
                    : isMenuOpen && bar === 2
                    ? "-translate-y-1.5 -rotate-45"
                    : isMenuOpen && bar === 1
                    ? "opacity-0"
                    : ""
                }`}
              />
            ))}
          </div>
        </button>
      </div>
      <AnimatePresence>
        {isMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t border-slate-700 bg-primary/95 lg:hidden"
          >
            <ul className="flex flex-col px-4 py-6">
              {navItems.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    onClick={() => setIsMenuOpen(false)}
                    className={({ isActive }) =>
                      `block rounded-lg px-4 py-3 text-sm font-medium transition ${
                        isActive
                          ? "bg-slate-800 text-accent"
                          : "text-slate-200 hover:bg-slate-800 hover:text-accent"
                      }`
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
              <li className="mt-4">
                <Link
                  to="/contact"
                  onClick={() => setIsMenuOpen(false)}
                  className="block rounded-full bg-accent px-4 py-3 text-center text-sm font-semibold text-white shadow-soft"
                >
                  Connect with Editors
                </Link>
              </li>
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;