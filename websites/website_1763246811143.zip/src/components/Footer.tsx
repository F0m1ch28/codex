import React from "react";
import { Link } from "react-router-dom";

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary text-surface">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent text-white">
              DL
            </div>
            <div>
              <p className="font-display text-lg font-semibold">DevLayer</p>
              <p className="text-sm text-slate-300">
                Editorial narratives for developer workflows.
              </p>
            </div>
          </div>
          <p className="mt-6 text-sm leading-relaxed text-slate-400">
            From Toronto, we curate deep dives on software systems, platform
            engineering, and the cognitive craft of shipping resilient products.
          </p>
        </div>
        <div>
          <h3 className="font-display text-base font-semibold uppercase tracking-wide text-slate-200">
            Platform
          </h3>
          <ul className="mt-4 space-y-3 text-sm text-slate-300">
            <li>
              <Link className="transition hover:text-accent" to="/workflows">
                Workflow Patterns
              </Link>
            </li>
            <li>
              <Link className="transition hover:text-accent" to="/mindset">
                Developer Mindset
              </Link>
            </li>
            <li>
              <Link className="transition hover:text-accent" to="/archives">
                Code History
              </Link>
            </li>
            <li>
              <Link className="transition hover:text-accent" to="/queue">
                Reading Queue
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="font-display text-base font-semibold uppercase tracking-wide text-slate-200">
            Company
          </h3>
          <ul className="mt-4 space-y-3 text-sm text-slate-300">
            <li>
              <Link className="transition hover:text-accent" to="/about">
                About
              </Link>
            </li>
            <li>
              <Link className="transition hover:text-accent" to="/services">
                Programs
              </Link>
            </li>
            <li>
              <Link className="transition hover:text-accent" to="/blog">
                Essays
              </Link>
            </li>
            <li>
              <Link className="transition hover:text-accent" to="/notes">
                Editorial Notes
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="font-display text-base font-semibold uppercase tracking-wide text-slate-200">
            Connect
          </h3>
          <ul className="mt-4 space-y-3 text-sm text-slate-300">
            <li>333 Bay St, Toronto, ON M5H 2R2</li>
            <li>+1 (416) 905-6621</li>
            <li>
              <a
                href="https://github.com/devlayer"
                target="_blank"
                rel="noopener noreferrer"
                className="transition hover:text-accent"
              >
                GitHub
              </a>
            </li>
            <li>
              <a
                href="https://www.linkedin.com/company/devlayer"
                target="_blank"
                rel="noopener noreferrer"
                className="transition hover:text-accent"
              >
                LinkedIn
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-700">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 text-sm text-slate-400 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p>© {new Date().getFullYear()} DevLayer. All rights reserved.</p>
          <div className="flex gap-6">
            <Link className="transition hover:text-accent" to="/privacy">
              Privacy
            </Link>
            <Link className="transition hover:text-accent" to="/terms">
              Terms
            </Link>
            <span className="text-slate-600">
              For educational use only. Editorial references, no guarantees.
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;