import React, { Suspense, lazy } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTop";

const HomePage = lazy(() => import("./pages/Home"));
const AboutPage = lazy(() => import("./pages/About"));
const ServicesPage = lazy(() => import("./pages/Services"));
const ContactPage = lazy(() => import("./pages/Contact"));
const ContactThanksPage = lazy(() => import("./pages/ContactThanks"));
const PrivacyPage = lazy(() => import("./pages/Privacy"));
const TermsPage = lazy(() => import("./pages/Terms"));
const BlogPage = lazy(() => import("./pages/Blog"));
const BlogContextSwitchingPage = lazy(
  () => import("./pages/BlogWhyContextSwitchingKillsProductivity")
);
const BlogCloudPatternsPage = lazy(
  () => import("./pages/BlogCloudPatternsForScale")
);
const BlogDevopsCulturePage = lazy(
  () => import("./pages/BlogTheEvolutionOfDevopsCulture")
);
const WorkflowsPage = lazy(() => import("./pages/Workflows"));
const MindsetPage = lazy(() => import("./pages/Mindset"));
const QueuePage = lazy(() => import("./pages/Queue"));
const ArchivesPage = lazy(() => import("./pages/Archives"));
const NotesPage = lazy(() => import("./pages/Notes"));

const ScrollToTopOnRoute: React.FC = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname]);

  return null;
};

const App: React.FC = () => {
  const location = useLocation();

  return (
    <div className="bg-surface text-slate-800">
      <ScrollToTopOnRoute />
      <Header />
      <AnimatePresence mode="wait">
        <Suspense
          fallback={
            <div className="flex min-h-screen items-center justify-center bg-surface">
              <div className="h-16 w-16 animate-spin rounded-full border-4 border-accent border-t-transparent" />
            </div>
          }
        >
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/contact/thanks" element={<ContactThanksPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route
              path="/blog/why-context-switching-kills-productivity"
              element={<BlogContextSwitchingPage />}
            />
            <Route
              path="/blog/cloud-patterns-for-scale"
              element={<BlogCloudPatternsPage />}
            />
            <Route
              path="/blog/the-evolution-of-devops-culture"
              element={<BlogDevopsCulturePage />}
            />
            <Route path="/workflows" element={<WorkflowsPage />} />
            <Route path="/mindset" element={<MindsetPage />} />
            <Route path="/queue" element={<QueuePage />} />
            <Route path="/archives" element={<ArchivesPage />} />
            <Route path="/notes" element={<NotesPage />} />
          </Routes>
        </Suspense>
      </AnimatePresence>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;