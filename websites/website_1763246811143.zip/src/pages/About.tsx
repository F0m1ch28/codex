import React from "react";
import { Helmet } from "react-helmet-async";

const About: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>About DevLayer | Editorial Mission & Values</title>
        <meta
          name="description"
          content="Learn about DevLayer's mission, editorial values, methodology, ethics, and the people curating stories on developer workflows and software systems."
        />
        <meta
          property="og:title"
          content="About DevLayer | Editorial Mission & Values"
        />
        <meta
          property="og:description"
          content="DevLayer is a Canadian editorial studio documenting developer workflows, cloud infrastructure, and platform engineering culture."
        />
        <meta property="og:url" content="https://devlayer.example.com/about" />
        <meta property="og:type" content="article" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=310" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "AboutPage",
            name: "About DevLayer",
            description:
              "Mission and values of DevLayer, an editorial platform for developer workflows.",
            publisher: { "@type": "Organization", name: "DevLayer" }
          })}
        </script>
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Crafting editorial depth for the developer ecosystem.
          </h1>
          <p className="mt-6 text-secondary">
            DevLayer is an editorial platform born in Toronto, Canada. Our
            mission is to reveal the layered stories behind developer workflows,
            software systems, and cloud infrastructure. We bridge narrative
            craft with engineering rigor to surface insights teams can apply.
          </p>
          <div className="mt-10 grid gap-8 rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft md:grid-cols-2">
            <div>
              <h2 className="font-display text-2xl font-semibold text-primary">
                Editorial Values
              </h2>
              <ul className="mt-4 space-y-3 text-sm text-secondary">
                <li>• Practitioner empathy before analysis.</li>
                <li>• Evidence-backed storytelling over speculation.</li>
                <li>• Ethical sourcing and responsible anonymization.</li>
                <li>• Respect for historical precedent and future impact.</li>
              </ul>
            </div>
            <div>
              <h2 className="font-display text-2xl font-semibold text-primary">
                Methodology
              </h2>
              <p className="mt-4 text-sm text-secondary">
                We conduct interviews, workflow observations, and telemetry
                reviews. Each story includes cross-checking with subject matter
                experts, visual modeling, and narrative testing across audiences.
              </p>
            </div>
          </div>
        </section>

        <section className="bg-secondary/10 py-16">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <h2 className="font-display text-3xl font-semibold text-primary">
              Code of Ethics
            </h2>
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
                <h3 className="font-display text-xl font-semibold text-primary">
                  Respect for Sources
                </h3>
                <p className="mt-3 text-sm text-secondary">
                  We secure informed consent, maintain confidentiality where
                  required, and help participants review key insights prior to
                  publication.
                </p>
              </div>
              <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
                <h3 className="font-display text-xl font-semibold text-primary">
                  Evidence & Attribution
                </h3>
                <p className="mt-3 text-sm text-secondary">
                  All data, quotes, and historical references are documented and
                  attributed. We track revision history and errata transparently.
                </p>
              </div>
              <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
                <h3 className="font-display text-xl font-semibold text-primary">
                  Impact Review
                </h3>
                <p className="mt-3 text-sm text-secondary">
                  We assess the potential organizational impact of our stories
                  and share guidance on responsible adoption of featured practices.
                </p>
              </div>
              <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
                <h3 className="font-display text-xl font-semibold text-primary">
                  Historical Stewardship
                </h3>
                <p className="mt-3 text-sm text-secondary">
                  Our archives team ensures legacy artifacts are contextualized
                  with care and respect for original contributors.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h2 className="font-display text-3xl font-semibold text-primary">
            Our Story
          </h2>
          <p className="mt-4 text-secondary">
            DevLayer started as a small Toronto meetup documenting workflow
            experiments across local startups. The transcripts became essays,
            the essays became playbooks, and demand for thoughtful storytelling
            grew. Today, DevLayer partners with platform engineering leaders,
            product teams, and research labs to capture how software gets made.
          </p>
        </section>
      </main>
    </>
  );
};

export default About;