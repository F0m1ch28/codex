import React from "react";
import { Helmet } from "react-helmet-async";

const notes = [
  {
    title: "January 2024 Editorial Update",
    content:
      "Kicked off a new series on developer onboarding rituals with input from Canadian platform teams.",
    date: "Jan 15, 2024"
  },
  {
    title: "Archive Digitization Progress",
    content:
      "Digitized three legacy UNIX memos; annotations coming this spring.",
    date: "Jan 8, 2024"
  },
  {
    title: "Dispatch Experiments",
    content:
      "Testing shorter narrative fragments to deliver workflow insights between major essays.",
    date: "Dec 20, 2023"
  }
];

const Notes: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Editorial Notes | DevLayer</title>
        <meta
          name="description"
          content="Internal notes and updates from the DevLayer editorial team."
        />
        <meta property="og:title" content="Editorial Notes | DevLayer" />
        <meta
          property="og:description"
          content="Stay current with DevLayer's editorial experiments and platform updates."
        />
        <meta property="og:url" content="https://devlayer.example.com/notes" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Editorial Notes
          </h1>
          <p className="mt-6 text-secondary">
            Quick updates from the DevLayer newsroom, offering a peek into our
            editorial experiments and platform engineering research pipeline.
          </p>
          <div className="mt-10 space-y-6">
            {notes.map((note) => (
              <div
                key={note.title}
                className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
              >
                <p className="text-xs uppercase tracking-[0.3em] text-secondary">
                  {note.date}
                </p>
                <h2 className="mt-2 font-display text-2xl font-semibold text-primary">
                  {note.title}
                </h2>
                <p className="mt-3 text-sm text-secondary">{note.content}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};

export default Notes;