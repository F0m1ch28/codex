import React from "react";
import { Helmet } from "react-helmet-async";

const queueItems = [
  {
    title: "Maintenance Windows as Culture Shifts",
    description:
      "Reframing maintenance windows as deliberate pauses for innovation and learning.",
    tags: ["developer workflows", "culture"]
  },
  {
    title: "Streaming Telemetry for Cognitive Relief",
    description:
      "Reducing dashboard overload with contextual stream processing and purposeful alerting.",
    tags: ["software systems", "cloud infrastructure"]
  },
  {
    title: "Documentation that Meets Developers Where They Are",
    description:
      "Adaptive documentation strategies that mirror day-to-day engineering workflows.",
    tags: ["technical writing", "platform engineering"]
  },
  {
    title: "Legacy Stories from the Archives",
    description:
      "Exploring historical RFCs to understand the foundations of modern distributed computing.",
    tags: ["code history", "distributed computing"]
  }
];

const Queue: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Reading Queue | DevLayer</title>
        <meta
          name="description"
          content="DevLayer's curated reading queue featuring upcoming essays and research themes."
        />
        <meta property="og:title" content="Reading Queue | DevLayer" />
        <meta
          property="og:description"
          content="Curated queue of upcoming DevLayer essays on developer workflows and software systems."
        />
        <meta property="og:url" content="https://devlayer.example.com/queue" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Reading Queue
          </h1>
          <p className="mt-6 text-secondary">
            Here’s what the editorial team is currently researching. Expect to
            see these stories in upcoming dispatches.
          </p>
          <div className="mt-10 space-y-6">
            {queueItems.map((item) => (
              <div
                key={item.title}
                className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
              >
                <h2 className="font-display text-2xl font-semibold text-primary">
                  {item.title}
                </h2>
                <p className="mt-3 text-sm text-secondary">{item.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {item.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-accent"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};

export default Queue;