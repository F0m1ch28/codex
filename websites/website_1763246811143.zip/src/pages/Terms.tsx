import React from "react";
import { Helmet } from "react-helmet-async";

const Terms: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | DevLayer</title>
        <meta
          name="description"
          content="Read DevLayer's terms of use covering intellectual property, disclaimers, and jurisdiction."
        />
        <meta property="og:title" content="Terms of Use | DevLayer" />
        <meta
          property="og:description"
          content="DevLayer terms of use for editorial content."
        />
        <meta property="og:url" content="https://devlayer.example.com/terms" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Terms of Use
          </h1>
          <div className="mt-8 space-y-6 text-sm text-secondary">
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Acceptance of Terms
              </h2>
              <p className="mt-2">
                By accessing DevLayer you agree to these terms. If you disagree,
                please refrain from using the site.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Intellectual Property
              </h2>
              <p className="mt-2">
                DevLayer owns the editorial content, graphics, and design. You
                may reference excerpts with attribution and a link back to the
                original article.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Use of Content
              </h2>
              <p className="mt-2">
                Content is provided for educational purposes. DevLayer does not
                provide warranties and is not liable for decisions made using our
                materials.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Disclaimers
              </h2>
              <p className="mt-2">
                While we verify information, software ecosystems change quickly.
                Readers should validate practices within their own environments.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Jurisdiction
              </h2>
              <p className="mt-2">
                These terms are governed by the laws of Ontario, Canada. Disputes
                shall be resolved in Ontario courts.
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Terms;