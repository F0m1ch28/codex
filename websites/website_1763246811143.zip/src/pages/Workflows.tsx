import React from "react";
import { Helmet } from "react-helmet-async";

const workflowSections = [
  {
    title: "CI/CD Harmonies",
    description:
      "Designing pipelines that balance automation with human oversight. We study how teams choreograph testing, approvals, and progressive delivery.",
    bullets: [
      "Commit conventions and branching models",
      "Pipeline observability with actionable dashboards",
      "Rollout strategies aligned with customer signals"
    ]
  },
  {
    title: "Build Pipeline Ergonomics",
    description:
      "Build pipelines should feel like supportive choreography. We analyze caching strategies, dependency controls, and developer feedback loops.",
    bullets: [
      "Build time budgets and alerting thresholds",
      "Dependency risk registers and mitigation playbooks",
      "Feedback loops that surface experience metrics"
    ]
  },
  {
    title: "IDE & Tooling Rituals",
    description:
      "From AI-assisted code review to context-rich snippets, we examine how tooling either supports or distracts from deep engineering work.",
    bullets: [
      "IDE telemetry and qualitative research",
      "Pair programming ergonomics",
      "Tool adoption narratives from field studies"
    ]
  },
  {
    title: "Team Ceremonies",
    description:
      "Rituals like standups, retrospectives, and roadmap reviews hint at the health of a developer workflow. We document the ones that keep teams aligned.",
    bullets: [
      "Narrative-driven updates instead of status recitations",
      "Retrospectives that connect incidents with strategy",
      "Roadmap reviews anchored in developer experience"
    ]
  }
];

const Workflows: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Workflow Patterns | DevLayer</title>
        <meta
          name="description"
          content="Discover DevLayer's research on CI/CD, build pipelines, IDE ergonomics, and team rituals."
        />
        <meta property="og:title" content="Workflow Patterns | DevLayer" />
        <meta
          property="og:description"
          content="Insights into developer workflows, pipelines, and collaboration rituals."
        />
        <meta property="og:url" content="https://devlayer.example.com/workflows" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Workflow Patterns Library
          </h1>
          <p className="mt-6 text-secondary">
            Our workflow research decodes how teams integrate CI/CD, build
            ergonomics, IDE tooling, and collaborative rituals. Each pattern is
            grounded in field observations and interviews with engineering teams.
          </p>
          <div className="mt-10 space-y-10">
            {workflowSections.map((section) => (
              <div
                key={section.title}
                className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
              >
                <h2 className="font-display text-2xl font-semibold text-primary">
                  {section.title}
                </h2>
                <p className="mt-3 text-sm text-secondary">{section.description}</p>
                <ul className="mt-4 space-y-2 text-sm text-secondary">
                  {section.bullets.map((bullet) => (
                    <li key={bullet}>• {bullet}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};

export default Workflows;