import React from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

type Filter = "All" | "Workflow" | "Systems" | "Tooling" | "Culture";

type BlogPost = {
  title: string;
  description: string;
  category: Filter;
  path: string;
  date: string;
};

const posts: BlogPost[] = [
  {
    title: "Why Context Switching Kills Productivity",
    description:
      "Cognitive fragmentation across development teams and rituals that reclaim deep work.",
    category: "Workflow",
    path: "/blog/why-context-switching-kills-productivity",
    date: "January 10, 2024"
  },
  {
    title: "Cloud Patterns for Scale",
    description:
      "Responsible scaling patterns aligned with platform engineering guardrails.",
    category: "Systems",
    path: "/blog/cloud-patterns-for-scale",
    date: "December 18, 2023"
  },
  {
    title: "The Evolution of DevOps Culture",
    description:
      "From deployment boards to platform teams—how culture adapts to automation.",
    category: "Culture",
    path: "/blog/the-evolution-of-devops-culture",
    date: "November 28, 2023"
  }
];

const Blog: React.FC = () => {
  const [filter, setFilter] = React.useState<Filter>("All");

  const filteredPosts = React.useMemo(() => {
    if (filter === "All") return posts;
    return posts.filter((post) => post.category === filter);
  }, [filter]);

  return (
    <>
      <Helmet>
        <title>DevLayer Blog | Essays on Developer Workflows</title>
        <meta
          name="description"
          content="Explore DevLayer essays analyzing developer workflows, software systems, tooling signals, and DevOps culture."
        />
        <meta
          property="og:title"
          content="DevLayer Blog | Essays on Developer Workflows"
        />
        <meta
          property="og:description"
          content="Narrative-driven essays on developer workflows, platform engineering, and cloud infrastructure."
        />
        <meta property="og:url" content="https://devlayer.example.com/blog" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="font-display text-4xl font-semibold text-primary">
                Essays & Playbooks
              </h1>
              <p className="mt-2 text-secondary">
                Curated research on developer workflows, software systems, and
                platform engineering culture.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {["All", "Workflow", "Systems", "Tooling", "Culture"].map(
                (item) => (
                  <button
                    key={item}
                    onClick={() => setFilter(item as Filter)}
                    className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                      filter === item
                        ? "bg-accent text-white"
                        : "border border-secondary text-secondary hover:border-accent hover:text-accent"
                    }`}
                  >
                    {item}
                  </button>
                )
              )}
            </div>
          </div>
          <div className="mt-10 space-y-6">
            {filteredPosts.map((post) => (
              <article
                key={post.path}
                className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
              >
                <span className="text-xs uppercase tracking-[0.3em] text-secondary">
                  {post.date}
                </span>
                <h2 className="mt-2 font-display text-2xl font-semibold text-primary">
                  {post.title}
                </h2>
                <p className="mt-3 text-sm text-secondary">{post.description}</p>
                <Link
                  to={post.path}
                  className="mt-4 inline-flex items-center text-sm font-semibold text-accent"
                >
                  Read essay →
                </Link>
              </article>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};

export default Blog;