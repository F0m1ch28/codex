import React from "react";
import { Helmet } from "react-helmet-async";

const Privacy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | DevLayer</title>
        <meta
          name="description"
          content="Read how DevLayer handles cookies, analytics, data processing, and user rights."
        />
        <meta property="og:title" content="Privacy Policy | DevLayer" />
        <meta
          property="og:description"
          content="DevLayer's privacy policy covers cookies, analytics, and user rights."
        />
        <meta property="og:url" content="https://devlayer.example.com/privacy" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Privacy Policy
          </h1>
          <p className="mt-6 text-secondary">
            DevLayer respects reader privacy and adheres to Canadian privacy
            legislation. This policy explains how we collect, use, and protect
            data.
          </p>
          <div className="mt-10 space-y-6 text-sm text-secondary">
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Cookies
              </h2>
              <p className="mt-2">
                We use lightweight cookies to remember site preferences and to
                support analytics consent. Cookies are optional and can be
                declined via the cookie banner.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Analytics
              </h2>
              <p className="mt-2">
                We rely on privacy-conscious analytics tools to observe aggregate
                reader behavior. Data is anonymized and never shared with third
                parties for advertising.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Data Handling
              </h2>
              <p className="mt-2">
                Contact form submissions and newsletter sign-ups are stored
                securely in Canada. You may request deletion by contacting our
                editorial team at the email you used when submitting.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                Third-Party Services
              </h2>
              <p className="mt-2">
                We integrate Sendler for contact submissions and privacy-first
                newsletter tools. Each provider complies with Canadian and
                international privacy regulations.
              </p>
            </div>
            <div>
              <h2 className="font-display text-xl font-semibold text-primary">
                User Rights
              </h2>
              <p className="mt-2">
                You can request access, correction, or deletion of your data by
                emailing our editorial team. We respond within 30 days.
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Privacy;