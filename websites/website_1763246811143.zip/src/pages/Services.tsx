import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const services = [
  {
    title: "Editorial Field Labs",
    description:
      "Immersive research programs where our editors join your sprint rituals, architecture sessions, and incident debriefs to map developer workflows end-to-end.",
    deliverables: [
      "Workflow journey maps",
      "Narrative summary of systemic friction",
      "Recommendations grounded in platform engineering practices"
    ]
  },
  {
    title: "Platform Story Series",
    description:
      "A multi-part editorial series translating your cloud infrastructure evolution into accessible stories for stakeholders and future hires.",
    deliverables: [
      "Feature-length essays with diagrams",
      "Interview clips and audio excerpts",
      "Companion briefing for leadership teams"
    ]
  },
  {
    title: "Developer Mindset Clinics",
    description:
      "Interactive workshops and playbooks focusing on cognition, communication rituals, and sustainable pace across distributed teams.",
    deliverables: [
      "Facilitated sessions",
      "Mindset assessments",
      "Actionable rituals for focus and alignment"
    ]
  }
];

const Services: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>DevLayer Programs | Editorial Services</title>
        <meta
          name="description"
          content="Explore DevLayer's editorial programs, including field research, platform storytelling, and developer mindset clinics."
        />
        <meta
          property="og:title"
          content="DevLayer Programs | Editorial Services"
        />
        <meta
          property="og:description"
          content="Programs designed to surface insights on developer workflows, software systems, and cloud infrastructure."
        />
        <meta property="og:url" content="https://devlayer.example.com/services" />
        <meta property="og:type" content="article" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=320" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Programs tailored for developer workflow storytelling.
          </h1>
          <p className="mt-6 max-w-2xl text-secondary">
            Each engagement blends investigative research, narrative craft, and
            practical playbooks. We partner with platform engineering teams to
            capture the nuance of their systems and culture.
          </p>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <h2 className="font-display text-2xl font-semibold text-primary">
                  {service.title}
                </h2>
                <p className="mt-4 text-sm text-secondary">{service.description}</p>
                <ul className="mt-6 space-y-2 text-sm text-secondary">
                  {service.deliverables.map((deliverable) => (
                    <li key={deliverable}>• {deliverable}</li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};

export default Services;