import React from "react";
import { Helmet } from "react-helmet-async";

const archives = [
  {
    title: "RFC 3168: The Addition of Explicit Congestion Notification",
    year: 2001,
    insight:
      "Understanding how congestion control shaped modern distributed systems.",
    linkText: "View commentary"
  },
  {
    title: "The Xerox PARC Alto Memo Collection",
    year: 1973,
    insight:
      "Tracing interface innovations that influence today’s development environments.",
    linkText: "Explore annotations"
  },
  {
    title: "UNIX Seventh Edition Manual",
    year: 1979,
    insight:
      "An annotated dive into pipeline thinking and its impact on CI/CD workflows.",
    linkText: "Review highlights"
  },
  {
    title: "The Google SRE Book Field Notes",
    year: 2016,
    insight:
      "Field notes summarizing resilience practices that seeded many platform engineering teams.",
    linkText: "Read synthesis"
  }
];

const Archives: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Archives | DevLayer</title>
        <meta
          name="description"
          content="Historical archives curated by DevLayer featuring RFCs, memos, and foundational documents."
        />
        <meta property="og:title" content="Archives | DevLayer" />
        <meta
          property="og:description"
          content="DevLayer archives highlight historical documents that inform modern developer workflows."
        />
        <meta property="og:url" content="https://devlayer.example.com/archives" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            DevLayer Archives
          </h1>
          <p className="mt-6 text-secondary">
            Our archive surfaces foundational documents that influenced today’s
            developer workflows and cloud infrastructure practices.
          </p>
          <div className="mt-10 space-y-6">
            {archives.map((item) => (
              <div
                key={item.title}
                className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
              >
                <p className="text-xs uppercase tracking-[0.3em] text-secondary">
                  {item.year}
                </p>
                <h2 className="mt-2 font-display text-2xl font-semibold text-primary">
                  {item.title}
                </h2>
                <p className="mt-3 text-sm text-secondary">{item.insight}</p>
                <span className="mt-4 inline-flex items-center text-sm font-semibold text-accent">
                  {item.linkText} →
                </span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};

export default Archives;