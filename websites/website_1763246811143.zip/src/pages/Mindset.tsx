import React from "react";
import { Helmet } from "react-helmet-async";

const essays = [
  {
    title: "Focus Windows & Attention Mapping",
    description:
      "How teams carve out focus windows, defend energy, and align leadership expectations.",
    tags: ["engineering psychology", "developer workflows"]
  },
  {
    title: "Narrative-First Communication",
    description:
      "Replacing status updates with story-driven communication that builds shared understanding.",
    tags: ["technical writing", "culture"]
  },
  {
    title: "Restorative Incident Practices",
    description:
      "Pairing post-incident reviews with reflection rituals to sustain healthy platform teams.",
    tags: ["devops culture", "platform engineering"]
  },
  {
    title: "Remote Collaboration Heuristics",
    description:
      "Signals and rhythms that keep distributed teams synchronized without overloading calendars.",
    tags: ["distributed computing", "mindset"]
  }
];

const Mindset: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Developer Mindset | DevLayer</title>
        <meta
          name="description"
          content="Essays on the cognitive side of software engineering, addressing focus, communication, and sustainable pace."
        />
        <meta property="og:title" content="Developer Mindset | DevLayer" />
        <meta
          property="og:description"
          content="Insights on engineering psychology, burnout prevention, and communication rituals."
        />
        <meta property="og:url" content="https://devlayer.example.com/mindset" />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
          <h1 className="font-display text-4xl font-semibold text-primary">
            Developer Mindset Essays
          </h1>
          <p className="mt-6 text-secondary">
            The human side of software engineering influences everything from
            architecture decisions to incident response. DevLayer documents the
            rituals, perspectives, and cognitive frameworks that sustain teams.
          </p>
          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {essays.map((essay) => (
              <div
                key={essay.title}
                className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
              >
                <h2 className="font-display text-2xl font-semibold text-primary">
                  {essay.title}
                </h2>
                <p className="mt-3 text-sm text-secondary">{essay.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {essay.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-accent"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
};

export default Mindset;