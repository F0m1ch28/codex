import React from "react";
import { Helmet } from "react-helmet-async";
import { useNavigate } from "react-router-dom";

type FormState = {
  name: string;
  email: string;
  company: string;
  message: string;
};

type Errors = Partial<Record<keyof FormState, string>>;

const initialState: FormState = {
  name: "",
  email: "",
  company: "",
  message: ""
};

const Contact: React.FC = () => {
  const [form, setForm] = React.useState<FormState>(initialState);
  const [errors, setErrors] = React.useState<Errors>({});
  const navigate = useNavigate();

  const validate = (): boolean => {
    const newErrors: Errors = {};
    if (!form.name.trim()) {
      newErrors.name = "Please enter your name.";
    }
    if (!form.email.includes("@")) {
      newErrors.email = "Please provide a valid email address.";
    }
    if (!form.company.trim()) {
      newErrors.company = "Please enter your organization.";
    }
    if (form.message.trim().length < 20) {
      newErrors.message = "Please share at least 20 characters.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validate()) return;

    // Simulate integration with Sendler PHP script then navigate
    navigate("/contact/thanks", { replace: true });
  };

  const handleChange =
    (field: keyof FormState) =>
    (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setForm((prev) => ({ ...prev, [field]: event.target.value }));
    };

  return (
    <>
      <Helmet>
        <title>Contact DevLayer | Editorial Partnerships</title>
        <meta
          name="description"
          content="Connect with DevLayer to discuss editorial collaborations focused on developer workflows, software systems, and cloud infrastructure."
        />
        <meta
          property="og:title"
          content="Contact DevLayer | Editorial Partnerships"
        />
        <meta
          property="og:description"
          content="Contact DevLayer editors in Toronto to collaborate on developer workflow storytelling and research."
        />
        <meta property="og:url" content="https://devlayer.example.com/contact" />
        <meta property="og:type" content="article" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=330" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <h1 className="font-display text-4xl font-semibold text-primary">
                Let’s explore your next editorial journey.
              </h1>
              <p className="mt-6 text-secondary">
                Share your platform engineering story, developer workflow
                insights, or cloud infrastructure evolution. Our editors will
                respond within two business days.
              </p>
              <div className="mt-6 space-y-4 rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft text-sm text-secondary">
                <p>
                  <strong className="text-primary">Address:</strong> 333 Bay St,
                  Toronto, ON M5H 2R2, Canada
                </p>
                <p>
                  <strong className="text-primary">Phone:</strong> +1 (416)
                  905-6621
                </p>
                <p>
                  <strong className="text-primary">GitHub:</strong>{" "}
                  <a
                    href="https://github.com/devlayer"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-accent"
                  >
                    github.com/devlayer
                  </a>
                </p>
                <p>
                  <strong className="text-primary">LinkedIn:</strong>{" "}
                  <a
                    href="https://www.linkedin.com/company/devlayer"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-accent"
                  >
                    linkedin.com/company/devlayer
                  </a>
                </p>
              </div>
              <iframe
                title="DevLayer Toronto Office"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.105544254322!2d-79.38233902343776!3d43.64947997110271!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d3e0e6f36b%3A0x66c3ad137de6eb59!2s333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2%2C%20Canada!5e0!3m2!1sen!2sca!4v1700000000000"
                loading="lazy"
                className="mt-6 h-64 w-full rounded-3xl border border-slate-200"
                allowFullScreen
              />
            </div>
            <form
              onSubmit={handleSubmit}
              className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
            >
              <div>
                <label
                  htmlFor="name"
                  className="block text-sm font-semibold text-primary"
                >
                  Name
                </label>
                <input
                  id="name"
                  value={form.name}
                  onChange={handleChange("name")}
                  className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none"
                  placeholder="Jordan Rivera"
                />
                {errors.name && (
                  <p className="mt-1 text-xs text-red-500">{errors.name}</p>
                )}
              </div>
              <div className="mt-4">
                <label
                  htmlFor="email"
                  className="block text-sm font-semibold text-primary"
                >
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange("email")}
                  className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none"
                  placeholder="you@company.com"
                  required
                />
                {errors.email && (
                  <p className="mt-1 text-xs text-red-500">{errors.email}</p>
                )}
              </div>
              <div className="mt-4">
                <label
                  htmlFor="company"
                  className="block text-sm font-semibold text-primary"
                >
                  Organization
                </label>
                <input
                  id="company"
                  value={form.company}
                  onChange={handleChange("company")}
                  className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none"
                  placeholder="Platform Engineering Team"
                />
                {errors.company && (
                  <p className="mt-1 text-xs text-red-500">{errors.company}</p>
                )}
              </div>
              <div className="mt-4">
                <label
                  htmlFor="message"
                  className="block text-sm font-semibold text-primary"
                >
                  How can we collaborate?
                </label>
                <textarea
                  id="message"
                  value={form.message}
                  onChange={handleChange("message")}
                  className="mt-2 h-40 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm text-secondary focus:border-accent focus:outline-none"
                  placeholder="Share context about your developer workflows, platform engineering goals, or story ideas..."
                />
                {errors.message && (
                  <p className="mt-1 text-xs text-red-500">{errors.message}</p>
                )}
              </div>
              <button
                type="submit"
                className="mt-6 w-full rounded-full bg-accent px-4 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
              >
                Send to DevLayer Editors
              </button>
              <p className="mt-3 text-xs text-secondary">
                Submission is routed securely to our Sendler integration. We
                respond within two business days.
              </p>
            </form>
          </div>
        </section>
      </main>
    </>
  );
};

export default Contact;