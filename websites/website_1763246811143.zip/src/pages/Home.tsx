import React from "react";
import { Link } from "react-router-dom";
import { motion, useInView } from "framer-motion";
import { Helmet } from "react-helmet-async";

type Stat = {
  label: string;
  value: number;
  suffix?: string;
};

type ExploreItem = {
  title: string;
  description: string;
  icon: string;
};

type Card = {
  title: string;
  excerpt: string;
  link: string;
  tag: string;
};

type WorkflowPattern = {
  title: string;
  description: string;
};

type ToolingSignal = {
  title: string;
  insight: string;
};

type MindsetInsight = {
  title: string;
  description: string;
};

type TimelineStep = {
  step: string;
  description: string;
};

type Testimonial = {
  quote: string;
  author: string;
  role: string;
};

type TeamMember = {
  name: string;
  title: string;
  bio: string;
  image: string;
};

type Project = {
  title: string;
  description: string;
  category: string;
  image: string;
};

type FAQItem = {
  question: string;
  answer: string;
};

const stats: Stat[] = [
  {
    label: "Workflow breakdowns",
    value: 140,
    suffix: "+"
  },
  {
    label: "Platform interviews",
    value: 68,
    suffix: ""
  },
  {
    label: "Cloud patterns mapped",
    value: 36,
    suffix: ""
  },
  {
    label: "Historical artifacts",
    value: 210,
    suffix: ""
  }
];

const exploreItems: ExploreItem[] = [
  {
    title: "Systems",
    description:
      "Distributed computing, infrastructure topologies, and the invisible contracts that keep releases resilient.",
    icon: "🧭"
  },
  {
    title: "Workflows",
    description:
      "Developer workflows that choreograph commits, reviews, and delivery pipelines across global teams.",
    icon: "🛠️"
  },
  {
    title: "Cognition",
    description:
      "Engineering psychology, focus rituals, and the feedback loops that guard against burnout.",
    icon: "🧠"
  }
];

const featuredEssays: Card[] = [
  {
    title: "Why Context Switching Disrupts Delivery Cycles",
    excerpt:
      "A look into cognitive residue, fragmented attention, and how teams reclaim deep focus.",
    link: "/blog/why-context-switching-kills-productivity",
    tag: "Mindset"
  },
  {
    title: "Cloud Patterns for Responsible Scale",
    excerpt:
      "Pragmatic approaches to multi-region deployments, resilience budgets, and latency-aware architecture.",
    link: "/blog/cloud-patterns-for-scale",
    tag: "Systems"
  },
  {
    title: "The Evolution of DevOps Culture",
    excerpt:
      "From cultural handshakes to platform teams—the new rituals guiding collaborative engineering.",
    link: "/blog/the-evolution-of-devops-culture",
    tag: "Culture"
  }
];

const workflowPatterns: WorkflowPattern[] = [
  {
    title: "Continuous Integration Rhythms",
    description:
      "Cadence planning, branch hygiene, and evidence-based commit policies that keep builds breathable."
  },
  {
    title: "Progressive Delivery",
    description:
      "Feature flags, experimental cohorts, and observability guardrails to learn without disrupting users."
  },
  {
    title: "Incident Replay Studios",
    description:
      "Narrative-driven incident reviews aligning platform engineering insights with roadmap choices."
  }
];

const toolingSignals: ToolingSignal[] = [
  {
    title: "IDE Ergonomics Index",
    insight:
      "Pairing heuristics and context-aware surfacing shorten discovery of defects during code review sessions."
  },
  {
    title: "Telemetry Compression",
    insight:
      "Event prioritization strategies reduce noise while preserving signals critical to distributed tracing."
  },
  {
    title: "Workflow Dashboards",
    insight:
      "Composable dashboards feed the right narrative: developer experience, lead time, and cognitive load."
  }
];

const mindsetInsights: MindsetInsight[] = [
  {
    title: "Defend Focus Time",
    description:
      "Defragmented calendars correlate with deeper architecture choices and faster onboarding for new engineers."
  },
  {
    title: "Story-Driven Communication",
    description:
      "Briefing formats that distill system state shift conversations from speculation to shared understanding."
  },
  {
    title: "Sustainable Pace",
    description:
      "Teams thrive when rituals address energy, not just velocity—pairing retrospectives with rest practices."
  }
];

const timeline: TimelineStep[] = [
  {
    step: "01 | Field Research",
    description:
      "We interview platform engineers, product teams, and SREs to surface behavioral signals."
  },
  {
    step: "02 | Workflow Mapping",
    description:
      "Each essay diagrams workflow friction and enabling structures with visual systems thinking."
  },
  {
    step: "03 | Narrative Assembly",
    description:
      "Editors craft multi-layered stories that merge data, history, and cognitive frameworks."
  },
  {
    step: "04 | Delivery Playbooks",
    description:
      "Insights become actionable frameworks for developer workflows and infrastructure stewardship."
  }
];

const testimonials: Testimonial[] = [
  {
    quote:
      "DevLayer translated our platform migration into a nuanced story that resonated across leadership and engineers alike.",
    author: "Priya Raman",
    role: "Director of Platform Engineering, Northwave"
  },
  {
    quote:
      "Their editorial lens on developer workflows helped our teams articulate friction and redesign practices with intent.",
    author: "Liam Chen",
    role: "Engineering Manager, Polaris Labs"
  },
  {
    quote:
      "The depth of historical context and research rigour sets DevLayer apart. It feels like an atlas for modern software teams.",
    author: "Amelia Volkov",
    role: "Principal Architect, Aurora Systems"
  }
];

const teamMembers: TeamMember[] = [
  {
    name: "Elena Matsuda",
    title: "Editor-in-Chief",
    bio: "Former platform engineer guiding research on developer workflows and engineering psychology.",
    image: "https://picsum.photos/400/400?random=103"
  },
  {
    name: "Marcus Patel",
    title: "Director of Systems Research",
    bio: "Leads distributed computing investigations and curates cloud infrastructure narratives.",
    image: "https://picsum.photos/400/400?random=104"
  },
  {
    name: "Sofia Grant",
    title: "Senior Technical Writer",
    bio: "Transforms complex telemetry and platform architecture into accessible essays and playbooks.",
    image: "https://picsum.photos/400/400?random=105"
  }
];

const projects: Project[] = [
  {
    title: "The Observability Atlas",
    description:
      "A visual field guide for telemetry-first engineering cultures, connecting signals with workflow rituals.",
    category: "Systems",
    image: "https://picsum.photos/1200/800?random=204"
  },
  {
    title: "Delivery Rhythm Research Lab",
    description:
      "Longitudinal study of release cadence, developer experience, and psychological safety.",
    category: "Workflows",
    image: "https://picsum.photos/1200/800?random=205"
  },
  {
    title: "Cloud Stewardship Narratives",
    description:
      "Explores responsible scale strategies across multi-cloud estates with practical playbooks.",
    category: "Cloud",
    image: "https://picsum.photos/1200/800?random=206"
  },
  {
    title: "Cognitive Load Field Notes",
    description:
      "Ethnographic research on focus, collaboration, and sustainable engineering pace.",
    category: "Mindset",
    image: "https://picsum.photos/1200/800?random=207"
  }
];

const faqItems: FAQItem[] = [
  {
    question: "What makes DevLayer different from traditional tech publications?",
    answer:
      "We focus on narrative-driven analysis of developer workflows, pairing qualitative research with system diagrams and historical context."
  },
  {
    question: "Do you collaborate with engineering teams?",
    answer:
      "Yes, we partner with platform, SRE, and product teams to document processes, surface playbooks, and share responsibly anonymized insights."
  },
  {
    question: "How often are new essays published?",
    answer:
      "We release primary essays every month, supported by weekly notes and archival additions that extend the research."
  },
  {
    question: "Can we pitch topics to the editorial team?",
    answer:
      "Absolutely. Reach out via the contact form with your workflow or platform engineering story. We evaluate pitches based on rigor and relevance."
  }
];

const readingQueue = [
  {
    title: "Resilience Budgeting in Platform Engineering",
    description:
      "How teams set experiential budgets for downtime, experimentation, and infrastructure upgrades.",
    tags: ["platform engineering", "developer workflows"]
  },
  {
    title: "Signals-Driven Backlog Prioritization",
    description:
      "Using observability data to orchestrate backlog priorities and align with developer experience goals.",
    tags: ["software systems", "cloud infrastructure"]
  },
  {
    title: "Narrating Legacy Modernization",
    description:
      "Storytelling techniques that help teams honor history while embracing platform re-architecture.",
    tags: ["code history", "technical writing"]
  }
];

const blogPreview = [
  {
    title: "Lifecycle of a Feature Flag",
    excerpt:
      "From inception to sunset, we follow a feature flag across distributed teams and environments.",
    link: "/blog"
  },
  {
    title: "When Incident Reviews Become Story Studios",
    excerpt:
      "Narratives that transform actionable learning into shared understanding across the org chart.",
    link: "/blog"
  },
  {
    title: "Human-centered Telemetry Dashboards",
    excerpt:
      "Designing dashboards that sharpen cognition instead of overwhelming engineers with noise.",
    link: "/blog"
  }
];

const Home: React.FC = () => {
  const statsRef = React.useRef<HTMLDivElement | null>(null);
  const isStatsInView = useInView(statsRef, { once: true, amount: 0.3 });
  const [testimonialIndex, setTestimonialIndex] = React.useState<number>(0);
  const [projectFilter, setProjectFilter] = React.useState<string>("All");
  const [subscriberEmail, setSubscriberEmail] = React.useState<string>("");
  const [subscriberMessage, setSubscriberMessage] = React.useState<string>("");
  const [activeFaq, setActiveFaq] = React.useState<number | null>(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = React.useMemo(() => {
    if (projectFilter === "All") return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  const animatedValues = React.useMemo(() => {
    if (!isStatsInView) {
      return stats.map(() => 0);
    }
    return stats.map((stat) => stat.value);
  }, [isStatsInView]);

  const handleSubscribe = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!subscriberEmail || !subscriberEmail.includes("@")) {
      setSubscriberMessage("Please provide a valid email address.");
      return;
    }
    setSubscriberMessage(
      "Thank you for subscribing. You'll receive the next editorial dispatch."
    );
    setSubscriberEmail("");
  };

  return (
    <>
      <Helmet>
        <title>DevLayer | Editorial Platform for Developer Workflows</title>
        <meta
          name="description"
          content="DevLayer is a Canadian editorial platform exploring developer workflows, software systems, and cloud infrastructure with narrative depth."
        />
        <meta
          property="og:title"
          content="DevLayer | Editorial Platform for Developer Workflows"
        />
        <meta
          property="og:description"
          content="Stories, research, and playbooks across developer workflows, software systems, and platform engineering."
        />
        <meta property="og:url" content="https://devlayer.example.com/" />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=300" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "DevLayer",
            url: "https://devlayer.example.com",
            description:
              "Canadian editorial platform translating developer workflows and platform engineering into narratives.",
            address: {
              "@type": "PostalAddress",
              streetAddress: "333 Bay St",
              addressLocality: "Toronto",
              addressRegion: "ON",
              postalCode: "M5H 2R2",
              addressCountry: "Canada"
            },
            contactPoint: {
              "@type": "ContactPoint",
              telephone: "+1-416-905-6621",
              contactType: "editorial"
            }
          })}
        </script>
      </Helmet>
      <main className="pt-28 md:pt-32">
        <section className="relative overflow-hidden bg-primary text-surface">
          <div className="absolute inset-0">
            <img
              src="https://picsum.photos/1600/900?random=101"
              alt="Developers collaborating in a modern studio"
              className="h-full w-full object-cover opacity-30"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-secondary/90" />
          </div>
          <div className="relative mx-auto flex max-w-6xl flex-col gap-12 px-4 py-24 sm:px-6 lg:flex-row lg:items-center lg:px-8">
            <motion.div
              className="max-w-2xl"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <p className="text-sm uppercase tracking-[0.4em] text-slate-300">
                Every Layer Tells a Story
              </p>
              <h1 className="mt-5 font-display text-4xl font-semibold leading-tight sm:text-5xl lg:text-6xl">
                Editorial intelligence for developer workflows, software
                systems, and cloud infrastructure.
              </h1>
              <p className="mt-6 max-w-xl text-lg text-slate-300">
                DevLayer translates distributed computing practice into
                evidence-based narratives, blending platform engineering
                research, technical writing craft, and engineering psychology.
              </p>
              <div className="mt-10 flex flex-col gap-4 sm:flex-row">
                <Link
                  to="/blog"
                  className="inline-flex items-center justify-center rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-accent/90"
                >
                  Explore Essays
                </Link>
                <a
                  href="#newsletter"
                  className="inline-flex items-center justify-center rounded-full border border-slate-500 px-6 py-3 text-sm font-semibold text-slate-200 transition hover:border-slate-300 hover:text-white"
                >
                  Join the Editorial Dispatch
                </a>
              </div>
            </motion.div>
            <motion.div
              className="relative rounded-3xl border border-slate-700 bg-primary/40 p-6 shadow-soft backdrop-blur"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.9, delay: 0.2 }}
            >
              <div className="space-y-6">
                <div>
                  <h2 className="font-display text-lg font-semibold text-white">
                    Platform Signals Report
                  </h2>
                  <p className="mt-3 text-sm text-slate-300">
                    A curated digest on developer workflows, incident rituals,
                    and cloud infrastructure narratives across Canadian teams.
                  </p>
                </div>
                <div className="rounded-2xl bg-slate-900/50 p-5">
                  <p className="text-xs uppercase tracking-[0.3em] text-slate-400">
                    Latest Highlights
                  </p>
                  <ul className="mt-4 space-y-3 text-sm text-slate-200">
                    <li>→ Internal platforms as storytelling canvases</li>
                    <li>→ Cognitive load audits for distributed squads</li>
                    <li>→ Responsible scaling across multi-cloud estates</li>
                  </ul>
                </div>
                <div className="flex items-center justify-between rounded-2xl bg-slate-900/40 p-5">
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-slate-400">
                      Next release
                    </p>
                    <p className="mt-1 text-base font-semibold text-white">
                      March 2024 Dispatch
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-slate-400">Curated by</p>
                    <p className="font-medium text-white">DevLayer Editors</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section
          ref={statsRef}
          className="mx-auto grid max-w-6xl gap-6 px-4 py-16 sm:px-6 md:grid-cols-2 lg:grid-cols-4 lg:px-8"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft"
              initial={{ opacity: 0, y: 20 }}
              animate={isStatsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.1, duration: 0.6 }}
            >
              <p className="text-xs uppercase tracking-[0.35em] text-primary/60">
                {stat.label}
              </p>
              <p className="mt-4 font-display text-4xl font-semibold text-primary">
                {isStatsInView ? animatedValues[index] : 0}
                {stat.suffix}
              </p>
              <p className="mt-2 text-sm text-secondary">
                Curated cases across developer workflows, software systems, and
                cloud infrastructure research.
              </p>
            </motion.div>
          ))}
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.4em] text-secondary">
                What We Explore
              </p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                Every narrative maps a developer workflow, a software system,
                and a human story.
              </h2>
            </div>
            <p className="max-w-xl text-secondary">
              Our editors map distributed computing practices, platform
              engineering roadmaps, and engineering psychology to surface
              playbooks that teams can adapt immediately.
            </p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {exploreItems.map((item) => (
              <motion.div
                key={item.title}
                className="group relative rounded-3xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-xl"
                whileHover={{ y: -6 }}
              >
                <span className="text-3xl">{item.icon}</span>
                <h3 className="mt-6 font-display text-2xl font-semibold text-primary">
                  {item.title}
                </h3>
                <p className="mt-4 text-sm text-secondary">{item.description}</p>
                <div className="mt-6 flex items-center text-sm font-semibold text-accent">
                  Explore insights →
                </div>
                <div className="pointer-events-none absolute inset-0 rounded-3xl bg-accent/5 opacity-0 transition group-hover:opacity-100" />
              </motion.div>
            ))}
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                  Featured Essays
                </p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                  Essays bridging developer workflows with platform engineering.
                </h2>
              </div>
              <Link
                to="/blog"
                className="inline-flex items-center rounded-full border border-secondary px-4 py-2 text-sm font-semibold text-secondary transition hover:border-accent hover:text-accent"
              >
                View all essays →
              </Link>
            </div>
            <div className="mt-12 grid gap-6 md:grid-cols-3">
              {featuredEssays.map((essay, index) => (
                <motion.article
                  key={essay.link}
                  className="flex h-full flex-col rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-xl"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <span className="inline-flex items-center rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold text-accent">
                    {essay.tag}
                  </span>
                  <h3 className="mt-4 font-display text-xl font-semibold text-primary">
                    {essay.title}
                  </h3>
                  <p className="mt-4 text-sm text-secondary">{essay.excerpt}</p>
                  <Link
                    to={essay.link}
                    className="mt-auto inline-flex items-center text-sm font-semibold text-accent"
                  >
                    Read the essay →
                  </Link>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-2">
            <div>
              <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                Workflow Patterns
              </p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                Rituals and systems that shape developer experience.
              </h2>
              <p className="mt-4 text-secondary">
                We catalogue patterns emerging from platform engineering labs,
                SRE retrospectives, and product delivery teams. Each pattern
                includes narrative, visuals, and actionable guidance.
              </p>
            </div>
            <div className="space-y-6">
              {workflowPatterns.map((pattern) => (
                <div
                  key={pattern.title}
                  className="rounded-3xl border border-slate-200 bg-white p-5 shadow-soft"
                >
                  <h3 className="font-display text-xl font-semibold text-primary">
                    {pattern.title}
                  </h3>
                  <p className="mt-3 text-sm text-secondary">
                    {pattern.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-secondary/10 py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                  Tooling Signals
                </p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                  Observability-driven cognition for software systems.
                </h2>
              </div>
              <p className="max-w-xl text-secondary">
                Tooling is more than stack choices. We analyze how dashboards,
                IDE ergonomics, and incident tooling shape developer workflows
                and influence engineering psychology.
              </p>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {toolingSignals.map((signal) => (
                <div
                  key={signal.title}
                  className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft"
                >
                  <h3 className="font-display text-xl font-semibold text-primary">
                    {signal.title}
                  </h3>
                  <p className="mt-4 text-sm text-secondary">{signal.insight}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                Developer Mindset
              </p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                Engineering psychology shapes the future of platform work.
              </h2>
              <p className="mt-4 text-secondary">
                From focus rituals to narrative-driven communication, we explore
                the human side of distributed engineering teams. Each essay
                blends cognitive science and practical workflows.
              </p>
              <Link
                to="/mindset"
                className="mt-6 inline-flex items-center text-sm font-semibold text-accent"
              >
                Explore mindset essays →
              </Link>
            </div>
            <div className="space-y-6">
              {mindsetInsights.map((insight) => (
                <div
                  key={insight.title}
                  className="rounded-3xl border border-slate-200 bg-white p-5 shadow-soft"
                >
                  <h3 className="font-display text-xl font-semibold text-primary">
                    {insight.title}
                  </h3>
                  <p className="mt-3 text-sm text-secondary">
                    {insight.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-8 lg:grid-cols-2">
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                  Code History
                </p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                  The archives keep developer wisdom alive.
                </h2>
                <p className="mt-4 text-secondary">
                  DevLayer maintains a growing catalog of RFCs, legacy systems
                  documentation, and open standards. We contextualize them so
                  teams can learn from history while building futures.
                </p>
                <Link
                  to="/archives"
                  className="mt-6 inline-flex items-center text-sm font-semibold text-accent"
                >
                  Visit the archives →
                </Link>
              </div>
              <div className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft">
                <h3 className="font-display text-xl font-semibold text-primary">
                  Editorial Highlights
                </h3>
                <div className="mt-6 space-y-5 text-sm text-secondary">
                  <p>
                    • Early memos on UNIX pipeline thinking and their influence
                    on modern CI/CD rituals.
                  </p>
                  <p>
                    • Annotated timeline of distributed systems breakthroughs,
                    from ARPANET to cloud-native service meshes.
                  </p>
                  <p>
                    • Oral histories from platform pioneers shaping today’s
                    developer workflows.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-secondary">
              Reading Queue
            </p>
            <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
              Curated queue for your next deep focus block.
            </h2>
          </div>
          <div className="mt-8 space-y-6">
            {readingQueue.map((item) => (
              <div
                key={item.title}
                className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft"
              >
                <h3 className="font-display text-xl font-semibold text-primary">
                  {item.title}
                </h3>
                <p className="mt-3 text-sm text-secondary">{item.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {item.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-accent"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-secondary/10 py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div>
              <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                Process
              </p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                Our editorial workflow distills complex ecosystems into
                meaningful stories.
              </h2>
            </div>
            <div className="mt-12 grid gap-6 lg:grid-cols-4">
              {timeline.map((step) => (
                <div
                  key={step.step}
                  className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft"
                >
                  <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                    {step.step}
                  </p>
                  <p className="mt-4 text-sm text-secondary">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                Programs
              </p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                Services designed for the developer workflow community.
              </h2>
            </div>
            <Link
              to="/services"
              className="inline-flex items-center rounded-full border border-secondary px-4 py-2 text-sm font-semibold text-secondary transition hover:border-accent hover:text-accent"
            >
              View programs →
            </Link>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {[
              {
                title: "Workflow Diagnostics",
                description:
                  "On-site and remote investigations mapping developer workflows across teams."
              },
              {
                title: "Narrative Playbooks",
                description:
                  "Custom editorial series that articulate platform engineering strategies."
              },
              {
                title: "Leadership Briefings",
                description:
                  "Quarterly insights combining cloud infrastructure trends with engineering psychology."
              }
            ].map((service) => (
              <div
                key={service.title}
                className="group rounded-3xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:border-accent hover:shadow-xl"
              >
                <h3 className="font-display text-xl font-semibold text-primary">
                  {service.title}
                </h3>
                <p className="mt-4 text-sm text-secondary">{service.description}</p>
                <span className="mt-6 inline-flex items-center text-sm font-semibold text-accent">
                  Discover →
                </span>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                  Testimonials
                </p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                  Trusted by platform teams navigating complex systems.
                </h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    setTestimonialIndex(
                      (prev) => (prev - 1 + testimonials.length) % testimonials.length
                    )
                  }
                  className="rounded-full border border-secondary p-2 text-secondary transition hover:border-accent hover:text-accent"
                  aria-label="Previous testimonial"
                >
                  ←
                </button>
                <button
                  onClick={() =>
                    setTestimonialIndex((prev) => (prev + 1) % testimonials.length)
                  }
                  className="rounded-full border border-secondary p-2 text-secondary transition hover:border-accent hover:text-accent"
                  aria-label="Next testimonial"
                >
                  →
                </button>
              </div>
            </div>
            <div className="mt-10 overflow-hidden rounded-3xl border border-slate-200 bg-surface p-8 shadow-soft">
              <motion.div
                key={testimonialIndex}
                initial={{ opacity: 0, x: 60 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <p className="text-lg text-secondary">
                  “{testimonials[testimonialIndex].quote}”
                </p>
                <p className="mt-6 text-sm font-semibold text-primary">
                  {testimonials[testimonialIndex].author}
                </p>
                <p className="text-sm text-secondary">
                  {testimonials[testimonialIndex].role}
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="bg-secondary/10 py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                  Team
                </p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                  Editors with platform engineering roots.
                </h2>
              </div>
              <p className="max-w-xl text-secondary">
                We combine practitioner expertise with narrative craft to capture
                the realities of developer workflows and cloud infrastructure.
              </p>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {teamMembers.map((member) => (
                <div
                  key={member.name}
                  className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft"
                >
                  <img
                    src={member.image}
                    alt={`Portrait of ${member.name}`}
                    className="h-52 w-full rounded-2xl object-cover"
                    loading="lazy"
                  />
                  <h3 className="mt-6 font-display text-xl font-semibold text-primary">
                    {member.name}
                  </h3>
                  <p className="text-sm text-accent">{member.title}</p>
                  <p className="mt-3 text-sm text-secondary">{member.bio}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                  Projects
                </p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                  Investigative projects exploring the layers of software.
                </h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {["All", "Systems", "Workflows", "Cloud", "Mindset"].map(
                  (category) => (
                    <button
                      key={category}
                      onClick={() => setProjectFilter(category)}
                      className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                        projectFilter === category
                          ? "bg-accent text-white"
                          : "border border-secondary text-secondary hover:border-accent hover:text-accent"
                      }`}
                    >
                      {category}
                    </button>
                  )
                )}
              </div>
            </div>
            <div className="mt-10 grid gap-6 lg:grid-cols-2">
              {filteredProjects.map((project) => (
                <motion.div
                  key={project.title}
                  className="overflow-hidden rounded-3xl border border-slate-200 bg-surface shadow-soft"
                  whileHover={{ y: -4 }}
                >
                  <img
                    src={project.image}
                    alt={`Project insight: ${project.title}`}
                    className="h-64 w-full object-cover"
                    loading="lazy"
                  />
                  <div className="p-6">
                    <span className="rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-accent">
                      {project.category}
                    </span>
                    <h3 className="mt-4 font-display text-2xl font-semibold text-primary">
                      {project.title}
                    </h3>
                    <p className="mt-3 text-sm text-secondary">
                      {project.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-secondary/10 py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-8 lg:grid-cols-2">
              <div>
                <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                  FAQ
                </p>
                <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                  Questions about DevLayer.
                </h2>
                <p className="mt-4 text-secondary">
                  Our editorial studio blends rigorous research with thoughtful
                  storytelling. Here is what readers and partners ask us most.
                </p>
              </div>
              <div className="space-y-4">
                {faqItems.map((item, index) => (
                  <div
                    key={item.question}
                    className="rounded-3xl border border-slate-200 bg-white p-5 shadow-soft"
                  >
                    <button
                      onClick={() =>
                        setActiveFaq((prev) => (prev === index ? null : index))
                      }
                      className="flex w-full items-center justify-between text-left"
                    >
                      <span className="font-display text-base font-semibold text-primary">
                        {item.question}
                      </span>
                      <span className="text-accent">
                        {activeFaq === index ? "−" : "+"}
                      </span>
                    </button>
                    {activeFaq === index && (
                      <p className="mt-3 text-sm text-secondary">
                        {item.answer}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div>
              <p className="text-xs uppercase tracking-[0.35em] text-secondary">
                Latest Insights
              </p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-primary">
                Blog preview
              </h2>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {blogPreview.map((post) => (
                <div
                  key={post.title}
                  className="rounded-3xl border border-slate-200 bg-surface p-6 shadow-soft"
                >
                  <h3 className="font-display text-xl font-semibold text-primary">
                    {post.title}
                  </h3>
                  <p className="mt-3 text-sm text-secondary">{post.excerpt}</p>
                  <Link
                    to={post.link}
                    className="mt-4 inline-flex items-center text-sm font-semibold text-accent"
                  >
                    Continue reading →
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section
          id="newsletter"
          className="relative overflow-hidden bg-primary text-surface"
        >
          <div className="absolute inset-0">
            <img
              src="https://picsum.photos/1200/800?random=208"
              alt="City skyline symbolizing connected engineering teams"
              className="h-full w-full object-cover opacity-30"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-primary/90" />
          </div>
          <div className="relative mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
            <div className="rounded-3xl border border-slate-800/80 bg-primary/80 p-8 shadow-soft backdrop-blur">
              <p className="text-xs uppercase tracking-[0.35em] text-slate-300">
                Newsletter
              </p>
              <h2 className="mt-3 font-display text-3xl font-semibold text-white">
                Receive the DevLayer Dispatch.
              </h2>
              <p className="mt-4 max-w-2xl text-sm text-slate-200">
                Monthly editorial insights on developer workflows, platform
                engineering, and cloud infrastructure—crafted for engineering
                leaders, staff engineers, and technical writers.
              </p>
              <form
                onSubmit={handleSubscribe}
                className="mt-8 flex flex-col gap-4 sm:flex-row"
              >
                <input
                  type="email"
                  value={subscriberEmail}
                  onChange={(event) => setSubscriberEmail(event.target.value)}
                  placeholder="yourname@company.com"
                  className="w-full rounded-full border border-slate-600 bg-primary/40 px-5 py-3 text-sm text-white placeholder:text-slate-400 focus:border-accent focus:outline-none"
                  required
                />
                <button
                  type="submit"
                  className="inline-flex h-12 items-center justify-center rounded-full bg-accent px-6 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
                >
                  Subscribe
                </button>
              </form>
              {subscriberMessage && (
                <p className="mt-3 text-sm text-slate-200">
                  {subscriberMessage}
                </p>
              )}
            </div>
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl border border-slate-200 bg-surface p-8 shadow-soft text-center">
              <h2 className="font-display text-3xl font-semibold text-primary">
                Ready to co-create your next editorial journey?
              </h2>
              <p className="mt-4 text-secondary">
                Partner with DevLayer to tell the story of your platform
                engineering breakthroughs, developer workflows, and cloud
                infrastructure strategies.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-4">
                <Link
                  to="/contact"
                  className="rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-accent/90"
                >
                  Start a conversation
                </Link>
                <Link
                  to="/services"
                  className="rounded-full border border-secondary px-6 py-3 text-sm font-semibold text-secondary transition hover:border-accent hover:text-accent"
                >
                  View editorial programs
                </Link>
              </div>
              <p className="mt-6 text-xs uppercase tracking-[0.4em] text-secondary">
                For educational use only
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Home;