import React from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

const ContactThanks: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Thank You | DevLayer</title>
        <meta
          name="description"
          content="Thank you for contacting DevLayer. Our editors will respond shortly."
        />
        <meta property="og:title" content="Thank You | DevLayer" />
        <meta
          property="og:description"
          content="Your message reached the DevLayer editorial team."
        />
        <meta
          property="og:url"
          content="https://devlayer.example.com/contact/thanks"
        />
        <meta property="og:type" content="article" />
      </Helmet>
      <main className="bg-white pt-32">
        <section className="mx-auto max-w-3xl px-4 py-16 text-center sm:px-6 lg:px-8">
          <div className="rounded-3xl border border-slate-200 bg-surface p-10 shadow-soft">
            <h1 className="font-display text-3xl font-semibold text-primary">
              Your message is in our inbox.
            </h1>
            <p className="mt-4 text-secondary">
              Thank you for reaching out. Our Sendler integration delivered your
              note to the editorial desk. We will respond within two business
              days.
            </p>
            <div className="mt-6 flex justify-center gap-4">
              <Link
                to="/"
                className="rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
              >
                Return home
              </Link>
              <Link
                to="/blog"
                className="rounded-full border border-secondary px-6 py-3 text-sm font-semibold text-secondary transition hover:border-accent hover:text-accent"
              >
                Read latest essays
              </Link>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default ContactThanks;