document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = siteNav.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        const navLinks = siteNav.querySelectorAll('a');
        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 1024) {
                    siteNav.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    const declineCookies = document.getElementById('declineCookies');

    if (cookieBanner && acceptCookies && declineCookies) {
        const storedDecision = localStorage.getItem('preferthvl-cookie-decision');
        if (storedDecision) {
            cookieBanner.classList.add('is-hidden');
        }

        const saveDecision = function (decision) {
            localStorage.setItem('preferthvl-cookie-decision', decision);
            cookieBanner.classList.add('is-hidden');
        };

        acceptCookies.addEventListener('click', function () {
            saveDecision('accepted');
        });

        declineCookies.addEventListener('click', function () {
            saveDecision('declined');
        });
    }
});