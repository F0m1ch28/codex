document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieButtons = cookieBanner ? cookieBanner.querySelectorAll('[data-consent]') : [];

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            document.body.classList.toggle('nav-open', !expanded);
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 1023) {
                    document.body.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem('focusvbgs-cookie-consent');
        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const consentValue = button.dataset.consent || 'dismissed';
                localStorage.setItem('focusvbgs-cookie-consent', consentValue);
                cookieBanner.classList.add('is-hidden');
            });
        });
    }
});