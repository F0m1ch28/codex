document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      mainNav.classList.toggle("is-open");
    });

    mainNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (mainNav.classList.contains("is-open")) {
          mainNav.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const storedChoice = localStorage.getItem("df-cookie-choice");
    if (storedChoice) {
      cookieBanner.classList.add("is-hidden");
    }
    cookieBanner.querySelectorAll("button[data-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        const choice = button.getAttribute("data-choice");
        localStorage.setItem("df-cookie-choice", choice);
        cookieBanner.classList.add("is-hidden");
      });
    });
  }
});