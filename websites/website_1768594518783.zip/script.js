document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.querySelector(".menu-toggle");
    const nav = document.querySelector(".site-nav");

    if (menuToggle && nav) {
        menuToggle.addEventListener("click", function () {
            const expanded = this.getAttribute("aria-expanded") === "true" || false;
            this.setAttribute("aria-expanded", !expanded);
            nav.classList.toggle("is-open");
        });

        nav.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (menuToggle.getAttribute("aria-expanded") === "true") {
                    menuToggle.setAttribute("aria-expanded", "false");
                    nav.classList.remove("is-open");
                }
            });
        });
    }

    const timelineButtons = document.querySelectorAll("[data-timeline-year]");
    const timelineHeading = document.getElementById("timelineYear");
    const timelineBody = document.getElementById("timelineBody");

    if (timelineButtons.length && timelineHeading && timelineBody) {
        timelineButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                timelineButtons.forEach(function (btn) {
                    btn.setAttribute("aria-pressed", "false");
                });
                button.setAttribute("aria-pressed", "true");
                const year = button.dataset.timelineYear;
                const heading = button.dataset.timelineHeading;
                const description = button.dataset.timelineDescription;
                timelineHeading.textContent = heading || year;
                timelineBody.textContent = description || "";
            });
        });

        const defaultButton = document.querySelector("[data-timeline-year].default-active");
        if (defaultButton) {
            defaultButton.click();
        }
    }

    const mapButtons = document.querySelectorAll("[data-location]");
    const mapTitle = document.getElementById("mapLocationTitle");
    const mapDescription = document.getElementById("mapLocationDescription");

    if (mapButtons.length && mapTitle && mapDescription) {
        mapButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                mapButtons.forEach(function (btn) {
                    btn.setAttribute("aria-pressed", "false");
                });
                button.setAttribute("aria-pressed", "true");
                mapTitle.textContent = button.dataset.locationTitle || "Grid Node";
                mapDescription.textContent = button.dataset.locationDescription || "";
            });
        });

        const defaultLocation = document.querySelector("[data-location].default-active");
        if (defaultLocation) {
            defaultLocation.click();
        }
    }

    const layerToggles = document.querySelectorAll(".layer-toggle input[type='checkbox']");
    const layerCards = document.querySelectorAll(".layer-card");

    if (layerToggles.length && layerCards.length) {
        const updateLayers = function () {
            const activeLayers = Array.from(layerToggles)
                .filter(function (checkbox) {
                    return checkbox.checked;
                })
                .map(function (checkbox) {
                    return checkbox.value;
                });

            layerCards.forEach(function (card) {
                if (activeLayers.includes(card.dataset.layer)) {
                    card.classList.add("is-active");
                } else {
                    card.classList.remove("is-active");
                }
            });
        };

        layerToggles.forEach(function (toggle) {
            toggle.addEventListener("change", updateLayers);
        });

        updateLayers();
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookies = document.getElementById("acceptCookies");
    const declineCookies = document.getElementById("declineCookies");
    const cookieStorageKey = "vgi_cookie_preference";

    if (cookieBanner && acceptCookies && declineCookies) {
        const storedPreference = localStorage.getItem(cookieStorageKey);
        if (!storedPreference) {
            cookieBanner.classList.add("active");
        }

        acceptCookies.addEventListener("click", function () {
            localStorage.setItem(cookieStorageKey, "accepted");
            cookieBanner.classList.remove("active");
        });

        declineCookies.addEventListener("click", function () {
            localStorage.setItem(cookieStorageKey, "declined");
            cookieBanner.classList.remove("active");
        });
    }

    const consentCheckboxes = document.querySelectorAll(".lead-form input[type='checkbox'][required]");
    consentCheckboxes.forEach(function (checkbox) {
        checkbox.addEventListener("invalid", function () {
            this.setCustomValidity("Please confirm that you understand how your information will be handled.");
        });
        checkbox.addEventListener("change", function () {
            this.setCustomValidity("");
        });
    });
});