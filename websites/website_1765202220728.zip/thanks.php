<?php echo "<" . "!DOCTYPE html>"; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Mensaje enviado | Sol Energía Autoconsumo España</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Confirmación de envío de mensaje a Sol Energía Autoconsumo España.">
  <link rel="canonical" href="https://www.solenergia-autoconsumo.es/thanks.php">
  <meta property="og:title" content="Gracias por contactar">
  <meta property="og:description" content="Tu solicitud se ha enviado correctamente.">
  <meta property="og:image" content="https://picsum.photos/1200/630?random=thanks-solar">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.solenergia-autoconsumo.es/thanks.php">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3E%3Crect width='48' height='48' rx='10' ry='10' fill='%232C3E50'/%3E%3Cpath d='M12 24h24M24 12v24' stroke='%23F39C12' stroke-width='4' stroke-linecap='round'/%3E%3Ccircle cx='24' cy='24' r='6' fill='%2327AE60'/%3E%3C/svg%3E">
</head>
<body class="page-thanks">
  <a class="skip-link" href="#contenido">Saltar al contenido principal</a>
  <header class="site-header" role="banner">
    <div class="container nav-wrapper">
      <a class="brand" href="index.html">
        <span class="brand-mark">Sol Energía</span>
        <span class="brand-sub">Autoconsumo España</span>
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="menuPrincipal">
        <span class="nav-toggle-line"></span>
        <span class="nav-toggle-line"></span>
        <span class="nav-toggle-line"></span>
        <span class="visually-hidden">Abrir menú</span>
      </button>
      <nav class="site-nav" aria-label="Menú principal">
        <ul id="menuPrincipal" class="nav-links">
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Quiénes somos</a></li>
          <li><a href="services.html">Servicios</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="contact.php">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenido">
    <section class="section hero hero-thanks">
      <div class="container hero-grid">
        <div class="hero-content">
          <h1>¡Gracias por tu mensaje!</h1>
          <p>Hemos recibido tu solicitud. Nuestro equipo de Sol Energía Autoconsumo España revisará la información y se pondrá en contacto contigo en un plazo máximo de 24 horas laborables.</p>
          <div class="hero-actions">
            <a class="btn btn-primary" href="index.html">Volver al inicio</a>
            <a class="btn btn-secondary" href="services.html">Ver servicios</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer" role="contentinfo">
    <div class="container footer-grid">
      <div>
        <h3>Sol Energía Autoconsumo España</h3>
        <p>Torre Mapfre, Carrer de la Marina 16–18, Planta 20<br>08005 Barcelona, España</p>
        <p>Tel: <a href="tel:+34931624978">+34 931 624 978</a><br>Correo: <a href="mailto:contacto@solenergia-autoconsumo.es">contacto@solenergia-autoconsumo.es</a></p>
      </div>
      <div>
        <h4>Compañía</h4>
        <ul class="footer-links">
          <li><a href="about.html">Quiénes somos</a></li>
          <li><a href="services.html">Servicios</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="contact.php">Contacto</a></li>
        </ul>
      </div>
      <div>
        <h4>Legal</h4>
        <ul class="footer-links">
          <li><a href="privacy.html">Privacidad</a></li>
          <li><a href="cookies.html">Cookies</a></li>
          <li><a href="terms.html">Términos legales</a></li>
        </ul>
      </div>
      <div>
        <h4>Síguenos</h4>
        <ul class="footer-links">
          <li><a href="https://www.linkedin.com" target="_blank" rel="noopener">LinkedIn</a></li>
          <li><a href="https://www.twitter.com" target="_blank" rel="noopener">Twitter</a></li>
        </ul>
      </div>
    </div>
    <p class="footer-note">© <span id="currentYear">2024</span> Sol Energía Autoconsumo España. Ingeniería solar de alto rendimiento.</p>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <div class="cookie-content">
      <p>Utilizamos cookies analíticas para mejorar la experiencia. Puedes aceptarlas o rechazarlas.</p>
      <div class="cookie-actions">
        <button class="btn btn-secondary" id="cookieDecline">Rechazar</button>
        <button class="btn btn-primary" id="cookieAccept">Aceptar</button>
      </div>
      <a class="cookie-link" href="cookies.html">Más información</a>
    </div>
  </div>

  <script src="main.js" defer></script>
</body>
</html>