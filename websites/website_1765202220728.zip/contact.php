<?php echo "<" . "!DOCTYPE html>"; ?>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto | Sol Energía Autoconsumo España</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Contacta con Sol Energía Autoconsumo España para solicitar estudio solar, instalaciones fotovoltaicas y soluciones de autoconsumo.">
  <link rel="canonical" href="https://www.solenergia-autoconsumo.es/contact.php">
  <meta property="og:title" content="Contactar con Sol Energía Autoconsumo España">
  <meta property="og:description" content="Solicita estudio solar personalizado para paneles solares España, baterías y monitorización.">
  <meta property="og:image" content="https://picsum.photos/1200/630?random=contact-office">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.solenergia-autoconsumo.es/contact.php">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 48'%3E%3Crect width='48' height='48' rx='10' ry='10' fill='%232C3E50'/%3E%3Cpath d='M12 24h24M24 12v24' stroke='%23F39C12' stroke-width='4' stroke-linecap='round'/%3E%3Ccircle cx='24' cy='24' r='6' fill='%2327AE60'/%3E%3C/svg%3E">
</head>
<body class="page-contact">
  <a class="skip-link" href="#contenido">Saltar al contenido principal</a>
  <header class="site-header" role="banner">
    <div class="container nav-wrapper">
      <a class="brand" href="index.html">
        <span class="brand-mark">Sol Energía</span>
        <span class="brand-sub">Autoconsumo España</span>
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="menuPrincipal">
        <span class="nav-toggle-line"></span>
        <span class="nav-toggle-line"></span>
        <span class="nav-toggle-line"></span>
        <span class="visually-hidden">Abrir menú</span>
      </button>
      <nav class="site-nav" aria-label="Menú principal">
        <ul id="menuPrincipal" class="nav-links">
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Quiénes somos</a></li>
          <li><a href="services.html">Servicios</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="contact.php" class="nav-cta active">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenido">
    <section class="hero hero-inner">
      <div class="container hero-grid">
        <div class="hero-content">
          <p class="eyebrow">Hablemos de tu proyecto</p>
          <h1>Solicitar Estudio Solar Gratuito</h1>
          <p>Completa el formulario y nuestro equipo se pondrá en contacto para analizar tu instalación fotovoltaica, almacenamiento energético y subvenciones disponibles.</p>
        </div>
      </div>
    </section>

    <section class="section" aria-labelledby="contacto">
      <div class="container contact-grid">
        <div>
          <h2 id="contacto">Formulario de contacto</h2>
          <form class="form" action="thanks.php" method="post">
            <div class="form-field">
              <label for="nombre">Nombre completo</label>
              <input id="nombre" name="nombre" type="text" autocomplete="name" required>
            </div>
            <div class="form-field">
              <label for="email">Correo electrónico</label>
              <input id="email" name="email" type="email" autocomplete="email" required>
            </div>
            <div class="form-field">
              <label for="telefono">Teléfono</label>
              <input id="telefono" name="telefono" type="tel" autocomplete="tel">
            </div>
            <div class="form-field">
              <label for="tipo-proyecto">Tipo de proyecto</label>
              <select id="tipo-proyecto" name="tipo-proyecto">
                <option value="residencial">Autoconsumo residencial</option>
                <option value="comercial">Energía solar empresas</option>
                <option value="mixto">Proyecto mixto</option>
              </select>
            </div>
            <div class="form-field">
              <label for="mensaje">Mensaje</label>
              <textarea id="mensaje" name="mensaje" rows="5" placeholder="Describe tus necesidades energéticas"></textarea>
            </div>
            <div class="form-checkbox">
              <input id="legal" name="legal" type="checkbox" required>
              <label for="legal">He leído y acepto la <a href="privacy.html">política de privacidad</a>.</label>
            </div>
            <button class="btn btn-primary" type="submit">Enviar solicitud</button>
          </form>
        </div>
        <aside class="contact-info">
          <div class="info-card">
            <h3>Oficina principal</h3>
            <p>Torre Mapfre<br>Carrer de la Marina 16–18, Planta 20<br>08005 Barcelona, España</p>
          </div>
          <div class="info-card">
            <h3>Contacto directo</h3>
            <p>Tel: <a href="tel:+34931624978">+34 931 624 978</a><br>Correo: <a href="mailto:contacto@solenergia-autoconsumo.es">contacto@solenergia-autoconsumo.es</a></p>
          </div>
          <div class="info-card">
            <h3>Horario de atención</h3>
            <p>Lunes a viernes · 9:00 - 18:00</p>
          </div>
          <div class="info-card">
            <img src="https://picsum.photos/600/400?random=office-space" loading="lazy" width="600" height="400" alt="Oficina de Sol Energía Autoconsumo España en Barcelona">
          </div>
          <div class="info-card">
            <img src="https://picsum.photos/600/400?random=field-team" loading="lazy" width="600" height="400" alt="Equipo técnico revisando instalación solar">
          </div>
        </aside>
      </div>
    </section>

    <section class="section accent" aria-labelledby="mapa">
      <div class="container">
        <h2 id="mapa">Cómo llegar</h2>
        <div class="map-wrapper">
          <iframe title="Ubicación de Sol Energía Autoconsumo España" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2992.424910942796!2d2.190701315429823!3d41.38632737926296!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4a2f8a4a4dbcb%3A0x2fb1c0c1060b0d30!2sTorre%20Mapfre!5e0!3m2!1ses!2ses!4v1700000000000!5m2!1ses!2ses" loading="lazy" width="600" height="450" style="border:0;" allowfullscreen="" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer" role="contentinfo">
    <div class="container footer-grid">
      <div>
        <h3>Sol Energía Autoconsumo España</h3>
        <p>Torre Mapfre, Carrer de la Marina 16–18, Planta 20<br>08005 Barcelona, España</p>
        <p>Tel: <a href="tel:+34931624978">+34 931 624 978</a><br>Correo: <a href="mailto:contacto@solenergia-autoconsumo.es">contacto@solenergia-autoconsumo.es</a></p>
      </div>
      <div>
        <h4>Compañía</h4>
        <ul class="footer-links">
          <li><a href="about.html">Quiénes somos</a></li>
          <li><a href="services.html">Servicios</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="contact.php" class="active">Contacto</a></li>
        </ul>
      </div>
      <div>
        <h4>Legal</h4>
        <ul class="footer-links">
          <li><a href="privacy.html">Privacidad</a></li>
          <li><a href="cookies.html">Cookies</a></li>
          <li><a href="terms.html">Términos legales</a></li>
        </ul>
      </div>
      <div>
        <h4>Síguenos</h4>
        <ul class="footer-links">
          <li><a href="https://www.linkedin.com" target="_blank" rel="noopener">LinkedIn</a></li>
          <li><a href="https://www.twitter.com" target="_blank" rel="noopener">Twitter</a></li>
        </ul>
      </div>
    </div>
    <p class="footer-note">© <span id="currentYear">2024</span> Sol Energía Autoconsumo España. Ingeniería solar de alto rendimiento.</p>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <div class="cookie-content">
      <p>Utilizamos cookies analíticas para mejorar la experiencia. Puedes aceptarlas o rechazarlas.</p>
      <div class="cookie-actions">
        <button class="btn btn-secondary" id="cookieDecline">Rechazar</button>
        <button class="btn btn-primary" id="cookieAccept">Aceptar</button>
      </div>
      <a class="cookie-link" href="cookies.html">Más información</a>
    </div>
  </div>

  <script src="main.js" defer></script>
</body>
</html>