document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.site-nav');
  const navLinks = document.querySelectorAll('.nav-links a');
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  const currentYear = document.getElementById('currentYear');

  if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (navMenu.classList.contains('open')) {
          navMenu.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const COOKIE_KEY = 'solEnergiaCookies';
  const cookieStatus = localStorage.getItem(COOKIE_KEY);

  if (cookieBanner) {
    if (!cookieStatus) {
      setTimeout(() => cookieBanner.classList.add('show'), 800);
    } else {
      cookieBanner.classList.add('hidden');
    }

    acceptBtn?.addEventListener('click', () => {
      localStorage.setItem(COOKIE_KEY, 'accepted');
      cookieBanner.classList.remove('show');
      cookieBanner.classList.add('hidden');
    });

    declineBtn?.addEventListener('click', () => {
      localStorage.setItem(COOKIE_KEY, 'declined');
      cookieBanner.classList.remove('show');
      cookieBanner.classList.add('hidden');
    });
  }
});