document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navigation = document.querySelector(".nav");

  if (navToggle && navigation) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navigation.classList.toggle("active");
    });

    navigation.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navigation.classList.remove("active");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const yearElement = document.getElementById("current-year");
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const consentKey = "gridnexis-cookie-consent";

  function hideBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  function showBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("active");
    }
  }

  if (cookieBanner && acceptBtn && declineBtn) {
    const savedConsent = localStorage.getItem(consentKey);
    if (!savedConsent) {
      setTimeout(showBanner, 1000);
    }

    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      hideBanner();
    });

    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      hideBanner();
    });
  }

  const contactForm = document.querySelector('form[data-form="contact"]');
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      window.location.href = "thanks.html";
    });
  }
});