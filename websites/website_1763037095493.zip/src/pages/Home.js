import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import useInView from '../hooks/useInView';

const Home = () => {
  const statsData = [
    { label: 'CO₂-Reduktion pro Jahr', value: 2800, suffix: 't' },
    { label: 'Erfolgreiche Projekte', value: 145, suffix: '+' },
    { label: 'Energieeinsparung', value: 37, suffix: '%' },
    { label: 'Zertifizierte Experten', value: 42, suffix: '' }
  ];

  const [statsRef, statsVisible] = useInView({ threshold: 0.4 });
  const [counters, setCounters] = useState(statsData.map(() => 0));
  useEffect(() => {
    if (!statsVisible) return;
    const intervals = statsData.map((stat, index) => {
      const duration = 1600;
      const frameRate = 20;
      const totalFrames = Math.round(duration / frameRate);
      let frame = 0;
      return setInterval(() => {
        frame += 1;
        const progress = Math.min(frame / totalFrames, 1);
        setCounters((prev) => {
          const updated = [...prev];
          updated[index] = Math.floor(progress * stat.value);
          return updated;
        });
        if (progress === 1) {
          clearInterval(intervals[index]);
        }
      }, frameRate);
    });
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsVisible, statsData]);

  const [techRef, techVisible] = useInView();
  const [processRef, processVisible] = useInView();
  const [testimonialsRef, testimonialsVisible] = useInView();
  const [faqRef, faqVisible] = useInView();

  const testimonials = [
    {
      quote:
        'GreenTech Innovations hat unsere Rechenzentrumsstrategie komplett neu ausgerichtet. Die CO₂-Einsparungen sind messbar und unsere Systeme laufen effizienter als je zuvor.',
      name: 'Verena Hoffmann',
      position: 'CIO, EcoLog Logistics'
    },
    {
      quote:
        'Dank der digitalen Nachhaltigkeit und den nachhaltigen IT-Lösungen konnten wir unsere Smart-City-Plattform in rekordverdächtiger Zeit ausrollen.',
      name: 'Marc Schneider',
      position: 'Head of Innovation, Stadtwerke Köln'
    },
    {
      quote:
        'Die Kombination aus grüner Technologie und Umwelttechnik ist beeindruckend. Wir erleben täglich, wie moderne IT ressourcenschonend funktionieren kann.',
      name: 'Leonie Berger',
      position: 'Leiterin IT, Alpine Renewables'
    }
  ];

  const [activeTestimonial, setActiveTestimonial] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const services = [
    {
      title: 'Nachhaltige Cloud-Architekturen',
      description:
        'Skalierbare Cloud-Infrastrukturen, optimiert für Energieeffizienz und mit nachweislich reduziertem CO₂-Fußabdruck.',
      icon: '☁️'
    },
    {
      title: 'Green Data Analytics',
      description:
        'Datenstrategien, die Umwelttechnik mit KI verbinden, um Ressourcen intelligent einzusetzen.',
      icon: '📊'
    },
    {
      title: 'Eco Software Engineering',
      description:
        'Softwareentwicklung mit Fokus auf digitale Nachhaltigkeit, zirkuläre Prozesse und langlebige Systeme.',
      icon: '💻'
    }
  ];

  const faqItems = [
    {
      question: 'Wie verbindet GreenTech Innovations nachhaltige IT-Lösungen mit wirtschaftlichem Erfolg?',
      answer:
        'Unsere Projekte vereinen ökologische KPI mit klaren Business-Zielen. Durch Energieeffizienz, optimierte Prozesse und intelligente Datenstrategien erzielen Sie messbare Einsparungen und stärken gleichzeitig Ihre Nachhaltigkeitsbilanz.'
    },
    {
      question: 'Welche Branchen profitieren besonders?',
      answer:
        'Wir begleiten Energieversorger, Industrieunternehmen, Städte und Versorgungsbetriebe sowie den Finanzsektor. Überall dort, wo grüne Technologie und digitale Transformation zusammenkommen, entfalten wir Wirkung.'
    },
    {
      question: 'Wie wird die Umstellung organisiert?',
      answer:
        'Mit unserem 5-Phasen-Framework führen wir Sie von der Analyse über co-kreative Konzepte bis zur Implementierung und kontinuierlichen Optimierung. Transparente Kommunikation und Zertifizierungen sichern den Erfolg.'
    }
  ];

  const blogPreviews = [
    {
      title: 'Digitale Nachhaltigkeit: Warum Effizienz allein nicht reicht',
      excerpt:
        'Wir beleuchten, wie nachhaltige IT-Lösungen weit über klassische Effizienzprogramme hinausgehen und welchen Impact adaptive Systeme haben.',
      link: '/blog/digitale-nachhaltigkeit-strategien'
    },
    {
      title: 'Grüne Technologie in Rechenzentren: Praxisleitfaden 2024',
      excerpt:
        'Von Freikühlung bis KI-gestütztem Load Balancing – so transformieren Unternehmen ihre Rechenzentren zu nachhaltigen Kraftwerken.',
      link: '/blog/gruene-rechenzentren-praxisleitfaden'
    },
    {
      title: 'Smart Cities: Umwelttechnik trifft Data Governance',
      excerpt:
        'Wie urbane Datenplattformen ökologische Ziele unterstützen und gleichzeitig Bürger:innen schützen.',
      link: '/blog/smart-cities-umwelttechnik'
    }
  ];

  const partners = [
    'Siemens Sustainability Lab',
    'BMW Circular Economy Hub',
    'Fraunhofer ISE',
    'Green Deal Allianz',
    'Microsoft Partner for Sustainability',
    'SAP Climate21'
  ];

  return (
    <>
      <Helmet>
        <title>GreenTech Innovations | Nachhaltige IT-Lösungen aus München</title>
        <meta
          name="description"
          content="GreenTech Innovations entwickelt nachhaltige IT-Lösungen, grüne Technologie und Umwelttechnik für Unternehmen. Digitale Nachhaltigkeit made in Germany."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroBadge}>Nachhaltige IT-Lösungen seit 2012</div>
            <h1 id="hero-heading" className={styles.heroTitle}>
              Nachhaltige IT-Lösungen
              <span> für eine klimaneutrale Zukunft</span>
            </h1>
            <p className={styles.heroText}>
              Wir verbinden grüne Technologie, Umwelttechnik und digitale Nachhaltigkeit, um
              Unternehmens-IT emissionsarm, effizient und resilient zu gestalten.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className={styles.heroButtonPrimary}>
                Jetzt Projekt anfragen
              </Link>
              <Link to="/portfolio" className={styles.heroButtonSecondary}>
                Erfolgsstories entdecken
              </Link>
            </div>
            <div className={styles.heroHighlights}>
              <span>ISO 14001 zertifiziert</span>
              <span>EU Green Deal Contributor</span>
              <span>Impact Messung in Echtzeit</span>
            </div>
          </div>
          <div className={styles.heroVisual}>
            <img
              src="https://picsum.photos/1600/900?random=11"
              alt="Professionelles Team bei der Planung nachhaltiger IT-Lösungen"
              loading="lazy"
            />
            <div className={styles.heroFloatingCard}>
              <p>Live Impact Tracking</p>
              <strong>+23% Energieeffizienz</strong>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Erfolgskennzahlen">
        <div className="container">
          <div ref={statsRef} className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <h3>
                  {counters[index]}
                  {stat.suffix}
                </h3>
                <p>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="mission-heading">
        <div className="container">
          <div className={styles.zigzag}>
            <div className={styles.zigzagImage}>
              <img
                src="https://picsum.photos/800/600?random=22"
                alt="Innovative Umwelttechnik im Rechenzentrum"
                loading="lazy"
              />
            </div>
            <div className={styles.zigzagContent}>
              <h2 id="mission-heading">Unsere Mission: Digitale Nachhaltigkeit erlebbar machen</h2>
              <p>
                GreenTech Innovations aus München kombiniert tiefes technologisches Know-how mit
                konsequenter Nachhaltigkeit. Wir entwickeln Strategien und Lösungen, die ökologische
                Ziele messbar unterstützen und Unternehmen resilient machen.
              </p>
              <ul className={styles.featureList}>
                <li>Ganzheitliche Beratung von der Analyse bis zum Rollout</li>
                <li>Verzahnung von Umwelttechnik, Energieeffizienz und IT-Architekturen</li>
                <li>Transparente ESG-Reporting-Tools für Ihre Stakeholder</li>
              </ul>
              <Link to="/about" className={styles.inlineLink}>
                Mehr über uns erfahren →
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.sectionAlternate}`} aria-labelledby="services-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="services-heading">Leistungen, die Wirkung zeigen</h2>
            <p>
              Unsere nachhaltigen IT-Lösungen schaffen skalierbare Mehrwerte. Von der IT-Strategie
              bis zur Umsetzung – alles aus einer Hand, mit klaren Nachhaltigkeitsmetriken.
            </p>
          </div>
          <div className={styles.cardsGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.cardLink}>
                  Mehr erfahren
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        ref={techRef}
        className={`${styles.section} ${styles.fadeIn} ${techVisible ? styles.isVisible : ''}`}
        aria-labelledby="tech-heading"
      >
        <div className="container">
          <div className={styles.zigzag}>
            <div className={styles.zigzagContent}>
              <h2 id="tech-heading">Technologie & Innovation</h2>
              <p>
                Wir kombinieren Edge Computing, KI-basierte Automatisierung und smarte Sensorik mit
                grüner Technologie. In unserem Innovation Lab testen wir neue Ansätze für digitale
                Nachhaltigkeit und skalieren bewährte Lösungen europaweit.
              </p>
              <div className={styles.techStack}>
                <span>Edge & Fog Computing</span>
                <span>AI-gestützte Energiesteuerung</span>
                <span>Carbon Accounting Plattformen</span>
                <span>Zirkuläre Hardware-Konzepte</span>
              </div>
            </div>
            <div className={styles.zigzagImage}>
              <img
                src="https://picsum.photos/800/600?random=33"
                alt="Technologisches Dashboard mit Nachhaltigkeitsmetriken"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section
        ref={processRef}
        className={`${styles.section} ${styles.sectionAlternate} ${styles.fadeIn} ${processVisible ? styles.isVisible : ''}`}
        aria-labelledby="process-heading"
      >
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="process-heading">Unser 5-Phasen Framework</h2>
            <p>
              Transparenz und Co-Kreation von Anfang an: So begleiten wir Ihr Transformationsprojekt
              hin zu nachhaltiger IT und Umwelttechnik.
            </p>
          </div>
          <div className={styles.processGrid}>
            {['Discover', 'Design', 'Develop', 'Deliver', 'Delight'].map((phase, index) => (
              <article key={phase} className={styles.processStep}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{phase}</h3>
                <p>
                  {index === 0 &&
                    'Gemeinsame Analyse der bestehenden Infrastruktur, ESG-Ziele und Stakeholder-Anforderungen.'}
                  {index === 1 &&
                    'Co-kreative Workshops zur Entwicklung maßgeschneiderter nachhaltiger IT-Lösungen.'}
                  {index === 2 &&
                    'Iterative Entwicklung mit Fokus auf Energie- und Ressourceneffizienz.'}
                  {index === 3 &&
                    'Rollout mit Impact-Monitoring, Schulungen und transparentem Reporting.'}
                  {index === 4 &&
                    'Kontinuierliche Optimierung, Benchmarks und Innovation Sprints für weitere Fortschritte.'}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="cases-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="cases-heading">Kundenerfolge</h2>
            <p>
              Unternehmen aus Energie, Industrie und öffentlicher Hand setzen auf unsere nachhaltigen IT-Lösungen.
              Hier einige Highlights.
            </p>
          </div>
          <div className={styles.caseGrid}>
            <article className={styles.caseCard}>
              <img
                src="https://picsum.photos/1200/800?random=44"
                alt="Smart City Dashboard mit Echtzeitdaten"
                loading="lazy"
              />
              <div className={styles.caseContent}>
                <h3>Smart City München</h3>
                <p>
                  Aufbau einer integrierten Datenplattform, die Verkehr, Energie und Umwelttechnik verbindet.
                  Ergebnis: 18% weniger Emissionen im urbanen Raum.
                </p>
                <Link to="/portfolio" className={styles.cardLink}>
                  Projekt ansehen
                </Link>
              </div>
            </article>
            <article className={styles.caseCard}>
              <img
                src="https://picsum.photos/1200/800?random=55"
                alt="Modernes nachhaltiges Rechenzentrum"
                loading="lazy"
              />
              <div className={styles.caseContent}>
                <h3>Green Data Center Rhein-Main</h3>
                <p>
                  Transformation eines Rechenzentrums mit KI-basiertem Energiemanagement, Abwärmenutzung und
                  Solarstromintegration.
                </p>
                <Link to="/portfolio" className={styles.cardLink}>
                  Mehr sehen
                </Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section
        ref={testimonialsRef}
        className={`${styles.section} ${styles.sectionAlternate} ${styles.fadeIn} ${testimonialsVisible ? styles.isVisible : ''}`}
        aria-labelledby="testimonials-heading"
      >
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="testimonials-heading">Stimmen unserer Kund:innen</h2>
          </div>
          <div className={styles.testimonialWrapper}>
            <div className={styles.testimonialSlider}>
              {testimonials.map((testimonial, index) => (
                <article
                  key={testimonial.name}
                  className={`${styles.testimonialCard} ${
                    activeTestimonial === index ? styles.testimonialActive : ''
                  }`}
                  aria-hidden={activeTestimonial !== index}
                >
                  <p className={styles.testimonialQuote}>&ldquo;{testimonial.quote}&rdquo;</p>
                  <div className={styles.testimonialAuthor}>
                    <strong>{testimonial.name}</strong>
                    <span>{testimonial.position}</span>
                  </div>
                </article>
              ))}
            </div>
            <div className={styles.testimonialDots} role="tablist" aria-label="Testimonials">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  role="tab"
                  aria-selected={activeTestimonial === index}
                  className={`${styles.dot} ${
                    activeTestimonial === index ? styles.dotActive : ''
                  }`}
                  onClick={() => setActiveTestimonial(index)}
                ></button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="partners-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="partners-heading">Partner & Zertifizierungen</h2>
            <p>
              Wir arbeiten mit führenden Initiativen und Verbänden zusammen, um nachhaltige IT-Lösungen
              europaweit zu etablieren.
            </p>
          </div>
          <div className={styles.partnerGrid}>
            {partners.map((partner) => (
              <div key={partner} className={styles.partnerCard}>
                {partner}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        ref={faqRef}
        className={`${styles.section} ${styles.sectionAlternate} ${styles.fadeIn} ${faqVisible ? styles.isVisible : ''}`}
        aria-labelledby="faq-heading"
      >
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="faq-heading">Häufige Fragen</h2>
            <p>Alles, was Sie über unsere nachhaltigen IT-Lösungen wissen sollten.</p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="blog-heading">
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2 id="blog-heading">Insights aus dem GreenTech Lab</h2>
            <p>Neuigkeiten, Best Practices und Trends zu grüner Technologie und digitaler Nachhaltigkeit.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPreviews.map((post) => (
              <article key={post.link} className={styles.blogCard}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.inlineLink}>
                  Beitrag lesen →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.sectionCta}`} aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2 id="cta-heading">Bereit für Ihre nachhaltige IT-Transformation?</h2>
              <p>
                Lassen Sie uns gemeinsam eine Roadmap erstellen, die ökologische Wirkung mit
                wirtschaftlichem Erfolg verbindet.
              </p>
            </div>
            <Link to="/contact" className={styles.heroButtonPrimary}>
              Beratungsgespräch vereinbaren
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;