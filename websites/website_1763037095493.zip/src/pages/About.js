import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';
import useInView from '../hooks/useInView';

const About = () => {
  const [valuesRef, valuesVisible] = useInView({ threshold: 0.3 });
  const [teamRef, teamVisible] = useInView({ threshold: 0.3 });

  const teamMembers = [
    {
      name: 'Dr. Jana Feldmann',
      role: 'Geschäftsführerin & Head of Sustainability',
      image: 'https://picsum.photos/400/400?random=101',
      bio: 'Verantwortet ESG-Strategien und begleitet internationale Transformationsprogramme.'
    },
    {
      name: 'Lukas Steiner',
      role: 'Director Green Software Engineering',
      image: 'https://picsum.photos/400/400?random=102',
      bio: 'Führt teams über die gesamte Software-Lifecycle hinweg mit Fokus auf digitale Nachhaltigkeit.'
    },
    {
      name: 'Miriam Koch',
      role: 'Lead Umwelttechnik & Smart Cities',
      image: 'https://picsum.photos/400/400?random=103',
      bio: 'Entwickelt intelligente Infrastrukturen für energieeffiziente Städte und Regionen.'
    },
    {
      name: 'Thiago Schuster',
      role: 'Head of Data & AI Impact',
      image: 'https://picsum.photos/400/400?random=104',
      bio: 'Spezialist für datengetriebene Nachhaltigkeit und KI-gestützte Optimierung.'
    }
  ];

  const milestones = [
    {
      year: '2012',
      title: 'Gründung in München',
      description: 'Start mit Fokus auf nachhaltige IT-Beratung und Energieeffizienz.'
    },
    {
      year: '2015',
      title: 'Green Data Lab',
      description: 'Aufbau eines eigenen Innovation Labs für grüne Technologie.'
    },
    {
      year: '2018',
      title: 'EU Green Deal Partnerschaft',
      description: 'Anerkennung als offizieller Partner für klimaneutrale Projekte.'
    },
    {
      year: '2022',
      title: 'Climate Neutral IT Award',
      description: 'Auszeichnung für wegweisende Projekte in Europa.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Über uns | GreenTech Innovations</title>
        <meta
          name="description"
          content="Lernen Sie GreenTech Innovations kennen: unser Team, unsere Werte und unser Engagement für nachhaltige IT-Lösungen, grüne Technologie und Umwelttechnik."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="about-heading">
        <div className="container">
          <div className={styles.heroContent}>
            <h1 id="about-heading">Wir gestalten digitale Nachhaltigkeit</h1>
            <p>
              Seit über einem Jahrzehnt begleitet GreenTech Innovations Organisationen in Deutschland
              und Europa auf dem Weg zu klimafreundlicher IT und resilienten Technologien.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="values-heading">
        <div className="container">
          <div ref={valuesRef} className={`${styles.valuesGrid} ${valuesVisible ? styles.visible : ''}`}>
            <article className={styles.valueCard}>
              <h2 id="values-heading">Unsere Werte</h2>
              <p>
                Integrität, Co-Creation und messbarer Impact bilden das Fundament unserer Arbeit.
                Wir glauben daran, dass nachhaltige IT-Lösungen nur in enger Partnerschaft mit unseren
                Kund:innen langfristig wirken.
              </p>
            </article>
            <article className={styles.valueCard}>
              <h3>Impact</h3>
              <p>
                Wir messen jeden Fortschritt anhand klarer KPIs – von eingesparter Energie bis zu CO₂-Äquivalenten.
              </p>
            </article>
            <article className={styles.valueCard}>
              <h3>Innovation</h3>
              <p>
                Unsere Teams forschen in Kooperation mit Hochschulen und Labs an grüner Technologie der Zukunft.
              </p>
            </article>
            <article className={styles.valueCard}>
              <h3>Menschlichkeit</h3>
              <p>
                Wir setzen auf Diversität, transparente Kommunikation und lebensfreundliche Arbeitsmodelle.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="timeline-heading">
        <div className="container">
          <h2 id="timeline-heading" className={styles.sectionTitle}>Meilensteine</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <article key={milestone.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{milestone.year}</span>
                <div>
                  <h3>{milestone.title}</h3>
                  <p>{milestone.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="team-heading">
        <div className="container">
          <div ref={teamRef} className={`${styles.teamSection} ${teamVisible ? styles.visible : ''}`}>
            <h2 id="team-heading" className={styles.sectionTitle}>Unser Führungsteam</h2>
            <div className={styles.teamGrid}>
              {teamMembers.map((member) => (
                <article key={member.name} className={styles.teamCard}>
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                  <div className={styles.teamInfo}>
                    <h3>{member.name}</h3>
                    <span>{member.role}</span>
                    <p>{member.bio}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="responsibility-heading">
        <div className="container">
          <h2 id="responsibility-heading" className={styles.sectionTitle}>Verantwortung leben</h2>
          <div className={styles.responsibilityGrid}>
            <div>
              <h3>Soziale Verantwortung</h3>
              <p>
                Wir fördern Bildungspartnerschaften, unterstützen Nachwuchstalente und investieren pro
                Mitarbeiter:in jährlich 40 Stunden in Weiterbildung zu Nachhaltigkeit.
              </p>
            </div>
            <div>
              <h3>Ökologische Wirkung</h3>
              <p>
                Unser Münchner Büro ist seit 2019 klimaneutral. Wir kompensieren Restemissionen über
                zertifizierte Projekte und setzen auf zirkuläre Hardware-Konzepte.
              </p>
            </div>
            <div>
              <h3>Governance</h3>
              <p>
                Transparente ESG-Standards, regelmäßige Audits und ein unabhängiger Sustainability Board
                sichern Compliance und Glaubwürdigkeit.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;