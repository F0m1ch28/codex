import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('gt-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('gt-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <aside
      className={styles.banner}
      role="dialog"
      aria-live="polite"
      aria-label="Cookie Hinweis"
    >
      <div className={styles.content}>
        <h2>Wir respektieren Ihre Privatsphäre</h2>
        <p>
          Wir verwenden Cookies, um unsere nachhaltigen IT-Lösungen zu optimieren und die digitale
          Nachhaltigkeit unserer Plattform zu verbessern. Mit einem Klick auf „Akzeptieren“ stimmen
          Sie der Nutzung zu. Mehr Informationen finden Sie in unserer{' '}
          <Link to="/cookie-policy">Cookie-Richtlinie</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={handleAccept}>
          Akzeptieren
        </button>
        <Link to="/privacy" className={styles.secondaryButton}>
          Mehr erfahren
        </Link>
      </div>
    </aside>
  );
};

export default CookieBanner;