import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [menuOpen]);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header
      className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`}
    >
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.logoWrapper}>
            <NavLink to="/" className={styles.logo} aria-label="GreenTech Innovations Startseite">
              <span className={styles.logoAccent}>Green</span>Tech Innovations
            </NavLink>
            <p className={styles.tagline}>Digitale Nachhaltigkeit aus München</p>
          </div>

          <button
            className={styles.menuToggle}
            aria-expanded={menuOpen}
            aria-controls="hauptnavigation"
            aria-label="Menü öffnen"
            onClick={toggleMenu}
          >
            <span className={styles.menuLine}></span>
            <span className={styles.menuLine}></span>
            <span className={styles.menuLine}></span>
          </button>

          <nav
            id="hauptnavigation"
            className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
            aria-label="Hauptnavigation"
          >
            <NavLink
              onClick={closeMenu}
              to="/"
              end
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.activeLink : ''}`
              }
            >
              Start
            </NavLink>
            <NavLink
              onClick={closeMenu}
              to="/about"
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.activeLink : ''}`
              }
            >
              Über uns
            </NavLink>
            <NavLink
              onClick={closeMenu}
              to="/services"
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.activeLink : ''}`
              }
            >
              Leistungen
            </NavLink>
            <NavLink
              onClick={closeMenu}
              to="/portfolio"
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.activeLink : ''}`
              }
            >
              Portfolio
            </NavLink>
            <NavLink
              onClick={closeMenu}
              to="/blog"
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.activeLink : ''}`
              }
            >
              Blog
            </NavLink>
            <NavLink
              onClick={closeMenu}
              to="/careers"
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.activeLink : ''}`
              }
            >
              Karriere
            </NavLink>
            <NavLink
              onClick={closeMenu}
              to="/contact"
              className={({ isActive }) =>
                `${styles.ctaLink} ${styles.navLink} ${isActive ? styles.activeLink : ''}`
              }
            >
              Kontakt aufnehmen
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;