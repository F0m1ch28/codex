import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brandColumn}>
            <h2 id="footer-heading" className={styles.footerTitle}>
              GreenTech Innovations
            </h2>
            <p className={styles.footerText}>
              Wir entwickeln nachhaltige IT-Lösungen, die grüne Technologie,
              Umwelttechnik und digitale Nachhaltigkeit intelligent verbinden.
            </p>
            <div className={styles.addressBlock}>
              <strong className={styles.addressTitle}>Headquarters</strong>
              <p>
                GreenTech Innovations GmbH<br />
                Ludwigstraße 123<br />
                80539 München, Deutschland
              </p>
            </div>
          </div>

          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Navigation</h3>
            <ul className={styles.linkList}>
              <li><Link to="/about">Über uns</Link></li>
              <li><Link to="/services">Leistungen</Link></li>
              <li><Link to="/portfolio">Portfolio</Link></li>
              <li><Link to="/blog">Blog</Link></li>
              <li><Link to="/careers">Karriere</Link></li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Rechtliches</h3>
            <ul className={styles.linkList}>
              <li><Link to="/terms">Terms of Service</Link></li>
              <li><Link to="/privacy">Datenschutzerklärung</Link></li>
              <li><Link to="/cookie-policy">Cookie-Richtlinie</Link></li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Kontakt</h3>
            <ul className={styles.contactList}>
              <li>
                <a href="tel:+498912345678">+49 89 12345678</a>
              </li>
              <li>
                <a href="mailto:info@greentech-innovations.de">
                  info@greentech-innovations.de
                </a>
              </li>
            </ul>
            <form className={styles.newsletter} aria-label="Newsletter Anmeldung">
              <label htmlFor="newsletter-email" className="sr-only">
                E-Mail Adresse
              </label>
              <input
                id="newsletter-email"
                type="email"
                placeholder="E-Mail eingeben"
                aria-required="true"
              />
              <button type="submit">Abonnieren</button>
            </form>
            <p className={styles.newsletterInfo}>
              Erhalten Sie Insights zu Umwelttechnik, digitale Nachhaltigkeit und grüner Technologie.
            </p>
          </div>
        </div>

        <div className={styles.bottomBar}>
          <p>© {currentYear} GreenTech Innovations GmbH. Alle Rechte vorbehalten.</p>
          <div className={styles.badges}>
            <span className={styles.badge}>ISO 14001</span>
            <span className={styles.badge}>EU Green Deal Partner</span>
            <span className={styles.badge}>Climate Neutral IT 2024</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;