document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navList = document.querySelector(".nav-list");
  const navLinks = document.querySelectorAll(".nav-link");

  if (navToggle && navList) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      navList.classList.toggle("is-open");
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute("aria-expanded", "false");
          navList.classList.remove("is-open");
        }
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector('[data-cookie-action="accept"]');
  const declineBtn = document.querySelector('[data-cookie-action="decline"]');
  const cookieChoice = localStorage.getItem("qazlearn-cookie-choice");

  if (cookieBanner && !cookieChoice) {
    setTimeout(() => {
      cookieBanner.classList.add("is-visible");
    }, 600);
  }

  const handleCookieChoice = (value) => {
    localStorage.setItem("qazlearn-cookie-choice", value);
    cookieBanner?.classList.remove("is-visible");
  };

  acceptBtn?.addEventListener("click", () => handleCookieChoice("accepted"));
  declineBtn?.addEventListener("click", () => handleCookieChoice("declined"));

  const yearElements = document.querySelectorAll(".js-current-year");
  const currentYear = new Date().getFullYear();
  yearElements.forEach((el) => {
    el.textContent = currentYear;
  });
});