import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AnalysesPage.module.css';

const analysesData = [
  {
    id: 1,
    theme: 'Écoles publiques',
    title: 'Convergence des projets éducatifs locaux dans les arrondissements de l’est parisien',
    date: '31 août 2023',
    words: 2850,
    synopsis:
      'Étude comparative des projets éducatifs territoriaux dans les 10e, 11e et 20e arrondissements, avec une attention portée aux priorités de continuité pédagogique et de coopération périscolaire.',
  },
  {
    id: 2,
    theme: 'Enseignement supérieur',
    title: 'Accompagnement des primo-entrants à l’Université Paris Cité',
    date: '22 août 2023',
    words: 2310,
    synopsis:
      'Analyse des dispositifs de tutorat et de mentorat proposés aux étudiants entrant en licence, appuyée sur des données de réussite académique et des enquêtes auprès des services universitaires.',
  },
  {
    id: 3,
    theme: 'Histoire',
    title: 'Évolution des internats scolaires parisiens depuis 1945',
    date: '14 août 2023',
    words: 3125,
    synopsis:
      'Retour historique sur les internats publics et privés parisiens, mettant en lumière les transformations architecturales, pédagogiques et sociales de ces structures.',
  },
  {
    id: 4,
    theme: 'Écoles publiques',
    title: 'Pilotage de la réussite éducative dans les quartiers en renouvellement urbain',
    date: '2 août 2023',
    words: 2560,
    synopsis:
      'Présentation des collaborations entre rectorat, mairies d’arrondissement et associations pour suivre les parcours des élèves dans les quartiers concernés par des opérations de rénovation.',
  },
  {
    id: 5,
    theme: 'Histoire',
    title: 'Les lycées professionnels parisiens et la formation aux métiers d’art',
    date: '20 juillet 2023',
    words: 1980,
    synopsis:
      'Panorama des filières artisanales et artistiques proposées dans les lycées professionnels, avec un éclairage sur les partenariats institutionnels et culturels.',
  },
  {
    id: 6,
    theme: 'Enseignement supérieur',
    title: 'Mobilité internationale et réussite académique des étudiantes parisiennes',
    date: '5 juillet 2023',
    words: 2740,
    synopsis:
      'Exploration des parcours de mobilité internationale, en mettant l’accent sur les dispositifs de soutien linguistique et financier proposés par les établissements parisiens.',
  },
];

const filters = ['Toutes', 'Écoles publiques', 'Enseignement supérieur', 'Histoire'];

const AnalysesPage = () => {
  const [activeFilter, setActiveFilter] = useState('Toutes');

  const filteredAnalyses = useMemo(() => {
    if (activeFilter === 'Toutes') {
      return analysesData;
    }
    return analysesData.filter((analysis) => analysis.theme === activeFilter);
  }, [activeFilter]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Analyses et Articles | Education in Paris Review</title>
        <meta
          name="description"
          content="Accès aux analyses détaillées d’Education in Paris Review sur les écoles publiques, l’enseignement supérieur et l’histoire éducative parisienne."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>Analyses et articles</h1>
          <p>
            Les analyses regroupent des études de cas, des synthèses statistiques et des enquêtes documentaires permettant de mieux comprendre les dynamiques éducatives parisiennes.
          </p>
        </header>

        <div className={styles.filters} role="tablist" aria-label="Filtrer les analyses par thème">
          {filters.map((filter) => (
            <button
              type="button"
              key={filter}
              role="tab"
              aria-selected={activeFilter === filter}
              className={`${styles.filterButton} ${activeFilter === filter ? styles.active : ''}`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className={styles.list}>
          {filteredAnalyses.map((analysis) => (
            <article key={analysis.id} className={styles.card}>
              <div className={styles.cardHeader}>
                <span className="tag">{analysis.theme}</span>
                <time>{analysis.date}</time>
              </div>
              <h2>{analysis.title}</h2>
              <p className={styles.synopsis}>{analysis.synopsis}</p>
              <div className={styles.meta}>
                <span>{analysis.words.toLocaleString('fr-FR')} mots</span>
                <span>Disponible dans la rubrique Analyses</span>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default AnalysesPage;