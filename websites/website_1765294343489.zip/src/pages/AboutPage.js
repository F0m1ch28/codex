import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>À Propos | Education in Paris Review</title>
        <meta
          name="description"
          content="Education in Paris Review adopte une méthodologie indépendante et rigoureuse pour analyser les mutations éducatives parisiennes."
        />
      </Helmet>

      <section className="container">
        <header className={styles.header}>
          <h1>À propos de l&rsquo;Education in Paris Review</h1>
          <p>
            Education in Paris Review est un média d’analyse dédié à l’étude du système éducatif parisien. La rédaction privilégie une approche
            documentaire rigoureuse fondée sur la vérification des sources, la contextualisation historique et l’observation des pratiques professionnelles.
          </p>
        </header>

        <div className={styles.grid}>
          <article className={styles.card}>
            <h2>Mission éditoriale</h2>
            <p>
              La mission consiste à fournir un éclairage neutre et argumenté sur les politiques éducatives et les initiatives locales. Chaque publication
              vise à rendre intelligibles les évolutions du paysage scolaire, du premier degré à l’enseignement supérieur, en tenant compte des spécificités parisiennes.
            </p>
          </article>

          <article className={styles.card}>
            <h2>Méthodologie</h2>
            <p>
              Les enquêtes combinent analyses statistiques, revues de littérature et entretiens qualitatifs. L’équipe s’assure de croiser les informations
              avec des documents publics, des travaux universitaires et des retours d’acteurs de terrain afin de garantir la robustesse des conclusions.
            </p>
          </article>

          <article className={styles.card}>
            <h2>Collaboration éditoriale</h2>
            <p>
              Un comité éditorial pluridisciplinaire, composé de spécialistes de l’éducation, de sociologues et de journalistes, supervise la qualité des contenus.
              Les contributions externes sont examinées selon des critères méthodologiques précis, garantissant un haut niveau de fiabilité.
            </p>
          </article>
        </div>

        <section className={styles.values}>
          <h2>Principes directeurs</h2>
          <div className={styles.valuesGrid}>
            <div>
              <h3>Neutralité</h3>
              <p>
                La rédaction veille à présenter les faits et les analyses sans biais partisan, en s’appuyant sur des données vérifiables et des méthodes transparentes.
              </p>
            </div>
            <div>
              <h3>Exigence scientifique</h3>
              <p>
                Chaque article mentionne ses sources, précise ses limites méthodologiques et propose des pistes de prolongement pour les chercheurs et praticiens.
              </p>
            </div>
            <div>
              <h3>Ouverture institutionnelle</h3>
              <p>
                Le média encourage les échanges avec les établissements, les collectivités, les associations et les laboratoires de recherche, afin de restituer la diversité des points de vue.
              </p>
            </div>
          </div>
        </section>
      </section>
    </div>
  );
};

export default AboutPage;