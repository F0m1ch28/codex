(function () {
    function setCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }

    function getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(";");
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === " ") c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function ready(fn) {
        if (document.readyState !== "loading") {
            fn();
        } else {
            document.addEventListener("DOMContentLoaded", fn);
        }
    }

    ready(function () {
        var banner = document.getElementById("cookieBanner");
        if (!banner) return;

        var acceptBtn = banner.querySelector("[data-cookie-accept]");
        var declineBtn = banner.querySelector("[data-cookie-decline]");

        if (getCookie("ndebelwjfo_consent") === "accepted") {
            banner.classList.add("hide");
            return;
        }

        acceptBtn.addEventListener("click", function () {
            setCookie("ndebelwjfo_consent", "accepted", 180);
            banner.classList.add("hide");
        });

        declineBtn.addEventListener("click", function () {
            banner.classList.add("hide");
        });
    });
})();