import React from 'react';
import { Routes, Route } from 'react-router-dom';
import styles from './App.module.css';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import ScrollToTopOnRoute from './components/ScrollToTopOnRoute';

import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import PortfolioPage from './pages/PortfolioPage';
import ProcessPage from './pages/ProcessPage';
import ContactsPage from './pages/ContactsPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';

const App = () => (
  <div className={styles.app}>
    <ScrollToTopOnRoute />
    <Header />
    <main id="main-content" className={styles.main}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/uslugi" element={<ServicesPage />} />
        <Route path="/portfolio" element={<PortfolioPage />} />
        <Route path="/process" element={<ProcessPage />} />
        <Route path="/kontakty" element={<ContactsPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/cookie-policy" element={<CookiePolicyPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

export default App;
