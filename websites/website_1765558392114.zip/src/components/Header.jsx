import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { to: '/', label: 'Главная' },
  { to: '/uslugi', label: 'Услуги' },
  { to: '/portfolio', label: 'Портфолио' },
  { to: '/process', label: 'Процесс' },
  { to: '/kontakty', label: 'Контакты' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  useEffect(() => {
    closeMenu();
  }, [location.pathname]);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="На главную">
          🎨 <span>Сколько вариантов сайта создать?</span>
        </Link>

        <button
          type="button"
          className={styles.menuToggle}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
        >
          <span className={styles.menuIcon} />
          <span className="visually-hidden">Открыть меню</span>
        </button>

        <nav
          id="primary-navigation"
          className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    "${styles.navLink} ${isActive ? styles.navLinkActive : ''}"
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/kontakty" className={styles.ctaButton}>
            Обсудить проект
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;
