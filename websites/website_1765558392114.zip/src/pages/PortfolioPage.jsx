import React from 'react';
import { Helmet } from 'react-helmet-async';
import layoutStyles from '../styles/Layout.module.css';
import styles from './PortfolioPage.module.css';

const projects = [
  {
    title: 'Агентство элитной недвижимости «Altitude»',
    description: 'Редизайн сайта агентства с интеграцией CRM, интерактивной картой объектов и калькулятором ипотечных программ.',
    result: 'Рост заявок с сайта на 38% в первые три месяца после релиза.',
    image: 'https://images.unsplash.com/photo-1529429617124-aee711a6f812?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Платформа онлайн-обучения «SkillEra»',
    description: 'Создание образовательной платформы с личными кабинетами, прогревом курсов и системой геймификации.',
    result: 'Среднее время на сайте выросло до 14 минут, увеличилась конверсия в покупку.',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Бренд косметики «Nordic Glow»',
    description: 'E-commerce с AR-примеркой, кастомным конструктором наборов и CRM-интеграцией для email-кампаний.',
    result: 'Выручка за счет онлайн-канала удвоилась за полгода.',
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Медиа о городской культуре «Pulse City»',
    description: 'Редакционная платформа, гибкий конструктор спецпроектов и мобильное приложение на базе PWA.',
    result: 'Среднее число просмотренных материалов увеличилось в 2,3 раза.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Финтех-стартап «ClearFin»',
    description: 'Лендинг с инфографикой, интерактивными калькуляторами и закрытой зоной для инвесторов.',
    result: 'Успешный раунд инвестиций и рост базы лидов на 54%.',
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=900&q=80'
  },
  {
    title: 'Международный форум «FutureWork»',
    description: 'Сайт мероприятия с онлайн-программой, стримингом, кабинетами спикеров и сеткой виртуального нетворкинга.',
    result: 'На платформе зарегистрировалось более 18 тысяч участников по всему миру.',
    image: 'https://images.unsplash.com/photo-1516245834210-c4c142787335?auto=format&fit=crop&w=900&q=80'
  }
];

const PortfolioPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Портфолио — 🎨 Сколько вариантов сайта создать?</title>
      <meta
        name="description"
        content="Посмотрите реализованные проекты агентства «🎨 Сколько вариантов сайта создать?». Digital-решения для девелоперов, e-commerce, медиа, образования и стартапов."
      />
      <meta
        name="keywords"
        content="портфолио, веб-дизайн, разработка сайтов, кейсы, проекты"
      />
    </Helmet>

    <section className={"${layoutStyles.sectionPadding} ${styles.hero}"}>
      <div className={layoutStyles.container}>
        <h1>Наши проекты</h1>
        <p>
          Мы создаем продукты, которые работают на задачи бренда и удобны людям.
          Каждый кейс — это совместная работа с клиентом, глубокое погружение и ответ на конкретный вызов.
        </p>
      </div>
    </section>

    <section className={layoutStyles.sectionPadding}>
      <div className={layoutStyles.container}>
        <div className={styles.grid}>
          {projects.map((project) => (
            <article key={project.title} className={styles.card}>
              <img src={project.image} alt={"Кейс: ${project.title}"} loading="lazy" />
              <div className={styles.content}>
                <h2>{project.title}</h2>
                <p>{project.description}</p>
                <div className={styles.result}>
                  <span>Результат</span>
                  <p>{project.result}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default PortfolioPage;
