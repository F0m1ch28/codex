import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import layoutStyles from '../styles/Layout.module.css';
import styles from './ContactsPage.module.css';

const initialFormState = {
  name: '',
  company: '',
  email: '',
  message: ''
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((state) => ({ ...state, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты — 🎨 Сколько вариантов сайта создать?</title>
        <meta
          name="description"
          content="Свяжитесь с агентством «🎨 Сколько вариантов сайта создать?». Адрес: г. Москва, ул. Тверская, д. 10, офис 45. Телефон: +7 (495) 123-45-67. Email: info@skolko-variantov.ru."
        />
        <meta
          name="keywords"
          content="контакты веб-студия, заказать сайт Москва, креативное агентство контакты"
        />
      </Helmet>

      <section className={"${layoutStyles.sectionPadding} ${styles.hero}"}>
        <div className={layoutStyles.container}>
          <h1>Обсудим ваш проект</h1>
          <p>
            Расскажите о задаче, и мы подготовим предложение с конкретными сроками и подходящим стеком.
            Можно написать на почту, позвонить или оставить заявку в форме — мы ответим в течение одного рабочего дня.
          </p>
        </div>
      </section>

      <section className={layoutStyles.sectionPadding}>
        <div className={layoutStyles.container}>
          <div className={styles.grid}>
            <div className={styles.contactBlock}>
              <h2>Контакты</h2>
              <ul>
                <li>
                  <span>Адрес</span>
                  г. Москва, ул. Тверская, д. 10, офис 45
                </li>
                <li>
                  <span>Телефон</span>
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <span>Email</span>
                  <a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a>
                </li>
              </ul>
              <div className={styles.note}>
                <strong>Рабочие часы:</strong>
                <p>Понедельник — пятница, с 10:00 до 19:00 по московскому времени.</p>
              </div>
            </div>

            <form className={styles.form} onSubmit={handleSubmit} aria-label="Форма обратной связи">
              <h2>Расскажите о задаче</h2>
              <div className={styles.field}>
                <label htmlFor="name">Имя</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  placeholder="Как к вам обращаться?"
                  value={formData.name}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="company">Компания</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  placeholder="Название компании или проекта"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  placeholder="Ваш рабочий email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Описание проекта</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  required
                  placeholder="Что нужно сделать? Какие цели стоят?"
                  value={formData.message}
                  onChange={handleChange}
                />
              </div>
              <button type="submit" className={styles.submitButton}>
                Отправить заявку
              </button>
              {submitted && (
                <div className={styles.success} role="status">
                  Спасибо за обращение! Мы свяжемся с вами в ближайшее время.
                </div>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;
