document.addEventListener("DOMContentLoaded", function () {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const consent = localStorage.getItem("taeed-cookie-consent");

  if (consent) {
    banner.classList.add("is-hidden");
    return;
  }

  requestAnimationFrame(() => {
    banner.classList.add("is-visible");
  });

  acceptBtn.addEventListener("click", function () {
    localStorage.setItem("taeed-cookie-consent", "accepted");
    banner.classList.remove("is-visible");
    banner.classList.add("is-hidden");
  });

  declineBtn.addEventListener("click", function () {
    localStorage.setItem("taeed-cookie-consent", "declined");
    banner.classList.remove("is-visible");
    banner.classList.add("is-hidden");
  });
});