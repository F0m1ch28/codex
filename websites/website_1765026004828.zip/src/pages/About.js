import React from "react";

const leadership = [
  {
    name: "Jared Montoya",
    role: "Founder & Managing Partner",
    image: "https://picsum.photos/400/400?random=13",
    bio: "Strategy leader with 18+ years guiding Fortune 500 executives through complex digital transformations."
  },
  {
    name: "Priya Raman",
    role: "Head of Experience Design",
    image: "https://picsum.photos/400/400?random=14",
    bio: "Drives CX innovation blending service design, research, and behavioral science methodologies."
  },
  {
    name: "Noah Blake",
    role: "Chief Technology Officer",
    image: "https://picsum.photos/400/400?random=15",
    bio: "Architects resilient platforms, data foundations, and product ecosystems optimized for velocity."
  }
];

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container page-hero-grid">
          <div>
            <span className="eyebrow">About Prime Edge</span>
            <h1>We exist to orchestrate meaningful digital change.</h1>
            <p>
              Prime Edge Consulting was founded by a team of strategists, designers, and technologists who believe
              progress happens when clarity meets execution. We partner deeply with clients to uncover opportunities,
              architect the path forward, and deliver measurable outcomes that endure.
            </p>
          </div>
          <div className="page-hero-stats">
            <div>
              <span className="stat-value">92%</span>
              <span className="stat-label">Repeat engagement rate</span>
            </div>
            <div>
              <span className="stat-value">200+</span>
              <span className="stat-label">Leaders upskilled through our programs</span>
            </div>
            <div>
              <span className="stat-value">32</span>
              <span className="stat-label">Awards for experience and product design</span>
            </div>
          </div>
        </div>
      </section>

      <section className="container about-narrative">
        <h2>Our story</h2>
        <p>
          Enterprises today must navigate evolving customer expectations, rapid technology shifts, and complex operating
          models. We founded Prime Edge to be the partner that makes this journey achievable. Our teams bring a blend of
          foresight, pragmatism, and craftsmanship to every engagement. We co-create with clients, build internal
          capabilities, and align every initiative to measurable business value.
        </p>
        <p>
          With hubs in San Francisco, London, and Singapore, we assemble multidisciplinary teams that balance global
          expertise with local market nuance. We are independent, founder-led, and relentlessly focused on elevating both
          the customer and employee experience.
        </p>
      </section>

      <section className="team-section container">
        <div className="section-header">
          <span className="eyebrow">Leadership</span>
          <h2>Meet the team guiding our clients toward the future.</h2>
        </div>
        <div className="team-grid">
          {leadership.map((member) => (
            <article className="team-card" key={member.name}>
              <div className="team-image">
                <img src={`${member.image}&cache=${member.name}`} alt={`${member.name} portrait`} loading="lazy" />
              </div>
              <div className="team-details">
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="values-section">
        <div className="container values-grid">
          <div>
            <span className="eyebrow">Our Values</span>
            <h2>Principles that shape how we partner and deliver.</h2>
          </div>
          <div className="values-list">
            <div>
              <h3>Impact over outputs</h3>
              <p>Every deliverable anchors to clear value metrics, adoption measures, and business outcomes.</p>
            </div>
            <div>
              <h3>Design for people</h3>
              <p>We empathize with customers, employees, and partners to ensure solutions resonate and endure.</p>
            </div>
            <div>
              <h3>Transparency builds trust</h3>
              <p>Open communication, shared dashboards, and collaborative rituals keep stakeholders aligned.</p>
            </div>
            <div>
              <h3>Be future-ready</h3>
              <p>We constantly explore new technologies, frameworks, and models to deliver resilient solutions.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;