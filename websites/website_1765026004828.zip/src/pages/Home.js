import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

const statsData = [
  { label: "Digital programs launched", value: 120 },
  { label: "Revenue uplift delivered", value: 65, suffix: "%" },
  { label: "Client satisfaction score", value: 4.9, suffix: "/5" },
  { label: "Countries served", value: 18 }
];

const services = [
  {
    title: "Digital Strategy & Roadmapping",
    description: "Clarity on the initiatives, investments, and milestones that unlock your next wave of growth.",
    icon: "🧭"
  },
  {
    title: "Customer Experience Design",
    description: "Human-centered journeys, product UX, and service blueprints that delight customers.",
    icon: "🎨"
  },
  {
    title: "Data & AI Enablement",
    description: "Modern data foundations, predictive intelligence, and automation aligned to strategic outcomes.",
    icon: "🧠"
  },
  {
    title: "Product Acceleration",
    description: "Cross-functional pods that deliver enterprise-grade software with startup velocity.",
    icon: "🚀"
  }
];

const processSteps = [
  {
    title: "Discover",
    description: "Immersive research, stakeholder interviews, and analytics uncover true opportunities."
  },
  {
    title: "Design",
    description: "Co-creative sprints translate insights into differentiated strategies and experiences."
  },
  {
    title: "Build",
    description: "Agile delivery teams engineer scalable solutions with robust governance."
  },
  {
    title: "Optimize",
    description: "Evidence-based iteration drives adoption, business value, and continuous improvement."
  }
];

const testimonials = [
  {
    quote:
      "Prime Edge transformed our digital channel mix, delivering a 47% increase in qualified pipeline within three months.",
    name: "Elena Williams",
    role: "CMO, Horizon Biotech"
  },
  {
    quote:
      "Their product acceleration squad shipped a complex platform in record time while maintaining enterprise-grade quality.",
    name: "Marcus Grant",
    role: "CTO, FinEdge Capital"
  },
  {
    quote:
      "From discovery to execution, the team challenged assumptions and aligned our leadership around a bold roadmap.",
    name: "Sofia Liang",
    role: "Chief Strategy Officer, UrbanFrame"
  }
];

const projectCategories = ["All", "Strategy", "Product", "Experience", "Data"];

const projects = [
  {
    id: 1,
    title: "Global eCommerce Cloud Migration",
    category: "Product",
    image: "https://picsum.photos/1200/800?random=4",
    description: "Scaled platform supporting 14 markets with localized experiences and unified analytics."
  },
  {
    id: 2,
    title: "Omni-Channel Banking Blueprint",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=5",
    description: "Thirty-month roadmap with prioritized initiatives that modernized core banking journeys."
  },
  {
    id: 3,
    title: "AI-Powered Claims Automation",
    category: "Data",
    image: "https://picsum.photos/1200/800?random=6",
    description: "Computer vision and NLP models reducing claims handling time by 61%."
  },
  {
    id: 4,
    title: "Experience-led Retail Concept",
    category: "Experience",
    image: "https://picsum.photos/1200/800?random=7",
    description: "Immersive store flow, digital concierge, and loyalty platform boosting repeat visits."
  }
];

const faqs = [
  {
    question: "How do you engage with new clients?",
    answer:
      "We begin with a collaborative discovery to align on goals, stakeholders, and baseline metrics, followed by a prioritized engagement roadmap."
  },
  {
    question: "What industries do you specialize in?",
    answer:
      "Our teams have deep experience across financial services, healthcare, retail, technology, and industrial sectors."
  },
  {
    question: "Do you provide post-launch support?",
    answer:
      "Yes. We offer managed services, capability upskilling, and continuous optimization programs tailored to your needs."
  },
  {
    question: "Can you work with existing internal teams?",
    answer:
      "Absolutely. We integrate seamlessly with internal teams, providing co-creation models and governance frameworks that accelerate delivery."
  }
];

const blogPosts = [
  {
    id: 1,
    title: "Designing Data-Driven Customer Journeys in 2024",
    excerpt: "Unlock personalization at scale with signal-based segmentation and orchestrated omnichannel experiences.",
    image: "https://picsum.photos/800/600?random=8",
    date: "March 28, 2024"
  },
  {
    id: 2,
    title: "The Executive Guide to Responsible AI Adoption",
    excerpt: "Frameworks and safeguards to operationalize AI with transparency and long-term trust.",
    image: "https://picsum.photos/800/600?random=9",
    date: "March 11, 2024"
  },
  {
    id: 3,
    title: "Why Product Velocity Requires Modern Platforms",
    excerpt: "Assessing tech debt, platform resilience, and modular architectures for sustainable speed.",
    image: "https://picsum.photos/800/600?random=10",
    date: "February 24, 2024"
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState("All");
  const [faqOpen, setFaqOpen] = useState(null);
  const [counters, setCounters] = useState(statsData.map(() => 0));

  const filteredProjects = useMemo(() => {
    if (activeCategory === "All") return projects;
    return projects.filter((project) => project.category === activeCategory);
  }, [activeCategory]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const animationDuration = 1500;
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / animationDuration, 1);
      setCounters(
        statsData.map((stat) => {
          const finalValue = stat.value;
          return parseFloat((finalValue * progress).toFixed(stat.suffix === "/5" ? 1 : 0));
        })
      );
      if (progress < 1) requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  }, []);

  return (
    <>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="eyebrow">Digital Transformation Partners</span>
            <h1>
              Accelerate outcomes with <span className="highlight">precision strategy</span> and human-centered
              innovation.
            </h1>
            <p>
              We help ambitious teams envision the future, orchestrate complex change, and build digital products that
              customers love. From roadmap to launch, we partner to deliver measurable value.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn primary">
                Schedule a Consultation
              </Link>
              <a href="#services" className="btn secondary">
                Explore Services
              </a>
            </div>
            <div className="hero-meta">
              <span>Trusted by global enterprises</span>
              <span>ISO 27001 certified</span>
              <span>Average ROI 5.2x</span>
            </div>
          </div>
          <div className="hero-image">
            <img src="https://picsum.photos/1600/900?random=11" alt="Digital consulting team strategizing with data dashboards" loading="lazy" />
          </div>
        </div>
      </section>

      <section className="stats">
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <span className="stat-value">
                {counters[index]}
                {stat.suffix || ""}
              </span>
              <span className="stat-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section id="services" className="services">
        <div className="container section-header">
          <span className="eyebrow">Our Expertise</span>
          <h2>Services designed to move you from insight to impact.</h2>
          <p>
            We blend strategy, design, data, and engineering disciplines to deliver differentiated digital experiences
            at enterprise scale.
          </p>
        </div>
        <div className="container services-grid">
          {services.map((service) => (
            <article className="service-card" key={service.title}>
              <div className="service-icon">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-link">
                Learn more →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section id="process" className="process">
        <div className="container">
          <div className="section-header">
            <span className="eyebrow">How We Work</span>
            <h2>Our method combines rigor, creativity, and momentum.</h2>
            <p>
              A proven framework that keeps stakeholders aligned, decisions transparent, and delivery accountable at
              every stage.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title}>
                <div className="process-number">{String(index + 1).padStart(2, "0")}</div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container testimonials-wrapper">
          <div className="section-header">
            <span className="eyebrow">Client Voices</span>
            <h2>Leaders choose Prime Edge to deliver change that sticks.</h2>
          </div>
          <div className="testimonial-carousel">
            {testimonials.map((testimonial, index) => (
              <blockquote
                key={testimonial.name}
                className={`testimonial-card ${index === activeTestimonial ? "active" : ""}`}
                aria-hidden={index !== activeTestimonial}
              >
                <p>“{testimonial.quote}”</p>
                <cite>
                  <span>{testimonial.name}</span>
                  <span>{testimonial.role}</span>
                </cite>
              </blockquote>
            ))}
            <div className="carousel-controls">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveTestimonial(index)}
                  className={index === activeTestimonial ? "active" : ""}
                  aria-label={`Show testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="projects">
        <div className="container">
          <div className="section-header">
            <span className="eyebrow">Selected Work</span>
            <h2>Outcomes that redefine what’s possible.</h2>
            <p>
              Explore a sample of programs where we partnered with leaders to architect, build, and scale transformative
              digital capabilities.
            </p>
          </div>
          <div className="projects-filters">
            {projectCategories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={category === activeCategory ? "active" : ""}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.id}>
                <div className="project-image">
                  <img src={`${project.image}&unique=${project.id}`} alt={`${project.title} case study visual`} loading="lazy" />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <a href="#contact" className="project-link">
                    Read case study →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="insight">
        <div className="container insight-grid">
          <div className="insight-media">
            <img src="https://picsum.photos/800/600?random=12" alt="Consultants collaborating around data dashboards" loading="lazy" />
          </div>
          <div className="insight-content">
            <span className="eyebrow">Why Prime Edge</span>
            <h2>Cross-disciplinary teams built for velocity and measurable value.</h2>
            <ul>
              <li>Embedded strategists, designers, data scientists, and engineers.</li>
              <li>Modern delivery practices with transparent governance and reporting.</li>
              <li>Partner ecosystem spanning cloud, data, and emerging technology leaders.</li>
              <li>Capability uplift programs that empower internal teams to sustain momentum.</li>
            </ul>
            <Link to="/about" className="btn secondary">
              Meet the Team
            </Link>
          </div>
        </div>
      </section>

      <section id="faq" className="faq">
        <div className="container">
          <div className="section-header">
            <span className="eyebrow">FAQs</span>
            <h2>Answers to common questions</h2>
            <p>Transparent engagement models designed to fit your priorities, cadence, and organizational context.</p>
          </div>
          <div className="faq-accordion">
            {faqs.map((faq, index) => (
              <div className={`faq-item ${faqOpen === index ? "open" : ""}`} key={faq.question}>
                <button
                  className="faq-question"
                  onClick={() => setFaqOpen((prev) => (prev === index ? null : index))}
                  aria-expanded={faqOpen === index}
                >
                  {faq.question}
                  <span className="faq-icon">{faqOpen === index ? "−" : "+"}</span>
                </button>
                <div className="faq-answer">
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="blog" className="blog">
        <div className="container">
          <div className="section-header">
            <span className="eyebrow">Insights &amp; Analysis</span>
            <h2>Stay ahead with perspective from our consultants.</h2>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article key={post.id} className="blog-card">
                <div className="blog-image">
                  <img src={`${post.image}&id=${post.id}`} alt={`${post.title} illustration`} loading="lazy" />
                </div>
                <div className="blog-content">
                  <span className="blog-date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href="#!" className="blog-link">
                    Read article →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container cta-content">
          <h2>Ready to create a clear path from strategy to execution?</h2>
          <p>
            Let’s explore where your organization can unlock outsized value through digital, data, and product-led
            transformation.
          </p>
          <div className="cta-actions">
            <Link to="/contact" className="btn primary">
              Start the Conversation
            </Link>
            <a href="tel:+14155550123" className="btn tertiary">
              Call +1 (415) 555-0123
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;