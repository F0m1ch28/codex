import React from "react";

const Privacy = () => (
  <div className="page legal-page">
    <section className="container">
      <h1>Privacy Policy</h1>
      <p>Effective date: March 30, 2024</p>
      <h2>Information We Collect</h2>
      <p>
        We collect personal information that you provide to us such as name, company, contact information, job title, and
        any other information you voluntarily share via the Site’s forms or communications. We also automatically collect
        certain information through cookies and analytics technologies.
      </p>
      <h2>How We Use Information</h2>
      <p>
        We use personal information to respond to inquiries, provide services, improve the Site, personalize content, and
        comply with legal obligations. We do not sell personal data.
      </p>
      <h2>Your Rights</h2>
      <p>
        Depending on your jurisdiction, you may have rights to access, correct, delete, or restrict the processing of your
        personal information. Contact <a href="mailto:privacy@primeedge.co">privacy@primeedge.co</a> to exercise your
        rights.
      </p>
      <h2>Data Security</h2>
      <p>
        We implement industry-standard technical and organizational measures to protect personal information against
        unauthorized access, disclosure, alteration, or destruction.
      </p>
      <h2>Contact</h2>
      <p>
        For privacy inquiries, email <a href="mailto:privacy@primeedge.co">privacy@primeedge.co</a>.
      </p>
    </section>
  </div>
);

export default Privacy;