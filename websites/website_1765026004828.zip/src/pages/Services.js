import React, { useState } from "react";

const serviceDetails = [
  {
    title: "Digital Strategy & Roadmapping",
    overview:
      "Structured discovery, benchmarking, and prioritization that align leadership around a clear transformation agenda.",
    bullets: [
      "Market and competitive analysis",
      "Growth scenario planning",
      "Operating model design",
      "Investment prioritization"
    ]
  },
  {
    title: "Customer & Employee Experience",
    overview:
      "End-to-end journey design that blends qualitative research with quantitative insights to create frictionless interactions.",
    bullets: [
      "Service design & journey orchestration",
      "Experience prototyping & testing",
      "Voice of customer analytics",
      "Experience measurement frameworks"
    ]
  },
  {
    title: "Data & AI Enablement",
    overview:
      "Modern data architectures, governance, and AI use cases that unlock speed, precision, and intelligent decisioning.",
    bullets: [
      "Data modernization roadmaps",
      "Machine learning solution design",
      "Responsible AI & governance",
      "Intelligent automation programs"
    ]
  },
  {
    title: "Product Delivery & Modern Engineering",
    overview:
      "Cross-functional teams driving agile product development, platform modernization, and scalable cloud-native solutions.",
    bullets: [
      "Product operating model setup",
      "Platform architecture & DevOps",
      "Quality engineering & automation",
      "Capability uplift & coaching"
    ]
  }
];

const Services = () => {
  const [active, setActive] = useState(0);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container page-hero-grid">
          <div>
            <span className="eyebrow">Our Services</span>
            <h1>Integrated consulting services built for measurable outcomes.</h1>
            <p>
              Our multidisciplinary teams design, build, and scale digital capabilities that create meaningful value for
              customers and stakeholders. Engagements are tailored to your context, governance, and speed requirements.
            </p>
          </div>
          <div className="page-hero-cta">
            <a href="#capabilities" className="btn primary">
              Explore Capabilities
            </a>
            <a href="/contact" className="btn secondary">
              Discuss Your Needs
            </a>
          </div>
        </div>
      </section>

      <section id="capabilities" className="container capabilities">
        <div className="capabilities-tabs">
          {serviceDetails.map((service, index) => (
            <button
              key={service.title}
              className={active === index ? "active" : ""}
              onClick={() => setActive(index)}
              aria-expanded={active === index}
            >
              {service.title}
            </button>
          ))}
        </div>
        <div className="capabilities-content">
          <h2>{serviceDetails[active].title}</h2>
          <p>{serviceDetails[active].overview}</p>
          <ul>
            {serviceDetails[active].bullets.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="engagement-models">
        <div className="container">
          <div className="section-header">
            <span className="eyebrow">Engagement Models</span>
            <h2>Flexible models aligned to your ambitions.</h2>
          </div>
          <div className="engagement-grid">
            <div>
              <h3>Advisory</h3>
              <p>Executive-level guidance, roadmaps, and governance to de-risk strategic decisions.</p>
              <ul>
                <li>Quarterly strategy sessions</li>
                <li>Investment case development</li>
                <li>Due diligence support</li>
              </ul>
            </div>
            <div>
              <h3>Embedded Teams</h3>
              <p>Multi-disciplinary pods working alongside internal teams to accelerate delivery.</p>
              <ul>
                <li>Product &amp; design leadership</li>
                <li>Engineering &amp; data squads</li>
                <li>Capability uplift programs</li>
              </ul>
            </div>
            <div>
              <h3>Transformation Programs</h3>
              <p>End-to-end change including strategy, delivery governance, and operating model design.</p>
              <ul>
                <li>Transformation office setup</li>
                <li>Change management and enablement</li>
                <li>Value tracking &amp; OKR implementation</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;