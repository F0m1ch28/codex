import React, { useState } from "react";

const initialState = {
  name: "",
  email: "",
  company: "",
  message: ""
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your name.";
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!formData.message.trim()) newErrors.message = "Let us know how we can help.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container page-hero-grid">
          <div>
            <span className="eyebrow">Contact Us</span>
            <h1>Let’s build the next chapter of your digital evolution.</h1>
            <p>
              Share your goals and challenges. Our consultants will assess your needs and craft a personalized approach
              that brings clarity and confidence to your transformation journey.
            </p>
            <div className="contact-meta">
              <span>Email: hello@primeedge.co</span>
              <span>Phone: +1 (415) 555-0123</span>
              <span>Offices: San Francisco • London • Singapore</span>
            </div>
          </div>
          <div className="contact-form-card">
            {submitted ? (
              <div className="contact-success">
                <h2>Thank you!</h2>
                <p>Our team will reach out within one business day.</p>
                <button className="btn secondary" onClick={() => setSubmitted(false)}>
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                <div className="form-group">
                  <label htmlFor="name">Full Name *</label>
                  <input id="name" name="name" value={formData.name} onChange={handleChange} placeholder="Jane Doe" />
                  {errors.name && <span className="error">{errors.name}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="email">Work Email *</label>
                  <input
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="jane.doe@company.com"
                  />
                  {errors.email && <span className="error">{errors.email}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="company">Company</label>
                  <input
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="Company name"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="message">How can we help? *</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows="4"
                    placeholder="Tell us about your objectives, challenges, timeline, or budget."
                  />
                  {errors.message && <span className="error">{errors.message}</span>}
                </div>
                <button type="submit" className="btn primary">
                  Submit Inquiry
                </button>
                <p className="form-disclaimer">
                  By submitting this form, you agree to our <a href="/privacy">Privacy Policy</a>.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      <section className="container contact-info">
        <div>
          <h2>Global presence, local expertise</h2>
          <p>
            Our distributed teams allow us to work closely with clients around the globe while bringing deep local market
            insights and regulatory understanding.
          </p>
        </div>
        <div className="contact-locations">
          <div>
            <h3>San Francisco</h3>
            <p>135 Townsend Street, Suite 700</p>
            <p>San Francisco, CA 94107</p>
          </div>
          <div>
            <h3>London</h3>
            <p>27 Soho Square</p>
            <p>London W1D 3QR, United Kingdom</p>
          </div>
          <div>
            <h3>Singapore</h3>
            <p>80 Robinson Road #09-01</p>
            <p>Singapore 068898</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;