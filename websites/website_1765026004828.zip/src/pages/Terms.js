import React from "react";

const Terms = () => (
  <div className="page legal-page">
    <section className="container">
      <h1>Terms &amp; Conditions</h1>
      <p>Last updated: March 30, 2024</p>
      <h2>1. Agreement to Terms</h2>
      <p>
        These Terms constitute a legally binding agreement made between you and Prime Edge Consulting (“Company”, “we”,
        “us”, or “our”). By accessing our site, you agree that you have read, understood, and agree to be bound by all of
        these Terms.
      </p>
      <h2>2. Intellectual Property Rights</h2>
      <p>
        Unless otherwise indicated, the Site and all content are our proprietary property and are protected by copyright,
        trademark, and other intellectual property laws.
      </p>
      <h2>3. User Representations</h2>
      <p>
        By using the Site, you represent and warrant that: (1) all registration information you submit will be true,
        accurate, and complete; (2) you have the legal capacity and you agree to comply with these Terms.
      </p>
      <h2>4. Governing Law</h2>
      <p>These Terms shall be governed by and defined following the laws of California, United States.</p>
      <h2>5. Contact Us</h2>
      <p>
        For questions regarding these Terms, contact us at <a href="mailto:legal@primeedge.co">legal@primeedge.co</a>.
      </p>
    </section>
  </div>
);

export default Terms;