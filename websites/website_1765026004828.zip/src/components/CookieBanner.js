import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("pe-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("pe-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>
        We use cookies to personalize content, tailor digital experiences, and analyze our traffic. By clicking “Accept”,
        you agree to our use of cookies.{" "}
        <a href="/privacy">Learn more</a>
      </p>
      <button onClick={acceptCookies} className="btn primary">
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;