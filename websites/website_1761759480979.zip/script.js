document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const contactForm = document.getElementById('contactForm');
    const faqItems = document.querySelectorAll('.faq-item');
    const currentYearSpan = document.getElementById('currentYear');
    const revealElements = document.querySelectorAll('.reveal');

    // Mobile navigation
    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            nav.classList.toggle('open');
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Cookie consent
    if (cookieBanner) {
        const consent = localStorage.getItem('pip_cookie_consent');
        if (!consent) {
            setTimeout(() => cookieBanner.classList.add('active'), 1000);
        }
        if (acceptCookiesBtn) {
            acceptCookiesBtn.addEventListener('click', () => {
                localStorage.setItem('pip_cookie_consent', 'accepted');
                cookieBanner.classList.remove('active');
            });
        }
    }

    // Contact form handling
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formMessage = contactForm.querySelector('.form-message');

            // Basic validation beyond HTML5
            const requiredFields = ['name', 'company', 'email', 'phone', 'service', 'message', 'privacy'];
            const formData = new FormData(contactForm);
            let valid = true;

            requiredFields.forEach(field => {
                if (!formData.get(field)) {
                    valid = false;
                }
            });

            if (!valid) {
                formMessage.textContent = 'Compila tutti i campi richiesti.';
                formMessage.classList.add('error');
                formMessage.classList.remove('success');
                return;
            }

            // Simulate async submission
            formMessage.textContent = 'Invio in corso...';
            formMessage.classList.remove('error', 'success');

            setTimeout(() => {
                formMessage.textContent = 'Grazie! Ti ricontatteremo entro 24 ore lavorative.';
                formMessage.classList.add('success');
                formMessage.classList.remove('error');
                contactForm.reset();
            }, 1200);
        });
    }

    // FAQ toggle
    if (faqItems.length) {
        faqItems.forEach(item => {
            const questionBtn = item.querySelector('.faq-question');
            const answer = item.querySelector('.faq-answer');
            questionBtn.addEventListener('click', () => {
                const isExpanded = questionBtn.getAttribute('aria-expanded') === 'true';
                questionBtn.setAttribute('aria-expanded', String(!isExpanded));
                if (isExpanded) {
                    answer.hidden = true;
                    item.classList.remove('open');
                } else {
                    answer.hidden = false;
                    item.classList.add('open');
                }
            });
        });
    }

    // Current year
    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

    // Reveal animations
    if ('IntersectionObserver' in window && revealElements.length) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.2
        });

        revealElements.forEach(el => observer.observe(el));
    } else {
        revealElements.forEach(el => el.classList.add('visible'));
    }
});