import React from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    organisation: '',
    interest: 'Frontend Development',
    message: ''
  });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = 'Enter a valid email.';
    if (!formData.message.trim()) newErrors.message = 'Share a few details about your goals.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitted(false);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData({
      name: '',
      email: '',
      organisation: '',
      interest: 'Frontend Development',
      message: ''
    });
  };

  return (
    <>
      <Seo
        title="Contact IT Learning Hub Belgium"
        description="Contact IT Learning Hub Belgium to discuss IT courses, custom training, or partnerships. We're ready to design your next learning journey."
      />
      <section className={styles.contact}>
        <div className={styles.content}>
          <span className="eyebrow">Contact us</span>
          <h1 className="section-title">We are here to co-create your learning journey.</h1>
          <p>
            Share your goals and we will connect you with the right advisor. Whether you are an
            individual learner or a team leader, we tailor programmes that match your ambitions.
          </p>
          <div className={styles.contactDetails}>
            <div>
              <h2>Visit us</h2>
              <p>
                IT Learning Hub<br />
                Avenue de la Toison d&apos;Or 56<br />
                1060 Brussels, Belgium
              </p>
            </div>
            <div>
              <h2>Talk with us</h2>
              <p>
                <a href="tel:+3221234567">+32 2 123 45 67</a>
                <br />
                <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
              </p>
            </div>
          </div>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Name *</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Your full name"
              value={formData.name}
              onChange={handleChange}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email *</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="name@company.com"
              value={formData.email}
              onChange={handleChange}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="organisation">Organisation</label>
            <input
              type="text"
              id="organisation"
              name="organisation"
              placeholder="Company or institution"
              value={formData.organisation}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="interest">Area of interest</label>
            <select
              id="interest"
              name="interest"
              value={formData.interest}
              onChange={handleChange}
            >
              <option>Frontend Development</option>
              <option>Data Analysis</option>
              <option>Cloud Foundations</option>
              <option>Cybersecurity</option>
              <option>Custom Training Programme</option>
            </select>
          </div>
          <div className={styles.field}>
            <label htmlFor="message">How can we help? *</label>
            <textarea
              id="message"
              name="message"
              rows="4"
              placeholder="Share your goals, timelines, and any context."
              value={formData.message}
              onChange={handleChange}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && (
              <span id="message-error" className={styles.error}>{errors.message}</span>
            )}
          </div>
          <button type="submit" className={styles.submit}>
            Submit enquiry
          </button>
          {submitted && (
            <div className={styles.success} role="status">
              Thank you! Our team will reach out shortly to continue the conversation.
            </div>
          )}
        </form>
      </section>
    </>
  );
};

export default Contact;