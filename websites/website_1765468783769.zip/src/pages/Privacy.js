import React from 'react';
import Seo from '../components/Seo';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Seo
      title="Privacy Policy | IT Learning Hub Belgium"
      description="Learn how IT Learning Hub Belgium collects, stores, and protects personal data in line with GDPR."
    />
    <section className={styles.page}>
      <h1 className="section-title">Privacy Policy</h1>
      <p className={styles.updated}>Effective date: June 2023</p>
      <p>
        IT Learning Hub Belgium is committed to protecting your personal data in accordance with the
        General Data Protection Regulation (GDPR). This policy describes how we collect, use, and
        safeguard information when you interact with our services.
      </p>

      <h2>Information we collect</h2>
      <ul>
        <li>Contact details shared via forms, email, or telephone.</li>
        <li>Learning preferences and profile information provided during onboarding.</li>
        <li>Engagement metrics within learning platforms to improve learner experience.</li>
      </ul>

      <h2>How we use information</h2>
      <ul>
        <li>To deliver, personalise, and support learning programmes.</li>
        <li>To communicate updates, schedules, and relevant learning resources.</li>
        <li>To analyse aggregated data for programme improvement.</li>
      </ul>

      <h2>Data protection and retention</h2>
      <p>
        We implement administrative and technical safeguards to protect personal data. Information is
        retained only for as long as necessary to fulfil the purposes outlined above or to comply
        with legal obligations.
      </p>

      <h2>Your rights</h2>
      <p>
        You have the right to request access, correction, deletion, or restriction of your personal
        data. To exercise these rights or ask questions about our privacy practices, contact
        info@itlearninghub.be.
      </p>
    </section>
  </>
);

export default Privacy;