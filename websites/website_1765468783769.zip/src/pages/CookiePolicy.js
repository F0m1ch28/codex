import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Seo
      title="Cookie Policy | IT Learning Hub Belgium"
      description="Understand how IT Learning Hub Belgium uses cookies to improve site performance and user experience."
    />
    <section className={styles.page}>
      <h1 className="section-title">Cookie Policy</h1>
      <p className={styles.updated}>Effective date: June 2023</p>
      <p>
        This Cookie Policy explains how IT Learning Hub Belgium uses cookies and similar technologies
        on our website and learning platforms. By continuing to browse our site, you consent to the
        use of cookies as described here.
      </p>

      <h2>What are cookies?</h2>
      <p>
        Cookies are small data files stored on your device when you visit a website. They help the
        site remember your preferences, understand usage patterns, and enhance overall performance.
      </p>

      <h2>How we use cookies</h2>
      <ul>
        <li>Essential cookies to enable secure access and session management.</li>
        <li>Performance cookies to analyse site traffic and optimise content.</li>
        <li>Functional cookies to remember preferences such as language or region.</li>
      </ul>

      <h2>Managing cookies</h2>
      <p>
        You can control and manage cookies through your browser settings. Please note that disabling
        certain cookies may affect the functionality of our website or learning platforms.
      </p>

      <p>
        If you have questions about our cookie usage, contact us at info@itlearninghub.be.
      </p>
    </section>
  </>
);

export default CookiePolicy;