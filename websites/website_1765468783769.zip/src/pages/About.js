import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const values = [
  {
    title: 'Human-centred learning',
    description:
      'We treat learning as a co-created journey, listening deeply to our learners and adapting experiences to their aspirations.'
  },
  {
    title: 'Experimentation culture',
    description:
      'We champion curiosity with labs, hackathons, and reflective practice to embed knowledge through experimentation.'
  },
  {
    title: 'Inclusive communities',
    description:
      'We design programmes that welcome multilingual, multicultural audiences reflective of Belgium’s diverse landscape.'
  }
];

const timeline = [
  {
    year: '2016',
    title: 'Launch in Brussels',
    description:
      'IT Learning Hub opened its first collaborative studio near Avenue de la Toison d’Or, hosting evening coding meetups.'
  },
  {
    year: '2018',
    title: 'Partnerships with universities',
    description:
      'We co-designed blended courses with Belgian universities, merging academic excellence with industry pragmatism.'
  },
  {
    year: '2020',
    title: 'Remote-first acceleration',
    description:
      'Responding to digital transformation, we built remote labs and mentorship programmes accessible across Belgium.'
  },
  {
    year: '2022',
    title: 'Enterprise academies',
    description:
      'We launched dedicated academies for public institutions and scale-ups, focusing on cloud, data, and cybersecurity.'
  }
];

const leadership = [
  {
    name: 'Charlotte De Smet',
    role: 'Founder & Learning Strategist',
    bio: 'Charlotte translates organisational goals into human-focused learning journeys powered by adaptable frameworks.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Hugo Kerkhof',
    role: 'Director of Technology Programs',
    bio: 'Hugo brings 15 years of engineering leadership, guiding cohorts through cloud-native architectures and DevOps culture.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=401&q=80'
  },
  {
    name: 'Nora Lemaire',
    role: 'Head of Learner Experience',
    bio: 'Nora ensures every learner is supported through wellness initiatives, coaching, and community-building activities.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=402&q=80'
  }
];

const About = () => (
  <>
    <Seo
      title="About IT Learning Hub Belgium | Our Story and Impact"
      description="Discover the mission, values, and leadership behind IT Learning Hub Belgium. Learn how we empower professionals through inclusive, human-centred IT education."
    />
    <section className={styles.intro}>
      <div className={styles.introContent}>
        <span className="eyebrow">Our story</span>
        <h1 className="section-title">Purpose-led learning for a digitally confident Belgium.</h1>
        <p>
          IT Learning Hub Belgium was born from a simple idea: building a space where technology
          professionals feel inspired, supported, and equipped to shape the future. From our studio
          in Brussels to hybrid classrooms nationwide, we design learning experiences that blend
          empathy, experimentation, and results.
        </p>
      </div>
      <div className={styles.introMedia}>
        <img
          src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=900&q=80"
          alt="Collaborative learning session in Brussels"
        />
      </div>
    </section>

    <section className={styles.values}>
      <h2 className="section-title">Values that guide every interaction</h2>
      <div className={styles.valueGrid}>
        {values.map((value) => (
          <article key={value.title} className={styles.valueCard}>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.timeline}>
      <div className={styles.timelineHeader}>
        <span className="eyebrow">Milestones</span>
        <h2 className="section-title">Growing with Belgium&apos;s tech community</h2>
        <p>
          Over the years, we have continuously refined our programmes to anticipate industry shifts
          and learner needs.
        </p>
      </div>
      <div className={styles.timelineList}>
        {timeline.map((item) => (
          <article key={item.year} className={styles.timelineItem}>
            <div className={styles.timelineMarker}>
              <span>{item.year}</span>
            </div>
            <div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.leadership}>
      <h2 className="section-title">Leadership team</h2>
      <p className="section-description">
        Our leadership team combines experience in education, technology, and community building to
        ensure every programme delivers measurable impact.
      </p>
      <div className={styles.leadershipGrid}>
        {leadership.map((leader) => (
          <article key={leader.name} className={styles.leaderCard}>
            <img src={leader.image} alt={leader.name} />
            <div className={styles.leaderContent}>
              <h3>{leader.name}</h3>
              <span className={styles.leaderRole}>{leader.role}</span>
              <p>{leader.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default About;