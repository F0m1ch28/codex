import React from 'react';
import Seo from '../components/Seo';
import styles from './Methodology.module.css';

const pillars = [
  {
    title: 'Immersive learning design',
    description:
      'Each module combines live sessions, collaborative studios, and reflective assignments to promote active engagement.'
  },
  {
    title: 'Mentorship and coaching',
    description:
      'Learners meet weekly with mentors for personalised feedback, portfolio reviews, and career-oriented guidance.'
  },
  {
    title: 'Measurement and iteration',
    description:
      'We measure learner progress through qualitative reflections, skills assessments, and project showcases.'
  }
];

const Methodology = () => (
  <>
    <Seo
      title="Our Methodology | IT Learning Hub Belgium"
      description="Explore the methodology behind IT Learning Hub Belgium's programmes, rooted in human-centred design, mentorship, and measurable outcomes."
    />
    <section className={styles.hero}>
      <div className={styles.heroText}>
        <span className="eyebrow">Methodology</span>
        <h1 className="section-title">Learning that inspires action and measurable outcomes.</h1>
        <p>
          Our methodology blends learning science with real-world practice. We focus on enabling
          practitioners to retain knowledge, apply skills confidently, and embrace continuous
          growth.
        </p>
      </div>
      <div className={styles.heroMedia}>
        <img
          src="https://images.unsplash.com/photo-1513258496099-48168024aec0?auto=format&fit=crop&w=900&q=80"
          alt="Interactive workshop methodology"
        />
      </div>
    </section>

    <section className={styles.pillars}>
      <h2 className="section-title">Three pillars that shape our programmes</h2>
      <div className={styles.pillarGrid}>
        {pillars.map((pillar) => (
          <article key={pillar.title} className={styles.pillarCard}>
            <h3>{pillar.title}</h3>
            <p>{pillar.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.framework}>
      <div className={styles.frameworkContent}>
        <h2 className="section-title">Our learning framework</h2>
        <p>
          We guide learners through an iterative cycle of discovery, experimentation, delivery, and
          reflection. This approach allows knowledge to move beyond theory and into daily practice.
        </p>
        <ul>
          <li>Discovery sessions to align goals and assess current competencies.</li>
          <li>Hands-on labs that simulate real-world scenarios and collaborative problem-solving.</li>
          <li>Capstone projects that demonstrate applied knowledge and showcase impact.</li>
          <li>Reflection rituals and coaching for sustained improvement.</li>
        </ul>
      </div>
      <div className={styles.frameworkVisual}>
        <img
          src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=900&q=80"
          alt="Students working on laptops during a collaborative project"
        />
      </div>
    </section>
  </>
);

export default Methodology;