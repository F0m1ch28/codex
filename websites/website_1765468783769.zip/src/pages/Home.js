import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const stats = [
  { value: '2,500+', label: 'Learners Empowered' },
  { value: '85%', label: 'Career Transitions within 6 months' },
  { value: '40', label: 'Industry-Aligned Mentors' },
  { value: '12', label: 'Learning Tracks Across Belgium' }
];

const benefits = [
  {
    title: 'Real-World Curriculum',
    description: 'We co-create modules with Belgian tech leaders to mirror real project challenges and toolchains.',
    icon: '🧭'
  },
  {
    title: 'Expert Trainers',
    description: 'Our trainers bring years of industry experience from cloud-native companies, scale-ups, and consultancies.',
    icon: '🧑‍🏫'
  },
  {
    title: 'Practice-First Learning',
    description: 'Every course blends immersive labs, collaborative sprints, and reflective sessions to accelerate mastery.',
    icon: '🧪'
  },
  {
    title: 'Career Support Network',
    description: 'We offer mentoring circles, portfolio reviews, and networking events to help you reach your next role.',
    icon: '🤝'
  }
];

const learningPaths = [
  {
    title: 'Frontend Development',
    summary: 'Build performant interfaces with React, TypeScript, accessibility-first design, and testing workflows.',
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Data Analysis',
    summary: 'Master Python tooling, analytics pipelines, visualization, and data storytelling for business impact.',
    image: 'https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Cybersecurity Fundamentals',
    summary: 'Gain hands-on exposure to threat modelling, incident response, and zero-trust architecture principles.',
    image: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=800&q=80'
  },
  {
    title: 'Cloud Basics',
    summary: 'Learn to design and deploy resilient services across AWS and Azure with DevOps best practices.',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80'
  }
];

const processSteps = [
  {
    title: 'Discover',
    summary: 'We map your team or individual goals and align them with the Belgian tech landscape.',
    detail: 'Starting with a diagnostic workshop, we identify skill gaps, tooling requirements, and preferred learning modes.'
  },
  {
    title: 'Design',
    summary: 'We craft modular learning journeys that blend live sessions, microlearning, and coaching.',
    detail: 'Our instructional design team curates projects and labs to mirror your workflows while encouraging innovation.'
  },
  {
    title: 'Deliver',
    summary: 'We facilitate interactive sessions led by field experts and powered by collaborative platforms.',
    detail: 'Expect sprint-based assignments, code reviews, design critiques, and continuous feedback loops.'
  },
  {
    title: 'Develop',
    summary: 'We extend support with mentorship, showcases, and communities to sustain momentum.',
    detail: 'Learners join alumni circles, monthly meetups, and receive career guidance to embed new skills.'
  }
];

const successStories = [
  {
    title: 'AI-Ready Operations',
    description: 'An Antwerp fintech transitioned to data-driven decision making with a tailored analytics accelerator.',
    image: 'https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Secure-by-Design Culture',
    description: 'A Brussels-based public agency upskilled 60 professionals through cybersecurity war games and labs.',
    image: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Cloud-Native Transformation',
    description: 'A Ghent scale-up re-architected its platform with cloud-native practices after a blended learning sprint.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'
  }
];

const testimonials = [
  {
    name: 'Lina Vermeulen',
    role: 'Software Engineer, Antwerp',
    quote:
      'IT Learning Hub shaped my transition from QA to frontend engineering. The project-based approach and coaching made advanced concepts approachable.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'Mateo Laurent',
    role: 'Cloud Consultant, Brussels',
    quote:
      'The cloud bootcamp led by practitioners gave me the confidence to architect and deploy production workloads responsibly.',
    image: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=200&q=80'
  },
  {
    name: 'Isabella Dupont',
    role: 'Data Analyst, Liège',
    quote:
      'Collaborative labs and weekly feedback sessions created a powerful learning rhythm. I now champion data literacy in my organisation.',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80'
  }
];

const faqItems = [
  {
    question: 'How do you tailor learning paths for Belgian organisations?',
    answer:
      'We start with stakeholder interviews, align content with local regulatory requirements, and integrate case studies drawn from Belgian industries including finance, public services, and manufacturing.'
  },
  {
    question: 'Can individuals join without prior experience?',
    answer:
      'Yes. Each pathway has on-boarding materials to help newcomers establish foundations before joining live cohort sessions.'
  },
  {
    question: 'Do you offer hybrid or remote formats?',
    answer:
      'We combine in-person workshops in Brussels with virtual labs and asynchronous activities to accommodate distributed teams.'
  },
  {
    question: 'What support is available after a course ends?',
    answer:
      'Graduates access alumni circles, mentoring, exclusive meetups, and curated resources to sustain growth and network within the Belgian tech community.'
  }
];

const blogHighlights = [
  {
    title: 'How Belgian Teams Accelerate with Cloud Sandboxes',
    excerpt: 'Discover actionable strategies to introduce cloud-native practices across cross-functional squads.',
    date: 'July 18, 2023'
  },
  {
    title: 'Designing Accessible Interfaces for Multilingual Audiences',
    excerpt: 'Tips from our UX mentors on building inclusive frontends for Belgium’s diverse user base.',
    date: 'June 30, 2023'
  },
  {
    title: 'Data Literacy Frameworks for Public Institutions',
    excerpt: 'A practical guide to launching data upskilling programs within administration environments.',
    date: 'May 22, 2023'
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);

  React.useEffect(() => {
    const interval = window.setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => window.clearInterval(interval);
  }, []);

  return (
    <>
      <Seo
        title="IT Learning Hub Belgium | Future-Ready IT Education"
        description="IT Learning Hub Belgium delivers future-ready IT education through immersive courses, expert mentorship, and collaborative communities across Belgium."
      />
      <section
        className={styles.hero}
        style={{
          backgroundImage:
            "linear-gradient(120deg, rgba(15,23,42,0.65), rgba(30,58,138,0.65)), url('https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80')"
        }}
      >
        <div className={styles.heroContent}>
          <span className="eyebrow">Belgian Tech Education</span>
          <h1 className={styles.heroTitle}>
            Future-ready IT learning experiences for ambitious teams and individuals.
          </h1>
          <p className={styles.heroSubtitle}>
            Navigate the evolving digital landscape with human-centred training, industry-leading
            mentors, and transformative communities in the heart of Belgium.
          </p>
          <div className={styles.heroActions}>
            <Link to="/courses" className={styles.primaryCta}>
              Explore Courses
            </Link>
            <Link to="/contact" className={styles.secondaryCta}>
              Talk to an advisor
            </Link>
          </div>
          <div className={styles.heroStats}>
            {stats.map((item) => (
              <div key={item.label} className={styles.heroStatCard}>
                <span className={styles.statValue}>{item.value}</span>
                <span className={styles.statLabel}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <span className="eyebrow">Why choose us</span>
        <h2 className="section-title">Crafted for impact, designed for Belgian innovation</h2>
        <p className="section-description">
          We transform learning into actionable progress—combining applied projects, mentorship, and
          community support to unlock new possibilities for every learner.
        </p>
        <div className={styles.benefitGrid}>
          {benefits.map((benefit) => (
            <article key={benefit.title} className={styles.benefitCard}>
              <span className={styles.benefitIcon} aria-hidden="true">
                {benefit.icon}
              </span>
              <h3>{benefit.title}</h3>
              <p>{benefit.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.learningPaths}>
        <div className={styles.sectionHeader}>
          <span className="eyebrow">Popular learning paths</span>
          <h2 className="section-title">Grow skills that employers trust</h2>
          <p className="section-description">
            Every path blends theory with hands-on labs, giving you the confidence to deliver value
            from day one.
          </p>
        </div>
        <div className={styles.pathsGrid}>
          {learningPaths.map((path) => (
            <article key={path.title} className={styles.pathCard}>
              <img src={path.image} alt={`${path.title} illustration`} />
              <div className={styles.pathContent}>
                <h3>{path.title}</h3>
                <p>{path.summary}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.aboutPreview}>
        <div className={styles.aboutGrid}>
          <div className={styles.aboutContent}>
            <span className="eyebrow">About IT Learning Hub Belgium</span>
            <h2 className="section-title">
              A collective of educators, technologists, and strategists.
            </h2>
            <p>
              We partner with organisations and individuals to design learning ecosystems rooted in
              empathy, experimentation, and tangible progress. From bespoke academies to open
              cohorts, we cultivate environments where curiosity thrives.
            </p>
            <ul className={styles.aboutList}>
              <li>Collaborative studios in Brussels, Antwerp, and Ghent.</li>
              <li>Expert-led academies shaped by real Belgian case studies.</li>
              <li>Communities that support diverse career journeys across Europe.</li>
            </ul>
            <Link to="/about" className={styles.textLink}>
              Learn more about our story →
            </Link>
          </div>
          <div className={styles.aboutMedia}>
            <img
              src="https://images.unsplash.com/photo-1521737604893-9112a317a0f0?auto=format&fit=crop&w=800&q=80"
              alt="Learners collaborating during a workshop"
            />
            <div className={styles.mediaCard}>
              <h3>Mission Statement</h3>
              <p>
                We empower Belgium&apos;s digital ecosystem by nurturing adaptive talent and
                inclusive teams ready for tomorrow&apos;s challenges.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <span className="eyebrow">Our process</span>
          <h2 className="section-title">From discovery to continuous development</h2>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <article key={step.title} className={styles.processCard}>
              <span className={styles.stepNumber}>0{index + 1}</span>
              <div className={styles.stepContent}>
                <h3>{step.title}</h3>
                <p className={styles.stepSummary}>{step.summary}</p>
                <p className={styles.stepDetail}>{step.detail}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <span className="eyebrow">Testimonials</span>
          <h2 className="section-title">What our learning community is saying</h2>
        </div>
        <div className={styles.testimonialWrapper}>
          <button
            type="button"
            aria-label="Previous testimonial"
            onClick={() =>
              setActiveTestimonial(
                (prev) => (prev - 1 + testimonials.length) % testimonials.length
              )
            }
            className={styles.navButton}
          >
            ←
          </button>
          <article className={styles.testimonialCard}>
            <img
              src={testimonials[activeTestimonial].image}
              alt={testimonials[activeTestimonial].name}
              className={styles.testimonialImage}
            />
            <blockquote>{testimonials[activeTestimonial].quote}</blockquote>
            <div className={styles.testimonialMeta}>
              <strong>{testimonials[activeTestimonial].name}</strong>
              <span>{testimonials[activeTestimonial].role}</span>
            </div>
          </article>
          <button
            type="button"
            aria-label="Next testimonial"
            onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
            className={styles.navButton}
          >
            →
          </button>
        </div>
        <div className={styles.dots}>
          {testimonials.map((_, index) => (
            <button
              key={index}
              type="button"
              className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
              aria-label={`Show testimonial ${index + 1}`}
              onClick={() => setActiveTestimonial(index)}
            />
          ))}
        </div>
      </section>

      <section className={styles.successStories}>
        <div className={styles.sectionHeader}>
          <span className="eyebrow">Success stories</span>
          <h2 className="section-title">Belgian teams unlocking their potential</h2>
        </div>
        <div className={styles.storyGrid}>
          {successStories.map((story) => (
            <article key={story.title} className={styles.storyCard}>
              <img src={story.image} alt={`${story.title} project`} />
              <div className={styles.storyContent}>
                <h3>{story.title}</h3>
                <p>{story.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <span className="eyebrow">FAQ</span>
          <h2 className="section-title">Frequently asked questions</h2>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item) => (
            <details key={item.question} className={styles.faqItem}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHeader}>
          <span className="eyebrow">Insights</span>
          <h2 className="section-title">Latest reflections from our faculty</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogHighlights.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <span className={styles.blogDate}>{post.date}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <Link to="/contact" className={styles.textLink}>
                Continue the conversation →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaInner}>
          <span className="eyebrow">Ready to begin?</span>
          <h2>Let&apos;s design your next learning milestone together.</h2>
          <p>
            Connect with our team to map a learning journey aligned with your aspirations. We are
            here to help you transform curiosity into confidence.
          </p>
          <Link to="/contact" className={styles.ctaButton}>
            Get in Touch
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;