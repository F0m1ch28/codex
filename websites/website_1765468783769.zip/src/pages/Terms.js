import React from 'react';
import Seo from '../components/Seo';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Seo
      title="Terms of Service | IT Learning Hub Belgium"
      description="Review the Terms of Service for IT Learning Hub Belgium covering learning programmes, platform usage, and support."
    />
    <section className={styles.page}>
      <h1 className="section-title">Terms of Service</h1>
      <p className={styles.updated}>Last updated: June 2023</p>
      <p>
        These Terms of Service govern access to and participation in programmes delivered by IT
        Learning Hub Belgium. By engaging with our services, you acknowledge and agree to the
        following terms.
      </p>

      <h2>1. Programmes and participation</h2>
      <p>
        We design learning journeys that may include live instruction, online learning environments,
        mentoring, and community events. Participants are expected to uphold respectful
        communication, maintain confidentiality of shared materials, and engage responsibly with
        fellow learners.
      </p>

      <h2>2. Intellectual property</h2>
      <p>
        All course materials, recordings, and resources remain the intellectual property of IT
        Learning Hub Belgium or our partners. Learners may use resources for personal development
        but may not redistribute or publish them without written consent.
      </p>

      <h2>3. Use of platforms</h2>
      <p>
        Access to digital platforms may be provided for collaboration, content hosting, or
        assessments. Learners agree to comply with platform-specific policies and ensure the
        security of their accounts.
      </p>

      <h2>4. Support and feedback</h2>
      <p>
        We encourage open feedback to continually refine our programmes. Any concerns should be
        shared with our support team at info@itlearninghub.be. We endeavour to respond promptly and
        work collaboratively toward a resolution.
      </p>

      <h2>5. Changes to terms</h2>
      <p>
        We may update these terms from time to time. Updated versions will be posted on this page
        with the effective date clearly stated. Continued participation indicates acceptance of the
        revised terms.
      </p>
    </section>
  </>
);

export default Terms;