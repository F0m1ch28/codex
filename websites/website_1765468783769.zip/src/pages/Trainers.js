import React from 'react';
import Seo from '../components/Seo';
import styles from './Trainers.module.css';

const trainers = [
  {
    name: 'Eva Janssens',
    role: 'Lead Frontend Trainer',
    bio: 'Eva specialises in design systems and accessibility. She has led frontend teams for European SaaS scale-ups.',
    expertise: ['React', 'Design Systems', 'Accessibility'],
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=403&q=80'
  },
  {
    name: 'Milan Rodrigues',
    role: 'Principal Cloud Mentor',
    bio: 'Milan empowers engineers with reliable, secure cloud architectures, drawing from a decade of platform engineering.',
    expertise: ['AWS', 'Azure', 'DevOps'],
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=404&q=80'
  },
  {
    name: 'Sophie Claes',
    role: 'Data Science Coach',
    bio: 'Sophie coaches teams on analytics, ML ops, and ethical AI. She brings experience from Brussels-based analytics consultancies.',
    expertise: ['Python', 'Machine Learning', 'Data Ethics'],
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=405&q=80'
  },
  {
    name: 'Noah Moreau',
    role: 'Cybersecurity Instructor',
    bio: 'Noah runs red team simulations and security champions programmes for both startups and public organisations.',
    expertise: ['Threat Modelling', 'Incident Response', 'Zero Trust'],
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=406&q=80'
  }
];

const Trainers = () => (
  <>
    <Seo
      title="Meet Our Trainers | IT Learning Hub Belgium"
      description="Meet the experienced trainers at IT Learning Hub Belgium. Explore their expertise in frontend, cloud, data, and cybersecurity education."
    />
    <section className={styles.intro}>
      <span className="eyebrow">Our trainers</span>
      <h1 className="section-title">Guided by practitioners who lead with empathy and expertise.</h1>
      <p>
        Our trainers are hands-on professionals who translate complex topics into digestible,
        engaging sessions. They mentor learners through projects, champion inclusive learning, and
        share insights from Belgium&apos;s vibrant tech community.
      </p>
    </section>

    <section className={styles.trainerGrid}>
      {trainers.map((trainer) => (
        <article key={trainer.name} className={styles.trainerCard}>
          <img src={trainer.image} alt={trainer.name} />
          <div className={styles.trainerContent}>
            <h2>{trainer.name}</h2>
            <span className={styles.role}>{trainer.role}</span>
            <p>{trainer.bio}</p>
            <div className={styles.expertise}>
              {trainer.expertise.map((skill) => (
                <span key={skill}>{skill}</span>
              ))}
            </div>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default Trainers;