import React from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const categories = ['All', 'Frontend', 'Data', 'Cloud', 'Cybersecurity'];

const courses = [
  {
    title: 'Modern Frontend Craft',
    category: 'Frontend',
    description:
      'Level up with component-driven architectures, state management patterns, accessibility, and performance budgets.'
  },
  {
    title: 'React & TypeScript Studio',
    category: 'Frontend',
    description:
      'Dive into scalable React design, TypeScript contracts, testing strategies, and continuous integration workflows.'
  },
  {
    title: 'Data Analytics Accelerator',
    category: 'Data',
    description:
      'Comprehensive journey through Python data stacks, dashboarding, storytelling, and stakeholder communication.'
  },
  {
    title: 'Applied Machine Learning',
    category: 'Data',
    description:
      'Build end-to-end ML prototypes with hands-on exploration of model ops, ethical considerations, and deployment.'
  },
  {
    title: 'Cloud Foundations',
    category: 'Cloud',
    description:
      'Understand cloud architecture principles, networking fundamentals, and security controls across AWS and Azure.'
  },
  {
    title: 'Site Reliability Essentials',
    category: 'Cloud',
    description:
      'Learn observability, incident response, automation, and platform engineering fundamentals from production veterans.'
  },
  {
    title: 'Cybersecurity Essentials',
    category: 'Cybersecurity',
    description:
      'Grasp risk management, secure architectures, and incident handling with realistic simulations tailored to Belgium.'
  },
  {
    title: 'Security Champions Program',
    category: 'Cybersecurity',
    description:
      'Empower product teams with secure-by-design practices, threat modelling, and agile governance playbooks.'
  }
];

const Services = () => {
  const [activeCategory, setActiveCategory] = React.useState('All');

  const filteredCourses =
    activeCategory === 'All'
      ? courses
      : courses.filter((course) => course.category === activeCategory);

  return (
    <>
      <Seo
        title="IT Courses in Belgium | IT Learning Hub Belgium"
        description="Explore immersive IT courses in frontend development, data analytics, cloud, and cybersecurity. Flexible formats for teams and individuals across Belgium."
      />
      <section className={styles.header}>
        <div className={styles.headerText}>
          <span className="eyebrow">Our Courses</span>
          <h1 className="section-title">
            Master future-proof skills with expert-led programmes.
          </h1>
          <p>
            Whether you are skilling up your team or reimagining your career, our tracks combine
            live mentoring, labs, and collaborative projects to accelerate progress.
          </p>
        </div>
        <div className={styles.headerMedia}>
          <img
            src="https://images.unsplash.com/photo-1489528792647-46ec1e5af534?auto=format&fit=crop&w=900&q=80"
            alt="Group of professionals learning together"
          />
        </div>
      </section>

      <section className={styles.catalog}>
        <div className={styles.filterBar} role="tablist" aria-label="Course categories">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              role="tab"
              aria-selected={activeCategory === cat}
              className={`${styles.filterButton} ${
                activeCategory === cat ? styles.filterActive : ''
              }`}
              onClick={() => setActiveCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className={styles.courseGrid}>
          {filteredCourses.map((course) => (
            <article key={course.title} className={styles.courseCard}>
              <span className={styles.category}>{course.category}</span>
              <h3>{course.title}</h3>
              <p>{course.description}</p>
              <div className={styles.meta}>
                <span>Immersive labs</span>
                <span>Expert mentors</span>
                <span>Peer feedback</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.highlights}>
        <div className={styles.highlightCard}>
          <h2>Learning formats designed around you</h2>
          <ul>
            <li>Hybrid cohorts blending in-person workshops in Brussels with remote labs.</li>
            <li>Challenge-based learning with weekly demos and retrospectives.</li>
            <li>Access to mentor office hours and progress coaching.</li>
          </ul>
        </div>
        <div className={styles.highlightCard}>
          <h2>Beyond the classroom</h2>
          <ul>
            <li>Curated resource hub with playbooks, templates, and recordings.</li>
            <li>Community of peers for accountability, networking, and collaboration.</li>
            <li>Showcase events where learners present capstones to industry guests.</li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default Services;