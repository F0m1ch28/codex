import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem('itlh-cookie-consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('itlh-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.message}>
          We use cookies to personalize learning experiences and analyze our traffic. By clicking
          “Accept”, you consent to the use of cookies in line with our policies.
        </p>
        <div className={styles.actions}>
          <Link className={styles.secondary} to="/cookie-policy">
            Learn More
          </Link>
          <button type="button" className={styles.primary} onClick={handleAccept}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;