import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.column}>
        <div className={styles.brand}>IT Learning Hub</div>
        <p className={styles.text}>
          IT Learning Hub Belgium empowers professionals across the country through future-focused
          IT education, collaborative learning, and career-accelerating mentorship.
        </p>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Quick Links</h3>
        <ul className={styles.list}>
          <li><Link to="/" className={styles.link}>Home</Link></li>
          <li><Link to="/about" className={styles.link}>About Us</Link></li>
          <li><Link to="/courses" className={styles.link}>Our Courses</Link></li>
          <li><Link to="/methodology" className={styles.link}>Methodology</Link></li>
          <li><Link to="/trainers" className={styles.link}>Meet Our Trainers</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Contact</h3>
        <address className={styles.address}>
          <span>IT Learning Hub</span>
          <span>Avenue de la Toison d'Or 56</span>
          <span>1060 Brussels, Belgium</span>
          <a className={styles.link} href="tel:+3221234567">+32 2 123 45 67</a>
          <a className={styles.link} href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
        </address>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Policies</h3>
        <ul className={styles.list}>
          <li><Link to="/terms-of-service" className={styles.link}>Terms of Service</Link></li>
          <li><Link to="/privacy-policy" className={styles.link}>Privacy Policy</Link></li>
          <li><Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link></li>
        </ul>
      </div>
    </div>
    <div className={styles.bottomBar}>
      © 2023 IT Learning Hub Belgium. All rights reserved.
    </div>
  </footer>
);

export default Footer;