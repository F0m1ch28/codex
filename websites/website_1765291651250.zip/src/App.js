import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Articles from './pages/Articles';
import Themes from './pages/Themes';
import Entretiens from './pages/Entretiens';
import Ressources from './pages/Ressources';
import Contact from './pages/Contact';
import PolitiqueConfidentialite from './pages/PolitiqueConfidentialite';
import ConditionsUtilisation from './pages/ConditionsUtilisation';
import PolitiqueCookies from './pages/PolitiqueCookies';
import styles from './App.module.css';

const App = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return (
    <div className={styles.app}>
      <Header />
      <main id="contenu-principal" className={styles.mainContent} tabIndex={-1}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/a-propos" element={<About />} />
          <Route path="/articles" element={<Articles />} />
          <Route path="/themes" element={<Themes />} />
          <Route path="/entretiens" element={<Entretiens />} />
          <Route path="/ressources" element={<Ressources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/politique-de-confidentialite" element={<PolitiqueConfidentialite />} />
          <Route path="/conditions-d-utilisation" element={<ConditionsUtilisation />} />
          <Route path="/politique-des-cookies" element={<PolitiqueCookies />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  );
};

export default App;