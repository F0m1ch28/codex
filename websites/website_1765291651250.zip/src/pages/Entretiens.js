import React from 'react';
import SEO from '../components/SEO';
import interviewsData from '../data/interviews';
import styles from './Entretiens.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/entretiens';

const Entretiens = () => {
  return (
    <div className={styles.entretiens}>
      <SEO
        title="Parisian Bakeries Review | Entretiens"
        description="Entretiens approfondis avec des boulangers, des historiens et des sociologues sur le rôle des boulangeries parisiennes."
        keywords="entretiens, artisans boulangers, historiens, sociologues"
        url={baseUrl}
      />
      <section className={styles.introSection}>
        <div className={styles.container}>
          <h1 className={styles.title}>Voix des acteurs</h1>
          <p className={styles.lead}>
            Les entretiens offrent des perspectives croisées sur la place des boulangeries dans la
            société parisienne. Chaque échange est retranscrit avec l’accord des interlocuteurs et
            contextualisé par des analyses complémentaires.
          </p>
        </div>
      </section>
      <section className={styles.listSection}>
        <div className={styles.container}>
          <div className={styles.grid}>
            {interviewsData.map((interview) => (
              <article key={interview.id} className={styles.card}>
                <img src={interview.image} alt={interview.name} className={styles.image} />
                <div className={styles.cardBody}>
                  <h2>{interview.name}</h2>
                  <p className={styles.role}>{interview.role}</p>
                  <blockquote className={styles.quote}>
                    <p>{interview.quote}</p>
                  </blockquote>
                  {interview.summary.split('\n\n').map((paragraph, index) => (
                    <p key={index} className={styles.summary}>
                      {paragraph}
                    </p>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Entretiens;