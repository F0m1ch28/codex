import React from 'react';
import SEO from '../components/SEO';
import styles from './Themes.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/themes';

const themes = [
  {
    title: 'Histoire et urbanisme',
    text: 'Étude des archives, analyse des reconstructions, cartographie des transferts de fournils et des implantations de fours municipaux.'
  },
  {
    title: 'Fermentations et céréales',
    text: 'Observation des levains, comparaisons des farines franciliennes, suivi des innovations liées aux blés anciens et aux fermentations mixtes.'
  },
  {
    title: 'Réglementation',
    text: 'Décryptage des décrets, veille sur les inspections sanitaires, documentation des labels et concours qui structurent la profession.'
  },
  {
    title: 'Transmission des savoir-faire',
    text: 'Analyses des formations, portraits d’apprentis, étude des dynamiques intergénérationnelles et des écoles d’application.'
  },
  {
    title: 'Influences de quartier',
    text: 'Cartographie sensible des pratiques selon les arrondissements, étude des interactions entre boulangeries et initiatives citoyennes.'
  },
  {
    title: 'Innovation et recherche',
    text: 'Suivi des outils numériques, des procédés à faible impact environnemental et des collaborations avec les laboratoires scientifiques.'
  }
];

const Themes = () => {
  return (
    <div className={styles.themes}>
      <SEO
        title="Parisian Bakeries Review | Thèmes"
        description="Panorama des grands axes de recherche explorés par Parisian Bakeries Review autour des boulangeries parisiennes."
        keywords="thèmes de recherche, boulangeries, innovation, réglementation"
        url={baseUrl}
      />
      <section className={styles.headerSection}>
        <div className={styles.container}>
          <h1 className={styles.title}>Axes d’étude</h1>
          <p className={styles.lead}>
            Les thématiques suivantes orientent la production éditoriale. Elles sont revisitées à
            chaque enquête pour refléter les mutations du paysage boulanger parisien.
          </p>
        </div>
      </section>
      <section className={styles.themeSection}>
        <div className={styles.container}>
          <div className={styles.themeGrid}>
            {themes.map((theme) => (
              <article key={theme.title} className={styles.themeCard}>
                <h2>{theme.title}</h2>
                <p>{theme.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Themes;