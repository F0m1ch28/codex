import React from 'react';
import SEO from '../components/SEO';
import styles from './About.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/a-propos';

const teamMembers = [
  {
    name: 'Jeanne Roux',
    role: 'Rédactrice en chef - spécialiste des patrimoines culinaires',
    bio: 'Elle coordonne les enquêtes historiques et supervise les collaborations avec les services d’archives et les bibliothèques municipales.',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Marc Leclerc',
    role: 'Rédacteur scientifique - expert en fermentation',
    bio: 'Il traduit les analyses microbiologiques en articles accessibles, met en relation les artisans et les laboratoires franciliens.',
    image:
      'https://images.unsplash.com/photo-1521579971123-1192931a1452?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Aïcha Benyamina',
    role: 'Journaliste de terrain - sociologie urbaine',
    bio: 'Elle cartographie les réseaux de boulangeries, suit les initiatives de quartier et documente les usages sociaux du pain.',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80'
  }
];

const About = () => {
  return (
    <div className={styles.about}>
      <SEO
        title="Parisian Bakeries Review | À Propos"
        description="Mission éditoriale, méthodologie de terrain et équipe de Parisian Bakeries Review, revue dédiée aux boulangeries parisiennes."
        keywords="mission éditoriale, boulangeries parisiennes, recherche, équipe"
        url={baseUrl}
      />

      <section className={styles.introduction} aria-labelledby="mission">
        <div className={styles.container}>
          <h1 id="mission" className={styles.title}>
            Une revue dédiée aux boulangeries parisiennes comme institutions culturelles
          </h1>
          <p>
            Parisian Bakeries Review documente les boulangeries de la capitale en tant que lieux
            d’étude. La rédaction s’attache à retracer leur histoire, à décrypter les pratiques
            artisanales et à comprendre les dynamiques sociales qui en découlent. Chaque numéro se
            construit à partir de sources croisées : archives, enquêtes de terrain, entretiens
            approfondis et contributions scientifiques.
          </p>
        </div>
      </section>

      <section className={styles.methods} aria-labelledby="methodes">
        <div className={styles.container}>
          <h2 id="methodes" className={styles.subtitle}>
            Méthodologie de recherche
          </h2>
          <div className={styles.grid}>
            <article className={styles.methodCard}>
              <h3>Observation in situ</h3>
              <p>
                Les membres de la rédaction réalisent des immersions dans les fournils pour décrire
                les gestes, les rythmes de production et les relations avec la clientèle. Chaque
                visite donne lieu à un journal détaillé puis à une restitution validée avec
                l’artisan.
              </p>
            </article>
            <article className={styles.methodCard}>
              <h3>Analyse documentaire</h3>
              <p>
                Les archives municipales, les collections iconographiques et les publications
                professionnelles sont consultées afin de replacer les boulangeries dans les
                transformations de la ville et de la filière blé.
              </p>
            </article>
            <article className={styles.methodCard}>
              <h3>Collaboration scientifique</h3>
              <p>
                Des partenariats avec des chercheurs en microbiologie, en sociologie urbaine et en
                histoire de l’alimentation garantissent la solidité des analyses et l’actualisation
                des données.
              </p>
            </article>
            <article className={styles.methodCard}>
              <h3>Corpus d’entretiens</h3>
              <p>
                Les entretiens semi-directifs menés auprès de boulangers, de meuniers, de
                responsables associatifs et d’institutions culturelles alimentent une base de
                connaissances consultable par thématique.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.timeline} aria-labelledby="frise">
        <div className={styles.container}>
          <h2 id="frise" className={styles.subtitle}>
            Jalons fondateurs
          </h2>
          <ul className={styles.timelineList}>
            <li>
              <span className={styles.timelineYear}>2015</span>
              <span className={styles.timelineText}>
                Première série d’enquêtes sur les fournils de la rive droite et création d’un comité
                scientifique pluridisciplinaire.
              </span>
            </li>
            <li>
              <span className={styles.timelineYear}>2017</span>
              <span className={styles.timelineText}>
                Lancement de la cartographie collaborative des fours parisiens et collecte de
                témoignages oraux auprès des maîtres boulangers retraités.
              </span>
            </li>
            <li>
              <span className={styles.timelineYear}>2020</span>
              <span className={styles.timelineText}>
                Déploiement d’un programme d’étude sur le levain avec le soutien de laboratoires
                universitaires spécialisés en microbiologie.
              </span>
            </li>
            <li>
              <span className={styles.timelineYear}>2022</span>
              <span className={styles.timelineText}>
                Intégration d’un volet sociologique dédié aux quartiers périphériques et aux
                initiatives solidaires de redistribution du pain.
              </span>
            </li>
          </ul>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="equipe">
        <div className={styles.container}>
          <h2 id="equipe" className={styles.subtitle}>
            Équipe éditoriale
          </h2>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.memberCard}>
                <img src={member.image} alt={member.name} />
                <div className={styles.memberContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.memberRole}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;