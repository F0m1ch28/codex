import React, { useMemo, useState } from 'react';
import SEO from '../components/SEO';
import articlesData from '../data/articles';
import styles from './Articles.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/articles';

const Articles = () => {
  const categories = useMemo(() => {
    const unique = new Set(articlesData.map((article) => article.category));
    return ['Tout', ...unique];
  }, []);

  const [selectedCategory, setSelectedCategory] = useState('Tout');
  const [selectedArticle, setSelectedArticle] = useState(articlesData[0]);

  const filteredArticles =
    selectedCategory === 'Tout'
      ? articlesData
      : articlesData.filter((article) => article.category === selectedCategory);

  const handleFilter = (category) => {
    setSelectedCategory(category);
    const first =
      category === 'Tout'
        ? articlesData[0]
        : articlesData.find((article) => article.category === category);
    setSelectedArticle(first || articlesData[0]);
  };

  const handleSelectArticle = (article) => {
    setSelectedArticle(article);
  };

  return (
    <div className={styles.articles}>
      <SEO
        title="Parisian Bakeries Review | Articles"
        description="Archive des enquêtes approfondies consacrées aux boulangeries parisiennes, à leurs savoir-faire et à leurs cadres réglementaires."
        keywords="articles, boulangeries parisiennes, levain, réglementation"
        url={baseUrl}
      />
      <section className={styles.introduction} aria-labelledby="articles-titre">
        <div className={styles.container}>
          <h1 id="articles-titre" className={styles.title}>
            Dossiers et enquêtes
          </h1>
          <p className={styles.lead}>
            Chaque article présente des recherches détaillées mêlant témoignages, données
            techniques et sources historiques. Les textes complets sont disponibles ci-dessous.
          </p>
          <div className={styles.filters} role="tablist" aria-label="Filtrer les articles">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={selectedCategory === category}
                className={`${styles.filterButton} ${
                  selectedCategory === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => handleFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.content}>
        <div className={styles.container}>
          <div className={styles.grid}>
            <div className={styles.list} role="navigation" aria-label="Liste des articles">
              {filteredArticles.map((article) => (
                <article
                  key={article.id}
                  id={article.id}
                  className={`${styles.listItem} ${
                    selectedArticle && selectedArticle.id === article.id ? styles.listItemActive : ''
                  }`}
                >
                  <button type="button" onClick={() => handleSelectArticle(article)}>
                    <h2>{article.title}</h2>
                    <p className={styles.listMeta}>
                      <span>{article.category}</span>
                      <span aria-hidden="true">•</span>
                      <time dateTime={article.date}>{article.date}</time>
                    </p>
                    <p className={styles.listExcerpt}>{article.excerpt}</p>
                  </button>
                </article>
              ))}
            </div>
            <article className={styles.detail} aria-live="polite">
              {selectedArticle && (
                <>
                  <header className={styles.detailHeader}>
                    <h2>{selectedArticle.title}</h2>
                    <p className={styles.detailMeta}>
                      <span>{selectedArticle.category}</span>
                      <span aria-hidden="true">•</span>
                      <time dateTime={selectedArticle.date}>{selectedArticle.date}</time>
                    </p>
                  </header>
                  <img
                    src={selectedArticle.image}
                    alt={selectedArticle.imageAlt}
                    className={styles.detailImage}
                  />
                  <div className={styles.detailBody}>
                    {selectedArticle.content.split('\n\n').map((paragraph, index) => (
                      <p key={index}>{paragraph}</p>
                    ))}
                  </div>
                </>
              )}
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Articles;