import React from 'react';
import SEO from '../components/SEO';
import styles from './PolitiqueCookies.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/politique-des-cookies';

const PolitiqueCookies = () => {
  return (
    <div className={styles.page}>
      <SEO
        title="Parisian Bakeries Review | Politique des Cookies"
        description="Information complète sur l'utilisation des cookies par Parisian Bakeries Review."
        keywords="cookies, consentement, politique"
        url={baseUrl}
      />
      <section className={styles.section}>
        <div className={styles.container}>
          <h1>Politique des cookies</h1>
          <p>
            Cette politique décrit les types de cookies utilisés sur le site Parisian Bakeries
            Review, leurs finalités et les moyens de gestion mis à disposition des visiteurs.
          </p>

          <h2>Définition</h2>
          <p>
            Un cookie est un petit fichier texte, sauvegardé sur le terminal de l’utilisateur, qui
            permet de mémoriser des informations utiles pour la navigation. Certains cookies sont
            obligatoires pour garantir le bon fonctionnement du site.
          </p>

          <h2>Cookies fonctionnels</h2>
          <p>
            Ils mémorisent les préférences essentielles telles que l’affichage du bandeau de
            consentement ou l’activation de l’accessibilité. Ces cookies ne peuvent pas être
            désactivés.
          </p>

          <h2>Cookies d’analyse</h2>
          <p>
            Ils enregistrent, de manière anonymisée, des données statistiques sur la fréquentation
            (pages consultées, temps de visite). Ils sont activés uniquement après accord explicite
            de l’utilisateur.
          </p>

          <h2>Paramétrage</h2>
          <p>
            Le bandeau cookies permet d’accepter, de refuser ou de personnaliser le dépôt. Les choix
            sont enregistrés pour une durée maximale de treize mois. À tout moment, l’utilisateur peut
            effacer les cookies via les paramètres de son navigateur.
          </p>

          <h2>Contact</h2>
          <p>
            Pour toute question relative à cette politique, écrire à
            redaction@parisianbakeriesreview.fr. La rédaction répondra dans les meilleurs délais.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PolitiqueCookies;