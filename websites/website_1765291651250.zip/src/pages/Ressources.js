import React from 'react';
import SEO from '../components/SEO';
import styles from './Ressources.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/ressources';

const Ressources = () => {
  return (
    <div className={styles.ressources}>
      <SEO
        title="Parisian Bakeries Review | Ressources"
        description="Sélection de ressources consacrées aux boulangeries parisiennes : ouvrages, musées, archives et associations."
        keywords="ressources boulangeries, bibliographie, musées, archives"
        url={baseUrl}
      />
      <section className={styles.headerSection}>
        <div className={styles.container}>
          <h1 className={styles.title}>Ressources pour approfondir</h1>
          <p className={styles.lead}>
            La rédaction recense des références utiles pour prolonger la compréhension de la
            boulangerie parisienne. Cette sélection est actualisée régulièrement en concertation
            avec les institutions partenaires.
          </p>
        </div>
      </section>
      <section className={styles.resourceSection}>
        <div className={styles.container}>
          <div className={styles.resourceGrid}>
            <article className={styles.resourceCard}>
              <h2>Ouvrages de référence</h2>
              <ul>
                <li>
                  <strong>« Le Pain de Paris »</strong>, sous la direction de Claire Masson. Études
                  historiques et iconographiques issues des archives municipales.
                </li>
                <li>
                  <strong>« Microbiotes des fournils »</strong>, collectif de chercheurs de l’INRAE.
                  Analyses des levains et protocoles de fermentation.
                </li>
                <li>
                  <strong>« Sociologie des commerces de proximité »</strong>, revue Territoires
                  urbains, numéro spécial consacré aux boulangeries.
                </li>
              </ul>
            </article>
            <article className={styles.resourceCard}>
              <h2>Médiathèques et archives</h2>
              <ul>
                <li>
                  <strong>Bibliothèque Forney</strong> : fonds iconographiques sur les métiers de
                  bouche et affiches de concours boulangers.
                </li>
                <li>
                  <strong>Archives de Paris</strong> : registres de corporations, plans de fours
                  municipaux et dossiers réglementaires.
                </li>
                <li>
                  <strong>Médiathèque de la Cité internationale de la gastronomie</strong> :
                  publications scientifiques, thèses et mémoires.
                </li>
              </ul>
            </article>
            <article className={styles.resourceCard}>
              <h2>Institutions et musées</h2>
              <ul>
                <li>
                  <strong>Maison du Pain d’Île-de-France</strong> : expositions et ateliers sur le
                  patrimoine meunier et boulanger.
                </li>
                <li>
                  <strong>Musée de la Boulangère parisienne</strong> : parcours historique du fournil
                  urbain, démonstrations de pétrissage.
                </li>
                <li>
                  <strong>Musée des Arts et Métiers</strong> : collection de machines boulangères,
                  pétrins historiques et fours à gueulard.
                </li>
              </ul>
            </article>
            <article className={styles.resourceCard}>
              <h2>Associations et réseaux</h2>
              <ul>
                <li>
                  <strong>Observatoire du pain francilien</strong> : groupe de recherche réunissant
                  artisans, scientifiques et urbanistes.
                </li>
                <li>
                  <strong>Collectif Levain Partagé</strong> : ateliers citoyens de transmission de
                  souches et d’éducation au goût.
                </li>
                <li>
                  <strong>Échanges Meuniers-Boulangers</strong> : plateforme de coordination entre
                  producteurs céréaliers et fournils urbains.
                </li>
              </ul>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Ressources;