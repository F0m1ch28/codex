import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contact.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/contact';

const Contact = () => {
  const [formState, setFormState] = useState({
    nom: '',
    email: '',
    organisation: '',
    message: ''
  });
  const [status, setStatus] = useState('idle');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
    setStatus('idle');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formState.nom || !formState.email || !formState.message) {
      setStatus('error');
      return;
    }
    setStatus('success');
    setFormState({
      nom: '',
      email: '',
      organisation: '',
      message: ''
    });
  };

  return (
    <div className={styles.contact}>
      <SEO
        title="Parisian Bakeries Review | Contact"
        description="Coordonnées et formulaire de contact pour joindre Parisian Bakeries Review."
        keywords="contact, rédaction, Parisian Bakeries Review"
        url={baseUrl}
      />
      <section className={styles.headerSection}>
        <div className={styles.container}>
          <h1 className={styles.title}>Contacter la rédaction</h1>
          <p className={styles.lead}>
            Les équipes répondent aux demandes de collaboration, de documentation ou
            d’interview. Les messages reçoivent une réponse personnalisée selon la nature des
            projets.
          </p>
          <div className={styles.infos}>
            <div>
              <h2>Adresse postale</h2>
              <address>
                Parisian Bakeries Review<br />
                BP 123<br />
                75006 Paris<br />
                France
              </address>
            </div>
            <div>
              <h2>Courriel</h2>
              <p>
                <a href="mailto:redaction@parisianbakeriesreview.fr">
                  redaction@parisianbakeriesreview.fr
                </a>
              </p>
              <p className={styles.note}>
                Les demandes sont traitées dans un délai moyen de cinq jours ouvrés.
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className={styles.formSection}>
        <div className={styles.container}>
          <div className={styles.formCard}>
            <h2>Formulaire</h2>
            <form onSubmit={handleSubmit} className={styles.form} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="nom">Nom et prénom</label>
                <input
                  id="nom"
                  name="nom"
                  type="text"
                  value={formState.nom}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">Adresse électronique</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formState.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="organisation">Organisation (facultatif)</label>
                <input
                  id="organisation"
                  name="organisation"
                  type="text"
                  value={formState.organisation}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  value={formState.message}
                  onChange={handleChange}
                  required
                />
              </div>
              <button type="submit" className={styles.submitButton}>
                Envoyer
              </button>
              <div className={styles.feedback} aria-live="polite">
                {status === 'success' && (
                  <p className={styles.success}>Le message a été transmis à la rédaction.</p>
                )}
                {status === 'error' && (
                  <p className={styles.error}>
                    Merci de compléter tous les champs obligatoires avant l’envoi.
                  </p>
                )}
              </div>
            </form>
          </div>
          <div className={styles.mapPlaceholder}>
            <img
              src="https://images.unsplash.com/photo-1447078806655-40579c2520d6?auto=format&fit=crop&w=900&q=80"
              alt="Rue parisienne avec une boulangerie de quartier"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;