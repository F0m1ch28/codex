import React from 'react';
import SEO from '../components/SEO';
import styles from './PolitiqueConfidentialite.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/politique-de-confidentialite';

const PolitiqueConfidentialite = () => {
  return (
    <div className={styles.page}>
      <SEO
        title="Parisian Bakeries Review | Politique de Confidentialité"
        description="Politique de confidentialité de Parisian Bakeries Review concernant les données personnelles."
        keywords="confidentialité, données personnelles, politique"
        url={baseUrl}
      />
      <section className={styles.section}>
        <div className={styles.container}>
          <h1>Politique de confidentialité</h1>
          <p>
            La présente politique détaille la manière dont Parisian Bakeries Review traite les
            données personnelles collectées via ce site. Elle s’appuie sur le Règlement général sur
            la protection des données (RGPD) et sur la législation française en vigueur.
          </p>

          <h2>Responsable du traitement</h2>
          <p>
            Parisian Bakeries Review, BP 123, 75006 Paris, France, agit en qualité de responsable du
            traitement pour les données communiquées sur le site. Les demandes relatives à la
            confidentialité peuvent être adressées à redaction@parisianbakeriesreview.fr.
          </p>

          <h2>Données collectées</h2>
          <p>
            Les formulaires disponibles recueillent les informations suivantes : nom, adresse
            électronique, organisation et contenu du message. Ces données sont transmises à la
            rédaction pour répondre aux demandes et archivées pendant une durée maximale de trois
            ans.
          </p>
          <p>
            Les cookies fonctionnels mémorisent les préférences de navigation indispensables. Des
            cookies d’analyse anonymisés peuvent être activés après consentement afin de mesurer la
            fréquentation globale.
          </p>

          <h2>Finalités et base légale</h2>
          <ul>
            <li>Gestion des messages reçus via le formulaire de contact (intérêt légitime).</li>
            <li>
              Envoi des informations éditoriales lorsque le lecteur demande à être informé
              (consentement).
            </li>
            <li>
              Production de statistiques anonymisées pour améliorer l’ergonomie du site (consentement
              préalable).
            </li>
          </ul>

          <h2>Destinataires</h2>
          <p>
            Les données sont accessibles uniquement aux membres de la rédaction. Aucun transfert
            commercial ou cession à des partenaires n’est réalisé.
          </p>

          <h2>Durée de conservation</h2>
          <p>
            Les informations issues du formulaire sont conservées jusqu’à trois ans après le dernier
            échange. Les consentements liés aux cookies sont conservés treize mois. Les adresses
            électroniques des abonnés à la lettre d’information sont supprimées sur simple demande.
          </p>

          <h2>Vos droits</h2>
          <p>
            Conformément au RGPD, chaque personne dispose d’un droit d’accès, de rectification, de
            suppression, de limitation et d’opposition. Ces droits s’exercent par courriel à
            redaction@parisianbakeriesreview.fr. Une réponse sera fournie dans un délai d’un mois.
          </p>

          <h2>Sécurité</h2>
          <p>
            Des mesures techniques (chiffrement TLS, accès restreint) et organisationnelles
            (sensibilisation de l’équipe) garantissent la confidentialité des données. En cas
            d’incident, les autorités compétentes et les personnes concernées seront informées selon
            les obligations légales.
          </p>

          <h2>Modification de la politique</h2>
          <p>
            Cette politique peut être actualisée pour tenir compte des évolutions législatives ou de
            l’organisation interne. Les modifications majeures seront annoncées sur le site.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PolitiqueConfidentialite;