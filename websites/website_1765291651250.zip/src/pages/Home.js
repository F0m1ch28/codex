import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import articlesData from '../data/articles';
import interviewsData from '../data/interviews';
import styles from './Home.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr';

const Home = () => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState('idle');

  const latestArticles = articlesData.slice(0, 3);
  const featuredInterview = interviewsData[0];

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newsletterEmail)) {
      setNewsletterStatus('error');
      return;
    }
    setNewsletterStatus('success');
    setNewsletterEmail('');
  };

  return (
    <div className={styles.home}>
      <SEO
        title="Parisian Bakeries Review | Accueil"
        description="Panorama éditorial des boulangeries parisiennes, de leurs savoir-faire, de leurs innovations et de leur rôle social."
        keywords="boulangeries parisiennes, pain artisanal, levain, baguette, patrimoine, fermentation"
        url={baseUrl}
      />

      <section className={styles.hero} aria-labelledby="hero-title">
        <div className={styles.heroContent}>
          <h1 id="hero-title" className={styles.heroTitle}>
            Observer les boulangeries parisiennes comme des lieux de transmission
          </h1>
          <p className={styles.heroSubtitle}>
            Parisian Bakeries Review documente les traditions boulangères, compare les pratiques de
            fermentation et suit l’évolution réglementaire qui façonne la baguette et ses
            interprétations contemporaines.
          </p>
        </div>
      </section>

      <section className={styles.latest} aria-labelledby="latest-title">
        <div className={styles.sectionHeader}>
          <h2 id="latest-title" className={styles.sectionTitle}>
            Dernières publications
          </h2>
          <p className={styles.sectionIntro}>
            Chaque enquête met en lumière les mécanismes culturels, techniques et sociaux qui
            façonnent les fournils parisiens.
          </p>
        </div>
        <div className={styles.articlesGrid}>
          {latestArticles.map((article) => (
            <article key={article.id} className={styles.articleCard}>
              <img src={article.image} alt={article.imageAlt} className={styles.articleImage} />
              <div className={styles.articleBody}>
                <p className={styles.articleMeta}>
                  <span>{article.category}</span>
                  <span aria-hidden="true">•</span>
                  <time dateTime={article.date}>{article.date}</time>
                </p>
                <h3 className={styles.articleTitle}>{article.title}</h3>
                <p className={styles.articleExcerpt}>{article.excerpt}</p>
                <Link className={styles.articleLink} to={`/articles#${article.id}`}>
                  Consulter l’analyse
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.researchThemes} aria-labelledby="themes-title">
        <div className={styles.sectionHeader}>
          <h2 id="themes-title" className={styles.sectionTitle}>
            Thèmes de recherche
          </h2>
          <p className={styles.sectionIntro}>
            Les axes d’étude explorent la pluralité des métiers, des quartiers et des régulations.
          </p>
        </div>
        <div className={styles.themeGrid}>
          <article className={styles.themeCard}>
            <span className={styles.themeMarker}>01</span>
            <h3 className={styles.themeTitle}>Histoire et mémoire boulangère</h3>
            <p>
              Les chronologies de fournils révèlent les migrations d’artisans, les reconstructions
              après guerre et la permanence de certaines dynasties familiales.
            </p>
          </article>
          <article className={styles.themeCard}>
            <span className={styles.themeMarker}>02</span>
            <h3 className={styles.themeTitle}>Fermentation et levain</h3>
            <p>
              Les protocoles de maturation sont comparés pour comprendre leur influence sur les
              textures, la conservation et l’identité aromatique de la baguette parisienne.
            </p>
          </article>
          <article className={styles.themeCard}>
            <span className={styles.themeMarker}>03</span>
            <h3 className={styles.themeTitle}>Réglementation et labels</h3>
            <p>
              Les textes officiels, les inspections et les concours municipaux structurent le
              quotidien des artisans et déterminent les critères de reconnaissance.
            </p>
          </article>
          <article className={styles.themeCard}>
            <span className={styles.themeMarker}>04</span>
            <h3 className={styles.themeTitle}>Rôle social des boulangeries</h3>
            <p>
              Les boulangeries servent de relais communautaires, de repères urbains et d’espaces où
              se négocient les identités alimentaires.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.quoteSection} aria-labelledby="quote-title">
        <div className={styles.quoteContainer}>
          <h2 id="quote-title" className={styles.sectionTitle}>
            Voix d’experte
          </h2>
          <blockquote className={styles.blockquote}>
            <p>{featuredInterview.quote}</p>
            <footer>
              <cite className={styles.cite}>{featuredInterview.name}</cite>
              <span className={styles.citeDetails}>{featuredInterview.role}</span>
            </footer>
          </blockquote>
        </div>
      </section>

      <section className={styles.aboutPreview} aria-labelledby="preview-title">
        <div className={styles.aboutContent}>
          <h2 id="preview-title" className={styles.sectionTitle}>
            À propos de la rédaction
          </h2>
          <p>
            Parisian Bakeries Review observe les ateliers parisiens, interroge les artisans,
            recueille des données techniques et travaille avec des historiens de l’alimentation.
            Chaque dossier s’appuie sur des visites de terrain, des sources archivistiques et des
            analyses scientifiques partagées avec les acteurs concernés.
          </p>
          <Link to="/a-propos" className={styles.aboutLink}>
            Méthodologie complète
          </Link>
        </div>
        <div className={styles.aboutImageContainer}>
          <img
            src="https://images.unsplash.com/photo-1523292562811-8fa7962a78c8?auto=format&fit=crop&w=900&q=80"
            alt="Four de boulangerie parisienne en activité"
          />
        </div>
      </section>

      <section className={styles.newsletter} aria-labelledby="newsletter-title">
        <div className={styles.newsletterInner}>
          <h2 id="newsletter-title" className={styles.sectionTitle}>
            Mise à jour éditoriale
          </h2>
          <p>
            Les lecteurs peuvent renseigner une adresse électronique afin d’être informés des
            prochains dossiers de fond. Les envois restent ponctuels et accompagnent les publications
            majeures.
          </p>
          <form className={styles.newsletterForm} onSubmit={handleNewsletterSubmit}>
            <label htmlFor="newsletter-email" className="visually-hidden">
              Adresse électronique
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              placeholder="adresse@exemple.fr"
              value={newsletterEmail}
              onChange={(event) => {
                setNewsletterEmail(event.target.value);
                setNewsletterStatus('idle');
              }}
              required
            />
            <button type="submit">Valider</button>
          </form>
          <div className={styles.newsletterFeedback} aria-live="polite">
            {newsletterStatus === 'success' && (
              <p className={styles.successMessage}>
                L’adresse a été enregistrée. Un message de confirmation sera adressé prochainement.
              </p>
            )}
            {newsletterStatus === 'error' && (
              <p className={styles.errorMessage}>
                Le format saisi ne permet pas l’enregistrement. Merci de vérifier l’adresse.
              </p>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;