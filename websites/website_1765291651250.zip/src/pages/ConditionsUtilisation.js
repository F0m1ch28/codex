import React from 'react';
import SEO from '../components/SEO';
import styles from './ConditionsUtilisation.module.css';

const baseUrl = 'https://www.parisianbakeriesreview.fr/conditions-d-utilisation';

const ConditionsUtilisation = () => {
  return (
    <div className={styles.page}>
      <SEO
        title="Parisian Bakeries Review | Conditions d'Utilisation"
        description="Conditions d'utilisation du site Parisian Bakeries Review."
        keywords="conditions d utilisation, mentions légales, site web"
        url={baseUrl}
      />
      <section className={styles.section}>
        <div className={styles.container}>
          <h1>Conditions d&apos;utilisation</h1>
          <p>
            Les présentes conditions fixent les règles applicables lors de la consultation du site
            Parisian Bakeries Review. L’accès implique l’acceptation des dispositions ci-dessous.
          </p>

          <h2>Objet</h2>
          <p>
            Le site propose des contenus éditoriaux consacrés aux boulangeries parisiennes. Ils sont
            fournis à titre informatif et peuvent être modifiés sans préavis.
          </p>

          <h2>Propriété intellectuelle</h2>
          <p>
            Les textes, photographies, graphismes et logos sont protégés par le droit d’auteur.
            Toute reproduction nécessite l’accord écrit de la rédaction. Les citations sont autorisées
            sous réserve de mentionner la source.
          </p>

          <h2>Responsabilité</h2>
          <p>
            Parisian Bakeries Review veille à la fiabilité des informations publiées. Toutefois, la
            revue ne saurait être tenue responsable des conséquences liées à une interprétation
            erronée ou à une utilisation détournée des contenus.
          </p>

          <h2>Liens externes</h2>
          <p>
            Des liens vers des sites tiers peuvent être proposés pour faciliter la recherche. La
            rédaction ne contrôle pas ces ressources et décline toute responsabilité quant à leur
            contenu.
          </p>

          <h2>Disponibilité</h2>
          <p>
            Le site est accessible 24h/24 et 7j/7 sous réserve d’interruptions pour maintenance. Les
            opérations techniques nécessaires seront planifiées afin de limiter les perturbations.
          </p>

          <h2>Modification des conditions</h2>
          <p>
            Les conditions peuvent évoluer pour intégrer des changements législatifs ou techniques.
            Les utilisateurs sont invités à les consulter régulièrement.
          </p>

          <h2>Droit applicable</h2>
          <p>
            Les présentes conditions sont soumises au droit français. En cas de litige, les
            tribunaux compétents seront ceux de Paris.
          </p>
        </div>
      </section>
    </div>
  );
};

export default ConditionsUtilisation;