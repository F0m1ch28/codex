const interviewsData = [
  {
    id: 'anne-morel',
    name: 'Anne Morel',
    role: 'Boulangère et cheffe de production, 12e arrondissement',
    image:
      'https://images.unsplash.com/photo-1585238342021-78b9dba3b914?auto=format&fit=crop&w=900&q=80',
    quote:
      '« Le levain rappelle chaque nuit que le pain dépend d’un rythme collectif, étroitement lié au quartier. »',
    summary: `L’entretien examine la manière dont Anne Morel organise le rafraîchi de son levain et comment elle coordonne son équipe autour de cycles de production étagés. Elle décrit un système de veille qui répartit les rôles entre pétrissage, façonnage et cuisson afin que chacun connaisse l’origine des farines et la maturité du ferment.

Elle insiste sur la transmission des gestes aux apprentis. Chaque nouveau membre consigne ses observations dans un carnet partagé, où sont notés les écarts de température, l’activité des bulles et les feedbacks sensoriels des clients. Ces traces écrites alimentent une discussion hebdomadaire suivie par la rédaction.

Le dialogue aborde enfin la relation avec le voisinage. Les habitantes et habitants sont invités à découvrir le fournil lors d’ateliers mensuels. Ces moments permettent de comparer les pains, de discuter des attentes gustatives et d’ajuster les protocoles sans renoncer aux exigences réglementaires.`
  },
  {
    id: 'hugo-delorme',
    name: 'Hugo Delorme',
    role: 'Historien de l’alimentation, chercheur associé à l’EHESS',
    image:
      'https://images.unsplash.com/photo-1502685104226-ee32379fefbe?auto=format&fit=crop&w=900&q=80',
    quote:
      '« La boulangerie parisienne fait coexister des héritages corporatifs et des innovations logistiques surprenantes. »',
    summary: `Le chercheur revient sur l’évolution des statuts de la boulangerie, depuis les maîtrises d’Ancien Régime jusqu’aux décrets contemporains. Il détaille les archives utilisées pour retracer l’évolution des fours, des personnels et des systèmes de distribution dans la capitale.

Hugo Delorme explique comment la modernisation des transports a transformé la logistique du pain, notamment avec la création de dépôts municipaux et de circuits nocturnes. Ces infrastructures ont influencé la morphologie des boutiques et l’organisation des ateliers.

L’entretien se conclut sur les enjeux méthodologiques. Le chercheur insiste sur l’importance de croiser sources administratives, témoignages oraux et analyses sensorielles pour comprendre la place du pain dans la ville actuelle.`
  },
  {
    id: 'leila-bensaid',
    name: 'Leïla Bensaïd',
    role: 'Sociologue urbaine, spécialiste des commerces de proximité',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80',
    quote:
      '« La boulangerie fonctionne comme une agora discrète où se relient les habitants et les réseaux associatifs. »',
    summary: `La sociologue analyse les interactions observées devant les boulangeries de trois quartiers contrastés : Belleville, Grenelle et la porte de Clignancourt. Elle montre que la configuration de la rue, la présence d’écoles ou de marchés et la densité associative influencent fortement les usages.

Les enquêtes menées avec Parisian Bakeries Review révèlent que la boulangerie peut devenir un relais d’informations locales. Les artisans jouent un rôle d’orientation, conseillent sur des actions culturelles ou associatives et acceptent parfois de collecter des dons alimentaires.

Leïla Bensaïd souligne aussi la dimension temporelle. Les rythmes d’ouverture structurent la journée de nombreux habitants, notamment les personnes âgées ou travaillant en horaires décalés. Comprendre ces cadences aide à imaginer des politiques publiques adaptées aux besoins quotidiens.`
  }
];

export default interviewsData;