import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Pied de page">
      <div className={styles.inner}>
        <div className={styles.brandColumn}>
          <p className={styles.logo}>Parisian Bakeries Review</p>
          <p className={styles.description}>
            Revue culturelle et analytique consacrée aux boulangeries parisiennes, à leur histoire,
            à leurs pratiques artisanales et à leur rôle social.
          </p>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Navigation</h3>
          <ul className={styles.linkList}>
            <li>
              <NavLink to="/" className={styles.link}>
                Accueil
              </NavLink>
            </li>
            <li>
              <NavLink to="/articles" className={styles.link}>
                Articles
              </NavLink>
            </li>
            <li>
              <NavLink to="/themes" className={styles.link}>
                Thèmes
              </NavLink>
            </li>
            <li>
              <NavLink to="/entretiens" className={styles.link}>
                Entretiens
              </NavLink>
            </li>
            <li>
              <NavLink to="/ressources" className={styles.link}>
                Ressources
              </NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Références</h3>
          <ul className={styles.linkList}>
            <li>
              <NavLink to="/a-propos" className={styles.link}>
                À Propos
              </NavLink>
            </li>
            <li>
              <NavLink to="/politique-de-confidentialite" className={styles.link}>
                Politique de Confidentialité
              </NavLink>
            </li>
            <li>
              <NavLink to="/conditions-d-utilisation" className={styles.link}>
                Conditions d&apos;Utilisation
              </NavLink>
            </li>
            <li>
              <NavLink to="/politique-des-cookies" className={styles.link}>
                Politique des Cookies
              </NavLink>
            </li>
            <li>
              <NavLink to="/contact" className={styles.link}>
                Contact
              </NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.contactColumn}>
          <h3 className={styles.columnTitle}>Coordonnées</h3>
          <address className={styles.address}>
            Parisian Bakeries Review<br />
            BP 123<br />
            75006 Paris<br />
            France
          </address>
          <p className={styles.email}>
            <a href="mailto:redaction@parisianbakeriesreview.fr" className={styles.link}>
              redaction@parisianbakeriesreview.fr
            </a>
          </p>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Parisian Bakeries Review. Tous droits réservés.</p>
      </div>
    </footer>
  );
};

export default Footer;