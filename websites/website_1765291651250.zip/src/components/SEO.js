import React from 'react';
import { Helmet } from 'react-helmet';

const SEO = ({ title, description, keywords, url }) => {
  return (
    <Helmet>
      <title>{title}</title>
      {description && <meta name="description" content={description} />}
      {keywords && <meta name="keywords" content={keywords} />}
      {url && <link rel="canonical" href={url} />}
    </Helmet>
  );
};

export default SEO;