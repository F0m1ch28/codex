import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Accueil' },
    { path: '/a-propos', label: 'À Propos' },
    { path: '/articles', label: 'Articles' },
    { path: '/themes', label: 'Thèmes' },
    { path: '/entretiens', label: 'Entretiens' },
    { path: '/ressources', label: 'Ressources' },
    { path: '/contact', label: 'Contact' }
  ];

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <a href="#contenu-principal" className={styles.skipLink}>
        Aller au contenu principal
      </a>
      <div className={styles.inner}>
        <div className={styles.logo} aria-label="Parisian Bakeries Review">
          Parisian Bakeries Review
        </div>
        <button
          type="button"
          className={styles.mobileToggle}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="navigation-principale"
        >
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
          <span className="visually-hidden">Ouvrir le menu</span>
        </button>
        <nav
          id="navigation-principale"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Navigation principale"
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                  }
                  onClick={handleLinkClick}
                  end={item.path === '/'}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      {menuOpen && <div className={styles.backdrop} aria-hidden="true" onClick={handleToggle} />}
    </header>
  );
};

export default Header;