import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'pbr_cookie_preferences';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState({
    fonctionnelles: true,
    analyses: false
  });

  useEffect(() => {
    const storedPreferences = localStorage.getItem(STORAGE_KEY);
    if (!storedPreferences) {
      setVisible(true);
    } else {
      try {
        const parsed = JSON.parse(storedPreferences);
        setPreferences(parsed);
      } catch (e) {
        setVisible(true);
      }
    }
  }, []);

  const handleAccept = () => {
    const consent = { fonctionnelles: true, analyses: true };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(consent));
    setPreferences(consent);
    setVisible(false);
  };

  const handleRefuse = () => {
    const consent = { fonctionnelles: true, analyses: false };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(consent));
    setPreferences(consent);
    setVisible(false);
  };

  const handleSave = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Bannière cookies">
      <div className={styles.content}>
        <p className={styles.text}>
          Ce site utilise des cookies fonctionnels indispensables au bon fonctionnement. Des
          cookies d’analyse anonymisés peuvent être activés pour mieux comprendre l’audience. Toutes
          les informations figurent dans la{' '}
          <a className={styles.link} href="/politique-des-cookies">
            politique des cookies
          </a>
          .
        </p>
        {showSettings && (
          <div className={styles.settings} aria-label="Paramètres de cookies">
            <label className={styles.checkboxLabel}>
              <input
                type="checkbox"
                checked
                disabled
                aria-disabled="true"
                aria-describedby="fonctionnelles-desc"
              />
              Cookies fonctionnels (obligatoires)
            </label>
            <p id="fonctionnelles-desc" className={styles.settingDescription}>
              Ces cookies garantissent la sécurité, l’accessibilité et la mémorisation des
              préférences essentielles.
            </p>
            <label className={styles.checkboxLabel}>
              <input
                type="checkbox"
                checked={preferences.analyses}
                onChange={(event) =>
                  setPreferences((prev) => ({ ...prev, analyses: event.target.checked }))
                }
              />
              Cookies d’analyse anonymisés
            </label>
            <p className={styles.settingDescription}>
              Ils permettent de mesurer la fréquentation afin d’améliorer les contenus éditoriaux.
            </p>
          </div>
        )}
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondaryBtn} onClick={handleRefuse}>
          Refuser
        </button>
        <button type="button" className={styles.primaryBtn} onClick={handleAccept}>
          Accepter
        </button>
        <button
          type="button"
          className={styles.secondaryBtn}
          onClick={() => setShowSettings((prev) => !prev)}
        >
          {showSettings ? 'Masquer' : 'Personnaliser'}
        </button>
        {showSettings && (
          <button type="button" className={styles.saveBtn} onClick={handleSave}>
            Enregistrer
          </button>
        )}
      </div>
    </div>
  );
};

export default CookieBanner;