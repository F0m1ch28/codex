document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = siteNav.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        siteNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    const acceptButton = document.querySelector('[data-cookie-accept]');
    const declineButton = document.querySelector('[data-cookie-decline]');
    const cookieStorageKey = 'springieCookieConsent';

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove('is-visible');
        }
    }

    function showCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.add('is-visible');
        }
    }

    const storedConsent = localStorage.getItem(cookieStorageKey);
    if (!storedConsent && cookieBanner) {
        showCookieBanner();
    }

    if (acceptButton) {
        acceptButton.addEventListener('click', function () {
            localStorage.setItem(cookieStorageKey, 'accepted');
            hideCookieBanner();
        });
    }

    if (declineButton) {
        declineButton.addEventListener('click', function () {
            localStorage.setItem(cookieStorageKey, 'declined');
            hideCookieBanner();
        });
    }

    const filterButtons = document.querySelectorAll('.filter-button');
    const resourceCards = document.querySelectorAll('.resource-card');

    if (filterButtons.length > 0 && resourceCards.length > 0) {
        filterButtons.forEach(function (button) {
            button.addEventListener('click', function () {
                const filter = button.getAttribute('data-filter');
                filterButtons.forEach(function (btn) {
                    btn.classList.toggle('is-active', btn === button);
                });

                resourceCards.forEach(function (card) {
                    const category = card.getAttribute('data-category');
                    const shouldShow = filter === 'all' || category === filter;
                    card.setAttribute('data-visible', shouldShow ? 'true' : 'false');
                });
            });
        });
    }

    const animatedElements = document.querySelectorAll('[data-animate]');
    if (animatedElements.length > 0) {
        const observer = new IntersectionObserver(
            function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.15 }
        );

        animatedElements.forEach(function (element) {
            observer.observe(element);
        });
    }
});