document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");
  const cookieBanner = document.getElementById("cookieBanner");
  const cookieAccept = document.getElementById("cookieAccept");
  const cookieDecline = document.getElementById("cookieDecline");
  const consentKey = "tradeTechToolsConsent";

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      const isOpen = mainNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    document.addEventListener("click", function (event) {
      if (
        !mainNav.contains(event.target) &&
        !navToggle.contains(event.target) &&
        mainNav.classList.contains("open")
      ) {
        mainNav.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const storedConsent = localStorage.getItem(consentKey);
  if (!storedConsent && cookieBanner) {
    cookieBanner.classList.add("active");
  }

  function handleConsent(value) {
    localStorage.setItem(consentKey, value);
    cookieBanner.classList.remove("active");
  }

  if (cookieAccept) {
    cookieAccept.addEventListener("click", function () {
      handleConsent("accepted");
    });
  }

  if (cookieDecline) {
    cookieDecline.addEventListener("click", function () {
      handleConsent("declined");
    });
  }
});