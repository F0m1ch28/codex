document.addEventListener("DOMContentLoaded", function () {
    const toggleButton = document.querySelector(".menu-toggle");
    const navigation = document.querySelector(".site-nav");
    if (toggleButton && navigation) {
        toggleButton.addEventListener("click", function () {
            const isOpen = navigation.classList.toggle("is-open");
            toggleButton.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });
    }

    const cookieBanner = document.querySelector("[data-cookie-banner]");
    const acceptButton = document.querySelector("[data-cookie-accept]");
    const declineButton = document.querySelector("[data-cookie-decline]");
    const storageKey = "smuttiwfjy-cookie-choice";

    function hideBanner() {
        if (cookieBanner) {
            cookieBanner.style.display = "none";
        }
    }

    function showBanner() {
        if (cookieBanner) {
            cookieBanner.style.display = "block";
        }
    }

    const savedChoice = localStorage.getItem(storageKey);
    if (!savedChoice) {
        showBanner();
    }

    if (acceptButton) {
        acceptButton.addEventListener("click", function () {
            localStorage.setItem(storageKey, "accepted");
            hideBanner();
        });
    }

    if (declineButton) {
        declineButton.addEventListener("click", function () {
            localStorage.setItem(storageKey, "declined");
            hideBanner();
        });
    }
});