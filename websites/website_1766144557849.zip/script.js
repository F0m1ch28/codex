document.addEventListener("DOMContentLoaded", function () {
  var banner = document.getElementById("cookieBanner");
  if (!banner) {
    return;
  }

  var storedChoice = localStorage.getItem("uecrCookieConsent");
  if (!storedChoice) {
    banner.style.display = "flex";
  }

  var acceptButton = document.getElementById("acceptCookies");
  var declineButton = document.getElementById("declineCookies");

  if (acceptButton) {
    acceptButton.addEventListener("click", function () {
      localStorage.setItem("uecrCookieConsent", "accepted");
      banner.style.display = "none";
    });
  }

  if (declineButton) {
    declineButton.addEventListener("click", function () {
      localStorage.setItem("uecrCookieConsent", "declined");
      banner.style.display = "none";
    });
  }
});