document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('.site-header');
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-list a');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieKey = 'feathedscxCookieChoice';

    if (header) {
        const handleScroll = () => {
            if (window.scrollY > 20) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        };
        handleScroll();
        window.addEventListener('scroll', handleScroll);
    }

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = siteNav.classList.toggle('is-open');
            navToggle.classList.toggle('active');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 1024) {
                    siteNav.classList.remove('is-open');
                    navToggle.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                siteNav.classList.remove('is-open');
                navToggle.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    if (cookieBanner) {
        const storedChoice = localStorage.getItem(cookieKey);
        if (!storedChoice) {
            cookieBanner.classList.add('active');
        }

        const cookieButtons = cookieBanner.querySelectorAll('[data-cookie-action]');
        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.getAttribute('data-cookie-action');
                localStorage.setItem(cookieKey, choice);
                cookieBanner.classList.remove('active');
                const target = button.getAttribute('href');
                setTimeout(() => {
                    window.location.href = target;
                }, 150);
            });
        });
    }
});