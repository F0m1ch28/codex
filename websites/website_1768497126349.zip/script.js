document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.getElementById("primary-nav");
    const navLinks = document.querySelectorAll(".nav-list a");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", function () {
            const isOpen = siteNav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", String(isOpen));
        });

        navLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                if (siteNav.classList.contains("is-open")) {
                    siteNav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });

        window.addEventListener("resize", function () {
            if (window.innerWidth >= 768) {
                siteNav.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedConsent = localStorage.getItem("cookieConsent");
        if (storedConsent) {
            cookieBanner.classList.add("is-hidden");
        } else {
            setTimeout(function () {
                cookieBanner.classList.add("is-visible");
            }, 600);
        }

        cookieBanner.querySelectorAll(".cookie-action").forEach(function (actionButton) {
            actionButton.addEventListener("click", function (event) {
                event.preventDefault();
                const action = actionButton.dataset.action || "declined";
                localStorage.setItem("cookieConsent", action);
                cookieBanner.classList.add("is-hidden");
                window.location.href = actionButton.getAttribute("href");
            });
        });
    }
});