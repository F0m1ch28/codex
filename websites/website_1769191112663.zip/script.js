document.addEventListener('DOMContentLoaded', function () {
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  const toast = document.getElementById('form-toast');
  const cookieBanner = document.querySelector('.cookie-banner');
  const yearTargets = document.querySelectorAll('[data-year-target]');
  const forms = document.querySelectorAll('form[data-async]');

  if (yearTargets.length) {
    const currentYear = new Date().getFullYear();
    yearTargets.forEach(el => el.textContent = currentYear);
  }

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      header.classList.toggle('nav-open');
    });

    nav.addEventListener('click', event => {
      if (event.target.closest('a')) {
        header.classList.remove('nav-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  if (forms.length) {
    forms.forEach(form => {
      form.addEventListener('submit', event => {
        event.preventDefault();
        if (toast) {
          toast.textContent = 'Message received. Redirecting to confirmation...';
          toast.classList.add('show');
        }
        setTimeout(() => {
          if (toast) {
            toast.classList.remove('show');
          }
          window.location.href = form.getAttribute('action') || 'thank-you.html';
        }, 1800);
      });
    });
  }

  if (cookieBanner) {
    const storedChoice = localStorage.getItem('haavikCookieChoice');
    if (storedChoice) {
      cookieBanner.setAttribute('hidden', '');
    }
    cookieBanner.addEventListener('click', event => {
      const button = event.target.closest('button[data-cookie-choice]');
      if (!button) return;
      const choice = button.getAttribute('data-cookie-choice');
      localStorage.setItem('haavikCookieChoice', choice);
      cookieBanner.setAttribute('hidden', '');
    });
  }
});