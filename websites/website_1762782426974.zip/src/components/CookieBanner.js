// @ts-check
import React, { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem("devlayer_cookie_consent");
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem("devlayer_cookie_consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={`${styles.banner} bg-slate-800 text-slate-100`}>
      <div className="container mx-auto flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-slate-200">
          DevLayer uses minimal cookies for session awareness and analytics that help us improve editorial guidance. Read our{" "}
          <a className="underline text-blue-400" href="/privacy">
            privacy statement
          </a>
          .
        </p>
        <button
          onClick={acceptCookies}
          className="inline-flex items-center justify-center rounded-md bg-blue-500 px-4 py-2 text-sm font-medium text-slate-900 transition hover:bg-blue-400"
        >
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;