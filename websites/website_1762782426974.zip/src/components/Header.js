// @ts-check
import React, { useState, useEffect } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import styles from "./Header.module.css";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/workflows", label: "Workflows" },
  { to: "/mindset", label: "Mindset" },
  { to: "/blog", label: "Blog" },
  { to: "/archives", label: "Archives" },
  { to: "/notes", label: "Notes" },
  { to: "/contact", label: "Contact" }
];

const Header = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  return (
    <header className={`${styles.header} bg-slate-900/90 backdrop-blur`}>
      <div className="container mx-auto flex items-center justify-between py-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-slate-900 font-bold">
            DL
          </div>
          <div className="flex flex-col">
            <span className="font-satoshi text-lg font-semibold text-slate-100">
              DevLayer
            </span>
            <span className="text-xs text-slate-400">
              Editorial Platform for Engineering Clarity
            </span>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-6">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `text-sm font-medium transition hover:text-blue-400 ${
                  isActive ? "text-blue-400" : "text-slate-200"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <button
          onClick={() => setOpen((prev) => !prev)}
          className="lg:hidden h-10 w-10 flex items-center justify-center rounded-md border border-slate-700 text-slate-100"
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          <span className={styles.hamburger}>
            <span />
            <span />
            <span />
          </span>
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-slate-800 bg-slate-900"
          >
            <ul className="flex flex-col px-4 py-4 gap-3">
              {navItems.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    className={({ isActive }) =>
                      `block rounded-md px-3 py-2 text-sm font-medium transition ${
                        isActive
                          ? "bg-blue-500/10 text-blue-400"
                          : "text-slate-200 hover:bg-slate-800"
                      }`
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;