// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const archives = [
  {
    title: "BSD System Architecture Notes",
    description:
      "A collection of historical documents on modular design that informs modern platform thinking."
  },
  {
    title: "RFC 1925 – Fundamental Truths of Networking",
    description:
      "Humorous yet insightful guidelines that still resonate with today’s distributed computing challenges."
  },
  {
    title: "LISP Machine Workstation Memos",
    description:
      "Historical material revealing early insights about developer experience and tooling ergonomics."
  },
  {
    title: "Early DevOps Handbook Drafts",
    description:
      "Observations on bridging development and operations before the term had global recognition."
  }
];

const Archives = () => (
  <>
    <Helmet>
      <title>Archives | DevLayer</title>
      <meta
        name="description"
        content="DevLayer archives feature historical computing references, RFC retrospectives, and open standard documentation."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Archives</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        We maintain a living archive of historical computing resources that continue to shape modern developer workflows and platform engineering practices.
      </p>
      <div className="mt-10 grid gap-8 md:grid-cols-2">
        {archives.map((item) => (
          <div key={item.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
            <h2 className="text-xl font-semibold text-slate-100">{item.title}</h2>
            <p className="mt-3 text-sm text-slate-400">{item.description}</p>
          </div>
        ))}
      </div>
    </section>
  </>
);

export default Archives;