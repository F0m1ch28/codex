// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const queueItems = [
  {
    title: "Designing Sociotechnical Systems",
    summary:
      "Exploring how organizational structures and technology decisions influence each other in platform engineering.",
    tags: ["platform engineering", "systems thinking"]
  },
  {
    title: "The Science of Flow in Remote Teams",
    summary:
      "Investigating research on attention, ritual design, and collaborative tools supporting developer focus.",
    tags: ["developer workflows", "engineering psychology"]
  },
  {
    title: "Resilience Patterns for Distributed Computing",
    summary:
      "Curating studies on failover strategies, chaos drills, and adaptive automation.",
    tags: ["cloud infrastructure", "distributed computing"]
  }
];

const Queue = () => (
  <>
    <Helmet>
      <title>Reading Queue | DevLayer</title>
      <meta
        name="description"
        content="DevLayer’s reading queue highlights upcoming research across developer workflows, software systems, and engineering psychology."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Reading Queue</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        A curated list of sources currently under review by the DevLayer editorial team. We share summaries to inspire your own exploration.
      </p>
      <div className="mt-10 space-y-6">
        {queueItems.map((item) => (
          <div key={item.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
            <h2 className="text-xl font-semibold text-slate-100">{item.title}</h2>
            <p className="mt-3 text-sm text-slate-400">{item.summary}</p>
            <div className="mt-4 flex flex-wrap gap-2 text-xs uppercase tracking-widest text-blue-400">
              {item.tags.map((tag) => (
                <span key={tag} className="rounded-full border border-blue-400/40 px-3 py-1">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  </>
);

export default Queue;