// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const services = [
  {
    title: "Platform Narrative Programs",
    description:
      "Long-form editorial programs weaving system diagrams, release plans, and operational metrics into a cohesive storyline for stakeholders."
  },
  {
    title: "Workflow Diagnostics",
    description:
      "Collaborative audits of developer workflows with documented opportunities for focus, automation, and knowledge sharing."
  },
  {
    title: "Knowledge Garden Design",
    description:
      "Information architecture for internal portals, ensuring documentation is discoverable, versioned, and accessible."
  },
  {
    title: "Incident Storycraft",
    description:
      "Structured retrospectives that transform recovery data into empathetic, educational artifacts."
  },
  {
    title: "Research Summaries",
    description:
      "Executive-ready briefs condensing technical research, distributed computing trends, and tooling insights."
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>DevLayer Services | Editorial Programs for Engineering Teams</title>
      <meta
        name="description"
        content="Explore DevLayer’s editorial services including platform narrative programs, workflow diagnostics, knowledge garden design, and incident storycraft."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Services</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        DevLayer delivers editorial services that bridge technical mastery and human understanding. Our programs are tailored to your platform maturity, communication rhythms, and engineering psychology.
      </p>

      <div className="mt-12 grid gap-8 md:grid-cols-2">
        {services.map((service) => (
          <div
            key={service.title}
            className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8 hover:border-blue-400/40 transition"
          >
            <h2 className="text-xl font-semibold text-slate-100">
              {service.title}
            </h2>
            <p className="mt-3 text-sm text-slate-400">{service.description}</p>
          </div>
        ))}
      </div>

      <div className="mt-12 rounded-3xl border border-blue-500/30 bg-blue-500/10 p-10">
        <h2 className="text-2xl font-semibold text-slate-100">Process Overview</h2>
        <ol className="mt-6 space-y-4 text-sm text-slate-200">
          <li>
            <span className="text-blue-400 font-medium">Discovery:</span> collaborative scoping conversations with engineering and product partners.
          </li>
          <li>
            <span className="text-blue-400 font-medium">Mapping:</span> inventory of systems, workflows, documents, and stakeholders.
          </li>
          <li>
            <span className="text-blue-400 font-medium">Storycraft:</span> iterative drafts with research references and supporting visuals.
          </li>
          <li>
            <span className="text-blue-400 font-medium">Activation:</span> enablement sessions that help teams adopt new documentation practices.
          </li>
        </ol>
      </div>
    </section>
  </>
);

export default Services;