// @ts-check
import React from "react";
import { useLocation, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";

const ContactThanks = () => {
  const location = useLocation();
  const name = location.state?.name ?? "there";

  return (
    <>
      <Helmet>
        <title>Thank You | DevLayer Contact Confirmation</title>
        <meta
          name="description"
          content="Thank you for reaching out to DevLayer. Our team will respond promptly to discuss your editorial requirements."
        />
      </Helmet>
      <section className="container mx-auto px-4 py-20 lg:py-32 text-center">
        <div className="mx-auto max-w-xl rounded-3xl border border-blue-500/30 bg-blue-500/10 px-8 py-16">
          <h1 className="font-satoshi text-4xl text-slate-100">Thank you, {name}.</h1>
          <p className="mt-4 text-slate-200">
            Your message is on its way to our editorial inbox. A DevLayer editor will respond soon to continue the conversation.
          </p>
          <p className="mt-4 text-sm text-slate-300">
            If you need to add more detail, email us anytime at{" "}
            <a className="text-blue-200" href="mailto:editorial@devlayer.ca">
              editorial@devlayer.ca
            </a>.
          </p>
          <Link
            to="/"
            className="mt-8 inline-flex items-center justify-center rounded-md bg-slate-900 px-6 py-3 text-sm font-semibold text-blue-200 border border-blue-400/40 hover:bg-blue-500/10"
          >
            Return Home
          </Link>
        </div>
      </section>
    </>
  );
};

export default ContactThanks;