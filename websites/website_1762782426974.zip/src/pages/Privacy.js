// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Statement | DevLayer</title>
      <meta
        name="description"
        content="Learn how DevLayer handles cookies, analytics, data processing, third-party services, and user rights."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Privacy Statement</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        DevLayer respects your privacy. We collect only the information necessary to improve our platform and maintain responsible editorial relationships.
      </p>

      <div className="mt-10 space-y-8 text-sm text-slate-400">
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Cookies</h2>
          <p className="mt-3">
            Our website uses session cookies to remember your preferences. You may disable cookies in your browser; however, some interactive features may operate differently.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Analytics</h2>
          <p className="mt-3">
            We rely on privacy-conscious analytics to understand readership patterns. Data is aggregated and does not identify individual visitors.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Data Processing</h2>
          <p className="mt-3">
            Contact form submissions are used to respond to inquiries. We retain communications only as long as necessary for collaboration or legal obligations.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">Third-Party Services</h2>
          <p className="mt-3">
            DevLayer may use secure third-party services for email delivery and hosting. We ensure those providers adhere to robust data protection standards.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold text-slate-100">User Rights</h2>
          <p className="mt-3">
            You may request access to, correction of, or deletion of your personal data by contacting
            {" "}
            <a href="mailto:privacy@devlayer.ca" className="text-blue-300">
              privacy@devlayer.ca
            </a>.
          </p>
        </section>
      </div>
    </section>
  </>
);

export default Privacy;