// @ts-check
import React from "react";
import { Helmet } from "react-helmet-async";

const topics = [
  {
    title: "Developer Cognition",
    description:
      "We explore how mental models, memory scaffolds, and narrative techniques shape the way developers interpret complex systems."
  },
  {
    title: "Burnout Prevention",
    description:
      "Editorial frameworks that promote recovery practices, boundaries, and supportive rituals within engineering organizations."
  },
  {
    title: "Communication Practices",
    description:
      "Guidelines for asynchronous updates, proposal writing, and meeting architecture that respect attention."
  },
  {
    title: "Focus Strategies",
    description:
      "Research-informed recommendations on deep work scheduling, knowledge gardens, and signal hygiene."
  }
];

const Mindset = () => (
  <>
    <Helmet>
      <title>Developer Mindset | DevLayer</title>
      <meta
        name="description"
        content="DevLayer’s mindset essays examine developer cognition, burnout prevention, communication practices, and focus strategies."
      />
    </Helmet>
    <section className="container mx-auto px-4 py-16 lg:py-24">
      <h1 className="font-satoshi text-4xl text-slate-100">Developer Mindset</h1>
      <p className="mt-4 text-slate-300 max-w-3xl">
        Editorial research that champions the human side of engineering, emphasizing psychological safety, attention management, and meaningful collaboration.
      </p>
      <div className="mt-10 grid gap-8 md:grid-cols-2">
        {topics.map((topic) => (
          <article key={topic.title} className="rounded-3xl border border-slate-800 bg-slate-900/60 p-8">
            <h2 className="text-xl font-semibold text-slate-100">{topic.title}</h2>
            <p className="mt-3 text-sm text-slate-400">{topic.description}</p>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Mindset;