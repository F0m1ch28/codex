import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Docenti.module.css';

const teachers = [
  {
    name: 'Federica Bianchi',
    role: 'Head of SEO & Analytics',
    bio: 'Specialista in SEO tecnica per e-commerce e portali editoriali. Coordina audit strutturali e strategie di contenuto.',
    image: 'https://picsum.photos/400/400?random=51'
  },
  {
    name: 'Marco Ferri',
    role: 'Lead Facebook Ads Strategist',
    bio: 'Consulente per brand fashion e retail. Esperto di pubblicità targetizzata, funnel e creatività data-driven.',
    image: 'https://picsum.photos/400/400?random=52'
  },
  {
    name: 'Sara Lombardi',
    role: 'Senior Front-end Developer',
    bio: 'Sviluppatrice front-end con focus su React, performance e accessibilità. Guida il corso coding.',
    image: 'https://picsum.photos/400/400?random=53'
  },
  {
    name: 'Daniele Moretti',
    role: 'Marketing Automation Specialist',
    bio: 'Progetta sistemi di nurturing multi-canale e integra dati CRM con campagne paid.',
    image: 'https://picsum.photos/400/400?random=54'
  },
  {
    name: 'Chiara Ricci',
    role: 'Content Strategy Lead',
    bio: 'Coordina progetti editoriali e storytelling per brand B2B e B2C con approccio SEO-oriented.',
    image: 'https://picsum.photos/400/400?random=55'
  },
  {
    name: 'Luca Rinaldi',
    role: 'Data Analyst',
    bio: 'Trasforma dati complessi in dashboard utili per decisioni di marketing digitale.',
    image: 'https://picsum.photos/400/400?random=56'
  }
];

function Docenti() {
  return (
    <>
      <Helmet>
        <title>Docenti | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Conosci il team docenti di Digitalized Master Academy: esperti di SEO, pubblicità targetizzata, corso coding e social media marketing."
        />
        <meta
          name="keywords"
          content="docenti SEO, docenti marketing digitale, social media marketing, programmazione, pubblicità targetizzata"
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Docenti</p>
            <h1>Professionisti del digitale al tuo fianco</h1>
            <p>
              Il nostro team è composto da specialisti attivi in agenzie, startup e aziende corporate.
              Portano in aula best practice, casi reali e strumenti concreti per guidare progetti digitali.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.grid}>
              {teachers.map((teacher) => (
                <article className={styles.card} key={teacher.name}>
                  <div className={styles.imageWrapper}>
                    <img src={teacher.image} alt={`Docente ${teacher.name}`} loading="lazy" />
                  </div>
                  <div className={styles.info}>
                    <h2>{teacher.name}</h2>
                    <span>{teacher.role}</span>
                    <p>{teacher.bio}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default Docenti;