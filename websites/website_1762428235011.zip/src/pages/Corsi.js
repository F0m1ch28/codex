import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Corsi.module.css';

const modules = [
  {
    title: 'SEO Strategy Lab',
    description:
      'Dal technical SEO al content marketing: impari a creare strategie organiche scalabili per il mercato italiano.',
    highlights: [
      'Site audit con strumenti professionali',
      'Keyword research avanzata e cluster tematici',
      'Dashboard di monitoraggio e KPI'
    ]
  },
  {
    title: 'Meta Ads Intensive',
    description:
      'Approfondisci la gestione di Facebook Ads con campagne full funnel, ottimizzazioni e framework di test.',
    highlights: [
      'Impostazione Business Manager e conversion API',
      'Creatività dinamiche e personalizzazione delle audience',
      'Misurazione incrementale e analisi dei risultati'
    ]
  },
  {
    title: 'Coding Essentials per Marketer',
    description:
      'Integra elementi di programmazione front-end e tracking nei tuoi progetti di marketing digitale.',
    highlights: [
      'Componenti React e CSS Modules per landing page',
      'Implementazione tag e script analytics',
      'Automazioni con strumenti no-code e API'
    ]
  },
  {
    title: 'Social Media Growth',
    description:
      'Costruisci una strategia social cross-platform con focus su Instagram marketing e community management.',
    highlights: [
      'Piano editoriale e workflow di approvazione',
      'Storytelling visivo e metriche di engagement',
      'Integrazione tra organico e campagne paid'
    ]
  }
];

function Corsi() {
  return (
    <>
      <Helmet>
        <title>Corsi Digitali | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Scopri i corsi di Digitalized Master Academy: SEO, social media marketing, programmazione e pubblicità targetizzata per professionisti digitali in Italia."
        />
        <meta
          name="keywords"
          content="corsi online Italia, formazione digitale, SEO, social media marketing, programmazione, pubblicità targetizzata"
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Offerta formativa</p>
            <h1>Corsi digitali per guidare progetti di marketing e tecnologia</h1>
            <p>
              Dalla SEO al corso coding, dalla pubblicità targetizzata al social media marketing,
              i nostri percorsi uniscono teoria, pratica e mentoring per accompagnarti verso risultati concreti.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.modulesGrid}>
              {modules.map((module) => (
                <article className={styles.moduleCard} key={module.title}>
                  <h2>{module.title}</h2>
                  <p>{module.description}</p>
                  <ul>
                    {module.highlights.map((highlight) => (
                      <li key={highlight}>{highlight}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.resourcesSection} section-spacing`}>
          <div className="container">
            <div className={styles.resourcesGrid}>
              <div>
                <h2>Strumenti inclusi</h2>
                <p>
                  Accedi a template, dashboard analytics, sandbox di sviluppo web, framework per campagne Facebook Ads e checklist SEO da applicare ai tuoi progetti.
                </p>
              </div>
              <ul>
                <li>Workspace Notion per organizzare attività e materiali.</li>
                <li>Accesso a strumenti di keyword research e analisi SERP.</li>
                <li>Template per report di social media marketing e advertising.</li>
                <li>Repository Git con esempi di codice e componenti riutilizzabili.</li>
              </ul>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default Corsi;