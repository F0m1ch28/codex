import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './TerminiCondizioni.module.css';

function TerminiCondizioni() {
  return (
    <>
      <Helmet>
        <title>Termini e Condizioni | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Leggi i termini e condizioni d'uso di Digitalized Master Academy, piattaforma di corsi online Italia su marketing digitale e programmazione."
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Legale</p>
            <h1>Termini e condizioni d'uso</h1>
            <p>
              Questi termini disciplinano l’accesso e l’utilizzo della piattaforma Digitalized Master Academy.
              Utilizzando i nostri servizi accetti integralmente le condizioni riportate.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.content}>
              <h2>1. Definizioni</h2>
              <p>
                “Piattaforma” indica l’ambiente online Digitalized Master Academy. “Utente” è la persona che accede ai contenuti formativi.
              </p>

              <h2>2. Condizioni di accesso</h2>
              <p>
                L’accesso ai corsi online Italia è personale e non trasferibile. Ogni account deve essere utilizzato da un singolo utente autorizzato.
              </p>

              <h2>3. Proprietà intellettuale</h2>
              <p>
                I contenuti didattici, inclusi materiali su SEO, social media marketing, programmazione e pubblicità targetizzata,
                sono protetti da copyright e non possono essere distribuiti senza consenso scritto.
              </p>

              <h2>4. Supporto e assistenza</h2>
              <p>
                Forniamo servizi di assistenza agli utenti registrati tramite il canale dedicato e la community.
              </p>

              <h2>5. Limitazione di responsabilità</h2>
              <p>
                L’Accademia non è responsabile di eventuali danni indiretti derivanti dall’uso improprio della piattaforma o dei contenuti.
              </p>

              <h2>6. Modifiche ai termini</h2>
              <p>
                Possiamo aggiornare i presenti termini per adeguarli a nuove normative o funzioni della piattaforma.
                Le modifiche saranno comunicate tramite avviso in piattaforma.
              </p>

              <h2>7. Legge applicabile</h2>
              <p>
                I presenti termini sono regolati dalla legge italiana. Per ogni controversia è competente il foro di Prato.
              </p>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default TerminiCondizioni;