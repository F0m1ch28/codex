import React, { useEffect, useState, useMemo } from 'react';
import { NavLink } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Studenti formati', value: 1250, suffix: '+' },
  { label: 'Tasso di completamento', value: 85, suffix: '%' },
  { label: 'Project work conclusi', value: 50, suffix: '+' },
  { label: 'Docenti specialisti', value: 12, suffix: '' }
];

const testimonials = [
  {
    quote:
      'Il percorso su SEO e social media marketing è stato strutturato con casi reali italiani. Ho migliorato le mie campagne di Facebook Ads in poche settimane.',
    name: 'Giovanni R.',
    role: 'Digital Strategist, Milano'
  },
  {
    quote:
      'La combinazione tra corso coding e sviluppo web moderno è perfetta per chi viene dal marketing. Le lezioni sono chiare e subito applicabili.',
    name: 'Laura M.',
    role: 'Marketing Specialist, Torino'
  },
  {
    quote:
      'Docenti preparati e tutoraggio continuo. Ho lanciato campagne di pubblicità targetizzata su Instagram marketing seguendo il programma passo-passo.',
    name: 'Chiara P.',
    role: 'Social Media Manager, Firenze'
  }
];

const projects = [
  {
    id: 1,
    title: 'Audit SEO per e-commerce moda',
    category: 'SEO',
    description:
      'Analisi tecnica e keyword research per rafforzare la visibilità organica di un brand italiano.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    id: 2,
    title: 'Dashboard Facebook Ads',
    category: 'Pubblicità',
    description:
      'Ottimizzazione di campagne di pubblicità targetizzata con metriche personalizzate.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    id: 3,
    title: 'Landing page sviluppo web',
    category: 'Sviluppo',
    description:
      'Prototipazione e coding front-end per lead generation multicanale.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    id: 4,
    title: 'Strategia Instagram marketing',
    category: 'Social',
    description:
      'Workflow editoriale e automazioni per community management.',
    image: 'https://picsum.photos/1200/800?random=44'
  },
  {
    id: 5,
    title: 'Piano contenuti blog SEO',
    category: 'SEO',
    description:
      'Calendario in ottica long tail per posizionamento competitivo su corsi online Italia.',
    image: 'https://picsum.photos/1200/800?random=45'
  }
];

const faqItems = [
  {
    question: 'Qual è la durata media del programma?',
    answer:
      'Il programma principale prevede 16 settimane di formazione digitale intensiva, con moduli su SEO, social media marketing e sviluppo web pratico.'
  },
  {
    question: 'Come funzionano i project work?',
    answer:
      'Ogni modulo include project work guidati su campagne di Facebook Ads, analisi SEO e coding. I docenti forniscono feedback asincrono e sessioni live Q&A.'
  },
  {
    question: 'Riceverò supporto personalizzato?',
    answer:
      'Sì, il nostro team docenti offre mentoring dedicato attraverso sessioni di tutoraggio e community Slack riservata.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Trend SEO 2024: come preparare la tua strategia',
    date: '12 Marzo 2024',
    excerpt:
      'Dalla ricerca semantica alle ottimizzazioni Core Web Vitals: scopri le priorità per la tua crescita organica in Italia.',
    link: '/blog/trend-seo-2024'
  },
  {
    id: 2,
    title: 'Segmentazione avanzata per pubblicità targetizzata',
    date: '02 Marzo 2024',
    excerpt:
      'Integra dati di prima parte per costruire audience su Facebook Ads e Instagram marketing con maggiore precisione.',
    link: '/blog/pubblicita-targetizzata'
  },
  {
    id: 3,
    title: 'Perché imparare coding potenzia il marketing digitale',
    date: '22 Febbraio 2024',
    excerpt:
      'Conoscere HTML, CSS e JavaScript facilita la collaborazione tra marketing e sviluppo web e velocizza i test.',
    link: '/blog/coding-e-marketing'
  }
];

function Home() {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Tutti');
  const [openFaq, setOpenFaq] = useState(null);

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Tutti') return projects;
    return projects.filter((project) => project.category === projectFilter || (projectFilter === 'Social' && project.category === 'Social'));
  }, [projectFilter]);

  useEffect(() => {
    const timers = statsData.map((stat, index) => {
      const target = stat.value;
      const duration = 1800;
      const frameRate = 60;
      const totalFrames = Math.round((duration / 1000) * frameRate);
      let currentFrame = 0;

      const counterTimer = setInterval(() => {
        currentFrame += 1;
        const progress = currentFrame / totalFrames;
        const easeProgress = Math.min(1, progress);
        setCounters((prev) => {
          const next = [...prev];
          next[index] = Math.floor(target * easeProgress);
          return next;
        });
        if (currentFrame === totalFrames) {
          clearInterval(counterTimer);
        }
      }, 1000 / frameRate);

      return counterTimer;
    });

    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <Helmet>
        <title>Digitalized Master Academy | Formazione Digitale Avanzata</title>
        <meta
          name="description"
          content="Trasforma la tua carriera con i corsi online Italia di Digitalized Master Academy: SEO, social media marketing, corso coding e pubblicità targetizzata."
        />
        <meta
          name="keywords"
          content="corsi online Italia, formazione digitale, SEO, corso coding, social media marketing, pubblicità targetizzata, sviluppo web, Facebook Ads, Instagram marketing"
        />
      </Helmet>
      <article className={styles.home}>
        <section className={styles.hero}>
          <div className={styles.heroOverlay} />
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Studenti che lavorano a progetti digitali su laptop"
            className={styles.heroImage}
            loading="eager"
          />
          <div className={styles.heroContent}>
            <p className={styles.heroKicker}>Piattaforma Educativa Online</p>
            <h1 className={styles.heroTitle}>Trasforma la Tua Carriera Digitale</h1>
            <p className={styles.heroSubtitle}>
              Master specialistico in SEO, pubblicità targetizzata, social media marketing e sviluppo web.
              Percorsi guidati, tutoring continuo e project work reali per il mercato italiano.
            </p>
            <div className={styles.heroActions}>
              <NavLink to="/corsi" className="btn btn-primary">
                Scopri i corsi
              </NavLink>
              <NavLink to="/programma" className="btn btn-outline">
                Guarda il programma
              </NavLink>
            </div>
          </div>
        </section>

        <section className={styles.stats} aria-label="Risultati raggiunti">
          <div className="container">
            <div className={styles.statsGrid}>
              {statsData.map((stat, index) => (
                <div className={styles.statCard} key={stat.label}>
                  <span className={styles.statValue}>
                    {counters[index]}
                    {stat.suffix}
                  </span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section-spacing" id="intro">
          <div className="container">
            <div className={styles.introGrid}>
              <div>
                <p className="section-kicker">Chi Siamo</p>
                <h2 className="section-title">Una scuola digitale nata per i professionisti in evoluzione</h2>
              </div>
              <div className={styles.introContent}>
                <p>
                  Digitalized Master Academy è la piattaforma italiana che unisce strategia e pratica.
                  Creiamo percorsi formativi verticali su SEO, corso coding orientato al marketing e campagne di Facebook Ads
                  per rendere i nostri studenti pronti ad agire. Ogni modulo è pensato per accompagnarti nello sviluppo di competenze digitali realmente spendibili.
                </p>
                <ul className={styles.introList}>
                  <li>Sessioni live, laboratori su dashboard analytics e project work su casi aziendali.</li>
                  <li>Library aggiornata con materiali video, template, checklist e guide operative.</li>
                  <li>Comunità di professionisti in Italia per networking e confronto continuo.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="section-spacing" id="corsi">
          <div className="container">
            <p className="section-kicker">I nostri corsi</p>
            <h2 className="section-title">Percorsi specialistici per la tua formazione digitale</h2>
            <div className={styles.coursesGrid}>
              <article className={styles.courseCard}>
                <h3>Master in Pubblicità Targetizzata</h3>
                <p>
                  Impara a progettare campagne di Facebook Ads e Instagram marketing con segmentazione avanzata, creatività data-driven e reportistica chiara.
                </p>
                <ul>
                  <li>Framework per funnel awareness & consideration</li>
                  <li>Audience building e automazioni CRM</li>
                  <li>Analisi KPI e ottimizzazioni in tempo reale</li>
                </ul>
              </article>
              <article className={styles.courseCard}>
                <h3>Corso Coding per Marketer</h3>
                <p>
                  Collega marketing e programmazione: HTML5, CSS modulare, introduzione a JavaScript e strumenti per testare landing e tracking.
                </p>
                <ul>
                  <li>Set up tracciamenti e tag dinamici</li>
                  <li>Componenti front-end responsive</li>
                  <li>Workflow con team di sviluppo web</li>
                </ul>
              </article>
              <article className={styles.courseCard}>
                <h3>Strategie di Social Media Marketing</h3>
                <p>
                  Costruisci un piano editoriale omnicanale, sfrutta i dati per ottimizzare contenuti e integra i canali organici con campagne paid.
                </p>
                <ul>
                  <li>Definizione tone of voice e community management</li>
                  <li>Calendarizzazione e strumenti di publishing</li>
                  <li>Reportistica integrata tra organico e paid</li>
                </ul>
              </article>
            </div>
          </div>
        </section>

        <section className={`${styles.processSection} section-spacing`} id="process">
          <div className="container">
            <p className="section-kicker">Come funziona</p>
            <h2 className="section-title">Un percorso step-by-step per crescere con metodo</h2>
            <div className={styles.processGrid}>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>01</span>
                <h3>Assessment iniziale</h3>
                <p>Analizziamo competenze e obiettivi per costruire un piano personalizzato.</p>
              </div>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>02</span>
                <h3>Learning path guidato</h3>
                <p>Moduli video, esercitazioni pratiche e materiali scaricabili sempre disponibili.</p>
              </div>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>03</span>
                <h3>Project work reali</h3>
                <p>Lavori su casi studio di SEO, social media marketing e sviluppo web.</p>
              </div>
              <div className={styles.processStep}>
                <span className={styles.stepNumber}>04</span>
                <h3>Mentoring e networking</h3>
                <p>Sessioni live con docenti, feedback puntuali e community italiana attiva.</p>
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.benefitsSection} section-spacing`}>
          <div className="container">
            <p className="section-kicker">Perché sceglierci</p>
            <h2 className="section-title">Vantaggi competitivi per professionisti digitali</h2>
            <div className={styles.benefitsGrid}>
              <div className={styles.benefitCard}>
                <h3>Metodologia pratica</h3>
                <p>Ogni lezione collega teoria e casi reali, con strumenti aggiornati al mercato italiano.</p>
              </div>
              <div className={styles.benefitCard}>
                <h3>Mentor esperti</h3>
                <p>Docenti attivi in agenzie e aziende tech guidano le tue sperimentazioni.</p>
              </div>
              <div className={styles.benefitCard}>
                <h3>Career coaching</h3>
                <p>Supporto su portfolio, colloqui e posizionamento professionale nel settore digitale.</p>
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.testimonialsSection} section-spacing`} aria-label="Testimonianze studenti">
          <div className="container">
            <p className="section-kicker">Testimonianze</p>
            <h2 className="section-title">Esperienze di chi ha già trasformato la propria carriera</h2>
            <div className={styles.testimonialCarousel}>
              {testimonials.map((item, index) => (
                <blockquote
                  key={item.name}
                  className={`${styles.testimonialCard} ${
                    index === activeTestimonial ? styles.testimonialActive : ''
                  }`}
                >
                  <p>“{item.quote}”</p>
                  <footer>
                    <span className={styles.testimonialName}>{item.name}</span>
                    <span className={styles.testimonialRole}>{item.role}</span>
                  </footer>
                </blockquote>
              ))}
              <div className={styles.testimonialControls}>
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    type="button"
                    className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                    aria-label={`Mostra testimonianza ${index + 1}`}
                    onClick={() => setActiveTestimonial(index)}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.teamSection} section-spacing`} id="team">
          <div className="container">
            <p className="section-kicker">Team Collaborativo</p>
            <h2 className="section-title">Docenti e mentor che vivono il digitale ogni giorno</h2>
            <div className={styles.teamGrid}>
              {[
                {
                  name: 'Federica Bianchi',
                  role: 'Head of SEO & Analytics',
                  image: 'https://picsum.photos/400/400?random=21'
                },
                {
                  name: 'Marco Ferri',
                  role: 'Lead Facebook Ads Strategist',
                  image: 'https://picsum.photos/400/400?random=22'
                },
                {
                  name: 'Sara Lombardi',
                  role: 'Senior Front-end Developer',
                  image: 'https://picsum.photos/400/400?random=23'
                }
              ].map((member) => (
                <article className={styles.teamCard} key={member.name}>
                  <div className={styles.teamImageWrapper}>
                    <img src={member.image} alt={`Docente ${member.name}`} loading="lazy" />
                  </div>
                  <div>
                    <h3>{member.name}</h3>
                    <p>{member.role}</p>
                  </div>
                </article>
              ))}
            </div>
            <div className={styles.teamCta}>
              <NavLink to="/docenti" className="btn btn-outline">
                Conosci tutti i docenti
              </NavLink>
            </div>
          </div>
        </section>

        <section className={`${styles.projectsSection} section-spacing`} id="projects">
          <div className="container">
            <p className="section-kicker">Project Work</p>
            <div className={styles.projectsHeader}>
              <h2 className="section-title">Esperienze applicative su progetti reali</h2>
              <div className={styles.filterGroup} role="group" aria-label="Filtra progetti">
                {['Tutti', 'SEO', 'Pubblicità', 'Sviluppo', 'Social'].map((filter) => (
                  <button
                    key={filter}
                    type="button"
                    className={`${styles.filterButton} ${
                      projectFilter === filter ? styles.filterActive : ''
                    }`}
                    onClick={() => setProjectFilter(filter)}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.projectsGrid}>
              {filteredProjects.map((project) => (
                <article className={styles.projectCard} key={project.id}>
                  <div className={styles.projectImageWrapper}>
                    <img src={project.image} alt={project.title} loading="lazy" />
                  </div>
                  <div className={styles.projectContent}>
                    <span className={styles.projectCategory}>{project.category}</span>
                    <h3>{project.title}</h3>
                    <p>{project.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.faqSection} section-spacing`} id="faq">
          <div className="container">
            <p className="section-kicker">FAQ</p>
            <h2 className="section-title">Domande frequenti</h2>
            <div className={styles.faqList}>
              {faqItems.map((item, index) => (
                <div className={styles.faqItem} key={item.question}>
                  <button
                    className={styles.faqQuestion}
                    onClick={() => setOpenFaq((prev) => (prev === index ? null : index))}
                    aria-expanded={openFaq === index}
                  >
                    {item.question}
                    <span className={styles.faqIcon}>{openFaq === index ? '−' : '+'}</span>
                  </button>
                  {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.blogSection} section-spacing`} id="blog">
          <div className="container">
            <p className="section-kicker">Insight dal blog</p>
            <h2 className="section-title">Aggiornati sulle novità del marketing digitale</h2>
            <div className={styles.blogGrid}>
              {blogPosts.map((post) => (
                <article className={styles.blogCard} key={post.id}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href={post.link} className={styles.blogLink}>
                    Continua a leggere →
                  </a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.finalCta} section-spacing`} id="cta">
          <div className="container">
            <div className={styles.finalCtaCard}>
              <div>
                <p className="section-kicker">Pronto a iniziare?</p>
                <h2>Inizia oggi il tuo percorso con Digitalized Master Academy</h2>
                <p>
                  Costruisci con noi il tuo piano di crescita su SEO, programmazione front-end,
                  pubblicità targetizzata e social media marketing. Il digitale è la tua prossima opportunità.
                </p>
              </div>
              <div className={styles.finalCtaActions}>
                <NavLink to="/contatti" className="btn btn-primary">
                  Prenota un colloquio informativo
                </NavLink>
                <NavLink to="/programma" className="btn btn-outline">
                  Scarica il programma completo
                </NavLink>
              </div>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default Home;