import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programma.module.css';

const schedule = [
  {
    week: 'Settimane 1-2',
    focus: 'Fondamenti e mindset digitale',
    points: [
      'Introduzione alla strategia digitale e ai framework OKR',
      'Impostazione strumenti di project management e analytics',
      'Workshop: analisi SWOT digitale per un brand italiano'
    ]
  },
  {
    week: 'Settimane 3-6',
    focus: 'SEO & Content Strategy',
    points: [
      'Ricerca keyword, clustering tematico e architettura informativa',
      'Ottimizzazione tecnica: Core Web Vitals, schema, pagine dinamiche',
      'Project work: piano editoriale SEO e dashboard reportistica'
    ]
  },
  {
    week: 'Settimane 7-10',
    focus: 'Social Media Marketing & Advertising',
    points: [
      'Framework per Instagram marketing e community management',
      'Pianificazione e test di campagne Meta Ads con pubblicità targetizzata',
      'Analisi performance con metriche omnicanale'
    ]
  },
  {
    week: 'Settimane 11-14',
    focus: 'Sviluppo Web & Tracking',
    points: [
      'Corso coding: componenti React, CSS Modules e responsive design',
      'Implementazione pixel, tag server-side e strumenti di misurazione',
      'Project work: landing page conversione con integrazione CRM'
    ]
  },
  {
    week: 'Settimane 15-16',
    focus: 'Capstone Project e Career Coaching',
    points: [
      'Sviluppo progetto completo con presentazione finale',
      'Sessioni di feedback con docenti e revisione portfolio',
      'Career lab: posizionamento professionale e storytelling'
    ]
  }
];

function Programma() {
  return (
    <>
      <Helmet>
        <title>Programma Master | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Esplora il programma completo di Digitalized Master Academy: SEO, pubblicità targetizzata, corso coding, social media marketing e sviluppo web."
        />
        <meta
          name="keywords"
          content="programma corsi online Italia, SEO, social media marketing, corso coding, sviluppo web, pubblicità targetizzata"
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Programma</p>
            <h1>Un percorso strutturato per consolidare competenze digitali avanzate</h1>
            <p>
              Il master combina lezioni on-demand, laboratori live e project work su casi reali. Ogni modulo
              è progettato per accompagnarti lungo un percorso coerente tra strategia, esecuzione e analisi.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.scheduleTimeline}>
              {schedule.map((item) => (
                <article className={styles.scheduleCard} key={item.week}>
                  <span className={styles.scheduleWeek}>{item.week}</span>
                  <h2>{item.focus}</h2>
                  <ul>
                    {item.points.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.deliverySection} section-spacing`}>
          <div className="container">
            <div className={styles.deliveryGrid}>
              <div>
                <h2>Metodologia di erogazione</h2>
                <p>
                  Ogni settimana alterna studio autonomo, laboratori interattivi e momenti di confronto con docenti e studenti.
                  L’insieme di video, workshop e feedback permette di consolidare competenze e applicarle immediatamente.
                </p>
              </div>
              <div className={styles.deliveryHighlights}>
                <div>
                  <strong>Learning Hub</strong>
                  <p>Accesso 24/7 a materiali, registrazioni, repository e forum dedicato.</p>
                </div>
                <div>
                  <strong>Tutor dedicato</strong>
                  <p>Supporto continuo per orientarti nel percorso e monitorare i progressi.</p>
                </div>
                <div>
                  <strong>Career coaching</strong>
                  <p>Sessioni strategiche su personal branding, portfolio e colloqui.</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default Programma;