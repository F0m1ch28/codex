import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PrivacyPolicy.module.css';

function PrivacyPolicy() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Informativa privacy di Digitalized Master Academy: trattamento dei dati per corsi di marketing digitale, SEO e programmazione."
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Legale</p>
            <h1>Informativa sulla privacy</h1>
            <p>
              Questa informativa descrive come Digitalized Master Academy tratta i dati personali raccolti
              tramite la piattaforma e i servizi di formazione digitale.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.content}>
              <h2>1. Titolare del trattamento</h2>
              <p>
                Il titolare del trattamento è Digitalized Master Academy, con sede in Via Roma, 107, 59100 Prato PO.
              </p>

              <h2>2. Tipologie di dati raccolti</h2>
              <p>
                Raccogliamo dati identificativi (nome, email), informazioni professionali, dati relativi all’utilizzo della piattaforma
                e agli interessi formativi su SEO, social media marketing e programmazione.
              </p>

              <h2>3. Finalità del trattamento</h2>
              <ul>
                <li>Gestione delle iscrizioni ai corsi e ai project work.</li>
                <li>Invio di comunicazioni relative a eventi formativi e aggiornamenti.</li>
                <li>Miglioramento dell’esperienza utente attraverso analisi statistiche.</li>
              </ul>

              <h2>4. Modalità del trattamento</h2>
              <p>
                I dati sono trattati con strumenti informatici e telematici, adottando misure di sicurezza adeguate
                per prevenire accessi non autorizzati.
              </p>

              <h2>5. Conservazione dei dati</h2>
              <p>
                I dati vengono conservati per il tempo necessario a fornire i servizi richiesti e adempiere agli obblighi normativi.
              </p>

              <h2>6. Diritti degli interessati</h2>
              <p>
                Gli utenti possono esercitare diritti di accesso, rettifica, cancellazione, limitazione e opposizione
                inviando una richiesta tramite il modulo di contatto.
              </p>

              <h2>7. Trasferimento dei dati</h2>
              <p>
                I dati non vengono trasferiti al di fuori dell’Unione Europea se non in presenza di garanzie adeguate.
              </p>

              <h2>8. Aggiornamenti</h2>
              <p>
                Questa informativa può essere aggiornata in base a evoluzioni normative o tecniche.
              </p>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default PrivacyPolicy;