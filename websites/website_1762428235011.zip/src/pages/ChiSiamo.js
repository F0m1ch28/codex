import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ChiSiamo.module.css';

function ChiSiamo() {
  return (
    <>
      <Helmet>
        <title>Chi Siamo | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Conosci la missione di Digitalized Master Academy: formazione digitale italiana su SEO, social media marketing, programmazione e pubblicità targetizzata."
        />
        <meta
          name="keywords"
          content="formazione digitale, corsi online Italia, SEO, social media marketing, programmazione, pubblicità targetizzata"
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Chi siamo</p>
            <h1>Un'accademia digitale per professionisti che vogliono guidare il cambiamento</h1>
            <p>
              Digitalized Master Academy nasce a Prato dall’esperienza di consulenti marketing, sviluppatori e analisti italiani.
              Offriamo percorsi formativi verticali su SEO, social media, corso coding e campagne di advertising per costruire competenze concrete e aggiornate.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.storyGrid}>
              <div className={styles.storyCard}>
                <h2>La nostra missione</h2>
                <p>
                  Vogliamo accelerare la crescita digitale di professionisti e aziende italiane.
                  Crediamo nel valore dell'apprendimento pratico, in modelli data-driven e nella contaminazione tra marketing e sviluppo web.
                </p>
                <p>
                  Ogni programma viene progettato con un approccio modulare: teoria, esercizi interattivi, project work e mentoring personalizzato.
                </p>
              </div>
              <div className={styles.storyCard}>
                <h2>I valori che ci guidano</h2>
                <ul>
                  <li>Trasparenza sui risultati e sulle metriche che contano davvero.</li>
                  <li>Innovazione continua: aggiorniamo i moduli su SEO e social media marketing ogni trimestre.</li>
                  <li>Collaborazione: docenti e studenti lavorano insieme su sfide reali del mercato italiano.</li>
                  <li>Responsabilità: ogni percorso include feedback strutturato e piano di crescita individuale.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.timelineSection} section-spacing`}>
          <div className="container">
            <h2 className="section-title">Un viaggio di crescita costante</h2>
            <div className={styles.timeline}>
              <div className={styles.timelineItem}>
                <span className={styles.timelineYear}>2018</span>
                <h3>Nascita dell'accademia</h3>
                <p>
                  Abbiamo lanciato il primo percorso di formazione digitale a Milano, con focus su SEO e data analytics.
                </p>
              </div>
              <div className={styles.timelineItem}>
                <span className={styles.timelineYear}>2020</span>
                <h3>Espansione ai corsi online</h3>
                <p>
                  Introduzione del corso coding e delle sessioni live su programmazione front-end per marketer.
                </p>
              </div>
              <div className={styles.timelineItem}>
                <span className={styles.timelineYear}>2022</span>
                <h3>Laboratori di social media marketing</h3>
                <p>
                  Nuovi moduli dedicati a Instagram marketing e pubblicità targetizzata su Meta Ads.
                </p>
              </div>
              <div className={styles.timelineItem}>
                <span className={styles.timelineYear}>2024</span>
                <h3>Piattaforma evoluta</h3>
                <p>
                  Implementazione di percorsi personalizzati con mentorship, dashboard avanzate e community professionale.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.visionCard}>
              <div>
                <h2>La nostra visione</h2>
                <p>
                  Puntiamo a diventare il punto di riferimento per corsi online Italia dedicati al marketing digitale,
                  mettendo in connessione studenti, aziende e innovazione tecnologica.
                </p>
              </div>
              <div>
                <h3>Focus strategici</h3>
                <ul>
                  <li>Facilitare l'integrazione tra team marketing e sviluppo web.</li>
                  <li>Promuovere progetti concreti su cui misurare i risultati.</li>
                  <li>Mantenere qualità didattica con docenti certificati e attivi sul campo.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default ChiSiamo;