import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Cookie Policy di Digitalized Master Academy: utilizzo di cookie tecnici e di analisi sulla piattaforma formativa."
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Legale</p>
            <h1>Cookie Policy</h1>
            <p>
              La presente policy descrive le tipologie di cookie utilizzate dalla piattaforma Digitalized Master Academy
              e le finalità collegate.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.content}>
              <h2>1. Cosa sono i cookie</h2>
              <p>
                I cookie sono file di testo archiviatati sul dispositivo dell’utente che permettono di migliorare la navigazione
                e raccogliere informazioni sull’utilizzo della piattaforma.
              </p>

              <h2>2. Cookie utilizzati</h2>
              <ul>
                <li>
                  Cookie tecnici: necessari al funzionamento del sito e all’erogazione dei corsi online Italia.
                </li>
                <li>
                  Cookie analitici: utilizzati in forma aggregata per analizzare il traffico e ottimizzare i percorsi di formazione digitale.
                </li>
              </ul>

              <h2>3. Gestione dei cookie</h2>
              <p>
                Gli utenti possono gestire o disabilitare i cookie tramite le impostazioni del browser. La disattivazione
                potrebbe limitare alcune funzionalità della piattaforma.
              </p>

              <h2>4. Aggiornamenti</h2>
              <p>
                La presente policy può essere aggiornata per adeguamenti normativi o tecnici.
              </p>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default CookiePolicy;