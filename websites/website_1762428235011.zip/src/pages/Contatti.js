import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contatti.module.css';

function Contatti() {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    azienda: '',
    messaggio: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.nome.trim()) newErrors.nome = 'Inserisci il tuo nome e cognome.';
    if (!formData.email.trim()) {
      newErrors.email = 'Inserisci la tua email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Inserisci un indirizzo email valido.';
    }
    if (!formData.messaggio.trim()) newErrors.messaggio = 'Scrivi un messaggio.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      setStatus(null);
      return;
    }
    setErrors({});
    setStatus('successo');
    setFormData({ nome: '', email: '', azienda: '', messaggio: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contatti | Digitalized Master Academy</title>
        <meta
          name="description"
          content="Contatta Digitalized Master Academy per informazioni su corsi online Italia, SEO, social media marketing, programmazione e pubblicità targetizzata."
        />
        <meta
          name="keywords"
          content="contatti formazione digitale, corsi online Italia, SEO, social media marketing, programmazione"
        />
      </Helmet>
      <article className="page">
        <header className="page-hero">
          <div className="container">
            <p className="page-kicker">Contatti</p>
            <h1>Parliamo del tuo piano di crescita digitale</h1>
            <p>
              Compila il modulo per ricevere maggiori informazioni sui nostri corsi, sul programma e sulle opportunità di mentoring.
              Il nostro team ti risponderà entro 24 ore lavorative.
            </p>
          </div>
        </header>

        <section className="section-spacing">
          <div className="container">
            <div className={styles.grid}>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <div className={styles.field}>
                  <label htmlFor="nome">Nome e Cognome *</label>
                  <input
                    id="nome"
                    name="nome"
                    type="text"
                    value={formData.nome}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, nome: e.target.value }))
                    }
                    aria-invalid={errors.nome ? 'true' : 'false'}
                    aria-describedby={errors.nome ? 'errore-nome' : undefined}
                  />
                  {errors.nome && <span id="errore-nome" className={styles.error}>{errors.nome}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="email">Email *</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, email: e.target.value }))
                    }
                    aria-invalid={errors.email ? 'true' : 'false'}
                    aria-describedby={errors.email ? 'errore-email' : undefined}
                  />
                  {errors.email && <span id="errore-email" className={styles.error}>{errors.email}</span>}
                </div>

                <div className={styles.field}>
                  <label htmlFor="azienda">Azienda (opzionale)</label>
                  <input
                    id="azienda"
                    name="azienda"
                    type="text"
                    value={formData.azienda}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, azienda: e.target.value }))
                    }
                  />
                </div>

                <div className={styles.field}>
                  <label htmlFor="messaggio">Messaggio *</label>
                  <textarea
                    id="messaggio"
                    name="messaggio"
                    rows="5"
                    value={formData.messaggio}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, messaggio: e.target.value }))
                    }
                    aria-invalid={errors.messaggio ? 'true' : 'false'}
                    aria-describedby={errors.messaggio ? 'errore-messaggio' : undefined}
                  />
                  {errors.messaggio && (
                    <span id="errore-messaggio" className={styles.error}>{errors.messaggio}</span>
                  )}
                </div>

                <button type="submit" className="btn btn-primary">
                  Invia richiesta
                </button>

                {status === 'successo' && (
                  <div className={styles.success} role="status">
                    Messaggio inviato con successo! Ti contatteremo al più presto.
                  </div>
                )}
              </form>

              <aside className={styles.info}>
                <div className={styles.infoCard}>
                  <h2>Sede</h2>
                  <p>
                    Digitalized Master Academy<br />
                    Via Roma, 107<br />
                    59100 Prato PO
                  </p>
                </div>
                <div className={styles.infoCard}>
                  <h2>Telefono</h2>
                  <a href="tel:+390212346721">+39 02 1234 6721</a>
                </div>
                <div className={styles.infoCard}>
                  <h2>Orari di contatto</h2>
                  <p>Lunedì - Venerdì: 9:00 - 18:00</p>
                </div>
              </aside>
            </div>
          </div>
        </section>
      </article>
    </>
  );
}

export default Contatti;