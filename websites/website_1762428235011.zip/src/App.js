import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import ChiSiamo from './pages/ChiSiamo';
import Corsi from './pages/Corsi';
import Programma from './pages/Programma';
import Docenti from './pages/Docenti';
import Contatti from './pages/Contatti';
import TerminiCondizioni from './pages/TerminiCondizioni';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  return (
    <div className="appShell">
      <Header />
      <main className="mainContent" id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/chi-siamo" element={<ChiSiamo />} />
          <Route path="/corsi" element={<Corsi />} />
          <Route path="/programma" element={<Programma />} />
          <Route path="/docenti" element={<Docenti />} />
          <Route path="/contatti" element={<Contatti />} />
          <Route path="/termini" element={<TerminiCondizioni />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
}

export default App;