import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/chi-siamo', label: 'Chi Siamo' },
  { path: '/corsi', label: 'Corsi' },
  { path: '/programma', label: 'Programma' },
  { path: '/docenti', label: 'Docenti' },
  { path: '/contatti', label: 'Contatti' }
];

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} aria-label="Digitalized Master Academy Home">
            <span className={styles.logoMark}>DMA</span>
            <span className={styles.logoText}>Digitalized Master Academy</span>
          </NavLink>
          <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Menu principale">
            <ul className={styles.navList}>
              {navLinks.map((link) => (
                <li key={link.path}>
                  <NavLink
                    to={link.path}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.activeLink : ''}`
                    }
                  >
                    {link.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
          <button
            className={styles.menuButton}
            aria-label={isMenuOpen ? 'Chiudi menu' : 'Apri menu'}
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((prev) => !prev)}
          >
            <span className={styles.menuIcon} />
            <span className="sr-only">Menu</span>
          </button>
        </div>
      </div>
    </header>
  );
}

export default Header;