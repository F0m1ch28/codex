import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'dma_cookie_consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(COOKIE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="region" aria-label="Cookie banner">
      <div className={styles.content}>
        <p>
          Utilizziamo cookie tecnici e di analisi per migliorare la tua esperienza di formazione digitale.
          Continuando la navigazione accetti la nostra <a href="/cookie-policy">Cookie Policy</a>.
        </p>
        <button onClick={handleAccept} className={styles.button}>
          Accetta
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;