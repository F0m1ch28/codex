import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Piè di pagina">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brandColumn}>
            <h3 className={styles.brandTitle}>Digitalized Master Academy</h3>
            <p className={styles.brandText}>
              Piattaforma educativa online italiana dedicata a corsi online Italia di marketing digitale,
              SEO e sviluppo web per professionisti che desiderano crescere con metodo.
            </p>
            <div className={styles.address}>
              <span>Via Roma, 107</span>
              <span>59100 Prato PO</span>
              <a href="tel:+390212346721" className={styles.phone}>
                +39 02 1234 6721
              </a>
            </div>
          </div>
          <div className={styles.linksColumn}>
            <h4 className={styles.columnTitle}>Navigazione</h4>
            <ul className={styles.linkList}>
              <li><NavLink to="/chi-siamo">Chi Siamo</NavLink></li>
              <li><NavLink to="/corsi">Corsi</NavLink></li>
              <li><NavLink to="/programma">Programma</NavLink></li>
              <li><NavLink to="/docenti">Docenti</NavLink></li>
              <li><NavLink to="/contatti">Contatti</NavLink></li>
            </ul>
          </div>
          <div className={styles.linksColumn}>
            <h4 className={styles.columnTitle}>Informazioni</h4>
            <ul className={styles.linkList}>
              <li><NavLink to="/termini">Termini e Condizioni</NavLink></li>
              <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
              <li><NavLink to="/cookie-policy">Cookie Policy</NavLink></li>
            </ul>
          </div>
          <div className={styles.newsColumn}>
            <h4 className={styles.columnTitle}>Aggiornamenti</h4>
            <p className={styles.newsText}>
              Ricevi insight su SEO, Facebook Ads, Instagram marketing e sviluppo web professionale.
            </p>
            <form className={styles.newsForm} aria-label="Iscrizione aggiornamenti">
              <label htmlFor="newsletter-email" className="sr-only">
                Inserisci la tua email
              </label>
              <input
                id="newsletter-email"
                type="email"
                placeholder="La tua email"
                required
              />
              <button type="submit">Iscriviti</button>
            </form>
          </div>
        </div>
        <div className={styles.bottomBar}>
          <p>© {new Date().getFullYear()} Digitalized Master Academy. Tutti i diritti riservati.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;