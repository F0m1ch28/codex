document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const siteNav = document.querySelector('[data-site-nav]');
  const navLinks = document.querySelectorAll('[data-site-nav] a');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      siteNav.dataset.visible = String(!isExpanded);
    });

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute('aria-expanded', 'false');
          siteNav.dataset.visible = 'false';
        }
      });
    });
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  const acceptBtn = document.querySelector('[data-accept-cookies]');
  const declineBtn = document.querySelector('[data-decline-cookies]');

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedConsent = localStorage.getItem('cookieConsent');

    if (!storedConsent) {
      cookieBanner.removeAttribute('hidden');
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    }

    acceptBtn.addEventListener('click', () => {
      localStorage.setItem('cookieConsent', 'accepted');
      closeBanner();
    });

    declineBtn.addEventListener('click', () => {
      localStorage.setItem('cookieConsent', 'declined');
      closeBanner();
    });

    function closeBanner() {
      cookieBanner.classList.remove('is-visible');
      cookieBanner.addEventListener(
        'transitionend',
        () => {
          cookieBanner.setAttribute('hidden', '');
        },
        { once: true }
      );
    }
  }

  const yearTargets = document.querySelectorAll('#current-year');
  const currentYear = new Date().getFullYear();
  yearTargets.forEach((node) => {
    node.textContent = currentYear;
  });
});