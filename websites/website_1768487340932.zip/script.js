document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = siteNav.classList.toggle('nav-open');
            navToggle.classList.toggle('nav-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');

    const consentKey = 'genusCayqgConsent';
    const storedConsent = localStorage.getItem(consentKey);

    if (cookieBanner) {
        if (!storedConsent) {
            cookieBanner.classList.add('show');
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                localStorage.setItem(consentKey, 'accepted');
                cookieBanner.classList.remove('show');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                localStorage.setItem(consentKey, 'declined');
                cookieBanner.classList.remove('show');
            });
        }
    }
});