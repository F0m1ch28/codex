document.addEventListener("DOMContentLoaded", () => {
  const yearSpan = document.getElementById("year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const toggleNav = document.querySelector(".toggle-nav");
  const navList = document.querySelector(".site-nav ul");

  if (toggleNav && navList) {
    toggleNav.addEventListener("click", () => {
      navList.classList.toggle("open");
    });
  }

  const page = document.body.dataset.page;
  if (page && navList) {
    navList.querySelectorAll("a").forEach((link) => {
      const href = link.getAttribute("href");
      if (href && href.includes(page)) {
        link.classList.add("active");
      }
      if (page === "inicio" && href === "index.html") {
        link.classList.add("active");
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const consentKey = "travellionera_cookie_consent";

  const showBanner = () => cookieBanner?.classList.add("show");
  const hideBanner = () => cookieBanner?.classList.remove("show");

  const savedConsent = localStorage.getItem(consentKey);
  if (!savedConsent) {
    setTimeout(showBanner, 800);
  }

  acceptBtn?.addEventListener("click", () => {
    localStorage.setItem(consentKey, "accepted");
    hideBanner();
  });

  declineBtn?.addEventListener("click", () => {
    localStorage.setItem(consentKey, "declined");
    hideBanner();
  });

  document.addEventListener("click", (e) => {
    if (navList?.classList.contains("open") && !e.target.closest(".site-nav") && !e.target.closest(".toggle-nav")) {
      navList.classList.remove("open");
    }
  });
});