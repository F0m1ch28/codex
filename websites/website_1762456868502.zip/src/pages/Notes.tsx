import React from "react";
import { Helmet } from "react-helmet";

const notes = [
  {
    title: "Notes 2024-02-18",
    summary:
      "We are piloting research labs with two Canadian platform teams focusing on knowledge architecture for service ownership."
  },
  {
    title: "Notes 2024-01-30",
    summary:
      "Edited transcripts from our latest roundtable on cognitive load in developer portals are now in peer review."
  },
  {
    title: "Notes 2024-01-12",
    summary:
      "The archives have expanded with newly digitized Bell Northern Research documents courtesy of the Computing History Museum."
  }
];

const Notes: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Notes | DevLayer</title>
        <meta
          name="description"
          content="DevLayer editorial notes, platform updates, and internal commentary."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-4xl space-y-6 px-4 md:px-6 lg:px-8">
          <h1 className="font-heading text-4xl font-semibold text-midnight">
            Editorial notes.
          </h1>
          <p className="text-base text-slate-600">
            Quick updates from the DevLayer team about current research,
            partnerships, and internal experiments.
          </p>
          <div className="space-y-6">
            {notes.map((note) => (
              <article
                key={note.title}
                className="rounded-3xl border border-slate-200 bg-cloudMist/70 p-6 shadow-soft"
              >
                <h2 className="font-heading text-2xl font-semibold text-midnight">
                  {note.title}
                </h2>
                <p className="mt-2 text-sm text-slate-600">{note.summary}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Notes;