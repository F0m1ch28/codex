import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import { motion, useInView } from "framer-motion";

type Stat = {
  label: string;
  value: number;
  suffix?: string;
};

const stats: Stat[] = [
  { label: "Articles curated", value: 128 },
  { label: "Workflow studies", value: 46 },
  { label: "Cloud blueprints", value: 32 },
  { label: "Contributors involved", value: 18 }
];

const featuredEssays = [
  {
    title: "Why context switching dismantles deep engineering focus",
    category: "Workflow",
    href: "/blog/why-context-switching-kills-productivity",
    summary:
      "Tracing the hidden tax that quick task pivots place on engineering teams and the frameworks we use to regain flow.",
    readingTime: "12 min"
  },
  {
    title: "Cloud patterns for resilient scale",
    category: "Systems",
    href: "/blog/cloud-patterns-for-scale",
    summary:
      "Pragmatic cloud design motifs that keep distributed systems observable, cost-efficient, and ready for sudden demand shifts.",
    readingTime: "14 min"
  },
  {
    title: "DevOps culture is still evolving",
    category: "Culture",
    href: "/blog/the-evolution-of-devops-culture",
    summary:
      "A decade-long retrospective on how platform engineering reframed DevOps and why psychological safety is the missing layer.",
    readingTime: "16 min"
  }
];

const workflowPatterns = [
  {
    title: "Adaptive pipelines",
    description:
      "Composable CI/CD pipelines anchored in policy-as-code, ephemeral previews, and measurable developer satisfaction.",
    link: "/workflows"
  },
  {
    title: "Observability choreography",
    description:
      "Narratives on structured logging, golden signals, and service dependency mapping that inform whole-system awareness.",
    link: "/archives"
  },
  {
    title: "Team cadence rituals",
    description:
      "Evidence-based rhythms for incident postmortems, pairing rotations, and feedback loops that keep cognition aligned.",
    link: "/mindset"
  }
];

const toolingSignals = [
  {
    title: "IDE ergonomics",
    description:
      "Editors as collaboration canvases: pair programming settings, plugin health checks, and latency thresholds.",
    icon: "🧭"
  },
  {
    title: "Platform scorecards",
    description:
      "Multi-layer benchmarks blending deployment frequency, mean restore time, and platform reliability sentiment.",
    icon: "📈"
  },
  {
    title: "Runtime intelligence",
    description:
      "Tracing asynchronous workflows, event buses, and domain boundaries to surface optimization opportunities.",
    icon: "🛰️"
  }
];

const testimonials = [
  {
    quote:
      "DevLayer crystallizes the trade-offs we face in platform engineering. The editorial voice is grounded in field experience.",
    name: "Sonia Patel",
    role: "Director of Platform Strategy, RenderNorth"
  },
  {
    quote:
      "Our developer programs team references DevLayer artifacts in weekly planning. The focus on cognition is invaluable.",
    name: "Marcus O'Neil",
    role: "Head of Developer Experience, CloudHorizon"
  },
  {
    quote:
      "Every newsletter gives our engineers a structured lens on modern workflows without hype. Precisely what we need.",
    name: "Amélie Tremblay",
    role: "Principal Engineer, Montréal Digital Lab"
  }
];

const faqItems = [
  {
    question: "How does DevLayer source its research?",
    answer:
      "We synthesize peer-reviewed studies, public RFCs, and interviews with platform engineers across Canada and abroad. Each piece cites primary sources in the reading queue."
  },
  {
    question: "Can we suggest a workflow deep dive?",
    answer:
      "Absolutely. Use the contact form to propose topics, supporting data, or practitioners we should interview. The editorial board reviews suggestions weekly."
  },
  {
    question: "Do you collaborate with engineering teams?",
    answer:
      "DevLayer runs collaborative research sprints with product and infrastructure teams. These sprints produce public essays, internal playbooks, and workshop outlines."
  },
  {
    question: "How often is new content published?",
    answer:
      "We publish long-form essays twice per month, ship notes weekly, and update the reading queue as relevant papers or community resources emerge."
  }
];

const queuePreview = [
  {
    title: "Cognitive Load Theory for Distributed Teams",
    source: "University of Waterloo",
    tags: ["Research", "Mindset"]
  },
  {
    title: "Policy Driven Platform Engineering",
    source: "CNCF Whitepaper",
    tags: ["Cloud", "Governance"]
  },
  {
    title: "Incident Collaboration Patterns",
    source: "AdaptiveOps Collective",
    tags: ["Workflow", "Culture"]
  }
];

const readingHighlights = [
  {
    title: "Editorial S1E04",
    description:
      "Deep dive into distributed cognition and the rituals that safeguard focus inside hybrid infrastructure teams.",
    link: "/notes"
  },
  {
    title: "Stack Archaeology",
    description:
      "What legacy build systems teach us about crafting maintainable, interpretable workflows for next-gen automation.",
    link: "/archives"
  },
  {
    title: "Platform Routines",
    description:
      "How cross-functional runbooks evolve when platform engineering shifts from ticket-based to service-based ownership.",
    link: "/workflows"
  }
];

const blogPreview = [
  {
    title: "Service blueprints for unified developer portals",
    excerpt:
      "Mapping the interplay between service catalogs, golden paths, and developer onboarding.",
    link: "/blog"
  },
  {
    title: "Cognition-informed code review practices",
    excerpt:
      "Reducing review fatigue with heuristics that emphasize clarity, signals, and availability.",
    link: "/blog"
  },
  {
    title: "Scaling observability literature",
    excerpt:
      "Building reading programs that turn observability from tooling to shared language.",
    link: "/blog"
  }
];

const servicesTeasers = [
  {
    title: "Editorial sprints",
    description:
      "Two-week research intensives co-created with platform leads to document workflows, metrics, and decision cadences.",
    link: "/services"
  },
  {
    title: "Narrative playbooks",
    description:
      "Bespoke long-form analyses that convert platform engineering outcomes into board-ready narratives and diagrams.",
    link: "/services"
  },
  {
    title: "Knowledge orchestration",
    description:
      "Systems for aligning internal wikis, broadcast channels, and onboarding curricula with operational reality.",
    link: "/services"
  }
];

const processSteps = [
  {
    title: "Listen",
    description:
      "We interview practitioners, shadow rituals, and gather telemetry to understand existing systems."
  },
  {
    title: "Synthesize",
    description:
      "Research is converted into editorial maps, diagrams, and annotated models that expose systemic trade-offs."
  },
  {
    title: "Co-create",
    description:
      "Workshops with engineering, product, and operations teams validate insights and define next experiments."
  },
  {
    title: "Publish",
    description:
      "We deliver essays, playbooks, and talk tracks that align leadership and ecosystems around durable workflows."
  }
];

const Home: React.FC = () => {
  const statsRef = useRef<HTMLDivElement | null>(null);
  const statsInView = useInView(statsRef, { once: true, margin: "-100px" });
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setActiveTestimonial((prev) =>
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 7000);
    return () => window.clearInterval(interval);
  }, []);

  const animatedStats = useMemo(() => {
    if (!statsInView) return stats.map((stat) => ({ ...stat, display: 0 }));
    return stats.map((stat) => ({ ...stat, display: stat.value }));
  }, [statsInView]);

  return (
    <>
      <Helmet>
        <title>DevLayer | Every Layer Tells a Story</title>
        <meta
          name="description"
          content="DevLayer is a Canadian editorial platform that examines developer workflows, software systems, and cloud infrastructure."
        />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "DevLayer",
            url: "https://www.devlayer.ca",
            slogan: "Every Layer Tells a Story",
            address: {
              "@type": "PostalAddress",
              streetAddress: "333 Bay St",
              addressLocality: "Toronto",
              addressRegion: "ON",
              postalCode: "M5H 2R2",
              addressCountry: "CA"
            },
            telephone: "+1-416-905-6621",
            sameAs: [
              "https://github.com/devlayer-platform",
              "https://www.linkedin.com/company/devlayer"
            ]
          })}
        </script>
      </Helmet>

      <div className="space-y-24 pb-24">
        <section className="relative overflow-hidden bg-white">
          <div className="absolute inset-0">
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Abstract architecture indicating layered systems"
              className="h-full w-full object-cover opacity-20"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-white via-white/90 to-cloudMist" />
          </div>
          <div className="relative mx-auto flex max-w-7xl flex-col gap-12 px-4 py-24 md:flex-row md:px-6 lg:px-8 lg:py-32">
            <motion.div
              className="max-w-2xl space-y-6"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.35em] text-slate-500 shadow-soft">
                Editorial intelligence for developers
              </span>
              <h1 className="font-heading text-4xl font-bold tracking-tight text-midnight sm:text-5xl lg:text-6xl">
                Every Layer Tells a Story
              </h1>
              <p className="text-lg leading-relaxed text-slate-600">
                DevLayer brings together systems thinking, developer workflows,
                and cloud infrastructure research. We translate complex
                engineering decisions into narratives that shape strategy,
                culture, and sustainable delivery.
              </p>
              <div className="flex flex-col gap-4 sm:flex-row">
                <Link
                  to="/blog"
                  className="inline-flex items-center justify-center rounded-full bg-midnight px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-slateDeep"
                >
                  Explore editorial insights
                </Link>
                <Link
                  to="/about"
                  className="inline-flex items-center justify-center rounded-full border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-midnight transition hover:border-midnight hover:text-midnight"
                >
                  View our approach
                </Link>
              </div>
              <p className="text-xs uppercase tracking-[0.3em] text-slate-400">
                Disclaimer: for educational use only
              </p>
            </motion.div>
            <motion.div
              className="relative flex-1 rounded-3xl border border-slate-200 bg-white/60 p-8 shadow-soft backdrop-blur"
              initial={{ opacity: 0, x: 60 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.9, ease: "easeOut" }}
            >
              <div className="space-y-6">
                <h2 className="font-heading text-xl font-semibold text-midnight">
                  What we explore
                </h2>
                <div className="grid gap-5">
                  {workflowPatterns.map((pattern) => (
                    <div
                      key={pattern.title}
                      className="rounded-2xl border border-slate-200 bg-white p-5 transition hover:-translate-y-1 hover:shadow-soft"
                    >
                      <p className="text-xs uppercase tracking-[0.3em] text-azurePulse">
                        Insight Track
                      </p>
                      <h3 className="mt-2 font-heading text-lg font-semibold text-midnight">
                        {pattern.title}
                      </h3>
                      <p className="mt-2 text-sm text-slate-600">
                        {pattern.description}
                      </p>
                      <Link
                        to={pattern.link}
                        className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-azurePulse transition hover:opacity-80"
                      >
                        Learn more
                        <span aria-hidden="true">→</span>
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section ref={statsRef} className="mx-auto max-w-7xl px-4 md:px-6 lg:px-8">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-soft lg:p-12">
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {animatedStats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  className="rounded-2xl border border-slate-100 bg-cloudMist/60 p-6 text-center shadow-sm"
                  initial={{ opacity: 0, y: 32 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.15 }}
                >
                  <h3 className="font-heading text-sm uppercase tracking-[0.3em] text-slate-500">
                    {stat.label}
                  </h3>
                  <p className="mt-4 text-4xl font-semibold text-midnight">
                    {statsInView ? stat.value.toLocaleString() : 0}
                    {stat.suffix}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl space-y-12 px-4 md:px-6 lg:px-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="font-heading text-3xl font-semibold text-midnight">
                Featured essays
              </h2>
              <p className="mt-2 max-w-2xl text-sm text-slate-600">
                Essays emerge from conversations with engineering leaders,
                platform practitioners, and cognitive researchers.
              </p>
            </div>
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 text-sm font-semibold text-azurePulse transition hover:opacity-80"
            >
              Browse all essays
              <span aria-hidden="true">→</span>
            </Link>
          </div>
          <div className="grid gap-6 lg:grid-cols-3">
            {featuredEssays.map((essay, index) => (
              <motion.article
                key={essay.title}
                className="group flex flex-col rounded-3xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:border-midnight"
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <span className="text-xs uppercase tracking-[0.3em] text-azurePulse">
                  {essay.category}
                </span>
                <h3 className="mt-4 font-heading text-xl font-semibold text-midnight">
                  {essay.title}
                </h3>
                <p className="mt-3 flex-1 text-sm text-slate-600">
                  {essay.summary}
                </p>
                <div className="mt-4 flex items-center justify-between text-sm text-slate-500">
                  <span>{essay.readingTime} read</span>
                  <Link
                    to={essay.href}
                    className="inline-flex items-center gap-2 text-azurePulse transition group-hover:translate-x-1 group-hover:opacity-80"
                  >
                    Read essay
                    <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-7xl grid gap-12 px-4 md:px-6 lg:grid-cols-2 lg:px-8">
          <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Tooling signals
            </h2>
            <p className="text-sm text-slate-600">
              We monitor how tooling ecosystems influence developer sentiment,
              acceleration, and governance. Signals inform editorial direction
              and partner research programs.
            </p>
            <div className="space-y-5">
              {toolingSignals.map((signal, index) => (
                <motion.div
                  key={signal.title}
                  className="rounded-2xl border border-slate-100 bg-cloudMist/60 p-4"
                  initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.6 }}
                  transition={{ duration: 0.6 }}
                >
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{signal.icon}</div>
                    <h3 className="font-heading text-lg font-semibold text-midnight">
                      {signal.title}
                    </h3>
                  </div>
                  <p className="mt-3 text-sm text-slate-600">
                    {signal.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-soft">
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Developers collaborating around workflow diagrams"
              className="h-64 w-full object-cover"
              loading="lazy"
            />
            <div className="space-y-5 p-8">
              <h2 className="font-heading text-2xl font-semibold text-midnight">
                Developer mindset
              </h2>
              <p className="text-sm text-slate-600">
                DevLayer’s editorial voice is anchored in cognitive science,
                organisational psychology, and reflective engineering practice.
                Each piece is designed to help teams build humane, sustainable,
                and high-context workflows.
              </p>
              <Link
                to="/mindset"
                className="inline-flex items-center gap-2 text-sm font-semibold text-azurePulse transition hover:opacity-80"
              >
                Explore mindset essays
                <span aria-hidden="true">→</span>
              </Link>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 md:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-[1.1fr,0.9fr]">
            <div className="space-y-6">
              <h2 className="font-heading text-3xl font-semibold text-midnight">
                Editorial highlights
              </h2>
              <div className="grid gap-6 md:grid-cols-2">
                {readingHighlights.map((item, index) => (
                  <motion.div
                    key={item.title}
                    className="rounded-2xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:border-midnight"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.5 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <p className="text-xs uppercase tracking-[0.3em] text-azurePulse">
                      Spotlight
                    </p>
                    <h3 className="mt-3 font-heading text-xl font-semibold text-midnight">
                      {item.title}
                    </h3>
                    <p className="mt-2 text-sm text-slate-600">
                      {item.description}
                    </p>
                    <Link
                      to={item.link}
                      className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-azurePulse transition hover:opacity-80"
                    >
                      Continue reading
                      <span aria-hidden="true">→</span>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
            <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
              <h2 className="font-heading text-3xl font-semibold text-midnight">
                Reading queue
              </h2>
              <p className="text-sm text-slate-600">
                Curated references that extend each essay with academic papers,
                archival documents, and open standards.
              </p>
              <ul className="space-y-4">
                {queuePreview.map((item) => (
                  <li
                    key={item.title}
                    className="rounded-2xl border border-slate-100 bg-cloudMist/70 p-5"
                  >
                    <h3 className="font-heading text-lg font-semibold text-midnight">
                      {item.title}
                    </h3>
                    <p className="text-xs uppercase tracking-[0.3em] text-slate-500">
                      {item.source}
                    </p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {item.tags.map((tag) => (
                        <span
                          key={tag}
                          className="inline-flex rounded-full bg-white px-3 py-1 text-xs font-semibold uppercase tracking-widest text-azurePulse"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </li>
                ))}
              </ul>
              <Link
                to="/queue"
                className="inline-flex items-center gap-2 text-sm font-semibold text-azurePulse transition hover:opacity-80"
              >
                View queue
                <span aria-hidden="true">→</span>
              </Link>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 md:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2">
            <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
              <h2 className="font-heading text-3xl font-semibold text-midnight">
                Our collaborative process
              </h2>
              <p className="text-sm text-slate-600">
                DevLayer operates like a studio. We co-create with engineering
                teams to align research, storytelling, and iteration.
              </p>
              <div className="space-y-4">
                {processSteps.map((step, index) => (
                  <motion.div
                    key={step.title}
                    className="flex gap-4 rounded-2xl border border-slate-100 bg-cloudMist/70 p-5"
                    initial={{ opacity: 0, x: -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.5 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-midnight text-sm font-semibold text-white">
                      {index + 1}
                    </div>
                    <div>
                      <h3 className="font-heading text-lg font-semibold text-midnight">
                        {step.title}
                      </h3>
                      <p className="mt-1 text-sm text-slate-600">
                        {step.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="space-y-6 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
              <h2 className="font-heading text-3xl font-semibold text-midnight">
                Partner perspectives
              </h2>
              <p className="text-sm text-slate-600">
                Voices from engineering leaders who integrate DevLayer research
                into their operational rhythms.
              </p>
              <div className="relative overflow-hidden rounded-2xl border border-slate-100 bg-cloudMist/70">
                {testimonials.map((testimonial, index) => (
                  <motion.div
                    key={testimonial.name}
                    className="space-y-4 p-6"
                    initial={{ opacity: 0 }}
                    animate={{
                      opacity: activeTestimonial === index ? 1 : 0,
                      x: activeTestimonial === index ? 0 : -40,
                      position: activeTestimonial === index ? "relative" : "absolute"
                    }}
                    transition={{ duration: 0.6 }}
                    aria-hidden={activeTestimonial !== index}
                  >
                    <p className="text-sm italic text-slate-600">
                      “{testimonial.quote}”
                    </p>
                    <div className="text-sm font-semibold text-midnight">
                      {testimonial.name}
                    </div>
                    <p className="text-xs uppercase tracking-[0.3em] text-slate-500">
                      {testimonial.role}
                    </p>
                  </motion.div>
                ))}
              </div>
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => setActiveTestimonial(index)}
                    className={`h-2 w-8 rounded-full transition ${
                      activeTestimonial === index
                        ? "bg-midnight"
                        : "bg-slate-300 hover:bg-slate-500"
                    }`}
                    aria-label={`Show testimonial ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl grid gap-10 px-4 md:px-6 lg:grid-cols-3 lg:px-8">
          {servicesTeasers.map((service, index) => (
            <motion.div
              key={service.title}
              className="group rounded-3xl border border-slate-200 bg-white p-7 shadow-soft transition hover:-translate-y-1 hover:border-midnight"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <span className="text-xs uppercase tracking-[0.3em] text-azurePulse">
                Collaboration
              </span>
              <h3 className="mt-3 font-heading text-xl font-semibold text-midnight">
                {service.title}
              </h3>
              <p className="mt-3 text-sm text-slate-600">{service.description}</p>
              <Link
                to={service.link}
                className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-azurePulse transition group-hover:translate-x-1"
              >
                Discover program
                <span aria-hidden="true">→</span>
              </Link>
            </motion.div>
          ))}
        </section>

        <section className="mx-auto max-w-7xl px-4 md:px-6 lg:px-8">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
            <h2 className="font-heading text-3xl font-semibold text-midnight">
              Frequently asked questions
            </h2>
            <div className="mt-6 space-y-4">
              {faqItems.map((item, index) => (
                <details
                  key={item.question}
                  className="group rounded-2xl border border-slate-100 bg-cloudMist/70 p-5"
                >
                  <summary className="flex cursor-pointer items-center justify-between text-left text-sm font-semibold text-midnight">
                    <span>{item.question}</span>
                    <span className="text-azurePulse transition group-open:rotate-45">
                      +
                    </span>
                  </summary>
                  <motion.p
                    initial={{ opacity: 0, height: 0 }}
                    whileInView={{ opacity: 1, height: "auto" }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4 }}
                    className="mt-3 text-sm text-slate-600"
                  >
                    {item.answer}
                  </motion.p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 md:px-6 lg:px-8">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
            <div className="grid gap-8 lg:grid-cols-2">
              <div className="space-y-4">
                <h2 className="font-heading text-3xl font-semibold text-midnight">
                  Latest from the blog
                </h2>
                <p className="text-sm text-slate-600">
                  Essays, interviews, and research dispatches to keep your teams
                  aligned.
                </p>
              </div>
              <div className="grid gap-6">
                {blogPreview.map((post, index) => (
                  <motion.div
                    key={post.title}
                    className="rounded-2xl border border-slate-100 bg-cloudMist/70 p-5"
                    initial={{ opacity: 0, x: 30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.6 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <h3 className="font-heading text-lg font-semibold text-midnight">
                      {post.title}
                    </h3>
                    <p className="mt-2 text-sm text-slate-600">{post.excerpt}</p>
                    <Link
                      to={post.link}
                      className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-azurePulse transition hover:opacity-80"
                    >
                      Read insights
                      <span aria-hidden="true">→</span>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-4xl rounded-3xl border border-azurePulse/20 bg-midnight p-10 text-white shadow-soft">
          <div className="space-y-4 text-center">
            <h2 className="font-heading text-3xl font-semibold">
              Subscribe to the DevLayer signal
            </h2>
            <p className="text-sm text-slate-200">
              Monthly research briefings, workflow frameworks, and behind-the-scenes
              editorial notes curated for engineering leaders and systems thinkers.
            </p>
            <form className="mx-auto flex max-w-lg flex-col gap-3 sm:flex-row">
              <label className="sr-only" htmlFor="newsletter-email">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                name="email"
                required
                placeholder="you@organization.com"
                className="w-full rounded-full border border-slate-600 bg-white/10 px-5 py-3 text-sm text-white placeholder:text-slate-300 focus:border-azurePulse focus:outline-none focus:ring-2 focus:ring-azurePulse/40"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center rounded-full bg-azurePulse px-5 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-blue-500"
              >
                Join the signal
              </button>
            </form>
            <p className="text-xs text-slate-300">
              We respect your inbox and uphold Canadian anti-spam regulations.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 text-center md:px-6 lg:px-8">
          <div className="rounded-3xl border border-slate-200 bg-white p-12 shadow-soft">
            <h2 className="font-heading text-3xl font-semibold text-midnight">
              Ready to shape your developer narrative?
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              Let’s partner on editorial research, knowledge architecture, and
              workflow storytelling that aligns engineering vision with business
              context.
            </p>
            <div className="mt-6 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                to="/services"
                className="inline-flex items-center justify-center rounded-full bg-midnight px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-slateDeep"
              >
                Explore programs
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center rounded-full border border-slate-300 px-6 py-3 text-sm font-semibold text-midnight transition hover:border-midnight"
              >
                Start a conversation
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;