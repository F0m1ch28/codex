import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import { motion, AnimatePresence } from "framer-motion";

const services = [
  {
    title: "Editorial research labs",
    summary:
      "Collaborative investigations that trace workflow friction, platform adoption, and cognitive load through interviews and telemetry.",
    details: [
      "Service blueprints mapping tooling, rituals, and dependencies",
      "Annotated research decks for leadership stakeholders",
      "Recommendations shaped by behavioural science"
    ]
  },
  {
    title: "Narrative playbook production",
    summary:
      "Custom long-form artefacts turning engineering achievements into strategic narratives for executive, product, and customer audiences.",
    details: [
      "Editorial strategy, tone, and voice development",
      "Visual storytelling with diagrams and data illustrations",
      "Enablement guides for internal communications"
    ]
  },
  {
    title: "Knowledge architecture design",
    summary:
      "Structuring documentation ecosystems that keep developers oriented and reduce search fatigue across tools, runbooks, and portals.",
    details: [
      "Information architecture workshops and audits",
      "Portal taxonomy aligned with team workflows",
      "Maintenance rituals that keep knowledge current"
    ]
  }
];

const projectGallery = [
  {
    title: "Platform Runbook Modernization",
    category: "Workflow Automation",
    description:
      "Reimagined incident documentation for a large-scale e-commerce platform, integrating runtime telemetry and on-call ergonomics.",
    image: "https://picsum.photos/1200/800?random=4"
  },
  {
    title: "Cloud Sovereignty Narrative",
    category: "Cloud Architecture",
    description:
      "Produced a narrative for public sector leadership on balancing compliance with delivery agility in hybrid cloud environments.",
    image: "https://picsum.photos/1200/800?random=44"
  },
  {
    title: "Developer Portal Storycraft",
    category: "Knowledge Systems",
    description:
      "Led workshops and editorial design for a developer portal relaunch focusing on search, onboarding, and golden paths.",
    image: "https://picsum.photos/1200/800?random=444"
  },
  {
    title: "Incident Culture Report",
    category: "Culture",
    description:
      "Co-authored a report on psychological safety in incident response, blending qualitative interviews with operational metrics.",
    image: "https://picsum.photos/1200/800?random=404"
  }
];

const filters = ["All", "Workflow Automation", "Cloud Architecture", "Knowledge Systems", "Culture"];

const faq = [
  {
    question: "What does a typical engagement timeline look like?",
    answer:
      "Engagements often span 6 to 8 weeks, starting with discovery interviews, continuing through collaborative synthesis, and concluding with editorial delivery plus enablement workshops."
  },
  {
    question: "Do you work with startups and enterprises alike?",
    answer:
      "Yes. Our approach scales for teams of varying size. We shape pricing and scope according to complexity, stakeholders, and editorial assets required."
  },
  {
    question: "Can DevLayer integrate with internal data sources?",
    answer:
      "We collaborate closely with security and compliance teams to access relevant telemetry responsibly, abiding by data handling policies and anonymization requirements."
  },
  {
    question: "Do you provide ongoing support post-engagement?",
    answer:
      "We offer stewardship retainers for update cycles, mentorship for internal editorial teams, and quarterly reviews to ensure artefacts remain aligned with evolving systems."
  }
];

const Services: React.FC = () => {
  const [activeService, setActiveService] = useState(services[0]);
  const [selectedFilter, setSelectedFilter] = useState("All");

  const filteredProjects = useMemo(() => {
    if (selectedFilter === "All") return projectGallery;
    return projectGallery.filter((project) => project.category === selectedFilter);
  }, [selectedFilter]);

  return (
    <>
      <Helmet>
        <title>DevLayer Services | Editorial Programs for Engineering Teams</title>
        <meta
          name="description"
          content="Explore DevLayer's editorial research labs, narrative playbooks, and knowledge architecture services for engineering organizations."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-6xl px-4 md:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-[1.1fr,0.9fr] lg:items-center">
            <div className="space-y-6">
              <span className="text-xs uppercase tracking-[0.35em] text-azurePulse">
                Services
              </span>
              <h1 className="font-heading text-4xl font-semibold text-midnight">
                Editorial programs built for engineering leaders.
              </h1>
              <p className="text-base leading-relaxed text-slate-600">
                DevLayer collaborates with platform, product, and developer
                experience teams to design editorial assets that align leadership
                and teams around shared narratives. We combine research, writing,
                and facilitation to strengthen decision-making and knowledge flow.
              </p>
              <p className="text-base leading-relaxed text-slate-600">
                Our work spans editorial strategy, documentation ecosystems,
                narrative playbooks, and workflow modernization. Every engagement
                includes co-creation with your practitioners to preserve context
                and authenticity.
              </p>
            </div>
            <div className="rounded-3xl border border-slate-200 bg-cloudMist/60 p-6 shadow-soft">
              <h2 className="font-heading text-2xl font-semibold text-midnight">
                How it works
              </h2>
              <ul className="mt-4 space-y-3 text-sm text-slate-600">
                <li>• Discovery session to align objectives and stakeholders.</li>
                <li>• Research sprint with interviews, artefact analysis, and telemetry review.</li>
                <li>• Editorial co-creation with iterative feedback loops.</li>
                <li>• Delivery with enablement workshops and knowledge stewardship plan.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-cloudMist py-16">
        <div className="mx-auto max-w-6xl px-4 md:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-[0.8fr,1.2fr]">
            <div className="space-y-6">
              <h2 className="font-heading text-3xl font-semibold text-midnight">
                Select a program
              </h2>
              <p className="text-sm text-slate-600">
                Choose a pillar to explore the activities and outcomes we deliver.
              </p>
              <div className="flex flex-col gap-3">
                {services.map((service) => (
                  <button
                    key={service.title}
                    type="button"
                    onClick={() => setActiveService(service)}
                    className={`rounded-2xl border px-4 py-3 text-left transition ${
                      activeService.title === service.title
                        ? "border-midnight bg-white shadow-soft"
                        : "border-slate-200 bg-white/70 hover:border-midnight"
                    }`}
                  >
                    <p className="font-heading text-lg font-semibold text-midnight">
                      {service.title}
                    </p>
                    <p className="text-sm text-slate-600">{service.summary}</p>
                  </button>
                ))}
              </div>
            </div>
            <AnimatePresence mode="wait">
              <motion.div
                key={activeService.title}
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -40 }}
                transition={{ duration: 0.5 }}
                className="rounded-3xl border border-slate-200 bg-white p-8 shadow-soft"
              >
                <h3 className="font-heading text-2xl font-semibold text-midnight">
                  {activeService.title}
                </h3>
                <p className="mt-3 text-sm text-slate-600">
                  {activeService.summary}
                </p>
                <ul className="mt-6 space-y-3 text-sm text-slate-600">
                  {activeService.details.map((detail) => (
                    <li key={detail} className="flex gap-3">
                      <span className="mt-1 h-2 w-2 rounded-full bg-azurePulse" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-6xl space-y-8 px-4 md:px-6 lg:px-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="space-y-2">
              <h2 className="font-heading text-3xl font-semibold text-midnight">
                Featured projects
              </h2>
              <p className="text-sm text-slate-600">
                Illustrative collaborations that showcase DevLayer’s editorial and
                research practice.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {filters.map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setSelectedFilter(filter)}
                  className={`rounded-full border px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] transition ${
                    selectedFilter === filter
                      ? "border-midnight bg-midnight text-white shadow-soft"
                      : "border-slate-300 bg-white text-slate-600 hover:border-midnight"
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            {filteredProjects.map((project) => (
              <motion.article
                key={project.title}
                className="overflow-hidden rounded-3xl border border-slate-200 bg-cloudMist/60 shadow-soft"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ duration: 0.6 }}
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="h-64 w-full object-cover"
                  loading="lazy"
                />
                <div className="space-y-3 p-6">
                  <span className="text-xs uppercase tracking-[0.3em] text-azurePulse">
                    {project.category}
                  </span>
                  <h3 className="font-heading text-xl font-semibold text-midnight">
                    {project.title}
                  </h3>
                  <p className="text-sm text-slate-600">{project.description}</p>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-cloudMist py-16">
        <div className="mx-auto max-w-6xl space-y-6 px-4 md:px-6 lg:px-8">
          <h2 className="font-heading text-3xl font-semibold text-midnight">
            Frequently asked
          </h2>
          <div className="space-y-4">
            {faq.map((item) => (
              <details
                key={item.question}
                className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft"
              >
                <summary className="flex cursor-pointer items-center justify-between text-sm font-semibold text-midnight">
                  <span>{item.question}</span>
                  <span className="text-azurePulse transition group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-sm text-slate-600">{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-midnight py-20 text-white">
        <div className="mx-auto max-w-4xl space-y-6 px-4 text-center md:px-6 lg:px-8">
          <h2 className="font-heading text-3xl font-semibold">
            Bring editorial intelligence to your engineering practice
          </h2>
          <p className="text-sm text-slate-200">
            We’re ready to design research programs, knowledge architectures, and
            narratives that align every layer of your organization. DevLayer
            anchors each engagement in clarity, evidence, and purposeful
            storytelling.
          </p>
          <div className="flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a
              href="mailto:hello@devlayer.ca"
              className="inline-flex items-center justify-center rounded-full bg-azurePulse px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-blue-500"
            >
              hello@devlayer.ca
            </a>
            <a
              href="tel:+14169056621"
              className="inline-flex items-center justify-center rounded-full border border-slate-400 px-6 py-3 text-sm font-semibold text-white transition hover:border-white"
            >
              +1 (416) 905-6621
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;