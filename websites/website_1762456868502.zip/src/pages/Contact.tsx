import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { useNavigate } from "react-router-dom";

type FormState = {
  name: string;
  email: string;
  organization: string;
  role: string;
  topic: string;
  message: string;
};

const defaultState: FormState = {
  name: "",
  email: "",
  organization: "",
  role: "",
  topic: "Editorial collaboration",
  message: ""
};

const Contact: React.FC = () => {
  const [form, setForm] = useState<FormState>(defaultState);
  const [errors, setErrors] = useState<Partial<FormState>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const validate = () => {
    const newErrors: Partial<FormState> = {};
    if (!form.name.trim()) newErrors.name = "Please add your name.";
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/))
      newErrors.email = "Please provide a valid email address.";
    if (!form.message.trim())
      newErrors.message = "A brief message helps us prepare.";
    return newErrors;
  };

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      navigate("/contact/thanks", { replace: true, state: { form } });
    }, 800);
  };

  return (
    <>
      <Helmet>
        <title>Contact DevLayer | Connect with the Editorial Team</title>
        <meta
          name="description"
          content="Reach the DevLayer editorial collective in Toronto to discuss collaborations, research, and developer workflow storytelling."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl px-4 md:px-6 lg:px-8">
          <div className="space-y-4">
            <span className="text-xs uppercase tracking-[0.35em] text-azurePulse">
              Contact
            </span>
            <h1 className="font-heading text-4xl font-semibold text-midnight">
              Let’s create clarity around your engineering narrative.
            </h1>
            <p className="max-w-2xl text-base leading-relaxed text-slate-600">
              Share a few details about your team, goals, and engineering
              questions. We respond within two business days with a discovery call
              invitation and initial perspective on how DevLayer can support you.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-cloudMist py-16">
        <div className="mx-auto grid max-w-5xl gap-12 px-4 md:grid-cols-[1.1fr,0.9fr] md:px-6 lg:px-8">
          <form
            onSubmit={handleSubmit}
            className="space-y-6 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft"
            noValidate
          >
            <div className="grid gap-4 md:grid-cols-2">
              <label className="text-sm font-semibold text-midnight">
                Full name
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-midnight focus:border-azurePulse focus:outline-none focus:ring-2 focus:ring-azurePulse/40"
                  required
                />
                {errors.name && (
                  <span className="mt-1 block text-xs text-red-500">{errors.name}</span>
                )}
              </label>

              <label className="text-sm font-semibold text-midnight">
                Email
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-midnight focus:border-azurePulse focus:outline-none focus:ring-2 focus:ring-azurePulse/40"
                  required
                />
                {errors.email && (
                  <span className="mt-1 block text-xs text-red-500">{errors.email}</span>
                )}
              </label>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <label className="text-sm font-semibold text-midnight">
                Organization
                <input
                  type="text"
                  name="organization"
                  value={form.organization}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-midnight focus:border-azurePulse focus:outline-none focus:ring-2 focus:ring-azurePulse/40"
                />
              </label>

              <label className="text-sm font-semibold text-midnight">
                Role
                <input
                  type="text"
                  name="role"
                  value={form.role}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-midnight focus:border-azurePulse focus:outline-none focus:ring-2 focus:ring-azurePulse/40"
                />
              </label>
            </div>

            <label className="text-sm font-semibold text-midnight">
              Discussion topic
              <select
                name="topic"
                value={form.topic}
                onChange={handleChange}
                className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-midnight focus:border-azurePulse focus:outline-none focus:ring-2 focus:ring-azurePulse/40"
              >
                <option>Editorial collaboration</option>
                <option>Research lab inquiry</option>
                <option>Knowledge architecture</option>
                <option>Speaking or workshop</option>
                <option>General question</option>
              </select>
            </label>

            <label className="text-sm font-semibold text-midnight">
              Message
              <textarea
                name="message"
                value={form.message}
                onChange={handleChange}
                rows={5}
                className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-midnight focus:border-azurePulse focus:outline-none focus:ring-2 focus:ring-azurePulse/40"
                placeholder="Share context, goals, or timelines."
                required
              />
              {errors.message && (
                <span className="mt-1 block text-xs text-red-500">{errors.message}</span>
              )}
            </label>

            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex w-full items-center justify-center rounded-full bg-midnight px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-slateDeep disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isSubmitting ? "Sending..." : "Submit"}
            </button>
            <p className="text-xs text-slate-500">
              By submitting, you consent to our handling of the data in accordance
              with the{" "}
              <a href="/privacy" className="text-azurePulse underline">
                privacy policy
              </a>
              .
            </p>
          </form>

          <div className="space-y-6">
            <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h2 className="font-heading text-2xl font-semibold text-midnight">
                Reach us directly
              </h2>
              <ul className="mt-4 space-y-3 text-sm text-slate-600">
                <li>
                  Email:{" "}
                  <a
                    className="text-azurePulse underline"
                    href="mailto:hello@devlayer.ca"
                  >
                    hello@devlayer.ca
                  </a>
                </li>
                <li>
                  Phone:{" "}
                  <a className="text-azurePulse underline" href="tel:+14169056621">
                    +1 (416) 905-6621
                  </a>
                </li>
                <li>Address: 333 Bay St, Toronto, ON M5H 2R2, Canada</li>
                <li>
                  GitHub:{" "}
                  <a
                    className="text-azurePulse underline"
                    href="https://github.com/devlayer-platform"
                    target="_blank"
                    rel="noreferrer"
                  >
                    github.com/devlayer-platform
                  </a>
                </li>
                <li>
                  LinkedIn:{" "}
                  <a
                    className="text-azurePulse underline"
                    href="https://www.linkedin.com/company/devlayer"
                    target="_blank"
                    rel="noreferrer"
                  >
                    linkedin.com/company/devlayer
                  </a>
                </li>
              </ul>
            </div>

            <div className="overflow-hidden rounded-3xl border border-slate-200 shadow-soft">
              <iframe
                title="DevLayer Toronto Office"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.093158017159!2d-79.38165952370925!3d43.648610053759535!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34d7fb91b151%3A0x73fc8231961aec1!2s333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2%2C%20Canada!5e0!3m2!1sen!2sca!4v1709763841002!5m2!1sen!2sca"
                width="100%"
                height="300"
                loading="lazy"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;