import React from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";

const values = [
  {
    title: "Systems literacy",
    description:
      "We map interactions across architecture, process, and human behaviour to reveal the dependencies that influence delivery."
  },
  {
    title: "Editorial rigor",
    description:
      "Every essay blends primary research, lived practitioner experience, and clear storytelling anchored in credible sources."
  },
  {
    title: "Ethical curiosity",
    description:
      "We examine how technology impacts cognition, inclusion, and sustainability—balancing progress with responsibility."
  }
];

const team = [
  {
    name: "Leah Chan",
    role: "Editor-in-Chief",
    focus:
      "Former platform engineer guiding narratives on distributed systems and cognitive ergonomics.",
    img: "https://picsum.photos/400/400?random=3"
  },
  {
    name: "Rami Desrochers",
    role: "Lead Researcher",
    focus:
      "Data storytelling specialist translating workflow telemetry into clear visual frameworks.",
    img: "https://picsum.photos/400/400?random=33"
  },
  {
    name: "Naomi Venkataraman",
    role: "Head of Community",
    focus:
      "Facilitates dialogues across DevLayer contributors, ensuring inclusive and sustainable editorial practices.",
    img: "https://picsum.photos/400/400?random=333"
  },
  {
    name: "Andre Hernandez",
    role: "Technical Producer",
    focus:
      "Builds interactive knowledge artefacts, diagrams, and workshop kits that accompany every essay release.",
    img: "https://picsum.photos/400/400?random=303"
  }
];

const About: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>About DevLayer | Mission, Values, and Team</title>
        <meta
          name="description"
          content="Discover DevLayer’s mission, editorial values, methodology, ethics, and the people behind the Canadian developer-focused platform."
        />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "AboutPage",
            name: "About DevLayer",
            url: "https://www.devlayer.ca/about",
            mainEntity: {
              "@type": "Organization",
              name: "DevLayer",
              foundingDate: "2020",
              founder: "DevLayer Editorial Collective",
              location: {
                "@type": "Place",
                name: "Toronto, Canada"
              }
            }
          })}
        </script>
      </Helmet>

      <section className="relative overflow-hidden bg-white">
        <div className="absolute inset-0 bg-gradient-to-br from-cloudMist via-white to-cloudMist" />
        <div className="relative mx-auto max-w-6xl px-4 py-20 md:px-6 lg:px-8">
          <div className="grid gap-14 lg:grid-cols-[1.2fr,0.8fr]">
            <div className="space-y-6">
              <span className="text-xs uppercase tracking-[0.35em] text-azurePulse">
                Our mission
              </span>
              <h1 className="font-heading text-4xl font-semibold text-midnight md:text-5xl">
                We illuminate the engineering layers that shape meaningful
                software delivery.
              </h1>
              <p className="text-base leading-relaxed text-slate-600">
                DevLayer exists to champion thoughtful developer experiences
                across Canada and beyond. We are fascinated by the interplay
                between socio-technical systems, infrastructure craftsmanship,
                and human cognition. Through essays, research programs, and
                workshops, we create space for practitioners to reflect, learn,
                and design future-ready workflows.
              </p>
              <p className="text-base leading-relaxed text-slate-600">
                Our editorial foundation is built on listening to engineers,
                ops leaders, SREs, product strategists, and cognitive
                scientists. We convert those conversations into stories that
                resonate with decision-makers while honouring the nuance of
                technical practice.
              </p>
            </div>
            <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h2 className="font-heading text-2xl font-semibold text-midnight">
                Editorial methodology
              </h2>
              <p className="mt-4 text-sm text-slate-600">
                Each DevLayer project follows a transparent methodology:
              </p>
              <ul className="mt-4 space-y-4 text-sm text-slate-600">
                <li>
                  <strong className="font-semibold text-midnight">
                    Baseline research:
                  </strong>{" "}
                  We gather telemetry, documentation, incident data, and
                  interviews to build context maps.
                </li>
                <li>
                  <strong className="font-semibold text-midnight">
                    Synthesis workshop:
                  </strong>{" "}
                  Editorial, research, and practitioner teams co-create models,
                  diagrams, and theme hypotheses.
                </li>
                <li>
                  <strong className="font-semibold text-midnight">
                    Narrative design:
                  </strong>{" "}
                  We craft long-form essays, interactive artefacts, and knowledge
                  toolkits that convey insight without jargon.
                </li>
                <li>
                  <strong className="font-semibold text-midnight">
                    Stewardship:
                  </strong>{" "}
                  DevLayer maintains ongoing relationships to measure impact and
                  update artefacts as systems evolve.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-12 px-4 py-20 md:px-6 lg:px-8">
        <div className="space-y-3">
          <h2 className="font-heading text-3xl font-semibold text-midnight">
            Editorial values
          </h2>
          <p className="text-sm text-slate-600">
            Our values keep DevLayer grounded in integrity, clarity, and
            curiosity.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {values.map((value) => (
            <motion.div
              key={value.title}
              className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:border-midnight"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.6 }}
            >
              <h3 className="font-heading text-xl font-semibold text-midnight">
                {value.title}
              </h3>
              <p className="mt-3 text-sm text-slate-600">{value.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="bg-cloudMist py-20">
        <div className="mx-auto max-w-6xl space-y-12 px-4 md:px-6 lg:px-8">
          <div className="space-y-4 text-center">
            <h2 className="font-heading text-3xl font-semibold text-midnight">
              The DevLayer collective
            </h2>
            <p className="mx-auto max-w-2xl text-sm text-slate-600">
              A multi-disciplinary team weaving editorial craft with platform
              engineering expertise.
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-2">
            {team.map((member) => (
              <motion.div
                key={member.name}
                className="group overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-soft transition hover:-translate-y-1 hover:border-midnight"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.6 }}
              >
                <img
                  src={member.img}
                  alt={`${member.name}, ${member.role}`}
                  className="h-64 w-full object-cover"
                  loading="lazy"
                />
                <div className="space-y-3 p-6">
                  <h3 className="font-heading text-xl font-semibold text-midnight">
                    {member.name}
                  </h3>
                  <p className="text-xs uppercase tracking-[0.3em] text-azurePulse">
                    {member.role}
                  </p>
                  <p className="text-sm text-slate-600">{member.focus}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-20 md:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2">
          <div className="space-y-4">
            <h2 className="font-heading text-3xl font-semibold text-midnight">
              Our editorial history
            </h2>
            <p className="text-sm text-slate-600">
              DevLayer started in 2020 as a newsletter documenting the day-to-day
              realities of platform engineers in Toronto. What began as
              annotated notebooks became public essays, research playbooks, and
              community roundtables. Today, we collaborate with teams across
              Canada, the United States, and Europe to surface lessons and
              frameworks that others can adapt.
            </p>
            <p className="text-sm text-slate-600">
              Our archives house RFCs, legacy documentation, and oral histories
              that contextualize current tooling trends. We believe that modern
              engineering practice gains depth when anchored in historical
              awareness.
            </p>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
            <h3 className="font-heading text-xl font-semibold text-midnight">
              Ethics statement
            </h3>
            <p className="mt-3 text-sm text-slate-600">
              DevLayer maintains strict editorial independence. We disclose
              partnerships, cite sources, and honour contributor consent. Our
              research follows Canadian privacy statutes, with transparent
              handling of any data. When we discuss incidents or internal
              workflows, we anonymize sensitive details while preserving
              learning value.
            </p>
            <p className="mt-3 text-sm text-slate-600">
              We recognise that technology narratives can reinforce inequities.
              Our team actively seeks voices from underrepresented communities
              and ensures inclusive language across every publication.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;