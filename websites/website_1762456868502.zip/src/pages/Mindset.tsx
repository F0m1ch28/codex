import React from "react";
import { Helmet } from "react-helmet";

const Mindset: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Developer Mindset | DevLayer</title>
        <meta
          name="description"
          content="DevLayer essays on developer cognition, burnout prevention, communication, and focus rituals."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-4xl space-y-6 px-4 md:px-6 lg:px-8">
          <h1 className="font-heading text-4xl font-semibold text-midnight">
            Developer mindset and cognitive sustainability.
          </h1>
          <p className="text-base leading-relaxed text-slate-600">
            We examine how cognition, motivation, and psychological safety shape
            software delivery. Our essays blend research insights with practical
            rituals teams can adopt.
          </p>
        </div>
      </section>

      <section className="bg-cloudMist py-12">
        <div className="mx-auto grid max-w-4xl gap-8 px-4 md:grid-cols-2 md:px-6 lg:px-8">
          <article className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Cognitive load mapping
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              Frameworks for assessing the mental overhead placed on developers,
              including task complexity, knowledge debt, and communication demands.
            </p>
          </article>
          <article className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Burnout signals
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              Research-backed indicators for spotting burnout early, plus rituals
              that encourage restoration, autonomy, and mentorship.
            </p>
          </article>
          <article className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Communication ergonomics
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              High-context communication practices that keep distributed teams
              aligned without overwhelming asynchronous channels.
            </p>
          </article>
          <article className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Focus rituals
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              Techniques to protect engineering focus: deep work blocks,
              documentation diaries, and attention-friendly tooling setups.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Mindset;