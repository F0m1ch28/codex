import React from "react";
import { Helmet } from "react-helmet";
import { Link, useLocation } from "react-router-dom";

const ContactThanks: React.FC = () => {
  const location = useLocation();
  const form = (location.state as { form?: { name?: string } })?.form;

  return (
    <>
      <Helmet>
        <title>Thank You | DevLayer Contact Confirmation</title>
        <meta
          name="description"
          content="Thank you for contacting DevLayer. Our editorial team will respond soon."
        />
      </Helmet>

      <section className="bg-white py-24">
        <div className="mx-auto max-w-3xl space-y-6 rounded-3xl border border-slate-200 bg-cloudMist/70 p-10 text-center shadow-soft">
          <h1 className="font-heading text-3xl font-semibold text-midnight">
            Message received
          </h1>
          <p className="text-sm text-slate-600">
            Thank you{form?.name ? `, ${form.name}` : ""}! The DevLayer team will
            review your note and reach out within two business days. In the
            meantime, explore our latest research and editorial highlights.
          </p>
          <div className="flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              to="/blog"
              className="inline-flex items-center justify-center rounded-full bg-midnight px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-slateDeep"
            >
              Read essays
            </Link>
            <Link
              to="/services"
              className="inline-flex items-center justify-center rounded-full border border-slate-300 px-6 py-3 text-sm font-semibold text-midnight transition hover:border-midnight"
            >
              Explore programs
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactThanks;