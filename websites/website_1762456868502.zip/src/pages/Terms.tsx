import React from "react";
import { Helmet } from "react-helmet";

const Terms: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | DevLayer</title>
        <meta
          name="description"
          content="DevLayer terms of use detailing acceptable usage, intellectual property, disclaimers, and governing law."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-4xl space-y-8 px-4 md:px-6 lg:px-8">
          <h1 className="font-heading text-4xl font-semibold text-midnight">
            Terms of use
          </h1>
          <p className="text-sm text-slate-600">
            Last updated: January 10, 2024
          </p>
          <p className="text-base leading-relaxed text-slate-600">
            These terms govern your use of the DevLayer website, publications,
            and associated services. By accessing this site, you agree to comply
            with these terms.
          </p>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Acceptable usage
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              You agree to use the site for lawful purposes, to respect the
              intellectual property rights of DevLayer and contributors, and to
              refrain from any activity that disrupts site functionality or
              security.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Intellectual property
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              All articles, diagrams, videos, and other materials published by
              DevLayer are protected by copyright. You may reference and share
              excerpts for educational purposes with attribution. Commercial use
              requires prior written permission.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Contributor content
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Contributors retain ownership of their submissions while granting
              DevLayer a license to publish and promote the work. Contributors
              confirm that submissions do not infringe on third-party rights and
              respect confidentiality agreements.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Disclaimers
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              DevLayer content is provided for educational purposes. We strive
              for accuracy but do not warrant completeness. Any actions taken
              based on the content are at your discretion. Always consider your
              organization’s policies and consult relevant professionals when
              adapting practices.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Limitation of liability
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              DevLayer shall not be liable for indirect, incidental, or
              consequential damages arising from the use of or inability to use
              the site or its content.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Jurisdiction
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              These terms are governed by the laws of the Province of Ontario and
              the federal laws of Canada. Any disputes will be resolved in the
              courts located in Toronto, Ontario.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Updates
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              We may modify these terms from time to time. Material changes will
              be communicated through this site. Continued use after updates
              signifies acceptance.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Contact
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Questions regarding these terms can be directed to:
              <br />
              DevLayer Editorial Collective
              <br />
              333 Bay St, Toronto, ON M5H 2R2, Canada
              <br />
              Email: legal@devlayer.ca
            </p>
          </section>
        </div>
      </section>
    </>
  );
};

export default Terms;