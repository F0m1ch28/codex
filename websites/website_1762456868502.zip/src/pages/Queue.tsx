import React from "react";
import { Helmet } from "react-helmet";

const queueItems = [
  {
    title: "Cognitive Load Theory for Distributed Teams",
    author: "University of Waterloo",
    summary:
      "Academic study translating cognitive load theory into practical guidance for remote collaboration.",
    tags: ["Mindset", "Research"]
  },
  {
    title: "Policy Driven Platform Engineering",
    author: "Cloud Native Computing Foundation",
    summary:
      "Whitepaper on weaving policy-as-code into platform engineering workflows with real-world case studies.",
    tags: ["Systems", "Cloud"]
  },
  {
    title: "Incident Collaboration Patterns",
    author: "AdaptiveOps Collective",
    summary:
      "Field guide capturing narrative-driven incident response practices from Canadian SRE teams.",
    tags: ["Workflow", "Culture"]
  },
  {
    title: "Human Factors in DevOps",
    author: "O'Reilly Velocity Archive",
    summary:
      "Conference proceedings exploring the psychological and organizational aspects of DevOps transformations.",
    tags: ["Culture", "Mindset"]
  }
];

const Queue: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Reading Queue | DevLayer</title>
        <meta
          name="description"
          content="DevLayer curated reading queue featuring academic papers, whitepapers, and community resources on workflows and systems."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-4xl space-y-6 px-4 md:px-6 lg:px-8">
          <h1 className="font-heading text-4xl font-semibold text-midnight">
            Curated reading queue.
          </h1>
          <p className="text-base leading-relaxed text-slate-600">
            A rotating selection of papers, essays, and guides that complement our
            editorial themes. We update this queue bi-weekly.
          </p>
          <div className="space-y-6">
            {queueItems.map((item) => (
              <article
                key={item.title}
                className="rounded-3xl border border-slate-200 bg-cloudMist/70 p-6 shadow-soft"
              >
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <h2 className="font-heading text-2xl font-semibold text-midnight">
                      {item.title}
                    </h2>
                    <p className="text-sm text-slate-500">{item.author}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {item.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full bg-white px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-azurePulse"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <p className="mt-3 text-sm text-slate-600">{item.summary}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Queue;