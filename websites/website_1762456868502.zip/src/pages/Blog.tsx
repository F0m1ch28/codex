import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";

const posts = [
  {
    title: "Why context switching dismantles deep engineering focus",
    excerpt:
      "A neuroscience-informed analysis of the cognitive load engineers face when interrupted by competing priorities.",
    category: "Workflow",
    link: "/blog/why-context-switching-kills-productivity",
    date: "Feb 26, 2024"
  },
  {
    title: "Cloud patterns for resilient scale",
    excerpt:
      "Evolving cloud-native patterns that balance compliance, observability, and financial stewardship.",
    category: "Systems",
    link: "/blog/cloud-patterns-for-scale",
    date: "Feb 12, 2024"
  },
  {
    title: "The evolution of DevOps culture",
    excerpt:
      "Tracing how DevOps principles matured into platform engineering and the socio-technical rituals that emerged.",
    category: "Culture",
    link: "/blog/the-evolution-of-devops-culture",
    date: "Jan 29, 2024"
  },
  {
    title: "Distributed cognition in incident response",
    excerpt:
      "How teams externalize knowledge, document context, and maintain resilience under pressure.",
    category: "Culture",
    link: "/notes",
    date: "Jan 15, 2024"
  },
  {
    title: "Practical service maturity scorecards",
    excerpt:
      "A framework for measuring service health with leading indicators that resonate across departments.",
    category: "Tooling",
    link: "/workflows",
    date: "Jan 3, 2024"
  }
];

const filters = ["All", "Workflow", "Systems", "Tooling", "Culture"];

const Blog: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState("All");

  const filteredPosts = useMemo(() => {
    if (activeFilter === "All") return posts;
    return posts.filter((post) => post.category === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <Helmet>
        <title>DevLayer Blog | Workflow, Systems, Tooling, Culture</title>
        <meta
          name="description"
          content="Browse DevLayer essays on developer workflows, software systems, tooling, and engineering culture."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl px-4 md:px-6 lg:px-8">
          <span className="text-xs uppercase tracking-[0.35em] text-azurePulse">
            Blog archive
          </span>
          <h1 className="mt-4 font-heading text-4xl font-semibold text-midnight">
            Analytical essays for engineering decision-makers.
          </h1>
          <p className="mt-4 max-w-3xl text-base text-slate-600">
            Filter by category to surface research-backed essays on the workflows
            that shape teams, the systems that carry production load, the tooling
            ecosystems teams adopt, and the culture that sustains long-term
            delivery.
          </p>
        </div>
      </section>

      <section className="bg-cloudMist py-12">
        <div className="mx-auto max-w-5xl px-4 md:px-6 lg:px-8">
          <div className="flex flex-wrap gap-2">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`rounded-full border px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] transition ${
                  activeFilter === filter
                    ? "border-midnight bg-midnight text-white shadow-soft"
                    : "border-slate-300 bg-white text-slate-600 hover:border-midnight"
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          <div className="mt-10 grid gap-6">
            {filteredPosts.map((post) => (
              <article
                key={post.title}
                className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:border-midnight"
              >
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <span className="text-xs uppercase tracking-[0.3em] text-azurePulse">
                      {post.category}
                    </span>
                    <h2 className="mt-2 font-heading text-2xl font-semibold text-midnight">
                      {post.title}
                    </h2>
                    <p className="mt-2 text-sm text-slate-600">{post.excerpt}</p>
                  </div>
                  <div className="flex flex-col items-start gap-2 text-sm text-slate-500 md:items-end">
                    <span>{post.date}</span>
                    <Link
                      to={post.link}
                      className="inline-flex items-center gap-2 font-semibold text-azurePulse transition hover:opacity-80"
                    >
                      Read
                      <span aria-hidden="true">→</span>
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;