import React from "react";
import { Helmet } from "react-helmet";

const Privacy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | DevLayer</title>
        <meta
          name="description"
          content="DevLayer privacy policy explaining cookie usage, analytics, data processing, third-party providers, and user rights."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-4xl space-y-8 px-4 md:px-6 lg:px-8">
          <h1 className="font-heading text-4xl font-semibold text-midnight">
            Privacy policy
          </h1>
          <p className="text-sm text-slate-600">
            Effective date: January 10, 2024
          </p>
          <p className="text-base leading-relaxed text-slate-600">
            DevLayer is committed to responsible stewardship of personal
            information. This policy outlines the types of data we collect, how
            we use it, and the rights you have as a reader or collaborator.
          </p>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Cookies
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              We use cookies to remember preferences, analyze engagement, and
              support essential site functionality. You can accept or decline
              cookies via the banner. Declining may limit personalization but you
              will still be able to access published content.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Analytics
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              DevLayer uses privacy-conscious analytics platforms hosted in
              Canada. Aggregated metrics help our editorial team understand which
              topics resonate, how readers navigate the site, and where we can
              improve accessibility. We do not create behavioural profiles or sell
              data to advertisers.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Data we collect
            </h2>
            <ul className="mt-2 space-y-2 text-sm text-slate-600">
              <li>
                • Contact details voluntarily provided through forms (name, email,
                organization, role).
              </li>
              <li>
                • Message content you submit when requesting collaboration or
                subscribing to updates.
              </li>
              <li>
                • Technical information such as IP address and browser type, used
                solely for security and aggregate analytics.
              </li>
            </ul>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Data processing and retention
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              We store contact form submissions in secure systems managed by
              DevLayer’s editorial operations team. Data is retained for
              relationship management and deleted when it no longer supports an
              ongoing collaboration. Newsletter email addresses are stored in our
              email service provider with opt-out links in every message.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Third-party services
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              DevLayer uses trusted partners for hosting, analytics, email
              delivery, and collaborative design. Each partner is reviewed for
              compliance with Canadian and international privacy regulations. We
              only share data necessary to deliver services and require partners to
              safeguard information appropriately.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Your rights
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              You can request access to your personal data, ask for corrections,
              or request deletion. Email{" "}
              <a className="text-azurePulse underline" href="mailto:privacy@devlayer.ca">
                privacy@devlayer.ca
              </a>{" "}
              with your request. We will respond within thirty days in accordance
              with Canadian privacy legislation.
            </p>
          </section>

          <section>
            <h2 className="font-heading text-2xl font-semibold text-midnight">
              Contact
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Privacy inquiries can be directed to:
              <br />
              DevLayer Privacy Office
              <br />
              333 Bay St, Toronto, ON M5H 2R2, Canada
              <br />
              Email: privacy@devlayer.ca
            </p>
          </section>

          <p className="text-sm text-slate-500">
            We may update this policy to reflect new practices or legal
            requirements. Material changes will be announced via the site and
            newsletter.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;