import React from "react";
import { Helmet } from "react-helmet";

const sections = [
  {
    title: "CI/CD evolution",
    description:
      "Blueprints for continuous integration and delivery systems that incorporate policy-as-code, ephemeral environments, and developer-friendly feedback loops."
  },
  {
    title: "Pipeline ergonomics",
    description:
      "Guides for designing pipelines that reduce toil, accelerate onboarding, and integrate metrics that resonate with product leadership."
  },
  {
    title: "Rituals and ceremonies",
    description:
      "Playbooks for daily standups, async updates, and retros that keep distributed teams aligned without overwhelming calendars."
  },
  {
    title: "Incident choreography",
    description:
      "Runbook templates, escalation paths, and communication protocols grounded in psychological safety and clear knowledge handoffs."
  }
];

const Workflows: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Workflows | DevLayer</title>
        <meta
          name="description"
          content="DevLayer workflow research covering CI/CD, pipeline ergonomics, and team rituals for resilient delivery."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl space-y-6 px-4 md:px-6 lg:px-8">
          <h1 className="font-heading text-4xl font-semibold text-midnight">
            Workflow patterns shaping resilient teams.
          </h1>
          <p className="text-base leading-relaxed text-slate-600">
            DevLayer studies the rituals, automation, and governance structures
            that enable high-performing engineering organizations. From pipeline
            design to knowledge sharing, our workflow research emphasizes clarity
            and cognition.
          </p>
        </div>
      </section>

      <section className="bg-cloudMist py-12">
        <div className="mx-auto grid max-w-5xl gap-8 px-4 md:grid-cols-2 md:px-6 lg:px-8">
          {sections.map((section) => (
            <article
              key={section.title}
              className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-1 hover:border-midnight"
            >
              <h2 className="font-heading text-2xl font-semibold text-midnight">
                {section.title}
              </h2>
              <p className="mt-3 text-sm text-slate-600">{section.description}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Workflows;