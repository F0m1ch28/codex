import React from "react";
import { Helmet } from "react-helmet";

const archives = [
  {
    title: "RFC 1925: The Twelve Networking Truths",
    year: 1996,
    summary:
      "A humorous yet insightful reminder that distributed systems follow patterns that still resonate in modern cloud architecture."
  },
  {
    title: "NASA Space Shuttle Software Standards",
    year: 1980,
    summary:
      "A meticulous look at aerospace software processes that inspired many modern quality assurance frameworks."
  },
  {
    title: "Bell Northern Research Software Process Handbook",
    year: 1988,
    summary:
      "Canadian telecom history documenting rigorous process models and knowledge management techniques."
  },
  {
    title: "UNIX System V Release Notes",
    year: 1983,
    summary:
      "Exploration of the modular design philosophy that influenced contemporary microservices thinking."
  }
];

const Archives: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Archives | DevLayer</title>
        <meta
          name="description"
          content="DevLayer archives featuring historical computing references, RFCs, legacy documents, and open standards."
        />
      </Helmet>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl space-y-6 px-4 md:px-6 lg:px-8">
          <h1 className="font-heading text-4xl font-semibold text-midnight">
            Historical archives for modern inspiration.
          </h1>
          <p className="text-base leading-relaxed text-slate-600">
            We collect archival documents, RFCs, and standards that continue to
            influence today’s workflows. Understanding the past sharpens our
            perspective on current systems.
          </p>
          <div className="grid gap-6 md:grid-cols-2">
            {archives.map((item) => (
              <article
                key={item.title}
                className="rounded-3xl border border-slate-200 bg-cloudMist/70 p-6 shadow-soft"
              >
                <h2 className="font-heading text-2xl font-semibold text-midnight">
                  {item.title}
                </h2>
                <p className="text-xs uppercase tracking-[0.3em] text-slate-500">
                  {item.year}
                </p>
                <p className="mt-3 text-sm text-slate-600">{item.summary}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Archives;