import React from "react";
import { Link } from "react-router-dom";

const footerLinks = {
  Platform: [
    { label: "About", to: "/about" },
    { label: "Services", to: "/services" },
    { label: "Workflows", to: "/workflows" },
    { label: "Mindset", to: "/mindset" },
    { label: "Queue", to: "/queue" }
  ],
  Editorial: [
    { label: "Blog", to: "/blog" },
    { label: "Archives", to: "/archives" },
    { label: "Notes", to: "/notes" },
    { label: "Privacy", to: "/privacy" },
    { label: "Terms", to: "/terms" }
  ],
  Connect: [
    { label: "Contact", to: "/contact" },
    {
      label: "GitHub",
      href: "https://github.com/devlayer-platform",
      external: true
    },
    {
      label: "LinkedIn",
      href: "https://www.linkedin.com/company/devlayer",
      external: true
    }
  ]
};

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 md:grid-cols-2 md:px-6 lg:grid-cols-4 lg:px-8">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-azurePulse text-white shadow-soft">
              DL
            </div>
            <div>
              <p className="font-heading text-lg font-semibold text-midnight">
                DevLayer
              </p>
              <p className="text-xs uppercase tracking-[0.2em] text-slate-500">
                Editorial Systems Studio
              </p>
            </div>
          </div>
          <p className="max-w-xs text-sm leading-relaxed text-slate-600">
            DevLayer curates practitioner-led essays and research on developer
            workflows, distributed systems, and cloud infrastructure from a
            Canadian vantage point.
          </p>
          <div className="space-y-1 text-sm text-slate-600">
            <p>333 Bay St, Toronto, ON M5H 2R2, Canada</p>
            <p>+1 (416) 905-6621</p>
          </div>
        </div>

        {Object.entries(footerLinks).map(([section, links]) => (
          <div key={section} className="space-y-4">
            <h3 className="font-heading text-sm font-semibold uppercase tracking-[0.3em] text-slate-500">
              {section}
            </h3>
            <ul className="space-y-2 text-sm text-slate-600">
              {links.map((link) =>
                link.external ? (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      target="_blank"
                      rel="noreferrer"
                      className="transition hover:text-midnight"
                    >
                      {link.label}
                    </a>
                  </li>
                ) : (
                  <li key={link.label}>
                    <Link className="transition hover:text-midnight" to={link.to!}>
                      {link.label}
                    </Link>
                  </li>
                )
              )}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-slate-200 bg-cloudMist py-6">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 text-xs uppercase tracking-[0.2em] text-slate-500 md:flex-row md:items-center md:justify-between md:px-6 lg:px-8">
          <span>© {new Date().getFullYear()} DevLayer Editorial Collective</span>
          <span>for educational use only</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;