import React, { useEffect, useState } from "react";

const COOKIE_STORAGE_KEY = "devlayer-cookie-consent";

const CookieBanner: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const savedConsent = window.localStorage.getItem(COOKIE_STORAGE_KEY);
    if (!savedConsent) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  const handleConsent = (value: "accepted" | "declined") => {
    window.localStorage.setItem(COOKIE_STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="fixed inset-x-4 bottom-6 z-[60] mx-auto max-w-3xl rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
      <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
        <div className="space-y-2">
          <p className="font-semibold text-midnight">
            Cookies & analytics preferences
          </p>
          <p className="text-sm text-slate-600">
            DevLayer uses cookies for audience analytics and platform
            personalization. We value consent-first data stewardship aligned
            with Canadian privacy standards.
          </p>
        </div>
        <div className="flex shrink-0 flex-col gap-2 md:flex-row">
          <button
            type="button"
            onClick={() => handleConsent("declined")}
            className="rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:border-midnight hover:text-midnight"
          >
            Decline
          </button>
          <button
            type="button"
            onClick={() => handleConsent("accepted")}
            className="rounded-full bg-midnight px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-slateDeep"
          >
            Accept cookies
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;