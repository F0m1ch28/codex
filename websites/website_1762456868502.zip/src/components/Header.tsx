import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import classNames from "classnames";

const navItems = [
  { name: "Home", path: "/" },
  { name: "About", path: "/about" },
  { name: "Services", path: "/services" },
  { name: "Workflows", path: "/workflows" },
  { name: "Mindset", path: "/mindset" },
  { name: "Queue", path: "/queue" },
  { name: "Archives", path: "/archives" },
  { name: "Notes", path: "/notes" },
  { name: "Blog", path: "/blog" },
  { name: "Contact", path: "/contact" }
];

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen((prev) => !prev);

  return (
    <header className="sticky top-0 z-50 bg-cloudMist/80 backdrop-blur-lg shadow-sm shadow-slate-900/5">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-6 lg:px-8">
        <Link
          to="/"
          className="flex items-center gap-3"
          aria-label="DevLayer home"
        >
          <motion.div
            className="flex h-10 w-10 items-center justify-center rounded-full bg-azurePulse text-white shadow-soft"
            whileHover={{ rotate: 6 }}
            transition={{ type: "spring", stiffness: 220, damping: 18 }}
          >
            <span className="font-semibold tracking-tight">DL</span>
          </motion.div>
          <div className="flex flex-col leading-tight">
            <span className="font-heading text-lg font-semibold text-midnight">
              DevLayer
            </span>
            <span className="text-xs uppercase tracking-[0.24em] text-slate-500">
              Editorial Systems
            </span>
          </div>
        </Link>

        <nav className="hidden items-center gap-2 xl:flex" aria-label="Primary">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                classNames(
                  "rounded-full px-4 py-2 text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-midnight text-white shadow-soft"
                    : "text-slate-600 hover:bg-white hover:text-midnight hover:shadow-sm"
                )
              }
            >
              {item.name}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            to="/contact"
            className="hidden rounded-full bg-midnight px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-slateDeep xl:inline-flex"
          >
            Connect with us
          </Link>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-slate-200 bg-white text-midnight shadow-soft transition hover:bg-slate-100 xl:hidden"
            onClick={toggleMenu}
            aria-controls="mobile-navigation"
            aria-expanded={isOpen}
            aria-label="Toggle navigation menu"
          >
            <span className="h-5 w-5">
              <span
                className={classNames(
                  "block h-0.5 w-5 rounded-full bg-midnight transition-transform duration-300",
                  { "translate-y-1.5 rotate-45": isOpen }
                )}
              />
              <span
                className={classNames(
                  "mt-1 block h-0.5 w-5 rounded-full bg-midnight transition-opacity duration-300",
                  { "opacity-0": isOpen }
                )}
              />
              <span
                className={classNames(
                  "mt-1 block h-0.5 w-5 rounded-full bg-midnight transition-transform duration-300",
                  { "-translate-y-1.5 -rotate-45": isOpen }
                )}
              />
            </span>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.nav
            id="mobile-navigation"
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="xl:hidden"
          >
            <div className="space-y-2 border-t border-slate-200 bg-white px-4 py-4">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) =>
                    classNames(
                      "flex items-center justify-between rounded-2xl border px-4 py-3 text-sm font-semibold transition",
                      isActive
                        ? "border-midnight bg-midnight text-white"
                        : "border-slate-200 text-slate-600 hover:border-midnight hover:bg-slate-100 hover:text-midnight"
                    )
                  }
                >
                  <span>{item.name}</span>
                  <span aria-hidden="true">→</span>
                </NavLink>
              ))}
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;