import React, { Suspense, lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollManager from "./components/ScrollToTop";

const Home = lazy(() => import("./pages/Home"));
const About = lazy(() => import("./pages/About"));
const Services = lazy(() => import("./pages/Services"));
const Workflows = lazy(() => import("./pages/Workflows"));
const Mindset = lazy(() => import("./pages/Mindset"));
const Queue = lazy(() => import("./pages/Queue"));
const Archives = lazy(() => import("./pages/Archives"));
const Notes = lazy(() => import("./pages/Notes"));
const Blog = lazy(() => import("./pages/Blog"));
const ArticleContextSwitching = lazy(
  () => import("./pages/blog/WhyContextSwitching")
);
const ArticleCloudPatterns = lazy(
  () => import("./pages/blog/CloudPatterns")
);
const ArticleDevOpsCulture = lazy(
  () => import("./pages/blog/DevOpsCulture")
);
const Contact = lazy(() => import("./pages/Contact"));
const ContactThanks = lazy(() => import("./pages/ContactThanks"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Terms = lazy(() => import("./pages/Terms"));

const App: React.FC = () => {
  return (
    <>
      <Helmet>
        <html lang="en" />
        <title>DevLayer | Editorial Workflows for Builders</title>
        <meta
          name="description"
          content="DevLayer is a Canadian editorial platform elevating developer workflows, systems thinking, and cloud infrastructure insights."
        />
        <meta property="og:title" content="DevLayer Editorial Platform" />
        <meta
          property="og:description"
          content="Research-backed narratives on developer workflows, platform engineering, and distributed systems."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.devlayer.ca" />
        <meta property="og:image" content="https://picsum.photos/1600/900?random=999" />
      </Helmet>
      <div className="flex min-h-screen flex-col bg-cloudMist text-slate-900">
        <ScrollManager />
        <Header />
        <main className="flex-1">
          <Suspense
            fallback={
              <div className="flex min-h-[60vh] items-center justify-center bg-cloudMist">
                <div className="flex items-center gap-3 rounded-full bg-white px-6 py-3 shadow-soft">
                  <span className="h-3 w-3 animate-ping rounded-full bg-azurePulse" />
                  <span className="text-sm font-medium tracking-wide text-slate-600">
                    Loading DevLayer insights...
                  </span>
                </div>
              </div>
            }
          >
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/services" element={<Services />} />
              <Route path="/workflows" element={<Workflows />} />
              <Route path="/mindset" element={<Mindset />} />
              <Route path="/queue" element={<Queue />} />
              <Route path="/archives" element={<Archives />} />
              <Route path="/notes" element={<Notes />} />
              <Route path="/blog" element={<Blog />} />
              <Route
                path="/blog/why-context-switching-kills-productivity"
                element={<ArticleContextSwitching />}
              />
              <Route
                path="/blog/cloud-patterns-for-scale"
                element={<ArticleCloudPatterns />}
              />
              <Route
                path="/blog/the-evolution-of-devops-culture"
                element={<ArticleDevOpsCulture />}
              />
              <Route path="/contact" element={<Contact />} />
              <Route path="/contact/thanks" element={<ContactThanks />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/terms" element={<Terms />} />
            </Routes>
          </Suspense>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </>
  );
};

export default App;