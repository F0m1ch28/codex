declare const content: string;
export default content;