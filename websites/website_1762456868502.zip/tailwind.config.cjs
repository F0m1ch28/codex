module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        midnight: "#111827",
        slateDeep: "#334155",
        azurePulse: "#3B82F6",
        cloudMist: "#F1F5F9"
      },
      fontFamily: {
        heading: ["'Satoshi'", "Inter", "sans-serif"],
        body: ["Inter", "system-ui", "sans-serif"]
      },
      boxShadow: {
        soft: "0 20px 45px -20px rgba(15, 23, 42, 0.45)",
        insetGlow: "0 0 0 1px rgba(148, 163, 184, 0.25)"
      }
    }
  },
  plugins: []
};