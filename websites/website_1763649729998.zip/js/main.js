document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".main-nav");
  const body = document.body;

  const toggleNav = () => {
    const isOpen = nav.classList.toggle("is-open");
    navToggle.setAttribute("aria-expanded", isOpen);
  };

  navToggle?.addEventListener("click", toggleNav);

  nav?.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      if (nav.classList.contains("is-open")) toggleNav();
    });
  });

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", event => {
      const targetID = anchor.getAttribute("href").slice(1);
      const target = document.getElementById(targetID);
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  const currentPage = body.dataset.page;
  document.querySelectorAll(`a[data-page="${currentPage}"]`).forEach(link => {
    if (!link.classList.contains("btn")) {
      link.classList.add("is-active");
      link.setAttribute("aria-current", "page");
    }
  });

  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieButtons = document.querySelectorAll("[data-cookie]");
  const cookiePreference = localStorage.getItem("cookiePreference");

  const showCookieBanner = () => {
    cookieBanner?.classList.add("is-visible");
  };

  if (!cookiePreference) {
    setTimeout(showCookieBanner, 800);
  }

  cookieButtons.forEach(button => {
    button.addEventListener("click", () => {
      const choice = button.dataset.cookie;
      localStorage.setItem("cookiePreference", choice);
      cookieBanner.classList.remove("is-visible");
    });
  });

  const yearEl = document.getElementById("current-year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", event => {
      event.preventDefault();
      let isValid = true;

      contactForm.querySelectorAll("[required]").forEach(field => {
        const formGroup = field.closest(".form-group");
        if (!field.checkValidity() || (field.type === "checkbox" && !field.checked)) {
          isValid = false;
          formGroup.classList.add("invalid");
        } else {
          formGroup.classList.remove("invalid");
        }
      });

      if (isValid) {
        contactForm.reset();
        contactForm.querySelectorAll(".form-group").forEach(group => group.classList.remove("invalid"));
        const successMessage = contactForm.querySelector(".form-success");
        if (successMessage) {
          successMessage.style.display = "block";
          setTimeout(() => {
            successMessage.style.display = "none";
          }, 5000);
        }
      }
    });

    contactForm.querySelectorAll("input, textarea, select").forEach(field => {
      field.addEventListener("input", () => {
        field.closest(".form-group")?.classList.remove("invalid");
      });
    });
  }
});