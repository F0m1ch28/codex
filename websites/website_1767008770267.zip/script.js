(function () {
  function setYear() {
    var yearElements = document.querySelectorAll('#year');
    var currentYear = new Date().getFullYear();
    yearElements.forEach(function (el) {
      el.textContent = currentYear;
    });
  }

  function initCookieBanner() {
    var banner = document.querySelector('.cookie-banner');
    if (!banner) {
      return;
    }
    var acceptButton = banner.querySelector('[data-cookie-action="accept"]');
    var declineButton = banner.querySelector('[data-cookie-action="decline"]');
    var consent = localStorage.getItem('sl-cookie-consent');

    if (!consent) {
      banner.classList.add('active');
    }

    function handleChoice(value) {
      localStorage.setItem('sl-cookie-consent', value);
      banner.classList.remove('active');
    }

    if (acceptButton) {
      acceptButton.addEventListener('click', function () {
        handleChoice('accepted');
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', function () {
        handleChoice('declined');
      });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    setYear();
    initCookieBanner();
  });
})();