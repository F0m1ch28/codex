document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navLinks.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-accept');
    const declineButton = document.querySelector('.cookie-decline');
    const storageKey = 'genuscayqg_cookie_preference';

    function hideBanner() {
        if (cookieBanner) {
            cookieBanner.style.display = 'none';
        }
    }

    if (cookieBanner) {
        const preference = localStorage.getItem(storageKey);
        if (!preference) {
            cookieBanner.style.display = 'flex';
        }

        if (acceptButton) {
            acceptButton.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'accepted');
                hideBanner();
            });
        }

        if (declineButton) {
            declineButton.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'declined');
                hideBanner();
            });
        }
    }
});