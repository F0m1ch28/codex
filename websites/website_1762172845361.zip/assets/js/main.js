document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('navToggle');
  const nav = document.getElementById('primaryMenu');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('open');
    });
  }

  const navLinks = document.querySelectorAll('.main-nav a');
  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      if (navToggle && nav) {
        navToggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('open');
      }
    });
  });

  const scrollButton = document.getElementById('scrollTopButton');
  if (scrollButton) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 400) {
        scrollButton.classList.add('show');
      } else {
        scrollButton.classList.remove('show');
      }
    });

    scrollButton.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  const forms = document.querySelectorAll('.js-contact-form');
  forms.forEach((form) => {
    const messageElement = form.querySelector('.form-message');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      let valid = true;
      const requiredFields = form.querySelectorAll('[required]');
      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          valid = false;
          field.setAttribute('aria-invalid', 'true');
          field.classList.add('field-error');
        } else {
          field.setAttribute('aria-invalid', 'false');
          field.classList.remove('field-error');
        }
      });

      if (!valid) {
        if (messageElement) {
          messageElement.textContent = 'Өтінеміз, барлық міндетті өрістерді толтырыңыз.';
          messageElement.classList.add('error');
        }
        return;
      }

      if (messageElement) {
        messageElement.textContent = 'Рақмет! Хабарламаңыз қабылданды, команда сізге жақын уақытта хабарласады.';
        messageElement.classList.remove('error');
      }

      form.reset();
    });
  });

  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookies = document.getElementById('acceptCookies');
  if (cookieBanner && acceptCookies) {
    const consent = localStorage.getItem('kazBrandCookieConsent');
    if (consent === 'accepted') {
      cookieBanner.classList.add('hidden');
    }

    acceptCookies.addEventListener('click', () => {
      localStorage.setItem('kazBrandCookieConsent', 'accepted');
      cookieBanner.classList.add('hidden');
    });
  }

  const yearHolder = document.getElementById('currentYear');
  if (yearHolder) {
    yearHolder.textContent = new Date().getFullYear();
  }

  window.addEventListener('beforeunload', () => {
    window.scrollTo(0, 0);
  });
});