<?php
$prefillNombre = htmlspecialchars($_GET['nombre'] ?? '', ENT_QUOTES, 'UTF-8');
$prefillEmail = htmlspecialchars($_GET['email'] ?? '', ENT_QUOTES, 'UTF-8');
$prefillProyecto = htmlspecialchars($_GET['proyecto'] ?? '', ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contacto | BESS Energía España</title>
  <meta name="description" content="Contacta con BESS Energía España para solicitar un estudio de almacenamiento energético, ingeniería, instalación y monitorización.">
  <link rel="canonical" href="https://energiabessespana.com/contact.php">
  <meta property="og:type" content="article">
  <meta property="og:title" content="Contacto BESS Energía España">
  <meta property="og:description" content="Solicita información sobre sistemas BESS utility-scale, integración renovable y servicios de ingeniería.">
  <meta property="og:url" content="https://energiabessespana.com/contact.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?random=contact-bess">
  <meta property="og:site_name" content="BESS Energía España">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/styles.css">
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": ["LocalBusiness", "EnergyService"],
    "name": "BESS Energía España",
    "description": "Empresa española especializada en sistemas BESS a gran escala para integración de renovables, estabilización de red y gestión avanzada de energía.",
    "url": "https://energiabessespana.com/",
    "telephone": "+34 913 672 481",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Plaza Pablo Ruiz Picasso 1, Planta 26",
      "addressLocality": "Madrid",
      "postalCode": "28020",
      "addressCountry": "ES",
      "addressRegion": "Comunidad de Madrid"
    },
    "areaServed": {
      "@type": "Country",
      "name": "España"
    },
    "serviceType": [
      "Sistemas de almacenamiento energético",
      "Integración de energías renovables",
      "Servicios avanzados de red"
    ],
    "image": "https://picsum.photos/1200/630?random=contact-bess"
  }
  </script>
  <script src="assets/js/main.js" defer></script>
</head>
<body class="page-contact">
  <a class="skip-link" href="#contenido-principal">Saltar al contenido</a>
  <header class="site-header">
    <div class="container header-inner">
      <a href="index.html" class="logo">
        <span class="logo-mark">BESS</span>
        <span class="logo-text">BESS Energía España</span>
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="site-navigation" aria-label="Abrir menú">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      <nav class="site-nav" id="site-navigation" aria-label="Navegación principal">
        <ul>
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Nosotros</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="projects.html">Proyectos</a></li>
          <li><a href="grid-integration.html">Integración en Red</a></li>
          <li><a href="contact.php" class="button-link is-active">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenido-principal">
    <section class="section">
      <div class="container hero-grid">
        <div class="hero-intro">
          <span class="badge">Contacto</span>
          <h1>Solicita tu estudio de almacenamiento energético</h1>
          <p>Comparte los objetivos y retos de tu proyecto para que nuestros especialistas elaboren un análisis técnico y propongan la arquitectura BESS idónea.</p>
          <ul class="feature-list">
            <li>Estudios de prefactibilidad y dimensionamiento</li>
            <li>Ingeniería y construcción llave en mano</li>
            <li>Operación, mantenimiento y monitorización continua</li>
          </ul>
        </div>
        <figure class="hero-media">
          <img src="https://picsum.photos/800/500?random=contact-office" alt="Sala de reuniones del equipo de BESS Energía España" loading="lazy">
        </figure>
      </div>
    </section>

    <section class="section alt">
      <div class="container info-grid">
        <div class="info-block">
          <h2>Formulario de contacto</h2>
          <form class="cta-form" action="thanks.php" method="post">
            <div class="form-grid">
              <div>
                <label for="nombre">Nombre completo*</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo $prefillNombre; ?>" autocomplete="name" required>
              </div>
              <div>
                <label for="empresa">Empresa*</label>
                <input type="text" id="empresa" name="empresa" autocomplete="organization" required>
              </div>
            </div>
            <div class="form-grid">
              <div>
                <label for="email">Correo corporativo*</label>
                <input type="email" id="email" name="email" value="<?php echo $prefillEmail; ?>" autocomplete="email" required>
              </div>
              <div>
                <label for="telefono">Teléfono de contacto*</label>
                <input type="tel" id="telefono" name="telefono" autocomplete="tel" required>
              </div>
            </div>
            <div>
              <label for="proyecto">Tipo de proyecto*</label>
              <select id="proyecto" name="proyecto" required>
                <option value="">Selecciona una opción</option>
                <option value="solar" <?php echo ($prefillProyecto === 'solar') ? 'selected' : ''; ?>>Planta solar + almacenamiento</option>
                <option value="eolico" <?php echo ($prefillProyecto === 'eolico') ? 'selected' : ''; ?>>Parque eólico + almacenamiento</option>
                <option value="utility" <?php echo ($prefillProyecto === 'utility') ? 'selected' : ''; ?>>BESS utility-scale</option>
                <option value="industrial" <?php echo ($prefillProyecto === 'industrial') ? 'selected' : ''; ?>>Hub o microrred industrial</option>
                <option value="otro" <?php echo ($prefillProyecto === 'otro') ? 'selected' : ''; ?>>Otro</option>
              </select>
            </div>
            <div>
              <label for="mensaje">Detalles del proyecto*</label>
              <textarea id="mensaje" name="mensaje" placeholder="Describe la localización, la potencia prevista y los objetivos operativos" required></textarea>
            </div>
            <div>
              <label for="consentimiento" class="sr-only">Consentimiento de privacidad</label>
              <p>Al enviar este formulario aceptas nuestra <a href="privacy.html">política de privacidad</a>.</p>
            </div>
            <button class="button" type="submit">Enviar solicitud</button>
          </form>
        </div>
        <div class="info-block">
          <h2>Información de contacto</h2>
          <p><strong>Dirección:</strong> Torre Picaso, Plaza Pablo Ruiz Picasso 1, Planta 26, 28020 Madrid, España.</p>
          <p><strong>Teléfono:</strong> <a href="tel:+34913672481">+34 913 672 481</a></p>
          <p><strong>Correo:</strong> <a href="mailto:contacto@energiabessespana.com">contacto@energiabessespana.com</a></p>
          <p><strong>Horario:</strong> Lunes a viernes, 09:00 a 18:00 CET.</p>
          <div style="margin-top: var(--spacing-xl);">
            <iframe class="map-frame" title="Ubicación BESS Energía España" loading="lazy" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.447188699437!2d-3.6969875233385477!3d40.449427355018286!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd42281caaec1f99%3A0xec4a6a31bfb1f7f4!2sTorre%20Picasso!5e0!3m2!1ses!2ses!4v1697040000000"></iframe>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="footer">
    <div class="container footer-grid">
      <div>
        <a href="index.html" class="logo">
          <span class="logo-mark">BESS</span>
          <span class="logo-text">BESS Energía España</span>
        </a>
        <p>Contacta a nuestro equipo experto en almacenamiento energético y redes inteligentes.</p>
      </div>
      <div>
        <h4>Compañía</h4>
        <ul>
          <li><a href="about.html">Quiénes somos</a></li>
          <li><a href="projects.html">Referencias</a></li>
          <li><a href="grid-integration.html">Integración en red</a></li>
        </ul>
      </div>
      <div>
        <h4>Soluciones</h4>
        <ul>
          <li><a href="solutions.html">Portafolio</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="contact.php">Solicitar estudio</a></li>
        </ul>
      </div>
      <div>
        <h4>Contacto</h4>
        <ul>
          <li>Torre Picaso, Plaza Pablo Ruiz Picasso 1, Planta 26, 28020 Madrid</li>
          <li><a href="tel:+34913672481">+34 913 672 481</a></li>
          <li><a href="mailto:contacto@energiabessespana.com">contacto@energiabessespana.com</a></li>
        </ul>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>© <?php echo date('Y'); ?> BESS Energía España. Todos los derechos reservados.</span>
      <nav aria-label="Legal" class="legal-list">
        <a href="privacy.html">Privacidad</a>
        <a href="cookies.html">Cookies</a>
        <a href="terms.html">Condiciones legales</a>
      </nav>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <div>
      <p>Utilizamos cookies técnicas y analíticas para optimizar la experiencia en EnergiaBESSEspaña.com. Puedes aceptar o rechazar su uso en cualquier momento.</p>
    </div>
    <div class="cookie-actions">
      <button class="button" type="button" data-cookie-accept>Aceptar</button>
      <button class="button ghost" type="button" data-cookie-decline>Rechazar</button>
      <a class="cookie-link" href="cookies.html">Más información</a>
    </div>
  </div>
</body>
</html>