"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isOpen));
      siteNav.classList.toggle("is-open");
    });

    siteNav.addEventListener("click", (event) => {
      const target = event.target;
      if (target instanceof HTMLElement && target.tagName === "A" && navToggle.getAttribute("aria-expanded") === "true") {
        navToggle.setAttribute("aria-expanded", "false");
        siteNav.classList.remove("is-open");
      }
    });
  }

  const banner = document.querySelector(".cookie-banner");
  if (banner) {
    const acceptBtn = banner.querySelector("[data-cookie-accept]");
    const declineBtn = banner.querySelector("[data-cookie-decline]");
    const storageKey = "bessCookieConsent";

    let storedConsent = null;
    try {
      storedConsent = localStorage.getItem(storageKey);
    } catch (error) {
      storedConsent = null;
    }

    if (!storedConsent) {
      requestAnimationFrame(() => {
        banner.classList.add("is-visible");
      });
    }

    const setConsent = (value) => {
      try {
        localStorage.setItem(storageKey, value);
      } catch (error) {
        // ignore storage errors
      }
      banner.classList.remove("is-visible");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => setConsent("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => setConsent("declined"));
    }
  }
});