<?php
function field($key) {
  return htmlspecialchars($_POST[$key] ?? '', ENT_QUOTES, 'UTF-8');
}
$nombre = field('nombre');
$empresa = field('empresa');
$email = field('email');
$telefono = field('telefono');
$proyecto = field('proyecto');
$mensaje = field('mensaje');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Solicitud enviada | BESS Energía España</title>
  <meta name="description" content="Confirmación de solicitud enviada a BESS Energía España.">
  <link rel="canonical" href="https://energiabessespana.com/thanks.php">
  <meta property="og:type" content="article">
  <meta property="og:title" content="Solicitud enviada - BESS Energía España">
  <meta property="og:description" content="Hemos recibido tu mensaje y nuestro equipo se pondrá en contacto contigo en breve.">
  <meta property="og:url" content="https://energiabessespana.com/thanks.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?random=thanks-bess">
  <meta property="og:site_name" content="BESS Energía España">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/styles.css">
  <script src="assets/js/main.js" defer></script>
</head>
<body class="page-thanks">
  <a class="skip-link" href="#contenido-principal">Saltar al contenido</a>
  <header class="site-header">
    <div class="container header-inner">
      <a href="index.html" class="logo">
        <span class="logo-mark">BESS</span>
        <span class="logo-text">BESS Energía España</span>
      </a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="site-navigation" aria-label="Abrir menú">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      <nav class="site-nav" id="site-navigation" aria-label="Navegación principal">
        <ul>
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Nosotros</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="projects.html">Proyectos</a></li>
          <li><a href="grid-integration.html">Integración en Red</a></li>
          <li><a href="contact.php" class="button-link">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenido-principal">
    <section class="section">
      <div class="container">
        <div class="cta-panel">
          <div>
            <span class="badge">Solicitud enviada</span>
            <h1>Gracias por contactar con BESS Energía España</h1>
            <p>Hemos recibido tu petición y nuestro equipo responderá en un plazo máximo de 48 horas laborables para continuar con el análisis técnico.</p>
            <?php if ($nombre || $empresa || $proyecto): ?>
            <div class="info-block" style="margin-top: var(--spacing-lg);">
              <h3>Resumen de tu solicitud</h3>
              <ul class="feature-list">
                <?php if ($nombre): ?><li><strong>Nombre:</strong> <?php echo $nombre; ?></li><?php endif; ?>
                <?php if ($empresa): ?><li><strong>Empresa:</strong> <?php echo $empresa; ?></li><?php endif; ?>
                <?php if ($email): ?><li><strong>Correo:</strong> <?php echo $email; ?></li><?php endif; ?>
                <?php if ($telefono): ?><li><strong>Teléfono:</strong> <?php echo $telefono; ?></li><?php endif; ?>
                <?php if ($proyecto): ?><li><strong>Proyecto:</strong> <?php echo $proyecto; ?></li><?php endif; ?>
              </ul>
              <?php if ($mensaje): ?>
              <p><strong>Mensaje recibido:</strong> <?php echo $mensaje; ?></p>
              <?php endif; ?>
            </div>
            <?php endif; ?>
          </div>
          <div>
            <h2>Próximos pasos</h2>
            <ul class="feature-list">
              <li>Revisión técnica por especialistas BESS</li>
              <li>Contacto para ampliar información y datos operativos</li>
              <li>Entrega de propuesta de alcance y plan de trabajo</li>
            </ul>
            <a class="button" href="index.html">Volver al inicio</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="footer">
    <div class="container footer-grid">
      <div>
        <a href="index.html" class="logo">
          <span class="logo-mark">BESS</span>
          <span class="logo-text">BESS Energía España</span>
        </a>
        <p>Estaremos encantados de acompañarte en tu proyecto de almacenamiento energético.</p>
      </div>
      <div>
        <h4>Compañía</h4>
        <ul>
          <li><a href="about.html">Quiénes somos</a></li>
          <li><a href="projects.html">Referencias</a></li>
          <li><a href="grid-integration.html">Integración en red</a></li>
        </ul>
      </div>
      <div>
        <h4>Soluciones</h4>
        <ul>
          <li><a href="solutions.html">Portafolio</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="contact.php">Solicitar estudio</a></li>
        </ul>
      </div>
      <div>
        <h4>Contacto</h4>
        <ul>
          <li>Torre Picaso, Plaza Pablo Ruiz Picasso 1, Planta 26, 28020 Madrid</li>
          <li><a href="tel:+34913672481">+34 913 672 481</a></li>
          <li><a href="mailto:contacto@energiabessespana.com">contacto@energiabessespana.com</a></li>
        </ul>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>© <?php echo date('Y'); ?> BESS Energía España. Todos los derechos reservados.</span>
      <nav aria-label="Legal" class="legal-list">
        <a href="privacy.html">Privacidad</a>
        <a href="cookies.html">Cookies</a>
        <a href="terms.html">Condiciones legales</a>
      </nav>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
    <div>
      <p>Utilizamos cookies técnicas y analíticas para optimizar la experiencia en EnergiaBESSEspaña.com. Puedes aceptar o rechazar su uso en cualquier momento.</p>
    </div>
    <div class="cookie-actions">
      <button class="button" type="button" data-cookie-accept>Aceptar</button>
      <button class="button ghost" type="button" data-cookie-decline>Rechazar</button>
      <a class="cookie-link" href="cookies.html">Más información</a>
    </div>
  </div>
</body>
</html>