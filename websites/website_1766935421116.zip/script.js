document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const mainNav = document.querySelector('[data-main-nav]');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', function () {
      mainNav.classList.toggle('open');
    });
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const cookieChoice = localStorage.getItem('giftedbliss-cookie-choice');

  if (cookieBanner) {
    if (!cookieChoice) {
      cookieBanner.classList.remove('is-hidden');
    }

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        localStorage.setItem('giftedbliss-cookie-choice', 'accepted');
        cookieBanner.classList.add('is-hidden');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        localStorage.setItem('giftedbliss-cookie-choice', 'declined');
        cookieBanner.classList.add('is-hidden');
      });
    }
  }

  const slider = document.querySelector('[data-slider]');
  if (slider) {
    const images = [
      {
        src: 'https://picsum.photos/seed/giftjoy1/720/540',
        caption: 'Signature Christmas Grandeur Box · Ships within 48 hours',
        alt: 'Luxury holiday gift box arrangement'
      },
      {
        src: 'https://picsum.photos/seed/giftjoy2/720/540',
        caption: 'Birthday Sparkle Deluxe · Personalized confetti moments',
        alt: 'Birthday themed luxury gift box'
      },
      {
        src: 'https://picsum.photos/seed/giftjoy3/720/540',
        caption: 'Winter Wonderland Keepsake · Handcrafted artisan pieces',
        alt: 'Winter wonderland gift set'
      }
    ];
    let currentIndex = 0;
    const imgElement = slider.querySelector('img');
    const captionElement = slider.querySelector('.slider-caption');

    function updateSlider(index) {
      const item = images[index];
      imgElement.src = item.src;
      imgElement.alt = item.alt;
      captionElement.textContent = item.caption;
    }

    setInterval(function () {
      currentIndex = (currentIndex + 1) % images.length;
      slider.classList.add('fade');
      setTimeout(function () {
        updateSlider(currentIndex);
        slider.classList.remove('fade');
      }, 350);
    }, 4800);
  }

  const collectionGrid = document.querySelector('[data-collection-grid]');
  const filterButtons = document.querySelectorAll('[data-filter]');
  if (collectionGrid && filterButtons.length) {
    filterButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        filterButtons.forEach(function (btn) {
          btn.classList.remove('active');
        });
        button.classList.add('active');
        const filter = button.getAttribute('data-filter');
        const cards = collectionGrid.querySelectorAll('.card');
        cards.forEach(function (card) {
          const categories = card.getAttribute('data-category').split(' ');
          if (filter === 'all' || categories.includes(filter)) {
            card.style.display = 'grid';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }

  const customForm = document.querySelector('[data-custom-form]');
  if (customForm) {
    const summaryList = document.querySelector('[data-summary-list]');
    const summaryTotal = document.querySelector('[data-summary-total]');
    const message = document.querySelector('[data-custom-message]');

    function calculateTotal() {
      const occasion = customForm.querySelector('#box-occasion');
      const theme = customForm.querySelector('#box-theme');
      const addons = customForm.querySelectorAll('input[name="addons"]:checked');

      let total = 0;
      const occasionOption = occasion.options[occasion.selectedIndex];
      const themeOption = theme.options[theme.selectedIndex];
      total += parseFloat(occasionOption.dataset.price || 0);
      total += parseFloat(themeOption.dataset.price || 0);

      const selectedAddons = [];
      addons.forEach(function (addon) {
        total += parseFloat(addon.dataset.price || 0);
        selectedAddons.push(addon.value);
      });

      const listItems = summaryList.querySelectorAll('li');
      listItems[0].innerHTML = `<span>Occasion</span><span>${occasionOption.value}</span>`;
      listItems[1].innerHTML = `<span>Theme</span><span>${themeOption.value}</span>`;
      listItems[2].innerHTML = `<span>Add-ons</span><span>${selectedAddons.length ? selectedAddons.join(', ') : 'None'}</span>`;

      summaryTotal.textContent = `$${total.toFixed(2)}`;
    }

    customForm.addEventListener('change', calculateTotal);
    calculateTotal();

    customForm.addEventListener('submit', function (event) {
      event.preventDefault();
      message.textContent = 'Thank you! Our concierge will review your custom box and respond within 24 hours.';
      message.classList.remove('error');
      message.classList.add('success');
      customForm.reset();
      calculateTotal();
      setTimeout(function () {
        message.classList.remove('success');
        message.textContent = '';
      }, 6000);
    });
  }

  const contactForm = document.querySelector('[data-contact-form]');
  if (contactForm) {
    const message = document.querySelector('[data-contact-message]');
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const name = contactForm.querySelector('#contact-name').value.trim();
      const email = contactForm.querySelector('#contact-email').value.trim();
      const topic = contactForm.querySelector('#contact-topic').value;
      const body = contactForm.querySelector('#contact-message').value.trim();

      if (name.length < 2 || body.length < 10) {
        message.textContent = 'Please provide a valid name and message with at least 10 characters.';
        message.classList.remove('success');
        message.classList.add('error');
        return;
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        message.textContent = 'Please enter a valid email address.';
        message.classList.remove('success');
        message.classList.add('error');
        return;
      }

      if (!topic) {
        message.textContent = 'Please select a topic so we can route your request.';
        message.classList.remove('success');
        message.classList.add('error');
        return;
      }

      message.textContent = 'Message sent! Our concierge will be in touch shortly.';
      message.classList.remove('error');
      message.classList.add('success');
      contactForm.reset();
      setTimeout(function () {
        message.classList.remove('success');
        message.textContent = '';
      }, 6000);
    });
  }

  const faqList = document.querySelector('[data-faq-list]');
  if (faqList) {
    faqList.addEventListener('click', function (event) {
      const toggle = event.target.closest('[data-faq-toggle]');
      if (!toggle) return;
      const item = toggle.parentElement;
      const expanded = item.classList.contains('expanded');
      faqList.querySelectorAll('.faq-item').forEach(function (faqItem) {
        faqItem.classList.remove('expanded');
        const symbol = faqItem.querySelector('.faq-question span:last-child');
        if (symbol) symbol.textContent = '+';
      });
      if (!expanded) {
        item.classList.add('expanded');
        const symbol = item.querySelector('.faq-question span:last-child');
        if (symbol) symbol.textContent = '−';
      }
    });
  }

  const newsletterForms = document.querySelectorAll('#footer-newsletter');
  newsletterForms.forEach(function (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const input = form.querySelector('input[type="email"]');
      const message = form.querySelector('[data-newsletter-message]');
      if (!input || !message) return;

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(input.value.trim())) {
        message.textContent = 'Please enter a valid email address.';
        message.classList.remove('success');
        message.classList.add('error');
        return;
      }

      message.textContent = 'You are on the list! Expect festive updates soon.';
      message.classList.remove('error');
      message.classList.add('success');
      input.value = '';
      setTimeout(function () {
        message.classList.remove('success');
        message.textContent = '';
      }, 5000);
    });
  });
});