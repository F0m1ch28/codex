import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Pied de page">
      <div className={styles.grid}>
        <div className={styles.brandColumn}>
          <p className={styles.brandName}>Historic Streets of France Review</p>
          <p className={styles.brandDescription}>
            Publication dédiée à l’étude des rues historiques françaises, à leur conservation matérielle et aux dynamiques sociales qui les traversent.
          </p>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Navigation</h3>
          <ul className={styles.list}>
            <li><Link to="/">Accueil</Link></li>
            <li><Link to="/publications">Publications</Link></li>
            <li><Link to="/entretiens">Entretiens</Link></li>
            <li><Link to="/archives">Archives</Link></li>
            <li><Link to="/a-propos">À propos</Link></li>
            <li><Link to="/services">Approches</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Informations</h3>
          <ul className={styles.list}>
            <li><Link to="/conditions-generales">Conditions générales</Link></li>
            <li><Link to="/politique-de-confidentialite">Politique de confidentialité</Link></li>
            <li><Link to="/politique-de-cookies">Politique de cookies</Link></li>
            <li><Link to="/contact">Contact de la rédaction</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Contact</h3>
          <p className={styles.contactItem}>redaction@historicstreets-fr-review.fr</p>
          <p className={styles.contactItem}>Communication professionnelle et demandes de collaboration éditoriale.</p>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Historic Streets of France Review. Tous droits réservés.</p>
      </div>
    </footer>
  );
};

export default Footer;