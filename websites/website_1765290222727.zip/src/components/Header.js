import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="Accueil Historic Streets of France Review">
          Historic Streets of France Review
        </Link>
        <button
          className={styles.menuToggle}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
        >
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className={styles.menuLine} />
          <span className="sr-only">Ouvrir le menu</span>
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Navigation principale"
        >
          <NavLink to="/" end className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Accueil
          </NavLink>
          <NavLink to="/publications" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Publications
          </NavLink>
          <NavLink to="/entretiens" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Entretiens
          </NavLink>
          <NavLink to="/archives" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Archives
          </NavLink>
          <NavLink to="/a-propos" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            À propos
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Approches
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;