import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('hsfr-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('hsfr-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Ce site utilise des cookies nécessaires à la mesure d’audience et à l’amélioration de l’expérience de lecture. Pour en savoir plus, consulter la <Link to="/politique-de-cookies">politique de cookies</Link>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        J’ai compris
      </button>
    </div>
  );
};

export default CookieBanner;