import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './TermsOfServicePage.module.css';

const TermsOfServicePage = () => {
  return (
    <>
      <PageHelmet
        title="Conditions générales d’utilisation | Historic Streets of France Review"
        description="Conditions générales d’utilisation du site Historic Streets of France Review."
      />
      <section className={styles.page}>
        <h1>Conditions générales d’utilisation</h1>
        <p>Version en vigueur à compter du 20 mai 2024.</p>

        <h2>Article 1 – Objet</h2>
        <p>
          Les présentes conditions générales d’utilisation (CGU) encadrent l’accès et l’usage du site « Historic Streets of France Review ». En consultant le site, l’utilisateur accepte sans réserve les présentes CGU.
        </p>

        <h2>Article 2 – Accès au site</h2>
        <p>
          Le site est accessible gratuitement à tout utilisateur disposant d’un accès à Internet. Tous les frais afférents à la connexion restent à la charge de l’utilisateur. L’éditeur se réserve la possibilité de suspendre l’accès pour maintenance ou actualisation.
        </p>

        <h2>Article 3 – Contenus éditoriaux</h2>
        <p>
          Les contenus publiés relèvent d’une démarche documentaire et informative. Toute reproduction ou réutilisation nécessite une autorisation préalable de la rédaction. Les citations doivent mentionner la source complète.
        </p>

        <h2>Article 4 – Responsabilité</h2>
        <p>
          Les informations mises à disposition sont vérifiées avec soin. Toutefois, l’éditeur ne saurait être tenu responsable des éventuelles omissions ou inexactitudes résultant de sources externes. Les liens hypertextes proposés vers d’autres sites le sont à titre informatif.
        </p>

        <h2>Article 5 – Propriété intellectuelle</h2>
        <p>
          Le site et chacun des éléments qui le composent, notamment textes, images, graphismes et logo, sont protégés par le droit d’auteur. Toute utilisation non autorisée pourra faire l’objet de poursuites.
        </p>

        <h2>Article 6 – Données personnelles</h2>
        <p>
          Les modalités de collecte et de traitement des données sont détaillées dans la politique de confidentialité. L’utilisateur dispose d’un droit d’accès, de rectification et de suppression conformément à la réglementation en vigueur.
        </p>

        <h2>Article 7 – Modification des CGU</h2>
        <p>
          L’éditeur se réserve le droit de modifier les présentes CGU à tout moment. Les utilisateurs sont invités à les consulter régulièrement pour prendre connaissance des dernières mises à jour.
        </p>

        <h2>Article 8 – Contact</h2>
        <p>
          Toute question relative aux CGU peut être adressée à la rédaction : redaction@historicstreets-fr-review.fr.
        </p>
      </section>
    </>
  );
};

export default TermsOfServicePage;