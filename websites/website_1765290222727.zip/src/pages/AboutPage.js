import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  return (
    <>
      <PageHelmet
        title="À propos | Historic Streets of France Review"
        description="Présentation de la méthodologie éditoriale, de la ligne de recherche et de l’équipe de Historic Streets of France Review."
        keywords="à propos, rédaction, méthodologie, publication, rues historiques"
      />
      <section className={styles.page}>
        <header className={styles.header}>
          <h1>À propos</h1>
          <p>
            Historic Streets of France Review est une publication dédiée à l’analyse des rues historiques françaises. Les enquêtes croisent sources archivistiques, relevés urbains et témoignages d’acteurs du patrimoine.
          </p>
        </header>

        <div className={styles.grid}>
          <div className={styles.card}>
            <h2>Approche éditoriale</h2>
            <p>
              La rédaction privilégie un traitement factuel et documenté. Chaque article est relu par un binôme comprenant un historien et un urbaniste, garantissant la qualité des références et la justesse des analyses.
            </p>
            <p>
              Les textes sont rédigés en français et s’appuient sur une bibliographie transparente. Les citations d’archives sont systématiquement vérifiées auprès des institutions concernées.
            </p>
          </div>
          <div className={styles.card}>
            <h2>Méthodologie</h2>
            <ul>
              <li>Analyse des cartes anciennes et des plans contemporains.</li>
              <li>Observations de terrain, relevés photographiques et notes de parcours.</li>
              <li>Entretiens avec historiens, architectes, urbanistes et gestionnaires de patrimoine.</li>
              <li>Comparaison avec des cas européens pour contextualiser les dynamiques françaises.</li>
            </ul>
          </div>
          <div className={styles.card}>
            <h2>Comité éditorial</h2>
            <p>
              Le comité éditorial est composé de chercheuses et chercheurs spécialisés en histoire urbaine, d’architectes du patrimoine, de responsables de services municipaux et d’archivistes. Il se réunit trimestriellement pour définir les priorités éditoriales.
            </p>
          </div>
          <div className={styles.card}>
            <h2>Collaborations</h2>
            <p>
              La publication collabore régulièrement avec des institutions culturelles, des universités et des centres d’archives afin de partager méthodologies et bonnes pratiques de documentation.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;