import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => {
  return (
    <>
      <PageHelmet
        title="Politique de cookies | Historic Streets of France Review"
        description="Informations sur l’utilisation des cookies sur le site Historic Streets of France Review."
      />
      <section className={styles.page}>
        <h1>Politique de cookies</h1>
        <p>Version en vigueur à compter du 20 mai 2024.</p>

        <h2>1. Définition</h2>
        <p>
          Un cookie est un fichier texte déposé sur l’équipement de l’utilisateur lors de la consultation d’un site web. Il permet de mémoriser certaines informations afin de faciliter la navigation.
        </p>

        <h2>2. Cookies utilisés</h2>
        <ul>
          <li>Cookies strictement nécessaires à la navigation et aux mesures d’audience anonymisées.</li>
          <li>Cookies de préférence permettant de conserver l’accord de l’utilisateur sur l’utilisation des cookies.</li>
        </ul>

        <h2>3. Gestion des cookies</h2>
        <p>
          L’utilisateur peut accepter ou refuser les cookies via le bandeau d’information. Il peut également configurer son navigateur pour bloquer ou supprimer les cookies existants.
        </p>

        <h2>4. Durée de conservation</h2>
        <p>
          Les cookies de mesure d’audience sont conservés pour une durée maximale de treize mois. Les cookies de consentement sont conservés pendant douze mois.
        </p>

        <h2>5. Contact</h2>
        <p>
          Pour toute question relative aux cookies, contacter : redaction@historicstreets-fr-review.fr.
        </p>
      </section>
    </>
  );
};

export default CookiePolicyPage;