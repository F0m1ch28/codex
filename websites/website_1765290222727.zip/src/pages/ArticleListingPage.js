import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import articlesData from '../data/articles';
import styles from './ArticleListingPage.module.css';

const ArticleListingPage = () => {
  const [query, setQuery] = useState('');
  const [selectedTheme, setSelectedTheme] = useState('Tous');

  const themes = useMemo(() => {
    const set = new Set();
    articlesData.forEach((article) => {
      article.themes.forEach((theme) => set.add(theme));
    });
    return ['Tous', ...Array.from(set)];
  }, []);

  const filteredArticles = useMemo(() => {
    return articlesData.filter((article) => {
      const matchesTheme = selectedTheme === 'Tous' || article.themes.includes(selectedTheme);
      const normalizedQuery = query.trim().toLowerCase();
      const haystack = `${article.title} ${article.summary} ${article.category} ${article.themes.join(' ')}`.toLowerCase();
      const matchesQuery = normalizedQuery === '' || haystack.includes(normalizedQuery);
      return matchesTheme && matchesQuery;
    });
  }, [query, selectedTheme]);

  return (
    <>
      <PageHelmet
        title="Publications | Historic Streets of France Review"
        description="Index des publications consacrées aux rues historiques françaises : analyses urbaines, études patrimoniales et transformations sociales."
        keywords="publications, rues historiques, patrimoine urbain, France"
      />
      <section className={styles.page}>
        <div className={styles.header}>
          <h1>Publications</h1>
          <p>
            Retrouvez l’ensemble des articles de la rédaction : études diachroniques, comparaisons cartographiques et analyses d’archives autour des rues historiques françaises.
          </p>
        </div>

        <div className={styles.filters}>
          <label htmlFor="search" className={styles.searchLabel}>
            Rechercher
          </label>
          <input
            id="search"
            type="search"
            placeholder="Rechercher une rue, une ville, une époque..."
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            className={styles.searchInput}
          />
          <div className={styles.themeFilter} role="group" aria-label="Filtrer par thème">
            {themes.map((theme) => (
              <button
                key={theme}
                type="button"
                className={`${styles.themeButton} ${selectedTheme === theme ? styles.themeButtonActive : ''}`}
                onClick={() => setSelectedTheme(theme)}
              >
                {theme}
              </button>
            ))}
          </div>
        </div>

        <div className={styles.list}>
          {filteredArticles.length === 0 && (
            <p className={styles.emptyState}>
              Aucun article ne correspond à votre recherche. Ajustez les filtres pour explorer d’autres rues ou thématiques.
            </p>
          )}
          {filteredArticles.map((article) => (
            <article key={article.id} className={styles.articleItem}>
              <div className={styles.thumbnail}>
                <img src={article.coverImage} alt={article.coverImageAlt} loading="lazy" />
              </div>
              <div className={styles.articleContent}>
                <p className={styles.category}>{article.category}</p>
                <h2>{article.title}</h2>
                <p className={styles.subtitle}>{article.subtitle}</p>
                <p className={styles.summary}>{article.summary}</p>
                <div className={styles.meta}>
                  <span>{new Date(article.date).toLocaleDateString('fr-FR')}</span>
                  <span>•</span>
                  <span>{article.readingTime}</span>
                </div>
                <div className={styles.tags} aria-label="Thèmes de l’article">
                  {article.themes.map((theme) => (
                    <span key={theme}>{theme}</span>
                  ))}
                </div>
                <Link to={`/publications/${article.slug}`} className={styles.readMore}>
                  Lire l’article complet
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default ArticleListingPage;