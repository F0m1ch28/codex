import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './PrivacyPolicyPage.module.css';

const PrivacyPolicyPage = () => {
  return (
    <>
      <PageHelmet
        title="Politique de confidentialité | Historic Streets of France Review"
        description="Politique de confidentialité et modalités de traitement des données personnelles pour le site Historic Streets of France Review."
      />
      <section className={styles.page}>
        <h1>Politique de confidentialité</h1>
        <p>Version en vigueur à compter du 20 mai 2024.</p>

        <h2>1. Responsable du traitement</h2>
        <p>
          Le responsable du traitement est la rédaction de Historic Streets of France Review. Pour toute question, contacter : redaction@historicstreets-fr-review.fr.
        </p>

        <h2>2. Données collectées</h2>
        <p>
          Les données collectées via le formulaire de contact se limitent au nom, à l’adresse électronique, à l’organisation et au contenu du message. Aucune donnée sensible n’est demandée.
        </p>

        <h2>3. Finalités</h2>
        <p>
          Les informations sont utilisées exclusivement pour répondre aux demandes reçues et assurer le suivi des échanges professionnels. Elles ne font l’objet d’aucune cession à des tiers.
        </p>

        <h2>4. Base légale</h2>
        <p>
          Le traitement repose sur l’intérêt légitime de la rédaction à organiser les échanges éditoriaux et à répondre aux sollicitations.
        </p>

        <h2>5. Durée de conservation</h2>
        <p>
          Les données sont conservées pendant une durée maximale de trois ans à compter du dernier échange, puis supprimées ou anonymisées.
        </p>

        <h2>6. Droits des personnes</h2>
        <p>
          Conformément au Règlement général sur la protection des données (RGPD), toute personne dispose d’un droit d’accès, de rectification, d’effacement, de limitation et d’opposition. Les demandes sont à adresser à redaction@historicstreets-fr-review.fr.
        </p>

        <h2>7. Sécurité</h2>
        <p>
          Des mesures techniques et organisationnelles sont mises en place pour protéger les données contre les accès non autorisés, les altérations ou divulgations.
        </p>

        <h2>8. Cookies</h2>
        <p>
          Les modalités d’utilisation des cookies sont détaillées dans la politique dédiée. L’utilisateur peut gérer ses préférences directement sur son navigateur.
        </p>
      </section>
    </>
  );
};

export default PrivacyPolicyPage;