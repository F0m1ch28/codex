import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './InterviewsPage.module.css';

const interviews = [
  {
    name: 'Claire Bourdon',
    role: 'Historienne de l’urbanisme, Université Paris 1 Panthéon-Sorbonne',
    quote:
      'Les rues historiques constituent des archives à ciel ouvert. Chaque façade traduit une négociation entre les pouvoirs publics, les propriétaires et les habitants successifs.',
    focus: 'Étude comparée des politiques de sauvegarde des rues commerçantes parisiennes.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Mahdi Rahmani',
    role: 'Architecte du patrimoine, Atelier des territoires méditerranéens',
    quote:
      'Observer les rues marseillaises suppose de prendre en compte la lumière, les matériaux mais aussi les usages portuaires qui façonnent le quotidien.',
    focus: 'Diagnostic patrimonial de la Canebière et accompagnement des commerces historiques.',
    image: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?auto=format&fit=crop&w=400&q=80',
  },
  {
    name: 'Sophie Rückert',
    role: 'Urbaniste, Eurométropole de Strasbourg',
    quote:
      'Les rues médiévales sont des espaces où se croisent mobilités douces, tourisme raisonné et vie locale. L’enjeu est de concevoir des régulations partagées.',
    focus: 'Stratégies de circulation dans les quartiers historiques de Strasbourg et de Colmar.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
  }
];

const InterviewsPage = () => {
  return (
    <>
      <PageHelmet
        title="Entretiens | Historic Streets of France Review"
        description="Rencontres avec historiens, urbanistes, architectes et conservateurs autour des rues historiques françaises."
        keywords="entretiens, historiens, urbanistes, patrimoine, rues historiques"
      />
      <section className={styles.page}>
        <header className={styles.header}>
          <h1>Entretiens</h1>
          <p>
            Cette rubrique rassemble des conversations approfondies avec des spécialistes qui éclairent les enjeux de conservation, de médiation et de transformation des rues historiques françaises.
          </p>
        </header>
        <div className={styles.grid}>
          {interviews.map((interview) => (
            <article key={interview.name} className={styles.card}>
              <div className={styles.portrait}>
                <img src={interview.image} alt={`Portrait de ${interview.name}`} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <h2>{interview.name}</h2>
                <p className={styles.role}>{interview.role}</p>
                <blockquote>« {interview.quote} »</blockquote>
                <p className={styles.focus}>
                  <strong>Focus :</strong> {interview.focus}
                </p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default InterviewsPage;