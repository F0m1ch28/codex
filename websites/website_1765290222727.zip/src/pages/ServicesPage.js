import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './ServicesPage.module.css';

const ServicesPage = () => {
  return (
    <>
      <PageHelmet
        title="Approches éditoriales | Historic Streets of France Review"
        description="Présentation des approches de recherche, des formats éditoriaux et des dispositifs de valorisation mis en œuvre par la rédaction."
        keywords="approches éditoriales, méthodologie, recherche urbaine"
      />
      <section className={styles.page}>
        <header className={styles.header}>
          <h1>Approches éditoriales</h1>
          <p>
            Les contenus d’Historic Streets of France Review reposent sur plusieurs formats complémentaires permettant de restituer la complexité des rues historiques françaises.
          </p>
        </header>

        <div className={styles.grid}>
          <article className={styles.card}>
            <h2>Dossiers diachroniques</h2>
            <p>
              Analyses longues associant chronologie, plans d’alignement et lecture des façades pour suivre l’évolution d’une rue sur plusieurs siècles.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Cartographies commentées</h2>
            <p>
              Superposition de cartes anciennes et contemporaines, accompagnée d’un commentaire expert sur les modifications du parcellaire et des alignements.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Entretiens d’experts</h2>
            <p>
              Dialogues structurés avec des historiens, architectes et urbanistes pour éclairer les enjeux de conservation, de médiation et de transformation des rues.
            </p>
          </article>
          <article className={styles.card}>
            <h2>Chroniques de terrain</h2>
            <p>
              Notes d’observation réalisées in situ, complétées par des relevés photographiques et sonores, afin de saisir les usages quotidiens et les ambiances.
            </p>
          </article>
        </div>

        <aside className={styles.note}>
          <h2>Processus rédactionnel</h2>
          <ol>
            <li>Identification de la rue et cadrage historique.</li>
            <li>Collecte documentaire : archives, cartographies, iconographie.</li>
            <li>Entretiens avec les acteurs locaux et spécialistes.</li>
            <li>Rédaction, relecture croisée et validation scientifique.</li>
            <li>Mise en page et diffusion auprès du réseau de partenaires.</li>
          </ol>
        </aside>
      </section>
    </>
  );
};

export default ServicesPage;