import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './ArchivesPage.module.css';

const ArchivesPage = () => {
  return (
    <>
      <PageHelmet
        title="Archives et ressources | Historic Streets of France Review"
        description="Cartes anciennes, plans d’alignement, relevés photographiques et ressources documentaires sur les rues historiques françaises."
        keywords="archives, cartes anciennes, ressources patrimoniales, rues historiques"
      />
      <section className={styles.page}>
        <header className={styles.header}>
          <h1>Archives et ressources</h1>
          <p>
            Les archives jouent un rôle central dans l’analyse des rues historiques. Cette section présente les principaux fonds consultés par la rédaction et propose des repères pour approfondir les recherches.
          </p>
        </header>

        <div className={styles.content}>
          <div className={styles.block}>
            <h2>Cartographies anciennes</h2>
            <p>
              Les plans de Turgot, de Cassini, ainsi que les levées cadastrales du XIXe siècle permettent de suivre l’évolution des tracés, des alignements et des parcelles. Chaque dossier de recherche associe ces documents à des observations de terrain pour mesurer les continuités ou les ruptures.
            </p>
          </div>
          <div className={styles.block}>
            <h2>Fonds photographiques</h2>
            <p>
              Les fonds des musées municipaux, des services d’archives et de l’Inventaire général offrent des séries d’images précieuses : vitrines, pavages, signalétiques ou mobiliers urbains. La confrontation entre clichés anciens et relevés contemporains éclaire les transformations matérielles.
            </p>
          </div>
          <div className={styles.block}>
            <h2>Sources écrites</h2>
            <p>
              Les registres de métiers, les délibérations municipales, les dossiers d’alignement et les chroniques locales apportent un éclairage sur les usages, les conflits et les décisions d’aménagement. Ils sont systématiquement cités dans les articles afin de garantir la traçabilité des informations.
            </p>
          </div>
          <div className={styles.block}>
            <h2>Ressources audio et témoignages</h2>
            <p>
              Les collectes orales menées par les centres d’archives sonores et les associations de quartier complètent les données matérielles. Elles offrent des récits sensibles sur les rythmes quotidiens, les pratiques commerçantes ou les souvenirs d’événements publics.
            </p>
          </div>
        </div>

        <aside className={styles.note}>
          <h2>Accès et consultation</h2>
          <p>
            Les fiches techniques associées à chaque article précisent les conditions de consultation des documents, les références archivistiques et les éventuelles restrictions. Les lecteurs sont invités à contacter directement les institutions mentionnées pour organiser leurs recherches sur place.
          </p>
        </aside>
      </section>
    </>
  );
};

export default ArchivesPage;