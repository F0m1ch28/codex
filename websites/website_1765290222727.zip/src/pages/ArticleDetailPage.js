import React from 'react';
import { useParams, Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import articles from '../data/articles';
import styles from './ArticleDetailPage.module.css';

const ArticleDetailPage = () => {
  const { articleSlug } = useParams();
  const article = articles.find((item) => item.slug === articleSlug);

  if (!article) {
    return (
      <section className={styles.notFound}>
        <h1>Article introuvable</h1>
        <p>
          L’article recherché n’est plus disponible ou le lien est erroné. Utilisez la rubrique des publications pour retrouver les analyses en ligne.
        </p>
        <Link to="/publications" className={styles.backLink}>
          Retourner aux publications
        </Link>
      </section>
    );
  }

  return (
    <>
      <PageHelmet
        title={`${article.title} | Historic Streets of France Review`}
        description={article.summary}
        keywords={article.themes.join(', ')}
      />
      <article className={styles.article}>
        <header className={styles.header}>
          <p className={styles.category}>{article.category}</p>
          <h1>{article.title}</h1>
          <p className={styles.subtitle}>{article.subtitle}</p>
          <div className={styles.meta}>
            <span>{article.author}</span>
            <span>•</span>
            <span>{new Date(article.date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
            <span>•</span>
            <span>{article.readingTime}</span>
          </div>
        </header>

        <figure className={styles.figure}>
          <img src={article.coverImage} alt={article.coverImageAlt} loading="lazy" />
          <figcaption>{article.coverImageAlt}</figcaption>
        </figure>

        <div className={styles.content}>
          {article.content.map((block, index) => {
            if (block.type === 'heading') {
              return (
                <h2 key={`heading-${index}`} className={styles.subheading}>
                  {block.text}
                </h2>
              );
            }
            return (
              <p key={`paragraph-${index}`} className={styles.paragraph}>
                {block.text}
              </p>
            );
          })}
        </div>

        <aside className={styles.references}>
          <h2>Références et sources</h2>
          <ul>
            {article.references.map((reference) => (
              <li key={reference}>{reference}</li>
            ))}
          </ul>
        </aside>

        <footer className={styles.footer}>
          <div className={styles.tagList} aria-label="Thèmes abordés">
            {article.themes.map((theme) => (
              <span key={theme}>{theme}</span>
            ))}
          </div>
          <Link to="/publications" className={styles.backLink}>
            Retour aux publications
          </Link>
        </footer>
      </article>
    </>
  );
};

export default ArticleDetailPage;