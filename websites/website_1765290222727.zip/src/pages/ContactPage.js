import React, { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './ContactPage.module.css';

const initialState = {
  name: '',
  email: '',
  organisation: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [status, setStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus({ type: 'error', message: 'Merci de compléter les champs requis.' });
      return;
    }
    setStatus({ type: 'success', message: 'Votre message a été transmis à la rédaction. Une réponse vous sera adressée après analyse.' });
    setFormData(initialState);
  };

  return (
    <>
      <PageHelmet
        title="Contact | Historic Streets of France Review"
        description="Formulaire de contact pour les demandes de collaboration éditoriale, de recherche ou d’information."
        keywords="contact rédaction, recherche urbaine, patrimoine, publication"
      />
      <section className={styles.page}>
        <div className={styles.header}>
          <h1>Contact rédactionnel</h1>
          <p>
            Pour les demandes de collaboration, de contribution ou d’information, merci d’utiliser le formulaire ci-dessous. La rédaction centralise les échanges via l’adresse officielle.
          </p>
          <p className={styles.email}>
            Adresse courriel : <a href="mailto:redaction@historicstreets-fr-review.fr">redaction@historicstreets-fr-review.fr</a>
          </p>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Nom et prénom *</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Votre nom"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="email">Adresse électronique *</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="votre.adresse@example.fr"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="organisation">Organisation</label>
            <input
              id="organisation"
              name="organisation"
              type="text"
              placeholder="Structure ou institution"
              value={formData.organisation}
              onChange={handleChange}
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="message">Message *</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              placeholder="Décrivez votre demande ou votre proposition éditoriale."
              value={formData.message}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className={styles.submitButton}>
            Envoyer la demande
          </button>

          {status && (
            <p className={`${styles.status} ${status.type === 'success' ? styles.success : styles.error}`}>
              {status.message}
            </p>
          )}
        </form>
      </section>
    </>
  );
};

export default ContactPage;