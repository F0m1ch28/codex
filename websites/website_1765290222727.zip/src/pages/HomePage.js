import React from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import articles from '../data/articles';
import styles from './HomePage.module.css';

const HomePage = () => {
  const latestArticles = articles.slice(0, 3);

  return (
    <>
      <PageHelmet
        title="Historic Streets of France Review – Études des rues historiques françaises"
        description="Analyses, enquêtes et ressources sur les rues historiques françaises, leurs patrimoines bâtis et leurs transformations sociales."
        keywords="rues historiques, urbanisme, patrimoine urbain, centres anciens, France"
      />
      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <h1 id="hero-heading">Observer et documenter les rues historiques françaises</h1>
          <p>
            Historic Streets of France Review propose des enquêtes approfondies sur l’évolution des rues emblématiques, des quartiers médiévaux aux tracés haussmanniens. Chaque dossier s’appuie sur des sources archivistiques, des analyses urbaines et des voix d’experts.
          </p>
          <Link to="/publications" className={styles.heroButton}>
            Explorer les publications
          </Link>
        </div>
      </section>

      <section className={styles.aboutSection} aria-labelledby="about-heading">
        <div className={styles.aboutInner}>
          <div>
            <h2 id="about-heading">Une lecture structurée des espaces publics français</h2>
            <p>
              L’équipe rédactionnelle rassemble historiens, urbanistes et conservateurs afin de contextualiser les transformations des rues et des boulevards. Les articles articulent la mémoire des habitants, les politiques urbaines et la matérialité architecturale.
            </p>
            <p>
              Chaque publication est construite à partir d’archives municipales, de cartographies anciennes, de relevés de terrain et d’entretiens avec des spécialistes. La démarche privilégie une restitution rigoureuse, sans sensationnalisme, pour offrir des repères fiables aux chercheurs, étudiants et professionnels du patrimoine.
            </p>
          </div>
          <div className={styles.statsCard}>
            <p className={styles.statsTitle}>Chiffres clés de la rédaction</p>
            <div className={styles.statsGrid}>
              <div>
                <span className={styles.statNumber}>48</span>
                <span className={styles.statLabel}>cartes anciennes comparées</span>
              </div>
              <div>
                <span className={styles.statNumber}>26</span>
                <span className={styles.statLabel}>entretiens avec des spécialistes</span>
              </div>
              <div>
                <span className={styles.statNumber}>12</span>
                <span className={styles.statLabel}>rues étudiées en 2023-2024</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.articlesSection} aria-labelledby="latest-articles-heading">
        <div className={styles.sectionHeader}>
          <h2 id="latest-articles-heading">Dernières publications</h2>
          <Link to="/publications" className={styles.sectionLink}>
            Consulter toutes les analyses
          </Link>
        </div>
        <div className={styles.articlesGrid}>
          {latestArticles.map((article) => (
            <article key={article.id} className={styles.articleCard}>
              <div className={styles.imageWrapper}>
                <img src={article.coverImage} alt={article.coverImageAlt} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <p className={styles.cardCategory}>{article.category}</p>
                <h3>{article.title}</h3>
                <p className={styles.cardSummary}>{article.summary}</p>
                <Link to={`/publications/${article.slug}`} className={styles.readLink} aria-label={`Lire l'article ${article.title}`}>
                  Lire l’article
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.themesSection} aria-labelledby="themes-heading">
        <h2 id="themes-heading">Thématiques de recherche</h2>
        <div className={styles.themeGrid}>
          <div className={styles.themeCard}>
            <span className={styles.themeIcon} aria-hidden="true">🏛️</span>
            <h3>Évolution architecturale</h3>
            <p>Étude des matériaux, des gabarits et des styles qui façonnent les rues françaises du Moyen Âge à aujourd’hui.</p>
          </div>
          <div className={styles.themeCard}>
            <span className={styles.themeIcon} aria-hidden="true">🗺️</span>
            <h3>Patrimoine urbain</h3>
            <p>Analyse des politiques publiques, des classements patrimoniaux et des actions de restauration dans les centres historiques.</p>
          </div>
          <div className={styles.themeCard}>
            <span className={styles.themeIcon} aria-hidden="true">🤝</span>
            <h3>Mémoire collective</h3>
            <p>Recueil de récits, d’usages quotidiens et d’initiatives citoyennes qui animent les espaces publics.</p>
          </div>
        </div>
      </section>

      <section className={styles.missionSection} aria-labelledby="mission-heading">
        <div className={styles.missionCard}>
          <h2 id="mission-heading">Mission éditoriale</h2>
          <blockquote>
            « Documenter les rues historiques implique de croiser regards, disciplines et temporalités. Historic Streets of France Review se consacre à cette observation patiente, attentive aux détails du bâti et aux récits des habitants. »
          </blockquote>
          <cite>Comité éditorial</cite>
        </div>
      </section>

      <section className={styles.previewSection} aria-labelledby="interview-archives-heading">
        <div className={styles.previewGrid}>
          <div>
            <h2 id="interview-archives-heading">Entretiens et archives</h2>
            <p>
              Les entretiens recueillent les analyses de chercheurs, architectes, conservateurs et urbanistes. La rubrique Archives met en lumière des cartes anciennes, des plans d’alignement et des fonds iconographiques essentiels pour comprendre l’évolution des rues.
            </p>
            <div className={styles.previewLinks}>
              <Link to="/entretiens">Découvrir les entretiens</Link>
              <Link to="/archives">Consulter les archives</Link>
            </div>
          </div>
          <div className={styles.previewImage}>
            <img src="https://images.unsplash.com/photo-1494488180300-4c63486f697b?auto=format&fit=crop&w=900&q=80" alt="Cartes anciennes posées sur une table en bois" loading="lazy" />
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;