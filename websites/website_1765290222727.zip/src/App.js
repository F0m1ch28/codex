import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/HomePage';
import ArticleListingPage from './pages/ArticleListingPage';
import ArticleDetailPage from './pages/ArticleDetailPage';
import InterviewsPage from './pages/InterviewsPage';
import ArchivesPage from './pages/ArchivesPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import TermsOfServicePage from './pages/TermsOfServicePage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import ServicesPage from './pages/ServicesPage';
import styles from './App.module.css';

function App() {
  return (
    <div className={styles.appShell}>
      <ScrollToTop />
      <Header />
      <main className={styles.mainContent}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/publications" element={<ArticleListingPage />} />
          <Route path="/publications/:articleSlug" element={<ArticleDetailPage />} />
          <Route path="/entretiens" element={<InterviewsPage />} />
          <Route path="/archives" element={<ArchivesPage />} />
          <Route path="/a-propos" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/conditions-generales" element={<TermsOfServicePage />} />
          <Route path="/politique-de-confidentialite" element={<PrivacyPolicyPage />} />
          <Route path="/politique-de-cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;