document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      siteNav.classList.toggle("site-nav-open");
      navToggle.setAttribute("aria-expanded", siteNav.classList.contains("site-nav-open"));
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        siteNav.classList.remove("site-nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const consentKey = "site-cookie-consent-v1";

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);

    if (storedConsent === "accepted" || storedConsent === "declined") {
      cookieBanner.classList.add("hidden");
    }

    cookieBanner.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) {
        return;
      }
      const consent = target.dataset.consent;
      if (!consent) {
        return;
      }

      if (consent === "accept") {
        localStorage.setItem(consentKey, "accepted");
      } else if (consent === "decline") {
        localStorage.setItem(consentKey, "declined");
      }

      cookieBanner.classList.add("hidden");
    });
  }
});