import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Services.module.css';

const services = [
  {
    title: 'Corporate & Commercial',
    description:
      'Entity structuring, shareholder agreements, cross-border M&A, joint ventures, and governance frameworks tailored to investors and boards.',
    deliverables: ['Corporate structuring playbooks', 'Governance reports', 'Cross-border transaction management'],
    cta: 'Discuss corporate strategy'
  },
  {
    title: 'Technology & IT Contracts',
    description:
      'End-to-end technology contracting for SaaS, licensing, outsourcing, and strategic alliances with negotiation guidelines and playbooks.',
    deliverables: ['Master service agreements', 'Global licensing policies', 'Vendor management toolkits'],
    cta: 'Review your tech contracts'
  },
  {
    title: 'Data Protection & GDPR',
    description:
      'Data audits, DPIAs, privacy-by-design frameworks, and regulator engagement that strengthens resilience and customer trust.',
    deliverables: ['GDPR maturity assessments', 'DPIA programmes', 'Incident response blueprints'],
    cta: 'Plan your GDPR roadmap'
  },
  {
    title: 'Employment & Incentives',
    description:
      'Executive agreements, incentive schemes, cross-border employment structures, and HR policy frameworks aligned with Irish law.',
    deliverables: ['Employment policy suite', 'Equity incentive plans', 'Mobility and secondment support'],
    cta: 'Align people strategy'
  },
  {
    title: 'Regulatory Compliance',
    description:
      'PSD2, e-money, AML, and sector-specific regulatory authorisations delivered with ongoing compliance monitoring and reporting.',
    deliverables: ['Authorisation submissions', 'Compliance monitoring packs', 'Regulator liaison support'],
    cta: 'Prepare your filing'
  },
  {
    title: 'Disputes & Investigations',
    description:
      'Swift strategic action for commercial disputes, IP infringement, shareholder conflict, and regulatory investigations.',
    deliverables: ['Litigation strategy notes', 'Investigation response plans', 'Advocacy before Irish courts'],
    cta: 'Mobilise response team'
  },
  {
    title: 'Consultancy & Retainers',
    description:
      'Dedicated counsel as-a-service for scaleups and SMEs, including legal project management and embedded advisory support.',
    deliverables: ['Flexible retainer models', 'Embedded counsel rotations', 'Quarterly risk reviews'],
    cta: 'Build your advisory plan'
  }
];

const Services = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | Studdfxg Legal Solutions</title>
        <meta
          name="description"
          content="Explore Studdfxg’s corporate, technology, data protection, employment, regulatory, and dispute resolution services crafted for Irish and international clients."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.eyebrow}>Services</span>
          <h1>Strategic legal counsel across the lifecycle of your business</h1>
          <p>
            Studdfxg designs agile legal programmes, transaction support, and regulatory solutions that move in step with your objectives.
          </p>
        </div>
      </section>

      <section className={styles.servicesList}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceHeader}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                </div>
                <div className={styles.serviceBody}>
                  <h3>Deliverables include</h3>
                  <ul>
                    {service.deliverables.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
                <Link to="/contact" className={styles.cardCta}>
                  {service.cta}
                  <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.methodSection}>
        <div className="container">
          <div className={styles.methodGrid}>
            <div>
              <h2>How we deliver measurable value</h2>
              <p>
                Each engagement is calibrated to your internal bandwidth, stakeholder preferences, and strategic goals.
                We integrate securely with your collaboration tools, map decisions to responsible owners, and use data-driven dashboards
                to track progress.
              </p>
              <p>
                Our matter leads coordinate multidisciplinary teams including data protection specialists, regulatory subject-matter experts,
                and experienced litigators to ensure every aspect is covered.
              </p>
            </div>
            <div className={styles.methodCard}>
              <h3>Engagement structure</h3>
              <ul>
                <li>Kick-off workshop with core stakeholders.</li>
                <li>Action plan with deliverables and dependencies.</li>
                <li>Weekly or bi-weekly sprints with transparent reporting.</li>
                <li>Access to dedicated partner and engagement manager.</li>
                <li>Continuous knowledge sharing through secure portal.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Ready to activate the right legal support?</h2>
              <p>Book a consultation to align the Studdfxg team with your timelines, stakeholders, and objectives.</p>
            </div>
            <Link to="/contact" className={styles.ctaButton}>
              Request a consultation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;