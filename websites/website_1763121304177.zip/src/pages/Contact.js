import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    organisation: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Please share your full name.';
    if (!form.email.trim()) {
      newErrors.email = 'We require an email to respond.';
    } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!form.message.trim()) newErrors.message = 'Let us know how we can help.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStatus('loading');
    setTimeout(() => {
      setStatus('success');
      setForm({ name: '', email: '', organisation: '', message: '' });
    }, 1200);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact | Studdfxg</title>
        <meta
          name="description"
          content="Contact Studdfxg to request a consultation with our Irish legal experts across corporate, technology, regulatory, and dispute resolution matters."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.eyebrow}>Contact</span>
          <h1>Request a consultation with Studdfxg</h1>
          <p>
            Share your priorities and our partner team will respond within one business day. Urgent matters can be escalated immediately.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>How can we help?</h2>
              <div className={styles.field}>
                <label htmlFor="name">Full name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={form.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  placeholder="Your name"
                  required
                />
                {errors.name && (
                  <span id="name-error" className={styles.error}>
                    {errors.name}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  placeholder="name@company.com"
                  required
                />
                {errors.email && (
                  <span id="email-error" className={styles.error}>
                    {errors.email}
                  </span>
                )}
              </div>
              <div className={styles.field}>
                <label htmlFor="organisation">Organisation</label>
                <input
                  id="organisation"
                  name="organisation"
                  type="text"
                  value={form.organisation}
                  onChange={handleChange}
                  placeholder="Company or team"
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Message *</label>
                <textarea
                  id="message"
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  rows="5"
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  placeholder="Share details about your priorities or timelines."
                  required
                />
                {errors.message && (
                  <span id="message-error" className={styles.error}>
                    {errors.message}
                  </span>
                )}
              </div>
              <button type="submit" className={styles.submitButton} disabled={status === 'loading'}>
                {status === 'loading' ? 'Sending…' : 'Request a consultation'}
              </button>
              {status === 'success' && (
                <p className={styles.successMessage} role="status">
                  Thank you. Our team will be in touch shortly.
                </p>
              )}
            </form>
            <aside className={styles.sidebar}>
              <div className={styles.contactCard}>
                <h2>Get in touch</h2>
                <p>
                  <strong>Address:</strong> Ireland address
                </p>
                <p>
                  <strong>Phone:</strong> +353 1 555 0101
                </p>
                <p>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:contact@studdfxg.world">contact@studdfxg.world</a>
                </p>
                <p>
                  We offer in-person and virtual consultations. Please share your preferred format when submitting the form.
                </p>
              </div>
              <div className={styles.mapWrapper} aria-label="Studdfxg location map">
                <iframe
                  title="Studdfxg Dublin area map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2381.690559257558!2d-6.260309!3d53.349805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48670e9aab0a7d3f%3A0xb11b5ce49963cf0!2sDublin%2C%20Ireland!5e0!3m2!1sen!2sie!4v1711372800000"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
              <div className={styles.assuranceCard}>
                <h3>Confidentiality assurance</h3>
                <p>
                  All enquiries are handled in strict confidence. We will never disclose your information without consent and operate in full compliance
                  with GDPR requirements.
                </p>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;