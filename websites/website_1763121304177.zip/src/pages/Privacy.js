import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Notice | Studdfxg</title>
      <meta
        name="description"
        content="Privacy notice explaining how Studdfxg collects, uses, and protects personal data in line with GDPR."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Privacy Notice</h1>
        <p>Effective date: 1 March 2024</p>
      </div>
    </section>
    <section className={styles.content}>
      <div className="container">
        <h2>1. Controller</h2>
        <p>
          Studdfxg, Ireland address, is the controller of personal data collected via studdfxg.world.
        </p>
        <h2>2. Data we collect</h2>
        <p>
          We collect contact details, professional information, enquiry content, and technical usage data when you engage with our site or services.
        </p>
        <h2>3. How we use data</h2>
        <p>
          Data is used to respond to enquiries, deliver services, maintain client relationships, and improve our site. We process data lawfully under GDPR, primarily on the basis of consent, contract, and legitimate interest.
        </p>
        <h2>4. Disclosure</h2>
        <p>
          We share data with trusted service providers, professional advisers, and regulatory authorities where required. We implement safeguards for transfers outside the EEA.
        </p>
        <h2>5. Data retention</h2>
        <p>
          Personal data is retained only as long as necessary for the purposes collected, aligned with legal and regulatory requirements.
        </p>
        <h2>6. Your rights</h2>
        <p>
          You have rights to access, rectify, erase, restrict, and object to processing of your personal data, and to data portability. Contact us at contact@studdfxg.world.
        </p>
        <h2>7. Security</h2>
        <p>
          We employ technical and organisational measures to protect personal data, including encryption, access controls, and continuous monitoring.
        </p>
      </div>
    </section>
  </div>
);

export default Privacy;