import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const stats = [
  { label: 'Years advising innovators', value: 18 },
  { label: 'Cross-border projects delivered', value: 240 },
  { label: 'Jurisdictions coordinated', value: 32 },
  { label: 'Average NPS from clients', value: 96, suffix: '%' }
];

const practiceAreas = [
  {
    title: 'Corporate & Commercial',
    description:
      'Tailored structuring, shareholder alignment, and governance frameworks designed for high-growth companies.',
    icon: '🏛️'
  },
  {
    title: 'Technology & IT Contracts',
    description:
      'Robust SaaS, licensing, outsourcing, and vendor agreements that keep innovation compliant and scalable.',
    icon: '💻'
  },
  {
    title: 'Data Protection & GDPR',
    description:
      'Pragmatic data mapping, DPIAs, and GDPR programmes that satisfy regulators while supporting product velocity.',
    icon: '🛡️'
  },
  {
    title: 'Disputes & Regulatory Defence',
    description:
      'Swift response units for investigations, tech disputes, and complex commercial litigation in Irish courts.',
    icon: '⚖️'
  }
];

const industries = [
  {
    title: 'Startups & Emerging Tech',
    copy: 'Seed to Series D counsel with playbooks for Irish and EU expansion, investor expectations, and IP protection.'
  },
  {
    title: 'SMEs & Scaleups',
    copy: 'Operational counsel covering commercial contracts, employment, and governance checkpoints to support growth.'
  },
  {
    title: 'Fintech & Regulated Firms',
    copy: 'Authorisations, PSD2, AML, and e-money compliance managed with a regulator-ready documentation trail.'
  },
  {
    title: 'Creative & Digital',
    copy: 'Rights management, collaborative ventures, and digital distribution agreements negotiated with precision.'
  },
  {
    title: 'International Entrants',
    copy: 'Landing strategies in Ireland with tax, regulatory, and employment support aligned to EU market expectations.'
  }
];

const whyPoints = [
  {
    heading: 'Partner-led delivery',
    detail: 'Experienced partners remain hands-on from strategy through execution, ensuring decisions are informed and immediate.'
  },
  {
    heading: 'Technology fluency',
    detail: 'We speak your product language, from APIs to GDPR, translating complex regulation into product-ready actions.'
  },
  {
    heading: 'Cross-border perspective',
    detail: 'Coordinated support across EU and US stakeholders, with a dependable network of specialist counsel on-call.'
  }
];

const processSteps = [
  {
    title: 'Discovery & Alignment',
    description:
      'We clarify objectives, risk tolerances, and delivery milestones in an accelerated strategy session.'
  },
  {
    title: 'Strategic Blueprint',
    description:
      'A bespoke legal roadmap prioritised by impact, outlining responsibilities, timelines, and stakeholder communication.'
  },
  {
    title: 'Execution & Advocacy',
    description:
      'Agile execution supported by rigorous documentation, proactive regulator management, and decisive negotiation.'
  },
  {
    title: 'Continuous Support',
    description:
      'Ongoing counsel with structured check-ins, horizon scanning, and rapid response to evolving risk.'
  }
];

const testimonials = [
  {
    quote:
      'Studdfxg were instrumental in launching our EU payments platform. Their ability to translate regulatory hurdles into clear actions saved us months.',
    name: 'Maeve O’Connor',
    role: 'COO, EmeraldPay'
  },
  {
    quote:
      'From our first funding round through to international expansion, the Studdfxg team have been strategic partners, not just lawyers.',
    name: 'Ethan Doyle',
    role: 'CEO, Lumen Analytics'
  },
  {
    quote:
      'When a data incident surfaced, they mobilised instantly, contained the exposure, and managed regulators with absolute control.',
    name: 'Chloe Byrne',
    role: 'Chief Risk Officer, HelixCloud'
  }
];

const faqs = [
  {
    question: 'Do you support clients outside Ireland?',
    answer:
      'Yes. We advise international companies entering or expanding across Ireland and coordinate with trusted counsel across Europe, North America, and Asia-Pacific.'
  },
  {
    question: 'How quickly can we start working together?',
    answer:
      'We typically onboard within three business days following an initial consultation. Urgent regulatory or dispute matters can be mobilised within 24 hours.'
  },
  {
    question: 'Can Studdfxg act as our outsourced legal function?',
    answer:
      'Absolutely. We provide customised retainers for scaleups and SMEs needing ongoing general counsel support, with transparent workflows and responsive SLAs.'
  },
  {
    question: 'Do you offer GDPR representative or DPO services?',
    answer:
      'We maintain partnerships with specialist EU representatives and can act as external DPO, providing the governance, reporting, and regulatory engagement required.'
  }
];

const blogPosts = [
  {
    title: 'Irish VC Term Sheet Trends 2024',
    excerpt:
      'Key points founders should negotiate in the current funding climate, with practical examples from recent transactions.',
    date: 'April 2024',
    link: '/resources/irish-vc-term-sheet-trends-2024'
  },
  {
    title: 'Designing GDPR-Compliant AI Products',
    excerpt:
      'A field guide for product and engineering teams aligning AI models with EU data protection obligations from day one.',
    date: 'March 2024',
    link: '/resources/gdpr-compliant-ai-products'
  },
  {
    title: 'PSD2 Successor: What Fintech Leaders Need to Plan For',
    excerpt:
      'We unpack the European Commission’s latest proposals and timelines, highlighting immediate action items for Irish fintechs.',
    date: 'February 2024',
    link: '/resources/psd2-successor-readiness'
  }
];

const projects = [
  {
    title: 'European SaaS Expansion',
    category: 'Technology',
    description: 'Structured cross-border licensing and data transfer mechanisms for a Dublin-based SaaS scaleup.',
    image: 'https://picsum.photos/1200/800?random=4',
    alt: 'Corporate professionals reviewing SaaS contracts'
  },
  {
    title: 'Fintech Regulatory Authorisation',
    category: 'Fintech',
    description: 'Delivered Central Bank of Ireland authorisation and AML framework for a digital payments entrant.',
    image: 'https://picsum.photos/1200/800?random=5',
    alt: 'Fintech compliance team working in office'
  },
  {
    title: 'Data Governance Transformation',
    category: 'Data',
    description: 'Implemented GDPR overhaul and privacy-by-design controls for a health tech provider operating across the EU.',
    image: 'https://picsum.photos/1200/800?random=6',
    alt: 'Data protection strategy meeting at legal firm'
  },
  {
    title: 'Strategic Commercial Dispute',
    category: 'Disputes',
    description: 'Resolved a multi-jurisdictional IP dispute through arbitration, securing favourable settlement terms.',
    image: 'https://picsum.photos/1200/800?random=7',
    alt: 'Mediation table with legal documents'
  }
];

const Home = () => {
  const [counters, setCounters] = useState(stats.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('All');
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const timers = stats.map((stat, index) =>
      setInterval(
        () =>
          setCounters((prev) => {
            const updated = [...prev];
            const target = stat.value;
            const increment = Math.ceil(target / 50);
            if (updated[index] < target) {
              updated[index] = Math.min(updated[index] + increment, target);
            }
            return updated;
          }),
        40 + index * 30
      )
    );
    return () => timers.forEach(clearInterval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  const categories = ['All', ...new Set(projects.map((project) => project.category))];
  const filteredProjects =
    activeCategory === 'All'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.pageWrapper}>
      <Helmet>
        <title>Studdfxg | Strategic Legal Counsel in Ireland</title>
        <meta
          name="description"
          content="Studdfxg is an Irish law firm advising technology, fintech, and global businesses on corporate, data, and regulatory matters."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroMedia}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Modern legal team collaborating in Dublin office"
            loading="lazy"
          />
        </div>
        <div className={styles.heroContent}>
          <span className={styles.heroEyebrow}>Legal strategy for bold operators</span>
          <h1>
            Irish counsel for teams scaling technology, finance, and global operations with confidence.
          </h1>
          <p>
            Studdfxg pairs partner-level insight with agile delivery to help leaders anticipate risk, close deals faster,
            and thrive in regulated markets.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contact" className={styles.heroCta}>
              Request a consultation
            </Link>
            <Link to="/services" className={styles.secondaryLink}>
              Explore our services
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.statsSection} aria-label="Key firm statistics">
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {counters[index]}
                  {stat.suffix || ''}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.differentiators} aria-labelledby="why-studdfxg">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>Why Studdfxg</span>
              <h2 id="why-studdfxg">An advisory team built for decisive action</h2>
            </div>
            <p>
              From venture-backed founders to regulated finance innovators, our clients value clarity, speed,
              and commercial understanding. We bring the legal precision to match.
            </p>
          </div>
          <div className={styles.whyGrid}>
            {whyPoints.map((point) => (
              <article key={point.heading} className={styles.whyCard}>
                <h3>{point.heading}</h3>
                <p>{point.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection} id="services" aria-labelledby="practice-areas">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>Services</span>
              <h2 id="practice-areas">Focused legal disciplines that power your growth</h2>
            </div>
            <Link to="/services" className={styles.sectionLink}>
              View all services
            </Link>
          </div>
          <div className={styles.servicesGrid}>
            {practiceAreas.map((area) => (
              <article key={area.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {area.icon}
                </span>
                <h3>{area.title}</h3>
                <p>{area.description}</p>
                <Link to="/contact" className={styles.cardCta}>
                  Schedule a call
                  <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.industriesSection} aria-labelledby="industries-we-serve">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>Industries</span>
              <h2 id="industries-we-serve">Sector insight wherever you operate</h2>
            </div>
            <Link to="/industries" className={styles.sectionLink}>
              Explore industries
            </Link>
          </div>
          <div className={styles.industriesGrid}>
            {industries.map((item) => (
              <article key={item.title} className={styles.industryCard}>
                <h3>{item.title}</h3>
                <p>{item.copy}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection} aria-labelledby="engagement-process">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>How we work</span>
              <h2 id="engagement-process">A collaborative process engineered for momentum</h2>
            </div>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.stepNumber}>{String(index + 1).padStart(2, '0')}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} aria-labelledby="recent-projects">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>Case snapshots</span>
              <h2 id="recent-projects">Impact across technology, finance, and global markets</h2>
            </div>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Project category filter">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={activeCategory === category}
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterButtonActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={project.alt} loading="lazy" />
                  <span className={styles.projectCategory}>{project.category}</span>
                </div>
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/contact" className={styles.cardCta}>
                    Discuss similar work
                    <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-labelledby="client-testimonials">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>Client voices</span>
              <h2 id="client-testimonials">Trusted by leaders navigating complex change</h2>
            </div>
          </div>
          <div className={styles.testimonialCarousel} role="region" aria-live="polite">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>&ldquo;{testimonial.quote}&rdquo;</p>
                <div className={styles.testimonialMeta}>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.carouselDots} role="tablist" aria-label="Select testimonial">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.carouselDot} ${
                  index === activeTestimonial ? styles.carouselDotActive : ''
                }`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Show testimonial ${index + 1}`}
                aria-selected={index === activeTestimonial}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>FAQ</span>
              <h2 id="faq-heading">Answers to frequent questions</h2>
            </div>
          </div>
          <div className={styles.faqList}>
            {faqs.map((faq, index) => (
              <article key={faq.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqTrigger}
                  onClick={() => toggleFaq(index)}
                  aria-expanded={openFaq === index}
                >
                  <span>{faq.question}</span>
                  <span aria-hidden="true" className={styles.faqIcon}>
                    {openFaq === index ? '−' : '+'}
                  </span>
                </button>
                <div
                  className={`${styles.faqContent} ${
                    openFaq === index ? styles.faqContentOpen : ''
                  }`}
                  role="region"
                  aria-hidden={openFaq === index ? 'false' : 'true'}
                >
                  <p>{faq.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} aria-labelledby="insights">
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <span className={styles.sectionEyebrow}>Resources</span>
              <h2 id="insights">Latest insights from Studdfxg</h2>
            </div>
            <Link to="/resources" className={styles.sectionLink}>
              Visit resources hub
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <time dateTime={post.date} className={styles.blogDate}>
                  {post.date}
                </time>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.cardCta}>
                  Read the insight <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.finalCta} aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.finalCtaInner}>
            <div>
              <span className={styles.sectionEyebrow}>Partner with us</span>
              <h2 id="cta-heading">Ready to move forward with confidence?</h2>
              <p>
                Let’s align on your objectives, organise priorities, and design a legal strategy that accelerates your next chapter.
              </p>
            </div>
            <div className={styles.finalCtaActions}>
              <Link to="/contact" className={styles.heroCta}>
                Request a consultation
              </Link>
              <Link to="/team" className={styles.secondaryLink}>
                Meet our team
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;