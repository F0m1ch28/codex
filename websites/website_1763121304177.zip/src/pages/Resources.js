import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Resources.module.css';

const guides = [
  {
    title: 'Irish Company Formation Checklist',
    description:
      'A step-by-step checklist for founders establishing an Irish company, covering tax registrations, shareholder documents, and governance.',
    link: '/resources/irish-company-formation-checklist'
  },
  {
    title: 'GDPR Incident Response Playbook',
    description:
      'Practical timelines, regulator notifications, and communication templates for handling data incidents in the EU.',
    link: '/resources/gdpr-incident-response-playbook'
  },
  {
    title: 'Scaling Compliance in Fintech',
    description:
      'A framework for building a regulator-ready compliance culture, including PSD2, AMLD, and outsourcing requirements.',
    link: '/resources/scaling-compliance-in-fintech'
  }
];

const faqs = [
  {
    question: 'Do you provide template suites for commercial contracts?',
    answer:
      'Yes. We design customised template suites for sales, procurement, and partnership functions, complete with negotiation guidelines and training workshops.'
  },
  {
    question: 'Can Studdfxg train our teams on GDPR requirements?',
    answer:
      'We regularly deliver privacy trainings for engineering, product, marketing, and leadership teams, tailoring content to your operations and risk profile.'
  },
  {
    question: 'How do you collaborate with in-house legal teams?',
    answer:
      'We integrate seamlessly with in-house counsel, offering overflow support, specialist expertise, and local representation for Irish law issues.'
  }
];

const Resources = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Resources | Studdfxg Legal Insights</title>
        <meta
          name="description"
          content="Access Studdfxg’s latest guides, updates, and FAQs covering Irish corporate law, GDPR, fintech regulation, and dispute readiness."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.eyebrow}>Resources</span>
          <h1>Insights, guides, and FAQs for Irish and EU legal readiness</h1>
          <p>
            Our resource hub equips leadership, legal, and compliance teams with timely intelligence on emerging regulation,
            transaction trends, and operational playbooks.
          </p>
        </div>
      </section>

      <section className={styles.guidesSection}>
        <div className="container">
          <h2>Featured guides</h2>
          <div className={styles.guidesGrid}>
            {guides.map((guide) => (
              <article key={guide.title} className={styles.guideCard}>
                <h3>{guide.title}</h3>
                <p>{guide.description}</p>
                <Link to={guide.link} className={styles.cardCta}>
                  Access the guide <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.alertsSection}>
        <div className="container">
          <div className={styles.alertCard}>
            <span className={styles.alertTag}>Regulatory update</span>
            <h2>EU AI Act: Irish implementation timeline</h2>
            <p>
              The European Council has finalised the AI Act, introducing phased obligations for providers and deployers.
              We are advising clients on foundational compliance assessments, risk categorisation, and governance frameworks ahead of enforcement.
            </p>
            <Link to="/contact" className={styles.cardCta}>
              Schedule a compliance briefing
              <span aria-hidden="true">→</span>
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <h2>Frequently asked questions</h2>
          <div className={styles.faqList}>
            {faqs.map((faq) => (
              <article key={faq.question} className={styles.faqCard}>
                <h3>{faq.question}</h3>
                <p>{faq.answer}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Need insight on a specific issue?</h2>
              <p>
                We publish bespoke briefings for clients navigating transactions, regulatory change, or complex disputes.
                Let us know what you’re working on.
              </p>
            </div>
            <Link to="/contact" className={styles.ctaButton}>
              Contact our team
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Resources;