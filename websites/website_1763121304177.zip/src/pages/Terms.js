import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms of Use | Studdfxg</title>
      <meta
        name="description"
        content="Terms of use governing access to studdfxg.world and Studdfxg’s legal resources."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Terms of Use</h1>
        <p>Effective date: 1 March 2024</p>
      </div>
    </section>
    <section className={styles.content}>
      <div className="container">
        <h2>1. Acceptance of terms</h2>
        <p>
          Accessing or using studdfxg.world constitutes acceptance of these Terms of Use. If you do not agree, please refrain from using the site.
        </p>
        <h2>2. Professional information</h2>
        <p>
          Content on this website is provided for general information only and does not constitute legal advice. Engage Studdfxg formally before relying on any information.
        </p>
        <h2>3. Intellectual property</h2>
        <p>
          All material on studdfxg.world is owned or licensed by Studdfxg. You may not reproduce, distribute, or adapt any content without prior written consent.
        </p>
        <h2>4. Limitation of liability</h2>
        <p>
          Studdfxg disclaims liability for any loss resulting from reliance on information published on this site. We recommend seeking tailored advice.
        </p>
        <h2>5. Governing law</h2>
        <p>
          These Terms are governed by Irish law and subject to the exclusive jurisdiction of the courts of Ireland.
        </p>
        <h2>6. Contact</h2>
        <p>
          For queries regarding these Terms, contact Studdfxg at <a href="mailto:contact@studdfxg.world">contact@studdfxg.world</a>.
        </p>
      </div>
    </section>
  </div>
);

export default Terms;