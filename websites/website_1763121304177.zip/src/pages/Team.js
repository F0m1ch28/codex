import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Team.module.css';

const teamMembers = [
  {
    name: 'Aoife Gallagher',
    role: 'Managing Partner, Corporate & Commercial',
    bio: 'Aoife advises high-growth technology companies on strategic transactions, governance, and international structuring.',
    credentials: ['Solicitor, Law Society of Ireland', 'LLM, Trinity College Dublin', 'Admitted in England & Wales'],
    image: 'https://picsum.photos/400/400?random=3'
  },
  {
    name: 'Patrick Byrne',
    role: 'Partner, Regulatory & Fintech',
    bio: 'Patrick specialises in financial regulation, authorisations, investigations, and PSD2 compliance for fintech innovators.',
    credentials: ['Former Central Bank legal counsel', 'Certified AML Specialist', 'Member, European Compliance Association'],
    image: 'https://picsum.photos/400/400?random=8'
  },
  {
    name: 'Niamh Doyle',
    role: 'Partner, Technology & Data',
    bio: 'Niamh leads the data protection and technology contracts team, advising on GDPR, AI governance, and cloud outsourcing.',
    credentials: ['CIPP/E Certified', 'Certified Information Privacy Manager', 'Member, IAPP Ireland'],
    image: 'https://picsum.photos/400/400?random=9'
  },
  {
    name: 'James Murphy',
    role: 'Head of Litigation & Disputes',
    bio: 'James manages complex commercial disputes, arbitration, and risk management for scaling organisations.',
    credentials: ['Solicitor Advocate', 'Accredited Mediator', 'Member, Chartered Institute of Arbitrators'],
    image: 'https://picsum.photos/400/400?random=10'
  }
];

const Team = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Team | Studdfxg Legal Experts</title>
        <meta
          name="description"
          content="Meet Studdfxg’s partner-led team of corporate, fintech, data protection, and dispute resolution specialists delivering premium advisory services."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.eyebrow}>Team</span>
          <h1>Partner-led, multidisciplinary legal specialists</h1>
          <p>
            Our team combines decades of experience advising technology and finance leaders across Ireland, Europe, and the US.
            We stay close to your objectives, align with your stakeholders, and deliver decisive legal outcomes.
          </p>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.grid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.memberCard}>
                <div className={styles.photoWrapper}>
                  <img src={member.image} alt={`Portrait of ${member.name}`} loading="lazy" />
                </div>
                <div className={styles.memberContent}>
                  <h2>{member.name}</h2>
                  <p className={styles.role}>{member.role}</p>
                  <p className={styles.bio}>{member.bio}</p>
                  <h3>Credentials</h3>
                  <ul>
                    {member.credentials.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                  <Link to="/contact" className={styles.cardCta}>
                    Contact {member.name}
                    <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cultureSection}>
        <div className="container">
          <div className={styles.cultureGrid}>
            <div>
              <h2>Collaboration that scales with you</h2>
              <p>
                We pair each matter with the right blend of partner insight, senior associates, and specialist consultants.
                Teams are assembled based on your industry, geography, and risk profile, ensuring that you always have access to
                the expertise your matter demands.
              </p>
            </div>
            <div className={styles.cultureCard}>
              <h3>Professional memberships</h3>
              <ul>
                <li>Law Society of Ireland</li>
                <li>Irish Software Association</li>
                <li>International Association of Privacy Professionals (IAPP)</li>
                <li>Chartered Institute of Arbitrators</li>
                <li>European Compliance Association</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Connect directly with our partners</h2>
              <p>
                Arrange a confidential consultation to understand how Studdfxg can support your next transaction, investigation, or transformation.
              </p>
            </div>
            <Link to="/contact" className={styles.ctaButton}>
              Request a consultation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Team;