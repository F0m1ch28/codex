import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Industries.module.css';

const industries = [
  {
    title: 'Startups & Emerging Technology',
    description:
      'From formation to exits, we support cap tables, venture financings, IP protection, and cross-border expansion.',
    services: ['Venture financings', 'Founder agreements', 'IP & licensing strategy', 'Rapid expansion playbooks']
  },
  {
    title: 'Small & Medium Enterprises',
    description:
      'General counsel capability for growing businesses, covering commercial contracts, HR, risk, and governance frameworks.',
    services: ['Commercial contract suite', 'Employment law support', 'Supplier negotiations', 'Risk reviews']
  },
  {
    title: 'Fintech & Payments',
    description:
      'Authorisations, ongoing compliance, partnership agreements, and regulatory engagement for fintech innovators.',
    services: ['Central Bank of Ireland licensing', 'AML & PSD2 compliance', 'Banking partnerships', 'Governance upgrades']
  },
  {
    title: 'Creative & Digital Industries',
    description:
      'Rights management, co-production agreements, and digital distribution strategies for media, gaming, and digital agencies.',
    services: ['IP exploitation structures', 'Digital licensing', 'Brand collaborations', 'Content compliance']
  },
  {
    title: 'International Operators',
    description:
      'Landing and scaling in Ireland with corporate setup, employment, regulatory, and commercial support for global organisations.',
    services: ['Market entry planning', 'Regulatory gap analysis', 'Subsidiary governance', 'International HR strategies']
  }
];

const Industries = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Industries | Studdfxg Sector Expertise</title>
        <meta
          name="description"
          content="Studdfxg advises startups, SMEs, fintech, creative industries, and international companies operating in Ireland with sector-informed legal strategies."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.eyebrow}>Industries</span>
          <h1>Legal intelligence tailored to your sector</h1>
          <p>
            We collaborate with leadership teams across technology, finance, creative, and international organisations.
            Our matter teams combine sector context with legal precision so you can move decisively.
          </p>
        </div>
      </section>

      <section className={styles.industriesSection}>
        <div className="container">
          <div className={styles.grid}>
            {industries.map((industry) => (
              <article key={industry.title} className={styles.industryCard}>
                <header>
                  <h2>{industry.title}</h2>
                  <p>{industry.description}</p>
                </header>
                <div>
                  <h3>How we help</h3>
                  <ul>
                    {industry.services.map((service) => (
                      <li key={service}>{service}</li>
                    ))}
                  </ul>
                </div>
                <Link to="/contact" className={styles.cardCta}>
                  Start a sector consultation
                  <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Not sure where your organisation fits?</h2>
              <p>
                We regularly design bespoke teams for unique market entrants and hybrid business models.
                Let’s align on your goals and map a strategy together.
              </p>
            </div>
            <Link to="/contact" className={styles.ctaButton}>
              Contact our team
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Industries;