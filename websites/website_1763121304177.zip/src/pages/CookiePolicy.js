import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Cookie Policy | Studdfxg</title>
      <meta
        name="description"
        content="Cookie policy explaining how Studdfxg uses cookies and similar technologies on studdfxg.world."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Effective date: 1 March 2024</p>
      </div>
    </section>
    <section className={styles.content}>
      <div className="container">
        <h2>1. What are cookies?</h2>
        <p>Cookies are small text files that help us deliver a secure and effective website experience.</p>
        <h2>2. Types of cookies we use</h2>
        <ul>
          <li>Necessary cookies for security, load balancing, and session management.</li>
          <li>Analytics cookies to understand how visitors use our site and improve functionality.</li>
        </ul>
        <h2>3. Managing cookies</h2>
        <p>
          You can control cookies through browser settings. Some features may not function properly if you disable certain cookies.
        </p>
        <h2>4. Updates</h2>
        <p>
          We may update this policy to reflect changes in technology or regulation. Please review periodically.
        </p>
        <h2>5. Contact</h2>
        <p>
          For more information, contact <a href="mailto:contact@studdfxg.world">contact@studdfxg.world</a>.
        </p>
      </div>
    </section>
  </div>
);

export default CookiePolicy;