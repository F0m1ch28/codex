import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './About.module.css';

const milestones = [
  {
    year: '2010',
    title: 'Firm founded in Dublin',
    description: 'Studdfxg opens its doors with a mission to provide technology-native legal support to Irish innovators.'
  },
  {
    year: '2014',
    title: 'Cross-border expansion',
    description: 'Launched dedicated desk for US and EU inbound companies seeking agile Irish counsel.'
  },
  {
    year: '2018',
    title: 'Regulatory practice growth',
    description: 'Built a specialist regulatory team to support fintech licensing, investigations, and enforcement defence.'
  },
  {
    year: '2022',
    title: 'Integrated data advisory',
    description: 'Combined legal, data protection, and information security expertise to deliver holistic GDPR programmes.'
  }
];

const values = [
  {
    title: 'Clarity first',
    description: 'We translate complexity into actionable guidance, delivering decision-ready answers at pace.'
  },
  {
    title: 'Forward looking',
    description: 'Our teams track regulatory, commercial, and geopolitical shifts to anticipate what comes next.'
  },
  {
    title: 'Collaborative by design',
    description: 'We embed alongside leadership and product teams, aligning legal work with operational goals.'
  },
  {
    title: 'Trusted accountability',
    description: 'Every engagement maintains partner oversight, rigorous quality control, and transparent communication.'
  }
];

const About = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About Studdfxg | Dublin-based Legal Strategists</title>
        <meta
          name="description"
          content="Discover Studdfxg’s story, philosophy, and commitment to guiding technology and finance leaders through key legal milestones in Ireland."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.eyebrow}>About Studdfxg</span>
          <h1>Purpose-built Irish counsel for ambitious teams</h1>
          <p>
            Since launch, Studdfxg has combined deep legal knowledge with product fluency and boardroom experience.
            We exist to support organisations operating at the intersection of innovation, regulation, and international expansion.
          </p>
          <Link to="/team" className={styles.cta}>
            Meet our team
          </Link>
        </div>
      </section>

      <section className={styles.storySection}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2>Moving beyond traditional legal service</h2>
              <p>
                Our clients operate in markets where innovation outpaces regulation. Studdfxg bridges that gap, combining
                legal precision with commercial agility. We pair seasoned partners with multidisciplinary teams who understand
                technology, finance, and international risk.
              </p>
              <p>
                Every engagement is anchored by proximity to decision-makers, rapid iteration, and outputs that align with stakeholder expectations.
                We engage early, question assumptions, and ensure leaders are prepared for both opportunities and scrutiny.
              </p>
            </div>
            <div className={styles.storyCard}>
              <h3>Leadership principles</h3>
              <ul>
                <li>Partner-led relationships with transparent accountability.</li>
                <li>Tailored teams shaped around your operating model and growth plan.</li>
                <li>Digital collaboration powered by secure, modern tooling.</li>
                <li>Continuous learning culture underpinned by professional development.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.milestonesSection} aria-labelledby="firm-milestones">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.eyebrow}>Milestones</span>
            <h2 id="firm-milestones">A decade-plus supporting Irish innovation</h2>
          </div>
          <div className={styles.timeline}>
            {milestones.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <div className={styles.timelineYear}>{item.year}</div>
                <div className={styles.timelineContent}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.valuesSection} aria-labelledby="core-values">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.eyebrow}>Values</span>
            <h2 id="core-values">Principles guiding every engagement</h2>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Talk with a partner</h2>
              <p>
                Arrange a strategic consultation to walk through your priorities, upcoming transactions, and risk horizon.
              </p>
            </div>
            <Link to="/contact" className={styles.cta}>
              Request a consultation
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;