import React from 'react';
import { Link } from 'react-router-dom';
import styles from './NotFound.module.css';

const NotFound = () => (
  <div className={styles.page}>
    <div className={styles.inner}>
      <h1>404</h1>
      <p>The page you’re seeking is not available. Let’s guide you back on track.</p>
      <Link to="/" className={styles.cta}>
        Return home
      </Link>
    </div>
  </div>
);

export default NotFound;