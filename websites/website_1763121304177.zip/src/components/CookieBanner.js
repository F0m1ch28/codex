import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const storageKey = 'studdfxg_cookie_consent';

  useEffect(() => {
    const consent = window.localStorage.getItem(storageKey);
    if (!consent) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(storageKey, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent notice">
      <div className={styles.inner}>
        <div className={styles.copy}>
          <h4>Cookies &amp; privacy</h4>
          <p>
            We use necessary cookies to make studdfxg.world work and analytics cookies to improve your experience.
            You can learn more in our{' '}
            <Link to="/cookie-policy">Cookie Policy</Link>.
          </p>
        </div>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Accept cookies
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;