import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.inner}>
        <div className={styles.brandColumn}>
          <div className={styles.brandTitle}>Studdfxg.world</div>
          <p className={styles.brandText}>
            Strategic Irish legal advisors for founders, boards, and global businesses
            operating in and through Ireland.
          </p>
          <div className={styles.contactBlock}>
            <p>
              <strong>Address:</strong> Ireland address
            </p>
            <p>
              <strong>Phone:</strong> +353 1 555 0101
            </p>
            <p>
              <strong>Email:</strong>{' '}
              <a href="mailto:contact@studdfxg.world">contact@studdfxg.world</a>
            </p>
          </div>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Firm</h3>
          <ul className={styles.linkList}>
            <li>
              <NavLink to="/about">About</NavLink>
            </li>
            <li>
              <NavLink to="/team">Team</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
            <li>
              <NavLink to="/industries">Industries</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Resources</h3>
          <ul className={styles.linkList}>
            <li>
              <NavLink to="/resources">Insights & Guides</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Schedule a call</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Privacy Notice</NavLink>
            </li>
            <li>
              <NavLink to="/cookie-policy">Cookie Policy</NavLink>
            </li>
          </ul>
        </div>
        <div className={styles.linksColumn}>
          <h3 className={styles.columnTitle}>Engage</h3>
          <ul className={styles.linkList}>
            <li>
              <NavLink to="/contact">Request a consultation</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Contact our team</NavLink>
            </li>
            <li>
              <NavLink to="/terms">Terms of Use</NavLink>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottomRow}>
        <p>© {new Date().getFullYear()} Studdfxg. All rights reserved.</p>
        <p className={styles.euNotice}>Advising clients across Ireland & the EU.</p>
      </div>
    </footer>
  );
};

export default Footer;