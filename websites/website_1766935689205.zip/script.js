const LuxeFestive = (() => {
  const cookieKey = 'luxefestive-cookie-consent';

  function initCookieBanner() {
    const banner = document.querySelector('.cookie-banner');
    if (!banner) return;

    const acceptBtn = banner.querySelector('.cookie-accept');
    const declineBtn = banner.querySelector('.cookie-decline');
    const storedPreference = localStorage.getItem(cookieKey);

    if (!storedPreference) {
      requestAnimationFrame(() => banner.classList.add('is-visible'));
    }

    const setPreference = (value) => {
      localStorage.setItem(cookieKey, value);
      banner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', () => setPreference('accepted'));
    declineBtn?.addEventListener('click', () => setPreference('declined'));
  }

  function initCustomizer() {
    const form = document.getElementById('customBoxForm');
    if (!form) return;

    const previewTheme = document.getElementById('previewTheme');
    const previewMood = document.getElementById('previewMood');
    const previewRibbon = document.getElementById('previewRibbon');
    const previewBudget = document.getElementById('previewBudget');
    const budgetValue = document.getElementById('budgetValue');
    const previewItems = document.getElementById('selectedItems');
    const previewSummary = document.getElementById('previewSummary');
    const previewDate = document.getElementById('previewDate');
    const previewMessage = document.getElementById('previewMessage');
    const previewCard = document.getElementById('boxPreview');
    const alertBox = document.getElementById('customizerAlert');

    const themeSelect = form.querySelector('#themeSelect');
    const ribbonSelect = form.querySelector('#ribbonStyle');
    const moodRadios = form.querySelectorAll('input[name="mood"]');
    const budgetRange = form.querySelector('#budgetRange');
    const deliveryDate = form.querySelector('#deliveryDate');
    const messageField = form.querySelector('#message');
    const recipientField = form.querySelector('#recipientName');

    const updateItems = () => {
      const treatCheckboxes = form.querySelectorAll('input[name="treats"]:checked');
      previewItems.innerHTML = '';
      if (treatCheckboxes.length === 0) {
        const placeholder = document.createElement('span');
        placeholder.className = 'chip';
        placeholder.textContent = 'No treats selected yet';
        previewItems.appendChild(placeholder);
        return;
      }
      treatCheckboxes.forEach((checkbox) => {
        const chip = document.createElement('span');
        chip.className = 'chip';
        chip.textContent = checkbox.value;
        previewItems.appendChild(chip);
      });
    };

    const formatDate = (value) => {
      if (!value) return 'Select a date';
      const date = new Date(value + 'T00:00:00');
      return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    };

    const updateThemeBanner = () => {
      const selected = themeSelect.options[themeSelect.selectedIndex];
      const colors = selected.dataset.colors ? selected.dataset.colors.split(',') : ['#b40a2d', '#f7c948'];
      previewCard.querySelector('.preview-banner').style.background = `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`;
      previewTheme.textContent = selected.textContent;
    };

    const updateMood = () => {
      const selectedMood = form.querySelector('input[name="mood"]:checked');
      previewMood.textContent = `Mood: ${selectedMood ? selectedMood.value : 'Heartfelt & Cozy'}`;
    };

    const updateBudget = () => {
      const value = Number(budgetRange.value);
      const formatted = `$${value}`;
      previewBudget.textContent = formatted;
      budgetValue.textContent = formatted;
    };

    const updateRibbon = () => {
      previewRibbon.textContent = ribbonSelect.value;
    };

    const updateMessage = () => {
      const name = recipientField.value.trim() || 'Your loved one';
      const note = messageField.value.trim();
      if (note.length > 0) {
        previewMessage.textContent = note;
      } else {
        previewMessage.textContent = 'Your message will appear here with artisan calligraphy.';
      }
      previewSummary.textContent = `${name}’s celebration pairs ${previewTheme.textContent.toLowerCase()} with ${previewMood.textContent.replace('Mood: ', '').toLowerCase()} energy.`;
    };

    const updateDate = () => {
      previewDate.textContent = formatDate(deliveryDate.value);
    };

    const updatePreview = () => {
      updateThemeBanner();
      updateMood();
      updateRibbon();
      updateBudget();
      updateItems();
      updateMessage();
      updateDate();
    };

    form.addEventListener('input', updatePreview);
    form.addEventListener('change', updatePreview);

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      updatePreview();
      alertBox.textContent = 'Your celebration blueprint is saved! Our concierge will email final touches within 12 hours.';
      alertBox.className = 'form-alert success is-visible';
    });

    updatePreview();
  }

  function initOccasionFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const cards = document.querySelectorAll('.occasion-card');
    if (!filterButtons.length || !cards.length) return;

    filterButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const filter = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove('is-active'));
        button.classList.add('is-active');

        cards.forEach((card) => {
          if (filter === 'all' || card.dataset.occasion === filter) {
            card.classList.remove('is-hidden');
          } else {
            card.classList.add('is-hidden');
          }
        });
      });
    });
  }

  function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    const alertBox = document.getElementById('contactAlert');

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const name = form.contactName.value.trim();
      const email = form.contactEmail.value.trim();
      const message = form.contactMessage.value.trim();

      if (!name || !email || !message) {
        alertBox.textContent = 'Please complete your name, email, and message so we can support your celebration.';
        alertBox.className = 'form-alert error is-visible';
        return;
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        alertBox.textContent = 'Please provide a valid email address.';
        alertBox.className = 'form-alert error is-visible';
        return;
      }

      alertBox.textContent = 'Thank you! Our concierge will reach out within 12 hours.';
      alertBox.className = 'form-alert success is-visible';
      form.reset();
    });
  }

  function init() {
    document.addEventListener('DOMContentLoaded', () => {
      initCookieBanner();
      initCustomizer();
      initOccasionFilters();
      initContactForm();
    });
  }

  return { init };
})();

LuxeFestive.init();