document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const toggle = document.querySelector('.mobile-toggle');
    const nav = document.getElementById('primaryNav');

    if (toggle && nav) {
        toggle.addEventListener('click', () => {
            const expanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', (!expanded).toString());
            body.classList.toggle('nav-open', !expanded);
        });

        const navLinks = nav.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 1024) {
                    toggle.setAttribute('aria-expanded', 'false');
                    body.classList.remove('nav-open');
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                toggle.setAttribute('aria-expanded', 'false');
                body.classList.remove('nav-open');
            }
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = document.querySelectorAll('[data-cookie-consent]');

    if (cookieBanner) {
        let consentValue = null;
        try {
            consentValue = localStorage.getItem('dv-cookie-consent');
        } catch (error) {
            consentValue = null;
        }

        if (!consentValue) {
            cookieBanner.classList.add('is-visible');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.dataset.cookieConsent || 'undecided';
                try {
                    localStorage.setItem('dv-cookie-consent', choice);
                } catch (error) {
                    // Ignore storage errors (private mode)
                }
                cookieBanner.classList.remove('is-visible');
                const target = button.getAttribute('href');
                if (target) {
                    setTimeout(() => {
                        window.location.href = target;
                    }, 150);
                }
            });
        });
    }
});