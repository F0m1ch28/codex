document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function () {
            navLinks.classList.toggle('is-open');
            menuToggle.classList.toggle('active');
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', !expanded);
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    menuToggle.classList.remove('active');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const cookieStorageKey = 'romanlqkgxCookieConsent';

    if (cookieBanner && acceptBtn && declineBtn) {
        const savedConsent = localStorage.getItem(cookieStorageKey);

        if (!savedConsent) {
            setTimeout(function () {
                cookieBanner.classList.remove('is-hidden');
            }, 400);
        }

        function handleConsent(choice) {
            localStorage.setItem(cookieStorageKey, choice);
            cookieBanner.classList.add('is-hidden');
        }

        acceptBtn.addEventListener('click', function () {
            handleConsent('accepted');
        });

        declineBtn.addEventListener('click', function () {
            handleConsent('declined');
        });
    }
});