const YKV_STORAGE_KEYS = {
  USER: "ykvUser",
  PROFILE: "ykvProfile",
  LEADERBOARD: "ykvLeaderboard",
  COOKIE: "ykvCookieConsent",
  STATS: "ykvStats"
};

document.addEventListener("DOMContentLoaded", () => {
  initializeUserName();
  handleCookieBanner();
  initializeProfile();
  initializeGame();
  populateStats();
  populateLeaderboard();
  bindContactForm();
});

function initializeUserName() {
  const nameContainerList = document.querySelectorAll("[data-user-name]");
  const profile = getProfileData();
  const name = profile?.name || "Гость";
  nameContainerList.forEach((el) => {
    el.textContent = name;
  });
}

function handleCookieBanner() {
  const bannerList = document.querySelectorAll("[data-cookie-banner]");
  if (!bannerList.length) return;
  const consent = localStorage.getItem(YKV_STORAGE_KEYS.COOKIE);
  if (consent) {
    bannerList.forEach((banner) => banner.classList.remove("active"));
    return;
  }
  bannerList.forEach((banner) => banner.classList.add("active"));
  document.querySelectorAll("[data-cookie-accept]").forEach((button) => {
    button.addEventListener("click", () => {
      localStorage.setItem(YKV_STORAGE_KEYS.COOKIE, "accepted");
      bannerList.forEach((banner) => banner.classList.remove("active"));
    });
  });
  document.querySelectorAll("[data-cookie-decline]").forEach((button) => {
    button.addEventListener("click", () => {
      localStorage.setItem(YKV_STORAGE_KEYS.COOKIE, "declined");
      bannerList.forEach((banner) => banner.classList.remove("active"));
    });
  });
}

function getProfileData() {
  try {
    const profileRaw = localStorage.getItem(YKV_STORAGE_KEYS.PROFILE);
    if (!profileRaw) return null;
    return JSON.parse(profileRaw);
  } catch (err) {
    console.error("Не удалось прочитать профиль", err);
    return null;
  }
}

function saveProfileData(data) {
  localStorage.setItem(YKV_STORAGE_KEYS.PROFILE, JSON.stringify(data));
}

function initializeProfile() {
  const profileForm = document.querySelector("[data-profile-form]");
  if (!profileForm) return;
  const profile = getProfileData() || {
    name: "Гость",
    email: "",
    notification: "weekly",
    xp: 0,
    streak: 0,
    games: 0,
    averageScore: 0
  };
  profileForm.playerName.value = profile.name || "";
  profileForm.playerEmail.value = profile.email || "";
  profileForm.notification.value = profile.notification || "weekly";
  profileForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const updatedProfile = {
      ...profile,
      name: profileForm.playerName.value.trim() || "Игрок",
      email: profileForm.playerEmail.value.trim(),
      notification: profileForm.notification.value
    };
    saveProfileData(updatedProfile);
    initializeUserName();
    renderProfileStats(updatedProfile);
  });
  renderProfileStats(profile);
}

function renderProfileStats(profile) {
  const xp = profile?.xp || 0;
  const streak = profile?.streak || 0;
  const games = profile?.games || 0;
  const average = profile?.averageScore || 0;
  const level = Math.floor(xp / 120) + 1;
  const xpIntoLevel = xp % 120;
  const xpRemaining = 120 - xpIntoLevel;
  const levelLabel = level >= 5 ? "Гуру Яндекса" : level >= 3 ? "Продвинутый" : "Новичок";
  const progressPercent = Math.min(100, Math.round((xpIntoLevel / 120) * 100));
  const levelElement = document.querySelector("[data-profile-level]");
  if (levelElement) {
    levelElement.textContent = `Уровень ${level} · ${levelLabel}`;
  }
  const xpElement = document.querySelector("[data-profile-xp]");
  if (xpElement) {
    xpElement.textContent = `${xp} XP`;
  }
  const progressElement = document.querySelector("[data-profile-progress]");
  if (progressElement) {
    progressElement.style.width = `${progressPercent}%`;
  }
  const nextElement = document.querySelector("[data-profile-next]");
  if (nextElement) {
    nextElement.textContent = xpRemaining;
  }
  const streakElement = document.querySelector("[data-profile-streak]");
  if (streakElement) streakElement.textContent = streak;
  const gamesElement = document.querySelector("[data-profile-games]");
  if (gamesElement) gamesElement.textContent = games;
  const averageElement = document.querySelector("[data-profile-average]");
  if (averageElement) averageElement.textContent = average;
}

function initializeGame() {
  const gameRoot = document.querySelector("[data-game-root]");
  if (!gameRoot) return;
  const startButton = document.querySelector("[data-game-start]");
  const skipButton = document.querySelector("[data-game-skip]");
  const resetButton = document.querySelector("[data-game-reset]");
  const questionElement = document.querySelector("[data-game-question]");
  const answersContainer = document.querySelector("[data-game-answers]");
  const progressLine = document.querySelector("[data-game-progress]");
  const roundElement = document.querySelector("[data-game-round]");
  const scoreElement = document.querySelector("[data-game-score]");
  const streakElement = document.querySelector("[data-game-streak]");
  const summaryBlock = document.querySelector("[data-game-summary]");
  const summaryScore = document.querySelector("[data-summary-score]");
  const summaryAccuracy = document.querySelector("[data-summary-accuracy]");
  const summaryBest = document.querySelector("[data-summary-best]");
  const shareVK = document.querySelector("[data-share-vk]");
  const shareTG = document.querySelector("[data-share-tg]");
  const questions = getGameQuestions();
  let currentIndex = -1;
  let score = 0;
  let streak = 0;
  let correctAnswers = 0;
  let answeredQuestions = 0;
  const totalQuestions = questions.length;

  roundElement.textContent = `0 / ${totalQuestions}`;
  scoreElement.textContent = score;
  streakElement.textContent = streak;

  function startGame() {
    currentIndex = -1;
    score = 0;
    streak = 0;
    correctAnswers = 0;
    answeredQuestions = 0;
    summaryBlock.classList.remove("active");
    nextQuestion();
  }

  function nextQuestion() {
    currentIndex += 1;
    if (currentIndex >= totalQuestions) {
      finishGame();
      return;
    }
    roundElement.textContent = `${currentIndex + 1} / ${totalQuestions}`;
    const currentQuestion = questions[currentIndex];
    questionElement.textContent = currentQuestion.question;
    answersContainer.innerHTML = "";
    currentQuestion.answers.forEach((answer) => {
      const option = document.createElement("button");
      option.textContent = answer.text;
      option.addEventListener("click", () => selectAnswer(option, answer.correct, currentQuestion.difficulty));
      answersContainer.appendChild(option);
    });
    updateProgress();
  }

  function selectAnswer(button, isCorrect, difficulty) {
    if (button.classList.contains("correct") || button.classList.contains("incorrect")) return;
    const allButtons = Array.from(answersContainer.querySelectorAll("button"));
    allButtons.forEach((btn) => btn.disabled = true);
    answeredQuestions += 1;
    if (isCorrect) {
      button.classList.add("correct");
      correctAnswers += 1;
      streak += 1;
      const points = 10 + (difficulty === "hard" ? 5 : difficulty === "medium" ? 3 : 1);
      score += points;
    } else {
      button.classList.add("incorrect");
      streak = 0;
    }
    scoreElement.textContent = score;
    streakElement.textContent = streak;
    setTimeout(nextQuestion, 900);
  }

  function skipQuestion() {
    if (currentIndex >= totalQuestions) return;
    streak = Math.max(0, streak - 1);
    score = Math.max(0, score - 5);
    scoreElement.textContent = score;
    streakElement.textContent = streak;
    nextQuestion();
  }

  function finishGame() {
    const accuracy = answeredQuestions ? Math.round((correctAnswers / answeredQuestions) * 100) : 0;
    questionElement.textContent = "Раунд завершён! Сыграйте снова, чтобы улучшить результат.";
    answersContainer.innerHTML = "";
    summaryBlock.classList.add("active");
    summaryScore.textContent = score;
    summaryAccuracy.textContent = `${accuracy}%`;
    const best = updateStatistics(score, streak, accuracy);
    summaryBest.textContent = best;
    updateProgress();
    updateShareLinks(shareVK, shareTG, score, accuracy);
  }

  function resetGame() {
    currentIndex = -1;
    score = 0;
    streak = 0;
    correctAnswers = 0;
    answeredQuestions = 0;
    scoreElement.textContent = score;
    streakElement.textContent = streak;
    questionElement.textContent = "Игра сброшена. Нажмите «Играть сейчас», чтобы начать новый раунд.";
    answersContainer.innerHTML = "";
    summaryBlock.classList.remove("active");
    progressLine.style.width = "0%";
    roundElement.textContent = `0 / ${totalQuestions}`;
  }

  function updateProgress() {
    const progressPercent = Math.min(100, Math.round(((currentIndex + 1) / totalQuestions) * 100));
    progressLine.style.width = `${progressPercent}%`;
  }

  startButton?.addEventListener("click", startGame);
  skipButton?.addEventListener("click", skipQuestion);
  resetButton?.addEventListener("click", resetGame);
}

function getGameQuestions() {
  return [
    {
      question: "Какой сервис Яндекса помогает строить маршруты с учётом пробок?",
      difficulty: "easy",
      answers: [
        { text: "Яндекс.Карты", correct: true },
        { text: "Яндекс.Дзен", correct: false },
        { text: "Яндекс.Маркет", correct: false },
        { text: "Яндекс.Лавка", correct: false }
      ]
    },
    {
      question: "Как называется голосовой ассистент Яндекса?",
      difficulty: "easy",
      answers: [
        { text: "Сири", correct: false },
        { text: "Алиса", correct: true },
        { text: "Кортана", correct: false },
        { text: "Агата", correct: false }
      ]
    },
    {
      question: "Что делает технология CatBoost от Яндекса?",
      difficulty: "medium",
      answers: [
        { text: "Автоматизирует логистику доставки", correct: false },
        { text: "Обрабатывает платежи", correct: false },
        { text: "Решает задачи машинного обучения", correct: true },
        { text: "Управляет рекламными баннерами", correct: false }
      ]
    },
    {
      question: "Какой сервис отвечает за облачные вычисления?",
      difficulty: "medium",
      answers: [
        { text: "Яндекс 360", correct: false },
        { text: "Яндекс.Cloud", correct: true },
        { text: "Яндекс.Еда", correct: false },
        { text: "Яндекс Go", correct: false }
      ]
    },
    {
      question: "Какой формат музыки поддерживает Яндекс.Музыка для офлайн-проигрывания?",
      difficulty: "hard",
      answers: [
        { text: "Только WAV", correct: false },
        { text: "MP3 и AAC", correct: true },
        { text: "OGG только", correct: false },
        { text: "Только FLAC", correct: false }
      ]
    },
    {
      question: "Где находится штаб-квартира Яндекса?",
      difficulty: "hard",
      answers: [
        { text: "Санкт-Петербург", correct: false },
        { text: "Москва", correct: true },
        { text: "Минск", correct: false },
        { text: "Новосибирск", correct: false }
      ]
    },
    {
      question: "Какой сервис Яндекса помогает анализировать посетителей сайта?",
      difficulty: "medium",
      answers: [
        { text: "Яндекс.Метрика", correct: true },
        { text: "Яндекс.Погода", correct: false },
        { text: "Яндекс.Трекер", correct: false },
        { text: "Яндекс.Диск", correct: false }
      ]
    },
    {
      question: "В каком году был запущен поисковик yandex.ru?",
      difficulty: "hard",
      answers: [
        { text: "1990", correct: false },
        { text: "1997", correct: true },
        { text: "2001", correct: false },
        { text: "1995", correct: false }
      ]
    }
  ];
}

function updateStatistics(score, streak, accuracy) {
  const stats = getStatsData();
  const profile = getProfileData() || {
    name: "Гость",
    xp: 0,
    streak: 0,
    games: 0,
    averageScore: 0
  };
  const timestamp = new Date().toISOString();
  const bestScore = Math.max(stats.bestScore || 0, score);
  const bestStreak = Math.max(stats.bestStreak || 0, streak);
  const gamesPlayed = (profile.games || 0) + 1;
  const totalScores = (profile.averageScore || 0) * (profile.games || 0) + score;
  const newAverage = Math.round(totalScores / gamesPlayed);
  const newAccuracy = Math.round(((stats.totalAccuracy || 0) * (stats.games || 0) + accuracy) / (stats.games + 1 || 1));
  const newStats = {
    bestScore,
    bestStreak,
    lastPlayed: timestamp,
    games: (stats.games || 0) + 1,
    totalAccuracy: newAccuracy
  };
  localStorage.setItem(YKV_STORAGE_KEYS.STATS, JSON.stringify(newStats));
  const newProfile = {
    ...profile,
    xp: (profile.xp || 0) + score,
    streak,
    games: gamesPlayed,
    averageScore: newAverage
  };
  saveProfileData(newProfile);
  addToLeaderboard(newProfile.name || "Игрок", score, accuracy, timestamp);
  renderProfileStats(newProfile);
  populateStats();
  return `Лучший счет: ${bestScore}, лучшая серия: ${bestStreak}`;
}

function getStatsData() {
  try {
    const raw = localStorage.getItem(YKV_STORAGE_KEYS.STATS);
    if (!raw) return { bestScore: 0, bestStreak: 0, lastPlayed: null, games: 0, totalAccuracy: 0 };
    return JSON.parse(raw);
  } catch (error) {
    console.error("Ошибка чтения статистики", error);
    return { bestScore: 0, bestStreak: 0, lastPlayed: null, games: 0, totalAccuracy: 0 };
  }
}

function populateStats() {
  const stats = getStatsData();
  const totalXpElement = document.querySelector("[data-stat-total-xp]");
  const streakElement = document.querySelector("[data-stat-streak]");
  const reactionElement = document.querySelector("[data-stat-reaction]");
  const bestStreakElement = document.querySelector("[data-stat-best-streak]");
  const accuracyElement = document.querySelector("[data-stat-accuracy]");
  const lastPlayedElement = document.querySelector("[data-stat-last-played]");
  const profile = getProfileData();
  if (totalXpElement && profile) totalXpElement.textContent = profile.xp || 0;
  if (streakElement && profile) streakElement.textContent = profile.streak || 0;
  if (reactionElement) reactionElement.textContent = stats.games ? "2.4 c" : "—";
  if (bestStreakElement) bestStreakElement.textContent = stats.bestStreak || 0;
  if (accuracyElement) accuracyElement.textContent = `${stats.totalAccuracy || 0}%`;
  if (lastPlayedElement) {
    lastPlayedElement.textContent = stats.lastPlayed ? new Date(stats.lastPlayed).toLocaleString("ru-RU") : "—";
  }
}

function addToLeaderboard(name, score, accuracy, timestamp) {
  const leaderboard = getLeaderboard();
  leaderboard.unshift({
    name,
    score,
    accuracy: `${accuracy}%`,
    updated: new Date(timestamp).toLocaleString("ru-RU")
  });
  const trimmed = leaderboard.slice(0, 20);
  localStorage.setItem(YKV_STORAGE_KEYS.LEADERBOARD, JSON.stringify(trimmed));
  populateLeaderboard();
}

function getLeaderboard() {
  try {
    const raw = localStorage.getItem(YKV_STORAGE_KEYS.LEADERBOARD);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (error) {
    console.error("Ошибка чтения лидерборда", error);
    return [];
  }
}

function populateLeaderboard() {
  const body = document.querySelector("[data-leaderboard-body]");
  if (!body) return;
  const leaderboard = getLeaderboard();
  body.innerHTML = "";
  if (!leaderboard.length) {
    const row = document.createElement("tr");
    row.classList.add("table-empty");
    const cell = document.createElement("td");
    cell.colSpan = 5;
    cell.textContent = "Ещё нет данных. Сыграйте первый раунд!";
    row.appendChild(cell);
    body.appendChild(row);
    return;
  }
  leaderboard.forEach((entry, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${index + 1}</td>
      <td>${entry.name}</td>
      <td>${entry.score}</td>
      <td>${entry.accuracy}</td>
      <td>${entry.updated}</td>
    `;
    body.appendChild(row);
  });
}

function updateShareLinks(vkButton, tgButton, score, accuracy) {
  if (vkButton) {
    const vkText = encodeURIComponent(`Я набрал ${score} очков и ${accuracy}% точности в «Игре как вы Яндексе»!`);
    vkButton.href = `https://vk.com/share.php?comment=${vkText}`;
  }
  if (tgButton) {
    const tgText = encodeURIComponent(`Мой результат: ${score} очков и ${accuracy}% точности в «Игре как вы Яндексе»!`);
    tgButton.href = `https://t.me/share/url?url=https://igrayandex.ru&text=${tgText}`;
  }
}

function bindContactForm() {
  const contactForm = document.querySelector("[data-contact-form]");
  if (!contactForm) return;
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    alert("Спасибо! Мы получили ваше сообщение и ответим в течение 24 часов.");
    contactForm.reset();
  });
}