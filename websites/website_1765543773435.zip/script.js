document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');

  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navList.classList.toggle('is-open');
    });

    navList.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navList.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('ue_cookie_consent');
    if (storedPreference) {
      cookieBanner.classList.add('is-hidden');
    } else {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }

    const acceptButton = cookieBanner.querySelector('.cookie-accept');
    const declineButton = cookieBanner.querySelector('.cookie-decline');

    const handleChoice = (choice) => {
      localStorage.setItem('ue_cookie_consent', choice);
      cookieBanner.classList.add('is-hidden');
    };

    acceptButton?.addEventListener('click', () => handleChoice('accepted'));
    declineButton?.addEventListener('click', () => handleChoice('declined'));
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const destinationCards = document.querySelectorAll('[data-category]');

  if (filterButtons.length && destinationCards.length) {
    filterButtons.forEach(button => {
      button.addEventListener('click', () => {
        const filter = button.dataset.filter;
        filterButtons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');

        destinationCards.forEach(card => {
          const categories = card.dataset.category.split(',');
          const isMatch = filter === 'all' || categories.includes(filter);
          card.classList.toggle('is-hidden', !isMatch);
        });
      });
    });
  }

  const journeyToggles = document.querySelectorAll('.journey-toggle');
  journeyToggles.forEach(toggle => {
    toggle.addEventListener('click', () => {
      const journeyCard = toggle.closest('.journey-card');
      const details = journeyCard?.querySelector('.journey-details');
      if (!details) return;
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      details.toggleAttribute('hidden', expanded);
    });
  });

  const contactForm = document.querySelector('#contact-form');
  const statusMessage = document.querySelector('.form-status');

  if (contactForm && statusMessage) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!contactForm.checkValidity()) {
        contactForm.reportValidity();
        statusMessage.textContent = 'Please complete all required fields before sending your message.';
        statusMessage.classList.add('is-error');
        return;
      }
      statusMessage.classList.remove('is-error');
      statusMessage.textContent = 'Thank you! Your message is on its way. We will respond within 24 hours.';
      contactForm.reset();
    });
  }
});