document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('active');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    siteNav.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const consentKey = 'genusCayqgConsent';

    if (cookieBanner && acceptBtn && declineBtn) {
        const storedConsent = localStorage.getItem(consentKey);

        if (!storedConsent) {
            setTimeout(() => {
                cookieBanner.classList.add('active');
            }, 500);
        }

        acceptBtn.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineBtn.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});