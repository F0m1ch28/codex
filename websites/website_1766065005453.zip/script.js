document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      navMenu.classList.toggle('is-open');
    });

    navMenu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navMenu.classList.remove('is-open');
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const consentKey = 'qazfinance_cookie_consent';

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedConsent = localStorage.getItem(consentKey);
    if (storedConsent === 'accepted' || storedConsent === 'declined') {
      cookieBanner.classList.add('is-hidden');
    }

    acceptBtn.addEventListener('click', function () {
      localStorage.setItem(consentKey, 'accepted');
      cookieBanner.classList.add('is-hidden');
    });

    declineBtn.addEventListener('click', function () {
      localStorage.setItem(consentKey, 'declined');
      cookieBanner.classList.add('is-hidden');
    });
  }
});