document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('#nav-list');
  const primaryNav = document.querySelector('.primary-nav');
  const body = document.body;
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const yearEl = document.getElementById('year');
  const contactForm = document.getElementById('contactForm');
  const formSuccess = document.querySelector('.form-success');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  /* Mobile Navigation */
  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
      navToggle.setAttribute('aria-expanded', !expanded);
      navList.classList.toggle('open');
      primaryNav.classList.toggle('open');
    });

    navList.querySelectorAll('a').forEach(link =>
      link.addEventListener('click', () => {
        navList.classList.remove('open');
        primaryNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      })
    );
  }

  /* Active Navigation Highlight */
  const currentPage = body.dataset.page;
  if (currentPage) {
    const activeLink = document.querySelector(`a[data-nav="${currentPage}"]`);
    if (activeLink) {
      activeLink.classList.add('active');
    }
  }

  /* Smooth Scroll for anchor links */
  document.querySelectorAll('[data-scroll]').forEach(link => {
    link.addEventListener('click', event => {
      const href = link.getAttribute('href');
      if (href && href.startsWith('#')) {
        event.preventDefault();
        document.querySelector(href).scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  /* Cookie Banner */
  const storageKey = 'aurora-cookie-consent';
  const consent = localStorage.getItem(storageKey);

  const hideBanner = () => {
    cookieBanner.classList.remove('show');
    setTimeout(() => {
      cookieBanner.style.display = 'none';
    }, 400);
  };

  if (!consent && cookieBanner) {
    setTimeout(() => {
      cookieBanner.classList.add('show');
    }, 600);
  } else {
    cookieBanner.style.display = 'none';
  }

  const setConsent = value => {
    localStorage.setItem(storageKey, value);
    hideBanner();
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => setConsent('accepted'));
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => setConsent('declined'));
  }

  /* Contact Form Validation */
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      let isValid = true;

      const requiredFields = ['name', 'email', 'message'];
      requiredFields.forEach(fieldId => {
        const field = contactForm.querySelector(`#${fieldId}`);
        const errorEl = field.nextElementSibling;
        if (!field.value.trim()) {
          isValid = false;
          errorEl.textContent = 'This field is required.';
        } else if (fieldId === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value)) {
          isValid = false;
          errorEl.textContent = 'Enter a valid email address.';
        } else {
          errorEl.textContent = '';
        }
      });

      if (isValid) {
        formSuccess.textContent = 'Thank you! We will reach out within two business days.';
        contactForm.reset();
        setTimeout(() => {
          formSuccess.textContent = '';
        }, 6000);
      }
    });

    contactForm.querySelectorAll('input, textarea').forEach(field => {
      field.addEventListener('input', () => {
        const errorEl = field.nextElementSibling;
        if (errorEl && errorEl.classList.contains('error-message')) {
          errorEl.textContent = '';
        }
      });
    });
  }
});