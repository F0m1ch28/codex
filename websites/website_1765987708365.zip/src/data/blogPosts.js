const blogPosts = [
  {
    slug: 'tecnicas-manejo-estres',
    title: 'Técnicas de manejo del estrés diario',
    excerpt: 'Respiración consciente, micro hábitos y rituales de cierre para sostenerte durante jornadas demandantes.',
    date: '5 mayo 2024',
    author: 'Equipo Sol Mirado',
    image: 'https://picsum.photos/seed/estres/860/520',
    content: [
      'Cuando el estrés se vuelve parte del paisaje cotidiano, nuestro sistema nervioso opera en alerta constante. El primer paso es reconocer las señales: tensión muscular, pensamientos acelerados y dificultades para dormir.',
      'Implementar pausas conscientes cada 90 minutos ayuda a recalibrar tu energía. Puedes combinar respiraciones 4-7-8, estiramientos suaves y un registro rápido de emociones en tu diario.',
      'Cerrar la jornada con un ritual breve crea seguridad. Haz una lista de tres logros, agradece a tu cuerpo por sostenerte y elige una actividad restaurativa: un baño tibio, luz tenue o música calmante.',
    ],
  },
  {
    slug: 'cambio-laboral-salud-mental',
    title: 'Cambio laboral: cuidar la salud mental en el proceso',
    excerpt: 'Cómo gestionar emociones, expectativas y relaciones al iniciar un nuevo capítulo profesional.',
    date: '21 abril 2024',
    author: 'Alma Rivera',
    image: 'https://picsum.photos/seed/cambio-laboral/860/520',
    content: [
      'Los cambios laborales suelen combinar entusiasmo con incertidumbre. Identificar qué parte del proceso depende de ti y cuál no es clave para bajar la ansiedad.',
      'Diseña un plan de 30-60-90 días que incluya metas realistas, espacios de descanso y conversaciones de retroalimentación. Mantén comunicación abierta con tu red de apoyo para procesar lo que vives.',
      'Recuerda que adaptarte toma tiempo. Celebra cada aprendizaje y registra cómo evoluciona tu nivel de energía. La transición será más amable si honras tu ritmo.',
    ],
  },
  {
    slug: 'rituales-para-transiciones-personales',
    title: 'Rituales conscientes para transiciones personales',
    excerpt: 'Pequeños gestos simbólicos que marcan hitos y te permiten despedirte de etapas anteriores.',
    date: '8 abril 2024',
    author: 'Carmen Ortiz',
    image: 'https://picsum.photos/seed/rituales/860/520',
    content: [
      'Los rituales no tienen que ser ceremonias complejas. Basta con intenciones claras y atención plena. Puedes escribir una carta de gratitud a la etapa que concluye y quemarla de forma segura como acto simbólico.',
      'Involucra elementos sensoriales: aromas que evoquen calma, texturas suaves o música que te conecte con emociones que quieras invitar a tu vida.',
      'Al finalizar, regálate unos minutos de silencio para notar cómo se siente tu cuerpo. Reconoce lo que se transforma y dale bienvenida a lo que nace.',
    ],
  },
];

export default blogPosts;
