import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'solMiradoCookieConsent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleDecision = (choice) => {
    localStorage.setItem(STORAGE_KEY, choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <h2>Cookies para mejorar tu experiencia</h2>
        <p>
          Utilizamos cookies esenciales para asegurar el funcionamiento del sitio y comprender cómo navegas. Puedes
          conocer más en nuestra <Link to="/cookie-policy">Política de Cookies</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondary} onClick={() => handleDecision('rejected')}>
          Rechazar
        </button>
        <button type="button" className={styles.primary} onClick={() => handleDecision('accepted')}>
          Aceptar
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;