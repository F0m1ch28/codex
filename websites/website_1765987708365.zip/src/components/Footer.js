import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const currentYear = new Date().getFullYear();

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Pie de página de Sol Mirado">
      <div className={styles.columns}>
        <div className={styles.brandBlock}>
          <div className={styles.logo}>
            <span role="img" aria-label="Sol">🌅</span>
          </div>
          <p className={styles.tagline}>
            Acompañamos tus procesos de cambio con recursos claros, apoyo constante y una comunidad que escucha.
          </p>
        </div>
        <div className={styles.linkBlock}>
          <h3>Explora</h3>
          <NavLink to="/">Inicio</NavLink>
          <NavLink to="/guide">Guías</NavLink>
          <NavLink to="/programs">Programas</NavLink>
          <NavLink to="/tools">Herramientas</NavLink>
          <NavLink to="/blog">Blog</NavLink>
        </div>
        <div className={styles.linkBlock}>
          <h3>Compañía</h3>
          <NavLink to="/about">Acerca de</NavLink>
          <NavLink to="/contact">Contacto</NavLink>
          <NavLink to="/legal">Aviso Legal</NavLink>
          <NavLink to="/terms">Términos de Servicio</NavLink>
          <NavLink to="/privacy">Política de Privacidad</NavLink>
          <NavLink to="/cookie-policy">Política de Cookies</NavLink>
        </div>
        <div className={styles.contactBlock}>
          <h3>Conexión</h3>
          <p>hola@solmiradoventola.site</p>
          <div className={styles.social}>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram de Sol Mirado">
              <span aria-hidden="true">ⓘ</span>
            </a>
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn de Sol Mirado">
              <span aria-hidden="true">in</span>
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube de Sol Mirado">
              <span aria-hidden="true">▶</span>
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {currentYear} Sol Mirado. Inspirando equilibrio consciente.</p>
      </div>
    </footer>
  );
}

export default Footer;