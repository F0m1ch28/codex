import React, { useState, useEffect } from 'react';
import styles from './ScrollToTop.module.css';

function ScrollToTopButton() {
  const [showButton, setShowButton] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setShowButton(window.scrollY > 320);
    };
    window.addEventListener('scroll', toggleVisibility, { passive: true });
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const handleScrollTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!showButton) {
    return null;
  }

  return (
    <button type="button" className={styles.scrollButton} onClick={handleScrollTop} aria-label="Volver arriba">
      ↑
    </button>
  );
}

export default ScrollToTopButton;