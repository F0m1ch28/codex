import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const body = document.body;
    if (menuOpen) {
      body.classList.add('no-scroll');
    } else {
      body.classList.remove('no-scroll');
    }
  }, [menuOpen]);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.brand} aria-label="Ir al inicio">
          <span className={styles.brandSymbol}>☀️</span>
          <span className={styles.brandText}>Sol Mirado</span>
        </NavLink>
        <button
          className={styles.menuButton}
          type="button"
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span className={styles.menuIcon} />
          <span className="sr-only">Abrir o cerrar menú</span>
        </button>
        <nav
          id="primary-navigation"
          className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"}
          aria-label="Navegación principal"
        >
          <NavLink to="/" className={({ isActive }) => (isActive ? styles.activeLink : styles.navLink)}>
            Inicio
          </NavLink>
          <NavLink to="/guide" className={({ isActive }) => (isActive ? styles.activeLink : styles.navLink)}>
            Guías
          </NavLink>
          <NavLink to="/programs" className={({ isActive }) => (isActive ? styles.activeLink : styles.navLink)}>
            Programas
          </NavLink>
          <NavLink to="/tools" className={({ isActive }) => (isActive ? styles.activeLink : styles.navLink)}>
            Herramientas
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.activeLink : styles.navLink)}>
            Blog
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? styles.activeLink : styles.navLink)}>
            Acerca de
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.activeLink : styles.navLink)}>
            Contacto
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default Header;