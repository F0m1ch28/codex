import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

function AboutPage() {
  return (
    <>
      <Helmet>
        <title>Acerca de Sol Mirado | Nuestra historia y misión</title>
        <meta
          name="description"
          content="Conoce la misión de Sol Mirado: acompañar procesos de cambio con herramientas integrales, ciencia del bienestar y una comunidad empática."
        />
      </Helmet>
      <section className={styles.introSection}>
        <div className={styles.text}>
          <h1>Un faro para acompañar el cambio desde México hacia el mundo</h1>
          <p>
            Sol Mirado nació frente al mar de Oaxaca, cuando un grupo de psicólogas, facilitadores somáticos y
            educadoras se propusieron crear una plataforma que combinara claridad metodológica con calidez humana. Cada
            programa, taller y guía surge de investigación rigurosa, escucha activa y co-creación con nuestra comunidad.
          </p>
        </div>
        <img
          src="https://picsum.photos/seed/vision-equipo/720/520"
          alt="Equipo de Sol Mirado en conversación"
          loading="lazy"
        />
      </section>

      <section className={styles.missionSection}>
        <article>
          <h2>Misión</h2>
          <p>
            Acompañar a personas y organizaciones a transitar cambios de vida con estabilidad mental, ampliando su
            capacidad de elección, reflexión y cuidado colectivo.
          </p>
        </article>
        <article>
          <h2>Visión</h2>
          <p>
            Construir una red latinoamericana de aprendizaje en bienestar integral donde cada decisión esté guiada por
            la escucha interna y el sentido comunitario.
          </p>
        </article>
        <article>
          <h2>Enfoque</h2>
          <p>
            Integramos psicología positiva, trauma informado, mindfulness, creatividad y prácticas ancestrales
            latinoamericanas en experiencias accesibles y transformadoras.
          </p>
        </article>
      </section>

      <section className={styles.timelineSection}>
        <h2>Nuestro camino</h2>
        <div className={styles.timeline}>
          <div>
            <h3>2018 · Primer círculo de calma</h3>
            <p>
              Iniciamos reuniones semanales para personas en transición profesional. Desde entonces, el acompañamiento
              grupal es un pilar de Sol Mirado.
            </p>
          </div>
          <div>
            <h3>2020 · Comunidad digital</h3>
            <p>
              Lanzamos nuestra plataforma con guías descargables y sesiones virtuales, extendiendo nuestro alcance a
              toda Latinoamérica.
            </p>
          </div>
          <div>
            <h3>2023 · Programas para equipos</h3>
            <p>
              Empezamos a colaborar con organizaciones que buscan culturas laborales sostenibles y sensibles al cambio.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <h2>Equipo facilitador</h2>
        <div className={styles.teamGrid}>
          <article>
            <img src="https://picsum.photos/seed/equipo1/320/320" alt="Retrato de Alma Rivera" loading="lazy" />
            <h3>Alma Rivera</h3>
            <p>Dirección de contenidos · Psicóloga clínica y facilitadora de mindfulness.</p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/equipo2/320/320" alt="Retrato de Julián Flores" loading="lazy" />
            <h3>Julián Flores</h3>
            <p>Coordinación de programas · Especialista en resiliencia organizacional.</p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/equipo3/320/320" alt="Retrato de Carmen Ortiz" loading="lazy" />
            <h3>Carmen Ortiz</h3>
            <p>Investigación y comunidad · Terapeuta corporal y acompañante de duelos.</p>
          </article>
        </div>
      </section>

      <section className={styles.valuesSection}>
        <h2>Nuestros valores</h2>
        <ul>
          <li>
            <strong>Humanidad:</strong> Honramos las historias singulares y celebramos el aprendizaje colectivo.
          </li>
          <li>
            <strong>Rigor:</strong> Tomamos decisiones basadas en evidencia científica y resultados medibles.
          </li>
          <li>
            <strong>Creatividad:</strong> Mantenemos viva la curiosidad y la experimentación consciente.
          </li>
          <li>
            <strong>Equidad:</strong> Diseñamos experiencias accesibles, inclusivas y culturalmente sensibles.
          </li>
        </ul>
      </section>
    </>
  );
}

export default AboutPage;