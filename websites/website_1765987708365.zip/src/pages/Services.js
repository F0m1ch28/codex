import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

function ProgramsPage() {
  return (
    <>
      <Helmet>
        <title>Programas Sol Mirado | Diseña estabilidad durante el cambio</title>
        <meta
          name="description"
          content="Explora los programas de Sol Mirado para navegar transiciones personales y profesionales con acompañamiento humano y metodologías efectivas."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroText}>
          <h1>Programas que abrazan tu proceso de cambio</h1>
          <p>
            Diseñamos experiencias inmersivas que integran reflexión, práctica y acompañamiento para sostener la mente,
            el cuerpo y las relaciones durante momentos de transformación.
          </p>
        </div>
        <img src="https://picsum.photos/seed/programas-sol/780/520" alt="Espacio de trabajo colaborativo y cálido" loading="lazy" />
      </section>

      <section className={styles.programsGrid}>
        <article>
          <h2>Cartografía del Cambio</h2>
          <p>
            Un recorrido de ocho semanas para mapear tu transición vital, identificar necesidades centrales y construir
            un plan flexible con apoyo entre pares.
          </p>
          <ul>
            <li>Sesiones grupales sincrónicas con facilitación experta.</li>
            <li>Diario descargable y prácticas somáticas guiadas.</li>
            <li>Rituales de cierre para integrar aprendizajes.</li>
          </ul>
        </article>
        <article>
          <h2>Respira el Presente</h2>
          <p>
            Programa intensivo de regulación emocional que combina respiración diafragmática, meditación compasiva y
            micro descansos activos para el día a día.
          </p>
          <ul>
            <li>Biblioteca de audios accesible 24/7.</li>
            <li>Plan de seguimiento con recordatorios personalizados.</li>
            <li>Sesiones de co-regulación en vivo cada semana.</li>
          </ul>
        </article>
        <article>
          <h2>Equipos Resilientes</h2>
          <p>
            Acompañamiento para líderes y equipos que buscan cultivar culturas laborales conectadas, empáticas y
            adaptables a nuevas dinámicas.
          </p>
          <ul>
            <li>Diagnóstico integral de bienestar organizacional.</li>
            <li>Talleres vivenciales sobre comunicación y límites sanos.</li>
            <li>Coaching grupal para sostener acuerdos a largo plazo.</li>
          </ul>
        </article>
      </section>

      <section className={styles.impactSection}>
        <h2>Impacto que medimos</h2>
        <div className={styles.impactGrid}>
          <article>
            <span>87%</span>
            <p>de participantes reportan mayor claridad emocional al finalizar el programa.</p>
          </article>
          <article>
            <span>92%</span>
            <p>indican haber incorporado al menos dos nuevas prácticas de autocuidado sostenibles.</p>
          </article>
          <article>
            <span>76%</span>
            <p>observa mejoras en la comunicación de sus equipos después de tres meses.</p>
          </article>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div>
          <h2>Conversemos sobre el programa que mejor se adapta a tu momento</h2>
          <p>
            Cuéntanos tus necesidades y construiremos un plan que honre los recursos y ritmos disponibles.
          </p>
        </div>
        <a className={styles.ctaButton} href="/contact">
          Solicitar acompañamiento
        </a>
      </section>
    </>
  );
}

export default ProgramsPage;