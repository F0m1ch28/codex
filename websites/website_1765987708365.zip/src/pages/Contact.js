import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialValues = {
  name: '',
  email: '',
  subject: '',
  message: '',
};

function ContactPage() {
  const [formValues, setFormValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) newErrors.name = 'Por favor ingresa tu nombre.';
    if (!formValues.email.trim()) {
      newErrors.email = 'Necesitamos tu correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formValues.email)) {
      newErrors.email = 'Introduce un correo válido.';
    }
    if (!formValues.subject.trim()) newErrors.subject = 'Añade un asunto breve.';
    if (!formValues.message.trim()) newErrors.message = 'Comparte tu mensaje.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
    if (status) setStatus('');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setStatus('Gracias por escribirnos. Responderemos a hola@solmiradoventola.site muy pronto.');
      setFormValues(initialValues);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contacto | Hablemos sobre tu proceso con Sol Mirado</title>
        <meta
          name="description"
          content="Completa el formulario de contacto de Sol Mirado para recibir acompañamiento y recursos adaptados a tus necesidades."
        />
      </Helmet>

      <section className={styles.contactIntro}>
        <h1>Compártenos tu proceso</h1>
        <p>
          Nos encantará leer tu historia, responder tus preguntas y sugerirte recursos hechos a tu medida. Completa el
          formulario y nos pondremos en contacto contigo.
        </p>
      </section>

      <section className={styles.contactContent}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formGroup}>
            <label htmlFor="name">Nombre</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Tu nombre completo"
              value={formValues.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
              required
            />
            {errors.name && (
              <span id="name-error" className={styles.error}>
                {errors.name}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="email">Correo electrónico</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="hola@solmiradoventola.site"
              value={formValues.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
              required
            />
            {errors.email && (
              <span id="email-error" className={styles.error}>
                {errors.email}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="subject">Asunto</label>
            <input
              id="subject"
              name="subject"
              type="text"
              placeholder="¿Sobre qué te gustaría conversar?"
              value={formValues.subject}
              onChange={handleChange}
              aria-invalid={Boolean(errors.subject)}
              aria-describedby={errors.subject ? 'subject-error' : undefined}
              required
            />
            {errors.subject && (
              <span id="subject-error" className={styles.error}>
                {errors.subject}
              </span>
            )}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="message">Mensaje</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              placeholder="Comparte lo que estás viviendo, tus expectativas o preguntas."
              value={formValues.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
              required
            />
            {errors.message && (
              <span id="message-error" className={styles.error}>
                {errors.message}
              </span>
            )}
          </div>
          <button type="submit" className={styles.submitButton}>
            Enviar
          </button>
          {status && (
            <p role="status" className={styles.successMessage}>
              {status}
            </p>
          )}
        </form>

        <aside className={styles.sidePanel}>
          <h2>¿Qué sucede después de escribirnos?</h2>
          <ul>
            <li>Respondemos en un máximo de 48 horas hábiles.</li>
            <li>Si es necesario, proponemos una breve llamada de exploración.</li>
            <li>Recomendamos los recursos que mejor se ajusten a tu momento.</li>
          </ul>
          <div className={styles.card}>
            <h3>Confidencialidad</h3>
            <p>
              Valoramos tu confianza. Toda la información que compartas se mantiene protegida y alineada con nuestra
              política de privacidad.
            </p>
          </div>
        </aside>
      </section>
    </>
  );
}

export default ContactPage;