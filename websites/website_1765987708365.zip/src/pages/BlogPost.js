import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import blogPosts from '../data/blogPosts';
import styles from './BlogPost.module.css';

function BlogPostPage() {
  const { slug } = useParams();
  const post = blogPosts.find((entry) => entry.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <h1>Artículo no encontrado</h1>
        <p>El contenido que buscas puede haber cambiado de lugar.</p>
        <Link to="/blog" className={styles.backLink}>Volver al blog</Link>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Blog Sol Mirado</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>

      <article className={styles.postWrapper}>
        <header className={styles.header}>
          <p className={styles.meta}>{post.date} · {post.author}</p>
          <h1>{post.title}</h1>
          <img src={post.image} alt={post.title} loading="lazy" />
        </header>
        <div className={styles.content}>
          {post.content.map((paragraph) => (
            <p key={paragraph.substring(0, 24)}>{paragraph}</p>
          ))}
          <blockquote>
            “Repetir que todo estará bien no es suficiente. La calma se construye con estrategias concretas y con la
            confianza de que no atravesamos el cambio en soledad.”
          </blockquote>
        </div>
        <footer className={styles.footer}>
          <Link to="/blog" className={styles.backLink}>← Volver al blog</Link>
        </footer>
      </article>
    </>
  );
}

export default BlogPostPage;