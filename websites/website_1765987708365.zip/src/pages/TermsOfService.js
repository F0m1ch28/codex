import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsOfService.module.css';

function TermsPage() {
  return (
    <>
      <Helmet>
        <title>Términos de Servicio | Sol Mirado</title>
        <meta
          name="description"
          content="Consulta los términos de servicio que rigen el uso de los recursos digitales ofrecidos por Sol Mirado."
        />
      </Helmet>
      <section className={styles.legalSection}>
        <h1>Términos de Servicio</h1>
        <p>Fecha de actualización: 10 de mayo de 2024</p>

        <h2>1. Aceptación de los términos</h2>
        <p>
          Al acceder y utilizar el sitio <strong>solmiradoventola.site</strong>, aceptas cumplir con estos términos y
          todas las leyes aplicables. Si no estás de acuerdo, te invitamos a detener el uso de la plataforma.
        </p>

        <h2>2. Uso responsable</h2>
        <p>
          Los contenidos ofrecidos tienen fines educativos y de acompañamiento. No sustituyen procesos terapéuticos,
          médicos ni diagnósticos profesionales.
        </p>

        <h2>3. Propiedad intelectual</h2>
        <p>
          Todos los materiales, incluidos textos, diseños, audios e ilustraciones, pertenecen a Sol Mirado o a sus
          colaboradores y están protegidos por leyes de derecho de autor. Se prohíbe la reproducción sin autorización
          escrita.
        </p>

        <h2>4. Comunidad y participación</h2>
        <p>
          Las interacciones en foros o sesiones grupales deben mantener un tono respetuoso. Sol Mirado puede moderar,
          editar o remover contenidos que vulneren la seguridad emocional de otras personas.
        </p>

        <h2>5. Limitación de responsabilidad</h2>
        <p>
          Nos esforzamos por proporcionar información actualizada, pero no garantizamos resultados específicos. El uso
          de los recursos se realiza bajo tu propio criterio y responsabilidad.
        </p>

        <h2>6. Modificaciones</h2>
        <p>
          Podemos actualizar estos términos para reflejar ajustes legales o mejoras de la plataforma. Las actualizaciones
          se publicarán con fecha vigente en esta página.
        </p>

        <h2>7. Contacto legal</h2>
        <p>
          Para consultas relacionadas con estos términos, escribe a <a href="mailto:hola@solmiradoventola.site">hola@solmiradoventola.site</a>.
        </p>
      </section>
    </>
  );
}

export default TermsPage;