import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

function LegalPage() {
  return (
    <>
      <Helmet>
        <title>Aviso Legal | Sol Mirado</title>
        <meta
          name="description"
          content="Consulta el aviso legal de Sol Mirado, incluyendo información corporativa, responsabilidades y uso de cookies conforme a GDPR."
        />
      </Helmet>
      <section className={styles.legal}>
        <h1>Aviso Legal</h1>
        <p>Fecha de actualización: 10 de mayo de 2024</p>

        <h2>Información general</h2>
        <p>
          El sitio <strong>solmiradoventola.site</strong> es operado por Sol Mirado, plataforma mexicana dedicada al
          desarrollo de recursos de bienestar mental. La presente información cumple con obligaciones de transparencia
          y comunicación en línea.
        </p>

        <h2>Condiciones de uso</h2>
        <p>
          Las personas usuarias aceptan usar el sitio de manera diligente, respetuosa y conforme a la ley. Sol Mirado no
          se responsabiliza por un uso indebido ni por interpretaciones alejadas de la intención educativa de los
          contenidos.
        </p>

        <h2>Propiedad intelectual</h2>
        <p>
          Los derechos de autor de los contenidos, diseño, fotografías y material descargable pertenecen a Sol Mirado y
          a sus autores/as colaboradores. Queda prohibida la reproducción total o parcial sin autorización.
        </p>

        <h2>Cookies y tecnologías similares</h2>
        <p>
          Este sitio emplea cookies esenciales y analíticas. Puedes gestionar tus preferencias en la{' '}
          <a href="/cookie-policy">Política de Cookies</a>. Al navegar, aceptas el uso descrito en dicha política.
        </p>

        <h2>Enlaces externos</h2>
        <p>
          Sol Mirado puede incluir enlaces a otros sitios. No nos responsabilizamos por sus contenidos ni políticas. Te
          recomendamos revisar los avisos legales de cada plataforma visitada.
        </p>

        <h2>Jurisdicción</h2>
        <p>
          Las relaciones se rigen por la normativa mexicana, sin perjuicio de los derechos reconocidos a visitantes de
          otras jurisdicciones.
        </p>

        <h2>Contacto</h2>
        <p>
          Para aclaraciones sobre este aviso, escríbenos a <a href="mailto:hola@solmiradoventola.site">hola@solmiradoventola.site</a>.
        </p>
      </section>
    </>
  );
}

export default LegalPage;