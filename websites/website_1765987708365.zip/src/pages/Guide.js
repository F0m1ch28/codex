import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Guide.module.css';

const guides = [
  {
    title: 'Bitácora de decisiones conscientes',
    description: 'Un proceso de cuatro pasos para clarificar opciones, evaluar recursos y actuar con calma.',
    focus: 'Planificación personal',
    duration: '25 minutos',
  },
  {
    title: 'Protocolos de autocuidado para días críticos',
    description: 'Checklist matutino y nocturno para sostener tu energía cuando todo parece moverse rápido.',
    focus: 'Cuidado diario',
    duration: '15 minutos',
  },
  {
    title: 'Cómo comunicar límites con empatía',
    description: 'Marco de conversación para expresar necesidades sin comprometer vínculos importantes.',
    focus: 'Comunicación',
    duration: '20 minutos',
  },
  {
    title: 'Rituales para cerrar ciclos',
    description: 'Ceremonia breve de escritura y respiración para agradecer lo vivido y abrir nuevos espacios.',
    focus: 'Transiciones emocionales',
    duration: '30 minutos',
  },
  {
    title: 'Micro pausas conscientes en el trabajo remoto',
    description: 'Serie de pausas de tres minutos que regulan tu sistema nervioso durante la jornada laboral.',
    focus: 'Bienestar laboral',
    duration: '18 minutos',
  },
];

function GuidePage() {
  return (
    <>
      <Helmet>
        <title>Guías Sol Mirado | Estrategias para navegar el cambio</title>
        <meta
          name="description"
          content="Descubre guías diseñadas por Sol Mirado para gestionar el estrés, comunicar límites y planificar cambios con serenidad."
        />
      </Helmet>

      <section className={styles.intro}>
        <h1>Guías para acompañar cada etapa de tu cambio</h1>
        <p>
          Articulamos ejercicios, preguntas de reflexión y prácticas somáticas para ayudarte a comprender lo que sientes
          y actuar con claridad. Cada guía es un mapa flexible: tómala como un punto de partida y adáptala a tu ritmo.
        </p>
      </section>

      <section className={styles.guideGrid}>
        {guides.map((guide) => (
          <article key={guide.title} className={styles.guideCard}>
            <header>
              <h2>{guide.title}</h2>
              <p className={styles.focus}>{guide.focus}</p>
            </header>
            <p>{guide.description}</p>
            <footer>
              <span className={styles.duration}>{guide.duration}</span>
              <button type="button" className={styles.downloadButton}>
                Guardar para leer
              </button>
            </footer>
          </article>
        ))}
      </section>
    </>
  );
}

export default GuidePage;