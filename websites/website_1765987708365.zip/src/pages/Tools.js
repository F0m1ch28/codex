import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Plantilla de diario de calma',
    description: 'Formato semanal para registrar emociones, sensaciones corporales y micro victorias.',
    link: '#',
  },
  {
    title: 'Audio: respiración 4-7-8',
    description: 'Guía sonora de cinco minutos para re-equilibrar tu sistema nervioso.',
    link: '#',
  },
  {
    title: 'Mapa de red de apoyo',
    description: 'Visualiza personas, recursos y prácticas que pueden sostenerte durante el cambio.',
    link: '#',
  },
  {
    title: 'Guía de apps de meditación curada',
    description: 'Selección de aplicaciones verificadas con prácticas en español y enfoque inclusivo.',
    link: '#',
  },
  {
    title: 'Checklist de inicio de semana',
    description: 'Revisión consciente para priorizar tareas, descanso y momentos de disfrute.',
    link: '#',
  },
  {
    title: 'Playlist restaurativa',
    description: 'Colección colaborativa de sonidos calmantes para acompañar tus pausas.',
    link: '#',
  },
];

function ToolsPage() {
  return (
    <>
      <Helmet>
        <title>Herramientas Sol Mirado | Recursos para tu bienestar</title>
        <meta
          name="description"
          content="Accede a herramientas prácticas de Sol Mirado: diarios, audios de respiración, mapas de apoyo y guías de aplicaciones para tu estabilidad mental."
        />
      </Helmet>
      <section className={styles.intro}>
        <h1>Herramientas para reforzar tu estabilidad mental</h1>
        <p>
          Descarga recursos prácticos, ligeros y adaptables a diferentes momentos del día. Cada herramienta está
          pensada para integrarse de forma amable en tu agenda y recordarte que el cuidado puede ser sencillo.
        </p>
      </section>

      <section className={styles.toolsGrid}>
        {tools.map((tool) => (
          <article key={tool.title} className={styles.toolCard}>
            <h2>{tool.title}</h2>
            <p>{tool.description}</p>
            <a href={tool.link} className={styles.toolLink}>
              Acceder al recurso
            </a>
          </article>
        ))}
      </section>
    </>
  );
}

export default ToolsPage;