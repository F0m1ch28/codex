import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import blogPosts from '../data/blogPosts';
import styles from './Home.module.css';

function HomePage() {
  const featuredPosts = blogPosts.slice(0, 3);

  return (
    <>
      <Helmet>
        <title>Sol Mirado | Navegar cambios con calma y claridad</title>
        <meta
          name="description"
          content="Sol Mirado ofrece guías, programas y herramientas para navegar cambios con estabilidad mental y bienestar integral."
        />
        <meta
          name="keywords"
          content="bienestar mental, estabilidad emocional, cambios de vida, autoconocimiento, recursos de resiliencia"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Navega la transformación con serenidad y propósito</h1>
          <p>
            Sol Mirado es un faro para quienes atraviesan etapas de cambio. Te acompañamos con recursos basados en
            evidencia, prácticas contemplativas y un enfoque humano que abraza cada emoción.
          </p>
          <div className={styles.heroActions}>
            <Link to="/guide" className={styles.primaryButton}>Explorar guías prácticas</Link>
            <Link to="/programs" className={styles.secondaryButton}>Conocer programas</Link>
          </div>
          <ul className={styles.heroHighlights}>
            <li>Metodologías basadas en psicología positiva</li>
            <li>Rutinas sostenibles para el equilibrio diario</li>
            <li>Acompañamiento respetuoso de tu ritmo</li>
          </ul>
        </div>
        <div className={styles.heroImageWrapper}>
          <img src="https://picsum.photos/id/1011/720/820" alt="Horizonte tranquilo con luz suave" loading="lazy" />
        </div>
      </section>

      <section className={styles.conceptSection}>
        <div className={styles.sectionIntro}>
          <h2>¿Qué es navegar el cambio?</h2>
          <p>
            Cambiar no siempre es elegir. A veces sucede y nos sorprende. Navegar el cambio significa reconocer el
            paisaje emocional, honrar las preguntas y cultivar recursos internos que sostengan tu bienestar mientras
            nuevas posibilidades se abren paso.
          </p>
        </div>
        <div className={styles.conceptGrid}>
          <article>
            <h3>Observación consciente</h3>
            <p>
              Aprender a escuchar señales corporales y mentales permite tomar decisiones más alineadas con tus valores.
            </p>
          </article>
          <article>
            <h3>Reencuadre compasivo</h3>
            <p>
              Transformamos narrativas rígidas en historias de resiliencia, promoviendo una relación amable contigo
              misma/o.
            </p>
          </article>
          <article>
            <h3>Planificación flexible</h3>
            <p>
              Diseñamos estrategias adaptables que te ayudan a sostener estabilidad sin perder apertura al aprendizaje.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.pillarsSection}>
        <h2>Los pilares de la estabilidad mental</h2>
        <div className={styles.pillarCards}>
          <article>
            <span aria-hidden="true" className={styles.pillarIcon}>🧭</span>
            <h3>Claridad</h3>
            <p>Mapeamos emociones, patrones y necesidades para construir una visión nítida del momento vital.</p>
          </article>
          <article>
            <span aria-hidden="true" className={styles.pillarIcon}>🪴</span>
            <h3>Regulación</h3>
            <p>Integramos prácticas somáticas, respiración y micro hábitos que favorecen el equilibrio diario.</p>
          </article>
          <article>
            <span aria-hidden="true" className={styles.pillarIcon}>🤝</span>
            <h3>Red de apoyo</h3>
            <p>Fomentamos relaciones conscientes, espacios de escucha y acuerdos que sostienen tu proceso.</p>
          </article>
          <article>
            <span aria-hidden="true" className={styles.pillarIcon}>✨</span>
            <h3>Sentido</h3>
            <p>Reconectamos con propósitos pequeños y grandes que dan dirección a cada paso de tu transformación.</p>
          </article>
        </div>
      </section>

      <section className={styles.resourcesSection}>
        <div className={styles.sectionHeader}>
          <h2>¿Qué encontrarás en Sol Mirado?</h2>
          <p>Recursos diseñados para acompañarte desde la reflexión hasta la acción consciente.</p>
        </div>
        <div className={styles.resourceGrid}>
          <Link to="/guide" className={styles.resourceCard}>
            <h3>Guías paso a paso</h3>
            <p>Itinerarios claros para comprender tus emociones y preparar respuestas prácticas.</p>
          </Link>
          <Link to="/programs" className={styles.resourceCard}>
            <h3>Programas inmersivos</h3>
            <p>Experiencias estructuradas que integran psicología, mindfulness y creatividad.</p>
          </Link>
          <Link to="/tools" className={styles.resourceCard}>
            <h3>Herramientas descargables</h3>
            <p>Plantillas, audios y checklists para sostener hábitos saludables durante el cambio.</p>
          </Link>
          <Link to="/blog" className={styles.resourceCard}>
            <h3>Blog con perspectiva</h3>
            <p>Historias, entrevistas y análisis para inspirar decisiones conscientes cada semana.</p>
          </Link>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <h2>Relatos de transformación</h2>
        <div className={styles.testimonialGrid}>
          <article className={styles.testimonialCard}>
            <img src="https://picsum.photos/seed/sonrisa1/96" alt="Retrato de Ana, participante" loading="lazy" />
            <blockquote>
              “Aprendí a escuchar mi cuerpo y a darme permiso para avanzar a mi propio ritmo. Hoy siento estabilidad sin
              perder la emoción por lo nuevo.”
            </blockquote>
            <p className={styles.testimonialName}>Ana R. · Ciudad de México</p>
          </article>
          <article className={styles.testimonialCard}>
            <img src="https://picsum.photos/seed/sonrisa2/96" alt="Retrato de Marcelo, participante" loading="lazy" />
            <blockquote>
              “Encontré herramientas simples para los días desafiantes y una comunidad que entiende cómo se siente
              reinventarse.”
            </blockquote>
            <p className={styles.testimonialName}>Marcelo G. · Guadalajara</p>
          </article>
          <article className={styles.testimonialCard}>
            <img src="https://picsum.photos/seed/sonrisa3/96" alt="Retrato de Elisa, participante" loading="lazy" />
            <blockquote>
              “Los ejercicios de respiración y las sesiones de reflexión cambiaron mi forma de acompañar a mi equipo en
              tiempos de cambio.”
            </blockquote>
            <p className={styles.testimonialName}>Elisa M. · Monterrey</p>
          </article>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className={styles.sectionHeader}>
          <h2>Desde el blog</h2>
          <p>Historias y estrategias recientes para cultivar estabilidad mental en escenarios cambiantes.</p>
        </div>
        <div className={styles.blogGrid}>
          {featuredPosts.map((post) => (
            <article key={post.slug} className={styles.blogCard}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className={styles.blogContent}>
                <p className={styles.blogDate}>{post.date}</p>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={"/blog/${post.slug}"} className={styles.blogLink}>
                  Leer artículo
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Regálate una pausa consciente para redescubrir tu equilibrio</h2>
          <p>
            Suscríbete a nuestros recursos quincenales y recibe prácticas breves, playlists restaurativas y
            recordatorios amables para tus días de cambio.
          </p>
          <Link to="/contact" className={styles.primaryButton}>
            Empezar con Sol Mirado
          </Link>
        </div>
      </section>

      <section className={styles.aboutSection}>
        <div className={styles.aboutContent}>
          <h2>Conoce la historia de Sol Mirado</h2>
          <p>
            Nacimos en la costa de Oaxaca como un espacio de escucha para quienes buscaban sostener su salud mental
            mientras enfrentaban decisiones importantes. Hoy acompañamos a personas y equipos en toda Latinoamérica.
          </p>
          <Link to="/about" className={styles.secondaryButton}>Descubrir nuestra visión</Link>
        </div>
        <div className={styles.aboutImage}>
          <img src="https://picsum.photos/id/1025/720/640" alt="Grupo de personas compartiendo al atardecer" loading="lazy" />
        </div>
      </section>
    </>
  );
}

export default HomePage;