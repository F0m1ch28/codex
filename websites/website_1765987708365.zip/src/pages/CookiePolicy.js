import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

function CookiePolicyPage() {
  return (
    <>
      <Helmet>
        <title>Política de Cookies | Sol Mirado</title>
        <meta
          name="description"
          content="Revisa cómo Sol Mirado utiliza cookies esenciales y analíticas, y cómo puedes gestionarlas según GDPR."
        />
      </Helmet>

      <section className={styles.policy}>
        <h1>Política de Cookies</h1>
        <p>Fecha de actualización: 10 de mayo de 2024</p>

        <h2>¿Qué son las cookies?</h2>
        <p>
          Las cookies son pequeños archivos que se almacenan en tu dispositivo al navegar por internet. Nos ayudan a
          garantizar el correcto funcionamiento del sitio y a comprender cómo interactúas con nuestros contenidos.
        </p>

        <h2>Tipos de cookies que utilizamos</h2>
        <ul>
          <li>
            <strong>Esenciales:</strong> Garantizan la navegación, seguridad y acceso a funciones básicas. Son
            necesarias para ofrecer el servicio solicitado.
          </li>
          <li>
            <strong>Analíticas:</strong> Recopilan información anónima sobre el uso de la web para mejorar la
            experiencia. Puedes aceptarlas o rechazarlas.
          </li>
        </ul>

        <h2>Gestión de cookies</h2>
        <p>
          Puedes administrar tus preferencias a través del banner de cookies al ingresar al sitio o ajustando la
          configuración de tu navegador. Rechazar cookies analíticas no afectará el acceso a los contenidos.
        </p>

        <h2>Conservación</h2>
        <p>
          Las cookies esenciales se mantienen durante la sesión. Las analíticas se conservan por un período máximo de 12
          meses, tras lo cual se eliminan automáticamente.
        </p>

        <h2>Consentimiento</h2>
        <p>
          Al hacer clic en &ldquo;Aceptar&rdquo; en el banner, otorgas tu consentimiento informado. Puedes modificarlo en
          cualquier momento eliminando las cookies desde tu navegador.
        </p>

        <h2>Más información</h2>
        <p>
          Si tienes dudas, contáctanos en <a href="mailto:hola@solmiradoventola.site">hola@solmiradoventola.site</a>.
        </p>
      </section>
    </>
  );
}

export default CookiePolicyPage;