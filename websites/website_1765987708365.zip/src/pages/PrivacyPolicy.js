import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPolicy.module.css';

function PrivacyPage() {
  return (
    <>
      <Helmet>
        <title>Política de Privacidad | Sol Mirado</title>
        <meta
          name="description"
          content="Conoce cómo Sol Mirado protege y gestiona tus datos personales de acuerdo con la normativa vigente."
        />
      </Helmet>

      <section className={styles.privacySection}>
        <h1>Política de Privacidad</h1>
        <p>Fecha de actualización: 10 de mayo de 2024</p>

        <h2>1. Responsable del tratamiento</h2>
        <p>
          La plataforma Sol Mirado gestiona los datos personales de conformidad con la legislación mexicana y los
          criterios del Reglamento General de Protección de Datos (RGPD) para visitantes internacionales.
        </p>

        <h2>2. Datos recopilados</h2>
        <p>
          Recabamos información identificativa (nombre, correo electrónico) cuando completas formularios o te
          suscribes a nuestros recursos. También usamos cookies esenciales para garantizar el funcionamiento del sitio.
        </p>

        <h2>3. Finalidades</h2>
        <ul>
          <li>Responder a solicitudes enviadas mediante formularios.</li>
          <li>Enviar recursos y novedades si otorgas tu consentimiento expreso.</li>
          <li>Analizar métricas agregadas que ayuden a mejorar la experiencia.</li>
        </ul>

        <h2>4. Conservación</h2>
        <p>
          Conservamos los datos el tiempo estrictamente necesario para la finalidad prevista o hasta que solicites su
          eliminación.
        </p>

        <h2>5. Derechos de las personas usuarias</h2>
        <p>
          Puedes ejercer tus derechos de acceso, rectificación, cancelación, oposición, portabilidad y limitación del
          tratamiento escribiendo a <a href="mailto:hola@solmiradoventola.site">hola@solmiradoventola.site</a>.
        </p>

        <h2>6. Transferencias</h2>
        <p>
          No compartimos tus datos con terceros, salvo obligación legal o servicios tecnológicos necesarios para
          operar la plataforma, los cuales cumplen estándares de protección adecuados.
        </p>

        <h2>7. Seguridad</h2>
        <p>
          Implementamos medidas administrativas y técnicas para proteger la información frente a accesos no autorizados,
          alteración o divulgación.
        </p>

        <h2>8. Actualizaciones</h2>
        <p>
          Esta política puede actualizarse para reflejar cambios normativos o tecnológicos. La versión vigente estará
          siempre disponible en esta página.
        </p>
      </section>
    </>
  );
}

export default PrivacyPage;