import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import blogPosts from '../data/blogPosts';
import styles from './Blog.module.css';

function BlogPage() {
  return (
    <>
      <Helmet>
        <title>Blog Sol Mirado | Perspectivas sobre cambio y bienestar</title>
        <meta
          name="description"
          content="Lee artículos, entrevistas y técnicas para sostener tu salud mental durante procesos de cambio personal y profesional."
        />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <h1>Ideas que te acompañan mientras el mundo se mueve</h1>
          <p>
            Cada artículo invita a detenerte, respirar y generar entendimiento sobre lo que estás viviendo. Encontrarás
            técnicas, historias reales y reflexiones para transformar el cambio en crecimiento.
          </p>
        </div>
        <img src="https://picsum.photos/seed/blog-sol/780/520" alt="Cuaderno abierto listo para escribir reflexiones" loading="lazy" />
      </section>

      <section className={styles.postGrid}>
        {blogPosts.map((post) => (
          <article key={post.slug} className={styles.postCard}>
            <img src={post.image} alt={post.title} loading="lazy" />
            <div className={styles.postContent}>
              <p className={styles.postMeta}>{post.date} · {post.author}</p>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <Link to={"/blog/${post.slug}"} className={styles.readMore}>
                Leer más
              </Link>
            </div>
          </article>
        ))}
      </section>
    </>
  );
}

export default BlogPage;