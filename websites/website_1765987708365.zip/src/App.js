import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import styles from './App.module.css';

const HomePage = lazy(() => import('./pages/Home'));
const AboutPage = lazy(() => import('./pages/About'));
const GuidePage = lazy(() => import('./pages/Guide'));
const ProgramsPage = lazy(() => import('./pages/Services'));
const ToolsPage = lazy(() => import('./pages/Tools'));
const BlogPage = lazy(() => import('./pages/Blog'));
const BlogPostPage = lazy(() => import('./pages/BlogPost'));
const ContactPage = lazy(() => import('./pages/Contact'));
const LegalPage = lazy(() => import('./pages/Legal'));
const TermsPage = lazy(() => import('./pages/TermsOfService'));
const PrivacyPage = lazy(() => import('./pages/PrivacyPolicy'));
const CookiePolicyPage = lazy(() => import('./pages/CookiePolicy'));

function App() {
  return (
    <div className={styles.appWrapper}>
      <a href="#main-content" className={styles.skipLink}>Saltar al contenido principal</a>
      <Header />
      <main id="main-content" className={styles.mainContent}>
        <Suspense
          fallback={
            <div className={styles.loader} role="status" aria-live="polite">
              <span className={styles.loaderDot} />
              <span className={styles.loaderDot} />
              <span className={styles.loaderDot} />
              <p>Cargando contenido...</p>
            </div>
          }
        >
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/guide" element={<GuidePage />} />
            <Route path="/programs" element={<ProgramsPage />} />
            <Route path="/tools" element={<ToolsPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:slug" element={<BlogPostPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/legal" element={<LegalPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;