(function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.navigation');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-button');
    const yearElements = document.querySelectorAll('[id^="year-"]');

    yearElements.forEach(function (element) {
        element.textContent = new Date().getFullYear();
    });

    if (navToggle && navigation) {
        navToggle.addEventListener('click', function () {
            navigation.classList.toggle('active');
        });

        navigation.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navigation.classList.remove('active');
            });
        });
    }

    function getCookieConsent() {
        try {
            return window.localStorage.getItem('gc_cookie_consent');
        } catch (error) {
            return null;
        }
    }

    function setCookieConsent(value) {
        try {
            window.localStorage.setItem('gc_cookie_consent', value);
        } catch (error) {
            // storage not available
        }
    }

    if (cookieBanner && !getCookieConsent()) {
        cookieBanner.classList.add('active');
    }

    cookieButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const choice = button.dataset.cookie;
            setCookieConsent(choice);
            cookieBanner.classList.remove('active');
        });
    });
})();