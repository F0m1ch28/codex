document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navToggle.classList.toggle("is-active");
      nav.classList.toggle("is-open");
    });
    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("is-active");
        nav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const sections = document.querySelectorAll(".fade-section");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    sections.forEach((section) => observer.observe(section));
  } else {
    sections.forEach((section) => section.classList.add("is-visible"));
  }

  const yearTargets = document.querySelectorAll(".current-year");
  const year = String(new Date().getFullYear());
  yearTargets.forEach((el) => (el.textContent = year));

  const toast = document.querySelector(".toast-notice");
  const forms = document.querySelectorAll("form[data-form]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (toast) {
        toast.textContent = "Message received. Redirecting to confirmation.";
        toast.classList.add("is-visible");
      }
      setTimeout(() => {
        if (toast) {
          toast.classList.remove("is-visible");
        }
        window.location.href = form.getAttribute("action") || "thank-you.html";
      }, 1600);
    });
  });

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector(".accept");
    const declineButton = cookieBanner.querySelector(".decline");
    const storageKey = "meshware-cookie-choice";
    const storedChoice = localStorage.getItem(storageKey);
    if (storedChoice) {
      cookieBanner.classList.add("hidden");
    }
    const handleChoice = (choice) => {
      localStorage.setItem(storageKey, choice);
      cookieBanner.classList.add("hidden");
    };
    acceptButton?.addEventListener("click", () => handleChoice("accepted"));
    declineButton?.addEventListener("click", () => handleChoice("declined"));
  }
});