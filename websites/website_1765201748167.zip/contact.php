<?php
  header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contacto | Solar Flotante Systems España</title>
  <meta name="description" content="Contacta con Solar Flotante Systems España para solicitar consultoría en sistemas solares flotantes, almacenamiento y monitorización.">
  <meta name="keywords" content="contacto energía solar flotante, consultoría fotovoltaica, solicitud de información, Torre Sevilla">
  <link rel="canonical" href="https://www.solarflotantesistemas.es/contact.php">
  <meta property="og:title" content="Contacto Solar Flotante Systems España">
  <meta property="og:description" content="Solicita una consultoría personalizada para proyectos solares flotantes y almacenamiento sostenible.">
  <meta property="og:image" content="https://picsum.photos/1000/400?random=contact">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.solarflotantesistemas.es/contact.php">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ccircle cx='32' cy='32' r='30' fill='%230277BD'/%3E%3Cpath d='M12 34h40L32 12z' fill='%23FFFFFF'/%3E%3Cpath d='M20 36h24l-12 16z' fill='%232E7D32'/%3E%3C/svg%3E">
  <style>
    :root{--color-primary:#2E7D32;--color-secondary:#0277BD;--color-light:#FFFFFF;--color-dark:#263238;--color-muted:#455A64;--font-sans:'Segoe UI','Helvetica Neue',Arial,sans-serif;--spacing-2xs:4px;--spacing-xs:8px;--spacing-sm:12px;--spacing-md:16px;--spacing-lg:24px;--spacing-xl:32px;--spacing-2xl:48px;--spacing-3xl:64px;--radius-sm:8px;--radius-md:16px;--shadow-sm:0 6px 18px rgba(69,90,100,.08);--shadow-md:0 18px 48px rgba(2,119,189,.16);--transition:300ms ease-in-out;}
    *,*::before,*::after{box-sizing:border-box;}
    body{margin:0;font-family:var(--font-sans);color:var(--color-dark);background:#F4F8FB;line-height:1.6;font-size:clamp(1rem,2.2vw,1.05rem);}
    header{position:sticky;top:0;z-index:900;background:rgba(255,255,255,.96);backdrop-filter:blur(14px);box-shadow:0 1px 18px rgba(69,90,100,.15);}
    .topbar{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-xs) calc(var(--spacing-lg));font-size:.95rem;color:var(--color-muted);}
    .topbar a{color:var(--color-secondary);font-weight:600;}
    nav{display:flex;align-items:center;justify-content:space-between;padding:var(--spacing-md) calc(var(--spacing-lg));gap:var(--spacing-md);}
    nav ul{list-style:none;display:flex;flex-wrap:wrap;gap:var(--spacing-md);padding:0;margin:0;}
    nav a{font-weight:600;padding:var(--spacing-xs) var(--spacing-sm);border-radius:var(--radius-sm);transition:background var(--transition),color var(--transition),transform var(--transition);}
    nav a:hover,nav a:focus-visible{background:rgba(2,119,189,.12);color:var(--color-secondary);transform:translateY(-2px);}
    nav a[aria-current="page"]{background:var(--color-secondary);color:var(--color-light);}
    .logo{display:flex;align-items:center;gap:var(--spacing-sm);font-weight:700;letter-spacing:.4px;color:var(--color-secondary);}
    .logo span{text-transform:uppercase;font-size:clamp(1.1rem,3vw,1.35rem);}
    main{padding:var(--spacing-3xl) clamp(1.5rem,6vw,4rem);min-height:100vh;}
    h1{font-size:clamp(2.2rem,5vw,3.1rem);color:var(--color-secondary);margin-top:0;}
    .contact-grid{display:grid;gap:var(--spacing-2xl);grid-template-columns:repeat(auto-fit,minmax(320px,1fr));}
    form{background:var(--color-light);padding:var(--spacing-2xl);border-radius:var(--radius-md);box-shadow:var(--shadow-md);display:grid;gap:var(--spacing-lg);}
    label{font-weight:600;color:var(--color-muted);}
    input,textarea,select{width:100%;padding:var(--spacing-sm) var(--spacing-md);border-radius:var(--radius-sm);border:1px solid rgba(69,90,100,.2);font-size:1rem;transition:border var(--transition),box-shadow var(--transition);}
    input:focus,textarea:focus,select:focus{border-color:var(--color-secondary);box-shadow:0 0 0 4px rgba(2,119,189,.12);}
    textarea{min-height:140px;resize:vertical;}
    .btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--spacing-xs);padding:var(--spacing-sm) var(--spacing-xl);border-radius:var(--radius-md);border:none;background:var(--color-secondary);color:var(--color-light);font-weight:700;cursor:pointer;transition:transform var(--transition),box-shadow var(--transition);}
    .btn:hover{transform:translateY(-3px);box-shadow:var(--shadow-sm);}
    .info-card{background:var(--color-light);padding:var(--spacing-2xl);border-radius:var(--radius-md);box-shadow:var(--shadow-sm);display:grid;gap:var(--spacing-md);}
    .map{border-radius:var(--radius-md);overflow:hidden;box-shadow:var(--shadow-sm);}
    footer{padding:var(--spacing-3xl) clamp(1.5rem,6vw,4rem) var(--spacing-xl);color:var(--color-light);background:#1B2831;display:grid;gap:var(--spacing-2xl);}
    .footer-grid{display:grid;gap:var(--spacing-xl);grid-template-columns:repeat(auto-fit,minmax(220px,1fr));}
    .footer-nav,.footer-nav ul{list-style:none;margin:0;padding:0;display:grid;gap:var(--spacing-xs);}
    .footer-nav a{color:#D6E3EA;}
    .footer-bottom{display:flex;flex-wrap:wrap;gap:var(--spacing-sm);justify-content:space-between;align-items:center;font-size:.95rem;color:#9FB3C0;}
    figure{margin:0;}
    img{max-width:100%;display:block;border-radius:var(--radius-sm);}
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <span>Torre Sevilla, Calle Gonzalo Jiménez de Quesada 2, Planta 17, 41092 Sevilla, España</span>
      <a href="tel:+34955824613">+34 955 824 613</a>
    </div>
    <nav aria-label="Navegación principal">
      <a class="logo" href="index.html">
        <svg width="32" height="32" viewBox="0 0 64 64" aria-hidden="true">
          <circle cx="32" cy="32" r="30" fill="#0277BD"/>
          <path d="M12 34h40L32 12z" fill="#FFFFFF"/>
          <path d="M20 36h24l-12 16z" fill="#2E7D32"/>
        </svg>
        <span>Solar Flotante Systems España</span>
      </a>
      <ul>
        <li><a href="index.html">Inicio</a></li>
        <li><a href="solutions.html">Soluciones</a></li>
        <li><a href="projects.html">Proyectos</a></li>
        <li><a href="sustainability.html">Sostenibilidad</a></li>
        <li><a href="about.html">Sobre Nosotros</a></li>
        <li><a href="contact.php" aria-current="page">Contacto</a></li>
        <li><a href="privacy.html">Privacidad</a></li>
        <li><a href="cookies.html">Cookies</a></li>
        <li><a href="terms.html">Términos</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <h1>Conversemos sobre tu proyecto solar flotante</h1>
    <p>Rellena el formulario y nuestro equipo de ingeniería te contactará para entender tu infraestructura hídrica y definir el alcance de la consultoría.</p>
    <div class="contact-grid">
      <form action="thanks.php" method="post" enctype="application/x-www-form-urlencoded">
        <div>
          <label for="nombre">Nombre completo</label>
          <input id="nombre" name="nombre" type="text" required autocomplete="name">
        </div>
        <div>
          <label for="email">Correo electrónico</label>
          <input id="email" name="email" type="email" required autocomplete="email">
        </div>
        <div>
          <label for="telefono">Teléfono</label>
          <input id="telefono" name="telefono" type="tel" autocomplete="tel">
        </div>
        <div>
          <label for="empresa">Entidad / Empresa</label>
          <input id="empresa" name="empresa" type="text" autocomplete="organization">
        </div>
        <div>
          <label for="interes">Interés principal</label>
          <select id="interes" name="interes" required>
            <option value="" disabled selected>Selecciona una opción</option>
            <option value="embalse-publico">Embalse público</option>
            <option value="regadio">Regadío y comunidades de regantes</option>
            <option value="industrial">Instalación industrial</option>
            <option value="almacenamiento">Almacenamiento energético</option>
            <option value="monitorizacion">Monitorización y control</option>
          </select>
        </div>
        <div>
          <label for="mensaje">Describe tu necesidad</label>
          <textarea id="mensaje" name="mensaje" required></textarea>
        </div>
        <div>
          <label>
            <input type="checkbox" name="consentimiento" value="sí" required>
            He leído y acepto la <a href="privacy.html" target="_blank" rel="noopener">política de privacidad</a>.
          </label>
        </div>
        <button class="btn" type="submit">Enviar solicitud</button>
      </form>

      <aside class="info-card" aria-label="Información de contacto">
        <h2>Contacto directo</h2>
        <p><strong>Dirección:</strong> Torre Sevilla, Calle Gonzalo Jiménez de Quesada 2, Planta 17, 41092 Sevilla.</p>
        <p><strong>Teléfono:</strong> <a href="tel:+34955824613">+34 955 824 613</a></p>
        <p><strong>Correo:</strong> <a href="mailto:info@solarflotantesistemas.es">info@solarflotantesistemas.es</a></p>
        <figure>
          <img src="https://picsum.photos/1000/400?random=contact" alt="Oficina de Solar Flotante Systems España en Sevilla" loading="lazy" width="1000" height="400">
        </figure>
        <div class="map" aria-label="Mapa de la ubicación">
          <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=-6.013%2C37.390%2C-6.008%2C37.394&amp;layer=mapnik&amp;marker=37.3925%2C-6.0105" width="100%" height="320" style="border:0;" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </aside>
    </div>
  </main>

  <footer>
    <div class="footer-grid">
      <div>
        <a class="logo" href="index.html">
          <svg width="32" height="32" viewBox="0 0 64 64" aria-hidden="true">
            <circle cx="32" cy="32" r="30" fill="#0277BD"/>
            <path d="M12 34h40L32 12z" fill="#FFFFFF"/>
            <path d="M20 36h24l-12 16z" fill="#2E7D32"/>
          </svg>
          <span>Solar Flotante Systems España</span>
        </a>
        <p style="margin-top:var(--spacing-md);color:#D6E3EA;">Consultoría y operación de sistemas solares flotantes en España.</p>
      </div>
      <nav class="footer-nav" aria-label="Navegación en el pie">
        <h3 style="color:#FFFFFF;margin:0 0 var(--spacing-sm);">Compañía</h3>
        <ul>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="projects.html">Proyectos</a></li>
          <li><a href="sustainability.html">Sostenibilidad</a></li>
          <li><a href="about.html">Equipo</a></li>
        </ul>
      </nav>
      <nav class="footer-nav" aria-label="Información legal">
        <h3 style="color:#FFFFFF;margin:0 0 var(--spacing-sm);">Legal</h3>
        <ul>
          <li><a href="privacy.html">Privacidad</a></li>
          <li><a href="cookies.html">Cookies</a></li>
          <li><a href="terms.html">Términos</a></li>
        </ul>
      </nav>
      <div>
        <h3 style="color:#FFFFFF;margin:0 0 var(--spacing-sm);">Contacto</h3>
        <p style="color:#D6E3EA;">Torre Sevilla, Calle Gonzalo Jiménez de Quesada 2, Planta 17<br>41092 Sevilla, España</p>
        <p style="color:#D6E3EA;">Teléfono: <a style="color:#FFFFFF;" href="tel:+34955824613">+34 955 824 613</a><br>Correo: <a style="color:#FFFFFF;" href="mailto:info@solarflotantesistemas.es">info@solarflotantesistemas.es</a></p>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2024 Solar Flotante Systems España.</span>
      <span>Actualizado el 10 de mayo de 2024</span>
    </div>
  </footer>
</body>
</html>