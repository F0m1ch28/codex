<?php
  header('Content-Type: text/html; charset=UTF-8');
  $nombre = htmlspecialchars($_POST['nombre'] ?? 'Contacto');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Gracias por tu solicitud | Solar Flotante Systems España</title>
  <meta name="robots" content="noindex, nofollow">
  <link rel="canonical" href="https://www.solarflotantesistemas.es/thanks.php">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ccircle cx='32' cy='32' r='30' fill='%230277BD'/%3E%3Cpath d='M12 34h40L32 12z' fill='%23FFFFFF'/%3E%3Cpath d='M20 36h24l-12 16z' fill='%232E7D32'/%3E%3C/svg%3E">
  <style>
    :root{--color-primary:#2E7D32;--color-secondary:#0277BD;--color-light:#FFFFFF;--color-dark:#263238;--color-muted:#455A64;--font-sans:'Segoe UI','Helvetica Neue',Arial,sans-serif;--spacing-sm:12px;--spacing-md:16px;--spacing-lg:24px;--spacing-xl:32px;--spacing-2xl:48px;--radius-md:16px;--shadow-md:0 18px 48px rgba(2,119,189,.16);}
    *,*::before,*::after{box-sizing:border-box;}
    body{margin:0;font-family:var(--font-sans);color:var(--color-dark);background:#F4F8FB;line-height:1.6;font-size:clamp(1rem,2.2vw,1.05rem);}
    header{position:sticky;top:0;z-index:900;background:rgba(255,255,255,.96);backdrop-filter:blur(14px);box-shadow:0 1px 18px rgba(69,90,100,.15);}
    .topbar{display:flex;justify-content:space-between;align-items:center;padding:var(--spacing-sm) clamp(1.5rem,6vw,4rem);font-size:.95rem;color:var(--color-muted);}
    .topbar a{color:var(--color-secondary);font-weight:600;}
    nav{display:flex;align-items:center;justify-content:space-between;padding:var(--spacing-md) clamp(1.5rem,6vw,4rem);gap:var(--spacing-md);}
    nav ul{list-style:none;display:flex;flex-wrap:wrap;gap:var(--spacing-md);padding:0;margin:0;}
    nav a{font-weight:600;padding:var(--spacing-sm) var(--spacing-md);border-radius:12px;}
    nav a:hover{background:rgba(2,119,189,.12);color:var(--color-secondary);}
    .logo{display:flex;align-items:center;gap:var(--spacing-sm);font-weight:700;color:var(--color-secondary);}
    .logo span{text-transform:uppercase;font-size:clamp(1.1rem,3vw,1.35rem);}
    main{padding:var(--spacing-2xl) clamp(1.5rem,6vw,4rem);min-height:100vh;display:grid;place-items:center;}
    .thankyou{background:var(--color-light);padding:var(--spacing-2xl);border-radius:var(--radius-md);box-shadow:var(--shadow-md);max-width:560px;text-align:center;display:grid;gap:var(--spacing-md);}
    h1{font-size:clamp(2rem,5vw,2.8rem);color:var(--color-secondary);}
    .btn{display:inline-flex;align-items:center;justify-content:center;padding:var(--spacing-sm) var(--spacing-xl);border-radius:12px;background:var(--color-secondary);color:var(--color-light);font-weight:700;}
    footer{padding:var(--spacing-2xl) clamp(1.5rem,6vw,4rem);color:#D6E3EA;background:#1B2831;text-align:center;}
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <span>Torre Sevilla, Calle Gonzalo Jiménez de Quesada 2, Planta 17, 41092 Sevilla, España</span>
      <a href="tel:+34955824613">+34 955 824 613</a>
    </div>
    <nav aria-label="Navegación principal">
      <a class="logo" href="index.html">
        <svg width="32" height="32" viewBox="0 0 64 64" aria-hidden="true">
          <circle cx="32" cy="32" r="30" fill="#0277BD"/>
          <path d="M12 34h40L32 12z" fill="#FFFFFF"/>
          <path d="M20 36h24l-12 16z" fill="#2E7D32"/>
        </svg>
        <span>Solar Flotante Systems España</span>
      </a>
      <ul>
        <li><a href="index.html">Inicio</a></li>
        <li><a href="solutions.html">Soluciones</a></li>
        <li><a href="projects.html">Proyectos</a></li>
        <li><a href="sustainability.html">Sostenibilidad</a></li>
        <li><a href="about.html">Sobre Nosotros</a></li>
        <li><a href="contact.php">Contacto</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="thankyou">
      <h1>Gracias, <?php echo $nombre; ?>.</h1>
      <p>Hemos recibido tu solicitud. El equipo de Solar Flotante Systems España revisará la información y se pondrá en contacto contigo en un plazo máximo de dos días laborables.</p>
      <p>Si necesitas atención inmediata puedes llamarnos al <a href="tel:+34955824613">+34 955 824 613</a>.</p>
      <a class="btn" href="index.html">Volver al inicio</a>
    </section>
  </main>

  <footer>
    © 2024 Solar Flotante Systems España.
  </footer>
</body>
</html>