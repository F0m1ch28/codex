(function () {
    const nav = document.querySelector(".primary-nav");
    const toggle = document.querySelector("[data-menu-toggle]");
    if (nav && toggle) {
        toggle.addEventListener("click", () => {
            const isOpen = nav.classList.toggle("open");
            toggle.setAttribute("aria-label", isOpen ? "Закрыть меню" : "Открыть меню");
        });
        nav.addEventListener("click", (event) => {
            if (event.target.matches(".nav-link")) {
                nav.classList.remove("open");
                toggle.setAttribute("aria-label", "Открыть меню");
            }
        });
    }

    const banner = document.querySelector(".cookie-banner");
    if (!banner) {
        return;
    }
    const storageKey = "nv-cookie-consent";
    const storedValue = localStorage.getItem(storageKey);

    const hideBanner = () => {
        banner.classList.remove("show");
        setTimeout(() => {
            banner.style.display = "none";
        }, 320);
    };

    const showBanner = () => {
        banner.style.display = "flex";
        requestAnimationFrame(() => {
            banner.classList.add("show");
        });
    };

    if (!storedValue) {
        showBanner();
    }

    banner.addEventListener("click", (event) => {
        const action = event.target.getAttribute("data-cookie-action");
        if (!action) return;
        if (action === "accept") {
            localStorage.setItem(storageKey, "accepted");
        }
        if (action === "decline") {
            localStorage.setItem(storageKey, "declined");
        }
        hideBanner();
    });
})();