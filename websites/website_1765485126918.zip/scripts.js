document.addEventListener("DOMContentLoaded", () => {
    const header = document.querySelector(".site-header");
    const navToggle = document.querySelector(".nav-toggle");
    const body = document.body;

    if (navToggle) {
        navToggle.addEventListener("click", () => {
            header.classList.toggle("nav-open");
        });
    }

    document.addEventListener("click", (event) => {
        if (!header.contains(event.target) && header.classList.contains("nav-open")) {
            header.classList.remove("nav-open");
        }
    });

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");
    const consentKey = "maple-cookie-preference";

    const showBanner = () => {
        cookieBanner?.classList.add("show");
    };

    const hideBanner = () => {
        cookieBanner?.classList.remove("show");
    };

    try {
        const stored = localStorage.getItem(consentKey);
        if (!stored && cookieBanner) {
            setTimeout(showBanner, 600);
        }
        acceptBtn?.addEventListener("click", () => {
            localStorage.setItem(consentKey, "accepted");
            hideBanner();
        });
        declineBtn?.addEventListener("click", () => {
            localStorage.setItem(consentKey, "declined");
            hideBanner();
        });
    } catch (error) {
        // If storage is unavailable, still show banner for transparency
        showBanner();
    }
});