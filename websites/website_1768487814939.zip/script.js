document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            document.body.classList.toggle('no-scroll', isOpen);
        });
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                    document.body.classList.remove('no-scroll');
                }
            });
        });
    }
    const banner = document.querySelector('.cookie-banner');
    if (banner) {
        const consent = localStorage.getItem('genusCookieConsent');
        if (!consent) {
            banner.classList.remove('is-hidden');
        }
        const handleConsent = (value) => {
            localStorage.setItem('genusCookieConsent', value);
            banner.classList.add('is-hidden');
        };
        const acceptButton = banner.querySelector('[data-cookie="accept"]');
        const declineButton = banner.querySelector('[data-cookie="decline"]');
        if (acceptButton) {
            acceptButton.addEventListener('click', () => handleConsent('accepted'));
        }
        if (declineButton) {
            declineButton.addEventListener('click', () => handleConsent('declined'));
        }
    }
});