const translations = {
  es: {
    meta: {
      title: "PlanConfiable · Educación financiera responsable",
      description:
        "PlanConfiable ofrece aprendizaje claro sobre economía personal argentina con datos confiables para tu presupuesto."
    },
    nav: {
      home: "Inicio",
      about: "Nosotros",
      services: "Servicios",
      curso: "Curso",
      datos: "Datos",
      blog: "Blog",
      contact: "Contacto"
    },
    ctas: {
      primary: "Explorar la plataforma",
      secondary: "Ver el curso",
      contact: "Hablar con el equipo",
      join: "Unirse a la comunidad",
      startTrial: "Recibir clase de prueba"
    },
    hero: {
      eyebrow: "Educación financiera para Argentina",
      title: "Finanzas inteligentes para tu futuro",
      subtitle:
        "Información confiable y herramientas prácticas para planificar tu presupuesto con tranquilidad y responsabilidad.",
      primaryCta: "Explorar recursos",
      secondaryCta: "Datos recientes"
    },
    stats: {
      title: "Indicadores clave",
      sub: "Datos actualizados semanalmente con fuentes públicas argentinas.",
      arsUsd: "ARS → USD",
      inflation: "Inflación mensual",
      salary: "Ingreso promedio",
      savings: "Índice de ahorro"
    },
    inflation: {
      title: "Inflación argentina comentada",
      text:
        "Analizamos la evolución mensual y la proyección trimestral para ayudarte a dimensionar el impacto en gastos básicos. No ofrecemos asesoramiento de inversión; brindamos contexto educativo."
    },
    courseTeaser: {
      eyebrow: "Curso destacado",
      title: "Gestión de finanzas personales con contexto argentino",
      text:
        "Aprende a construir presupuestos resilientes, interpretar datos macroeconómicos locales y tomar decisiones responsables.",
      bullets: [
        "Módulos breves con ejemplos reales",
        "Tableros interactivos con datos oficiales",
        "Acceso a sesiones grupales de análisis"
      ],
      button: "Conocer el programa"
    },
    services: {
      title: "Recursos educativos",
      description:
        "Contenido modular, reportes descargables y simuladores que acompañan tu desarrollo financiero responsable.",
      items: [
        {
          title: "Biblioteca guiada",
          text: "Mapas de estudio organizados por objetivos personales y etapas de vida."
        },
        {
          title: "Laboratorio de escenarios",
          text: "Compara variantes de tipo de cambio e inflación sin prometer resultados."
        },
        {
          title: "Acompañamiento docente",
          text: "Sesiones virtuales en vivo para resolver dudas y orientar decisiones informadas."
        }
      ]
    },
    process: {
      title: "Cómo trabajamos",
      steps: [
        {
          title: "Diagnóstico educativo",
          text: "Identificamos tus necesidades financieras con un formulario introductorio."
        },
        {
          title: "Ruta personalizada",
          text: "Proponemos contenidos y tableros según tu horizonte y contexto."
        },
        {
          title: "Práctica aplicada",
          text: "Ejercicios sobre presupuestos reales sin ofrecer servicios financieros."
        },
        {
          title: "Revisión acompañada",
          text: "Seguimiento mensual con docentes certificados."
        }
      ]
    },
    testimonials: {
      title: "Historias de aprendizaje",
      quotes: [
        {
          name: "Mariana S.",
          role: "Analista en CABA",
          text:
            "PlanConfiable me ayudó a ordenar mis gastos con datos claros. La plataforma evita promesas y se enfoca en educación verdadera."
        },
        {
          name: "Julián R.",
          role: "Docente en Córdoba",
          text:
            "Los tableros sobre inflación y salarios me permitieron explicar temas complejos a mis estudiantes."
        },
        {
          name: "Paula T.",
          role: "Emprendedora en Rosario",
          text:
            "Valoro que siempre aclaran que no brindan servicios financieros. El enfoque educativo me dio confianza."
        }
      ]
    },
    team: {
      title: "Equipo docente",
      intro:
        "Especialistas en economía doméstica, estadística y pedagogía con experiencia en Argentina.",
      members: [
        {
          name: "Lucía Gómez",
          role: "Directora académica",
          bio: "Economista UBA con 10 años en programas de alfabetización financiera.",
          img: "https://picsum.photos/400/400?random=31"
        },
        {
          name: "Santiago Álvarez",
          role: "Especialista en datos",
          bio: "Analista de datos públicos, desarrolla tableros interactivos accesibles.",
          img: "https://picsum.photos/400/400?random=32"
        },
        {
          name: "Carolina Méndez",
          role: "Pedagoga",
          bio: "Diseña experiencias de aprendizaje inclusivas y relevantes.",
          img: "https://picsum.photos/400/400?random=33"
        }
      ]
    },
    projects: {
      title: "Casos y proyectos educativos",
      filters: ["Todo", "Presupuesto", "Inflación", "Moneda"],
      items: [
        {
          title: "Mapa de gastos esenciales",
          category: "Presupuesto",
          text: "Modelo de asignación de ingresos considerando paritarias docentes.",
          img: "https://picsum.photos/1200/800?random=41"
        },
        {
          title: "Comparador de inflación regional",
          category: "Inflación",
          text: "Visualización interactiva con variaciones IPC GBA vs. interior.",
          img: "https://picsum.photos/1200/800?random=42"
        },
        {
          title: "Seguimiento de dólar ahorro",
          category: "Moneda",
          text: "Escenarios responsables para comprender brechas cambiarias.",
          img: "https://picsum.photos/1200/800?random=43"
        }
      ]
    },
    faq: {
      title: "Preguntas frecuentes",
      items: [
        {
          q: "¿PlanConfiable brinda asesoramiento financiero?",
          a: "No. Ofrecemos contenidos educativos y herramientas informativas. No recomendamos inversiones ni gestionamos fondos."
        },
        {
          q: "¿De dónde provienen los datos?",
          a: "Utilizamos fuentes públicas como INDEC, BCRA y ministerios nacionales. Documentamos la metodología en la sección Datos."
        },
        {
          q: "¿El acceso tiene costo?",
          a: "Hay recursos gratuitos y planes pagos para instituciones educativas. El formulario de prueba ofrece una clase inicial sin cargo."
        }
      ]
    },
    blog: {
      title: "Últimos análisis",
      posts: [
        {
          title: "Cómo leer el índice de precios al consumidor",
          text: "Guía paso a paso para interpretar el IPC argentino sin caer en conclusiones apresuradas.",
          date: "12 Mar 2024"
        },
        {
          title: "Planificación de gastos en contextos volátiles",
          text: "Estrategias educativas para sostener hábitos de ahorro responsables.",
          date: "04 Mar 2024"
        },
        {
          title: "Construyendo un presupuesto familiar con datos reales",
          text: "Metodología de PlanConfiable aplicada a un hogar de cuatro personas.",
          date: "25 Feb 2024"
        }
      ]
    },
    cta: {
      title: "Decisiones responsables, planes claros",
      text: "Únete a PlanConfiable y fortalece tu criterio financiero con acompañamiento docente.",
      button: "Comenzar hoy"
    },
    form: {
      title: "Obtener clase de prueba",
      subtitle: "Completa tus datos para acceder a la experiencia introductoria.",
      name: "Nombre",
      email: "Correo electrónico",
      phone: "Teléfono (opcional)",
      interest: "Interés principal",
      interests: [
        "Organizar presupuesto personal",
        "Capacitación para equipos",
        "Docentes y escuelas",
        "Otro"
      ],
      consent: "Acepto la Política de Privacidad y los Términos.",
      submit: "Enviar solicitud",
      success: "Solicitud enviada con éxito.",
      rateLimit:
        "Espera un minuto antes de enviar nuevamente para proteger la plataforma.",
      honeypot: "Déjalo vacío"
    },
    contact: {
      title: "Contacto",
      intro:
        "Escríbenos para coordinar talleres educativos, alianzas institucionales o prensa.",
      office: "Oficina",
      phone: "Teléfono",
      email: "Correo",
      formTitle: "Envía un mensaje",
      submit: "Enviar mensaje",
      thanks:
        "Gracias por tu consulta. Respondemos dentro de 48 horas hábiles.",
      placeholders: {
        name: "Tu nombre",
        email: "Tu correo",
        message: "Cuéntanos en qué podemos ayudarte"
      }
    },
    course: {
      title: "Curso: Gestión de finanzas personales",
      audience:
        "Diseñado para personas, docentes y equipos que buscan un entendimiento integral del presupuesto argentino.",
      modulesTitle: "Módulos principales",
      modules: [
        "M1: Diagnóstico de ingresos y gastos en pesos.",
        "M2: Herramientas para ajustar presupuestos con inflación.",
        "M3: Estrategias de ahorro en contextos de brecha cambiaria.",
        "M4: Planificación de objetivos y gastos proyectados."
      ],
      format: {
        title: "Formato de aprendizaje",
        items: [
          "Clases sincrónicas y asincrónicas con materiales descargables.",
          "Simuladores en vivo con datos actualizados semanalmente.",
          "Foros moderados por docentes para resolver dudas."
        ]
      },
      disclaimer:
        "Este curso no ofrece asesoramiento financiero ni recomendaciones de inversión."
    },
    datos: {
      title: "Metodología y fuentes",
      intro:
        "PlanConfiable compila datos de organismos oficiales y medios verificados para construir visualizaciones educativas.",
      sourcesTitle: "Principales fuentes",
      sources: [
        "Instituto Nacional de Estadística y Censos (INDEC).",
        "Banco Central de la República Argentina (BCRA).",
        "Ministerio de Trabajo, Empleo y Seguridad Social.",
        "Ministerio de Educación de la Nación."
      ],
      limitations:
        "Los datos pueden estar sujetos a revisiones. Las visualizaciones tienen fines pedagógicos y no sustituyen el análisis profesional individual.",
      update: "Última actualización metodológica: marzo 2024."
    },
    blogPage: {
      title: "Blog y recursos",
      intro:
        "Explora artículos didácticos, guías descargables y entrevistas sobre economía cotidiana.",
      categories: ["Todos", "Presupuesto", "Inflación", "Educación"],
      more: "Leer más"
    },
    thankyou: {
      title: "¡Gracias por escribirnos!",
      text:
        "Recibimos tu solicitud y te contactaremos por correo con los próximos pasos. No brindamos servicios financieros; recibirás exclusivamente materiales educativos."
    },
    gracias: {
      title: "¡Gracias por contactarnos!",
      text:
        "Tu solicitud fue registrada. Revisa tu correo para conocer los recursos de nuestra clase de prueba."
    },
    legal: {
      privacyTitle: "Política de Privacidad",
      cookiesTitle: "Política de Cookies",
      termsTitle: "Términos de uso",
      disclaimer:
        "PlanConfiable es una plataforma educativa. No realizamos operaciones financieras ni damos asesoramiento de inversión."
    },
    footer: {
      mission:
        "PlanConfiable comparte educación financiera responsable con datos verificables.",
      disclaimer:
        "Aviso: PlanConfiable no presta servicios financieros ni promete rendimientos.",
      rights: "© 2024 PlanConfiable. Todos los derechos reservados."
    }
  },
  en: {
    meta: {
      title: "PlanConfiable · Reliable financial learning",
      description:
        "PlanConfiable delivers clear education about Argentine personal finance backed by trustworthy data."
    },
    nav: {
      home: "Home",
      about: "About",
      services: "Services",
      curso: "Course",
      datos: "Data",
      blog: "Blog",
      contact: "Contact"
    },
    ctas: {
      primary: "Explore the platform",
      secondary: "View the course",
      contact: "Talk to our team",
      join: "Join the community",
      startTrial: "Get trial lesson"
    },
    hero: {
      eyebrow: "Financial education for Argentina",
      title: "Smart finances for your future",
      subtitle:
        "Reliable insights and practical tools to plan your budget with confidence and responsibility.",
      primaryCta: "Explore resources",
      secondaryCta: "Latest data"
    },
    stats: {
      title: "Key indicators",
      sub: "Weekly updates sourced from Argentine public data.",
      arsUsd: "ARS → USD",
      inflation: "Monthly inflation",
      salary: "Average salary",
      savings: "Savings index"
    },
    inflation: {
      title: "Argentina inflation at a glance",
      text:
        "We unpack monthly evolution and quarterly projections to help you understand basic expense impact. We do not provide investment advice; this is educational context."
    },
    courseTeaser: {
      eyebrow: "Featured course",
      title: "Personal finance management in Argentina",
      text:
        "Learn to build resilient budgets, read local macro data, and make responsible decisions.",
      bullets: [
        "Micro lessons with real case studies",
        "Interactive dashboards based on official data",
        "Access to group analysis sessions"
      ],
      button: "Discover the syllabus"
    },
    services: {
      title: "Educational resources",
      description:
        "Modular content, downloadable reports, and simulators that support responsible financial learning.",
      items: [
        {
          title: "Guided library",
          text: "Study maps organized by personal goals and life stages."
        },
        {
          title: "Scenario lab",
          text: "Compare exchange and inflation paths without promising outcomes."
        },
        {
          title: "Instructor support",
          text: "Live virtual sessions to clarify questions and inform decisions."
        }
      ]
    },
    process: {
      title: "Our process",
      steps: [
        {
          title: "Learning diagnosis",
          text: "We identify your needs through an onboarding assessment."
        },
        {
          title: "Personalized roadmap",
          text: "Content and dashboards tailored to your horizon and context."
        },
        {
          title: "Applied practice",
          text: "Exercises on real budgets—no financial services involved."
        },
        {
          title: "Guided review",
          text: "Monthly check-ins with certified instructors."
        }
      ]
    },
    testimonials: {
      title: "Learning stories",
      quotes: [
        {
          name: "Mariana S.",
          role: "Analyst in Buenos Aires",
          text:
            "PlanConfiable helped me structure my expenses with clear data. They stay true to education without promises."
        },
        {
          name: "Julián R.",
          role: "Teacher in Córdoba",
          text:
            "The inflation and salary dashboards made complex topics easier for my classes."
        },
        {
          name: "Paula T.",
          role: "Entrepreneur in Rosario",
          text:
            "I appreciate the constant disclaimer—no financial services, just practical learning."
        }
      ]
    },
    team: {
      title: "Academic team",
      intro:
        "Experts in household economics, statistics, and pedagogy focused on Argentina.",
      members: [
        {
          name: "Lucía Gómez",
          role: "Academic director",
          bio: "Economist with 10 years in financial literacy programs.",
          img: "https://picsum.photos/400/400?random=34"
        },
        {
          name: "Santiago Álvarez",
          role: "Data specialist",
          bio: "Public data analyst building accessible dashboards.",
          img: "https://picsum.photos/400/400?random=35"
        },
        {
          name: "Carolina Méndez",
          role: "Learning designer",
          bio: "Creates inclusive and relevant learning experiences.",
          img: "https://picsum.photos/400/400?random=36"
        }
      ]
    },
    projects: {
      title: "Educational cases and projects",
      filters: ["All", "Budget", "Inflation", "Currency"],
      items: [
        {
          title: "Essential expense map",
          category: "Budget",
          text: "Income allocation model considering wage negotiations.",
          img: "https://picsum.photos/1200/800?random=44"
        },
        {
          title: "Regional inflation tracker",
          category: "Inflation",
          text: "Interactive view comparing CPI between regions.",
          img: "https://picsum.photos/1200/800?random=45"
        },
        {
          title: "Savings in pesos and dollars",
          category: "Currency",
          text: "Responsible scenarios to understand FX gaps.",
          img: "https://picsum.photos/1200/800?random=46"
        }
      ]
    },
    faq: {
      title: "Frequently asked questions",
      items: [
        {
          q: "Does PlanConfiable offer financial services?",
          a: "No. We provide educational content and information tools. We do not recommend investments or manage funds."
        },
        {
          q: "Where do the data sets come from?",
          a: "We rely on official sources such as INDEC, BCRA, and national ministries. Methodology is available on the Data page."
        },
        {
          q: "Is there a cost to join?",
          a: "We offer free resources and paid plans for institutions. The trial lesson request grants an initial class at no cost."
        }
      ]
    },
    blog: {
      title: "Latest insights",
      posts: [
        {
          title: "Reading Argentina's consumer price index",
          text: "Step-by-step guide to interpret CPI figures without hasty conclusions.",
          date: "March 12, 2024"
        },
        {
          title: "Planning expenses in volatile contexts",
          text: "Educational strategies to maintain responsible saving habits.",
          date: "March 4, 2024"
        },
        {
          title: "Building a family budget with real data",
          text: "PlanConfiable methodology applied to a four-person household.",
          date: "Feb 25, 2024"
        }
      ]
    },
    cta: {
      title: "Responsible decisions, clear plans",
      text: "Join PlanConfiable to strengthen your financial criteria with guided support.",
      button: "Start today"
    },
    form: {
      title: "Get a free trial lesson",
      subtitle:
        "Share your details to access the introductory experience with our instructors.",
      name: "Name",
      email: "Email",
      phone: "Phone (optional)",
      interest: "Primary interest",
      interests: [
        "Organizing personal budget",
        "Training for teams",
        "Teachers and schools",
        "Other"
      ],
      consent: "I accept the Privacy Policy and Terms.",
      submit: "Send request",
      success: "Request submitted successfully.",
      rateLimit:
        "Please wait a minute before sending another request to protect the platform.",
      honeypot: "Leave this empty"
    },
    contact: {
      title: "Contact",
      intro:
        "Write to coordinate educational workshops, institutional partnerships, or press inquiries.",
      office: "Office",
      phone: "Phone",
      email: "Email",
      formTitle: "Send a message",
      submit: "Send message",
      thanks:
        "Thanks for reaching out. We reply within 48 business hours.",
      placeholders: {
        name: "Your name",
        email: "Your email",
        message: "How can we support you?"
      }
    },
    course: {
      title: "Course: Personal finance management",
      audience:
        "Designed for individuals, teachers, and teams seeking a comprehensive understanding of the Argentine budget landscape.",
      modulesTitle: "Core modules",
      modules: [
        "M1: Income and expense diagnosis in pesos.",
        "M2: Tools to adjust budgets for inflation.",
        "M3: Savings strategies amid multiple exchange rates.",
        "M4: Planning goals and projected expenses."
      ],
      format: {
        title: "Learning format",
        items: [
          "Live and on-demand classes with downloadable materials.",
          "Real-time simulators fed with weekly updated data.",
          "Moderated forums to resolve questions."
        ]
      },
      disclaimer:
        "This course does not provide financial advisory or investment recommendations."
    },
    datos: {
      title: "Methodology & sources",
      intro:
        "PlanConfiable compiles data from official agencies and vetted media to build educational visualizations.",
      sourcesTitle: "Primary sources",
      sources: [
        "National Institute of Statistics and Census (INDEC).",
        "Central Bank of the Argentine Republic (BCRA).",
        "Ministry of Labor, Employment and Social Security.",
        "National Ministry of Education."
      ],
      limitations:
        "Data may be revised. Visualizations are for educational purposes and do not replace individual professional analysis.",
      update: "Last methodology update: March 2024."
    },
    blogPage: {
      title: "Blog & resources",
      intro:
        "Discover learning articles, downloadable guides, and interviews on everyday economics.",
      categories: ["All", "Budget", "Inflation", "Education"],
      more: "Read more"
    },
    thankyou: {
      title: "Thank you for reaching out!",
      text:
        "We received your request and will contact you with the next steps. We do not provide financial services; expect educational materials only."
    },
    gracias: {
      title: "Thanks for contacting us!",
      text:
        "Your submission is registered. Check your email for access to the trial lesson resources."
    },
    legal: {
      privacyTitle: "Privacy Policy",
      cookiesTitle: "Cookies Policy",
      termsTitle: "Terms of use",
      disclaimer:
        "PlanConfiable is an educational platform. We do not run financial operations or deliver investment advice."
    },
    footer: {
      mission:
        "PlanConfiable delivers responsible financial literacy backed by verifiable data.",
      disclaimer:
        "Notice: PlanConfiable does not provide financial services or promise returns.",
      rights: "© 2024 PlanConfiable. All rights reserved."
    }
  }
};

export default translations;