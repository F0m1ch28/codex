import React, { useContext } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const Gracias = () => {
  const { t } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>PlanConfiable · Gracias</title>
      </Helmet>
      <section className="section-space">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center">
          <div className="card-white">
            <h1 className="text-3xl font-bold text-slate-900 mb-4">
              {t.gracias.title}
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              {t.gracias.text}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Gracias;