import React, { useContext } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const CookiesPolicy = () => {
  const { t, lang } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Política de cookies"
            : "PlanConfiable · Cookies policy"}
        </title>
      </Helmet>

      <section className="section-space">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="card-white space-y-4">
            <h1 className="text-3xl font-bold text-slate-900">
              {t.legal.cookiesTitle}
            </h1>
            <p className="text-sm text-slate-600">
              {lang === "es"
                ? "Usamos cookies esenciales para asegurar el funcionamiento de la plataforma y cookies analíticas para entender cómo se utilizan los recursos educativos."
                : "We use essential cookies to guarantee platform operation and analytics cookies to understand how our educational resources are used."}
            </p>
            <p className="text-sm text-slate-600">
              {lang === "es"
                ? "Puedes gestionar las preferencias desde el banner inicial o escribiendo a privacidad@planconfiable.com."
                : "Manage your preferences from the initial banner or by emailing privacidad@planconfiable.com."}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default CookiesPolicy;