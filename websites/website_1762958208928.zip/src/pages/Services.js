import React, { useContext, useState } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";
import { FiCheckCircle, FiLayers, FiTrendingUp } from "react-icons/fi";

const Services = () => {
  const { t, lang } = useContext(LanguageContext);
  const [activeTab, setActiveTab] = useState("individual");

  const tabs = [
    {
      id: "individual",
      label: lang === "es" ? "Personas" : "Individuals",
      content: lang === "es"
        ? "Rutas personalizadas, tableros explicativos y sesiones mensuales para interpretar tus números sin sobresaltos."
        : "Personalized routes, explanatory dashboards, and monthly sessions to interpret your numbers calmly."
    },
    {
      id: "institutions",
      label: lang === "es" ? "Instituciones" : "Institutions",
      content: lang === "es"
        ? "Diseñamos programas para escuelas, universidades y ONG que buscan integrar educación financiera responsable."
        : "We design programs for schools, universities, and NGOs looking to integrate responsible financial education."
    },
    {
      id: "companies",
      label: lang === "es" ? "Equipos" : "Teams",
      content: lang === "es"
        ? "Capacitaciones para áreas de RR. HH. y bienestar financiero sin vender productos ni servicios financieros."
        : "Training for HR and wellness teams without selling financial products or services."
    }
  ];

  const bundles = [
    {
      title: lang === "es" ? "Ruta guiada" : "Guided path",
      items: [
        lang === "es"
          ? "Evaluación inicial con reporte educativo"
          : "Initial assessment with educational report",
        lang === "es"
          ? "Dashboard personalizado con objetivos trimestrales"
          : "Personal dashboard with quarterly goals",
        lang === "es"
          ? "Sesiones grupales en vivo"
          : "Live group sessions"
      ]
    },
    {
      title: lang === "es" ? "Laboratorio de datos" : "Data lab",
      items: [
        lang === "es"
          ? "Acceso a visualizaciones exclusivas"
          : "Access to exclusive visualizations",
        lang === "es"
          ? "Actualizaciones semanales vía newsletter"
          : "Weekly updates via newsletter",
        lang === "es"
          ? "Recursos descargables en formatos abiertos"
          : "Downloadable resources in open formats"
      ]
    },
    {
      title: lang === "es" ? "Mentorías docentes" : "Teacher mentoring",
      items: [
        lang === "es"
          ? "Workshops didácticos para equipos educativos"
          : "Didactic workshops for teaching teams",
        lang === "es"
          ? "Bibliografía y dinámicas listas para usar"
          : "Ready-to-use bibliography and activities",
        lang === "es"
          ? "Asistencia en implementación curricular"
          : "Support for curriculum implementation"
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Servicios educativos"
            : "PlanConfiable · Educational services"}
        </title>
        <meta
          name="description"
          content={
            lang === "es"
              ? "Recursos y programas educativos de PlanConfiable para personas, instituciones y equipos."
              : "PlanConfiable educational resources for individuals, institutions, and teams."
          }
        />
      </Helmet>

      <section className="section-space">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <span className="badge-soft-blue">
              {lang === "es"
                ? "Recursos para diferentes audiencias"
                : "Resources for different audiences"}
            </span>
            <h1 className="section-title">
              {lang === "es"
                ? "Diseñamos experiencias educativas a medida"
                : "We design tailored learning experiences"}
            </h1>
            <p className="section-subtitle">
              {lang === "es"
                ? "Todos los programas mantienen el mismo principio: educación responsable sin prometer resultados financieros."
                : "Every program follows the same principle: responsible education with no promised financial outcomes."}
            </p>
          </div>

          <div className="bg-white border border-blue-100 rounded-3xl shadow-xl p-8 mb-12">
            <div className="flex flex-wrap gap-3 mb-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold border transition ${
                    activeTab === tab.id
                      ? "bg-blue-600 text-white border-blue-600"
                      : "bg-blue-50 text-blue-700 border-blue-200"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            {tabs.map(
              (tab) =>
                activeTab === tab.id && (
                  <p
                    key={tab.id}
                    className="text-sm text-slate-700 leading-relaxed"
                  >
                    {tab.content}
                  </p>
                )
            )}
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {bundles.map((bundle) => (
              <div key={bundle.title} className="card-white">
                <h3 className="text-xl font-semibold text-slate-900 mb-4">
                  {bundle.title}
                </h3>
                <ul className="space-y-3 text-sm text-slate-600">
                  {bundle.items.map((item) => (
                    <li key={item} className="flex items-start space-x-3">
                      <FiCheckCircle className="mt-1 text-blue-500" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-slate-500 mt-6">
                  {lang === "es"
                    ? "Aviso: ningún plan incluye servicios financieros."
                    : "Notice: no plan includes financial services."}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-blue-100 border border-blue-200 rounded-3xl p-8">
            <h2 className="text-2xl font-bold text-blue-900 mb-4">
              {lang === "es"
                ? "Resultados educativos medibles"
                : "Measurable learning outcomes"}
            </h2>
            <p className="text-sm text-blue-900 leading-relaxed mb-6">
              {lang === "es"
                ? "Medimos el progreso a través de evaluaciones formativas y autoevaluaciones guiadas. Publicamos métricas agregadas sin exponer información personal."
                : "We measure progress through formative assessments and guided self-evaluations. Aggregated metrics are published without exposing personal information."}
            </p>
            <div className="flex flex-wrap gap-4">
              <span className="tag-pill">
                <FiLayers className="mr-1" /> {lang === "es" ? "Rubricas" : "Rubrics"}
              </span>
              <span className="tag-pill">
                <FiTrendingUp className="mr-1" /> KPI educativos
              </span>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;