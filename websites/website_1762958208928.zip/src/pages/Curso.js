import React, { useContext } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";
import { FiPlayCircle, FiCalendar, FiUsers } from "react-icons/fi";

const Curso = () => {
  const { t, lang } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Curso de finanzas personales"
            : "PlanConfiable · Personal finance course"}
        </title>
      </Helmet>

      <section className="section-space">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="card-white mb-10">
            <span className="badge-soft-blue">{t.course.eyebrow}</span>
            <h1 className="text-3xl font-bold text-slate-900 mb-4">
              {t.course.title}
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              {t.course.audience}
            </p>
            <div className="flex flex-wrap gap-3 mt-6">
              <span className="tag-pill">
                <FiPlayCircle className="mr-1" /> Streaming educativo
              </span>
              <span className="tag-pill">
                <FiCalendar className="mr-1" /> 8 semanas
              </span>
              <span className="tag-pill">
                <FiUsers className="mr-1" /> Grupos reducidos
              </span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <div className="card-white">
              <h2 className="text-xl font-semibold text-slate-900 mb-3">
                {t.course.modulesTitle}
              </h2>
              <ul className="space-y-3 text-sm text-slate-600">
                {t.course.modules.map((module) => (
                  <li key={module} className="flex items-start space-x-3">
                    <span className="w-2 mt-2 h-2 rounded-full bg-blue-600" />
                    <span>{module}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="card-white">
              <h2 className="text-xl font-semibold text-slate-900 mb-3">
                {t.course.format.title}
              </h2>
              <ul className="space-y-3 text-sm text-slate-600">
                {t.course.format.items.map((item) => (
                  <li key={item} className="flex items-start space-x-3">
                    <span className="w-2 mt-2 h-2 rounded-full bg-blue-600" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-3xl p-8">
            <h3 className="text-lg font-semibold text-blue-900 mb-3">
              {lang === "es" ? "Aviso importante" : "Important notice"}
            </h3>
            <p className="text-sm text-blue-900 leading-relaxed">
              {t.course.disclaimer}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Curso;