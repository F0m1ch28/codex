import React, { useContext, useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  AreaChart,
  Area,
  BarChart,
  Bar
} from "recharts";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers";
import { useNavigate } from "react-router-dom";
import { FiArrowRight, FiBookOpen, FiActivity, FiGrid } from "react-icons/fi";

const honeypotField = "favorite_color";

const Home = () => {
  const { lang, t } = useContext(LanguageContext);
  const navigate = useNavigate();

  const lineData = [
    { month: "Nov", rate: 0.0032 },
    { month: "Dec", rate: 0.0035 },
    { month: "Jan", rate: 0.0037 },
    { month: "Feb", rate: 0.0039 },
    { month: "Mar", rate: 0.004 },
    { month: "Apr", rate: 0.0042 }
  ];

  const inflationData = [
    { month: "Nov", value: 12.8 },
    { month: "Dec", value: 12.4 },
    { month: "Jan", value: 20.6 },
    { month: "Feb", value: 13.2 },
    { month: "Mar", value: 11.8 }
  ];

  const salaryData = [
    { month: "2023-Q2", amount: 210000 },
    { month: "2023-Q3", amount: 245000 },
    { month: "2023-Q4", amount: 280000 },
    { month: "2024-Q1", amount: 320000 }
  ];

  const stats = [
    { label: t.stats.arsUsd, value: 0.0042 },
    { label: t.stats.inflation, value: "13.2%" },
    { label: t.stats.salary, value: "$320.000" },
    { label: t.stats.savings, value: "18%" }
  ];

  const schema = useMemo(
    () =>
      z.object({
        name: z.string().min(2, { message: lang === "es" ? "Ingresa tu nombre" : "Enter your name" }),
        email: z.string().email({ message: lang === "es" ? "Correo no válido" : "Invalid email" }),
        phone: z.string().optional(),
        interest: z.string().min(1, { message: lang === "es" ? "Selecciona un interés" : "Select an interest" }),
        [honeypotField]: z.string().max(0)
      }),
    [lang]
  );

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting }
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      interest: "",
      [honeypotField]: ""
    }
  });

  const [rateLimitMessage, setRateLimitMessage] = useState("");

  const onSubmit = async (values) => {
    const stored = localStorage.getItem("lead-last-submit");
    const now = Date.now();
    if (stored && now - parseInt(stored, 10) < 60000) {
      setRateLimitMessage(t.form.rateLimit);
      return;
    }
    if (values[honeypotField]) {
      return;
    }
    setRateLimitMessage("");
    localStorage.setItem("lead-last-submit", String(now));
    await new Promise((resolve) => setTimeout(resolve, 1200));
    reset();
    const path = lang === "es" ? "/gracias" : "/thank-you";
    navigate(path, { replace: true, state: { success: true } });
  };

  const [activeProject, setActiveProject] = useState(
    t.projects.filters[0]
  );
  const filteredProjects = t.projects.items.filter((project) =>
    activeProject === t.projects.filters[0]
      ? true
      : project.category === activeProject ||
        project.category === activeProject.replace("í", "i")
  );

  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) =>
        prev === t.testimonials.quotes.length - 1 ? 0 : prev + 1
      );
    }, 6000);
    return () => clearInterval(timer);
  }, [t.testimonials.quotes.length]);

  const statsAnimated = stats.map((item, index) => ({
    ...item,
    delay: index * 0.1
  }));

  const leadInterests = t.form.interests;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "PlanConfiable",
    url: "https://planconfiable.example.com",
    logo: "https://picsum.photos/200/200?random=55",
    sameAs: [
      "https://www.linkedin.com/company/planconfiable",
      "https://twitter.com/planconfiable"
    ],
    description: lang === "es" ? t.meta.description : t.meta.description,
    contactPoint: [
      {
        "@type": "ContactPoint",
        email: "hola@planconfiable.com",
        contactType: "customer service",
        areaServed: "AR"
      }
    ]
  };

  const courseLd = {
    "@context": "https://schema.org",
    "@type": "Course",
    name:
      lang === "es"
        ? t.course.title
        : "Personal finance management course",
    description: lang === "es" ? t.course.audience : t.course.audience,
    provider: {
      "@type": "Organization",
      name: "PlanConfiable",
      url: "https://planconfiable.example.com"
    }
  };

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: t.faq.items.map((item) => ({
      "@type": "Question",
      name: item.q,
      acceptedAnswer: {
        "@type": "Answer",
        text: item.a
      }
    }))
  };

  return (
    <>
      <Helmet>
        <title>{t.meta.title}</title>
        <meta name="description" content={t.meta.description} />
        <link
          rel="alternate"
          href="https://planconfiable.example.com/"
          hrefLang="x-default"
        />
        <link
          rel="alternate"
          href="https://planconfiable.example.com/"
          hrefLang="es-AR"
        />
        <link
          rel="alternate"
          href="https://planconfiable.example.com/"
          hrefLang="en-AR"
        />
        <script type="application/ld+json">
          {JSON.stringify(jsonLd)}
        </script>
        <script type="application/ld+json">
          {JSON.stringify(courseLd)}
        </script>
        <script type="application/ld+json">
          {JSON.stringify(faqLd)}
        </script>
      </Helmet>

      <div className="relative overflow-hidden">
        <section className="hero-flag-bg">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-16 pb-24">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-6"
              >
                <span className="inline-flex items-center text-sm font-semibold uppercase tracking-widest text-blue-700 bg-blue-100/80 border border-blue-200 rounded-full px-4 py-1">
                  {t.hero.eyebrow}
                </span>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 leading-tight">
                  {t.hero.title}
                </h1>
                <p className="text-lg text-slate-700 leading-relaxed max-w-xl">
                  {t.hero.subtitle}
                </p>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <a
                    href="#stats"
                    className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-blue-600 text-white font-semibold shadow-lg hover:bg-blue-700 transition"
                  >
                    {t.hero.primaryCta}
                    <FiArrowRight className="ml-2" />
                  </a>
                  <a
                    href="#datos"
                    className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-blue-300 text-blue-700 font-semibold hover:bg-blue-50 transition"
                  >
                    {t.hero.secondaryCta}
                  </a>
                </div>
                <div className="flex items-center space-x-4 pt-4">
                  <div className="flex items-center">
                    <img
                      src="https://picsum.photos/60/60?random=12"
                      alt="Estudiante PlanConfiable"
                      className="w-12 h-12 rounded-full border-4 border-white shadow-lg -mr-3"
                    />
                    <img
                      src="https://picsum.photos/60/60?random=13"
                      alt="Participante PlanConfiable"
                      className="w-12 h-12 rounded-full border-4 border-white shadow-lg"
                    />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-600">
                      +8.500 personas ya participan
                    </p>
                    <p className="text-xs text-slate-500">
                      {lang === "es"
                        ? "Contenido actualizado semanalmente"
                        : "Weekly refreshed content"}
                    </p>
                  </div>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 32 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, delay: 0.1 }}
                className="relative"
              >
                <div className="bg-white/90 backdrop-blur border border-blue-100 rounded-3xl shadow-2xl p-6 sm:p-10 space-y-8">
                  <div className="grid grid-cols-2 gap-4">
                    {statsAnimated.map((item, idx) => (
                      <motion.div
                        key={item.label}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{
                          duration: 0.5,
                          delay: item.delay
                        }}
                        className="bg-blue-50 rounded-2xl p-4 shadow-sm border border-blue-100"
                      >
                        <p className="text-xs uppercase text-blue-600 font-semibold">
                          {item.label}
                        </p>
                        <p className="text-2xl font-bold text-blue-900 mt-2">
                          {item.value}
                        </p>
                      </motion.div>
                    ))}
                  </div>
                  <div className="rounded-3xl border border-blue-100 p-4 bg-gradient-to-br from-blue-50 via-white to-blue-100 shadow-inner">
                    <p className="text-sm font-semibold text-blue-700">
                      {lang === "es"
                        ? "Datos confiables para tu presupuesto"
                        : "Reliable data for your budget"}
                    </p>
                    <p className="text-xs text-slate-600 mt-2">
                      {lang === "es"
                        ? "Comparativo ARS/USD en diferentes mercados con actualización semanal."
                        : "ARS/USD comparative overview across markets with weekly refresh."}
                    </p>
                  </div>
                  <img
                    src="https://picsum.photos/800/600?random=14"
                    alt="Profesionales estudiando finanzas en Argentina"
                    className="w-full rounded-3xl object-cover shadow-lg"
                    loading="lazy"
                  />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Stats & Charts */}
        <section id="stats" className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mb-10">
              <div>
                <h2 className="text-3xl font-bold text-slate-900">
                  {t.stats.title}
                </h2>
                <p className="text-sm text-slate-600 mt-2">{t.stats.sub}</p>
              </div>
              <div className="space-x-3">
                <span className="inline-flex items-center px-4 py-2 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold">
                  ARS → USD
                </span>
                <span className="inline-flex items-center px-4 py-2 rounded-full bg-blue-50 text-blue-600 text-xs font-semibold">
                  IPC · INDEC
                </span>
              </div>
            </div>
            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
              <div className="card-white">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm font-semibold text-blue-700">
                      ARS / USD (promedio
                    </p>
                    <p className="text-xs text-slate-500">Mercado oficial y MEP</p>
                  </div>
                  <FiActivity className="text-blue-600 text-xl" />
                </div>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={lineData}>
                      <XAxis dataKey="month" stroke="#93c5fd" />
                      <YAxis stroke="#bfdbfe" />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="rate"
                        stroke="#2563eb"
                        strokeWidth={3}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="card-white">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm font-semibold text-blue-700">
                      {t.stats.inflation}
                    </p>
                    <p className="text-xs text-slate-500">IPC mensual</p>
                  </div>
                  <FiGrid className="text-blue-600 text-xl" />
                </div>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={inflationData}>
                      <defs>
                        <linearGradient id="colorInflation" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1} />
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="month" stroke="#93c5fd" />
                      <YAxis stroke="#bfdbfe" />
                      <Tooltip />
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke="#2563eb"
                        fillOpacity={1}
                        fill="url(#colorInflation)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="card-white md:col-span-2 xl:col-span-1">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm font-semibold text-blue-700">
                      {t.stats.salary}
                    </p>
                    <p className="text-xs text-slate-500">INDEC · RIPTE</p>
                  </div>
                  <FiBookOpen className="text-blue-600 text-xl" />
                </div>
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={salaryData}>
                      <XAxis dataKey="month" stroke="#93c5fd" />
                      <YAxis stroke="#bfdbfe" />
                      <Tooltip />
                      <Bar dataKey="amount" fill="#2563eb" radius={[12, 12, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Inflation block */}
        <section className="pt-20 sm:pt-24" id="datos">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-10 items-center">
              <div className="bg-gradient-to-br from-blue-600 via-blue-500 to-blue-700 text-white rounded-3xl p-8 shadow-xl">
                <h3 className="text-2xl font-bold mb-4">
                  {t.inflation.title}
                </h3>
                <p className="text-sm leading-relaxed text-blue-50">
                  {t.inflation.text}
                </p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <span className="badge-light">INDEC</span>
                  <span className="badge-light">BCRA</span>
                  <span className="badge-light">Educación responsable</span>
                </div>
                <div className="mt-8">
                  <a
                    href="/datos"
                    className="inline-flex items-center px-5 py-2 rounded-full bg-white text-blue-700 font-semibold shadow hover:bg-blue-50 transition"
                  >
                    {lang === "es" ? "Ver metodología" : "View methodology"}
                    <FiArrowRight className="ml-2" />
                  </a>
                </div>
              </div>
              <div>
                <img
                  src="https://picsum.photos/800/600?random=15"
                  alt="Visualización de inflación argentina"
                  className="w-full rounded-3xl shadow-2xl"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Course teaser */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="bg-white border border-blue-100 rounded-3xl p-10 shadow-xl">
              <div className="grid lg:grid-cols-2 gap-10 items-center">
                <div className="space-y-4">
                  <span className="badge-soft-blue">{t.courseTeaser.eyebrow}</span>
                  <h3 className="text-3xl font-bold text-slate-900">
                    {t.courseTeaser.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">
                    {t.courseTeaser.text}
                  </p>
                  <ul className="space-y-3">
                    {t.courseTeaser.bullets.map((bullet) => (
                      <li key={bullet} className="flex items-start space-x-3">
                        <span className="w-2 h-2 mt-2 rounded-full bg-blue-600" />
                        <span className="text-sm text-slate-700">{bullet}</span>
                      </li>
                    ))}
                  </ul>
                  <a
                    href="/curso"
                    className="inline-flex items-center px-6 py-3 rounded-full bg-blue-600 text-white font-semibold shadow hover:bg-blue-700 transition"
                  >
                    {t.courseTeaser.button}
                    <FiArrowRight className="ml-2" />
                  </a>
                </div>
                <div className="relative">
                  <img
                    src="https://picsum.photos/800/600?random=16"
                    alt="Sesión educativa PlanConfiable"
                    className="w-full rounded-3xl shadow-2xl"
                    loading="lazy"
                  />
                  <div className="absolute -bottom-6 -left-6 bg-blue-600 text-white rounded-2xl p-4 shadow-2xl">
                    <p className="text-sm font-semibold">
                      {lang === "es"
                        ? "Sesiones en vivo cada semana"
                        : "Weekly live sessions"}
                    </p>
                    <p className="text-xs text-blue-100">
                      {lang === "es"
                        ? "Docentes certificados"
                        : "Certified instructors"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="md:flex md:items-center md:justify-between mb-10">
              <div>
                <h2 className="text-3xl font-bold text-slate-900">
                  {t.services.title}
                </h2>
                <p className="mt-3 text-sm text-slate-600">
                  {t.services.description}
                </p>
              </div>
              <a
                href="/services"
                className="inline-flex items-center px-5 py-2 mt-4 md:mt-0 rounded-full border border-blue-300 text-blue-700 font-semibold hover:bg-blue-50 transition"
              >
                {lang === "es" ? "Detalles de servicios" : "Service details"}
              </a>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {t.services.items.map((item) => (
                <div
                  key={item.title}
                  className="card-white hover:border-blue-300 hover:shadow-xl transition group"
                >
                  <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-2xl flex items-center justify-center mb-4">
                    <FiBookOpen className="text-xl" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 group-hover:text-blue-700 transition">
                    {item.title}
                  </h3>
                  <p className="text-sm text-slate-600 mt-3 leading-relaxed">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="bg-blue-950 text-blue-100 rounded-3xl p-10 sm:p-12 shadow-2xl relative overflow-hidden">
              <div className="absolute inset-y-0 right-0 opacity-10">
                <img
                  src="https://picsum.photos/600/800?random=17"
                  alt="Proceso PlanConfiable"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
              <div className="relative z-10">
                <h2 className="text-3xl font-bold mb-8">{t.process.title}</h2>
                <div className="grid md:grid-cols-4 gap-6">
                  {t.process.steps.map((step, idx) => (
                    <div
                      key={step.title}
                      className="bg-white/10 backdrop-blur border border-blue-500/30 rounded-2xl p-5 space-y-3"
                    >
                      <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center font-semibold">
                        {idx + 1}
                      </div>
                      <h3 className="text-lg font-semibold text-white">
                        {step.title}
                      </h3>
                      <p className="text-sm text-blue-100 leading-relaxed">
                        {step.text}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl font-bold text-slate-900 mb-8">
              {t.testimonials.title}
            </h2>
            <div className="grid lg:grid-cols-3 gap-6">
              {t.testimonials.quotes.map((quote, idx) => (
                <div
                  key={quote.name}
                  className={`card-white border-2 transition ${
                    idx === currentTestimonial
                      ? "border-blue-500 shadow-2xl"
                      : "border-transparent"
                  }`}
                >
                  <p className="text-sm text-slate-600 leading-relaxed">
                    “{quote.text}”
                  </p>
                  <div className="mt-6">
                    <p className="text-sm font-semibold text-blue-700">
                      {quote.name}
                    </p>
                    <p className="text-xs text-slate-500">{quote.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="md:flex md:items-center md:justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-900">
                  {t.team.title}
                </h2>
                <p className="mt-2 text-sm text-slate-600">{t.team.intro}</p>
              </div>
              <a
                href="/about"
                className="inline-flex items-center px-5 py-2 rounded-full bg-blue-600 text-white text-sm font-semibold shadow hover:bg-blue-700 transition"
              >
                {lang === "es" ? "Conocer al equipo" : "Meet the team"}
              </a>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {t.team.members.map((member) => (
                <div
                  key={member.name}
                  className="group bg-white border border-blue-100 rounded-3xl overflow-hidden shadow hover:shadow-2xl transition"
                >
                  <div className="relative">
                    <img
                      src={member.img}
                      alt={`Equipo PlanConfiable - ${member.name}`}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute inset-x-4 -bottom-6 bg-white rounded-2xl shadow p-4">
                      <p className="text-sm font-semibold text-blue-700">
                        {member.name}
                      </p>
                      <p className="text-xs text-slate-500">{member.role}</p>
                    </div>
                  </div>
                  <div className="p-6 mt-8">
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {member.bio}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Projects */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-900">
                  {t.projects.title}
                </h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {t.projects.filters.map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setActiveProject(filter)}
                    className={`px-4 py-2 rounded-full text-sm font-semibold transition border ${
                      activeProject === filter
                        ? "bg-blue-600 text-white border-blue-600 shadow"
                        : "bg-white text-blue-700 border-blue-200 hover:bg-blue-50"
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {filteredProjects.map((project) => (
                <div
                  key={project.title}
                  className="group bg-white border border-blue-100 rounded-3xl overflow-hidden shadow hover:shadow-2xl transition"
                >
                  <div className="relative">
                    <img
                      src={project.img}
                      alt={project.title}
                      className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-700"
                      loading="lazy"
                    />
                    <span className="absolute top-4 left-4 bg-white/90 text-blue-700 px-3 py-1 rounded-full text-xs font-semibold">
                      {project.category}
                    </span>
                  </div>
                  <div className="p-6 space-y-3">
                    <h3 className="text-lg font-semibold text-slate-900">
                      {project.title}
                    </h3>
                    <p className="text-sm text-slate-600">{project.text}</p>
                    <a
                      href="/datos"
                      className="inline-flex items-center text-sm font-semibold text-blue-600 hover:text-blue-800 transition"
                    >
                      {lang === "es" ? "Ver detalles" : "See details"}
                      <FiArrowRight className="ml-2" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <h2 className="text-3xl font-bold text-center text-slate-900 mb-10">
              {t.faq.title}
            </h2>
            <div className="space-y-4">
              {t.faq.items.map((item, idx) => (
                <details
                  key={item.q}
                  className="bg-white border border-blue-100 rounded-2xl shadow-sm transition hover:border-blue-200"
                  open={idx === 0}
                >
                  <summary className="cursor-pointer px-5 py-4 text-sm font-semibold text-blue-800 flex justify-between items-center">
                    {item.q}
                  </summary>
                  <div className="px-5 pb-4 text-sm text-slate-600 leading-relaxed">
                    {item.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* Blog preview */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-slate-900">
                {t.blog.title}
              </h2>
              <a
                href="/blog"
                className="text-sm font-semibold text-blue-600 hover:text-blue-800 transition"
              >
                {lang === "es" ? "Ver todas" : "View all"}
              </a>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {t.blog.posts.map((post, idx) => (
                <article
                  key={post.title}
                  className="bg-white border border-blue-100 rounded-3xl shadow hover:shadow-xl transition overflow-hidden"
                >
                  <img
                    src={`https://picsum.photos/600/400?random=${60 + idx}`}
                    alt={post.title}
                    className="w-full h-48 object-cover"
                    loading="lazy"
                  />
                  <div className="p-6 space-y-3">
                    <span className="text-xs uppercase font-semibold text-blue-600">
                      {post.date}
                    </span>
                    <h3 className="text-lg font-semibold text-slate-900">
                      {post.title}
                    </h3>
                    <p className="text-sm text-slate-600">{post.text}</p>
                    <a
                      href="/blog"
                      className="inline-flex items-center text-sm font-semibold text-blue-600 hover:text-blue-800 transition"
                    >
                      {lang === "es" ? "Seguir leyendo" : "Continue reading"}
                      <FiArrowRight className="ml-2" />
                    </a>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="pt-20 sm:pt-24">
          <div className="max-w-5xl mx-auto px-4 sm:px-6">
            <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-blue-800 text-white rounded-3xl p-10 sm:p-12 shadow-2xl">
              <div className="grid md:grid-cols-2 gap-6 items-center">
                <div>
                  <h2 className="text-3xl font-bold">{t.cta.title}</h2>
                  <p className="mt-4 text-sm text-blue-100">{t.cta.text}</p>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-end">
                  <a
                    href="/services"
                    className="px-6 py-3 rounded-full bg-white text-blue-700 font-semibold shadow hover:bg-blue-100 transition"
                  >
                    {t.ctas.primary}
                  </a>
                  <a
                    href="#lead"
                    className="px-6 py-3 rounded-full border border-white/60 text-white font-semibold hover:bg-white/10 transition"
                  >
                    {t.cta.button}
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Lead form */}
        <section id="lead" className="pt-20 sm:pt-24 pb-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <div className="bg-white border border-blue-100 rounded-3xl shadow-2xl p-8 sm:p-10">
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-slate-900">
                  {t.form.title}
                </h2>
                <p className="text-sm text-slate-600 mt-2">
                  {t.form.subtitle}
                </p>
                <p className="text-xs text-slate-500 mt-2">
                  {lang === "es"
                    ? "Aviso: PlanConfiable no presta servicios financieros ni promete rendimientos."
                    : "Notice: PlanConfiable does not offer financial services or promised returns."}
                </p>
              </div>
              <form onSubmit={handleSubmit(onSubmit)} className="grid gap-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="form-label">{t.form.name}</label>
                    <input
                      type="text"
                      className="form-input"
                      {...register("name")}
                    />
                    {errors.name && (
                      <p className="form-error">{errors.name.message}</p>
                    )}
                  </div>
                  <div>
                    <label className="form-label">{t.form.email}</label>
                    <input
                      type="email"
                      className="form-input"
                      {...register("email")}
                    />
                    {errors.email && (
                      <p className="form-error">{errors.email.message}</p>
                    )}
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="form-label">{t.form.phone}</label>
                    <input
                      type="tel"
                      className="form-input"
                      {...register("phone")}
                    />
                  </div>
                  <div>
                    <label className="form-label">{t.form.interest}</label>
                    <select className="form-input" {...register("interest")}>
                      <option value="">
                        {lang === "es" ? "Selecciona una opción" : "Select an option"}
                      </option>
                      {leadInterests.map((interest) => (
                        <option key={interest} value={interest}>
                          {interest}
                        </option>
                      ))}
                    </select>
                    {errors.interest && (
                      <p className="form-error">{errors.interest.message}</p>
                    )}
                  </div>
                </div>
                <div className="hidden">
                  <label>{t.form.honeypot}</label>
                  <input type="text" {...register(honeypotField)} />
                </div>
                <label className="flex items-start space-x-3 text-xs text-slate-600">
                  <input
                    type="checkbox"
                    required
                    className="mt-1 rounded border-blue-300 text-blue-600"
                  />
                  <span>
                    {t.form.consent}{" "}
                    <a href="/privacy" className="underline">
                      Privacy
                    </a>{" "}
                    /{" "}
                    <a href="/terms" className="underline">
                      Terms
                    </a>
                  </span>
                </label>
                {rateLimitMessage && (
                  <div className="bg-blue-50 border border-blue-200 text-blue-700 text-sm rounded-2xl px-4 py-3">
                    {rateLimitMessage}
                  </div>
                )}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-blue-600 text-white font-semibold shadow hover:bg-blue-700 transition disabled:bg-blue-300"
                    disabled={isSubmitting}
                  >
                    {isSubmitting
                      ? lang === "es"
                        ? "Enviando..."
                        : "Submitting..."
                      : t.form.submit}
                    <FiArrowRight className="ml-2" />
                  </button>
                  <p className="text-xs text-slate-500">
                    {lang === "es"
                      ? "Responderemos dentro de 48 hs hábiles."
                      : "We respond within 48 business hours."}
                  </p>
                </div>
              </form>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;