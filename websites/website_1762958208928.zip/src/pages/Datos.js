import React, { useContext } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const Datos = () => {
  const { t, lang } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Metodología de datos"
            : "PlanConfiable · Data methodology"}
        </title>
      </Helmet>

      <section className="section-space">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="card-white">
            <h1 className="text-3xl font-bold text-slate-900 mb-4">
              {t.datos.title}
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              {t.datos.intro}
            </p>

            <h2 className="text-lg font-semibold text-blue-800 mb-3">
              {t.datos.sourcesTitle}
            </h2>
            <ul className="list-disc list-inside text-sm text-slate-600 space-y-2 mb-6">
              {t.datos.sources.map((source) => (
                <li key={source}>{source}</li>
              ))}
            </ul>

            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-sm text-blue-900 mb-4">
              {t.datos.limitations}
            </div>
            <p className="text-xs text-slate-500">{t.datos.update}</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Datos;