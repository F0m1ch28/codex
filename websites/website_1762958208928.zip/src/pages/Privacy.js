import React, { useContext } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const Privacy = () => {
  const { t, lang } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Política de privacidad"
            : "PlanConfiable · Privacy policy"}
        </title>
      </Helmet>

      <section className="section-space">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="card-white space-y-4">
            <h1 className="text-3xl font-bold text-slate-900">
              {t.legal.privacyTitle}
            </h1>
            <p className="text-sm text-slate-600">
              {lang === "es"
                ? "PlanConfiable recopila datos personales mínimos (nombre, correo, teléfono opcional) para gestionar comunicaciones educativas."
                : "PlanConfiable collects minimal personal data (name, email, optional phone) to manage educational communications."}
            </p>
            <p className="text-sm text-slate-600">
              {lang === "es"
                ? "No compartimos información con terceros con fines comerciales. Puedes solicitar la eliminación de tus datos escribiendo a privacidad@planconfiable.com."
                : "We do not share information with third parties for commercial purposes. You can request data removal by emailing privacidad@planconfiable.com."}
            </p>
            <p className="text-xs text-slate-500">
              {t.legal.disclaimer}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Privacy;