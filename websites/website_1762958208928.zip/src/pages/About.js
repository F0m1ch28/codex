import React, { useContext } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const About = () => {
  const { t, lang } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Sobre nosotros"
            : "PlanConfiable · About us"}
        </title>
        <meta
          name="description"
          content={
            lang === "es"
              ? "Conoce al equipo educativo de PlanConfiable y nuestra misión de alfabetización financiera responsable."
              : "Meet the PlanConfiable team and our mission to deliver responsible financial literacy."
          }
        />
      </Helmet>

      <section className="section-space">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="mb-10">
            <span className="badge-soft-blue">
              {lang === "es" ? "Nuestra misión" : "Our mission"}
            </span>
            <h1 className="section-title">
              {lang === "es"
                ? "Educación financiera responsable para Argentina"
                : "Responsible financial education for Argentina"}
            </h1>
            <p className="section-subtitle">
              {lang === "es"
                ? "PlanConfiable nació en 2018 con el propósito de acercar datos claros y herramientas pedagógicas a quienes desean comprender la economía doméstica sin ruido ni falsas promesas."
                : "PlanConfiable was created in 2018 to bring clear data and pedagogical tools to people seeking to understand household economics without noise or false promises."}
            </p>
          </div>

          <div className="grid gap-10 md:grid-cols-2">
            <div className="card-white">
              <h2 className="text-xl font-semibold text-slate-900 mb-3">
                {lang === "es" ? "Qué hacemos" : "What we do"}
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                {lang === "es"
                  ? "Diseñamos itinerarios de aprendizaje, dashboards accesibles y ejercicios que ayudan a interpretar la economía argentina. Cada recurso se construye con fuentes públicas verificadas."
                  : "We design learning itineraries, accessible dashboards, and exercises to interpret the Argentine economy. Every resource is built with verified public sources."}
              </p>
            </div>
            <div className="card-white">
              <h2 className="text-xl font-semibold text-slate-900 mb-3">
                {lang === "es" ? "Qué no hacemos" : "What we do not do"}
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                {lang === "es"
                  ? "No brindamos asesoramiento financiero, no gestionamos inversiones ni prometemos resultados. Nuestro foco es la alfabetización y la toma de decisiones responsables."
                  : "We do not offer financial advice, manage investments, or promise results. Our focus is literacy and responsible decision-making."}
              </p>
            </div>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {t.team.members.map((member) => (
              <div key={member.name} className="card-white text-center">
                <img
                  src={member.img}
                  alt={member.name}
                  className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-lg font-semibold text-slate-900">
                  {member.name}
                </h3>
                <p className="text-xs text-blue-600 uppercase tracking-wide">
                  {member.role}
                </p>
                <p className="text-sm text-slate-600 mt-3">{member.bio}</p>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-blue-50 border border-blue-200 rounded-3xl p-8">
            <h2 className="text-xl font-semibold text-blue-800 mb-3">
              {lang === "es"
                ? "Compromiso docente"
                : "Teaching commitment"}
            </h2>
            <p className="text-sm text-blue-900 leading-relaxed">
              {lang === "es"
                ? "Todo el contenido cuenta con revisión académica y se actualiza trimestralmente. Trabajamos con instituciones educativas y organizaciones civiles para ampliar el alcance de la educación financiera responsable."
                : "All content undergoes academic review and is updated quarterly. We collaborate with educational institutions and civil organizations to broaden access to responsible financial education."}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;