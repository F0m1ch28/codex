import React, { useContext } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";

const Terms = () => {
  const { t, lang } = useContext(LanguageContext);

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Términos de uso"
            : "PlanConfiable · Terms of use"}
        </title>
      </Helmet>

      <section className="section-space">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="card-white space-y-4">
            <h1 className="text-3xl font-bold text-slate-900">
              {t.legal.termsTitle}
            </h1>
            <p className="text-sm text-slate-600">
              {lang === "es"
                ? "El acceso a PlanConfiable implica aceptar que los contenidos tienen fines exclusivamente educativos. No ofrecemos servicios financieros ni recomendaciones de inversión."
                : "Accessing PlanConfiable means accepting that all content is for educational purposes only. We do not offer financial services or investment recommendations."}
            </p>
            <p className="text-sm text-slate-600">
              {lang === "es"
                ? "Los usuarios pueden descargar materiales para uso personal o institucional citando la fuente. Queda prohibido comercializar los contenidos."
                : "Users may download materials for personal or institutional use while crediting the source. Commercializing the content is prohibited."}
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Terms;