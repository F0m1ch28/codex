import React, { useContext, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { LanguageContext } from "../context/LanguageContext";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers";
import { useNavigate } from "react-router-dom";

const honeypot = "contact_field";

const Contact = () => {
  const { t, lang } = useContext(LanguageContext);
  const navigate = useNavigate();

  const schema = useMemo(
    () =>
      z.object({
        name: z.string().min(2),
        email: z.string().email(),
        message: z.string().min(10),
        [honeypot]: z.string().max(0)
      }),
    []
  );

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting }
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
      [honeypot]: ""
    }
  });

  const [rateMessage, setRateMessage] = useState("");

  const onSubmit = async (values) => {
    if (values[honeypot]) return;
    const last = localStorage.getItem("contact-last-submit");
    const now = Date.now();
    if (last && now - parseInt(last, 10) < 60000) {
      setRateMessage(
        lang === "es"
          ? "Por favor espera antes de enviar nuevamente."
          : "Please wait before submitting again."
      );
      return;
    }
    setRateMessage("");
    localStorage.setItem("contact-last-submit", String(now));
    await new Promise((resolve) => setTimeout(resolve, 1200));
    reset();
    const path = lang === "es" ? "/gracias" : "/thank-you";
    navigate(path, { replace: true, state: { success: true } });
  };

  return (
    <>
      <Helmet>
        <title>
          {lang === "es"
            ? "PlanConfiable · Contacto"
            : "PlanConfiable · Contact"}
        </title>
      </Helmet>

      <section className="section-space">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="grid md:grid-cols-2 gap-10">
            <div className="space-y-4">
              <h1 className="text-3xl font-bold text-slate-900">
                {t.contact.title}
              </h1>
              <p className="text-sm text-slate-600">
                {t.contact.intro}
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-3xl p-6 space-y-3 text-sm text-blue-900">
                <p>
                  <strong>{t.contact.office}: </strong>Av. Corrientes 1234, CABA
                </p>
                <p>
                  <strong>{t.contact.phone}: </strong>+54 11 5555-0000
                </p>
                <p>
                  <strong>{t.contact.email}: </strong>hola@planconfiable.com
                </p>
                <p className="text-xs text-blue-700">
                  {lang === "es"
                    ? "Aviso: no brindamos servicios financieros."
                    : "Notice: we do not provide financial services."}
                </p>
              </div>
            </div>

            <div className="card-white">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">
                {t.contact.formTitle}
              </h2>
              <form className="grid gap-4" onSubmit={handleSubmit(onSubmit)}>
                <div>
                  <label className="form-label">
                    {t.form.name}
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    {...register("name")}
                    placeholder={t.contact.placeholders.name}
                  />
                  {errors.name && (
                    <p className="form-error">
                      {lang === "es"
                        ? "Ingresa tu nombre"
                        : "Enter your name"}
                    </p>
                  )}
                </div>
                <div>
                  <label className="form-label">{t.form.email}</label>
                  <input
                    type="email"
                    className="form-input"
                    {...register("email")}
                    placeholder={t.contact.placeholders.email}
                  />
                  {errors.email && (
                    <p className="form-error">
                      {lang === "es"
                        ? "Correo inválido"
                        : "Invalid email"}
                    </p>
                  )}
                </div>
                <div>
                  <label className="form-label">Mensaje</label>
                  <textarea
                    rows="5"
                    className="form-input"
                    {...register("message")}
                    placeholder={t.contact.placeholders.message}
                  />
                  {errors.message && (
                    <p className="form-error">
                      {lang === "es"
                        ? "Escribe al menos 10 caracteres"
                        : "Write at least 10 characters"}
                    </p>
                  )}
                </div>
                <div className="hidden">
                  <label>{lang === "es" ? "Campo vacío" : "Leave empty"}</label>
                  <input type="text" {...register(honeypot)} />
                </div>
                {rateMessage && (
                  <div className="text-xs text-blue-600 bg-blue-50 border border-blue-200 rounded-2xl px-4 py-2">
                    {rateMessage}
                  </div>
                )}
                <button
                  type="submit"
                  className="px-6 py-3 rounded-full bg-blue-600 text-white font-semibold hover:bg-blue-700 transition disabled:bg-blue-300"
                  disabled={isSubmitting}
                >
                  {isSubmitting
                    ? lang === "es"
                      ? "Enviando..."
                      : "Sending..."
                    : t.contact.submit}
                </button>
                <p className="text-xs text-slate-500">
                  {t.contact.thanks}
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;