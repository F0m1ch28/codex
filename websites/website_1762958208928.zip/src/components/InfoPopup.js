import React, { useEffect, useState, useContext } from "react";
import { LanguageContext } from "../context/LanguageContext";
import { FiInfo } from "react-icons/fi";

const InfoPopup = () => {
  const { lang } = useContext(LanguageContext);
  const [open, setOpen] = useState(false);
  const [dontShow, setDontShow] = useState(false);
  const cookieKey = "planconfiable-popup-dismissed";

  useEffect(() => {
    const saved = localStorage.getItem(cookieKey);
    if (!saved) {
      const timer = setTimeout(() => setOpen(true), 3500);
      return () => clearTimeout(timer);
    }
  }, []);

  const message =
    "We do not provide financial services / No brindamos servicios financieros.";

  const closePopup = () => {
    setOpen(false);
    if (dontShow) {
      const expires = Date.now() + 30 * 24 * 60 * 60 * 1000;
      localStorage.setItem(cookieKey, String(expires));
    }
  };

  const checkStored = () => {
    const saved = localStorage.getItem(cookieKey);
    if (!saved) {
      setOpen(true);
    }
  };

  return (
    <>
      <button
        className="fixed bottom-24 right-6 z-40 w-11 h-11 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center shadow hover:bg-blue-200 transition"
        onClick={checkStored}
        aria-label="Important notice"
      >
        <FiInfo className="text-xl" />
      </button>
      {open && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center px-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-blue-100">
            <h3 className="text-lg font-semibold text-blue-900">
              PlanConfiable · Aviso importante
            </h3>
            <p className="text-sm text-slate-700 leading-relaxed">
              {message}
            </p>
            <label className="flex items-center space-x-2 text-sm text-slate-600">
              <input
                type="checkbox"
                checked={dontShow}
                onChange={(e) => setDontShow(e.target.checked)}
                className="rounded border-blue-300 text-blue-600 focus:ring-blue-500"
              />
              <span>{lang === "es" ? "No volver a mostrar" : "Don't show again"}</span>
            </label>
            <button
              onClick={closePopup}
              className="w-full bg-blue-600 text-white py-2 rounded-full font-semibold hover:bg-blue-700 transition"
            >
              OK
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default InfoPopup;