import React, { useEffect, useState, useContext } from "react";
import { LanguageContext } from "../context/LanguageContext";
import { FiSettings } from "react-icons/fi";

const CookieBanner = () => {
  const { lang } = useContext(LanguageContext);
  const [visible, setVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const storageKey = "planconfiable-cookie-consent";

  useEffect(() => {
    const saved = localStorage.getItem(storageKey);
    if (!saved) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(storageKey, JSON.stringify({ accepted: true }));
    setVisible(false);
  };

  const content = {
    es: {
      text:
        "Utilizamos cookies educativas para mejorar la experiencia. Revisa las políticas antes de continuar.",
      accept: "Aceptar",
      settings: "Preferencias",
      analytics: "Cookies analíticas",
      functional: "Cookies funcionales",
      essential:
        "Las cookies esenciales son necesarias para el funcionamiento del sitio."
    },
    en: {
      text:
        "We use educational cookies to enhance your experience. Review our policies before continuing.",
      accept: "Accept",
      settings: "Preferences",
      analytics: "Analytics cookies",
      functional: "Functional cookies",
      essential: "Essential cookies are required for the site to work."
    }
  };

  if (!visible) return null;

  const copy = content[lang];

  return (
    <div className="fixed bottom-0 inset-x-0 z-50 px-4 pb-4">
      <div className="max-w-3xl mx-auto bg-white shadow-2xl border border-blue-200 rounded-3xl p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-2">
            <h4 className="text-base font-semibold text-blue-900">
              Cookies · PlanConfiable
            </h4>
            <p className="text-sm text-slate-700">{copy.text}</p>
            <div className="text-xs text-slate-500">
              <a href="/privacy" className="underline mr-2">
                Privacy
              </a>
              <a href="/cookies" className="underline">
                Cookies Policy
              </a>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowSettings((prev) => !prev)}
              className="flex items-center space-x-1 px-4 py-2 rounded-full border border-blue-300 text-blue-700 text-sm font-medium hover:bg-blue-50 transition"
            >
              <FiSettings />
              <span>{copy.settings}</span>
            </button>
            <button
              onClick={handleAccept}
              className="px-5 py-2 rounded-full bg-blue-600 text-white text-sm font-semibold shadow hover:bg-blue-700 transition"
            >
              {copy.accept}
            </button>
          </div>
        </div>
        {showSettings && (
          <div className="mt-4 space-y-2 text-sm text-slate-600 bg-blue-50 border border-blue-100 rounded-2xl p-4">
            <p>{copy.essential}</p>
            <p>• {copy.analytics}</p>
            <p>• {copy.functional}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CookieBanner;