import React, { useContext, useState } from "react";
import { NavLink } from "react-router-dom";
import { LanguageContext } from "../context/LanguageContext";
import { motion, AnimatePresence } from "framer-motion";
import { FiMenu, FiX, FiGlobe } from "react-icons/fi";

const navClasses =
  "px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover:bg-blue-100 hover:text-blue-700";

const Header = () => {
  const { lang, setLang, t } = useContext(LanguageContext);
  const [open, setOpen] = useState(false);

  const navItems = [
    { path: "/", label: t.nav.home },
    { path: "/about", label: t.nav.about },
    { path: "/services", label: t.nav.services },
    { path: "/curso", label: t.nav.curso },
    { path: "/datos", label: t.nav.datos },
    { path: "/blog", label: t.nav.blog },
    { path: "/contact", label: t.nav.contact }
  ];

  const handleLang = (value) => {
    setLang(value);
    setOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/85 backdrop-blur border-b border-blue-100 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <NavLink
            to="/"
            className="flex items-center space-x-2 text-blue-800 font-semibold"
          >
            <div className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center text-lg">
              P
            </div>
            <span className="text-lg sm:text-xl tracking-tight">
              PlanConfiable
            </span>
          </NavLink>

          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `${navClasses} ${
                    isActive ? "bg-blue-600 text-white shadow-lg" : ""
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="hidden lg:flex items-center space-x-2">
            <div className="flex items-center bg-blue-50 rounded-full p-1">
              <button
                onClick={() => handleLang("es")}
                className={`px-3 py-1 text-xs font-semibold rounded-full ${
                  lang === "es"
                    ? "bg-blue-600 text-white shadow"
                    : "text-blue-700"
                }`}
              >
                ES
              </button>
              <button
                onClick={() => handleLang("en")}
                className={`px-3 py-1 text-xs font-semibold rounded-full ${
                  lang === "en"
                    ? "bg-blue-600 text-white shadow"
                    : "text-blue-700"
                }`}
              >
                EN
              </button>
            </div>
            <a
              href="https://planconfiable.example.com/#lead"
              className="bg-blue-600 text-white px-5 py-2 rounded-full text-sm font-semibold hover:bg-blue-700 transition-colors"
            >
              {t.ctas.startTrial}
            </a>
          </div>

          <button
            className="lg:hidden text-blue-800 text-2xl"
            onClick={() => setOpen((prev) => !prev)}
            aria-label="Toggle menu"
          >
            {open ? <FiX /> : <FiMenu />}
          </button>
        </div>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              className="lg:hidden bg-white border border-blue-100 rounded-2xl shadow-xl p-4 mt-2 space-y-4"
            >
              <div className="flex items-center justify-between bg-blue-50 rounded-full px-3 py-2">
                <span className="flex items-center text-blue-700 font-medium">
                  <FiGlobe className="mr-2" />
                  Idioma / Language
                </span>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleLang("es")}
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      lang === "es"
                        ? "bg-blue-600 text-white shadow"
                        : "bg-white text-blue-700 border border-blue-200"
                    }`}
                  >
                    ES
                  </button>
                  <button
                    onClick={() => handleLang("en")}
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      lang === "en"
                        ? "bg-blue-600 text-white shadow"
                        : "bg-white text-blue-700 border border-blue-200"
                    }`}
                  >
                    EN
                  </button>
                </div>
              </div>

              <div className="grid gap-2">
                {navItems.map((item) => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={() => setOpen(false)}
                    className={({ isActive }) =>
                      `px-4 py-3 rounded-2xl text-sm font-medium shadow-sm border border-blue-100 ${
                        isActive
                          ? "bg-blue-600 text-white"
                          : "bg-white text-blue-700"
                      }`
                    }
                  >
                    {item.label}
                  </NavLink>
                ))}
              </div>

              <a
                href="#lead"
                onClick={() => setOpen(false)}
                className="block text-center bg-blue-600 text-white px-4 py-3 rounded-full text-sm font-semibold shadow hover:bg-blue-700 transition-colors"
              >
                {t.ctas.startTrial}
              </a>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};

export default Header;