import React, { useContext } from "react";
import { NavLink } from "react-router-dom";
import { LanguageContext } from "../context/LanguageContext";
import { FiMail, FiPhone, FiMapPin, FiExternalLink } from "react-icons/fi";

const Footer = () => {
  const { t } = useContext(LanguageContext);

  return (
    <footer className="bg-blue-950 text-blue-100 mt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center font-bold text-white">
                P
              </div>
              <span className="text-xl font-semibold">PlanConfiable</span>
            </div>
            <p className="text-sm text-blue-200 mb-4">{t.footer.mission}</p>
            <p className="text-xs text-blue-300">{t.footer.disclaimer}</p>
          </div>

          <div>
            <h4 className="text-sm font-semibold tracking-wide uppercase mb-4 text-blue-200">
              Sitemap
            </h4>
            <nav className="grid gap-2 text-sm">
              <NavLink className="hover:text-white transition-colors" to="/">
                {t.nav.home}
              </NavLink>
              <NavLink
                className="hover:text-white transition-colors"
                to="/about"
              >
                {t.nav.about}
              </NavLink>
              <NavLink
                className="hover:text-white transition-colors"
                to="/services"
              >
                {t.nav.services}
              </NavLink>
              <NavLink
                className="hover:text-white transition-colors"
                to="/curso"
              >
                {t.nav.curso}
              </NavLink>
              <NavLink
                className="hover:text-white transition-colors"
                to="/datos"
              >
                {t.nav.datos}
              </NavLink>
              <NavLink
                className="hover:text-white transition-colors"
                to="/blog"
              >
                {t.nav.blog}
              </NavLink>
              <NavLink
                className="hover:text-white transition-colors"
                to="/contact"
              >
                {t.nav.contact}
              </NavLink>
            </nav>
          </div>

          <div>
            <h4 className="text-sm font-semibold tracking-wide uppercase mb-4 text-blue-200">
              Legal
            </h4>
            <div className="grid gap-2 text-sm">
              <NavLink to="/privacy" className="hover:text-white transition">
                {t.legal.privacyTitle}
              </NavLink>
              <NavLink to="/cookies" className="hover:text-white transition">
                {t.legal.cookiesTitle}
              </NavLink>
              <NavLink to="/terms" className="hover:text-white transition">
                {t.legal.termsTitle}
              </NavLink>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold tracking-wide uppercase mb-4 text-blue-200">
              Contacto
            </h4>
            <ul className="space-y-2 text-sm text-blue-200">
              <li className="flex items-center space-x-2">
                <FiMapPin />
                <span>Av. Corrientes 1234, CABA</span>
              </li>
              <li className="flex items-center space-x-2">
                <FiPhone />
                <span>+54 11 5555-0000</span>
              </li>
              <li className="flex items-center space-x-2">
                <FiMail />
                <span>hola@planconfiable.com</span>
              </li>
              <li className="flex items-center space-x-2">
                <FiExternalLink />
                <a
                  href="https://planconfiable.example.com"
                  className="hover:text-white transition"
                >
                  planconfiable.example.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-800 mt-10 pt-6 text-xs text-center text-blue-300">
          {t.footer.rights}
        </div>
      </div>
    </footer>
  );
};

export default Footer;