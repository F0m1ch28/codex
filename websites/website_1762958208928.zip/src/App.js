import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import InfoPopup from "./components/InfoPopup";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Curso from "./pages/Curso";
import Datos from "./pages/Datos";
import Blog from "./pages/Blog";
import Contact from "./pages/Contact";
import Privacy from "./pages/Privacy";
import CookiesPolicy from "./pages/CookiesPolicy";
import Terms from "./pages/Terms";
import ThankYou from "./pages/ThankYou";
import Gracias from "./pages/Gracias";
import translations from "./translations";
import { LanguageContext } from "./context/LanguageContext";

const App = () => {
  const [lang, setLang] = useState("es");

  return (
    <LanguageContext.Provider
      value={{ lang, setLang, t: translations[lang], translations }}
    >
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/curso" element={<Curso />} />
            <Route path="/datos" element={<Datos />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<CookiesPolicy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/gracias" element={<Gracias />} />
          </Routes>
        </main>
        <Footer />
        <ScrollToTop />
        <CookieBanner />
        <InfoPopup />
      </div>
    </LanguageContext.Provider>
  );
};

export default App;