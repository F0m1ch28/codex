(function () {
    const banner = document.getElementById('cookie-banner');
    if (!banner) return;
    const storedChoice = localStorage.getItem('unlikedvniCookieChoice');
    if (!storedChoice) {
        banner.classList.add('visible');
    }
    const buttons = banner.querySelectorAll('.cookie-btn');
    buttons.forEach(function (button) {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const choice = button.dataset.choice || 'accepted';
            localStorage.setItem('unlikedvniCookieChoice', choice);
            banner.classList.remove('visible');
            if (choice === 'accepted') {
                window.location.href = 'cookies.html#accepted';
            } else {
                window.location.href = 'cookies.html#declined';
            }
        });
    });
})();