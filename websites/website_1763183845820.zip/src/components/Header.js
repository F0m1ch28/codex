import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [isNavOpen, setIsNavOpen] = useState(false);

  const handleToggle = () => {
    setIsNavOpen((prev) => !prev);
  };

  const closeNav = () => {
    setIsNavOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className="layout">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} onClick={closeNav}>
            <span className={styles.logoAccent}>Tech</span>Solutions
          </Link>
          <button
            className={styles.menuButton}
            onClick={handleToggle}
            aria-label="Toggle navigation menu"
          >
            <span className={styles.menuIcon} />
          </button>
          <nav
            className={`${styles.nav} ${isNavOpen ? styles.navOpen : ''}`}
            aria-label="Main navigation"
          >
            <NavLink
              to="/"
              onClick={closeNav}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
              end
            >
              Home
            </NavLink>
            <NavLink
              to="/services"
              onClick={closeNav}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Services
            </NavLink>
            <NavLink
              to="/about"
              onClick={closeNav}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              About
            </NavLink>
            <NavLink
              to="/contact"
              onClick={closeNav}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.active : ''}`
              }
            >
              Contact
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;