import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  telefon: '',
  projektart: 'Privat',
  nachricht: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setSubmitted(false);
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte geben Sie Ihren Namen ein.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse ein.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse ein.';
    }
    if (formData.telefon && !/^[\d+\s()-]{6,}$/.test(formData.telefon)) {
      newErrors.telefon = 'Bitte geben Sie eine gültige Telefonnummer ein.';
    }
    if (!formData.nachricht.trim()) {
      newErrors.nachricht = 'Beschreiben Sie bitte Ihr Projekt oder Ihre Frage.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validateForm();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | GreenTech Solutions München</title>
        <meta
          name="description"
          content="Kontaktieren Sie GreenTech Solutions in München. Wir beraten Sie unverbindlich zu Photovoltaik und Energiesystemen."
        />
        <link rel="canonical" href="https://www.greentech-solutions.de/kontakt" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Wir freuen uns auf Ihre Anfrage</h1>
            <p>
              Rufen Sie uns an, schreiben Sie eine E-Mail oder nutzen Sie das Kontaktformular. Unser Team meldet sich
              innerhalb eines Werktags bei Ihnen.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.contactGrid}>
            <div className={styles.info}>
              <div className={styles.infoCard}>
                <h2>Kontaktinformationen</h2>
                <ul className={styles.infoList}>
                  <li>
                    <span>Adresse</span>
                    Musterstraße 123, 80331 München
                  </li>
                  <li>
                    <span>Telefon</span>
                    <a href="tel:+498912345678">+49 89 12345678</a>
                  </li>
                  <li>
                    <span>E-Mail</span>
                    <a href="mailto:info@greentech-solutions.de">info@greentech-solutions.de</a>
                  </li>
                  <li>
                    <span>Office-Zeiten</span>
                    Mo–Fr: 08:00–18:00 Uhr · Sa: 09:00–14:00 Uhr
                  </li>
                </ul>
              </div>
              <div className={styles.mapWrapper} aria-label="Karte mit unserem Standort">
                <iframe
                  title="GreenTech Solutions Standort in München"
                  src="https://www.google.com/maps?q=Musterstraße%20123%2080331%20München&output=embed"
                  loading="lazy"
                  allowFullScreen
                />
              </div>
            </div>

            <form className={styles.form} noValidate onSubmit={handleSubmit}>
              <h2>Kontaktformular</h2>
              <p>Beschreiben Sie Ihr Projekt – wir melden uns mit passenden Lösungsansätzen.</p>
              <div className={styles.formGroup}>
                <label htmlFor="kontakt-name">Name*</label>
                <input
                  id="kontakt-name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  required
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="kontakt-email">E-Mail*</label>
                <input
                  id="kontakt-email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  required
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formRow}>
                <div className={styles.formGroup}>
                  <label htmlFor="kontakt-telefon">Telefon</label>
                  <input
                    id="kontakt-telefon"
                    name="telefon"
                    type="tel"
                    value={formData.telefon}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.telefon)}
                  />
                  {errors.telefon && <span className={styles.error}>{errors.telefon}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="kontakt-projektart">Projektart</label>
                  <select
                    id="kontakt-projektart"
                    name="projektart"
                    value={formData.projektart}
                    onChange={handleChange}
                  >
                    <option value="Privat">Privat</option>
                    <option value="Gewerbe">Gewerbe</option>
                    <option value="Landwirtschaft">Landwirtschaft</option>
                    <option value="Kommunal">Kommunal</option>
                  </select>
                </div>
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="kontakt-nachricht">Nachricht*</label>
                <textarea
                  id="kontakt-nachricht"
                  name="nachricht"
                  rows="5"
                  value={formData.nachricht}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.nachricht)}
                  required
                />
                {errors.nachricht && <span className={styles.error}>{errors.nachricht}</span>}
              </div>
              <button type="submit" className="btn btn-primary">
                Nachricht senden
              </button>
              {submitted && (
                <p className={styles.success} role="status">
                  Vielen Dank! Wir haben Ihre Nachricht erhalten und melden uns schnellstmöglich.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;