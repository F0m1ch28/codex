document.addEventListener("DOMContentLoaded", () => {
    const banner = document.getElementById("cookie-banner");
    if (!banner) return;

    const acceptBtn = banner.querySelector("[data-cookie-accept]");
    const declineBtn = banner.querySelector("[data-cookie-decline]");
    const cookiePref = localStorage.getItem("csi_cookie_pref");

    const hideBanner = () => banner.classList.remove("show");
    const showBanner = () => banner.classList.add("show");

    if (!cookiePref) {
        setTimeout(showBanner, 600);
    }

    acceptBtn?.addEventListener("click", () => {
        localStorage.setItem("csi_cookie_pref", "accepted");
        hideBanner();
    });

    declineBtn?.addEventListener("click", () => {
        localStorage.setItem("csi_cookie_pref", "declined");
        hideBanner();
    });
});