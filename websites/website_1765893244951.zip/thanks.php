<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: contact.php');
  exit;
}
function sanitize_field($value) {
  return htmlspecialchars(trim($value ?? ''), ENT_QUOTES, 'UTF-8');
}
$name = sanitize_field($_POST['name'] ?? '');
$topic = sanitize_field($_POST['topic'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You | Arctic Wind Control Canada</title>
  <meta name="description" content="Thank you for contacting Arctic Wind Control Canada. Our team will respond promptly to discuss your wind management needs.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="canonical" href="https://www.arcticwindcontrol.com/thanks.php">
  <meta property="og:title" content="Thank You for Contacting Arctic Wind Control Canada">
  <meta property="og:description" content="Our specialists will review your wind management request and connect shortly.">
  <meta property="og:url" content="https://www.arcticwindcontrol.com/thanks.php">
  <meta property="og:type" content="article">
  <meta property="og:image" content="https://picsum.photos/1200/630?wind&t=244">
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto+Mono:wght@500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <script src="scripts.js" defer></script>
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>
  <header class="site-header">
    <div class="header-inner">
      <div class="branding">
        <div class="branding-logo" aria-hidden="true">AW</div>
        <div class="branding-text">
          <span>Arctic Wind Control</span>
          <span>Canada</span>
        </div>
      </div>
      <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation">Menu</button>
      <nav id="primary-navigation" class="primary-nav" aria-expanded="false">
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="solutions.html">Solutions</a>
        <a href="technology.html">Technology</a>
        <a href="performance.html">Performance</a>
        <a href="projects.html">Projects</a>
        <a href="contact.php" class="header-cta cta-button">Contact</a>
      </nav>
    </div>
  </header>

  <main id="main-content">
    <section class="page-hero">
      <div class="hero-inner">
        <div class="hero-copy">
          <span class="hero-badge">Thank You</span>
          <h1>We Received Your Wind Evaluation Request</h1>
          <p>Thank you<?php echo $name ? ', ' . $name : ''; ?>. Our team is reviewing your <?php echo $topic ? strtolower($topic) . ' ' : ''; ?>submission and will connect shortly to plan next steps.</p>
        </div>
      </div>
    </section>

    <section class="section surface">
      <div class="section-inner">
        <div class="card">
          <h2>What Happens Next?</h2>
          <ul class="list-check">
            <li>Our specialists will contact you within two business days.</li>
            <li>We will confirm key details about your wind portfolio and operational objectives.</li>
            <li>A tailored roadmap will outline monitoring, analytics, and control opportunities.</li>
          </ul>
          <a class="cta-button" href="index.html">Return to Homepage</a>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="footer-inner">
      <div class="footer-top">
        <div class="footer-brand">
          <div class="branding">
            <div class="branding-logo" aria-hidden="true">AW</div>
            <div class="branding-text">
              <span>Arctic Wind Control</span>
              <span>Canada</span>
            </div>
          </div>
          <p>Advanced supervision and analytics for Canadian wind assets, engineered to excel from Atlantic coasts to Arctic winds.</p>
          <div class="badge-inline">
            <span aria-hidden="true">🌐</span>
            <span>ArcticWindControl.com</span>
          </div>
        </div>
        <div>
          <h4>Navigation</h4>
          <ul class="footer-links">
            <li><a href="about.html">Our Story</a></li>
            <li><a href="solutions.html">Solutions</a></li>
            <li><a href="technology.html">Technology</a></li>
            <li><a href="performance.html">Performance</a></li>
            <li><a href="projects.html">Projects</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4>Compliance</h4>
          <ul class="footer-links">
            <li><a href="privacy.html">Privacy Policy</a></li>
            <li><a href="cookies.html">Cookies Policy</a></li>
            <li><a href="terms.html">Terms &amp; Conditions</a></li>
            <li><a href="sitemap.xml">Sitemap</a></li>
          </ul>
        </div>
        <div>
          <h4>Contact</h4>
          <ul class="contact-list">
            <li>Bay Adelaide Centre<br>333 Bay Street, Suite 2400<br>Toronto, ON M5H 2R2, Canada</li>
            <li>+1 416 555 4820</li>
            <li>info@arcticwindcontrol.com</li>
          </ul>
        </div>
      </div>
      <div class="footer-meta">
        <span>&copy; 2024 Arctic Wind Control Canada. All rights reserved.</span>
        <span>Engineered for resilient Canadian wind operations.</span>
      </div>
    </div>
  </footer>

  <div class="cookie-banner" aria-hidden="true" role="dialog" aria-live="polite" aria-label="Cookie consent">
    <h3>Cookies &amp; Analytics</h3>
    <p>We use functional and analytics cookies to enhance wind management insights. You can accept or decline analytics tracking at any time.</p>
    <div class="cookie-actions">
      <button type="button" class="cookie-button decline">Decline</button>
      <button type="button" class="cookie-button accept">Accept</button>
    </div>
    <p><a href="cookies.html">Learn more about cookies</a></p>
  </div>
</body>
</html>