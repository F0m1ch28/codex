document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = primaryNav.getAttribute("aria-expanded") === "true";
      primaryNav.setAttribute("aria-expanded", String(!expanded));
      navToggle.setAttribute("aria-expanded", String(!expanded));
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-button.accept");
  const declineBtn = document.querySelector(".cookie-button.decline");
  const storageKey = "awc-cookie-consent";

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedConsent = localStorage.getItem(storageKey);
    if (!storedConsent) {
      cookieBanner.setAttribute("aria-hidden", "false");
    }

    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(storageKey, "accepted");
      cookieBanner.setAttribute("aria-hidden", "true");
    });

    declineBtn.addEventListener("click", () => {
      localStorage.setItem(storageKey, "declined");
      cookieBanner.setAttribute("aria-hidden", "true");
    });
  }

  const links = document.querySelectorAll('a[href^="#"]');
  links.forEach((link) => {
    link.addEventListener("click", (event) => {
      const targetId = link.getAttribute("href").substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        event.preventDefault();
        target.setAttribute("tabindex", "-1");
        target.focus({ preventScroll: true });
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });
});