document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  const header = document.querySelector('.site-header');
  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieAccept = document.querySelector('.cookie-accept');
  const forms = document.querySelectorAll('.capture-form');
  const yearEl = document.getElementById('current-year');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('is-open');
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', event => {
      const targetId = link.getAttribute('href').substring(1);
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        event.preventDefault();
        const headerHeight = header ? header.offsetHeight : 0;
        const elementPosition = targetEl.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
          top: elementPosition - headerHeight + 1,
          behavior: 'smooth'
        });
      }
    });
  });

  if (forms.length) {
    forms.forEach(form => {
      form.addEventListener('submit', event => {
        event.preventDefault();
        const successIndicator = form.querySelector('.form-success');
        if (successIndicator) {
          successIndicator.classList.add('is-visible');
        }
        form.reset();
        setTimeout(() => {
          if (successIndicator) {
            successIndicator.classList.remove('is-visible');
          }
        }, 6000);
      });
    });
  }

  const cookieKey = 'swiftlaunch-cookie-consent';
  if (cookieBanner && cookieAccept) {
    const consentGiven = localStorage.getItem(cookieKey);
    if (!consentGiven) {
      cookieBanner.style.display = 'block';
    }
    cookieAccept.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'true');
      cookieBanner.style.display = 'none';
    });
  }
});