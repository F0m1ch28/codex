document.addEventListener('DOMContentLoaded', () => {
  const yearSpan = document.querySelectorAll('#year');
  const currentYear = new Date().getFullYear();
  yearSpan.forEach(span => span.textContent = currentYear);

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');
  const cookiePreference = localStorage.getItem('cookiePreference');

  if (cookieBanner && !cookiePreference) {
    requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
  }

  const handlePreference = value => {
    localStorage.setItem('cookiePreference', value);
    if (cookieBanner) {
      cookieBanner.classList.remove('is-visible');
    }
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handlePreference('accepted'));
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => handlePreference('declined'));
  }

  const slider = document.querySelector('.hero-slider');
  if (slider) {
    const slides = Array.from(slider.querySelectorAll('.hero-slide'));
    const dots = Array.from(slider.querySelectorAll('.slider-dot'));
    let index = 0;
    const interval = parseInt(slider.dataset.interval, 10) || 5000;

    const activateSlide = newIndex => {
      slides[index].classList.remove('is-active');
      dots[index].classList.remove('is-active');
      index = newIndex;
      slides[index].classList.add('is-active');
      dots[index].classList.add('is-active');
    };

    dots.forEach((dot, dotIndex) => {
      dot.addEventListener('click', () => {
        activateSlide(dotIndex);
        resetTimer();
      });
    });

    let sliderTimer = setInterval(() => {
      const nextIndex = (index + 1) % slides.length;
      activateSlide(nextIndex);
    }, interval);

    const resetTimer = () => {
      clearInterval(sliderTimer);
      sliderTimer = setInterval(() => {
        const nextIndex = (index + 1) % slides.length;
        activateSlide(nextIndex);
      }, interval);
    };
  }

  const customizationForm = document.getElementById('customization-form');
  if (customizationForm) {
    const boxStyle = document.getElementById('box-style');
    const gourmetSelection = document.getElementById('gourmet-selection');
    const addOns = document.getElementById('celebration-add-ons');
    const wrapping = document.getElementById('wrapping');
    const summaryList = document.getElementById('summary-list');
    const summaryTotal = document.querySelector('.summary-total');
    const previewImage = document.getElementById('preview-image');
    const previewTitle = document.getElementById('preview-title');
    const previewDescription = document.getElementById('preview-description');

    const calculateTotal = () => {
      let total = 0;
      summaryList.innerHTML = '';

      const addLineItem = (label, price) => {
        const li = document.createElement('li');
        li.textContent = `${label}: $${price}`;
        summaryList.appendChild(li);
      };

      const boxOption = boxStyle.selectedOptions[0];
      const boxPrice = Number(boxOption.dataset.price || 0);
      total += boxPrice;
      addLineItem('Keepsake Box', boxPrice);

      if (previewImage) {
        previewImage.src = boxOption.dataset.image;
      }
      if (previewTitle) {
        previewTitle.textContent = boxOption.dataset.title;
      }

      const gourmetOption = gourmetSelection.selectedOptions[0];
      const gourmetPrice = Number(gourmetOption.dataset.price || 0);
      total += gourmetPrice;
      addLineItem('Gourmet Selection', gourmetPrice);

      const addOnOptions = Array.from(addOns.selectedOptions);
      if (addOnOptions.length) {
        addOnOptions.forEach(option => {
          const price = Number(option.dataset.price || 0);
          total += price;
          addLineItem(option.dataset.description || option.textContent, price);
        });
      } else {
        const li = document.createElement('li');
        li.textContent = 'No add-ons selected';
        summaryList.appendChild(li);
      }

      const wrappingOption = wrapping.selectedOptions[0];
      const wrappingPrice = Number(wrappingOption.dataset.price || 0);
      total += wrappingPrice;
      addLineItem('Finishing Touch', wrappingPrice);

      if (previewDescription) {
        const addOnDescriptions = addOnOptions.map(option => option.dataset.description);
        previewDescription.textContent = addOnDescriptions.length
          ? `Features include ${addOnDescriptions.join(', ')} with ${wrappingOption.textContent}.`
          : `Paired with ${wrappingOption.textContent} for a refined finishing touch.`;
      }

      summaryTotal.textContent = `$${total}`;
    };

    calculateTotal();

    [boxStyle, gourmetSelection, addOns, wrapping].forEach(field => {
      field.addEventListener('change', calculateTotal);
    });

    customizationForm.addEventListener('submit', event => {
      event.preventDefault();
      alert('Thank you! A celebration stylist will reach out within 24 hours to finalise your bespoke gift box.');
    });
  }
});