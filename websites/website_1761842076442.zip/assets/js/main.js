document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    const scrollBtn = document.getElementById("scrollToTop");
    const contactForm = document.querySelector(".contact-form");
    const formMessage = document.getElementById("formMessage");
    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookies = document.getElementById("acceptCookies");
    const currentYearEl = document.getElementById("currentYear");

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const isOpen = navMenu.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", isOpen.toString());
        });

        navMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    if (scrollBtn) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 250) {
                scrollBtn.style.display = "flex";
            } else {
                scrollBtn.style.display = "none";
            }
        });

        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (contactForm && formMessage) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            formMessage.textContent = "Thank you for reaching out. Our team will connect with you soon.";
            contactForm.reset();
        });
    }

    if (cookieBanner && acceptCookies) {
        const consent = localStorage.getItem("enervailnorthCookieConsent");
        if (!consent) {
            cookieBanner.classList.add("visible");
        }

        acceptCookies.addEventListener("click", () => {
            localStorage.setItem("enervailnorthCookieConsent", "true");
            cookieBanner.classList.remove("visible");
        });
    }
});