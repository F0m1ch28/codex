document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', String(!expanded));
            primaryNav.classList.toggle('open');
            document.body.classList.toggle('no-scroll', !expanded);
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                primaryNav.classList.remove('open');
                document.body.classList.remove('no-scroll');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('athanagejyCookieChoice');
        if (!storedChoice) {
            setTimeout(() => cookieBanner.classList.add('visible'), 800);
        }
        cookieBanner.querySelectorAll('.cookie-btn').forEach(btn => {
            btn.addEventListener('click', event => {
                event.preventDefault();
                const action = btn.dataset.action || 'acknowledge';
                localStorage.setItem('athanagejyCookieChoice', action);
                cookieBanner.classList.remove('visible');
                const target = btn.getAttribute('href');
                if (target) {
                    window.open(target, '_blank');
                }
            });
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const postCards = document.querySelectorAll('.post-card');
    const searchInput = document.querySelector('#postSearch');

    function applyFilters() {
        const activeFilter = document.querySelector('.filter-button.active');
        const filterValue = activeFilter ? activeFilter.dataset.filter : 'all';
        const query = searchInput ? searchInput.value.trim().toLowerCase() : '';

        postCards.forEach(card => {
            const category = card.dataset.category || '';
            const title = card.querySelector('h3')?.textContent.toLowerCase() || '';
            const excerpt = card.querySelector('p')?.textContent.toLowerCase() || '';
            const matchCategory = filterValue === 'all' || category.includes(filterValue);
            const matchQuery = title.includes(query) || excerpt.includes(query);
            if (matchCategory && matchQuery) {
                card.classList.remove('hidden');
            } else {
                card.classList.add('hidden');
            }
        });
    }

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            applyFilters();
        });
    });

    if (searchInput) {
        searchInput.addEventListener('input', () => applyFilters());
    }

    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            const inputs = form.querySelectorAll('[required]');
            let valid = true;
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    valid = false;
                    input.classList.add('invalid');
                    setTimeout(() => input.classList.remove('invalid'), 2000);
                }
            });

            const messageField = form.querySelector('textarea[name="message"]');
            if (messageField && messageField.value.trim().length < 20) {
                valid = false;
                messageField.classList.add('invalid');
                setTimeout(() => messageField.classList.remove('invalid'), 2000);
            }

            if (!valid) {
                event.preventDefault();
            }
        });
    });
});