const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const COOKIE_STORAGE_KEY = "cookie_consent";

const I18N = {
  fr: {
    common: {
      company: "danswholesaleplants",
      skipToContent: "Aller directement au contenu",
      learnMore: "Approfondir",
      readMore: "Consulter l’analyse",
      backToBlog: "Retourner aux analyses",
      backHome: "Retourner à l’accueil",
      sitemap: "Plan du site",
      sectionLabel: {
        recommendations: "Référentiels"
      }
    },
    header: {
      nav: {
        home: "Accueil",
        services: "Axes d’étude",
        about: "À propos",
        blog: "Analyses",
        faq: "Questions",
        contact: "Contact"
      },
      openMenu: "Ouvrir la navigation",
      closeMenu: "Fermer la navigation",
      language: {
        fr: "FR",
        en: "EN"
      }
    },
    footer: {
      aboutTitle: "Orientation spatiale",
      aboutText: "Approches numériques et cartographiques pour rendre lisibles les environnements bâtis complexes et fluidifier les parcours piétons.",
      contactTitle: "Coordonnées",
      legalTitle: "Références juridiques",
      phone: "+32 2 123 45 67",
      email: "contact@danswholesaleplants.com",
      address: "Rue de la Loi 16, 1000 Bruxelles, Belgique",
      links: {
        terms: "Conditions d’utilisation",
        privacy: "Politique de confidentialité",
        cookies: "Politique de cookies",
        refund: "Politique de retour",
        disclaimer: "Avis de non-responsabilité"
      },
      sitemap: "Découvrir le plan du site",
      copyright: "© {year} danswholesaleplants. Publication dédiée à l’UX spatiale."
    },
    home: {
      hero: {
        badge: "Études interdisciplinaires",
        title: "Systèmes d’orientation numérique pour architectures complexes",
        subtitle: "Recherche intégrée sur la signalétique, la cartographie interactive et le guidage piéton dans les bâtiments publics et les infrastructures urbaines de Belgique.",
        primaryAction: "Explorer les axes de travail",
        secondaryAction: "Comprendre notre démarche",
        stat1: { label: "Cartographies contextualisées", value: "58 plans" },
        stat2: { label: "Enquêtes utilisateurs", value: "2 400 retours" },
        stat3: { label: "Territoires étudiés", value: "12 sites" },
        imageAlt: "Interface de navigation intérieure avec cartographie lumineuse"
      },
      featured: {
        heading: "Traduire l’espace en informations lisibles",
        text: "Nous associons analyse comportementale, cognition spatiale et design de l’information pour mettre en cohérence flux piétons, architecture et supports numériques.",
        items: {
          1: {
            title: "Observation des parcours",
            text: "Diagnostics qualitatifs et collecte microscopique des déplacements pour détecter frictions, hésitations et zones d’attention.",
            footer: "Basé sur la mobilité pédestre active"
          },
          2: {
            title: "Modélisation des flux",
            text: "Cartographies synthétiques, coupes et matrices de circulation pour rendre visibles les régimes temporels d’un lieu.",
            footer: "Synthèses comparables site par site"
          },
          3: {
            title: "Dispositifs numériques",
            text: "Prototypes interactifs couvrant signalétique dynamique, kiosques et guidage mobile pour des espaces connectés.",
            footer: "Expérimentations en situation réelle"
          }
        }
      },
      method: {
        heading: "Cadres méthodologiques transverses",
        text: "Nos cadres sont conçus pour articuler infrastructures physiques et couches informatives : de la lecture immédiate à l’assistance immersive.",
        items: {
          1: {
            title: "Matrices de lisibilité",
            text: "Grilles évaluant la compréhension d’un espace selon l’angle, la signalétique, la lumière et la densité décisionnelle."
          },
          2: {
            title: "Cartes narratives",
            text: "Représentations chronologiques des étapes vécues par les usagers, nourries de verbatims et de mesures de fréquentation."
          },
          3: {
            title: "Scripts d’adaptation",
            text: "Scénarios permettant de faire évoluer les supports numériques en fonction du temps, de la langue et du profil d’usage."
          }
        }
      },
      recommendations: {
        heading: "Référentiels et recommandations",
        text: "Sélection d’axes de travail pour consolider la cohérence informationnelle des espaces publics intérieurs.",
        items: {
          1: {
            title: "Aligner architecture et données",
            text: "Rapprocher les plans architecturaux de l’information terrain pour rendre cohérents jalonnements physiques et canaux digitaux.",
            alt: "Schéma d’architecture avec surcouche de flux piétons"
          },
          2: {
            title: "Structurer la multi-langue",
            text: "Concevoir les séquences de traduction dès la phase amont afin de préserver hiérarchie visuelle et compréhension simultanée.",
            alt: "Interface multilingue affichée sur un totem tactile"
          },
          3: {
            title: "Suivre l’usage réel",
            text: "Mettre en place des cycles de vérification réguliers pour intégrer les retours utilisateurs dans les mises à jour signalétiques.",
            alt: "Analyse collaborative autour d’un plan interactif"
          }
        }
      },
      testimonials: {
        heading: "Retours de pairs",
        text: "Institutions publiques, agences urbaines et centres culturels rejoignent nos programmes pour renforcer l’accessibilité spatiale.",
        items: {
          1: {
            quote: "Les ateliers ont renouvelé notre compréhension des flux piétons et rendu tangible la lecture du bâtiment pour nos équipes de médiation.",
            name: "Anne-Sophie Vermeer",
            role: "Coordination muséographique, Bruxelles"
          },
          2: {
            quote: "La structuration bilingue proposée limite désormais les ambiguïtés dans nos terminaux et simplifie les annonces contextuelles.",
            name: "Hugo De Waele",
            role: "Supervision mobilité urbaine, Flandre"
          },
          3: {
            quote: "La cartographie scénarisée nous aide à piloter l’accueil évènementiel avec une vision claire des points de friction.",
            name: "Leïla Brankaert",
            role: "Gestion des flux événementiels, Liège"
          }
        }
      },
      insights: {
        heading: "Analyses récentes",
        text: "Études approfondies sur la signalétique numérique, la cartographie des flux et les environnements hybrides.",
        items: {}
      }
    },
    blog: {
      hero: {
        badge: "Carnet de recherche",
        title: "Analyses et retours d’expérience",
        subtitle: "Documentation détaillée sur la navigation intérieure, l’information visuelle et la compréhension spatiale des environnements bâtis."
      },
      cards: {
        post1: {
          date: "Publié le 12 septembre 2024",
          category: "Navigation intérieure",
          title: "Cartographier les repères cognitifs au sein des bâtiments publics",
          excerpt: "Comment identifier les repères mémoriels et combiner signalétique physique et interfaces numériques pour orienter sans surcharge.",
          alt: "Perspective d’un hall public avec repères colorés"
        },
        post2: {
          date: "Publié le 26 août 2024",
          category: "Signalétique numérique",
          title: "Synchroniser affichages dynamiques et flux ferroviaires",
          excerpt: "Approche systémique pour ajuster messages temps réel, directionnels et contextuels dans les pôles de transport belges.",
          alt: "Écrans d’information dans une gare contemporaine"
        },
        post3: {
          date: "Publié le 7 août 2024",
          category: "Mobilité piétonne",
          title: "Données piétonnes et maquettes spatiales collaboratives",
          excerpt: "Conjuguer mesures de densité et narration cartographique afin de prioriser les correctifs d’orientation.",
          alt: "Plan interactif analysé par un groupe de travail"
        },
        post4: {
          date: "Publié le 17 juillet 2024",
          category: "Design informationnel",
          title: "Contrastes visuels et continuité des parcours complexes",
          excerpt: "Évaluer lumière, couleurs et typographies pour renforcer la lisibilité des corridors ramifiés.",
          alt: "Couloir lumineux avec signalétique directionnelle"
        },
        post5: {
          date: "Publié le 24 juin 2024",
          category: "Expérience usager",
          title: "Méthodes d’évaluation in situ des dispositifs d’orientation",
          excerpt: "Cadres d’observation en temps réel pour tester prototypes numériques et supports physiques.",
          alt: "Observation d’un usager devant un totem interactif"
        }
      }
    },
    services: {
      hero: {
        badge: "Champs d’étude",
        title: "Axes de recherche appliquée",
        subtitle: "Nous combinons exploration terrain, modélisation et design de l’information pour soutenir les projets d’orientation spatiale."
      },
      sections: {
        1: {
          title: "Analyse des parcours et flux",
          text: "Études de circulation dans des environnements denses afin de comprendre décisions, hésitations et rythmes temporels.",
          points: {
            1: "Cartographies comportementales multi-périodes",
            2: "Repérage des points de confusion et seuils de transition",
            3: "Synthèse des trajectoires en scénarios cibles"
          }
        },
        2: {
          title: "Signalétique numérique et guidage visuel",
          text: "Programmes directionnels associant dispositifs dynamiques, balisage stratifié et cohérence des messages.",
          points: {
            1: "Inventaires des supports existants et hiérarchies",
            2: "Prototypage d’interfaces à feedback contextuel",
            3: "Protocoles de maintenance et d’actualisation"
          }
        },
        3: {
          title: "Cartographie interactive",
          text: "Plans immersifs et bases de données géospatiales pour rendre intelligibles les réseaux intérieurs et leurs connexions urbaines.",
          points: {
            1: "Modélisation 2D/3D avec couches d’usage",
            2: "Paramétrage de filtres thématiques bilingues",
            3: "Tests utilisateurs et indicateurs de compréhension"
          }
        },
        4: {
          title: "Design informationnel et accessibilité",
          text: "Structuration des contenus et du langage visuel pour des usages diversifiés, incluant publics internationaux et besoins spécifiques.",
          points: {
            1: "Matrices de hiérarchie typographique multilingue",
            2: "Analyse des contrastes et exigences d’accessibilité",
            3: "Guides opérationnels pour la diffusion"
          }
        },
        5: {
          title: "Recherche sur la mobilité piétonne",
          text: "Production de références et de retours d’expérience pour alimenter politiques publiques et projets hybrides.",
          points: {
            1: "États de l’art transverses",
            2: "Benchmark des environnements complexes",
            3: "Suivis longitudinal sur les usages"
          }
        }
      },
      framework: {
        title: "Processus modulaires",
        text: "Nos livrables sont alignés sur les cycles de conception afin de faciliter l’intégration des orientations dans les projets.",
        items: {
          1: {
            title: "Diagnostic préparatoire",
            text: "Immersion, relevés et entretiens avec les équipes terrain afin de calibrer les hypothèses spatiales."
          },
          2: {
            title: "Itérations cartographiques",
            text: "Allers-retours entre plans numériques et repères physiques pour maintenir la cohérence globale."
          },
          3: {
            title: "Transfert méthodologique",
            text: "Documentation pédagogique pour autonomiser les acteurs dans l’évolution des systèmes d’orientation."
          }
        }
      }
    },
    about: {
      hero: {
        badge: "Lecture du territoire",
        title: "Une cellule dédiée à la lisibilité spatiale",
        subtitle: "Nous croisons urbanisme, sciences de l’information et design d’interfaces pour clarifier les environnements publics."
      },
      sections: {
        1: {
          title: "Approche",
          text: "Observer le geste de se déplacer : nous travaillons depuis les usages réels, les interactions avec le bâti et les dispositifs d’orientation."
        },
        2: {
          title: "Recherche appliquée",
          text: "Chaque mission alimente une base de connaissances sur la manière dont les usagers construisent leurs repères dans les espaces contraints."
        },
        3: {
          title: "Transmission",
          text: "Nos publications, ateliers et guides visent à partager des méthodes reproductibles pour les acteurs publics belges."
        }
      },
      timeline: {
        title: "Étapes fondatrices",
        text: "Quelques jalons ayant structuré notre démarche collaborative.",
        items: {
          1: "2016 : Premières explorations des flux à la station Botanique avec cartographies évolutives.",
          2: "2018 : Mise en place d’un protocole d’évaluation bilingue pour un campus universitaire bruxellois.",
          3: "2020 : Déploiement de maquettes numériques de navigation dans deux hôpitaux publics.",
          4: "2023 : Lancement d’un laboratoire mobile pour tester des supports de signalétique temporaire."
        }
      },
      network: {
        title: "Coopérations",
        text: "Pour affiner nos analyses, nous travaillons avec des spécialistes complémentaires.",
        items: {
          1: {
            title: "Acoustique et ambiance",
            text: "Caractériser le bruit et la résonance qui influencent la perception des annonces et repères vocaux."
          },
          2: {
            title: "Sociologie urbaine",
            text: "Comprendre la manière dont les publics s’approprient les lieux et développent des trajectoires singulières."
          },
          3: {
            title: "Data design",
            text: "Transformer les données spatiales en représentations claires pour les décideurs et les équipes sur site."
          }
        }
      }
    },
    faq: {
      hero: {
        badge: "Orientation pratique",
        title: "Questions récurrentes",
        subtitle: "Éléments de réponse issus de notre accompagnement auprès des infrastructures belges."
      },
      items: {
        1: {
          question: "Comment démarrez-vous l’analyse d’un site ?",
          answer: "Une phase d’immersion courte comprenant observation des parcours, collecte de plans existants et entretien avec les équipes d’accueil."
        },
        2: {
          question: "Intégrez-vous les contraintes multilingues ?",
          answer: "Oui, chaque prototype prévoit une adaptation simultanée français/anglais et, si nécessaire, des déclinaisons supplémentaires."
        },
        3: {
          question: "Quel type de données collectez-vous ?",
          answer: "Des relevés anonymisés de flux, des retours qualitatifs et des mesures contextuelles (temps d’attente, densités)."
        },
        4: {
          question: "Proposez-vous des formations ?",
          answer: "Des ateliers thématiques permettent aux équipes internes de maintenir et faire évoluer les systèmes de guidage."
        },
        5: {
          question: "Travaillez-vous sur sites occupés ?",
          answer: "Oui, nos observations et tests sont organisés pour coexister avec les usages quotidiens des espaces publics."
        },
        6: {
          question: "Comment évaluez-vous l’impact d’un dispositif ?",
          answer: "Par des revues croisées associant mesures quantitatives, retours usagers et ajustements cartographiques."
        }
      },
      notice: "Pour toute question spécifique, utilisez le formulaire de contact afin de nous partager le contexte détaillé."
    },
    contact: {
      hero: {
        badge: "Entrer en relation",
        title: "Partager un contexte d’orientation spatiale",
        subtitle: "Échangeons autour de vos enjeux de lisibilité, d’accessibilité et de navigation numérique."
      },
      info: {
        title: "Coordonnées directes",
        text: "Nous répondons aux sollicitations institutionnelles, associatives ou académiques liées aux environnements complexes.",
        phone: "Nous appeler : +32 2 123 45 67",
        email: "Écrire : contact@danswholesaleplants.com",
        notice: "Merci de décrire succinctement le site, le public ciblé et le calendrier souhaité."
      },
      form: {
        title: "Formulaire de prise de contact",
        description: "Les champs marqués d’un astérisque sont nécessaires pour organiser un premier échange.",
        fields: {
          name: { label: "Nom complet *", placeholder: "Votre nom" },
          email: { label: "Adresse électronique *", placeholder: "email@exemple.be" },
          organisation: { label: "Organisation", placeholder: "Structure ou projet" },
          message: { label: "Message *", placeholder: "Décrivez le contexte spatial et les besoins" }
        },
        notice: "Les informations transmises sont utilisées exclusivement pour une réponse initiale. Aucune liste de diffusion n’est constituée.",
        submit: "Envoyer vers merci"
      },
      map: {
        title: "Localisation à Bruxelles",
        caption: "Nous sommes situés près du Parc de Bruxelles, accessible par les lignes principales de transports."
      }
    },
    faqPage: {},
    cookie: {
      title: "Gestion des cookies",
      description: "Nous utilisons des cookies essentiels pour le bon fonctionnement du site et des préférences optionnelles pour améliorer l’expérience.",
      manage: "Gérer les préférences",
      decline: "Refuser tout sauf le nécessaire",
      save: "Enregistrer la sélection",
      accept: "Tout accepter",
      categories: {
        necessary: {
          title: "Nécessaires (toujours actifs)",
          text: "Assurent la sécurité, la mémorisation de la langue et le fonctionnement de base."
        },
        preferences: {
          title: "Préférences",
          text: "Enregistrent vos choix d’affichage et vos sections consultées."
        },
        analytics: {
          title: "Analyses",
          text: "Mesurent l’audience de façon agrégée pour améliorer les contenus."
        },
        marketing: {
          title: "Contextuels",
          text: "Personnalisent la présentation des références et publications."
        }
      }
    },
    toast: {
      languageChanged: "Langue changée en français.",
      cookiesAccepted: "Préférences enregistrées : tous les cookies activés.",
      cookiesDeclined: "Préférences enregistrées : seuls les cookies nécessaires sont actifs.",
      cookiesSaved: "Sélection de cookies mise à jour.",
      formSubmitted: "Merci, redirection en cours vers la page de confirmation."
    },
    servicesPage: {},
    meta: {
      title: {
        home: "danswholesaleplants · Orientation spatiale et signalétique numérique",
        services: "Axes de travail · danwholesaleplants",
        about: "À propos · danswholesaleplants",
        blog: "Analyses et études · danswholesaleplants",
        post1: "Repères cognitifs dans les bâtiments publics · danswholesaleplants",
        post2: "Affichages dynamiques et flux ferroviaires · danswholesaleplants",
        post3: "Données piétonnes et maquettes collaboratives · danswholesaleplants",
        post4: "Contrastes visuels et parcours complexes · danswholesaleplants",
        post5: "Évaluations in situ des dispositifs d’orientation · danswholesaleplants",
        contact: "Contact · danswholesaleplants",
        faq: "Questions fréquentes · danswholesaleplants",
        terms: "Conditions d’utilisation · danswholesaleplants",
        privacy: "Politique de confidentialité · danswholesaleplants",
        cookies: "Politique de cookies · danswholesaleplants",
        refund: "Politique de retour · danswholesaleplants",
        disclaimer: "Avis de non-responsabilité · danswholesaleplants",
        thank: "Merci · danswholesaleplants",
        notFound: "Page non trouvée · danswholesaleplants"
      },
      description: {
        home: "Plateforme belge dédiée à l’orientation spatiale, la signalétique numérique et la cartographie des environnements complexes.",
        services: "Présentation des axes de recherche appliquée : parcours, signalétique digitale, cartographie interactive, accessibilité et mobilité piétonne.",
        about: "Historique, méthodologies et partenariats de danswholesaleplants pour la lisibilité des espaces publics.",
        blog: "Analyses de terrain sur la navigation intérieure, l’information visuelle et la mobilité piétonne.",
        post1: "Étude approfondie des repères cognitifs pour orienter les usagers dans les bâtiments publics.",
        post2: "Synchronisation des affichages numériques et flux ferroviaires dans les pôles de transport belges.",
        post3: "Maquettes collaboratives et données piétonnes pour ajuster les parcours urbains complexes.",
        post4: "Contrastes visuels et continuité des parcours dans les architectures ramifiées.",
        post5: "Méthodes d’évaluation sur site des dispositifs d’orientation et signalétiques numériques.",
        contact: "Coordonnées de danswholesaleplants, formulaire de contact et localisation à Bruxelles.",
        faq: "Réponses aux questions fréquentes concernant l’orientation spatiale et la signalétique numérique.",
        terms: "Conditions générales d’utilisation du site danswholesaleplants.",
        privacy: "Politique de confidentialité de danswholesaleplants concernant les données traitées.",
        cookies: "Politique détaillée relative aux cookies pour danswholesaleplants.",
        refund: "Politique de retour et de révision de danswholesaleplants.",
        disclaimer: "Avis de non-responsabilité pour les contenus publiés par danswholesaleplants.",
        thank: "Confirmation d’envoi du formulaire vers danswholesaleplants.",
        notFound: "La page demandée n’a pas été trouvée sur danswholesaleplants."
      }
    },
    contactPage: {},
    faqPageExtra: {},
    thank: {
      badge: "Message reçu",
      title: "Merci pour votre envoi",
      message: "Nous analysons votre demande et revenons vers vous avec les premières pistes d’orientation.",
      backHome: "Retourner à l’accueil",
      exploreBlog: "Parcourir les analyses"
    },
    notFound: {
      badge: "Erreur 404",
      title: "Page introuvable",
      message: "Le contenu recherché n’existe plus ou a été déplacé. Utilisez la navigation pour poursuivre votre exploration.",
      backHome: "Revenir à l’accueil",
      contact: "Contacter l’équipe"
    },
    terms: {
      title: "Conditions d’utilisation",
      intro: "Ces conditions encadrent l’accès au site danswholesaleplants.com et à ses contenus informatifs.",
      section01: {
        title: "Objet",
        content: "<p>Le site diffuse des ressources relatives à l’orientation spatiale et à la signalétique numérique. Aucun contrat commercial n’est proposé.</p>"
      },
      section02: {
        title: "Accès au site",
        content: "<p>L’accès est libre. L’utilisateur doit disposer des moyens techniques nécessaires et rester responsable de sa connexion.</p>"
      },
      section03: {
        title: "Propriété intellectuelle",
        content: "<p>Les contenus sont protégés. Toute reproduction doit être soumise à autorisation préalable.</p>"
      },
      section04: {
        title: "Utilisation des contenus",
        content: "<p>Les informations sont fournies à titre documentaire. Toute réutilisation doit citer la source et respecter l’intégrité des analyses.</p>"
      },
      section05: {
        title: "Contributions externes",
        content: "<p>Les témoignages ou citations sont publiés avec l’accord explicite de leurs auteurs.</p>"
      },
      section06: {
        title: "Responsabilité",
        content: "<p>Nous nous efforçons de maintenir une information fiable sans garantie d’exhaustivité.</p>"
      },
      section07: {
        title: "Hyperliens",
        content: "<p>Les liens sortants sont fournis pour approfondir. Nous n’assumons aucune responsabilité quant à leur contenu.</p>"
      },
      section08: {
        title: "Disponibilité",
        content: "<p>Le site peut être suspendu pour maintenance sans préavis. Nous limitons la durée des interruptions.</p>"
      },
      section09: {
        title: "Sécurité",
        content: "<p>Des mesures raisonnables sécurisent l’accès mais l’absence de risque ne peut être garantie.</p>"
      },
      section10: {
        title: "Données personnelles",
        content: "<p>Les messages envoyés via le formulaire sont traités conformément à la politique de confidentialité.</p>"
      },
      section11: {
        title: "Langues",
        content: "<p>Les contenus sont disponibles en français et en anglais. En cas de divergence, la version française prévaut.</p>"
      },
      section12: {
        title: "Mises à jour",
        content: "<p>Les conditions peuvent évoluer. La date de mise à jour est indiquée en pied de page.</p>"
      },
      section13: {
        title: "Droit applicable",
        content: "<p>Le droit belge s’applique. Tout litige relève des juridictions de Bruxelles.</p>"
      },
      section14: {
        title: "Contact",
        content: "<p>Pour toute question sur ces conditions, utilisez les coordonnées mentionnées dans la section Contact.</p>"
      }
    },
    privacy: {
      title: "Politique de confidentialité",
      intro: "Cette politique explique quelles données sont recueillies et comment elles sont protégées.",
      section1: {
        title: "Principes généraux",
        content: "<p>Nous collectons uniquement les informations nécessaires au traitement des demandes reçues via le formulaire.</p>"
      },
      section2: {
        title: "Données collectées",
        content: "<p>Nom, adresse électronique, organisation et message. Aucune donnée sensible n’est requise.</p>"
      },
      section3: {
        title: "Base légale",
        content: "<p>Le traitement s’appuie sur l’intérêt légitime de répondre aux sollicitations professionnelles.</p>"
      },
      section4: {
        title: "Durée de conservation",
        content: "<p>Les messages sont conservés douze mois au maximum, sauf échange suivi explicitement demandé.</p>"
      },
      section5: {
        title: "Destinataires",
        content: "<p>Seules les personnes en charge du suivi au sein de danswholesaleplants ont accès aux messages.</p>"
      },
      section6: {
        title: "Sécurité",
        content: "<p>Des mesures techniques et organisationnelles limitent l’accès non autorisé aux données.</p>"
      },
      section7: {
        title: "Droits des personnes",
        content: "<p>Vous disposez d’un droit d’accès, de rectification, d’effacement et de limitation. Contactez-nous pour l’exercer.</p>"
      },
      section8: {
        title: "Sous-traitants",
        content: "<p>Nous utilisons des infrastructures d’hébergement situées dans l’Union européenne.</p>"
      },
      section9: {
        title: "Cookies",
        content: "<p>La gestion détaillée des cookies est décrite dans la Politique dédiée.</p>"
      },
      section10: {
        title: "Mise à jour",
        content: "<p>Cette politique peut évoluer. La version en vigueur est affichée sur cette page.</p>"
      }
    },
    cookiesPage: {
      title: "Politique de cookies",
      intro: "Ce document précise les cookies utilisés sur danswholesaleplants.com.",
      section1: {
        title: "Définition",
        content: "<p>Un cookie est un petit fichier texte stocké sur votre terminal pour faciliter la navigation.</p>"
      },
      section2: {
        title: "Paramétrage",
        content: "<p>Vous pouvez ajuster vos préférences depuis le bandeau ou via votre navigateur.</p>"
      },
      section3: {
        title: "Tableau récapitulatif",
        content: "<p>La liste ci-dessous décrit les cookies susceptibles d’être déposés.</p>"
      },
      table: {
        name: "Nom",
        provider: "Fournisseur",
        type: "Type",
        purpose: "Finalité",
        duration: "Durée",
        rows: {
          1: {
            name: "site_lang",
            provider: "danswholesaleplants",
            type: "Préférence",
            purpose: "Mémorise la langue sélectionnée.",
            duration: "12 mois"
          },
          2: {
            name: "cookie_consent",
            provider: "danswholesaleplants",
            type: "Nécessaire",
            purpose: "Sauvegarde les choix de consentement.",
            duration: "12 mois"
          },
          3: {
            name: "session_view",
            provider: "danswholesaleplants",
            type: "Nécessaire",
            purpose: "Garantit la sécurité de session.",
            duration: "Session"
          },
          4: {
            name: "analytics_view",
            provider: "danswholesaleplants",
            type: "Analyse",
            purpose: "Mesure l’audience agrégée.",
            duration: "6 mois"
          }
        }
      }
    },
    refund: {
      title: "Politique de retour et de révision",
      intro: "Les contenus du site sont informatifs. Cette politique précise le traitement des demandes de correction.",
      section1: {
        title: "Champ d’application",
        content: "<p>La politique s’applique aux publications et documents mis à disposition sur le site.</p>"
      },
      section2: {
        title: "Demandes de rectification",
        content: "<p>Vous pouvez signaler une information inexacte via le formulaire de contact en fournissant les détails nécessaires.</p>"
      },
      section3: {
        title: "Délais de traitement",
        content: "<p>Les demandes sont analysées dans un délai de trente jours ouvrés.</p>"
      },
      section4: {
        title: "Révisions de contenu",
        content: "<p>Si une correction est jugée pertinente, la publication est mise à jour et datée.</p>"
      },
      section5: {
        title: "Absence de remboursement financier",
        content: "<p>Le site ne propose aucun service payant. Aucune restitution monétaire n’est donc possible.</p>"
      },
      section6: {
        title: "Archivage",
        content: "<p>Les versions précédentes peuvent être conservées à des fins de traçabilité.</p>"
      },
      section7: {
        title: "Communication",
        content: "<p>Une réponse est adressée à la personne ayant soumis la demande, indiquant la décision prise.</p>"
      },
      section8: {
        title: "Cas particuliers",
        content: "<p>Les contenus produits avec des partenaires sont révisés conjointement.</p>"
      },
      section9: {
        title: "Limites",
        content: "<p>Les avis et interprétations ne sont pas modifiés, sauf erreur factuelle manifeste.</p>"
      },
      section10: {
        title: "Contact",
        content: "<p>Utilisez la section Contact pour adresser toute demande relative à cette politique.</p>"
      }
    },
    disclaimer: {
      title: "Avis de non-responsabilité",
      intro: "Les informations diffusées visent un usage documentaire.",
      section1: {
        title: "Absence de garantie",
        content: "<p>Nous ne garantissons pas l’exhaustivité ni l’actualité permanente des contenus.</p>"
      },
      section2: {
        title: "Utilisation autonome",
        content: "<p>Les lecteurs restent responsables de l’interprétation des analyses présentées.</p>"
      },
      section3: {
        title: "Références externes",
        content: "<p>La présence de liens ne constitue pas une validation des ressources externes.</p>"
      },
      section4: {
        title: "Évolutions",
        content: "<p>Les informations peuvent être modifiées sans préavis pour intégrer de nouvelles observations.</p>"
      },
      section5: {
        title: "Absence de relation contractuelle",
        content: "<p>La consultation du site n’établit aucun contrat entre l’utilisateur et danswholesaleplants.</p>"
      },
      section6: {
        title: "Contact",
        content: "<p>Pour toute clarification, adressez une demande via la page Contact.</p>"
      }
    },
    thank: {},
    notFoundPage: {},
    post1: {
      badge: "Analyse approfondie",
      title: "Cartographier les repères cognitifs au sein des bâtiments publics",
      meta: "Navigation intérieure · 12 septembre 2024",
      section1: {
        title: "Comprendre la mémoire spatiale",
        content: "<p>Dans les bâtiments publics, la première orientation repose sur la capacité des usagers à identifier des repères cognitifs clairs : volumes majeurs, verticalités, ouvertures lumineuses ou tonalités colorées. Lorsque ces éléments sont diffuses, les visiteurs se réfèrent à des stratégies secondaires — suivre un flux dominant, lire un support textuel, se fier à l’iconographie. Nous avons mené plusieurs sessions d’observation in situ afin de collecter les points de fixation visuelle prioritaires selon les profils. Ces traces montrent que la hiérarchie des repères n’est jamais homogène : un guichet baigné de lumière peut servir de pivot à certains, tandis que d’autres mémorisent plutôt une œuvre murale ou une rupture de matériau.</p><p>En parallèle de cette observation, nous avons interrogé les dispositifs existants. Les plans statiques, souvent accrochés aux rez-de-chaussée, sont consultés pour valider une trajectoire plutôt que pour engager une exploration. Les signalétiques suspendues, lorsque leur typographie manque de contraste, sont peu retenues. Ces constats invitent à considérer l’espace comme un récit visuel où chaque élément doit être pensé selon sa perception effective et non uniquement selon sa présence physique.</p>"
      },
      section2: {
        title: "Hiérarchie des supports physiques et numériques",
        content: "<p>La superposition de supports hétérogènes produit parfois un bruit informationnel. Nous avons testé une méthode de hiérarchisation qui consiste à documenter la fonction réelle de chaque support : signaler, confirmer, rassurer. Les écrans dynamiques, par exemple, sont rarement interprétés comme un outil d’orientation s’ils sont placés après le point de décision. Ils deviennent pertinents lorsqu’ils proposent des scénarios de parcours simples, avec un affichage contextuel limité à trois options maximum. Inversement, les cartouches muraux jouent surtout un rôle de repère fixe. Ils gagnent à afficher une nomenclature cohérente avec la version numérique pour éviter les divergences terminologiques.</p><p>Nous recommandons ainsi de définir une palette restreinte de supports maîtres et de réserver les autres formats à des compléments narratifs. L’objectif n’est pas de multiplier les sources mais de renforcer l’alignement des langages visuel et textuel entre chaque composant du parcours.</p>"
      },
      section3: {
        title: "Apport des cartographies combinées",
        content: "<p>Pour dépasser la simple juxtaposition des plans architecturaux et des cartographies usuelles, nous avons élaboré des couches hybridées : fonds épurés, codes couleur par familles d’espaces, pictogrammes issus de la même bibliothèque que la signalétique. Lorsque ces cartes sont diffusées sur des totems interactifs, elles doivent conserver une structure légère afin d’éviter les saturations. Un zoom progressif permet de passer du macro (comment atteindre une aile) au micro (quel couloir emprunter). Les personnes interrogées retiennent mieux les informations lorsqu’elles peuvent visualiser successivement ces deux niveaux.</p><p>La mise en cohérence des cartes et des repères physiques repose sur un protocole de mise à jour : chaque modification spatiale déclenche un contrôle croisé. Sans ce suivi, le système perd sa crédibilité et les usagers reviennent à des stratégies plus aléatoires.</p>"
      },
      section4: {
        title: "Vers une expérience multimodale fluide",
        content: "<p>La combinaison des repères physiques, des indications numériques et des interactions humaines (agents d’accueil) doit être orchestrée comme un même dispositif. Nous incitons à construire des scripts de parcours intégrant ces dimensions : par exemple, la personne reçoit un QR code lors de son arrivée qui ouvre une carte personnalisée alignée sur la signalétique physique et les indications vocales. Chaque canal renvoie ainsi vers les mêmes jalons. Cette approche limite la confusion, notamment pour les visiteurs internationaux ou ponctuels.</p><p>En conclusion, cartographier les repères cognitifs implique de considérer le bâtiment comme un média. L’analyse ne s’arrête pas à la production d’un plan, elle s’étend à l’expérience vécue. L’enjeu consiste à orchestrer repères physiques et numériques pour permettre à chacun de créer son propre fil conducteur sans perdre la cohérence collective.</p>"
      }
    },
    post2: {
      badge: "Cahier de terrain",
      title: "Synchroniser affichages dynamiques et flux ferroviaires",
      meta: "Signalétique numérique · 26 août 2024",
      section1: {
        title: "Observer la chaîne d’information",
        content: "<p>Dans les gares belges, l’information voyage entre divers systèmes : données horaires, alertes, annonces vocales, affichages directionnels. Lorsque ces maillons ne sont pas synchronisés, les voyageurs adoptent des stratégies de compensation : suivre le mouvement de foule, interroger un agent, surveiller plusieurs écrans. Notre travail a commencé par une cartographie de cette chaîne d’information et par la mesure des temps de propagation d’une alerte entre la source (logiciel de gestion de trafic) et les supports visibles.</p><p>Nous avons constaté que certains écrans de signalétique dite de confort (plan des quais, orientation vers les bus) ne recevaient pas les mises à jour en temps réel. Ils diffusaient encore des informations statiques alors que les voyageurs attendaient des indications adaptatives. La première étape consiste donc à définir un référentiel de priorités : quelles informations doivent impérativement changer simultanément, lesquelles peuvent rester stables.</p>"
      },
      section2: {
        title: "Construire une scénarisation",
        content: "<p>Nous proposons une segmentation en trois niveaux. Le premier niveau concerne la sécurité et les annonces critiques : il doit préempter tous les écrans indépendamment du contenu affiché. Le deuxième niveau concerne la fluidité des parcours : quand un quai change, l’orientation vers celui-ci doit suivre la modification sans latence. Le troisième niveau correspond aux informations contextuelles (services, conseils). Cette hiérarchie est traduite dans un cahier des charges technique pour l’architecture logicielle et dans des règles visuelles pour l’affichage.</p><p>En parallèle, les annonces vocales doivent reprendre la même terminologie que les écrans. Les tests menés montrent que la cohérence linguistique entre voix et écran renforce la réassurance et réduit la dispersion des flux.</p>"
      },
      section3: {
        title: "Impacts sur les flux piétons",
        content: "<p>Nous avons effectué des relevés vidéo anonymisés pour mesurer l’évolution des déplacements après synchronisation. Les zones d’hésitation, identifiées par des arrêts prolongés, diminuent significativement lorsque les écrans offrent un schéma directionnel clair accompagné d’un rappel couleur identique sur les supports statiques.</p><p>La simultanéité des mises à jour évite les contre-flux : les personnes n’ont plus besoin de revenir sur leurs pas. On observe également une meilleure diffusion latérale dans les gares comportant des accès multiples, car l’information guide vers toutes les options disponibles et non uniquement vers la voie principale.</p>"
      },
      section4: {
        title: "Recommandations opérationnelles",
        content: "<p>Pour maintenir la synchronisation, un tableau de bord permet aux équipes d’exploitation de visualiser l’état des différents canaux et de déclencher manuellement une relecture lorsque les données changent brutalement. La documentation multilingue du vocabulaire utilisé sur les écrans est partagée avec les équipes sur site afin que les annonces vocales reprennent les mêmes termes. Enfin, les tests réguliers avec des usagers ponctuels (touristes, voyageurs peu habitués) servent de baromètre pour vérifier la lisibilité du système.</p><p>La réussite d’un affichage dynamique ne se mesure donc pas uniquement à la technologie employée mais à sa capacité à orchestrer les flux et à préserver une cohérence narrative entre tous les supports.</p>"
      }
    },
    post3: {
      badge: "Étude collaborative",
      title: "Données piétonnes et maquettes spatiales collaboratives",
      meta: "Mobilité piétonne · 7 août 2024",
      section1: {
        title: "Collecter et partager les données",
        content: "<p>La collecte des données piétonnes est souvent fragmentée entre différentes entités. Nous avons mis en place un protocole commun : capteurs anonymes pour compter les entrées, enquêtes sur place pour qualifier les motifs de visite, et observation vidéo ponctuelle pour analyser les gestes. Ces données sont stockées dans un format standardisé, permettant de les superposer dans une maquette numérique.</p><p>Cette maquette est ensuite utilisée lors d’ateliers réunissant urbanistes, gestionnaires de site, responsables de sécurité et médiateurs. Chacun peut manipuler les couches, visualiser les densités à différents moments et commenter directement les zones à risque ou les parcours inattendus.</p>"
      },
      section2: {
        title: "De la donnée à l’action",
        content: "<p>L’un des défis majeurs consiste à transformer les données en décisions concrètes. Nous avons développé une série d’indicateurs simples : temps moyen de traversée, points d’arrêt récurrents, zones d’agrégation. Ces indicateurs sont représentés sous forme de graphiques attachés à la maquette. Lorsqu’un corridor présente un temps de traversée supérieur à la moyenne, il est possible de cliquer pour visualiser les séquences vidéo correspondantes et comprendre les raisons (signalétique absente, point de décision ambigu, manque d’éclairage).</p><p>La maquette devient un outil de dialogue : chaque observation chiffrée peut être enrichie par les retours qualitatifs recueillis auprès des usagers.</p>"
      },
      section3: {
        title: "Intégrer les retours citoyens",
        content: "<p>Nous organisons des sessions ouvertes où des représentants d’usagers (personnes à mobilité réduite, publics étrangers, personnels d’accueil) sont invités à manipuler la maquette. Ils peuvent proposer des annotations visibles par tous, ce qui évite que des intuitions pertinentes soient perdues. Cette participation stimule une compréhension commune du site et révèle des besoins parfois absents des données quantitatives (zones anxiogènes, alignement des trajectoires avec des repères symboliques).</p><p>Les commentaires sont ensuite codés et intégrés au processus de décision, afin que chaque ajustement soit justifié par une convergence de données et d’expériences vécues.</p>"
      },
      section4: {
        title: "Suivre l’évolution",
        content: "<p>La maquette n’est pas un produit figé. Nous planifions des mises à jour trimestrielles et comparons les indicateurs à chaque cycle. Cela permet de mesurer l’impact des modifications : ajout d’une signalétique, ouverture d’un nouvel accès, réarrangement d’un hall. Lorsque les résultats ne correspondent pas à l’objectif initial, un débat est ouvert pour proposer d’autres solutions ou affiner les scénarios.</p><p>Ce dispositif collaboratif crée une culture de l’amélioration continue. Les espaces publics complexes deviennent plus lisibles parce que l’ensemble des acteurs dispose d’un langage commun, ancré dans une représentation partagée des flux piétons.</p>"
      }
    },
    post4: {
      badge: "Design informationnel",
      title: "Contrastes visuels et continuité des parcours complexes",
      meta: "Design informationnel · 17 juillet 2024",
      section1: {
        title: "Mesurer les contrastes existants",
        content: "<p>Dans les architectures ramifiées, les contrastes de couleur, de luminosité et de texture conditionnent la perception des directions. Nous avons réalisé une campagne de mesures (luxmètre, photos calibrées) pour évaluer les transitions lumineuses. Résultat : certains couloirs présentent des ruptures de contraste telles que les signalétiques deviennent invisibles pour les usagers à vision réduite.</p><p>La première action consiste à redéfinir une palette chromatique compatible avec les standards d’accessibilité. Les contrastes doivent rester supérieurs à 4,5:1 entre fond et typographie pour garantir la lisibilité.</p>"
      },
      section2: {
        title: "Continuité narrative des parcours",
        content: "<p>Le parcours d’un usager est une succession de micro-décisions. Chaque point doit confirmer le précédent. Nous avons créé un fil narratif où chaque zone est associée à une teinte, une forme et un symbole. Cette continuité évite les ruptures : un couloir bleu menant à un espace bleu, avec un pictogramme identique, renforce la confiance. Les changements de couleur signalent une bifurcation intentionnelle.</p><p>Nous veillons à intégrer cette logique aussi bien dans la peinture murale que dans les affichages numériques. Les écrans reprennent les mêmes codes pour éviter la dissonance.</p>"
      },
      section3: {
        title: "Prototypage in situ",
        content: "<p>Des tests grandeur nature sont menés sur des segments pilotes. Nous installons des bandeaux lumineux réglables pour ajuster le contraste en direct. Des questionnaires rapides sont proposés à des usagers de passage, couplés à des mesures d’eye-tracking mobile. Les résultats montrent une diminution du temps de décision de 18 % lorsque le contraste est optimisé et que les symboles sont rappelés sur plusieurs supports.</p><p>Ces données servent à argumenter la généralisation et à prioriser les zones où l’effort de contraste apportera le plus grand bénéfice.</p>"
      },
      section4: {
        title: "Maintenance et évolutions",
        content: "<p>Le contraste est une question vivante. La dégradation des matériaux ou la modification de l’éclairage peut altérer les résultats. Nous recommandons d’intégrer un contrôle régulier dans les opérations de maintenance, avec un relevé semestriel. Les fiches techniques indiquent les valeurs de contraste à respecter pour chaque zone, permettant aux équipes d’intervenir rapidement.</p><p>Cette approche préventive garantit la continuité de lecture des parcours, même lorsque les infrastructures évoluent.</p>"
      }
    },
    post5: {
      badge: "Retour d’expérimentation",
      title: "Méthodes d’évaluation in situ des dispositifs d’orientation",
      meta: "Expérience usager · 24 juin 2024",
      section1: {
        title: "Mettre en place un protocole d’observation",
        content: "<p>Pour évaluer un dispositif d’orientation, nous combinons plusieurs techniques : observation discrète, auto-confrontation, suivi des temps de parcours. Chaque session commence par une phase de repérage où les usagers testent un itinéraire précis. Nous enregistrons les arrêts, les retours en arrière, les interactions avec les supports. Cette cartographie comportementale met en lumière les zones de doute et les supports qui retiennent l’attention.</p><p>Nous complétons par des entretiens courts pour comprendre les raisonnement derrière chaque décision. Ces retours qualitatifs enrichissent l’interprétation des données quantitatives.</p>"
      },
      section2: {
        title: "Mesurer la compréhension",
        content: "<p>La qualité d’un dispositif ne se mesure pas uniquement par la rapidité de déplacement, mais aussi par la confiance ressentie. Nous distribuons des cartes mentales à compléter après le parcours. Les usagers dessinent les étapes mémorisées, ce qui révèle les éléments marquants ou au contraire oubliés. En parallèle, nous analysons la cohérence entre le vocabulaire utilisé par les visiteurs et celui de la signalétique. Les divergences lexicales signalent un besoin d’ajustement.</p><p>Lorsque des supports numériques sont impliqués, nous enregistrons les interactions (touchpoints, navigation dans les menus). Les écrans doivent proposer des niveaux d’information gradués pour éviter la surcharge.</p>"
      },
      section3: {
        title: "Évaluer sur la durée",
        content: "<p>La réussite d’un dispositif ne s’évalue pas uniquement lors de son lancement. Nous planifions des sessions de suivi à un, trois et six mois. Cela permet de vérifier si les améliorations perdurent, si la compréhension s’installe durablement. Les retours du personnel d’accueil sont également collectés : ils témoignent des questions récurrentes et des difficultés résiduelles.</p><p>Cette vision dans le temps montre les moments où des révisions mineures suffisent (ajout d’un pictogramme) et ceux où une refonte plus profonde est nécessaire.</p>"
      },
      section4: {
        title: "Diffuser les enseignements",
        content: "<p>Les résultats sont compilés dans une documentation accessible à toutes les parties prenantes. Nous utilisons un format visuel : cartographies de points d’attention, fiches actions, vidéos courtes. L’objectif est que chaque acteur puisse s’approprier les enseignements et les réinjecter dans ses pratiques quotidiennes.</p><p>Évaluer in situ devient ainsi un levier de transformation continue, alignant dispositifs physiques, numériques et interactions humaines.</p>"
      }
    },
    thankPage: {},
    notFoundPageExtra: {}
  },
  en: {
    common: {
      company: "danswholesaleplants",
      skipToContent: "Skip to main content",
      learnMore: "Explore further",
      readMore: "Read the analysis",
      backToBlog: "Back to insights",
      backHome: "Return home",
      sitemap: "Access the sitemap"
    },
    header: {
      nav: {
        home: "Home",
        services: "Workstreams",
        about: "About",
        blog: "Insights",
        faq: "Questions",
        contact: "Contact"
      },
      openMenu: "Open navigation",
      closeMenu: "Close navigation",
      language: {
        fr: "FR",
        en: "EN"
      }
    },
    footer: {
      aboutTitle: "Spatial orientation",
      aboutText: "Digital signage, interactive mapping and information design to bring clarity to complex built environments in Belgium.",
      contactTitle: "Contact",
      legalTitle: "Legal references",
      phone: "+32 2 123 45 67",
      email: "contact@danswholesaleplants.com",
      address: "Rue de la Loi 16, 1000 Brussels, Belgium",
      links: {
        terms: "Terms of use",
        privacy: "Privacy policy",
        cookies: "Cookie policy",
        refund: "Return policy",
        disclaimer: "Disclaimer"
      },
      sitemap: "See the sitemap",
      copyright: "© {year} danswholesaleplants. Spatial UX knowledge platform."
    },
    home: {
      hero: {
        badge: "Interdisciplinary studies",
        title: "Digital wayfinding systems for complex architectures",
        subtitle: "Integrated research on signage, interactive cartography and pedestrian guidance across Belgian public buildings and urban infrastructures.",
        primaryAction: "Review workstreams",
        secondaryAction: "Understand our approach",
        stat1: { label: "Contextual maps", value: "58 layouts" },
        stat2: { label: "User interviews", value: "2,400 inputs" },
        stat3: { label: "Sites surveyed", value: "12 areas" },
        imageAlt: "Indoor navigation interface with luminous mapping"
      },
      featured: {
        heading: "Translating space into legible information",
        text: "We align behavioural analysis, spatial cognition and information design to synchronise pedestrian flows, architecture and digital touchpoints.",
        items: {
          1: {
            title: "Pathway observation",
            text: "Qualitative diagnostics capturing movements to locate frictions, moments of doubt and focal zones.",
            footer: "Grounded in active pedestrian mobility"
          },
          2: {
            title: "Flow modelling",
            text: "Synthetic cartographies, sectional views and mobility matrices to expose temporal regimes of each site.",
            footer: "Comparable reports across locations"
          },
          3: {
            title: "Digital devices",
            text: "Interactive prototypes covering dynamic signage, kiosks and mobile guidance for connected spaces.",
            footer: "Live experiments in daily context"
          }
        }
      },
      method: {
        heading: "Transversal methodological frameworks",
        text: "Our frameworks merge physical infrastructures and information layers: from immediate legibility to immersive assistance.",
        items: {
          1: {
            title: "Legibility matrices",
            text: "Grids evaluating spatial comprehension by angle, signage, light and decision density."
          },
          2: {
            title: "Narrative maps",
            text: "Chronological representations of user journeys enriched with verbatim and occupancy metrics."
          },
          3: {
            title: "Adaptation scripts",
            text: "Scenarios enabling digital media to adjust to time, language and user profiles."
          }
        }
      },
      recommendations: {
        heading: "Guidelines and recommendations",
        text: "Selected lines of work to consolidate informational consistency in indoor public spaces.",
        items: {
          1: {
            title: "Align architecture and data",
            text: "Cross architectural drawings and field knowledge to keep physical signage and digital channels coherent.",
            alt: "Architectural scheme layered with pedestrian flows"
          },
          2: {
            title: "Structure multilingual journeys",
            text: "Plan translations from the outset to preserve visual hierarchy and simultaneous comprehension.",
            alt: "Multilingual interface on a touch totem"
          },
          3: {
            title: "Monitor actual use",
            text: "Set iterative reviews to feed user feedback into signage updates.",
            alt: "Collaborative team evaluating an interactive map"
          }
        }
      },
      testimonials: {
        heading: "Peer testimonies",
        text: "Public institutions, urban agencies and cultural venues rely on our programmes to enhance spatial accessibility.",
        items: {
          1: {
            quote: "Workshops reframed how we observe pedestrian flows and clarified the building narrative for our mediation teams.",
            name: "Anne-Sophie Vermeer",
            role: "Museum coordination, Brussels"
          },
          2: {
            quote: "The bilingual structure now keeps our terminals aligned and simplifies contextual announcements.",
            name: "Hugo De Waele",
            role: "Urban mobility supervision, Flanders"
          },
          3: {
            quote: "Narrative mapping informs our event hosting with a precise view of friction points.",
            name: "Leïla Brankaert",
            role: "Event flow management, Liège"
          }
        }
      },
      insights: {
        heading: "Latest insights",
        text: "In-depth studies on digital signage, flow mapping and hybrid environments."
      }
    },
    blog: {
      hero: {
        badge: "Field log",
        title: "Analyses and case studies",
        subtitle: "Detailed documentation on indoor navigation, visual information and the spatial experience of built environments."
      },
      cards: {
        post1: {
          date: "12 September 2024",
          category: "Indoor navigation",
          title: "Mapping cognitive anchors within public buildings",
          excerpt: "Identifying memory cues and aligning physical signage with digital interfaces without overwhelming visitors.",
          alt: "View of a public hall with colorful cues"
        },
        post2: {
          date: "26 August 2024",
          category: "Digital signage",
          title: "Synchronising dynamic displays with rail flows",
          excerpt: "Systemic approach to orchestrate real-time messages, directional cues and contextual information across Belgian hubs.",
          alt: "Information screens inside a modern station"
        },
        post3: {
          date: "7 August 2024",
          category: "Pedestrian mobility",
          title: "Pedestrian data and collaborative spatial mock-ups",
          excerpt: "Combining density metrics and narrative mapping to prioritise orientation adjustments.",
          alt: "Interactive plan analysed by a working group"
        },
        post4: {
          date: "17 July 2024",
          category: "Information design",
          title: "Visual contrast and continuity across complex routes",
          excerpt: "Assessing light, colours and type to reinforce corridor legibility.",
          alt: "Bright corridor with directional signage"
        },
        post5: {
          date: "24 June 2024",
          category: "User experience",
          title: "In situ evaluation methods for wayfinding systems",
          excerpt: "Observation frameworks to test digital prototypes and physical supports.",
          alt: "Observation of a user at an interactive totem"
        }
      }
    },
    services: {
      hero: {
        badge: "Fields of work",
        title: "Applied research streams",
        subtitle: "We combine field exploration, modelling and information design to support spatial orientation projects."
      },
      sections: {
        1: {
          title: "Pathway and flow analysis",
          text: "Dense-environment circulation studies to understand decisions, hesitation points and temporal rhythms.",
          points: {
            1: "Multi-period behavioural mapping",
            2: "Detection of confusion nodes and thresholds",
            3: "Scenario-based synthesis of trajectories"
          }
        },
        2: {
          title: "Digital signage and visual guidance",
          text: "Directional programmes merging dynamic media, layered signage and coherent messaging.",
          points: {
            1: "Inventory of existing supports and hierarchies",
            2: "Context-aware interface prototyping",
            3: "Maintenance and update protocols"
          }
        },
        3: {
          title: "Interactive mapping",
          text: "Immersive plans and geospatial datasets to make indoor networks and urban connections understandable.",
          points: {
            1: "2D/3D modelling with usage layers",
            2: "Bilingual thematic filters",
            3: "Usability testing and comprehension metrics"
          }
        },
        4: {
          title: "Information design and accessibility",
          text: "Content and visual language structuring for diverse audiences, including international users and specific needs.",
          points: {
            1: "Multilingual typographic hierarchies",
            2: "Contrast and accessibility audits",
            3: "Operational deployment guides"
          }
        },
        5: {
          title: "Pedestrian mobility research",
          text: "Production of benchmarks and feedback to feed public strategies and hybrid projects.",
          points: {
            1: "Cross-disciplinary state of the art",
            2: "Benchmark of complex environments",
            3: "Longitudinal tracking of usage"
          }
        }
      },
      framework: {
        title: "Modular process",
        text: "Deliverables match design cycles to ease the integration of orientation decisions.",
        items: {
          1: {
            title: "Preliminary diagnosis",
            text: "Immersion, surveys and interviews with on-site teams to calibrate spatial assumptions."
          },
          2: {
            title: "Cartographic iterations",
            text: "Iterative exchanges between digital plans and physical cues to retain global coherence."
          },
          3: {
            title: "Method transfer",
            text: "Pedagogical documentation empowering teams to evolve the wayfinding system."
          }
        }
      }
    },
    about: {
      hero: {
        badge: "Reading places",
        title: "A cell dedicated to spatial legibility",
        subtitle: "We interlace urban planning, information science and interface design to clarify public environments."
      },
      sections: {
        1: {
          title: "Approach",
          text: "We observe the act of moving: real uses, encounters with the built environment and orientation devices."
        },
        2: {
          title: "Applied research",
          text: "Each assignment fuels a knowledge base on how users build spatial anchors within constrained spaces."
        },
        3: {
          title: "Transmission",
          text: "Publications, workshops and guides share reproducible methods with Belgian public actors."
        }
      },
      timeline: {
        title: "Key milestones",
        text: "Some turning points that shaped our collaborative approach.",
        items: {
          1: "2016: First flow explorations at Botanique station with evolving cartographies.",
          2: "2018: Bilingual assessment protocol for a Brussels university campus.",
          3: "2020: Deployment of digital navigation mock-ups in two public hospitals.",
          4: "2023: Launch of a mobile lab for testing temporary signage supports."
        }
      },
      network: {
        title: "Cooperation network",
        text: "We partner with complementary specialists to refine our analyses.",
        items: {
          1: {
            title: "Acoustics",
            text: "Characterising sound environments that influence vocal cues perception."
          },
          2: {
            title: "Urban sociology",
            text: "Understanding how audiences adopt places and create singular routes."
          },
          3: {
            title: "Data design",
            text: "Transforming spatial data into actionable representations for decision-makers."
          }
        }
      }
    },
    faq: {
      hero: {
        badge: "Practical orientation",
        title: "Frequent questions",
        subtitle: "Answers drawn from our collaboration with Belgian infrastructures."
      },
      items: {
        1: {
          question: "How do you start analysing a site?",
          answer: "By immersing on location, observing pathways, reviewing available plans and meeting frontline teams."
        },
        2: {
          question: "Do you handle multiple languages?",
          answer: "Yes, every prototype is conceived for French/English parity and can be extended when needed."
        },
        3: {
          question: "Which data do you collect?",
          answer: "Anonymous flow measurements, qualitative feedback and contextual indicators such as waiting times."
        },
        4: {
          question: "Do you offer training sessions?",
          answer: "Thematic workshops help internal teams maintain and evolve guidance systems."
        },
        5: {
          question: "Do you observe spaces while in operation?",
          answer: "Yes, our protocols are designed to coexist with daily public usage."
        },
        6: {
          question: "How is impact evaluated?",
          answer: "Through cross reviews combining quantitative metrics, user feedback and cartographic adjustments."
        }
      },
      notice: "For specific topics, please share context via the contact form."
    },
    contact: {
      hero: {
        badge: "Get in touch",
        title: "Discuss your spatial orientation context",
        subtitle: "Let’s exchange on legibility, accessibility and digital navigation challenges."
      },
      info: {
        title: "Direct details",
        text: "We answer institutional, associative and academic requests dealing with complex environments.",
        phone: "Call us: +32 2 123 45 67",
        email: "Write: contact@danswholesaleplants.com",
        notice: "Please outline the site, target audience and timeline expectations."
      },
      form: {
        title: "Contact form",
        description: "Fields marked with an asterisk are required to arrange an initial exchange.",
        fields: {
          name: { label: "Full name *", placeholder: "Your name" },
          email: { label: "Email address *", placeholder: "email@example.com" },
          organisation: { label: "Organisation", placeholder: "Structure or project" },
          message: { label: "Message *", placeholder: "Describe the spatial context and needs" }
        },
        notice: "Provided information is used solely to reply to your request. No mailing list is created.",
        submit: "Submit to thank you"
      },
      map: {
        title: "Brussels location",
        caption: "Situated near Brussels Park with access to main transit lines."
      }
    },
    cookie: {
      title: "Cookie management",
      description: "We use essential cookies for core features and optional preferences to enhance the experience.",
      manage: "Manage preferences",
      decline: "Decline all except essential",
      save: "Save selection",
      accept: "Accept all",
      categories: {
        necessary: {
          title: "Necessary (always on)",
          text: "Ensure security, language memory and base operations."
        },
        preferences: {
          title: "Preferences",
          text: "Store your display choices and visited sections."
        },
        analytics: {
          title: "Analytics",
          text: "Measure aggregated audience data to improve content."
        },
        marketing: {
          title: "Contextual",
          text: "Adapt the presentation of references and publications."
        }
      }
    },
    toast: {
      languageChanged: "Language switched to English.",
      cookiesAccepted: "Preferences saved: all cookies enabled.",
      cookiesDeclined: "Preferences saved: only essential cookies remain active.",
      cookiesSaved: "Cookie selection updated.",
      formSubmitted: "Thank you, redirecting to the confirmation page."
    },
    meta: {
      title: {
        home: "danswholesaleplants · Spatial orientation and digital signage",
        services: "Workstreams · danswholesaleplants",
        about: "About · danswholesaleplants",
        blog: "Insights and research · danswholesaleplants",
        post1: "Cognitive anchors in public buildings · danswholesaleplants",
        post2: "Dynamic displays and rail flows · danswholesaleplants",
        post3: "Pedestrian data and collaborative mock-ups · danswholesaleplants",
        post4: "Visual contrast across complex routes · danswholesaleplants",
        post5: "In situ evaluation of wayfinding systems · danswholesaleplants",
        contact: "Contact · danswholesaleplants",
        faq: "Frequently asked questions · danswholesaleplants",
        terms: "Terms of use · danswholesaleplants",
        privacy: "Privacy policy · danswholesaleplants",
        cookies: "Cookie policy · danswholesaleplants",
        refund: "Return policy · danswholesaleplants",
        disclaimer: "Disclaimer · danswholesaleplants",
        thank: "Thank you · danswholesaleplants",
        notFound: "Page not found · danswholesaleplants"
      },
      description: {
        home: "Belgian platform dedicated to spatial orientation, digital signage and mapping within complex environments.",
        services: "Overview of applied research streams: pathways, digital signage, interactive mapping, accessibility and pedestrian mobility.",
        about: "History, methodologies and partnerships of danswholesaleplants towards spatial legibility.",
        blog: "Field analyses on indoor navigation, visual information and pedestrian mobility.",
        post1: "Deep dive into cognitive anchors to guide visitors across public buildings.",
        post2: "Synchronising digital displays with railway flows in Belgian hubs.",
        post3: "Collaborative mock-ups and pedestrian datasets to adjust complex journeys.",
        post4: "Visual contrasts and continuity across ramified architectures.",
        post5: "On-site evaluation methods for orientation devices and digital signage.",
        contact: "Contact details, form and Brussels location of danswholesaleplants.",
        faq: "Answers to frequent questions about spatial orientation and digital signage.",
        terms: "Terms governing access to danswholesaleplants content.",
        privacy: "Confidentiality policy regarding processed data.",
        cookies: "Detailed cookie policy for danswholesaleplants.",
        refund: "Return and revision policy of danswholesaleplants.",
        disclaimer: "Disclaimer for materials published by danswholesaleplants.",
        thank: "Confirmation that the contact form was submitted.",
        notFound: "Requested page was not found on danswholesaleplants."
      }
    },
    thank: {
      badge: "Message received",
      title: "Thank you for your submission",
      message: "We review your message and will come back with initial orientation proposals.",
      backHome: "Go back home",
      exploreBlog: "Browse insights"
    },
    notFound: {
      badge: "Error 404",
      title: "Page not found",
      message: "The content you are looking for is no longer available. Use the navigation to continue exploring.",
      backHome: "Back to homepage",
      contact: "Contact the team"
    },
    terms: {
      title: "Terms of use",
      intro: "These terms regulate access to danswholesaleplants.com and its informational materials.",
      section01: {
        title: "Purpose",
        content: "<p>The site shares resources about spatial orientation and digital signage. No commercial contract is offered.</p>"
      },
      section02: {
        title: "Access",
        content: "<p>Access is free. Users remain responsible for their devices and internet connection.</p>"
      },
      section03: {
        title: "Intellectual property",
        content: "<p>Content is protected. Any reproduction requires prior permission.</p>"
      },
      section04: {
        title: "Use of content",
        content: "<p>Information is provided as documentation. Any reuse must credit the source and preserve integrity.</p>"
      },
      section05: {
        title: "External contributions",
        content: "<p>Testimonials or quotes are published with explicit approval from their authors.</p>"
      },
      section06: {
        title: "Liability",
        content: "<p>We strive for reliable information without guaranteeing completeness.</p>"
      },
      section07: {
        title: "Hyperlinks",
        content: "<p>Outbound links are offered for further reading. We are not responsible for their content.</p>"
      },
      section08: {
        title: "Availability",
        content: "<p>The site may be suspended for maintenance without notice. Interruptions are kept as short as possible.</p>"
      },
      section09: {
        title: "Security",
        content: "<p>Reasonable measures secure access yet zero risk cannot be guaranteed.</p>"
      },
      section10: {
        title: "Personal data",
        content: "<p>Messages sent through the form are processed according to the privacy policy.</p>"
      },
      section11: {
        title: "Languages",
        content: "<p>Content is available in French and English. The French version prevails if discrepancies arise.</p>"
      },
      section12: {
        title: "Updates",
        content: "<p>Terms may evolve. The update date is displayed in the footer.</p>"
      },
      section13: {
        title: "Applicable law",
        content: "<p>Belgian law applies. Any dispute falls under Brussels jurisdiction.</p>"
      },
      section14: {
        title: "Contact",
        content: "<p>For any questions, use the contact details provided on the Contact page.</p>"
      }
    },
    privacy: {
      title: "Privacy policy",
      intro: "This policy explains which data is collected and how it is protected.",
      section1: {
        title: "General principles",
        content: "<p>We only collect information necessary to process messages received through the form.</p>"
      },
      section2: {
        title: "Data collected",
        content: "<p>Name, email address, organisation and message. No sensitive data is requested.</p>"
      },
      section3: {
        title: "Legal basis",
        content: "<p>Processing relies on the legitimate interest of answering professional requests.</p>"
      },
      section4: {
        title: "Retention",
        content: "<p>Messages are kept up to twelve months unless a follow-up is explicitly agreed.</p>"
      },
      section5: {
        title: "Recipients",
        content: "<p>Only the team members in charge of follow-up have access to the messages.</p>"
      },
      section6: {
        title: "Security",
        content: "<p>Technical and organisational measures limit unauthorised access to data.</p>"
      },
      section7: {
        title: "Rights",
        content: "<p>You may exercise rights of access, rectification, erasure and restriction. Contact us to proceed.</p>"
      },
      section8: {
        title: "Processors",
        content: "<p>We rely on hosting infrastructure located within the European Union.</p>"
      },
      section9: {
        title: "Cookies",
        content: "<p>Cookie management is detailed in the dedicated policy.</p>"
      },
      section10: {
        title: "Updates",
        content: "<p>This policy may change. The current version is displayed on this page.</p>"
      }
    },
    cookiesPage: {
      title: "Cookie policy",
      intro: "This document lists the cookies used on danswholesaleplants.com.",
      section1: {
        title: "Definition",
        content: "<p>A cookie is a small text file stored on your device to support navigation.</p>"
      },
      section2: {
        title: "Settings",
        content: "<p>You can adjust your preferences through the banner or your browser.</p>"
      },
      section3: {
        title: "Summary table",
        content: "<p>The table below describes the cookies that may be placed.</p>"
      },
      table: {
        name: "Name",
        provider: "Provider",
        type: "Type",
        purpose: "Purpose",
        duration: "Duration",
        rows: {
          1: {
            name: "site_lang",
            provider: "danswholesaleplants",
            type: "Preference",
            purpose: "Stores the selected language.",
            duration: "12 months"
          },
          2: {
            name: "cookie_consent",
            provider: "danswholesaleplants",
            type: "Essential",
            purpose: "Saves consent choices.",
            duration: "12 months"
          },
          3: {
            name: "session_view",
            provider: "danswholesaleplants",
            type: "Essential",
            purpose: "Ensures session security.",
            duration: "Session"
          },
          4: {
            name: "analytics_view",
            provider: "danswholesaleplants",
            type: "Analytics",
            purpose: "Measures aggregated audience.",
            duration: "6 months"
          }
        }
      }
    },
    refund: {
      title: "Return and revision policy",
      intro: "Site materials are informational. This policy explains how correction requests are handled.",
      section1: {
        title: "Scope",
        content: "<p>The policy applies to publications and documents made available on the site.</p>"
      },
      section2: {
        title: "Correction requests",
        content: "<p>You may report inaccurate information via the contact form with full details.</p>"
      },
      section3: {
        title: "Processing time",
        content: "<p>Requests are reviewed within thirty working days.</p>"
      },
      section4: {
        title: "Content revisions",
        content: "<p>If a correction is relevant, the publication is updated and date-stamped.</p>"
      },
      section5: {
        title: "No financial refund",
        content: "<p>The site offers no paid service. No financial refund applies.</p>"
      },
      section6: {
        title: "Archiving",
        content: "<p>Past versions may be stored for traceability.</p>"
      },
      section7: {
        title: "Communication",
        content: "<p>We inform the requester of the decision taken.</p>"
      },
      section8: {
        title: "Special cases",
        content: "<p>Content produced with partners is revised jointly.</p>"
      },
      section9: {
        title: "Limitations",
        content: "<p>Opinions or interpretations are not modified unless a factual error is confirmed.</p>"
      },
      section10: {
        title: "Contact",
        content: "<p>Use the Contact page for any question about this policy.</p>"
      }
    },
    disclaimer: {
      title: "Disclaimer",
      intro: "Information is provided for documentation purposes only.",
      section1: {
        title: "No guarantee",
        content: "<p>We do not guarantee exhaustive or permanent accuracy of content.</p>"
      },
      section2: {
        title: "Autonomous use",
        content: "<p>Readers remain responsible for interpreting the analyses presented.</p>"
      },
      section3: {
        title: "External references",
        content: "<p>Links do not imply endorsement of external resources.</p>"
      },
      section4: {
        title: "Updates",
        content: "<p>Information can change without notice to reflect new observations.</p>"
      },
      section5: {
        title: "No contractual relation",
        content: "<p>Visiting the site does not create any contract between the user and danswholesaleplants.</p>"
      },
      section6: {
        title: "Contact",
        content: "<p>For clarifications, submit a request via the Contact page.</p>"
      }
    },
    thank: {
      badge: "Message received",
      title: "Thank you for your submission",
      message: "We review your message and will come back with initial orientation proposals.",
      backHome: "Go back home",
      exploreBlog: "Browse insights"
    },
    notFound: {
      badge: "Error 404",
      title: "Page not found",
      message: "The page you requested is no longer available. Use the navigation to keep exploring.",
      backHome: "Back to homepage",
      contact: "Contact the team"
    },
    post1: {
      badge: "In-depth analysis",
      title: "Mapping cognitive anchors within public buildings",
      meta: "Indoor navigation · 12 September 2024",
      section1: {
        title: "Understanding spatial memory",
        content: "<p>Inside public buildings, initial orientation relies on users spotting clear cognitive anchors: major volumes, vertical openings, specific light or colour cues. When these anchors are diffuse, visitors adopt secondary strategies—following dominant flows, reading textual signage, trusting iconography. We carried out in situ observation sessions to capture primary visual fixations across profiles. Findings show that anchor hierarchies are never homogeneous: a luminous ticketing area may work as a pivot for some, while others memorise a mural or a change in materials.</p><p>In parallel we audited existing devices. Static maps, often located on ground floors, mostly confirm a route rather than initiate exploration. Suspended signs lacking contrast are rarely retained. The space therefore becomes a visual narrative: every element must be designed for actual perception, not only for physical presence.</p>"
      },
      section2: {
        title: "Hierarchy between physical and digital supports",
        content: "<p>Stacking heterogeneous supports can generate informational noise. Our hierarchy method documents the real function of each medium: to signal, to confirm, to reassure. Dynamic screens, for instance, are seldom seen as wayfinding tools if placed after the decision point. They become relevant when showing simple scenarios with a maximum of three contextual options. Conversely, wall-mounted plates act as fixed anchors. They benefit from using the same nomenclature as digital interfaces to prevent terminological gaps.</p><p>We therefore suggest identifying a limited set of primary supports and reserving other formats for narrative add-ons. The goal is not to multiply sources but to align visual and textual languages throughout the journey.</p>"
      },
      section3: {
        title: "Benefits of combined cartography",
        content: "<p>Beyond blending architectural drawings and conventional maps, we created hybrid layers: simplified backgrounds, colour codes by space families, pictograms from the same library as signage. When such maps appear on interactive totems they must remain lightweight to avoid overload. Progressive zoom lets users shift from macro (how to reach a wing) to micro (which corridor to take). Interviewed visitors retain information better when they can sequentially visualise both scales.</p><p>Keeping maps and physical anchors coherent relies on an update protocol: every spatial change triggers cross-checks. Without that follow-up, the system loses credibility and users revert to more random strategies.</p>"
      },
      section4: {
        title: "Towards a fluid multimodal experience",
        content: "<p>Physical anchors, digital cues and human interaction (front-desk teams) must operate as a single device. We advocate for journey scripts merging these dimensions: upon arrival the visitor receives a QR code opening a personalised map aligned with physical signage and vocal announcements. Each channel points to the same milestones. This limits confusion, especially for international or occasional visitors.</p><p>Ultimately, mapping cognitive anchors means treating buildings as media. Analysis extends beyond producing a plan; it embraces the lived experience. The challenge is orchestrating physical and digital cues so everyone can craft a personal storyline while staying within collective coherence.</p>"
      }
    },
    post2: {
      badge: "Field notebook",
      title: "Synchronising dynamic displays with rail flows",
      meta: "Digital signage · 26 August 2024",
      section1: {
        title: "Observing the information chain",
        content: "<p>In Belgian stations, information circulates across schedule databases, alerts, vocal announcements and directional signage. When links desynchronise, travellers compensate by following crowds, asking staff, watching multiple screens. We mapped this chain and measured propagation times between the source (traffic management software) and visible supports.</p><p>Some comfort signage screens (platform layouts, bus orientation) were not receiving real-time updates. They still showed static content whereas travellers expected adaptive cues. The first step is establishing priorities: which information must update simultaneously and which can remain stable.</p>"
      },
      section2: {
        title: "Building a narrative structure",
        content: "<p>We segment information into three layers. Layer one covers safety and critical alerts: it overrides any screen content. Layer two handles journey fluidity: when a platform changes, directional cues must shift without delay. Layer three is contextual (services, advice). This hierarchy translates into technical requirements for software architecture and visual rules for displays.</p><p>Voice announcements reuse the same terminology as screens. Tests show that linguistic coherence between spoken and displayed messages boosts reassurance and reduces crowd dispersion.</p>"
      },
      section3: {
        title: "Impact on pedestrian flows",
        content: "<p>Anonymous video tracking before and after synchronisation reveals fewer hesitation zones when screens offer clear directional schemes paired with colour reminders on static signage.</p><p>Simultaneous updates avoid counterflows: travellers no longer backtrack. Distribution improves in stations with multiple exits because information guides towards every available option, not only the main corridor.</p>"
      },
      section4: {
        title: "Operational recommendations",
        content: "<p>A dashboard lets operations teams monitor channel status and trigger manual refresh when data changes sharply. The multilingual vocabulary used on screens is shared with onsite staff to align voice announcements. Regular tests with occasional users (tourists, infrequent travellers) serve as a barometer to verify legibility.</p><p>The success of dynamic signage therefore lies less in technology than in its ability to orchestrate flows and maintain narrative coherence across channels.</p>"
      }
    },
    post3: {
      badge: "Collaborative study",
      title: "Pedestrian data and collaborative spatial mock-ups",
      meta: "Pedestrian mobility · 7 August 2024",
      section1: {
        title: "Collecting and sharing data",
        content: "<p>Pedestrian datasets are often fragmented. We set up a shared protocol: anonymous counters, on-site surveys capturing motives, punctual video observation to analyse gestures. Data is stored in a standard format for overlay within a digital mock-up.</p><p>Workshops gather planners, site managers, safety coordinators and mediators. Participants manipulate layers, view density per time slot, and annotate risk zones or unexpected patterns.</p>"
      },
      section2: {
        title: "From data to action",
        content: "<p>Transforming data into decisions requires accessible indicators: average crossing time, recurring stops, aggregation areas. Indicators appear as charts linked to the mock-up. When a corridor shows longer crossing times, one click reveals related video segments to understand causes (missing signage, ambiguous decision point, lack of light).</p><p>The mock-up becomes a dialogue tool: every metric is enriched with qualitative feedback gathered from users.</p>"
      },
      section3: {
        title: "Including citizens’ input",
        content: "<p>Open sessions invite user representatives (reduced-mobility persons, international audiences, welcome teams) to manipulate the mock-up. They can submit annotations visible to all, ensuring valuable intuition is not lost. Participation builds a shared understanding and surfaces needs absent from raw data (stressful areas, symbolic anchors).</p><p>Comments are coded and fed into decision-making so each adjustment stems from both data and lived experience.</p>"
      },
      section4: {
        title: "Monitoring evolution",
        content: "<p>The mock-up is updated quarterly and indicators compared. We observe the effect of modifications: new signage, alternative access, hall reconfiguration. If results differ from objectives, stakeholders debate corrective options or revisit scenarios.</p><p>This collaborative device nurtures continuous improvement. Complex public spaces become more legible because actors share a common language rooted in a collective representation of pedestrian flows.</p>"
      }
    },
    post4: {
      badge: "Information design",
      title: "Visual contrast and continuity across complex routes",
      meta: "Information design · 17 July 2024",
      section1: {
        title: "Measuring current contrasts",
        content: "<p>In ramified architectures, colour, light and texture contrasts drive directional perception. We ran measurements (lux meter, calibrated photos) to evaluate transitions. Some corridors showed contrast gaps making signage invisible to low-vision users.</p><p>Redefining a colour palette aligned with accessibility standards is the first action. Contrast ratios above 4.5:1 between background and type ensure readability.</p>"
      },
      section2: {
        title: "Narrative continuity",
        content: "<p>Each route is a succession of micro-decisions. Consistency is key: we assign every area a colour, shape and symbol. Continuity avoids ruptures—blue corridor leading to blue destination with the same icon fosters confidence. Colour shifts signal intentional branching.</p><p>Digital displays replicate identical codes to prevent dissonance.</p>"
      },
      section3: {
        title: "Prototyping on site",
        content: "<p>Pilot segments are fitted with adjustable light bands to tweak contrast live. Quick surveys and mobile eye-tracking capture results. Decision time drops by 18% when contrast is optimised and symbols echo across media.</p><p>Data helps prioritise areas with highest benefit from contrast upgrades.</p>"
      },
      section4: {
        title: "Maintenance and evolution",
        content: "<p>Contrast is dynamic. Material wear or lighting changes may alter results. We recommend semi-annual checks during maintenance operations. Technical sheets specify desired contrast values for each zone so teams can react swiftly.</p><p>Preventive management ensures continuous legibility even as infrastructures evolve.</p>"
      }
    },
    post5: {
      badge: "Experiment feedback",
      title: "In situ evaluation methods for wayfinding systems",
      meta: "User experience · 24 June 2024",
      section1: {
        title: "Setting up an observation protocol",
        content: "<p>Evaluation combines discrete observation, self-confrontation and travel-time tracking. Sessions start with users testing a defined itinerary. We log stops, backtracking and interactions with supports. Behavioural cartography reveals doubt zones and points of attention.</p><p>Short interviews follow to understand the reasoning behind each decision. Qualitative insights enrich quantitative data.</p>"
      },
      section2: {
        title: "Measuring comprehension",
        content: "<p>Performance is not just about speed but also confidence. We hand out sketch maps to fill after the journey. Users redraw memorable steps, showing key or forgotten elements. We analyse vocabulary to detect mismatches between visitors’ wording and signage. Lexical gaps indicate adjustments.</p><p>For digital devices, interaction logs (touchpoints, menu navigation) highlight whether information levels are well balanced.</p>"
      },
      section3: {
        title: "Assessing over time",
        content: "<p>Success is tracked beyond launch through follow-ups at one, three and six months. This checks whether comprehension endures. Feedback from staff answers recurrent questions and remaining difficulties.</p><p>Longitudinal view distinguishes cases needing minor tweaks (pictogram added) from those requiring deeper redesign.</p>"
      },
      section4: {
        title: "Sharing learnings",
        content: "<p>Results feed accessible documentation for stakeholders: maps of attention points, action sheets, short videos. Everyone can internalise lessons and inject them into daily practices.</p><p>In situ evaluation thus becomes a driver for ongoing alignment between physical supports, digital media and human interaction.</p>"
      }
    },
    toast: {
      languageChanged: "Language switched to English.",
      cookiesAccepted: "Preferences saved: all cookies enabled.",
      cookiesDeclined: "Preferences saved: only essential cookies remain active.",
      cookiesSaved: "Cookie selection updated.",
      formSubmitted: "Thank you, redirecting to the confirmation page."
    }
  }
};

let currentLanguage = DEFAULT_LANG;
const dynamicValues = { year: new Date().getFullYear() };

function getTranslation(lang, key) {
  const parts = key.split(".");
  let value = I18N[lang];
  for (const part of parts) {
    if (value && Object.prototype.hasOwnProperty.call(value, part)) {
      value = value[part];
    } else {
      return undefined;
    }
  }
  return value;
}

function insertDynamicValues(text) {
  return typeof text === "string"
    ? text.replace(/\{(\w+)\}/g, (match, token) => (token in dynamicValues ? dynamicValues[token] : match))
    : text;
}

function applyTranslations() {
  document.documentElement.setAttribute("lang", currentLanguage);
  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.getAttribute("data-i18n");
    const translation = getTranslation(currentLanguage, key);
    if (translation !== undefined) {
      element.textContent = insertDynamicValues(translation);
    }
  });
  document.querySelectorAll("[data-i18n-html]").forEach((element) => {
    const key = element.getAttribute("data-i18n-html");
    const translation = getTranslation(currentLanguage, key);
    if (translation !== undefined) {
      element.innerHTML = insertDynamicValues(translation);
    }
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
    const key = element.getAttribute("data-i18n-placeholder");
    const translation = getTranslation(currentLanguage, key);
    if (translation !== undefined) {
      element.setAttribute("placeholder", insertDynamicValues(translation));
    }
  });
  document.querySelectorAll("[data-i18n-alt]").forEach((element) => {
    const key = element.getAttribute("data-i18n-alt");
    const translation = getTranslation(currentLanguage, key);
    if (translation !== undefined) {
      element.setAttribute("alt", insertDynamicValues(translation));
    }
  });
  document.querySelectorAll("[data-i18n-title]").forEach((element) => {
    const key = element.getAttribute("data-i18n-title");
    const translation = getTranslation(currentLanguage, key);
    if (translation !== undefined) {
      if (element.tagName.toLowerCase() === "title") {
        element.textContent = insertDynamicValues(translation);
      } else {
        element.setAttribute("title", insertDynamicValues(translation));
      }
    }
  });
  document.querySelectorAll("[data-i18n-meta]").forEach((element) => {
    const key = element.getAttribute("data-i18n-meta");
    const translation = getTranslation(currentLanguage, key);
    if (translation !== undefined) {
      element.setAttribute("content", insertDynamicValues(translation));
    }
  });
  updateLanguageButtons();
}

function updateLanguageButtons() {
  document.querySelectorAll("[data-language-toggle]").forEach((button) => {
    const lang = button.getAttribute("data-language-toggle");
    button.classList.toggle("is-active", lang === currentLanguage);
  });
}

function setLanguage(lang) {
  if (!I18N[lang]) return;
  currentLanguage = lang;
  localStorage.setItem(LANG_STORAGE_KEY, lang);
  applyTranslations();
  showToast("toast.languageChanged");
}

function initLanguage() {
  const stored = localStorage.getItem(LANG_STORAGE_KEY);
  if (stored && I18N[stored]) {
    currentLanguage = stored;
  } else {
    currentLanguage = DEFAULT_LANG;
  }
  applyTranslations();
}

const consentDefault = {
  necessary: true,
  preferences: false,
  analytics: false,
  marketing: false
};

let consentState = { ...consentDefault };

function loadConsent() {
  try {
    const saved = JSON.parse(localStorage.getItem(COOKIE_STORAGE_KEY));
    if (saved && typeof saved === "object") {
      consentState = { ...consentDefault, ...saved };
    }
  } catch (error) {
    consentState = { ...consentDefault };
  }
}

function storeConsent() {
  localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify(consentState));
}

function updateConsentUI() {
  document.querySelectorAll("[data-cookie-checkbox]").forEach((checkbox) => {
    const key = checkbox.getAttribute("data-cookie-checkbox");
    checkbox.checked = !!consentState[key];
  });
}

function showCookieBanner(force = false) {
  const banner = document.querySelector("[data-cookie-banner]");
  if (!banner) return;
  if (force || !localStorage.getItem(COOKIE_STORAGE_KEY)) {
    banner.classList.add("is-visible");
  } else {
    banner.classList.remove("is-visible");
  }
}

function hideCookieBanner() {
  const banner = document.querySelector("[data-cookie-banner]");
  if (banner) banner.classList.remove("is-visible");
}

function acceptAllCookies() {
  consentState = { necessary: true, preferences: true, analytics: true, marketing: true };
  storeConsent();
  updateConsentUI();
  hideCookieBanner();
  showToast("toast.cookiesAccepted");
}

function declineAllCookies() {
  consentState = { ...consentDefault };
  storeConsent();
  updateConsentUI();
  hideCookieBanner();
  showToast("toast.cookiesDeclined");
}

function saveCookiePreferences() {
  storeConsent();
  hideCookieBanner();
  showToast("toast.cookiesSaved");
}

function toggleCookiePreferences() {
  const container = document.querySelector("[data-cookie-preferences]");
  if (container) {
    container.classList.toggle("is-open");
  }
}

function initCookieControls() {
  loadConsent();
  updateConsentUI();
  showCookieBanner();
  document.querySelectorAll("[data-cookie-checkbox]").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      const key = checkbox.getAttribute("data-cookie-checkbox");
      consentState[key] = checkbox.checked;
      storeConsent();
    });
  });
  const acceptButton = document.querySelector("[data-cookie-accept]");
  const declineButton = document.querySelector("[data-cookie-decline]");
  const saveButton = document.querySelector("[data-cookie-save]");
  const manageButton = document.querySelector("[data-cookie-manage]");
  if (acceptButton) acceptButton.addEventListener("click", acceptAllCookies);
  if (declineButton) declineButton.addEventListener("click", declineAllCookies);
  if (saveButton) saveButton.addEventListener("click", saveCookiePreferences);
  if (manageButton) manageButton.addEventListener("click", toggleCookiePreferences);
}

function showToast(key) {
  const container = document.querySelector("[data-toast-container]");
  if (!container) return;
  const translation = getTranslation(currentLanguage, key);
  if (!translation) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = insertDynamicValues(translation);
  container.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.add("visible");
  });
  setTimeout(() => {
    toast.classList.remove("visible");
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

function initNavToggle() {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const nav = document.querySelector("[data-main-nav]");
  if (!navToggle || !nav) return;
  navToggle.addEventListener("click", () => {
    const expanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", String(!expanded));
    navToggle.classList.toggle("is-open", !expanded);
    nav.classList.toggle("is-open", !expanded);
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navToggle.setAttribute("aria-expanded", "false");
      navToggle.classList.remove("is-open");
      nav.classList.remove("is-open");
    });
  });
}

function initLanguageSwitcher() {
  document.querySelectorAll("[data-language-toggle]").forEach((button) => {
    button.addEventListener("click", () => {
      const lang = button.getAttribute("data-language-toggle");
      if (lang !== currentLanguage) {
        setLanguage(lang);
      }
    });
  });
}

function initFadeIn() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll(".fade-in").forEach((element) => observer.observe(element));
}

function initForms() {
  document.querySelectorAll("form[data-has-toast]").forEach((form) => {
    form.addEventListener("submit", () => {
      showToast("toast.formSubmitted");
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initNavToggle();
  initLanguageSwitcher();
  initFadeIn();
  initForms();
  initCookieControls();
});