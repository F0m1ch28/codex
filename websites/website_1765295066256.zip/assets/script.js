document.addEventListener("DOMContentLoaded", () => {
    const banner = document.querySelector(".cookie-banner");
    if (!banner) return;

    const storedChoice = localStorage.getItem("epr-cookie-consent");

    if (!storedChoice) {
        requestAnimationFrame(() => banner.classList.remove("hidden"));
    }

    const handleChoice = (choice) => {
        localStorage.setItem("epr-cookie-consent", choice);
        banner.classList.add("hidden");
    };

    const acceptButton = banner.querySelector('[data-cookie="accept"]');
    const declineButton = banner.querySelector('[data-cookie="decline"]');

    if (acceptButton) {
        acceptButton.addEventListener("click", () => handleChoice("accepted"));
    }
    if (declineButton) {
        declineButton.addEventListener("click", () => handleChoice("declined"));
    }
});