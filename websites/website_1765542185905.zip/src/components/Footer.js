import React from 'react';
import { Link } from 'react-router-dom';
import styles from '../styles/Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.brandColumn}>
        <h2 className={styles.logo}>Joyful<span>Toys</span></h2>
        <p>Brightening Dutch playrooms with safe, imaginative toys that grow with every child’s curiosity.</p>
        <p className={styles.copyright}>© {new Date().getFullYear()} Joyful Toys. All rights reserved.</p>
      </div>
      <div className={styles.column}>
        <h3>Explore</h3>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/products">Our Toys</Link></li>
          <li><Link to="/guide">Toy Buying Guide</Link></li>
          <li><Link to="/blog">Playful Insights</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Company</h3>
        <ul>
          <li><Link to="/about">Our Story</Link></li>
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/privacy">Privacy Policy</Link></li>
          <li><Link to="/terms">Terms of Service</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3>Stay in Touch</h3>
        <ul className={styles.contactList}>
          <li><span className={styles.label}>Email:</span> <a href="mailto:info@joyfultoys.nl">info@joyfultoys.nl</a></li>
          <li><span className={styles.label}>Phone:</span> <a href="tel:+31201234567">+31 20 123 4567</a></li>
          <li><span className={styles.label}>City:</span> Amsterdam, Netherlands</li>
        </ul>
      </div>
    </div>
  </footer>
);

export default Footer;