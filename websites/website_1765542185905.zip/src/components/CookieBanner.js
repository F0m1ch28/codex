import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from '../styles/CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const consent = window.localStorage.getItem('joyfulToysCookieConsent');
      if (!consent) {
        setIsVisible(true);
      }
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('joyfulToysCookieConsent', 'accepted');
    }
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <strong>We use cookies</strong>
        <p>
          Joyful Toys uses cookies to personalise your experience and analyse how our playful community uses the site. Read our{' '}
          <Link to="/cookie-policy">Cookie Policy</Link> to learn more.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Sounds Great!
      </button>
    </div>
  );
};

export default CookieBanner;