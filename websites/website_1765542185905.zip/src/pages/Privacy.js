import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Joyful Toys</title>
      <meta name="description" content="Learn how Joyful Toys collects, uses, and protects your personal data." />
    </Helmet>
    <div className={styles.page}>
      <h1>Privacy Policy</h1>
      <div className={styles.content}>
        <p>
          Joyful Toys respects your privacy and is committed to protecting your personal data. This policy explains what information we collect, how we use it, and the rights you have under relevant data protection laws.
        </p>
        <p>
          We collect personal information you voluntarily provide, such as contact details submitted through forms. We also collect usage data to improve our services. Information is stored securely and accessed only by authorised team members.
        </p>
        <p>
          You have the right to access, update, or delete your data. To exercise these rights or ask questions, email <a href="mailto:info@joyfultoys.nl">info@joyfultoys.nl</a>. We may update this policy periodically to reflect changes in regulations or our practices.
        </p>
      </div>
    </div>
  </>
);

export default Privacy;