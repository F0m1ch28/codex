import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Service | Joyful Toys</title>
      <meta name="description" content="Read the Joyful Toys Terms of Service for information about website use and user responsibilities." />
    </Helmet>
    <div className={styles.page}>
      <h1>Terms of Service</h1>
      <div className={styles.content}>
        <p>
          These Terms of Service govern your use of the Joyful Toys website. By accessing or browsing our site, you agree to these terms and any applicable laws and regulations.
        </p>
        <p>
          Content provided on this site is for informational purposes only. We strive to keep information accurate and current, but we make no warranties, explicit or implied, regarding completeness or reliability.
        </p>
        <p>
          Users agree not to misuse the website, attempt unauthorised access, or engage in any activity that disrupts the platform. Joyful Toys reserves the right to modify these terms at any time. Continued use of the site constitutes acceptance of any changes.
        </p>
        <p>
          For questions about our terms, please contact us at <a href="mailto:info@joyfultoys.nl">info@joyfultoys.nl</a>.
        </p>
      </div>
    </div>
  </>
);

export default Terms;