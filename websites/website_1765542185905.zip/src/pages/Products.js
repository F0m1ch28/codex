import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Products.module.css';

const products = [
  {
    name: 'Rainbow Builder Blocks',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80',
    description: 'Handcrafted beech wood blocks featuring vibrant arches and shapes that inspire architectural storytelling.',
    age: '3 – 6 years',
    category: 'STEM & Building',
    highlights: ['Montessori inspired', 'Sustainably sourced wood', 'Includes storage cotton bag']
  },
  {
    name: 'Discover & Dance Music Set',
    image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=900&q=80',
    description: 'A playful percussion set with maracas, tambourine, and rhythm cards encouraging whole-body movement.',
    age: '2 – 5 years',
    category: 'Music & Movement',
    highlights: ['Non-toxic finish', 'Includes rhythm guide', 'Supports sensory integration']
  },
  {
    name: 'Mini Eco Explorer Pack',
    image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=900&q=80',
    description: 'Field journal, child-friendly binoculars, and observation cards to transform walks into nature quests.',
    age: '5 – 9 years',
    category: 'Outdoor Play',
    highlights: ['Weather-resistant materials', 'Designed in the Netherlands', 'Encourages mindful exploration']
  },
  {
    name: 'Soothing Star Projector',
    image: 'https://images.unsplash.com/photo-1618593219985-9ffb0193f1df?auto=format&fit=crop&w=900&q=80',
    description: 'Create calming bedtime routines with gentle starry skies, soft melodies, and colour-changing lights.',
    age: '0 – 4 years',
    category: 'Mindful Moments',
    highlights: ['Auto shut-off timer', 'Rechargeable battery', 'Breathing exercise guide included']
  },
  {
    name: 'Inventors Circuit Lab',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=900&q=80',
    description: 'Modular circuits with magnetic connectors designed to teach electricity basics through playful challenges.',
    age: '7 – 10 years',
    category: 'STEM & Building',
    highlights: ['20 guided experiments', 'Reusable components', 'Teacher-approved curriculum']
  },
  {
    name: 'Storytime Puppet Friends',
    image: 'https://images.unsplash.com/photo-1549921296-3ec8ff86fcda?auto=format&fit=crop&w=900&q=80',
    description: 'A set of whimsical puppets encouraging expressive storytelling and language development.',
    age: '3 – 8 years',
    category: 'Imaginative Play',
    highlights: ['Soft organic cotton', 'Inclusive character set', 'Comes with story prompts']
  },
  {
    name: 'Balance River Stones',
    image: 'https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=900&q=80',
    description: 'Textured stepping stones with anti-slip surfaces to develop coordination and confidence indoors.',
    age: '3 – 7 years',
    category: 'Movement & Gross Motor',
    highlights: ['Stackable for storage', 'Supports sensory seekers', 'Includes activity poster']
  },
  {
    name: 'Curiosity Coding Cards',
    image: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=900&q=80',
    description: 'Screen-free coding puzzles that boost logical thinking through storytelling and collaborative play.',
    age: '6 – 9 years',
    category: 'STEAM Learning',
    highlights: ['Reusable dry-erase boards', 'Group-friendly challenges', 'Created with Dutch educators']
  }
];

const Products = () => (
  <>
    <Helmet>
      <title>Our Toys | Joyful Toys</title>
      <meta
        name="description"
        content="Explore the Joyful Toys collection of high-quality, developmentally balanced toys curated for children in the Netherlands."
      />
    </Helmet>

    <div className={styles.page}>
      <header className={styles.intro}>
        <span className={styles.kicker}>Our Toys</span>
        <h1>Discover Playful Picks for Every Explorer</h1>
        <p>
          These highlighted products reflect the Joyful Toys philosophy: sustainable materials, thoughtful design, and delightful play value. Use the filters below to explore age ranges, categories, and price comfort levels.
        </p>
      </header>

      <section className={styles.filters} aria-label="Toy filters">
        <div className={styles.filterGroup}>
          <label htmlFor="age-filter">Age group</label>
          <select id="age-filter" name="age">
            <option value="">All ages</option>
            <option value="0-2">0 – 2 years</option>
            <option value="3-5">3 – 5 years</option>
            <option value="6-8">6 – 8 years</option>
            <option value="9-10">9 – 10 years</option>
          </select>
        </div>
        <div className={styles.filterGroup}>
          <label htmlFor="price-filter">Price range</label>
          <select id="price-filter" name="price">
            <option value="">All ranges</option>
            <option value="budget-friendly">Budget-friendly</option>
            <option value="mid-range">Mid-range</option>
            <option value="premium">Premium selection</option>
          </select>
        </div>
        <fieldset className={styles.filterGroup} aria-label="Category filter">
          <legend>Category</legend>
          <label>
            <input type="checkbox" name="category" value="stem" />
            STEM & Building
          </label>
          <label>
            <input type="checkbox" name="category" value="movement" />
            Movement & Outdoor
          </label>
          <label>
            <input type="checkbox" name="category" value="mindful" />
            Mindful Moments
          </label>
          <label>
            <input type="checkbox" name="category" value="creative" />
            Creative Play
          </label>
        </fieldset>
      </section>

      <section className={styles.grid} aria-label="Toy product grid">
        {products.map((product) => (
          <article key={product.name} className={styles.card}>
            <img src={product.image} alt={product.name} className={styles.image} />
            <div className={styles.content}>
              <div className={styles.meta}>
                <span className={styles.tag}>{product.age}</span>
                <span className={styles.tag}>{product.category}</span>
              </div>
              <h2>{product.name}</h2>
              <p>{product.description}</p>
              <ul className={styles.highlightList}>
                {product.highlights.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <button type="button" className={styles.cta} aria-label={`Learn more about ${product.name}`}>
                Learn more
              </button>
            </div>
          </article>
        ))}
      </section>
    </div>
  </>
);

export default Products;