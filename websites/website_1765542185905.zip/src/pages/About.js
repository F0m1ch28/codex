import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/About.module.css';

const milestones = [
  {
    year: '2015',
    title: 'A playgroup idea becomes a business',
    description: 'Joyful Toys began as a weekend playgroup in Amsterdam Zuid run by founders Noor and Bram, where parents requested curated toy kits to take home.'
  },
  {
    year: '2018',
    title: 'Sourcing across Europe',
    description: 'We partnered with independent makers in the Netherlands, Germany, and Denmark to deliver responsibly produced toys with timeless appeal.'
  },
  {
    year: '2021',
    title: 'Play coach programme',
    description: 'Our play experts—educators, therapists, and designers—joined to offer personalised guidance for families ordering tailored toy bundles.'
  },
  {
    year: '2023',
    title: 'Nationwide community',
    description: 'Joyful Toys now serves families across the Netherlands with speedy delivery, local pop-up events, and a growing library of play resources.'
  }
];

const values = [
  {
    title: 'Child-first design',
    description: 'We evaluate toys against developmental research and feedback from Dutch families to ensure every product inspires curiosity.'
  },
  {
    title: 'Sustainable thinking',
    description: 'We prioritise recycled packaging, energy-efficient production, and durable toys that can be loved by siblings for years.'
  },
  {
    title: 'Inclusive play',
    description: 'Our collection spans sensory-friendly, multilingual, and adaptive play options so every child feels represented and empowered.'
  }
];

const teamMembers = [
  {
    name: 'Noor van Dijk',
    role: 'Co-founder & Chief Play Curator',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Bram Janssen',
    role: 'Co-founder & Operations Lead',
    image: 'https://images.unsplash.com/photo-1521572267360-6eb1776115a0?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Lotte Meijer',
    role: 'Head of Play Coaching',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Eva de Groot',
    role: 'Sustainability Coordinator',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>Our Story | Joyful Toys</title>
      <meta
        name="description"
        content="Learn how Joyful Toys grew from a neighbourhood playgroup in Amsterdam into the Netherlands’ favourite destination for thoughtful toys."
      />
    </Helmet>

    <div className={styles.page}>
      <header className={styles.intro}>
        <span className={styles.kicker}>Our Story</span>
        <h1>Bringing Playful Energy to Families Across the Netherlands</h1>
        <p>
          Joyful Toys is more than an online shop—we are a community of parents, educators, and designers on a mission to nurture creativity through play. We believe that quality toys can spark lifelong curiosity, encourage empathy, and celebrate diversity.
        </p>
      </header>

      <section className={styles.story}>
        <h2>Milestones That Shaped Joyful Toys</h2>
        <div className={styles.timeline}>
          {milestones.map((milestone) => (
            <article key={milestone.year} className={styles.timelineItem}>
              <div className={styles.timelineYear}>{milestone.year}</div>
              <div className={styles.timelineContent}>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.values}>
        <h2>What Matters to Us</h2>
        <div className={styles.valueGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <h2>Meet the Team</h2>
        <p>
          Our core team collaborates with a wider network of certified play therapists, child psychologists, and sustainability experts to keep our collection forward-thinking and responsible.
        </p>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} className={styles.teamImage} />
              <h3>{member.name}</h3>
              <p className={styles.teamRole}>{member.role}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  </>
);

export default About;