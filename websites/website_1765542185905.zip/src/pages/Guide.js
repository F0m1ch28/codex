import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Guide.module.css';

const ageGuides = [
  {
    ageRange: '0 – 12 months',
    focus: 'Sensory discovery and bonding',
    description:
      'Choose toys with contrasting colours, gentle sounds, and varied textures to stimulate the senses and support motor milestones.',
    tips: [
      'Soft rattles and crinkly fabric books are perfect for supervised tummy time.',
      'Look for toys certified for mouthing with non-toxic finishes.',
      'Rotate sensory items weekly to keep curiosity high without overstimulation.'
    ]
  },
  {
    ageRange: '1 – 3 years',
    focus: 'Cause-and-effect exploration',
    description:
      'Toddlers thrive on repetition and movement. Durable toys with buttons, levers, and stackable shapes build confidence through simple problem solving.',
    tips: [
      'Encourage pretend play with chunky animal figures or kitchen sets.',
      'Large-piece puzzles and pull-along toys support coordination.',
      'Alternate indoor and outdoor play to channel energy healthily.'
    ]
  },
  {
    ageRange: '4 – 6 years',
    focus: 'Imagination and pre-literacy',
    description:
      'Creative kits, story-building games, and role-play costumes help children express themselves while strengthening early language skills.',
    tips: [
      'Select open-ended sets for endless storytelling scenarios.',
      'STEM-lite kits with magnets, gears, or coding cards build logical thinking.',
      'Collaborate with your child to create simple rules and challenges.'
    ]
  },
  {
    ageRange: '7 – 10 years',
    focus: 'STEM curiosity and teamwork',
    description:
      'Complex construction sets, science experiments, and strategy games foster perseverance and collaboration among friends or siblings.',
    tips: [
      'Involve children in reading instructions and planning builds.',
      'Introduce Dutch-designed tech kits for a local twist on innovation.',
      'Balance screen-based learning with unplugged, hands-on projects.'
    ]
  }
];

const interestIdeas = [
  {
    title: 'For budding artists',
    point: 'Art kits with washable paints, eco crayons, and inspiring prompts keep creative minds flowing without the mess.'
  },
  {
    title: 'For movement lovers',
    point: 'Balance stones, dance ribbons, and indoor climbing aids channel energy and improve balance on rainy days.'
  },
  {
    title: 'For mindful dreamers',
    point: 'Weighted plush toys, story projectors, and breathing cards cultivate calm bedtime rituals.'
  },
  {
    title: 'For junior engineers',
    point: 'Mechanical building sets, circuitry games, and recycled-material craft projects challenge logical thinking.'
  }
];

const safetyChecklist = [
  'Always inspect for small parts that could detach—especially when sharing toys among siblings of different ages.',
  'Look for CE markings and age recommendations suited to your child’s developmental stage.',
  'Choose sustainably sourced materials and water-based paints to minimise allergens and toxins.',
  'Store toys in breathable containers and clean them regularly according to manufacturer guidance.'
];

const Guide = () => (
  <>
    <Helmet>
      <title>Toy Buying Guide | Joyful Toys</title>
      <meta
        name="description"
        content="Use the Joyful Toys buying guide to choose safe, developmentally appropriate toys tailored to your child’s age, interests, and learning style."
      />
    </Helmet>
    <div className={styles.page}>
      <header className={styles.intro}>
        <span className={styles.kicker}>Toy Buying Guide</span>
        <h1>Smart Toy Choices for Every Stage of Childhood</h1>
        <p>
          Selecting toys should feel joyful, not overwhelming. We consulted child development specialists and Dutch families to compile simple guidance for discovering toys that match your child’s age, interests, and environment.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Age-Based Play Suggestions</h2>
        <div className={styles.grid}>
          {ageGuides.map((group) => (
            <article key={group.ageRange} className={styles.card}>
              <h3>{group.ageRange}</h3>
              <p className={styles.focus}>{group.focus}</p>
              <p>{group.description}</p>
              <ul className={styles.tipList}>
                {group.tips.map((tip) => (
                  <li key={tip}>{tip}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2>Match Toys to Your Child’s Interests</h2>
        <div className={styles.interestGrid}>
          {interestIdeas.map((idea) => (
            <article key={idea.title} className={styles.interestCard}>
              <h3>{idea.title}</h3>
              <p>{idea.point}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2>Safety Snapshot Checklist</h2>
        <p>
          Safety is the heart of our curation. Use this quick checklist when introducing new toys, especially when friends visit or siblings share play spaces.
        </p>
        <ul className={styles.checklist}>
          {safetyChecklist.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className={styles.section}>
        <h2>Encourage Open-Ended Play</h2>
        <p>
          Open-ended toys—like wooden blocks, magnetic tiles, and loose parts—allow children to invent new games daily, boosting imagination and resilience. Combine them with story prompts or music for a unique sensory experience.
        </p>
        <p>
          Need personalised advice? Reach out via our contact page and our play coaches will share tailored recommendations for your family.
        </p>
      </section>
    </div>
  </>
);

export default Guide;