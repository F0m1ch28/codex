import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from '../styles/Home.module.css';

const heroSlides = [
  {
    title: 'Imaginative Playsets',
    subtitle: 'Build story worlds with sustainable materials and bright colours.',
    image: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=1600&q=80',
    alt: 'Child playing with colourful wooden blocks on a rug'
  },
  {
    title: 'STEM Adventures',
    subtitle: 'Hands-on kits that let curious minds tinker, test, and triumph.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1600&q=80',
    alt: 'Child assembling a wooden robotic toy with tools'
  },
  {
    title: 'Cozy Cuddle Buddies',
    subtitle: 'Soft, sensory-friendly friends for the sweetest bedtime rituals.',
    image: 'https://images.unsplash.com/photo-1540924788198-94139024b05d?auto=format&fit=crop&w=1600&q=80',
    alt: 'Two plush animal toys on a children’s bed'
  }
];

const categories = [
  {
    title: 'Creative Makers',
    description: 'Art boxes, DIY crafts, and STEAM projects to keep curious minds buzzing on rainy Dutch afternoons.',
    image: 'https://images.unsplash.com/photo-1511415519840-874f103a5a0c?auto=format&fit=crop&w=800&q=80',
    alt: 'Painted hands crafting colourful art pieces',
    cta: 'Explore creative play'
  },
  {
    title: 'Active Explorers',
    description: 'Balance bikes, movement games, and outdoor play to keep energetic kids moving with joy.',
    image: 'https://images.unsplash.com/photo-1504618291800-bf12f77d7cff?auto=format&fit=crop&w=800&q=80',
    alt: 'Child riding a balance bike on a path',
    cta: 'Browse active play'
  },
  {
    title: 'Mindful Moments',
    description: 'Sensory toys, calming puzzles, and bedtime buddies designed for mindful winding down.',
    image: 'https://images.unsplash.com/photo-1484820544313-33a4e66be7c0?auto=format&fit=crop&w=800&q=80',
    alt: 'Soft plush toys arranged on a bed',
    cta: 'See mindful picks'
  },
  {
    title: 'Dutch Design Picks',
    description: 'Locally inspired favourites celebrating craftsmanship from creative studios across the Netherlands.',
    image: 'https://images.unsplash.com/photo-1582053433976-25c00369fc93?auto=format&fit=crop&w=800&q=80',
    alt: 'Wooden toys on a design table',
    cta: 'Discover local gems'
  }
];

const promotions = [
  {
    title: 'Rainy Day Discovery Kits',
    description: 'Keep indoor days lively with themed kits packed full of experiments, storytelling prompts, and collaborative challenges.',
    image: 'https://images.unsplash.com/photo-1523475472560-59c07b314a10?auto=format&fit=crop&w=1200&q=80',
    alt: 'Children conducting science experiments at home',
    badge: 'Popular Pick',
    highlights: ['10 interactive experiments', 'Reusable materials', 'Includes parent guide']
  },
  {
    title: 'Eco-Friendly Wooden Blocks',
    description: 'Responsibly sourced beech wood blocks with tactile shapes that align with Montessori principles for open-ended play.',
    image: 'https://images.unsplash.com/photo-1615484477546-9334b1f0812b?auto=format&fit=crop&w=1200&q=80',
    alt: 'A toddler stacking wooden building blocks',
    badge: 'Sustainable',
    highlights: ['Certified non-toxic finish', '60-piece rainbow set', 'Supports fine motor skills']
  },
  {
    title: 'Outdoor Adventure Explorer Pack',
    description: 'Encourage outdoor curiosity with binoculars, nature journals, and mini experiments for park days and beach trips.',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
    alt: 'Child exploring nature with binoculars',
    badge: 'Limited Edition',
    highlights: ['Weather-resistant bag', 'STEM-aligned activities', 'Designed in the Netherlands']
  }
];

const qualityFeatures = [
  {
    title: 'Curated by Play Experts',
    description: 'Every toy is play-tested by educators and Dutch families to ensure it encourages creativity, empathy, and confidence.',
    icon: '🎓'
  },
  {
    title: 'Safety Guaranteed',
    description: 'Certified non-toxic materials, CE marking, and rigorous durability testing provide peace of mind for every parent.',
    icon: '🛡️'
  },
  {
    title: 'Sustainable Choices',
    description: 'We work with brands that prioritise recycled packaging, renewable materials, and responsible production.',
    icon: '🌱'
  }
];

const stats = [
  { label: 'Happy Dutch families', value: '5K+' },
  { label: 'Play experts in our network', value: '32' },
  { label: 'Eco-conscious toys curated', value: '180' }
];

const testimonials = [
  {
    quote: 'The personalised recommendations helped me find a perfect mix of toys for both my toddler and five-year-old. They play together more than ever!',
    name: 'Sanne, Utrecht',
    role: 'Parent of two explorers'
  },
  {
    quote: 'As a teacher, I appreciate how Joyful Toys focuses on skill-building play. The STEM kits are a hit with my classroom.',
    name: 'Jeroen, Rotterdam',
    role: 'Primary school teacher'
  },
  {
    quote: 'Fast delivery, beautifully packaged, and the toys are built to last. We love supporting a Dutch company with heart.',
    name: 'Amina, Amsterdam',
    role: 'Mindful play advocate'
  }
];

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setCurrentSlide((prev) => (prev + 1) % heroSlides.length),
      6000
    );
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Helmet>
        <title>Joyful Toys | High-Quality Play for Curious Kids</title>
        <meta
          name="description"
          content="Discover Joyful Toys, the energetic online toy store in the Netherlands offering safe, stimulating toys that inspire creativity and learning."
        />
      </Helmet>

      <section className={styles.hero} aria-label="Featured toys carousel">
        <div className={styles.heroInner}>
          <div className={styles.heroContent}>
            <span className={styles.tagline}>Play. Discover. Shine.</span>
            <h1>Joyful Toys for Bright Little Explorers</h1>
            <p>
              Curated with love in the Netherlands, our toy collection blends imagination, movement, and mindful learning so every playtime becomes a mini adventure.
            </p>
            <div className={styles.heroActions}>
              <Link to="/products" className={styles.primaryButton}>
                Explore Our Toys
              </Link>
              <Link to="/guide" className={styles.secondaryButton}>
                Read the Buying Guide
              </Link>
            </div>
          </div>
          <div className={styles.heroCarousel}>
            <img
              src={heroSlides[currentSlide].image}
              alt={heroSlides[currentSlide].alt}
              className={styles.slideImage}
            />
            <div className={styles.slideCaption}>
              <h3>{heroSlides[currentSlide].title}</h3>
              <p>{heroSlides[currentSlide].subtitle}</p>
            </div>
            <div className={styles.carouselIndicators} role="tablist" aria-label="Hero slides">
              {heroSlides.map((slide, index) => (
                <button
                  key={slide.title}
                  type="button"
                  className={`${styles.indicator} ${index === currentSlide ? styles.indicatorActive : ''}`}
                  onClick={() => setCurrentSlide(index)}
                  aria-label={`Show slide: ${slide.title}`}
                  aria-selected={index === currentSlide}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="category-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionKicker}>Shop by interest</span>
          <h2 id="category-heading">Quick Access to Favourite Categories</h2>
          <p className={styles.sectionDescription}>
            Whether your child loves to build towering cities, dance to new rhythms, or cuddle up with sensory-friendly friends, find a curated category that sparks joy in seconds.
          </p>
        </div>
        <div className={styles.categoryGrid}>
          {categories.map((category) => (
            <article key={category.title} className={styles.categoryCard}>
              <img src={category.image} alt={category.alt} className={styles.categoryImage} />
              <div className={styles.categoryContent}>
                <h3 className={styles.categoryTitle}>{category.title}</h3>
                <p className={styles.categoryText}>{category.description}</p>
                <Link to="/products" className={styles.categoryLink} aria-label={`View ${category.title} toys`}>
                  {category.cta}
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.promotionsSection}`} aria-labelledby="promotion-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionKicker}>Featured highlights</span>
          <h2 id="promotion-heading">This Month’s Joyful Spotlights</h2>
          <p className={styles.sectionDescription}>
            We rotate our spotlight to celebrate toys that inspire STEM skills, outdoor play, and calming bedtime rituals—perfect for the changing seasons in the Netherlands.
          </p>
        </div>
        <div className={styles.promotionGrid}>
          {promotions.map((promotion) => (
            <article key={promotion.title} className={styles.promotionCard}>
              <span className={styles.promotionBadge}>{promotion.badge}</span>
              <img src={promotion.image} alt={promotion.alt} />
              <div className={styles.promotionContent}>
                <h3>{promotion.title}</h3>
                <p>{promotion.description}</p>
                <ul className={styles.promotionList}>
                  {promotion.highlights.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.qualitySection}`} aria-labelledby="quality-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionKicker}>Safety first</span>
          <h2 id="quality-heading">Our Promise to Dutch Families</h2>
          <p className={styles.sectionDescription}>
            Joyful Toys partners with trusted European makers so that every design delivers long-lasting fun, safe materials, and mindful learning aligned with Dutch educational values.
          </p>
        </div>
        <div className={styles.qualityGrid}>
          {qualityFeatures.map((feature) => (
            <article key={feature.title} className={styles.qualityCard}>
              <div className={styles.qualityIcon} aria-hidden="true">{feature.icon}</div>
              <h3 className={styles.qualityTitle}>{feature.title}</h3>
              <p>{feature.description}</p>
            </article>
          ))}
        </div>
        <div className={styles.statsGrid}>
          {stats.map((stat) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statNumber}>{stat.value}</span>
              <span>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialSection}`} aria-labelledby="testimonial-heading">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionKicker}>Families approve</span>
          <h2 id="testimonial-heading">Why Parents Love Joyful Toys</h2>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial) => (
            <blockquote key={testimonial.name} className={styles.testimonialCard}>
              <p className={styles.testimonialQuote}>&ldquo;{testimonial.quote}&rdquo;</p>
              <footer className={styles.testimonialMeta}>
                <span className={styles.testimonialName}>{testimonial.name}</span>
                <span className={styles.testimonialRole}>{testimonial.role}</span>
              </footer>
            </blockquote>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.blogCta}`} aria-labelledby="blog-cta-heading">
        <div className={styles.blogCtaContent}>
          <div>
            <span className={styles.sectionKicker}>Playful insights</span>
            <h2 id="blog-cta-heading">Read the Latest Tips from Our Play Experts</h2>
            <p>
              Visit the Playful Insights blog for fresh activity ideas, seasonal toy picks, and interviews with child development specialists from across the Netherlands.
            </p>
          </div>
          <div className={styles.blogCtaActions}>
            <Link to="/blog" className={styles.primaryButton}>
              Visit the Blog
            </Link>
            <Link to="/guide" className={styles.secondaryButton}>
              Toy Buying Guide
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;