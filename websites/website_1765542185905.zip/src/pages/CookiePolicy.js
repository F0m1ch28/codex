import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Joyful Toys</title>
      <meta name="description" content="Understand how Joyful Toys uses cookies and similar technologies to enhance your browsing experience." />
    </Helmet>
    <div className={styles.page}>
      <h1>Cookie Policy</h1>
      <div className={styles.content}>
        <p>
          This Cookie Policy explains how Joyful Toys uses cookies and similar technologies when you visit our website. Cookies help us provide a more personalised experience and understand how visitors interact with our content.
        </p>
        <p>
          We use essential cookies required for core functionality, analytical cookies to measure site performance, and preference cookies to remember your settings. You can manage cookie preferences through your browser settings at any time.
        </p>
        <p>
          By continuing to browse our site after seeing the cookie notice, you consent to our use of cookies. If you have questions about this policy, contact <a href="mailto:info@joyfultoys.nl">info@joyfultoys.nl</a>.
        </p>
      </div>
    </div>
  </>
);

export default CookiePolicy;