import React from 'react';
import { Helmet } from 'react-helmet';
import styles from '../styles/Contact.module.css';

const Contact = () => {
  const handleSubmit = (event) => {
    event.preventDefault();
    alert('Thank you for connecting with Joyful Toys! We will respond shortly.');
    event.target.reset();
  };

  return (
    <>
      <Helmet>
        <title>Get in Touch | Joyful Toys</title>
        <meta
          name="description"
          content="Contact Joyful Toys in Amsterdam, Netherlands. Our friendly team is ready to answer questions and offer personalised toy recommendations."
        />
      </Helmet>

      <div className={styles.page}>
        <header className={styles.intro}>
          <span className={styles.kicker}>Get in Touch</span>
          <h1>We’re Here to Help Your Playtime Shine</h1>
          <p>
            Reach out for personalised toy advice, partnership opportunities, or press enquiries. The Joyful Toys team loves hearing from our vibrant community.
          </p>
        </header>

        <div className={styles.grid}>
          <section className={styles.formCard} aria-labelledby="contact-form-heading">
            <h2 id="contact-form-heading">Send Us a Message</h2>
            <form className={styles.form} onSubmit={handleSubmit}>
              <div className={styles.formGroup}>
                <label htmlFor="name">Name</label>
                <input id="name" name="name" type="text" required placeholder="Your name" />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">Email</label>
                <input id="email" name="email" type="email" required placeholder="you@example.com" />
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="subject">Subject</label>
                <select id="subject" name="subject" required>
                  <option value="">Choose a subject</option>
                  <option value="general">General Query</option>
                  <option value="product">Product Suggestion</option>
                  <option value="wholesale">Wholesale Inquiry</option>
                </select>
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="message">Message</label>
                <textarea id="message" name="message" rows="5" required placeholder="How can we help?"></textarea>
              </div>
              <div className={styles.formActions}>
                <button type="submit" className={styles.submitButton}>
                  Send Your Joyful Message
                </button>
              </div>
            </form>
          </section>

          <section className={styles.infoCard} aria-labelledby="contact-info-heading">
            <h2 id="contact-info-heading">Contact Details</h2>
            <ul className={styles.infoList}>
              <li>
                <span className={styles.label}>Email:</span>
                <a href="mailto:info@joyfultoys.nl">info@joyfultoys.nl</a>
              </li>
              <li>
                <span className={styles.label}>Phone:</span>
                <a href="tel:+31201234567">+31 20 123 4567</a>
              </li>
              <li>
                <span className={styles.label}>Address:</span>
                Amsterdam, Netherlands
              </li>
              <li>
                <span className={styles.label}>Office hours:</span>
                Monday – Friday, 09:00 – 17:00 CET
              </li>
            </ul>
            <p>
              Prefer personal guidance? Book a free 15-minute play consultation with one of our coaches to receive tailored toy recommendations for your family.
            </p>
          </section>
        </div>
      </div>
    </>
  );
};

export default Contact;