import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from '../styles/Blog.module.css';

const posts = [
  {
    title: 'Balancing Screen Time with Hands-On Play',
    image: 'https://images.unsplash.com/photo-1530053969600-caed2596d242?auto=format&fit=crop&w=900&q=80',
    excerpt: 'Our play therapists share practical routines to keep digital learning healthy alongside tactile play this winter.',
    category: 'Playful Insights',
    readTime: '4 min read'
  },
  {
    title: 'Dutch Designers Leading Sustainable Toy Innovation',
    image: 'https://images.unsplash.com/photo-1516632664305-eda5d6a45277?auto=format&fit=crop&w=900&q=80',
    excerpt: 'Meet the creative studios crafting eco-conscious toys with circular design principles and family feedback loops.',
    category: 'Behind the Scenes',
    readTime: '6 min read'
  },
  {
    title: 'Outdoor Adventure Ideas for Every Season',
    image: 'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&w=900&q=80',
    excerpt: 'From beach scavenger hunts to urban nature bingo, discover ways to turn the Netherlands into an open-air playground.',
    category: 'Play Ideas',
    readTime: '5 min read'
  },
  {
    title: 'Supporting Neurodiverse Children Through Sensory Play',
    image: 'https://images.unsplash.com/photo-1523475472560-c40f39f84b68?auto=format&fit=crop&w=900&q=80',
    excerpt: 'Create inclusive play corners with sensory-friendly textures, rhythmic tools, and predictable routines.',
    category: 'Child Development',
    readTime: '7 min read'
  }
];

const Blog = () => (
  <>
    <Helmet>
      <title>Playful Insights | Joyful Toys Blog</title>
      <meta
        name="description"
        content="Discover Joyful Toys articles about child development, toy safety, and creative play ideas tailored for Dutch families."
      />
    </Helmet>

    <div className={styles.page}>
      <header className={styles.intro}>
        <span className={styles.kicker}>Playful Insights</span>
        <h1>Stories, Tips, and Research for Vibrant Play</h1>
        <p>
          Our editorial team works with occupational therapists, educators, and parents throughout the Netherlands to bring you actionable ideas and heartfelt stories. Dive in for seasonal toy tips and mindful parenting inspiration.
        </p>
      </header>

      <section className={styles.grid} aria-label="Blog posts">
        {posts.map((post) => (
          <article key={post.title} className={styles.card}>
            <img src={post.image} alt={post.title} className={styles.image} />
            <div className={styles.content}>
              <div className={styles.meta}>
                <span className={styles.category}>{post.category}</span>
                <span>{post.readTime}</span>
              </div>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <Link to="/contact" className={styles.link} aria-label={`Connect with Joyful Toys about ${post.title}`}>
                Share your thoughts →
              </Link>
            </div>
          </article>
        ))}
      </section>
    </div>
  </>
);

export default Blog;