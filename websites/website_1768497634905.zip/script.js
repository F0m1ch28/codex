document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");
    const navLinks = document.querySelectorAll(".nav-menu a");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!isExpanded));
            navMenu.classList.toggle("is-open");
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (navMenu.classList.contains("is-open")) {
                    navMenu.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieStorageKey = "genus-cayqg-cookie-consent";

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(cookieStorageKey);

        if (!storedConsent) {
            window.setTimeout(() => {
                cookieBanner.classList.add("is-visible");
            }, 600);
        } else {
            cookieBanner.classList.add("is-dismissed");
        }

        const cookieButtons = cookieBanner.querySelectorAll("[data-cookie-action]");
        cookieButtons.forEach((button) => {
            button.addEventListener("click", (event) => {
                event.preventDefault();
                const decision = button.getAttribute("data-cookie-action");
                localStorage.setItem(cookieStorageKey, decision);
                cookieBanner.classList.remove("is-visible");
                cookieBanner.classList.add("is-dismissed");
                const targetHref = button.getAttribute("href");
                if (targetHref) {
                    window.open(targetHref, "_blank", "noopener");
                }
            });
        });
    }
});