document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelectorAll('.site-nav a.nav-link');

  if (navToggle) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      body.classList.toggle('nav-open');
    });
  }

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (body.classList.contains('nav-open') && navToggle) {
        body.classList.remove('nav-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');
  const storageKey = 'cloudHashCookieConsent';

  if (banner) {
    const stored = localStorage.getItem(storageKey);
    if (!stored) {
      setTimeout(() => banner.classList.add('active'), 600);
    }

    const closeBanner = (value) => {
      localStorage.setItem(storageKey, value);
      banner.classList.remove('active');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => closeBanner('accepted'));
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', () => closeBanner('declined'));
    }
  }
});