document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('open');
    });

    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        navLinks.classList.remove('open');
      });
    });
  }

  const yearElements = document.querySelectorAll('.current-year');
  const currentYear = new Date().getFullYear();
  yearElements.forEach((el) => {
    el.textContent = currentYear;
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.18 });

  document.querySelectorAll('.fade-section').forEach((section) => {
    observer.observe(section);
  });

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const consent = localStorage.getItem('dmgelectech_cookie_consent');
    if (!consent) {
      cookieBanner.classList.add('active');
    }

    cookieBanner.querySelectorAll('[data-cookie-choice]').forEach((button) => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-cookie-choice');
        localStorage.setItem('dmgelectech_cookie_consent', choice);
        cookieBanner.classList.remove('active');
      });
    });
  }

  const toast = document.getElementById('global-toast');
  const forms = document.querySelectorAll('form');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (toast) {
        toast.textContent = 'Message submitted. Redirecting...';
        toast.classList.add('visible');
        setTimeout(() => {
          toast.classList.remove('visible');
          window.location.href = form.getAttribute('action') || 'thank-you.html';
        }, 1200);
      } else {
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }
    });
  });
});