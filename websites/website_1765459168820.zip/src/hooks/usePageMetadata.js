import { useEffect } from 'react';

const ensureMetaTag = (selector, attributes) => {
  let element = document.head.querySelector(selector);
  if (!element) {
    element = document.createElement('meta');
    Object.keys(attributes).forEach((key) => {
      element.setAttribute(key, attributes[key]);
    });
    document.head.appendChild(element);
  }
  return element;
};

const usePageMetadata = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      const descriptionMeta = ensureMetaTag('meta[name="description"]', { name: 'description' });
      descriptionMeta.setAttribute('content', description);
    }
    if (keywords) {
      const keywordsMeta = ensureMetaTag('meta[name="keywords"]', { name: 'keywords' });
      keywordsMeta.setAttribute('content', keywords);
    }
  }, [title, description, keywords]);
};

export default usePageMetadata;