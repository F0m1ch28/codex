import React, { useEffect, useState } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import DisclaimerModal from './components/DisclaimerModal';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage from './pages/Services';
import MethodologyPage from './pages/Methodology';
import CoursePage from './pages/Course';
import ResourcesPage from './pages/Resources';
import ContactPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsOfServicePage from './pages/TermsOfService';
import PrivacyPolicyPage from './pages/PrivacyPolicy';
import CookiePolicyPage from './pages/CookiePolicy';

const RouteChangeHandler = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  const [isDisclaimerVisible, setIsDisclaimerVisible] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('tph_disclaimer_acknowledged') !== 'true';
    }
    return false;
  });

  const handleCloseDisclaimer = () => {
    setIsDisclaimerVisible(false);
    if (typeof window !== 'undefined') {
      localStorage.setItem('tph_disclaimer_acknowledged', 'true');
    }
  };

  return (
    <div>
      <RouteChangeHandler />
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/inflation" element={<MethodologyPage />} />
          <Route path="/course" element={<CoursePage />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/thank-you" element={<ThankYouPage />} />
          <Route path="/terms" element={<TermsOfServicePage />} />
          <Route path="/privacy" element={<PrivacyPolicyPage />} />
          <Route path="/cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTopButton />
      <CookieBanner />
      <DisclaimerModal
        isVisible={isDisclaimerVisible}
        onClose={handleCloseDisclaimer}
      />
    </div>
  );
}

export default App;