import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicyPage = () => {
  usePageMetadata({
    title: 'Privacy Policy | Tu Progreso Hoy',
    description: 'Understand how Tu Progreso Hoy protects your data and respects privacy across our educational platform.'
  });

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>Last updated: January 2025</p>
        <div className={styles.section}>
          <h2>1. Data We Collect</h2>
          <p>
            We collect account information (name, email), learning preferences, and optional child age ranges to personalize content.
            We do not store payment details on our servers.
          </p>
        </div>
        <div className={styles.section}>
          <h2>2. Cookies</h2>
          <p>
            Essential cookies support secure login. Analytics cookies help us improve the platform and respect Dutch privacy guidelines.
            You can manage preferences via your browser or our cookie banner.
          </p>
        </div>
        <div className={styles.section}>
          <h2>3. Data Storage</h2>
          <p>
            Data is hosted within the EU. Backups are encrypted. We never sell personal data and only share with service providers under strict agreements.
          </p>
        </div>
        <div className={styles.section}>
          <h2>4. Your Rights</h2>
          <p>
            You may request access, correction, or deletion of your data at any time by contacting info@tuprogresohoy.com.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;