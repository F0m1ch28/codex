import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './TermsOfService.module.css';

const TermsOfServicePage = () => {
  usePageMetadata({
    title: 'Terms of Service | Tu Progreso Hoy',
    description: 'Read the Tu Progreso Hoy terms of service and understand how our educational SaaS platform operates.'
  });

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Terms of Service</h1>
        <p>Last updated: January 2025</p>
        <div className={styles.section}>
          <h2>1. Purpose</h2>
          <p>
            Tu Progreso Hoy provides educational content, safety insights, and community coaching to support families.
            We do not sell toys or offer professional childcare consulting. Access to our platform signifies agreement to these terms.
          </p>
        </div>
        <div className={styles.section}>
          <h2>2. Accounts & Access</h2>
          <p>
            Users must be 18+ and responsible for safeguarding credentials. Accounts are for personal household use unless a partner agreement states otherwise.
          </p>
        </div>
        <div className={styles.section}>
          <h2>3. Content Usage</h2>
          <p>
            You may download worksheets and checklists for personal use. Republishing content without permission is prohibited.
            Any translation should reference Tu Progreso Hoy as the original author.
          </p>
        </div>
        <div className={styles.section}>
          <h2>4. Liability</h2>
          <p>
            Insights are provided for educational purposes. Parents remain responsible for verifying product suitability and seeking professional advice where necessary.
          </p>
        </div>
        <div className={styles.section}>
          <h2>5. Contact</h2>
          <p>
            Questions can be directed to info@tuprogresohoy.com or by phone at +54 11 5555-1234.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TermsOfServicePage;