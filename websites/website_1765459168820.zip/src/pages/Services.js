import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Services.module.css';

const services = [
  {
    title: 'Safety Intelligence Platform',
    summary:
      'Interactive dashboards that filter EU Safety Gate data, Dutch NVWA alerts, and retailer updates with child-centric tagging.',
    features: ['Live alert translation (EN + ES-AR)', 'Age-stage risk scoring', 'Compliance checklists downloadable']
  },
  {
    title: 'Play Lab Analytics',
    summary:
      'Proprietary datasets on toy materials, design reviews, and inclusive play heuristics sourced from European labs.',
    features: ['Material provenance tracking', 'Inclusive design scoring', 'Eco-impact snapshots']
  },
  {
    title: 'Parent Enablement Course',
    summary:
      'On-demand micro-lessons and live community circles guiding parents through safety, routine design, and emotional play.',
    features: ['Weekly coaching prompts', 'Downloadable bilingual worksheets', 'Cohort-based accountability']
  },
  {
    title: 'Community Knowledge Base',
    summary:
      'Glossaries, bilingual explainers, and checklists aligned with Dutch childcare expectations and cultural nuance.',
    features: ['Terminology in EN + ES-AR', 'Step-by-step guides for reporting issues', 'Monthly toy spotlight briefings']
  }
];

const ServicesPage = () => {
  usePageMetadata({
    title: 'Tu Progreso Hoy Services | Toy Safety SaaS for NL Parents',
    description:
      'Review Tu Progreso Hoy services including toy safety dashboards, play lab analytics, parent enablement course, and community knowledge base.',
    keywords:
      'toy safety platform Netherlands, parenting analytics NL, educational SaaS services, Tu Progreso Hoy features'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Solutions designed to empower parents, partners, and communities.</h1>
          <p>
            From safety dashboards to collaborative labs, Tu Progreso Hoy offers modular services that merge
            regulatory precision with culturally responsive coaching.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <h2>{service.title}</h2>
                <p>{service.summary}</p>
                <ul>
                  {service.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.partners}>
        <div className="container">
          <div className={styles.partnerCard}>
            <h2>Partner with Tu Progreso Hoy</h2>
            <p>
              Municipal libraries, childcare centres, and toy boutiques partner with us to co-host safety clinics and
              distribute our bilingual content. Together we strengthen local awareness across the Netherlands.
            </p>
            <p className={styles.badge}>Available across NL cities</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;