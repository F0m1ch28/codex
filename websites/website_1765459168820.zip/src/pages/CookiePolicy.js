import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => {
  usePageMetadata({
    title: 'Cookie Policy | Tu Progreso Hoy',
    description:
      'Learn how Tu Progreso Hoy uses cookies to deliver a responsive educational experience for parents in the Netherlands.'
  });

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Last updated: January 2025</p>
        <div className={styles.section}>
          <h2>Types of cookies</h2>
          <ul>
            <li><strong>Essential cookies:</strong> Required for authentication and protecting the platform.</li>
            <li><strong>Analytics cookies:</strong> Help us understand which lessons are most useful. Aggregated and anonymised.</li>
            <li><strong>Preference cookies:</strong> Store language and cohort selections.</li>
          </ul>
        </div>
        <div className={styles.section}>
          <h2>Managing cookies</h2>
          <p>
            You can accept or reject optional cookies via our banner. Browser settings also allow you to delete cookies at any time.
            For questions, contact info@tuprogresohoy.com.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicyPage;