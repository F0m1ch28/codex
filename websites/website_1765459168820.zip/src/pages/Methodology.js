import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Methodology.module.css';

const faqs = [
  {
    question: 'Which data sources do you monitor for toy safety?',
    answer:
      'We integrate the EU Safety Gate (RAPEX) weekly feed, the Dutch NVWA inspection bulletins, customs updates, retailer recall announcements, and parent community signals validated by our analysts.'
  },
  {
    question: 'How do you interpret EU directives for parents?',
    answer:
      'Our analysts translate regulatory text into impact statements, cross-reference with child development research, and produce bilingual summaries. We highlight what to look for on packaging, websites, and receipts.'
  },
  {
    question: 'How often are datasets refreshed?',
    answer:
      'Automated fetches run every 12 hours, with manual validation every Monday and Thursday. Rapid response alerts are issued within 4 hours of high-risk notifications.'
  },
  {
    question: 'Which standards are prioritised?',
    answer:
      'EN 71 parts 1-14, EN 62115 for electrical toys, EN IEC 62368 for connected devices, plus Dutch NVWA guidance on magnet strength, chemical content, and choking hazards.'
  }
];

const MethodologyPage = () => {
  usePageMetadata({
    title: 'Toy Safety Methodology | Tu Progreso Hoy',
    description:
      'Learn how Tu Progreso Hoy sources toy safety data, interprets EU standards, and supports parents with transparent methodology.',
    keywords:
      'toy safety methodology Netherlands, EU standards toys, NVWA compliance, Tu Progreso Hoy data method'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Meticulously translating EU toy standards into parent-friendly actions.</h1>
          <p>
            Our methodology blends structured data pipelines, expert review boards, and community-check mechanisms.
            Here is how we ensure every recommendation honours Dutch and European standards.
          </p>
        </div>
      </section>

      <section className={styles.sources}>
        <div className="container">
          <div className={styles.grid}>
            <article>
              <h2>Primary data inputs</h2>
              <ul>
                <li>EU Safety Gate (RAPEX) alerts enriched with age-stage tags.</li>
                <li>Dutch NVWA inspection reports and stop-sales orders.</li>
                <li>Voluntary recalls tracked from major NL retailers and e-commerce platforms.</li>
                <li>Lab reports from our partner institutions in Amsterdam, Rotterdam, and Buenos Aires.</li>
              </ul>
            </article>
            <article>
              <h2>Validation workflow</h2>
              <p>
                Alerts enter a triage queue where analysts verify legitimacy, cross-check product identifiers, and generate a parent-facing summary.
                Content is reviewed by pediatric advisors before publication to ensure developmentally appropriate guidance.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.standards}>
        <div className="container">
          <h2>EU safety standards we translate weekly</h2>
          <div className={styles.standardsGrid}>
            <div className={styles.standardCard}>
              <h3>EN 71 Series</h3>
              <p>Mechanical, chemical, and flammability requirements for traditional toys.</p>
            </div>
            <div className={styles.standardCard}>
              <h3>EN 62115</h3>
              <p>Electrical toy safety, focusing on overheating and accessible wiring.</p>
            </div>
            <div className={styles.standardCard}>
              <h3>EN IEC 62368</h3>
              <p>Audio/video, IT, and communication technology equipment that doubles as play devices.</p>
            </div>
            <div className={styles.standardCard}>
              <h3>Cyber & privacy guidelines</h3>
              <p>GDPR and Dutch Autoriteit Persoonsgegevens expectations for connected toys.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.workflow}>
        <div className="container">
          <h2>Our methodology workflow</h2>
          <div className={styles.workflowGrid}>
            <div>
              <span className={styles.step}>1</span>
              <h3>Capture & Classify</h3>
              <p>We ingest alerts, label them with product type, age group, and exposure risk, and run them through anomaly detection.</p>
            </div>
            <div>
              <span className={styles.step}>2</span>
              <h3>Translate & Contextualise</h3>
              <p>Analysts summarise alerts in English and Spanish, adding cultural examples and at-home mitigation strategies.</p>
            </div>
            <div>
              <span className={styles.step}>3</span>
              <h3>Publish & Coach</h3>
              <p>Parents receive updates via dashboards, lesson modules, and community circles with live Q&A.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <h2>Frequently asked questions</h2>
          <div className={styles.faqList}>
            {faqs.map((item) => (
              <details key={item.question}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default MethodologyPage;