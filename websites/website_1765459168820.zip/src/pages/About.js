import React from 'react';
import { Link } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './About.module.css';

const AboutPage = () => {
  usePageMetadata({
    title: 'About Tu Progreso Hoy | Our Story Across NL & LatAm',
    description:
      'Discover the story of Tu Progreso Hoy, an education-focused SaaS platform connecting Dutch safety standards with Latin American warmth.',
    keywords:
      'Tu Progreso Hoy, about toy safety platform, parenting support Netherlands, educational SaaS NL'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroCard}>
            <h1>We unite Dutch rigor and Latin American heart to guide families through play.</h1>
            <p>
              Tu Progreso Hoy started when a Buenos Aires educator and a Dutch safety analyst realised that parents needed a bridge between regulations and real-life play moments. We built a platform where data, empathy, and bilingual storytelling coexist.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.storyGrid}>
            <div>
              <h2>Origin story</h2>
              <p>
                In 2020, our founders migrated from Argentina to Utrecht and instantly felt the weight of navigating new standards.
                They gathered EU directives, consulted with Dutch inspectors, and co-created workshops with fellow parents.
                The result was Tu Progreso Hoy: a SaaS platform offering toy safety dashboards, co-learning circles, and a responsive knowledge base.
              </p>
            </div>
            <div>
              <h3>Our values</h3>
              <ul className={styles.valuesList}>
                <li><strong>Care without compromise.</strong> Families deserve clarity before toys enter their homes.</li>
                <li><strong>Bilingual inclusion.</strong> English and Spanish live equally across our dashboards, videos, and worksheets.</li>
                <li><strong>Community science.</strong> Parents, designers, and therapists co-create the insights you see.</li>
                <li><strong>Data ethics first.</strong> We track trends responsibly and never monetise personal data.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2>Milestones that shaped our platform.</h2>
          <div className={styles.timelineGrid}>
            <article>
              <span className={styles.year}>2020</span>
              <h3>Early research circles in Utrecht</h3>
              <p>Weekly sessions with expat parents uncovered the need for a bilingual toy translation layer.</p>
            </article>
            <article>
              <span className={styles.year}>2021</span>
              <h3>Safety dashboards launch</h3>
              <p>We connected EU Safety Gate data and the Dutch NVWA RSS feed into a parent-friendly interface.</p>
            </article>
            <article>
              <span className={styles.year}>2023</span>
              <h3>Parent course goes live</h3>
              <p>A modular training programme blending asynchronous lessons, live office hours, and reflection prompts.</p>
            </article>
            <article>
              <span className={styles.year}>2025</span>
              <h3>Play Lab fellowship</h3>
              <p>Designing toy prototypes with inclusive design studios in Rotterdam and Buenos Aires.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.callout}>
        <div className="container">
          <div className={styles.calloutCard}>
            <h2>Want to understand how we evaluate toys?</h2>
            <p>We publish our frameworks, dataset references, and frequent updates in the Methodology & Safety space.</p>
            <Link to="/inflation" className={styles.calloutLink}>Explore the methodology →</Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;