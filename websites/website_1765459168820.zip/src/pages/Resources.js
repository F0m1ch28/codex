import React, { useMemo, useState } from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Resources.module.css';

const articles = [
  {
    id: 1,
    title: 'Smart magnet play: what Dutch parents need to check in 2025',
    excerpt:
      'Magnet toys keep evolving. Learn how to inspect casing, measure pull force, and store sets safely in canal-side homes.',
    language: 'EN',
    category: 'Safety',
    link: '#'
  },
  {
    id: 2,
    title: 'Glosario bilingüe: términos clave de seguridad en la UE',
    excerpt:
      'Desde “fit for purpose” hasta “chemical migration”, repasamos el vocabulario que aparece en las alertas oficiales.',
    language: 'ES-AR',
    category: 'Glossary',
    link: '#'
  },
  {
    id: 3,
    title: 'A parent’s guide to circular toy swaps in Amsterdam',
    excerpt:
      'Map of swap spots, hygiene checklists, and conversation starters for inclusive toy exchanges.',
    language: 'EN',
    category: 'Community',
    link: '#'
  },
  {
    id: 4,
    title: 'Checklist para evaluar juguetes de madera artesanales',
    excerpt:
      'Qué preguntar a fabricantes pequeños, cómo interpretar certificaciones FSC, y cómo cuidar las piezas en climas húmedos.',
    language: 'ES-AR',
    category: 'Checklist',
    link: '#'
  },
  {
    id: 5,
    title: 'Connected toy privacy essentials for Dutch households',
    excerpt:
      'Understand data flows, default settings, and how to communicate privacy expectations to caregivers.',
    language: 'EN',
    category: 'Safety',
    link: '#'
  }
];

const ResourcesPage = () => {
  const [languageFilter, setLanguageFilter] = useState('All');

  usePageMetadata({
    title: 'Toy Safety Resources & Articles | Tu Progreso Hoy',
    description:
      'Access bilingual toy safety resources, glossaries, and guides curated by Tu Progreso Hoy for parents in the Netherlands.',
    keywords:
      'toy safety resources, bilingual parenting articles, Tu Progreso Hoy resources, play safety NL'
  });

  const filteredArticles = useMemo(() => {
    if (languageFilter === 'All') return articles;
    return articles.filter((article) => article.language === languageFilter);
  }, [languageFilter]);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Resources to keep your family inspired and informed.</h1>
          <p>
            Explore guided play ideas, safety explainers, and community stories in English and Español (ES-AR).
            Use the language toggle to tailor your reading list.
          </p>
          <div className={styles.filters}>
            {['All', 'EN', 'ES-AR'].map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguageFilter(lang)}
                className={languageFilter === lang ? styles.active : ''}
                type="button"
              >
                {lang === 'All' ? 'All languages' : lang}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.list}>
        <div className="container">
          <div className={styles.articleGrid}>
            {filteredArticles.map((article) => (
              <article key={article.id} className={styles.card}>
                <span className={styles.language}>{article.language}</span>
                <h2>{article.title}</h2>
                <p>{article.excerpt}</p>
                <a href={article.link} className={styles.readMore}>Read article →</a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ResourcesPage;