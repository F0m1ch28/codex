import React from 'react';
import { Link } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Course.module.css';

const modules = [
  {
    title: 'Module 1: Safety Mindset & EU Landscape',
    description:
      'Understand EN 71 standards, Dutch NVWA guidance, and how to spot reliable certifications in local shops and online marketplaces.',
    outcomes: ['Decode labels confidently', 'Spot early risk signals', 'Build a personal safety checklist']
  },
  {
    title: 'Module 2: Developmental Play Blueprints',
    description:
      'Align toy selection with motor, cognitive, and socio-emotional milestones. Includes bilingual routines and sensory adaptations.',
    outcomes: ['Map toys to developmental goals', 'Bridge bilingual storytelling', 'Design inclusive play setups']
  },
  {
    title: 'Module 3: Home Ecosystem Planning',
    description:
      'Create organised play zones, rotate toy libraries, and balance screen-based learning with unplugged experiences.',
    outcomes: ['Draft rotation calendars', 'Set up safe storage', 'Balance digital curiosity with boundaries']
  },
  {
    title: 'Module 4: Community & Advocacy',
    description:
      'Learn how to report concerns, collaborate with childcare providers, and share findings with friends and neighbours.',
    outcomes: ['Report effectively', 'Host micro-workshops', 'Lead community toy audits']
  }
];

const CoursePage = () => {
  usePageMetadata({
    title: 'Parent Course Overview | Tu Progreso Hoy',
    description:
      'Dive into the Tu Progreso Hoy parent course syllabus covering safety mindset, developmental play, home ecosystems, and advocacy.',
    keywords:
      'parenting course Netherlands, toy safety course, Tu Progreso Hoy syllabus, parent education NL'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Guide your family with confidence through our four-week parent course.</h1>
          <p>
            Each module combines bite-sized lessons, bilingual resources, and live dialogue circles. The curriculum is optimised
            for Dutch daily life, with roots in Latin American community care.
          </p>
          <a href="/#intro-form" className={styles.heroCta}>Claim your free intro lesson</a>
        </div>
      </section>

      <section className={styles.modules}>
        <div className="container">
          <div className={styles.moduleGrid}>
            {modules.map((module) => (
              <article key={module.title} className={styles.moduleCard}>
                <h2>{module.title}</h2>
                <p>{module.description}</p>
                <h3>Key outcomes</h3>
                <ul>
                  {module.outcomes.map((outcome) => (
                    <li key={outcome}>{outcome}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.details}>
        <div className="container">
          <div className={styles.detailCard}>
            <h2>Course logistics</h2>
            <div className={styles.detailGrid}>
              <div>
                <h3>Format</h3>
                <p>Self-paced videos, printable worksheets, and weekly live circles (EN & ES-AR).</p>
              </div>
              <div>
                <h3>Schedule</h3>
                <p>New cohorts begin every 6 weeks. Sessions scheduled for CET evenings to support working parents.</p>
              </div>
              <div>
                <h3>Support</h3>
                <p>Office hours with analysts, community Slack channels, and feedback on home play plans.</p>
              </div>
            </div>
            <Link to="/contact" className={styles.contactLink}>Ask us about the next cohort →</Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CoursePage;