import React, { useState } from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Contact.module.css';

const ContactPage = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});

  usePageMetadata({
    title: 'Contact Tu Progreso Hoy',
    description:
      'Get in touch with Tu Progreso Hoy for toy safety insights, parent course questions, or partnership opportunities.',
    keywords:
      'contact Tu Progreso Hoy, toy safety contact Netherlands, parenting course contact'
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    const nextErrors = {};
    if (!formState.name.trim()) nextErrors.name = 'Please share your name.';
    if (!formState.email.trim()) nextErrors.email = 'Email is required.';
    else if (!/^\S+@\S+\.\S+$/.test(formState.email.trim())) nextErrors.email = 'Enter a valid email.';
    if (!formState.message.trim()) nextErrors.message = 'Tell us how we can support you.';
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length === 0) {
      setFormState({ name: '', email: '', message: '' });
      alert('Thank you! We will reply within two business days.');
    }
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Contact Tu Progreso Hoy</h1>
          <p>We operate across the Netherlands with a hybrid team in Buenos Aires. Reach out for parent support, partnerships, or media inquiries.</p>
        </div>
      </section>

      <section className={styles.grid}>
        <div className="container">
          <div className={styles.contentGrid}>
            <div className={styles.contactCard}>
              <h2>Send us a message</h2>
              <form onSubmit={handleSubmit} noValidate>
                <label htmlFor="contactName">Name *</label>
                <input
                  id="contactName"
                  value={formState.name}
                  onChange={(event) => setFormState({ ...formState, name: event.target.value })}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}

                <label htmlFor="contactEmail">Email *</label>
                <input
                  id="contactEmail"
                  type="email"
                  value={formState.email}
                  onChange={(event) => setFormState({ ...formState, email: event.target.value })}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}

                <label htmlFor="contactMessage">How can we help? *</label>
                <textarea
                  id="contactMessage"
                  rows="4"
                  value={formState.message}
                  onChange={(event) => setFormState({ ...formState, message: event.target.value })}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}

                <button type="submit">Send message</button>
              </form>
            </div>

            <div className={styles.info}>
              <div className={styles.mapWrapper} aria-label="Tu Progreso Hoy Netherlands presence">
                <iframe
                  title="Tu Progreso Hoy Netherlands map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d243646.55877477287!2d4.728055328664743!3d52.35473284708677!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c6099c6ba0b3b5%3A0x787ff62c555c27ec!2sAmsterdam%2C%20Netherlands!5e0!3m2!1sen!2snl!4v1700000000000!5m2!1sen!2snl"
                  loading="lazy"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
              <div className={styles.infoCard}>
                <h3>Official contact details</h3>
                <ul>
                  <li><strong>Address:</strong> Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</li>
                  <li><strong>Phone:</strong> <a href="tel:+541155551234">+54 11 5555-1234</a></li>
                  <li><strong>Email:</strong> <a href="mailto:info@tuprogresohoy.com">info@tuprogresohoy.com</a></li>
                </ul>
              </div>
              <div className={styles.infoCard}>
                <h3>Social</h3>
                <p>Follow our play lab updates and upcoming circles.</p>
                <div className={styles.socials}>
                  <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                  <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a>
                  <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;