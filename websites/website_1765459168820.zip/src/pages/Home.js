import React, { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Home.module.css';

const valuePropositions = [
  {
    title: 'Datos verificados para planificar',
    description: 'Curated toy safety alerts pulled from EU RAPEX, the Dutch NVWA, and trusted consumer labs. Delivered in plain English with Spanish context so your family decisions stay ahead.',
    icon: '🔍'
  },
  {
    title: 'Decisions responsables y conscientes',
    description: 'Scenario-based guidance aligns toy choices with development stages, sensory needs, and Dutch childcare guidelines.',
    icon: '🧠'
  },
  {
    title: 'Learning journeys that travel with you',
    description: 'A modular parent course blending micro-lessons, reflective prompts, and live study circles for expat and local families alike.',
    icon: '🧭'
  },
  {
    title: 'Community-backed evidence',
    description: 'Insights are co-created with pediatric therapists, toy designers, and NL parent councils for a rich mix of expertise.',
    icon: '🤝'
  }
];

const complianceTrends = [
  { year: 2021, safePercentage: 82, flaggedItems: 37, note: 'Rise in small-part alerts for 0-3 age group.' },
  { year: 2022, safePercentage: 85, flaggedItems: 29, note: 'Magnet safety rules tightened across EU.' },
  { year: 2023, safePercentage: 88, flaggedItems: 24, note: 'Sustainability labeling improved clarity for parents.' },
  { year: 2024, safePercentage: 91, flaggedItems: 18, note: 'Dutch customs increased inspections on imported STEM kits.' },
  { year: 2025, safePercentage: 93, flaggedItems: 15, note: 'Predictive analytics highlight inclusive design as a top priority.' }
];

const labSnapshots = [
  {
    id: 'eco',
    category: 'Eco Play',
    title: 'Circular Blocks Lab',
    focus: 'Recycled wood with natural dyes, tested for saliva exposure.',
    ageRange: '18-36 months',
    image: 'https://images.unsplash.com/photo-1601758125946-6ec2e7b6f65f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'stem',
    category: 'STEM',
    title: 'Magnet Coding Tiles',
    focus: 'Sensorial coding patterns using low-gauss magnets and EU-compliant casing.',
    ageRange: '4-6 years',
    image: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'inclusive',
    category: 'Inclusive',
    title: 'Sensory Story Set',
    focus: 'Multilingual tactile cards featuring diverse families and neuro-inclusive prompts.',
    ageRange: '3-5 years',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'outdoor',
    category: 'Outdoor',
    title: 'Canal Explorer Kits',
    focus: 'Water-safe tools with UV-resistant materials designed for Amsterdam waterways.',
    ageRange: '5-8 years',
    image: 'https://images.unsplash.com/photo-1467810563316-b5476525c0f9?auto=format&fit=crop&w=800&q=80'
  }
];

const teamMembers = [
  {
    name: 'Saskia van Dijk',
    title: 'Toy Safety Analyst',
    focus: 'Former NVWA policy advisor translating EU directives into parent-friendly language.',
    image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'María Eugenia Torres',
    title: 'Parent Coach & Psychopedagogue',
    focus: 'Buenos Aires-born educator bridging bilingual learning for expat communities in NL.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Noah Janssen',
    title: 'Data Product Lead',
    focus: 'Builds predictive dashboards to flag recalls and share trends with our members.',
    image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=600&q=80'
  }
];

const testimonials = [
  {
    name: 'Laura & Diego',
    role: 'Parents in Utrecht',
    quote:
      'The bilingual safety trackers helped us confidently choose toys for our son’s daycare routine. The course modules feel realistic and respectfully paced.'
  },
  {
    name: 'Amira',
    role: 'Parenting Circle Host in Rotterdam',
    quote:
      'Our group used the Tu Progreso Hoy dashboards to audit holiday gift plans. The EU compliance summaries saved hours of research.'
  },
  {
    name: 'Rik & Femke',
    role: 'First-time parents in Haarlem',
    quote:
      'We appreciated the alerts about evolving magnet standards. The “Play Lab Snapshots” also introduce ideas we hadn’t considered.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: 'Mapping Toy Trends 2025 for Dutch Families',
    summary:
      'Discover how sustainability, inclusive design, and interconnected play are shaping store shelves across the Randstad.',
    language: 'EN',
    link: '/resources'
  },
  {
    id: 2,
    title: 'Guía express: estándares de juguetes en la UE explicados para familias latino-holandesas',
    summary:
      'Comprende qué etiquetas revisar, cómo leer reportes de seguridad y cómo reportar irregularidades en los Países Bajos.',
    language: 'ES-AR',
    link: '/resources'
  },
  {
    id: 3,
    title: 'From Amsterdam canals to the living room: Outdoor play kits that meet EU norms',
    summary:
      'We compare four outdoor kits tested for water safety and UV resistance—perfect for families exploring Dutch nature.',
    language: 'EN',
    link: '/resources'
  }
];

const HomePage = () => {
  usePageMetadata({
    title: 'Tu Progreso Hoy | Toy Safety & Parent Course for NL Families',
    description:
      'Tu Progreso Hoy blends toy safety analytics, bilingual guidance, and a parent course tailored to families living in the Netherlands.',
    keywords:
      'children toys NL, toy safety Netherlands, kids educational toys, parenting course NL, toy trends 2025, safe toys EU standards'
  });

  const [selectedYear, setSelectedYear] = useState(2024);
  const [activeCategory, setActiveCategory] = useState('All');
  const [formData, setFormData] = useState({ name: '', email: '', childAge: '' });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const currentTrend = useMemo(
    () => complianceTrends.find((trend) => trend.year === Number(selectedYear)),
    [selectedYear]
  );

  const filteredSnapshots = useMemo(() => {
    if (activeCategory === 'All') return labSnapshots;
    return labSnapshots.filter((snapshot) => snapshot.category === activeCategory);
  }, [activeCategory]);

  const handleSubmit = (event) => {
    event.preventDefault();
    const nextErrors = {};
    if (!formData.name.trim()) {
      nextErrors.name = 'Please add your name so we can personalise the intro lesson.';
    }
    if (!formData.email.trim()) {
      nextErrors.email = 'Email helps us deliver your lesson pack.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email.trim())) {
      nextErrors.email = 'Please enter a valid email address.';
    }
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length === 0) {
      navigate('/thank-you');
    }
  };

  return (
    <div className={styles.wrapper}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroCopy}>
              <span className={styles.heroBadge}>Built for parents in the Netherlands</span>
              <h1>Confidence in every toy decision—even before it reaches home.</h1>
              <p>
                Tu Progreso Hoy combines EU safety intelligence, child development research, and bilingual coaching,
                guiding families through play choices that honour curiosity and compliance.
              </p>
              <div className={styles.heroActions}>
                <a href="#intro-form" className={styles.primaryBtn}>Get Free Intro Lesson</a>
                <Link to="/inflation" className={styles.secondaryBtn}>See Safety Methodology</Link>
              </div>
              <div className={styles.heroStats}>
                <div>
                  <strong>4.8/5</strong>
                  <span>Average parent rating for clarity</span>
                </div>
                <div>
                  <strong>120+</strong>
                  <span>Toys tracked quarterly for NL households</span>
                </div>
                <div>
                  <strong>2 languages</strong>
                  <span>English & Español (ES-AR)</span>
                </div>
              </div>
              <p className={styles.heroDisclaimer}>
                We do not provide commercial toy sales or professional childcare consulting.
              </p>
            </div>
            <div className={styles.heroPanel}>
              <div className={styles.heroCard}>
                <p className={styles.heroCardLabel}>Weekly Toy Signal</p>
                <h3>STEM Kits Check</h3>
                <ul>
                  <li>3 magnet-based kits flagged for casing durability.</li>
                  <li>New Dutch guidelines for connected toys classified.</li>
                  <li>Community pick: Circular Blocks Lab (18-36 months).</li>
                </ul>
                <Link to="/resources" className={styles.heroCardLink}>Read the full signal →</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <p className="sectionLabel">Why Tu Progreso Hoy</p>
          <h2>Play intelligence grounded in data, culture, and heart.</h2>
          <div className={styles.valueGrid}>
            {valuePropositions.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <span className={styles.valueIcon} aria-hidden="true">{value.icon}</span>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.insights}>
        <div className="container">
          <div className={styles.insightsHeader}>
            <div>
              <p className="sectionLabel">Toy Safety Tracker NL</p>
              <h2>Data-led view of compliance trends up to 2025.</h2>
              <p>
                Our tracker aggregates EU Safety Gate alerts, Dutch NVWA inspections, and parent-reported observations.
                Slide across the timeline to see how the risk landscape is evolving.
              </p>
            </div>
            <div className={styles.yearSelector}>
              <label htmlFor="yearRange">Select year: {selectedYear}</label>
              <input
                id="yearRange"
                type="range"
                min="2021"
                max="2025"
                value={selectedYear}
                onChange={(event) => setSelectedYear(Number(event.target.value))}
              />
            </div>
          </div>

          {currentTrend && (
            <div className={styles.trendCard}>
              <div>
                <span>Safe toys on market</span>
                <strong>{currentTrend.safePercentage}%</strong>
              </div>
              <div>
                <span>Items flagged in NL</span>
                <strong>{currentTrend.flaggedItems}</strong>
              </div>
              <div className={styles.trendNote}>
                <span className={styles.noteDot} aria-hidden="true"></span>
                <p>{currentTrend.note}</p>
              </div>
            </div>
          )}

          <div className={styles.metricsGrid}>
            <div className={styles.metric}>
              <h4>Average recall response time</h4>
              <p><strong>48h</strong> once a signal enters our dashboard.</p>
            </div>
            <div className={styles.metric}>
              <h4>Dutch parent confidence score</h4>
              <p><strong>87%</strong> of members feel prepared when shopping for toys.</p>
            </div>
            <div className={styles.metric}>
              <h4>Live course cohorts</h4>
              <p><strong>6 annual circles</strong> featuring Argentine & Dutch specialists.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.coursePreview}>
        <div className="container">
          <div className={styles.courseContent}>
            <p className="sectionLabel">Parent Course Overview</p>
            <h2>From toy aisles to home rituals—guided in three steps.</h2>
            <p>
              Our course blends asynchronous resources with live bilingual circles. Whether you are a local Dutch family or newly arrived,
              you can adapt quickly to standards, development cues, and mindful play vibes.
            </p>
            <ol className={styles.steps}>
              <li>
                <h3>Decode</h3>
                <p>Learn to read EU compliance labels, NVWA alerts, and sustainability scores in under 15 minutes per module.</p>
              </li>
              <li>
                <h3>Design</h3>
                <p>Co-create play routines using our developmental matrices, sensory checklists, and scenario labs.</p>
              </li>
              <li>
                <h3>Dialogue</h3>
                <p>Join our bilingual live sessions to test your insights, ask questions, and share community-led discoveries.</p>
              </li>
            </ol>
            <Link to="/course" className={styles.courseLink}>Full course syllabus →</Link>
          </div>
          <div className={styles.courseAside}>
            <div className={styles.progressCard}>
              <p>Average completion</p>
              <strong>92%</strong>
              <span>of parents finish the four-week sprint.</span>
            </div>
            <div className={styles.progressCard}>
              <p>Time commitment</p>
              <strong>25 min</strong>
              <span>per lesson with optional deep dives.</span>
            </div>
            <div className={styles.progressCard}>
              <p>Languages</p>
              <strong>EN + ES-AR</strong>
              <span>Switch anytime during the course.</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.expertSection}>
        <div className="container">
          <div className={styles.expertHeader}>
            <div>
              <p className="sectionLabel">Expert Collective & Play Lab</p>
              <h2>Meet the minds guiding our Dutch-Argentine play lab.</h2>
              <p>
                Our advisors connect EU regulation, pedagogy, and product design. Explore their latest lab snapshots to inspire safe, joyful play at home.
              </p>
            </div>
            <div className={styles.filterGroup}>
              <button
                type="button"
                className={activeCategory === 'All' ? styles.filterActive : ''}
                onClick={() => setActiveCategory('All')}
              >
                All
              </button>
              {['Eco', 'STEM', 'Inclusive', 'Outdoor'].map((category) => (
                <button
                  key={category}
                  type="button"
                  className={activeCategory === category ? styles.filterActive : ''}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={`${member.name}, ${member.title}`} loading="lazy" />
                <div>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.title}</p>
                  <p>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>

          <div className={styles.snapshotGrid}>
            {filteredSnapshots.map((snapshot) => (
              <article key={snapshot.id} className={styles.snapshotCard}>
                <img src={snapshot.image} alt={`${snapshot.title} sample`} loading="lazy" />
                <div className={styles.snapshotContent}>
                  <span className={styles.snapshotCategory}>{snapshot.category}</span>
                  <h3>{snapshot.title}</h3>
                  <p>{snapshot.focus}</p>
                  <p className={styles.snapshotAge}>Ideal for: {snapshot.ageRange}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <p className="sectionLabel">Parent Stories</p>
          <h2>Confidence travels from Buenos Aires to Utrecht.</h2>
          <div className={styles.testimonialGrid}>
            {testimonials.map((testimonial) => (
              <blockquote key={testimonial.name} className={styles.testimonialCard}>
                <p>{testimonial.quote}</p>
                <footer>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.blogHeader}>
            <div>
              <p className="sectionLabel">Learning Hub</p>
              <h2>Latest resources to inspire safe, inclusive play.</h2>
            </div>
            <Link to="/resources" className={styles.blogLink}>View all resources</Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <span className={styles.blogLanguage}>{post.language}</span>
                <h3>{post.title}</h3>
                <p>{post.summary}</p>
                <Link to={post.link} className={styles.blogRead}>Read more →</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta} id="intro-form">
        <div className="container">
          <div className={styles.ctaInner}>
            <div className={styles.ctaCopy}>
              <p className="sectionLabel">Start your play transformation</p>
              <h2>Request a free intro lesson and get the 2025 Toy Safety Cheat Sheet.</h2>
              <p>
                Share a few details so we can tailor the lesson to your household. You will receive a bilingual guide,
                the latest recall summary, and tips for age-appropriate play rituals.
              </p>
            </div>
            <form className={styles.ctaForm} onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="ctaName">Parent name *</label>
                <input
                  id="ctaName"
                  name="name"
                  type="text"
                  placeholder="Your name"
                  value={formData.name}
                  onChange={(event) => setFormData({ ...formData, name: event.target.value })}
                  aria-describedby={errors.name ? 'ctaName-error' : undefined}
                />
                {errors.name && <span className={styles.error} id="ctaName-error">{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="ctaEmail">Email *</label>
                <input
                  id="ctaEmail"
                  name="email"
                  type="email"
                  placeholder="you@email.com"
                  value={formData.email}
                  onChange={(event) => setFormData({ ...formData, email: event.target.value })}
                  aria-describedby={errors.email ? 'ctaEmail-error' : undefined}
                />
                {errors.email && <span className={styles.error} id="ctaEmail-error">{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="ctaChildAge">Child age or stage</label>
                <input
                  id="ctaChildAge"
                  name="childAge"
                  type="text"
                  placeholder="E.g., 3 years or newborn"
                  value={formData.childAge}
                  onChange={(event) => setFormData({ ...formData, childAge: event.target.value })}
                />
              </div>
              <button type="submit" className={styles.submitBtn}>Send me the intro lesson</button>
              <p className={styles.formNote}>
                By submitting, you agree to our <Link to="/privacy">Privacy Policy</Link> and consent to receive onboarding emails.
              </p>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;