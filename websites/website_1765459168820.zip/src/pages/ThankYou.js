import React from 'react';
import { Link } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './ThankYou.module.css';

const ThankYouPage = () => {
  usePageMetadata({
    title: 'Thank You | Tu Progreso Hoy',
    description: 'Thank you for connecting with Tu Progreso Hoy. We will reach out with your intro resources soon.'
  });

  return (
    <div className={styles.page}>
      <div className="container">
        <div className={styles.card}>
          <h1>Thank you! 🎉</h1>
          <p>
            Your request is in good hands. Expect an email from our team within the next 24 hours
            with your intro lesson, toy safety cheat sheet, and suggestions for the Netherlands.
          </p>
          <Link to="/" className={styles.link}>Back to home</Link>
        </div>
      </div>
    </div>
  );
};

export default ThankYouPage;