import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} id="site-footer">
      <div className={`container ${styles.grid}`}>
        <div>
          <div className={styles.brand}>
            <span className={styles.brandMark}>TP</span>
            <div>
              <p className={styles.brandTitle}>Tu Progreso Hoy</p>
              <p className={styles.tagline}>Toy safety intelligence & parenting course for NL families.</p>
            </div>
          </div>
          <p className={styles.disclaimer}>
            We do not provide commercial toy sales or professional childcare consulting.
          </p>
        </div>

        <div className={styles.column}>
          <h4>Explore</h4>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/inflation">Methodology & Safety</Link></li>
            <li><Link to="/course">Parent Course</Link></li>
            <li><Link to="/resources">Play Resources</Link></li>
            <li><Link to="/services">Platform Solutions</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Company</h4>
          <ul>
            <li><Link to="/about">About Tu Progreso Hoy</Link></li>
            <li><Link to="/terms">Terms of Service</Link></li>
            <li><Link to="/privacy">Privacy Policy</Link></li>
            <li><Link to="/cookies">Cookie Policy</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Contact</h4>
          <ul className={styles.contactList}>
            <li>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</li>
            <li><a href="tel:+541155551234">+54 11 5555-1234</a></li>
            <li><a href="mailto:info@tuprogresohoy.com">info@tuprogresohoy.com</a></li>
          </ul>
          <div className={styles.socials}>
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              in
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
              IG
            </a>
            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
              fb
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {new Date().getFullYear()} Tu Progreso Hoy. Crafted for parents in the Netherlands with Latin warmth.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;