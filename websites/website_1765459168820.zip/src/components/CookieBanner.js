import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const consent = localStorage.getItem('tph_cookie_consent');
      if (!consent) {
        const timer = setTimeout(() => setVisible(true), 800);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const handleAccept = () => {
    setVisible(false);
    if (typeof window !== 'undefined') {
      localStorage.setItem('tph_cookie_consent', 'accepted');
    }
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <h3>Cookies & Play Insights</h3>
        <p>
          We use cookies to understand how Dutch families explore our toy safety platform and to tailor bilingual content.
          You can learn more in our <a href="/cookies">Cookie Policy</a>.
        </p>
      </div>
      <button onClick={handleAccept} className={styles.button}>Accept</button>
    </div>
  );
};

export default CookieBanner;