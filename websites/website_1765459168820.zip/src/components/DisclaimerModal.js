import React from 'react';
import styles from './DisclaimerModal.module.css';

const DisclaimerModal = ({ isVisible, onClose }) => {
  if (!isVisible) return null;

  return (
    <div className={styles.overlay} role="alertdialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className={styles.modal}>
        <h3 id="disclaimer-title">Important service note</h3>
        <p>
          We do not provide commercial toy sales or professional childcare consulting. Tu Progreso Hoy focuses on data insights, safety monitoring, and parent education.
        </p>
        <button onClick={onClose} className={styles.button}>Understood</button>
      </div>
    </div>
  );
};

export default DisclaimerModal;