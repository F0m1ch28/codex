(function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const body = document.body;

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('open');
            body.classList.toggle('nav-open');
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navToggle.classList.remove('active');
                navMenu.classList.remove('open');
                body.classList.remove('nav-open');
            });
        });
    }

    const banner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');

    if (banner && acceptBtn && declineBtn) {
        const cookieChoice = localStorage.getItem('dantesdjkg_cookie_choice');
        if (!cookieChoice) {
            banner.style.display = 'flex';
        }

        acceptBtn.addEventListener('click', function () {
            localStorage.setItem('dantesdjkg_cookie_choice', 'accepted');
            banner.style.display = 'none';
        });

        declineBtn.addEventListener('click', function () {
            localStorage.setItem('dantesdjkg_cookie_choice', 'declined');
            banner.style.display = 'none';
        });
    }
})();