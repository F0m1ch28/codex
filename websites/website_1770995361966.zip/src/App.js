import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage, {
  EventsPage,
  ResourcesPage,
  BlogPage,
  BlogArticlePage,
} from './pages/Services';
import ContactPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsOfServicePage, { CookiePolicyPage } from './pages/TermsOfService';
import PrivacyPolicyPage from './pages/PrivacyPolicy';

const App = () => {
  const NotFoundPage = () => (
    <div className="page not-found-page">
      <Helmet>
        <title>Страница не найдена | Rainbow Harmony</title>
        <meta
          name="description"
          content="Запрошенная страница не найдена. Вернитесь на главную Rainbow Harmony, чтобы продолжить знакомство с сообществом."
        />
      </Helmet>
      <section className="section">
        <div className="container narrow">
          <h1>Страница не найдена</h1>
          <p>
            Похоже, вы искали страницу, которая отсутствует или была перемещена.
            Перейдите на главную, чтобы продолжить путешествие вместе с Rainbow Harmony.
          </p>
          <a className="button primary-button" href="/">
            Вернуться на главную
          </a>
        </div>
      </section>
    </div>
  );

  return (
    <BrowserRouter>
      <ScrollToTop />
      <CookieBanner />
      <a href="#main-content" className="skip-link">
        Перейти к основному содержанию
      </a>
      <div className="app-shell">
        <Header />
        <main id="main-content" className="main-content" tabIndex="-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/o-nas" element={<AboutPage />} />
            <Route path="/programmy" element={<ServicesPage />} />
            <Route path="/sobytiya" element={<EventsPage />} />
            <Route path="/resursy" element={<ResourcesPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:slug" element={<BlogArticlePage />} />
            <Route path="/kontakty" element={<ContactPage />} />
            <Route path="/spasibo" element={<ThankYouPage />} />
            <Route path="/pravila-polzovaniya" element={<TermsOfServicePage />} />
            <Route path="/politika-konfidencialnosti" element={<PrivacyPolicyPage />} />
            <Route path="/politika-cookie" element={<CookiePolicyPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
};

export default App;