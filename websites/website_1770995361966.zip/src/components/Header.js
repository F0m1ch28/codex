import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const navItems = [
    { path: '/', label: 'Главная' },
    { path: '/o-nas', label: 'О нас' },
    { path: '/sobytiya', label: 'События' },
    { path: '/resursy', label: 'Ресурсы' },
    { path: '/blog', label: 'Блог' },
    { path: '/kontakty', label: 'Контакты' },
  ];

  return (
    <header className="site-header" role="banner">
      <div className="container header-container">
        <Link to="/" className="brand" aria-label="Rainbow Harmony главная">
          <span className="brand-mark" aria-hidden="true">
            🌈
          </span>
          <span className="brand-name">Rainbow Harmony</span>
        </Link>
        <button
          className="menu-toggle"
          type="button"
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          onClick={() => setIsMenuOpen((prev) => !prev)}
        >
          <span className="menu-icon" aria-hidden="true" />
          <span className="menu-label">Меню</span>
        </button>
        <nav
          id="primary-navigation"
          className={"primary-navigation ${isMenuOpen ? 'open' : ''}"}
          aria-label="Основное меню"
        >
          <ul>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive ? 'nav-link active' : 'nav-link'
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className="header-cta">
            <Link to="/programmy" className="button secondary-button">
              Программы
            </Link>
            <Link to="/kontakty" className="button primary-button">
              Связаться
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;