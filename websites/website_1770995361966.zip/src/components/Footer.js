import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-grid">
      <div className="footer-column">
        <div className="footer-brand">
          <span className="brand-mark" aria-hidden="true">
            🌈
          </span>
          <span className="brand-name">Rainbow Harmony</span>
        </div>
        <p className="footer-description">
          Сообщество взаимопонимания, поддержки и гармонии для ЛГБТК+ людей и их друзей.
        </p>
        <div className="footer-social">
          <a
            href="https://vk.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Мы во ВКонтакте"
          >
            <span aria-hidden="true">VK</span>
          </a>
          <a
            href="https://t.me"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Мы в Telegram"
          >
            <span aria-hidden="true">TG</span>
          </a>
          <a
            href="https://youtube.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Мы на YouTube"
          >
            <span aria-hidden="true">YT</span>
          </a>
        </div>
      </div>
      <div className="footer-column">
        <h3 className="footer-title">Навигация</h3>
        <ul className="footer-links">
          <li>
            <Link to="/">Главная</Link>
          </li>
          <li>
            <Link to="/o-nas">О нас</Link>
          </li>
          <li>
            <Link to="/sobytiya">События</Link>
          </li>
          <li>
            <Link to="/resursy">Ресурсы</Link>
          </li>
          <li>
            <Link to="/blog">Блог</Link>
          </li>
          <li>
            <Link to="/kontakty">Контакты</Link>
          </li>
        </ul>
      </div>
      <div className="footer-column">
        <h3 className="footer-title">Контакты</h3>
        <address>
          <p>г. Москва, Ленинградский проспект, д. 39, стр. 79</p>
          <p>
            Телефон:{' '}
            <a href="tel:+74951234567" className="footer-link">
              +7 (495) 123-45-67
            </a>
          </p>
            <p className="footer-note">
              <Link to="/kontakty" className="footer-link">
                Подробнее о контактах
              </Link>
            </p>
          <p>
            Email:{' '}
            <a href="mailto:info@rainbow-harmony.ru" className="footer-link">
              info@rainbow-harmony.ru
            </a>
          </p>
        </address>
      </div>
      <div className="footer-column">
        <h3 className="footer-title">Правовая информация</h3>
        <ul className="footer-links">
          <li>
            <Link to="/pravila-polzovaniya">Правила пользования</Link>
          </li>
          <li>
            <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
          </li>
          <li>
            <Link to="/politika-cookie">Политика cookie</Link>
          </li>
        </ul>
        <p className="footer-smallprint">
          © {new Date().getFullYear()} Rainbow Harmony. Все права защищены.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;