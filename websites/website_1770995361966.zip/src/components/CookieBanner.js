import React, { useState, useEffect } from 'react';

const STORAGE_KEY = 'rainbow-harmony-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      const storedChoice = localStorage.getItem(STORAGE_KEY);
      if (!storedChoice) {
        setVisible(true);
      }
    } catch (error) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (consent) => {
    try {
      localStorage.setItem(STORAGE_KEY, consent);
    } catch (error) {
      // graceful fallback without blocking UI
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          Мы используем cookie, чтобы сделать сайт удобнее и внимательнее к вашим интересам.
          Настройки можно изменить в любое время.
        </p>
        <div className="cookie-actions">
          <button
            type="button"
            className="button primary-button"
            onClick={() => handleChoice('accepted')}
          >
            Принять
          </button>
          <button
            type="button"
            className="button ghost-button"
            onClick={() => handleChoice('declined')}
          >
            Отклонить
          </button>
          <a className="cookie-link" href="/politika-cookie">
            Подробнее
          </a>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;