import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';

const ContactPage = () => {
  const navigate = useNavigate();
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [submissionStatus, setSubmissionStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) {
      newErrors.name = 'Укажите ваше имя.';
    }
    if (!formState.email.trim()) {
      newErrors.email = 'Укажите email.';
    } else {
      const emailPattern =
        /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
      if (!emailPattern.test(formState.email.trim())) {
        newErrors.email = 'Проверьте корректность email.';
      }
    }
    if (!formState.message.trim()) {
      newErrors.message = 'Расскажите, с чем мы можем помочь.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmissionStatus(null);

    if (!validate()) {
      return;
    }

    setSubmissionStatus({
      type: 'success',
      message: 'Сообщение отправлено. Перенаправляем…',
    });

    setTimeout(() => {
      navigate('/spasibo');
    }, 600);
  };

  return (
    <div className="page contact-page">
      <Helmet>
        <title>Контакты Rainbow Harmony — напишите нам</title>
        <meta
          name="description"
          content="Свяжитесь с Rainbow Harmony: адрес в Москве, телефон +7 (495) 123-45-67, email info@rainbow-harmony.ru. Заполните форму для связи с командой."
        />
      </Helmet>

      <section className="section page-hero">
        <div className="container narrow">
          <p className="page-kicker">Контакты</p>
          <h1>Давайте познакомимся и будем на связи</h1>
          <p>
            Заполните форму или используйте удобный способ связи. Мы ответим в течение двух рабочих дней.
          </p>
        </div>
      </section>

      <section className="section contact-content">
        <div className="container grid-two">
          <div className="contact-details">
            <h2>Как нас найти</h2>
            <ul className="contact-list">
              <li>
                <span className="contact-label">Адрес:</span>
                <span>г. Москва, Ленинградский проспект, д. 39, стр. 79</span>
              </li>
              <li>
                <span className="contact-label">Телефон:</span>
                <a href="tel:+74951234567" className="contact-link">
                  +7 (495) 123-45-67
                </a>
              </li>
              <li>
                <span className="contact-label">Email:</span>
                <a href="mailto:info@rainbow-harmony.ru" className="contact-link">
                  info@rainbow-harmony.ru
                </a>
              </li>
            </ul>
            <div className="contact-info-card">
              <h3>Часы обратной связи</h3>
              <p>
                Пн–Пт: 11:00–19:00 МСК<br />
                Сб–Вс: по предварительной записи
              </p>
              <p>
                В экстренных ситуациях воспользуйтесь ресурсами в разделе{' '}
                <a href="/resursy">Ресурсы</a>.
              </p>
            </div>
          </div>

          <div className="contact-form-wrapper">
            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <div className="form-field">
                <label htmlFor="contact-name">Имя</label>
                <input
                  id="contact-name"
                  name="name"
                  type="text"
                  autoComplete="name"
                  value={formState.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && (
                  <span className="field-error" role="alert">
                    {errors.name}
                  </span>
                )}
              </div>

              <div className="form-field">
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  value={formState.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && (
                  <span className="field-error" role="alert">
                    {errors.email}
                  </span>
                )}
              </div>

              <div className="form-field">
                <label htmlFor="contact-message">Сообщение</label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows="6"
                  value={formState.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && (
                  <span className="field-error" role="alert">
                    {errors.message}
                  </span>
                )}
              </div>

              <button type="submit" className="button primary-button">
                Отправить сообщение
              </button>
              {submissionStatus && (
                <p
                  className={"form-feedback ${submissionStatus.type}"}
                  role="status"
                  aria-live="polite"
                >
                  {submissionStatus.message}
                </p>
              )}
            </form>
          </div>
        </div>
      </section>

      <section className="section faq-section">
        <div className="container">
          <div className="section-header">
            <h2>Частые вопросы</h2>
            <p>Если вы не нашли ответ, оставьте сообщение — мы расскажем подробнее.</p>
          </div>
          <div className="faq-grid">
            <article>
              <h3>Можно ли присоединиться к событиям из другого города?</h3>
              <p>
                Да! Большинство встреч проходит онлайн. Мы заранее отправляем необходимые ссылки и материалы
                участникам, которые зарегистрировались.
              </p>
            </article>
            <article>
              <h3>Нужен ли опыт, чтобы стать волонтёром?</h3>
              <p>
                Достаточно желания помогать. Мы проводим onboarding и делимся материалами, чтобы вам было комфортно
                присоединиться к инициативам.
              </p>
            </article>
            <article>
              <h3>Как поддержать Rainbow Harmony?</h3>
              <p>
                Можно рассказать о нас друзьям, стать наставником или предложить профессиональные навыки. Напишите,
                и мы обсудим, чем вы можете помочь.
              </p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;