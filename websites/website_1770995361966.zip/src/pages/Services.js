import React from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';

export const eventsList = [
  {
    id: 1,
    title: 'Видео-встреча: Искусство и идентичность',
    date: '12 марта 2024',
    time: '19:00 МСК',
    format: 'Онлайн',
    location: 'Zoom',
    description:
      'Разговор с художницами и художниками о том, как творчество помогает проживать и выражать идентичность.',
    image: 'https://picsum.photos/seed/rainbow-event1/640/420',
    registration: 'https://forms.gle/example1',
  },
  {
    id: 2,
    title: 'Киноклуб: Просмотр и обсуждение',
    date: '24 марта 2024',
    time: '18:30 МСК',
    format: 'Офлайн',
    location: 'Москва, культурное пространство “Поток”',
    description:
      'Совместный просмотр короткометражек и дискуссия о том, как кино влияет на общественное восприятие.',
    image: 'https://picsum.photos/seed/rainbow-event2/640/420',
    registration: 'https://forms.gle/example2',
  },
  {
    id: 3,
    title: 'Практики устойчивости: дыхание и движение',
    date: '6 апреля 2024',
    time: '12:00 МСК',
    format: 'Онлайн',
    location: 'Zoom',
    description:
      'Телесный практикум по техникам осознанности и самоподдержки в сложные периоды.',
    image: 'https://picsum.photos/seed/rainbow-event3/640/420',
    registration: 'https://forms.gle/example3',
  },
  {
    id: 4,
    title: 'Совместный брейншторм волонтёров',
    date: '16 апреля 2024',
    time: '20:00 МСК',
    format: 'Онлайн',
    location: 'Discord',
    description:
      'Обсуждаем новые инициативы, собираем идеи и распределяем задачи для волонтёрских команд.',
    image: 'https://picsum.photos/seed/rainbow-event4/640/420',
    registration: 'https://forms.gle/example4',
  },
];

export const resourceCategories = [
  {
    id: 1,
    title: 'Психологическая поддержка',
    icon: '💬',
    description:
      'Проверенные специалисты, работающие с запросами идентичности, тревожности и жизненных переходов.',
    links: [
      {
        label: 'Ассоциация специалистов по ЛГБТК+ вопросам',
        url: 'https://psyhelp24.org',
      },
      {
        label: 'Психологическая линия доверия',
        url: 'https://help.lgbt',
      },
      {
        label: 'Телеграм-канал о заботе о себе',
        url: 'https://t.me/selfcare_channel',
      },
    ],
  },
  {
    id: 2,
    title: 'Юридические консультации',
    icon: '⚖️',
    description:
      'Материалы и партнёры, которые помогают разобраться с документами, защитой прав и трудовыми вопросами.',
    links: [
      {
        label: 'Правовое пространство “Согласие”',
        url: 'https://lgbtlegal.org',
      },
      {
        label: 'Гид по юридическим вопросам ЛГБТК+',
        url: 'https://lgbt-legal-guide.com',
      },
      {
        label: 'Образцы обращений и заявлений',
        url: 'https://docs.google.com',
      },
    ],
  },
  {
    id: 3,
    title: 'История и культура',
    icon: '📚',
    description:
      'Подборка курсов, фильмов и публикаций, рассказывающих о богатстве ЛГБТК+ культуры в России и мире.',
    links: [
      {
        label: 'Цифровой архив культуры',
        url: 'https://queerarchive.org',
      },
      {
        label: 'Подкаст “Голоса сообщества”',
        url: 'https://podcasts.apple.com',
      },
      {
        label: 'Лекторий Rainbow Harmony',
        url: 'https://youtube.com',
      },
    ],
  },
  {
    id: 4,
    title: 'Ресурсы для союзников',
    icon: '🤗',
    description:
      'Гайды и тренинги для друзей, родных и коллег, которые хотят эффективно поддерживать ЛГБТК+ людей.',
    links: [
      {
        label: 'Методичка для союзников',
        url: 'https://allyguide.org',
      },
      {
        label: 'Инклюзивность на работе',
        url: 'https://inclusive.work',
      },
      {
        label: 'Вебинары Rainbow Harmony',
        url: 'https://rainbow-harmony.ru/webinars',
      },
    ],
  },
];

export const blogPosts = [
  {
    slug: 'istoriya-simvolov-soobschestva',
    title: 'История символов сообщества: от флага до цифровых трендов',
    excerpt:
      'Разбираем, как появлялись и трансформировались символы, объединяющие ЛГБТК+ людей по всему миру.',
    category: 'Культура',
    readTime: '7 минут',
    coverImage: 'https://picsum.photos/seed/rainbow-blog1/720/480',
    keywords: ['символы', 'история', 'культура'],
    content: [
      'ЛГБТК+ движение богато визуальными символами, которые помогают чувствовать сопричастность и рассказывать о ценностях сообщества.',
      'Первый радужный флаг был разработан Гилбертом Бейкером в 1978 году. С тех пор палитра расширялась, появлялись варианты для разных идентичностей и инициатив.',
      'В цифровую эпоху символы приобрели новые формы: эмодзи, хэштеги, стикеры и фильтры усиливают видимость и создают дружелюбные пространства в сети.',
      'Символика важна не только как знак принадлежности. Она помогает разрабатывать образовательные программы, развивать брендинг инициатив и делать сообщества узнаваемыми.',
    ],
    featuredQuote:
      '“Визуальные символы помогают нам видеть друг друга и оставаться связанными даже на расстоянии.”',
  },
  {
    slug: 'kak-sozdat-podderzhivayuschee-okruzhenie',
    title: 'Как создать поддерживающее окружение дома и на работе',
    excerpt:
      'Пять шагов, которые помогают выстроить уважительное и безопасное пространство для всех.',
    category: 'Практика',
    readTime: '6 минут',
    coverImage: 'https://picsum.photos/seed/rainbow-blog2/720/480',
    keywords: ['поддержка', 'allyship', 'коммуникация'],
    content: [
      'Поддерживающее окружение — это комбинация осознанности, действий и готовности слушать.',
      'Начните с языка. Используйте инклюзивные формулировки, спрашивайте, как человеку комфортнее, и уважайте выбранные местоимения.',
      'Создайте систему поддержки: изучите ресурсы, предложите помощь, создайте каналы обратной связи.',
      'Не забывайте о границах. Уважение к границам — ключ к безопасному диалогу и доверию.',
    ],
    featuredQuote:
      '“Поддержка начинается с доверия и готовности учиться. Сообщество становится сильнее, когда мы действуем вместе.”',
  },
  {
    slug: 'praktiki-osennego-tepla',
    title: 'Практики осеннего тепла: заботимся о себе и близких',
    excerpt:
      'Осень — время перезагрузки. Делимся ритуалами и практиками, которые помогают сохранить баланс.',
    category: 'Забота о себе',
    readTime: '5 минут',
    coverImage: 'https://picsum.photos/seed/rainbow-blog3/720/480',
    keywords: ['забота', 'ментальное здоровье', 'практики'],
    content: [
      'Когда сокращается световой день, важно уделять внимание телу и эмоциям.',
      'Попробуйте тёплые вечерние ритуалы: свечи, плейлисты, ведение дневника благодарности.',
      'Связывайтесь с людьми, которые вас поддерживают — групповые звонки, совместные прогулки или просмотр фильмов могут стать прекрасной традицией.',
      'Не забывайте про профессиональную помощь. Психолог или коуч поможет выстроить устойчивые привычки заботы о себе.',
    ],
    featuredQuote:
      '“Забота о себе — это не роскошь, а необходимая часть гармоничной жизни.”',
  },
];

const ServicesPage = () => {
  const services = [
    {
      title: 'Команды взаимопомощи',
      description:
        'Тёплые встречи по интересам и запросам: от эмоциональной поддержки до профессионального обмена.',
      benefit: 'Найти людей, которые разделяют похожий опыт и готовы поддержать.',
    },
    {
      title: 'Культурные проекты',
      description:
        'Выставки, кинопоказы, клубы чтения и творческие лаборатории, раскрывающие богатство культурного наследия.',
      benefit: 'Расширить кругозор и познакомиться с новыми формами самовыражения.',
    },
    {
      title: 'Образовательные программы',
      description:
        'Лекции, мастер-классы и корпоративные тренинги по инклюзивности и этике взаимодействия.',
      benefit: 'Сформировать навыки поддерживающего общения и allyship.',
    },
  ];

  return (
    <div className="page services-page">
      <Helmet>
        <title>Программы и инициативы Rainbow Harmony</title>
        <meta
          name="description"
          content="Программы Rainbow Harmony: взаимопомощь, культурные проекты и образовательные инициативы для ЛГБТК+ сообщества и союзников."
        />
      </Helmet>

      <section className="section page-hero">
        <div className="container narrow">
          <p className="page-kicker">Программы</p>
          <h1>Что мы делаем для сообщества</h1>
          <p>
            Rainbow Harmony — это живое пространство инициатив. Мы слушаем запросы участников и
            создаём программы, которые помогают чувствовать уверенность, развиваться и находить друзей.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container card-grid">
          {services.map((service) => (
            <article className="program-card" key={service.title}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <p className="program-benefit">
                <strong>Что даёт:</strong> {service.benefit}
              </p>
            </article>
          ))}
        </div>
      </section>

      <section className="section cta-section">
        <div className="container cta-inner">
          <div>
            <h2>Хотите присоединиться к программе?</h2>
            <p>
              Напишите нам, чтобы получить расписание встреч и записаться на ближайшее мероприятие.
            </p>
          </div>
          <Link to="/kontakty" className="button primary-button">
            Оставить заявку
          </Link>
        </div>
      </section>
    </div>
  );
};

export const EventsPage = () => (
  <div className="page events-page">
    <Helmet>
      <title>События Rainbow Harmony — встречи и инициативы</title>
      <meta
        name="description"
        content="Расписание онлайн и офлайн событий Rainbow Harmony: творческие вечера, брейнштормы волонтёров, практики заботы о себе."
      />
    </Helmet>

    <section className="section page-hero">
      <div className="container narrow">
        <p className="page-kicker">События</p>
        <h1>Предстоящие встречи Rainbow Harmony</h1>
        <p>
          Присоединяйтесь к онлайн- и офлайн-мероприятиям — от творческих вечеров до групп волонтёрской поддержки.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container card-grid">
        {eventsList.map((event) => (
          <article className="event-card large" key={event.id} id={"event-${event.id}"}>
            <img src={event.image} alt={event.title} loading="lazy" />
            <div className="event-content">
              <p className="event-meta">
                {event.date} · {event.time} · {event.format}
              </p>
              <h2>{event.title}</h2>
              <p>{event.description}</p>
              <p className="event-location">
                <strong>Локация:</strong> {event.location}
              </p>
              <a
                href={event.registration}
                className="button secondary-button"
                target="_blank"
                rel="noopener noreferrer"
              >
                Зарегистрироваться
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
  </div>
);

export const ResourcesPage = () => (
  <div className="page resources-page">
    <Helmet>
      <title>Ресурсы и поддержка Rainbow Harmony</title>
      <meta
        name="description"
        content="Подборка ресурсов Rainbow Harmony: психологи, юристы, культурные инициативы и материалы для союзников."
      />
    </Helmet>

    <section className="section page-hero">
      <div className="container narrow">
        <p className="page-kicker">Ресурсы</p>
        <h1>Поддержка и знания для гармоничной жизни</h1>
        <p>
          Мы собираем и проверяем материалы, которые помогают заботиться о себе, защищать свои права и расширять кругозор.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container card-grid">
        {resourceCategories.map((resource) => (
          <article className="resource-card detailed" key={resource.id}>
            <div className="resource-icon" aria-hidden="true">
              {resource.icon}
            </div>
            <h2>{resource.title}</h2>
            <p>{resource.description}</p>
            <ul>
              {resource.links.map((link) => (
                <li key={link.url}>
                  <a href={link.url} target="_blank" rel="noopener noreferrer">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>
  </div>
);

export const BlogPage = () => (
  <div className="page blog-page">
    <Helmet>
      <title>Блог Rainbow Harmony — истории и практики</title>
      <meta
        name="description"
        content="Читайте блог Rainbow Harmony: истории сообществ, практики заботы о себе, рекомендации для союзников и культурные обзоры."
      />
    </Helmet>

    <section className="section page-hero">
      <div className="container narrow">
        <p className="page-kicker">Блог</p>
        <h1>Истории, вдохновение и практические советы</h1>
        <p>
          Мы делимся опытом участников, полезными заметками и идеями, которые помогают быть внимательнее к себе и окружающим.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container card-grid">
        {blogPosts.map((post) => (
          <article className="blog-card large" key={post.slug}>
            <img src={post.coverImage} alt={post.title} loading="lazy" />
            <div className="blog-content">
              <p className="blog-meta">
                {post.category} · {post.readTime}
              </p>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <Link to={"/blog/${post.slug}"} className="button ghost-button">
                Читать дальше
              </Link>
            </div>
          </article>
        ))}
      </div>
    </section>
  </div>
);

export const BlogArticlePage = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const article = blogPosts.find((post) => post.slug === slug);

  if (!article) {
    return (
      <div className="page article-page">
        <Helmet>
          <title>Статья не найдена | Rainbow Harmony</title>
        </Helmet>
        <section className="section">
          <div className="container narrow">
            <h1>Статья не найдена</h1>
            <p>Похоже, ссылка устарела. Перейдите к другим материалам блога.</p>
            <button type="button" className="button primary-button" onClick={() => navigate('/blog')}>
              Вернуться в блог
            </button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page article-page">
      <Helmet>
        <title>{"${article.title} | Блог Rainbow Harmony"}</title>
        <meta name="description" content={article.excerpt} />
        <meta name="keywords" content={article.keywords.join(', ')} />
      </Helmet>

      <article className="section">
        <div className="container narrow">
          <p className="blog-meta">
            {article.category} · {article.readTime}
          </p>
          <h1>{article.title}</h1>
          <img
            className="article-image"
            src={article.coverImage}
            alt={article.title}
            loading="lazy"
          />
          {article.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
          <blockquote className="article-quote">“{article.featuredQuote}”</blockquote>
          <div className="article-back">
            <Link to="/blog" className="button ghost-button">
              Вернуться в блог
            </Link>
          </div>
        </div>
      </article>
    </div>
  );
};

export default ServicesPage;