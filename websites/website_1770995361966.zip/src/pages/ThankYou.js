import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';

const ThankYouPage = () => (
  <div className="page thank-you-page">
    <Helmet>
      <title>Спасибо за сообщение | Rainbow Harmony</title>
      <meta
        name="description"
        content="Мы получили ваше сообщение. Команда Rainbow Harmony свяжется с вами в ближайшее время."
      />
    </Helmet>

    <section className="section">
      <div className="container narrow thank-you-card">
        <h1>Спасибо за контакт!</h1>
        <p>
          Мы внимательно прочитаем ваше сообщение и ответим в течение двух рабочих дней.
          В экстренных ситуациях воспользуйтесь ресурсами в соответствующем разделе.
        </p>
        <div className="thank-you-actions">
          <Link to="/" className="button primary-button">
            На главную
          </Link>
          <Link to="/resursy" className="button secondary-button">
            Посмотреть ресурсы
          </Link>
        </div>
      </div>
    </section>
  </div>
);

export default ThankYouPage;