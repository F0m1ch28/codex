import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { eventsList, resourceCategories, blogPosts } from './Services';

const HomePage = () => {
  const [subscriptionEmail, setSubscriptionEmail] = useState('');
  const [subscriptionFeedback, setSubscriptionFeedback] = useState(null);

  const serviceHighlights = [
    {
      title: 'Группы взаимопомощи',
      description:
        'Небольшие встречи онлайн и офлайн, где можно обсудить важные темы и получить поддержку единомышленников.',
      icon: '🤝',
    },
    {
      title: 'Культурные события',
      description:
        'Кино, искусство, лекции и творческие вечера, раскрывающие разнообразие опытов ЛГБТК+ сообщества.',
      icon: '🎨',
    },
    {
      title: 'Консультации специалистов',
      description:
        'Партнёрская сеть психологов, юристов и медиаторов, которые чувствительно и профессионально решают вопросы.',
      icon: '🧠',
    },
  ];

  const testimonials = [
    {
      name: 'Мария, Санкт-Петербург',
      role: 'Волонтёр инициативной группы',
      quote:
        'В Rainbow Harmony я впервые почувствовала, что меня слышат. Здесь безопасно быть собой и вместе искать решения.',
      image: 'https://picsum.photos/seed/rainbow-testimonial1/120/120',
    },
    {
      name: 'Александр, Казань',
      role: 'Участник комьюнити',
      quote:
        'Мне нравятся насыщенные события и теплая атмосфера. Даже онлайн встречи дарят ощущение присутствия и поддержки.',
      image: 'https://picsum.photos/seed/rainbow-testimonial2/120/120',
    },
    {
      name: 'Лейла, Москва',
      role: 'Куратор образовательных программ',
      quote:
        'Команда Rainbow Harmony умеет объединять людей и открывать новые перспективы через культуру и диалог.',
      image: 'https://picsum.photos/seed/rainbow-testimonial3/120/120',
    },
  ];

  const teamPreview = [
    {
      name: 'Екатерина Орлова',
      position: 'Основательница',
      description:
        'Социальная активистка и медиатор. Создала Rainbow Harmony, чтобы объединить людей и опыт.',
      image: 'https://picsum.photos/seed/rainbow-team1/280/300',
    },
    {
      name: 'Даниил Кузнецов',
      position: 'Координатор программ',
      description:
        'Организует событийную повестку и поддерживает волонтёров по всей стране.',
      image: 'https://picsum.photos/seed/rainbow-team2/280/300',
    },
    {
      name: 'Асия Галимова',
      position: 'Психолог и исследовательница',
      description:
        'Разрабатывает методические материалы и курирует направление ментального здоровья.',
      image: 'https://picsum.photos/seed/rainbow-team3/280/300',
    },
  ];

  const handleSubscribe = (event) => {
    event.preventDefault();
    const trimmed = subscriptionEmail.trim();
    const emailPattern =
      /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;

    if (!emailPattern.test(trimmed)) {
      setSubscriptionFeedback({
        type: 'error',
        message: 'Проверьте корректность email-адреса.',
      });
      return;
    }

    setSubscriptionFeedback({
      type: 'success',
      message:
        'Спасибо! Мы добавили вас в список рассылки и скоро пришлём новости.',
    });
    setSubscriptionEmail('');
  };

  return (
    <div className="page home-page">
      <Helmet>
        <title>Rainbow Harmony — пространство гармонии и поддержки</title>
        <meta
          name="description"
          content="Rainbow Harmony — дружелюбное ЛГБТК+ сообщество в России. События, ресурсы, блог и поддержка для тех, кто ценит гармонию и разнообразие."
        />
        <meta
          name="keywords"
          content="ЛГБТК+, поддержка, сообщество, события, ресурсы, гармония, безопасность"
        />
      </Helmet>

      <section className="hero">
        <div className="container hero-inner">
          <div className="hero-content">
            <p className="hero-kicker">Сообщество тепла и уважения</p>
            <h1>Добро пожаловать в пространство гармонии и понимания</h1>
            <p className="hero-subtitle">
              Rainbow Harmony объединяет ЛГБТК+ людей и их друзей, чтобы создавать безопасные связи,
              вдохновляющие события и полезные ресурсы для счастливой, насыщенной жизни.
            </p>
            <div className="hero-actions">
              <Link to="/kontakty" className="button primary-button">
                Связаться с нами
              </Link>
              <Link to="/sobytiya" className="button ghost-button">
                Ближайшие события
              </Link>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="hero-orb orb-one" />
            <div className="hero-orb orb-two" />
            <div className="hero-orb orb-three" />
          </div>
        </div>
      </section>

      <section className="section about-preview">
        <div className="container grid-two">
          <div>
            <h2>Rainbow Harmony в нескольких словах</h2>
            <p>
              Мы создаём пространство, где у каждого есть возможность быть услышанным, получить
              поддержку и поделиться историей. Команда объединяет психологов, кураторов, волонтёров и
              активистов, которые работают ради общего благополучия.
            </p>
            <p>
              Наши направления включают культурные события, программы взаимопомощи, консультации
              специалистов и образовательные инициативы. Мы верим в гармонию через разнообразие.
            </p>
            <Link to="/o-nas" className="button secondary-button">
              Узнать больше
            </Link>
          </div>
          <div className="about-stats">
            <div className="stat-card">
              <span className="stat-value">120+</span>
              <p>постоянных участников комьюнити</p>
            </div>
            <div className="stat-card">
              <span className="stat-value">35</span>
              <p>городов России и ближнего зарубежья</p>
            </div>
            <div className="stat-card">
              <span className="stat-value">18</span>
              <p>волонтёрских инициатив за последний год</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section services-showcase">
        <div className="container">
          <div className="section-header">
            <h2>Что мы создаём вместе</h2>
            <p>
              Наши направления развиваются по запросам сообщества: от встреч взаимопомощи до
              образовательных программ для союзников.
            </p>
          </div>
          <div className="card-grid">
            {serviceHighlights.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="service-icon" aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section events-preview">
        <div className="container">
          <div className="section-header">
            <h2>Ближайшие события</h2>
            <p>Присоединяйтесь к онлайн и офлайн мероприятиям, чтобы познакомиться и вдохновиться.</p>
          </div>
          <div className="card-grid">
            {eventsList.slice(0, 3).map((event) => (
              <article className="event-card" key={event.id}>
                <img src={event.image} alt={event.title} loading="lazy" />
                <div className="event-content">
                  <p className="event-meta">
                    {event.date} · {event.format}
                  </p>
                  <h3>{event.title}</h3>
                  <p>{event.description}</p>
                  <p className="event-location">{event.location}</p>
                  <Link to="/sobytiya" className="event-link">
                    Подробнее об участии
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className="section-cta">
            <Link to="/sobytiya" className="button primary-button">
              Все события
            </Link>
          </div>
        </div>
      </section>

      <section className="section resources-preview">
        <div className="container">
          <div className="section-header">
            <h2>Полезные ресурсы</h2>
            <p>Подборки проверенных материалов и специалистов, которые помогут решить важные вопросы.</p>
          </div>
          <div className="card-grid">
            {resourceCategories.slice(0, 3).map((resource) => (
              <article className="resource-card" key={resource.id}>
                <div className="resource-icon" aria-hidden="true">
                  {resource.icon}
                </div>
                <h3>{resource.title}</h3>
                <p>{resource.description}</p>
                <ul>
                  {resource.links.slice(0, 2).map((link) => (
                    <li key={link.url}>
                      <a href={link.url} target="_blank" rel="noopener noreferrer">
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <div className="section-cta">
            <Link to="/resursy" className="button secondary-button">
              Все ресурсы
            </Link>
          </div>
        </div>
      </section>

      <section className="section blog-preview">
        <div className="container">
          <div className="section-header">
            <h2>Избранные статьи</h2>
            <p>Истории, аналитика и практические советы для сообщества и союзников.</p>
          </div>
          <div className="card-grid">
            {blogPosts.slice(0, 3).map((post) => (
              <article className="blog-card" key={post.slug}>
                <img src={post.coverImage} alt={post.title} loading="lazy" />
                <div className="blog-content">
                  <p className="blog-meta">{post.readTime} · {post.category}</p>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={"/blog/${post.slug}"} className="blog-link">
                    Читать статью
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className="section-cta">
            <Link to="/blog" className="button ghost-button">
              ЧИТАТЬ БЛОГ
            </Link>
          </div>
        </div>
      </section>

      <section className="section testimonials">
        <div className="container">
          <div className="section-header">
            <h2>Голоса сообщества</h2>
            <p>Мы ценим отзывы и бережно относимся к опыту каждого участника Rainbow Harmony.</p>
          </div>
          <div className="card-grid">
            {testimonials.map((testimonial) => (
              <figure className="testimonial-card" key={testimonial.name}>
                <img src={testimonial.image} alt={testimonial.name} loading="lazy" />
                <blockquote>“{testimonial.quote}”</blockquote>
                <figcaption>
                  <span className="testimonial-name">{testimonial.name}</span>
                  <span className="testimonial-role">{testimonial.role}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="section team-preview">
        <div className="container">
          <div className="section-header">
            <h2>Люди, которые создают гармонию</h2>
            <p>
              Команда Rainbow Harmony — это профессионалы и волонтёры, объединённые ценностями
              инклюзивности и заботы.
            </p>
          </div>
          <div className="card-grid">
            {teamPreview.map((member) => (
              <article className="team-card" key={member.name}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className="team-content">
                  <h3>{member.name}</h3>
                  <p className="team-role">{member.position}</p>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section newsletter-section" id="subscribe">
        <div className="container newsletter-inner">
          <div>
            <h2>Будем на связи</h2>
            <p>
              Подписывайтесь на рассылку, чтобы первыми узнавать о встречах, открытых лекциях и новых ресурсах.
            </p>
          </div>
          <form className="newsletter-form" onSubmit={handleSubscribe} noValidate>
            <label htmlFor="newsletter-email" className="sr-only">
              Email для подписки
            </label>
            <input
              id="newsletter-email"
              type="email"
              name="email"
              placeholder="example@email.com"
              value={subscriptionEmail}
              onChange={(event) => setSubscriptionEmail(event.target.value)}
              required
              aria-required="true"
            />
            <button type="submit" className="button primary-button">
              Подписаться
            </button>
            {subscriptionFeedback && (
              <p
                className={"form-feedback ${subscriptionFeedback.type}"}
                role="status"
                aria-live="polite"
              >
                {subscriptionFeedback.message}
              </p>
            )}
          </form>
        </div>
      </section>

      <section className="section call-to-action">
        <div className="container cta-inner">
          <div>
            <h2>Присоединяйтесь к Rainbow Harmony уже сегодня</h2>
            <p>
              Напишите нам, чтобы получить поддержку, предложить инициативу или стать волонтёром.
              Вместе мы создаём культуру уважения и дружелюбия.
            </p>
          </div>
          <div className="cta-buttons">
            <Link to="/kontakty" className="button primary-button">
              Связаться с командой
            </Link>
            <Link to="/programmy" className="button secondary-button">
              Узнать о программах
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;