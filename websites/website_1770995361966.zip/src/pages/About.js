import React from 'react';
import { Helmet } from 'react-helmet-async';

const AboutPage = () => {
  const values = [
    {
      title: 'Безопасность и уважение',
      description:
        'Мы создаём атмосферу, где каждый может свободно выражать себя, зная, что его поддерживают и слышат.',
    },
    {
      title: 'Инклюзивность и разнообразие',
      description:
        'Ценим многообразие идентичностей и жизненных путей. Поддерживаем и союзников, и тех, кто ищет свой путь.',
    },
    {
      title: 'Ответственность и профессионализм',
      description:
        'Работаем с проверенными специалистами и волонтёрами, соблюдаем этику общения и конфиденциальность.',
    },
  ];

  const milestones = [
    {
      year: '2018',
      title: 'Первые встречи',
      description:
        'Небольшая группа друзей устроила открытый разговор о поддержке и будущем ЛГБТК+ проектов в России.',
    },
    {
      year: '2020',
      title: 'Старт онлайн-программ',
      description:
        'Мы расширили формат и перешли в онлайн, чтобы оставаться на связи с участниками из разных городов.',
    },
    {
      year: '2022',
      title: 'Партнёрства и ресурсы',
      description:
        'Rainbow Harmony стала платформой, объединяющей специалистов и инициативы в единой сети поддержки.',
    },
    {
      year: '2023',
      title: 'Сообщество союзников',
      description:
        'Запустили образовательные программы для союзников и корпоративных команд, поддерживающих инклюзивность.',
    },
  ];

  return (
    <div className="page about-page">
      <Helmet>
        <title>О Rainbow Harmony — история и миссия</title>
        <meta
          name="description"
          content="Узнайте, как Rainbow Harmony создаёт безопасное пространство для ЛГБТК+ людей и их друзей, развивая программы поддержки и культурные инициативы."
        />
      </Helmet>

      <section className="section page-hero">
        <div className="container narrow">
          <p className="page-kicker">О сообществе</p>
          <h1>История Rainbow Harmony и наши ценности</h1>
          <p>
            Мы начинали как небольшая группа друзей, а сегодня Rainbow Harmony — это устойчивое и заботливое
            сообщество, которое объединяет участников из России и стран СНГ. Наша задача — превращать
            взаимопонимание в действие.
          </p>
        </div>
      </section>

      <section className="section values-section">
        <div className="container">
          <div className="section-header">
            <h2>Наши основные ценности</h2>
            <p>Каждая программа и встреча строится на принципах уважения, открытости и поддержки.</p>
          </div>
          <div className="card-grid">
            {values.map((value) => (
              <article className="value-card" key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section mission-section">
        <div className="container grid-two">
          <div>
            <h2>Миссия Rainbow Harmony</h2>
            <p>
              Мы развиваем пространство, где люди могут открыто говорить о своей идентичности,
              получать поддержку специалистов, находить друзей и предлагать собственные инициативы.
              Вместе мы заботимся о благополучии и эмоциональной устойчивости.
            </p>
            <p>
              Наши программы охватывают психологическую и юридическую поддержку, культурные события,
              образовательные проекты для союзников и корпоративные тренинги по инклюзивности.
            </p>
          </div>
          <div className="mission-card">
            <h3>Что мы делаем ежедневно</h3>
            <ul>
              <li>Поддерживаем горячие линии и чаты взаимопомощи.</li>
              <li>Проводим творческие вечера, лекции и клубы по интересам.</li>
              <li>Собираем базу проверенных специалистов и ресурсов.</li>
              <li>Организуем волонтёрские и образовательные программы.</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section milestones-section">
        <div className="container">
          <div className="section-header">
            <h2>Путь развития</h2>
            <p>Несколько важных этапов, которые сделали сообщество таким, каким вы видите его сегодня.</p>
          </div>
          <div className="timeline">
            {milestones.map((milestone) => (
              <div className="timeline-item" key={milestone.year}>
                <div className="timeline-marker" aria-hidden="true" />
                <div className="timeline-content">
                  <span className="timeline-year">{milestone.year}</span>
                  <h3>{milestone.title}</h3>
                  <p>{milestone.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section support-invite">
        <div className="container cta-inner">
          <div>
            <h2>Хотите присоединиться или задать вопрос?</h2>
            <p>
              Мы открыты к диалогу и сотрудничеству. Напишите нам, если хотите стать волонтёром,
              поделиться опытом или предложить совместный проект.
            </p>
          </div>
          <a className="button primary-button" href="/kontakty">
            Связаться с Rainbow Harmony
          </a>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;