document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function () {
            navLinks.classList.toggle('nav-open');
            this.classList.toggle('is-active');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('nav-open')) {
                    navLinks.classList.remove('nav-open');
                    menuToggle.classList.remove('is-active');
                }
            });
        });
    }

    const banner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('acceptCookies');
    const declineBtn = document.getElementById('declineCookies');
    const consent = localStorage.getItem('sptCookieConsent');

    if (banner && acceptBtn && declineBtn) {
        if (!consent) {
            banner.classList.add('is-visible');
        }

        acceptBtn.addEventListener('click', function () {
            localStorage.setItem('sptCookieConsent', 'accepted');
            banner.classList.remove('is-visible');
        });

        declineBtn.addEventListener('click', function () {
            localStorage.setItem('sptCookieConsent', 'declined');
            banner.classList.remove('is-visible');
        });
    }
});