document.addEventListener("DOMContentLoaded", function () {
  const consentKey = "icewindCookieConsent";
  const cookieBanner = document.getElementById("cookie-banner");
  const acceptButton = document.getElementById("cookie-accept");
  const declineButton = document.getElementById("cookie-decline");

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (storedConsent) {
      cookieBanner.classList.add("is-hidden");
    }

    if (acceptButton) {
      acceptButton.addEventListener("click", function () {
        localStorage.setItem(consentKey, "accepted");
        cookieBanner.classList.add("is-hidden");
      });
    }

    if (declineButton) {
      declineButton.addEventListener("click", function () {
        localStorage.setItem(consentKey, "declined");
        cookieBanner.classList.add("is-hidden");
      });
    }
  }

  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    const responseField = document.getElementById("form-response");

    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const errors = [];

      const fullName = (formData.get("fullName") || "").trim();
      const organization = (formData.get("organization") || "").trim();
      const email = (formData.get("email") || "").trim();
      const phone = (formData.get("phone") || "").trim();
      const audience = formData.get("audience");
      const message = (formData.get("message") || "").trim();

      if (!/^[a-zA-ZÀ-ÿ' -]{3,}$/.test(fullName)) {
        errors.push("Please provide a valid full name (minimum 3 characters).");
      }

      if (organization.length < 2) {
        errors.push("Organization name must be at least 2 characters long.");
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push("Enter a valid business email address.");
      }

      if (phone && !/^[+\d][\d\s\-()]{6,}$/.test(phone)) {
        errors.push("Phone number should contain only digits and standard symbols.");
      }

      if (!audience) {
        errors.push("Select the audience category that best describes your organization.");
      }

      if (message.length < 20) {
        errors.push("Message should describe your project goals in at least 20 characters.");
      }

      if (errors.length > 0) {
        responseField.classList.remove("success");
        responseField.classList.add("error");
        responseField.innerHTML = errors.join("<br>");
        responseField.setAttribute("role", "alert");
        responseField.style.display = "block";
        return;
      }

      responseField.classList.remove("error");
      responseField.classList.add("success");
      responseField.innerHTML = "Thank you for reaching out. Our northern project specialists will respond within two business days.";
      responseField.setAttribute("role", "status");
      responseField.style.display = "block";
      contactForm.reset();
    });
  }
});