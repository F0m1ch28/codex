document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const declineCookiesBtn = document.getElementById('decline-cookies');
    const culinaryButtons = document.querySelectorAll('[data-region]');
    const mapTitle = document.getElementById('map-region-title');
    const mapDescription = document.getElementById('map-region-description');
    const filterButtons = document.querySelectorAll('[data-filter]');
    const filterables = document.querySelectorAll('[data-category]');
    const modalBackdrop = document.getElementById('modal-backdrop');
    const modalContent = document.querySelector('.modal-content');
    const modalCloseBtn = document.querySelector('.modal-close');
    const modalTriggers = document.querySelectorAll('[data-modal]');
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    const lightboxCaption = document.getElementById('lightbox-caption');
    const lightboxClose = document.getElementById('lightbox-close');
    const galleryLinks = document.querySelectorAll('[data-lightbox]');
    const accordionToggles = document.querySelectorAll('.accordion-toggle');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            primaryNav.classList.toggle('nav-open');
            if (!expanded) {
                primaryNav.querySelector('a').focus();
            } else {
                navToggle.focus();
            }
        });
    }

    if (cookieBanner && acceptCookiesBtn && declineCookiesBtn) {
        const cookieChoice = localStorage.getItem('ccgr-cookie-choice');
        if (!cookieChoice) {
            cookieBanner.setAttribute('aria-hidden', 'false');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('ccgr-cookie-choice', 'accepted');
            cookieBanner.setAttribute('aria-hidden', 'true');
        });

        declineCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('ccgr-cookie-choice', 'declined');
            cookieBanner.setAttribute('aria-hidden', 'true');
        });
    }

    if (culinaryButtons && mapTitle && mapDescription) {
        culinaryButtons.forEach((button) => {
            button.addEventListener('click', () => {
                culinaryButtons.forEach((btn) => btn.setAttribute('aria-pressed', 'false'));
                button.setAttribute('aria-pressed', 'true');
                mapTitle.textContent = button.dataset.regionTitle;
                mapDescription.textContent = button.dataset.regionDescription;
            });
        });
    }

    if (filterButtons.length > 0) {
        filterButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const filter = button.dataset.filter;
                filterButtons.forEach((btn) => btn.setAttribute('aria-pressed', btn === button ? 'true' : 'false'));
                filterables.forEach((item) => {
                    if (filter === 'all' || item.dataset.category.includes(filter)) {
                        item.removeAttribute('data-hidden');
                    } else {
                        item.setAttribute('data-hidden', 'true');
                    }
                });
            });
        });
    }

    const openModal = (contentId) => {
        const template = document.getElementById(contentId);
        if (template && modalBackdrop && modalContent) {
            modalContent.innerHTML = template.innerHTML;
            modalBackdrop.setAttribute('aria-hidden', 'false');
            modalBackdrop.focus();
            body.style.overflow = 'hidden';
        }
    };

    const closeModal = () => {
        if (modalBackdrop) {
            modalBackdrop.setAttribute('aria-hidden', 'true');
            modalContent.innerHTML = '';
            body.style.overflow = '';
        }
    };

    modalTriggers.forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const modalId = trigger.dataset.modal;
            openModal(modalId);
        });
    });

    if (modalCloseBtn && modalBackdrop) {
        modalCloseBtn.addEventListener('click', closeModal);
        modalBackdrop.addEventListener('click', (event) => {
            if (event.target === modalBackdrop) {
                closeModal();
            }
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                closeModal();
                closeLightbox();
            }
        });
    }

    const openLightbox = (imageSrc, caption) => {
        if (lightbox) {
            lightboxImage.src = imageSrc;
            lightboxCaption.textContent = caption;
            lightbox.setAttribute('aria-hidden', 'false');
            body.style.overflow = 'hidden';
        }
    };

    const closeLightbox = () => {
        if (lightbox) {
            lightbox.setAttribute('aria-hidden', 'true');
            lightboxImage.src = '';
            lightboxCaption.textContent = '';
            body.style.overflow = '';
        }
    };

    galleryLinks.forEach((link) => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const imageSrc = link.getAttribute('href');
            const caption = link.dataset.caption || '';
            openLightbox(imageSrc, caption);
        });
    });

    if (lightboxClose) {
        lightboxClose.addEventListener('click', closeLightbox);
        lightbox.addEventListener('click', (event) => {
            if (event.target === lightbox) {
                closeLightbox();
            }
        });
    }

    accordionToggles.forEach((toggle) => {
        toggle.addEventListener('click', () => {
            const item = toggle.closest('.accordion-item');
            const expanded = item.getAttribute('aria-expanded') === 'true';
            item.setAttribute('aria-expanded', expanded ? 'false' : 'true');
        });
    });
});