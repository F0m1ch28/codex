document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('open');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => navLinks.classList.remove('open'));
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn');

    if (cookieBanner) {
        const savedChoice = localStorage.getItem('scapholctvCookieChoice');
        if (!savedChoice) {
            cookieBanner.classList.add('active');
        }

        cookieButtons.forEach(btn => {
            btn.addEventListener('click', (event) => {
                event.preventDefault();
                const choice = btn.dataset.choice || 'accepted';
                localStorage.setItem('scapholctvCookieChoice', choice);
                cookieBanner.classList.remove('active');
                window.location.href = btn.getAttribute('href');
            });
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const destinationCards = document.querySelectorAll('[data-continent]');

    if (filterButtons.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const target = button.dataset.filter;
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                destinationCards.forEach(card => {
                    const continent = card.dataset.continent;
                    if (target === 'all' || continent === target) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    const likeButtons = document.querySelectorAll('.story-like');
    likeButtons.forEach(button => {
        button.addEventListener('click', () => {
            button.classList.toggle('liked');
            const countSpan = button.querySelector('[data-count]');
            if (countSpan) {
                let current = parseInt(countSpan.textContent, 10);
                if (button.classList.contains('liked')) {
                    current += 1;
                } else {
                    current -= 1;
                }
                countSpan.textContent = current;
            }
        });
    });

    const saveButtons = document.querySelectorAll('.tip-save');
    saveButtons.forEach(button => {
        button.addEventListener('click', () => {
            button.classList.toggle('saved');
            const status = button.classList.contains('saved') ? 'Saved' : 'Save';
            button.querySelector('span').textContent = status;
        });
    });
});