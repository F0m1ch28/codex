document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !isExpanded);
            navMenu.classList.toggle('active');
        });
    }

    const banner = document.querySelector('[data-cookie-banner]');
    if (banner) {
        const storedChoice = localStorage.getItem('cantoniujg-cookie-choice');
        if (!storedChoice) {
            banner.classList.add('active');
        }
        const acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
        const declineBtn = banner.querySelector('[data-cookie-action="decline"]');
        const hideBanner = () => banner.classList.remove('active');

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function (event) {
                event.preventDefault();
                localStorage.setItem('cantoniujg-cookie-choice', 'accepted');
                hideBanner();
                setTimeout(() => {
                    window.location.href = acceptBtn.getAttribute('href');
                }, 200);
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function (event) {
                event.preventDefault();
                localStorage.setItem('cantoniujg-cookie-choice', 'declined');
                hideBanner();
                setTimeout(() => {
                    window.location.href = declineBtn.getAttribute('href');
                }, 200);
            });
        }
    }
});