import React from "react";

const portfolioItems = [
  {
    id: 1,
    title: "Neon Pulse",
    tags: "Digital-арт, Моушн-дизайн",
    src: "https://picsum.photos/seed/avport1/800/620",
    description:
      "Экспрессивная серия цифровых артов для музыкальной платформы с акцентом на динамику и световые эффекты.",
  },
  {
    id: 2,
    title: "Nordic Sense",
    tags: "Брендинг, Веб-дизайн",
    src: "https://picsum.photos/seed/avport2/800/620",
    description:
      "Минималистичная айдентика и сайт для скандинавского бренда косметики с focus на натуральность.",
  },
  {
    id: 3,
    title: "Urban Flow",
    tags: "Иллюстрация, Digital-арт",
    src: "https://picsum.photos/seed/avport3/800/620",
    description:
      "Серия иллюстраций для кампании городского фонда, подчёркивающих динамику мегаполиса.",
  },
  {
    id: 4,
    title: "Motion Matters",
    tags: "Моушн-дизайн",
    src: "https://picsum.photos/seed/avport4/800/620",
    description:
      "Комплект анимированных скринсейверов и коротких роликов для презентаций SaaS-продукта.",
  },
  {
    id: 5,
    title: "Taste Forward",
    tags: "Брендинг, Иллюстрация",
    src: "https://picsum.photos/seed/avport5/800/620",
    description:
      "Айдентика и арт для гастрономического фестиваля: яркие фактуры и смелые композиции.",
  },
  {
    id: 6,
    title: "Future Studio",
    tags: "Веб-дизайн, Digital-арт",
    src: "https://picsum.photos/seed/avport6/800/620",
    description:
      "Концепт сайта продакшн-студии с анимированными 3D-элементами и интерактивной сеткой работ.",
  },
];

const Portfolio = () => (
  <div className="page portfolio-page">
    <section className="page-hero">
      <div className="container">
        <p className="eyebrow">Портфолио</p>
        <h1>Проекты, в которых дизайн и эмоции работают вместе</h1>
        <p className="hero-text">
          Мы создаем визуальные решения для брендов из разных сфер — от
          технологичных стартапов до культурных инициатив.
        </p>
      </div>
    </section>

    <section className="container portfolio-mosaic">
      {portfolioItems.map((item) => (
        <article className="portfolio-item" key={item.id}>
          <div className="portfolio-thumb">
            <img src={item.src} alt={`Проект ${item.title}`} />
          </div>
          <div className="portfolio-info">
            <h3>{item.title}</h3>
            <p className="portfolio-tags">{item.tags}</p>
            <p>{item.description}</p>
          </div>
        </article>
      ))}
    </section>
  </div>
);

export default Portfolio;