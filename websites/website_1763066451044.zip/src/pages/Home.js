import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="page home-page">
      <section className="hero-section">
        <div className="container hero-grid">
          <div className="hero-content">
            <p className="eyebrow">Графический дизайн &amp; Digital-арт</p>
            <h1>
              Мы создаем визуальные истории, которые усиливают бренды и
              вдохновляют людей.
            </h1>
            <p className="hero-text">
              ArtVision Studio — творческая команда дизайнеров, иллюстраторов и
              motion-специалистов из Москвы. Мы объединяем эстетику и стратегию,
              чтобы бренды звучали громче.
            </p>
            <div className="hero-actions">
              <Link to="/portfolio" className="btn btn-primary">
                Смотреть портфолио
              </Link>
              <Link to="/services" className="btn btn-secondary">
                Наши услуги
              </Link>
            </div>
          </div>
          <div className="hero-media">
            <div className="hero-image-wrapper">
              <img
                src="https://picsum.photos/seed/artvisionhero/720/880"
                alt="Цифровая арт-композиция с яркими акцентами"
              />
              <div className="floating-card floating-card--primary">
                <span>120+</span>
                <p>реализованных проектов</p>
              </div>
              <div className="floating-card floating-card--accent">
                <span>15</span>
                <p>наград за креатив</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="services-highlight">
        <div className="container section-header">
          <p className="eyebrow">Ключевые направления</p>
          <h2>Комплексный дизайн для сильных брендов</h2>
        </div>
        <div className="container services-grid">
          {[
            {
              title: "Брендинг",
              desc: "Стратегия, айдентика и визуальные руководства, формирующие узнаваемость.",
            },
            {
              title: "Digital-арт",
              desc: "Концептуальные иллюстрации и арт-проекты для цифровых кампаний и NFT.",
            },
            {
              title: "Веб-дизайн",
              desc: "Адаптивные сайты с фокусом на UX/UI, визуальные концепции и прототипы.",
            },
            {
              title: "Моушн-дизайн",
              desc: "Анимация, 2D/3D ролики, динамичная графика для презентаций и соцсетей.",
            },
          ].map((service) => (
            <article className="service-card" key={service.title}>
              <div className="card-overlay" />
              <h3>{service.title}</h3>
              <p>{service.desc}</p>
              <Link to="/services" className="text-link">
                Подробнее
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className="portfolio-preview">
        <div className="container section-header">
          <p className="eyebrow">Портфолио</p>
          <h2>От концепта до готового визуального решения</h2>
        </div>
        <div className="container portfolio-grid">
          {[1, 2, 3, 4].map((item) => (
            <figure className="portfolio-card" key={item}>
              <img
                src={`https://picsum.photos/seed/avproject${item}/520/520`}
                alt={`Проект ArtVision Studio номер ${item}`}
              />
              <figcaption>
                <span>Проект #{item}</span>
                <p>Графический дизайн, Digital-арт</p>
              </figcaption>
            </figure>
          ))}
        </div>
        <div className="container center">
          <Link to="/portfolio" className="btn btn-outline">
            Смотреть все проекты
          </Link>
        </div>
      </section>

      <section className="about-snippet">
        <div className="container about-grid">
          <div className="about-text">
            <p className="eyebrow">О студии</p>
            <h2>Команда, влюбленная в визуальный язык</h2>
            <p>
              Мы объединяем креатив, технологичность и глубокое понимание
              брендов. Сильная арт-дирекция и собственная методология помогают
              нам создавать решения, которые работают и радуют глаз.
            </p>
            <ul className="about-list">
              <li>Работаем с экосистемами бренда: от стратегии до визуала</li>
              <li>Выстраиваем узнаваемый стиль на всех цифровых носителях</li>
              <li>Интегрируем анимацию и интерактив в любые форматы</li>
            </ul>
            <Link to="/about" className="btn btn-secondary">
              Узнать о нас больше
            </Link>
          </div>
          <div className="about-media">
            <img
              src="https://picsum.photos/seed/artvisionteam/820/620"
              alt="Команда дизайнеров ArtVision Studio за работой"
            />
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-card">
          <div>
            <h2>Готовы придать вашему бренду визуальную смелость?</h2>
            <p>
              Расскажите о задаче — мы предложим концепты, которые окажутся на
              шаг впереди трендов.
            </p>
          </div>
          <Link to="/contact" className="btn btn-primary">
            Связаться с нами
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;