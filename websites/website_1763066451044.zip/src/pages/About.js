import React from "react";

const About = () => (
  <div className="page about-page">
    <section className="page-hero">
      <div className="container">
        <p className="eyebrow">О студии</p>
        <h1>ArtVision Studio — визуальный партнер вашего бренда</h1>
        <p className="hero-text">
          Мы строим наглядные истории, которые отражают ценности компаний и
          помогают устанавливать эмоциональную связь с аудиторией.
        </p>
      </div>
    </section>

    <section className="container about-content">
      <div className="about-block">
        <h2>Наш подход</h2>
        <p>
          Каждый проект начинается с глубокого погружения в контекст, чтобы
          понять, какие визуальные решения действительно повлияют на восприятие
          бренда. Мы соединяем стратегию, эстетику и технологичность, чтобы
          дизайн оставался актуальным и функциональным.
        </p>
      </div>
      <div className="about-block">
        <h2>Команда специалистов</h2>
        <p>
          В команде ArtVision Studio работают арт-директора, графические
          дизайнеры, иллюстраторы, motion-дизайнеры и UX-специалисты. Мы
          ценим открытость, эксперименты и умение работать в коллаборации.
        </p>
      </div>
      <div className="about-stats">
        <div>
          <span>8 лет</span>
          <p>опыта в индустрии</p>
        </div>
        <div>
          <span>35+</span>
          <p>постоянных клиентов</p>
        </div>
        <div>
          <span>5 стран</span>
          <p>география проектов</p>
        </div>
      </div>
    </section>

    <section className="values-grid">
      <div className="container">
        <h2>Что нас вдохновляет</h2>
        <div className="values-cards">
          <article>
            <h3>Осознанность</h3>
            <p>
              Мы работаем на стыке дизайна и стратегии, чтобы визуальные
              решения поддерживали бизнес-цели.
            </p>
          </article>
          <article>
            <h3>Эксперименты</h3>
            <p>
              Постоянно тестируем новые техники: генеративный арт, 3D-графику,
              интерактив.
            </p>
          </article>
          <article>
            <h3>Прозрачность</h3>
            <p>
              Строим долгосрочные партнерства, регулярно делимся прогрессом и
              фокусируемся на результате.
            </p>
          </article>
        </div>
      </div>
    </section>
  </div>
);

export default About;