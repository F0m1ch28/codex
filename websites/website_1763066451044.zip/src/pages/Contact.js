import React from "react";

const Contact = () => (
  <div className="page contact-page">
    <section className="page-hero">
      <div className="container">
        <p className="eyebrow">Контакты</p>
        <h1>Давайте обсудим ваш проект</h1>
        <p className="hero-text">
          Напишите нам, чтобы обсудить задачу, сроки и формат сотрудничества.
        </p>
      </div>
    </section>

    <section className="container contact-grid">
      <form className="contact-form">
        <label>
          Имя
          <input type="text" name="name" placeholder="Ваше имя" required />
        </label>
        <label>
          Email
          <input
            type="email"
            name="email"
            placeholder="name@example.com"
            required
          />
        </label>
        <label>
          Компания
          <input type="text" name="company" placeholder="Название компании" />
        </label>
        <label>
          Сообщение
          <textarea
            name="message"
            rows="5"
            placeholder="Расскажите о задаче и желаемых результатах"
            required
          />
        </label>
        <button type="submit" className="btn btn-primary">
          Отправить сообщение
        </button>
      </form>

      <div className="contact-info">
        <div className="contact-card">
          <h3>Связь</h3>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
        </div>
        <div className="contact-card">
          <h3>Адрес</h3>
          <p>
            ул. Художественная, 15 <br />
            Москва, Россия
          </p>
        </div>
        <div className="contact-card">
          <h3>Социальные сети</h3>
          <p>
            Behance · Dribbble · Instagram
            <br />
            <span className="muted">
              Следите за обновлениями и behind-the-scenes.
            </span>
          </p>
        </div>
      </div>
    </section>
  </div>
);

export default Contact;