import React from "react";

const services = [
  {
    title: "Брендинг и айдентика",
    bullets: [
      "Исследование аудитории и позиционирование",
      "Создание логотипа, цветовых схем, типографики",
      "Гайдлайны бренда и дизайн-системы",
    ],
    image: "https://picsum.photos/seed/avservices1/640/480",
  },
  {
    title: "Digital-арт и иллюстрация",
    bullets: [
      "Концепты для рекламных кампаний и соцсетей",
      "NFT-коллекции и арт-дирекция",
      "Редакционная и коммерческая иллюстрация",
    ],
    image: "https://picsum.photos/seed/avservices2/640/480",
  },
  {
    title: "Веб- и UI/UX дизайн",
    bullets: [
      "Прототипирование и пользовательские сценарии",
      "Дизайн адаптивных интерфейсов",
      "Подготовка UI-китов и ассетов",
    ],
    image: "https://picsum.photos/seed/avservices3/640/480",
  },
  {
    title: "Моушн и анимация",
    bullets: [
      "Анимированные презентации и продуктовые ролики",
      "2D/3D motion-графика для событий",
      "Титры, заставки и графика для видео",
    ],
    image: "https://picsum.photos/seed/avservices4/640/480",
  },
];

const Services = () => (
  <div className="page services-page">
    <section className="page-hero">
      <div className="container">
        <p className="eyebrow">Услуги</p>
        <h1>Создаём дизайн, который влияет на восприятие бренда</h1>
        <p className="hero-text">
          Полный цикл от стратегии до финальных визуальных материалов с
          акцентом на digital-среду.
        </p>
      </div>
    </section>

    <section className="container services-list">
      {services.map((service) => (
        <article className="service-row" key={service.title}>
          <div className="service-image">
            <img src={service.image} alt={service.title} />
          </div>
          <div className="service-details">
            <h2>{service.title}</h2>
            <ul>
              {service.bullets.map((bullet) => (
                <li key={bullet}>{bullet}</li>
              ))}
            </ul>
          </div>
        </article>
      ))}
    </section>

    <section className="cta-section compact">
      <div className="container cta-card">
        <div>
          <h2>Ищете партнеров для смелого визуального проекта?</h2>
          <p>
            Обсудим концепцию, тайминг и формат сотрудничества — от проектных
            задач до долгосрочного сопровождения.
          </p>
        </div>
        <a className="btn btn-accent" href="mailto:hello@artvision.ru">
          Написать нам
        </a>
      </div>
    </section>
  </div>
);

export default Services;