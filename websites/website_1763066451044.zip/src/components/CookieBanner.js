import React, { useEffect, useState } from "react";

const COOKIE_KEY = "artvision-cookie-consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(COOKIE_KEY, "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-message">
        Мы используем cookies, чтобы улучшить впечатление от сайта. Продолжая
        пользоваться сайтом, вы соглашаетесь с нашей{" "}
        <a href="/privacy">политикой конфиденциальности</a>.
      </div>
      <button className="btn btn-accent" onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;