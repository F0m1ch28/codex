import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen((prev) => !prev);
  const closeMenu = () => setOpen(false);

  return (
    <header className="site-header">
      <div className="container header-container">
        <Link to="/" className="logo" onClick={closeMenu}>
          <span className="logo-mark">AV</span>
          <span className="logo-text">ArtVision Studio</span>
        </Link>

        <button
          className={`menu-toggle ${open ? "is-open" : ""}`}
          aria-expanded={open}
          aria-controls="primary-navigation"
          onClick={toggleMenu}
        >
          <span />
          <span />
        </button>

        <nav
          id="primary-navigation"
          className={`primary-nav ${open ? "is-open" : ""}`}
        >
          <NavLink onClick={closeMenu} to="/" end>
            Главная
          </NavLink>
          <NavLink onClick={closeMenu} to="/portfolio">
            Портфолио
          </NavLink>
          <NavLink onClick={closeMenu} to="/services">
            Услуги
          </NavLink>
          <NavLink onClick={closeMenu} to="/about">
            О студии
          </NavLink>
          <NavLink onClick={closeMenu} to="/contact">
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;