import React from "react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-grid">
      <div>
        <h3 className="footer-title">ArtVision Studio</h3>
        <p className="footer-text">
          Графический дизайн и digital-арт для брендов, которые стремятся
          вдохновлять.
        </p>
        <div className="footer-contact">
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:hello@artvision.ru">hello@artvision.ru</a>
        </div>
      </div>

      <div>
        <h4 className="footer-heading">Страницы</h4>
        <ul className="footer-links">
          <li>
            <Link to="/">Главная</Link>
          </li>
          <li>
            <Link to="/portfolio">Портфолио</Link>
          </li>
          <li>
            <Link to="/services">Услуги</Link>
          </li>
          <li>
            <Link to="/about">О студии</Link>
          </li>
          <li>
            <Link to="/contact">Контакты</Link>
          </li>
          <li>
            <Link to="/privacy">Политика конфиденциальности</Link>
          </li>
        </ul>
      </div>

      <div>
        <h4 className="footer-heading">Адрес</h4>
        <p className="footer-text">
          ул. Художественная, 15<br />
          Москва, Россия
        </p>
        <p className="footer-text footer-keywords">
          графический дизайн · digital-арт · брендинг · иллюстрация · веб-дизайн
          · моушн-дизайн
        </p>
      </div>
    </div>
    <div className="footer-bottom">
      <span>© {new Date().getFullYear()} ArtVision Studio</span>
      <span>Создано с вниманием к деталям</span>
    </div>
  </footer>
);

export default Footer;