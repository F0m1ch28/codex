(function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navigation = document.querySelector(".site-nav");
  if (navToggle && navigation) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navigation.classList.toggle("nav-open");
    });
  }

  const banner = document.querySelector(".cookie-banner");
  if (!banner) return;
  const acceptBtn = banner.querySelector("[data-accept-cookies]");
  const declineBtn = banner.querySelector("[data-decline-cookies]");
  const storageKey = "tradetech-cookie-preference";

  const setPreference = (value) => {
    try {
      localStorage.setItem(storageKey, value);
    } catch (err) {
      console.warn("Cookies preference could not be stored.", err);
    }
  };

  const getPreference = () => {
    try {
      return localStorage.getItem(storageKey);
    } catch (err) {
      return null;
    }
  };

  const initBanner = () => {
    if (!getPreference()) {
      banner.classList.add("active");
    }
  };

  const closeBanner = () => {
    banner.classList.remove("active");
  };

  acceptBtn?.addEventListener("click", () => {
    setPreference("accepted");
    closeBanner();
  });

  declineBtn?.addEventListener("click", () => {
    setPreference("declined");
    closeBanner();
  });

  document.addEventListener("DOMContentLoaded", initBanner);
})();