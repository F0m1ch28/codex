import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ServicesPage, { ProcessPage } from './pages/Services';
import ContactPage from './pages/Contact';
import TermsPage from './pages/TermsOfService';
import PrivacyPage, { CookiePolicyPage } from './pages/PrivacyPolicy';

const App = () => {
  return (
    <BrowserRouter>
      <div className="app-shell">
        <a className="skip-link" href="#main-content">
          Перейти до основного змісту
        </a>
        <Header />
        <main id="main-content" className="main-content" role="main">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/pro-nas" element={<AboutPage />} />
            <Route path="/nashi-posluhy" element={<ServicesPage />} />
            <Route path="/yak-tsye-pracyuye" element={<ProcessPage />} />
            <Route path="/kontakty" element={<ContactPage />} />
            <Route path="/umovy-vykorystannya" element={<TermsPage />} />
            <Route path="/polityka-konfidentsiinosti" element={<PrivacyPage />} />
            <Route path="/polityka-cookie" element={<CookiePolicyPage />} />
          </Routes>
        </main>
        <Footer />
        <ScrollToTopButton />
        <CookieBanner />
      </div>
    </BrowserRouter>
  );
};

export default App;