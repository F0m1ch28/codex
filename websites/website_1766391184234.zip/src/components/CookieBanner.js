import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('ai-sitecraft-cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('ai-sitecraft-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <h4 className={styles.title}>Ми використовуємо cookie</h4>
        <p className={styles.description}>
          Файли cookie допомагають нам покращувати сервіс та адаптувати сайт під ваші потреби. Продовжуючи,
          ви погоджуєтеся з <a href="/polityka-cookie">політикою cookie</a>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Прийняти
      </button>
    </div>
  );
};

export default CookieBanner;