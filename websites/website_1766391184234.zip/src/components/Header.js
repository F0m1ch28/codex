import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Головна' },
  { path: '/pro-nas', label: 'Про нас' },
  { path: '/nashi-posluhy', label: 'Послуги' },
  { path: '/yak-tsye-pracyuye', label: 'Процес' },
  { path: '/kontakty', label: 'Контакти' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 992) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className={styles.header}>
      <div className={"${styles.inner} container"}>
        <NavLink to="/" className={styles.brand} aria-label="AI SiteCraft — на головну">
          <span className={styles.logo}>AI SiteCraft</span>
          <span className={styles.tagline}>Створюємо майбутнє вебу</span>
        </NavLink>

        <button
          className={styles.menuButton}
          aria-label="Перемикач меню"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className={styles.menuBar} />
          <span className={styles.menuBar} />
          <span className={styles.menuBar} />
        </button>

        <nav className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"} aria-label="Основна навігація">
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.activeLink}" : styles.navLink
                  }
                  end={item.path === '/'}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <NavLink to="/kontakty" className={styles.ctaLink}>
            Звʼязатися
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;