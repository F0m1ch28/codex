import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className={"${styles.top} container"}>
        <div className={styles.brandBlock}>
          <Link to="/" className={styles.logo}>
            AI SiteCraft
          </Link>
          <p className={styles.description}>
            Ми поєднуємо штучний інтелект та людський досвід, щоб запускати витончені веб-продукти у рекордні строки.
          </p>
        </div>

        <div className={styles.linksBlock}>
          <div className={styles.column}>
            <h4 className={styles.columnTitle}>Компанія</h4>
            <Link to="/pro-nas" className={styles.link}>
              Про нас
            </Link>
            <Link to="/nashi-posluhy" className={styles.link}>
              Наші послуги
            </Link>
            <Link to="/yak-tsye-pracyuye" className={styles.link}>
              Процес роботи
            </Link>
          </div>

          <div className={styles.column}>
            <h4 className={styles.columnTitle}>Підтримка</h4>
            <Link to="/kontakty" className={styles.link}>
              Контакти
            </Link>
            <Link to="/umovy-vykorystannya" className={styles.link}>
              Умови використання
            </Link>
            <Link to="/polityka-konfidentsiinosti" className={styles.link}>
              Політика конфіденційності
            </Link>
            <Link to="/polityka-cookie" className={styles.link}>
              Політика cookie
            </Link>
          </div>

          <div className={styles.column}>
            <h4 className={styles.columnTitle}>Контакти</h4>
            <p className={styles.contactItem}>вул. Технологічна, 15, м. Київ, 02000</p>
            <a className={styles.contactItem} href="tel:+380441234567">
              +380 (44) 123-45-67
            </a>
            <a className={styles.contactItem} href="mailto:info@aisitecraft.ua">
              info@aisitecraft.ua
            </a>
            <div className={styles.socials} aria-label="Соціальні мережі">
              <a
                className={styles.socialLink}
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
              >
                in
              </a>
              <a
                className={styles.socialLink}
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                aria-label="GitHub"
              >
                gh
              </a>
              <a
                className={styles.socialLink}
                href="https://dribbble.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Dribbble"
              >
                db
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className={styles.bottom}>
        <div className="container">
          <p className={styles.copy}>&copy; {year} AI SiteCraft. Усі права захищені.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;