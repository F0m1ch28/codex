import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';
import { Link } from 'react-router-dom';

const services = [
  {
    title: 'Discovery & AI-стратегія',
    description:
      'Аналізуємо цілі бізнесу, досліджуємо аудиторію, обираємо AI-інструменти та готуємо роадмап цифрової трансформації.',
    deliverables: ['AI discovery session', 'Roadmap із KPI', 'Tone of voice guidelines']
  },
  {
    title: 'Дизайн та AI-генерація інтерфейсів',
    description:
      'Створюємо дизайн-систему, генеруємо UI-концепти та адаптуємо їх під бренд. Усе зберігається у Figma та доступне вашій команді.',
    deliverables: ['Дизайн-система', 'Інтерактивні прототипи', 'UI kit']
  },
  {
    title: 'Розробка та інтеграції',
    description:
      'Будуємо SPA на React/Next.js, інтегруємо CRM, CMS, автоматизуємо контент, налаштовуємо аналітику та SEO.',
    deliverables: ['Продуктивний фронтенд', 'CI/CD пайплайн', 'SEO-оптимізація']
  },
  {
    title: 'Підтримка та розвиток',
    description:
      'Стежимо за показниками, експериментуємо з AI-моделями, пропонуємо покращення UX та контенту. Все — через прозорий SLA.',
    deliverables: ['Регулярні апдейти', 'Аналітичні звіти', 'A/B тестування']
  }
];

const processSteps = [
  {
    number: '01',
    title: 'Інтенсивне брифування',
    text: 'Спільні воркшопи, аналіз ринкової ніші, визначення KPI та створення дорожньої карти.'
  },
  {
    number: '02',
    title: 'AI-дизайн спринт',
    text: 'Генеруємо різні сценарії, підбираємо схеми взаємодії, тестуємо з фокус-групою.'
  },
  {
    number: '03',
    title: 'Продуктивна розробка',
    text: 'Готуємо компонентну архітектуру, налаштовуємо CI/CD, інтегруємо сторонні сервіси.'
  },
  {
    number: '04',
    title: 'Запуск і масштабування',
    text: 'Моніторинг продуктивності, технічна підтримка, генерація нового контенту за потреби.'
  }
];

const ServicesPage = () => {
  return (
    <>
      <Helmet>
        <title>Послуги AI SiteCraft — комплексні рішення з AI веб-розробки</title>
        <meta
          name="description"
          content="AI SiteCraft пропонує discovery, AI-дизайн, розробку на React та підтримку. Створюємо сайти, що працюють на бізнес."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={"${styles.intro} container"}>
          <h1>Наші послуги</h1>
          <p>
            Ми покриваємо повний цикл створення цифрового продукту: від стратегії та AI-генерації до розробки та
            підтримки. Обирайте модулі, які відповідають вашим цілям, або довірте нам весь процес.
          </p>
        </section>

        <section className={"${styles.section} container"}>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceIcon} aria-hidden="true">
                  ●
                </div>
                <div className={styles.serviceContent}>
                  <h2 className={styles.serviceTitle}>{service.title}</h2>
                  <p className={styles.serviceDescription}>{service.description}</p>
                  <ul className={styles.serviceList}>
                    {service.deliverables.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={"${styles.section} ${styles.ctaSection} container"}>
          <h2>Не впевнені, з чого почати?</h2>
          <p>
            Ми проведемо безкоштовний discovery-дзвінок, щоб визначити ваші цілі та сформувати індивідуальний набір
            послуг.
          </p>
          <Link className={styles.primaryButton} to="/kontakty">
            Запланувати консультацію
          </Link>
        </section>
      </div>
    </>
  );
};

export const ProcessPage = () => {
  return (
    <>
      <Helmet>
        <title>Як працює AI SiteCraft — процес створення сайту</title>
        <meta
          name="description"
          content="Дізнайтеся, як AI SiteCraft проводить брифування, AI-дизайн, розробку та запуск, щоб створити сайт вашої мрії."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={"${styles.intro} container"}>
          <h1>Процес роботи</h1>
          <p>
            Ми створили прозорий, керований процес, у якому AI виконує рутину, а команда фокусується на стратегічних
            рішеннях. Кожен етап має чіткі артефакти та дедлайни.
          </p>
        </section>

        <section className={"${styles.section} container"}>
          <div className={styles.processTimeline}>
            {processSteps.map((step) => (
              <article key={step.number} className={styles.processStep}>
                <span className={styles.stepNumber}>{step.number}</span>
                <div className={styles.stepContent}>
                  <h2>{step.title}</h2>
                  <p>{step.text}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={"${styles.section} ${styles.ctaSection} container"}>
          <h2>Готові рухатися далі?</h2>
          <p>Розкажіть про проєкт, і ми підготуємо персоналізований план розвитку разом з AI SiteCraft.</p>
          <Link className={styles.primaryButton} to="/kontakty">
            Надіслати запит
          </Link>
        </section>
      </div>
    </>
  );
};

export default ServicesPage;