import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Вкажіть, будь ласка, ім'я.";
    if (!formData.email.trim()) {
      newErrors.email = 'Email потрібен для зворотного звʼязку.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Перевірте коректність email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Детально опишіть свій запит.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    alert('Повідомлення надіслано! Ми відповімо вам дуже скоро.');
    setStatus('Дякуємо! Ваша заявка у системі. Команда AI SiteCraft надішле відповідь протягом одного робочого дня.');
    setFormData({ name: '', email: '', company: '', message: '' });
    setErrors({});
  };

  return (
    <>
      <Helmet>
        <title>Контакти AI SiteCraft — звʼяжіться з нами</title>
        <meta
          name="description"
          content="Потрібен сайт, створений з використанням штучного інтелекту? Залиште запит або напишіть на info@aisitecraft.ua."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={"${styles.intro} container"}>
          <h1>Звʼяжіться з AI SiteCraft</h1>
          <p>
            Заплануйте консультацію з нашими AI-експертами. Ми проаналізуємо ваші задачі та запропонуємо найкращий шлях
            до запуску проєкту.
          </p>
        </section>

        <section className={"${styles.section} container"}>
          <div className={styles.grid}>
            <div className={styles.infoCard}>
              <h2>Контактні дані</h2>
              <p>Ми відкриті для зустрічей у Києві чи віддалено по всьому світу.</p>
              <div className={styles.infoItem}>
                <span className={styles.label}>Адреса</span>
                <p>вул. Технологічна, 15, м. Київ, 02000</p>
              </div>
              <div className={styles.infoItem}>
                <span className={styles.label}>Телефон</span>
                <a href="tel:+380441234567">+380 (44) 123-45-67</a>
              </div>
              <div className={styles.infoItem}>
                <span className={styles.label}>Email</span>
                <a href="mailto:info@aisitecraft.ua">info@aisitecraft.ua</a>
              </div>
              <div className={styles.infoItem}>
                <span className={styles.label}>Графік</span>
                <p>Пн — Пт: 09:00—19:00 (EET)</p>
              </div>
            </div>

            <form className={styles.formCard} onSubmit={handleSubmit} noValidate>
              <h2>Надіслати запит</h2>
              <div className={styles.field}>
                <label htmlFor="contact-name">Ваше імʼя</label>
                <input
                  id="contact-name"
                  name="name"
                  type="text"
                  placeholder="Марія, керівниця маркетингу"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'contact-name-error' : undefined}
                />
                {errors.name && (
                  <span id="contact-name-error" className={styles.error} role="alert">
                    {errors.name}
                  </span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  placeholder="you@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'contact-email-error' : undefined}
                />
                {errors.email && (
                  <span id="contact-email-error" className={styles.error} role="alert">
                    {errors.email}
                  </span>
                )}
              </div>

              <div className={styles.field}>
                <label htmlFor="contact-company">Компанія (за бажанням)</label>
                <input
                  id="contact-company"
                  name="company"
                  type="text"
                  placeholder="Назва компанії або продукту"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                />
              </div>

              <div className={styles.field}>
                <label htmlFor="contact-message">Як ми можемо допомогти?</label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows="5"
                  placeholder="Опишіть завдання, бюджетні рамки, ключові KPI чи побажання"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'contact-message-error' : undefined}
                />
                {errors.message && (
                  <span id="contact-message-error" className={styles.error} role="alert">
                    {errors.message}
                  </span>
                )}
              </div>

              <button type="submit" className={styles.submit}>
                Надіслати
              </button>
              {status && (
                <p className={styles.success} role="status">
                  {status}
                </p>
              )}
            </form>
          </div>
        </section>
      </div>
    </>
  );
};

export default ContactPage;