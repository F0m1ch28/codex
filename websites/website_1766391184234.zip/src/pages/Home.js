import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const servicesPreview = [
  {
    title: 'AI-генерація прототипів',
    description:
      'Створюємо структуровані прототипи та візуальні концепти за лічені хвилини, щоб команда могла одразу рухатися вперед.',
    icon: '⚡'
  },
  {
    title: 'Розробка на React',
    description:
      'Збираємо швидкі, масштабовані інтерфейси з використанням найкращих практик та сучасного стеку технологій.',
    icon: '⚛️'
  },
  {
    title: 'Індивідуальний брендинг',
    description:
      'AI SiteCraft зберігає ваш унікальний стиль завдяки системі дизайн-токенів та ручному кураторству арт-директорів.',
    icon: '🎨'
  }
];

const advantages = [
  {
    title: 'Швидкість впровадження',
    description: 'До 10 разів швидше запуску проєктів завдяки автоматизованим AI-пайплайнам.',
    icon: '🚀'
  },
  {
    title: 'Контроль якості',
    description: 'Команда дизайнерів та розробників контролює кожен етап, щоб результат відповідав бренду.',
    icon: '🛡️'
  },
  {
    title: 'Гнучкість інтеграцій',
    description: 'Легко підключаємо CRM, аналітику, e-commerce та сторонні API.',
    icon: '🔗'
  },
  {
    title: 'Підтримка 24/7',
    description: 'Ми залишаємося поруч після релізу: оптимізація, оновлення, масштабування.',
    icon: '💡'
  }
];

const processSteps = [
  {
    number: '01',
    title: 'Глибоке брифування',
    description: 'Спільно формуємо бачення, збираємо референси, визначаємо бізнес-цілі та очікуваний результат.'
  },
  {
    number: '02',
    title: 'AI-генерація та дизайн',
    description: 'AI створює перші концепти, а наші дизайнери адаптують їх до tone of voice та брендгайдів.'
  },
  {
    number: '03',
    title: 'Розробка та інтеграції',
    description: 'Пишемо чистий код на React, налаштовуємо CMS, підключаємо аналітику й сервісні інтеграції.'
  },
  {
    number: '04',
    title: 'Тестування й запуск',
    description: 'Перевірка доступності, продуктивності та безпеки. Готуємо команду клієнта до подальшої підтримки.'
  }
];

const techStack = ['React', 'Next.js', 'Node.js', 'TypeScript', 'OpenAI API', 'Figma', 'Vercel', 'Netlify'];

const testimonials = [
  {
    name: 'Олена Кравець',
    role: 'CMO, DigitalNova',
    quote:
      'AI SiteCraft перетворили наш маркетинговий сайт на живий організм, який легко масштабувати. Результати перевершили очікування.',
    avatar: 'https://picsum.photos/seed/testimonial1/96/96'
  },
  {
    name: 'Максим Іванченко',
    role: 'CEO, FinTech Core',
    quote:
      'Команда швидко занурилася в специфіку фінансового продукту та створила платформу, де AI працює прозоро й безпечно.',
    avatar: 'https://picsum.photos/seed/testimonial2/96/96'
  },
  {
    name: 'Надія Поліщук',
    role: 'Product Owner, EduSpark',
    quote:
      'Дуже вразила співпраця. Ми отримали адаптивний сайт, який легко редагувати. Підтримка — на високому рівні.',
    avatar: 'https://picsum.photos/seed/testimonial3/96/96'
  }
];

const HomePage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [statusMessage, setStatusMessage] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Будь ласка, введіть ім'я.";
    if (!formData.email.trim()) {
      newErrors.email = 'Вкажіть email для звʼязку.';
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Перевірте коректність email.';
    }
    if (!formData.message.trim()) newErrors.message = 'Напишіть кілька слів про ваш запит.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    alert('Дякуємо! Ми звʼяжемося з вами протягом одного робочого дня.');
    setStatusMessage('Ваш запит надіслано. Очікуйте лист від нашої команди найближчим часом.');
    setFormData({ name: '', email: '', message: '' });
    setErrors({});
  };

  return (
    <>
      <Helmet>
        <title>AI SiteCraft: Генерація сайтів майбутнього</title>
        <meta
          name="description"
          content="AI SiteCraft — студія, що створює сучасні веб-сайти за допомогою штучного інтелекту, зберігаючи контроль дизайнера."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={"${styles.hero} container"}>
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <p className={styles.eyebrow}>Преміальна веб-розробка з AI</p>
              <h1 className={styles.title}>AI SiteCraft: Генерація сайтів майбутнього</h1>
              <p className={styles.subtitle}>
                Створюємо майбутнє вебу, рядок за рядком. Поєднуємо потужність штучного інтелекту з досвідом
                експертів, щоб запускати сайти, що драйвлять бізнес.
              </p>
              <div className={styles.heroActions}>
                <a className={styles.primaryButton} href="#services">
                  Дізнатися більше
                </a>
                <Link className={styles.secondaryButton} to="/kontakty">
                  Замовити консультацію
                </Link>
              </div>
            </div>
            <div className={styles.heroMedia}>
              <img
                src="https://picsum.photos/seed/ai-sitecraft-hero/720/520"
                alt="Інтерфейс генерації сайтів за допомогою штучного інтелекту"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        <section id="services" className={"${styles.section} ${styles.servicesPreview} container"}>
          <header className={styles.sectionHeader}>
            <span className={styles.sectionEyebrow}>Послуги</span>
            <h2 className={styles.sectionTitle}>Формуємо цифровий досвід на кожному етапі</h2>
            <p className={styles.sectionDescription}>
              AI SiteCraft створює комплексні рішення: від швидких MVP до повноцінних корпоративних порталів.
            </p>
          </header>
          <div className={styles.cardsGrid}>
            {servicesPreview.map((service) => (
              <article className={styles.card} key={service.title}>
                <span className={styles.cardIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3 className={styles.cardTitle}>{service.title}</h3>
                <p className={styles.cardText}>{service.description}</p>
                <Link className={styles.cardLink} to="/nashi-posluhy">
                  Детальніше →
                </Link>
              </article>
            ))}
          </div>
        </section>

        <section className={"${styles.section} container"}>
          <div className={styles.split}>
            <div className={styles.splitText}>
              <span className={styles.sectionEyebrow}>Про нас</span>
              <h2 className={styles.sectionTitle}>Місія AI SiteCraft</h2>
              <p className={styles.sectionDescription}>
                Ми створили AI SiteCraft, щоб зруйнувати барʼєри між ідеєю та її реалізацією у вебі. Наша мета —
                автоматизувати рутину, зберегти творчість та зробити запуск нового сайту безболісним.
              </p>
              <Link className={styles.primaryLink} to="/pro-nas">
                Дізнатися про команду
              </Link>
            </div>
            <div className={styles.splitMedia}>
              <img
                src="https://picsum.photos/seed/aisitecraft-team/720/520"
                alt="Команда AI SiteCraft працює над проєктом"
                loading="lazy"
              />
            </div>
          </div>
        </section>

        <section className={"${styles.section} ${styles.advantages} container"}>
          <header className={styles.sectionHeader}>
            <span className={styles.sectionEyebrow}>Наші переваги</span>
            <h2 className={styles.sectionTitle}>Чому бренди обирають AI SiteCraft</h2>
          </header>
          <div className={styles.advantagesGrid}>
            {advantages.map((advantage) => (
              <article className={styles.advantage} key={advantage.title}>
                <span className={styles.advantageIcon} aria-hidden="true">
                  {advantage.icon}
                </span>
                <h3 className={styles.advantageTitle}>{advantage.title}</h3>
                <p className={styles.advantageText}>{advantage.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={"${styles.section} ${styles.process} container"}>
          <header className={styles.sectionHeader}>
            <span className={styles.sectionEyebrow}>Як це працює</span>
            <h2 className={styles.sectionTitle}>Від ідеї до запуску — швидко та контрольовано</h2>
          </header>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article className={styles.processCard} key={step.number}>
                <span className={styles.processNumber}>{step.number}</span>
                <h3 className={styles.processTitle}>{step.title}</h3>
                <p className={styles.processText}>{step.description}</p>
              </article>
            ))}
          </div>
          <div className={styles.processCta}>
            <Link className={styles.primaryButton} to="/yak-tsye-pracyuye">
              Переглянути весь процес
            </Link>
          </div>
        </section>

        <section className={"${styles.section} ${styles.technologies} container"}>
          <header className={styles.sectionHeader}>
            <span className={styles.sectionEyebrow}>Технології</span>
            <h2 className={styles.sectionTitle}>Стек, що задає темп інноваціям</h2>
            <p className={styles.sectionDescription}>
              Ми комбінуємо найкращі фреймворки, AI-моделі та DevOps-підходи, щоб ваш продукт був готовий до зростання.
            </p>
          </header>
          <div className={styles.techGrid}>
            {techStack.map((tech) => (
              <div className={styles.techItem} key={tech}>
                {tech}
              </div>
            ))}
          </div>
        </section>

        <section className={"${styles.section} ${styles.testimonials} container"}>
          <header className={styles.sectionHeader}>
            <span className={styles.sectionEyebrow}>Відгуки</span>
            <h2 className={styles.sectionTitle}>Голоси партнерів, яким ми допомогли вирости</h2>
          </header>
          <div className={styles.testimonialGrid}>
            {testimonials.map((testimonial) => (
              <article className={styles.testimonialCard} key={testimonial.name}>
                <div className={styles.testimonialHeader}>
                  <img
                    className={styles.avatar}
                    src={testimonial.avatar}
                    alt={"Фото ${testimonial.name}"}
                    width="48"
                    height="48"
                    loading="lazy"
                  />
                  <div>
                    <p className={styles.clientName}>{testimonial.name}</p>
                    <p className={styles.clientRole}>{testimonial.role}</p>
                  </div>
                </div>
                <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
              </article>
            ))}
          </div>
        </section>

        <section className={"${styles.section} ${styles.formSection} container"}>
          <div className={styles.formIntro}>
            <span className={styles.sectionEyebrow}>Звʼязок</span>
            <h2 className={styles.sectionTitle}>Готові створити щось вражаюче?</h2>
            <p className={styles.sectionDescription}>
              Опишіть нам ваш задум — і вже за 24 години ви отримаєте дорожню карту запуску від AI SiteCraft.
            </p>
          </div>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.field}>
              <label htmlFor="home-name">Ваше імʼя</label>
              <input
                id="home-name"
                name="name"
                type="text"
                placeholder="Наприклад, Марія"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'home-name-error' : undefined}
              />
              {errors.name && (
                <span id="home-name-error" className={styles.error} role="alert">
                  {errors.name}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="home-email">Email</label>
              <input
                id="home-email"
                name="email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'home-email-error' : undefined}
              />
              {errors.email && (
                <span id="home-email-error" className={styles.error} role="alert">
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="home-message">Опишіть ваш запит</label>
              <textarea
                id="home-message"
                name="message"
                rows="4"
                placeholder="Коротко опишіть проєкт, бажані терміни та задачі"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'home-message-error' : undefined}
              />
              {errors.message && (
                <span id="home-message-error" className={styles.error} role="alert">
                  {errors.message}
                </span>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Надіслати запит
            </button>

            {statusMessage && (
              <p className={styles.success} role="status">
                {statusMessage}
              </p>
            )}
          </form>
        </section>
      </div>
    </>
  );
};

export default HomePage;