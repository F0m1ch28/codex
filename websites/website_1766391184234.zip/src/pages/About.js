import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const values = [
  {
    title: 'Партнерство понад усе',
    description:
      'Ми сприймаємо клієнтів як однодумців, залучаємо їх до процесу та ділимося знаннями, щоб проєкт розвивався після релізу.'
  },
  {
    title: 'Прозорість процесів',
    description:
      'Кожен етап документується: від AI-генерації та дизайну до тестувань. Ви завжди розумієте, що відбувається далі.'
  },
  {
    title: 'Творча сміливість',
    description:
      'Команда регулярно експериментує з новими AI-інструментами та патернами UX, щоб ваш продукт був на крок попереду.'
  }
];

const team = [
  {
    name: 'Аліна Коваль',
    role: 'CEO & Co-founder',
    bio: '10 років у digital-продуктах. Консультувала стартапи в Y Combinator та Enterprise-команди у Європі.',
    photo: 'https://picsum.photos/seed/team1/320/320'
  },
  {
    name: 'Тарас Пилипенко',
    role: 'CTO',
    bio: 'Лід інженерії з фокусом на React, Node.js та DevOps. Раніше — Delivery Hero, Grammarly.',
    photo: 'https://picsum.photos/seed/team2/320/320'
  },
  {
    name: 'Марія Литвин',
    role: 'Creative Lead',
    bio: 'Вибудовує дизайн-системи та бренд-ідентичності. Переможниця Red Dot Design Award 2021.',
    photo: 'https://picsum.photos/seed/team3/320/320'
  },
  {
    name: 'Дмитро Вербицький',
    role: 'Lead AI Engineer',
    bio: 'Спеціалізується на створенні AI-пайплайнів для генерації інтерфейсів та контенту.',
    photo: 'https://picsum.photos/seed/team4/320/320'
  }
];

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>Про AI SiteCraft — команда, яка створює майбутнє вебу</title>
        <meta
          name="description"
          content="Дізнайтеся про місію, команду та цінності AI SiteCraft. Ми поєднуємо штучний інтелект і людський досвід для прискореної веб-розробки."
        />
      </Helmet>

      <div className={styles.page}>
        <section className={"${styles.hero} container"}>
          <div className={styles.heroContent}>
            <h1>Ми — AI SiteCraft</h1>
            <p>
              Команда інженерів, дизайнерів і AI-дослідників, які прагнуть зробити створення веб-продуктів швидким,
              прозорим і емоційно захопливим. Ми віримо, що штучний інтелект має бути інструментом, а не заміною
              креативності.
            </p>
            <p>
              За кожним проєктом стоїть зміст: бізнес-цілі, цінності бренду, очікування користувачів. Наша задача —
              відобразити їх у цифровому досвіді, який працює на результат.
            </p>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://picsum.photos/seed/aisitecraft-culture/760/520"
              alt="Команда AI SiteCraft під час дизайн-воркшопу"
              loading="lazy"
            />
          </div>
        </section>

        <section className={"${styles.section} container"}>
          <h2>Наші цінності</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={"${styles.section} container"}>
          <div className={styles.story}>
            <div>
              <h2>Шлях, який ми пройшли</h2>
              <p>
                AI SiteCraft розпочався з невеликої групи ентузіастів, які прагнули навчити AI працювати на благо
                дизайнерів та розробників. Ми створили власні пайплайни генерації інтерфейсів, налаштували контрольні
                точки, де людина приймає ключові рішення, та виробили процес, який забезпечує швидкість і якість.
              </p>
            </div>
            <div>
              <h3>Що нас надихає</h3>
              <ul className={styles.list}>
                <li>Складні завдання, де потрібно поєднати бізнес-логіку, емоції бренду та зручний UX.</li>
                <li>Команди, які мислять глобально та шукають нові способи взаємодії з аудиторією.</li>
                <li>Технології, що дозволяють звільнити час для стратегічного мислення.</li>
              </ul>
            </div>
          </div>
        </section>

        <section className={"${styles.section} ${styles.teamSection} container"}>
          <header className={styles.teamHeader}>
            <h2>Люди, які творять AI SiteCraft</h2>
            <p>Ми обʼєднали досвід з продуктових компаній, аутсорсингу та AI-лабораторій, щоб створювати новий стандарт вебу.</p>
          </header>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.photo} alt={member.name} className={styles.teamPhoto} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p className={styles.role}>{member.role}</p>
                  <p className={styles.bio}>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default AboutPage;