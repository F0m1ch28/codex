document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.main-navigation');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookies = document.getElementById('accept-cookies');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            if (navigation.style.display === 'block') {
                navigation.style.display = 'none';
            } else {
                navigation.style.display = 'block';
            }
        });
    }

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach((link) => {
        link.addEventListener('click', () => {
            if (window.innerWidth < 640 && navigation && navToggle) {
                navigation.style.display = 'none';
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollTopBtn.style.display = 'block';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    });

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && acceptCookies) {
        const consent = localStorage.getItem('lspCookiesAccepted');
        if (consent === 'yes') {
            cookieBanner.style.display = 'none';
        }
        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('lspCookiesAccepted', 'yes');
            cookieBanner.style.display = 'none';
        });
    }
});