document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAcceptBtn = document.getElementById('cookie-accept');
    const bodyPage = document.body.dataset.page;

    // Mobile navigation toggle
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            siteNav.classList.toggle('open');
        });
    }

    // Close mobile menu on link click and scroll to top
    navLinks.forEach(link => {
        if (link.dataset.page === bodyPage && bodyPage) {
            link.classList.add('active-link');
        }

        link.addEventListener('click', () => {
            if (siteNav.classList.contains('open')) {
                siteNav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // Scroll restoration
    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
    window.scrollTo(0, 0);

    // Scroll to top button
    const handleScrollButton = () => {
        if (window.scrollY > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    };

    if (scrollTopBtn) {
        window.addEventListener('scroll', handleScrollButton);
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    const cookieKey = 'nvaCookieConsent';
    if (!localStorage.getItem(cookieKey) && cookieBanner) {
        cookieBanner.classList.add('show');
    }

    if (cookieAcceptBtn) {
        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            cookieBanner.classList.remove('show');
        });
    }
});