document.addEventListener('DOMContentLoaded', function () {
    var banner = document.getElementById('cookieBanner');
    if (!banner) {
        return;
    }

    var acceptButton = banner.querySelector('.accept-cookies');
    var declineButton = banner.querySelector('.decline-cookies');
    var preferencesButton = banner.querySelector('.preferences-cookies');
    var consentStatus = localStorage.getItem('coagulbtdbCookieConsent');

    if (consentStatus) {
        banner.classList.add('hidden');
    }

    if (acceptButton) {
        acceptButton.addEventListener('click', function () {
            localStorage.setItem('coagulbtdbCookieConsent', 'accepted');
            banner.classList.add('hidden');
        });
    }

    if (declineButton) {
        declineButton.addEventListener('click', function () {
            localStorage.setItem('coagulbtdbCookieConsent', 'declined');
            banner.classList.add('hidden');
        });
    }

    if (preferencesButton) {
        preferencesButton.addEventListener('click', function () {
            window.location.href = 'cookies.html';
        });
    }
});