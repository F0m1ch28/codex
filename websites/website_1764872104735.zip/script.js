document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
      navToggle.classList.toggle('is-active', isOpen);
    });
  }

  const yearSpan = document.getElementById('current-year');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  if (!cookieBanner) return;

  const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
  const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
  const storageKey = 'maple-cookie-consent';

  const storedChoice = localStorage.getItem(storageKey);
  if (storedChoice) {
    cookieBanner.classList.add('is-hidden');
  }

  const handleChoice = (value) => {
    localStorage.setItem(storageKey, value);
    cookieBanner.classList.add('is-hidden');
    setTimeout(() => cookieBanner.setAttribute('hidden', ''), 400);
  };

  acceptBtn?.addEventListener('click', () => handleChoice('accepted'));
  declineBtn?.addEventListener('click', () => handleChoice('declined'));
});