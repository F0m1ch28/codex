document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('is-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768 && siteNav.classList.contains('is-open')) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    siteNav.classList.remove('is-open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieChoices = document.querySelectorAll('[data-cookie-choice]');
    const storageKey = 'breweranrdCookieChoice';

    if (cookieBanner) {
        const storedChoice = localStorage.getItem(storageKey);
        if (storedChoice) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieChoices.forEach(choice => {
            choice.addEventListener('click', (event) => {
                event.preventDefault();
                const preference = choice.getAttribute('data-cookie-choice') || 'unknown';
                localStorage.setItem(storageKey, preference);
                cookieBanner.classList.add('is-hidden');

                const target = choice.getAttribute('href');
                if (target) {
                    window.open(target, '_blank', 'noopener');
                }
            });
        });
    }
});