document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navigation = document.querySelector('.site-nav');

  if (navToggle && navigation) {
    navToggle.addEventListener('click', () => {
      const isOpen = navigation.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    navigation.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navigation.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('cookieConsent121nearme');
    if (!storedPreference) {
      setTimeout(() => cookieBanner.classList.add('show'), 400);
    }
    cookieBanner.querySelectorAll('[data-cookie-choice]').forEach((button) => {
      button.addEventListener('click', () => {
        const choice = button.getAttribute('data-cookie-choice');
        localStorage.setItem('cookieConsent121nearme', choice);
        cookieBanner.classList.remove('show');
      });
    });
  }

  const observed = document.querySelectorAll('[data-observe]');
  if (observed.length > 0) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.18 }
    );
    observed.forEach((el) => observer.observe(el));
  }

  const forms = document.querySelectorAll('form[data-form-type]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const toast = document.getElementById('formToast');
      if (toast) {
        toast.classList.add('show');
      }
      setTimeout(() => {
        if (toast) {
          toast.classList.remove('show');
        }
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 1800);
    });
  });

  const yearSpan = document.getElementById('currentYear');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
});