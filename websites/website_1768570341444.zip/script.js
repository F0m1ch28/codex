document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.getElementById('nav-toggle');
    const navLinks = document.getElementById('nav-links');
    const acceptBtn = document.getElementById('acceptCookies');
    const declineBtn = document.getElementById('declineCookies');
    const cookieBanner = document.getElementById('cookie-banner');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            navToggle.classList.toggle('active');
            navLinks.classList.toggle('active');
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navToggle.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });
    }

    if (cookieBanner && acceptBtn && declineBtn) {
        const consent = localStorage.getItem('validazjjlCookieConsent');

        if (!consent) {
            cookieBanner.classList.add('active');
        }

        acceptBtn.addEventListener('click', function () {
            localStorage.setItem('validazjjlCookieConsent', 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineBtn.addEventListener('click', function () {
            localStorage.setItem('validazjjlCookieConsent', 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});