import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './NotFound.module.css';

function NotFound() {
  return (
    <>
      <Helmet>
        <title>Page non trouvée | French Automotive Sector Analysis</title>
      </Helmet>
      <section className={styles.section}>
        <h1>Page non trouvée</h1>
        <p>Le contenu recherché n&apos;est pas disponible. Vous pouvez revenir à la page d&apos;accueil.</p>
        <Link to="/" className={styles.link}>
          Retour à l&apos;accueil
        </Link>
      </section>
    </>
  );
}

export default NotFound;