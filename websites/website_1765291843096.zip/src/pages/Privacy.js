import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Politique de confidentialité | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Politique de confidentialité de French Automotive Sector Analysis détaillant la gestion des données personnelles."
        />
      </Helmet>
      <section className={styles.section}>
        <h1>Politique de confidentialité</h1>
        <article>
          <h2>1. Responsable éditorial</h2>
          <p>
            La publication French Automotive Sector Analysis assure le traitement des données collectées via le formulaire
            de contact. Toute question peut être adressée à redaction@automotive-analysis.fr.
          </p>
        </article>
        <article>
          <h2>2. Données collectées</h2>
          <p>
            Le site collecte uniquement les informations fournies volontairement via le formulaire de contact : adresse
            email, sujet et contenu du message. Aucune donnée sensible n’est requise.
          </p>
        </article>
        <article>
          <h2>3. Finalités</h2>
          <p>
            Les données sont utilisées afin de répondre aux demandes formulées par les utilisateurs. Elles ne sont pas
            cédées à des tiers et ne servent pas à des opérations de prospection.
          </p>
        </article>
        <article>
          <h2>4. Durée de conservation</h2>
          <p>
            Les messages sont conservés le temps nécessaire au traitement de la demande, puis archivés pour une durée
            maximale de douze mois à des fins de suivi éditorial.
          </p>
        </article>
        <article>
          <h2>5. Cookies</h2>
          <p>
            Le site utilise des cookies techniques indispensables et des cookies de mesure d’audience anonymisés. Pour en
            savoir plus, consulter la politique relative aux cookies.
          </p>
        </article>
        <article>
          <h2>6. Droits des personnes</h2>
          <p>
            Conformément à la réglementation, toute personne dispose d’un droit d’accès, de rectification, d’effacement,
            de limitation et d’opposition. Ces droits s’exercent par email à l’adresse mentionnée ci-dessus.
          </p>
        </article>
        <article>
          <h2>7. Sécurité</h2>
          <p>
            Des mesures techniques et organisationnelles raisonnables sont mises en place pour protéger les données contre
            tout accès non autorisé, conformément aux bonnes pratiques en vigueur.
          </p>
        </article>
        <article>
          <h2>8. Mise à jour</h2>
          <p>
            La présente politique peut être ajustée afin de refléter les évolutions du site ou du cadre légal. La date de
            la dernière mise à jour est indiquée en en-tête de la page.
          </p>
        </article>
      </section>
    </>
  );
}

export default Privacy;