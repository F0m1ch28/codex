import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { analyses } from '../data/analyses';
import styles from './Analyses.module.css';

function Analyses() {
  return (
    <>
      <Helmet>
        <title>Analyses sectorielles | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Panorama des analyses sectorielles consacrées à l’industrie automobile française : transition énergétique, robotisation, logistique et cadres réglementaires."
        />
        <meta
          name="keywords"
          content="analyses automobile, filière française, électromobilité, robotisation, chaîne logistique, normes environnementales"
        />
      </Helmet>
      <section className={styles.section}>
        <div className={styles.intro}>
          <h1>Analyses</h1>
          <p>
            Les analyses approfondies abordent les transformations industrielles, les innovations technologiques et les
            cadres réglementaires qui structurent l&apos;industrie automobile française. Chaque publication repose sur
            des sources multiples et des entretiens spécialisés.
          </p>
        </div>
        <div className={styles.list}>
          {analyses.map((analysis) => (
            <article key={analysis.id} className={styles.card}>
              <div className={styles.meta}>
                <span className={styles.date}>{new Date(analysis.date).toLocaleDateString('fr-FR')}</span>
                <ul className={styles.tags}>
                  {analysis.tags.map((tag) => (
                    <li key={tag}>{tag}</li>
                  ))}
                </ul>
              </div>
              <h2>{analysis.title}</h2>
              {analysis.subtitle && <p className={styles.subtitle}>{analysis.subtitle}</p>}
              <p className={styles.description}>{analysis.description}</p>
              <Link to={`/analyses/${analysis.slug}`} className={styles.link}>
                Lire l&apos;analyse
              </Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default Analyses;