import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Politique relative aux cookies | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Politique détaillant l’utilisation des cookies sur French Automotive Sector Analysis."
        />
      </Helmet>
      <section className={styles.section}>
        <h1>Politique relative aux cookies</h1>
        <article>
          <h2>1. Définition</h2>
          <p>
            Un cookie est un fichier texte déposé sur l’appareil de l’utilisateur lors de la consultation d’un site. Il
            permet à ce site de mémoriser certaines informations afin de faciliter la navigation ou de mesurer l’activité.
          </p>
        </article>
        <article>
          <h2>2. Cookies utilisés</h2>
          <ul>
            <li>
              Cookies techniques : indispensables au fonctionnement du site, notamment pour rappeler l’acceptation de la
              bannière d’information.
            </li>
            <li>
              Cookies de mesure d’audience : utilisés pour comprendre l’usage du site et améliorer les contenus. Les
              données collectées sont anonymisées.
            </li>
          </ul>
        </article>
        <article>
          <h2>3. Gestion des préférences</h2>
          <p>
            L’utilisateur peut configurer son navigateur pour accepter ou refuser les cookies. Le paramétrage peut
            toutefois modifier les conditions d’accès à certaines fonctionnalités.
          </p>
        </article>
        <article>
          <h2>4. Durée de conservation</h2>
          <p>
            Les cookies techniques sont conservés pour une durée maximale de treize mois. Les cookies de mesure d’audience
            suivent la même durée de conservation.
          </p>
        </article>
        <article>
          <h2>5. Contact</h2>
          <p>
            Pour toute question relative aux cookies, l’utilisateur peut écrire à redaction@automotive-analysis.fr.
          </p>
        </article>
      </section>
    </>
  );
}

export default CookiePolicy;