import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './APropos.module.css';

function APropos() {
  return (
    <>
      <Helmet>
        <title>À propos | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Présentation de la mission, de la méthodologie et des principes éditoriaux de French Automotive Sector Analysis, plateforme dédiée à l’industrie automobile française."
        />
        <meta
          name="keywords"
          content="à propos, mission éditoriale, méthodologie, industrie automobile française, publication analytique"
        />
      </Helmet>
      <section className={styles.section}>
        <header className={styles.header}>
          <h1>À Propos</h1>
          <p>
            French Automotive Sector Analysis est une publication analysant en profondeur les mutations de l&apos;industrie
            automobile française. L&apos;équipe rassemble journalistes spécialisés, analystes et chercheurs associés afin
            de proposer une lecture documentée, structurée et transversale.
          </p>
        </header>
        <div className={styles.grid}>
          <article>
            <h2>Mission éditoriale</h2>
            <p>
              La mission consiste à éclairer les enjeux technologiques, industriels et sociétaux de la filière automobile
              française. Les contenus privilégient la neutralité, la vérification des sources et la mise en perspective
              internationale. La publication s’adresse aux décideurs industriels, aux responsables publics, aux chercheurs
              et aux étudiants.
            </p>
          </article>
          <article>
            <h2>Méthodologie</h2>
            <p>
              Les analyses reposent sur un corpus combinant documents officiels, données ouvertes, études scientifiques,
              séries statistiques et témoignages d&apos;experts. Chaque article fait l’objet d’une revue interne croisée
              entre spécialistes de l&apos;ingénierie, de la logistique et des politiques publiques afin d’assurer la
              robustesse des conclusions.
            </p>
          </article>
          <article>
            <h2>Principes rédactionnels</h2>
            <p>
              Les textes sont rédigés à la troisième personne, dans un style analytique et factuel. Les opinions
              personnelles sont contextualisées et attribuées à leurs auteurs. La publication ne formule pas de conseils
              financiers et se concentre sur la compréhension des dynamiques industrielles.
            </p>
          </article>
          <article>
            <h2>Public visé</h2>
            <p>
              French Automotive Sector Analysis s’adresse aux professionnels de la filière automobile, aux acteurs de la
              mobilité, aux chercheurs, aux observateurs institutionnels et aux étudiants en sciences de l’ingénieur ou en
              sciences sociales. L’objectif est de fournir des repères fiables pour éclairer leurs travaux et décisions.
            </p>
          </article>
        </div>
      </section>
    </>
  );
}

export default APropos;