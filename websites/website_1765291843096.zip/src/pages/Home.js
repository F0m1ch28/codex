import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { analyses } from '../data/analyses';
import { interviews } from '../data/interviews';
import styles from './Home.module.css';

function Home() {
  const latestAnalyses = analyses.slice(0, 3);
  const latestInterviews = interviews.slice(0, 3);

  const themes = [
    {
      title: 'Motorisations & Batteries',
      description:
        'Études sur l’évolution des groupes motopropulseurs, la chimie des batteries et l’organisation des gigafactories.',
      icon: '⚙️',
    },
    {
      title: 'Chaînes Logistiques',
      description:
        'Cartographie des flux, résilience des fournisseurs et intégration numérique des réseaux de transport.',
      icon: '🔄',
    },
    {
      title: 'Normes & Politiques',
      description:
        'Analyse des directives européennes, des objectifs climatiques et de leur impact sur la production française.',
      icon: '📜',
    },
    {
      title: 'Innovation & R&D',
      description:
        'Suivi des laboratoires, des pôles de compétitivité et des coopérations entre ingénieurs et chercheurs.',
      icon: '🔬',
    },
  ];

  const stats = [
    {
      figure: '47 %',
      label: 'Part estimée de la production française dédiée aux motorisations électrifiées en 2024.',
    },
    {
      figure: '32 000',
      label: 'Nombre d’emplois spécialisés mobilisés dans les projets batteries et électrification.',
    },
    {
      figure: '5,2 Mt',
      label: 'Volume de CO₂ évité grâce au renouvellement des gammes depuis 2019 selon les données ministérielles.',
    },
    {
      figure: '18',
      label: 'Sites industriels engagés dans une montée en cadence robotisée depuis 2021.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>French Automotive Sector Analysis | Accueil</title>
        <meta
          name="description"
          content="Publication analytique dédiée à l’industrie automobile française : études sectorielles, innovations technologiques, logistique, réglementation et témoignages d’experts."
        />
        <meta
          name="keywords"
          content="industrie automobile française, analyses, batteries, robotisation, réglementation automobile, mobilité électrique"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>French Automotive Sector Analysis</h1>
          <p className={styles.subtitle}>
            Analyse sectorielle, recherche et prospective sur l&apos;industrie automobile française.
          </p>
          <p className={styles.description}>
            La publication rassemble enquêtes, données structurées et entretiens d&apos;experts pour observer les
            transformations industrielles, technologiques et environnementales de la filière automobile en France.
          </p>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1000&q=80"
            alt="Chaîne de production automobile en France"
            className={styles.heroImage}
          />
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Dernières Analyses</h2>
          <Link to="/analyses" className={styles.sectionLink}>
            Voir toutes les analyses
          </Link>
        </div>
        <div className={styles.grid}>
          {latestAnalyses.map((analysis) => (
            <article key={analysis.id} className={styles.card}>
              <p className={styles.cardDate}>{new Date(analysis.date).toLocaleDateString('fr-FR')}</p>
              <h3>{analysis.title}</h3>
              <p className={styles.cardExcerpt}>{analysis.description}</p>
              <Link to={`/analyses/${analysis.slug}`} className={styles.cardLink}>
                Lire l&apos;analyse
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Thématiques Clés</h2>
        </div>
        <div className={styles.themeGrid}>
          {themes.map((theme) => (
            <article key={theme.title} className={styles.themeCard}>
              <span className={styles.themeIcon} aria-hidden="true">
                {theme.icon}
              </span>
              <h3>{theme.title}</h3>
              <p>{theme.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Méthodologie de Recherche</h2>
        </div>
        <div className={styles.methodology}>
          <article>
            <h3>Collecte de données</h3>
            <p>
              La rédaction analyse les communiqués industriels, les données publiques européennes, les indicateurs
              d&apos;organismes de normalisation et les publications académiques. Chaque information est recoupée afin de
              présenter un panorama cohérent de la filière.
            </p>
          </article>
          <article>
            <h3>Approche comparative</h3>
            <p>
              Les études confrontent la trajectoire française aux tendances européennes et mondiales, en utilisant des
              séries statistiques et des entretiens ciblés pour éclairer les écarts de compétitivité, de technologie et
              d&apos;organisation logistique.
            </p>
          </article>
          <article>
            <h3>Relecture pluridisciplinaire</h3>
            <p>
              Les analyses sont relues par des spécialistes de l&apos;ingénierie, de l&apos;économie industrielle et des
              politiques publiques afin de garantir un regard équilibré, factuel et contextualisé.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>Interviews &amp; Témoignages</h2>
          <Link to="/interviews" className={styles.sectionLink}>
            Consulter les entretiens
          </Link>
        </div>
        <div className={styles.grid}>
          {latestInterviews.map((interview) => (
            <article key={interview.id} className={styles.card}>
              <div className={styles.person}>
                <img src={interview.photo} alt={`Portrait de ${interview.name}`} />
                <div>
                  <p className={styles.personName}>{interview.name}</p>
                  <p className={styles.personRole}>
                    {interview.role} · {interview.organization}
                  </p>
                </div>
              </div>
              <h3>{interview.topic}</h3>
              <p className={styles.cardExcerpt}>{interview.excerpt}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <div className={styles.sectionHeader}>
          <h2>Chiffres &amp; Données</h2>
        </div>
        <div className={styles.statsGrid}>
          {stats.map((item) => (
            <article key={item.figure} className={styles.statCard}>
              <p className={styles.statFigure}>{item.figure}</p>
              <p className={styles.statLabel}>{item.label}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.sectionHeader}>
          <h2>À Propos de la Publication</h2>
        </div>
        <div className={styles.aboutText}>
          <p>
            French Automotive Sector Analysis suit les transformations structurelles de la filière automobile française
            depuis la conception jusqu&apos;à la logistique. L&apos;équipe s&apos;attache à fournir des analyses
            contextualisées, en croisant des sources multiples et en privilégiant une lecture de long terme. La
            publication s&apos;adresse aux professionnels de l&apos;industrie, aux chercheurs, aux représentants
            institutionnels et aux étudiants qui souhaitent disposer d&apos;éléments fiables pour comprendre les
            mutations en cours.
          </p>
        </div>
      </section>
    </>
  );
}

export default Home;