import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { analyses } from '../data/analyses';
import { interviews } from '../data/interviews';
import styles from './Archives.module.css';

function Archives() {
  const allYears = useMemo(() => {
    const yearSet = new Set();
    analyses.forEach((item) => yearSet.add(new Date(item.date).getFullYear()));
    interviews.forEach((item) => yearSet.add(new Date(item.date).getFullYear()));
    return Array.from(yearSet).sort((a, b) => b - a);
  }, []);

  const allThemes = useMemo(() => {
    const themeSet = new Set();
    analyses.forEach((item) => item.tags.forEach((tag) => themeSet.add(tag)));
    interviews.forEach((item) => themeSet.add(item.theme));
    return Array.from(themeSet).sort();
  }, []);

  const [selectedYear, setSelectedYear] = useState('Tous');
  const [selectedTheme, setSelectedTheme] = useState('Tous');

  const archiveItems = useMemo(() => {
    const analysisItems = analyses.map((item) => ({
      id: item.id,
      title: item.title,
      date: item.date,
      type: 'Analyse',
      tags: item.tags,
      link: `/analyses/${item.slug}`,
    }));
    const interviewItems = interviews.map((item) => ({
      id: `interview-${item.id}`,
      title: item.topic,
      date: item.date,
      type: 'Interview',
      tags: [item.theme, item.role],
      link: '/interviews',
    }));
    return [...analysisItems, ...interviewItems].sort((a, b) => new Date(b.date) - new Date(a.date));
  }, []);

  const filteredItems = archiveItems.filter((item) => {
    const yearMatch = selectedYear === 'Tous' || new Date(item.date).getFullYear().toString() === selectedYear;
    const themeMatch =
      selectedTheme === 'Tous' ||
      item.tags.some((tag) => tag.toLowerCase() === selectedTheme.toLowerCase());
    return yearMatch && themeMatch;
  });

  return (
    <>
      <Helmet>
        <title>Archives | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Archives complètes des analyses et des interviews relatives à l’industrie automobile française, classées par année et par thématique."
        />
        <meta
          name="keywords"
          content="archives automobile, analyses historiques, interviews experts, filière automobile française"
        />
      </Helmet>
      <section className={styles.section}>
        <header className={styles.header}>
          <h1>Archives</h1>
          <p>
            Parcours chronologique et thématique de l&apos;ensemble des publications disponibles au sein de French
            Automotive Sector Analysis.
          </p>
        </header>
        <div className={styles.filters}>
          <div className={styles.filter}>
            <label htmlFor="yearSelect">Année</label>
            <select
              id="yearSelect"
              value={selectedYear}
              onChange={(event) => setSelectedYear(event.target.value)}
            >
              <option value="Tous">Toutes les années</option>
              {allYears.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </div>
          <div className={styles.filter}>
            <label htmlFor="themeSelect">Thématique</label>
            <select
              id="themeSelect"
              value={selectedTheme}
              onChange={(event) => setSelectedTheme(event.target.value)}
            >
              <option value="Tous">Toutes les thématiques</option>
              {allThemes.map((theme) => (
                <option key={theme} value={theme}>
                  {theme}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className={styles.list}>
          {filteredItems.map((item) => (
            <article key={item.id} className={styles.card}>
              <div className={styles.cardHeader}>
                <span className={styles.type}>{item.type}</span>
                <span className={styles.date}>{new Date(item.date).toLocaleDateString('fr-FR')}</span>
              </div>
              <h2>{item.title}</h2>
              <ul className={styles.tags}>
                {item.tags.map((tag) => (
                  <li key={tag}>{tag}</li>
                ))}
              </ul>
              <Link to={item.link} className={styles.link}>
                Consulter
              </Link>
            </article>
          ))}
          {filteredItems.length === 0 && (
            <p className={styles.empty}>Aucun contenu ne correspond aux filtres sélectionnés.</p>
          )}
        </div>
      </section>
    </>
  );
}

export default Archives;