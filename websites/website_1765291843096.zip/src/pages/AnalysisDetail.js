import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { analyses } from '../data/analyses';
import styles from './AnalysisDetail.module.css';

function AnalysisDetail() {
  const { slug } = useParams();
  const analysis = analyses.find((item) => item.slug === slug);

  if (!analysis) {
    return (
      <section className={styles.section}>
        <div className={styles.notFound}>
          <h1>Analyse introuvable</h1>
          <p>Le contenu recherché n&apos;est pas disponible ou a été déplacé.</p>
          <Link to="/analyses" className={styles.backLink}>
            Revenir aux analyses
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{analysis.title} | French Automotive Sector Analysis</title>
        <meta name="description" content={analysis.description} />
        <meta
          name="keywords"
          content={analysis.tags.join(', ') + ', industrie automobile française, étude sectorielle'}
        />
      </Helmet>
      <section className={styles.section}>
        <article className={styles.article}>
          <header className={styles.header}>
            <p className={styles.date}>{new Date(analysis.date).toLocaleDateString('fr-FR')}</p>
            <h1>{analysis.title}</h1>
            {analysis.subtitle && <h2 className={styles.subtitle}>{analysis.subtitle}</h2>}
            <ul className={styles.tags}>
              {analysis.tags.map((tag) => (
                <li key={tag}>{tag}</li>
              ))}
            </ul>
          </header>
          <div className={styles.content}>
            {analysis.content.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
          <footer className={styles.footer}>
            <Link to="/analyses" className={styles.backLink}>
              Retour à la liste des analyses
            </Link>
          </footer>
        </article>
      </section>
    </>
  );
}

export default AnalysisDetail;