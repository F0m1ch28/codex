import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Terms.module.css';

function Terms() {
  return (
    <>
      <Helmet>
        <title>Conditions d&apos;utilisation | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Conditions générales d’utilisation du site French Automotive Sector Analysis."
        />
      </Helmet>
      <section className={styles.section}>
        <h1>Conditions d&apos;utilisation</h1>
        <article>
          <h2>1. Objet</h2>
          <p>
            Les présentes conditions encadrent l’accès et l’utilisation du site French Automotive Sector Analysis. En
            consultant le site, l’utilisateur accepte l’ensemble des dispositions ci-après détaillées.
          </p>
        </article>
        <article>
          <h2>2. Accès au site</h2>
          <p>
            Le site est accessible gratuitement à tout utilisateur disposant d’un accès à Internet. Tous les frais
            permettant cette connexion restent à la charge de l’utilisateur. Le site peut être interrompu pour des raisons
            de maintenance ou d’actualisation sans préavis.
          </p>
        </article>
        <article>
          <h2>3. Contenus éditoriaux</h2>
          <p>
            Les informations publiées sont fournies à titre informatif. Elles résultent d’analyses, de données publiques
            et de témoignages d’experts identifiés. La rédaction veille à leur exactitude mais ne peut garantir
            l’absence totale d’erreur ou d’omission. Les utilisateurs sont invités à recouper les informations avec leurs
            propres sources.
          </p>
        </article>
        <article>
          <h2>4. Utilisation des contenus</h2>
          <p>
            Toute reproduction ou diffusion des contenus du site doit être accompagnée de la mention explicite du titre
            French Automotive Sector Analysis et, le cas échéant, d’un lien vers l’article concerné. Les contenus ne
            peuvent être modifiés ou sortis de leur contexte sans accord préalable.
          </p>
        </article>
        <article>
          <h2>5. Responsabilité</h2>
          <p>
            La rédaction ne saurait être tenue responsable des dommages directs ou indirects résultant de l’utilisation du
            site ou des informations communiquées. Les décisions professionnelles ou organisationnelles prises à partir des
            analyses relèvent de la seule responsabilité des utilisateurs.
          </p>
        </article>
        <article>
          <h2>6. Liens externes</h2>
          <p>
            Le site peut contenir des liens vers des ressources externes. French Automotive Sector Analysis ne contrôle
            pas ces contenus et décline toute responsabilité quant aux informations ou services proposés sur ces sites
            tiers.
          </p>
        </article>
        <article>
          <h2>7. Données personnelles</h2>
          <p>
            Les modalités de collecte et de traitement des données personnelles sont décrites dans la politique de
            confidentialité. L’utilisateur peut exercer ses droits conformément aux dispositions applicables en matière de
            protection des données.
          </p>
        </article>
        <article>
          <h2>8. Modification des conditions</h2>
          <p>
            Les conditions peuvent être modifiées à tout moment afin de prendre en compte l’évolution du site ou de la
            réglementation. Les utilisateurs sont invités à les consulter régulièrement.
          </p>
        </article>
        <article>
          <h2>9. Droit applicable</h2>
          <p>
            Les conditions sont régies par le droit français. En cas de litige, les juridictions françaises sont seules
            compétentes.
          </p>
        </article>
      </section>
    </>
  );
}

export default Terms;