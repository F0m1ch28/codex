import React from 'react';
import { Helmet } from 'react-helmet-async';
import { interviews } from '../data/interviews';
import styles from './Interviews.module.css';

function Interviews() {
  return (
    <>
      <Helmet>
        <title>Interviews et témoignages | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Entretiens avec ingénieurs, économistes et designers de l’automobile française. Regards croisés sur l’électrification, la logistique, la robotisation et la conception des véhicules."
        />
        <meta
          name="keywords"
          content="interviews automobile, experts industrie, ingénierie automobile, design automobile, économie industrielle"
        />
      </Helmet>
      <section className={styles.section}>
        <header className={styles.header}>
          <h1>Interviews</h1>
          <p>
            Les interviews donnent la parole aux spécialistes qui conçoivent, pilotent et évaluent les mutations de la
            filière automobile française. Chaque entretien suit un format structuré, précis et documenté.
          </p>
        </header>
        <div className={styles.list}>
          {interviews.map((interview) => (
            <article key={interview.id} className={styles.card}>
              <div className={styles.profile}>
                <img src={interview.photo} alt={`Portrait de ${interview.name}`} />
                <div>
                  <h2>{interview.name}</h2>
                  <p className={styles.role}>
                    {interview.role} · {interview.organization}
                  </p>
                  <p className={styles.topic}>{interview.topic}</p>
                </div>
              </div>
              <p className={styles.excerpt}>{interview.excerpt}</p>
              <div className={styles.qa}>
                {interview.questions.map((q) => (
                  <div key={q.question} className={styles.qaItem}>
                    <p className={styles.question}>{q.question}</p>
                    <p className={styles.answer}>{q.answer}</p>
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default Interviews;