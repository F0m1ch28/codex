import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

function Contact() {
  const [formData, setFormData] = useState({
    email: '',
    subject: '',
    message: '',
  });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.email || !formData.subject || !formData.message) {
      setStatus({ type: 'error', message: 'Merci de compléter tous les champs requis.' });
      return;
    }
    setStatus({
      type: 'success',
      message: 'Le message a été enregistré. La rédaction répondra dans les meilleurs délais si nécessaire.',
    });
    setFormData({
      email: '',
      subject: '',
      message: '',
    });
  };

  return (
    <>
      <Helmet>
        <title>Contact | French Automotive Sector Analysis</title>
        <meta
          name="description"
          content="Contacter la rédaction de French Automotive Sector Analysis pour toute question relative aux analyses sectorielles ou aux contenus éditoriaux."
        />
        <meta
          name="keywords"
          content="contact rédaction, publication automobile, questions sectorielles, industrie automobile"
        />
      </Helmet>
      <section className={styles.section}>
        <div className={styles.intro}>
          <h1>Contact</h1>
          <p>
            Pour toute demande d&apos;information ou proposition d&apos;échange, la rédaction peut être contactée par le
            biais du formulaire ci-dessous ou à l&apos;adresse redaction@automotive-analysis.fr. La publication n&apos;assure pas de
            prestations de conseil et ne délivre pas d&apos;orientations financières.
          </p>
          <p className={styles.address}>Adresse éditoriale : Publication en ligne - Analyse sectorielle</p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="email">Adresse email</label>
          <input
            id="email"
            name="email"
            type="email"
            placeholder="nom@example.com"
            value={formData.email}
            onChange={handleChange}
            required
          />

          <label htmlFor="subject">Sujet</label>
          <input
            id="subject"
            name="subject"
            type="text"
            placeholder="Objet de la demande"
            value={formData.subject}
            onChange={handleChange}
            required
          />

          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            placeholder="Votre message"
            rows="6"
            value={formData.message}
            onChange={handleChange}
            required
          />

          <button type="submit">Envoyer</button>
          {status.message && (
            <p className={status.type === 'error' ? styles.error : styles.success}>{status.message}</p>
          )}
        </form>
      </section>
    </>
  );
}

export default Contact;