export const interviews = [
  {
    id: 1,
    name: 'Claire Marchand',
    role: 'Responsable ingénierie batteries',
    organization: 'Stellantis - Centre de Trémery',
    topic: 'Coordonner l’industrialisation des modules batteries en France',
    excerpt:
      "Claire Marchand détaille la montée en puissance des lignes batteries du groupe et le rôle des partenariats scientifiques pour fiabiliser chimie, sécurité et recyclage dans l'Hexagone.",
    theme: 'Batteries',
    date: '2024-03-01',
    photo: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80',
    questions: [
      {
        question: 'Comment la filière française structure-t-elle la montée en cadence des modules batteries ?',
        answer:
          "La stratégie repose sur une coordination fine entre sites de production, laboratoires partenaires et fournisseurs de matériaux. Les équipes françaises ont défini un référentiel commun qui couvre la traçabilité, les essais de sécurité et l'organisation des retours d'expérience. Cette cohérence facilite l'harmonisation des procédés et réduit les risques de dérive qualitative.",
      },
      {
        question: 'Quel rôle jouent les compétences locales ?',
        answer:
          "Les sites français disposent d’une expertise historique en mécanique et en thermique. Les collaborateurs suivent désormais des formations en chimie des électrodes et en électronique de puissance. Cette hybridation des compétences permet de sécuriser la production et de préparer les évolutions de générations de cellules.",
      },
      {
        question: 'Quels sont les axes de travail prioritaires pour 2024 ?',
        answer:
          "La priorité porte sur l'optimisation énergétique des process et sur la réduction de l'empreinte carbone des matériaux entrants. Les partenariats académiques autour du recyclage hydrométallurgique jouent un rôle central pour récupérer des composants stratégiques et alimenter les futures séries.",
      },
    ],
  },
  {
    id: 2,
    name: 'Mathieu Rolland',
    role: 'Directeur logistique Europe',
    organization: 'Renault Group',
    topic: 'Renforcer la résilience des chaînes logistiques hexagonales',
    excerpt:
      "Mathieu Rolland partage la cartographie des risques suivie par Renault Group, les nouveaux indicateurs de traçabilité et les collaborations avec les autorités portuaires françaises.",
    theme: 'Logistique',
    date: '2024-02-20',
    photo: 'https://images.unsplash.com/photo-1522199996660-7b5e0a0d79c5?auto=format&fit=crop&w=300&q=80',
    questions: [
      {
        question: 'Quels enseignements tirer des disruptions récentes ?',
        answer:
          "Les événements des trois dernières années ont mis en évidence la nécessité d'une vision temps réel. Les équipes ont développé des tableaux de bord intégrant tous les flux critiques et des scénarios d'urgence. Cette transparence partagée avec les fournisseurs de rangs 2 et 3 facilite la prise de décision.",
      },
      {
        question: 'Comment la durabilité s’intègre-t-elle à la logistique ?',
        answer:
          "Chaque fournisseur doit désormais fournir des indicateurs environnementaux vérifiables. Nous harmonisons les formats de reporting, ce qui permet de comparer les performances entre sites et de prioriser les actions correctives. Les ports français nous accompagnent dans l'électrification des zones de manutention.",
      },
      {
        question: 'Quels outils soutiennent cette transformation ?',
        answer:
          "Nous déployons des jumeaux numériques pour simuler divers scénarios et dimensionner les stocks de sécurité. Ces outils sont conçus avec des partenaires technologiques français, ce qui favorise la souveraineté des données.",
      },
    ],
  },
  {
    id: 3,
    name: 'Sophie Delorme',
    role: 'Cheffe de projet robotisation',
    organization: 'Valeo - Pôle d’Annonay',
    topic: 'Automatiser sans fragmenter les équipes de production',
    excerpt:
      "Sophie Delorme explique comment Valeo associe opérateurs et ingénieurs dans la robotisation de ses lignes tout en préservant la qualité de production et la cohésion des ateliers.",
    theme: 'Robotisation',
    date: '2024-01-30',
    photo: 'https://images.unsplash.com/photo-1531891437562-4301cf35b7e4?auto=format&fit=crop&w=300&q=80',
    questions: [
      {
        question: 'Quelle méthode privilégiez-vous pour introduire un nouveau robot ?',
        answer:
          "Chaque projet débute par une phase de simulation où les opérateurs participent aux ajustements. Cela permet de définir précisément les périmètres d'interaction homme-machine et de sécuriser l'ergonomie avant l'installation réelle.",
      },
      {
        question: 'Comment accompagnez-vous les équipes ?',
        answer:
          "Nous avons mis en place un cursus interne combinant formations théoriques, ateliers pratiques et mentorat. Les opérateurs sont encouragés à prendre des responsabilités en supervision ou en maintenance, ce qui renforce la polyvalence collective.",
      },
      {
        question: 'Quels sont les prochains axes de travail ?',
        answer:
          "Nous poursuivons l'intégration des outils de vision 3D et l'amélioration de la cybersécurité. L'objectif est de maintenir un haut niveau de disponibilité tout en respectant les exigences des constructeurs en matière de qualité.",
      },
    ],
  },
];