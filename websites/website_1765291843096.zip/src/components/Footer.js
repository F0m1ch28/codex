import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brandBlock}>
          <p className={styles.brandName}>French Automotive Sector Analysis</p>
          <p className={styles.brandDescription}>
            Publication en ligne consacrée à l&apos;analyse structurée de l&apos;industrie automobile française et de ses
            écosystèmes techniques.
          </p>
        </div>
        <div className={styles.linksBlock}>
          <h3 className={styles.heading}>Navigation</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/analyses" className={styles.link}>
                Analyses
              </Link>
            </li>
            <li>
              <Link to="/interviews" className={styles.link}>
                Interviews
              </Link>
            </li>
            <li>
              <Link to="/archives" className={styles.link}>
                Archives
              </Link>
            </li>
            <li>
              <Link to="/a-propos" className={styles.link}>
                À Propos
              </Link>
            </li>
            <li>
              <Link to="/contact" className={styles.link}>
                Contact
              </Link>
            </li>
          </ul>
        </div>
        <div className={styles.legalBlock}>
          <h3 className={styles.heading}>Informations légales</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/terms" className={styles.link}>
                Conditions d&apos;utilisation
              </Link>
            </li>
            <li>
              <Link to="/privacy" className={styles.link}>
                Politique de confidentialité
              </Link>
            </li>
            <li>
              <Link to="/cookie-policy" className={styles.link}>
                Politique relative aux cookies
              </Link>
            </li>
          </ul>
          <p className={styles.contactLine}>Email rédaction : redaction@automotive-analysis.fr</p>
          <p className={styles.contactLine}>Adresse : Publication en ligne - Analyse sectorielle</p>
        </div>
      </div>
      <div className={styles.bottomNote}>
        <p>© {new Date().getFullYear()} French Automotive Sector Analysis. Tous droits réservés.</p>
      </div>
    </footer>
  );
}

export default Footer;