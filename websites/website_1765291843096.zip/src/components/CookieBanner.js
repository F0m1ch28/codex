import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('fasa-cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('fasa-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Ce site utilise des cookies strictement nécessaires au fonctionnement et à la mesure d&apos;audience. Pour en
        savoir plus, consulter la <Link to="/cookie-policy">politique relative aux cookies</Link>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Compris
      </button>
    </div>
  );
}

export default CookieBanner;