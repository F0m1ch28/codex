import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          French Automotive Sector Analysis
        </NavLink>
        <button
          className={styles.hamburger}
          type="button"
          aria-label="Basculer la navigation"
          aria-expanded={menuOpen}
          onClick={toggleMenu}
        >
          <span className={styles.bar} />
          <span className={styles.bar} />
          <span className={styles.bar} />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Navigation principale">
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}>
            Accueil
          </NavLink>
          <NavLink
            to="/analyses"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
          >
            Analyses
          </NavLink>
          <NavLink
            to="/interviews"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
          >
            Interviews
          </NavLink>
          <NavLink
            to="/archives"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
          >
            Archives
          </NavLink>
          <NavLink
            to="/a-propos"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
          >
            À Propos
          </NavLink>
          <NavLink
            to="/contact"
            onClick={closeMenu}
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
          >
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default Header;