document.addEventListener('DOMContentLoaded', () => {
    const yearSpan = document.querySelectorAll('#current-year');
    yearSpan.forEach(span => span.textContent = new Date().getFullYear());

    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });
    }

    const banner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('[data-cookie]');
    const consent = localStorage.getItem('baa-cookie-consent');

    if (banner && !consent) {
        requestAnimationFrame(() => banner.classList.add('show'));
    }

    cookieButtons.forEach(button => {
        button.addEventListener('click', () => {
            const choice = button.dataset.cookie;
            localStorage.setItem('baa-cookie-consent', choice);
            banner.classList.remove('show');
        });
    });

    const searchInput = document.getElementById('agency-search');
    const categorySelect = document.getElementById('filter-category');
    const citySelect = document.getElementById('filter-city');
    const agencyList = document.getElementById('agency-list');
    const noResults = document.querySelector('.no-results');

    if (agencyList && searchInput && categorySelect && citySelect) {
        const agencyCards = Array.from(agencyList.children);

        const filterAgencies = () => {
            const term = searchInput.value.trim().toLowerCase();
            const category = categorySelect.value;
            const city = citySelect.value;

            let matches = 0;

            agencyCards.forEach(card => {
                const name = card.dataset.name.toLowerCase();
                const cardCategory = card.dataset.category;
                const cardCity = card.dataset.city;

                const matchesName = name.includes(term);
                const matchesCategory = category === 'all' || cardCategory === category;
                const matchesCity = city === 'all' || cardCity === city;

                if (matchesName && matchesCategory && matchesCity) {
                    card.hidden = false;
                    matches++;
                } else {
                    card.hidden = true;
                }
            });

            if (noResults) {
                noResults.hidden = matches !== 0;
            }
        };

        searchInput.addEventListener('input', filterAgencies);
        categorySelect.addEventListener('change', filterAgencies);
        citySelect.addEventListener('change', filterAgencies);
    }
});