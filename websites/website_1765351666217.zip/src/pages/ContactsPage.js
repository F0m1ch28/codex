import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./ContactsPage.module.css";

const initialFormState = { name: "", email: "", topic: "", message: "" };

const ContactsPage = () => {
  const [form, setForm] = React.useState(initialFormState);
  const [status, setStatus] = React.useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setStatus({ type: "error", message: "Заполните обязательные поля." });
      return;
    }
    setStatus({ type: "success", message: "Спасибо! Мы свяжемся с вами в ближайшее время." });
    setForm(initialFormState);
  };

  return (
    <>
      <MetaTags
        title="Контакты — Digital Cover Art"
        description="Свяжитесь с командой Digital Cover Art: поддержка, сотрудничество и общие вопросы."
      />
      <section className={styles.hero}>
        <h1>Свяжитесь с нами</h1>
        <p>
          Мы — цифровая платформа. Свяжитесь с нами онлайн: команда отвечает в течение 24 часов.
        </p>
      </section>
      <section className={styles.grid}>
        <div className={styles.info}>
          <h2>Контактные данные</h2>
          <p>
            Поддержка:{" "}
            <a href="mailto:support@digitalcoverart.com">support@digitalcoverart.com</a>
          </p>
          <p>
            Сотрудничество:{" "}
            <a href="mailto:partners@digitalcoverart.com">partners@digitalcoverart.com</a>
          </p>
          <p>
            Мы собираем заявки на кастомные проекты, партнёрство и предложения по развитию платформы.
          </p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Отправить сообщение</h2>
          <label htmlFor="name">
            Имя*
            <input
              id="name"
              name="name"
              type="text"
              value={form.name}
              onChange={handleChange}
              placeholder="Как к вам обращаться?"
              required
              aria-required="true"
            />
          </label>
          <label htmlFor="email">
            Email*
            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              placeholder="you@example.com"
              required
              aria-required="true"
            />
          </label>
          <label htmlFor="topic">
            Тема
            <input
              id="topic"
              name="topic"
              type="text"
              value={form.topic}
              onChange={handleChange}
              placeholder="Выберите тему обращения"
            />
          </label>
          <label htmlFor="message">
            Сообщение*
            <textarea
              id="message"
              name="message"
              rows="5"
              value={form.message}
              onChange={handleChange}
              placeholder="Опишите задачу или вопрос"
              required
              aria-required="true"
            />
          </label>
          <button type="submit">Отправить</button>
          {status && (
            <p
              className={
                status.type === "success" ? styles.successMessage : styles.errorMessage
              }
            >
              {status.message}
            </p>
          )}
        </form>
      </section>
    </>
  );
};

export default ContactsPage;