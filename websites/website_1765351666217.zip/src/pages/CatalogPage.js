import React from "react";
import { NavLink } from "react-router-dom";
import MetaTags from "../components/MetaTags";
import styles from "./CatalogPage.module.css";

const catalogSections = [
  {
    title: "Обложки для видео",
    description:
      "Готовые превью для YouTube, VK Видео, TikTok. Адаптированы под разные соотношения сторон и форматы заголовков.",
    to: "/catalog/video-covers",
    image: "https://picsum.photos/800/600?random=501"
  },
  {
    title: "Аватарки и логотипы",
    description:
      "Коллекции для персональных брендов, киберспортивных команд и подкастов. Варианты с персонажами, типографикой и эмблемами.",
    to: "/catalog/avatars",
    image: "https://picsum.photos/800/600?random=502"
  },
  {
    title: "Баннеры и оверлеи стрима",
    description:
      "Комплекты для Twitch и YouTube Live: стартовые экраны, баннеры каналов, панели донатов и расписания.",
    to: "/catalog/stream-banners",
    image: "https://picsum.photos/800/600?random=503"
  }
];

const CatalogPage = () => {
  return (
    <>
      <MetaTags
        title="Каталог Digital Cover Art — обложки, аватарки, баннеры"
        description="Просматривайте каталог Digital Cover Art: обложки для видео, аватарки и баннеры для стримов от дизайнеров по всему миру."
      />
      <section className={styles.hero}>
        <h1>Каталог Digital Cover Art</h1>
        <p>
          Откройте curated-подборку цифрового дизайна от лучших авторов платформы.
          Используйте фильтры по платформам, жанрам и ключевым цветам, сохраните работы в коллекции или оформите кастомный заказ.
        </p>
      </section>
      <section className={styles.gridSection}>
        {catalogSections.map((section) => (
          <article key={section.title} className={styles.card}>
            <img src={section.image} alt={section.title} loading="lazy" />
            <div className={styles.cardContent}>
              <h2>{section.title}</h2>
              <p>{section.description}</p>
              <NavLink to={section.to} className={styles.cardLink}>
                Открыть коллекцию →
              </NavLink>
            </div>
          </article>
        ))}
      </section>
      <section className={styles.cta}>
        <div>
          <h2>Нужен полный визуальный комплект?</h2>
          <p>
            Мы соберём команду авторов под ваш проект и подготовим полный набор графики:
            от превью до анимированных оверлеев. Расскажите о задаче — и мы предложим
            решение с учётом сроков и масштаба.
          </p>
        </div>
        <NavLink to="/contacts" className={styles.ctaButton}>
          Обсудить проект
        </NavLink>
      </section>
    </>
  );
};

export default CatalogPage;