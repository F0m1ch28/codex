import React from "react";
import { NavLink } from "react-router-dom";
import MetaTags from "../components/MetaTags";
import styles from "./HomePage.module.css";

const categories = [
  {
    title: "Обложки для видео",
    description: "Эффектные превью для YouTube, TikTok и Reels с высокой конверсией.",
    to: "/catalog/video-covers",
    image: "https://picsum.photos/600/400?random=101"
  },
  {
    title: "Аватарки",
    description: "Премиальные аватары для стримеров, блогеров и команд.",
    to: "/catalog/avatars",
    image: "https://picsum.photos/600/400?random=102"
  },
  {
    title: "Баннеры для стримов",
    description: "Оформление Twitch и YouTube каналов с единым стилем.",
    to: "/catalog/stream-banners",
    image: "https://picsum.photos/600/400?random=103"
  }
];

const galleryProjects = [
  {
    id: 1,
    title: "Cyber Pulse",
    category: "Обложки",
    image: "https://picsum.photos/800/600?random=201",
    tags: ["YouTube", "Неон", "Sci-fi"]
  },
  {
    id: 2,
    title: "Stream Nova",
    category: "Баннеры",
    image: "https://picsum.photos/800/600?random=202",
    tags: ["Twitch", "Градиент", "Motion"]
  },
  {
    id: 3,
    title: "Creator ID",
    category: "Аватары",
    image: "https://picsum.photos/800/600?random=203",
    tags: ["Команда", "Esports"]
  },
  {
    id: 4,
    title: "Future Cast",
    category: "Обложки",
    image: "https://picsum.photos/800/600?random=204",
    tags: ["YouTube", "Минимализм"]
  },
  {
    id: 5,
    title: "Pixel Squad",
    category: "Аватары",
    image: "https://picsum.photos/800/600?random=205",
    tags: ["Gaming", "Mascot"]
  },
  {
    id: 6,
    title: "Live Horizon",
    category: "Баннеры",
    image: "https://picsum.photos/800/600?random=206",
    tags: ["Live", "Abstract"]
  }
];

const testimonials = [
  {
    quote:
      "Digital Cover Art полностью преобразил визуальную айдентику моего канала. Превью стали заметнее, CTR вырос без дополнительной рекламы.",
    name: "Алексей Громов",
    role: "YouTube-автор",
    image: "https://picsum.photos/200/200?random=301"
  },
  {
    quote:
      "Команда платформы помогла подобрать дизайнера под стиль нашего турнира. Все материалы были готовы раньше дедлайна и выглядели превосходно.",
    name: "Team Aurora",
    role: "Киберспортивная организация",
    image: "https://picsum.photos/200/200?random=302"
  },
  {
    quote:
      "Продажи моих работ выросли в два раза после публикации на Digital Cover Art. Интерфейс прост, статистика прозрачная, поддержка отвечает быстро.",
    name: "Ника Ю.",
    role: "Дизайнер",
    image: "https://picsum.photos/200/200?random=303"
  }
];

const faqItems = [
  {
    question: "Как выбрать оптимальную обложку для своего видео?",
    answer:
      "Сначала определите ключевую эмоцию ролика и аудиторию. В каталоге используйте фильтры по жанру, цветовой гамме и платформе. Обратите внимание на динамичные композиции и читаемость текста."
  },
  {
    question: "Можно ли заказать уникальный дизайн под ключ?",
    answer:
      "Да, отправьте бриф через страницу контактов или свяжитесь по адресу partners@digitalcoverart.com. Мы подберём дизайнера и организуем прозрачный процесс согласований."
  },
  {
    question: "Какие форматы файлов я получу после покупки?",
    answer:
      "Стандартно предоставляются PSD или Figma-файлы плюс экспорт в PNG/JPEG для быстрого использования. Детали указаны в карточке продукта."
  },
  {
    question: "Как стать автором на платформе?",
    answer:
      "Ознакомьтесь с разделом «Для дизайнеров», подготовьте портфолио и отправьте заявку. Мы проверяем уникальность работ и соответствие стандартам качества."
  }
];

const blogPosts = [
  {
    title: "7 трендов оформления каналов в 2024",
    excerpt:
      "Разбираем, почему неоновые акценты и кинематографичные композиции работают лучше, чем однообразные шаблоны.",
    image: "https://picsum.photos/600/400?random=401",
    date: "15 марта 2024"
  },
  {
    title: "Как создать сет брендинга для Twitch за выходные",
    excerpt:
      "Пошаговый гайд по созданию единого стиля: от баннеров и оверлеев до эмодзи и экранов перехода.",
    image: "https://picsum.photos/600/400?random=402",
    date: "2 марта 2024"
  },
  {
    title: "Что нужно знать про авторские права на цифровой арт",
    excerpt:
      "Советы юристов о том, как легально использовать дизайн и защитить свои работы как автор.",
    image: "https://picsum.photos/600/400?random=403",
    date: "21 февраля 2024"
  }
];

const HomePage = () => {
  const [activeFilter, setActiveFilter] = React.useState("Все");
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);

  const filteredGallery =
    activeFilter === "Все"
      ? galleryProjects
      : galleryProjects.filter((item) => item.category === activeFilter);

  const handleNextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
  };

  const handlePrevTestimonial = () => {
    setTestimonialIndex((prev) =>
      prev === 0 ? testimonials.length - 1 : prev - 1
    );
  };

  return (
    <>
      <MetaTags
        title="Digital Cover Art — цифровые обложки, аватарки и баннеры"
        description="Выбирайте и покупайте премиальные обложки для видео, аватарки и баннеры для стримов на международной платформе Digital Cover Art."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Платформа цифрового дизайна</p>
          <h1 className={styles.heroTitle}>
            Создавайте медиа-бренд с обложек, о которых говорят
          </h1>
          <p className={styles.heroSubtitle}>
            Digital Cover Art помогает создателям выделяться при любой географии и формате.
            Выбирайте готовые решения или работайте с авторами напрямую.
          </p>
          <div className={styles.heroActions}>
            <NavLink to="/catalog" className={styles.primaryButton}>
              Смотреть каталог
            </NavLink>
            <NavLink to="/for-designers" className={styles.secondaryButton}>
              Я дизайнер
            </NavLink>
          </div>
          <div className={styles.stats}>
            <div>
              <span>12 000+</span>
              <p>готовых работ</p>
            </div>
            <div>
              <span>2 400</span>
              <p>дизайнеров в сообществе</p>
            </div>
            <div>
              <span>68 стран</span>
              <p>в нашей аудитории</p>
            </div>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Цифровая композиция с героями и неоновыми элементами"
            loading="lazy"
          />
          <div className={styles.heroBadge}>
            <span>Новая поставка</span>
            <p>Тренды весна 2024</p>
          </div>
        </div>
      </section>

      <section className={styles.categorySection}>
        <div className={styles.sectionHeader}>
          <h2>Популярные категории</h2>
          <p>
            Мы отбираем стили и композиции, которые повышают вовлечённость аудитории.
            Найдите готовое решение или вдохновитесь для кастомного заказа.
          </p>
        </div>
        <div className={styles.categoryGrid}>
          {categories.map((category) => (
            <NavLink key={category.title} to={category.to} className={styles.categoryCard}>
              <div className={styles.cardImageWrapper}>
                <img src={category.image} alt={category.title} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <h3>{category.title}</h3>
                <p>{category.description}</p>
                <span className={styles.cardLink}>Перейти →</span>
              </div>
            </NavLink>
          ))}
        </div>
      </section>

      <section className={styles.processSection}>
        <h2>Как это работает</h2>
        <div className={styles.processGrid}>
          <div>
            <span>1</span>
            <h3>Исследуйте каталог</h3>
            <p>
              Используйте фильтры по платформе, жанру и цветовой палитре. Каждый продукт
              проходил модерацию качества и проверки лицензий.
            </p>
          </div>
          <div>
            <span>2</span>
            <h3>Сравнивайте и сохраняйте</h3>
            <p>
              Создавайте подборки, делитесь с командой, сохраняйте избранное. Алгоритм
              предлагает похожие стили и авторов.
            </p>
          </div>
          <div>
            <span>3</span>
            <h3>Получайте файлы мгновенно</h3>
            <p>
              После покупки вы получаете экспорт и исходники. Для уникальных проектов
              предусмотрен чат с дизайнером и этапы согласования.
            </p>
          </div>
          <div>
            <span>4</span>
            <h3>Аналитика и поддержка</h3>
            <p>
              Отслеживайте статистику скачиваний, получайте рекомендации по улучшению CTR
              и персональные подборки трендовых решений.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.advantagesSection}>
        <h2>Почему Digital Cover Art</h2>
        <div className={styles.advantagesGrid}>
          <article>
            <h3>Кураторский отбор</h3>
            <p>
              Мы работаем с ведущими студиями и независимыми авторами. Каждая работа
              проходит проверку на уникальность и техническое соответствие.
            </p>
          </article>
          <article>
            <h3>Международная аудитория</h3>
            <p>
              Каталог адаптируется под YouTube, Twitch, Kick, VK Видео и другие
              платформы. Выбирайте языки, шрифты и форматы для любого региона.
            </p>
          </article>
          <article>
            <h3>Гибкая персонализация</h3>
            <p>
              Нужны цвета бренда или интеграция логотипа? Добавьте комментарий к заказу —
              автор подготовит доработку без потери сроков.
            </p>
          </article>
          <article>
            <h3>Поддержка 24/7</h3>
            <p>
              Команда поддержки и технических специалистов решает вопросы по файлам,
              лицензиям и работе платформы круглосуточно.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.gallerySection}>
        <div className={styles.sectionHeader}>
          <h2>Избранные проекты</h2>
          <p>
            Посмотрите, как авторы комбинируют типографику, визуальные эффекты и цвет,
            создавая выразительные истории для ваших контентов.
          </p>
        </div>
        <div className={styles.filterBar} role="tablist" aria-label="Фильтр проектов">
          {["Все", "Обложки", "Аватары", "Баннеры"].map((filter) => (
            <button
              key={filter}
              type="button"
              role="tab"
              aria-selected={activeFilter === filter}
              className={`${styles.filterButton} ${
                activeFilter === filter ? styles.filterActive : ""
              }`}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.galleryGrid}>
          {filteredGallery.map((item) => (
            <article key={item.id} className={styles.galleryCard}>
              <img src={item.image} alt={`Проект ${item.title}`} loading="lazy" />
              <div className={styles.galleryContent}>
                <p className={styles.galleryCategory}>{item.category}</p>
                <h3>{item.title}</h3>
                <div className={styles.tagList}>
                  {item.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonialSection}>
        <h2>Отзывы сообщества</h2>
        <div className={styles.testimonialWrapper}>
          <button
            type="button"
            onClick={handlePrevTestimonial}
            aria-label="Предыдущий отзыв"
            className={styles.testimonialControl}
          >
            ←
          </button>
          <article className={styles.testimonialCard}>
            <img
              src={testimonials[testimonialIndex].image}
              alt={`Фото ${testimonials[testimonialIndex].name}`}
              loading="lazy"
            />
            <p className={styles.testimonialQuote}>
              “{testimonials[testimonialIndex].quote}”
            </p>
            <div className={styles.testimonialAuthor}>
              <span>{testimonials[testimonialIndex].name}</span>
              <small>{testimonials[testimonialIndex].role}</small>
            </div>
          </article>
          <button
            type="button"
            onClick={handleNextTestimonial}
            aria-label="Следующий отзыв"
            className={styles.testimonialControl}
          >
            →
          </button>
        </div>
      </section>

      <section className={styles.faqSection}>
        <h2>Частые вопросы</h2>
        <div className={styles.faqGrid}>
          {faqItems.map((item) => (
            <details key={item.question} className={styles.faqItem}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className={styles.sectionHeader}>
          <h2>Свежие материалы блога</h2>
          <p>
            Аналитика, тренды и советы по визуальному брендингу для тех, кто хочет
            держать руку на пульсе индустрии.
          </p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img
                src={post.image}
                alt={`Превью статьи: ${post.title}`}
                loading="lazy"
              />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <NavLink to="/catalog" className={styles.blogLink}>
                  Читать далее →
                </NavLink>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.designerCta}>
        <div className={styles.designerContent}>
          <h2>Продавайте свои работы на Digital Cover Art</h2>
          <p>
            Подключайтесь к международной аудитории, публикуйте подборки, получайте аналитику и
            заработок с каждой продажи. Прозрачные правила, защита авторства и своевременные выплаты.
          </p>
          <NavLink to="/for-designers" className={styles.primaryButton}>
            Стать автором
          </NavLink>
        </div>
        <div className={styles.designerVisual}>
          <img
            src="https://picsum.photos/800/800?random=5"
            alt="Дизайнер работает над цифровым проектом"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.finalCta}>
        <h2>Создайте визуальную идентичность, которую нельзя пролистать</h2>
        <p>
          Подберите стиль, который усилит ваши видео и трансляции уже сегодня. Новые коллекции
          появляются каждую неделю.
        </p>
        <div className={styles.heroActions}>
          <NavLink to="/catalog" className={styles.primaryButton}>
            Перейти в каталог
          </NavLink>
          <NavLink to="/contacts" className={styles.secondaryButton}>
            Связаться с нами
          </NavLink>
        </div>
      </section>
    </>
  );
};

export default HomePage;