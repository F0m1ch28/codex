import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./AboutPage.module.css";

const milestones = [
  {
    year: "2020",
    title: "Запуск платформы",
    description: "Digital Cover Art стартовал как закрытая витрина для дизайнеров YouTube-сообщества."
  },
  {
    year: "2021",
    title: "Выход на Twitch и международный рынок",
    description: "Добавили категории баннеров и локализацию на английский язык."
  },
  {
    year: "2022",
    title: "Система аналитики и кастомных заказов",
    description: "Появились дашборды для авторов и прямые заказы с модерацией."
  },
  {
    year: "2023",
    title: "Глобальное сообщество",
    description: "Соединяем дизайнеров из 40+ стран, расширили поддержку и ускорили проверку контента."
  }
];

const teamMembers = [
  {
    name: "Илья Сорокин",
    role: "CEO & Co-founder",
    image: "https://picsum.photos/400/400?random=901",
    bio: "Отвечает за стратегию развития платформы и партнёрские программы. 8 лет — в digital-маркетинге."
  },
  {
    name: "Мария Лунная",
    role: "Creative Director",
    image: "https://picsum.photos/400/400?random=902",
    bio: "Куратор визуальных коллекций и авторских подборок. Работала с ведущими студиями motion-дизайна."
  },
  {
    name: "Оскар Иванов",
    role: "Head of Product",
    image: "https://picsum.photos/400/400?random=903",
    bio: "Разрабатывает инструменты аналитики и взаимодействия авторов и покупателей."
  }
];

const AboutPage = () => {
  return (
    <>
      <MetaTags
        title="О компании Digital Cover Art"
        description="Узнайте больше о Digital Cover Art — международной платформе для цифровых обложек и графики для создателей контента."
      />
      <section className={styles.hero}>
        <h1>Мы создаём визуальные истории для создателей контента</h1>
        <p>
          Digital Cover Art объединяет дизайнеров и создателей, чтобы каждый канал, стрим и подкаст
          выглядел профессионально с первых секунд. Мы начали как команда энтузиастов YouTube и
          выросли в глобальную платформу.
        </p>
      </section>
      <section className={styles.timeline}>
        {milestones.map((milestone) => (
          <article key={milestone.year} className={styles.milestone}>
            <div className={styles.year}>{milestone.year}</div>
            <div>
              <h2>{milestone.title}</h2>
              <p>{milestone.description}</p>
            </div>
          </article>
        ))}
      </section>
      <section className={styles.teamSection}>
        <h2>Команда и экспертиза</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`Фото: ${member.name}`} loading="lazy" />
              <div className={styles.teamContent}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className={styles.values}>
        <div>
          <h3>Уникальность и честность</h3>
          <p>
            Мы поддерживаем авторов, защищаем права на контент и боремся с плагиатом. Все работы
            проходят модерацию и сравнение с существующими материалами.
          </p>
        </div>
        <div>
          <h3>Фокус на создателях</h3>
          <p>
            От разработчиков до саппорта — мы понимаем боли креаторов, поэтому строим прозрачные
            инструменты для роста и монетизации.
          </p>
        </div>
        <div>
          <h3>Технологии и данные</h3>
          <p>
            Мы анализируем эффективность визуальных решений на разных платформах и делимся
            инсайтами с авторами и клиентами.
          </p>
        </div>
      </section>
    </>
  );
};

export default AboutPage;