import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./ForDesignersPage.module.css";

const advantages = [
  {
    title: "Глобальная аудитория",
    description:
      "Ваши работы увидят создатели из более чем 60 стран. Платформа помогает адаптировать карточки под разные языки."
  },
  {
    title: "Прозрачная аналитика",
    description:
      "Следите за сохранениями, переходами и завершёнными покупками в дашборде. Получайте рекомендации по тегам."
  },
  {
    title: "Поддержка авторов",
    description:
      "Команда помогает с модерацией, подсказывает по трендам и защищает ваши права. Используйте анти-плагиат проверки."
  }
];

const checklist = [
  "Подготовьте 6–10 работ в едином стиле и опишите, для каких платформ они подходят.",
  "Загрузите превью 1920×1080 или 3000×3000 для аватарок, используйте PNG/JPEG высокого качества.",
  "Приложите исходники (PSD, AI, Figma) с аккуратно структурированными слоями.",
  "Добавьте краткую инструкцию по кастомизации или комбинации элементов комплекта."
];

const ForDesignersPage = () => {
  return (
    <>
      <MetaTags
        title="Для дизайнеров — Digital Cover Art"
        description="Подайте заявку и начните продавать цифровые обложки и баннеры на платформе Digital Cover Art."
      />
      <section className={styles.hero}>
        <h1>Продавайте цифровой дизайн вместе с нами</h1>
        <p>
          Digital Cover Art помогает авторам монетизировать творчество, получать аналитику и
          работать с международными заказчиками без лишних барьеров.
        </p>
      </section>
      <section className={styles.advantages}>
        {advantages.map((item) => (
          <article key={item.title}>
            <h2>{item.title}</h2>
            <p>{item.description}</p>
          </article>
        ))}
      </section>
      <section className={styles.checklist}>
        <h2>Как подготовить заявку</h2>
        <ul>
          {checklist.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>
      <section className={styles.cta}>
        <div>
          <h2>Готовы начать?</h2>
          <p>
            Отправьте портфолио и краткий рассказ о себе на адрес{" "}
            <a href="mailto:partners@digitalcoverart.com">partners@digitalcoverart.com</a>.
            Мы свяжемся, чтобы обсудить детали и согласовать условия сотрудничества.
          </p>
        </div>
      </section>
    </>
  );
};

export default ForDesignersPage;