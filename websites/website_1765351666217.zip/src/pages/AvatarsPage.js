import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./AvatarsPage.module.css";

const avatars = [
  {
    title: "Phoenix Squad",
    description: "Командный логотип с акцентом на силуэт символа и яркое свечение.",
    image: "https://picsum.photos/600/600?random=701"
  },
  {
    title: "Creator Persona",
    description: "Индивидуальный персонаж с выраженной эмоцией и графичными линиями.",
    image: "https://picsum.photos/600/600?random=702"
  },
  {
    title: "Digital Emblem",
    description: "Минималистичный знак для личного бренда и социальных сетей.",
    image: "https://picsum.photos/600/600?random=703"
  },
  {
    title: "Stream Spirit",
    description: "Маскот для стримеров с динамичными линиями и фирменным градиентом.",
    image: "https://picsum.photos/600/600?random=704"
  },
  {
    title: "Podcast Voice",
    description: "Современная айдентика для авторских подкастов и интервью.",
    image: "https://picsum.photos/600/600?random=705"
  },
  {
    title: "Neo Minimal",
    description: "Чистый монохромный знак с лёгкой геометрией и вариативными формами.",
    image: "https://picsum.photos/600/600?random=706"
  }
];

const AvatarsPage = () => {
  return (
    <>
      <MetaTags
        title="Аватарки и логотипы — Digital Cover Art"
        description="Каталог аватарок и логотипов для стримеров, команд и персональных брендов. Авторский цифровой стиль."
      />
      <section className={styles.hero}>
        <h1>Аватарки и логотипы</h1>
        <p>
          Отражайте характер бренда с первой секунды. Каждый дизайн включает вариации для разных
          платформ и форматов публикаций.
        </p>
      </section>
      <section className={styles.grid}>
        {avatars.map((avatar) => (
          <article key={avatar.title} className={styles.card}>
            <img src={avatar.image} alt={avatar.title} loading="lazy" />
            <div className={styles.cardContent}>
              <h2>{avatar.title}</h2>
              <p>{avatar.description}</p>
            </div>
          </article>
        ))}
      </section>
      <section className={styles.tip}>
        <h2>Что входит</h2>
        <div className={styles.tipGrid}>
          <div>
            <h3>Версии под платформы</h3>
            <p>Квадрат, круг и адаптивные форматы для Discord, Twitch, TikTok, Telegram.</p>
          </div>
          <div>
            <h3>Исходники</h3>
            <p>Файлы в PSD/AI/Figma с упорядоченными слоями и рекомендациями по цветам.</p>
          </div>
          <div>
            <h3>Гайд по бренду</h3>
            <p>Цветовая палитра, типографика и варианты применения на мерче и превью.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default AvatarsPage;