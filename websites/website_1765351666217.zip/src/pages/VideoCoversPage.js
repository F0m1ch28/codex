import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./VideoCoversPage.module.css";

const videoCovers = [
  {
    title: "Impact Motion",
    description: "Динамичная обложка с акцентом на крупный заголовок и энергичную палитру.",
    image: "https://picsum.photos/800/600?random=601"
  },
  {
    title: "Story Frame",
    description: "Кинематографичный стиль с тёплым градиентом и фокусом на герое.",
    image: "https://picsum.photos/800/600?random=602"
  },
  {
    title: "Retro Stream",
    description: "Неоновый ретро-виб с пиксельной типографикой для геймерских каналов.",
    image: "https://picsum.photos/800/600?random=603"
  },
  {
    title: "Edu Focus",
    description: "Минималистичное решение для образовательных роликов и вебинаров.",
    image: "https://picsum.photos/800/600?random=604"
  },
  {
    title: "Daily Vibes",
    description: "Живой коллаж для лайфстайл-подкастов и ежедневных влогов.",
    image: "https://picsum.photos/800/600?random=605"
  },
  {
    title: "Highlight Buzz",
    description: "Контрастная композиция с крупным объектом и ярким бордером.",
    image: "https://picsum.photos/800/600?random=606"
  }
];

const VideoCoversPage = () => {
  return (
    <>
      <MetaTags
        title="Обложки для видео — Digital Cover Art"
        description="Категория обложек для видео: динамичные превью для YouTube, TikTok и VK Видео, созданные профессиональными дизайнерами."
      />
      <section className={styles.hero}>
        <h1>Обложки для видео</h1>
        <p>
          Сформируйте визуальную историю до клика. Листы адаптированы под разные
          платформы и форматы, включают зоны безопасности для текстов и ключевых объектов.
        </p>
      </section>
      <section className={styles.grid}>
        {videoCovers.map((cover) => (
          <article key={cover.title} className={styles.card}>
            <img src={cover.image} alt={cover.title} loading="lazy" />
            <div>
              <h2>{cover.title}</h2>
              <p>{cover.description}</p>
            </div>
          </article>
        ))}
      </section>
      <section className={styles.note}>
        <h2>Советы по выбору</h2>
        <ul>
          <li>Соотносите цвета с брендингом канала и превью предыдущих роликов.</li>
          <li>Проверяйте читаемость на мобильных устройствах — до 70% просмотров приходит с них.</li>
          <li>Используйте обложки как основу для A/B тестов заголовков и стилистики.</li>
        </ul>
      </section>
    </>
  );
};

export default VideoCoversPage;