import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./ServicesPage.module.css";

const services = [
  {
    title: "Комплексное оформление канала",
    description:
      "Команда дизайнеров-партнёров создаёт обложки, заставки, аватарки и баннеры в едином стиле. Подходит для запуска или ребрендинга канала.",
    image: "https://picsum.photos/800/600?random=1001"
  },
  {
    title: "Экспресс-набор обложек",
    description:
      "Подборка из 5–10 готовых обложек с быстрой персонализацией под ваши цвета и логотип. Отлично подходит для тестов и быстрых релизов.",
    image: "https://picsum.photos/800/600?random=1002"
  },
  {
    title: "Стрим-пакет под ключ",
    description:
      "Стартовые, переходные и финальные сцены, а также панели Twitch и Discord. Включены рекомендации по настройке в OBS/Streamlabs.",
    image: "https://picsum.photos/800/600?random=1003"
  }
];

const ServicesPage = () => {
  return (
    <>
      <MetaTags
        title="Услуги Digital Cover Art"
        description="Узнайте об услугах Digital Cover Art: комплексное оформление каналов, экспресс-набор обложек и стрим-пакеты."
      />
      <section className={styles.hero}>
        <h1>Услуги и готовые решения</h1>
        <p>
          Помимо каталога готовых работ мы предлагаем комплексные услуги. Команда кураторов и
          проверенных дизайнеров помогает запустить или обновить визуальную айдентику за короткие сроки.
        </p>
      </section>
      <section className={styles.grid}>
        {services.map((service) => (
          <article key={service.title} className={styles.card}>
            <img src={service.image} alt={service.title} loading="lazy" />
            <div className={styles.cardContent}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
            </div>
          </article>
        ))}
      </section>
      <section className={styles.cta}>
        <h2>Расскажите о своей задаче</h2>
        <p>
          Напишите нам через форму на странице контактов или отправьте запрос на{" "}
          <a href="mailto:partners@digitalcoverart.com">partners@digitalcoverart.com</a>.
          Мы подберём команду и предложим этапы реализации.
        </p>
      </section>
    </>
  );
};

export default ServicesPage;