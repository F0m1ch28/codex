import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./StreamBannersPage.module.css";

const banners = [
  {
    title: "Start Soon Overlay",
    description: "Анимированный экран ожидания с таймером и блоками соцсетей.",
    image: "https://picsum.photos/800/600?random=801"
  },
  {
    title: "Channel Header",
    description: "Фирменный баннер Twitch с расписанием и партнёрскими логотипами.",
    image: "https://picsum.photos/800/600?random=802"
  },
  {
    title: "Intermission Suite",
    description: "Комплект экранов перехода и чата с неоновыми линиями и эффектом glitch.",
    image: "https://picsum.photos/800/600?random=803"
  },
  {
    title: "Donation Panels",
    description: "Набор панелей и кнопок для донатов, спонсоров и ссылок.",
    image: "https://picsum.photos/800/600?random=804"
  },
  {
    title: "Offline Screen",
    description: "Стильный оффлайн-экран с напоминанием о следующем стриме.",
    image: "https://picsum.photos/800/600?random=805"
  },
  {
    title: "Event Package",
    description: "Полный комплект для сезонных мероприятий и специальных трансляций.",
    image: "https://picsum.photos/800/600?random=806"
  }
];

const StreamBannersPage = () => {
  return (
    <>
      <MetaTags
        title="Баннеры и оверлеи для стримов — Digital Cover Art"
        description="Категория баннеров, оверлеев и экранов для стримов: решения для Twitch, YouTube Live и Kick."
      />
      <section className={styles.hero}>
        <h1>Баннеры и оверлеи для стримов</h1>
        <p>
          Комплексное оформление канала повышает узнаваемость и удерживает аудиторию. Выбирайте
          готовые комплекты или комбинируйте элементы под свою задачу.
        </p>
      </section>
      <section className={styles.grid}>
        {banners.map((banner) => (
          <article key={banner.title} className={styles.card}>
            <img src={banner.image} alt={banner.title} loading="lazy" />
            <div className={styles.cardContent}>
              <h2>{banner.title}</h2>
              <p>{banner.description}</p>
            </div>
          </article>
        ))}
      </section>
      <section className={styles.features}>
        <div>
          <h3>Гибкая структура</h3>
          <p>Каждый комплект включает PSD/Figma-слои для изменения текстов, кнопок и анимации.</p>
        </div>
        <div>
          <h3>Технические стандарты</h3>
          <p>Размеры и вес оптимизированы под Twitch, YouTube Live и Kick с учётом ограничений.</p>
        </div>
        <div>
          <h3>Сценарные гайды</h3>
          <p>Рекомендации по использованию графики для стартовых, пауз и финальных сцен.</p>
        </div>
      </section>
    </>
  );
};

export default StreamBannersPage;