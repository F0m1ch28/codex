import React from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieConsentBanner from "./components/CookieConsentBanner";
import ScrollToTopButton from "./components/ScrollToTopButton";

import HomePage from "./pages/HomePage";
import CatalogPage from "./pages/CatalogPage";
import VideoCoversPage from "./pages/VideoCoversPage";
import AvatarsPage from "./pages/AvatarsPage";
import StreamBannersPage from "./pages/StreamBannersPage";
import AboutPage from "./pages/AboutPage";
import HowItWorksPage from "./pages/HowItWorksPage";
import ForDesignersPage from "./pages/ForDesignersPage";
import ContactsPage from "./pages/ContactsPage";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import TermsOfServicePage from "./pages/TermsOfServicePage";
import CookiePolicyPage from "./pages/CookiePolicyPage";
import ServicesPage from "./pages/ServicesPage";

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);
  return null;
};

function App() {
  return (
    <BrowserRouter>
      <ScrollToTopOnRoute />
      <div className="app">
        <Header />
        <main className="mainContent" role="main">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/catalog" element={<CatalogPage />} />
            <Route path="/catalog/video-covers" element={<VideoCoversPage />} />
            <Route path="/catalog/avatars" element={<AvatarsPage />} />
            <Route path="/catalog/stream-banners" element={<StreamBannersPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/how-it-works" element={<HowItWorksPage />} />
            <Route path="/for-designers" element={<ForDesignersPage />} />
            <Route path="/contacts" element={<ContactsPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsOfServicePage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
            <Route path="/services" element={<ServicesPage />} />
          </Routes>
        </main>
        <Footer />
        <CookieConsentBanner />
        <ScrollToTopButton />
      </div>
    </BrowserRouter>
  );
}

export default App;