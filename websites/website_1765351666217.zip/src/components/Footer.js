import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.grid}>
        <div>
          <div className={styles.logoBlock}>
            <span className={styles.logoMark}>Digital</span>
            <span className={styles.logoText}>Cover Art</span>
          </div>
          <p className={styles.description}>
            Международная платформа для авторских обложек, аватарок и баннеров.
            Мы объединяем дизайнеров и создателей контента со всего мира.
          </p>
        </div>
        <div>
          <h3 className={styles.heading}>Разделы</h3>
          <ul className={styles.list}>
            <li>
              <NavLink to="/catalog">Каталог</NavLink>
            </li>
            <li>
              <NavLink to="/catalog/video-covers">Обложки для видео</NavLink>
            </li>
            <li>
              <NavLink to="/catalog/avatars">Аватарки</NavLink>
            </li>
            <li>
              <NavLink to="/catalog/stream-banners">Баннеры для стримов</NavLink>
            </li>
            <li>
              <NavLink to="/services">Услуги</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.heading}>Компания</h3>
          <ul className={styles.list}>
            <li>
              <NavLink to="/about">О нас</NavLink>
            </li>
            <li>
              <NavLink to="/how-it-works">Как это работает</NavLink>
            </li>
            <li>
              <NavLink to="/for-designers">Для дизайнеров</NavLink>
            </li>
            <li>
              <NavLink to="/contacts">Контакты</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h3 className={styles.heading}>Контакты</h3>
          <p className={styles.contactLine}>
            Мы — цифровая платформа. Свяжитесь с нами онлайн.
          </p>
          <p className={styles.contactLine}>
            Поддержка:{" "}
            <a href="mailto:support@digitalcoverart.com">
              support@digitalcoverart.com
            </a>
          </p>
          <p className={styles.contactLine}>
            Партнёрство:{" "}
            <a href="mailto:partners@digitalcoverart.com">
              partners@digitalcoverart.com
            </a>
          </p>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Digital Cover Art. Все права защищены.</span>
        <div className={styles.policyLinks}>
          <NavLink to="/privacy">Политика конфиденциальности</NavLink>
          <NavLink to="/terms">Условия использования</NavLink>
          <NavLink to="/cookie-policy">Политика cookies</NavLink>
        </div>
      </div>
    </footer>
  );
};

export default Footer;