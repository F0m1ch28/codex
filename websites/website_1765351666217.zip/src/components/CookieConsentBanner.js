import React from "react";
import styles from "./CookieConsentBanner.module.css";

const CONSENT_KEY = "dca_cookie_consent";

const CookieConsentBanner = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(CONSENT_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(CONSENT_KEY, "accepted");
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.textBlock}>
        <h4>Мы используем cookies</h4>
        <p>
          Cookies помогают нам улучшать платформу и показывать релевантный контент.
          Продолжая работу с сайтом, вы принимаете использование cookies.
        </p>
      </div>
      <button className={styles.button} type="button" onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieConsentBanner;