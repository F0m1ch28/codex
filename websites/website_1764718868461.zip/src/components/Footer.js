import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-container">
      <div className="footer-column footer-brand">
        <h3>Nexen Partners</h3>
        <p>
          We help ambitious teams design human-centered strategies, transform operations, and ship digital products that
          move the bottom line.
        </p>
        <p className="footer-highlight">Headquartered in New York • Operating globally</p>
      </div>

      <div className="footer-column">
        <h4>Explore</h4>
        <ul>
          <li>
            <Link to="/about">Our Story</Link>
          </li>
          <li>
            <Link to="/services">What We Do</Link>
          </li>
          <li>
            <Link to="/contact">Book a Consultation</Link>
          </li>
          <li>
            <a href="#insights">Insights</a>
          </li>
        </ul>
      </div>

      <div className="footer-column">
        <h4>Connect</h4>
        <ul>
          <li>
            <a href="mailto:hello@nexenpartners.com">hello@nexenpartners.com</a>
          </li>
          <li>
            <a href="tel:+12125551234">+1 (212) 555-1234</a>
          </li>
          <li>299 Lafayette St, 8th Floor, NYC</li>
          <li>
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>{' '}
            ·{' '}
            <a href="https://twitter.com" target="_blank" rel="noreferrer">
              Twitter/X
            </a>
          </li>
        </ul>
      </div>

      <div className="footer-column">
        <h4>Stay in the loop</h4>
        <p>Monthly strategies, no spam. Join 12k+ leaders receiving our playbooks.</p>
        <form className="newsletter-form">
          <label className="sr-only" htmlFor="newsletter-email">
            Email address
          </label>
          <input type="email" id="newsletter-email" name="newsletter-email" placeholder="you@company.com" required />
          <button type="submit" className="btn btn-primary">
            Subscribe
          </button>
        </form>
      </div>
    </div>

    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} Nexen Partners. Crafted with precision and purpose.</p>
      <div className="footer-legal">
        <Link to="/privacy">Privacy Policy</Link>
        <span aria-hidden="true">•</span>
        <Link to="/terms">Terms of Service</Link>
      </div>
    </div>
  </footer>
);

export default Footer;