import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('nexen-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('nexen-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="region" aria-label="Cookie consent">
      <div className="cookie-content">
        <p>
          <strong>We use cookies</strong> to personalize content, analyze performance, and deliver a better consulting
          experience. You can review how we use data in our privacy policy.
        </p>
        <div className="cookie-actions">
          <button type="button" className="btn btn-primary" onClick={handleAccept}>
            Accept &amp; continue
          </button>
          <Link to="/privacy" className="btn btn-link">
            Learn more
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;