import React, { useState } from 'react';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter a business email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (!formData.company.trim()) {
      newErrors.company = 'Company name helps us tailor our response.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Tell us a little more about your initiative.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setStatus('loading');
      setTimeout(() => {
        setStatus('success');
        setFormData(initialFormState);
      }, 1200);
    }
  };

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  return (
    <div className="page contact-page">
      <section className="page-hero contact-hero">
        <div className="container">
          <span className="section-eyebrow">Work with us</span>
          <h1>Let’s design the next phase of growth together.</h1>
          <p>
            Share your goals and we’ll craft a tailored response within two business days. We work with leadership teams
            worldwide.
          </p>
        </div>
      </section>

      <section className="contact-details">
        <div className="container contact-grid">
          <div className="contact-form-wrapper" data-animate>
            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label htmlFor="name">Full name</label>
                <input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                  placeholder="Jordan Lee"
                />
                {errors.name && <span className="form-error">{errors.name}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="email">Business email</label>
                <input
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  placeholder="you@company.com"
                  type="email"
                />
                {errors.email && <span className="form-error">{errors.email}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.company)}
                  placeholder="Company / Organization"
                />
                {errors.company && <span className="form-error">{errors.company}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="message">Tell us about your initiative</label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  rows="5"
                  placeholder="Share objectives, timelines, or current challenges..."
                />
                {errors.message && <span className="form-error">{errors.message}</span>}
              </div>

              <button type="submit" className="btn btn-primary btn-large" disabled={status === 'loading'}>
                {status === 'loading' ? 'Sending...' : 'Submit inquiry'}
              </button>
              {status === 'success' && <p className="form-success">Thank you. We’ll be in touch shortly.</p>}
            </form>
          </div>

          <div className="contact-info" data-animate>
            <h2>Connect with our team</h2>
            <p>Email: <a href="mailto:hello@nexenpartners.com">hello@nexenpartners.com</a></p>
            <p>Phone: <a href="tel:+12125551234">+1 (212) 555-1234</a></p>
            <p>HQ: 299 Lafayette Street, 8th Floor, New York, NY 10012</p>
            <div className="contact-card">
              <h3>Working hours</h3>
              <p>Monday to Friday · 8:30 AM – 6:30 PM ET</p>
              <p>Global engagements across EMEA &amp; APAC time zones.</p>
            </div>
            <div className="contact-map">
              <img
                src="https://picsum.photos/1200/800?random=22"
                alt="Map illustration for Nexen Partners global offices"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;