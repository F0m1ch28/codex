import React from 'react';

const Terms = () => (
  <div className="page legal-page">
    <section className="page-hero legal-hero">
      <div className="container">
        <h1>Terms of Service</h1>
        <p>Updated March 2024</p>
      </div>
    </section>

    <section className="legal-content">
      <div className="container">
        <h2>1. Agreement to Terms</h2>
        <p>
          By accessing or using the Nexen Partners website or engaging with our services, you agree to be bound by these
          Terms of Service and our Privacy Policy. If you disagree with any part of these terms, you may not access our
          services.
        </p>

        <h2>2. Services</h2>
        <p>
          Nexen Partners provides consulting, advisory, and implementation services tailored to each client engagement. Any
          statements about future capabilities are not guarantees of performance.
        </p>

        <h2>3. Confidentiality</h2>
        <p>
          Both parties agree to maintain the confidentiality of proprietary information shared during an engagement unless
          otherwise agreed in writing. We implement industry-standard security measures to protect your data.
        </p>

        <h2>4. Intellectual Property</h2>
        <p>
          Unless otherwise agreed, all pre-existing intellectual property remains the property of the respective party.
          Work product created specifically for a client engagement becomes the property of the client once payment is
          complete, excluding Nexen Partners’ proprietary frameworks.
        </p>

        <h2>5. Limitation of Liability</h2>
        <p>
          To the maximum extent permitted by law, Nexen Partners is not liable for any indirect, incidental, or
          consequential damages arising from the use of our site or services.
        </p>

        <h2>6. Governing Law</h2>
        <p>
          These Terms are governed by the laws of the State of New York, without regard to conflict of law provisions.
        </p>

        <h2>7. Contact</h2>
        <p>
          For questions or concerns regarding these terms, please contact us at{' '}
          <a href="mailto:legal@nexenpartners.com">legal@nexenpartners.com</a>.
        </p>
      </div>
    </section>
  </div>
);

export default Terms;