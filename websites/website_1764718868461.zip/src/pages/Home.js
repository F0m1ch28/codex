import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

const statsData = [
  {
    label: 'Projects Delivered',
    value: 320,
    suffix: '+',
    description: 'High-impact launches delivered end-to-end.'
  },
  {
    label: 'Global Clients',
    value: 185,
    suffix: '+',
    description: 'Leaders across 14 industries trust our expertise.'
  },
  {
    label: 'Avg. Growth Rate',
    value: 98,
    suffix: '%',
    description: 'Average YoY revenue uplift for our client portfolio.'
  },
  {
    label: 'Awards Earned',
    value: 24,
    suffix: '',
    description: 'Recognized for innovation, experience, and delivery.'
  }
];

const servicesData = [
  {
    title: 'Strategy & Advisory',
    description:
      'Define the moves that matter with data-backed strategies, market intelligence, and transformation roadmaps tailored to your business goals.',
    features: ['Corporate & GTM Strategy', 'Operating Model Redesign', 'Leadership Alignment Workshops']
  },
  {
    title: 'Digital Product Innovation',
    description:
      'Launch customer-loved digital experiences. We prototype, validate, and build products that scale with your business.',
    features: ['Rapid Prototyping', 'Experience Design Sprints', 'Full-cycle Product Engineering']
  },
  {
    title: 'Revenue Acceleration',
    description:
      'Unlock new growth channels and modernize your marketing and sales motions through experimentation and automation.',
    features: ['Lifecycle & Growth Experiments', 'Revenue Operations', 'Performance Intelligence Dashboards']
  }
];

const processSteps = [
  {
    title: 'Discover & Align',
    description: 'Immersive discovery with cross-functional teams to align on ambition, constraints, and success metrics.'
  },
  {
    title: 'Design & Prototype',
    description: 'Translate strategy into tangible concepts, journeys, prototypes, and operating models primed for validation.'
  },
  {
    title: 'Deploy & Optimize',
    description: 'Intelligent execution with embedded analytics, experimentation, and change management support.'
  },
  {
    title: 'Scale & Transfer',
    description: 'Transition ownership with playbooks, training, and governance frameworks to sustain enduring results.'
  }
];

const testimonialsData = [
  {
    quote:
      'Nexen Partners redesigned our operating model and launched a new digital service line in 90 days. We exceeded our revenue targets within the first quarter.',
    name: 'Priya Desai',
    role: 'Chief Transformation Officer, Meridian Health',
    company: 'Meridian Health'
  },
  {
    quote:
      'They gave our leadership team clarity when we needed it most. Their ability to blend strategy and execution is unparalleled.',
    name: 'Caleb Martinez',
    role: 'SVP Strategy, Northstar Logistics',
    company: 'Northstar Logistics'
  },
  {
    quote:
      'From concept to launch, the Nexen team felt like an extension of our own. Our NPS jumped 34 points with the new platform.',
    name: 'Amelia Brooks',
    role: 'Head of Digital, Lumen Financial',
    company: 'Lumen Financial'
  }
];

const teamData = [
  {
    id: 'avery-carter',
    name: 'Avery Carter',
    role: 'Founder & CEO',
    image: 'https://picsum.photos/400/400?random=31',
    bio: 'Former McKinsey partner with 15+ years leading global transformations across financial services, retail, and healthcare.',
    expertise: ['Corporate Strategy', 'Operating Model Design', 'C-Suite Advisory']
  },
  {
    id: 'nora-lee',
    name: 'Nora Lee',
    role: 'Head of Product Innovation',
    image: 'https://picsum.photos/400/400?random=32',
    bio: 'Digital product leader who has shipped 40+ cross-platform experiences and specializes in design systems and agile delivery.',
    expertise: ['Product Strategy', 'Design Sprints', 'Growth Experimentation']
  },
  {
    id: 'mason-reid',
    name: 'Mason Reid',
    role: 'Principal, Revenue Acceleration',
    image: 'https://picsum.photos/400/400?random=33',
    bio: 'Built and scaled revenue programs for unicorn startups and Fortune 500 companies across North America and APAC.',
    expertise: ['RevOps Architecture', 'Go-to-Market', 'Analytics & Intelligence']
  }
];

const projectsData = [
  {
    id: 'project-aurora',
    title: 'Aurora Analytics Platform',
    category: 'Strategy',
    description:
      'Defined and executed the 24-month roadmap for a global analytics platform, aligning 12 markets under one vision.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    id: 'project-polaris',
    title: 'Polaris Connected Retail',
    category: 'Innovation',
    description:
      'Launched a seamless omnichannel retail experience with real-time inventory, booking, and concierge services.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    id: 'project-helix',
    title: 'Helix Operations OS',
    category: 'Transformation',
    description:
      'Reimagined the logistics control center using automation and AI, reducing delivery variance by 47%.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    id: 'project-lumen',
    title: 'Lumen Digital Bank',
    category: 'Innovation',
    description:
      'Co-created a mobile-first banking proposition with embedded financial wellness tools and bespoke advisory journeys.',
    image: 'https://picsum.photos/1200/800?random=44'
  }
];

const faqData = [
  {
    question: 'Which industries do you specialize in?',
    answer:
      'We partner with financial services, healthcare, retail, logistics, and B2B SaaS organizations. What unites our clients is an ambition to transform their operating models and launch market-leading experiences.'
  },
  {
    question: 'How do engagements typically kick off?',
    answer:
      'We begin with a rapid discovery sprint to map objectives, constraints, and key stakeholders. From there, we co-design a roadmap, establish governance, and build blended squads to deliver momentum from week one.'
  },
  {
    question: 'Do you help with implementation or just strategy?',
    answer:
      'Our teams stay the course from C-suite strategy through execution. We embed product, engineering, and change specialists to ensure the ideas we design are launched, adopted, and scaled with measurable outcomes.'
  },
  {
    question: 'How quickly can we start?',
    answer:
      'Kickoffs can begin within two weeks. We operate globally, offer flexible engagement models, and match the right talent to your mission-critical initiatives.'
  }
];

const blogPosts = [
  {
    id: 'blog-1',
    title: 'Designing Transformations Around Customer Truths',
    summary:
      'How leading organizations are building transformation programs that start with customer reality and end with measurable value.',
    image: 'https://picsum.photos/800/600?random=51',
    date: 'March 2024',
    category: 'Transformation'
  },
  {
    id: 'blog-2',
    title: '2024 GTM Playbook for Modern Revenue Teams',
    summary:
      'We breakdown the data-led motion behind teams who are winning in product-led growth, enterprise sales, and partner ecosystems.',
    image: 'https://picsum.photos/800/600?random=52',
    date: 'February 2024',
    category: 'Growth'
  },
  {
    id: 'blog-3',
    title: 'From Idea to Impact: Building Innovation Engines',
    summary:
      'A field guide to launching innovation programs that actually ship—without slowing down the core business.',
    image: 'https://picsum.photos/800/600?random=53',
    date: 'January 2024',
    category: 'Innovation'
  }
];

const Home = () => {
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [statsVisible, setStatsVisible] = useState(false);
  const statsRef = useRef(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeFaq, setActiveFaq] = useState(null);
  const [teamImagesLoaded, setTeamImagesLoaded] = useState({});
  const [projectImagesLoaded, setProjectImagesLoaded] = useState({});
  const [blogImagesLoaded, setBlogImagesLoaded] = useState({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStatsVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.45 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsVisible) {
      return;
    }

    const startValues = statsData.map(() => 0);
    const endValues = statsData.map((stat) => stat.value);
    const duration = 1600;
    let startTimestamp = null;

    const step = (timestamp) => {
      if (!startTimestamp) {
        startTimestamp = timestamp;
      }
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      const currentValues = endValues.map((endValue, index) =>
        progress === 1 ? endValue : Math.floor(startValues[index] + (endValue - startValues[index]) * progress)
      );
      setCounts(currentValues);

      if (progress < 1) {
        window.requestAnimationFrame(step);
      }
    };

    window.requestAnimationFrame(step);
  }, [statsVisible]);

  useEffect(() => {
    const animatedElements = document.querySelectorAll('[data-animate]');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.25 }
    );

    animatedElements.forEach((element) => observer.observe(element));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const categories = ['All', ...new Set(projectsData.map((project) => project.category))];
  const filteredProjects =
    selectedCategory === 'All'
      ? projectsData
      : projectsData.filter((project) => project.category === selectedCategory);

  const toggleFaq = (index) => {
    setActiveFaq((prev) => (prev === index ? null : index));
  };

  const previousTestimonial = () => {
    setTestimonialIndex((prev) => (prev === 0 ? testimonialsData.length - 1 : prev - 1));
  };

  const nextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length);
  };

  return (
    <div className="home-page">
      <section className="hero" data-animate>
        <div className="hero-media" aria-hidden="true" />
        <div className="hero-overlay" />
        <div className="container hero-content">
          <span className="hero-eyebrow">Boutique Strategy &amp; Digital Transformation Consultancy</span>
          <h1>
            Shape the <span>next era</span> of your business with clarity, momentum, and results that compound.
          </h1>
          <p>
            Nexen Partners helps visionary teams design transformative strategies, launch digital products, and unlock
            revenue engines. We blend C-suite advisory with hands-on implementation to deliver outcomes faster.
          </p>
          <div className="hero-actions">
            <Link to="/contact" className="btn btn-primary btn-large">
              Book a strategy session
            </Link>
            <Link to="/services" className="btn btn-outline btn-large">
              Explore our services
            </Link>
          </div>
          <div className="hero-meta">
            <div>
              <strong>Trusted by</strong>
              Global healthcare, finance, and logistics leaders
            </div>
            <div>
              <strong>Average ROI</strong>
              4.6x in the first twelve months
            </div>
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <article className="stat-card" key={stat.label} data-animate>
              <div className="stat-value">
                {counts[index]}
                {stat.suffix}
              </div>
              <h3>{stat.label}</h3>
              <p>{stat.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="services" id="services">
        <div className="container">
          <div className="section-header" data-animate>
            <span className="section-eyebrow">Core Services</span>
            <h2>We partner from strategy through scale.</h2>
            <p>
              Our interdisciplinary teams align executives, product, and go-to-market leaders. Together we design strategy,
              ship experiences, and build the capability to sustain growth.
            </p>
          </div>
          <div className="services-grid">
            {servicesData.map((service) => (
              <article className="service-card" key={service.title} data-animate>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <ul>
                  {service.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
                <Link to="/services" className="btn btn-link">
                  Discover the approach →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process">
        <div className="container">
          <div className="process-header" data-animate>
            <span className="section-eyebrow">Proven Methodology</span>
            <h2>Momentum built in sprints. Impact measured in quarters.</h2>
          </div>
          <div className="process-grid">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title} data-animate>
                <div className="step-number">0{index + 1}</div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials" id="testimonials">
        <div className="container testimonial-wrapper">
          <div className="testimonial-media" aria-hidden="true" />
          <div className="testimonial-content" data-animate>
            <span className="section-eyebrow">Client Stories</span>
            <p className="testimonial-quote">“{testimonialsData[testimonialIndex].quote}”</p>
            <div className="testimonial-author">
              <p>{testimonialsData[testimonialIndex].name}</p>
              <span>{testimonialsData[testimonialIndex].role}</span>
            </div>
            <div className="testimonial-controls">
              <button type="button" onClick={previousTestimonial} aria-label="Previous testimonial">
                ←
              </button>
              <button type="button" onClick={nextTestimonial} aria-label="Next testimonial">
                →
              </button>
            </div>
            <div className="testimonial-progress" role="tablist" aria-label="Testimonial carousel">
              {testimonialsData.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`testimonial-dot ${index === testimonialIndex ? 'is-active' : ''}`}
                  onClick={() => setTestimonialIndex(index)}
                  aria-label={`Show testimonial from ${testimonial.name}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team" id="team">
        <div className="container">
          <div className="section-header" data-animate>
            <span className="section-eyebrow">Leadership Team</span>
            <h2>The strategists, builders, and operators in your corner.</h2>
            <p>
              Our teams integrate executive advisors with product, design, engineering, and revenue specialists to deliver
              outcomes end-to-end.
            </p>
          </div>
          <div className="team-grid">
            {teamData.map((member) => (
              <article className="team-card" key={member.id} data-animate>
                <div className="team-image-wrapper">
                  <img
                    src={member.image}
                    alt={`${member.name} - ${member.role}`}
                    className={`team-image ${teamImagesLoaded[member.id] ? 'is-loaded' : ''}`}
                    onLoad={() => setTeamImagesLoaded((prev) => ({ ...prev, [member.id]: true }))}
                    loading="lazy"
                  />
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                  <div className="team-tags">
                    {member.expertise.map((item) => (
                      <span key={item}>{item}</span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container">
          <div className="section-header" data-animate>
            <span className="section-eyebrow">Selected Projects</span>
            <h2>Transformation work rooted in measurable outcomes.</h2>
            <p>Filter by the type of challenge to explore the work we launch with ambitious teams.</p>
          </div>

          <div className="project-filters" role="tablist" aria-label="Project categories">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`filter-btn ${selectedCategory === category ? 'is-active' : ''}`}
                onClick={() => setSelectedCategory(category)}
                aria-pressed={selectedCategory === category}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="project-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.id} data-animate>
                <div className="project-image-wrapper">
                  <img
                    src={project.image}
                    alt={`${project.title} transformation project`}
                    className={`project-image ${projectImagesLoaded[project.id] ? 'is-loaded' : ''}`}
                    onLoad={() => setProjectImagesLoaded((prev) => ({ ...prev, [project.id]: true }))}
                    loading="lazy"
                  />
                </div>
                <div className="project-info">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/contact" className="btn btn-link">
                    Talk about similar work →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container faq-container">
          <div className="faq-intro" data-animate>
            <span className="section-eyebrow">FAQ</span>
            <h2>Answers to common partner questions.</h2>
            <p>Have something more specific? Reach out and we’ll tailor a response to your context.</p>
            <Link to="/contact" className="btn btn-outline">
              Ask a question
            </Link>
          </div>
          <div className="faq-items">
            {faqData.map((item, index) => (
              <div
                key={item.question}
                className={`faq-item ${activeFaq === index ? 'is-open' : ''}`}
                data-animate
              >
                <button
                  type="button"
                  className="faq-question"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={activeFaq === index}
                >
                  <span>{item.question}</span>
                  <span className="faq-toggle" aria-hidden="true">
                    {activeFaq === index ? '−' : '+'}
                  </span>
                </button>
                <div className="faq-answer">
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog" id="insights">
        <div className="container">
          <div className="section-header" data-animate>
            <span className="section-eyebrow">Insights</span>
            <h2>Latest ideas from the Nexen Partners team.</h2>
            <p>We publish playbooks, frameworks, and interviews to help leaders build modern organizations.</p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.id} data-animate>
                <div className="blog-image-wrapper">
                  <img
                    src={post.image}
                    alt={`${post.title} - Nexen Partners insight`}
                    className={`blog-image ${blogImagesLoaded[post.id] ? 'is-loaded' : ''}`}
                    onLoad={() => setBlogImagesLoaded((prev) => ({ ...prev, [post.id]: true }))}
                    loading="lazy"
                  />
                </div>
                <div className="blog-info">
                  <span className="blog-meta">
                    {post.category} · {post.date}
                  </span>
                  <h3>{post.title}</h3>
                  <p>{post.summary}</p>
                  <Link to="/contact" className="btn btn-link">
                    Discuss this topic →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-card" data-animate>
          <div className="cta-content">
            <span className="section-eyebrow">Let’s build what’s next</span>
            <h2>Ready to accelerate your roadmap?</h2>
            <p>
              Bring us your boldest challenges. We’ll co-design a path to measurable growth and activate the teams to make
              it real.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn-primary btn-large">
              Book a consultation
            </Link>
            <Link to="/about" className="btn btn-outline btn-large">
              Meet the team
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;