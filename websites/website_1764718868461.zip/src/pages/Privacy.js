import React from 'react';

const Privacy = () => (
  <div className="page legal-page">
    <section className="page-hero legal-hero">
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>Updated March 2024</p>
      </div>
    </section>

    <section className="legal-content">
      <div className="container">
        <h2>1. Overview</h2>
        <p>
          Nexen Partners is committed to protecting your privacy. This policy outlines how we collect, use, and safeguard
          information you share with us online or through our services.
        </p>

        <h2>2. Information We Collect</h2>
        <p>
          We collect personal and business information that you voluntarily provide, such as when you request a consultation
          or subscribe to updates. This may include name, email, company, and details about your project or organization.
        </p>

        <h2>3. How We Use Information</h2>
        <p>
          We use collected information to respond to inquiries, provide consulting services, improve our offerings, and send
          relevant updates with your consent. We do not sell or rent your personal data.
        </p>

        <h2>4. Cookies &amp; Analytics</h2>
        <p>
          Our site uses cookies and analytics tools to understand engagement and improve usability. You can control cookies
          through your browser settings. We honor Do Not Track signals where technologically feasible.
        </p>

        <h2>5. Data Security</h2>
        <p>
          We implement administrative, technical, and physical safeguards designed to protect your information. While we
          strive to keep your data secure, no system is completely immune to risk.
        </p>

        <h2>6. Your Rights</h2>
        <p>
          Depending on your location, you may have rights to access, correct, or delete your personal data. Contact us at
          <a href="mailto:privacy@nexenpartners.com"> privacy@nexenpartners.com</a> to submit a request.
        </p>

        <h2>7. Updates</h2>
        <p>
          We may update this policy periodically. We encourage you to review this page when engaging with our services to
          stay informed about our practices.
        </p>
      </div>
    </section>
  </div>
);

export default Privacy;