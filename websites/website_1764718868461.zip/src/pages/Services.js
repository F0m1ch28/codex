import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const serviceOfferings = [
  {
    id: 'strategy',
    title: 'Strategy & Transformation',
    summary: 'Board-level advisory to define where to play, how to win, and how to organize working systems around the vision.',
    description:
      'We synthesize research, customer insights, and financial modeling to architect bold yet actionable strategies. Our squads design operating models, governance frameworks, and change plans that bring leadership teams into alignment.',
    outcomes: ['North star vision & narrative', 'Transformation roadmap', 'Executive alignment and KPIs']
  },
  {
    id: 'product',
    title: 'Digital Product & Experience',
    summary: 'Design and ship digital products that customers love and the business can scale with confidence.',
    description:
      'We run design sprints, experiment with prototypes, and build production-ready products. By combining product strategy, UX, and engineering, we accelerate the path from idea to market adoption.',
    outcomes: ['Validated product concepts', 'Experience and service blueprints', 'Full-stack implementation']
  },
  {
    id: 'revenue',
    title: 'Revenue Acceleration',
    summary: 'Modernize go-to-market motions and launch revenue programs that compound through automation and intelligence.',
    description:
      'We map journeys across marketing, sales, and success, then design experiments and GTM plays to lift conversion. Our team builds RevOps foundations, implements tooling, and trains your teams to sustain growth.',
    outcomes: ['GTM strategy & playbooks', 'Attribution & analytics dashboards', 'Revenue operations enablement']
  }
];

const capabilityMatrix = [
  { pillar: 'Insight & Strategy', capabilities: ['Market intelligence', 'Customer research', 'Financial modeling'] },
  { pillar: 'Experience & Product', capabilities: ['Design systems', 'Service design', 'Full-stack development'] },
  { pillar: 'Growth & Revenue', capabilities: ['Revenue intelligence', 'Lifecycle orchestration', 'Experimentation'] },
  { pillar: 'Enablement', capabilities: ['Change management', 'Capability building', 'Digital upskilling programs'] }
];

const Services = () => {
  const [activeService, setActiveService] = useState(serviceOfferings[0]);

  return (
    <div className="page services-page">
      <section className="page-hero services-hero">
        <div className="container">
          <span className="section-eyebrow">What We Do</span>
          <h1>Strategy, product, and growth squads aligned to your mission-critical outcomes.</h1>
          <p>
            We operate as an extension of your team—embedding strategy, product, and revenue specialists who move from
            insight to implementation without losing momentum.
          </p>
        </div>
      </section>

      <section className="service-offerings">
        <div className="container">
          <div className="offerings-tabs" role="tablist" aria-label="Service offerings">
            {serviceOfferings.map((service) => (
              <button
                key={service.id}
                type="button"
                className={`offering-tab ${activeService.id === service.id ? 'is-active' : ''}`}
                onClick={() => setActiveService(service)}
                aria-selected={activeService.id === service.id}
              >
                <div>
                  <h3>{service.title}</h3>
                  <p>{service.summary}</p>
                </div>
              </button>
            ))}
          </div>

          <div className="offering-details" data-animate>
            <h2>{activeService.title}</h2>
            <p>{activeService.description}</p>
            <div className="offering-outcomes">
              <h4>What you walk away with:</h4>
              <ul>
                {activeService.outcomes.map((outcome) => (
                  <li key={outcome}>{outcome}</li>
                ))}
              </ul>
            </div>
            <Link to="/contact" className="btn btn-primary">
              Plan an engagement
            </Link>
          </div>
        </div>
      </section>

      <section className="capability-matrix">
        <div className="container">
          <div className="section-header" data-animate>
            <span className="section-eyebrow">Integrated capabilities</span>
            <h2>Every engagement blends strategy, delivery, and enablement.</h2>
            <p>Our multi-disciplinary squads bring the breadth of expertise required to move complex initiatives forward.</p>
          </div>
          <div className="matrix-grid">
            {capabilityMatrix.map((item) => (
              <article className="matrix-card" key={item.pillar} data-animate>
                <h3>{item.pillar}</h3>
                <ul>
                  {item.capabilities.map((capability) => (
                    <li key={capability}>{capability}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="service-cta">
        <div className="container cta-card" data-animate>
          <div>
            <h2>Need a bespoke squad for your next mission?</h2>
            <p>We’ll assemble a blended team across strategy, product, and growth to unlock your next milestone.</p>
          </div>
          <Link to="/contact" className="btn btn-outline btn-large">
            Let’s discuss your goals
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;