import React from 'react';
import { Link } from 'react-router-dom';

const About = () => (
  <div className="page about-page">
    <section className="page-hero about-hero">
      <div className="container">
        <span className="section-eyebrow">Our Story</span>
        <h1>Guiding organizations through moments that define their future.</h1>
        <p>
          Nexen Partners was founded to bridge the gap between boardroom vision and the realities of building digital
          experiences that customers love. We believe the next era of category leaders will be powered by strategy,
          creativity, and technology working as one.
        </p>
      </div>
    </section>

    <section className="about-mission">
      <div className="container">
        <div className="mission-content" data-animate>
          <h2>Purpose-built to help ambitious teams unlock measurable outcomes.</h2>
          <p>
            We partner with leadership teams when the stakes are high: moments of transformation, new product launches,
            and critical growth inflection points. Our interdisciplinary squads combine top-tier strategy, human-centered
            design, and engineering excellence with revenue and change specialists.
          </p>
          <p>
            We’ve been in the trenches of complex transformations and rapid scaling journeys. Our approach is pragmatic,
            collaborative, and relentlessly focused on results you can share with the board.
          </p>
        </div>
        <div className="mission-image-wrapper" data-animate>
          <img
            src="https://picsum.photos/1000/800?random=12"
            alt="Nexen Partners strategy workshop session"
            loading="lazy"
          />
        </div>
      </div>
    </section>

    <section className="about-values">
      <div className="container">
        <h2 data-animate>Our values guide how we operate.</h2>
        <div className="values-grid">
          <article className="value-card" data-animate>
            <h3>Design for Impact</h3>
            <p>We diagnose the system, design around real human needs, and prioritize decisions that create compounding value.</p>
          </article>
          <article className="value-card" data-animate>
            <h3>Build Together</h3>
            <p>We embed with our clients, co-creating outcomes and transferring capability so teams can sustain momentum long after launch.</p>
          </article>
          <article className="value-card" data-animate>
            <h3>Move with Clarity</h3>
            <p>We cut through complexity using data-informed narratives, weekly rituals, and transparent communication.</p>
          </article>
          <article className="value-card" data-animate>
            <h3>Own the Result</h3>
            <p>We stay accountable from the boardroom to the build room, ensuring strategies translate into measurable outcomes.</p>
          </article>
        </div>
      </div>
    </section>

    <section className="about-timeline">
      <div className="container">
        <h2 data-animate>Milestones along our journey.</h2>
        <div className="timeline">
          <div className="timeline-item" data-animate>
            <span className="timeline-year">2016</span>
            <div>
              <h3>Nexen Partners is founded</h3>
              <p>We began with a mission to reimagine consulting for the modern era by embedding multi-disciplinary teams in client organizations.</p>
            </div>
          </div>
          <div className="timeline-item" data-animate>
            <span className="timeline-year">2018</span>
            <div>
              <h3>Global expansion</h3>
              <p>Opened London and Singapore hubs to support growth-stage clients scaling across EMEA and APAC regions.</p>
            </div>
          </div>
          <div className="timeline-item" data-animate>
            <span className="timeline-year">2020</span>
            <div>
              <h3>Innovation Lab launch</h3>
              <p>Built our in-house experimentation lab to prototype new products, AI accelerators, and digital-first experiences.</p>
            </div>
          </div>
          <div className="timeline-item" data-animate>
            <span className="timeline-year">2023</span>
            <div>
              <h3>4.6x average ROI</h3>
              <p>Our clients achieved 4.6x average ROI in the first year of engagement, driven by unified strategy and execution squads.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section className="about-cta">
      <div className="container cta-card" data-animate>
        <div>
          <h2>We’re ready to partner when the stakes are high.</h2>
          <p>Let’s discuss your next strategic move and design a roadmap to make it real.</p>
        </div>
        <Link to="/contact" className="btn btn-primary btn-large">
          Start the conversation
        </Link>
      </div>
    </section>
  </div>
);

export default About;