document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    const navLinks = document.querySelectorAll('.nav-links a');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            primaryNav.classList.toggle('active');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                primaryNav.classList.remove('active');
            });
        });
    }

    function setCookie(name, value, days) {
        const expires = new Date(Date.now() + days * 86400000).toUTCString();
        document.cookie = `${name}=${value}; expires=${expires}; path=/; SameSite=Lax`;
    }

    function getCookie(name) {
        return document.cookie.split('; ').find(row => row.startsWith(name + '='))?.split('=')[1];
    }

    if (cookieBanner && !getCookie('stomacoexaConsent')) {
        cookieBanner.classList.add('active');
    }

    if (acceptBtn) {
        acceptBtn.addEventListener('click', function () {
            setCookie('stomacoexaConsent', 'accepted', 180);
            cookieBanner.classList.remove('active');
            setTimeout(() => {
                window.location.href = 'cookies.html';
            }, 300);
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', function () {
            cookieBanner.classList.remove('active');
            setTimeout(() => {
                window.location.href = 'cookies.html';
            }, 300);
        });
    }
});