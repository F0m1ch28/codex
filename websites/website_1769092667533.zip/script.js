document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.mobile-nav-toggle');
  const primaryNav = document.getElementById('primary-navigation');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = primaryNav.getAttribute('data-open') === 'true';
      primaryNav.setAttribute('data-open', String(!isOpen));
      navToggle.setAttribute('aria-expanded', String(!isOpen));
      document.body.classList.toggle('nav-menu-open', !isOpen);
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        primaryNav.setAttribute('data-open', 'false');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('nav-menu-open');
      });
    });
  }

  document.querySelectorAll('[data-year]').forEach(el => {
    el.textContent = new Date().getFullYear();
  });

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedChoice = localStorage.getItem('crbtCookieChoice');
    if (storedChoice) {
      cookieBanner.classList.add('hidden');
      cookieBanner.setAttribute('data-visible', 'false');
    } else {
      cookieBanner.classList.remove('hidden');
      cookieBanner.setAttribute('data-visible', 'true');
    }

    cookieBanner.querySelectorAll('[data-action]').forEach(button => {
      button.addEventListener('click', () => {
        const action = button.getAttribute('data-action');
        localStorage.setItem('crbtCookieChoice', action);
        cookieBanner.setAttribute('data-visible', 'false');
        setTimeout(() => {
          cookieBanner.classList.add('hidden');
        }, 320);
      });
    });
  }

  const forms = document.querySelectorAll('form[data-form="redirect"]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const action = form.getAttribute('action') || 'thank-you.html';
      showToast('Message received. Redirecting…');
      setTimeout(() => {
        window.location.href = action;
      }, 1400);
    });
  });

  function showToast(message) {
    let toast = document.querySelector('.toast-notice');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast-notice';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'polite');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('visible');
    setTimeout(() => {
      toast.classList.remove('visible');
    }, 2400);
  }
});