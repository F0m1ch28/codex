document.addEventListener("DOMContentLoaded", () => {
    const menuToggle = document.querySelector(".menu-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (menuToggle && navLinks) {
        menuToggle.addEventListener("click", () => {
            const isExpanded = menuToggle.getAttribute("aria-expanded") === "true";
            menuToggle.setAttribute("aria-expanded", String(!isExpanded));
            navLinks.classList.toggle("open");
        });
    }

    const currentPath = window.location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-links a").forEach(link => {
        const linkPath = link.getAttribute("href");
        if (linkPath === currentPath || (currentPath === "" && linkPath === "index.html")) {
            link.classList.add("active");
        }
    });

    const cookieBanner = document.getElementById("cookieBanner");
    const acceptButton = document.querySelector('[data-cookie-action="accept"]');
    const declineButton = document.querySelector('[data-cookie-action="decline"]');
    const cookiePreference = localStorage.getItem("eosinoscbsCookiePreference");

    if (cookiePreference && cookieBanner) {
        cookieBanner.classList.add("hidden");
    }

    const handleCookieAction = (action) => {
        localStorage.setItem("eosinoscbsCookiePreference", action);
        if (cookieBanner) {
            cookieBanner.classList.add("hidden");
        }
        const target = action === "accepted" ? "cookies.html#accept" : "cookies.html#decline";
        setTimeout(() => {
            window.location.href = target;
        }, 150);
    };

    if (acceptButton) {
        acceptButton.addEventListener("click", () => handleCookieAction("accepted"));
    }
    if (declineButton) {
        declineButton.addEventListener("click", () => handleCookieAction("declined"));
    }

    const observer = new IntersectionObserver(
        entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                    observer.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.15 }
    );

    document.querySelectorAll(".animate-on-scroll").forEach(element => observer.observe(element));

    const yearElement = document.getElementById("current-year");
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
});