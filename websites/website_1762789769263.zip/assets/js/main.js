document.addEventListener('DOMContentLoaded', () => {
  const nav = document.querySelector('[data-nav]');
  const toggle = document.querySelector('[data-menu-toggle]');
  const scrollTopBtn = document.querySelector('.scroll-top');
  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieAcceptBtn = document.querySelector('[data-cookie-accept]');
  const yearEl = document.getElementById('year');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
    });

    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('open');
      });
    });
  }

  document.querySelectorAll('a[data-scroll-top]').forEach(link => {
    link.addEventListener('click', event => {
      const targetId = link.getAttribute('href');
      if (targetId && targetId.startsWith('#')) {
        event.preventDefault();
        const target = document.querySelector(targetId);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth' });
        } else {
          window.location.href = link.href;
        }
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });

  window.addEventListener('scroll', () => {
    if (window.scrollY > 200) {
      scrollTopBtn.classList.add('show');
    } else {
      scrollTopBtn.classList.remove('show');
    }
  });

  scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  const cookieKey = 'datanorth_cookie_consent';
  if (!localStorage.getItem(cookieKey)) {
    cookieBanner.classList.add('active');
  }

  cookieAcceptBtn.addEventListener('click', () => {
    localStorage.setItem(cookieKey, 'accepted');
    cookieBanner.classList.remove('active');
  });
});