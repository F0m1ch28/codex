(function redirectAliases() {
  var path = window.location.pathname.replace(/\/+$/, "");
  if (path === "/history" || path === "/history/index.html") {
    window.location.replace("industrial-context.html");
  }
  if (path === "/infrastructure" || path === "/infrastructure/index.html") {
    window.location.replace("architecture.html");
  }
  if (path === "/systems" || path === "/systems/index.html") {
    window.location.replace("coordination.html");
  }
  if (path === "/resilience" || path === "/resilience/index.html") {
    window.location.replace("reliability.html");
  }
})();

document.addEventListener("DOMContentLoaded", function () {
  var navToggle = document.querySelector(".nav-toggle");
  var primaryMenu = document.getElementById("primary-menu");

  if (navToggle && primaryMenu) {
    navToggle.addEventListener("click", function () {
      var expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      primaryMenu.classList.toggle("active");
    });
  }

  var cookieBanner = document.getElementById("cookieBanner");
  var acceptButton = document.getElementById("cookieAccept");
  var declineButton = document.getElementById("cookieDecline");

  var storedConsent = localStorage.getItem("nct_cookie_consent");
  if (!storedConsent && cookieBanner) {
    cookieBanner.classList.add("active");
  }

  function setConsent(value) {
    localStorage.setItem("nct_cookie_consent", value);
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  if (acceptButton) {
    acceptButton.addEventListener("click", function () {
      setConsent("accepted");
    });
  }

  if (declineButton) {
    declineButton.addEventListener("click", function () {
      setConsent("declined");
    });
  }
});