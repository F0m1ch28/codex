const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const CONSENT_STORAGE_KEY = "cookie_consent";

const I18N = {
  fr: {
    meta: {
      index: {
        title: "Orientation spatiale et signalétique numérique | danswholesaleplants",
        description: "Analyse approfondie de l’orientation spatiale, de la signalétique numérique et de la navigation intérieure pour les bâtiments publics et les environnements urbains complexes."
      },
      services: {
        title: "Domaines d’intervention et recherches appliquées | danswholesaleplants",
        description: "Approche pluridisciplinaire pour diagnostiquer les flux piétons, concevoir des systèmes de signalétique numérique et structurer la navigation dans les environnements bâtis."
      },
      about: {
        title: "Méthodologie et gouvernance scientifique | danswholesaleplants",
        description: "Présentation du laboratoire, de ses valeurs et de ses protocoles de recherche dédiés à la lisibilité et à l’accessibilité des espaces publics."
      },
      blog: {
        title: "Journal d’observation des flux et cartographies | danswholesaleplants",
        description: "Articles techniques sur la cartographie des espaces, l’UX spatiale, la mobilité piétonne et l’architecture de l’information."
      },
      contact: {
        title: "Coordonnées et demandes d’étude | danswholesaleplants",
        description: "Entrer en relation avec l’équipe pour partager des problématiques liées aux parcours utilisateurs dans les bâtiments et infrastructures."
      },
      faq: {
        title: "Questions récurrentes sur l’orientation spatiale | danswholesaleplants",
        description: "Réponses détaillées sur les méthodes d’analyse des flux, la signalétique numérique et la cartographie des espaces."
      },
      terms: {
        title: "Conditions d’utilisation | danswholesaleplants",
        description: "Conditions d’utilisation régissant l’accès et la consultation des contenus publiés par danswholesaleplants."
      },
      privacy: {
        title: "Politique de confidentialité | danswholesaleplants",
        description: "Informations sur la collecte, l’utilisation et la protection des données personnelles par danswholesaleplants."
      },
      cookies: {
        title: "Politique relative aux cookies | danswholesaleplants",
        description: "Description des cookies techniques, préférentiels, analytiques et informatifs utilisés sur le site."
      },
      refund: {
        title: "Politique de gestion des corrections | danswholesaleplants",
        description: "Modalités de demande de correction ou d’ajustement concernant les livrables informationnels fournis."
      },
      disclaimer: {
        title: "Avis de non-responsabilité | danswholesaleplants",
        description: "Limitations de responsabilité concernant l’usage des informations et recommandations publiées."
      },
      thankyou: {
        title: "Merci pour votre message | danswholesaleplants",
        description: "Confirmation de réception de votre demande par l’équipe danswholesaleplants."
      },
      post1: {
        title: "Modéliser les déplacements piétons dans les complexes culturels | danswholesaleplants",
        description: "Approche analytique pour décrire, mesurer et optimiser les flux de visiteurs dans les ensembles culturels à forte densité spatiale."
      },
      post2: {
        title: "Signalétique numérique pour les hubs intermodaux | danswholesaleplants",
        description: "Méthodes pour articuler la signalétique numérique et analogique dans les pôles de mobilité intermodale."
      },
      post3: {
        title: "Cartographie hybride des campus étendus | danswholesaleplants",
        description: "Principes cartographiques pour relier parcours intérieurs et extérieurs sur les campus universitaires et hospitaliers."
      },
      post4: {
        title: "Observer l’UX spatiale par protocoles qualitatifs | danswholesaleplants",
        description: "Description d’outils qualitatifs pour apprécier l’expérience de navigation au sein des bâtiments publics."
      },
      post5: {
        title: "Accessibilité des parcours dans les sites patrimoniaux | danswholesaleplants",
        description: "Analyse de la signalétique et des guides visuels pour les parcours accessibles au sein des sites patrimoniaux."
      }
    },
    global: {
      companyName: "danswholesaleplants",
      nav: {
        home: "Accueil",
        services: "Approches",
        about: "Profil",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      navToggle: "Ouvrir la navigation",
      language: {
        fr: "FR",
        en: "EN"
      },
      buttons: {
        learnMore: "Découvrir",
        readMore: "Lire l’article",
        viewAll: "Voir tout",
        contact: "Entrer en contact"
      },
      footer: {
        title: "Correspondance",
        description: "danswholesaleplants observe la lisibilité des environnements bâtis et conçoit des cadres méthodologiques pour faciliter les parcours usagers.",
        addressLabel: "Adresse",
        addressValue: "Rue des Chartreux 62, 1000 Bruxelles, Belgique",
        phoneLabel: "Téléphone",
        phoneValue: "+32 2 320 54 18",
        emailLabel: "Courriel",
        emailValue: "info@danswholesaleplants.com",
        copy: "© danswholesaleplants —",
        links: {
          terms: "Conditions d’utilisation",
          privacy: "Politique de confidentialité",
          cookies: "Politique cookies",
          refund: "Politique de correction",
          disclaimer: "Avis de non-responsabilité"
        }
      },
      toasts: {
        success: "Message transmis. Nous revenons vers vous rapidement.",
        error: "Merci de compléter les champs obligatoires."
      },
      validation: {
        required: "Ce champ est requis."
      }
    },
    cookies: {
      banner: {
        title: "Gestion des cookies",
        message: "Nous utilisons des cookies pour assurer le fonctionnement du site et analyser les parcours de navigation afin d’améliorer l’orientation spatiale.",
        link: "Consulter la politique cookies",
        manage: "Gérer les préférences"
      },
      buttons: {
        accept: "Tout accepter",
        decline: "Tout refuser",
        save: "Enregistrer"
      },
      toggles: {
        necessary: "Cookies nécessaires",
        preferences: "Cookies de préférences",
        analytics: "Cookies analytiques",
        marketing: "Cookies informatifs"
      },
      descriptions: {
        necessary: "Garantissent le fonctionnement du site, notamment la mémorisation de la langue et des décisions de consentement.",
        preferences: "Permettent d’enregistrer des paramètres de navigation spécifiques à votre session (par exemple, la sélection d’une page).",
        analytics: "Collectent des données agrégées sur la consultation des contenus pour ajuster la structure de navigation.",
        marketing: "Diffusent des informations éditoriales ciblées sur nos publications externes et événements thématiques."
      },
      aria: {
        necessary: "Commutateur cookies nécessaires, verrouillé",
        preferences: "Commutateur cookies de préférences",
        analytics: "Commutateur cookies analytiques",
        marketing: "Commutateur cookies informatifs"
      }
    },
    home: {
      hero: {
        title: "Orientation spatiale pour des lieux publics lisibles",
        subtitle: "Nous analysons les flux piétons, la signalétique numérique et la cartographie des espaces pour renforcer la compréhension des environnements bâtis complexes.",
        ctaPrimary: "Explorer nos approches",
        ctaSecondary: "Dialoguer avec l’équipe",
        stat1: {
          value: "32",
          label: "sites observés en Europe"
        },
        stat2: {
          value: "18",
          label: "protocoles d’évaluation des flux"
        },
        stat3: {
          value: "11",
          label: "structures publiques accompagnées en 2023"
        },
        alt: "Plan interactif dans un hall de bâtiment public"
      },
      intro: {
        title: "Des parcours lisibles fondés sur les données de terrain",
        body: "Chaque étude croise analyse qualitative, modélisation des flux et observation sensorielle pour révéler la logique de circulation et l’accessibilité d’un lieu. Les diagnostics produits servent à orienter les équipes de conception, d’exploitation ainsi que les responsables d’infrastructures publiques."
      },
      grid: {
        item1: {
          title: "Diagnostics de circulation",
          body: "Cartographier les trajectoires dominantes, repérer les zones de friction et objectiver les attentes de signalétique pour clarifier l’expérience usager.",
          alt: "Signalétique directionnelle dans un hall intérieur"
        },
        item2: {
          title: "Systèmes numériques situés",
          body: "Concevoir des interfaces contextuelles qui articulent kiosques, écrans et supports mobiles dans une approche cohérente de guidage visuel.",
          alt: "Écran numérique d’orientation dans une gare"
        },
        item3: {
          title: "Guidage urbain multimodal",
          body: "Relier les parcours piétons aux réseaux de mobilité douce et aux franchissements entre bâtiments pour fluidifier les transitions.",
          alt: "Flux de piétons dans un espace public urbain"
        }
      },
      methods: {
        title: "De la collecte à la synthèse cartographique",
        body: "Nos études se structurent autour d’observations in situ, de relevés photographiques et de modélisations graphiques pour comparer perception, usage et lecture des lieux.",
        highlightTitle: "Quatre volets complémentaires",
        point1: "Immersion sur site pour documenter les repères sensoriels et sonores.",
        point2: "Suivi des flux à l’aide de parcours commentés et d’outils de mesure discret.",
        point3: "Traduction cartographique avec indicateurs de densité et d’accessibilité.",
        point4: "Restitution pédagogique axée sur la prise de décision stratégique."
      },
      recommendations: {
        title: "Recommandations valorisées par les équipes",
        body: "Les synthèses produites servent de base aux architectes, urbanistes et services techniques pour ajuster les dispositifs d’accueil et d’information.",
        item1: {
          title: "Lecture hiérarchisée des portes et sas",
          body: "Réordonner la signalétique dans les halls aériens a permis de clarifier immédiatement l’accès aux services prioritaires et de réduire de 23 % les détours documentés.",
          meta: "Extrait du rapport d’audit d’une maison communale bruxelloise"
        },
        item2: {
          title: "Cartographie interactive modulaire",
          body: "Un socle cartographique segmenté par profils usagers a amélioré la compréhension des liaisons verticales et limité les demandes d’assistance en période d’affluence.",
          meta: "Synthèse UX d’un campus de santé universitaire"
        },
        item3: {
          title: "Séquençage lumineux du parcours",
          body: "L’introduction d’un séquençage lumineux couplé à la signalétique murale a fluidifié les mouvements sur trois niveaux de parking interconnectés.",
          meta: "Recommandation appliquée dans un pôle d’échanges multimodal"
        }
      },
      testimonials: {
        title: "Retours de terrain",
        body: "Les expertises produites viennent nourrir les équipes opérationnelles et les chantiers d’évolution de la signalétique.",
        item1: {
          quote: "La précision des relevés de flux et la capacité à les transformer en scénarios d’orientation nous ont aidés à prioriser des interventions concrètes.",
          author: "Delphine H., Direction des bâtiments communaux de Bruxelles"
        },
        item2: {
          quote: "Les ateliers menés avec nos médiateurs culturels ont révélé des besoins sensoriels déterminants pour nos visiteurs en situation de mobilité réduite.",
          author: "Mathieu C., Coordination d’un musée fédéral"
        },
        item3: {
          quote: "Le protocole proposé a clarifié les interactions entre nos écrans d’information et la signalétique physique dans un hub ferroviaire à fortes attaches urbaines.",
          author: "Nadia V., Pôle mobilité de la Région wallonne"
        }
      },
      cta: {
        title: "Un lieu demande une lecture spécifique",
        body: "Nous documentons les singularités de chaque site pour bâtir une grammaire d’orientation cohérente avec ses architectures et ses usagers.",
        button: "Initier un échange"
      }
    },
    services: {
      hero: {
        title: "Approches pour éclairer les environnements complexes",
        subtitle: "Nos interventions relient données de flux, observations qualitatives et design informationnel pour outiller les acteurs publics.",
        cta: "Fixer un rendez-vous exploratoire",
        secondary: "Consulter les publications",
        alt: "Analyse de plan dans un centre de transport"
      },
      summary: {
        title: "Des services construits pour les lieux pluriels",
        body: "Chaque mission combine des modules sur mesure : étude des flux, cartographie numérique, scénographie informationnelle et accompagnement méthodologique."
      },
      list: {
        item1: {
          title: "Analyse des flux piétons",
          body: "Observer, qualifier et modéliser les trajectoires pour comprendre les zones de friction et les attentes contextuelles.",
          point1: "Relevés temporels et saisonniers des déplacements.",
          point2: "Cartes de densité et profils d’usagers.",
          point3: "Identification des facteurs d’orientation implicites."
        },
        item2: {
          title: "Conception de signalétique numérique",
          body: "Définir la place des écrans, kiosques et supports interactifs en cohérence avec les repères physiques existants.",
          point1: "Scénarios d’usage par contexte et par public.",
          point2: "Charte de contenus dynamiques et hiérarchie de messages.",
          point3: "Recommandations d’implantation et de maintenance."
        },
        item3: {
          title: "Stratégie d’UX spatiale",
          body: "Articuler les dimensions sensorielles, cognitives et motrices pour une expérience fluide d’un point d’entrée à un point cible.",
          point1: "Cartographie des points de décision critiques.",
          point2: "Ateliers avec les personnels d’accueil et la maintenance.",
          point3: "Indicateurs UX pour suivre la mise en œuvre."
        },
        item4: {
          title: "Conseil en design informationnel",
          body: "Clarifier les codes visuels, typographiques et linguistiques afin d’aligner la signalétique avec l’architecture.",
          point1: "Audit de lisibilité des supports existants.",
          point2: "Recommandations rédactionnelles multilingues.",
          point3: "Alignement avec les contraintes réglementaires."
        },
        item5: {
          title: "Recherche sur l’accessibilité",
          body: "Évaluer la facilité d’usage pour tous les publics, y compris les personnes à mobilité réduite ou neurodivergentes.",
          point1: "Diagnostics sensoriels et tests utilisateurs ciblés.",
          point2: "Guides de conception inclusive pour les équipes.",
          point3: "Tableaux de bord d’indicateurs d’accessibilité."
        }
      },
      process: {
        title: "Une méthodologie documentée",
        body: "Notre démarche suit un enchaînement transparent : cadrage, observation, design, restitution. Chaque étape est partagée avec les équipes projet.",
        step1: {
          title: "Immersion initiale",
          body: "Entretiens, découverte des plans et repérage des enjeux institutionnels pour définir le périmètre."
        },
        step2: {
          title: "Campagnes d’observation",
          body: "Mesure des flux, relevés photo et collecte de retours usagers pour alimenter la modélisation."
        },
        step3: {
          title: "Synthèse cartographique",
          body: "Traduction graphique des itinéraires, points de friction et opportunités de repères visuels."
        },
        step4: {
          title: "Restitution partagée",
          body: "Co-construction de feuilles de route et de cadres d’évaluation pour la mise en œuvre."
        }
      },
      case: {
        title: "Études livrées en plusieurs formats",
        body: "Rapports illustrés, cartes interactives, ateliers de restitution : les supports sont ajustés à vos équipes et à vos échéances.",
        cta: "Proposer un contexte de site"
      }
    },
    about: {
      hero: {
        title: "Une équipe dédiée à la lisibilité des espaces publics",
        subtitle: "Nous réunissons des profils de cartographes, designers informationnels et analystes des flux pour accompagner les acteurs publics.",
        alt: "Vue d’un atrium avec signalétique suspendue"
      },
      mission: {
        title: "Une mission d’observation et de transmission",
        body: "danswholesaleplants explore les environnements bâtis pour en révéler la logique d’orientation et proposer des pistes concrètes d’amélioration. Nous intervenons auprès d’institutions culturelles, d’hôpitaux, de campus et d’infrastructures de mobilité.",
        focusTitle: "Points d’attention majeurs",
        focus1: "Comprendre la perception des espaces par les publics variés.",
        focus2: "Traduire les observations en supports opérationnels.",
        focus3: "Anticiper les évolutions réglementaires et technologiques."
      },
      timeline: {
        title: "Repères chronologiques",
        body: "La démarche s’est structurée au fil de collaborations transdisciplinaires et de projets pilotes en Belgique et à l’étranger.",
        entry1: {
          year: "2014",
          body: "Premiers travaux d’analyse des flux dans des maisons de justice et centres administratifs."
        },
        entry2: {
          year: "2017",
          body: "Déploiement d’une cellule dédiée aux cartographies interactives pour les campus hospitaliers."
        },
        entry3: {
          year: "2020",
          body: "Création d’un programme de recherche sur la signalétique numérique et les parcours multimodaux."
        },
        entry4: {
          year: "2023",
          body: "Constitution d’un réseau d’observatoires urbains à Bruxelles, Namur et Liège."
        }
      },
      values: {
        title: "Principes guidant nos études",
        body: "Chaque mission respecte un cadre éthique et scientifique garantissant une vision nuancée des usages.",
        item1: {
          title: "Neutralité analytique",
          body: "Les données recueillies sont documentées et contextualisées afin de limiter les interprétations hâtives."
        },
        item2: {
          title: "Conception inclusive",
          body: "Les préconisations tiennent compte des capacités sensorielles, cognitives et motrices des publics."
        },
        item3: {
          title: "Transmission durable",
          body: "Les livrables privilégient des formats appropriables par les équipes internes pour assurer la continuité."
        }
      },
      team: {
        title: "Organisation du laboratoire",
        body: "L’équipe est constituée de chercheurs seniors, de designers d’information, de spécialistes cartographiques et de coordinateurs de terrain.",
        structureTitle: "Fonctions principales",
        structure1: "Cellule de recherche : analyse de données, protocoles et publications.",
        structure2: "Cellule design : modélisation graphique, narration visuelle, guidage numérique.",
        structure3: "Cellule terrain : observation in situ, ateliers participatifs, tests utilisateurs."
      },
      cta: {
        title: "Partager vos observations",
        body: "Présentez-nous votre site, vos contraintes et vos hypothèses : nous construisons ensemble un plan d’étude réaliste.",
        button: "Organiser un échange"
      }
    },
    blog: {
      hero: {
        title: "Journal d’exploration des parcours publics",
        subtitle: "Chaque article compile retours de terrain, cadres théoriques et données chiffrées pour éclairer la navigation dans les espaces complexes.",
        alt: "Carte affichée dans un campus"
      },
      intro: {
        title: "Une veille centrée sur l’UX spatiale",
        body: "Les publications traitent de signalétique, de cartographie, de design d’information et de flux piétons. Elles visent à nourrir la réflexion des décideurs publics et des concepteurs."
      },
      posts: {
        post1: {
          title: "Modéliser les déplacements piétons dans les complexes culturels",
          excerpt: "Approche méthodique pour analyser les flux de visiteurs, intégrer les contraintes patrimoniales et concevoir des parcours lisibles dans les ensembles culturels.",
          alt: "Visiteurs dans un musée moderne"
        },
        post2: {
          title: "Harmoniser la signalétique numérique des hubs intermodaux",
          excerpt: "Quels principes pour articuler écrans, panneaux et capteurs dans les pôles de mobilité afin de fluidifier l’expérience voyageur ?",
          alt: "Signalétique dans une gare intermodale"
        },
        post3: {
          title: "Cartographie hybride pour campus étendus",
          excerpt: "Relier les parcours intérieurs et extérieurs grâce à une cartographie cohérente des installations universitaires et hospitalières.",
          alt: "Plan d’un campus universitaire"
        },
        post4: {
          title: "Observer l’UX spatiale avec des protocoles qualitatifs",
          excerpt: "Comment les observations accompagnées, journaux de bord et focus groupes enrichissent la compréhension des parcours usagers ?",
          alt: "Salle de lecture avec visiteurs"
        },
        post5: {
          title: "Accessibilité des sites patrimoniaux en mouvement",
          excerpt: "Étudier la signalétique, la médiation et les guidages pour rendre lisibles les itinéraires au sein des sites patrimoniaux fréquentés.",
          alt: "Touristes dans un site patrimonial"
        }
      },
      cta: {
        title: "Aller plus loin sur votre site",
        body: "Nous adaptons ces apprentissages à vos enjeux spécifiques et aux contextes réglementaires de vos infrastructures.",
        button: "Programmer une discussion"
      }
    },
    contact: {
      hero: {
        title: "Nous transmettre vos enjeux de navigation",
        subtitle: "Expliquez-nous le contexte de votre bâtiment, vos publics et vos hypothèses : nous préparerons une première lecture partagée.",
        cta: "Accéder aux coordonnées",
        secondary: "Voir les questions fréquentes",
        alt: "Hall d’un bâtiment public"
      },
      details: {
        title: "Coordonnées directes",
        body: "Notre équipe répond sous deux jours ouvrables et propose, si nécessaire, un court échange en visioconférence pour clarifier votre environnement.",
        phoneLabel: "Téléphone",
        phoneValue: "+32 2 320 54 18",
        emailLabel: "Courriel",
        emailValue: "info@danswholesaleplants.com",
        addressLabel: "Adresse",
        addressValue: "Rue des Chartreux 62, 1000 Bruxelles, Belgique",
        hoursLabel: "Horaires de réponse",
        hoursValue: "Du lundi au vendredi, 9h00 – 18h00"
      },
      form: {
        title: "Transmettre un contexte de site",
        body: "Précisez les éléments essentiels afin que nous préparions un premier diagnostic de vos parcours.",
        nameLabel: "Nom complet",
        namePlaceholder: "Indiquez votre nom et prénom",
        emailLabel: "Adresse courriel",
        emailPlaceholder: "exemple@organisation.be",
        orgLabel: "Organisation",
        orgPlaceholder: "Structure, service ou département",
        topicLabel: "Type de demande",
        topicDefault: "Sélectionnez une option",
        topicOption1: "Audit de flux piétons",
        topicOption2: "Stratégie de signalétique numérique",
        topicOption3: "Accessibilité et guidage",
        topicOption4: "Autre besoin",
        messageLabel: "Message",
        messagePlaceholder: "Décrivez brièvement les enjeux, le site et les délais envisagés",
        submit: "Envoyer la demande"
      },
      map: {
        title: "Localisation du centre d’observation",
        body: "Notre base se situe dans les Marolles, avec un accès rapide aux principaux pôles institutionnels de Bruxelles.",
        caption: "Carte centrée sur le centre d’observation de Bruxelles"
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        subtitle: "Réponses détaillées pour comprendre notre posture et la manière dont nous explorons les environnements complexes.",
        alt: "Vue d’un pôle de mobilité"
      },
      intro: {
        title: "Comprendre notre cadre d’intervention",
        body: "Les réponses ci-dessous éclairent la façon dont nous combinons études de terrain, analyses cartographiques et recommandations."
      },
      items: {
        item1: {
          question: "Pourquoi analyser les flux piétons sur plusieurs saisons ?",
          answer: "Les rythmes d’affluence influencent la perception des repères. Des mesures multiséquences révèlent les variations liées aux horaires, événements et conditions climatiques."
        },
        item2: {
          question: "Comment articulez-vous signalétique physique et numérique ?",
          answer: "Nous définissons une hiérarchie lisible où écrans, panneaux et marquages se complètent, en veillant à ne jamais surcharger un point décisionnel."
        },
        item3: {
          question: "Quelles données recueillez-vous lors des observations ?",
          answer: "Nous collectons des chronologies de déplacements, des croquis analytiques, des verbatim d’usagers et des relevés photographiques contextualisés."
        },
        item4: {
          question: "Travaillez-vous uniquement en Belgique ?",
          answer: "La majorité de nos missions se situe en Belgique, mais nous intervenons ponctuellement dans d’autres villes européennes lorsque les conditions d’étude sont réunies."
        },
        item5: {
          question: "Proposez-vous des outils de suivi post-étude ?",
          answer: "Oui, nous transmettons des indicateurs d’évaluation ainsi que des grilles de suivi que vos équipes peuvent alimenter au fil des ajustements."
        },
        item6: {
          question: "Comment impliquez-vous les usagers ?",
          answer: "Par des parcours commentés, des ateliers cartographiques et des tests de lisibilité ciblant différents profils, y compris des personnes à mobilité réduite."
        },
        item7: {
          question: "Pouvez-vous intervenir sur des projets en chantier ?",
          answer: "Nous intervenons en amont, pendant ou après les travaux, en adaptant les protocoles aux contraintes d’accès et de sécurité du site."
        },
        item8: {
          question: "Quels livrables fournissez-vous ?",
          answer: "Nous livrons des rapports illustrés, des cartes interactives, des supports de synthèse et des feuilles de route opérationnelles."
        }
      },
      cta: {
        title: "Un point n’est pas abordé ?",
        body: "Partagez votre question ou proposez un créneau d’échange afin que nous y répondions précisément.",
        button: "Contacter l’équipe"
      }
    },
    terms: {
      hero: {
        title: "Conditions d’utilisation",
        subtitle: "En accédant au site danswholesaleplants.com, vous acceptez les présentes conditions applicables."
      },
      sections: {
        s1: {
          title: "1. Objet",
          body1: "Les présentes conditions définissent les modalités d’accès et d’utilisation du site danswholesaleplants.com exploité par danswholesaleplants.",
          body2: "Toute consultation implique l’acceptation sans réserve de ces dispositions."
        },
        s2: {
          title: "2. Accès au site",
          body1: "Le site est accessible gratuitement aux utilisateurs disposant d’une connexion internet.",
          body2: "danswholesaleplants peut suspendre l’accès pour maintenance, mise à jour ou incident technique."
        },
        s3: {
          title: "3. Propriété intellectuelle",
          body1: "Les contenus, marques, logos, textes, images et graphismes sont protégés par le droit de la propriété intellectuelle.",
          body2: "Toute reproduction ou utilisation non autorisée est strictement interdite."
        },
        s4: {
          title: "4. Usage des contenus",
          body1: "Les informations publiées sont fournies à titre informatif et ne constituent pas d’engagement contractuel.",
          body2: "L’utilisateur s’engage à ne pas dénaturer le sens des contenus lors de leur citation."
        },
        s5: {
          title: "5. Contributions externes",
          body1: "Lorsque des contributions externes sont publiées, leurs auteurs en restent responsables.",
          body2: "danswholesaleplants se réserve le droit de retirer toute contribution en cas de non-conformité."
        },
        s6: {
          title: "6. Liens hypertextes",
          body1: "Le site peut contenir des liens vers d’autres ressources dont danswholesaleplants n’exerce aucun contrôle.",
          body2: "La présence de ces liens n’implique aucune approbation des contenus externes."
        },
        s7: {
          title: "7. Responsabilité",
          body1: "danswholesaleplants met tout en œuvre pour assurer la fiabilité des informations mais ne garantit pas l’absence d’erreurs.",
          body2: "L’utilisateur exploite les informations sous sa seule responsabilité."
        },
        s8: {
          title: "8. Sécurité",
          body1: "L’utilisateur s’assure de protéger ses équipements contre toute tentative d’intrusion ou virus.",
          body2: "danswholesaleplants ne pourra être tenu responsable des dommages subis par les équipements de l’utilisateur."
        },
        s9: {
          title: "9. Données personnelles",
          body1: "La consultation du site peut entraîner la collecte de données conformément à la Politique de confidentialité.",
          body2: "L’utilisateur peut exercer ses droits via l’adresse indiquée dans ladite politique."
        },
        s10: {
          title: "10. Cookies",
          body1: "Des cookies techniques et analytiques peuvent être déposés sur le terminal de l’utilisateur.",
          body2: "La gestion de ces cookies est détaillée dans la Politique cookies."
        },
        s11: {
          title: "11. Modifications",
          body1: "danswholesaleplants peut modifier les présentes conditions à tout moment.",
          body2: "Les utilisateurs sont invités à les consulter régulièrement."
        },
        s12: {
          title: "12. Loi applicable",
          body1: "Les présentes conditions sont régies par le droit belge.",
          body2: "Tout litige relève de la compétence des juridictions de Bruxelles."
        },
        s13: {
          title: "13. Contact",
          body1: "Pour toute question relative aux conditions d’utilisation, contactez info@danswholesaleplants.com.",
          body2: "Une réponse sera apportée dans un délai raisonnable."
        },
        s14: {
          title: "14. Entrée en vigueur",
          body1: "Les présentes conditions sont applicables à compter du 15 janvier 2024.",
          body2: "Elles annulent et remplacent toute version précédente."
        }
      }
    },
    privacy: {
      hero: {
        title: "Politique de confidentialité",
        subtitle: "Protection des données personnelles collectées par danswholesaleplants."
      },
      sections: {
        s1: {
          title: "1. Responsable de traitement",
          body1: "Le responsable du traitement est danswholesaleplants, établi Rue des Chartreux 62, 1000 Bruxelles.",
          body2: "Vous pouvez nous joindre via info@danswholesaleplants.com."
        },
        s2: {
          title: "2. Données collectées",
          body1: "Les données collectées incluent : identité, coordonnées professionnelles, informations liées aux demandes transmises.",
          body2: "Nous recueillons également des données d’utilisation anonymisées via les cookies analytiques."
        },
        s3: {
          title: "3. Finalités",
          body1: "Les données sont utilisées pour répondre aux demandes, organiser des échanges et améliorer le site.",
          body2: "Les données statistiques servent uniquement à optimiser la navigation."
        },
        s4: {
          title: "4. Fondements juridiques",
          body1: "Le traitement est fondé sur l’intérêt légitime de répondre à vos sollicitations et sur votre consentement lorsqu’il est requis.",
          body2: "L’utilisation de cookies analytiques repose sur votre choix explicite."
        },
        s5: {
          title: "5. Durées de conservation",
          body1: "Les données liées aux échanges sont conservées pendant trois ans à compter du dernier contact.",
          body2: "Les données analytiques agrégées sont conservées 13 mois."
        },
        s6: {
          title: "6. Destinataires",
          body1: "Les données sont accessibles aux membres autorisés de danswholesaleplants.",
          body2: "Aucun transfert commercial n’est réalisé vers des tiers."
        },
        s7: {
          title: "7. Sous-traitance",
          body1: "Certains traitements techniques peuvent être confiés à des prestataires européens respectant le RGPD.",
          body2: "Ils agissent sur instruction et ne peuvent utiliser les données à d’autres fins."
        },
        s8: {
          title: "8. Droits des personnes",
          body1: "Vous disposez des droits d’accès, rectification, effacement, opposition, limitation et portabilité.",
          body2: "Pour les exercer, écrivez à info@danswholesaleplants.com en précisant votre demande."
        },
        s9: {
          title: "9. Sécurité",
          body1: "Nous mettons en place des mesures techniques et organisationnelles adaptées pour protéger vos données.",
          body2: "Ces mesures sont réévaluées régulièrement."
        },
        s10: {
          title: "10. Réclamations",
          body1: "Vous pouvez introduire une réclamation auprès de l’Autorité de protection des données (APD) en Belgique.",
          body2: "Nous vous invitons toutefois à nous contacter en premier lieu pour rechercher une solution amiable."
        }
      }
    },
    cookiesPage: {
      hero: {
        title: "Politique relative aux cookies",
        subtitle: "Transparence sur les cookies utilisés par danswholesaleplants."
      },
      sections: {
        s1: {
          title: "1. Principes généraux",
          body1: "Les cookies sont de petits fichiers stockés sur votre terminal pour faciliter la navigation.",
          body2: "Vous choisissez librement d’activer ou non les cookies non nécessaires."
        },
        s2: {
          title: "2. Tableau récapitulatif",
          body1: "Le tableau ci-dessous décrit les cookies pouvant être déposés sur votre terminal.",
          body2: "Les informations sont mises à jour régulièrement."
        },
        s3: {
          title: "3. Gestion du consentement",
          body1: "Votre choix est mémorisé grâce à un cookie nécessaire afin de ne pas vous solliciter à chaque visite.",
          body2: "Vous pouvez modifier votre choix à tout moment via la bannière ou en supprimant vos cookies."
        },
        s4: {
          title: "4. Impact du refus",
          body1: "Le refus des cookies préférentiels ou analytiques peut entraîner une expérience moins personnalisée.",
          body2: "Les contenus essentiels demeurent accessibles."
        },
        s5: {
          title: "5. Contact",
          body1: "Pour toute question relative à cette politique, écrivez à info@danswholesaleplants.com.",
          body2: "Nous vous répondrons dans un délai raisonnable."
        }
      },
      table: {
        headers: {
          name: "Nom",
          provider: "Fournisseur",
          type: "Type",
          purpose: "Finalité",
          duration: "Durée"
        },
        rows: {
          necessary: {
            name: "consent_state",
            provider: "danswholesaleplants",
            type: "Technique",
            purpose: "Enregistrer vos choix de consentement et la langue sélectionnée.",
            duration: "12 mois"
          },
          preferences: {
            name: "layout_pref",
            provider: "danswholesaleplants",
            type: "Préférences",
            purpose: "Mémoriser les sections consultées pour adapter l’affichage lors de votre prochaine visite.",
            duration: "6 mois"
          },
          analytics: {
            name: "usage_metrics",
            provider: "danswholesaleplants",
            type: "Analytique",
            purpose: "Mesurer la fréquentation et identifier les chemins de navigation les plus utilisés.",
            duration: "13 mois"
          },
          marketing: {
            name: "publication_updates",
            provider: "danswholesaleplants",
            type: "Informationnel",
            purpose: "Proposer des contenus éditoriaux liés à nos publications externes.",
            duration: "6 mois"
          }
        }
      }
    },
    refund: {
      hero: {
        title: "Politique de correction et de révision",
        subtitle: "Modalités d’ajustement des livrables informationnels fournis par danswholesaleplants."
      },
      sections: {
        s1: {
          title: "1. Champ d’application",
          body1: "Cette politique concerne les livrables remis dans le cadre d’une étude ou d’un accompagnement.",
          body2: "Elle ne concerne pas les contenus consultables librement."
        },
        s2: {
          title: "2. Demande de correction",
          body1: "Toute demande doit être introduite par écrit dans les trente jours suivant la remise du livrable.",
          body2: "Elle précise les éléments estimés incomplets ou erronés."
        },
        s3: {
          title: "3. Analyse conjointe",
          body1: "Nous organisons un échange pour comprendre le contexte et définir l’ampleur de la correction attendue.",
          body2: "Un calendrier de traitement est proposé à l’issue de cette analyse."
        },
        s4: {
          title: "4. Corrections incluses",
          body1: "Les corrections remédiant à des inexactitudes factuelles ou graphiques sont réalisées sans frais supplémentaires.",
          body2: "Elles sont livrées dans un format identique au livrable initial."
        },
        s5: {
          title: "5. Ajustements hors périmètre",
          body1: "Les demandes impliquant de nouvelles collectes ou des analyses supplémentaires font l’objet d’un cadrage spécifique.",
          body2: "Un avenant est soumis avant toute réalisation."
        },
        s6: {
          title: "6. Délai de traitement",
          body1: "Les corrections incluses sont réalisées dans un délai maximum de quinze jours ouvrables.",
          body2: "Les ajustements hors périmètre suivent le calendrier convenu lors du cadrage."
        },
        s7: {
          title: "7. Validation",
          body1: "Un livrable corrigé est transmis pour validation.",
          body2: "En l’absence de retour dans les sept jours, il est considéré comme approuvé."
        },
        s8: {
          title: "8. Conservation des versions",
          body1: "Nous conservons les versions successives des livrables pour assurer la traçabilité.",
          body2: "Cette conservation est limitée aux besoins opérationnels."
        },
        s9: {
          title: "9. Suspension",
          body1: "danswholesaleplants peut suspendre la correction si les informations demandées ne sont pas fournies.",
          body2: "La suspension prend fin dès réception des éléments nécessaires."
        },
        s10: {
          title: "10. Contact",
          body1: "Toute demande est adressée à info@danswholesaleplants.com.",
          body2: "Merci d’indiquer l’intitulé du projet et la date de remise du livrable."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Avis de non-responsabilité",
        subtitle: "Limites liées à l’usage des informations publiées sur danswholesaleplants.com."
      },
      sections: {
        s1: {
          title: "1. Absence de garantie",
          body1: "Les informations sont diffusées à titre informatif et peuvent évoluer sans préavis.",
          body2: "danswholesaleplants ne garantit pas l’exhaustivité des contenus."
        },
        s2: {
          title: "2. Responsabilité de l’utilisateur",
          body1: "L’utilisateur reste seul responsable de l’utilisation qu’il fait des informations consultées.",
          body2: "Il lui appartient de vérifier la pertinence des contenus au regard de son contexte."
        },
        s3: {
          title: "3. Liens externes",
          body1: "Les liens vers des sites tiers sont fournis pour faciliter la veille.",
          body2: "danswholesaleplants ne répond pas de la fiabilité de ces ressources."
        },
        s4: {
          title: "4. Contenus tiers",
          body1: "Les citations de tiers sont attribuées à leurs auteurs respectifs.",
          body2: "danswholesaleplants ne peut être tenu responsable des propos repris."
        },
        s5: {
          title: "5. Utilisation professionnelle",
          body1: "Les contenus ne constituent pas un avis professionnel ou juridique.",
          body2: "Nous invitons les utilisateurs à consulter leurs conseillers pour toute décision opérationnelle."
        },
        s6: {
          title: "6. Contact",
          body1: "Pour signaler un contenu ou demander une précision, écrivez à info@danswholesaleplants.com.",
          body2: "Nous traiterons votre requête dans les meilleurs délais."
        }
      }
    },
    thankyou: {
      hero: {
        title: "Votre message est bien enregistré",
        subtitle: "Merci pour les informations transmises. Nous revenons vers vous rapidement pour un premier échange.",
        primary: "Retour à l’accueil",
        secondary: "Parcourir nos analyses"
      }
    },
    posts: {
      post1: {
        title: "Modéliser les déplacements piétons dans les complexes culturels",
        intro1: "Les ensembles culturels majeurs cumulent surfaces généreuses, densité de services et exigences patrimoniales. Comprendre la manière dont les visiteurs se déplacent est essentiel pour garantir la lisibilité du lieu sans dénaturer son identité.",
        intro2: "Nos recherches réunissent mesures quantitatives, récits d’usagers et relevés cartographiques pour représenter la diversité des trajectoires. Il ne s’agit pas seulement de compter des passages mais de comprendre ce qui guide les décisions à chaque bifurcation.",
        intro3: "En Belgique, plusieurs institutions muséales ont engagé des campagnes d’observation longue durée afin d’adapter leurs parcours. L’expérience montre que les dispositifs techniques doivent dialoguer avec les repères sensibles et les usages spontanés.",
        section1: {
          title: "Observer les flux au-delà des chiffres bruts",
          p1: "La première étape consiste à dépasser la simple mesure de fréquentation. Nous distinguons les flux par catégories de visiteurs, temporalités et motivations. L’objectif est de détecter les variations de rythme, les regroupements, les hésitations et les détours.",
          p2: "Pour cela, nous combinons relevés manuels, capteurs temporaires et parcours commentés. Chaque méthode apporte un regard différent : les capteurs objectivent la densité, tandis que les parcours commentés révèlent les repères cognitifs.",
          p3: "Les données sont ensuite intégrées à une cartographie évolutive. Chaque zone du musée est décrite selon sa fréquentation, sa visibilité et la facilité de compréhension des repères. Cette approche met en lumière les points d’attention prioritaires.",
          sub1: {
            title: "Donner un rôle à la micro-observation",
            p1: "Au-delà des trajectoires globales, nous nous concentrons sur les micro-interactions avec la signalétique. Combien de temps un visiteur s’arrête-t-il devant un panneau ? Change-t-il de direction après l’avoir consulté ?",
            p2: "Ces micro-observations révèlent la cohérence du message et la capacité du dispositif à répondre à une question précise. Elles sont indispensables pour hiérarchiser les interventions futures."
          }
        },
        section2: {
          title: "Composer avec les contraintes patrimoniales",
          p1: "Les complexes culturels belges sont souvent hébergés dans des bâtiments classés. Chaque ajout de signalétique doit donc respecter des contraintes strictes. Il est nécessaire de travailler avec les architectes et les responsables de conservation pour trouver des solutions réversibles.",
          p2: "Dans certains cas, nous privilégions des dispositifs autoportants, facilement déployés lors d’événements saisonniers. Ils permettent de guider les flux sans altérer les murs ni interrompre les perspectives historiques.",
          p3: "Nous expérimentons également des supports lumineux à intensité modulable. La lumière devient un repère subtil, particulièrement utile dans les vastes galeries ou les circulations verticales.",
          sub1: {
            title: "L’apport des technologies immersives",
            p1: "La réalité augmentée est parfois évoquée comme solution universelle. En pratique, nous l’utilisons de manière ponctuelle pour orienter des publics spécifiques, comme les groupes scolaires ou les visiteurs étrangers.",
            p2: "L’important est de garantir une expérience cohérente entre les dispositifs numériques et le guidage physique, sans imposer un équipement personnel à chaque visiteur."
          }
        },
        section3: {
          title: "Mesurer l’effet des ajustements",
          p1: "Après avoir implanté de nouveaux repères, nous évaluons leur impact sur les flux. Les indicateurs portent sur la réduction des hésitations, la meilleure répartition des visiteurs et la diminution des zones congestionnées.",
          p2: "Nous interrogeons aussi les équipes d’accueil, qui perçoivent en premier les changements de comportement. Leurs retours qualitatifs complètent les données chiffrées et inspirent de nouvelles itérations.",
          p3: "Les ajustements réussis sont ceux qui respectent l’identité du lieu. Loin d’imposer une signalétique uniforme, il s’agit de renforcer les repères existants en les rendant plus lisibles.",
          sub1: {
            title: "Diffuser les apprentissages en interne",
            p1: "Chaque mission se termine par une restitution détaillée auprès des équipes du musée. Nous partageons les plans mis à jour, les indicateurs suivis et les recommandations d’entretien.",
            p2: "Cette transmission permet de maintenir la cohérence dans le temps et d’éviter que les repères se dégradent ou perdent leur sens."
          }
        },
        conclusion: {
          title: "Vers une navigation sensible et informée",
          p1: "Modéliser les déplacements piétons ne se limite pas à tracer des flèches sur un plan. La démarche nécessite une écoute attentive des visiteurs, la prise en compte des contraintes patrimoniales et la capacité d’évaluer les ajustements.",
          p2: "Les complexes culturels belges qui ont intégré cette approche constatent une meilleure fluidité, une diminution des demandes d’orientation et une satisfaction accrue des publics variés."
        }
      },
      post2: {
        title: "Harmoniser la signalétique numérique des hubs intermodaux",
        intro1: "Les gares et hubs intermodaux réunissent des flux d’intensités très différentes : voyageurs quotidiens, touristes, étudiants, publics à mobilité réduite. La signalétique numérique y prend une place croissante.",
        intro2: "Pour qu’elle soit efficace, elle doit dialoguer avec les supports analogiques et les annonces sonores. L’harmonisation est un exercice délicat entre cohérence opérationnelle et adaptation locale.",
        intro3: "La Belgique développe plusieurs pôles intermodaux ambitieux, notamment à Bruxelles, Namur et Anvers. Chaque site constitue un laboratoire pour tester de nouvelles configurations.",
        section1: {
          title: "Cartographier les flux intermodaux",
          p1: "Dans un hub intermodal, chaque mode de transport impose son rythme et ses repères. Nous commençons par cartographier les flux structurants : trains, métro, bus, vélos, marchabilité.",
          p2: "Cette cartographie révèle les points de friction où les voyageurs hésitent ou se croisent. Elle permet d’assigner un rôle précis à chaque support de signalétique.",
          p3: "Les écrans doivent être positionnés aux endroits où la décision est la plus complexe. Ils complètent la signalétique analogique plutôt qu’ils ne la remplacent.",
          sub1: {
            title: "Exploiter les données en temps réel",
            p1: "Les écrans peuvent relayer des informations en direct : temps d’attente, état des ascenseurs, occupation des quais. Nous veillons à ne diffuser que des messages utiles à l’instant T.",
            p2: "La surcharge de messages crée de la confusion. Nous privilégions des interfaces sobres, hiérarchisées et faciles à lire à distance."
          }
        },
        section2: {
          title: "Assurer la cohérence visuelle et linguistique",
          p1: "Chaque opérateur de transport possède sa charte. L’harmonisation passe par un travail graphique subtil : typographies compatibles, codes couleur interprétables rapidement et traduction rigoureuse.",
          p2: "Dans les zones bilingues, nous veillons à la parité linguistique tout en préservant la lisibilité. L’usage de pictogrammes normalisés complète les textes.",
          p3: "Les écrans doivent aussi respecter les contrastes et tailles de caractères pour les publics malvoyants. Nous testons plusieurs scénarios d’affichage avant déploiement.",
          sub1: {
            title: "Gérer les annonces sonores",
            p1: "La cohérence passe également par la synchronisation des annonces sonores. Les messages diffusés doivent reprendre les mêmes codes que la signalétique visuelle.",
            p2: "Une charte de rédaction garantit que chaque annonce apporte une information actionnable sans saturer l’environnement sonore."
          }
        },
        section3: {
          title: "Impliquer les équipes de terrain",
          p1: "Les agents de mobilité sont les premiers relais de la signalétique. Nous construisons avec eux des scénarios d’usage et recueillons leurs observations après déploiement.",
          p2: "Ils identifient rapidement les zones où les voyageurs continuent de s’interroger. Leurs retours alimentent un plan d’ajustement progressif.",
          p3: "La maintenance est également décisive : un écran inactif ou mal calibré compromet la confiance. Nous prévoyons des protocoles de suivi clairs.",
          sub1: {
            title: "Évaluer la performance dans le temps",
            p1: "Nous mesurons la performance à travers des indicateurs : diminution des demandes d’information, temps moyen pour trouver un quai, fluidité aux correspondances.",
            p2: "Ces indicateurs sont partagés avec les gestionnaires pour ajuster le dispositif à chaque période de pointe."
          }
        },
        conclusion: {
          title: "Un système hybride et évolutif",
          p1: "La signalétique numérique ne remplace pas les repères analogiques. Elle en renforce l’efficacité lorsque son rôle est clairement défini et coordonné avec les autres canaux.",
          p2: "Les hubs intermodaux qui adoptent cette approche offrent une expérience plus fluide et rassurante, quelle que soit la familiarité du voyageur avec le site."
        }
      },
      post3: {
        title: "Cartographie hybride pour campus étendus",
        intro1: "Les campus universitaires et hospitaliers associent bâtiments, espaces publics et réseaux souterrains. La cartographie doit articuler ces dimensions pour guider les parcours.",
        intro2: "Une carte hybride combine données géographiques, informations fonctionnelles et repères sensibles. Elle fait dialoguer les espaces intérieurs et extérieurs.",
        intro3: "Nos travaux se concentrent sur des campus belges en évolution, où de nouveaux bâtiments s’ajoutent à des structures historiques.",
        section1: {
          title: "Identifier les parcours dominants",
          p1: "Nous analysons les déplacements par profil : étudiants, personnels, visiteurs ponctuels, patients. Chacun privilégie des itinéraires distincts en fonction de ses contraintes.",
          p2: "Cette analyse permet de définir les axes structurants qui doivent apparaître clairement sur la carte hybride.",
          p3: "Les parcours dominants servent de squelette au plan. Les chemins secondaires sont ensuite intégrés selon leur importance.",
          sub1: {
            title: "Cartographier les seuils et interfaces",
            p1: "Les campus présentent de nombreux seuils : entrées, atriums, ascenseurs, passerelles. Nous les repérons précisément pour guider la transition intérieur/extérieur.",
            p2: "Chaque seuil doit être lisible sur la carte et facilement localisable sur le terrain."
          }
        },
        section2: {
          title: "Structurer l’information cartographique",
          p1: "Une carte hybride ne peut tout montrer. Nous hiérarchisons les informations : d’abord les repères structurants, ensuite les services spécifiques.",
          p2: "Les niveaux multiples sont représentés par des schémas dédiés, reliés aux plans extérieurs par des codes couleur.",
          p3: "Nous intégrons des pictogrammes normalisés et des légendes bilingues claires.",
          sub1: {
            title: "Rendre la carte accessible",
            p1: "Le contraste élevé, la typographie lisible et les symboles simples sont essentiels. Nous testons la carte auprès de publics variés.",
            p2: "Des versions numériques interactives permettent d’adapter le niveau de détail selon les besoins."
          }
        },
        section3: {
          title: "Mettre à jour en continu",
          p1: "Les campus évoluent constamment. Nous mettons en place un processus de mise à jour régulier, avec un référent interne chargé de coordonner les modifications.",
          p2: "Les cartes numériques sont synchronisées avec les versions imprimées pour éviter les incohérences.",
          p3: "Des indicateurs suivent la consultation des cartes et les demandes de renseignements.",
          sub1: {
            title: "Partager les données en open format",
            p1: "Lorsque la politique du campus le permet, nous publions la cartographie sous forme de données ouvertes pour encourager l’innovation.",
            p2: "Des équipes étudiantes peuvent alors développer des outils complémentaires : applications, parcours guidés, services d’accessibilité."
          }
        },
        conclusion: {
          title: "Cartographier pour mieux naviguer",
          p1: "Une carte hybride réussie simplifie les déplacements, renforce la compréhension du campus et réduit le stress des visiteurs.",
          p2: "Elle devient un outil fédérateur, partagé par l’ensemble des services du site."
        }
      },
      post4: {
        title: "Observer l’UX spatiale avec des protocoles qualitatifs",
        intro1: "La lisibilité d’un lieu ne se mesure pas uniquement par des flux. Comprendre l’expérience vécue nécessite des approches qualitatives : observations, récits, ateliers.",
        intro2: "Ces protocoles donnent accès aux perceptions, aux sensations et aux stratégies développées par les usagers pour se repérer.",
        intro3: "Nous les combinons à des indicateurs quantitatifs pour obtenir une vision complète de la navigation.",
        section1: {
          title: "Choisir les bons outils qualitatifs",
          p1: "Les parcours commentés consistent à accompagner un usager dans son trajet et à enregistrer ses commentaires.",
          p2: "Les journaux de bord permettent aux agents d’accueil de noter les difficultés rencontrées par les visiteurs.",
          p3: "Les focus groupes réunissent plusieurs profils pour débattre des repères et des obstacles.",
          sub1: {
            title: "Adapter le protocole aux publics",
            p1: "Chaque outil doit être adapté aux capacités et disponibilités des participants.",
            p2: "Nous veillons à créer un climat de confiance pour recueillir des retours sincères."
          }
        },
        section2: {
          title: "Analyser les verbatim",
          p1: "Les enregistrements sont retranscrits et classés par thèmes : confusion, satisfaction, repères sensoriels, information manquante.",
          p2: "Nous croisons ces verbatim avec la cartographie des flux pour repérer les zones sensibles.",
          p3: "Les citations marquantes sont intégrées aux livrables pour restituer la voix des usagers.",
          sub1: {
            title: "Éviter les biais",
            p1: "Nous multiplions les profils pour limiter les biais liés à l’expérience personnelle.",
            p2: "Les observations sont conduites à différents moments de la journée et de la semaine."
          }
        },
        section3: {
          title: "Transformer les observations en actions",
          p1: "Les enseignements qualitatifs sont traduits en recommandations concrètes : repositionnement de panneaux, simplification de textes, ajout de repères sensoriels.",
          p2: "Nous priorisons ces actions selon leur impact et leur faisabilité.",
          p3: "Un plan de suivi permet d’évaluer la durabilité des améliorations.",
          sub1: {
            title: "Associer les équipes internes",
            p1: "Les résultats sont partagés lors d’ateliers pour que chacun comprenne l’importance des ajustements.",
            p2: "Cette appropriation facilite la mise en œuvre et l’entretien des nouveaux repères."
          }
        },
        conclusion: {
          title: "Des lieux pensés pour leurs usagers",
          p1: "Les protocoles qualitatifs complètent les mesures quantitatives et donnent un visage humain aux données.",
          p2: "Ils garantissent que la transformation des espaces reste alignée sur l’expérience réelle des usagers."
        }
      },
      post5: {
        title: "Accessibilité des sites patrimoniaux en mouvement",
        intro1: "Les sites patrimoniaux attirent des publics très variés, parfois en nombre élevé. Leur accessibilité doit concilier respect du patrimoine et besoins actuels.",
        intro2: "La navigation peut être complexe : escaliers anciens, écrans décalés, panneaux multilingues. Nous cherchons à offrir une expérience fluide sans altérer le site.",
        intro3: "Les projets récents en Belgique montrent qu’une approche progressive permet de concilier conservation et inclusion.",
        section1: {
          title: "Évaluer les contraintes du bâti",
          p1: "Nous commençons par inventorier les obstacles : dénivelés, passages étroits, éclairage variable. Chaque contrainte est cartographiée pour identifier les points critiques.",
          p2: "Les guides patrimoniaux participent à l’analyse pour préserver la cohérence esthétique.",
          p3: "La cartographie des contraintes sert de base aux scénarios d’accessibilité.",
          sub1: {
            title: "Prendre en compte la pollution visuelle",
            p1: "Dans les lieux classés, la signalétique ne peut pas être envahissante. Nous privilégions des supports discrets ou des repères lumineux temporisés.",
            p2: "La sobriété graphique garantit le respect du patrimoine tout en assurant la lisibilité."
          }
        },
        section2: {
          title: "Concevoir des parcours inclusifs",
          p1: "Nous proposons des itinéraires adaptés à différents profils : parcours sans obstacle, circuit sensoriel, visite rapide.",
          p2: "Chaque itinéraire est associé à des supports d’information cohérents, accessibles en ligne et sur place.",
          p3: "Des guides audio et des plans tactiles viennent compléter la signalétique visuelle.",
          sub1: {
            title: "Former les équipes d’accueil",
            p1: "Les médiateurs sont formés pour orienter les visiteurs selon leurs besoins.",
            p2: "Ils disposent de fiches de synthèse et de cartes simplifiées."
          }
        },
        section3: {
          title: "Évaluer l’expérience sur la durée",
          p1: "Des questionnaires ciblés et des observations régulières nous permettent de suivre l’évolution des usages.",
          p2: "Nous ajustons les supports lorsque de nouvelles contraintes apparaissent ou lorsque les flux varient.",
          p3: "La documentation des interventions garantit la traçabilité des adaptations.",
          sub1: {
            title: "Partager les résultats",
            p1: "Les retours d’expérience sont partagés avec les services du patrimoine et les collectivités.",
            p2: "Ils alimentent une base de connaissances utile à d’autres sites patrimoniaux."
          }
        },
        conclusion: {
          title: "Préserver et accueillir",
          p1: "L’accessibilité des sites patrimoniaux repose sur un équilibre entre respect du bâti et confort des visiteurs.",
          p2: "Une démarche progressive et partagée permet d’atteindre cet équilibre durablement."
        }
      }
    }
  },
  en: {
    meta: {
      index: {
        title: "Spatial orientation and digital wayfinding | danswholesaleplants",
        description: "In-depth analysis of spatial orientation, digital signage, and indoor navigation across public buildings and complex urban environments."
      },
      services: {
        title: "Fields of intervention and applied research | danswholesaleplants",
        description: "Multidisciplinary approach to diagnose pedestrian flows, design digital wayfinding systems, and structure navigation through built environments."
      },
      about: {
        title: "Methodology and research governance | danswholesaleplants",
        description: "Presentation of the laboratory, its values, and its research protocols dedicated to the legibility and accessibility of public spaces."
      },
      blog: {
        title: "Observation journal on flows and cartographies | danswholesaleplants",
        description: "Technical articles covering spatial UX, mapping, pedestrian mobility, and informational architecture for complex sites."
      },
      contact: {
        title: "Contact details and study requests | danswholesaleplants",
        description: "Share navigation issues within your building or infrastructure so we can prepare a first joint analysis."
      },
      faq: {
        title: "Frequently asked questions about spatial orientation | danswholesaleplants",
        description: "Detailed answers on flow analysis, digital signage, and mapping approaches for complex environments."
      },
      terms: {
        title: "Terms of use | danswholesaleplants",
        description: "Terms governing access to and consultation of content published by danswholesaleplants."
      },
      privacy: {
        title: "Privacy policy | danswholesaleplants",
        description: "Details on the collection, use, and protection of personal data processed by danswholesaleplants."
      },
      cookies: {
        title: "Cookie policy | danswholesaleplants",
        description: "Overview of the technical, preference, analytical, and informational cookies active on this website."
      },
      refund: {
        title: "Correction and revision policy | danswholesaleplants",
        description: "Modalities for requesting adjustments to informational deliverables shared by danswholesaleplants."
      },
      disclaimer: {
        title: "Disclaimer | danswholesaleplants",
        description: "Limitations of liability related to the use of guidance and information provided on this site."
      },
      thankyou: {
        title: "Thank you for your message | danswholesaleplants",
        description: "Confirmation that our team has received your request and will revert shortly."
      },
      post1: {
        title: "Modelling pedestrian movements in cultural complexes | danswholesaleplants",
        description: "Analytical framework to map, measure, and optimise visitor flows within large cultural venues."
      },
      post2: {
        title: "Aligning digital signage in intermodal hubs | danswholesaleplants",
        description: "Methods to orchestrate digital and physical signage across intermodal transport hubs."
      },
      post3: {
        title: "Hybrid mapping for extended campuses | danswholesaleplants",
        description: "Cartographic principles bridging indoor and outdoor journeys on university and healthcare campuses."
      },
      post4: {
        title: "Observing spatial UX with qualitative protocols | danswholesaleplants",
        description: "Qualitative tools to assess navigation experiences inside public buildings."
      },
      post5: {
        title: "Access routes in evolving heritage sites | danswholesaleplants",
        description: "Analysis of signage and guided paths to improve accessibility in heritage-rich environments."
      }
    },
    global: {
      companyName: "danswholesaleplants",
      nav: {
        home: "Home",
        services: "Approaches",
        about: "Profile",
        blog: "Blog",
        faq: "FAQ",
        contact: "Contact"
      },
      navToggle: "Open navigation",
      language: {
        fr: "FR",
        en: "EN"
      },
      buttons: {
        learnMore: "Discover",
        readMore: "Read article",
        viewAll: "View all",
        contact: "Get in touch"
      },
      footer: {
        title: "Correspondence",
        description: "danswholesaleplants investigates the legibility of built environments and crafts methodological frameworks to support user journeys.",
        addressLabel: "Address",
        addressValue: "Rue des Chartreux 62, 1000 Brussels, Belgium",
        phoneLabel: "Phone",
        phoneValue: "+32 2 320 54 18",
        emailLabel: "Email",
        emailValue: "info@danswholesaleplants.com",
        copy: "© danswholesaleplants —",
        links: {
          terms: "Terms of use",
          privacy: "Privacy policy",
          cookies: "Cookie policy",
          refund: "Correction policy",
          disclaimer: "Disclaimer"
        }
      },
      toasts: {
        success: "Message sent. We will get back to you shortly.",
        error: "Please complete the required fields."
      },
      validation: {
        required: "This field is required."
      }
    },
    cookies: {
      banner: {
        title: "Cookie management",
        message: "We rely on cookies to ensure the website functions correctly and to analyse navigation patterns for better spatial orientation.",
        link: "Read the cookie policy",
        manage: "Manage preferences"
      },
      buttons: {
        accept: "Accept all",
        decline: "Decline all",
        save: "Save"
      },
      toggles: {
        necessary: "Necessary cookies",
        preferences: "Preference cookies",
        analytics: "Analytical cookies",
        marketing: "Informational cookies"
      },
      descriptions: {
        necessary: "Guarantee the site’s core features, including language memory and consent storage.",
        preferences: "Store navigation settings specific to your session, such as section selections.",
        analytics: "Collect aggregated data on content consultation to refine navigation structure.",
        marketing: "Deliver editorial updates regarding our external publications and thematic events."
      },
      aria: {
        necessary: "Necessary cookies toggle, locked",
        preferences: "Preference cookies toggle",
        analytics: "Analytical cookies toggle",
        marketing: "Informational cookies toggle"
      }
    },
    home: {
      hero: {
        title: "Spatial orientation for readable public places",
        subtitle: "We analyse pedestrian flows, digital wayfinding, and spatial mapping to strengthen how complex built environments are understood.",
        ctaPrimary: "Explore our approaches",
        ctaSecondary: "Connect with the team",
        stat1: {
          value: "32",
          label: "European sites observed"
        },
        stat2: {
          value: "18",
          label: "Flow evaluation protocols"
        },
        stat3: {
          value: "11",
          label: "Public structures supported in 2023"
        },
        alt: "Interactive map inside a public building"
      },
      intro: {
        title: "Data-led journey intelligence",
        body: "Each study blends qualitative observation, flow modelling, and sensory analysis to reveal circulation logic and accessibility. The resulting diagnostics support design teams, facility managers, and public infrastructure leaders."
      },
      grid: {
        item1: {
          title: "Circulation diagnostics",
          body: "Map dominant trajectories, detect friction zones, and clarify signage expectations to improve user experience.",
          alt: "Directional signage in an indoor hall"
        },
        item2: {
          title: "Situated digital systems",
          body: "Shape cohesive interfaces connecting kiosks, screens, and mobile supports to deliver consistent visual guidance.",
          alt: "Digital orientation screen in a station"
        },
        item3: {
          title: "Multimodal urban guidance",
          body: "Link pedestrian journeys with soft mobility networks and inter-building crossovers to streamline transitions.",
          alt: "Pedestrian flows in an urban plaza"
        }
      },
      methods: {
        title: "From observation to mapped synthesis",
        body: "Our studies revolve around on-site observations, photographic logs, and graphic modelling to compare perception, usage, and spatial readability.",
        highlightTitle: "Four complementary layers",
        point1: "In-situ immersion to document sensory and acoustic cues.",
        point2: "Flow tracking via accompanied walks and discrete measuring tools.",
        point3: "Cartographic translation with density and accessibility indicators.",
        point4: "Actionable reporting tailored to strategic decision-making."
      },
      recommendations: {
        title: "Endorsed recommendations",
        body: "Our syntheses guide architects, urban designers, and technical teams as they adjust welcoming and informational devices.",
        item1: {
          title: "Reordering entrances and thresholds",
          body: "Restructuring signage in open-air halls instantly clarified access to priority services and reduced documented detours by 23%.",
          meta: "Excerpt from a Brussels civic building audit report"
        },
        item2: {
          title: "Modular interactive mapping",
          body: "A user-profiled cartographic foundation improved understanding of vertical links and reduced assistance requests during peaks.",
          meta: "Spatial UX summary for a healthcare campus"
        },
        item3: {
          title: "Light sequencing of routes",
          body: "Layered lighting cues paired with wall signage streamlined movements across three interconnected parking levels.",
          meta: "Recommendation applied in a multimodal interchange hub"
        }
      },
      testimonials: {
        title: "Field feedback",
        body: "Our expertise feeds operational teams and informs ongoing signage transformations.",
        item1: {
          quote: "Precise flow measurements translated into navigational scenarios helped us prioritise tangible interventions.",
          author: "Delphine H., Brussels municipal buildings department"
        },
        item2: {
          quote: "Workshops with cultural mediators uncovered sensory needs vital for visitors with reduced mobility.",
          author: "Mathieu C., Federal museum coordination"
        },
        item3: {
          quote: "The proposed protocol clarified interactions between info screens and physical signage within a dense railway hub.",
          author: "Nadia V., Walloon Region mobility unit"
        }
      },
      cta: {
        title: "Every site deserves a specific reading",
        body: "We document the singularities of each environment to build a consistent orientation grammar.",
        button: "Start a conversation"
      }
    },
    services: {
      hero: {
        title: "Approaches dedicated to complex environments",
        subtitle: "Our interventions align flow data, qualitative observation, and informational design to support public actors.",
        cta: "Schedule an exploratory call",
        secondary: "Browse publications",
        alt: "Analysis of a transit centre map"
      },
      summary: {
        title: "Services shaped for plural sites",
        body: "Every assignment mixes tailor-made modules: flow analysis, digital mapping, informational scenography, and methodological coaching."
      },
      list: {
        item1: {
          title: "Pedestrian flow analysis",
          body: "Observe, qualify, and model trajectories to understand friction points and contextual expectations.",
          point1: "Time-based and seasonal movement records.",
          point2: "Density maps and user profiles.",
          point3: "Identification of implicit orientation factors."
        },
        item2: {
          title: "Digital wayfinding design",
          body: "Define the role of screens, kiosks, and interactive supports in harmony with physical markers.",
          point1: "Usage scenarios by context and audience.",
          point2: "Dynamic content charter and messaging hierarchy.",
          point3: "Placement and maintenance recommendations."
        },
        item3: {
          title: "Spatial UX strategy",
          body: "Combine sensory, cognitive, and motor dimensions for seamless journeys from entrance to destination.",
          point1: "Mapping of critical decision points.",
          point2: "Workshops with front desk and maintenance teams.",
          point3: "UX indicators to monitor implementation."
        },
        item4: {
          title: "Information design consulting",
          body: "Clarify visual, typographic, and linguistic codes to align signage with architecture.",
          point1: "Readability audit of existing supports.",
          point2: "Multilingual editorial recommendations.",
          point3: "Alignment with regulatory constraints."
        },
        item5: {
          title: "Accessibility research",
          body: "Assess ease of use for all audiences, including people with reduced mobility or neurodiverse profiles.",
          point1: "Sensory diagnostics and targeted user testing.",
          point2: "Inclusive design guidelines for internal teams.",
          point3: "Accessibility indicator dashboards."
        }
      },
      process: {
        title: "Documented methodology",
        body: "Our workflow follows a transparent sequence: framing, observation, design, restitution. Each step is shared with project teams.",
        step1: {
          title: "Initial immersion",
          body: "Interviews, plan discovery, and institutional context review to set scope."
        },
        step2: {
          title: "Observation campaigns",
          body: "Flow measurement, photo logs, and user feedback fueling modelling."
        },
        step3: {
          title: "Cartographic synthesis",
          body: "Graphic translation of routes, friction points, and visual cue opportunities."
        },
        step4: {
          title: "Shared restitution",
          body: "Co-creation of roadmaps and evaluation frameworks for deployment."
        }
      },
      case: {
        title: "Deliverables in multiple formats",
        body: "Illustrated reports, interactive maps, restitution workshops: support formats adapt to your teams and timelines.",
        cta: "Share your site context"
      }
    },
    about: {
      hero: {
        title: "A team devoted to public space legibility",
        subtitle: "We bring together cartographers, information designers, and flow analysts to support public stakeholders.",
        alt: "Atrium with suspended signage"
      },
      mission: {
        title: "Mission of observation and transmission",
        body: "danswholesaleplants explores built environments to expose their orientation logic and propose concrete improvements. We work with cultural institutions, hospitals, campuses, and mobility infrastructures.",
        focusTitle: "Key attention points",
        focus1: "Understand how diverse audiences perceive space.",
        focus2: "Translate observations into actionable resources.",
        focus3: "Anticipate regulatory and technological shifts."
      },
      timeline: {
        title: "Chronological markers",
        body: "Our approach matured through multidisciplinary collaborations and pilot projects in Belgium and abroad.",
        entry1: {
          year: "2014",
          body: "First flow analysis assignments in justice and administrative buildings."
        },
        entry2: {
          year: "2017",
          body: "Launch of an interactive mapping unit for healthcare campuses."
        },
        entry3: {
          year: "2020",
          body: "Creation of a research programme on digital signage and multimodal journeys."
        },
        entry4: {
          year: "2023",
          body: "Formation of an urban observatory network across Brussels, Namur, and Liège."
        }
      },
      values: {
        title: "Principles that guide our studies",
        body: "Every mission follows an ethical and scientific framework ensuring nuanced insights.",
        item1: {
          title: "Analytical neutrality",
          body: "Collected data are thoroughly documented and contextualised to avoid rushed interpretations."
        },
        item2: {
          title: "Inclusive design",
          body: "Recommendations address sensory, cognitive, and motor abilities across audiences."
        },
        item3: {
          title: "Sustainable transfer",
          body: "Deliverables favour formats that internal teams can own and maintain."
        }
      },
      team: {
        title: "Laboratory organisation",
        body: "The team combines senior researchers, information designers, mapping specialists, and field coordinators.",
        structureTitle: "Core functions",
        structure1: "Research unit: data analysis, protocols, publications.",
        structure2: "Design unit: graphic modelling, visual narration, digital guidance.",
        structure3: "Field unit: on-site observation, participatory workshops, user testing."
      },
      cta: {
        title: "Share your observations",
        body: "Describe your site, constraints, and hypotheses so we can co-build a realistic study plan.",
        button: "Arrange a conversation"
      }
    },
    blog: {
      hero: {
        title: "Journal exploring public journeys",
        subtitle: "Each article merges field feedback, theoretical frameworks, and metrics to clarify navigation within complex sites.",
        alt: "Map displayed on a campus"
      },
      intro: {
        title: "Watch focused on spatial UX",
        body: "Posts cover signage, mapping, information design, and pedestrian flows to inform public decision-makers and designers."
      },
      posts: {
        post1: {
          title: "Modelling pedestrian movements in cultural complexes",
          excerpt: "A systematic approach to analyse visitor flows, integrate heritage constraints, and produce readable routes within cultural venues.",
          alt: "Visitors inside a modern museum"
        },
        post2: {
          title: "Aligning digital signage in intermodal hubs",
          excerpt: "Principles to coordinate screens, panels, and sensors across mobility hubs for smoother traveller experiences.",
          alt: "Signage within an intermodal station"
        },
        post3: {
          title: "Hybrid mapping for extended campuses",
          excerpt: "Link indoor and outdoor journeys through coherent mapping of university and healthcare facilities.",
          alt: "Plan of a university campus"
        },
        post4: {
          title: "Observing spatial UX with qualitative protocols",
          excerpt: "How accompanied walks, field diaries, and focus groups enrich navigation understanding.",
          alt: "Reading room with visitors"
        },
        post5: {
          title: "Access routes in evolving heritage sites",
          excerpt: "Studying signage, mediation, and guidance to produce readable paths in heritage settings.",
          alt: "Visitors at a heritage landmark"
        }
      },
      cta: {
        title: "Apply insights to your site",
        body: "We adapt these learnings to your conditions and the regulatory frameworks governing your infrastructure.",
        button: "Plan a discussion"
      }
    },
    contact: {
      hero: {
        title: "Tell us about your navigation challenges",
        subtitle: "Describe your building, audiences, and hypotheses so we can prepare a first shared review.",
        cta: "View contact options",
        secondary: "Browse frequent questions",
        alt: "Public building hall"
      },
      details: {
        title: "Direct contact",
        body: "We answer within two business days and can schedule a short videoconference to clarify your environment.",
        phoneLabel: "Phone",
        phoneValue: "+32 2 320 54 18",
        emailLabel: "Email",
        emailValue: "info@danswholesaleplants.com",
        addressLabel: "Address",
        addressValue: "Rue des Chartreux 62, 1000 Brussels, Belgium",
        hoursLabel: "Response hours",
        hoursValue: "Monday to Friday, 09:00 – 18:00"
      },
      form: {
        title: "Share your site context",
        body: "Provide the essentials so we can prepare an initial diagnostic proposal.",
        nameLabel: "Full name",
        namePlaceholder: "Enter your first and last name",
        emailLabel: "Email address",
        emailPlaceholder: "example@organisation.be",
        orgLabel: "Organisation",
        orgPlaceholder: "Structure, service, or department",
        topicLabel: "Type of enquiry",
        topicDefault: "Select an option",
        topicOption1: "Pedestrian flow audit",
        topicOption2: "Digital signage strategy",
        topicOption3: "Accessibility and guidance",
        topicOption4: "Another requirement",
        messageLabel: "Message",
        messagePlaceholder: "Describe key issues, site profile, and expected timelines",
        submit: "Send request"
      },
      map: {
        title: "Location of the observation centre",
        body: "Our base is in the Marolles district with fast access to Brussels’ main institutional hubs.",
        caption: "Map focused on the Brussels observation centre"
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        subtitle: "Detailed answers explaining our posture and how we explore complex environments.",
        alt: "View of a mobility hub"
      },
      intro: {
        title: "Understanding our intervention framework",
        body: "The answers below outline how we combine field studies, mapping analyses, and actionable recommendations."
      },
      items: {
        item1: {
          question: "Why measure pedestrian flows across several seasons?",
          answer: "Traffic rhythms influence how cues are perceived. Multi-sequence measurements reveal variations linked to schedules, events, and weather."
        },
        item2: {
          question: "How do you align physical and digital signage?",
          answer: "We define a readable hierarchy where screens, panels, and markings complement one another without overloading decision points."
        },
        item3: {
          question: "What data do you collect during observations?",
          answer: "We capture movement timelines, analytical sketches, user feedback, and contextual photography logs."
        },
        item4: {
          question: "Do you work only in Belgium?",
          answer: "Most missions are Belgian-based, yet we occasionally operate in other European cities when study conditions are appropriate."
        },
        item5: {
          question: "Do you provide post-study monitoring tools?",
          answer: "Yes, we deliver evaluation indicators and follow-up grids that your teams can update as adjustments unfold."
        },
        item6: {
          question: "How do you involve users?",
          answer: "Through accompanied walks, mapping workshops, and readability tests targeting various profiles, including reduced mobility audiences."
        },
        item7: {
          question: "Can you work during construction phases?",
          answer: "We adapt protocols to site access and safety constraints, intervening before, during, or after works."
        },
        item8: {
          question: "What deliverables do you share?",
          answer: "We provide illustrated reports, interactive maps, synthesis decks, and operational roadmaps."
        }
      },
      cta: {
        title: "Need a specific answer?",
        body: "Send us your question or suggest a meeting slot so we can address it precisely.",
        button: "Contact the team"
      }
    },
    terms: {
      hero: {
        title: "Terms of use",
        subtitle: "By accessing danswholesaleplants.com you agree to the conditions outlined below."
      },
      sections: {
        s1: {
          title: "1. Purpose",
          body1: "These terms define the rules governing access to and use of the danswholesaleplants.com website operated by danswholesaleplants.",
          body2: "By browsing the site, you accept these provisions without reservation."
        },
        s2: {
          title: "2. Site access",
          body1: "The site is accessible free of charge to users with an internet connection.",
          body2: "danswholesaleplants may suspend access for maintenance, upgrades, or technical incidents."
        },
        s3: {
          title: "3. Intellectual property",
          body1: "Content, trademarks, logos, texts, images, and graphics are protected by intellectual property laws.",
          body2: "Any reproduction or unauthorised use is strictly prohibited."
        },
        s4: {
          title: "4. Content usage",
          body1: "Information is provided for informational purposes only and does not constitute a contractual commitment.",
          body2: "Users agree not to distort content when quoting or referencing it."
        },
        s5: {
          title: "5. External contributions",
          body1: "When external contributions are published, their authors remain responsible for their statements.",
          body2: "danswholesaleplants reserves the right to remove contributions that breach these conditions."
        },
        s6: {
          title: "6. Hyperlinks",
          body1: "The site may include links to third-party resources beyond danswholesaleplants’ control.",
          body2: "Their presence does not imply approval of external content."
        },
        s7: {
          title: "7. Liability",
          body1: "danswholesaleplants strives to ensure information accuracy but cannot guarantee the absence of errors.",
          body2: "Users rely on the information at their own risk."
        },
        s8: {
          title: "8. Security",
          body1: "Users must protect their equipment from intrusions or viruses.",
          body2: "danswholesaleplants is not liable for damages caused to user equipment."
        },
        s9: {
          title: "9. Personal data",
          body1: "Browsing may involve data collection as described in our Privacy Policy.",
          body2: "Users can exercise their rights using the contact details provided in that policy."
        },
        s10: {
          title: "10. Cookies",
          body1: "Technical and analytical cookies may be stored on user devices.",
          body2: "Cookie management is detailed in the Cookie Policy."
        },
        s11: {
          title: "11. Changes",
          body1: "danswholesaleplants may amend these terms at any time.",
          body2: "Users are encouraged to review them regularly."
        },
        s12: {
          title: "12. Governing law",
          body1: "These terms are governed by Belgian law.",
          body2: "Any dispute falls under the jurisdiction of Brussels courts."
        },
        s13: {
          title: "13. Contact",
          body1: "For questions regarding the terms, contact info@danswholesaleplants.com.",
          body2: "We will respond within a reasonable timeframe."
        },
        s14: {
          title: "14. Effective date",
          body1: "These terms take effect from 15 January 2024.",
          body2: "They supersede all previous versions."
        }
      }
    },
    privacy: {
      hero: {
        title: "Privacy policy",
        subtitle: "Protection of personal data collected by danswholesaleplants."
      },
      sections: {
        s1: {
          title: "1. Data controller",
          body1: "The controller is danswholesaleplants, Rue des Chartreux 62, 1000 Brussels.",
          body2: "You can reach us at info@danswholesaleplants.com."
        },
        s2: {
          title: "2. Data collected",
          body1: "We collect identity details, professional contact information, and the content of submitted enquiries.",
          body2: "Anonymous usage data may also be gathered via analytical cookies."
        },
        s3: {
          title: "3. Purposes",
          body1: "Data is used to answer requests, schedule meetings, and improve the website.",
          body2: "Statistical data helps optimise navigation."
        },
        s4: {
          title: "4. Legal bases",
          body1: "Processing is based on legitimate interest to respond to your contact and on your consent when required.",
          body2: "Analytical cookies are activated only after explicit consent."
        },
        s5: {
          title: "5. Retention",
          body1: "Data related to communications is kept for three years from the last contact.",
          body2: "Aggregated analytical data is retained for 13 months."
        },
        s6: {
          title: "6. Recipients",
          body1: "Data is accessible to authorised members of danswholesaleplants.",
          body2: "No commercial transfer to third parties occurs."
        },
        s7: {
          title: "7. Processors",
          body1: "Certain technical operations may be entrusted to European processors compliant with GDPR.",
          body2: "They act on our instructions and may not reuse data for other purposes."
        },
        s8: {
          title: "8. Rights",
          body1: "You hold rights of access, rectification, erasure, objection, restriction, and portability.",
          body2: "To exercise them, email info@danswholesaleplants.com with your request."
        },
        s9: {
          title: "9. Security",
          body1: "Technical and organisational measures protect your data.",
          body2: "We review these measures regularly."
        },
        s10: {
          title: "10. Complaints",
          body1: "You may contact the Belgian Data Protection Authority (APD) to lodge a complaint.",
          body2: "We nevertheless invite you to contact us first to seek an amicable resolution."
        }
      }
    },
    cookiesPage: {
      hero: {
        title: "Cookie policy",
        subtitle: "Transparency about cookies used by danswholesaleplants."
      },
      sections: {
        s1: {
          title: "1. General principles",
          body1: "Cookies are small files stored on your device to facilitate browsing.",
          body2: "You are free to enable or disable non-essential cookies."
        },
        s2: {
          title: "2. Summary table",
          body1: "The table below describes cookies that may be stored on your device.",
          body2: "Information is updated on a regular basis."
        },
        s3: {
          title: "3. Consent management",
          body1: "Your choice is saved via a necessary cookie so you are not prompted on every visit.",
          body2: "You can adjust your choice anytime via the banner or by clearing cookies."
        },
        s4: {
          title: "4. Impact of refusal",
          body1: "Refusing preference or analytical cookies may reduce personalisation.",
          body2: "Essential content remains accessible regardless of your choice."
        },
        s5: {
          title: "5. Contact",
          body1: "For questions regarding this policy, email info@danswholesaleplants.com.",
          body2: "We will reply within a reasonable timeframe."
        }
      },
      table: {
        headers: {
          name: "Name",
          provider: "Provider",
          type: "Type",
          purpose: "Purpose",
          duration: "Duration"
        },
        rows: {
          necessary: {
            name: "consent_state",
            provider: "danswholesaleplants",
            type: "Technical",
            purpose: "Store your consent choices and selected language.",
            duration: "12 months"
          },
          preferences: {
            name: "layout_pref",
            provider: "danswholesaleplants",
            type: "Preferences",
            purpose: "Remember sections you visit to adapt display at your next visit.",
            duration: "6 months"
          },
          analytics: {
            name: "usage_metrics",
            provider: "danswholesaleplants",
            type: "Analytical",
            purpose: "Measure traffic and identify the most used navigation paths.",
            duration: "13 months"
          },
          marketing: {
            name: "publication_updates",
            provider: "danswholesaleplants",
            type: "Informational",
            purpose: "Share editorial updates about our external publications.",
            duration: "6 months"
          }
        }
      }
    },
    refund: {
      hero: {
        title: "Correction and revision policy",
        subtitle: "Procedures for adjusting informational deliverables issued by danswholesaleplants."
      },
      sections: {
        s1: {
          title: "1. Scope",
          body1: "This policy applies to deliverables produced during studies or advisory missions.",
          body2: "It does not cover freely accessible website content."
        },
        s2: {
          title: "2. Requesting a correction",
          body1: "Requests must be submitted in writing within thirty days following delivery.",
          body2: "They must specify the elements considered incomplete or inaccurate."
        },
        s3: {
          title: "3. Joint review",
          body1: "We arrange a discussion to clarify context and define the expected scope of correction.",
          body2: "A processing schedule is proposed after this review."
        },
        s4: {
          title: "4. Included corrections",
          body1: "Corrections addressing factual or graphic inaccuracies are covered without additional fees.",
          body2: "Updated deliverables mirror the original format."
        },
        s5: {
          title: "5. Out-of-scope adjustments",
          body1: "Requests involving new data collection or additional analysis require a dedicated scoping.",
          body2: "An addendum is issued before work begins."
        },
        s6: {
          title: "6. Processing time",
          body1: "Included corrections are completed within fifteen business days.",
          body2: "Out-of-scope adjustments follow the timeline agreed during scoping."
        },
        s7: {
          title: "7. Validation",
          body1: "Corrected deliverables are sent for validation.",
          body2: "Without feedback within seven days, they are deemed approved."
        },
        s8: {
          title: "8. Version tracking",
          body1: "We retain successive versions to ensure traceability.",
          body2: "Retention is limited to operational needs."
        },
        s9: {
          title: "9. Suspension",
          body1: "danswholesaleplants may suspend corrections if required information is missing.",
          body2: "Suspension ends once the necessary elements are received."
        },
        s10: {
          title: "10. Contact",
          body1: "Submit all requests to info@danswholesaleplants.com.",
          body2: "Please indicate the project title and original delivery date."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Disclaimer",
        subtitle: "Limits regarding the use of information published on danswholesaleplants.com."
      },
      sections: {
        s1: {
          title: "1. No guarantee",
          body1: "Information is provided for informational purposes and may change without notice.",
          body2: "danswholesaleplants does not guarantee completeness."
        },
        s2: {
          title: "2. User responsibility",
          body1: "Users are solely responsible for how they apply the information.",
          body2: "They must assess relevance for their specific context."
        },
        s3: {
          title: "3. External links",
          body1: "External links facilitate monitoring but remain outside our control.",
          body2: "danswholesaleplants is not liable for the reliability of these resources."
        },
        s4: {
          title: "4. Third-party content",
          body1: "Quotations from third parties remain under the responsibility of their authors.",
          body2: "danswholesaleplants cannot be held liable for referenced statements."
        },
        s5: {
          title: "5. Professional use",
          body1: "Content does not amount to professional or legal advice.",
          body2: "Users should consult their advisors before operational decisions."
        },
        s6: {
          title: "6. Contact",
          body1: "To flag content or request clarification, email info@danswholesaleplants.com.",
          body2: "We will address your enquiry promptly."
        }
      }
    },
    thankyou: {
      hero: {
        title: "We have received your message",
        subtitle: "Thank you for sharing these details. We will get back to you shortly with a first exchange proposal.",
        primary: "Return to homepage",
        secondary: "Browse our insights"
      }
    },
    posts: {
      post1: {
        title: "Modelling pedestrian movements in cultural complexes",
        intro1: "Major cultural venues combine generous surfaces, dense services, and heritage obligations. Understanding how visitors move is essential to guarantee a legible experience without compromising identity.",
        intro2: "Our research blends quantitative metrics, user narratives, and mapping outputs to represent journey diversity. It is not about counting heads but decoding decision-making at each branching point.",
        intro3: "Several Belgian institutions launched long-term observation campaigns to adapt their routes. Findings show technical devices must dialogue with sensory cues and spontaneous uses.",
        section1: {
          title: "Observing flows beyond raw numbers",
          p1: "We go beyond simple attendance metrics by segmenting flows by visitor type, time frame, and motivations. The aim is to detect rhythm variations, clustering, hesitations, and detours.",
          p2: "We combine manual counts, temporary sensors, and accompanied walks. Sensors quantify density while accompanied walks reveal cognitive anchors.",
          p3: "Data feeds a living map describing each area by footfall, visibility, and cue clarity. The approach highlights priority hotspots.",
          sub1: {
            title: "Role of micro-observation",
            p1: "Micro-interactions with signage matter: how long do visitors pause? Do they change direction after reading? Such events determine whether a device answers a specific question.",
            p2: "Micro-observation informs the hierarchy of future interventions and avoids over-specifying devices."
          }
        },
        section2: {
          title: "Working within heritage constraints",
          p1: "Belgian cultural complexes often reside in listed buildings. Signage must respect strict constraints, requiring close collaboration with architects and heritage managers.",
          p2: "We often favour freestanding devices deployed temporarily during seasonal peaks to guide flows without altering walls or sightlines.",
          p3: "Adjustable light cues also become subtle markers, especially in large galleries or vertical circulation zones.",
          sub1: {
            title: "Contributions of immersive tech",
            p1: "Augmented reality is sometimes cited as a universal fix. In practice we deploy it selectively for dedicated audiences, such as school groups or international visitors.",
            p2: "The priority is to maintain coherence between digital features and physical guidance without forcing personal equipment."
          }
        },
        section3: {
          title: "Measuring the effect of adjustments",
          p1: "After deploying new cues we evaluate impact on flows. Indicators include reduced hesitation, balanced visitor distribution, and fewer congestion points.",
          p2: "We also collect feedback from front-line teams who notice behaviour changes first. Their qualitative insights inspire further refinements.",
          p3: "Successful adjustments respect the venue’s identity. Rather than imposing uniform signage, we reinforce existing cues and make them clearer.",
          sub1: {
            title: "Sharing learnings internally",
            p1: "Each mission ends with a debriefing for the museum teams. We share updated plans, tracked indicators, and maintenance tips.",
            p2: "This knowledge transfer ensures long-term coherence and keeps cues meaningful."
          }
        },
        conclusion: {
          title: "Toward sensitive, informed navigation",
          p1: "Modelling pedestrian movement is not about drawing arrows on a plan. It requires listening to visitors, acknowledging heritage constraints, and assessing adjustments.",
          p2: "Belgian cultural complexes adopting this approach report smoother flows, fewer orientation queries, and higher visitor satisfaction."
        }
      },
      post2: {
        title: "Aligning digital signage in intermodal hubs",
        intro1: "Stations and intermodal hubs host flows of very different intensities: commuters, tourists, students, people with reduced mobility. Digital signage is gaining prominence.",
        intro2: "To be effective it must coordinate with physical supports and audio announcements. Harmonising requires balancing operational coherence with local adaptation.",
        intro3: "Belgium is developing ambitious intermodal nodes in Brussels, Namur, and Antwerp, offering living laboratories to test new setups.",
        section1: {
          title: "Mapping intermodal flows",
          p1: "Every transport mode imposes distinct rhythms and cues. We first map structural flows: trains, metro, buses, bikes, walkability.",
          p2: "Mapping reveals friction points where travellers hesitate or intersect. It guides the role assigned to each signage device.",
          p3: "Screens belong where decision-making is most complex. They complement rather than replace physical signage.",
          sub1: {
            title: "Leveraging real-time data",
            p1: "Screens may relay live updates: waiting times, lift status, platform occupancy. We display only actionable, timely content.",
            p2: "Message overload breeds confusion, so interfaces remain sober, hierarchical, and readable from afar."
          }
        },
        section2: {
          title: "Ensuring visual and linguistic coherence",
          p1: "Each transport operator has its own charter. Harmonisation requires aligning typefaces, colour codes, and translation accuracy.",
          p2: "In bilingual zones we maintain language parity while preserving readability. Standardised pictograms complement text.",
          p3: "Screens must likewise respect contrast and font sizes for low-vision users. We prototype several display scenarios before deployment.",
          sub1: {
            title: "Coordinating audio announcements",
            p1: "Coherence extends to public address systems. Audio messages should echo visual signage logic.",
            p2: "A drafting charter ensures each announcement conveys actionable details without saturating the soundscape."
          }
        },
        section3: {
          title: "Engaging on-site teams",
          p1: "Mobility agents are signage ambassadors. We co-build usage scenarios with them and collect post-deployment observations.",
          p2: "They spot areas where travellers still hesitate. Their feedback feeds a progressive adjustment roadmap.",
          p3: "Maintenance is crucial: an inactive or miscalibrated screen erodes trust. We provide clear monitoring protocols.",
          sub1: {
            title: "Tracking performance over time",
            p1: "Performance indicators include fewer information requests, faster platform discovery, and smoother transfers.",
            p2: "We share metrics with managers to refine the system during peak periods."
          }
        },
        conclusion: {
          title: "A hybrid, evolving system",
          p1: "Digital signage does not replace legacy cues. It strengthens them when roles are clearly defined and coordinated with other channels.",
          p2: "Intermodal hubs adopting this hybrid approach deliver smoother and more reassuring journeys irrespective of traveller familiarity."
        }
      },
      post3: {
        title: "Hybrid mapping for extended campuses",
        intro1: "University and healthcare campuses combine buildings, public areas, and underground links. Mapping must connect these layers to guide journeys.",
        intro2: "Hybrid maps mix geography, functional data, and sensory cues to bridge indoor and outdoor navigation.",
        intro3: "Our projects address evolving Belgian campuses where new facilities are grafted onto historic structures.",
        section1: {
          title: "Identifying dominant routes",
          p1: "We analyse movements by profile: students, staff, occasional visitors, patients. Each group follows distinct paths.",
          p2: "Analysis highlights structural axes that must stand out on the hybrid map.",
          p3: "Dominant routes form the plan’s skeleton. Secondary paths are prioritised according to importance.",
          sub1: {
            title: "Mapping thresholds and interfaces",
            p1: "Campuses host numerous thresholds: entrances, atriums, lifts, bridges. We map them meticulously to ease indoor/outdoor transitions.",
            p2: "Each threshold must be legible on the map and easy to locate on site."
          }
        },
        section2: {
          title: "Structuring cartographic information",
          p1: "A hybrid map cannot show everything. We layer information: structural cues first, specific services afterward.",
          p2: "Multiple floors are represented through dedicated diagrams connected to outdoor plans via colour codes.",
          p3: "We integrate standard pictograms and clear bilingual legends.",
          sub1: {
            title: "Ensuring accessible mapping",
            p1: "High contrast, legible typography, and simple symbols are essential. We test maps with diverse audiences.",
            p2: "Interactive digital versions allow detail levels to be tailored to user needs."
          }
        },
        section3: {
          title: "Keeping data up to date",
          p1: "Campuses constantly evolve. We set up regular updates with an internal coordinator overseeing modifications.",
          p2: "Digital and printed versions stay synchronised to avoid contradictions.",
          p3: "Indicators track map usage and information requests.",
          sub1: {
            title: "Sharing data in open formats",
            p1: "When policies allow, we publish mapping data openly to encourage innovation.",
            p2: "Student teams can then develop complementary tools: apps, guided paths, accessibility services."
          }
        },
        conclusion: {
          title: "Mapping to support navigation",
          p1: "A successful hybrid map simplifies journeys, clarifies campus structure, and reduces visitor stress.",
          p2: "It becomes a shared tool adopted across campus services."
        }
      },
      post4: {
        title: "Observing spatial UX with qualitative protocols",
        intro1: "Spatial legibility is not only about measuring flows. Understanding lived experience requires qualitative methods: observation, storytelling, workshops.",
        intro2: "These protocols give access to perceptions, sensations, and strategies people use to orient themselves.",
        intro3: "We combine them with quantitative indicators to build a complete navigation portrait.",
        section1: {
          title: "Selecting suitable qualitative tools",
          p1: "Accompanied walks involve following a user along a route while capturing commentary.",
          p2: "Field diaries allow reception staff to note recurring visitor difficulties.",
          p3: "Focus groups gather various profiles to discuss cues and obstacles.",
          sub1: {
            title: "Adapting to participant needs",
            p1: "Each tool is adapted to participant capacity and availability.",
            p2: "We foster a safe environment to elicit honest feedback."
          }
        },
        section2: {
          title: "Analysing verbatim",
          p1: "Recordings are transcribed and sorted by themes: confusion, satisfaction, sensory cues, missing data.",
          p2: "We cross verbatim with flow maps to pinpoint sensitive areas.",
          p3: "Key quotes appear in deliverables so user voices remain audible.",
          sub1: {
            title: "Limiting bias",
            p1: "We diversify participant profiles to prevent individual bias.",
            p2: "Sessions take place at different times and days to account for schedule variation."
          }
        },
        section3: {
          title: "Turning observations into action",
          p1: "Qualitative insights translate into concrete recommendations: repositioning panels, simplifying texts, adding sensory cues.",
          p2: "We prioritise according to impact and feasibility.",
          p3: "A follow-up plan monitors how improvements hold over time.",
          sub1: {
            title: "Involving internal teams",
            p1: "Results are shared during workshops so teams grasp the reasoning behind adjustments.",
            p2: "This collective ownership facilitates implementation and maintenance."
          }
        },
        conclusion: {
          title: "Spaces designed around their users",
          p1: "Qualitative protocols complete quantitative measures and humanise datasets.",
          p2: "They ensure spatial transformation aligns with real user journeys."
        }
      },
      post5: {
        title: "Access routes in evolving heritage sites",
        intro1: "Heritage sites welcome diverse audiences, sometimes in large numbers. Accessibility must reconcile preservation with present-day needs.",
        intro2: "Navigation is intricate: historic stairs, offset screens, multilingual signage. The goal is a fluid experience that respects the site.",
        intro3: "Recent Belgian projects demonstrate that progressive approaches reconcile conservation and inclusion.",
        section1: {
          title: "Assessing built constraints",
          p1: "We inventory barriers such as level changes, narrow passages, or variable lighting. Each constraint is mapped to reveal critical points.",
          p2: "Heritage guides join the analysis to preserve aesthetic coherence.",
          p3: "Constraint mapping underpins accessibility scenarios.",
          sub1: {
            title: "Managing visual clutter",
            p1: "In protected areas signage must remain discreet. We favour lightweight supports or timed light cues.",
            p2: "Graphic restraint respects heritage while remaining legible."
          }
        },
        section2: {
          title: "Designing inclusive routes",
          p1: "We propose itineraries for different profiles: barrier-free routes, sensory circuits, express visits.",
          p2: "Each itinerary comes with coherent information supports available on-site and online.",
          p3: "Audio guides and tactile plans complement visual signage.",
          sub1: {
            title: "Training hosting teams",
            p1: "Mediators receive training to direct visitors based on specific needs.",
            p2: "They use synthesis sheets and simplified maps."
          }
        },
        section3: {
          title: "Evaluating experience over time",
          p1: "Targeted surveys and regular observation track evolving use.",
          p2: "We adjust supports when new constraints emerge or flows change.",
          p3: "Documenting interventions ensures traceability.",
          sub1: {
            title: "Sharing findings",
            p1: "Feedback is shared with heritage services and local authorities.",
            p2: "It feeds a knowledge base for other heritage sites."
          }
        },
        conclusion: {
          title: "Preserving while welcoming",
          p1: "Heritage accessibility balances respect for the built fabric with visitor comfort.",
          p2: "A progressive, collaborative approach secures that balance over time."
        }
      }
    }
  }
};

function getNestedTranslation(lang, key) {
  const segments = key.split(".");
  let output = I18N[lang];
  for (const segment of segments) {
    if (output && Object.prototype.hasOwnProperty.call(output, segment)) {
      output = output[segment];
    } else {
      return null;
    }
  }
  return output;
}

function applyTranslations(lang) {
  const dictionary = I18N[lang] ? lang : DEFAULT_LANG;
  document.documentElement.setAttribute("lang", dictionary);

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const value = getNestedTranslation(dictionary, key);
    if (value !== null && value !== undefined) {
      el.textContent = value;
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const value = getNestedTranslation(dictionary, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("alt", value);
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const value = getNestedTranslation(dictionary, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("placeholder", value);
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria-label");
    const value = getNestedTranslation(dictionary, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("aria-label", value);
    }
  });

  const pageKey = document.body.getAttribute("data-page");
  if (pageKey) {
    const titleValue = getNestedTranslation(dictionary, `meta.${pageKey}.title`);
    if (titleValue) {
      document.title = titleValue;
    }
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      const descValue = getNestedTranslation(dictionary, `meta.${pageKey}.description`);
      meta.setAttribute("content", descValue || "");
    }
  }

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title");
    const value = getNestedTranslation(dictionary, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("title", value);
    }
  });

  document.querySelectorAll("[data-i18n-value]").forEach((el) => {
    const key = el.getAttribute("data-i18n-value");
    const value = getNestedTranslation(dictionary, key);
    if (value !== null && value !== undefined) {
      el.value = value;
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.getAttribute("data-i18n-meta");
    const value = getNestedTranslation(dictionary, key);
    if (value !== null && value !== undefined) {
      el.setAttribute("content", value);
    }
  });

  updateActiveLanguageButton(dictionary);
}

function updateActiveLanguageButton(lang) {
  document.querySelectorAll(".lang-switch").forEach((btn) => {
    const value = btn.getAttribute("data-lang");
    if (value === lang) {
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
}

function setLanguage(lang) {
  const dictionary = I18N[lang] ? lang : DEFAULT_LANG;
  localStorage.setItem(LANG_STORAGE_KEY, dictionary);
  applyTranslations(dictionary);
}

function initLanguage() {
  const stored = localStorage.getItem(LANG_STORAGE_KEY);
  const lang = stored && I18N[stored] ? stored : DEFAULT_LANG;
  applyTranslations(lang);
}

function initLanguageSwitch() {
  document.querySelectorAll(".lang-switch").forEach((button) => {
    button.addEventListener("click", () => {
      const lang = button.getAttribute("data-lang");
      setLanguage(lang);
    });
  });
}

function initNavToggle() {
  const toggle = document.querySelector(".mobile-toggle");
  const nav = document.querySelector(".primary-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    const isExpanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!isExpanded));
    nav.classList.toggle("open");
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

function initFadeInObserver() {
  const elements = document.querySelectorAll(".fade-in");
  const observer = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  elements.forEach((el) => observer.observe(el));
}

function showToast(message, type = "success") {
  const container = document.querySelector(".toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = `toast ${type === "error" ? "error" : "success"}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("fade");
    toast.addEventListener("transitionend", () => toast.remove());
  }, 4000);
}

function initForms() {
  const forms = document.querySelectorAll("form[data-validate]");
  if (!forms.length) return;
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      const lang = document.documentElement.getAttribute("lang") || DEFAULT_LANG;
      const invalidFields = Array.from(form.querySelectorAll("[required]")).filter((field) => {
        if (field.type === "checkbox" || field.type === "radio") {
          return !field.checked;
        }
        return !String(field.value || "").trim();
      });
      if (invalidFields.length > 0) {
        event.preventDefault();
        const message = getNestedTranslation(lang, "global.toasts.error");
        showToast(message || "Please complete required fields.", "error");
        invalidFields[0].focus();
      } else {
        const message = getNestedTranslation(lang, "global.toasts.success");
        showToast(message || "Message sent.", "success");
      }
    });
  });
}

function getStoredConsent() {
  const stored = localStorage.getItem(CONSENT_STORAGE_KEY);
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
}

function saveConsent(consent) {
  const payload = {
    necessary: true,
    preferences: Boolean(consent.preferences),
    analytics: Boolean(consent.analytics),
    marketing: Boolean(consent.marketing),
    decidedAt: new Date().toISOString()
  };
  localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(payload));
  return payload;
}

function applyConsentToBanner(consent) {
  const preferencesPanel = document.querySelector("[data-cookie-preferences]");
  if (!preferencesPanel) return;
  const toggles = preferencesPanel.querySelectorAll("[data-cookie-input]");
  toggles.forEach((toggle) => {
    const name = toggle.getAttribute("data-cookie-input");
    if (name === "necessary") {
      toggle.checked = true;
    } else {
      toggle.checked = Boolean(consent && consent[name]);
    }
  });
}

function hideCookieBanner() {
  const banner = document.querySelector("[data-cookie-banner]");
  if (banner) {
    banner.classList.remove("visible");
  }
}

function initCookies() {
  const banner = document.querySelector("[data-cookie-banner]");
  if (!banner) return;
  const manageButton = banner.querySelector("[data-cookie-manage]");
  const prefs = banner.querySelector("[data-cookie-preferences]");
  const accept = banner.querySelector("[data-cookie-accept]");
  const decline = banner.querySelector("[data-cookie-decline]");
  const save = banner.querySelector("[data-cookie-save]");

  const existingConsent = getStoredConsent();
  if (existingConsent) {
    applyConsentToBanner(existingConsent);
  } else {
    banner.classList.add("visible");
  }

  if (manageButton && prefs) {
    manageButton.addEventListener("click", () => {
      prefs.classList.toggle("active");
    });
  }

  if (accept) {
    accept.addEventListener("click", () => {
      const consent = saveConsent({ preferences: true, analytics: true, marketing: true });
      applyConsentToBanner(consent);
      hideCookieBanner();
    });
  }

  if (decline) {
    decline.addEventListener("click", () => {
      const consent = saveConsent({ preferences: false, analytics: false, marketing: false });
      applyConsentToBanner(consent);
      hideCookieBanner();
    });
  }

  if (save && prefs) {
    save.addEventListener("click", () => {
      const toggles = prefs.querySelectorAll("[data-cookie-input]");
      const values = { preferences: false, analytics: false, marketing: false };
      toggles.forEach((toggle) => {
        const name = toggle.getAttribute("data-cookie-input");
        if (name !== "necessary") {
          values[name] = toggle.checked;
        }
      });
      const consent = saveConsent(values);
      applyConsentToBanner(consent);
      hideCookieBanner();
    });
  }
}

function updateFooterYear() {
  const yearSpan = document.querySelector(".footer-year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initLanguageSwitch();
  initNavToggle();
  initFadeInObserver();
  initForms();
  initCookies();
  updateFooterYear();
});