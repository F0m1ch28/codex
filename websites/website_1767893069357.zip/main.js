document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('[data-nav]');

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            nav.classList.toggle('is-open');
        });

        nav.addEventListener('click', (event) => {
            if (event.target.closest('a') && nav.classList.contains('is-open')) {
                nav.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const yearElList = document.querySelectorAll('[data-year]');
    const currentYear = new Date().getFullYear();
    const displayYear = currentYear < 2025 ? 2025 : currentYear;
    yearElList.forEach((el) => {
        el.textContent = displayYear;
    });

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    const cookieAcceptLink = document.querySelector('[data-cookie-accept]');
    const COOKIE_KEY = 'lpp_cookie_consent';

    if (cookieBanner) {
        if (!localStorage.getItem(COOKIE_KEY)) {
            cookieBanner.classList.add('is-visible');
        }

        if (cookieAcceptLink) {
            cookieAcceptLink.addEventListener('click', (event) => {
                event.preventDefault();
                localStorage.setItem(COOKIE_KEY, 'accepted');
                cookieBanner.classList.remove('is-visible');
            });
        }
    }

    const searchInput = document.querySelector('[data-search-input]');
    const postList = document.querySelector('[data-post-list]');
    const loadMoreButton = document.querySelector('[data-load-more]');
    const POSTS_PER_BATCH = 6;
    let visibleCount = 0;

    const updateLoadMoreVisibility = () => {
        if (!postList || !loadMoreButton) return;
        const items = Array.from(postList.children).filter((item) => item.matches('[data-visible="true"]'));
        if (items.length >= Array.from(postList.children).length) {
            loadMoreButton.disabled = true;
        } else {
            loadMoreButton.disabled = false;
        }
    };

    const showNextBatch = () => {
        if (!postList) return;
        const items = Array.from(postList.children);
        const hiddenItems = items.filter((item) => item.getAttribute('data-visible') === 'false' && item.style.display !== 'none');
        hiddenItems.slice(0, POSTS_PER_BATCH).forEach((item) => {
            item.setAttribute('data-visible', 'true');
            item.style.display = '';
        });
        visibleCount = Array.from(postList.children).filter((item) => item.style.display !== 'none' && item.getAttribute('data-visible') === 'true').length;
        updateLoadMoreVisibility();
    };

    if (postList) {
        Array.from(postList.children).forEach((item) => {
            item.setAttribute('data-visible', 'false');
            item.style.display = '';
        });
        showNextBatch();
    }

    if (loadMoreButton) {
        loadMoreButton.addEventListener('click', () => {
            showNextBatch();
        });
    }

    const filterButtons = document.querySelectorAll('.filter-button');
    const applyFilter = (category) => {
        if (!postList) return;
        const items = Array.from(postList.children);
        items.forEach((item) => {
            const itemCategory = item.getAttribute('data-category');
            const title = item.getAttribute('data-title') || '';
            const matchesCategory = category === 'all' || itemCategory === category;
            const matchesSearch = !searchInput || searchInput.value.trim() === '' || title.toLowerCase().includes(searchInput.value.trim().toLowerCase());
            if (matchesCategory && matchesSearch) {
                item.style.display = '';
                item.setAttribute('data-visible', 'false');
            } else {
                item.style.display = 'none';
                item.setAttribute('data-visible', 'false');
            }
        });
        visibleCount = 0;
        showNextBatch();
    };

    if (filterButtons.length > 0) {
        filterButtons.forEach((button) => {
            button.addEventListener('click', () => {
                filterButtons.forEach((btn) => btn.classList.remove('is-active'));
                button.classList.add('is-active');
                const filter = button.getAttribute('data-filter');
                applyFilter(filter);
            });
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const activeFilter = document.querySelector('.filter-button.is-active');
            const filterValue = activeFilter ? activeFilter.getAttribute('data-filter') : 'all';
            applyFilter(filterValue);
        });
    }

    const articleContent = document.querySelector('[data-article-content]');
    const readingTimeEl = document.querySelector('[data-reading-time]');
    if (articleContent && readingTimeEl) {
        const text = articleContent.textContent || '';
        const words = text.trim().split(/\s+/).length;
        const minutes = Math.max(1, Math.round(words / 230));
        readingTimeEl.textContent = `${minutes} minute`;
        if (minutes !== 1) {
            readingTimeEl.textContent += 's';
        }
    }
});