document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('open');
            siteNav.classList.toggle('open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                siteNav.classList.remove('open');
                navToggle.classList.remove('open');
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 1024) {
                siteNav.classList.remove('open');
                navToggle.classList.remove('open');
            }
        });
    }

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    if (cookieBanner) {
        const storageKey = 'garglejral-cookie-consent';
        const storedDecision = localStorage.getItem(storageKey);
        if (!storedDecision) {
            cookieBanner.classList.remove('hidden');
        }
        const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
        const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'accepted');
                cookieBanner.classList.add('hidden');
            });
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'declined');
                cookieBanner.classList.add('hidden');
            });
        }
    }
});