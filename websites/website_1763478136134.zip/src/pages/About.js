import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const values = [
  {
    title: 'Sanfte Klarheit',
    description:
      'Wir kombinieren Selbstmitgefühl mit strukturierter Reflexion. So bleibt Achtsamkeit praxistauglich.'
  },
  {
    title: 'Evidenzbasiert',
    description:
      'Unsere Impulse orientieren sich an aktueller Emotionsforschung, Positiver Psychologie und Neurobiologie.'
  },
  {
    title: 'Alltagstauglich',
    description:
      'Wir denken in 5-Minuten-Einheiten, Mikro-Routinen und Tools, die auch in stressigen Zeiten funktionieren.'
  },
  {
    title: 'Inklusiv & respektvoll',
    description:
      'Sprache, Illustrationen und Beispiele sind bewusst vielfältig, damit sich unterschiedliche Lebensrealitäten wiederfinden.'
  }
];

const milestones = [
  {
    year: '2019',
    title: 'Idee & erste Workshops',
    description:
      'Loraveritas startete als Workshop-Reihe für Menschen, die Emotionen nicht länger unterdrücken, sondern verstehen wollten.'
  },
  {
    year: '2020',
    title: 'Digitale Bibliothek',
    description:
      'Entwicklung der ersten Tools & Checklisten. Wir machten die Inhalte in einer Online-Bibliothek zugänglich.'
  },
  {
    year: '2022',
    title: 'Community & Challenges',
    description:
      'Mit Challenges zu Stressregulation und Selbstkritik wuchs die Community auf über 2.000 Mitglieder.'
  },
  {
    year: '2023',
    title: 'Loraveritas Relaunch',
    description:
      'Integration von Audioimpulsen, Journaling-Serien und Team-Angeboten für Organisationen.'
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>Über Loraveritas | Mission & Haltung</title>
        <meta
          name="description"
          content="Loraveritas steht für achtsamen Umgang mit Emotionen. Erfahre mehr über Mission, Werte und das Team hinter der Plattform."
        />
      </Helmet>
      <section className="section">
        <div className={styles.hero}>
          <div className={styles.heroText}>
            <span className="badge">Über Loraveritas</span>
            <h1>Achtsamkeit, die im Alltag lebt.</h1>
            <p>
              Loraveritas ist aus der Frage entstanden, wie wir Emotionen ernst nehmen können – ohne sie
              zu dramatisieren oder zu verdrängen. Wir begleiten Dich auf Deinem Weg zu mehr innerer
              Klarheit, Schritt für Schritt, mit Mut und Freundlichkeit.
            </p>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Team, das gemeinsam Strategien entwickelt"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`section ${styles.mission}`}>
        <div className="sectionHeader">
          <h2>Unsere Mission</h2>
          <p>
            Wir machen bewusste Emotionsregulation zugänglich, verständlich und nachhaltig – für Dich,
            Dein Team und Deine Beziehungen.
          </p>
        </div>
        <div className={styles.missionGrid}>
          <article className={styles.missionCard}>
            <h3>Self Leadership stärken</h3>
            <p>
              Emotionen sind Wegweiser. Wir helfen Dir, diese Signale zu entschlüsseln, damit Du in
              herausfordernden Situationen handlungsfähig bleibst.
            </p>
          </article>
          <article className={styles.missionCard}>
            <h3>Strukturen statt Überforderung</h3>
            <p>
              Unsere Tools geben Dir Klarheit: Was genau passiert in Dir – und welche kleine Handlung
              bringt Dich zurück in Balance?
            </p>
          </article>
          <article className={styles.missionCard}>
            <h3>Verbindung fördern</h3>
            <p>
              Bewusste Kommunikation beginnt bei Dir. Wir geben Dir Leitfäden für Gespräche, die Verbindung
              statt Abstand schaffen.
            </p>
          </article>
        </div>
      </section>

      <section className={`section ${styles.values}`}>
        <div className="sectionHeader">
          <h2>Werte, die uns leiten</h2>
          <p>
            Jedes Angebot von Loraveritas ist aus diesen Haltungen heraus entwickelt – und daran messen wir
            uns täglich.
          </p>
        </div>
        <div className={`${styles.valueGrid} grid gridTwo`}>
          {values.map((value) => (
            <article className={styles.valueCard} key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={`section ${styles.timeline}`}>
        <div className="sectionHeader">
          <h2>Unser Weg bisher</h2>
          <p>Transparenz schafft Vertrauen. Hier ein Blick auf unsere wichtigsten Meilensteine.</p>
        </div>
        <div className={styles.timelineList}>
          {milestones.map((milestone) => (
            <div className={styles.timelineItem} key={milestone.year}>
              <span className={styles.timelineYear}>{milestone.year}</span>
              <div className={styles.timelineContent}>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default About;