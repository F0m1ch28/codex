import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const servicePackages = [
  {
    title: 'Solo Journey',
    subtitle: 'Selbstgesteuertes Lernen',
    features: [
      'Digitaler Leitfaden mit 4 Phasen',
      'Audioimpulse & Reflexionskarten',
      'Checklisten für Stressmomente',
      'Wöchentliche Fokus-E-Mails'
    ],
    investment: 'ab 39 € / Monat',
    highlight: 'Ideal für Dich allein'
  },
  {
    title: 'Guided Circles',
    subtitle: 'Begleitung in Kleingruppen',
    features: [
      'Live-Sessions mit Q&A',
      'Peer-Reflexion & Accountability',
      'Challenge-Formate (Stress, Selbstkritik)',
      'Optionale Voice-Support-Notizen'
    ],
    investment: 'ab 89 € / Monat',
    highlight: 'Stärkende Community'
  },
  {
    title: 'Team Experience',
    subtitle: 'Für Organisationen & Teams',
    features: [
      'Custom Workshops & Moderationskits',
      'Emotion & Konflikt-Playbooks',
      'Team-Retros & Check-in-Routinen',
      'Train-the-Coach Angebote'
    ],
    investment: 'auf Anfrage',
    highlight: 'Skalierbar & flexibel'
  }
];

const highlights = [
  {
    title: 'Alltagstaugliche Mikro-Routinen',
    description:
      'Wir denken in kleinen, machbaren Schritten. Ohne komplizierte Meditationen, dafür mit Werkzeugen für Deinen Kalender.'
  },
  {
    title: 'Sanfte Begleitung mit Struktur',
    description:
      'Ob allein oder im Team – unsere Formate geben Dir einen klaren Rahmen, ohne Druck aufzubauen.'
  },
  {
    title: 'Wissenschaftlich fundiert',
    description:
      'Wir übersetzen Erkenntnisse aus Psychologie, Embodiment & Habit Design in leicht verständliche Impulse.'
  }
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(1);

  return (
    <>
      <Helmet>
        <title>Programme & Begleitung | Loraveritas Angebote</title>
        <meta
          name="description"
          content="Entdecke die Loraveritas-Programme für bewusste Emotionsregulation – von Solo Journey bis Team Experience."
        />
      </Helmet>
      <section className="section">
        <div className={styles.hero}>
          <span className="badge">Angebote</span>
          <h1>Wähle die Begleitung, die zu Deinem Rhythmus passt.</h1>
          <p>
            Ob selbstgeführt, in einer unterstützenden Gruppe oder gemeinsam mit Deinem Team – Loraveritas
            bietet Dir Strukturen, die sich in Deinen Alltag einfügen.
          </p>
        </div>
        <div className={styles.packages}>
          {servicePackages.map((service, index) => (
            <article
              key={service.title}
              className={`${styles.packageCard} ${activeIndex === index ? styles.packageActive : ''}`}
              onMouseEnter={() => setActiveIndex(index)}
            >
              <div className={styles.packageHeader}>
                <span className={styles.packageHighlight}>{service.highlight}</span>
                <h2>{service.title}</h2>
                <p>{service.subtitle}</p>
              </div>
              <ul className={styles.featureList}>
                {service.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <div className={styles.packageFooter}>
                <span>{service.investment}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`section ${styles.highlights}`}>
        <div className="sectionHeader">
          <h2>Was uns wichtig ist</h2>
          <p>Wir verbinden Sanftheit mit Struktur – damit Wachstum sicher und nachhaltig möglich ist.</p>
        </div>
        <div className={styles.highlightGrid}>
          {highlights.map((item) => (
            <article className={styles.highlightCard} key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Services;