import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Imprint.module.css';

const Imprint = () => {
  return (
    <>
      <Helmet>
        <title>Impressum | Loraveritas</title>
        <meta
          name="description"
          content="Impressum von Loraveritas mit Angaben gemäß § 5 TMG."
        />
      </Helmet>
      <section className="section">
        <div className={styles.wrapper}>
          <h1>Impressum</h1>
          <h2>Angaben gemäß § 5 TMG</h2>
          <p>
            Loraveritas<br />
            Platzhalter-Adresse in Deutschland<br />
            E-Mail: <a href="mailto:Platzhalter E-Mail">Platzhalter E-Mail</a>
          </p>

          <h2>Verantwortlich für den Inhalt</h2>
          <p>Loraveritas, vertreten durch die Gründerin Lora Bergmann.</p>

          <h2>Haftung für Inhalte</h2>
          <p>
            Als Diensteanbieter sind wir für eigene Inhalte auf diesen Seiten nach den allgemeinen
            Gesetzen verantwortlich. Wir sind jedoch nicht verpflichtet, übermittelte oder gespeicherte
            fremde Informationen zu überwachen.
          </p>

          <h2>Haftung für Links</h2>
          <p>
            Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss
            haben. Für diese fremden Inhalte können wir keine Gewähr übernehmen.
          </p>

          <h2>Urheberrecht</h2>
          <p>
            Die durch Loraveritas erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen
            Urheberrecht. Beiträge Dritter sind als solche gekennzeichnet.
          </p>
        </div>
      </section>
    </>
  );
};

export default Imprint;