import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Emotionale Landkarten: Wie Du innere Muster erkennst',
    category: 'Reflexion',
    date: '20. Februar 2024',
    excerpt:
      'Selbsterkenntnis bedeutet, wiederkehrende Muster zu entdecken. Mit unserer Landkarte erkennst Du Trigger, Bedürfnisse und Ressourcen schneller.'
  },
  {
    title: 'Regulation in 5 Minuten: Meine liebsten Nervensystem-Minis',
    category: 'Alltag',
    date: '14. Februar 2024',
    excerpt:
      'Es müssen nicht 30 Minuten Meditation sein. Diese kurzen Übungen kannst Du zwischen E-Mails einbauen.'
  },
  {
    title: 'Gefühle im Team sichtbar machen',
    category: 'Teamwork',
    date: '06. Februar 2024',
    excerpt:
      'Ein Leitfaden für Team-Check-ins, damit Emotionen Raum haben und Projekte trotzdem vorankommen.'
  },
  {
    title: 'Wenn Selbstkritik laut wird: 4 Reframing-Techniken',
    category: 'Selbstfürsorge',
    date: '29. Januar 2024',
    excerpt:
      'Reframing bringt neue Perspektiven. Wir zeigen vier Varianten, die nicht toxisch-positiv sind.'
  }
];

const Blog = () => {
  const [activeCategory, setActiveCategory] = useState('Alle');
  const categories = ['Alle', ...new Set(posts.map((post) => post.category))];

  const filteredPosts =
    activeCategory === 'Alle' ? posts : posts.filter((post) => post.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Blog & Artikel | Loraveritas</title>
        <meta
          name="description"
          content="Inspiration für bewusste Emotionsregulation: Artikel zu Selbstreflexion, Teamarbeit und Alltag."
        />
      </Helmet>
      <section className="section">
        <div className={styles.hero}>
          <span className="badge">Blog & Artikel</span>
          <h1>Impulse für Deinen Emotionsalltag</h1>
          <p>
            Kurze Artikel, liebevoll recherchiert und praxisnah. Wir teilen Perspektiven, Tools und
            Geschichten aus der Community.
          </p>
        </div>
        <div className={styles.filters}>
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={`${styles.filterButton} ${
                activeCategory === category ? styles.filterActive : ''
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.postGrid}>
          {filteredPosts.map((post) => (
            <article key={post.title} className={styles.postCard}>
              <h2>{post.title}</h2>
              <div className={styles.meta}>
                <span>{post.category}</span>
                <span>{post.date}</span>
              </div>
              <p>{post.excerpt}</p>
              <button type="button">Zum Artikel</button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;