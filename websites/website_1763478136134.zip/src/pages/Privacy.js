import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Datenschutz | Loraveritas</title>
        <meta
          name="description"
          content="Datenschutzerklärung von Loraveritas – transparente Informationen zur Verarbeitung Deiner Daten."
        />
      </Helmet>
      <section className="section">
        <div className={styles.wrapper}>
          <h1>Datenschutz</h1>
          <p>
            Der Schutz Deiner personenbezogenen Daten ist uns wichtig. Wir behandeln Deine Daten
            vertraulich und entsprechend der gesetzlichen Vorschriften.
          </p>

          <h2>1. Verantwortliche Stelle</h2>
          <p>
            Loraveritas<br />
            Platzhalter-Adresse in Deutschland<br />
            E-Mail: <a href="mailto:Platzhalter E-Mail">Platzhalter E-Mail</a>
          </p>

          <h2>2. Zugriffsdaten</h2>
          <p>
            Bei jedem Zugriff auf unsere Plattform werden automatisch Informationen erfasst, die Dein
            Browser übermittelt (z. B. IP-Adresse, Datum, Uhrzeit, Browsertyp). Diese Daten sind nicht
            bestimmten Personen zuordenbar.
          </p>

          <h2>3. Kontaktaufnahme</h2>
          <p>
            Wenn Du uns kontaktierst, werden die von Dir gemachten Angaben gespeichert, um Deine Anfrage zu
            bearbeiten und Anschlussfragen zu beantworten.
          </p>

          <h2>4. Cookies</h2>
          <p>
            Wir nutzen essenzielle Cookies, um Benutzerfreundlichkeit und Sicherheitsfunktionen zu
            gewährleisten. Du kannst Cookies in Deinem Browser deaktivieren, wodurch einige Funktionen
            eingeschränkt sein können.
          </p>

          <h2>5. Rechte</h2>
          <p>
            Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, sowie
            Widerspruch und Datenübertragbarkeit. Wende Dich dazu bitte an uns.
          </p>

          <h2>6. Änderungen</h2>
          <p>
            Wir behalten uns vor, diese Datenschutzerklärung anzupassen, um sie an geänderte rechtliche
            Anforderungen anzupassen.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;