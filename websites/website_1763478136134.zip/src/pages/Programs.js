import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const programs = [
  {
    title: 'Stress Reset Journey',
    duration: '14 Tage',
    level: 'Sanfter Einstieg',
    description:
      'Tägliche Micro-Learnings, Nervensystem-Checks und Audio-Guides, damit Du Stress früh erkennst und regulierst.',
    focus: ['Atemanker', 'Grenzen setzen', 'Selbstcoaching']
  },
  {
    title: 'Konfliktklarheit Challenge',
    duration: '10 Tage',
    level: 'Intensive Praxis',
    description:
      'Reflexionsübungen, Gesprächsvorbereitungen und Nachsorge-Rituale für faire Kommunikation trotz starker Emotionen.',
    focus: ['Dialogkarten', 'Gefühlssprache', 'Selbstfürsorge']
  },
  {
    title: 'Selbstkritik sanft verwandeln',
    duration: '21 Tage',
    level: 'Deep Dive',
    description:
      'Audioimpulse und Journaling, die Deinen inneren Ton freundlich ausrichten und neue Überzeugungen verankern.',
    focus: ['Mindset Journaling', 'Embodiment', 'Reframing']
  },
  {
    title: 'Reizüberflutung navigieren',
    duration: '7 Tage',
    level: 'Akute Unterstützung',
    description:
      'Sensorische Notfallübungen, Schutzrituale und Übergangsanker für einen bewussten Umgang mit Reizen.',
    focus: ['Somatic Tools', 'Übergangsrituale', 'Energie-Management']
  }
];

const Programs = () => {
  return (
    <>
      <Helmet>
        <title>Programme & Challenges | Loraveritas</title>
        <meta
          name="description"
          content="Wähle aus Loraveritas Challenges und Programmen für Stress, Konflikte, Selbstkritik und Reizüberflutung – in Deinem Tempo."
        />
      </Helmet>
      <section className="section">
        <div className={styles.hero}>
          <span className="badge">Programme & Challenges</span>
          <h1>Dein Fokus, Deine Challenge</h1>
          <p>
            Kurze, wirksame Programme für unterschiedliche Emotions-Themen. Du kannst sie einzeln nutzen
            oder kombinieren – ganz nach Deiner aktuellen Lebenssituation.
          </p>
        </div>
        <div className={styles.programGrid}>
          {programs.map((program) => (
            <article key={program.title} className={styles.programCard}>
              <div>
                <h2>{program.title}</h2>
                <div className={styles.meta}>
                  <span>{program.duration}</span>
                  <span>{program.level}</span>
                </div>
                <p>{program.description}</p>
              </div>
              <div className={styles.focusTags}>
                {program.focus.map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Programs;