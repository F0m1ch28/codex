import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Menschen, die bewusster fühlen', value: 3600 },
  { label: 'Reflexionsminis', value: 124 },
  { label: 'Audio-Impulsstunden', value: 52 }
];

const benefits = [
  'Weniger impulsive Reaktionen in stressigen Momenten',
  'Mehr Klarheit bei Entscheidungen',
  'Verbesserte Dialoge und Beziehungen',
  'Stabilere innere Ruhe im turbulenten Alltag'
];

const processSteps = [
  {
    title: 'Spüren',
    description:
      'Du nimmst wahr, was in Dir passiert – ohne zu bewerten, dafür mit viel Freundlichkeit.'
  },
  {
    title: 'Verstehen',
    description:
      'Du entpackst die Botschaft Deiner Gefühle und findest Worte für das, was Dich bewegt.'
  },
  {
    title: 'Regulieren',
    description:
      'Du wählst bewusst aus kleinen, machbaren Strategien, um Balance zu schaffen.'
  },
  {
    title: 'Integrieren',
    description:
      'Du überträgst Deine Erkenntnisse in Alltagssituationen und wächst Schritt für Schritt.'
  }
];

const testimonials = [
  {
    name: 'Jasmin, 32',
    role: 'Product Designerin',
    quote:
      'Loraveritas hilft mir, Emotionen nicht mehr wegzuschieben. Ich fühle mich klarer und reagiere bewusster, selbst in hitzigen Meetings.',
    image: 'https://picsum.photos/200/200?random=11'
  },
  {
    name: 'Mariam, 41',
    role: 'Teamlead Customer Care',
    quote:
      'Die Mikro-Reflexionen sind Gold wert. Ich habe gelernt, innere Warnsignale früh wahrzunehmen und Grenzen respektvoll zu setzen.',
    image: 'https://picsum.photos/200/200?random=12'
  },
  {
    name: 'Lennard, 28',
    role: 'Gründer & Vater',
    quote:
      'Ich bin nicht mehr in Dauerschleife aus Stress. Die Tools helfen mir, präsent zu bleiben – auf der Arbeit und zu Hause.',
    image: 'https://picsum.photos/200/200?random=13'
  }
];

const team = [
  {
    name: 'Lora Bergmann',
    role: 'Gründerin & Emotionscoach',
    focus: 'Achtsame Selbstregulation, Systemisches Coaching, Storytelling',
    image: 'https://picsum.photos/400/400?random=21'
  },
  {
    name: 'Dr. Jonas Weber',
    role: 'Wissenschaftlicher Sparringspartner',
    focus: 'Emotionspsychologie, Habit Design, Evidenzbasierung',
    image: 'https://picsum.photos/400/400?random=22'
  },
  {
    name: 'Nadia Zimmer',
    role: 'Community & Inhalte',
    focus: 'Selbstfürsorge im Alltag, inklusives Schreiben, Barrierearme Formate',
    image: 'https://picsum.photos/400/400?random=23'
  }
];

const projectItems = [
  {
    title: 'Reset bei Stress-Alarm',
    category: 'Stress',
    description:
      'Ein 5-tägiges Mini-Programm, das Dich Schritt für Schritt aus der Überlastung holt und Deine Nervensystempflege stärkt.',
    image: 'https://picsum.photos/1200/800?random=31'
  },
  {
    title: 'Dialogklarheit bei Konflikten',
    category: 'Konflikte',
    description:
      'Toolkit für klare Grenzen, faire Gespräche und Nachsorge-Routinen – direkt anwendbar für Team und Privatleben.',
    image: 'https://picsum.photos/1200/800?random=32'
  },
  {
    title: 'Selbstkritik entkräften',
    category: 'Selbstkritik',
    description:
      'Reflexionsreise mit Audioimpulsen und Journaling, um Deinen inneren Ton liebevoller auszurichten.',
    image: 'https://picsum.photos/1200/800?random=33'
  },
  {
    title: 'Reizüberflutung regulieren',
    category: 'Reizüberflutung',
    description:
      'Ein sensorischer Notfallkoffer mit kurzen Interventionen, Visuals und Checklisten für akute Momente.',
    image: 'https://picsum.photos/1200/800?random=34'
  }
];

const faqs = [
  {
    question: 'Brauche ich Vorerfahrung mit Achtsamkeit oder Meditation?',
    answer:
      'Nein. Wir gestalten alle Inhalte so, dass Du ohne Vorerfahrung starten kannst. Du erhältst konkrete Hinweise, wie Du Dich Schritt für Schritt annäherst, ohne Dich zu überfordern.'
  },
  {
    question: 'Gibt es therapeutische Versprechen?',
    answer:
      'Nein. Loraveritas bietet Selbstreflexion und Bildung. Wir ersetzen keine medizinische oder psychotherapeutische Behandlung. Bei akuten Belastungen kontaktiere bitte professionelle Hilfe.'
  },
  {
    question: 'Wie viel Zeit sollte ich einplanen?',
    answer:
      'Viele Impulse dauern 5–10 Minuten. Wichtiger als die Dauer ist Deine Regelmäßigkeit. Wir empfehlen, kleine tägliche Routinen zu etablieren.'
  },
  {
    question: 'Kann ich Loraveritas im Team nutzen?',
    answer:
      'Ja. Wir stellen Moderationskarten, Workshop-Konzepte und Team-Reflexionen bereit. Melde Dich gerne, um gemeinsam passende Formate zu finden.'
  }
];

const blogPosts = [
  {
    title: 'Emotionen als Informationssystem: Was sie Dir wirklich sagen',
    excerpt:
      'Erfahre, wie Du feine Signale erkennst, ohne sie sofort wegzudrücken, und wie Du Deinen Alltag daran ausrichten kannst.',
    category: 'Selbstreflexion',
    date: '12. Februar 2024'
  },
  {
    title: 'Mikro-Routinen, die Deine Nervensystempflege stärken',
    excerpt:
      'Winzige Pausen, Atemanker und Übergangsrituale: So gelingt Regulation auch an vollgepackten Tagen.',
    category: 'Alltag',
    date: '05. Februar 2024'
  },
  {
    title: 'Konflikte liebevoll adressieren: 3 Fragen vor dem Gespräch',
    excerpt:
      'Bereite Dich mit klaren Leitfragen vor, bleibe bei Dir und schaffe Raum für Verbindung statt Drama.',
    category: 'Kommunikation',
    date: '29. Januar 2024'
  }
];

const Home = () => {
  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Alle');
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const durations = statsData.map((stat) => Math.max(1200, stat.value * 3));
    const startTime = performance.now();

    const animate = (now) => {
      const updated = statsData.map((stat, index) => {
        const progress = Math.min((now - startTime) / durations[index], 1);
        return Math.floor(progress * stat.value);
      });
      setStatValues(updated);
      if (updated.some((value, index) => value < statsData[index].value)) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeCategory === 'Alle'
      ? projectItems
      : projectItems.filter((item) => item.category === activeCategory);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Loraveritas | Weniger Gefühlschaos. Mehr innere Klarheit.</title>
        <meta
          name="description"
          content="Loraveritas begleitet Dich mit achtsamer Emotionsregulation, klaren Tools und Programmen, um innere Ruhe und bewusste Entscheidungen zu stärken."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <div className={styles.heroBadge}>Wissenschaftlich inspiriert · Alltagsnah · Ohne Esoterik</div>
          <h1>Weniger Gefühlschaos. Mehr innere Klarheit.</h1>
          <p>
            Loraveritas begleitet Dich dabei, Emotionen liebevoll zu verstehen statt sie zu verdrängen.
            Mit Mikro-Routinen, Reflexionsimpulsen und Tools, die in Deinen Alltag passen.
          </p>
          <div className={styles.heroActions}>
            <Link className="btnPrimary" to="/guide">
              Jetzt starten
            </Link>
            <Link className="btnSecondary" to="/contact">
              Emotionen bewusster erleben
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Menschen in ruhiger Besprechung mit Fokus"
            loading="lazy"
          />
        </div>
      </section>

      <section className={`${styles.stats} section`}>
        <div className="sectionHeader">
          <h2>Emotionen als Kompass – mit System und Sanftheit</h2>
          <p>
            Unsere Community wächst täglich. Gemeinsam entwickeln wir Selbstfürsorge-Routinen,
            die fühlbar bleiben und funktionieren.
          </p>
        </div>
        <div className={styles.statsGrid}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>{statValues[index]}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={`section ${styles.benefits}`}>
        <div className="sectionHeader">
          <h2>Was sich verändert, wenn Du Emotionen bewusst regulierst</h2>
          <p>Vier Effekte, die unsere Mitglieder immer wieder nennen.</p>
        </div>
        <div className={`${styles.benefitGrid} grid gridTwo`}>
          {benefits.map((benefit) => (
            <div className={styles.benefitCard} key={benefit}>
              <span className={styles.benefitIcon}>✶</span>
              <p>{benefit}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`section ${styles.process}`}>
        <div className="sectionHeader">
          <h2>So begleiten wir Dich Schritt für Schritt</h2>
          <p>
            Ein klarer Fahrplan, flexibel wählbar. Du steigst dort ein, wo Du gerade stehst und passt die
            Intensität Deinem Alltag an.
          </p>
        </div>
        <div className={`${styles.processGrid} grid gridTwo`}>
          {processSteps.map((step, index) => (
            <div className={styles.processCard} key={step.title}>
              <span className={styles.processStep}>0{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`section ${styles.testimonials}`}>
        <div className="sectionHeader">
          <h2>Echte Stimmen aus der Loraveritas Community</h2>
          <p>Menschen, die sich selbst achtsam priorisieren und neue Umgangsweisen mit Emotionen leben.</p>
        </div>
        <div className={styles.testimonialWrapper}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${
                activeTestimonial === index ? styles.testimonialActive : ''
              }`}
            >
              <img
                src={testimonial.image}
                alt={`Portrait von ${testimonial.name}`}
                loading="lazy"
              />
              <p className={styles.quote}>{testimonial.quote}</p>
              <span className={styles.author}>{testimonial.name}</span>
              <span className={styles.role}>{testimonial.role}</span>
            </article>
          ))}
          <div className={styles.testimonialControls}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                aria-label={`Testimonial ${index + 1} anzeigen`}
                className={`${styles.dot} ${activeTestimonial === index ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.team}`}>
        <div className="sectionHeader">
          <h2>Dein Begleitteam</h2>
          <p>
            Wir verbinden Psychologie, Habit Design und empathische Kommunikation – fokussiert auf
            machbare Schritte.
          </p>
        </div>
        <div className={`${styles.teamGrid} grid gridThree`}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <div className={styles.teamImageWrap}>
                <img src={member.image} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.focus}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`section ${styles.projects}`}>
        <div className="sectionHeader">
          <h2>Projekte & Fokusräume</h2>
          <p>Wähle nach Deinem Thema. Unsere Guides lassen sich einzeln oder kombiniert nutzen.</p>
        </div>
        <div className={styles.projectFilters}>
          {['Alle', 'Stress', 'Konflikte', 'Selbstkritik', 'Reizüberflutung'].map((category) => (
            <button
              type="button"
              key={category}
              className={`${styles.filterButton} ${
                activeCategory === category ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={`Projekt ${project.title}`} loading="lazy" />
                <span className={styles.projectCategory}>{project.category}</span>
              </div>
              <div className={styles.projectBody}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <Link className={styles.projectLink} to="/programs">
                  Mehr erfahren
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`section ${styles.faq}`}>
        <div className="sectionHeader">
          <h2>Fragen, die uns häufig erreichen</h2>
          <p>Transparente Antworten – damit Du gut entscheiden kannst, ob Loraveritas gerade passt.</p>
        </div>
        <div className={styles.faqList}>
          {faqs.map((faqItem, index) => (
            <div
              key={faqItem.question}
              className={`${styles.faqItem} ${openFaq === index ? styles.faqOpen : ''}`}
            >
              <button
                className={styles.faqQuestion}
                onClick={() => toggleFaq(index)}
                aria-expanded={openFaq === index}
              >
                {faqItem.question}
                <span aria-hidden>{openFaq === index ? '–' : '+'}</span>
              </button>
              {openFaq === index && <p className={styles.faqAnswer}>{faqItem.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={`sectionNarrow ${styles.blog}`}>
        <div className="sectionHeader">
          <h2>Neu im Blog</h2>
          <p>Kurze Impulse, reflektierte Perspektiven und praktische Mikro-Routinen.</p>
        </div>
        <div className={`${styles.blogGrid} grid gridThree`}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <span className={styles.blogCategory}>{post.category}</span>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <div className={styles.blogMeta}>
                <span>{post.date}</span>
                <Link to="/blog">Weiterlesen</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.cta} section`}>
        <div className={styles.ctaContent}>
          <h2>Starte Deine Reise zu mehr innerer Klarheit</h2>
          <p>
            Loraveritas führt Dich sanft und strukturiert durch Deinen Emotionsalltag. Mutig, freundlich
            und im Tempo, das sich gut anfühlt.
          </p>
          <div className={styles.ctaActions}>
            <Link className="btnPrimary" to="/services">
              Angebote entdecken
            </Link>
            <Link className="btnSecondary" to="/contact">
              Kostenloses Erstgespräch sichern
            </Link>
          </div>
          <span className={styles.ctaNote}>
            Kein Heilversprechen · Kein Esoterik-Schnickschnack · Einfach bewusster leben
          </span>
        </div>
      </section>

      <section className={`sectionNarrow ${styles.disclaimer}`}>
        <div className={styles.disclaimerCard}>
          <h3>Wichtiger Hinweis</h3>
          <p>
            Loraveritas bietet Unterstützung zur Selbstreflexion und zum bewussten Umgang mit Emotionen.
            Wir ersetzen keine medizinische oder psychotherapeutische Beratung. Wenn Du akute Belastungen
            erlebst, wende Dich bitte an medizinisches Fachpersonal oder Notrufstellen.
          </p>
        </div>
      </section>
    </>
  );
};

export default Home;