import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const tools = [
  {
    title: 'Gefühls-Check-in Karte',
    description:
      'Visualisiere Deinen inneren Zustand in drei Schichten: Körper, Emotion, Bedürfnis. Ideal für Morgen- oder Abendrituale.',
    format: 'PDF & Notion Template'
  },
  {
    title: 'Konflikt-Vorbereitungsbogen',
    description:
      'Strukturiert Deine Gedanken vor schwierigen Gesprächen: Trigger, Bedürfnisse, klare Bitte. Plus Nachsorge-Reminder.',
    format: 'PDF zum Ausfüllen'
  },
  {
    title: 'Nervensystem-Kit für zwischendurch',
    description:
      '10 Mikro-Übungen (1-5 Minuten) für unterwegs – mit Körperübungen, Atemanker und Fokuswechseln.',
    format: 'Audio & Karten'
  },
  {
    title: 'Selbstmitgefühl-Statements',
    description:
      'Formuliere liebevolle Sätze, die Dein Nervensystem beruhigen. Hilft gegen harsche Selbstkritik.',
    format: 'Audio + Print'
  },
  {
    title: 'Überforderungs-Notfallplan',
    description:
      'Erstelle Deinen individuellen SOS-Plan für Reizüberflutung: Warnsignale, Rückzugsorte, Unterstützung.',
    format: 'Canvas + Checkliste'
  }
];

const Tools = () => {
  return (
    <>
      <Helmet>
        <title>Tools & Checklisten | Loraveritas</title>
        <meta
          name="description"
          content="Lade Dir Tools & Checklisten für achtsame Emotionsregulation herunter – von Gefühls-Check-ins bis zu Notfallplänen."
        />
      </Helmet>
      <section className="section">
        <div className={styles.hero}>
          <span className="badge">Tools & Checklisten</span>
          <h1>Dein Werkzeugkasten für Selbstregulation</h1>
          <p>
            Alle Tools sind praxiserprobt und so gestaltet, dass Du sie sowohl digital als auch analog
            einsetzen kannst.
          </p>
        </div>
        <div className={styles.toolGrid}>
          {tools.map((tool) => (
            <article key={tool.title} className={styles.toolCard}>
              <h2>{tool.title}</h2>
              <p>{tool.description}</p>
              <span>{tool.format}</span>
              <button type="button">Tool anfragen</button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Tools;