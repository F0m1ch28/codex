import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const steps = [
  {
    title: '1. Emotion wahrnehmen',
    detail:
      'Nimm wahr, welche körperlichen Signale, Gedanken und Impulse auftauchen. Beschreibe sie in einfachen Worten, ohne sie zu bewerten.'
  },
  {
    title: '2. Kontext & Bedürfnis klären',
    detail:
      'Welche Situation hat die Emotion ausgelöst? Was ist Dir wichtig? Welche Werte oder Grenzen wurden berührt?'
  },
  {
    title: '3. Regulation wählen',
    detail:
      'Entscheide Dich bewusst für eine Mikro-Intervention: Atemanker, Körperübung, Journaling-Frage oder ein Mini-Ritual.'
  },
  {
    title: '4. Mit Dir verbunden bleiben',
    detail:
      'Check nach 10 Minuten erneut ein: Was hat sich verändert? Welche nächste kleine Handlung stärkt Dich jetzt?'
  }
];

const quickWins = [
  'Drei tiefe Atemzüge mit betonter Ausatmung (zieht Dein Nervensystem in Ruhe).',
  'Name it to tame it: Benenne Deine Emotion in einem Satz.',
  'Emotionstagebuch: Stichworte morgens oder abends notieren.',
  'Friendly check-in: „Was brauche ich gerade, damit ich gut für mich sorgen kann?“'
];

const Guide = () => {
  return (
    <>
      <Helmet>
        <title>Einfacher Leitfaden | Achtsames Emotionsmanagement</title>
        <meta
          name="description"
          content="Der Loraveritas Leitfaden führt Dich in vier Schritten durch achtsames Emotionsmanagement – mit Quick Wins für Deinen Alltag."
        />
      </Helmet>
      <section className="section">
        <div className={styles.hero}>
          <span className="badge">Leitfaden</span>
          <h1>Einfacher Leitfaden für achtsames Emotionsmanagement</h1>
          <p>
            Emotionen sind kein Problem, das gelöst werden muss. Sie sind Information. Der Loraveritas
            Leitfaden hilft Dir, diese Informationen zu hören und bewusst zu nutzen.
          </p>
        </div>

        <div className={styles.stepsGrid}>
          {steps.map((step) => (
            <article key={step.title} className={styles.stepCard}>
              <h2>{step.title}</h2>
              <p>{step.detail}</p>
            </article>
          ))}
        </div>

        <div className={styles.quickWins}>
          <h3>Quick Wins für unterwegs</h3>
          <ul>
            {quickWins.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <p className={styles.note}>
            Erinnerung: Sei sanft mit Dir. Der Leitfaden ist kein Wettbewerb, sondern eine Einladung, Dich
            besser kennenzulernen.
          </p>
        </div>
      </section>
    </>
  );
};

export default Guide;