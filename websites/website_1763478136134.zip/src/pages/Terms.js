import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Rechtliche Hinweise | Loraveritas</title>
        <meta
          name="description"
          content="Rechtliche Hinweise zu Nutzung, Haftungsausschluss und Verantwortung von Loraveritas."
        />
      </Helmet>
      <section className="section">
        <div className={styles.wrapper}>
          <h1>Rechtliche Hinweise</h1>
          <p>
            Loraveritas ist eine Plattform für Bildung, Selbstreflexion und achtsamen Umgang mit
            Emotionen. Wir bieten keine therapeutische, psychologische oder medizinische Behandlung.
          </p>

          <h2>Haftungsausschluss</h2>
          <p>
            Die Inhalte von Loraveritas wurden mit größter Sorgfalt erstellt und überprüft. Dennoch können
            wir keine Gewähr für die Vollständigkeit, Richtigkeit und Aktualität der Inhalte übernehmen.
            Die Nutzung der Inhalte erfolgt auf eigene Verantwortung.
          </p>

          <h2>Keine medizinische Beratung</h2>
          <p>
            Loraveritas ersetzt keine Ärztin, keinen Arzt, keine Psychotherapeutin oder Psychotherapeuten.
            Bei gesundheitlichen Beschwerden wende Dich bitte an medizinisches oder psychotherapeutisches
            Fachpersonal. In akuten Krisen kontaktiere bitte umgehend den Notruf.
          </p>

          <h2>Urheberrecht</h2>
          <p>
            Alle auf Loraveritas veröffentlichten Inhalte (Texte, Bilder, Grafiken, Downloads) unterliegen
            dem Urheberrecht. Jede Nutzung außerhalb der gesetzlich erlaubten Verwendung bedarf der
            vorherigen schriftlichen Zustimmung von Loraveritas.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;