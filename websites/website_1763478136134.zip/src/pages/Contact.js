import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte gib Deinen Namen an.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib Deine E-Mail-Adresse an.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Bitte prüfe Deine E-Mail-Adresse.';
    }
    if (!formData.message.trim()) newErrors.message = 'Wie dürfen wir Dich unterstützen?';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData({ name: '', email: '', topic: '', message: '' });
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Loraveritas</title>
        <meta
          name="description"
          content="Kontaktiere Loraveritas für Fragen zu Programmen, Tools und Kooperationen."
        />
      </Helmet>
      <section className="section">
        <div className={styles.wrapper}>
          <div className={styles.intro}>
            <span className="badge">Kontakt</span>
            <h1>Wir freuen uns auf Deine Nachricht</h1>
            <p>
              Teile uns mit, wobei Du Unterstützung brauchst. Wir melden uns innerhalb von zwei Werktagen
              bei Dir.
            </p>
            <div className={styles.contactDetails}>
              <span>📍 Platzhalter-Adresse in Deutschland</span>
              <a href="mailto:Platzhalter E-Mail">📧 Platzhalter E-Mail</a>
            </div>
            <p className={styles.reminder}>
              Hinweis: Loraveritas ersetzt keine medizinische oder psychotherapeutische Beratung.
            </p>
          </div>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className="formGroup">
              <label htmlFor="name">Name *</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={!!errors.name}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>
            <div className="formGroup">
              <label htmlFor="email">E-Mail *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={!!errors.email}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>
            <div className="formGroup">
              <label htmlFor="topic">Thema</label>
              <select id="topic" name="topic" value={formData.topic} onChange={handleChange}>
                <option value="">Bitte wählen</option>
                <option value="Solo Journey">Solo Journey</option>
                <option value="Guided Circles">Guided Circles</option>
                <option value="Team Experience">Team Experience</option>
                <option value="Tools & Checklisten">Tools & Checklisten</option>
                <option value="Kooperation">Kooperation</option>
              </select>
            </div>
            <div className="formGroup">
              <label htmlFor="message">Nachricht *</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={!!errors.message}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </div>
            <button className="btnPrimary" type="submit">
              Nachricht senden
            </button>
            {submitted && (
              <p className={styles.success}>
                Danke für Deine Nachricht! Wir melden uns schnellstmöglich bei Dir.
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default Contact;