import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.inner}>
        <div className={styles.brandColumn}>
          <div className={styles.logoWrap}>
            <span className={styles.logoMark}>LV</span>
            <span className={styles.logoText}>Loraveritas</span>
          </div>
          <p className={styles.description}>
            Bewusste Selbstregulation im Alltag. Loraveritas begleitet Dich mit klaren Impulsen
            und Werkzeugen – wissenschaftlich inspiriert, frei von Esoterik.
          </p>
          <p className={styles.disclaimer}>
            Hinweis: Loraveritas ersetzt keine medizinische oder psychotherapeutische Beratung.
          </p>
        </div>
        <div className={styles.columnGroup}>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Entdecken</h3>
            <ul className={styles.linkList}>
              <li><Link to="/guide">Einfacher Leitfaden</Link></li>
              <li><Link to="/programs">Programme & Challenges</Link></li>
              <li><Link to="/tools">Tools & Checklisten</Link></li>
              <li><Link to="/blog">Blog & Artikel</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Unternehmen</h3>
            <ul className={styles.linkList}>
              <li><Link to="/about">Über Loraveritas</Link></li>
              <li><Link to="/services">Begleitungsangebote</Link></li>
              <li><Link to="/contact">Kontakt</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Rechtliches</h3>
            <ul className={styles.linkList}>
              <li><Link to="/legal">Rechtliche Hinweise</Link></li>
              <li><Link to="/privacy">Datenschutz</Link></li>
              <li><Link to="/imprint">Impressum</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h3 className={styles.columnTitle}>Kontakt</h3>
            <address className={styles.address}>
              <span>Platzhalter-Adresse in Deutschland</span>
              <a href="mailto:Platzhalter E-Mail">Platzhalter E-Mail</a>
            </address>
            <Link className={styles.ctaButton} to="/contact">
              Schreib uns
            </Link>
          </div>
        </div>
      </div>
      <div className={styles.bottomRow}>
        <p>© {new Date().getFullYear()} Loraveritas. Alle Rechte vorbehalten.</p>
      </div>
    </footer>
  );
};

export default Footer;