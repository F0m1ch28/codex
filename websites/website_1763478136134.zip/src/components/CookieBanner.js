import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('lv_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('lv_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Wir nutzen Cookies, um Inhalte zu optimieren und anonymisierte Statistiken zu erhalten.
          Deine Daten bleiben bei uns geschützt. Mit Klick auf „Verstanden“ stimmst Du dem zu.
        </p>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Verstanden
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;