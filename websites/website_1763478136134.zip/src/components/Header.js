import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { to: '/', label: 'Start' },
  { to: '/guide', label: 'Leitfaden' },
  { to: '/programs', label: 'Programme' },
  { to: '/tools', label: 'Tools' },
  { to: '/blog', label: 'Blog' },
  { to: '/about', label: 'Über uns' },
  { to: '/contact', label: 'Kontakt' }
];

const Header = () => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const toggleMenu = () => setIsMobileOpen((prev) => !prev);
  const closeMenu = () => setIsMobileOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Loraveritas Startseite">
          <span className={styles.logoMark}>LV</span>
          <span className={styles.logoText}>Loraveritas</span>
        </Link>
        <nav className={styles.nav} aria-label="Hauptnavigation">
          <button
            type="button"
            className={styles.mobileToggle}
            aria-label="Hauptmenü umschalten"
            aria-expanded={isMobileOpen}
            onClick={toggleMenu}
          >
            <span className={styles.bar} />
            <span className={styles.bar} />
            <span className={styles.bar} />
          </button>
          <ul className={`${styles.navList} ${isMobileOpen ? styles.navListOpen : ''}`}>
            {navItems.map((item) => (
              <li key={item.to} className={styles.navItem}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                  }
                  onClick={closeMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;