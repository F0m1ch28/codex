import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | TechSolutions</title>
        <meta
          name="description"
          content="Review TechSolutions privacy policy outlining how we collect, use, and protect personal information shared through our website and services."
        />
      </Helmet>
      <section className={styles.policy}>
        <div className="layout">
          <h1>Privacy Policy</h1>
          <p className={styles.updated}>Last updated: January 1, 2024</p>

          <h2>Introduction</h2>
          <p>
            TechSolutions (“we”, “us”, “our”) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard personal information across our website and consulting services.
          </p>

          <h2>Information we collect</h2>
          <p>
            We may collect personal details such as your name, email address, phone number, company information, and any additional information you provide through contact forms or communications with our team.
          </p>

          <h2>How we use information</h2>
          <ul>
            <li>Respond to inquiries and provide requested services</li>
            <li>Improve our website, offerings, and customer experience</li>
            <li>Send relevant updates, insights, or event invitations</li>
            <li>Comply with legal obligations and enforce agreements</li>
          </ul>

          <h2>Information sharing</h2>
          <p>
            We do not sell personal data. We may share information with trusted partners who assist in delivering our services, subject to confidentiality obligations, or when required by law.
          </p>

          <h2>Data security</h2>
          <p>
            We implement administrative, technical, and physical safeguards designed to protect personal information against unauthorized access, alteration, or destruction.
          </p>

          <h2>Your choices</h2>
          <p>
            You may request access, correction, or deletion of your personal data by contacting us at <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>. You can opt out of marketing communications at any time by following the unsubscribe link or contacting us directly.
          </p>

          <h2>International transfers</h2>
          <p>
            If you access our services from outside the United States, note that your information may be transferred, stored, and processed in the United States where our servers are located.
          </p>

          <h2>Updates</h2>
          <p>
            We may update this policy periodically. Material changes will be notified on this page with an updated effective date.
          </p>

          <h2>Contact us</h2>
          <p>
            For any questions regarding this Privacy Policy, please contact us at <a href="mailto:info@techsolutions.com">info@techsolutions.com</a> or by mail at 123 Innovation Street, Tech Park, San Francisco, CA 94105.
          </p>
        </div>
      </section>
    </>
  );
}

export default Privacy;