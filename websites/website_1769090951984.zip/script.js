"use strict";

document.addEventListener("DOMContentLoaded", function () {
  var body = document.body;
  var navToggle = document.querySelector(".nav-toggle");
  var nav = document.querySelector("[data-nav]");
  var navOverlay = document.querySelector("[data-nav-overlay]");
  var header = document.querySelector(".site-header");

  var toastContainer = document.querySelector("[data-toast-container]");
  function showToast(message) {
    if (!toastContainer) {
      return;
    }
    var toast = document.createElement("div");
    toast.className = "form-toast";
    toast.textContent = message;
    toastContainer.appendChild(toast);
    requestAnimationFrame(function () {
      toast.classList.add("is-shown");
    });
    setTimeout(function () {
      toast.classList.remove("is-shown");
      setTimeout(function () {
        toast.remove();
      }, 400);
    }, 3200);
  }

  function closeNavigation() {
    if (!nav) {
      return;
    }
    nav.classList.remove("is-open");
    if (navToggle) {
      navToggle.setAttribute("aria-expanded", "false");
    }
    if (navOverlay) {
      navOverlay.classList.remove("is-active");
    }
    body.classList.remove("no-scroll");
  }

  if (navToggle && nav) {
    navToggle.addEventListener("click", function () {
      var expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", expanded ? "false" : "true");
      nav.classList.toggle("is-open");
      if (navOverlay) {
        navOverlay.classList.toggle("is-active");
      }
      body.classList.toggle("no-scroll", !expanded);
    });
  }

  if (navOverlay) {
    navOverlay.addEventListener("click", closeNavigation);
  }

  if (nav) {
    var navLinks = nav.querySelectorAll("a");
    navLinks.forEach(function (link) {
      link.addEventListener("click", closeNavigation);
    });
  }

  if (header) {
    window.addEventListener("scroll", function () {
      if (window.scrollY > 16) {
        header.classList.add("is-scrolled");
      } else {
        header.classList.remove("is-scrolled");
      }
    });
  }

  var animateElements = document.querySelectorAll("[data-animate]");
  if ("IntersectionObserver" in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.12
    });
    animateElements.forEach(function (el) {
      observer.observe(el);
    });
  } else {
    animateElements.forEach(function (el) {
      el.classList.add("is-visible");
    });
  }

  var forms = document.querySelectorAll("form.global-form");
  forms.forEach(function (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var message = form.getAttribute("data-toast-message") || "Dank je wel! We verwerken je bericht.";
      showToast(message);
      setTimeout(function () {
        window.location.href = form.getAttribute("action");
      }, 1400);
    });
  });

  var yearElements = document.querySelectorAll(".current-year");
  var currentYear = new Date().getFullYear();
  yearElements.forEach(function (element) {
    element.textContent = currentYear.toString();
  });

  var cookieBanner = document.querySelector("[data-cookie-banner]");
  var cookieAccept = document.querySelector("[data-cookie-accept]");
  var cookieDecline = document.querySelector("[data-cookie-decline]");
  var storageKey = "iiigloballl_cookie_preference";
  var savedPreference = localStorage.getItem(storageKey);

  if (cookieBanner) {
    if (savedPreference) {
      cookieBanner.classList.add("is-hidden");
    } else {
      setTimeout(function () {
        cookieBanner.classList.add("is-visible");
      }, 600);
    }
  }

  function handleCookieChoice(choice) {
    localStorage.setItem(storageKey, choice);
    if (cookieBanner) {
      cookieBanner.classList.remove("is-visible");
      setTimeout(function () {
        cookieBanner.classList.add("is-hidden");
      }, 320);
    }
    showToast("Cookiekeuze opgeslagen.");
  }

  if (cookieAccept) {
    cookieAccept.addEventListener("click", function () {
      handleCookieChoice("accepted");
    });
  }

  if (cookieDecline) {
    cookieDecline.addEventListener("click", function () {
      handleCookieChoice("declined");
    });
  }
});