import React from 'react';

const Section = ({ pretitle, title, subtitle, children, variant = 'default', id }) => {
  const sectionClass = `section ${variant === 'light' ? 'section--light' : ''}`;

  return (
    <section className={sectionClass} id={id}>
      <div className="container">
        {(pretitle || title || subtitle) && (
          <div className="section__header">
            {pretitle && <span className="section__pretitle">{pretitle}</span>}
            {title && <h2 className="section__title">{title}</h2>}
            {subtitle && <p className="section__subtitle">{subtitle}</p>}
          </div>
        )}
        {children}
      </div>
    </section>
  );
};

export default Section;