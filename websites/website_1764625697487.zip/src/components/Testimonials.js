import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const testimonials = [
  {
    name: 'Camila Torres',
    role: 'Product Manager, SaaS',
    company: 'Palermo',
    quoteEn:
      'The weekly CPI dashboards helped our team forecast ARS expenses with clarity.',
    quoteEs:
      'Los tableros semanales del IPC nos ayudaron a proyectar gastos en ARS con claridad.',
    avatar: 'https://picsum.photos/100/100?image=801'
  },
  {
    name: 'Julián Ricci',
    role: 'University Tutor',
    company: 'Recoleta',
    quoteEn:
      'Students quickly grasp monetary trends thanks to concise explainers and trackers.',
    quoteEs:
      'Les estudiantes comprenden las tendencias monetarias gracias a los explicadores y trackers.',
    avatar: 'https://picsum.photos/100/100?image=802'
  }
];

const Testimonials = () => {
  const { language } = useLanguage();

  return (
    <div className="testimonials">
      {testimonials.map((item) => (
        <article className="testimonial-card" key={item.name}>
          <div className="testimonial-card__profile">
            <img
              src={item.avatar}
              alt={`Portrait of ${item.name}`}
              width="64"
              height="64"
              loading="lazy"
            />
            <div>
              <strong>{item.name}</strong>
              <p style={{ margin: 0, color: '#475569', fontSize: '0.9rem' }}>
                {item.role} · {item.company}
              </p>
            </div>
          </div>
          <p style={{ color: '#1f2937', fontSize: '1rem', marginBottom: 0 }}>
            {language === 'en' ? item.quoteEn : item.quoteEs}
          </p>
        </article>
      ))}
    </div>
  );
};

export default Testimonials;