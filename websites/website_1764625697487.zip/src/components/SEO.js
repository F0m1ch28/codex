import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../context/LanguageContext';

const baseUrl = 'https://www.tuprogresohoy.com';

const SEO = ({ title, description, path = '/' }) => {
  const { language } = useLanguage();
  const canonicalUrl = `${baseUrl}${path}`;
  const altUrl = `${baseUrl}${path}${path.includes('?') ? '&' : '?'}lang=es-AR`;

  return (
    <Helmet>
      <html lang={language === 'en' ? 'en' : 'es-AR'} />
      <title>{title}</title>
      <link rel="canonical" href={canonicalUrl} />
      <link rel="alternate" hrefLang="en" href={canonicalUrl} />
      <link rel="alternate" hrefLang="es-AR" href={altUrl} />
      <meta name="description" content={description} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={canonicalUrl} />
    </Helmet>
  );
};

export default SEO;