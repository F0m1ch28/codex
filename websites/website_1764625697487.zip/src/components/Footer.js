import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Footer = () => {
  const { language } = useLanguage();

  return (
    <footer className="footer" role="contentinfo">
      <div className="container">
        <div className="footer__grid">
          <div>
            <h4 className="footer__title">Tu Progreso Hoy</h4>
            <p>
              {language === 'en'
                ? 'Datos verificados para planificar tu presupuesto. Decisiones responsables, objetivos nítidos.'
                : 'Datos verificados para planificar tu presupuesto. Decisiones responsables, objetivos nítidos.'}
            </p>
            <p>
              {language === 'en'
                ? 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
                : 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'}
            </p>
          </div>
          <div>
            <h4 className="footer__title">
              {language === 'en' ? 'Navigation' : 'Navegación'}
            </h4>
            <ul className="footer__list">
              <li>
                <Link to="/">{language === 'en' ? 'Home' : 'Inicio'}</Link>
              </li>
              <li>
                <Link to="/inflation">
                  {language === 'en' ? 'Inflation' : 'Inflación'}
                </Link>
              </li>
              <li>
                <Link to="/course">
                  {language === 'en' ? 'Course' : 'Curso'}
                </Link>
              </li>
              <li>
                <Link to="/resources">
                  {language === 'en' ? 'Resources' : 'Recursos'}
                </Link>
              </li>
              <li>
                <Link to="/contact">
                  {language === 'en' ? 'Contact' : 'Contacto'}
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="footer__title">
              {language === 'en' ? 'Compliance' : 'Cumplimiento'}
            </h4>
            <ul className="footer__list">
              <li>
                <Link to="/privacy">
                  {language === 'en' ? 'Privacy Policy' : 'Política de privacidad'}
                </Link>
              </li>
              <li>
                <Link to="/cookies">
                  {language === 'en' ? 'Cookie Policy' : 'Política de cookies'}
                </Link>
              </li>
              <li>
                <Link to="/terms">
                  {language === 'en' ? 'Terms of Service' : 'Términos de servicio'}
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="footer__title">
              {language === 'en' ? 'Contact' : 'Contacto'}
            </h4>
            <ul className="footer__list">
              <li>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</li>
              <li>+54 11 5555-1234</li>
              <li>
                <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
              </li>
              <li>
                {language === 'en'
                  ? 'Information confiable que respalda elecciones responsables sobre tu dinero.'
                  : 'Información confiable que respalda elecciones responsables sobre tu dinero.'}
              </li>
            </ul>
          </div>
        </div>
        <div className="footer__bottom">
          <span>© {new Date().getFullYear()} Tu Progreso Hoy.</span>
          <span>
            {language === 'en'
              ? 'We do not provide financial services.'
              : 'No proporcionamos servicios financieros.'}
          </span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;