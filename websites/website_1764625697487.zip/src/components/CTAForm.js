import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const CTAForm = () => {
  const { language } = useLanguage();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    focusArea: '',
    privacy: false
  });
  const [errors, setErrors] = useState({});
  const [doubleOptInConfirmed, setDoubleOptInConfirmed] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.fullName.trim()) {
      newErrors.fullName =
        language === 'en'
          ? 'Please enter your full name.'
          : 'Ingresa tu nombre completo.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email =
        language === 'en'
          ? 'Please enter a valid email.'
          : 'Ingresa un correo válido.';
    }
    if (!form.privacy) {
      newErrors.privacy =
        language === 'en'
          ? 'Please consent to data handling.'
          : 'Por favor acepta el manejo de datos.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStep(2);
  };

  const handleConfirm = () => {
    setDoubleOptInConfirmed(true);
    setTimeout(() => navigate('/thank-you'), 600);
  };

  const updateField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="form-card" id="trial">
      {step === 1 && (
        <>
          <h3 style={{ marginTop: 0 }}>
            {language === 'en'
              ? 'Get Your Free Trial Lesson'
              : 'Obtén tu clase de prueba gratuita'}
          </h3>
          <p style={{ color: '#475569', marginBottom: '1.5rem' }}>
            {language === 'en'
              ? 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.'
              : 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.'}
          </p>
          <form onSubmit={handleSubmit} noValidate>
            <div>
              <label htmlFor="trial-name">
                {language === 'en' ? 'Full name' : 'Nombre completo'}
              </label>
              <input
                id="trial-name"
                name="fullName"
                type="text"
                value={form.fullName}
                onChange={(e) => updateField('fullName', e.target.value)}
                autoComplete="name"
              />
              {errors.fullName && <p className="error-text">{errors.fullName}</p>}
            </div>
            <div>
              <label htmlFor="trial-email">
                Email
              </label>
              <input
                id="trial-email"
                name="email"
                type="email"
                value={form.email}
                onChange={(e) => updateField('email', e.target.value)}
                autoComplete="email"
              />
              {errors.email && <p className="error-text">{errors.email}</p>}
            </div>
            <div>
              <label htmlFor="trial-focus">
                {language === 'en'
                  ? 'Primary learning focus'
                  : 'Enfoque principal de aprendizaje'}
              </label>
              <select
                id="trial-focus"
                name="focusArea"
                value={form.focusArea}
                onChange={(e) => updateField('focusArea', e.target.value)}
              >
                <option value="">
                  {language === 'en'
                    ? 'Select a focus'
                    : 'Selecciona un enfoque'}
                </option>
                <option value="budgeting">
                  {language === 'en' ? 'Budgeting in ARS' : 'Presupuesto en ARS'}
                </option>
                <option value="inflation">
                  {language === 'en'
                    ? 'Inflation tracking'
                    : 'Seguimiento de inflación'}
                </option>
                <option value="fx">
                  {language === 'en'
                    ? 'Foreign exchange basics'
                    : 'Bases de tipo de cambio'}
                </option>
              </select>
            </div>
            <div>
              <label>
                <input
                  type="checkbox"
                  checked={form.privacy}
                  onChange={(e) => updateField('privacy', e.target.checked)}
                />{' '}
                {language === 'en'
                  ? 'I agree to receive the confirmation email and data handling policy.'
                  : 'Acepto recibir el correo de confirmación y la política de datos.'}
              </label>
              {errors.privacy && <p className="error-text">{errors.privacy}</p>}
            </div>
            <button type="submit" className="btn btn-primary">
              {language === 'en' ? 'Request Trial Lesson' : 'Solicitar clase de prueba'}
            </button>
          </form>
          <p className="notice">
            {language === 'en'
              ? 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
              : 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'}
          </p>
        </>
      )}

      {step === 2 && (
        <div aria-live="polite">
          <h3 style={{ marginTop: 0 }}>
            {language === 'en'
              ? 'Confirm your subscription'
              : 'Confirma tu suscripción'}
          </h3>
          <p style={{ color: '#475569' }}>
            {language === 'en'
              ? `We sent a confirmation email to ${form.email}. Click the button below after reviewing it to complete your double opt-in.`
              : `Enviamos un correo de confirmación a ${form.email}. Haz clic abajo después de revisarlo para completar el doble opt-in.`}
          </p>
          <button
            className="btn btn-primary"
            onClick={handleConfirm}
            disabled={doubleOptInConfirmed}
          >
            {language === 'en' ? 'I Confirmed via Email' : 'Ya confirmé por correo'}
          </button>
          {doubleOptInConfirmed && (
            <p className="success-message" aria-live="assertive">
              {language === 'en'
                ? 'Thank you! Redirecting to confirmation...'
                : '¡Gracias! Redirigiendo a la confirmación...'}
            </p>
          )}
          <p className="notice">
            {language === 'en'
              ? 'We do not provide financial services. This learning journey is for educational purposes only.'
              : 'No proporcionamos servicios financieros. Este recorrido educativo es solo con fines formativos.'}
          </p>
        </div>
      )}
    </div>
  );
};

export default CTAForm;