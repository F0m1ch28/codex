import React, { useState } from 'react';

const AccordionItem = ({ question, answer, index }) => {
  const [expanded, setExpanded] = useState(false);
  const contentId = `accordion-content-${index}`;
  const headerId = `accordion-header-${index}`;

  return (
    <div className="accordion__item">
      <button
        className="accordion__button"
        aria-expanded={expanded}
        aria-controls={contentId}
        id={headerId}
        onClick={() => setExpanded((prev) => !prev)}
      >
        {question}
        <span aria-hidden="true">{expanded ? '−' : '+'}</span>
      </button>
      {expanded && (
        <div
          className="accordion__panel"
          id={contentId}
          role="region"
          aria-labelledby={headerId}
        >
          {answer}
        </div>
      )}
    </div>
  );
};

const Accordion = ({ items }) => {
  return (
    <div className="accordion">
      {items.map((item, index) => (
        <AccordionItem key={item.question} index={index} {...item} />
      ))}
    </div>
  );
};

export default Accordion;