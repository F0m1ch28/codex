import React, { useEffect, useMemo, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const ExchangeWidget = () => {
  const { language } = useLanguage();
  const [rate, setRate] = useState(null);
  const [change, setChange] = useState(null);
  const [timestamp, setTimestamp] = useState(null);

  const simulatedHistory = useMemo(
    () => [
      { day: 'Mon', value: 0.00117 },
      { day: 'Tue', value: 0.00118 },
      { day: 'Wed', value: 0.00116 },
      { day: 'Thu', value: 0.00119 },
      { day: 'Fri', value: 0.00122 },
      { day: 'Sat', value: 0.00123 },
      { day: 'Sun', value: 0.00121 }
    ],
    []
  );

  useEffect(() => {
    const fetchData = async () => {
      try {
        const resp = await fetch(
          'https://api.exchangerate.host/latest?base=ARS&symbols=USD'
        );
        if (!resp.ok) throw new Error('Network error');
        const data = await resp.json();
        const latest = data?.rates?.USD;
        if (latest) {
          setRate(latest);
          const previous = simulatedHistory[simulatedHistory.length - 2].value;
          setChange(((latest - previous) / previous) * 100);
          setTimestamp(data.date);
        }
      } catch (error) {
        setRate(simulatedHistory[simulatedHistory.length - 1].value);
        setChange(0.0);
        setTimestamp('Simulated');
      }
    };

    fetchData();
  }, [simulatedHistory]);

  const formatRate = (value) =>
    value ? (1 / value).toFixed(2) : '...';

  const formatChange = (value) => {
    if (value === null) return '...';
    const rounded = value.toFixed(2);
    return `${rounded}%`;
  };

  return (
    <div className="data-panel" aria-live="polite">
      <div style={{ display: 'flex', justify-content: 'space-between', alignItems: 'flex-start', gap: '1.5rem' }}>
        <div>
          <h3 style={{ margin: '0 0 0.25rem' }}>
            {language === 'en' ? 'ARS → USD Tracker' : 'ARS → USD en tiempo real'}
          </h3>
          <p style={{ margin: 0, color: '#475569' }}>
            {language === 'en'
              ? 'Follow Argentine peso moves to anticipate course topics.'
              : 'Sigue los movimientos del peso para anticipar los contenidos del curso.'}
          </p>
        </div>
        <div>
          <span className="badge">
            {language === 'en' ? 'Live Data' : 'Dato en vivo'}
          </span>
        </div>
      </div>

      <div
        style={{
          marginTop: '1.25rem',
          display: 'grid',
          gap: '0.75rem',
          gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))'
        }}
      >
        <div className="card" style={{ boxShadow: 'none', border: '1px solid rgba(37,99,235,0.1)' }}>
          <strong>{language === 'en' ? '1 USD equals' : '1 USD equivale'}</strong>
          <p style={{ fontSize: '1.6rem', margin: '0.35rem 0', color: 'var(--color-secondary)' }}>
            {rate ? `${formatRate(rate)} ARS` : '...'}
          </p>
          <small style={{ color: '#475569' }}>
            {language === 'en' ? 'Source: exchangerate.host' : 'Fuente: exchangerate.host'}
          </small>
        </div>
        <div className="card" style={{ boxShadow: 'none', border: '1px solid rgba(37,99,235,0.1)' }}>
          <strong>{language === 'en' ? 'Day change' : 'Variación diaria'}</strong>
          <p
            style={{
              fontSize: '1.6rem',
              margin: '0.35rem 0',
              color: change >= 0 ? '#16a34a' : '#dc2626'
            }}
          >
            {formatChange(change)}
          </p>
          <small style={{ color: '#475569' }}>
            {language === 'en' ? 'vs. previous close' : 'vs. cierre previo'}
          </small>
        </div>
      </div>

      <div className="exchange-chart" role="img" aria-label="Seven-day ARS versus USD trend">
        {simulatedHistory.map((item) => (
          <div
            key={item.day}
            className="exchange-chart__bar"
            style={{ height: `${(item.value / 0.00125) * 100}%` }}
          >
            <span>{item.day}</span>
          </div>
        ))}
      </div>
      <small style={{ display: 'block', marginTop: '0.75rem', color: '#475569' }}>
        {language === 'en'
          ? `Last update: ${timestamp || 'Loading...'}`
          : `Última actualización: ${timestamp || 'Cargando...'}`}
      </small>
    </div>
  );
};

export default ExchangeWidget;