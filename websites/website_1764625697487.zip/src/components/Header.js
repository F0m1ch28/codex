import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import LanguageToggle from './LanguageToggle';
import { useLanguage } from '../context/LanguageContext';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const { language } = useLanguage();

  const navItems = [
    { to: '/', label: language === 'en' ? 'Home' : 'Inicio' },
    { to: '/inflation', label: language === 'en' ? 'Inflation' : 'Inflación' },
    { to: '/course', label: language === 'en' ? 'Course' : 'Curso' },
    { to: '/resources', label: language === 'en' ? 'Resources' : 'Recursos' },
    { to: '/contact', label: language === 'en' ? 'Contact' : 'Contacto' }
  ];

  return (
    <header className="navbar" role="banner">
      <div className="navbar__inner">
        <div className="navbar__logo">
          <NavLink to="/" aria-label="Tu Progreso Hoy Home">
            Tu Progreso Hoy
          </NavLink>
        </div>

        <button
          className="navbar__toggle"
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          ☰
        </button>

        <nav>
          <div
            id="primary-navigation"
            className={`navbar__menu ${menuOpen ? 'is-open' : ''}`}
            role="navigation"
          >
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `navbar__link ${isActive ? 'active' : ''}`
                }
                onClick={() => setMenuOpen(false)}
              >
                {item.label}
              </NavLink>
            ))}
            <LanguageToggle />
            <NavLink
              to="/#trial"
              className="btn btn-primary"
              onClick={() => setMenuOpen(false)}
            >
              {language === 'en' ? 'Get Free Trial Lesson' : 'Clase de prueba gratis'}
            </NavLink>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;