import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);
  const { language } = useLanguage();

  useEffect(() => {
    const flag = sessionStorage.getItem('tph_disclaimer_ack');
    if (!flag) {
      setOpen(true);
    }
  }, []);

  const closeModal = () => {
    sessionStorage.setItem('tph_disclaimer_ack', 'true');
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true">
      <div className="modal">
        <h3 className="modal__title">
          {language === 'en'
            ? 'Important Educational Disclaimer'
            : 'Aviso Educativo Importante'}
        </h3>
        <p className="modal__text">
          {language === 'en'
            ? 'We do not provide financial services. Tu Progreso Hoy shares market data and learning materials solely for educational purposes.'
            : 'No proporcionamos servicios financieros. Tu Progreso Hoy comparte datos de mercado y materiales de aprendizaje únicamente con fines educativos.'}
        </p>
        <div className="modal__actions">
          <button className="btn btn-outline" onClick={closeModal}>
            {language === 'en' ? 'I Understand' : 'Entiendo'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DisclaimerModal;