import React from 'react';

const MapFrame = () => (
  <div className="map-frame" role="img" aria-label="Map of Buenos Aires showing Tu Progreso Hoy location">
    <iframe
      title="Tu Progreso Hoy Location"
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.298661843156!2d-58.385184823536966!3d-34.60373835716836!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccaca3d01ffc7%3A0x4dab2326251c3*78!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1687000000000!5m2!1sen!2sar"
      width="100%"
      height="360"
      style={{ border: 0 }}
      allowFullScreen=""
      loading="lazy"
      referrerPolicy="no-referrer-when-downgrade"
    ></iframe>
  </div>
);

export default MapFrame;