import React from 'react';
import Header from './Header';
import Footer from './Footer';
import CookieBanner from './CookieBanner';
import DisclaimerModal from './DisclaimerModal';
import ScrollToTop from './ScrollToTop';

const Layout = ({ children }) => {
  return (
    <div className="app-wrapper">
      <ScrollToTop />
      <Header />
      <main id="main-content">{children}</main>
      <Footer />
      <CookieBanner />
      <DisclaimerModal />
    </div>
  );
};

export default Layout;