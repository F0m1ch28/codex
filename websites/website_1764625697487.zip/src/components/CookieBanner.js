import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const CookieBanner = () => {
  const { language } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('tph_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (value) => {
    localStorage.setItem('tph_cookie_consent', value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <h3 style={{ marginTop: 0 }}>
        {language === 'en' ? 'Cookie Preferences' : 'Preferencias de cookies'}
      </h3>
      <p style={{ marginBottom: 0 }}>
        {language === 'en'
          ? 'We use functional cookies to enhance learning analytics. You can accept or decline optional cookies at any time.'
          : 'Usamos cookies funcionales para mejorar los análisis educativos. Puedes aceptar o rechazar las cookies opcionales cuando desees.'}
      </p>
      <div className="cookie-banner__actions">
        <button
          className="cookie-banner__button cookie-banner__button--decline"
          onClick={() => handleChoice('declined')}
        >
          {language === 'en' ? 'Decline' : 'Rechazar'}
        </button>
        <button
          className="cookie-banner__button cookie-banner__button--accept"
          onClick={() => handleChoice('accepted')}
        >
          {language === 'en' ? 'Accept' : 'Aceptar'}
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;