import React from 'react';

const Hero = ({ image, title, subtitle, children, flagOverlay = false, badge }) => {
  return (
    <section
      className={`hero ${flagOverlay ? 'hero--flag' : ''}`}
      style={{ backgroundImage: `url(${image})` }}
    >
      <div className="hero__content">
        {badge && <div className="badge">{badge}</div>}
        <h1 className="hero__title">{title}</h1>
        {subtitle && <p className="hero__subtitle">{subtitle}</p>}
        {children}
      </div>
    </section>
  );
};

export default Hero;