const faqData = [
  {
    question: {
      en: 'How often are inflation dashboards refreshed?',
      es: '¿Con qué frecuencia se actualizan los tableros de inflación?'
    },
    answer: {
      en: 'Dashboards are automatically refreshed every 48 hours with official INDEC CPI data and leading FX indicators.',
      es: 'Los tableros se actualizan automáticamente cada 48 horas con datos oficiales de IPC del INDEC e indicadores líderes de FX.'
    }
  },
  {
    question: {
      en: 'Does Tu Progreso Hoy suggest specific investments?',
      es: '¿Tu Progreso Hoy sugiere inversiones específicas?'
    },
    answer: {
      en: 'No. Análisis transparentes y datos de mercado para decidir con seguridad. We deliver structured learning so you can build your own conclusions.',
      es: 'No. Análisis transparentes y datos de mercado para decidir con seguridad. Ofrecemos aprendizaje estructurado para que formes tus propias conclusiones.'
    }
  },
  {
    question: {
      en: 'What tools are required to take the course?',
      es: '¿Qué herramientas se necesitan para tomar el curso?'
    },
    answer: {
      en: 'You need a modern browser, spreadsheet software, and curiosity for economic signals in Argentina.',
      es: 'Necesitas un navegador moderno, software de hojas de cálculo y curiosidad por las señales económicas de Argentina.'
    }
  },
  {
    question: {
      en: 'Is support offered in Spanish?',
      es: '¿Se ofrece soporte en español?'
    },
    answer: {
      en: 'Yes, all sessions, transcripts, and Q&A forums are bilingual to ensure inclusive learning across Argentina.',
      es: 'Sí, todas las sesiones, transcripciones y foros de preguntas y respuestas son bilingües para asegurar aprendizaje inclusivo en Argentina.'
    }
  }
];

export default faqData;