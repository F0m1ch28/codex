import React from 'react';
import Hero from '../components/Hero';
import SEO from '../components/SEO';
import { useLanguage } from '../context/LanguageContext';

const NotFound = () => {
  const { language } = useLanguage();

  return (
    <>
      <SEO
        title="Page not found | Tu Progreso Hoy"
        description="The page you were looking for could not be found."
        path="/404"
      />
      <Hero
        image="https://picsum.photos/1200/600?image=100"
        title={language === 'en' ? 'Page not found' : 'Página no encontrada'}
        subtitle={
          language === 'en'
            ? 'Let’s get you back to the course and inflation resources.'
            : 'Volvamos al curso y a los recursos de inflación.'
        }
      >
        <a href="/" className="btn btn-primary">
          {language === 'en' ? 'Go home' : 'Ir al inicio'}
        </a>
      </Hero>
    </>
  );
};

export default NotFound;