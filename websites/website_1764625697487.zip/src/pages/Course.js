import React from 'react';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import Section from '../components/Section';
import SEO from '../components/SEO';
import { useLanguage } from '../context/LanguageContext';

const Course = () => {
  const { language } = useLanguage();

  const modules = [
    {
      title: language === 'en' ? 'Module 1 · Inflation Signals' : 'Módulo 1 · Señales de inflación',
      summary:
        language === 'en'
          ? 'Decode CPI releases, core indicators, and lagged effects across provinces.'
          : 'Decodifica los informes de IPC, indicadores núcleo y efectos rezagados en provincias.',
      image: 'https://picsum.photos/300/300?image=501'
    },
    {
      title: language === 'en' ? 'Module 2 · Responsible Budgeting' : 'Módulo 2 · Presupuesto responsable',
      summary:
        language === 'en'
          ? 'Design ARS budgets anchored on essential spending baskets in Buenos Aires.'
          : 'Diseña presupuestos en ARS basados en canastas esenciales porteñas.',
      image: 'https://picsum.photos/300/300?image=502'
    },
    {
      title: language === 'en' ? 'Module 3 · FX & Futures' : 'Módulo 3 · FX y futuros',
      summary:
        language === 'en'
          ? 'Understand FX curves, spreads, and hedging basics for decision-making.'
          : 'Comprende curvas FX, spreads y coberturas básicas para decidir.'
    },
    {
      title: language === 'en' ? 'Module 4 · Applied Labs' : 'Módulo 4 · Laboratorios aplicados',
      summary:
        language === 'en'
          ? 'Work through Buenos Aires case studies with bilingual facilitators.'
          : 'Trabaja casos porteños con facilitadores bilingües.',
      image: 'https://picsum.photos/300/300?image=503'
    }
  ];

  const audience = [
    language === 'en'
      ? 'Young professionals planning expenses in volatile ARS contexts.'
      : 'Jóvenes profesionales que planifican gastos en contextos volátiles de ARS.',
    language === 'en'
      ? 'University learners seeking to strengthen analytical reasoning about inflation.'
      : 'Estudiantes universitarios que desean reforzar su razonamiento analítico sobre la inflación.',
    language === 'en'
      ? 'Community leaders who need bilingual materials to explain economic shifts.'
      : 'Referentes comunitarios que necesitan materiales bilingües para explicar cambios económicos.'
  ];

  return (
    <>
      <SEO
        title="Course Syllabus | Tu Progreso Hoy"
        description="Explore our syllabus, modules, and bilingual labs to advance your financial literacy in Argentina."
        path="/course"
      />
      <Hero
        image="https://picsum.photos/1200/600?image=300"
        title={
          language === 'en'
            ? 'Course syllabus aligned with Argentina’s reality'
            : 'Programa del curso alineado con la realidad argentina'
        }
        subtitle={
          language === 'en'
            ? 'Explore learning modules, bilingual facilitation, and data labs designed for Argentinian learners.'
            : 'Explora módulos, facilitación bilingüe y laboratorios de datos diseñados para aprendices argentinos.'
        }
      >
        <Link to="/#trial" className="btn btn-primary">
          {language === 'en' ? 'Reserve free trial lesson' : 'Reservar clase gratuita'}
        </Link>
      </Hero>

      <Section
        pretitle={language === 'en' ? 'Curriculum map' : 'Mapa curricular'}
        title={
          language === 'en'
            ? 'Structured modules with weekly deliverables'
            : 'Módulos estructurados con entregables semanales'
        }
        subtitle={
          language === 'en'
            ? 'Each module blends lectures, dashboards, and coaching to keep you on track.'
            : 'Cada módulo combina clases, tableros y coaching para mantenerte encaminado.'
        }
      >
        <div className="grid grid--two">
          {modules.map((module) => (
            <article className="card" key={module.title}>
              {module.image && (
                <div className="card__media">
                  <img
                    src={module.image}
                    alt={module.title}
                    loading="lazy"
                    width="300"
                    height="300"
                  />
                </div>
              )}
              <h3 className="card__title">{module.title}</h3>
              <p className="card__text">{module.summary}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Who joins' : '¿Para quién?'}
        title={
          language === 'en'
            ? 'Designed for curious planners across Argentina'
            : 'Diseñado para planificadores curiosos en Argentina'
        }
        subtitle={
          language === 'en'
            ? 'Información confiable que respalda elecciones responsables sobre tu dinero.'
            : 'Información confiable que respalda elecciones responsables sobre tu dinero.'
        }
      >
        <div className="grid grid--two">
          <div>
            <img
              src="https://picsum.photos/400/300?image=702"
              alt="Learners engaging with digital dashboard"
              loading="lazy"
            />
          </div>
          <div>
            <h3>
              {language === 'en'
                ? 'Target audience'
                : 'Audiencia objetivo'}
            </h3>
            <ul className="list-check">
              {audience.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <p style={{ color: '#475569', marginTop: '1rem' }}>
              {language === 'en'
                ? 'We keep cohorts intimate to guarantee bilingual feedback and personal guidance.'
                : 'Mantenemos cohortes acotadas para garantizar feedback bilingüe y guía personal.'}
            </p>
          </div>
        </div>
      </Section>

      <Section
        pretitle={language === 'en' ? 'Educator team' : 'Equipo educativo'}
        title={
          language === 'en'
            ? 'Bilingual coaches based in Buenos Aires'
            : 'Coaches bilingües basados en Buenos Aires'
        }
        subtitle={
          language === 'en'
            ? 'Every facilitator connects live market signals with your assignments.'
            : 'Cada facilitador conecta señales del mercado en vivo con tus tareas.'
        }
      >
        <div className="grid grid--three">
          {[
            {
              name: 'Ana Beltrán',
              role: language === 'en' ? 'Lead Facilitator' : 'Facilitadora principal',
              bio:
                language === 'en'
                  ? 'Economist, ex-BCBA analyst, leading weekly inflation clinics.'
                  : 'Economista, ex analista BCBA, lidera clínicas semanales de inflación.',
              image: 'https://picsum.photos/300/300?image=501'
            },
            {
              name: 'Mariano Paredes',
              role: language === 'en' ? 'FX Research Coach' : 'Coach de investigación FX',
              bio:
                language === 'en'
                  ? 'Specialist in FX spreads, hedging basics, and spot vs. future comparisons.'
                  : 'Especialista en spreads FX, coberturas básicas y comparación spot vs futuros.',
              image: 'https://picsum.photos/300/300?image=502'
            },
            {
              name: 'Lucía Ocampo',
              role: language === 'en' ? 'Learning Designer' : 'Diseñadora de aprendizaje',
              bio:
                language === 'en'
                  ? 'Creates bilingual workbooks and adaptive assessments for each cohort.'
                  : 'Crea workbooks bilingües y evaluaciones adaptativas para cada cohorte.',
              image: 'https://picsum.photos/300/300?image=503'
            }
          ].map((coach) => (
            <article className="card" key={coach.name}>
              <div className="card__media">
                <img
                  src={coach.image}
                  alt={coach.name}
                  loading="lazy"
                  width="300"
                  height="300"
                />
              </div>
              <h3 className="card__title">{coach.name}</h3>
              <p style={{ color: '#2563EB', fontWeight: 600 }}>{coach.role}</p>
              <p className="card__text">{coach.bio}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Enroll now' : 'Inscríbete ahora'}
        title={
          language === 'en'
            ? 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.'
            : 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.'
        }
        subtitle={
          language === 'en'
            ? 'Secure your free trial and confirm via double opt-in to unlock the onboarding kit.'
            : 'Asegura tu clase gratuita y confirma con doble opt-in para acceder al kit de bienvenida.'
        }
      >
        <div className="card" style={{ textAlign: 'center' }}>
          <p style={{ color: '#475569' }}>
            {language === 'en'
              ? 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
              : 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'}
          </p>
          <Link to="/#trial" className="btn btn-primary">
            {language === 'en'
              ? 'Take me to the free trial form'
              : 'Ir al formulario de prueba gratis'}
          </Link>
        </div>
      </Section>
    </>
  );
};

export default Course;