import React from 'react';
import Hero from '../components/Hero';
import Section from '../components/Section';
import ExchangeWidget from '../components/ExchangeWidget';
import Testimonials from '../components/Testimonials';
import CTAForm from '../components/CTAForm';
import SEO from '../components/SEO';
import { useLanguage } from '../context/LanguageContext';

const Home = () => {
  const { language } = useLanguage();

  const insights = [
    {
      title:
        language === 'en'
          ? 'Daily inflation context'
          : 'Contexto de inflación diaria',
      text:
        language === 'en'
          ? 'We benchmark official CPI, private surveys, and wholesale FX to frame each weekly class.'
          : 'Contrastamos IPC oficial, relevamientos privados y FX mayorista para contextualizar cada clase semanal.',
      image: 'https://picsum.photos/400/300?image=701'
    },
    {
      title:
        language === 'en'
          ? 'City-wide expenses map'
          : 'Mapa de gastos en la ciudad',
      text:
        language === 'en'
          ? 'Compare essential baskets from Buenos Aires neighborhoods to tailor your budgeting exercises.'
          : 'Compara canastas esenciales de los barrios de Buenos Aires para personalizar tus ejercicios de presupuesto.',
      image: 'https://picsum.photos/400/300?image=702'
    },
    {
      title:
        language === 'en'
          ? 'Conocimiento financiero impulsado por tendencias.'
          : 'Conocimiento financiero impulsado por tendencias.',
      text:
        language === 'en'
          ? 'Blend narrative lessons with interactive dashboards to stay ahead of Argentina’s economic shifts.'
          : 'Combina lecciones narrativas y tableros interactivos para adelantarte a los cambios económicos de Argentina.',
      image: 'https://picsum.photos/800/500?image=600'
    }
  ];

  const promises = [
    'Datos verificados para planificar tu presupuesto.',
    'Decisiones responsables, objetivos nítidos.',
    'Pasos acertados hoy, mejor futuro mañana.',
    'Conocimiento financiero impulsado por tendencias.'
  ];

  return (
    <>
      <SEO
        title="Tu Progreso Hoy | ARS→USD Insights & Financial Learning"
        description="Conocimiento financiero impulsado por tendencias. Plan your budget, interpret inflation, and learn data-led strategies with Tu Progreso Hoy."
        path="/"
      />
      <Hero
        image="https://picsum.photos/1200/600?image=100"
        flagOverlay
        badge={language === 'en' ? 'Argentina Focus' : 'Enfoque Argentina'}
        title={
          language === 'en'
            ? 'Pasos acertados hoy, mejor futuro mañana.'
            : 'Pasos acertados hoy, mejor futuro mañana.'
        }
        subtitle={
          language === 'en'
            ? 'Curriculum-first learning paths powered by official Argentinian indicators, ARS→USD trackers, and bilingual guidance.'
            : 'Rutas de aprendizaje impulsadas por indicadores oficiales argentinos, trackers ARS→USD y acompañamiento bilingüe.'
        }
      >
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
          <a href="#trial" className="btn btn-primary">
            {language === 'en' ? 'Start free trial lesson' : 'Inicia clase de prueba'}
          </a>
          <a href="/inflation" className="btn btn-outline">
            {language === 'en' ? 'Explore inflation lab' : 'Explora el laboratorio de inflación'}
          </a>
        </div>
        <div className="stat-highlight">
          <div className="stat-highlight__item">
            <span className="stat-highlight__value">14+</span>
            <span className="stat-highlight__label">
              {language === 'en'
                ? 'hours of CPI dashboards & labs'
                : 'horas de tableros IPC y laboratorios'}
            </span>
          </div>
          <div className="stat-highlight__item">
            <span className="stat-highlight__value">12</span>
            <span className="stat-highlight__label">
              {language === 'en'
                ? 'weekly cohort sessions'
                : 'sesiones semanales por cohorte'}
            </span>
          </div>
          <div className="stat-highlight__item">
            <span className="stat-highlight__value">2</span>
            <span className="stat-highlight__label">
              {language === 'en'
                ? 'bilingual coaches in Buenos Aires'
                : 'coaches bilingües en Buenos Aires'}
            </span>
          </div>
        </div>
      </Hero>

      <Section
        pretitle={language === 'en' ? 'Key promises' : 'Compromisos claves'}
        title={
          language === 'en'
            ? 'Data-grounded guidance for responsible planning'
            : 'Orientación basada en datos para planificar responsablemente'
        }
        subtitle={
          language === 'en'
            ? 'Trust every insight and gain clarity with verified Argentinian sources curated for learners.'
            : 'Confía en cada insight y gana claridad con fuentes argentinas verificadas y curadas para estudiantes.'
        }
      >
        <div className="feature-list">
          {promises.map((promise) => (
            <article key={promise} className="feature-list__item">
              <h3 style={{ marginTop: 0, fontSize: '1.2rem' }}>{promise}</h3>
              <p style={{ color: '#475569' }}>
                {language === 'en'
                  ? 'Meaningful benchmarks, updated dashboards, and guided reflections anchor your progress.'
                  : 'Benchmark significativos, tableros actualizados y reflexiones guiadas sostienen tu progreso.'}
              </p>
            </article>
          ))}
        </div>
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Live markets' : 'Mercados en vivo'}
        title={
          language === 'en'
            ? 'ARS→USD tracker aligned with weekly learning themes'
            : 'Tracker ARS→USD alineado con temas semanales'
        }
        subtitle={
          language === 'en'
            ? 'Monitor the peso, connect shifts to CPI surprises, and adapt your budgeting simulations in real time.'
            : 'Monitorea el peso, conecta cambios con sorpresas del IPC y adapta tus simulaciones de presupuesto en tiempo real.'
        }
      >
        <ExchangeWidget />
      </Section>

      <Section
        pretitle={language === 'en' ? 'Insights' : 'Insights'}
        title={
          language === 'en'
            ? 'Learning blocks packed with actionable context'
            : 'Bloques de aprendizaje llenos de contexto accionable'
        }
        subtitle={
          language === 'en'
            ? 'Visual dashboards, narrative explainers, and Buenos Aires case studies combine for immersive practice.'
            : 'Tableros visuales, explicadores narrativos y casos de Buenos Aires se combinan para una práctica inmersiva.'
        }
      >
        <div className="grid grid--three">
          {insights.map((insight) => (
            <article className="card" key={insight.title}>
              <div className="card__media">
                <img
                  src={insight.image}
                  alt={insight.title}
                  width="400"
                  height="300"
                  loading="lazy"
                />
              </div>
              <h3 className="card__title">{insight.title}</h3>
              <p className="card__text">{insight.text}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Course overview' : 'Resumen del curso'}
        title={
          language === 'en'
            ? 'Argentina-focused curriculum to guide every learner'
            : 'Currículo enfocado en Argentina para cada estudiante'
        }
        subtitle={
          language === 'en'
            ? 'Follow learning modules crafted around macro drivers, FX trends, and responsible decision milestones.'
            : 'Sigue módulos diseñados alrededor de drivers macro, tendencias FX y hitos de decisiones responsables.'
        }
      >
        <div className="grid grid--two">
          <div>
            <img
              src="https://picsum.photos/400/300?image=701"
              alt="Students collaborating over financial dashboards"
              loading="lazy"
            />
          </div>
          <div>
            <h3>
              {language === 'en'
                ? 'Modular structure with guided labs'
                : 'Estructura modular con laboratorios guiados'}
            </h3>
            <ul className="list-check">
              <li>
                {language === 'en'
                  ? 'Module 1: Inflation anatomy through CPI, IPC Núcleo, and exchange rates.'
                  : 'Módulo 1: Anatomía de la inflación con IPC, IPC Núcleo y tipos de cambio.'}
              </li>
              <li>
                {language === 'en'
                  ? 'Module 2: Budgeting scenarios for Buenos Aires households with updated baskets.'
                  : 'Módulo 2: Escenarios de presupuesto para hogares porteños con canastas actualizadas.'}
              </li>
              <li>
                {language === 'en'
                  ? 'Module 3: FX sensitivity, hedging basics, and responsible choices.'
                  : 'Módulo 3: Sensibilidad al FX, coberturas básicas y decisiones responsables.'}
              </li>
            </ul>
          </div>
        </div>
      </Section>

      <Section
        pretitle={language === 'en' ? 'Voices from our learners' : 'Voces de quienes aprenden'}
        title={
          language === 'en'
            ? 'Information confiable que respalda elecciones responsables'
            : 'Información confiable que respalda elecciones responsables'
        }
        subtitle={
          language === 'en'
            ? 'Community leaders, product teams, and students share how Tu Progreso Hoy empowers better planning.'
            : 'Líderes comunitarios, equipos de producto y estudiantes comparten cómo Tu Progreso Hoy impulsa mejores planes.'
        }
      >
        <Testimonials />
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Free trial lesson' : 'Clase de prueba'}
        title={
          language === 'en'
            ? 'Ready to translate data into confident decisions?'
            : '¿Listo para transformar datos en decisiones seguras?'
        }
        subtitle={
          language === 'en'
            ? 'Información confiable que respalda elecciones responsables sobre tu dinero. Activate your double opt-in below.'
            : 'Información confiable que respalda elecciones responsables sobre tu dinero. Activa tu doble opt-in abajo.'
        }
      >
        <CTAForm />
      </Section>
    </>
  );
};

export default Home;