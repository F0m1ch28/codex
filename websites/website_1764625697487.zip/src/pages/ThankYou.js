import React from 'react';
import Hero from '../components/Hero';
import SEO from '../components/SEO';
import Section from '../components/Section';
import { useLanguage } from '../context/LanguageContext';

const ThankYou = () => {
  const { language } = useLanguage();

  return (
    <>
      <SEO
        title="Thank You | Tu Progreso Hoy"
        description="Confirmation received. Access the next steps to begin your Tu Progreso Hoy learning journey."
        path="/thank-you"
      />
      <Hero
        image="https://picsum.photos/1200/600?image=300"
        title={language === 'en' ? 'Thank you for confirming!' : '¡Gracias por confirmar!'}
        subtitle={
          language === 'en'
            ? 'Check your inbox for onboarding details and start date information.'
            : 'Revisa tu bandeja de entrada para ver los detalles de bienvenida y la fecha de inicio.'
        }
      >
        <span className="badge">
          {language === 'en' ? 'Double opt-in complete' : 'Doble opt-in completado'}
        </span>
      </Hero>

      <Section
        title={
          language === 'en'
            ? 'Next steps'
            : 'Próximos pasos'
        }
        subtitle={
          language === 'en'
            ? 'We do not provide financial services. All materials remain strictly educational.'
            : 'No proporcionamos servicios financieros. Todo el material es estrictamente educativo.'
        }
      >
        <div className="grid grid--two">
          <div className="card">
            <h3 className="card__title">
              {language === 'en'
                ? 'Access your dashboard'
                : 'Accede a tu tablero'}
            </h3>
            <p className="card__text">
              {language === 'en'
                ? 'We will email you a secure link to the CPI dashboards and learning schedule.'
                : 'Te enviaremos por correo un enlace seguro a los tableros de IPC y al cronograma de aprendizaje.'}
            </p>
          </div>
          <div className="card">
            <h3 className="card__title">
              {language === 'en'
                ? 'Join the community forum'
                : 'Únete al foro comunitario'}
            </h3>
            <p className="card__text">
              {language === 'en'
                ? 'Meet other planners, ask questions, and practice with budget simulations.'
                : 'Conoce a otros planificadores, haz preguntas y practica con simulaciones de presupuesto.'}
            </p>
          </div>
        </div>
      </Section>
    </>
  );
};

export default ThankYou;