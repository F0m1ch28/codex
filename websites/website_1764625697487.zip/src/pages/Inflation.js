import React from 'react';
import Hero from '../components/Hero';
import Section from '../components/Section';
import SEO from '../components/SEO';
import Accordion from '../components/Accordion';
import faqData from '../data/faqData';
import { useLanguage } from '../context/LanguageContext';

const Inflation = () => {
  const { language } = useLanguage();

  const localizedFaq = faqData.map((item) => ({
    question: language === 'en' ? item.question.en : item.question.es,
    answer: language === 'en' ? item.answer.en : item.answer.es
  }));

  const methodologyPoints = [
    {
      title:
        language === 'en'
          ? 'Official CPI + Private High Frequency'
          : 'IPC oficial + alta frecuencia privada',
      description:
        language === 'en'
          ? 'Weekly deep dives compare INDEC CPI, provincial data sets, Mercado Libre price crawls, and wholesale FX rates.'
          : 'Profundizaciones semanales comparan IPC del INDEC, conjuntos provinciales, crawlers de precios y FX mayorista.',
      image: 'https://picsum.photos/1200/600?image=200'
    },
    {
      title:
        language === 'en'
          ? 'Scenario modeling for learners'
          : 'Modelado de escenarios para estudiantes',
      description:
        language === 'en'
          ? 'Build ARS budget stress tests across food, transport, and energy baskets for Buenos Aires, Córdoba, and Rosario.'
          : 'Construye stress tests de presupuesto en ARS para canastas de alimentos, transporte y energía en Buenos Aires, Córdoba y Rosario.',
      image: 'https://picsum.photos/400/300?image=701'
    },
    {
      title:
        language === 'en'
          ? 'Análisis transparentes y datos de mercado para decidir con seguridad.'
          : 'Análisis transparentes y datos de mercado para decidir con seguridad.',
      description:
        language === 'en'
          ? 'Interactive dashboards show historical CPI, FX volatility, and real wage indices to frame long-term thinking.'
          : 'Los tableros interactivos muestran IPC histórico, volatilidad FX e índices de salario real para pensar a largo plazo.'
    }
  ];

  const cpiStats = [
    { label: language === 'en' ? 'Monthly CPI YoY' : 'IPC interanual', value: '142.7%' },
    { label: language === 'en' ? 'Core CPI YoY' : 'IPC Núcleo interanual', value: '131.3%' },
    { label: language === 'en' ? 'Blue FX variance (30d)' : 'Varianza blue (30 días)', value: '18.5%' },
    { label: language === 'en' ? 'Real wage index' : 'Índice salario real', value: '-4.2%' }
  ];

  return (
    <>
      <SEO
        title="Argentina Inflation Methodology | Tu Progreso Hoy"
        description="Dive into CPI, FX contexts, and methodological transparency for Argentina. Weekly refreshed dashboards and bilingual explainers."
        path="/inflation"
      />
      <Hero
        image="https://picsum.photos/1200/600?image=200"
        title={
          language === 'en'
            ? 'Inflation methodology built for learners'
            : 'Metodología de inflación para aprendices'
        }
        subtitle={
          language === 'en'
            ? 'Methodical CPI, FX, and wage analysis to decode Argentina’s inflation signals.'
            : 'Análisis metódico de IPC, FX y salarios para decodificar las señales de inflación en Argentina.'
        }
      />

      <Section
        pretitle={language === 'en' ? 'Methodology' : 'Metodología'}
        title={
          language === 'en'
            ? 'Transparent methodologies across every dashboard'
            : 'Metodologías transparentes en cada tablero'
        }
        subtitle={
          language === 'en'
            ? 'We blend official sources with high-frequency datasets so you interpret each indicator responsibly.'
            : 'Mezclamos fuentes oficiales con datos de alta frecuencia para que interpretes cada indicador con responsabilidad.'
        }
      >
        <div className="grid grid--three">
          {methodologyPoints.map((point) => (
            <article className="card" key={point.title}>
              {point.image && (
                <div className="card__media">
                  <img
                    src={point.image}
                    alt={point.title}
                    loading="lazy"
                    width="400"
                    height="300"
                  />
                </div>
              )}
              <h3 className="card__title">{point.title}</h3>
              <p className="card__text">{point.description}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Current CPI & FX context' : 'Contexto CPI y FX'}
        title={
          language === 'en'
            ? 'Key inflation signals at a glance'
            : 'Señales claves de inflación'
        }
        subtitle={
          language === 'en'
            ? 'Reconciling inflation with FX pressures, wages, and Argentine household realities.'
            : 'Reconciliamos la inflación con presiones FX, salarios y realidades de hogares argentinos.'
        }
      >
        <div className="grid grid--two">
          <div className="data-panel">
            <h3 style={{ marginTop: 0 }}>
              {language === 'en' ? 'CPI Heatmap' : 'Mapa de calor del IPC'}
            </h3>
            <div className="grid grid--two" style={{ marginTop: '1rem' }}>
              {cpiStats.map((stat) => (
                <div
                  key={stat.label}
                  className="card"
                  style={{
                    background: 'linear-gradient(160deg, #1f3a6f 0%, #2563eb 60%)',
                    color: '#f8fafc',
                    boxShadow: 'none',
                    border: 'none'
                  }}
                >
                  <strong style={{ fontSize: '0.9rem', opacity: 0.85 }}>
                    {stat.label}
                  </strong>
                  <span style={{ fontSize: '1.8rem', fontWeight: 700 }}>{stat.value}</span>
                </div>
              ))}
            </div>
            <p style={{ color: '#475569', marginTop: '1rem' }}>
              {language === 'en'
                ? 'Figures reflect the latest published data. Activities guide you on how to verify each indicator before using it in your decisions.'
                : 'Las cifras reflejan los últimos datos publicados. Las actividades te guían para verificar cada indicador antes de usarlo en tus decisiones.'}
            </p>
          </div>
          <div>
            <h3>
              {language === 'en'
                ? 'Timeline: From CPI release to classroom'
                : 'Línea de tiempo: del dato al aula'}
            </h3>
            <div className="timeline">
              <div className="timeline__item">
                <strong>
                  {language === 'en'
                    ? 'Day 0 – INDEC CPI release'
                    : 'Día 0 – Publicación IPC INDEC'}
                </strong>
                <p style={{ margin: '0.35rem 0 0', color: '#475569' }}>
                  {language === 'en'
                    ? 'We source official tables and translate them into actionable dashboards within hours.'
                    : 'Obtenemos las tablas oficiales y las traducimos a tableros accionables en pocas horas.'}
                </p>
              </div>
              <div className="timeline__item">
                <strong>
                  {language === 'en'
                    ? 'Day 1 – Cross-check with FX & wholesale prices'
                    : 'Día 1 – Contraste con FX y precios mayoristas'}
                </strong>
                <p style={{ margin: '0.35rem 0 0', color: '#475569' }}>
                  {language === 'en'
                    ? 'Learners see the peso’s response, blue market spreads, and sector sensitivities.'
                    : 'Los estudiantes visualizan la respuesta del peso, spreads del mercado blue y sensibilidades sectoriales.'}
                </p>
              </div>
              <div className="timeline__item">
                <strong>
                  {language === 'en'
                    ? 'Day 2 – Bilingual labs'
                    : 'Día 2 – Laboratorios bilingües'}
                </strong>
                <p style={{ margin: '0.35rem 0 0', color: '#475569' }}>
                  {language === 'en'
                    ? 'Labs walk through case studies to strengthen criteria when inflation shocks occur.'
                    : 'Los labs recorren casos para fortalecer el criterio ante shocks inflacionarios.'}
                </p>
              </div>
            </div>
          </div>
        </div>
        <p className="notice">
          {language === 'en'
            ? 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
            : 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'}
        </p>
      </Section>

      <Section
        pretitle={language === 'en' ? 'FAQ' : 'Preguntas frecuentes'}
        title={
          language === 'en'
            ? 'Questions about the inflation lab'
            : 'Preguntas sobre el laboratorio de inflación'
        }
        subtitle={
          language === 'en'
            ? 'Find details about refresh cycles, language coverage, and educational scope.'
            : 'Descubre detalles sobre ciclos de actualización, cobertura idiomática y alcance educativo.'
        }
      >
        <Accordion items={localizedFaq} />
      </Section>
    </>
  );
};

export default Inflation;