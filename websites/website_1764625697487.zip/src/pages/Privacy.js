import React from 'react';
import SEO from '../components/SEO';
import Section from '../components/Section';
import { useLanguage } from '../context/LanguageContext';

const Privacy = () => {
  const { language } = useLanguage();

  return (
    <>
      <SEO
        title="Privacy Policy | Tu Progreso Hoy"
        description="Read the privacy policy for Tu Progreso Hoy regarding personal data, analytics, and compliance."
        path="/privacy"
      />
      <Section
        title={language === 'en' ? 'Privacy Policy' : 'Política de privacidad'}
        subtitle={
          language === 'en'
            ? 'Effective date: March 2024'
            : 'Fecha de vigencia: marzo 2024'
        }
      >
        <article className="card" style={{ boxShadow: 'none' }}>
          <h3>{language === 'en' ? '1. Scope' : '1. Alcance'}</h3>
          <p>
            {language === 'en'
              ? 'This policy describes how Tu Progreso Hoy processes personal data for educational services. We collect only the information required to deliver learning materials, double opt-in communications, and community support.'
              : 'Esta política describe cómo Tu Progreso Hoy procesa datos personales para ofrecer servicios educativos. Recabamos únicamente la información necesaria para brindar materiales de aprendizaje, comunicaciones de doble opt-in y soporte comunitario.'}
          </p>

          <h3>{language === 'en' ? '2. Data collected' : '2. Datos recolectados'}</h3>
          <ul className="list-check">
            <li>
              {language === 'en'
                ? 'Contact information provided through forms.'
                : 'Información de contacto provista mediante formularios.'}
            </li>
            <li>
              {language === 'en'
                ? 'Learning preferences and module selections.'
                : 'Preferencias de aprendizaje y selección de módulos.'}
            </li>
            <li>
              {language === 'en'
                ? 'Interaction logs within dashboards for educational analytics.'
                : 'Registros de interacción en tableros para analítica educativa.'}
            </li>
          </ul>

          <h3>{language === 'en' ? '3. Purpose' : '3. Finalidad'}</h3>
          <p>
            {language === 'en'
              ? 'Data is processed to deliver course content, manage cohorts, comply with double opt-in standards, and maintain platform integrity.'
              : 'Los datos se procesan para entregar contenidos del curso, gestionar cohortes, cumplir con el doble opt-in y mantener la integridad de la plataforma.'}
          </p>

          <h3>{language === 'en' ? '4. Storage & security' : '4. Almacenamiento y seguridad'}</h3>
          <p>
            {language === 'en'
              ? 'We store data on secure servers located in the United States with industry-standard encryption. Access is limited to authorized educational staff.'
              : 'Almacenamos los datos en servidores seguros ubicados en Estados Unidos con cifrado estándar de la industria. El acceso se limita al personal educativo autorizado.'}
          </p>

          <h3>{language === 'en' ? '5. Rights' : '5. Derechos'}</h3>
          <p>
            {language === 'en'
              ? 'You may request access, rectification, or deletion of your data at hola@tuprogresohoy.com. We respond within 30 days.'
              : 'Puedes solicitar acceso, rectificación o eliminación de tus datos en hola@tuprogresohoy.com. Respondemos dentro de 30 días.'}
          </p>

          <h3>{language === 'en' ? '6. Cookies' : '6. Cookies'}</h3>
          <p>
            {language === 'en'
              ? 'See the Cookie Policy for details about essential and optional cookies. We only set analytics cookies after your consent.'
              : 'Consulta la Política de cookies para ver detalles sobre cookies esenciales y opcionales. Solo configuramos cookies analíticas después de tu consentimiento.'}
          </p>

          <h3>{language === 'en' ? '7. Updates' : '7. Actualizaciones'}</h3>
          <p>
            {language === 'en'
              ? 'Any substantial changes will be communicated via email and posted on this page.'
              : 'Cualquier cambio sustancial será comunicado por correo electrónico y publicado en esta página.'}
          </p>
        </article>
      </Section>
    </>
  );
};

export default Privacy;