import React from 'react';
import SEO from '../components/SEO';
import Section from '../components/Section';
import { useLanguage } from '../context/LanguageContext';

const Cookies = () => {
  const { language } = useLanguage();

  return (
    <>
      <SEO
        title="Cookie Policy | Tu Progreso Hoy"
        description="Understand how Tu Progreso Hoy uses cookies, preferences, and analytics to improve the learning experience."
        path="/cookies"
      />
      <Section
        title={language === 'en' ? 'Cookie Policy' : 'Política de cookies'}
        subtitle={
          language === 'en'
            ? 'Effective date: March 2024'
            : 'Fecha de vigencia: marzo 2024'
        }
      >
        <article className="card" style={{ boxShadow: 'none' }}>
          <h3>{language === 'en' ? '1. Essential cookies' : '1. Cookies esenciales'}</h3>
          <p>
            {language === 'en'
              ? 'Necessary for authentication, session management, and security of the learning dashboards. These cookies cannot be disabled.'
              : 'Necesarias para autenticación, gestión de sesión y seguridad de los tableros. Estas cookies no pueden deshabilitarse.'}
          </p>

          <h3>{language === 'en' ? '2. Preference cookies' : '2. Cookies de preferencia'}</h3>
          <p>
            {language === 'en'
              ? 'Store your language selection (EN / ES) and interface settings for accessibility.'
              : 'Guardan tu selección de idioma (EN / ES) y configuraciones de accesibilidad.'}
          </p>

          <h3>{language === 'en' ? '3. Analytics cookies' : '3. Cookies de analítica'}</h3>
          <p>
            {language === 'en'
              ? 'Used to gather aggregated statistics about module completion and dashboard usage. Enabled only after explicit consent.'
              : 'Se utilizan para obtener estadísticas agregadas sobre finalización de módulos y uso de tableros. Se activan solo después del consentimiento explícito.'}
          </p>

          <h3>{language === 'en' ? '4. Managing cookies' : '4. Gestión de cookies'}</h3>
          <p>
            {language === 'en'
              ? 'You can change your consent at any time via the cookie banner or by contacting hola@tuprogresohoy.com.'
              : 'Puedes cambiar tu consentimiento en cualquier momento mediante el banner de cookies o escribiendo a hola@tuprogresohoy.com.'}
          </p>
        </article>
      </Section>
    </>
  );
};

export default Cookies;