import React, { useState } from 'react';
import Hero from '../components/Hero';
import Section from '../components/Section';
import SEO from '../components/SEO';
import MapFrame from '../components/MapFrame';
import { useLanguage } from '../context/LanguageContext';

const Contact = () => {
  const { language } = useLanguage();
  const [form, setForm] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const updateField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) {
      newErrors.name =
        language === 'en'
          ? 'Please enter your name.'
          : 'Ingresa tu nombre.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email =
        language === 'en'
          ? 'Enter a valid email.'
          : 'Ingresa un correo válido.';
    }
    if (form.message.trim().length < 12) {
      newErrors.message =
        language === 'en'
          ? 'Message should have at least 12 characters.'
          : 'El mensaje debe tener al menos 12 caracteres.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const submitForm = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStatus('loading');
    setTimeout(() => {
      setStatus('success');
      setForm({ name: '', email: '', message: '' });
    }, 900);
  };

  return (
    <>
      <SEO
        title="Contact Tu Progreso Hoy | Buenos Aires"
        description="Reach Tu Progreso Hoy in Buenos Aires for bilingual support, cohort details, and educational partnerships."
        path="/contact"
      />
      <Hero
        image="https://picsum.photos/800/500?image=600"
        title={
          language === 'en'
            ? 'Connect with Tu Progreso Hoy'
            : 'Conecta con Tu Progreso Hoy'
        }
        subtitle={
          language === 'en'
            ? 'Our bilingual team in Buenos Aires is ready to guide you through the learning journey.'
            : 'Nuestro equipo bilingüe en Buenos Aires te acompaña en este recorrido de aprendizaje.'
        }
      >
        <span className="badge">
          {language === 'en' ? 'Buenos Aires · UTC-3' : 'Buenos Aires · UTC-3'}
        </span>
      </Hero>

      <Section
        pretitle={language === 'en' ? 'Visit us' : 'Visítanos'}
        title={
          language === 'en'
            ? 'Campus & community hub'
            : 'Campus y centro comunitario'
        }
        subtitle={
          language === 'en'
            ? 'Workshops take place near iconic Av. 9 de Julio — steps away from key transit lines.'
            : 'Los talleres se realizan cerca de la emblemática Av. 9 de Julio — a pasos de las principales líneas de transporte.'
        }
      >
        <MapFrame />
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Contact form' : 'Formulario de contacto'}
        title={
          language === 'en'
            ? 'Keep us posted about your goals'
            : 'Cuéntanos tus objetivos'
        }
        subtitle={
          language === 'en'
            ? 'Share how you’d like to engage with the course or community. We respond within one business day.'
            : 'Comparte cómo deseas vincularte al curso o comunidad. Respondemos dentro de un día hábil.'
        }
      >
        <div className="grid grid--two">
          <div className="form-card">
            <form onSubmit={submitForm} noValidate>
              <div>
                <label htmlFor="contact-name">
                  {language === 'en' ? 'Name' : 'Nombre'}
                </label>
                <input
                  id="contact-name"
                  value={form.name}
                  onChange={(e) => updateField('name', e.target.value)}
                />
                {errors.name && <p className="error-text">{errors.name}</p>}
              </div>
              <div>
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  type="email"
                  value={form.email}
                  onChange={(e) => updateField('email', e.target.value)}
                />
                {errors.email && <p className="error-text">{errors.email}</p>}
              </div>
              <div>
                <label htmlFor="contact-message">
                  {language === 'en' ? 'Message' : 'Mensaje'}
                </label>
                <textarea
                  id="contact-message"
                  value={form.message}
                  onChange={(e) => updateField('message', e.target.value)}
                ></textarea>
                {errors.message && (
                  <p className="error-text">{errors.message}</p>
                )}
              </div>
              <button type="submit" className="btn btn-primary">
                {language === 'en' ? 'Send message' : 'Enviar mensaje'}
              </button>
            </form>
            {status === 'loading' && (
              <p style={{ color: '#475569', marginTop: '1rem' }}>
                {language === 'en'
                  ? 'Sending...'
                  : 'Enviando...'}
              </p>
            )}
            {status === 'success' && (
              <div className="success-message" role="alert">
                {language === 'en'
                  ? 'Thanks! We will reply shortly.'
                  : '¡Gracias! Responderemos pronto.'}
              </div>
            )}
            <p className="notice">
              {language === 'en'
                ? 'We do not provide financial services. Messages are answered with an educational focus only.'
                : 'No proporcionamos servicios financieros. Respondemos los mensajes con enfoque educativo únicamente.'}
            </p>
          </div>
          <div>
            <div className="card">
              <h3 className="card__title">
                {language === 'en' ? 'Direct contact' : 'Contacto directo'}
              </h3>
              <p className="card__text">
                hola@tuprogresohoy.com
                <br />
                +54 11 5555-1234
              </p>
              <p className="card__text">
                {language === 'en'
                  ? 'Office hours: Monday to Friday, 9:00 to 18:00 (UTC-3).'
                  : 'Horario de atención: lunes a viernes, 9 a 18 (UTC-3).'}
              </p>
              <p className="card__text">
                {language === 'en'
                  ? 'Información confiable que respalda elecciones responsables sobre tu dinero.'
                  : 'Información confiable que respalda elecciones responsables sobre tu dinero.'}
              </p>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
};

export default Contact;