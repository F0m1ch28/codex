import React from 'react';
import SEO from '../components/SEO';
import Section from '../components/Section';
import { useLanguage } from '../context/LanguageContext';

const Terms = () => {
  const { language } = useLanguage();

  return (
    <>
      <SEO
        title="Terms of Service | Tu Progreso Hoy"
        description="Review the terms governing access to Tu Progreso Hoy educational platform and dashboards."
        path="/terms"
      />
      <Section
        title={language === 'en' ? 'Terms of Service' : 'Términos de servicio'}
        subtitle={
          language === 'en'
            ? 'Please read these terms carefully before using the platform.'
            : 'Lee atentamente estos términos antes de usar la plataforma.'
        }
      >
        <article className="card" style={{ boxShadow: 'none' }}>
          <h3>{language === 'en' ? '1. Agreement' : '1. Acuerdo'}</h3>
          <p>
            {language === 'en'
              ? 'By accessing Tu Progreso Hoy, you agree to use the materials exclusively for educational purposes.'
              : 'Al acceder a Tu Progreso Hoy, aceptas utilizar los materiales exclusivamente con fines educativos.'}
          </p>

          <h3>{language === 'en' ? '2. Eligibility' : '2. Elegibilidad'}</h3>
          <p>
            {language === 'en'
              ? 'You must be at least 16 years old or have parental consent to participate in live sessions and communities.'
              : 'Debes tener al menos 16 años o contar con consentimiento parental para participar en sesiones en vivo y comunidades.'}
          </p>

          <h3>{language === 'en' ? '3. Educational use' : '3. Uso educativo'}</h3>
          <p>
            {language === 'en'
              ? 'Content, dashboards, and materials cannot be republished or used to provide financial advice.'
              : 'El contenido, tableros y materiales no pueden republicarse ni utilizarse para brindar asesoramiento financiero.'}
          </p>

          <h3>{language === 'en' ? '4. Intellectual property' : '4. Propiedad intelectual'}</h3>
          <p>
            {language === 'en'
              ? 'All materials remain property of Tu Progreso Hoy. Limited licenses are granted for personal study.'
              : 'Todo el material es propiedad de Tu Progreso Hoy. Se conceden licencias limitadas para estudio personal.'}
          </p>

          <h3>{language === 'en' ? '5. Limitation of liability' : '5. Limitación de responsabilidad'}</h3>
          <p>
            {language === 'en'
              ? 'We do not provide financial services and are not responsible for investment decisions taken by learners.'
              : 'No proporcionamos servicios financieros y no somos responsables por decisiones de inversión tomadas por los estudiantes.'}
          </p>

          <h3>{language === 'en' ? '6. Termination' : '6. Terminación'}</h3>
          <p>
            {language === 'en'
              ? 'We reserve the right to suspend accounts that misuse content or breach community guidelines.'
              : 'Nos reservamos el derecho de suspender cuentas que hagan un uso indebido del contenido o incumplan las normas comunitarias.'}
          </p>

          <h3>{language === 'en' ? '7. Contact' : '7. Contacto'}</h3>
          <p>
            {language === 'en'
              ? 'Questions about these terms can be emailed to hola@tuprogresohoy.com.'
              : 'Las consultas sobre estos términos pueden enviarse a hola@tuprogresohoy.com.'}
          </p>
        </article>
      </Section>
    </>
  );
};

export default Terms;