import React from 'react';
import Hero from '../components/Hero';
import Section from '../components/Section';
import SEO from '../components/SEO';
import { useLanguage } from '../context/LanguageContext';

const Resources = () => {
  const { language } = useLanguage();

  const resources = [
    {
      title:
        language === 'en'
          ? 'Guide: Understanding Argentina’s CPI baskets'
          : 'Guía: comprender las canastas del IPC argentino',
      summary:
        language === 'en'
          ? 'Explore how regional weightings influence your household budgeting simulations.'
          : 'Explora cómo las ponderaciones regionales influyen en tus simulaciones de presupuesto del hogar.',
      lang: 'EN',
      image: 'https://picsum.photos/1200/600?image=400'
    },
    {
      title:
        language === 'en'
          ? 'Glosario esencial de inflación'
          : 'Glosario esencial de inflación',
      summary:
        language === 'en'
          ? 'Define concepts such as pass-through, crawling peg, and real wage index in Spanish.'
          : 'Define conceptos como pass-through, crawling peg e índice de salario real en español.',
      lang: 'ES',
      image: 'https://picsum.photos/400/300?image=701'
    },
    {
      title:
        language === 'en'
          ? 'Playbook: Budgeting in high-inflation cycles'
          : 'Playbook: presupuestar en ciclos de alta inflación',
      summary:
        language === 'en'
          ? 'Step-by-step exercises to stress-test ARS cashflows using the inflation lab dashboards.'
          : 'Ejercicios paso a paso para estresar flujos de caja en ARS usando los tableros del laboratorio de inflación.',
      lang: 'EN / ES',
      image: 'https://picsum.photos/400/300?image=702'
    }
  ];

  const glossary = [
    {
      term: 'Crawling peg',
      definition:
        language === 'en'
          ? 'A managed depreciation of the peso through scheduled adjustments.'
          : 'Una depreciación administrada del peso mediante ajustes programados.'
    },
    {
      term: 'Pass-through',
      definition:
        language === 'en'
          ? 'The effect of exchange rate changes on domestic prices.'
          : 'Efecto de los cambios del tipo de cambio en los precios domésticos.'
    },
    {
      term: 'Brecha cambiaria',
      definition:
        language === 'en'
          ? 'Gap between official and informal exchange rates.'
          : 'Diferencia entre tipos de cambio oficiales e informales.'
    }
  ];

  return (
    <>
      <SEO
        title="Resources & Glossaries | Tu Progreso Hoy"
        description="Download bilingual glossaries, Argentina CPI explainers, and budgeting playbooks to complement your learning."
        path="/resources"
      />
      <Hero
        image="https://picsum.photos/1200/600?image=400"
        title={
          language === 'en'
            ? 'Resource hub: Insights, articles, and glossaries'
            : 'Centro de recursos: insights, artículos y glosarios'
        }
        subtitle={
          language === 'en'
            ? 'Información confiable que respalda elecciones responsables sobre tu dinero.'
            : 'Información confiable que respalda elecciones responsables sobre tu dinero.'
        }
      />

      <Section
        pretitle={language === 'en' ? 'Featured resources' : 'Recursos destacados'}
        title={
          language === 'en'
            ? 'Curated materials for ongoing learning'
            : 'Materiales curados para aprendizaje continuo'
        }
        subtitle={
          language === 'en'
            ? 'Download guides, glossaries, and checklists to reinforce each module.'
            : 'Descarga guías, glosarios y checklists para reforzar cada módulo.'
        }
      >
        <div className="grid grid--three">
          {resources.map((resource) => (
            <article className="card" key={resource.title}>
              <div className="card__media">
                <img
                  src={resource.image}
                  alt={resource.title}
                  loading="lazy"
                  width="400"
                  height="300"
                />
              </div>
              <span className="badge">{resource.lang}</span>
              <h3 className="card__title" style={{ marginTop: '0.6rem' }}>
                {resource.title}
              </h3>
              <p className="card__text">{resource.summary}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section
        variant="light"
        pretitle={language === 'en' ? 'Glossary' : 'Glosario'}
        title={
          language === 'en'
            ? 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
            : 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
        }
        subtitle={
          language === 'en'
            ? 'Key terms you will reference throughout the course in both languages.'
            : 'Términos clave que usarás a lo largo del curso en ambos idiomas.'
        }
      >
        <div className="grid grid--two">
          {glossary.map((item) => (
            <article className="card" key={item.term}>
              <h3 className="card__title">{item.term}</h3>
              <p className="card__text">{item.definition}</p>
            </article>
          ))}
        </div>
        <p className="notice">
          {language === 'en'
            ? 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'
            : 'Plataforma educativa con datos esenciales, sin asesoría financiera directa.'}
        </p>
      </Section>
    </>
  );
};

export default Resources;