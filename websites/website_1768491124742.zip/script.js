document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', function () {
            const isOpen = navList.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        navList.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navList.classList.contains('is-open')) {
                    navList.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const consentButtons = document.querySelectorAll('.cookie-btn[data-consent]');
    const consentKey = 'inflamjhkaCookieChoice';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.add('is-visible');
        }
    }

    if (consentButtons.length) {
        consentButtons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const choice = button.getAttribute('data-consent');
                localStorage.setItem(consentKey, choice);
                if (cookieBanner) {
                    cookieBanner.classList.remove('is-visible');
                }
                const target = button.getAttribute('href');
                if (target) {
                    window.open(target, '_blank', 'noopener');
                }
            });
        });
    }
});