document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.dataset.open = (!expanded).toString();
    });
  }

  const cookieBanner = document.querySelector('[data-cookie-banner]');
  if (cookieBanner) {
    const storedChoice = localStorage.getItem('alkisodaCookieChoice');
    if (!storedChoice) {
      cookieBanner.removeAttribute('hidden');
    }

    const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');

    const closeBanner = (choice) => {
      localStorage.setItem('alkisodaCookieChoice', choice);
      cookieBanner.setAttribute('hidden', '');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => closeBanner('accepted'));
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', () => closeBanner('declined'));
    }
  }

  document.querySelectorAll('[data-current-year]').forEach((element) => {
    element.textContent = new Date().getFullYear();
  });
});