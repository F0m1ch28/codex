document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("[data-nav]");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      navToggle.classList.toggle("is-active");
      nav.setAttribute("data-open", (!expanded).toString());
    });

    const handleResize = () => {
      if (window.innerWidth >= 768) {
        nav.setAttribute("data-open", "true");
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.classList.remove("is-active");
      } else {
        nav.setAttribute("data-open", "false");
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const consentKey = "abs_cookie_consent";

  const hideBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.remove("visible");
      cookieBanner.classList.add("cookie-hidden");
    }
  };

  if (cookieBanner && acceptBtn && declineBtn) {
    const existingConsent = localStorage.getItem(consentKey);
    if (!existingConsent) {
      requestAnimationFrame(() => cookieBanner.classList.add("visible"));
    } else {
      hideBanner();
    }

    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      hideBanner();
    });

    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      hideBanner();
    });
  }
});