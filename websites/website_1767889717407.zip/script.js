document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("open");
        });
    }

    document.querySelectorAll(".current-year").forEach((el) => {
        el.textContent = new Date().getFullYear();
    });

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("accept-cookies");
    const declineBtn = document.getElementById("decline-cookies");
    const consent = localStorage.getItem("sorelyaptpCookieConsent");

    if (!consent && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    const handleConsent = (value) => {
        localStorage.setItem("sorelyaptpCookieConsent", value);
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
    };

    if (acceptBtn) {
        acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => handleConsent("declined"));
    }
});