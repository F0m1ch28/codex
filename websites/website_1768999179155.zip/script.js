document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isOpen = navMenu.classList.toggle('nav-menu--open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navMenu.classList.contains('nav-menu--open')) {
                    navMenu.classList.remove('nav-menu--open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('fincaTresAnillosCookieChoice');
        if (!storedChoice) {
            cookieBanner.classList.add('is-visible');
        }
        cookieBanner.addEventListener('click', function (event) {
            const button = event.target.closest('[data-cookie-choice]');
            if (!button) return;
            const choice = button.getAttribute('data-cookie-choice');
            localStorage.setItem('fincaTresAnillosCookieChoice', choice);
            cookieBanner.classList.remove('is-visible');
        });
    }
});