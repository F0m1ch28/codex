document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            navMenu.classList.toggle('is-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navToggle.classList.remove('is-active');
                    navMenu.classList.remove('is-open');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const consentKey = 'blackbrcolCookieConsent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieBanner.querySelectorAll('.cookie-btn').forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.dataset.choice || 'accepted';
                localStorage.setItem(consentKey, choice);
                cookieBanner.classList.add('is-hidden');
                const target = button.getAttribute('href');
                if (target) {
                    window.open(target, '_blank', 'noopener');
                }
            });
        });
    }
});