document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navList = document.getElementById("primary-navigation");
    const scrollBtn = document.getElementById("scrollTop");
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAccept = document.querySelector(".cookie-accept");
    const contactForm = document.getElementById("contact-form");

    // Mobile navigation toggle
    if (navToggle && navList) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            navList.classList.toggle("open");
        });

        navList.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navList.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    // Scroll to top button
    if (scrollBtn) {
        window.addEventListener("scroll", () => {
            if (window.pageYOffset > 300) {
                scrollBtn.classList.add("show");
            } else {
                scrollBtn.classList.remove("show");
            }
        });

        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    // Cookie consent
    if (cookieBanner) {
        const consent = localStorage.getItem("gneCookieConsent");
        if (consent === "accepted") {
            cookieBanner.classList.add("hidden");
        }

        if (cookieAccept) {
            cookieAccept.addEventListener("click", () => {
                localStorage.setItem("gneCookieConsent", "accepted");
                cookieBanner.classList.add("hidden");
            });
        }
    }

    // Buttons with data-scroll-target (from training section)
    document.querySelectorAll("[data-scroll-target='contact']").forEach(button => {
        button.addEventListener("click", () => {
            window.location.href = "contact.html";
        });
    });

    // Contact form submission
    if (contactForm) {
        const feedback = contactForm.querySelector(".form-feedback");
        contactForm.addEventListener("submit", event => {
            event.preventDefault();

            const name = contactForm.querySelector("#name").value.trim();
            const email = contactForm.querySelector("#email").value.trim();
            const company = contactForm.querySelector("#company").value.trim();
            const message = contactForm.querySelector("#message").value.trim();

            if (!name || !email || !company || !message) {
                if (feedback) {
                    feedback.textContent = "Пожалуйста, заполните все поля формы.";
                    feedback.style.color = "#d9534f";
                }
                return;
            }

            if (feedback) {
                feedback.textContent = "Спасибо! Ваше сообщение отправлено. Мы свяжемся с вами в ближайшее время.";
                feedback.style.color = "#28a745";
            }
            contactForm.reset();
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }
});