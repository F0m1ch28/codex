'use strict';

document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.mobile-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navLinks.classList.toggle('nav-open');
        });

        navLinks.querySelectorAll('a').forEach((link) => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('nav-open')) {
                    navLinks.classList.remove('nav-open');
                    navToggle.classList.remove('active');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('vineryvyacCookies');
        if (storedPreference) {
            cookieBanner.classList.add('hidden');
        }
        cookieBanner.querySelectorAll('[data-cookie-action]').forEach((element) => {
            element.addEventListener('click', () => {
                localStorage.setItem('vineryvyacCookies', element.dataset.cookieAction);
                cookieBanner.classList.add('hidden');
            });
        });
    }

    const searchInput = document.getElementById('postSearch');
    const filterButtons = document.querySelectorAll('[data-filter]');
    const postCards = document.querySelectorAll('.post-card');

    if (searchInput && filterButtons.length && postCards.length) {
        let activeFilter = 'all';

        const applyFilters = () => {
            const query = searchInput.value.trim().toLowerCase();
            postCards.forEach((card) => {
                const category = card.dataset.category || '';
                const text = card.textContent.toLowerCase();
                const matchesFilter = activeFilter === 'all' || category === activeFilter;
                const matchesSearch = text.includes(query);
                card.style.display = matchesFilter && matchesSearch ? 'grid' : 'none';
            });
        };

        searchInput.addEventListener('input', applyFilters);

        filterButtons.forEach((button) => {
            button.addEventListener('click', () => {
                filterButtons.forEach((btn) => btn.classList.remove('active'));
                button.classList.add('active');
                activeFilter = button.dataset.filter;
                applyFilters();
            });
        });
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        const messageBox = contactForm.querySelector('.form-message');
        contactForm.addEventListener('submit', (event) => {
            const fullName = contactForm.querySelector('#fullName');
            const email = contactForm.querySelector('#emailAddress');
            const organisation = contactForm.querySelector('#organisation');
            const topic = contactForm.querySelector('#topic');
            const message = contactForm.querySelector('#message');
            const consent = contactForm.querySelector('#consent');

            const errors = [];

            if (!fullName.value.trim() || fullName.value.trim().length < 3) {
                errors.push('Please provide a full name containing at least three characters.');
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email.value.trim())) {
                errors.push('Enter a valid email address to proceed.');
            }

            if (!organisation.value.trim()) {
                errors.push('Organisation field cannot be empty.');
            }

            if (!topic.value) {
                errors.push('Select one analytical focus area.');
            }

            if (!message.value.trim() || message.value.trim().length < 40) {
                errors.push('Message should outline your analytical query in at least forty characters.');
            }

            if (!consent.checked) {
                errors.push('Please confirm that you have reviewed the terms of use.');
            }

            if (errors.length) {
                event.preventDefault();
                if (messageBox) {
                    messageBox.textContent = errors.join(' ');
                    messageBox.classList.add('error');
                }
            } else if (messageBox) {
                messageBox.textContent = 'Submitting your message...';
                messageBox.classList.remove('error');
            }
        });
    }
});