document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-links a');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            siteNav.classList.toggle('open');
        });

        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 768 && siteNav.classList.contains('open')) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    siteNav.classList.remove('open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('frequeuhea_cookie_consent');
        if (!storedConsent) {
            cookieBanner.classList.add('visible');
        }

        const actionButtons = cookieBanner.querySelectorAll('[data-cookie-action]');
        actionButtons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const action = button.getAttribute('data-cookie-action');
                localStorage.setItem('frequeuhea_cookie_consent', action);
                cookieBanner.classList.remove('visible');
                setTimeout(function () {
                    cookieBanner.style.display = 'none';
                }, 400);
                if (button.hasAttribute('href')) {
                    window.open(button.getAttribute('href'), '_blank');
                }
            });
        });
    }
});