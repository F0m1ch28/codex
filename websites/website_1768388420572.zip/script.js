document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("is-open");
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!expanded).toString());
        });

        siteNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                siteNav.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const storageKey = "rdu_cookie_preference";

    if (cookieBanner) {
        const storedPreference = localStorage.getItem(storageKey);
        if (!storedPreference) {
            requestAnimationFrame(() => {
                cookieBanner.classList.add("is-visible");
            });
        }

        cookieBanner.querySelectorAll("[data-cookie-action]").forEach(button => {
            button.addEventListener("click", event => {
                const action = event.currentTarget.getAttribute("data-cookie-action");
                localStorage.setItem(storageKey, action);
                cookieBanner.classList.remove("is-visible");
            });
        });
    }

    const forms = document.querySelectorAll("form[data-validate='true']");

    forms.forEach(form => {
        form.addEventListener("submit", event => {
            const requiredFields = form.querySelectorAll("[data-required='true']");
            const emailFields = form.querySelectorAll("input[type='email']");
            let isValid = true;

            requiredFields.forEach(field => {
                const errorSpan = form.querySelector(`.form-error[data-error-for='${field.name}']`);
                if (errorSpan) {
                    errorSpan.classList.remove("is-visible");
                    errorSpan.textContent = "";
                }

                if (!field.value.trim()) {
                    isValid = false;
                    event.preventDefault();
                    if (errorSpan) {
                        errorSpan.textContent = "Câmpul este obligatoriu.";
                        errorSpan.classList.add("is-visible");
                    }
                }
            });

            emailFields.forEach(field => {
                if (field.value.trim()) {
                    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailPattern.test(field.value.trim())) {
                        const errorSpan = form.querySelector(`.form-error[data-error-for='${field.name}']`);
                        if (errorSpan) {
                            errorSpan.textContent = "Introduceți o adresă de email validă.";
                            errorSpan.classList.add("is-visible");
                        }
                        isValid = false;
                        event.preventDefault();
                    }
                }
            });

            const feedback = form.querySelector(".form-feedback");
            if (feedback) {
                feedback.classList.remove("error", "success");
                feedback.textContent = "";
            }

            if (!isValid) {
                if (feedback) {
                    feedback.textContent = "Verificați câmpurile marcate și încercați din nou.";
                    feedback.classList.add("error");
                }
            } else if (feedback) {
                feedback.textContent = "Trimiterea formularului este în curs…";
                feedback.classList.add("success");
            }
        });
    });
});