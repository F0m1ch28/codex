import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className="site-header" role="banner">
      <div className="container header-content">
        <Link to="/" className="logo" aria-label="blhank home">
          blhank
        </Link>
        <button
          type="button"
          className="nav-toggle"
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={"main-nav ${menuOpen ? 'open' : ''}"} aria-label="Primary">
          <NavLink to="/" end className={({ isActive }) => (isActive ? 'active nav-link' : 'nav-link')}>
            Home
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? 'active nav-link' : 'nav-link')}>
            About
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? 'active nav-link' : 'nav-link')}>
            Services
          </NavLink>
          <NavLink to="/cases" className={({ isActive }) => (isActive ? 'active nav-link' : 'nav-link')}>
            Cases
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? 'active nav-link' : 'nav-link')}>
            Blog
          </NavLink>
          <NavLink to="/careers" className={({ isActive }) => (isActive ? 'active nav-link' : 'nav-link')}>
            Careers
          </NavLink>
          <NavLink to="/contacts" className={({ isActive }) => (isActive ? 'active nav-link' : 'nav-link')}>
            Contact
          </NavLink>
        </nav>
        <Link to="/contacts" className="header-cta">
          Let’s talk
        </Link>
      </div>
    </header>
  );
};

export default Header;