import React, { useState, useEffect } from 'react';

const CookieBanner = () => {
  const [isOpen, setIsOpen] = useState(() => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('blhank_cookie_consent') !== 'accepted';
  });

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;
    const stored = localStorage.getItem('blhank_cookie_consent');
    if (stored === 'accepted') {
      setIsOpen(false);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('blhank_cookie_consent', 'accepted');
    setIsOpen(false);
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          We use cookies to personalize content, measure engagement, and keep your session secure. By accepting, you agree to our{' '}
          <a href="/cookie-policy">cookie policy</a>.
        </p>
        <button type="button" className="btn btn-primary" onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;