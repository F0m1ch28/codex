import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="site-footer" role="contentinfo">
      <div className="container footer-grid">
        <div className="footer-column">
          <Link to="/" className="footer-logo">
            blhank
          </Link>
          <p>
            Bank independent solutions for organizations that value resiliency, trust, and human-centered execution. We guide leaders across the United States from our home in Vermont.
          </p>
          <div className="footer-social">
            <a href="https://www.linkedin.com/company/itechus" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              <span>in</span>
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
              <span>tw</span>
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
              <span>yt</span>
            </a>
          </div>
        </div>
        <div className="footer-column">
          <h3>Explore</h3>
          <ul>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/cases">Case Stories</Link></li>
            <li><Link to="/blog">Blog</Link></li>
            <li><Link to="/careers">Careers</Link></li>
          </ul>
        </div>
        <div className="footer-column">
          <h3>Legal</h3>
          <ul>
            <li><Link to="/privacy-policy">Privacy Policy</Link></li>
            <li><Link to="/terms-conditions">Terms &amp; Conditions</Link></li>
            <li><Link to="/disclaimer">Disclaimer</Link></li>
            <li><Link to="/cookie-policy">Cookie Policy</Link></li>
          </ul>
        </div>
        <div className="footer-column">
          <h3>Contact</h3>
          <ul>
            <li>Itech Us Inc</li>
            <li>20 Kimball Ave #303n</li>
            <li>South Burlington, VT 05403</li>
          </ul>
          <Link className="footer-contact" to="/contacts">
            Call: +1 802-383-1500
          </Link>
          <Link className="footer-contact" to="/contacts">
            Email: info@blhank.pro
          </Link>
        </div>
      </div>
      <div className="footer-note">
        <p>© {currentYear} Itech Us Inc. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;