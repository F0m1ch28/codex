import React, { useEffect } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';

const updateMeta = (title, description, keywords) => {
  if (title) {
    document.title = title;
  }
  const applyTag = (name, content) => {
    if (!content) return;
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  applyTag('description', description);
  applyTag('keywords', keywords);
};

const BlogPage = () => {
  useEffect(() => {
    updateMeta(
      'Insights from blhank | Bank Independent Perspectives',
      'Read the latest bank independent insights, strategy notes, and digital finance trends from blhank.',
      'bank independent insights, financial blog, blhank blog'
    );
  }, []);

  const articles = [
    {
      id: 1,
      title: 'Reframing Bank Independent Growth in 2024',
      date: 'April 3, 2024',
      excerpt: 'Resilient operating models require flexible ecosystems. Explore how midmarket lenders are diversifying away from single-bank dependencies.',
      image: 'https://picsum.photos/seed/blog-growth/720/480'
    },
    {
      id: 2,
      title: 'Designing Trustworthy Digital Journeys',
      date: 'March 17, 2024',
      excerpt: 'Human-centered orchestration builds confidence during onboarding and servicing. We share a three-layer approach to experience transformation.',
      image: 'https://picsum.photos/seed/blog-digital/720/480'
    },
    {
      id: 3,
      title: 'Data Signals that Strengthen Independent Lending',
      date: 'February 28, 2024',
      excerpt: 'Advanced analytics can safeguard liquidity while improving relationship velocity. Here are the datasets we prioritize for blhank clients.',
      image: 'https://picsum.photos/seed/blog-data/720/480'
    }
  ];

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Insight Library</h1>
          <p>Ideas, research, and perspective from the blhank team on bank independent transformation.</p>
        </div>
      </section>
      <section className="page-section">
        <div className="container blog-grid">
          {articles.map((article) => (
            <article className="blog-card" key={article.id}>
              <img src={article.image} alt={article.title} loading="lazy" />
              <div className="blog-card-content">
                <p className="meta">{article.date}</p>
                <h2>{article.title}</h2>
                <p>{article.excerpt}</p>
                <Link to="/contacts" className="inline-link">
                  Continue the conversation
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

const CasesPage = () => {
  useEffect(() => {
    updateMeta(
      'Client Outcomes | blhank Case Studies',
      'See how blhank crafts bank independent solutions that accelerate growth, improve resilience, and modernize customer journeys.',
      'bank independent case study, financial services transformation, blhank cases'
    );
  }, []);

  const cases = [
    {
      id: 1,
      title: 'Regional Lender Liquidity Program',
      description:
        'We helped a regional lender build a multi-partner liquidity framework, reducing capital dependency on a single bank by 45% within six months.',
      result: 'Capital diversification across four independent partners while maintaining customer experience.',
      image: 'https://picsum.photos/seed/case-liquidity/720/480'
    },
    {
      id: 2,
      title: 'Embedded Finance for Retail Cooperative',
      description:
        'Our team orchestrated embedded finance rails supporting new membership products, unlock­ing recurring revenue streams from non-interest income.',
      result: '30% increase in member retention and 18% uplift in ancillary product adoption.',
      image: 'https://picsum.photos/seed/case-embedded/720/480'
    },
    {
      id: 3,
      title: 'Risk Intelligence Refresh',
      description:
        'We delivered a data modernization program for a national cooperative, combining first-party data with external signals for faster lending decisions.',
      result: 'Underwriting cycle times dropped from 9 days to 36 hours with improved compliance reporting.',
      image: 'https://picsum.photos/seed/case-risk/720/480'
    }
  ];

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Case Stories</h1>
          <p>Outcomes that show what focused bank independent strategy can achieve.</p>
        </div>
      </section>
      <section className="page-section">
        <div className="container case-grid">
          {cases.map((item) => (
            <article className="case-card" key={item.id}>
              <img src={item.image} alt={item.title} loading="lazy" />
              <div className="case-card-body">
                <h2>{item.title}</h2>
                <p>{item.description}</p>
                <p className="highlight">{item.result}</p>
              </div>
            </article>
          ))}
        </div>
        <div className="cta-banner">
          <h2>Ready to build with confidence?</h2>
          <p>Let’s map the next phase of your independent growth strategy together.</p>
          <Link to="/contacts" className="btn btn-primary">
            Talk with blhank
          </Link>
        </div>
      </section>
    </div>
  );
};

const CareersPage = () => {
  useEffect(() => {
    updateMeta(
      'Careers at blhank | Shape Bank Independent Futures',
      'Join blhank and help financial institutions design bank independent solutions with purpose.',
      'blhank careers, fintech jobs, bank independent careers'
    );
  }, []);

  const roles = [
    {
      id: 1,
      title: 'Senior Strategy Consultant',
      location: 'Remote, USA',
      type: 'Full-time',
      summary: 'Lead multi-disciplinary teams guiding lenders through bank independent operating models.'
    },
    {
      id: 2,
      title: 'Experience Designer',
      location: 'South Burlington, VT',
      type: 'Hybrid',
      summary: 'Craft intuitive digital journeys that build trust and clarity for banking customers.'
    },
    {
      id: 3,
      title: 'Data Solutions Architect',
      location: 'Remote, USA',
      type: 'Full-time',
      summary: 'Design resilient data pipelines that fuel decisioning for bank independent ecosystems.'
    }
  ];

  const benefits = ['Fully covered health benefits', 'Flexible PTO and recharge weeks', 'Learning stipends and certifications', 'Inclusive, purpose-driven culture'];

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Careers at blhank</h1>
          <p>Build meaningful progress for communities and clients who rely on bank independent resilience.</p>
        </div>
      </section>
      <section className="page-section">
        <div className="container careers-layout">
          <div className="careers-intro">
            <h2>We work as one team</h2>
            <p>
              blhank blends strategists, technologists, designers, and analysts who care deeply about the people behind financial systems. We aim to be deliberate listeners, rapid
              problem-solvers, and thoughtful partners for every client.
            </p>
            <p>
              Our team is anchored in South Burlington, Vermont, and operates across the United States. We design collaboration rituals that balance remote flexibility with meaningful in-person
              connection.
            </p>
            <h3>What you can expect</h3>
            <ul className="benefit-list">
              {benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
          </div>
          <div className="roles-list">
            {roles.map((role) => (
              <article className="role-card" key={role.id}>
                <h3>{role.title}</h3>
                <p className="meta">{role.location} · {role.type}</p>
                <p>{role.summary}</p>
                <a className="inline-link" href="https://www.linkedin.com/company/itechus" target="_blank" rel="noopener noreferrer">
                  Express interest on LinkedIn
                </a>
              </article>
            ))}
          </div>
        </div>
        <div className="cta-banner">
          <h2>Didn’t see a perfect fit?</h2>
          <p>We always welcome conversations with future collaborators. Send us a note and let’s connect.</p>
          <Link to="/contacts" className="btn btn-secondary">
            Reach out
          </Link>
        </div>
      </section>
    </div>
  );
};

const DisclaimerPage = () => {
  useEffect(() => {
    updateMeta(
      'Disclaimer | blhank',
      'Understand the limitations of information and advisory content published by blhank.',
      'blhank disclaimer, informational purposes'
    );
  }, []);

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Disclaimer</h1>
          <p>Important notices about the information provided on blhank channels.</p>
        </div>
      </section>
      <section className="page-section">
        <div className="container legal-content">
          <h2>Informational Purposes Only</h2>
          <p>
            The content presented by blhank on this website, blog, newsletters, and related materials is offered for general informational purposes. Nothing herein should be interpreted as legal,
            tax, investment, or accounting advice. Decisions should always be made in consultation with appropriately licensed professionals.
          </p>
          <h2>No Client Relationship</h2>
          <p>
            Viewing our content, downloading resources, or communicating with blhank through this site does not create a client or advisory relationship unless an explicit written contract is
            executed with Itech Us Inc.
          </p>
          <h2>Accuracy and Timeliness</h2>
          <p>
            We strive to ensure our materials reflect current perspectives on bank independent practices. However, regulations, markets, and technologies evolve rapidly. blhank makes no warranties
            regarding completeness, reliability, or accuracy of the information provided.
          </p>
          <h2>Third-Party Links</h2>
          <p>
            Certain articles may reference external websites. blhank is not responsible for the content, security, or availability of third-party resources. Following external links is at your own
            risk.
          </p>
          <h2>Liability Limitation</h2>
          <p>
            To the fullest extent permitted by applicable law, blhank and Itech Us Inc disclaim liability for any direct, indirect, or consequential damages arising from the use of this site or any
            linked resources.
          </p>
        </div>
      </section>
    </div>
  );
};

const CookiePolicyPage = () => {
  useEffect(() => {
    updateMeta(
      'Cookie Policy | blhank',
      'Learn how blhank uses cookies and similar technologies on blhank.pro.',
      'blhank cookie policy, website cookies'
    );
  }, []);

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>How and why we use cookies across the blhank digital experience.</p>
        </div>
      </section>
      <section className="page-section">
        <div className="container legal-content">
          <h2>What Are Cookies?</h2>
          <p>
            Cookies are small text files stored on your device when you visit a website. They help us understand how visitors engage with blhank.pro and allow us to improve performance, usability, and
            security.
          </p>
          <h2>Types of Cookies We Use</h2>
          <ul>
            <li><strong>Essential cookies</strong> power secure navigation and session management.</li>
            <li><strong>Analytics cookies</strong> help us measure usage patterns and enhance content relevance.</li>
            <li><strong>Preference cookies</strong> remember your selections such as language and cookie consent.</li>
          </ul>
          <h2>Managing Cookies</h2>
          <p>
            You can modify your browser settings to reject or delete cookies. Please note that disabling essential cookies may impact core site functionality. Our cookie banner allows you to accept or
            reject non-essential cookies.
          </p>
          <h2>Updates</h2>
          <p>
            We review this cookie policy periodically to reflect evolving regulations and technology. Updates will be posted here with a revised effective date.
          </p>
          <p>
            Questions? Reach out to <a href="mailto:info@blhank.pro">info@blhank.pro</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

const NotFoundPage = () => {
  useEffect(() => {
    updateMeta(
      'Page Not Found | blhank',
      'The page you requested could not be located on blhank.pro.',
      '404 blhank'
    );
  }, []);

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>We can’t find that page</h1>
          <p>The link you followed may be broken or the page may have been removed.</p>
          <Link to="/" className="btn btn-primary">
            Back to homepage
          </Link>
        </div>
      </section>
    </div>
  );
};

function App() {
  return (
    <div className="app-container">
      <Header />
      <main className="main-content" id="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/cases" element={<CasesPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/careers" element={<CareersPage />} />
          <Route path="/contacts" element={<Contact />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/terms-conditions" element={<TermsOfService />} />
          <Route path="/disclaimer" element={<DisclaimerPage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  );
}

export default App;