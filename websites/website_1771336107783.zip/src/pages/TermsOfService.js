import React, { useEffect } from 'react';

const TermsOfService = () => {
  useEffect(() => {
    document.title = 'Terms & Conditions | blhank';
    const ensureTag = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureTag('description', 'Read the terms and conditions that govern your use of blhank.pro.');
    ensureTag('keywords', 'blhank terms, terms and conditions');
  }, []);

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Terms &amp; Conditions</h1>
          <p>These Terms &amp; Conditions govern access to blhank.pro and any associated content or services.</p>
        </div>
      </section>

      <section className="page-section">
        <div className="container legal-content">
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing or using blhank.pro, you agree to be bound by these Terms &amp; Conditions and any additional policies referenced herein. If you do not agree, please refrain from using this
            site.
          </p>

          <h2>2. Services</h2>
          <p>
            Itech Us Inc (“blhank”) provides strategic consulting, design, technology advisory, and related services. Engagement terms are defined in individual agreements. Content on this website is
            provided for informational purposes and does not constitute a contractual offer.
          </p>

          <h2>3. Intellectual Property</h2>
          <p>
            All materials on this site, including text, graphics, logos, and imagery, are the intellectual property of Itech Us Inc unless otherwise noted. You may not reproduce, distribute, or create
            derivative works without prior written consent.
          </p>

          <h2>4. Acceptable Use</h2>
          <p>
            You agree not to misuse the website, interfere with security features, or attempt unauthorized access to our systems. Automated data collection, scraping, or other extraction methods are
            prohibited.
          </p>

          <h2>5. Privacy</h2>
          <p>
            Your use of this site is also governed by our <a href="/privacy-policy">Privacy Policy</a>, which explains how we collect, use, and safeguard information.
          </p>

          <h2>6. Limitation of Liability</h2>
          <p>
            To the fullest extent permitted by law, blhank is not liable for any indirect, incidental, or consequential damages arising from your use of the site. This includes loss of data, revenue,
            or profits.
          </p>

          <h2>7. Third-Party Links</h2>
          <p>
            We may reference third-party websites for convenience. We do not endorse, control, or take responsibility for the content or practices of those websites.
          </p>

          <h2>8. Modifications</h2>
          <p>
            We may update these Terms &amp; Conditions at any time. Changes take effect upon posting. Continued use of the site constitutes acceptance of the updated terms.
          </p>

          <h2>9. Governing Law</h2>
          <p>
            These Terms &amp; Conditions are governed by the laws of the State of Vermont, USA, without regard to conflict of law provisions.
          </p>

          <h2>10. Contact</h2>
          <p>
            For questions regarding these Terms &amp; Conditions, contact us at <a href="mailto:info@blhank.pro">info@blhank.pro</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default TermsOfService;