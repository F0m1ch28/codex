import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const About = () => {
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.title = 'About blhank | Our Story and Team';
      const applyTag = (name, content) => {
        if (!content) return;
        let tag = document.querySelector("meta[name="${name}"]");
        if (!tag) {
          tag = document.createElement('meta');
          tag.setAttribute('name', name);
          document.head.appendChild(tag);
        }
        tag.setAttribute('content', content);
      };
      applyTag('description', 'Meet the blhank team, our purpose, and how we help clients create bank independent resilience.');
      applyTag('keywords', 'blhank team, bank independent consulting, about blhank');
    }
  }, []);

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Our story</h1>
          <p>blhank is a Vermont-born consultancy transforming how financial institutions pursue bank independent growth.</p>
        </div>
      </section>

      <section className="page-section">
        <div className="container about-intro">
          <div className="about-text">
            <h2>Purpose anchored in people</h2>
            <p>
              We founded blhank with a straightforward belief: financial services should be resilient, empathetic, and accessible. Our roots in South Burlington keep us grounded in community values,
              while our national footprint allows us to serve forward-looking lenders, cooperatives, and fintech innovators across the United States.
            </p>
            <p>
              The name blhank reflects a simple promise — help leaders write their own bank independent stories. Whether we are architecting a liquidity program or co-designing a digital journey, we
              embed ourselves as long-term partners who champion the people behind the numbers.
            </p>
            <Link to="/services" className="inline-link">
              See how we support your teams
            </Link>
          </div>
          <div className="about-image-grid">
            <img src="https://picsum.photos/seed/about-office/640/420" alt="blhank Burlington office workspace" loading="lazy" />
            <img src="https://picsum.photos/seed/about-collaboration/640/420" alt="Team collaborating in a creative space" loading="lazy" />
          </div>
        </div>
      </section>

      <section className="page-section light">
        <div className="container team-section">
          <h2>Meet the leadership</h2>
          <p>blhank brings together cross-functional leaders with deep expertise in financial services, technology, and experience design.</p>
          <div className="team-grid">
            <article className="team-card">
              <img src="https://picsum.photos/seed/team-lead1/420/420" alt="Portrait of Maya Thompson, CEO" loading="lazy" />
              <h3>Maya Thompson</h3>
              <p className="meta">Chief Executive Officer</p>
              <p>Maya translates ambitious visions into bank independent roadmaps grounded in partnership, compliance, and measurable outcomes.</p>
            </article>
            <article className="team-card">
              <img src="https://picsum.photos/seed/team-lead2/420/420" alt="Portrait of Gabriel Alvarez, Head of Strategy" loading="lazy" />
              <h3>Gabriel Alvarez</h3>
              <p className="meta">Head of Strategy</p>
              <p>Gabriel guides institutions through ecosystem diversification and helps operationalize governance for sustainable expansion.</p>
            </article>
            <article className="team-card">
              <img src="https://picsum.photos/seed/team-lead3/420/420" alt="Portrait of Olivia Chen, Experience Director" loading="lazy" />
              <h3>Olivia Chen</h3>
              <p className="meta">Experience Director</p>
              <p>Olivia ensures every interaction honors the humans behind the transaction with purposeful design and storytelling.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="page-section">
        <div className="container values-section">
          <h2>Our values guide every engagement</h2>
          <div className="values-grid">
            <article>
              <h3>Clarity</h3>
              <p>We communicate openly, distilling complex financial transformations into clear, actionable plans for every stakeholder.</p>
            </article>
            <article>
              <h3>Empathy</h3>
              <p>We respect the customers, colleagues, and communities served by our clients and design solutions that honor their needs.</p>
            </article>
            <article>
              <h3>Momentum</h3>
              <p>We move quickly while safeguarding quality. Momentum means measurable progress and the courage to adapt along the way.</p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;