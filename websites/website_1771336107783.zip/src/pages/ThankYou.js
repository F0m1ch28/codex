import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const ThankYou = () => {
  useEffect(() => {
    document.title = 'Thank You | blhank';
    const ensureTag = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureTag('description', 'Thank you for contacting blhank. Our team will respond shortly.');
    ensureTag('keywords', 'thank you blhank');
  }, []);

  return (
    <div className="page">
      <section className="page-hero thank-you">
        <div className="container">
          <h1>Thank you</h1>
          <p>We received your message and will get in touch within two business days. We appreciate the opportunity to collaborate.</p>
          <div className="hero-actions">
            <Link to="/" className="btn btn-primary">
              Return home
            </Link>
            <Link to="/blog" className="btn btn-secondary">
              Browse insights
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ThankYou;