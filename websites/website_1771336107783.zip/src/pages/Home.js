import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const usePageMeta = (title, description, keywords) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    const ensureTag = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureTag('description', description);
    ensureTag('keywords', keywords);
  }, [title, description, keywords]);
};

const Home = () => {
  usePageMeta(
    'blhank | Bank Independent Solutions for Modern Finance',
    'blhank crafts bank independent strategies, experiences, and platforms that help U.S. financial leaders grow with confidence.',
    'bank independent, financial strategy, fintech consulting, blhank'
  );

  const services = [
    {
      title: 'Bank Independent Strategy',
      description: 'Clarify your operating model and partner ecosystem to minimize concentration risk while honoring customer trust.',
      image: 'https://picsum.photos/seed/service-strategy/120/120'
    },
    {
      title: 'Digital Experience Design',
      description: 'Build journey-forward experiences that blend empathy, compliance, and data-driven personalization across channels.',
      image: 'https://picsum.photos/seed/service-experience/120/120'
    },
    {
      title: 'Data & Decisioning Platforms',
      description: 'Modernize the intelligence layer with quality data pipelines, harmonized signals, and actionable insights for teams.',
      image: 'https://picsum.photos/seed/service-data/120/120'
    },
    {
      title: 'Change Enablement',
      description: 'Activate your teams with practical playbooks, co-created training, and measurable progress metrics.',
      image: 'https://picsum.photos/seed/service-change/120/120'
    }
  ];

  const cases = [
    {
      title: 'Diversifying Liquidity for a Regional Lender',
      image: 'https://picsum.photos/seed/home-case1/520/360',
      summary: 'Rebuilt capital partnerships to reduce single-bank dependency and strengthen treasury resilience.'
    },
    {
      title: 'Experience Refresh for a Credit Cooperative',
      image: 'https://picsum.photos/seed/home-case2/520/360',
      summary: 'Delivered a seamless member journey that increased retention and expanded new product adoption.'
    },
    {
      title: 'Risk Intelligence Modernization',
      image: 'https://picsum.photos/seed/home-case3/520/360',
      summary: 'Introduced a unified data fabric enabling faster lending decisions with transparent governance.'
    }
  ];

  const articles = [
    {
      title: 'Signals that Fuel Bank Independent Momentum',
      image: 'https://picsum.photos/seed/home-blog1/520/360',
      summary: 'How to identify the data moments that prepare your organization for resilient scaling.'
    },
    {
      title: 'Earning Trust with Purposeful Automation',
      image: 'https://picsum.photos/seed/home-blog2/520/360',
      summary: 'Automation only matters when customers feel seen. Our playbook for human-centered orchestration.'
    },
    {
      title: 'From Roadmap to Activation in 90 Days',
      image: 'https://picsum.photos/seed/home-blog3/520/360',
      summary: 'Practical steps to move from strategy slides to measurable outcomes without losing momentum.'
    }
  ];

  const testimonials = [
    {
      name: 'Jordan Lee',
      role: 'Chief Operations Officer, Community Lender',
      quote: 'blhank translated our ambition into a bank independent roadmap that teams could rally around. The execution discipline was unmatched.',
      avatar: 'https://i.pravatar.cc/120?img=5'
    },
    {
      name: 'Priya Desai',
      role: 'VP of Digital Experience, Cooperative Bank',
      quote: 'They listen deeply, respect our compliance needs, and still push us toward bold innovation. Our members feel the difference.',
      avatar: 'https://i.pravatar.cc/120?img=32'
    },
    {
      name: 'Ethan Gomez',
      role: 'Head of Strategy, National Finance Network',
      quote: 'From data architecture to change enablement, the blhank team guided us every step of the way. We are stronger and more agile today.',
      avatar: 'https://i.pravatar.cc/120?img=11'
    }
  ];

  return (
    <div className="home">
      <section
        className="hero"
        aria-labelledby="hero-title"
        style={{
          backgroundImage:
            'linear-gradient(135deg, rgba(10,31,59,0.92), rgba(10,31,59,0.65)), url(https://picsum.photos/seed/hero-office/1600/900)'
        }}
      >
        <div className="container hero-content">
          <h1 id="hero-title">Independent banking strategies for resilient growth</h1>
          <p>
            blhank empowers financial leaders with bank independent frameworks that combine strategic foresight, modern platforms, and human-centered delivery.
          </p>
          <div className="hero-actions">
            <Link to="/contacts" className="btn btn-primary">
              Start a project
            </Link>
            <Link to="/services" className="btn btn-secondary">
              Explore services
            </Link>
          </div>
          <div className="hero-pill">
            <span>Trusted partner to midmarket lenders across the U.S.</span>
          </div>
        </div>
      </section>

      <section className="intro" id="about">
        <div className="container intro-grid">
          <div className="intro-text">
            <h2>Your ally for bank independent momentum</h2>
            <p>
              We are strategists, designers, technologists, and operators who believe in the power of diversified financial ecosystems. Partnering with blhank means you gain a dedicated team anchored
              in Vermont and activated across the United States, ready to extend your capabilities with clarity and care.
            </p>
            <p>
              Our focus is simple: help you stay agile, compliant, and connected to the communities you serve. From discovery to activation, we stay by your side and champion the people who bring your
              mission to life.
            </p>
            <Link to="/about" className="inline-link">
              Learn about our story
            </Link>
          </div>
          <div className="intro-image">
            <img src="https://picsum.photos/seed/team-collab/640/520" alt="blhank team collaborating in the Burlington office" loading="lazy" />
          </div>
        </div>
      </section>

      <section className="services-preview">
        <div className="container">
          <div className="section-heading">
            <h2>Services that keep you bank independent</h2>
            <p>From executive strategy through digital delivery, we tailor engagements to amplify your strengths and mitigate risks.</p>
          </div>
          <div className="card-grid">
            {services.map((service) => (
              <article className="card" key={service.title}>
                <img src={service.image} alt={service.title} loading="lazy" />
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </article>
            ))}
          </div>
          <div className="section-footer">
            <Link to="/services" className="btn btn-primary">
              View all services
            </Link>
          </div>
        </div>
      </section>

      <section className="cases-preview">
        <div className="container">
          <div className="section-heading">
            <h2>Evidence of impact</h2>
            <p>Real-world examples of how blhank accelerates independent growth for lenders, cooperatives, and fintech innovators.</p>
          </div>
          <div className="card-grid">
            {cases.map((item) => (
              <article className="card case-card" key={item.title}>
                <img src={item.image} alt={item.title} loading="lazy" />
                <div className="card-body">
                  <h3>{item.title}</h3>
                  <p>{item.summary}</p>
                </div>
              </article>
            ))}
          </div>
          <div className="section-footer">
            <Link to="/cases" className="btn btn-secondary">
              Explore case stories
            </Link>
          </div>
        </div>
      </section>

      <section className="blog-preview">
        <div className="container">
          <div className="section-heading">
            <h2>From the blhank journal</h2>
            <p>Insights on bank independent strategy, experience design, and operational excellence.</p>
          </div>
          <div className="card-grid">
            {articles.map((article) => (
              <article className="card blog-card" key={article.title}>
                <img src={article.image} alt={article.title} loading="lazy" />
                <div className="card-body">
                  <h3>{article.title}</h3>
                  <p>{article.summary}</p>
                </div>
              </article>
            ))}
          </div>
          <div className="section-footer">
            <Link to="/blog" className="btn btn-primary">
              Read the blog
            </Link>
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container">
          <div className="section-heading">
            <h2>Leaders who trust blhank</h2>
            <p>We partner closely with executives across the U.S. to unlock sustainable, bank independent progress.</p>
          </div>
          <div className="testimonial-grid">
            {testimonials.map((item) => (
              <figure className="testimonial-card" key={item.name}>
                <img src={item.avatar} alt={item.name} loading="lazy" />
                <blockquote>“{item.quote}”</blockquote>
                <figcaption>
                  <strong>{item.name}</strong>
                  <span>{item.role}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="careers-preview">
        <div className="container careers-preview-grid">
          <div className="careers-copy">
            <h2>Work with a purpose-driven team</h2>
            <p>
              We hire curious builders who care deeply about community outcomes. Discover a culture that values flexibility, diversity, and continual learning.
            </p>
            <Link to="/careers" className="btn btn-secondary">
              Join the team
            </Link>
          </div>
          <div className="careers-image">
            <img src="https://picsum.photos/seed/careers-culture/640/520" alt="Team collaborating in a modern office space" loading="lazy" />
          </div>
        </div>
      </section>

      <section className="contact-cta" id="contact">
        <div className="container contact-cta-grid">
          <div className="contact-cta-text">
            <h2>Let’s build what’s next</h2>
            <p>
              Ready to reimagine your bank independent roadmap? Connect with our team to spark momentum within weeks, not months.
            </p>
            <ul className="contact-details">
              <li><strong>Phone:</strong> +1 802-383-1500</li>
              <li><strong>Email:</strong> info@blhank.pro</li>
              <li><strong>Address:</strong> 20 Kimball Ave #303n, South Burlington, VT 05403</li>
            </ul>
            <Link to="/contacts" className="btn btn-primary">
              Contact blhank
            </Link>
          </div>
          <div className="contact-cta-image">
            <img src="https://picsum.photos/seed/contact-team/640/520" alt="blhank client meeting in progress" loading="lazy" />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;