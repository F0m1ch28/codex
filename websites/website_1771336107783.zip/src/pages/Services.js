import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const Services = () => {
  useEffect(() => {
    document.title = 'blhank Services | Bank Independent Expertise';
    const ensureTag = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureTag('description', 'Discover the full suite of blhank services that help leaders thrive with bank independent strategies.');
    ensureTag('keywords', 'bank independent services, financial consulting, blhank services');
  }, []);

  const offerings = [
    {
      title: 'Independent Strategy & Advisory',
      description:
        'We co-create frameworks that redefine your relationship with capital partners, broaden collaboration opportunities, and strengthen governance.',
      details: ['Market and partner analysis', 'Risk diversification modeling', 'Liquidity planning', 'Executive facilitation'],
      image: 'https://picsum.photos/seed/services-advisory/720/480'
    },
    {
      title: 'Experience & Journey Design',
      description:
        'Transform experiences with human-centered research, storytelling, and iterative design to deepen trust at every customer touchpoint.',
      details: ['Journey mapping and service blueprints', 'Customer research and testing', 'Content strategy', 'Design systems'],
      image: 'https://picsum.photos/seed/services-experience/720/480'
    },
    {
      title: 'Data & Technology Modernization',
      description:
        'Modernize data architecture, integrate third-party signals, and activate automation responsibly to empower decision-makers.',
      details: ['Data platform assessments', 'Integration & API strategy', 'Analytics enablement', 'Automation playbooks'],
      image: 'https://picsum.photos/seed/services-data/720/480'
    },
    {
      title: 'Change Management & Enablement',
      description:
        'Ensure initiatives stick with structured change programs, enablement sessions, and measurement routines that celebrate progress.',
      details: ['Change narrative development', 'Capability building and training', 'Measurement dashboards', 'Communications support'],
      image: 'https://picsum.photos/seed/services-change/720/480'
    }
  ];

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Services</h1>
          <p>We build integrated solutions that keep your organization bank independent, customer-centric, and future ready.</p>
        </div>
      </section>

      <section className="page-section">
        <div className="container service-list">
          {offerings.map((offering) => (
            <article className="service-card" key={offering.title}>
              <div className="service-image">
                <img src={offering.image} alt={offering.title} loading="lazy" />
              </div>
              <div className="service-info">
                <h2>{offering.title}</h2>
                <p>{offering.description}</p>
                <ul>
                  {offering.details.map((detail) => (
                    <li key={detail}>{detail}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="page-section light">
        <div className="container collaboration">
          <h2>The blhank collaboration model</h2>
          <div className="collaboration-grid">
            <div>
              <h3>Discover</h3>
              <p>We start with listening sessions, data reviews, and co-working workshops to align on goals and define what progress looks like.</p>
            </div>
            <div>
              <h3>Design</h3>
              <p>We prototype experiences, architectures, and playbooks with your teams—testing early and often to surface the strongest ideas.</p>
            </div>
            <div>
              <h3>Activate</h3>
              <p>We stand shoulder-to-shoulder with your leaders during implementation, creating visibility, training, and momentum rituals.</p>
            </div>
          </div>
          <Link to="/cases" className="btn btn-secondary">
            See client success
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;