import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    document.title = 'Contact blhank | Start the Conversation';
    const ensureTag = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureTag('description', 'Connect with blhank to explore bank independent solutions tailored to your organization.');
    ensureTag('keywords', 'contact blhank, bank independent consultation');
  }, []);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please provide your name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Share a few details about your goals.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    const sanitized = {
      name: formData.name.trim(),
      email: formData.email.trim(),
      message: formData.message.trim()
    };
    console.info('Contact request submitted:', sanitized);
    navigate('/thank-you');
  };

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Contact blhank</h1>
          <p>Share your goals and we’ll respond within two business days to plan the next conversation.</p>
        </div>
      </section>

      <section className="page-section">
        <div className="container contact-layout">
          <div className="contact-info">
            <h2>Our details</h2>
            <p>
              <strong>Company:</strong> Itech Us Inc
            </p>
            <p>
              <strong>Address:</strong> 20 Kimball Ave #303n, South Burlington, VT 05403
            </p>
            <p>
              <strong>Phone:</strong> <a href="tel:+18023831500">+1 802-383-1500</a>
            </p>
            <p>
              <strong>Email:</strong> <a href="mailto:info@blhank.pro">info@blhank.pro</a>
            </p>
            <p>
              We collaborate with clients across the United States. Virtual workshops, on-site engagements, and hybrid models are all available based on your needs.
            </p>
            <div className="contact-card">
              <h3>Office hours</h3>
              <p>Monday – Friday: 8:30 AM – 6:00 PM EST</p>
              <p>Saturday & Sunday: By appointment</p>
            </div>
          </div>

          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <h2>Start the conversation</h2>
            <div className="form-group">
              <label htmlFor="name">Name *</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Email *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="message">How can we help? *</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && <span className="form-error">{errors.message}</span>}
            </div>
            <button type="submit" className="btn btn-primary">
              Submit message
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;