import React, { useEffect } from 'react';

const PrivacyPolicy = () => {
  useEffect(() => {
    document.title = 'Privacy Policy | blhank';
    const ensureTag = (name, content) => {
      if (!content) return;
      let tag = document.querySelector("meta[name="${name}"]");
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('name', name);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };
    ensureTag('description', 'Learn how blhank collects, uses, and protects personal information on blhank.pro.');
    ensureTag('keywords', 'blhank privacy policy, data protection');
  }, []);

  return (
    <div className="page">
      <section className="page-hero">
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>We respect your privacy and are committed to protecting personal information entrusted to us.</p>
        </div>
      </section>

      <section className="page-section">
        <div className="container legal-content">
          <h2>Information We Collect</h2>
          <p>
            When you interact with blhank.pro, we may collect personal details such as your name, email address, phone number, and organization. We also gather usage data including IP address, browser
            type, pages visited, and device identifiers.
          </p>

          <h2>How We Use Information</h2>
          <p>We use collected information to:</p>
          <ul>
            <li>Respond to inquiries and provide requested services.</li>
            <li>Improve website performance, content relevance, and user experience.</li>
            <li>Send updates about blhank offerings, events, or insights (you may opt out at any time).</li>
            <li>Maintain site security and comply with legal obligations.</li>
          </ul>

          <h2>Sharing of Information</h2>
          <p>
            We do not sell personal information. Data may be shared with trusted service providers who support our operations, such as analytics vendors or communication platforms, under strict
            confidentiality obligations. We may also disclose data if required by law or to protect our rights.
          </p>

          <h2>Cookies and Tracking</h2>
          <p>
            We use cookies and similar technologies to understand engagement patterns and optimize our services. Review our <a href="/cookie-policy">Cookie Policy</a> for details on managing your
            preferences.
          </p>

          <h2>Data Retention</h2>
          <p>We retain personal information only as long as necessary to fulfill the purposes outlined in this policy or to satisfy legal requirements.</p>

          <h2>Your Rights</h2>
          <p>
            Depending on your jurisdiction, you may request access, correction, or deletion of your personal data. Contact us at <a href="mailto:info@blhank.pro">info@blhank.pro</a> to exercise these
            rights. We will respond within a reasonable timeframe.
          </p>

          <h2>Security</h2>
          <p>
            We maintain administrative, technical, and physical safeguards designed to protect personal information against unauthorized access, alteration, or disclosure. No online system is entirely
            immune, so please use caution when sharing sensitive data.
          </p>

          <h2>Changes to This Policy</h2>
          <p>
            We may update this Privacy Policy periodically to reflect evolving regulations or practices. Changes take effect upon posting with a revised effective date.
          </p>

          <h2>Contact Us</h2>
          <p>
            Questions or concerns? Email <a href="mailto:info@blhank.pro">info@blhank.pro</a> or write to Itech Us Inc, 20 Kimball Ave #303n, South Burlington, VT 05403.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicy;