document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('active');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                navMenu.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieButtons = document.querySelectorAll('[data-cookie-choice]');

    if (cookieBanner) {
        const choice = localStorage.getItem('genusCookieChoice');
        if (!choice) {
            cookieBanner.classList.add('active');
        }

        cookieButtons.forEach(button => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const decision = button.getAttribute('data-cookie-choice');
                localStorage.setItem('genusCookieChoice', decision);
                cookieBanner.classList.remove('active');
                if (button.tagName.toLowerCase() === 'a' && button.href) {
                    window.location.href = button.href;
                }
            });
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const courseCards = document.querySelectorAll('[data-category]');

    if (filterButtons.length && courseCards.length) {
        filterButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const selected = btn.getAttribute('data-filter');
                filterButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                courseCards.forEach(card => {
                    const category = card.getAttribute('data-category');
                    if (selected === 'all' || category === selected) {
                        card.style.display = '';
                        card.classList.remove('filtered');
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    const faqItems = document.querySelectorAll('.faq-item');

    if (faqItems.length) {
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            question.addEventListener('click', () => {
                const isActive = item.classList.contains('active');
                faqItems.forEach(el => el.classList.remove('active'));
                if (!isActive) {
                    item.classList.add('active');
                }
            });
        });
    }
});