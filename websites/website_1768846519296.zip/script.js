document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            siteNav.classList.toggle('is-open');
        });
        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('is-active');
                siteNav.classList.remove('is-open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('acTattooCookieChoice');
        if (!storedChoice) {
            cookieBanner.classList.add('is-visible');
        }
        const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
        const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');

        const handleChoice = (choice) => {
            localStorage.setItem('acTattooCookieChoice', choice);
            cookieBanner.classList.remove('is-visible');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleChoice('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleChoice('declined'));
        }
    }
});