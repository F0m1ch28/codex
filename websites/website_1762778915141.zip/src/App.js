import React from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import Szenarien from './pages/Szenarien';
import Rechner from './pages/Rechner';
import Leitfaden from './pages/Leitfaden';
import Blog from './pages/Blog';
import BlogArticle from './pages/BlogArticle';
import FAQ from './pages/FAQ';
import Impressum from './pages/Impressum';
import Quellen from './pages/Quellen';

const ScrollToTopOnRoute = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

const AppRoutes = () => (
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/szenarien" element={<Szenarien />} />
    <Route path="/rechner" element={<Rechner />} />
    <Route path="/leitfaden" element={<Leitfaden />} />
    <Route path="/blog" element={<Blog />} />
    <Route path="/blog/:slug" element={<BlogArticle />} />
    <Route path="/about" element={<About />} />
    <Route path="/services" element={<Services />} />
    <Route path="/contact" element={<Contact />} />
    <Route path="/faq" element={<FAQ />} />
    <Route path="/terms" element={<Terms />} />
    <Route path="/policy" element={<Privacy />} />
    <Route path="/cookies" element={<CookiePolicy />} />
    <Route path="/impressum" element={<Impressum />} />
    <Route path="/quellen" element={<Quellen />} />
  </Routes>
);

const App = () => {
  return (
    <BrowserRouter>
      <Helmet>
        <html lang="de" />
        <title>ZukunftsKonto – Finanzplanung für heute &amp; morgen</title>
        <meta
          name="description"
          content="ZukunftsKonto unterstützt Familien, Paare und Solohaushalte bei smarter Finanzplanung – mit Szenario-Rechnern, Leitfäden und praxiserprobten Checklisten."
        />
        <meta property="og:title" content="ZukunftsKonto – Finanzplanung für heute & morgen" />
        <meta property="og:description" content="Plane mit Klarheit: Szenario-Tools, Leitfäden und Jahreskalender für starke finanzielle Entscheidungen." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.zukunftskonto.de" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=120" />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Organization',
            name: 'ZukunftsKonto',
            url: 'https://www.zukunftskonto.de',
            logo: 'https://picsum.photos/200/200?random=200',
            sameAs: [
              'https://www.linkedin.com',
              'https://www.instagram.com'
            ]
          })}
        </script>
      </Helmet>
      <ScrollToTopOnRoute />
      <Header />
      <main className="min-h-screen">
        <AppRoutes />
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </BrowserRouter>
  );
};

export default App;