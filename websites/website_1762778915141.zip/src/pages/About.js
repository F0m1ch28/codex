import React from 'react';
import { Helmet } from 'react-helmet';

const teamMembers = [
  {
    name: 'Lea Winter',
    role: 'Finanzplanerin &amp; Research Lead',
    image: 'https://picsum.photos/400/400?random=101',
    bio: 'Bereitet Finanzwissen so auf, dass Familien & Solohaushalte es direkt anwenden können. Schwerpunkte: Haushaltsbudget, Pflegefinanzierung.',
    focus: 'Rücklagenlogik &amp; Checklisten'
  },
  {
    name: 'David Stein',
    role: 'Produkt &amp; UX',
    image: 'https://picsum.photos/400/400?random=102',
    bio: 'Verantwortet das Produktdesign, Mobile-First und Accessibility. Baut Timeline- und Kalendermodule.',
    focus: 'Timeline &amp; Accessibility'
  },
  {
    name: 'Amira Celik',
    role: 'Daten &amp; Evidenz',
    image: 'https://picsum.photos/400/400?random=103',
    bio: 'Recherchiert Gesetze, Förderprogramme und erstellt Evidenzboxen mit Quellenangaben.',
    focus: 'Evidenz &amp; Quellenarbeit'
  }
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>Über uns – ZukunftsKonto Team</title>
        <meta name="description" content="Das Team hinter ZukunftsKonto: Finanzplaner:innen, UX-Designer:innen und Datenexpert:innen mit Fokus auf evidenzbasierte Planung." />
      </Helmet>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <header className="rounded-3xl bg-white p-8 shadow-soft md:p-12">
            <h1 className="font-heading text-3xl font-bold text-primary">Über ZukunftsKonto</h1>
            <p className="mt-3 text-secondary md:w-3/4">
              Wir sind ein interdisziplinäres Team aus Finanzplanung, UX und Sozialforschung. Unser Ziel: komplexe Finanzentscheidungen sichtbar machen – mit Empathie, Fakten und Tools, die sich gut anfühlen.
            </p>
            <div className="mt-6 grid gap-6 md:grid-cols-3">
              <div className="rounded-3xl border border-surface bg-background p-5">
                <p className="font-heading text-lg font-semibold text-primary">Workshops</p>
                <p className="mt-2 text-sm text-secondary">Quartalsweise Sessions mit Familien, Pflegenden und Soloselbstständigen.</p>
              </div>
              <div className="rounded-3xl border border-surface bg-background p-5">
                <p className="font-heading text-lg font-semibold text-primary">Design &amp; UX</p>
                <p className="mt-2 text-sm text-secondary">Mobile-first. WCAG 2.1 AA geprüft. Druck- &amp; Exportfunktion inklusive.</p>
              </div>
              <div className="rounded-3xl border border-surface bg-background p-5">
                <p className="font-heading text-lg font-semibold text-primary">Evidenz</p>
                <p className="mt-2 text-sm text-secondary">Wir verlinken jede Zahl. Keine Spekulationen, keine leeren Versprechen.</p>
              </div>
            </div>
          </header>

          <section className="mt-12">
            <h2 className="font-heading text-2xl font-bold text-primary">Team</h2>
            <div className="mt-6 grid gap-8 md:grid-cols-3">
              {teamMembers.map((member) => (
                <div key={member.name} className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
                  <img src={member.image} alt={`${member.name}, ${member.role}`} className="h-48 w-full rounded-2xl object-cover" />
                  <h3 className="mt-4 font-heading text-xl font-semibold text-primary">{member.name}</h3>
                  <p className="text-sm text-secondary">{member.role}</p>
                  <p className="mt-3 text-sm text-secondary">{member.bio}</p>
                  <span className="mt-3 inline-flex rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold text-accent">{member.focus}</span>
                </div>
              ))}
            </div>
          </section>
        </div>
      </section>
    </>
  );
};

export default About;