import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

const blogPosts = [
  {
    slug: 'elternzeit-budget-plan',
    title: 'Elternzeitbudget planen – aktualisierte Grenzwerte 2024',
    excerpt: 'Wie Elternzeitmodelle und Elterngeldreformen ineinandergreifen – plus Budgetvorlagen.',
    image: 'https://picsum.photos/800/600?random=81',
    category: 'Familienbudget',
    date: '15.01.2024'
  },
  {
    slug: 'energiepuffer-haushalt',
    title: 'Energiepuffer im Haushalt: Reserve clever dimensionieren',
    excerpt: 'Preisindices und Verbrauchsszenarien – so bleibst du liquide, wenn Tarife steigen.',
    image: 'https://picsum.photos/800/600?random=82',
    category: 'Energie & Wohnen',
    date: '02.02.2024'
  },
  {
    slug: 'weiterbildung-finanzieren',
    title: 'Weiterbildung finanzieren: Förderungen & Cashflow',
    excerpt: 'Welche Zuschüsse verfügbar sind und wie du Übergangsphasen finanzierst.',
    image: 'https://picsum.photos/800/600?random=83',
    category: 'Karriere & Bildung',
    date: '28.02.2024'
  }
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Blog – ZukunftsKonto Insights</title>
        <meta name="description" content="Aktuelle Artikel zu Elternzeitbudget, Energiepuffer und Weiterbildungskosten – mit Quellen und Checklisten." />
        <meta property="og:title" content="ZukunftsKonto Blog" />
        <meta property="og:description" content="Evidenzbasierte Artikel rund um Finanzplanung, Familienbudget, Energie und Weiterbildung." />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=88" />
      </Helmet>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <header className="mb-10">
            <h1 className="font-heading text-3xl font-bold text-primary">Blog &amp; Updates</h1>
            <p className="mt-3 text-secondary md:w-3/4">
              Wir bereiten komplexe Themen so auf, dass du sie direkt in deine Planung integrieren kannst – ohne Finanzjargon, mit transparenten Quellen.
            </p>
          </header>
          <div className="grid gap-8 md:grid-cols-3">
            {blogPosts.map((post) => (
              <article key={post.slug} className="rounded-3xl border border-surface bg-white shadow-soft transition hover:-translate-y-1">
                <img src={post.image} alt={post.title} className="h-48 w-full rounded-t-3xl object-cover" />
                <div className="space-y-3 p-6">
                  <span className="inline-block rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold text-accent">{post.category}</span>
                  <h2 className="font-heading text-xl font-semibold text-primary">{post.title}</h2>
                  <p className="text-sm text-secondary">{post.excerpt}</p>
                  <p className="text-xs text-secondary">Veröffentlicht am {post.date}</p>
                  <Link to={`/blog/${post.slug}`} className="inline-flex items-center text-sm font-semibold text-accent">
                    Beitrag lesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;