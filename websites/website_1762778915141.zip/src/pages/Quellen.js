import React from 'react';
import { Helmet } from 'react-helmet';

const sources = [
  { title: 'BMFSFJ – Elterngeldreform 2024', link: 'https://www.bmfsfj.de' },
  { title: 'Bundesverband der Energie- und Wasserwirtschaft (BDEW) – Energiemonitor 2023/24', link: 'https://www.bdew.de' },
  { title: 'Bundesagentur für Arbeit – Bildungsgutschein Merkblatt 2024', link: 'https://www.arbeitsagentur.de' },
  { title: 'BMBF – Aufstiegs-BAföG', link: 'https://www.aufstiegs-bafoeg.de' },
  { title: 'Verbraucherzentrale Bundesverband – Budgetanalyse 2023', link: 'https://www.vzbv.de' },
  { title: 'BMWK Förderdatenbank – Energieeffizienz', link: 'https://www.foerderdatenbank.de' }
];

const Quellen = () => {
  return (
    <>
      <Helmet>
        <title>Quellen &amp; Evidenz – ZukunftsKonto</title>
        <meta name="description" content="Unsere Evidenzbasis: seriöse Quellen für Finanzplanung, Förderungen, Energie und Pflege." />
      </Helmet>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-4xl rounded-3xl bg-white p-8 shadow-soft">
          <h1 className="font-heading text-3xl font-bold text-primary">Quellenverzeichnis</h1>
          <p className="mt-3 text-secondary">
            Wir aktualisieren dieses Verzeichnis regelmäßig. Hinweis: Manche Quellen führen auf externe Seiten.
          </p>
          <ul className="mt-6 space-y-3 text-sm text-secondary">
            {sources.map((source) => (
              <li key={source.title} className="rounded-2xl border border-surface bg-background px-4 py-3">
                <a href={source.link} target="_blank" rel="noreferrer" className="text-accent">{source.title}</a>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
};

export default Quellen;