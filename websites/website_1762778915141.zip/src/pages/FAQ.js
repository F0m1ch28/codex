import React from 'react';
import { Helmet } from 'react-helmet';

const faqItems = [
  {
    question: 'Wie oft aktualisiert ihr Daten & Quellen?',
    answer: 'Monatlich prüfen wir Förderprogramme, Gesetze und Indizes. Quartalsweise veröffentlichen wir Update-Notes mit Versionsangaben.'
  },
  {
    question: 'Kann ich Szenarien teilen?',
    answer: 'Ja. Du kannst Personen einladen, Aufgaben zuweisen und Kommentare hinterlassen. Wir setzen auf DSGVO-konforme Speicherung.'
  },
  {
    question: 'Gibt es persönliche Beratung?',
    answer: 'Auf Wunsch bieten wir Workshops und Fokus-Sessions (remote oder in Berlin). Ohne Vertriebssprech – mit klarer Agenda.'
  },
  {
    question: 'Unterstützt ihr Unternehmen?',
    answer: 'Ja. Wir entwickeln Programme für Arbeitgeber:innen, die Familienfreundlichkeit und Pflegeverantwortung stärken wollen.'
  }
];

const FAQ = () => {
  const [activeIndex, setActiveIndex] = React.useState(0);

  return (
    <>
      <Helmet>
        <title>FAQ – Häufige Fragen</title>
        <meta name="description" content="Antworten auf häufige Fragen zu Szenarien, Datenaktualisierung, Zusammenarbeit und Datenschutz." />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'FAQPage',
            mainEntity: faqItems.map((item) => ({
              '@type': 'Question',
              name: item.question,
              acceptedAnswer: { '@type': 'Answer', text: item.answer }
            }))
          })}
        </script>
      </Helmet>
      <section className="bg-white py-20">
        <div className="mx-auto max-w-3xl px-4">
          <h1 className="font-heading text-3xl font-bold text-primary">FAQ</h1>
          <p className="mt-3 text-secondary">
            Transparente Antworten auf deine Fragen. Keine versteckten Bedingungen – nur Klartext.
          </p>
          <div className="mt-8 space-y-4">
            {faqItems.map((item, index) => (
              <div key={item.question} className="rounded-3xl border border-surface bg-background p-5">
                <button
                  className="flex w-full items-center justify-between text-left"
                  onClick={() => setActiveIndex(activeIndex === index ? -1 : index)}
                  aria-expanded={activeIndex === index}
                >
                  <span className="font-heading text-lg font-semibold text-primary">{item.question}</span>
                  <span className="text-2xl text-accent">{activeIndex === index ? '−' : '+'}</span>
                </button>
                {activeIndex === index && (
                  <p className="mt-3 text-sm text-secondary">{item.answer}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default FAQ;