import React from 'react';
import { Helmet } from 'react-helmet';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Datenschutz – ZukunftsKonto</title>
        <meta name="description" content="Datenschutzerklärung von ZukunftsKonto. Erläutert Datenarten, Zwecke, Rechtsgrundlagen und Rechte der Nutzer:innen." />
      </Helmet>
      <section className="bg-white py-20">
        <div className="mx-auto max-w-4xl rounded-3xl bg-background p-8 shadow-soft">
          <h1 className="font-heading text-3xl font-bold text-primary">Datenschutzerklärung</h1>
          <p className="mt-3 text-secondary">Stand: 01. März 2024</p>
          <div className="mt-6 space-y-4 text-sm text-secondary">
            <p>Wir verarbeiten personenbezogene Daten (Name, E-Mail, Nutzungsdaten) zur Bereitstellung unserer Plattform, zur Kommunikation und zur Verbesserung der Funktionen.</p>
            <p>Rechtsgrundlagen: Art. 6 Abs. 1 lit. b DSGVO (Vertrag) und lit. f (berechtigtes Interesse an Produktverbesserung). Bei Newsletter: Art. 6 Abs. 1 lit. a (Einwilligung).</p>
            <p>Speicherdauer: personenbezogene Daten werden gelöscht, sobald der Zweck entfällt. Backups mit Aufbewahrungsfrist 12 Monate.</p>
            <p>Analysen: Wir nutzen anonymisierte Nutzungsstatistiken ohne Profilbildung.</p>
            <p>Betroffenenrechte: Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch, Datenübertragbarkeit. Kontaktiere uns via kontakt@zukunftskonto.de.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Privacy;