import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

const articles = {
  'elternzeit-budget-plan': {
    title: 'Elternzeitbudget planen – aktualisierte Grenzwerte 2024',
    description: 'Elterngeldreform, Steuerklassen und Budget-Strategien für unterschiedliche Einkommenssituationen.',
    category: 'Familienbudget',
    date: '15.01.2024',
    readingTime: '8 Minuten',
    image: 'https://picsum.photos/1200/800?random=91',
    content: [
      'Elternzeit bedeutet Einkommenslücken, veränderte Abgaben und neue Ausgaben. 2024 gelten niedrigere Einkommensgrenzen für das volle Elterngeld. Wichtig ist daher die rechtzeitige Planung von Partnermonaten, Splitting von ElterngeldPlus und Kombination mit Teilzeit.',
      'Schritt 1: Haushaltsbudget prüfen. Fixkosten vs. variable Kosten, potenzielle Kürzungen identifizieren. Schritt 2: Elterngeldrechner nutzen (BMFSFJ), Partnermonate taktisch einsetzen. Schritt 3: Krankenversicherung prüfen – freiwillige gesetzliche Beiträge können steigen, private Tarife verlangen Mindestbeiträge.',
      'Steuern: Ein Steuerklassenwechsel kann sinnvoll sein, muss aber 7 Monate vor Geburt erfolgen, um zu greifen. Für Selbstständige: UVG und Mutterschaftsgeld abklären. Rücklagen: Mindestens 4 Netto-Monate Reserve plus Kita-Einstiegskosten (Durchschnitt 150-350 € je nach Bundesland).',
      'Evidenzbox: BMFSFJ (Elterngeldreform 2024), Deutscher Kita-Verband (Betreuungskosten 2023), Bund der Steuerzahler (Steuerklassenwechsel).'
    ],
    evidenz: 'BMFSFJ, Stand: 10/2023; Deutscher Kita-Verband, Gebührenmonitor 2023; Bund der Steuerzahler, Ratgeber 2024.'
  },
  'energiepuffer-haushalt': {
    title: 'Energiepuffer im Haushalt – Reserve clever dimensionieren',
    description: 'Gas- und Strompreise bleiben volatil. Wir zeigen, wie hoch dein Puffer sein sollte und wie du ihn strukturierst.',
    category: 'Energie & Wohnen',
    date: '02.02.2024',
    readingTime: '6 Minuten',
    image: 'https://picsum.photos/1200/800?random=92',
    content: [
      'Haushalte sollten für 2024 mit einem durchschnittlichen Preisanstieg von 12% rechnen (BDEW Prognose). Strom- und Gasabschläge werden quartalsweise angepasst, besonders nach Abrechnungsspitzen.',
      'Unser Ansatz: Verbrauchsdaten des Vorjahres nehmen, Preissteigerungen simulieren und Puffer als separaten Rücklagentopf führen. Monatliche Entnahmen erst nach zusätzlicher Abrechnung.',
      'Checkliste: 1) Zählerstände dokumentieren. 2) Abschlagsprüfung quartalsweise. 3) Fördermöglichkeiten für Effizienzmaßnahmen prüfen (KfW 461). 4) Notfallplan bei Preissprünge ab 20% aktivieren.',
      'Evidenzbox: BDEW Energiemonitor 12/2023, BMWK Förderdatenbank 2024, Verbraucherzentrale NRW (Stromspar-Check).'
    ],
    evidenz: 'BDEW Energiebericht 12/2023; BMWK Förderdatenbank; Verbraucherzentrale NRW, Stromspar-Check 2023.'
  },
  'weiterbildung-finanzieren': {
    title: 'Weiterbildung finanzieren – Förderungen & Cashflow absichern',
    description: 'Bildungsgutschein, Aufstiegs-BAföG oder Bildungskarenz? So kombinierst du Förderungen ohne finanzielle Schieflage.',
    category: 'Karriere & Bildung',
    date: '28.02.2024',
    readingTime: '7 Minuten',
    image: 'https://picsum.photos/1200/800?random=93',
    content: [
      'Berufliche Weiterbildung kostet Zeit & Geld: Kursgebühren, entgangenes Einkommen und Zusatzkosten für Materialien oder Kinderbetreuung. Deshalb lohnt sich eine strukturierte Finanzierung.',
      'Förderungen: Bildungsgutschein (Bundesagentur für Arbeit), Aufstiegs-BAföG (bis 75% Zuschuss), Bildungsprämie (eingestellt 2022, Alternativen: Länderprogramme). Unternehmen nutzen Bildungsurlaub (5 Tage p.a. in meisten Bundesländern).',
      'Cashflow-Strategien: 1) Übergangsbudget mit Rücklagen und ggf. Nebenjobs aufbauen. 2) Krankenversicherung bei Teilzeit oder Freistellung klären. 3) Steuerliche Absetzbarkeit für Werbungskosten nutzen.',
      'Zeitplan: Mindestens 6 Monate vor Start Förderprogramme prüfen. Bei längerer Auszeit: Notgroschen erhöhen und Versicherungen (Berufsunfähigkeit, Haftpflicht) prüfen.',
      'Evidenzbox: Bundesagentur für Arbeit (Bildungsgutschein 2024), Aufstiegs-BAföG (BMBF), Stiftung Warentest Weiterbildung (2023).'
    ],
    evidenz: 'Bundesagentur für Arbeit, Merkblatt 2024; BMBF Aufstiegs-BAföG; Stiftung Warentest Weiterbildung 11/2023.'
  }
};

const BlogArticle = () => {
  const { slug } = useParams();
  const article = articles[slug];

  if (!article) {
    return (
      <section className="bg-background py-20">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <h1 className="font-heading text-3xl font-bold text-primary">Beitrag nicht gefunden</h1>
          <p className="mt-3 text-secondary">Der gesuchte Artikel ist nicht verfügbar. Bitte kehre zum Blog zurück.</p>
          <Link to="/blog" className="mt-6 inline-flex items-center text-sm font-semibold text-accent">
            Zurück zum Blog →
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{article.title} – ZukunftsKonto Blog</title>
        <meta name="description" content={article.description} />
        <meta property="og:title" content={article.title} />
        <meta property="og:description" content={article.description} />
        <meta property="og:image" content={article.image} />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Article',
            headline: article.title,
            datePublished: article.date,
            author: { '@type': 'Organization', name: 'ZukunftsKonto' },
            articleSection: article.category,
            image: article.image,
            description: article.description
          })}
        </script>
      </Helmet>
      <article className="bg-white py-20">
        <div className="mx-auto max-w-3xl px-4 md:px-0">
          <Link to="/blog" className="text-sm font-semibold text-accent">← Zurück zum Blog</Link>
          <header className="mt-6">
            <span className="rounded-full bg-accent/10 px-3 py-1 text-xs font-semibold text-accent">{article.category}</span>
            <h1 className="mt-4 font-heading text-3xl font-bold text-primary">{article.title}</h1>
            <p className="mt-2 text-sm text-secondary">
              {article.date} · {article.readingTime}
            </p>
          </header>
          <figure className="mt-8">
            <img src={article.image} alt={article.title} className="w-full rounded-3xl object-cover shadow-soft" />
            <figcaption className="mt-2 text-xs text-secondary">Symbolfoto: Finanzplanung mit Fokus auf {article.category}</figcaption>
          </figure>
          <div className="prose prose-invert prose-headings:font-heading prose-headings:text-primary prose-lg mt-10 max-w-none text-secondary">
            {article.content.map((paragraph, idx) => (
              <p key={idx}>{paragraph}</p>
            ))}
          </div>
          <aside className="mt-10 rounded-3xl border border-surface bg-background p-6 shadow-soft">
            <h2 className="font-heading text-xl font-semibold text-primary">Evidenzbox</h2>
            <p className="mt-3 text-sm text-secondary">{article.evidenz}</p>
          </aside>
        </div>
      </article>
    </>
  );
};

export default BlogArticle;