import React from 'react';
import { Helmet } from 'react-helmet';

const Leitfaden = () => {
  const sections = [
    {
      title: 'Finanzielle Grundlagen',
      content: [
        'Monatliche Budgets strukturieren: Fixkosten, variable Ausgaben, Rücklagen.',
        'Liquiditätssteuerung: Kontenmodell und automatisierte Überweisungen.',
        'Inflationsanpassung: jährliche Aktualisierung der Budgets.'
      ],
      icon: '📘'
    },
    {
      title: 'Versicherungen nach Lebensphase',
      content: [
        'Single & Berufseinstieg: Haftpflicht, Berufsunfähigkeit in Prüfung.',
        'Familiengründung: Risiko-LV, Krankenzusatz, Kinderabsicherung.',
        'Pflege & Ruhestand: Pflegezusatz, Wohnimmobilien-Schutz, Patientenverfügung.'
      ],
      icon: '🛡️'
    },
    {
      title: 'Steuerbasics & Fristen',
      content: [
        'Steuerklassenwechsel rechtzeitig mitdenken (BayBG 2024).',
        'Fortbildungskosten als Werbungskosten / Sonderausgaben eintragen.',
        'Pflege-Pauschbetrag & haushaltsnahe Dienstleistungen nutzen.'
      ],
      icon: '📆'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Leitfaden – Grundlagen &amp; Praxiswissen</title>
        <meta name="description" content="Grundlagen, Versicherungen und Steuerbasics – strukturiert nach Lebensphasen und angereichert mit verlässlichen Quellen." />
        <meta property="og:title" content="Leitfaden Finanzplanung" />
        <meta property="og:description" content="Finanzwissen, Versicherungen und Steuerbasics mit Quellen und Handlungsschritten." />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=73" />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Article',
            headline: 'Finanzleitfaden für Familien und Solohaushalte',
            author: {
              '@type': 'Organization',
              name: 'ZukunftsKonto'
            },
            datePublished: '2024-02-01',
            image: 'https://picsum.photos/1200/630?random=73',
            articleSection: 'Finanzplanung'
          })}
        </script>
      </Helmet>
      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="rounded-3xl bg-background p-8 shadow-soft md:p-12">
            <h1 className="font-heading text-3xl font-bold text-primary">Leitfaden: Grundlagen, Versicherungen, Steuern</h1>
            <p className="mt-4 text-secondary md:w-3/4">
              Kein Marketing-Blabla – hier findest du Handlungswissen, das in Workshops erprobt wurde. Mit Schema.org-HowTo, Quellen und Zugriff auf vertiefende Artikel.
            </p>
            <div className="mt-6 grid gap-6 md:grid-cols-3">
              {sections.map((section) => (
                <div key={section.title} className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
                  <span className="text-3xl">{section.icon}</span>
                  <h2 className="mt-4 font-heading text-xl font-semibold text-primary">{section.title}</h2>
                  <ul className="mt-3 space-y-2 text-sm text-secondary">
                    {section.content.map((item, idx) => (
                      <li key={idx}>• {item}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <div className="mt-10 rounded-3xl bg-primary p-6 text-white shadow-soft md:p-8">
              <h3 className="font-heading text-2xl font-semibold">Schritt-für-Schritt: Finanzplanung aufsetzen</h3>
              <ol className="mt-4 space-y-3 text-sm text-gray-200">
                <li><span className="font-semibold text-white">1.</span> Nettoeinnahmen &amp; Fixkosten erfassen – Fokus auf 6 zentrale Kategorien.</li>
                <li><span className="font-semibold text-white">2.</span> Rücklagen-Töpfe definieren: Notgroschen, Projekte, Vorsorge.</li>
                <li><span className="font-semibold text-white">3.</span> Szenarien wählen und Timeline erstellen.</li>
                <li><span className="font-semibold text-white">4.</span> Versicherungen &amp; Absicherungen anpassen.</li>
                <li><span className="font-semibold text-white">5.</span> Steuer-Deadlines notieren &amp; Jahreskalender aktiv nutzen.</li>
              </ol>
              <p className="mt-6 text-xs text-gray-300">
                Quellen: Verbraucherzentrale (Budgetierung 2023), BMAS (Pflegezeitgesetz), BMF (Steuerliche Absetzbarkeit von Fortbildungskosten 2024).
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Leitfaden;