import React from 'react';
import { Helmet } from 'react-helmet';

const scenarioData = [
  {
    id: 'elternzeit',
    title: 'Elternzeit-Budget',
    description: 'Berechne Einkommenslücken, verteilte Elterngeldmonate und Zusatzkosten wie Betreuung, Krankenversicherung oder Weiterbildung.',
    image: 'https://picsum.photos/800/600?random=51',
    checklist: [
      'Elterngeld-Zeiten und Partnermonate abstimmen',
      'Krankenversicherung während Elternzeit klären',
      'Betreuungskosten & Kita-Eintritt kalkulieren',
      'Rücklagen für Einkommenslücken auffüllen',
      'Steuerklassenwechsel rechtzeitig planen'
    ],
    timeline: [
      { label: 'Vor Geburt (6 Monate)', tasks: 'Elternzeitverteilung festlegen, Arbeitgeber informieren, Budget puffer definieren.' },
      { label: 'Monat 0-3', tasks: 'Elterngeld-Antrag, Versicherungsstatus prüfen, Notgroschen schützen.' },
      { label: 'Monat 6-12', tasks: 'Kita-Platz sichern, Betreuungskosten anpassen, beruflichen Wiedereinstieg planen.' },
      { label: 'Monat 12-24', tasks: 'Steuererklärung, Rückkehr in Voll-/Teilzeit, Vorsorgeupdate.' }
    ]
  },
  {
    id: 'weiterbildung',
    title: 'Weiterbildung finanzieren',
    description: 'Nimm Bildungsurlaub, Förderprogramme und Freistellungen unter die Lupe – mit Cashflow-Plan und Zeitbudget.',
    image: 'https://picsum.photos/800/600?random=52',
    checklist: [
      'Förderprogramme recherchieren (Bildungsgutschein, Meister-BAföG)',
      'Arbeitszeitmodelle und Freistellungen prüfen',
      'Lebenshaltungskosten vs. Einkommen abgleichen',
      'Notgroschen sichern und Übergang planen',
      'Weiterbildungskosten steuerlich berücksichtigen'
    ],
    timeline: [
      { label: 'Monat -9', tasks: 'Ziele festlegen, geeignete Programme vergleichen, Budgetrahmen definieren.' },
      { label: 'Monat -6', tasks: 'Anträge stellen, Arbeitgeber abstimmen, Finanzierung fixieren.' },
      { label: 'Monat 0', tasks: 'Start Weiterbildung: Cashflow prüfen, Lernzeit organisieren.' },
      { label: 'Monat +6', tasks: 'Plan reviewen: Rücklagen erhöhen, Karrierepfad konkretisieren.' }
    ]
  },
  {
    id: 'umzug',
    title: 'Umzug & neues Zuhause',
    description: 'Berücksichtige Mietkaution, Doppelmiete, Renovierung und Möblierung. Mit individueller Zeitachse bis zum Einzug.',
    image: 'https://picsum.photos/800/600?random=53',
    checklist: [
      'Mietvertrag prüfen, Kündigungsfristen planen',
      'Kaution & Umzugskosten absichern',
      'Strom, Gas, Internet rechtzeitig ummelden',
      'Renovierungsbudget & Zeitpuffer einplanen',
      'Adressänderungen & Versicherungen updaten'
    ],
    timeline: [
      { label: 'Monat -3', tasks: 'Wohnung sichern, Budget aktualisieren, Dienstleister anfragen.' },
      { label: 'Monat -1', tasks: 'Versicherungen & Energieanbieter umstellen, Packplan erstellen.' },
      { label: 'Einzug', tasks: 'Umzugshelfer koordinieren, Übergabeprotokolle bearbeiten.' },
      { label: 'Monat +1', tasks: 'Ämtergänge abschließen, Doppelkosten ausgleichen.' }
    ]
  },
  {
    id: 'pflege',
    title: 'Pflegefall bewältigen',
    description: 'Pflegegrade, Zuschüsse und Entlastungsangebote im Blick behalten – mit Zeitplan für Umbauten & Organisation.',
    image: 'https://picsum.photos/800/600?random=54',
    checklist: [
      'Pflegegrad beantragen und Widerspruchsfrist notieren',
      'Wohnumfeld anpassen & Zuschüsse beantragen',
      'Entlastungsleistungen und Kurzzeitpflege organisieren',
      'Pflegezeit- oder Familienpflegezeit prüfen',
      'Pflegekosten, Eigenanteil und Rücklagen abgleichen'
    ],
    timeline: [
      { label: 'Monat 0', tasks: 'Akutsituation: Pflegeberatung, Antrag, Übergänge organisieren.' },
      { label: 'Monat 1-3', tasks: 'Wohnumfeldanpassung, Entlastungsangebote nutzen.' },
      { label: 'Monat 4-12', tasks: 'Kostenmonitoring, Pflegegradüberprüfung, Steuererleichterungen.' },
      { label: 'Monat 12+', tasks: 'Langfristige Finanzierung, Vorsorgevollmacht, Angehörigen-Unterstützung.' }
    ]
  },
  {
    id: 'renovierung',
    title: 'Renovierung & Sanierung',
    description: 'Von Energieeffizienz bis Barrierefreiheit – kalkuliere Material, Handwerkerkosten und Fördermöglichkeiten.',
    image: 'https://picsum.photos/800/600?random=55',
    checklist: [
      'Projektumfang definieren & Prioritäten setzen',
      'Kostenangebote und Puffer vergleichen',
      'Förderprogramme prüfen (KfW, BAFA)',
      'Zeitplan mit Lieferzeiten und Urlaub abstimmen',
      'Versicherungen und Bauabnahmen organisieren'
    ],
    timeline: [
      { label: 'Monat -4', tasks: 'Projektplan, Finanzierung klären, Förderanträge stellen.' },
      { label: 'Monat -1', tasks: 'Material bestellen, Handwerker terminieren, Rücklagen separieren.' },
      { label: 'Bauphase', tasks: 'Kosten-Tracking, Qualitätscheck, Puffer für Verzögerungen.' },
      { label: 'Abschluss', tasks: 'Abnahmen, Rechnungen bündeln, Energieverbrauch dokumentieren.' }
    ]
  }
];

const Szenarien = () => {
  const [selectedScenario, setSelectedScenario] = React.useState(scenarioData[0]);
  const handlePrint = () => {
    window.print();
  };

  return (
    <>
      <Helmet>
        <title>Szenarien – Finanzplanung mit Plan</title>
        <meta
          name="description"
          content="Fünf Szenarien für Familien, Pflege und Weiterbildung. Mit Checklisten, Zeitplänen und Druckfunktion für deine Finanzplanung."
        />
        <meta property="og:title" content="Szenarien – Elternzeit, Pflege, Weiterbildung & mehr" />
        <meta property="og:description" content="Nutze unsere Szenario-Module mit druckbaren Checklisten, Zeitlinien und Evidenzboxen." />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=56" />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'FAQPage',
            mainEntity: scenarioData.map((scenario) => ({
              '@type': 'Question',
              name: `Wie plane ich ${scenario.title}?`,
              acceptedAnswer: {
                '@type': 'Answer',
                text: scenario.description
              }
            }))
          })}
        </script>
      </Helmet>
      <section className="bg-gradient-to-b from-background via-white to-background py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="rounded-3xl bg-white p-6 shadow-soft md:p-10">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="font-heading text-3xl font-bold text-primary">Szenarien: Von Elternzeit bis Pflegefall</h1>
                <p className="mt-3 text-secondary md:w-3/4">
                  Wähle ein Szenario, erkunde Zeitplan und Checklisten, und exportiere bei Bedarf deine Meilensteine als Druckversion.
                </p>
              </div>
              <button
                onClick={handlePrint}
                className="inline-flex items-center rounded-full border border-accent px-6 py-2 text-sm font-semibold text-accent transition hover:bg-accent hover:text-white"
              >
                Checklisten drucken
              </button>
            </div>
            <div className="mt-8 grid gap-4 md:grid-cols-5">
              {scenarioData.map((scenario) => (
                <button
                  key={scenario.id}
                  onClick={() => setSelectedScenario(scenario)}
                  className={`rounded-2xl border px-4 py-3 text-left text-sm transition ${selectedScenario.id === scenario.id ? 'border-accent bg-accent/10 text-primary shadow-soft' : 'border-surface bg-background text-secondary hover:border-accent hover:bg-accent/5'}`}
                >
                  <span className="font-semibold text-primary">{scenario.title}</span>
                  <p className="mt-1 text-xs">{scenario.description}</p>
                </button>
              ))}
            </div>
            <div className="mt-10 grid gap-8 md:grid-cols-2">
              <div className="overflow-hidden rounded-3xl">
                <img src={selectedScenario.image} alt={selectedScenario.title} className="h-full w-full object-cover" />
              </div>
              <div className="space-y-6">
                <div className="rounded-3xl border border-surface bg-background p-6">
                  <h2 className="font-heading text-2xl font-semibold text-primary">Checkliste</h2>
                  <ul className="mt-4 space-y-3 text-sm text-secondary print:text-black">
                    {selectedScenario.checklist.map((item, idx) => (
                      <li key={idx} className="flex gap-3">
                        <span className="mt-1 inline-flex h-6 w-6 flex-none items-center justify-center rounded-full bg-accent/10 font-semibold text-accent">
                          {idx + 1}
                        </span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
                  <h2 className="font-heading text-2xl font-semibold text-primary">Zeitplan &amp; Meilensteine</h2>
                  <div className="mt-4 space-y-4">
                    {selectedScenario.timeline.map((entry, idx) => (
                      <div key={idx} className="rounded-2xl border border-surface bg-background p-4">
                        <p className="text-xs font-semibold uppercase tracking-wide text-accent">{entry.label}</p>
                        <p className="mt-2 text-sm text-secondary">{entry.tasks}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              <div className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
                <h3 className="font-heading text-lg font-semibold text-primary">Rollen &amp; Verantwortlichkeiten</h3>
                <p className="mt-3 text-sm text-secondary">
                  Weise Aufgaben Personen zu, verfolge Statusänderungen und Kommentare – perfekt für Familien oder Teams.
                </p>
              </div>
              <div className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
                <h3 className="font-heading text-lg font-semibold text-primary">Liquiditäts-Ampel</h3>
                <p className="mt-3 text-sm text-secondary">
                  Visualisiere, ob deine Rücklagen in jeder Phase ausreichen. Ampelstatus in Echtzeit auf Basis deiner Eingaben.
                </p>
              </div>
              <div className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
                <h3 className="font-heading text-lg font-semibold text-primary">Evidenzbox</h3>
                <p className="mt-3 text-sm text-secondary">
                  Elternzeit: BMFSFJ, Pflege: Pflegekassen &amp; Sozialgesetzbuch, Weiterbildung: Bundesagentur für Arbeit – verlinkt für schnellen Faktencheck.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Szenarien;