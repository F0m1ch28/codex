import React from 'react';
import { Helmet } from 'react-helmet';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Nutzungsbedingungen – ZukunftsKonto</title>
        <meta name="description" content="Nutzungsbedingungen für ZukunftsKonto. Transparente Regeln für den Einsatz unserer Tools und Inhalte." />
      </Helmet>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-4xl rounded-3xl bg-white p-8 shadow-soft">
          <h1 className="font-heading text-3xl font-bold text-primary">Nutzungsbedingungen</h1>
          <p className="mt-3 text-secondary">
            Stand: 01. März 2024
          </p>
          <div className="mt-6 space-y-4 text-sm text-secondary">
            <p>1. ZukunftsKonto stellt Tools zur Finanzplanung bereit. Unsere Inhalte ersetzen keine individuelle Steuer- oder Rechtsberatung.</p>
            <p>2. Nutzer:innen sind verantwortlich für die Eingabe korrekter Daten. Ergebnisse gelten als Szenarien, nicht als Garantien.</p>
            <p>3. Inhalte dürfen mit Quellenangabe geteilt werden. Kommerzielle Nutzung bedarf einer schriftlichen Vereinbarung.</p>
            <p>4. Wir übernehmen keine Haftung für externe Links. Wir wählen Quellen sorgfältig aus, können jedoch keine Gewähr übernehmen.</p>
            <p>5. Datensicherheit: Wir verarbeiten personenbezogene Daten nur zur Bereitstellung unserer Services. Details siehe Datenschutz.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Terms;