import React from 'react';
import { Helmet } from 'react-helmet';

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie-Richtlinie – ZukunftsKonto</title>
        <meta name="description" content="Cookie-Richtlinie von ZukunftsKonto: Welche Cookies wir einsetzen und wie du sie verwaltest." />
      </Helmet>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-4xl rounded-3xl bg-white p-8 shadow-soft">
          <h1 className="font-heading text-3xl font-bold text-primary">Cookie-Richtlinie</h1>
          <div className="mt-6 space-y-4 text-sm text-secondary">
            <p>Wir setzen funktionale Cookies ein, um Logins zu speichern und Formularstatus zu sichern. Analytische Cookies werden nur mit Einwilligung aktiviert.</p>
            <p>Cookie-Typen:</p>
            <ul className="list-disc pl-6">
              <li>Essentiell: Session-Cookies (Speicherdauer: Sitzung)</li>
              <li>Präferenzen: Spracheinstellungen (Speicherdauer: 6 Monate)</li>
              <li>Analyse (optional): Matomo, anonymisiert (Speicherdauer: 13 Monate)</li>
            </ul>
            <p>Du kannst Cookies jederzeit in deinem Browser löschen oder den Cookie-Banner nutzen, um Einwilligungen anzupassen.</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;