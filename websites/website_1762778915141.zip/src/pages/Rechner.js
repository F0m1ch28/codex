import React from 'react';
import { Helmet } from 'react-helmet';

const Rechner = () => {
  const [inflationInput, setInflationInput] = React.useState({ amount: '', rate: '2.8', years: '3' });
  const [inflationResult, setInflationResult] = React.useState(null);

  const [reserveInput, setReserveInput] = React.useState({ monthly: '', months: '6' });
  const [reserveResult, setReserveResult] = React.useState(null);

  const [holidayInput, setHolidayInput] = React.useState({ persons: '2', days: '10', daily: '' });
  const [holidayResult, setHolidayResult] = React.useState(null);

  const [debtInput, setDebtInput] = React.useState({ balance: '', rate: '3.8', payment: '' });
  const [debtResult, setDebtResult] = React.useState(null);

  const [energyInput, setEnergyInput] = React.useState({ monthlyCost: '', increase: '12', months: '6' });
  const [energyResult, setEnergyResult] = React.useState(null);

  const calculateInflation = (e) => {
    e.preventDefault();
    const amount = parseFloat(inflationInput.amount);
    const rate = parseFloat(inflationInput.rate) / 100;
    const years = parseFloat(inflationInput.years);
    if (!amount || !rate || !years) return;
    const futureValue = amount * Math.pow(1 + rate, years);
    setInflationResult(futureValue);
  };

  const calculateReserve = (e) => {
    e.preventDefault();
    const monthly = parseFloat(reserveInput.monthly);
    const months = parseInt(reserveInput.months, 10);
    if (!monthly || !months) return;
    setReserveResult(monthly * months);
  };

  const calculateHoliday = (e) => {
    e.preventDefault();
    const persons = parseInt(holidayInput.persons, 10);
    const days = parseInt(holidayInput.days, 10);
    const daily = parseFloat(holidayInput.daily);
    if (!persons || !days || !daily) return;
    setHolidayResult(persons * days * daily);
  };

  const calculateDebt = (e) => {
    e.preventDefault();
    const balance = parseFloat(debtInput.balance);
    const rate = parseFloat(debtInput.rate) / 100 / 12;
    const payment = parseFloat(debtInput.payment);
    if (!balance || !rate || !payment) return;
    const months = Math.log(payment / (payment - rate * balance)) / Math.log(1 + rate);
    setDebtResult(months);
  };

  const calculateEnergy = (e) => {
    e.preventDefault();
    const monthlyCost = parseFloat(energyInput.monthlyCost);
    const increase = parseFloat(energyInput.increase) / 100;
    const months = parseInt(energyInput.months, 10);
    if (!monthlyCost || !increase || !months) return;
    const buffer = monthlyCost * (1 + increase) * months;
    setEnergyResult(buffer);
  };

  return (
    <>
      <Helmet>
        <title>Rechner &amp; Planer – ZukunftsKonto</title>
        <meta name="description" content="Inflationscheck, Rücklagen-Planer, Urlaubskosten, Schuldentilgung und Energiepuffer – alles in einem Dashboard." />
        <meta property="og:title" content="Rechner &amp; Planer" />
        <meta property="og:description" content="Nutze unsere Rechner, um Rücklagen, Inflation, Urlaubskosten, Schulden und Energiepuffer zu strukturieren." />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=63" />
      </Helmet>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl space-y-10 px-4 md:px-8">
          <header className="rounded-3xl bg-white p-8 shadow-soft">
            <h1 className="font-heading text-3xl font-bold text-primary">Rechner &amp; Puffer-Planer</h1>
            <p className="mt-3 text-secondary md:w-2/3">
              Passe deine Zahlen an, beobachte sofort die Auswirkungen und sichere dir mit wenigen Klicks verlässliche Finanzpuffer. Alle Werte basieren auf aktuellen Richtlinien (siehe Evidenzbox).
            </p>
            <div className="mt-6 rounded-2xl border border-surface bg-background p-4 text-sm text-secondary">
              <p className="font-semibold text-primary">Evidenzbox</p>
              <p>Inflationsannahme EU: 2,7% (EU-Kommission, Frühjahr 2024). Heizkostenanstieg Prognose 12% (BDEW, Dez 2023). Schuldentilgung nach Annuitätenformel.</p>
            </div>
          </header>

          <div className="grid gap-8 lg:grid-cols-2">
            <form onSubmit={calculateInflation} className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
              <h2 className="font-heading text-xl font-semibold text-primary">Inflationscheck</h2>
              <p className="mt-2 text-sm text-secondary">
                Wie viel mehr wirst du in Zukunft für das gleiche Budget benötigen?
              </p>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <label className="text-sm text-secondary">
                  Aktueller Betrag (€)
                  <input
                    type="number"
                    min="0"
                    step="100"
                    value={inflationInput.amount}
                    onChange={(e) => setInflationInput({ ...inflationInput, amount: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Inflation (% p.a.)
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={inflationInput.rate}
                    onChange={(e) => setInflationInput({ ...inflationInput, rate: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Zeitraum (Jahre)
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={inflationInput.years}
                    onChange={(e) => setInflationInput({ ...inflationInput, years: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
              </div>
              <button
                type="submit"
                className="mt-4 rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
              >
                Inflationsbetrag berechnen
              </button>
              {inflationResult && (
                <p className="mt-4 rounded-2xl bg-accent/10 px-4 py-3 text-sm text-accent">
                  Nach {inflationInput.years} Jahren brauchst du ca. {inflationResult.toFixed(2)} €.
                </p>
              )}
            </form>

            <form onSubmit={calculateReserve} className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
              <h2 className="font-heading text-xl font-semibold text-primary">Rücklagen-Planer</h2>
              <p className="mt-2 text-sm text-secondary">Dein individuelles Sicherheitsnetz – aufgeteilt nach Monaten.</p>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <label className="text-sm text-secondary">
                  Monatliche Kosten (€)
                  <input
                    type="number"
                    min="0"
                    step="50"
                    value={reserveInput.monthly}
                    onChange={(e) => setReserveInput({ ...reserveInput, monthly: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Monate Sicherheit
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={reserveInput.months}
                    onChange={(e) => setReserveInput({ ...reserveInput, months: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
              </div>
              <button
                type="submit"
                className="mt-4 rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
              >
                Rücklagenbedarf ermitteln
              </button>
              {reserveResult && (
                <p className="mt-4 rounded-2xl bg-accent/10 px-4 py-3 text-sm text-accent">
                  Empfohlene Rücklage: {reserveResult.toFixed(2)} €.
                </p>
              )}
            </form>

            <form onSubmit={calculateHoliday} className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
              <h2 className="font-heading text-xl font-semibold text-primary">Urlaubskosten-Kalkulator</h2>
              <p className="mt-2 text-sm text-secondary">Plan deine Auszeit inklusive Verpflegung &amp; Aktivitäten.</p>
              <div className="mt-4 grid gap-4 md:grid-cols-3">
                <label className="text-sm text-secondary">
                  Personen
                  <input
                    type="number"
                    min="1"
                    value={holidayInput.persons}
                    onChange={(e) => setHolidayInput({ ...holidayInput, persons: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Tage
                  <input
                    type="number"
                    min="1"
                    value={holidayInput.days}
                    onChange={(e) => setHolidayInput({ ...holidayInput, days: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Tagesbudget (€)
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={holidayInput.daily}
                    onChange={(e) => setHolidayInput({ ...holidayInput, daily: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
              </div>
              <button
                type="submit"
                className="mt-4 rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
              >
                Urlaubskosten berechnen
              </button>
              {holidayResult && (
                <p className="mt-4 rounded-2xl bg-accent/10 px-4 py-3 text-sm text-accent">
                  Gesamtbudget: {holidayResult.toFixed(2)} € (exkl. Reserve).
                </p>
              )}
            </form>

            <form onSubmit={calculateDebt} className="rounded-3xl border border-surface bg-white p-6 shadow-soft">
              <h2 className="font-heading text-xl font-semibold text-primary">Schuldentilgung Tracker</h2>
              <p className="mt-2 text-sm text-secondary">Wie lange brauchst du, um einen Kredit abzuzahlen?</p>
              <div className="mt-4 grid gap-4 md:grid-cols-3">
                <label className="text-sm text-secondary">
                  Restschuld (€)
                  <input
                    type="number"
                    min="0"
                    step="100"
                    value={debtInput.balance}
                    onChange={(e) => setDebtInput({ ...debtInput, balance: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Zins p.a. (%)
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={debtInput.rate}
                    onChange={(e) => setDebtInput({ ...debtInput, rate: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Monatsrate (€)
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={debtInput.payment}
                    onChange={(e) => setDebtInput({ ...debtInput, payment: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
              </div>
              <button
                type="submit"
                className="mt-4 rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
              >
                Tilgungsdauer ermitteln
              </button>
              {debtResult && (
                <p className="mt-4 rounded-2xl bg-accent/10 px-4 py-3 text-sm text-accent">
                  Du bist nach ca. {Math.ceil(debtResult)} Monaten schuldenfrei.
                </p>
              )}
            </form>

            <form onSubmit={calculateEnergy} className="rounded-3xl border border-surface bg-white p-6 shadow-soft lg:col-span-2">
              <h2 className="font-heading text-xl font-semibold text-primary">Energie- &amp; Heizpuffer</h2>
              <p className="mt-2 text-sm text-secondary">Plane Preissteigerungen ein und sichere deine Liquidität.</p>
              <div className="mt-4 grid gap-4 md:grid-cols-4">
                <label className="text-sm text-secondary md:col-span-2">
                  Aktuelle Monatskosten (€)
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={energyInput.monthlyCost}
                    onChange={(e) => setEnergyInput({ ...energyInput, monthlyCost: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Preissteigerung (%)
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={energyInput.increase}
                    onChange={(e) => setEnergyInput({ ...energyInput, increase: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
                <label className="text-sm text-secondary">
                  Monate Reserve
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={energyInput.months}
                    onChange={(e) => setEnergyInput({ ...energyInput, months: e.target.value })}
                    className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                    required
                  />
                </label>
              </div>
              <button
                type="submit"
                className="mt-4 rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
              >
                Energiepuffer berechnen
              </button>
              {energyResult && (
                <p className="mt-4 rounded-2xl bg-accent/10 px-4 py-3 text-sm text-accent">
                  Empfehlung: {energyResult.toFixed(2)} € Rücklage für die nächsten {energyInput.months} Monate.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Rechner;