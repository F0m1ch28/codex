import React from 'react';
import { Helmet } from 'react-helmet';

const Impressum = () => {
  return (
    <>
      <Helmet>
        <title>Impressum – ZukunftsKonto</title>
        <meta name="description" content="Impressum von ZukunftsKonto – Angaben gemäß § 5 TMG." />
      </Helmet>
      <section className="bg-white py-20">
        <div className="mx-auto max-w-4xl rounded-3xl bg-background p-8 shadow-soft">
          <h1 className="font-heading text-3xl font-bold text-primary">Impressum</h1>
          <div className="mt-6 space-y-4 text-sm text-secondary">
            <p>ZukunftsKonto GmbH<br />c/o FinLab Berlin<br />Friedrichstraße 200<br />10117 Berlin</p>
            <p>Kontakt: <a href="mailto:kontakt@zukunftskonto.de" className="text-accent">kontakt@zukunftskonto.de</a><br />Telefon: +49 (0)30 1234 5678</p>
            <p>Geschäftsführung: Lea Winter<br />Registergericht: AG Berlin Charlottenburg, HRB 123456</p>
            <p>USt-IdNr.: DE123456789</p>
            <p>Verantwortlich für Inhalte nach § 55 Abs. 2 RStV: Lea Winter, Friedrichstraße 200, 10117 Berlin</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Impressum;