import React from 'react';
import { Helmet } from 'react-helmet';

const Contact = () => {
  const [formData, setFormData] = React.useState({ name: '', email: '', topic: '', message: '' });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = 'Bitte Name angeben.';
    if (!formData.email || !formData.email.includes('@')) newErrors.email = 'Bitte gültige E-Mail-Adresse eintragen.';
    if (!formData.topic) newErrors.topic = 'Bitte Betreff auswählen.';
    if (!formData.message || formData.message.length < 20) newErrors.message = 'Bitte beschreibe dein Anliegen mit mindestens 20 Zeichen.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length === 0) {
      setSubmitted(true);
      setFormData({ name: '', email: '', topic: '', message: '' });
    } else {
      setErrors(formErrors);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt – ZukunftsKonto</title>
        <meta name="description" content="Kontaktiere ZukunftsKonto: Wir beantworten Fragen zu Szenarien, Leitfäden und Workshops." />
      </Helmet>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-5xl rounded-3xl bg-white p-8 shadow-soft md:p-12">
          <h1 className="font-heading text-3xl font-bold text-primary">Kontakt aufnehmen</h1>
          <p className="mt-3 text-secondary md:w-3/4">
            Frag uns zu individuellen Szenarien, Unternehmensworkshops oder Kooperationen. Wir antworten innerhalb von zwei Werktagen.
          </p>
          <div className="mt-8 grid gap-8 md:grid-cols-2">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="text-sm font-semibold text-primary">Name</label>
                <input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                  aria-invalid={errors.name ? 'true' : 'false'}
                />
                {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
              </div>
              <div>
                <label htmlFor="email" className="text-sm font-semibold text-primary">E-Mail</label>
                <input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
              </div>
              <div>
                <label htmlFor="topic" className="text-sm font-semibold text-primary">Betreff</label>
                <select
                  id="topic"
                  value={formData.topic}
                  onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                  aria-invalid={errors.topic ? 'true' : 'false'}
                >
                  <option value="">Bitte auswählen</option>
                  <option value="Szenarien">Szenarien &amp; Tools</option>
                  <option value="Workshops">Workshops &amp; Sessions</option>
                  <option value="Kooperation">Kooperationsanfrage</option>
                  <option value="Support">Support &amp; Hilfe</option>
                </select>
                {errors.topic && <p className="mt-1 text-xs text-red-500">{errors.topic}</p>}
              </div>
              <div>
                <label htmlFor="message" className="text-sm font-semibold text-primary">Nachricht</label>
                <textarea
                  id="message"
                  rows="5"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="mt-2 w-full rounded-lg border border-surface px-3 py-2 text-sm focus:border-accent focus:outline-none"
                  aria-invalid={errors.message ? 'true' : 'false'}
                ></textarea>
                {errors.message && <p className="mt-1 text-xs text-red-500">{errors.message}</p>}
              </div>
              <button
                type="submit"
                className="rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
              >
                Nachricht senden
              </button>
              {submitted && (
                <p className="text-sm text-accent">Danke für deine Nachricht! Wir melden uns zeitnah zurück.</p>
              )}
            </form>
            <aside className="space-y-6">
              <div className="rounded-3xl border border-surface bg-background p-6">
                <h2 className="font-heading text-lg font-semibold text-primary">Kontakt</h2>
                <p className="mt-3 text-sm text-secondary">
                  E-Mail: <a href="mailto:kontakt@zukunftskonto.de" className="text-accent">kontakt@zukunftskonto.de</a><br />
                  Telefon: +49 (0)30 1234 5678<br />
                  Standort: Berlin &amp; Remote
                </p>
              </div>
              <div className="rounded-3xl border border-surface bg-background p-6">
                <h2 className="font-heading text-lg font-semibold text-primary">Office-Zeiten</h2>
                <p className="mt-3 text-sm text-secondary">
                  Montag – Freitag: 9:00 – 17:00 Uhr<br />
                  Remote Sessions nach Vereinbarung.
                </p>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;