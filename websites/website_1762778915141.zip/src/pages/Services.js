import React from 'react';
import { Helmet } from 'react-helmet';

const servicesData = [
  {
    title: 'Szenario-Designer',
    description: 'Timeline-Builder mit Meilensteinen, Verantwortlichkeiten und Ampellogik – inkl. Druck &amp; PDF-Export.',
    features: ['3-12-36 Monate Planung', 'Status-Tracking', 'Team-Comments'],
    icon: '🧭'
  },
  {
    title: 'Rechenzentrum',
    description: 'Inflation, Rücklagen, Energie, Urlaub, Schulden – verknüpft mit deinem Jahresplan.',
    features: ['Individuelle Parameter', 'Energie-Index', 'Tilgungsplan'],
    icon: '🧮'
  },
  {
    title: 'Evidenzbibliothek',
    description: 'Quellen verlinkt, Zusammenfassungen verständlich, keine Buzzwords.',
    features: ['Gesetze &amp; Förderungen', 'Vergleichstabellen', 'Aktualisierungen'],
    icon: '📚'
  },
  {
    title: 'Jahreskalender',
    description: 'Termine, Fristen und saisonale Peaks – in einer klaren Quartalsansicht.',
    features: ['Mobil &amp; Desktop', 'Erinnerungen', 'Verknüpfung mit Szenarien'],
    icon: '🗓️'
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Leistungen – ZukunftsKonto Services</title>
        <meta name="description" content="Szenario-Designer, Rechenzentrum, Evidenzbibliothek und Jahreskalender – alles für deine Finanzplanung." />
      </Helmet>
      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <header className="text-center">
            <h1 className="font-heading text-3xl font-bold text-primary">Unsere Leistungen</h1>
            <p className="mt-3 text-secondary md:w-3/4 md:mx-auto">
              ZukunftsKonto verbindet Tools, Daten &amp; Coachingimpulse – modular und anpassbar. Kein Overload, sondern klare Schritte.
            </p>
          </header>
          <div className="mt-12 grid gap-8 md:grid-cols-2">
            {servicesData.map((service) => (
              <div key={service.title} className="rounded-3xl border border-surface bg-background p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-lg">
                <div className="flex items-center justify-between">
                  <span className="text-3xl">{service.icon}</span>
                  <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-accent">WCAG AA</span>
                </div>
                <h2 className="mt-4 font-heading text-xl font-semibold text-primary">{service.title}</h2>
                <p className="mt-2 text-sm text-secondary">{service.description}</p>
                <ul className="mt-4 space-y-2 text-sm text-secondary">
                  {service.features.map((feature) => (
                    <li key={feature}>• {feature}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;