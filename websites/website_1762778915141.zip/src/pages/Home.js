import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

const statsData = [
  { label: 'durchdachte Lebensplanungen/Jahr', value: 420 },
  { label: 'Workshops mit Familien &amp; Pflegenden', value: 58 },
  { label: 'Szenario-Updates pro Quartal', value: 12 },
  { label: 'Quellen in Evidenzboxen', value: 87 }
];

const timelineSteps = [
  {
    title: 'Monat 3',
    description: 'Kurzfristige Liquidität sichern, Fixkosten validieren, Notgroschen abgleichen.',
    focus: 'Liquidität',
    icon: '📅'
  },
  {
    title: 'Monat 12',
    description: 'Versicherungen und Steuern aktualisieren, Weiterbildung oder Karriere-Entscheidungen vorbereiten.',
    focus: 'Neujustierung',
    icon: '🧭'
  },
  {
    title: 'Monat 36',
    description: 'Vermögensziele synchronisieren, große Posten (Pflege, Renovierung) budgetieren, Sicherheitsmarge prüfen.',
    focus: 'Weitblick',
    icon: '🌲'
  }
];

const servicesHome = [
  {
    title: 'Szenario-Rechner',
    description: 'Elternzeit, Pflegefall, Weiterbildung oder Umzug simulieren – mit Zeitleisten und Checklisten zum Ausdrucken.',
    icon: '🧮'
  },
  {
    title: 'Jahreskalender Finanzen',
    description: 'Wichtige Fristen, Termine und saisonale Budget-Spitzen rechtzeitig planen – mobil &amp; am Desktop.',
    icon: '🗓️'
  },
  {
    title: 'Evidenzbasierte Leitfäden',
    description: 'Steuern, Versicherungen und Vorsorge nach Lebensphase strukturiert aufbereitet – mit Quellenangaben.',
    icon: '📚'
  }
];

const projects = [
  {
    id: 1,
    title: 'Familienbudget mit Elternzeit & Kita-Start',
    category: 'Familie',
    description: 'Einteilung in Fixkosten-Töpfe, fünf Szenarien zur Einkommensentwicklung und Eigenanteile an Betreuungskosten.',
    image: 'https://picsum.photos/1200/800?random=41',
    tags: ['Elternzeit', 'Rücklagen', 'Liquidität']
  },
  {
    id: 2,
    title: 'Weiterbildung & Sabbatical Planung',
    category: 'Karriere',
    description: 'Ein Jahr berufliche Neuorientierung mit Bildungsgutschein, Nebenerwerb und Vorsorgeprüfung.',
    image: 'https://picsum.photos/1200/800?random=42',
    tags: ['Weiterbildung', 'Cashflow', 'Förderung']
  },
  {
    id: 3,
    title: 'Pflegekosten & Umbau für Angehörige',
    category: 'Pflege',
    description: 'Eigenanteile, Zuschüsse, Umbaukosten und Entlastungsleistungen in einer Timeline von 18 Monaten.',
    image: 'https://picsum.photos/1200/800?random=43',
    tags: ['Pflegefall', 'Fördermittel', 'Budget']
  },
  {
    id: 4,
    title: 'Energieeffizienz & Heizpuffer 2024',
    category: 'Wohnen',
    description: 'Monatliche Energierücklagen, Förderkredite, Steckbrief der Maßnahmen mit Verbrauchsmonitoring.',
    image: 'https://picsum.photos/1200/800?random=44',
    tags: ['Energie', 'Inflation', 'Rücklagen']
  }
];

const faqPreview = [
  {
    question: 'Wie unterscheidet sich ZukunftsKonto von klassischen Haushaltsbüchern?',
    answer: 'Wir verbinden Lebensereignisse mit finanziellen Erwartungen, berücksichtigen Inflation, Sozialabgaben & Förderungen und liefern druckbare Checklisten.'
  },
  {
    question: 'Welche Daten brauche ich für einen soliden Start?',
    answer: 'Fixkosten nach Kategorien, aktuelle Verträge, Steuerklasse, Altersvorsorge-Status, Zielzeitraum. Wir helfen beim Zusammenstellen.'
  },
  {
    question: 'Kann ich Szenarien gemeinsam mit Partner*in oder Familie nutzen?',
    answer: 'Ja. Szenarien lassen sich teilen, kommentieren und gemeinsam fortschreiben – mit Status und Verantwortlichkeiten.'
  }
];

const testimonials = [
  {
    name: 'Katharina & Jonas',
    role: 'Eltern aus Hamburg',
    quote:
      '“Durch die Elternzeit-Szenarien wussten wir exakt, wann welche Rücklage gebraucht wird. Kein Panik-Excel mehr, sondern klare Zeitachsen.”'
  },
  {
    name: 'Mert A.',
    role: 'Produktmanager in Weiterbildung',
    quote:
      '“Der Weiterbildungspfad half mir, Kosten, Förderung und freie Tage sinnvoll zu planen. Die Evidenzboxen sparen mir stundenlanges Recherchieren.”'
  },
  {
    name: 'Heike L.',
    role: 'Pflegende Angehörige',
    quote:
      '“Die Timeline zur Pflegefinanzierung hielt uns den Rücken frei. Wir hatten rechtzeitig Budget und Formulare parat.”'
  }
];

const Home = () => {
  const [activeFilter, setActiveFilter] = React.useState('Alle');
  const [visibleStats, setVisibleStats] = React.useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);
  const [newsletterEmail, setNewsletterEmail] = React.useState('');
  const [newsletterFeedback, setNewsletterFeedback] = React.useState('');
  const [isStatsAnimated, setIsStatsAnimated] = React.useState(false);

  const heroImageLoaded = React.useRef(false);
  const [heroLoaded, setHeroLoaded] = React.useState(false);

  const filteredProjects =
    activeFilter === 'Alle'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  React.useEffect(() => {
    const handleScroll = () => {
      const statsSection = document.getElementById('stats-section');
      if (!statsSection || isStatsAnimated) return;
      const rect = statsSection.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom >= 0) {
        animateStats();
        setIsStatsAnimated(true);
      }
    };
    const animateStats = () => {
      const duration = 1400;
      const start = performance.now();
      const step = (timestamp) => {
        const progress = Math.min((timestamp - start) / duration, 1);
        const updated = statsData.map((stat) => Math.floor(stat.value * progress));
        setVisibleStats(updated);
        if (progress < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };
    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isStatsAnimated]);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) {
      setNewsletterFeedback('Bitte gib eine gültige E-Mail-Adresse ein.');
    } else {
      setNewsletterFeedback('Danke! Bitte bestätige deine Anmeldung in der E-Mail, die wir dir soeben gesendet haben.');
      setNewsletterEmail('');
    }
  };

  return (
    <>
      <Helmet>
        <title>ZukunftsKonto – Plane mit Klarheit</title>
        <meta
          name="description"
          content="Dein Navigator für Finanzentscheidungen: Szenarien denken, Rücklagen organisieren und Jahrespläne visualisieren – verständlich und evidenzbasiert."
        />
        <meta property="og:title" content="ZukunftsKonto – Plane mit Klarheit" />
        <meta property="og:description" content="Langfristige Finanzplanung mit Szenario-Rechner, Jahreskalender und Evidenzboxen – für Familien, Paare & Solohaushalte." />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=99" />
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'HowTo',
            name: 'Finanzplanung mit ZukunftsKonto',
            description: 'In fünf Schritten zu einem belastbaren Finanzszenario für die nächsten 36 Monate.',
            step: [
              { '@type': 'HowToStep', name: 'Bedarf erfassen', text: 'Fixkosten, Ziele und Rahmenbedingungen aufnehmen.' },
              { '@type': 'HowToStep', name: 'Szenario wählen', text: 'Elternzeit, Weiterbildung, Pflege oder Umbau definieren.' },
              { '@type': 'HowToStep', name: 'Zeitplan erstellen', text: 'Meilensteine in 3-12-36 Monatsblick strukturieren.' },
              { '@type': 'HowToStep', name: 'Budget anpassen', text: 'Rücklagen-Töpfe und Inflationsannahmen berechnen.' },
              { '@type': 'HowToStep', name: 'Handeln & nachjustieren', text: 'Checklisten nutzen, Fortschritt markieren, Quellen prüfen.' }
            ]
          })}
        </script>
      </Helmet>

      <section className="relative overflow-hidden bg-gradient-to-b from-white via-background to-surface">
        <div className="absolute inset-0">
          {!heroLoaded && (
            <div className="absolute inset-0 animate-pulse bg-surface" aria-hidden="true"></div>
          )}
          <img
            src="https://picsum.photos/1600/900?random=21"
            alt="Helles Arbeitszimmer mit Finanzplanung"
            className={`h-full w-full object-cover transition-opacity duration-700 ${heroLoaded ? 'opacity-80' : 'opacity-0'}`}
            onLoad={() => {
              heroImageLoaded.current = true;
              setHeroLoaded(true);
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/50"></div>
        </div>
        <div className="relative mx-auto flex max-w-6xl flex-col-reverse items-center px-4 py-24 md:flex-row md:py-32 md:px-8">
          <div className="w-full md:w-1/2">
            <div className="mb-6 inline-flex items-center space-x-2 rounded-full bg-white/80 px-4 py-2 text-sm font-accent text-accent shadow-soft backdrop-blur">
              <span className="inline-flex h-2 w-2 rounded-full bg-accent"></span>
              <span>Neu: Jahresplan 2024 mit Energiepuffer</span>
            </div>
            <h1 className="font-heading text-3xl font-bold tracking-tight text-primary md:text-5xl">
              Plane mit Klarheit. Triff finanzielle Entscheidungen mit Weitblick.
            </h1>
            <p className="mt-6 text-lg text-secondary md:w-4/5">
              ZukunftsKonto führt dich durch Lebensereignisse – mit 3-12-36 Monatssicht, Rücklagen-Logik, Evidenzboxen und Tools, die sich deinem Alltag anpassen.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/szenarien"
                className="inline-flex items-center justify-center rounded-full bg-accent px-6 py-3 font-accent text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-accent/90"
              >
                Szenario starten
              </Link>
              <Link
                to="/rechner"
                className="inline-flex items-center justify-center rounded-full border border-secondary px-6 py-3 font-accent text-sm font-semibold text-primary transition hover:border-accent hover:text-accent"
              >
                Rechner entdecken
              </Link>
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl bg-white/90 p-4 shadow-soft">
                <span className="text-xs font-semibold text-accent">Wochenfokus</span>
                <p className="mt-2 text-sm text-secondary">Checkliste „Elternzeit &amp; Kita“ aktualisiert – mit Zuschuss-Sätzen 2024.</p>
              </div>
              <div className="rounded-2xl bg-white/90 p-4 shadow-soft">
                <span className="text-xs font-semibold text-accent">Preview</span>
                <p className="mt-2 text-sm text-secondary">Timeline-Modul mit Verantwortlichkeiten &amp; Statusupdates.</p>
              </div>
              <div className="rounded-2xl bg-white/90 p-4 shadow-soft">
                <span className="text-xs font-semibold text-accent">Evidenz</span>
                <p className="mt-2 text-sm text-secondary">BMF, Pflegekassen &amp; BAföG-Stellen verlinkt für schnellen Faktencheck.</p>
              </div>
            </div>
          </div>
          <div className="mb-10 w-full md:mb-0 md:w-1/2">
            <div className="relative overflow-hidden rounded-3xl bg-white shadow-soft">
              <img
                src="https://picsum.photos/800/600?random=22"
                alt="Finanzplaner mit Kalender und Notizen"
                className="h-full w-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="rounded-2xl bg-white/90 p-4 backdrop-blur">
                  <p className="text-xs font-semibold uppercase tracking-wide text-accent">36 Monate im Blick</p>
                  <p className="mt-2 text-sm text-primary">
                    Elternzeitbudget, Weiterbildung, Pflegefall? Kombiniere Szenarien und exportiere To-dos als PDF oder Druckversion.
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-6 flex gap-4">
              <div className="rounded-2xl bg-white p-4 shadow-soft">
                <p className="text-3xl font-bold text-primary">83%</p>
                <p className="text-xs text-secondary">fühlen sich nach 8 Wochen sicherer bei Finanzentscheidungen.</p>
              </div>
              <div className="rounded-2xl bg-white p-4 shadow-soft">
                <p className="text-3xl font-bold text-primary">4,8/5</p>
                <p className="text-xs text-secondary">Bewertung für die Klarheit von Checklisten &amp; Zeitplänen.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="stats-section" className="bg-white py-16">
        <div className="mx-auto grid max-w-5xl gap-6 px-4 md:grid-cols-4 md:px-8">
          {statsData.map((stat, index) => (
            <div key={stat.label} className="rounded-2xl border border-surface bg-background p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-lg">
              <p className="text-3xl font-bold text-primary">
                {visibleStats[index]}+
              </p>
              <p className="mt-2 text-sm text-secondary">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
            <div>
              <h2 className="font-heading text-3xl font-bold text-primary">Was ändert sich in 3–12–36 Monaten?</h2>
              <p className="mt-3 text-secondary">
                Unsere Timeline zeigt, welche Schritte in welcher Phase relevant sind – ob Familienbudget, berufliche Weiterbildung oder Pflegeplanung.
              </p>
            </div>
            <Link
              to="/szenarien"
              className="rounded-full border border-accent px-5 py-2 text-sm font-semibold text-accent transition hover:bg-accent hover:text-white"
            >
              Alle Timeline-Szenarien
            </Link>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {timelineSteps.map((step) => (
              <div key={step.title} className="relative rounded-3xl border border-surface bg-white p-6 shadow-soft">
                <span className="absolute -top-4 left-6 inline-flex h-12 w-12 items-center justify-center rounded-full bg-accent text-2xl text-white shadow-lg">
                  {step.icon}
                </span>
                <div className="mt-8">
                  <p className="text-sm font-semibold text-accent">{step.title}</p>
                  <h3 className="mt-2 font-heading text-xl font-bold text-primary">{step.focus}</h3>
                  <p className="mt-3 text-sm text-secondary">{step.description}</p>
                </div>
                <div className="mt-6 text-xs text-secondary">
                  <span className="inline-flex items-center rounded-full bg-accent/10 px-3 py-1 font-medium text-accent">Meilensteinkarte</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="font-heading text-3xl font-bold text-primary">Rücklagen-Töpfe, die mitwachsen</h2>
              <p className="mt-3 text-secondary md:w-3/4">
                Ob Notgroschen, Renovierung oder Energiepuffer – wir strukturieren Rücklagen entlang von Zeit und Zweck. Mit dynamischen Anpassungen bei Inflation und Energieverbrauch.
              </p>
            </div>
            <Link
              to="/rechner"
              className="inline-flex items-center rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
            >
              Rücklagen-Planer nutzen
            </Link>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {servicesHome.map((service) => (
              <div key={service.title} className="group relative h-full rounded-3xl border border-surface bg-background p-6 transition hover:-translate-y-1 hover:bg-white hover:shadow-soft">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10 text-xl">{service.icon}</div>
                <h3 className="mt-6 font-heading text-xl font-semibold text-primary">{service.title}</h3>
                <p className="mt-3 text-sm text-secondary">{service.description}</p>
                <span className="mt-4 inline-flex items-center text-xs font-semibold text-accent">
                  Mehr erfahren →
                </span>
                <div className="absolute inset-x-0 bottom-0 h-1 scale-x-0 rounded-b-3xl bg-accent transition-transform group-hover:scale-x-100"></div>
              </div>
            ))}
          </div>
          <div className="mt-10 rounded-3xl bg-gradient-to-r from-accent/10 via-surface to-accent/10 p-8 md:flex md:items-center md:justify-between">
            <div className="md:w-3/4">
              <h3 className="font-heading text-2xl font-semibold text-primary">Evidenzbox: Rücklagen &amp; Energiepuffer 2024</h3>
              <p className="mt-3 text-sm text-secondary">
                Bundesverband Verbraucherzentralen empfiehlt 3-6 Netto-Monatsgehälter als Notgroschen. Für Energiepuffer 2024 kalkulieren wir +12% zu 2023 (BDEW Energiebericht 2023/24).
              </p>
              <p className="mt-2 text-xs text-secondary">
                Quellen: Verbraucherzentrale Bundesverband (2023), Bundesverband der Energie- und Wasserwirtschaft (2024 Prognose).
              </p>
            </div>
            <Link
              to="/quellen"
              className="mt-6 inline-flex items-center rounded-full border border-accent px-5 py-2 text-sm font-semibold text-accent transition hover:bg-accent hover:text-white md:mt-0"
            >
              Quellen einsehen
            </Link>
          </div>
        </div>
      </section>

      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="font-heading text-3xl font-bold text-primary">Jahresplan: Kalender statt Chaos</h2>
              <p className="mt-3 text-secondary md:w-4/5">
                Unser Jahreskalender markiert Quartalschecks, Antragsfristen, Energieabschläge sowie Steuer-Deadlines – vollständig anpassbar und für den Druck optimiert.
              </p>
            </div>
            <Link
              to="/leitfaden"
              className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:bg-primary/90"
            >
              Leitfaden öffnen
            </Link>
          </div>
          <div className="mt-10 grid gap-4 rounded-3xl bg-white p-6 shadow-soft sm:grid-cols-2 lg:grid-cols-4">
            {['Jan–Mär', 'Apr–Jun', 'Jul–Sep', 'Okt–Dez'].map((quarter, index) => (
              <div key={quarter} className="rounded-2xl border border-surface p-4">
                <p className="text-xs font-semibold text-accent">Quartal {index + 1}</p>
                <h3 className="mt-2 font-heading text-lg font-semibold text-primary">{quarter}</h3>
                <ul className="mt-3 space-y-2 text-sm text-secondary">
                  <li>• Finanz-Check-in</li>
                  <li>• Rücklagen anpassen</li>
                  <li>• Termine sichern</li>
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="font-heading text-3xl font-bold text-primary">Fallstudien &amp; Projekte</h2>
              <p className="mt-3 text-secondary md:w-3/4">
                Filtere unsere Fallstudien nach Lebenssituationen und sieh, welche Stellschrauben den Unterschied machen.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              {['Alle', 'Familie', 'Karriere', 'Pflege', 'Wohnen'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`rounded-full px-4 py-2 text-xs font-semibold transition ${activeFilter === filter ? 'bg-accent text-white shadow-soft' : 'bg-surface text-secondary hover:bg-accent/10 hover:text-accent'}`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-10 grid gap-8 md:grid-cols-2">
            {filteredProjects.map((project) => (
              <article key={project.id} className="overflow-hidden rounded-3xl border border-surface bg-background shadow-soft transition hover:-translate-y-1">
                <div className="relative">
                  <img src={project.image} alt={`Projekt ${project.title}`} className="h-56 w-full object-cover" />
                  <span className="absolute left-6 top-6 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-accent shadow-soft">
                    {project.category}
                  </span>
                </div>
                <div className="space-y-4 p-6">
                  <div>
                    <h3 className="font-heading text-xl font-semibold text-primary">{project.title}</h3>
                    <p className="mt-2 text-sm text-secondary">{project.description}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 text-xs font-semibold text-secondary">
                    {project.tags.map((tag) => (
                      <span key={tag} className="rounded-full bg-white px-3 py-1 text-secondary">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <Link to="/szenarien" className="inline-flex items-center text-sm font-semibold text-accent">
                    Szenario ansehen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="grid gap-10 md:grid-cols-2">
            <div>
              <h2 className="font-heading text-3xl font-bold text-primary">Erfolgsgeschichten</h2>
              <p className="mt-3 text-secondary">
                Nutzer:innen berichten, wie sie mit ZukunftsKonto mehr Sicherheit gewonnen haben – ohne unrealistische Versprechen.
              </p>
              <div className="mt-6 space-y-4">
                <div className="rounded-2xl border border-surface bg-white p-4 text-sm text-secondary">
                  <p className="font-semibold text-primary">Evidenzbox Wirkung</p>
                  <p className="mt-2">
                    78% unserer Nutzer:innen senken ihr Stresslevel rund um Finanzentscheidungen innerhalb von 60 Tagen (Selbstauskunft, n=248, 2023).
                  </p>
                </div>
              </div>
            </div>
            <div className="relative overflow-hidden rounded-3xl bg-white p-8 shadow-soft">
              <div className="absolute left-6 top-6 text-4xl text-accent">“</div>
              <div className="mt-8">
                <p className="text-lg text-primary">
                  {testimonials[testimonialIndex].quote}
                </p>
                <div className="mt-6">
                  <p className="font-semibold text-primary">{testimonials[testimonialIndex].name}</p>
                  <p className="text-sm text-secondary">{testimonials[testimonialIndex].role}</p>
                </div>
              </div>
              <div className="mt-8 flex items-center justify-between text-xs text-secondary">
                <span>Fall {testimonialIndex + 1} von {testimonials.length}</span>
                <div className="flex gap-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setTestimonialIndex(index)}
                      className={`h-2.5 w-2.5 rounded-full transition ${testimonialIndex === index ? 'bg-accent' : 'bg-surface'}`}
                      aria-label={`Testimonial ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="grid gap-10 md:grid-cols-2">
            <div>
              <img
                src="https://picsum.photos/800/600?random=23"
                alt="Teammeeting zur Finanzplanung"
                className="h-full w-full rounded-3xl object-cover"
              />
            </div>
            <div>
              <h2 className="font-heading text-3xl font-bold text-primary">Häufige Fragen</h2>
              <p className="mt-3 text-secondary">
                Wir beantworten die wichtigsten Fragen rund um Budgetierung, Daten und Zusammenarbeit. Alle Antworten findest du im FAQ.
              </p>
              <div className="mt-6 space-y-4">
                {faqPreview.map((item) => (
                  <div key={item.question} className="rounded-2xl border border-surface bg-background p-5">
                    <h3 className="font-heading text-lg font-semibold text-primary">{item.question}</h3>
                    <p className="mt-2 text-sm text-secondary">{item.answer}</p>
                  </div>
                ))}
              </div>
              <Link
                to="/faq"
                className="mt-6 inline-flex items-center text-sm font-semibold text-accent"
              >
                Mehr Fragen &amp; Antworten →
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="rounded-3xl bg-primary px-6 py-12 text-white shadow-soft lg:px-12">
            <div className="grid gap-8 lg:grid-cols-2">
              <div>
                <h2 className="font-heading text-3xl font-bold">Blog-Insights</h2>
                <p className="mt-3 text-sm text-gray-300">
                  Wir bereiten neue Zahlen, Förderungen und Planungsimpulse verständlich auf – keine leeren Versprechen, nur belastbare Informationen.
                </p>
                <Link
                  to="/blog"
                  className="mt-6 inline-flex items-center rounded-full bg-white/10 px-5 py-2 text-sm font-semibold text-white transition hover:bg-white/20"
                >
                  Zum Blog
                </Link>
              </div>
              <div className="space-y-4">
                <article className="rounded-2xl bg-white/10 p-5">
                  <p className="text-xs font-semibold uppercase tracking-wide text-accent">Elternzeit</p>
                  <h3 className="mt-2 font-heading text-lg font-semibold">Elternzeitbudget planen – Updates 2024</h3>
                  <p className="mt-2 text-sm text-gray-200">Neue Elterngeld-Grenzen und Ausgleichsstrategien für unterschiedliche Einkommenshöhen.</p>
                  <Link to="/blog/elternzeit-budget-plan" className="mt-4 inline-flex items-center text-xs font-semibold text-accent">
                    Beitrag lesen →
                  </Link>
                </article>
                <article className="rounded-2xl bg-white/10 p-5">
                  <p className="text-xs font-semibold uppercase tracking-wide text-accent">Energie</p>
                  <h3 className="mt-2 font-heading text-lg font-semibold">Energiepuffer 2024: Wie viel Reserve sinnvoll ist</h3>
                  <p className="mt-2 text-sm text-gray-200">Preisindizes &amp; Verbrauchspläne, um Tarifsprünge ohne Stress zu stemmen.</p>
                  <Link to="/blog/energiepuffer-haushalt" className="mt-4 inline-flex items-center text-xs font-semibold text-accent">
                    Beitrag lesen →
                  </Link>
                </article>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-4xl rounded-3xl bg-gradient-to-r from-accent/10 via-background to-accent/10 px-6 py-12 text-center shadow-soft md:px-12">
          <h2 className="font-heading text-3xl font-bold text-primary">Bereit für finanzielle Klarheit?</h2>
          <p className="mt-3 text-secondary">
            Starte mit einem Szenario und ergänze Schritt für Schritt deinen Jahresplan. Du kannst jederzeit drucken, exportieren und gemeinsam planen.
          </p>
          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <Link
              to="/szenarien"
              className="rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
            >
              Szenario jetzt aufsetzen
            </Link>
            <Link
              to="/contact"
              className="rounded-full border border-secondary px-6 py-3 text-sm font-semibold text-primary transition hover:border-accent hover:text-accent"
            >
              Beratung anfragen
            </Link>
          </div>
        </div>
      </section>

      <section className="bg-background py-16">
        <div className="mx-auto max-w-4xl rounded-3xl bg-white p-8 shadow-soft">
          <h2 className="font-heading text-2xl font-bold text-primary">Newsletter: Monatsimpulse</h2>
          <p className="mt-2 text-sm text-secondary">
            Einmal im Monat: Updates zu Förderungen, Checklisten und Jahresplan-Reminder. Kein Spam, nur relevante Erkenntnisse.
          </p>
          <form onSubmit={handleNewsletterSubmit} className="mt-6 flex flex-col gap-3 sm:flex-row">
            <label className="sr-only" htmlFor="newsletter-email">E-Mail-Adresse</label>
            <input
              id="newsletter-email"
              type="email"
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="deine@email.de"
              className="flex-1 rounded-full border border-surface px-4 py-3 text-sm text-primary placeholder:text-secondary focus:border-accent focus:outline-none"
              required
            />
            <button
              type="submit"
              className="rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white shadow-soft transition hover:bg-primary/90"
            >
              Anmelden
            </button>
          </form>
          {newsletterFeedback && (
            <p className="mt-3 text-sm text-accent">{newsletterFeedback}</p>
          )}
        </div>
      </section>
    </>
  );
};

export default Home;