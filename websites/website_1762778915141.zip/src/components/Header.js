import React from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';

const navItems = [
  { name: 'Start', path: '/' },
  { name: 'Szenarien', path: '/szenarien' },
  { name: 'Rechner', path: '/rechner' },
  { name: 'Leitfaden', path: '/leitfaden' },
  { name: 'Blog', path: '/blog' },
  { name: 'Über uns', path: '/about' },
  { name: 'Kontakt', path: '/contact' }
];

const Header = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);
  const location = useLocation();

  React.useEffect(() => {
    setIsOpen(false);
  }, [location]);

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur shadow-lg' : 'bg-background/80 backdrop-blur'}`}>
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 md:px-8">
        <Link to="/" className="flex items-center space-x-3" aria-label="ZukunftsKonto Startseite">
          <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10 text-xl font-semibold text-accent">ZK</span>
          <span className="flex flex-col leading-tight">
            <span className="font-heading text-lg font-bold tracking-tight">ZukunftsKonto</span>
            <span className="text-xs text-secondary">Finanzplanung für heute &amp; morgen</span>
          </span>
        </Link>
        <nav className="hidden items-center space-x-6 lg:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `text-sm font-accent font-medium transition-colors duration-200 hover:text-accent ${isActive ? 'text-accent' : 'text-secondary'}`
              }
            >
              {item.name}
            </NavLink>
          ))}
          <Link
            to="/services"
            className="rounded-full bg-accent px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:-translate-y-0.5 hover:bg-accent/90"
          >
            Lösungen entdecken
          </Link>
        </nav>
        <button
          onClick={() => setIsOpen((prev) => !prev)}
          className="lg:hidden"
          aria-label="Navigation öffnen"
        >
          <span className="sr-only">Menü</span>
          <div className="space-y-1.5">
            <span className={`block h-0.5 w-6 bg-primary transition ${isOpen ? 'translate-y-2 rotate-45' : ''}`}></span>
            <span className={`block h-0.5 w-6 bg-primary transition ${isOpen ? 'opacity-0' : ''}`}></span>
            <span className={`block h-0.5 w-6 bg-primary transition ${isOpen ? '-translate-y-2 -rotate-45' : ''}`}></span>
          </div>
        </button>
      </div>
      {isOpen && (
        <div className="border-t border-surface bg-white px-4 py-6 shadow-inner lg:hidden">
          <nav className="flex flex-col space-y-3">
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                className={({ isActive }) =>
                  `rounded-lg px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-accent/10 text-accent' : 'text-secondary hover:bg-surface'}`
                }
              >
                {item.name}
              </NavLink>
            ))}
            <Link
              to="/services"
              className="rounded-lg bg-accent px-4 py-3 text-center text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
            >
              Lösungen entdecken
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;