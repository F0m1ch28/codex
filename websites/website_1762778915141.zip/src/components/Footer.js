import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="border-t border-surface bg-primary text-gray-100">
      <div className="mx-auto grid max-w-6xl gap-12 px-4 py-16 md:grid-cols-4 md:px-8">
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-xl font-semibold text-white">
              ZK
            </span>
            <div>
              <span className="block font-heading text-lg font-bold">ZukunftsKonto</span>
              <span className="text-xs text-gray-300">Finanzplanung für heute &amp; morgen</span>
            </div>
          </div>
          <p className="text-sm text-gray-300">
            Zukunftsfähige Finanzplanung, die reale Lebenssituationen abbildet – mit Tools, Szenarien und verständlichen Leitfäden.
          </p>
          <div className="flex space-x-4" aria-label="Social Media">
            <a href="https://www.linkedin.com" className="text-gray-300 transition hover:text-accent" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="https://www.instagram.com" className="text-gray-300 transition hover:text-accent" target="_blank" rel="noreferrer" aria-label="Instagram">
              Instagram
            </a>
            <a href="https://www.youtube.com" className="text-gray-300 transition hover:text-accent" target="_blank" rel="noreferrer" aria-label="YouTube">
              YouTube
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-heading text-lg font-semibold text-white">Navigation</h4>
          <ul className="mt-4 space-y-3 text-sm text-gray-300">
            <li><Link to="/" className="transition hover:text-accent">Start</Link></li>
            <li><Link to="/szenarien" className="transition hover:text-accent">Szenarien</Link></li>
            <li><Link to="/rechner" className="transition hover:text-accent">Rechner</Link></li>
            <li><Link to="/services" className="transition hover:text-accent">Leistungen</Link></li>
            <li><Link to="/faq" className="transition hover:text-accent">FAQ</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading text-lg font-semibold text-white">Rechtliches &amp; Quellen</h4>
          <ul className="mt-4 space-y-3 text-sm text-gray-300">
            <li><Link to="/policy" className="transition hover:text-accent">Datenschutz</Link></li>
            <li><Link to="/cookies" className="transition hover:text-accent">Cookie-Richtlinie</Link></li>
            <li><Link to="/terms" className="transition hover:text-accent">Nutzungsbedingungen</Link></li>
            <li><Link to="/impressum" className="transition hover:text-accent">Impressum</Link></li>
            <li><Link to="/quellen" className="transition hover:text-accent">Quellenverzeichnis</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading text-lg font-semibold text-white">Newsletter</h4>
          <p className="mt-4 text-sm text-gray-300">
            Monatsimpulse zu Budget, Vorsorge und Planungssicherheit – ohne Verkaufsversprechen, mit Fakten und Quellen.
          </p>
          <form className="mt-4 space-y-3" aria-label="Newsletter abonnieren">
            <label className="sr-only" htmlFor="footer-email">E-Mail-Adresse</label>
            <input
              id="footer-email"
              type="email"
              required
              placeholder="E-Mail-Adresse"
              className="w-full rounded-lg border border-surface bg-primary/40 px-3 py-2 text-sm text-white placeholder:text-gray-400 focus:border-accent focus:outline-none"
            />
            <button
              type="submit"
              className="w-full rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-white transition hover:bg-accent/90"
            >
              Anmelden
            </button>
          </form>
        </div>
      </div>
      <div className="border-t border-primary bg-primary/90 py-6">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 text-xs text-gray-400 md:flex-row md:px-8">
          <span>© {new Date().getFullYear()} ZukunftsKonto. Alle Rechte vorbehalten.</span>
          <span>Made for langfristige Planung ohne leere Versprechen.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;