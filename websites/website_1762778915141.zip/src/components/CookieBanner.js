import React from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem('zk-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('zk-cookie-consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('zk-cookie-consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-3 left-0 right-0 z-[60] flex justify-center px-4">
      <div className="max-w-3xl rounded-2xl border border-surface bg-white p-4 shadow-xl md:flex md:items-center md:space-x-6">
        <div className="flex-1 text-sm text-secondary">
          <h3 className="font-heading text-base font-semibold text-primary">Cookies für Funktion &amp; Analyse</h3>
          <p className="mt-2">
            Wir verwenden funktionale Cookies für Stabilität sowie optionale Analysen (anonymisiert), um ZukunftsKonto weiterzuentwickeln.
            Details findest du in unserer{' '}
            <a href="/policy" className="text-accent underline">Datenschutzerklärung</a>.
          </p>
        </div>
        <div className="mt-4 flex gap-3 md:mt-0">
          <button
            onClick={handleDecline}
            className="rounded-full border border-secondary px-4 py-2 text-sm font-medium text-secondary transition hover:border-primary hover:text-primary"
          >
            Ablehnen
          </button>
          <button
            onClick={handleAccept}
            className="rounded-full bg-accent px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:bg-accent/90"
          >
            Akzeptieren
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;