import React from 'react';

const ScrollToTopButton = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => {
      setIsVisible(window.scrollY > 300);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label="Nach oben scrollen"
      className={`fixed bottom-10 right-6 z-40 rounded-full bg-accent p-3 text-white shadow-soft transition-all duration-200 hover:bg-accent/90 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-accent ${isVisible ? 'opacity-100' : 'pointer-events-none opacity-0'}`}
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;