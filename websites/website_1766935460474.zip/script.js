(function () {
  const header = document.querySelector('[data-header]');
  const nav = document.querySelector('.primary-nav');
  const navToggle = document.querySelector('.nav-toggle');
  const toast = document.getElementById('toast');

  if (header) {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
  }

  if (nav && navToggle) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const cookieButtons = cookieBanner.querySelectorAll('[data-cookie]');
    const storageKey = 'noel-celebration-cookie';

    const existingPreference = localStorage.getItem(storageKey);
    if (!existingPreference) {
      cookieBanner.classList.add('active');
    }

    cookieButtons.forEach(button => {
      button.addEventListener('click', () => {
        const value = button.dataset.cookie;
        localStorage.setItem(storageKey, value);
        cookieBanner.classList.remove('active');
      });
    });
  }

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('visible');
    setTimeout(() => toast.classList.remove('visible'), 2600);
  }

  document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
      const product = button.dataset.product || 'Gift Box';
      showToast(`${product} was added to your wish cart.`);
    });
  });

  const customForm = document.getElementById('customizer-form');
  if (customForm) {
    const summaryOccasion = document.getElementById('summary-occasion');
    const summaryPalette = document.getElementById('summary-palette');
    const summaryGourmet = document.getElementById('summary-gourmet');
    const summaryKeepsake = document.getElementById('summary-keepsake');
    const summaryBudget = document.getElementById('summary-budget');
    const summaryMessage = document.getElementById('summary-message');

    function updateSummary() {
      const occasionValue = customForm.occasion.value;
      const paletteValue = customForm.palette.value;
      const budgetValue = customForm.budget.value;
      const messageValue = customForm.message.value.trim();

      summaryOccasion.textContent = occasionValue;
      summaryPalette.textContent = paletteValue;
      summaryBudget.textContent = budgetValue;
      summaryMessage.textContent = messageValue ? `Message preview: "${messageValue}"` : 'Add your personal message to elevate the moment.';

      function buildList(container, values) {
        container.innerHTML = '';
        if (values.length === 0) {
          const li = document.createElement('li');
          li.textContent = 'No selections yet.';
          container.appendChild(li);
          return;
        }
        values.forEach(item => {
          const li = document.createElement('li');
          li.textContent = item;
          container.appendChild(li);
        });
      }

      const gourmetSelections = Array.from(customForm.querySelectorAll('input[name="gourmet"]:checked')).map(input => input.value);
      const keepsakeSelections = Array.from(customForm.querySelectorAll('input[name="keepsake"]:checked')).map(input => input.value);

      buildList(summaryGourmet, gourmetSelections);
      buildList(summaryKeepsake, keepsakeSelections);
    }

    customForm.addEventListener('change', updateSummary);
    customForm.addEventListener('submit', event => {
      event.preventDefault();
      showToast('Your custom gift plan has been reserved.');
      customForm.reset();
      updateSummary();
    });

    updateSummary();
  }

  const occasionTabs = document.querySelectorAll('.occasion-tab');
  if (occasionTabs.length) {
    const panels = document.querySelectorAll('.occasion-panel');

    occasionTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const target = tab.dataset.occasion;

        occasionTabs.forEach(btn => btn.classList.remove('active'));
        panels.forEach(panel => panel.classList.remove('active'));

        tab.classList.add('active');
        const panel = document.getElementById(target);
        if (panel) {
          panel.classList.add('active');
        }
      });
    });
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      showToast('Thank you! A concierge will respond shortly.');
      contactForm.reset();
    });
  }
})();