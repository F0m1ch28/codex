/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        base: "#0F1B26",
        accent: "#1F2D3D",
        primary: "#2A65D9",
        light: "#E8EDF0"
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["'Satoshi'", "Inter", "system-ui", "sans-serif"]
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(42,101,217,0.35), 0 12px 30px rgba(15,27,38,0.45)"
      },
      backgroundImage: {
        "grid-pattern": "linear-gradient(90deg, rgba(42,101,217,0.08) 1px, transparent 1px), linear-gradient(0deg, rgba(42,101,217,0.08) 1px, transparent 1px)"
      },
      animation: {
        "pulse-slow": "pulse 5s infinite ease-in-out",
        "float": "float 8s ease-in-out infinite"
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-12px)" }
        }
      }
    }
  },
  plugins: [
    require("@tailwindcss/forms")
  ]
};