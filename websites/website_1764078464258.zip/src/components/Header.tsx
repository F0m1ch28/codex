import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { label: "Inicio", to: "/" },
  { label: "Sobre nosotros", to: "/about" },
  { label: "Operaciones", to: "/operations" },
  { label: "Blog", to: "/blog" },
  { label: "Contacto", to: "/contact" }
];

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const location = useLocation();
  const toggleMenu = () => setIsOpen((prev) => !prev);

  React.useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-base/90 backdrop-blur-xl border-b border-white/5">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-primary/40 bg-primary/10 text-primary font-semibold">
            WV
          </span>
          <div>
            <p className="text-lg font-semibold font-display tracking-wide text-light">
              Wind Vector Hub
            </p>
            <p className="text-xs text-light/70">
              Observatorio de Infraestructura Eólica
            </p>
          </div>
        </div>
        <nav className="hidden items-center gap-1 text-sm font-medium md:flex">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                [
                  "px-4 py-2 rounded-full transition-all duration-300",
                  "hover:text-primary hover:bg-primary/10",
                  isActive ? "bg-primary/15 text-primary" : "text-light/80"
                ].join(" ")
              }
            >
              {item.label}
            </NavLink>
          ))}
          <a
            href="#newsletter"
            className="ml-4 inline-flex items-center rounded-full border border-primary/60 bg-primary/10 px-4 py-2 text-xs uppercase tracking-wider text-primary transition hover:bg-primary/20"
          >
            Boletín
          </a>
        </nav>
        <button
          onClick={toggleMenu}
          className="inline-flex items-center justify-center rounded-full border border-white/10 p-2 text-light transition hover:text-primary md:hidden"
          aria-label="Abrir menú"
        >
          <span className="sr-only">Abrir menú</span>
          <svg
            className="h-6 w-6"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
          >
            {isOpen ? (
              <path d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="md:hidden"
          >
            <div className="mx-3 mb-4 rounded-3xl border border-white/5 bg-accent/80 backdrop-blur-xl p-4 shadow-lg">
              <ul className="space-y-1">
                {navItems.map((item) => (
                  <li key={item.to}>
                    <NavLink
                      to={item.to}
                      className={({ isActive }) =>
                        [
                          "block rounded-2xl px-4 py-3 text-sm transition",
                          "hover:bg-primary/10 hover:text-primary",
                          isActive ? "bg-primary/15 text-primary" : "text-light/85"
                        ].join(" ")
                      }
                    >
                      {item.label}
                    </NavLink>
                  </li>
                ))}
                <li>
                  <a
                    href="#newsletter"
                    className="mt-3 block rounded-2xl border border-primary/60 bg-primary/10 px-4 py-3 text-center text-xs uppercase tracking-widest text-primary transition hover:bg-primary/20"
                  >
                    Suscríbete al boletín
                  </a>
                </li>
              </ul>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;