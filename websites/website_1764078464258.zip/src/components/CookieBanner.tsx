import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const STORAGE_KEY = "wind-vector-cookie-consent";

const CookieBanner: React.FC = () => {
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timeout = window.setTimeout(() => setIsVisible(true), 1500);
      return () => window.clearTimeout(timeout);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(STORAGE_KEY, "declined");
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed inset-x-0 bottom-0 z-[60] px-4 pb-6 sm:px-6 lg:px-8"
        >
          <div className="mx-auto max-w-5xl rounded-3xl border border-white/10 bg-accent/95 p-6 shadow-glow">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between md:gap-6">
              <div className="space-y-1">
                <h2 className="text-base font-semibold text-primary">
                  Configuración de cookies
                </h2>
                <p className="text-sm text-light/70">
                  Utilizamos cookies analíticas esenciales para comprender el uso de nuestro portal y mejorar la documentación ofrecida. No utilizamos cookies con fines publicitarios.
                </p>
              </div>
              <div className="flex flex-shrink-0 gap-3">
                <button
                  onClick={handleDecline}
                  className="rounded-full border border-white/15 px-4 py-2 text-sm text-light/70 transition hover:border-white/30 hover:text-light"
                >
                  Rechazar
                </button>
                <button
                  onClick={handleAccept}
                  className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-white shadow-lg shadow-primary/30 transition hover:bg-primary/90"
                >
                  Aceptar
                </button>
              </div>
            </div>
            <p className="mt-3 text-xs text-light/60">
              Puedes revisar nuestra <a href="/cookie-policy" className="underline hover:text-primary transition">política de cookies</a> para ampliar la información.
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieBanner;