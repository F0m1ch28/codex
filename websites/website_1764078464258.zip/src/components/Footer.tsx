import React from "react";
import { Link } from "react-router-dom";

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-white/5 bg-accent/80 backdrop-blur-lg">
      <div className="mx-auto flex max-w-7xl flex-col gap-12 px-4 py-12 sm:px-6 lg:px-8 lg:flex-row lg:justify-between">
        <div className="max-w-md space-y-4">
          <div className="flex items-center gap-3">
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-primary/40 bg-primary/10 text-primary font-semibold">
              WV
            </span>
            <div>
              <p className="text-lg font-semibold font-display text-light">
                Wind Vector Hub
              </p>
              <p className="text-sm text-light/70">
                Observatorio de infraestructura eólica española.
              </p>
            </div>
          </div>
          <p className="text-sm text-light/70">
            Documentamos con precisión los sistemas eólicos españoles, apoyando a equipos de ingeniería, planners territoriales y operadores de red con datos verificados, mapas comparables y análisis de trazabilidad.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-primary">
              Navegación
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-light/75">
              <li><Link to="/" className="hover:text-primary transition">Inicio</Link></li>
              <li><Link to="/about" className="hover:text-primary transition">Sobre nosotros</Link></li>
              <li><Link to="/operations" className="hover:text-primary transition">Operaciones</Link></li>
              <li><Link to="/blog" className="hover:text-primary transition">Blog</Link></li>
              <li><Link to="/contact" className="hover:text-primary transition">Contacto</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-primary">
              Recursos
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-light/75">
              <li><Link to="/terms" className="hover:text-primary transition">Términos y condiciones</Link></li>
              <li><Link to="/privacy" className="hover:text-primary transition">Política de privacidad</Link></li>
              <li><Link to="/cookie-policy" className="hover:text-primary transition">Política de cookies</Link></li>
              <li><a href="#newsletter" className="hover:text-primary transition">Boletín técnico</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-primary">
              Contacto
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-light/75">
              <li>Calle de la Energía 12</li>
              <li>28042 Madrid, España</li>
              <li>Teléfono: +34 91 555 4782</li>
              <li>Email: será añadido en el formulario de contacto</li>
            </ul>
            <div className="mt-4 flex gap-3 text-light/60">
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
                aria-label="LinkedIn Wind Vector Hub"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M6.94 6.5a1.94 1.94 0 11-1.94-1.94 1.94 1.94 0 011.94 1.94zM5 8.47h2v10H5zM14.4 8.31c-2.05 0-3.02 1.12-3.55 1.9V8.47H8.8v10h2.05V13.2c0-1.33.94-2.32 2.2-2.32s1.9.89 1.9 2.32v5.27H17v-5.63c0-2.7-1.44-4.53-3.6-4.53z" />
                </svg>
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
                aria-label="Twitter Wind Vector Hub"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M21 5.89a6.41 6.41 0 01-1.89.52A3.28 3.28 0 0020.42 4a6.56 6.56 0 01-2.06.81 3.26 3.26 0 00-5.57 2.23 3.36 3.36 0 00.08.74 9.29 9.29 0 01-6.77-3.43 3.26 3.26 0 001 4.35 3.23 3.23 0 01-1.48-.41v.04a3.27 3.27 0 002.61 3.2 3.28 3.28 0 01-1.47.06 3.27 3.27 0 003.05 2.27 6.54 6.54 0 01-4 1.37 6.68 6.68 0 01-.78-.05 9.22 9.22 0 005 1.47c6 0 9.28-5 9.28-9.28q0-.21 0-.42A6.7 6.7 0 0021 5.89z" />
                </svg>
              </a>
              <a
                href="https://www.youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition"
                aria-label="YouTube Wind Vector Hub"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M21.58 7.19a2.69 2.69 0 00-1.89-1.91C18.17 5 12 5 12 5s-6.17 0-7.69.28a2.69 2.69 0 00-1.89 1.91A28.37 28.37 0 002 12a28.37 28.37 0 00.42 4.81 2.69 2.69 0 001.89 1.91C5.83 19 12 19 12 19s6.17 0 7.69-.28a2.69 2.69 0 001.89-1.91A28.37 28.37 0 0022 12a28.37 28.37 0 00-.42-4.81zM10 15.12V8.88L15.18 12z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="border-t border-white/5 bg-base/60 py-4 text-center text-xs text-light/60">
        © {new Date().getFullYear()} Wind Vector Hub. Documentación técnica para la infraestructura eólica de España.
      </div>
    </footer>
  );
};

export default Footer;