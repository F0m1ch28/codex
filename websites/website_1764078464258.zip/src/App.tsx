import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { Helmet } from "react-helmet";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import Blog from "./pages/Blog";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import CookiePolicy from "./pages/CookiePolicy";
import TurbineLayoutOptimization from "./pages/blog/TurbineLayoutOptimization";
import AccessPathAnalysis from "./pages/blog/AccessPathAnalysis";
import GridInterfaceStudies from "./pages/blog/GridInterfaceStudies";

const App: React.FC = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname]);

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Wind Vector Hub",
    url: "https://www.windvectorhub.es",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Calle de la Energía 12",
      addressLocality: "Madrid",
      postalCode: "28042",
      addressCountry: "ES"
    },
    telephone: "+34 91 555 4782"
  };

  return (
    <div className="bg-base text-light min-h-screen flex flex-col">
      <Helmet>
        <meta name="language" content="es-ES" />
        <script type="application/ld+json">{JSON.stringify(organizationJsonLd)}</script>
      </Helmet>
      <Header />
      <main className="flex-1 pt-20 md:pt-24">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/operations" element={<Services />} />
          <Route path="/services" element={<Services />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/turbine-layout-optimization" element={<TurbineLayoutOptimization />} />
          <Route path="/blog/access-path-analysis" element={<AccessPathAnalysis />} />
          <Route path="/blog/grid-interface-studies" element={<GridInterfaceStudies />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  );
};

export default App;