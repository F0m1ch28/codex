import React from "react";
import { Helmet } from "react-helmet";

interface Cluster {
  title: string;
  paragraphs: string[];
  links: { name: string; href: string }[];
}

const clusters: Cluster[] = [
  {
    title: "Distribución de turbinas y diseño de parques",
    paragraphs: [
      "Mapeamos cada parque en relación con pendientes, rugosidades y servidumbres existentes. Empleamos modelos de flujo independientes y verificamos con campañas anemométricas para documentar decisiones de layout.",
      "El análisis incluye distancias mínimas entre turbinas, recursos de viento residual y configuraciones para minimizar estelas en repotenciaciones. Las fichas recogen la interacción con otras infraestructuras, como parques adyacentes o corredores ambientales.",
      "Cada diseño incorpora métricas comparables: densidad instalada, potencia específica del emplazamiento y factores de capacidad históricos. Así facilitamos comparativas rápidas entre regiones."
    ],
    links: [
      { name: "Atlas eólico IDAE", href: "https://atlaseolico.idae.es/" },
      { name: "Norma IEC 61400-1", href: "https://www.iec.ch/dyn/www/f?p=103:111:0::::FSP_ORG_ID,FSP_PROJECT_ID:1255,10377" },
      { name: "Planeamiento territorial MITERD", href: "https://energia.gob.es/" }
    ]
  },
  {
    title: "Caminos de acceso y logística",
    paragraphs: [
      "Evaluamos el estado de carreteras, puentes y pistas forestales necesarias para el transporte de componentes. Empleamos perfiles altimétricos, radios de giro y simulaciones logísticas para verificar la viabilidad.",
      "Incluimos recomendaciones de refuerzo temporal, puntos de espera, necesidades de balizamiento y protocolos de seguridad asociados a cada tramo. Las rutas se actualizan con datos de mantenimiento y restricciones municipales.",
      "Trabajamos de forma coordinada con autoridades locales y operadores de transporte, registrando horarios autorizados, velocidades máximas y tiempos de montaje previstos."
    ],
    links: [
      { name: "Guías de transporte especial DGT", href: "https://www.dgt.es/" },
      { name: "Cartografía del Instituto Geográfico Nacional", href: "https://www.ign.es/web" },
      { name: "AEMET - Datos meteorológicos en ruta", href: "https://www.aemet.es/es/portada" },
      { name: "Manual de seguridad en transporte pesado", href: "https://www.insst.es/" }
    ]
  },
  {
    title: "Integración con la red eléctrica",
    paragraphs: [
      "Documentamos el proceso de acceso y conexión con la red de transporte y distribución. Analizamos la topología de subestaciones, capacidad disponible y requisitos de control en tiempo real.",
      "Los informes detallan configuraciones de embarrados, protecciones, estudios de cortocircuito y sistemas de telecontrol. Incluimos matrices comparables que describen qué equipos se han instalado y cómo se coordinan con REE.",
      "La actualización continua contempla modificaciones de regulación, nuevos procedimientos de operación y resultados de pruebas P.O. 12.3. Incorporamos notas sobre limitaciones temporales y cronogramas de refuerzo."
    ],
    links: [
      { name: "Red Eléctrica de España - Acceso y conexión", href: "https://www.ree.es/es/gestion-red/sistema-electricidad/acceso-y-conexion" },
      { name: "Procedimientos de operación REE", href: "https://www.ree.es/es/gestion-red/sistema-electricidad/procedimientos-operacion" },
      { name: "CNMC - Información de capacidad", href: "https://www.cnmc.es/ambitos-de-actuacion/energia" }
    ]
  }
];

const Services: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Operaciones documentadas | Wind Vector Hub</title>
        <link rel="canonical" href="https://www.windvectorhub.es/operations" />
        <meta
          name="description"
          content="Descubre los clusters operativos de Wind Vector Hub: distribución de turbinas, accesos y logística, e integración con la red eléctrica."
        />
      </Helmet>
      <section className="bg-base pt-28 pb-16 sm:pt-32 sm:pb-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs uppercase tracking-[0.3em] text-primary">
            Operaciones
          </span>
          <h1 className="mt-4 text-4xl font-semibold text-white font-display">
            Clústeres de operación eólica
          </h1>
          <p className="mt-4 text-base text-light/70">
            Nuestros equipos analizan la distribución de turbinas, los caminos de acceso y la interfaz con la red para ofrecer documentación coherente y reutilizable.
          </p>
        </div>
      </section>

      <section className="bg-accent/70 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl space-y-12 px-4 sm:px-6 lg:px-8">
          {clusters.map((cluster) => (
            <article
              key={cluster.title}
              className="rounded-3xl border border-white/5 bg-base/60 p-10 transition hover:border-primary/40"
            >
              <h2 className="text-2xl font-semibold text-white font-display">{cluster.title}</h2>
              <div className="mt-6 space-y-4 text-sm text-light/70">
                {cluster.paragraphs.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
              <div className="mt-6 rounded-2xl border border-white/10 bg-accent/60 p-5">
                <h3 className="text-sm font-semibold text-primary uppercase tracking-wide">
                  Enlaces de referencia
                </h3>
                <ul className="mt-3 space-y-2 text-sm text-light/70">
                  {cluster.links.map((link) => (
                    <li key={link.href}>
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-primary hover:underline"
                      >
                        {link.name}
                        <svg className="ml-2 h-4 w-4" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round">
                          <path d="M5 12h14M13 5l7 7-7 7" />
                        </svg>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Services;