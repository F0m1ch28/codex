import React from "react";
import { Helmet } from "react-helmet";

const Privacy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Política de privacidad | Wind Vector Hub</title>
        <link rel="canonical" href="https://www.windvectorhub.es/privacy" />
      </Helmet>
      <section className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-4xl space-y-8 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-semibold text-white font-display">
            Política de privacidad
          </h1>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">1. Responsable del tratamiento</h2>
            <p className="mt-2">
              Wind Vector Hub, con sede en Calle de la Energía 12, 28042 Madrid, España, es responsable del tratamiento de los datos facilitados a través de los formularios del sitio web.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">2. Datos tratados y finalidad</h2>
            <p className="mt-2">
              Recogemos nombre, correo electrónico y mensaje para gestionar consultas técnicas o solicitudes de información. Únicamente utilizamos estos datos para responder a la petición y mantener trazabilidad del intercambio.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">3. Conservación</h2>
            <p className="mt-2">
              Los datos se conservan durante el tiempo necesario para atender la consulta y, en su caso, mantener un registro histórico de intercambios relevantes. Posteriormente se eliminan o anonimiza su contenido.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">4. Derechos</h2>
            <p className="mt-2">
              Puedes ejercitar derechos de acceso, rectificación, supresión, oposición y limitación escribiendo a través del formulario de contacto. Atenderemos la solicitud en los plazos establecidos por la normativa vigente.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">5. Seguridad</h2>
            <p className="mt-2">
              Aplicamos medidas técnicas y administrativas para proteger la información frente a accesos no autorizados. Revisamos periódicamente los procedimientos y actualizamos nuestros sistemas cuando es necesario.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Privacy;