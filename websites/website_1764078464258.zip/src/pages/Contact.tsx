import React from "react";
import { Helmet } from "react-helmet";

interface FormState {
  name: string;
  email: string;
  message: string;
}

const initialState: FormState = {
  name: "",
  email: "",
  message: ""
};

const Contact: React.FC = () => {
  const [formData, setFormData] = React.useState<FormState>(initialState);
  const [errors, setErrors] = React.useState<Partial<FormState>>({});
  const [status, setStatus] = React.useState<"idle" | "loading" | "success" | "error">("idle");

  const handleChange = (field: keyof FormState) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [field]: event.target.value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const newErrors: Partial<FormState> = {};
    if (!formData.name.trim()) newErrors.name = "Introduce tu nombre completo.";
    if (!formData.email.includes("@")) newErrors.email = "Introduce un correo válido.";
    if (formData.message.trim().length < 10) newErrors.message = "Describe con más detalle tu consulta.";
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setStatus("error");
      return;
    }
    setStatus("loading");
    setTimeout(() => {
      setStatus("success");
      setFormData(initialState);
    }, 1000);
  };

  return (
    <>
      <Helmet>
        <title>Contacto | Wind Vector Hub</title>
        <link rel="canonical" href="https://www.windvectorhub.es/contact" />
        <meta
          name="description"
          content="Contacta con Wind Vector Hub para compartir datos, solicitar documentación complementaria o coordinar observaciones de parques eólicos."
        />
      </Helmet>
      <section className="bg-base pt-28 pb-16 sm:pt-32 sm:pb-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs uppercase tracking-[0.3em] text-primary">
            Contacto técnico
          </span>
          <h1 className="mt-4 text-4xl font-semibold text-white font-display">
            Coordina información con nuestro equipo
          </h1>
          <p className="mt-4 text-base text-light/70">
            Comparte datos, solicita aclaraciones o coordina actualizaciones sobre parques eólicos en España. Respondemos con foco técnico y trazabilidad completa.
          </p>
        </div>
      </section>

      <section className="bg-accent/70 py-16 sm:py-20">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
          <div className="space-y-6">
            <div className="rounded-3xl border border-white/10 bg-base/60 p-6">
              <h2 className="text-xl font-semibold text-white font-display">
                Datos de contacto
              </h2>
              <ul className="mt-4 space-y-3 text-sm text-light/70">
                <li>Calle de la Energía 12</li>
                <li>28042 Madrid, España</li>
                <li>Teléfono: +34 91 555 4782</li>
                <li>Email: será añadido en el formulario de contacto</li>
              </ul>
            </div>
            <div className="rounded-3xl border border-white/10 bg-base/60 p-6 text-sm text-light/70">
              <p>
                Revisamos a diario las solicitudes recibidas. Si aportas documentación complementaria, indica la procedencia y fecha de actualización para mantener la trazabilidad. Nuestro equipo puede coordinar reuniones virtuales cuando se requiere intercambio de datos en profundidad.
              </p>
            </div>
          </div>
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl border border-white/10 bg-base/60 p-8 shadow-lg shadow-black/30"
          >
            <h2 className="text-xl font-semibold text-white font-display">Formulario de contacto</h2>
            <p className="mt-2 text-sm text-light/60">
              Completa todos los campos para que podamos responder con precisión.
            </p>
            <div className="mt-6 space-y-5">
              <div>
                <label className="text-sm font-medium text-light/80" htmlFor="name">
                  Nombre completo
                </label>
                <input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange("name")}
                  className="mt-2 w-full rounded-2xl border border-white/10 bg-accent/50 px-4 py-3 text-sm text-light placeholder:text-light/40 focus:border-primary/60 focus:ring-primary/40"
                  placeholder="Nombre y apellidos"
                  required
                />
                {errors.name && <p className="mt-1 text-xs text-red-300">{errors.name}</p>}
              </div>
              <div>
                <label className="text-sm font-medium text-light/80" htmlFor="email">
                  Correo electrónico
                </label>
                <input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange("email")}
                  className="mt-2 w-full rounded-2xl border border-white/10 bg-accent/50 px-4 py-3 text-sm text-light placeholder:text-light/40 focus:border-primary/60 focus:ring-primary/40"
                  placeholder="nombre@organizacion.es"
                  required
                />
                {errors.email && <p className="mt-1 text-xs text-red-300">{errors.email}</p>}
              </div>
              <div>
                <label className="text-sm font-medium text-light/80" htmlFor="message">
                  Mensaje
                </label>
                <textarea
                  id="message"
                  value={formData.message}
                  onChange={handleChange("message")}
                  className="mt-2 h-36 w-full rounded-2xl border border-white/10 bg-accent/50 px-4 py-3 text-sm text-light placeholder:text-light/40 focus:border-primary/60 focus:ring-primary/40"
                  placeholder="Describe la información que necesitas o el dataset que deseas compartir."
                  required
                />
                {errors.message && <p className="mt-1 text-xs text-red-300">{errors.message}</p>}
              </div>
            </div>
            <button
              type="submit"
              className="mt-6 inline-flex w-full items-center justify-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white transition hover:bg-primary/90"
              disabled={status === "loading"}
            >
              {status === "loading" ? "Enviando..." : "Enviar consulta"}
            </button>
            {status === "success" && (
              <p className="mt-4 text-sm text-primary">
                Hemos recibido tu mensaje. Responderemos en el plazo de dos días laborables.
              </p>
            )}
            {status === "error" && Object.keys(errors).length === 0 && (
              <p className="mt-4 text-sm text-red-300">
                Ocurrió un problema temporal. Vuelve a intentar en unos minutos.
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default Contact;