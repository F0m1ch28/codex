import React from "react";
import { Helmet } from "react-helmet";

const Terms: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Términos y condiciones | Wind Vector Hub</title>
        <link rel="canonical" href="https://www.windvectorhub.es/terms" />
      </Helmet>
      <section className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-4xl space-y-8 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-semibold text-white font-display">
            Términos y condiciones de uso
          </h1>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">1. Objeto</h2>
            <p className="mt-2">
              El presente documento regula el acceso y uso de la plataforma Wind Vector Hub. Al utilizar el sitio web aceptas estos términos y te comprometes a emplear la información respetando su procedencia y alcance técnico.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">2. Uso permitido</h2>
            <p className="mt-2">
              El contenido se ofrece con finalidad informativa y técnica. Puedes consultarlo, citarlo y compartirlo indicando la fuente. No está permitido modificarlo para atribuir conclusiones distintas ni presentarlo como documentación oficial.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">3. Propiedad intelectual</h2>
            <p className="mt-2">
              Los textos, mapas y visualizaciones son propiedad de Wind Vector Hub o de las fuentes citadas. Las marcas registradas de terceros se mencionan únicamente para identificar equipos o entidades relacionadas.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">4. Limitación de responsabilidad</h2>
            <p className="mt-2">
              A pesar de nuestras verificaciones, la información puede evolucionar. Wind Vector Hub no asume responsabilidad por decisiones tomadas exclusivamente con base en estos contenidos. Recomendamos contrastar con documentación oficial actualizada.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">5. Actualizaciones de los términos</h2>
            <p className="mt-2">
              Nos reservamos el derecho de modificar estas condiciones para adaptarlas a cambios normativos o mejoras de la plataforma. Las versiones vigentes estarán disponibles en esta página.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default Terms;