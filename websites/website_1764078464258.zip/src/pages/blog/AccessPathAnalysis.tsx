import React from "react";
import { Helmet } from "react-helmet";

const AccessPathAnalysis: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Análisis de caminos de acceso | Wind Vector Hub</title>
        <link rel="canonical" href="https://www.windvectorhub.es/blog/access-path-analysis" />
        <meta
          name="description"
          content="Evaluamos la planificación, refuerzo y mantenimiento de caminos de acceso para parques eólicos en España, con ejemplos reales y visuales técnicos."
        />
      </Helmet>
      <article className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-3xl space-y-6 px-4 sm:px-6 lg:px-8">
          <span className="text-xs uppercase tracking-[0.3em] text-primary">
            Caminos de acceso
          </span>
          <h1 className="text-4xl font-semibold text-white font-display">
            Análisis integral de caminos de acceso para aerogeneradores
          </h1>
          <p className="text-sm text-light/70">
            Publicado el 02 marzo 2024 · 8 min de lectura técnica
          </p>

          <p className="text-sm text-light/80">
            Un parque eólico depende de caminos de acceso capaces de soportar transporte de componentes gigantes. En la península, el relieve y la dispersión de infraestructuras exigen estudiar tramos existentes, planificar refuerzos y coordinar permisos. Hemos analizado 18 rutas completas desde puerto o taller hasta emplazamientos en Aragón, Castilla y León y Galicia.
          </p>
          <p className="text-sm text-light/80">
            El estudio parte de una cartografía detallada con el MDT de 5 metros. Medimos pendientes, radios de curva y ancho disponible. Cuando identificamos limitaciones, proponemos alternativas: ensanches temporales, desmontes puntuales o bypass. Las recomendaciones incluyen diagramas constructivos y cronogramas, vinculados a ventanas meteorológicas.
          </p>
          <p className="text-sm text-light/80">
            Las autoridades de tráfico y los ayuntamientos desempeñan un papel clave. Registramos cada autorización, horarios restringidos y contactos de emergencia. Los informes muestran la ruta paso a paso, con coordenadas y fotografías georreferenciadas que permiten replicar la inspección.
          </p>

          <figure className="rounded-3xl border border-white/10 bg-accent/60 p-4">
            <img
              src="https://picsum.photos/1000/600?random=221"
              alt="Mapa del trazado logístico con puntos de control"
              className="w-full rounded-2xl object-cover"
              loading="lazy"
            />
            <figcaption className="mt-3 text-xs text-light/60">
              Visual 1. Ruta logística con identificación de puntos críticos y radios de giro.
            </figcaption>
          </figure>

          <p className="text-sm text-light/80">
            Durante la fase de transporte nocturno, los equipos deben coordinar escoltas y cortes puntuales. Documentamos los tiempos reales de recorrido, el impacto de la climatología y los márgenes previstos entre convoyes. Esta información se integra con partes meteorológicos y previsiones de viento, esenciales para maniobrar palas de 70 metros.
          </p>
          <p className="text-sm text-light/80">
            Se prestó atención a la transición entre caminos existentes y ramales internos de obra. Las plataformas de grúas requieren compactación reforzada y control de drenaje. En Navarra, un tramo de 600 metros sufrió daños por lluvias torrenciales; el refuerzo posterior incluyó geotextiles, cunetas dobles y peraltes corregidos.
          </p>

          <blockquote className="rounded-3xl border-l-4 border-primary/60 bg-accent/50 p-6 text-sm text-light/70">
            “El seguimiento continuo de los tramos sensibles evitó retrasos mayores. El equipo local reportaba cada incidencia en un visor compartido, y las cuadrillas actuaban con instrucciones claras.” — Coordinación logística de parque Alto Jalón.
          </blockquote>

          <p className="text-sm text-light/80">
            Para evaluar la resistencia de puentes, trabajamos con los informes estructurales históricos y realizamos pruebas de carga cuando era necesario. Se obtiene una matriz que compara el peso del convoy con la capacidad admisible, incluyendo márgenes de seguridad acordados con las autoridades provinciales.
          </p>

          <figure className="rounded-3xl border border-white/10 bg-accent/60 p-4">
            <img
              src="https://picsum.photos/1000/600?random=222"
              alt="Sección transversal de camino de acceso reforzado"
              className="w-full rounded-2xl object-cover"
              loading="lazy"
            />
            <figcaption className="mt-3 text-xs text-light/60">
              Visual 2. Sección reforzada con capas de zahorra y refuerzo geotextil.
            </figcaption>
          </figure>

          <p className="text-sm text-light/80">
            Las rutas se mantienen tras la puesta en marcha para el mantenimiento mayor. Por ello, describimos un plan de conservación a medio plazo: drenajes, vegetación, control de baches y señalización. Los contratos de operación incluyen estas tareas y se monitorean con indicadores de estado.
          </p>
          <p className="text-sm text-light/80">
            Finalmente, las rutas se integran en la base de datos de Wind Vector Hub con perfiles descargables y metadatos de permisos. Esto permite a otros proyectos anticipar requisitos, reutilizar conocimiento y optimizar sus planificaciones.
          </p>
        </div>
      </article>
    </>
  );
};

export default AccessPathAnalysis;