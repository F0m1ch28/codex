import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import {
  motion,
  useInView,
  animate
} from "framer-motion";

type ProjectCategory = "Distribución" | "Accesos" | "Interfaz";

interface ProjectItem {
  id: number;
  title: string;
  category: ProjectCategory;
  description: string;
  image: string;
}

const AnimatedNumber: React.FC<{ value: number; suffix?: string }> = ({ value, suffix = "" }) => {
  const ref = React.useRef<HTMLSpanElement | null>(null);
  const [displayValue, setDisplayValue] = React.useState(0);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  React.useEffect(() => {
    if (isInView) {
      const controls = animate(0, value, {
        duration: 1.6,
        ease: "easeOut",
        onUpdate: (latest) => {
          setDisplayValue(Math.floor(latest));
        }
      });
      return () => controls.stop();
    }
  }, [isInView, value]);

  return (
    <span ref={ref}>
      {displayValue.toLocaleString("es-ES")}
      {suffix}
    </span>
  );
};

const Home: React.FC = () => {
  const [activeFilter, setActiveFilter] = React.useState<ProjectCategory | "Todos">("Todos");
  const [newsletterEmail, setNewsletterEmail] = React.useState("");
  const [newsletterStatus, setNewsletterStatus] = React.useState<"idle" | "loading" | "success" | "error">("idle");
  const [testimonialIndex, setTestimonialIndex] = React.useState(0);

  const stats = [
    { label: "Turbinas monitorizadas", value: 4275 },
    { label: "Subestaciones analizadas", value: 138, suffix: "" },
    { label: "Km de caminos auditados", value: 960 },
    { label: "Estudios de interfaz eléctrica", value: 92 }
  ];

  const analysisSections = [
    {
      title: "Evaluación aerodinámica de coronas",
      description:
        "Comparamos el rendimiento efectivo de coronas eólicas en entornos topográficos complejos mediante capas GIS y mediciones lidars. Identificamos turbulencias inducidas por cambios de rugosidad y establecemos umbrales de micro-siting para reducir estelas internas.",
      details: [
        "Matrices de densidad de potencia ajustadas por orografía",
        "Modelado de estelas cruzadas en escenarios de repotenciación",
        "Análisis de pérdidas dinámicas frente a viento nocturno"
      ]
    },
    {
      title: "Dinámica de flota en parques multi-tecnología",
      description:
        "Documentamos la convivencia de aerogeneradores de generaciones diferentes, describiendo condiciones de control, protocolos de frenado y ajustes de yaw que mantienen la estabilidad del parque sin sobrecargar inversores legacy.",
      details: [
        "Comparativa de curvas de potencia homologadas",
        "Sincronización de SCADA híbrido para parques agrupados",
        "Protocolos de mantenimiento predictivo en nacelles mixtas"
      ]
    },
    {
      title: "Monitorización de vibraciones estructurales",
      description:
        "Integramos mediciones en tiempo real con patrones históricos para distinguir entre desgaste progresivo y incidencias puntuales. Los dashboards incluyen alertas basadas en aprendizaje estadístico no supervisado.",
      details: [
        "Matrices espectrales de vibración longitudinal",
        "Límites de operación por carga extrema IEC 61400",
        "Interfaz con sistemas de supervisión de torres"
      ]
    }
  ];

  const planningModules = [
    {
      title: "Modelos de planificación territorial",
      summary:
        "Cartografiamos exclusiones ambientales, corredores logísticos y servidumbres eléctricas para anticipar configuraciones viables. Los módulos incorporan sensibilidad a distancias mínimas y gradientes de pendiente en la fase de selección.",
      image: "https://picsum.photos/800/600?random=121"
    },
    {
      title: "Secuenciación de montaje",
      summary:
        "Establecemos cronogramas sincronizados con ventanas meteorológicas, torres de grúas y disponibilidad de palas de gran envergadura. El módulo detalla cada hito logístico, de la cimentación al comisionado.",
      image: "https://picsum.photos/800/600?random=122"
    },
    {
      title: "Gestión de transición a operación",
      summary:
        "Definimos los traspasos entre equipos de construcción y operación, con matrices RACI, pruebas de aceptación y protocolos de entrega de documentación digital. Incluimos checklist de SCADA y calibraciones de sensores.",
      image: "https://picsum.photos/800/600?random=123"
    }
  ];

  const recommendedReading = [
    {
      title: "Cartografía de parques eólicos marinos de transición",
      href: "https://www.iea.org/reports/offshore-wind-outlook",
      description:
        "Panorama de la IEA sobre los desarrollos offshore y su relación con la infraestructura terrestre."
    },
    {
      title: "Metodologías de acceso a red de Red Eléctrica",
      href: "https://www.ree.es/es/",
      description:
        "Documentación pública de Red Eléctrica sobre procedimientos de solicitud y condiciones técnicas."
    },
    {
      title: "Lineamientos de integración ambiental IDAE",
      href: "https://www.idae.es/",
      description:
        "Guías y estudios del Instituto para la Diversificación y Ahorro de la Energía respecto a parques eólicos."
    }
  ];

  const processSteps = [
    {
      step: "01",
      title: "Observación y captura de datos",
      description:
        "Compilamos registros públicos, inspecciones in situ y telemetría abierta para construir la primera capa de referencia del proyecto.",
      icon: (
        <svg className="h-10 w-10 text-primary" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round">
          <path d="M12 5v14M5 12h14" />
        </svg>
      )
    },
    {
      step: "02",
      title: "Curación técnica y validación cruzada",
      description:
        "Contrastamos cada dato con fuentes independientes: visor de Red Eléctrica, registros autonómicos y cartografía del IGN.",
      icon: (
        <svg className="h-10 w-10 text-primary" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round">
          <path d="M20 6L9 17l-5-5" />
        </svg>
      )
    },
    {
      step: "03",
      title: "Modelado y simulación",
      description:
        "Aplicamos modelos de flujo, carga y evacuación energética para ofrecer escenarios comparables y cuantificados.",
      icon: (
        <svg className="h-10 w-10 text-primary" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round">
          <path d="M3 11h6l4-8 8 16h-6l-4 8z" />
        </svg>
      )
    },
    {
      step: "04",
      title: "Difusión y seguimiento",
      description:
        "Publicamos reportes estructurados, fichas descargables y mantenemos seguimiento continuo ante modificaciones regulatorias.",
      icon: (
        <svg className="h-10 w-10 text-primary" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round">
          <path d="M4 4h16v4H4zM4 12h10v8H4z" />
        </svg>
      )
    }
  ];

  const testimonials = [
    {
      quote:
        "Wind Vector Hub se convirtió en la referencia para verificar parámetros de operación compartida. Los informes sobre curvas de potencia comparadas nos ayudaron a revisar acuerdos de disponibilidad con datos claros.",
      name: "María Ortiz",
      role: "Responsable de Operaciones, Consorcio Eólico Manchego"
    },
    {
      quote:
        "La sección de accesos y logística sintetiza información repartida en varios expedientes oficiales. Nos permitió preparar nuestra campaña de transporte pesado con semanas de antelación.",
      name: "Jon Iriarte",
      role: "Coordinador de Construcción, NorteWind Servicios"
    },
    {
      quote:
        "La documentación sobre integración a red nos sirvió para alinear a ingeniería interna con los requisitos de REE y de la distribuidora. Es un recurso preciso y actualizado.",
      name: "Lucía Fernández",
      role: "Ingeniera de Interconexión, Ibergrid Consultoría"
    }
  ];

  const teamPreview = [
    {
      name: "Alba Navarro",
      title: "Cartógrafa de infraestructura",
      focus:
        "Especialista en bases geoespaciales, modelos digitales de terreno y detección de servidumbres críticas.",
      image: "https://picsum.photos/400/400?random=131"
    },
    {
      name: "Samuel Corvera",
      title: "Ing. de sistemas eólicos",
      focus:
        "Analiza curvas de potencia, protocolos SCADA y estrategias de mantenimiento predictivo en flotas diversas.",
      image: "https://picsum.photos/400/400?random=132"
    },
    {
      name: "Lidia Cortés",
      title: "Analista de redes",
      focus:
        "Audita requisitos de evacuación y coordina documentación técnica con operadores de transporte y distribución.",
      image: "https://picsum.photos/400/400?random=133"
    }
  ];

  const projectItems: ProjectItem[] = [
    {
      id: 1,
      title: "Matrix de turbinas en llanura cerealista",
      category: "Distribución",
      description:
        "Estructura modular de 58 aerogeneradores con optimización adaptativa según rugosidad estacional.",
      image: "https://picsum.photos/1200/800?random=141"
    },
    {
      id: 2,
      title: "Análisis de rutas de transporte en Aragón",
      category: "Accesos",
      description:
        "Modelado de radios de giro y puntos de refuerzo en caminos rurales para palas de 70 metros.",
      image: "https://picsum.photos/1200/800?random=142"
    },
    {
      id: 3,
      title: "Integración con subestación 220 kV",
      category: "Interfaz",
      description:
        "Diseño de bahías colectoras con seguimiento de topologías N-1 y telecontrol remoto.",
      image: "https://picsum.photos/1200/800?random=143"
    },
    {
      id: 4,
      title: "Turbinas en cresta rocosa litoral",
      category: "Distribución",
      description:
        "Evaluación de cargas por ráfagas costeras y alineación en cresta con mínima interferencia mutua.",
      image: "https://picsum.photos/1200/800?random=144"
    },
    {
      id: 5,
      title: "Camino de acceso con puentes reforzados",
      category: "Accesos",
      description:
        "Secuencia de obras provisionales para garantizar capacidad portante en tramo forestal.",
      image: "https://picsum.photos/1200/800?random=145"
    },
    {
      id: 6,
      title: "Nodo híbrido solar-eólico",
      category: "Interfaz",
      description:
        "Coordinación de despacho conjunto con algoritmos de limitación inteligente.",
      image: "https://picsum.photos/1200/800?random=146"
    }
  ];

  const faqs = [
    {
      question: "¿Cómo seleccionáis las fuentes de datos para cada proyecto?",
      answer:
        "Partimos de registros oficiales (REE, MITERD, boletines autonómicos), los verificamos con fotografías satélite, visitas y datos aportados por los operadores. Cada registro incorpora una ficha que documenta cuándo y cómo se validó."
    },
    {
      question: "¿Publicáis datos en tiempo real?",
      answer:
        "Trabajamos con datos cuasi en tiempo real cuando están disponibles. En la mayoría de los casos ofrecemos actualizaciones diarias o semanales, priorizando la consistencia frente a la inmediatez."
    },
    {
      question: "¿Puedo compartir las visualizaciones en mi organización?",
      answer:
        "Las visualizaciones están pensadas para uso colaborativo interno. Agradecemos que se cite Wind Vector Hub al reproducirlas en informes o presentaciones."
    },
    {
      question: "¿Qué regiones cubrís con más detalle?",
      answer:
        "Disponemos de cobertura completa sobre la península y seguimiento específico en Baleares y Canarias. Los parques en desarrollo piloto también se incluyen con fichas dedicadas."
    },
    {
      question: "¿Ofrecéis datos descargables?",
      answer:
        "Sí, cada parque cuenta con capas vectoriales y tablas en formatos abiertos. El acceso se gestiona mediante solicitud para asegurar la trazabilidad de las versiones compartidas."
    }
  ];

  const blogPreview = [
    {
      title: "Optimización del despliegue de turbinas",
      excerpt:
        "Exploramos la relación entre distancias mínimas, gradientes y rendimientos reales en parques peninsulares.",
      href: "/blog/turbine-layout-optimization",
      date: "15 abril 2024"
    },
    {
      title: "Análisis de caminos de acceso y mantenimiento",
      excerpt:
        "Un repaso a criterios estructurales y ambientales que determinan la logística del transporte.",
      href: "/blog/access-path-analysis",
      date: "02 marzo 2024"
    },
    {
      title: "Estudios de interfaz con la red",
      excerpt:
        "Revisión de modelos de comportamiento dinámico frente a eventos de red y coordinación con REE.",
      href: "/blog/grid-interface-studies",
      date: "10 febrero 2024"
    }
  ];

  const filteredProjects =
    activeFilter === "Todos"
      ? projectItems
      : projectItems.filter((item) => item.category === activeFilter);

  React.useEffect(() => {
    const interval = window.setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => window.clearInterval(interval);
  }, [testimonials.length]);

  const handleNewsletterSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes("@")) {
      setNewsletterStatus("error");
      return;
    }
    setNewsletterStatus("loading");
    setTimeout(() => {
      setNewsletterStatus("success");
      setNewsletterEmail("");
    }, 1000);
  };

  return (
    <>
      <Helmet>
        <title>Wind Vector Hub | Observando la Infraestructura Eólica de España</title>
        <link rel="canonical" href="https://www.windvectorhub.es/" />
        <meta name="description" content="Plataforma técnica dedicada a documentar, analizar y planificar la infraestructura eólica en España con datos verificables y metodologías contrastadas." />
      </Helmet>

      <section
        className="relative overflow-hidden bg-base pb-24 pt-32 sm:pt-40 md:pt-44"
        style={{
          backgroundImage: "url('https://picsum.photos/1600/900?random=111')",
          backgroundSize: "cover",
          backgroundPosition: "center"
        }}
      >
        <div className="absolute inset-0 bg-base/80 backdrop-blur-sm" />
        <div className="absolute inset-0 bg-grid-pattern bg-[length:32px_32px] opacity-20" />
        <div className="relative mx-auto flex max-w-6xl flex-col gap-10 px-4 sm:px-6 lg:flex-row lg:items-center lg:gap-16 lg:px-8">
          <div className="max-w-3xl">
            <motion.span
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.6 }}
              className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs uppercase tracking-[0.3em] text-primary"
            >
              Monitorización en campo
            </motion.span>
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.7 }}
              className="mt-6 text-4xl font-semibold leading-tight text-white sm:text-5xl md:text-6xl font-display"
            >
              Observando la Infraestructura Eólica de España
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.7 }}
              className="mt-6 text-base text-light/80 md:text-lg"
            >
              Wind Vector Hub ofrece un panorama preciso de parques eólicos, desde su concepción hasta su operación. Combinamos cartografía avanzada, registros públicos y métricas operativas para describir cómo se integra cada turbina en el territorio y en la red eléctrica.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.7 }}
              className="mt-4 text-base text-light/70 md:text-lg"
            >
              Nuestras guías apoyan decisiones técnicas de ingenierías, gestores de proyecto y autoridades locales, facilitando un lenguaje común sobre distancias, perfiles de viento, accesos y condiciones de evacuación.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.7 }}
              className="mt-8 flex flex-col gap-4 sm:flex-row"
            >
              <a
                href="#analisis-turbinas"
                className="inline-flex items-center justify-center rounded-full bg-primary px-8 py-3 text-sm font-semibold text-white shadow-lg shadow-primary/40 transition hover:bg-primary/90"
              >
                Explorar análisis
              </a>
              <Link
                to="/operations"
                className="inline-flex items-center justify-center rounded-full border border-white/20 px-8 py-3 text-sm font-semibold text-white/80 transition hover:border-primary/50 hover:text-primary"
              >
                Ver operaciones
              </Link>
            </motion.div>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6, duration: 0.7 }}
            className="relative mt-6 w-full max-w-md rounded-3xl border border-white/10 bg-accent/80 p-6 backdrop-blur-md lg:mt-0"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm uppercase tracking-[0.3em] text-primary">
                  Estado del viento
                </p>
                <p className="mt-2 text-3xl font-semibold text-white">16,8 m/s</p>
                <p className="mt-1 text-xs text-light/60">
                  Promedio peninsular en última hora (AEMET)
                </p>
              </div>
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-primary/40 bg-primary/10 text-primary font-display text-lg">
                WX
              </span>
            </div>
            <div className="mt-6 space-y-4 text-sm text-light/70">
              <div className="flex items-center justify-between">
                <span>Producción estimada</span>
                <span className="font-semibold text-primary">+3.2% interdiaria</span>
              </div>
              <div className="flex items-center justify-between">
                <span>SCADA monitoreados</span>
                <span>132 parques</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Nota de seguridad</span>
                <span className="text-primary/80">Sin incidencias relevantes</span>
              </div>
            </div>
            <div className="mt-6 rounded-2xl border border-primary/20 bg-primary/5 p-4 text-xs text-light/60">
              Actualizamos el panel meteorológico cada 30 minutos con datos públicos de AEMET, ajustados por la capacidad de los parques activos.
            </div>
          </motion.div>
        </div>
      </section>

      <section className="border-t border-white/5 bg-base py-16 sm:py-20">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 sm:px-6 md:grid-cols-2 lg:grid-cols-4 lg:px-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ delay: index * 0.1 }}
              className="rounded-3xl border border-white/5 bg-accent/60 p-6 backdrop-blur"
            >
              <p className="text-4xl font-semibold text-white font-display">
                <AnimatedNumber value={stat.value} suffix={stat.suffix ?? ""} />
              </p>
              <p className="mt-2 text-sm uppercase tracking-wide text-light/60">
                {stat.label}
              </p>
              <div className="mt-4 h-1 rounded-full bg-white/10">
                <div className="h-full rounded-full bg-primary/80" style={{ width: `${70 + index * 7}%` }} />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section id="analisis-turbinas" className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-white font-display">
                Análisis de configuración de turbinas
              </h2>
              <p className="mt-3 max-w-2xl text-base text-light/70">
                Cada módulo se basa en observaciones reales y datos operativos verificados. Traducimos la teoría en decisiones concretas para emplazamientos españoles.
              </p>
            </div>
            <Link
              to="/blog"
              className="inline-flex items-center rounded-full border border-primary/50 px-5 py-2 text-sm font-medium text-primary transition hover:bg-primary/10"
            >
              Ver publicaciones técnicas
            </Link>
          </div>
          <div className="grid gap-8 md:grid-cols-2">
            {analysisSections.map((section) => (
              <motion.article
                key={section.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.6 }}
                className="group rounded-3xl border border-white/5 bg-accent/70 p-8 backdrop-blur-lg transition hover:-translate-y-1 hover:border-primary/40 hover:bg-accent/90"
              >
                <h3 className="text-xl font-semibold text-white">{section.title}</h3>
                <p className="mt-4 text-sm text-light/70">{section.description}</p>
                <ul className="mt-6 space-y-3 text-sm text-light/65">
                  {section.details.map((detail) => (
                    <li key={detail} className="flex items-start gap-3">
                      <span className="mt-1 h-2 w-2 rounded-full bg-primary/80" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="border-y border-white/5 bg-accent/60 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h2 className="text-3xl font-semibold text-white font-display">
              Módulos de planificación de aerogeneradores
            </h2>
            <p className="mt-3 text-base text-light/70">
              Los módulos vinculan mapas, cronogramas y protocolos operativos. Permiten anticipar fases críticas y evaluar alternativas compatibles con los requisitos regulatorios españoles.
            </p>
          </div>
          <div className="mt-12 grid gap-8 lg:grid-cols-3">
            {planningModules.map((module) => (
              <motion.div
                key={module.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="group relative overflow-hidden rounded-3xl border border-white/5 bg-base shadow-lg shadow-black/20 transition hover:border-primary/50"
              >
                <img
                  src={module.image}
                  alt={`Ilustración del módulo ${module.title}`}
                  className="h-48 w-full object-cover opacity-90 transition duration-500 group-hover:scale-105 group-hover:opacity-100"
                  loading="lazy"
                />
                <div className="space-y-4 p-6">
                  <h3 className="text-xl font-semibold text-white">{module.title}</h3>
                  <p className="text-sm text-light/70">{module.summary}</p>
                  <Link
                    to="/operations"
                    className="inline-flex items-center text-sm font-medium text-primary hover:underline"
                  >
                    Ver metodología
                    <svg className="ml-2 h-4 w-4" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round">
                      <path d="M5 12h14M13 5l7 7-7 7" />
                    </svg>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-semibold text-white font-display">
            Lecturas recomendadas
          </h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {recommendedReading.map((item) => (
              <motion.a
                key={item.title}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="flex h-full flex-col rounded-3xl border border-white/5 bg-accent/70 p-6 transition hover:-translate-y-1 hover:border-primary/50"
              >
                <span className="text-xs uppercase tracking-[0.3em] text-primary">
                  Recurso público
                </span>
                <h3 className="mt-4 text-lg font-semibold text-white">{item.title}</h3>
                <p className="mt-3 text-sm text-light/70">{item.description}</p>
                <span className="mt-6 flex items-center text-sm font-medium text-primary">
                  Consultar
                  <svg className="ml-2 h-4 w-4" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round">
                    <path d="M5 12h14M13 5l7 7-7 7" />
                  </svg>
                </span>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-white/5 bg-accent/80 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <h2 className="text-3xl font-semibold text-white font-display">
                Flujo de trabajo integral
              </h2>
              <p className="mt-4 text-base text-light/70">
                Acompañamos todo el ciclo de vida: desde la observación inicial hasta el seguimiento operativo. Cada paso tiene artefactos verificables, listos para integrarse en los procesos de ingeniería.
              </p>
              <div className="mt-10 grid gap-6 sm:grid-cols-2">
                {processSteps.map((step) => (
                  <div key={step.title} className="rounded-3xl border border-white/5 bg-base/40 p-6">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full border border-primary/30 bg-primary/10 text-sm font-semibold text-primary">
                        {step.step}
                      </div>
                      {step.icon}
                    </div>
                    <h3 className="mt-4 text-lg font-semibold text-white">{step.title}</h3>
                    <p className="mt-2 text-sm text-light/70">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-base/40 p-6">
              <span className="inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs uppercase tracking-[0.3em] text-primary">
                Testimonios
              </span>
              <div className="mt-6 space-y-8">
                {testimonials.map((testimonial, index) => (
                  <motion.blockquote
                    key={testimonial.name}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{
                      opacity: testimonialIndex === index ? 1 : 0,
                      y: testimonialIndex === index ? 0 : 10,
                      position: testimonialIndex === index ? "relative" as const : "absolute" as const,
                      pointerEvents: testimonialIndex === index ? "auto" : "none"
                    }}
                    transition={{ duration: 0.6 }}
                    className="text-light/70"
                  >
                    <p className="text-base leading-relaxed">“{testimonial.quote}”</p>
                    <footer className="mt-4 text-sm text-primary">
                      {testimonial.name} · {testimonial.role}
                    </footer>
                  </motion.blockquote>
                ))}
              </div>
              <div className="mt-8 flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setTestimonialIndex(index)}
                    className={[
                      "h-2 rounded-full transition-all",
                      testimonialIndex === index ? "w-8 bg-primary" : "w-2 bg-white/30"
                    ].join(" ")}
                    aria-label={`Mostrar testimonio ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-white font-display">
                Equipo de campo y análisis
              </h2>
              <p className="mt-3 max-w-2xl text-base text-light/70">
                Los perfiles combinan experiencia en topografía, ingeniería eléctrica y análisis operativo. Trabajamos en conjunto con redes autonómicas de energía para mantener los datos vigentes.
              </p>
            </div>
            <Link
              to="/about"
              className="inline-flex items-center rounded-full border border-primary/50 px-5 py-2 text-sm font-medium text-primary transition hover:bg-primary/10"
            >
              Conocer al equipo
            </Link>
          </div>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {teamPreview.map((member) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="group rounded-3xl border border-white/10 bg-accent/60 p-6 backdrop-blur transition hover:-translate-y-2 hover:border-primary/40"
              >
                <img
                  src={member.image}
                  alt={`Retrato profesional de ${member.name}`}
                  className="h-40 w-full rounded-2xl object-cover transition duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <h3 className="mt-5 text-lg font-semibold text-white">{member.name}</h3>
                <p className="text-sm text-primary">{member.title}</p>
                <p className="mt-3 text-sm text-light/70">{member.focus}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-y border-white/5 bg-accent/70 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-white font-display">
                Casos documentados
              </h2>
              <p className="mt-3 max-w-xl text-sm text-light/70">
                Filtra por categoría para explorar rutas logísticas, layouts de turbinas e interfaces eléctricas asentadas en el territorio español.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              {["Todos", "Distribución", "Accesos", "Interfaz"].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter as ProjectCategory | "Todos")}
                  className={[
                    "rounded-full border px-4 py-2 text-xs uppercase tracking-wide transition",
                    activeFilter === filter
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-white/10 text-light/70 hover:border-primary/40"
                  ].join(" ")}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-10 grid gap-8 lg:grid-cols-3">
            {filteredProjects.map((project) => (
              <motion.article
                key={project.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="overflow-hidden rounded-3xl border border-white/5 bg-base shadow-lg shadow-black/20 transition hover:-translate-y-2 hover:border-primary/40"
              >
                <img
                  src={project.image}
                  alt={`Visualización del proyecto ${project.title}`}
                  className="h-44 w-full object-cover"
                  loading="lazy"
                />
                <div className="space-y-3 p-6">
                  <span className="text-xs uppercase tracking-[0.3em] text-primary">
                    {project.category}
                  </span>
                  <h3 className="text-lg font-semibold text-white">{project.title}</h3>
                  <p className="text-sm text-light/70">{project.description}</p>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-base py-16 sm:py-20">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
          <div>
            <h2 className="text-3xl font-semibold text-white font-display">
              Preguntas frecuentes
            </h2>
            <p className="mt-3 text-sm text-light/70">
              Respondemos dudas recurrentes acerca de la procedencia de la información y los procesos de actualización. Siempre puedes contactarnos para profundizar.
            </p>
            <Link
              to="/contact"
              className="mt-6 inline-flex items-center rounded-full border border-primary/60 px-5 py-2 text-sm font-medium text-primary transition hover:bg-primary/10"
            >
              Enviar una consulta
            </Link>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <details
                key={faq.question}
                className="group overflow-hidden rounded-3xl border border-white/10 bg-accent/70 transition hover:border-primary/40"
              >
                <summary className="flex cursor-pointer items-center justify-between px-6 py-5 text-sm font-semibold text-white">
                  {faq.question}
                  <span className="ml-4 text-primary transition group-open:rotate-45">
                    <svg className="h-4 w-4" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round">
                      <path d="M12 5v14M5 12h14" />
                    </svg>
                  </span>
                </summary>
                <div className="border-t border-white/5 px-6 py-4 text-sm text-light/70">
                  {faq.answer}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-white/5 bg-accent/75 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-white font-display">
                Últimas notas en el blog
              </h2>
              <p className="mt-3 text-sm text-light/70">
                Actualizamos los análisis con lecciones de campo, nuevos requisitos normativos y resultados de pruebas dinámicas.
              </p>
            </div>
            <Link
              to="/blog"
              className="inline-flex items-center rounded-full border border-primary/50 px-5 py-2 text-sm font-medium text-primary transition hover:bg-primary/10"
            >
              Ver todas las entradas
            </Link>
          </div>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {blogPreview.map((post) => (
              <article
                key={post.title}
                className="rounded-3xl border border-white/10 bg-base/60 p-6 transition hover:-translate-y-1 hover:border-primary/40"
              >
                <span className="text-xs uppercase tracking-[0.2em] text-primary">{post.date}</span>
                <h3 className="mt-4 text-lg font-semibold text-white">{post.title}</h3>
                <p className="mt-3 text-sm text-light/70">{post.excerpt}</p>
                <Link
                  to={post.href}
                  className="mt-5 inline-flex items-center text-sm font-medium text-primary hover:underline"
                >
                  Leer artículo
                  <svg className="ml-2 h-4 w-4" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round">
                    <path d="M5 12h14M13 5l7 7-7 7" />
                  </svg>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="newsletter" className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-4xl rounded-3xl border border-primary/30 bg-primary/10 px-6 py-12 text-center shadow-lg shadow-primary/30 sm:px-10">
          <h2 className="text-3xl font-semibold text-white font-display">
            Suscríbete al boletín técnico Wind Vector
          </h2>
          <p className="mt-4 text-sm text-light/70">
            Compartimos actualizaciones sobre normativas, resultados de pruebas de campo y rutas logísticas destacadas. Un envío quincenal, sin contenidos comerciales.
          </p>
          <form onSubmit={handleNewsletterSubmit} className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <input
              type="email"
              name="email"
              required
              value={newsletterEmail}
              onChange={(event) => {
                setNewsletterEmail(event.target.value);
                setNewsletterStatus("idle");
              }}
              placeholder="tu.email@organizacion.es"
              className="h-12 w-full rounded-full border border-white/10 bg-base/70 px-5 text-sm text-light placeholder:text-light/40 focus:border-primary/60 focus:ring-primary/40 sm:max-w-xs"
            />
            <button
              type="submit"
              className="inline-flex h-12 items-center justify-center rounded-full bg-primary px-6 text-sm font-semibold text-white transition hover:bg-primary/90"
              disabled={newsletterStatus === "loading"}
            >
              {newsletterStatus === "loading" ? "Enviando..." : "Recibir boletín"}
            </button>
          </form>
          {newsletterStatus === "success" && (
            <p className="mt-4 text-sm text-primary">
              Gracias por suscribirte. Recibirás la próxima edición en tu bandeja.
            </p>
          )}
          {newsletterStatus === "error" && (
            <p className="mt-4 text-sm text-red-300">
              Revisa el formato del correo electrónico antes de reenviar.
            </p>
          )}
        </div>
      </section>

      <section className="border-t border-white/5 bg-accent/70 py-12">
        <div className="mx-auto max-w-6xl px-4 text-sm text-light/60 sm:px-6 lg:px-8">
          <p>
            <strong className="text-primary">Aviso técnico:</strong> Wind Vector Hub no sustituye documentación oficial de operadores o autoridades. El contenido se basa en fuentes públicas, verificaciones de campo y datos aportados por agentes del sector. La información puede evolucionar con nuevos permisos, modificaciones constructivas o actualizaciones regulatorias.
          </p>
        </div>
      </section>
    </>
  );
};

export default Home;