import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

const posts = [
  {
    title: "Optimización del despliegue de turbinas",
    date: "15 abril 2024",
    excerpt:
      "Descubrimos cómo las nuevas metodologías de micro-siting equilibran distancias de seguridad, gradientes y rendimiento real con sensores en campo.",
    href: "/blog/turbine-layout-optimization"
  },
  {
    title: "Análisis de caminos de acceso y mantenimiento",
    date: "02 marzo 2024",
    excerpt:
      "Los corredores logísticos se estudian con topografía detallada, criterios estructurales y coordinación con autoridades locales para traslado de componentes XXL.",
    href: "/blog/access-path-analysis"
  },
  {
    title: "Estudios de interfaz con la red",
    date: "10 febrero 2024",
    excerpt:
      "Modelos dinámicos y pruebas de cumplimiento frente a variaciones de frecuencia y tensión, con seguimiento de los procedimientos de operación de REE.",
    href: "/blog/grid-interface-studies"
  }
];

const Blog: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Blog técnico | Wind Vector Hub</title>
        <link rel="canonical" href="https://www.windvectorhub.es/blog" />
        <meta
          name="description"
          content="Notas y análisis sobre planificación, logística y operación de parques eólicos en España. Actualizaciones periódicas con datos verificados."
        />
      </Helmet>
      <section className="bg-base pt-28 pb-16 sm:pt-32 sm:pb-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs uppercase tracking-[0.3em] text-primary">Blog técnico</span>
          <h1 className="mt-4 text-4xl font-semibold text-white font-display">
            Análisis recientes de infraestructura eólica
          </h1>
          <p className="mt-4 text-base text-light/70">
            Cada artículo profundiza en casos reales y metodologías aplicadas en el territorio español.
          </p>
        </div>
      </section>
      <section className="bg-accent/70 py-16 sm:py-20">
        <div className="mx-auto max-w-6xl grid gap-8 px-4 sm:px-6 lg:px-8 md:grid-cols-2">
          {posts.map((post) => (
            <article key={post.href} className="rounded-3xl border border-white/5 bg-base/60 p-8 transition hover:border-primary/40">
              <span className="text-xs uppercase tracking-[0.3em] text-primary">{post.date}</span>
              <h2 className="mt-4 text-2xl font-semibold text-white font-display">{post.title}</h2>
              <p className="mt-4 text-sm text-light/70">{post.excerpt}</p>
              <Link
                to={post.href}
                className="mt-6 inline-flex items-center text-sm font-semibold text-primary hover:underline"
              >
                Leer más
                <svg className="ml-2 h-4 w-4" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round">
                  <path d="M5 12h14M13 5l7 7-7 7" />
                </svg>
              </Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blog;