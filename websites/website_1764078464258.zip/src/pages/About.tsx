import React from "react";
import { Helmet } from "react-helmet";

const teamMembers = [
  {
    name: "Alba Navarro",
    role: "Cartógrafa de infraestructura",
    bio: "Graduada en Geografía y Ordenación del Territorio, Alba coordina la digitalización de capas territoriales, integra datos LiDAR y supervisa la consistencia entre planos oficiales y trazados de campo.",
    focus: "Especialidad en visores GIS y sistemas de referencia oficiales.",
    image: "https://picsum.photos/400/400?random=201"
  },
  {
    name: "Samuel Corvera",
    role: "Ingeniero de sistemas eólicos",
    bio: "Samuel aporta más de diez años en operación de parques peninsulares y canarios. Evalúa curvas de potencia, algoritmos de control y políticas de mantenimiento para flotas multitecnología.",
    focus: "Experto en estándares IEC 61400 y protocolos SCADA abiertos.",
    image: "https://picsum.photos/400/400?random=202"
  },
  {
    name: "Lidia Cortés",
    role: "Analista de integración a red",
    bio: "Lidia analiza la ventilación de cada proyecto con la red de transporte y distribución, revisando requisitos de REE y condiciones particulares de los operadores autonómicos.",
    focus: "Seguimiento de estudios de acceso y conexión.",
    image: "https://picsum.photos/400/400?random=203"
  },
  {
    name: "Jorge Quintela",
    role: "Documentalista de operaciones",
    bio: "Jorge identifica las mejores prácticas de puesta en marcha y transición a operación, asegurando que cada entrega incluya procedimientos, checklists y reportes reproducibles.",
    focus: "Coordinación con equipos de campo y mantenimiento predictivo.",
    image: "https://picsum.photos/400/400?random=204"
  }
];

const About: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Sobre Wind Vector Hub | Origen y Equipo</title>
        <link rel="canonical" href="https://www.windvectorhub.es/about" />
        <meta
          name="description"
          content="Conoce el origen de Wind Vector Hub, nuestra posición editorial y el equipo multidisciplinar que documenta la infraestructura eólica española."
        />
      </Helmet>
      <section className="bg-base pt-28 pb-16 sm:pt-32 sm:pb-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <span className="text-xs uppercase tracking-[0.3em] text-primary">
            Sobre Wind Vector Hub
          </span>
          <h1 className="mt-4 text-4xl font-semibold text-white font-display">
            Origen, posición editorial y equipo multidisciplinar
          </h1>
          <p className="mt-4 text-base text-light/70">
            Nacimos para conectar los datos dispersos de la infraestructura eólica española y ofrecer un relato técnico coherente, accesible para quienes toman decisiones cada día.
          </p>
        </div>
      </section>

      <section className="bg-accent/70 py-16 sm:py-20">
        <div className="mx-auto max-w-5xl space-y-8 px-4 sm:px-6 lg:px-8">
          <article className="rounded-3xl border border-white/5 bg-base/60 p-8">
            <h2 className="text-2xl font-semibold text-white font-display">Origen del proyecto</h2>
            <p className="mt-4 text-sm text-light/70">
              Wind Vector Hub surge en 2021, cuando profesionales de planificación, operación y documentación técnica decidimos unificar recursos dispersos acerca de parques eólicos españoles. Observamos que la información crítica se encontraba repartida entre boletines oficiales, expedientes de acceso a red y reportes ambientales, sin un repositorio que conectara todo el ciclo de vida de un parque. Empezamos digitalizando mapas, recopilando las curvas de potencia de cada tecnología instalada y generando resúmenes comparables región por región.
            </p>
            <p className="mt-4 text-sm text-light/70">
              La motivación principal es facilitar a los agentes del sector un punto de partida confiable, con metodologías transparentes y trazabilidad completa. Trabajamos con un calendario de actualizaciones mensuales y revisamos cada ficha cuando se emite una nueva autorización, se modifica un acceso o se repotencia una turbina.
            </p>
          </article>

          <article className="rounded-3xl border border-white/5 bg-base/60 p-8">
            <h2 className="text-2xl font-semibold text-white font-display">Posición editorial</h2>
            <p className="mt-4 text-sm text-light/70">
              Mantener la neutralidad técnica es prioritario. Utilizamos un lenguaje descriptivo, documentamos números verificables y citamos siempre la fuente primaria. No realizamos valoraciones comerciales ni priorizamos proyectos por su promotor. Cada análisis refleja el estado observable a partir de la documentación pública y los datos obtenidos en campo.
            </p>
          </article>

          <article className="rounded-3xl border border-white/5 bg-base/60 p-8">
            <h2 className="text-2xl font-semibold text-white font-display">Modelo de fuentes</h2>
            <p className="mt-4 text-sm text-light/70">
              Las fuentes principales incluyen expedientes de Red Eléctrica de España, resoluciones autonómicas, bases de datos del Instituto Geográfico Nacional, boletines del MITERD y mediciones propias adquiridas durante visitas de campo. Cada ficha incorpora metadatos de procedencia, fecha de actualización, coordenadas transformadas a ETRS89 y documentación probatoria cuando aplica.
            </p>
          </article>

          <article className="rounded-3xl border border-white/5 bg-base/60 p-8">
            <h2 className="text-2xl font-semibold text-white font-display">Política de neutralidad</h2>
            <p className="mt-4 text-sm text-light/70">
              No aceptamos contenido patrocinado ni integramos mensajes promocionales. Cuando una entidad comparte datos adicionales, los sometemos al mismo proceso de verificación y, en caso de publicarlos, señalamos su procedencia. Las decisiones editoriales se toman colectivamente, priorizando la transparencia y la reproducibilidad de los datos.
            </p>
          </article>
        </div>
      </section>

      <section className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-semibold text-white font-display text-center">
            Equipo multidisciplinar
          </h2>
          <p className="mt-3 text-center text-base text-light/70">
            Cada miembro coordina un eje temático y comparte metodologías para mantener la coherencia en los entregables.
          </p>
          <div className="mt-10 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {teamMembers.map((member) => (
              <div
                key={member.name}
                className="rounded-3xl border border-white/5 bg-accent/60 p-6 text-center transition hover:border-primary/40"
              >
                <img
                  src={member.image}
                  alt={`Retrato profesional de ${member.name}`}
                  className="mx-auto h-28 w-28 rounded-full object-cover"
                  loading="lazy"
                />
                <h3 className="mt-4 text-lg font-semibold text-white">{member.name}</h3>
                <p className="text-sm text-primary">{member.role}</p>
                <p className="mt-3 text-sm text-light/70">{member.bio}</p>
                <p className="mt-3 text-xs text-light/50">{member.focus}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;