import React from "react";
import { Helmet } from "react-helmet";

const CookiePolicy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Política de cookies | Wind Vector Hub</title>
        <link rel="canonical" href="https://www.windvectorhub.es/cookie-policy" />
      </Helmet>
      <section className="bg-base py-16 sm:py-20">
        <div className="mx-auto max-w-4xl space-y-8 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-semibold text-white font-display">
            Política de cookies
          </h1>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">Uso de cookies</h2>
            <p className="mt-2">
              Utilizamos cookies técnicas para garantizar el funcionamiento del sitio y cookies analíticas para medir el uso de la plataforma. No se emplean cookies con fines publicitarios ni se comparten datos con terceros.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">Configuración</h2>
            <p className="mt-2">
              Puedes aceptar o rechazar las cookies analíticas desde el banner de consentimiento. Las cookies técnicas son imprescindibles para mostrar el sitio y no almacenan información personal identificable.
            </p>
          </article>
          <article className="rounded-3xl border border-white/10 bg-accent/70 p-6 text-sm text-light/75">
            <h2 className="text-lg font-semibold text-white">Gestión en el navegador</h2>
            <p className="mt-2">
              La mayoría de navegadores permite eliminar o bloquear cookies. Consulta la documentación del navegador para conocer las instrucciones específicas y personalizar tu configuración.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;