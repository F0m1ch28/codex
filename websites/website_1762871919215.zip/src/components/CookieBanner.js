import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [preferences, setPreferences] = useState({
    essential: true,
    analytics: false,
    marketing: false,
  });

  useEffect(() => {
    const stored = localStorage.getItem('zyfrentica-cookie-consent');
    if (stored) {
      setPreferences(JSON.parse(stored));
      setVisible(false);
    } else {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleToggle = (key) => {
    if (key === 'essential') return;
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const savePreferences = (updated) => {
    localStorage.setItem('zyfrentica-cookie-consent', JSON.stringify(updated));
  };

  const handleAcceptAll = () => {
    const updated = { essential: true, analytics: true, marketing: true };
    setPreferences(updated);
    savePreferences(updated);
    setVisible(false);
  };

  const handleSave = () => {
    savePreferences(preferences);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie-Einstellungen">
      <div className={styles.content}>
        <h2>Cookies bei Zyfrentica</h2>
        <p>
          Wir verwenden Cookies, um grundlegende Funktionen zu ermöglichen und anonymisierte Analysen für bessere
          Kampagnenerlebnisse durchzuführen. Sie können Ihre Auswahl jederzeit anpassen.
        </p>
        <button
          type="button"
          className={styles.toggleDetails}
          onClick={() => setExpanded((prev) => !prev)}
          aria-expanded={expanded}
          aria-controls="cookie-details"
        >
          {expanded ? 'Weniger Details' : 'Details anzeigen'}
        </button>
        {expanded && (
          <div className={styles.details} id="cookie-details">
            <label className={styles.preference}>
              <span>
                <strong>Essentiell</strong>
                <small>Erforderlich für sichere Anmeldung und Grundfunktionen.</small>
              </span>
              <input type="checkbox" checked readOnly aria-readonly />
            </label>
            <label className={styles.preference}>
              <span>
                <strong>Analytics</strong>
                <small>Hilft uns dabei, Customer Journeys zu optimieren.</small>
              </span>
              <input
                type="checkbox"
                checked={preferences.analytics}
                onChange={() => handleToggle('analytics')}
                aria-label="Analytics-Cookies aktivieren"
              />
            </label>
            <label className={styles.preference}>
              <span>
                <strong>Marketing</strong>
                <small>Koordiniert die Ausspielung relevanter Kampagneninhalte.</small>
              </span>
              <input
                type="checkbox"
                checked={preferences.marketing}
                onChange={() => handleToggle('marketing')}
                aria-label="Marketing-Cookies aktivieren"
              />
            </label>
          </div>
        )}
      </div>
      <div className={styles.actions}>
        <button type="button" className={`btn btnSecondary ${styles.btnSecondary}`} onClick={handleSave}>
          Auswahl speichern
        </button>
        <button type="button" className={`btn btnPrimary ${styles.btnPrimary}`} onClick={handleAcceptAll}>
          Alle akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;