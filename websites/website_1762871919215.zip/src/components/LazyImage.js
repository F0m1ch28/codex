import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styles from './LazyImage.module.css';

const LazyImage = ({ src, alt, className = '', imgClassName = '', ...props }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`${styles.wrapper} ${className}`}>
      {!loaded && <div className={styles.skeleton} aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        className={`${styles.image} ${loaded ? styles.visible : ''} ${imgClassName}`}
        loading="lazy"
        {...props}
      />
    </div>
  );
};

LazyImage.propTypes = {
  src: PropTypes.string.isRequired,
  alt: PropTypes.string.isRequired,
  className: PropTypes.string,
  imgClassName: PropTypes.string,
};

export default LazyImage;