import React, { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen]);

  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <a className={styles.skipLink} href="#main-content">
        Zum Inhalt springen
      </a>
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} aria-label="Zyfrentica Startseite">
            <span className={styles.logoMark}>Z</span>
            Zyfrentica
          </Link>
          <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Hauptnavigation">
            <ul className={styles.navList}>
              <li>
                <NavLink
                  to="/funktionen"
                  className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
                  onClick={handleLinkClick}
                >
                  Funktionen
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/use-cases"
                  className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
                  onClick={handleLinkClick}
                >
                  Use Cases
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/ueber-uns"
                  className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
                  onClick={handleLinkClick}
                >
                  Über uns
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/kontakt"
                  className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
                  onClick={handleLinkClick}
                >
                  Kontakt
                </NavLink>
              </li>
            </ul>
            <div className={styles.navCta}>
              <Link to="/kontakt" className={`btn btnPrimary ${styles.demoBtn}`} onClick={handleLinkClick}>
                Demo anfordern
              </Link>
            </div>
          </nav>
          <button
            type="button"
            className={`${styles.menuToggle} ${menuOpen ? styles.menuToggleActive : ''}`}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-controls="Hauptnavigation"
            aria-label={menuOpen ? 'Menü schließen' : 'Menü öffnen'}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;