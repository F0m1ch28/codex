import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <Link to="/" className={styles.brandLink} aria-label="Zyfrentica Startseite">
              <span className={styles.logoMark}>Z</span>
              <span className={styles.logoText}>Zyfrentica</span>
            </Link>
            <p>
              Präzise Marketing-Automatisierung aus Berlin. Wir vernetzen Performance-Teams, orchestrieren Customer
              Journeys und schaffen klare Ergebnisse entlang der gesamten Leadgenerierung.
            </p>
            <div className={styles.badges}>
              <span className={styles.badge}>Made in Berlin</span>
              <span className={styles.badge}>ISO 27001 ready</span>
            </div>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Navigation</h3>
            <ul className={styles.links}>
              <li>
                <Link to="/funktionen">Funktionen</Link>
              </li>
              <li>
                <Link to="/use-cases">Use Cases</Link>
              </li>
              <li>
                <Link to="/ueber-uns">Über uns</Link>
              </li>
              <li>
                <Link to="/kontakt">Kontakt</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Richtlinien</h3>
            <ul className={styles.links}>
              <li>
                <Link to="/impressum">Impressum</Link>
              </li>
              <li>
                <Link to="/datenschutz">Datenschutz</Link>
              </li>
              <li>
                <Link to="/agb">AGB</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Kontakt</h3>
            <address className={styles.address}>
              <span>Potsdamer Platz 10</span>
              <span>10785 Berlin, Deutschland</span>
              <a href="tel:+493012345678">+49 30 1234 5678</a>
              <a href="mailto:kontakt@zyfrentica.de">kontakt@zyfrentica.de</a>
            </address>
            <div className={styles.socials} aria-label="Soziale Profile">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                in
              </a>
              <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
                x
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
                ▶
              </a>
            </div>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {year} Zyfrentica. Alle Rechte vorbehalten.</p>
          <div className={styles.bottomLinks}>
            <Link to="/datenschutz">Datenschutz</Link>
            <Link to="/agb">AGB</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;