import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Zyfrentica | Datenschutz</title>
        <meta
          name="description"
          content="Datenschutzinformationen von Zyfrentica. Erfahren Sie, wie wir personenbezogene Daten verarbeiten, schützen und welche Rechte Sie haben."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/datenschutz" />
      </Helmet>

      <section className={styles.page}>
        <div className="container">
          <h1>Datenschutz</h1>
          <p>Stand: 01. Mai 2024</p>

          <h2>1. Verantwortlicher</h2>
          <p>
            Zyfrentica GmbH
            <br />
            Potsdamer Platz 10, 10785 Berlin, Deutschland
            <br />
            Telefon: +49 30 1234 5678
            <br />
            E-Mail: kontakt@zyfrentica.de
          </p>

          <h2>2. Zweck der Datenverarbeitung</h2>
          <p>
            Wir verarbeiten personenbezogene Daten zur Bereitstellung der Plattform, zur Kommunikation, zur
            Vertragsdurchführung sowie zur Optimierung unserer Marketing Automatisierung und CRM Integration Services.
          </p>

          <h2>3. Rechtsgrundlagen</h2>
          <ul>
            <li>Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung)</li>
            <li>Art. 6 Abs. 1 lit. f DSGVO (berechtigtes Interesse an sicherem Betrieb)</li>
            <li>Art. 6 Abs. 1 lit. a DSGVO (Einwilligung für Newsletter & Double-Opt-In)</li>
          </ul>

          <h2>4. Kategorien von Daten</h2>
          <p>Wir verarbeiten insbesondere:</p>
          <ul>
            <li>Kontakt- und Stammdaten (Name, E-Mail, Telefonnummer, Unternehmen)</li>
            <li>Account- und Nutzungsdaten innerhalb der Zyfrentica Plattform</li>
            <li>Kommunikationsinhalte aus Support und Demo-Anfragen</li>
            <li>Log- und Sicherheitsdaten (z. B. IP-Adresse, Zeitstempel)</li>
          </ul>

          <h2>5. Empfänger</h2>
          <p>
            Innerhalb Zyfrentica erhalten nur Stellen Zugriff, die diese zur Aufgabenerfüllung benötigen. Externe
            Dienstleister (z. B. Hosting, Analytics, Support) werden sorgfältig ausgewählt, vertraglich gebunden und
            sitzen überwiegend in der EU.
          </p>

          <h2>6. Drittlandübermittlung</h2>
          <p>
            Wird ein Transfer in ein Drittland erforderlich, erfolgt dies ausschließlich auf Basis geeigneter Garantien
            gemäß Art. 44 ff. DSGVO (z. B. EU-Standardvertragsklauseln).
          </p>

          <h2>7. Speicherdauer</h2>
          <p>
            Wir speichern personenbezogene Daten nur so lange, wie es für den jeweiligen Zweck erforderlich ist.
            Vertragsbezogene Daten werden entsprechend gesetzlicher Aufbewahrungsfristen archiviert.
          </p>

          <h2>8. Rechte der Betroffenen</h2>
          <p>
            Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit
            sowie Widerspruch. Wenden Sie sich hierfür an kontakt@zyfrentica.de.
          </p>

          <h2>9. Newsletter & Double-Opt-In</h2>
          <p>
            Für den Newsletter-Versand nutzen wir das Double-Opt-In-Verfahren. Sie erhalten nach Anmeldung eine
            Bestätigungs-E-Mail. Erst nach Bestätigung wird der Versand aktiviert. Sie können die Einwilligung jederzeit
            widerrufen.
          </p>

          <h2>10. Cookie-Einsatz</h2>
          <p>
            Zyfrentica verwendet Cookies für essentielle Funktionen sowie optional für Analytics und Marketing. Details
            und Wahlmöglichkeiten finden Sie im Cookie-Banner.
          </p>

          <h2>11. Datensicherheit</h2>
          <p>
            Wir nutzen technische und organisatorische Maßnahmen wie verschlüsselte Verbindungen, Zugriffskontrollen,
            Rollen-Management, Penetrationstests und Backups, um personenbezogene Daten zu schützen.
          </p>

          <h2>12. Kontakt Datenschutzteam</h2>
          <p>
            Datenschutzbeauftragte:r (extern)
            <br />
            E-Mail: privacy@zyfrentica.de
          </p>

          <h2>13. Beschwerderecht</h2>
          <p>
            Sie haben das Recht, sich bei einer Datenschutzaufsichtsbehörde zu beschweren. Zuständig ist z. B. die
            Berliner Beauftragte für Datenschutz und Informationsfreiheit.
          </p>
        </div>
      </section>
    </>
  );
};

export default Privacy;