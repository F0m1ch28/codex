import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Zyfrentica | Allgemeine Geschäftsbedingungen</title>
        <meta
          name="description"
          content="Allgemeine Geschäftsbedingungen der Zyfrentica GmbH. Regelungen zu Leistungen, Lizenzen, Haftung und Pflichten."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/agb" />
      </Helmet>

      <section className={styles.page}>
        <div className="container">
          <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
          <p>Stand: 01. Mai 2024</p>

          <h2>1. Geltungsbereich</h2>
          <p>
            Diese AGB gelten für alle Verträge zwischen Zyfrentica GmbH, Potsdamer Platz 10, 10785 Berlin (nachfolgend
            “Zyfrentica”) und Kund:innen bezüglich der SaaS-Plattform für Marketing Automatisierung.
          </p>

          <h2>2. Leistungen</h2>
          <p>
            Zyfrentica stellt Kund:innen die Plattform inklusive Workflows, E-Mail Automation, Segmentierung, Formulare,
            Analytics und Integrationen über das Internet zur Verfügung. Der konkrete Leistungsumfang ergibt sich aus dem
            jeweiligen Angebot oder der Leistungsbeschreibung.
          </p>

          <h2>3. Nutzungsrechte</h2>
          <p>
            Zyfrentica gewährt Kund:innen das einfache, nicht übertragbare Recht, die Plattform während der Vertragslaufzeit
            zu nutzen. Eine Weitergabe an Dritte ist nur mit schriftlicher Zustimmung erlaubt.
          </p>

          <h2>4. Pflichten der Kund:innen</h2>
          <ul>
            <li>Sicherstellung richtiger und vollständiger Angaben bei Registrierung und Nutzung.</li>
            <li>Vertrauliche Behandlung von Zugangsdaten.</li>
            <li>Einhaltung geltender Datenschutz- und Marketing-Vorschriften.</li>
            <li>
              Keine Übermittlung rechtswidriger Inhalte. Kund:innen haften für Inhalte, die sie in Zyfrentica verarbeiten.
            </li>
          </ul>

          <h2>5. Verfügbarkeit</h2>
          <p>
            Zyfrentica strebt eine hohe Verfügbarkeit an. Wartungen, Updates und Ereignisse außerhalb unseres Einflussbereichs
            können die Erreichbarkeit vorübergehend einschränken.
          </p>

          <h2>6. Support</h2>
          <p>
            Supportleistungen werden gemäß den im Angebot vereinbarten Service Levels erbracht. Supportanfragen können
            per E-Mail an kontakt@zyfrentica.de gestellt werden.
          </p>

          <h2>7. Haftung</h2>
          <p>
            Zyfrentica haftet für Vorsatz und grobe Fahrlässigkeit. Bei leichter Fahrlässigkeit haftet Zyfrentica nur bei
            Verletzung wesentlicher Vertragspflichten (Kardinalpflichten). Die Haftung ist in diesem Fall auf
            vorhersehbare, vertragstypische Schäden begrenzt.
          </p>

          <h2>8. Datenschutz</h2>
          <p>
            Die Verarbeitung personenbezogener Daten erfolgt gemäß der Datenschutz­erklärung. Kund:innen sind für die
            Rechtmäßigkeit eigener Datenverarbeitung verantwortlich.
          </p>

          <h2>9. Laufzeit und Kündigung</h2>
          <p>
            Laufzeit und Kündigungsfristen ergeben sich aus dem jeweiligen Angebot. Das Recht zur außerordentlichen
            Kündigung bleibt unberührt.
          </p>

          <h2>10. Änderungen der AGB</h2>
          <p>
            Zyfrentica kann diese AGB anpassen. Kund:innen werden rechtzeitig informiert. Widersprechen sie nicht binnen
            vier Wochen, gelten die Änderungen als akzeptiert.
          </p>

          <h2>11. Schlussbestimmungen</h2>
          <p>
            Es gilt deutsches Recht. Gerichtsstand ist, soweit zulässig, Berlin. Sollten einzelne Bestimmungen unwirksam
            sein, bleibt der Vertrag im Übrigen wirksam.
          </p>
        </div>
      </section>
    </>
  );
};

export default Terms;