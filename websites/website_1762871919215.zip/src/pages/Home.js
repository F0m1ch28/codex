import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import LazyImage from '../components/LazyImage';

const statsData = [
  {
    label: 'Schnellere Kampagnenabstimmung',
    target: 72,
    suffix: '%',
    description: 'durch automatisierte Freigaben und Templates',
  },
  {
    label: 'Mehr aktive Leads',
    target: 38,
    suffix: '%',
    description: 'dank präziser Leadgenerierung und Segmentierung',
  },
  {
    label: 'Integrationen',
    target: 120,
    suffix: '+',
    description: 'vernetzte CRM- & Vertriebssysteme',
  },
  {
    label: 'Zufriedenheitswert',
    target: 48,
    suffix: '/5',
    divider: 10,
    description: 'Bewertung bestehender Kund:innen',
  },
];

const testimonials = [
  {
    quote:
      'Mit Zyfrentica haben wir unsere Customer Journey vollständig orchestriert. Die Workflows liefern endlich messbare Ergebnisse, ohne dass unser Team Überstunden schiebt.',
    name: 'Anna Keller',
    role: 'Head of Growth',
    company: 'BrightCommerce GmbH',
    image: 'https://picsum.photos/400/400?random=93',
  },
  {
    quote:
      'Die Segmentierung ist hochpräzise und unsere E-Mail Automation übertrifft die Benchmarks deutlich. Besonders schätzen wir die DSGVO-Transparenz.',
    name: 'Dennis Vogt',
    role: 'VP Marketing',
    company: 'SaaSly Europe',
    image: 'https://picsum.photos/400/400?random=94',
  },
  {
    quote:
      'Wir haben Zyfrentica an Salesforce und unser Data Warehouse angebunden. Die Insights aus den Analytics-Dashboards sind für unser B2B Team unverzichtbar geworden.',
    name: 'Lea Portmann',
    role: 'Marketing Operations Lead',
    company: 'Nordlicht Solutions',
    image: 'https://picsum.photos/400/400?random=95',
  },
];

const integrationLogos = ['HubSpot', 'Salesforce', 'Microsoft Dynamics 365', 'Pipedrive', 'Zendesk', 'Slack'];

const processSteps = [
  {
    title: 'Connect',
    description: 'Verbinden Sie CRM, Shops, Ads und Event-Daten über sichere Connectoren.',
  },
  {
    title: 'Model',
    description: 'Segmentieren Sie Kontakte anhand von Verhalten, Scoring und Customer Journey Meilensteinen.',
  },
  {
    title: 'Automate',
    description: 'Bauen Sie Workflows mit Drag & Drop Workflow Builder und E-Mail Automation.',
  },
  {
    title: 'Measure',
    description: 'Steuern Sie Kampagnen über Analytics, Attribution und KPI-Alerts in Echtzeit.',
  },
];

const projectsData = [
  {
    title: 'Unified Journey für E-Commerce Launch',
    category: 'E-Commerce',
    description:
      'Einbindung von Shopify, personalisierte Trigger-Mails und Predictive Analytics für Cross-Sell-Kampagnen.',
    image: 'https://picsum.photos/1200/800?random=96',
  },
  {
    title: 'Lifecycle Automation für SaaS Trial Nutzer:innen',
    category: 'SaaS',
    description:
      'Trial-zu-Plan Journey mit Feature Adoption Scoring, In-App Messaging und synchronisiertem CRM-Update.',
    image: 'https://picsum.photos/1200/800?random=97',
  },
  {
    title: 'Globaler B2B Lead Hub',
    category: 'B2B',
    description:
      'Account-basierte Nurturing-Strecken, automatische Routing-Regeln und Vertriebsalarme in Echtzeit.',
    image: 'https://picsum.photos/1200/800?random=98',
  },
  {
    title: 'Retail Loyalty Orchestration',
    category: 'E-Commerce',
    description:
      'Omnichannel Journeys mit POS-Integration, SMS-Opt-In und regionalisierten Kampagnenkalendern.',
    image: 'https://picsum.photos/1200/800?random=99',
  },
];

const faqItems = [
  {
    question: 'Wie unterstützt Zyfrentica bei der DSGVO-Konformität?',
    answer:
      'Alle Datenflüsse werden mit Audit Trails dokumentiert. Einwilligungen und Double-Opt-In lassen sich granular verwalten und werden revisionssicher archiviert.',
  },
  {
    question: 'Welche CRM-Systeme können angebunden werden?',
    answer:
      'Zyfrentica bietet native CRM Integration zu Salesforce, HubSpot, Microsoft Dynamics 365, Pipedrive, SAP C4C sowie REST- und GraphQL-APIs.',
  },
  {
    question: 'Wie funktioniert der Workflow Builder?',
    answer:
      'Sie kombinieren Aktionen, Bedingungen und Trigger via Drag & Drop. Versionierung, Sandbox-Testläufe und Rollback helfen bei komplexen Kampagnen.',
  },
  {
    question: 'Unterstützt Zyfrentica mehrsprachige Kampagnen?',
    answer:
      'Ja, Inhalte, Formulare und Journeys lassen sich für beliebig viele Sprachen klonen und lokalisieren. Übersetzungs-Workflows sind integriert.',
  },
];

const blogPosts = [
  {
    title: 'Customer Journey Mapping für hybride Teams',
    excerpt:
      'Wie Berliner Growth-Teams Journey Maps mit Echtzeit-Daten verknüpfen und dadurch Leadqualifizierung beschleunigen.',
    date: 'April 2024',
    image: 'https://picsum.photos/800/600?random=101',
  },
  {
    title: 'Leadscoring mit verknüpften CRM Integration',
    excerpt:
      'Structuriertes Leadscoring mit Behavioral Events, Sales Feedback und Predictive Analytics im Workflow Builder.',
    date: 'März 2024',
    image: 'https://picsum.photos/800/600?random=102',
  },
  {
    title: 'Analytics, die Kampagnen priorisieren',
    excerpt:
      'Welche KPI-Widgets Marketing-Leitungen nutzen, um Kampagnenkosten pro Touchpoint transparent zu machen.',
    date: 'Februar 2024',
    image: 'https://picsum.photos/800/600?random=103',
  },
];

const teamPreview = [
  {
    name: 'Lina Schneider',
    role: 'Director Product',
    focus: 'Leitet das Workflow Builder Team und schafft neue Automatisierungsstandards.',
    image: 'https://picsum.photos/400/400?random=104',
  },
  {
    name: 'Mats Reuter',
    role: 'Head of Data Science',
    focus: 'Verantwortlich für Predictive Analytics, Lead-Scoring und Attribution.',
    image: 'https://picsum.photos/400/400?random=105',
  },
  {
    name: 'Sira Feldmann',
    role: 'Lead Customer Success',
    focus: 'Begleitet Enterprise-Kund:innen bei globalen Rollouts und Audits.',
    image: 'https://picsum.photos/400/400?random=106',
  },
];

const benefits = [
  {
    title: 'Mehr Fokus auf Strategie',
    description: 'Automatisieren Sie Routineaufgaben und investieren Sie Zeit in kreative Kampagnen.',
    icon: '🎯',
  },
  {
    title: 'Datenbasierte Entscheidungen',
    description: 'Analytics-Dashboards zeigen KPIs in Echtzeit – von der Leadgenerierung bis zur Conversion.',
    icon: '📊',
  },
  {
    title: 'Nahtlose Zusammenarbeit',
    description: 'Marketing, Vertrieb und Success arbeiten auf einem gemeinsamen Customer Journey Canvas.',
    icon: '🤝',
  },
  {
    title: 'Skalierbare Governance',
    description: 'Rollen, Berechtigungen und Freigaben sichern globale Kampagnen-Standards ab.',
    icon: '🛡️',
  },
];

const featureHighlights = [
  {
    title: 'Intuitive Workflows',
    description: 'Drag & Drop Workflow Builder mit wiederverwendbaren Templates und Testing-Sandboxes.',
  },
  {
    title: 'E-Mail Automation',
    description: 'AI-unterstützte Betreffzeilen, dynamische Inhalte und kanalübergreifende Sequenzen.',
  },
  {
    title: 'Segmentierung',
    description: 'Echtzeit-Segmentierung mit Verhaltensdaten, Scores und CRM-Attributen.',
  },
  {
    title: 'Formulare & Landing Pages',
    description: 'Responsive Formulare, progressive Profiling und DSGVO-konforme Einwilligungen.',
  },
  {
    title: 'Analytics & Attribution',
    description: 'Interaktive Dashboards, Funnel-Ansichten und automatisierte KPI-Alerts.',
  },
  {
    title: 'Integrationen',
    description: 'Zertifizierte CRM Integration, Data Warehouse Connectoren und Webhooks.',
  },
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const statsRef = useRef(null);
  const [activeFilter, setActiveFilter] = useState('Alle');
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState(null);
  const [faqOpen, setFaqOpen] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !statsAnimated) {
          setStatsAnimated(true);
        }
      },
      { threshold: 0.4 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => {
      if (statsRef.current) {
        observer.unobserve(statsRef.current);
      }
    };
  }, [statsAnimated]);

  useEffect(() => {
    if (!statsAnimated) return;
    const duration = 1600;
    const start = performance.now();

    const animate = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      const updated = statsData.map((item) => Math.floor(item.target * progress));
      setCounters(updated);
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [statsAnimated]);

  const filteredProjects =
    activeFilter === 'Alle'
      ? projectsData
      : projectsData.filter((project) => project.category === activeFilter);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail || !/\S+@\S+\.\S+/.test(newsletterEmail)) {
      setNewsletterStatus({
        type: 'error',
        message: 'Bitte gib eine gültige E-Mail-Adresse ein.',
      });
      return;
    }
    setNewsletterStatus({
      type: 'success',
      message:
        'Vielen Dank! Bitte bestätige deine Adresse über den Link in der zugesandten Double-Opt-In E-Mail.',
    });
    setNewsletterEmail('');
  };

  const toggleFaq = (index) => {
    setFaqOpen((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>Zyfrentica | Marketing-Automatisierung neu gedacht</title>
        <meta
          name="description"
          content="Marketing Automatisierung mit Workflow Builder, E-Mail Automation, CRM Integration und Analytics. Zyfrentica aus Berlin orchestriert Ihre Customer Journeys."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <span className="badge">Berlin SaaS</span>
              <h1>Marketing-Automatisierung neu gedacht</h1>
              <p>
                Zyfrentica verbindet Marketing, Vertrieb und Customer Success auf einer Plattform. Orchestrieren Sie
                Customer Journeys, automatisieren Sie Leadgenerierung und steuern Sie Kampagnen mit Echtzeit-Analytics.
              </p>
              <div className={styles.heroActions}>
                <Link className="btn btnPrimary" to="/kontakt">
                  Demo anfordern
                </Link>
                <Link className="btn btnSecondary" to="/funktionen">
                  Funktionen entdecken
                </Link>
              </div>
              <ul className={styles.heroHighlights}>
                <li>
                  <span aria-hidden="true">⚡</span>
                  <span>
                    Marketing Automatisierung für wachsende Teams – vom ersten Workflow bis zur globalen Kampagne.
                  </span>
                </li>
                <li>
                  <span aria-hidden="true">🧭</span>
                  <span>Customer Journey Canvas inklusive Attribution und KPI-Alerts.</span>
                </li>
                <li>
                  <span aria-hidden="true">🔐</span>
                  <span>DSGVO-ready mit Hosting in Deutschland und auditierbaren Freigaben.</span>
                </li>
              </ul>
            </div>
            <div className={styles.heroVisual}>
              <LazyImage
                src="https://picsum.photos/1600/900?random=91"
                alt="Dashboard einer Marketing-Automatisierungsplattform"
                className={styles.heroImageWrapper}
                imgClassName={styles.heroImage}
              />
              <div className={styles.heroWidget}>
                <div>
                  <p>Workflow Builder</p>
                  <strong>Drag & Drop</strong>
                </div>
                <div>
                  <p>Live KPI</p>
                  <strong>46% Open Rate</strong>
                </div>
                <div>
                  <p>Aktive Journeys</p>
                  <strong>38</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Nutzen für Ihr Team</h2>
            <p className="sectionSubtitle">
              Wir bringen Strategie und Ausführung zusammen: Von der Planung über die Automatisierung bis zur Analyse
              jeder Customer Journey.
            </p>
          </div>
          <div className={styles.benefitsGrid}>
            {benefits.map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <div className={styles.benefitIcon} aria-hidden="true">
                  {benefit.icon}
                </div>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => {
              const value = stat.divider
                ? (counters[index] / stat.divider).toFixed(1)
                : counters[index];
              return (
                <article key={stat.label} className={styles.statCard}>
                  <div className={styles.statValue} aria-live="polite">
                    {value}
                    {stat.suffix}
                  </div>
                  <h3>{stat.label}</h3>
                  <p>{stat.description}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.features}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Funktionen, die Wachstum skalieren</h2>
            <p className="sectionSubtitle">
              Alles, was Sie für moderne Kampagnen brauchen: Workflow Builder, E-Mail Automation, Segmentierung,
              Formulare, Analytics und Integrationen in einer Oberfläche.
            </p>
          </div>
          <div className={styles.featureGrid}>
            {featureHighlights.map((feature) => (
              <article key={feature.title} className={styles.featureCard}>
                <span aria-hidden="true" className={styles.featureDot} />
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
                <Link to="/funktionen" className={styles.featureLink}>
                  Mehr erfahren
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.useCases}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Use Cases auf einen Blick</h2>
            <p className="sectionSubtitle">
              Von E-Commerce über SaaS bis B2B: Zyfrentica orchestriert Customer Journeys entlang der gesamten
              Kaufentscheidung.
            </p>
          </div>
          <div className={styles.useCaseTiles}>
            <article>
              <h3>E-Commerce</h3>
              <p>Personalisierte Kampagnen, Loyalty Automation, Warenkorb-Trigger und Omnichannel Journeys.</p>
              <Link to="/use-cases" className={styles.simpleLink}>
                Journey ansehen
              </Link>
            </article>
            <article>
              <h3>SaaS</h3>
              <p>Trial-Nurturing, Produktadoption, Renewal-Alerts und Health Scores pro Account.</p>
              <Link to="/use-cases" className={styles.simpleLink}>
                Journey ansehen
              </Link>
            </article>
            <article>
              <h3>B2B</h3>
              <p>Account-based Flows, Lead Routing, Vertriebs-SLAs und integriertes Reporting.</p>
              <Link to="/use-cases" className={styles.simpleLink}>
                Journey ansehen
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.integrations}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Integrationen, die verbinden</h2>
            <p className="sectionSubtitle">
              Verbinden Sie Zyfrentica mit Ihrem bestehenden Tech Stack – von CRM Integration bis Data Warehouse.
            </p>
          </div>
          <div className={styles.integrationGrid}>
            {integrationLogos.map((logo) => (
              <div key={logo} className={styles.integrationCard}>
                <span>{logo}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">So funktioniert die Zusammenarbeit</h2>
            <p className="sectionSubtitle">
              In vier Schritten zur skalierbaren Marketing-Automatisierung mit klarer Governance und messbarem Outcome.
            </p>
          </div>
          <div className={styles.processSteps}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processCard}>
                <span className={styles.processIndex}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Was Kund:innen sagen</h2>
            <p className="sectionSubtitle">
              Teams aus E-Commerce, SaaS und B2B steuern ihre Customer Journey mit Zyfrentica – skalierbar, messbar und
              DSGVO-konform.
            </p>
          </div>
          <div className={styles.testimonialWrapper}>
            <button
              type="button"
              className={styles.navButton}
              onClick={() =>
                setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
              }
              aria-label="Vorheriges Testimonial anzeigen"
            >
              ‹
            </button>
            <article className={styles.testimonialCard} aria-live="polite">
              <LazyImage
                src={testimonials[activeTestimonial].image}
                alt={`Porträt von ${testimonials[activeTestimonial].name}`}
                className={styles.testimonialImageWrapper}
                imgClassName={styles.testimonialImage}
              />
              <blockquote>“{testimonials[activeTestimonial].quote}”</blockquote>
              <p className={styles.testimonialMeta}>
                <strong>{testimonials[activeTestimonial].name}</strong> · {testimonials[activeTestimonial].role},{' '}
                {testimonials[activeTestimonial].company}
              </p>
            </article>
            <button
              type="button"
              className={styles.navButton}
              onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
              aria-label="Nächstes Testimonial anzeigen"
            >
              ›
            </button>
          </div>
          <div className={styles.carouselDots} role="tablist" aria-label="Testimonials auswählen">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Testimonial ${index + 1}`}
                aria-selected={index === activeTestimonial}
                role="tab"
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Team Einblicke</h2>
            <p className="sectionSubtitle">
              Hinter Zyfrentica steht ein interdisziplinäres Team mit Fokus auf Marketing Operations, Data Science und
              Sicherheit.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamPreview.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <LazyImage
                  src={member.image}
                  alt={`Teammitglied ${member.name}`}
                  className={styles.teamImageWrapper}
                  imgClassName={styles.teamImage}
                />
                <div className={styles.teamOverlay}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p>{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.teamCta}>
            <Link to="/ueber-uns" className="btn btnSecondary">
              Mehr über das Team erfahren
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Projektbeispiele</h2>
            <p className="sectionSubtitle">
              Wählen Sie eine Branche, um zu sehen, wie Zyfrentica Kampagnen orchestriert, Customer Journey Touchpoints
              verbindet und Analytics einbindet.
            </p>
          </div>
          <div className={styles.projectFilters} role="tablist" aria-label="Projekte nach Kategorie filtern">
            {['Alle', 'E-Commerce', 'SaaS', 'B2B'].map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`${styles.filterBtn} ${activeFilter === filter ? styles.filterBtnActive : ''}`}
                role="tab"
                aria-selected={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <LazyImage
                  src={project.image}
                  alt={`Projektvisualisierung: ${project.title}`}
                  className={styles.projectImageWrapper}
                  imgClassName={styles.projectImage}
                />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Häufige Fragen</h2>
            <p className="sectionSubtitle">
              Noch mehr Antworten rund um Marketing Automatisierung, CRM Integration, Analytics und Sicherheit.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <article key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  onClick={() => toggleFaq(index)}
                  className={styles.faqQuestion}
                  aria-expanded={faqOpen === index}
                >
                  <span>{item.question}</span>
                  <span aria-hidden="true">{faqOpen === index ? '−' : '+'}</span>
                </button>
                {faqOpen === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Aktuelle Insights</h2>
            <p className="sectionSubtitle">
              Praxisberichte aus Projekten, neue Features und Einblicke in datengetriebene Kampagnen.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <LazyImage
                  src={post.image}
                  alt={`Blogartikel: ${post.title}`}
                  className={styles.blogImageWrapper}
                  imgClassName={styles.blogImage}
                />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <span className={styles.blogLink}>Weiterlesen</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.finalContent}>
            <div>
              <span className="badge">Bereit für orchestrierte Kampagnen?</span>
              <h2>Jetzt Demo anfordern und Marketing Automation beschleunigen</h2>
              <p>
                Wir zeigen, wie Zyfrentica Ihren Workflow Builder, die E-Mail Automation, Segmentierung und Analytics in
                einer Customer Journey Plattform vereint.
              </p>
              <div className={styles.finalActions}>
                <Link to="/kontakt" className="btn btnPrimary">
                  Demo anfordern
                </Link>
                <Link to="/funktionen" className="btn btnSecondary">
                  Produkt-Tour
                </Link>
              </div>
            </div>
            <form className={styles.newsletter} onSubmit={handleNewsletterSubmit} noValidate>
              <label htmlFor="newsletter-email">
                Updates per Double-Opt-In erhalten (monatlich, fokussiert auf Marketing-Automatisierung).
              </label>
              <div className={styles.newsletterRow}>
                <input
                  id="newsletter-email"
                  type="email"
                  name="email"
                  placeholder="deine@adresse.de"
                  value={newsletterEmail}
                  onChange={(event) => setNewsletterEmail(event.target.value)}
                  required
                  aria-required="true"
                />
                <button type="submit" className="btn btnPrimary">
                  Anmelden
                </button>
              </div>
              {newsletterStatus && (
                <p
                  className={newsletterStatus.type === 'success' ? styles.successMessage : styles.errorMessage}
                  role="status"
                >
                  {newsletterStatus.message}
                </p>
              )}
              <small>
                Hinweis: Du erhältst eine Bestätigungs-E-Mail mit Double-Opt-In. Erst nach deiner Bestätigung senden wir
                weitere Insights.
              </small>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;