import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';
import LazyImage from '../components/LazyImage';

const leadership = [
  {
    name: 'Katrin Hoffmeister',
    role: 'Co-Founderin & CEO',
    bio: 'Verantwortet Strategie, Partnerschaften und skalierbare Organisation. Zuvor leitete sie Marketing Operations bei einem europäischen Tech-Unicorn.',
    image: 'https://picsum.photos/500/500?random=111',
  },
  {
    name: 'Dr. Jakob Voss',
    role: 'Co-Founder & CTO',
    bio: 'Führt Engineering, Plattformarchitektur und Sicherheit. Hat mehr als 15 Jahre Erfahrung in SaaS- und Infrastrukturprojekten.',
    image: 'https://picsum.photos/500/500?random=112',
  },
  {
    name: 'Nora Bell',
    role: 'Chief Customer Officer',
    bio: 'Verantwortlich für Customer Success, Enablement und Support. Bringt Teams von der Einführung bis zum Enterprise-Rollout.',
    image: 'https://picsum.photos/500/500?random=113',
  },
];

const milestones = [
  {
    year: '2019',
    title: 'Gründung in Berlin',
    text: 'Zyfrentica entsteht mit dem Ziel, Marketing Automatisierung für europäische Teams neu zu denken.',
  },
  {
    year: '2020',
    title: 'Workflow Builder Launch',
    text: 'Wir veröffentlichen unseren Drag & Drop Workflow Builder mit Echtzeitvorschau und QA-Sandboxes.',
  },
  {
    year: '2021',
    title: 'ISO-orientierte Sicherheitsprozesse',
    text: 'Einführung von Informationssicherheits-Standards und Aufbau eigener Audit-Programme.',
  },
  {
    year: '2023',
    title: 'Skalierung für Enterprise',
    text: 'Erweiterung des Plattformkerns um Multi-Brand-Verwaltung, granulare Governance und Data Residency.',
  },
];

const values = [
  {
    title: 'Transparente Zusammenarbeit',
    description: 'Wir bauen Produkte, die Teams vernetzen, Silos aufbrechen und Klarheit über Kampagnen schaffen.',
  },
  {
    title: 'Datenschutz als Prinzip',
    description:
      'DSGVO, ISO 27001-Anforderungen und Privacy by Design sind von Anfang an in unsere Plattform integriert.',
  },
  {
    title: 'Iterative Innovation',
    description:
      'Wir entwickeln Features eng mit Kund:innen und halten Feedback-Loops kurz – vom Workflow Builder bis Analytics.',
  },
  {
    title: 'Verlässliche Sicherheit',
    description:
      'Penetrationstests, Redundanz, Backups und strenge Zugriffskontrollen gehören zu unserem Standard.',
  },
];

const About = () => {
  return (
    <>
      <Helmet>
        <title>Zyfrentica | Über uns</title>
        <meta
          name="description"
          content="Erfahre mehr über Zyfrentica: unsere Mission, das Team in Berlin, Sicherheitsversprechen und wie wir Marketing Automatisierung gestalten."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/ueber-uns" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroWrapper}>
            <div className={styles.heroContent}>
              <span className="badge">Über Zyfrentica</span>
              <h1>Wir gestalten Marketing Operations neu</h1>
              <p>
                Zyfrentica ist eine in Berlin entwickelte SaaS-Plattform für Marketing Automatisierung. Unser Team
                verbindet Strategie, Technologie und Datenschutz, damit ambitionierte Unternehmen Customer Journeys in
                Echtzeit steuern können.
              </p>
            </div>
            <LazyImage
              src="https://picsum.photos/900/600?random=114"
              alt="Teamwork im Zyfrentica Office in Berlin"
              className={styles.heroImageWrapper}
              imgClassName={styles.heroImage}
            />
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2 className="sectionTitle">Unsere Mission</h2>
              <p>
                Wir helfen Marketing- und Growth-Teams, mit einem gemeinsamen Datenfundament zu arbeiten. Statt
                fragmentierter Tools bieten wir eine Plattform, die Workflows, E-Mail Automation, Segmentierung und
                Analytics zusammenführt.
              </p>
            </div>
            <div className={styles.missionPoints}>
              <article>
                <h3>Customer Journey als Zentrum</h3>
                <p>
                  Wir geben Teams einen visuellen Canvas, auf dem Marketing, Sales und Success Kampagnen gemeinsam
                  aufbauen – inklusive Analytics und Freigabeprozessen.
                </p>
              </article>
              <article>
                <h3>Verlässliche Daten</h3>
                <p>
                  Datenqualität, Governance und Sicherheit sind fest in Zyfrentica verankert. Mit granularen Rechten und
                  Audit Logs bleibt jede Aktion nachvollziehbar.
                </p>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Unsere Werte</h2>
            <p className="sectionSubtitle">
              Von unseren Produkt-Entscheidungen bis zum täglichen Umgang miteinander: Diese Prinzipien leiten uns.
            </p>
          </div>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.leadership}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Leadership</h2>
            <p className="sectionSubtitle">
              Das Führungsteam vereint Erfahrung aus Marketing Operations, SaaS-Produktentwicklung und
              Informationssicherheit.
            </p>
          </div>
          <div className={styles.leadershipGrid}>
            {leadership.map((leader) => (
              <article key={leader.name} className={styles.leaderCard}>
                <LazyImage
                  src={leader.image}
                  alt={`Portrait von ${leader.name}`}
                  className={styles.leaderImageWrapper}
                  imgClassName={styles.leaderImage}
                />
                <div className={styles.leaderContent}>
                  <h3>{leader.name}</h3>
                  <p className={styles.leaderRole}>{leader.role}</p>
                  <p>{leader.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Meilensteine</h2>
            <p className="sectionSubtitle">
              Ein Auszug aus unserer Entwicklung – von den ersten Workflows bis zur Enterprise-Orchestrierung.
            </p>
          </div>
          <div className={styles.timelineList}>
            {milestones.map((milestone) => (
              <article key={milestone.year}>
                <span className={styles.timelineYear}>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.security}>
        <div className="container">
          <div className={styles.securityGrid}>
            <div>
              <h2 className="sectionTitle">Sicherheit & Compliance</h2>
              <p>
                Sicherheit ist Teil unseres Produktkerns. Wir erfüllen Anforderungen europäischer Datenschutzgesetze,
                setzen auf dedizierte Infrastruktur in Deutschland und führen regelmäßige Penetrationstests durch.
              </p>
              <ul className={styles.securityList}>
                <li>Hosting in zertifizierten deutschen Rechenzentren</li>
                <li>Verschlüsselung im Transit (TLS 1.2+) und at REST (AES-256)</li>
                <li>Role-Based Access Control mit fein granularen Freigaben</li>
                <li>Regelmäßige Penetrationstests und Bug-Bounty-Programm</li>
              </ul>
            </div>
            <LazyImage
              src="https://picsum.photos/900/600?random=115"
              alt="Sicherheitsteam analysiert Datenflüsse"
              className={styles.securityImageWrapper}
              imgClassName={styles.securityImage}
            />
          </div>
        </div>
      </section>

      <section className={styles.joinUs}>
        <div className="container">
          <div className={styles.joinContent}>
            <div>
              <span className="badge">Talente willkommen</span>
              <h2>Wir wachsen – in Produkt, Data und Customer Experience</h2>
              <p>
                Du willst an Marketing Automatisierung der nächsten Generation mitarbeiten? Unser Team freut sich über
                Expert:innen aus Engineering, Data Science, Customer Success und Marketing Operations.
              </p>
            </div>
            <a
              className="btn btnPrimary"
              href="mailto:career@zyfrentica.de?subject=Initiativbewerbung%20Zyfrentica"
            >
              Initiativ bewerben
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;