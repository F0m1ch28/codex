import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialForm = {
  name: '',
  email: '',
  company: '',
  subject: '',
  message: '',
  consent: false,
};

const Contact = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);
  const [recaptchaToken, setRecaptchaToken] = useState('');

  useEffect(() => {
    const scriptId = 'google-recaptcha';
    if (!document.getElementById(scriptId)) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.src = 'https://www.google.com/recaptcha/api.js';
      script.async = true;
      script.defer = true;
      document.body.appendChild(script);
    }
    window.onSubmitRecaptcha = (token) => {
      setRecaptchaToken(token);
    };
    return () => {
      delete window.onSubmitRecaptcha;
    };
  }, []);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte Namen angeben.';
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Gültige E-Mail-Adresse erforderlich.';
    }
    if (!formData.subject.trim()) newErrors.subject = 'Bitte Betreff angeben.';
    if (!formData.message.trim() || formData.message.length < 10) {
      newErrors.message = 'Bitte eine Nachricht mit mindestens 10 Zeichen schreiben.';
    }
    if (!formData.consent) {
      newErrors.consent = 'Bitte stimme der Verarbeitung gemäß Datenschutz zu.';
    }
    if (!recaptchaToken) {
      newErrors.recaptcha = 'Bitte bestätige den reCAPTCHA.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setStatus({ type: 'success', message: 'Vielen Dank! Wir melden uns in Kürze mit verfügbaren Demo-Terminen.' });
      setFormData(initialForm);
      setRecaptchaToken('');
      if (window.grecaptcha) {
        window.grecaptcha.reset();
      }
    } else {
      setStatus({ type: 'error', message: 'Bitte Eingaben prüfen.' });
    }
  };

  return (
    <>
      <Helmet>
        <title>Zyfrentica | Kontakt</title>
        <meta
          name="description"
          content="Nehmen Sie Kontakt auf. Vereinbaren Sie eine Demo, sprechen Sie über Use Cases und erfahren Sie, wie Zyfrentica Ihre Marketing-Automatisierung beschleunigt."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/kontakt" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <span className="badge">Kontakt</span>
              <h1>Wir freuen uns auf Ihre Anfrage</h1>
              <p>
                Ob Demo, Projektgespräch oder technische Fragen: Unser Team antwortet innerhalb eines Werktages. Wir
                beraten zu Marketing Automatisierung, CRM Integration, Workflow Builder und Analytics.
              </p>
            </div>
            <div className={styles.contactInfo}>
              <h2>Kontaktinformationen</h2>
              <p>
                Zyfrentica GmbH
                <br />
                Potsdamer Platz 10
                <br />
                10785 Berlin, Deutschland
              </p>
              <p>
                <a href="tel:+493012345678">+49 30 1234 5678</a>
                <br />
                <a href="mailto:kontakt@zyfrentica.de">kontakt@zyfrentica.de</a>
              </p>
              <p>Montag – Freitag · 9:00 bis 18:00 Uhr (CET)</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <div className={styles.formWrapper}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Nachricht senden</h2>
              <div className={styles.formGrid}>
                <div className={styles.inputGroup}>
                  <label htmlFor="name">Name*</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={errors.name ? 'true' : 'false'}
                  />
                  {errors.name && <span className={styles.error}>{errors.name}</span>}
                </div>
                <div className={styles.inputGroup}>
                  <label htmlFor="email">E-Mail*</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={errors.email ? 'true' : 'false'}
                  />
                  {errors.email && <span className={styles.error}>{errors.email}</span>}
                </div>
                <div className={styles.inputGroup}>
                  <label htmlFor="company">Unternehmen</label>
                  <input
                    id="company"
                    name="company"
                    type="text"
                    value={formData.company}
                    onChange={handleChange}
                  />
                </div>
                <div className={styles.inputGroup}>
                  <label htmlFor="subject">Betreff*</label>
                  <input
                    id="subject"
                    name="subject"
                    type="text"
                    value={formData.subject}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={errors.subject ? 'true' : 'false'}
                  />
                  {errors.subject && <span className={styles.error}>{errors.subject}</span>}
                </div>
              </div>
              <div className={styles.inputGroup}>
                <label htmlFor="message">Nachricht*</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={errors.message ? 'true' : 'false'}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <div className={styles.checkboxGroup}>
                <label>
                  <input
                    type="checkbox"
                    name="consent"
                    checked={formData.consent}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={errors.consent ? 'true' : 'false'}
                  />
                  Ich stimme zu, dass Zyfrentica meine Angaben zur Kontaktaufnahme und Zuordnung zu verarbeiteten
                  Vorgängen nutzt. Mehr Infos in der{' '}
                  <a href="/datenschutz" target="_blank" rel="noreferrer">
                    Datenschutz­erklärung
                  </a>
                  .
                </label>
                {errors.consent && <span className={styles.error}>{errors.consent}</span>}
              </div>
              <div className={styles.recaptchaGroup}>
                <div
                  className="g-recaptcha"
                  data-sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
                  data-callback="onSubmitRecaptcha"
                  data-theme="light"
                />
                {errors.recaptcha && <span className={styles.error}>{errors.recaptcha}</span>}
              </div>
              <button type="submit" className="btn btnPrimary">
                Nachricht senden
              </button>
              {status && (
                <p className={status.type === 'success' ? styles.success : styles.errorMessage} role="status">
                  {status.message}
                </p>
              )}
            </form>
            <div className={styles.mapWrapper} aria-label="Karte Standort Zyfrentica">
              <iframe
                title="Zyfrentica Standort Potsdamer Platz Berlin"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.840768540199!2d13.3730652766119!3d52.50964897203351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851cafeeb0f1f%3A0x6b097cc9df3f2b24!2sPotsdamer%20Platz%2010%2C%2010785%20Berlin!5e0!3m2!1sde!2sde!4v1706711112345!5m2!1sde!2sde"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;