import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './UseCases.module.css';
import LazyImage from '../components/LazyImage';
import { Link } from 'react-router-dom';

const useCases = [
  {
    title: 'E-Commerce',
    description:
      'Vom ersten Besuch bis zum Loyalitätsprogramm: Zyfrentica verbindet Shopdaten, POS-Systeme und Marketing-Kanäle für personalisierte Journeys.',
    highlights: [
      'Warenkorb-Abbruch-Serien mit dynamischen Produktblöcken',
      'Loyalty-Punkte Trigger per E-Mail, SMS und App Push',
      'Predictive Analytics für Cross- und Upselling',
    ],
    image: 'https://picsum.photos/900/600?random=131',
  },
  {
    title: 'SaaS',
    description:
      'Von Trial bis Renewal: Automatisieren Sie Onboarding, Feature Adoption und Customer Success Playbooks abgestimmt auf Produktnutzung.',
    highlights: [
      'Trial Aktivierung per In-App Nachricht und E-Mail Sequenz',
      'Health Scores basierend auf Feature Usage und Support Cases',
      'Renewal Alerts für Sales und Success mit Aufgabenrouting',
    ],
    image: 'https://picsum.photos/900/600?random=132',
  },
  {
    title: 'B2B',
    description:
      'Account-basierte Nurturing-Strecken orchestrieren Vertrieb und Marketing. Leads werden verifiziert, priorisiert und automatisiert weitergeleitet.',
    highlights: [
      'Account-basierte Journeys mit Buying Committee Mapping',
      'Lead Routing nach Region, Produktlinie und Kapazität',
      'Verknüpfte Meeting Schedulers, Playbooks und Vertriebsalerts',
    ],
    image: 'https://picsum.photos/900/600?random=133',
  },
];

const UseCases = () => {
  return (
    <>
      <Helmet>
        <title>Zyfrentica | Use Cases</title>
        <meta
          name="description"
          content="Entdecke Use Cases für E-Commerce, SaaS und B2B Teams. Zyfrentica steuert Customer Journeys, Leadgenerierung und Kampagnen mit E-Mail Automation, Workflows und Analytics."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/use-cases" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="badge">Use Cases</span>
            <h1>Customer Journeys für Ihre Branche</h1>
            <p>
              Zyfrentica skaliert Use Cases aus E-Commerce, SaaS und B2B. Wir vernetzen Kampagnen, CRM Integration und
              Analytics, damit Teams schneller reagieren und besser entscheiden.
            </p>
          </div>
        </div>
      </section>

      {useCases.map((useCase, index) => (
        <section key={useCase.title} className={styles.caseSection}>
          <div className="container">
            <div className={`${styles.caseGrid} ${index % 2 === 1 ? styles.reverse : ''}`}>
              <LazyImage
                src={useCase.image}
                alt={`Use Case ${useCase.title}`}
                className={styles.caseImageWrapper}
                imgClassName={styles.caseImage}
              />
              <div className={styles.caseContent}>
                <h2>{useCase.title}</h2>
                <p>{useCase.description}</p>
                <ul>
                  {useCase.highlights.map((highlight) => (
                    <li key={highlight}>{highlight}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>
      ))}

      <section className={styles.compare}>
        <div className="container">
          <h2 className="sectionTitle">Vergleich der Journeys</h2>
          <p className="sectionSubtitle">
            Jede Journey ist individuell. Dennoch teilen sich Branchen zentrale KPIs, Touchpoints und Integrationen.
          </p>
          <div className={styles.tableWrapper}>
            <table>
              <thead>
                <tr>
                  <th>KPI Fokus</th>
                  <th>E-Commerce</th>
                  <th>SaaS</th>
                  <th>B2B</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Primary Metric</td>
                  <td>CLV & Wiederkaufsrate</td>
                  <td>Trial-Konversion & Retention</td>
                  <td>Pipeline Velocity & Win Rate</td>
                </tr>
                <tr>
                  <td>Wichtige Integrationen</td>
                  <td>Shopify, Klaviyo, POS-Systeme</td>
                  <td>Product Analytics, In-App Messaging</td>
                  <td>CRM, Sales Engagement, Datenanbieter</td>
                </tr>
                <tr>
                  <td>Trigger</td>
                  <td>Warenkorb, Loyalty Status, Retouren</td>
                  <td>Feature Adoption, NPS, Payment Events</td>
                  <td>Intent Signals, Formulare, Events</td>
                </tr>
                <tr>
                  <td>Automation Highlights</td>
                  <td>SKU-basierte Empfehlungen</td>
                  <td>Usage-basierte Mails & Alerts</td>
                  <td>Account-basierte Playbooks</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <div>
              <h2>Use Case vertiefen</h2>
              <p>Wir erstellen gemeinsam mit Ihnen ein Zielbild und priorisieren Journeys nach Impact und Komplexität.</p>
            </div>
            <Link to="/kontakt" className="btn btnPrimary">
              Gespräch vereinbaren
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default UseCases;