import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Impressum.module.css';

const Impressum = () => {
  return (
    <>
      <Helmet>
        <title>Zyfrentica | Impressum</title>
        <meta
          name="description"
          content="Impressum der Zyfrentica GmbH. Informationen gemäß § 5 TMG, Kontakt, Haftungshinweis."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/impressum" />
      </Helmet>

      <section className={styles.page}>
        <div className="container">
          <h1>Impressum</h1>
          <p>Angaben gemäß § 5 TMG</p>

          <h2>Anbieter</h2>
          <p>
            Zyfrentica GmbH
            <br />
            Potsdamer Platz 10
            <br />
            10785 Berlin
            <br />
            Deutschland
          </p>

          <h2>Kontakt</h2>
          <p>
            Telefon: +49 30 1234 5678
            <br />
            E-Mail: kontakt@zyfrentica.de
          </p>

          <h2>Vertreten durch</h2>
          <p>
            Katrin Hoffmeister, Dr. Jakob Voss
            <br />
            Registergericht: Amtsgericht Berlin-Charlottenburg
            <br />
            Registernummer: HRB 999999
            <br />
            USt-IdNr.: DE123456789
          </p>

          <h2>Verantwortlich für den Inhalt</h2>
          <p>
            Zyfrentica GmbH
            <br />
            Potsdamer Platz 10, 10785 Berlin, Deutschland
          </p>

          <h2>Hinweis gemäß § 36 VSBG</h2>
          <p>
            Zyfrentica ist weder verpflichtet noch bereit, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle
            teilzunehmen.
          </p>

          <h2>Haftung für Inhalte</h2>
          <p>
            Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten verantwortlich. Nach §§
            8 bis 10 TMG sind wir jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu
            überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
          </p>

          <h2>Haftung für Links</h2>
          <p>
            Unser Angebot enthält Links zu externen Webseiten Dritter. Auf deren Inhalte haben wir keinen Einfluss. Für
            externe Inhalte übernehmen wir keine Gewähr. Bei Bekanntwerden von Rechtsverletzungen entfernen wir derartige
            Links umgehend.
          </p>

          <h2>Urheberrecht</h2>
          <p>
            Die durch Zyfrentica erstellten Inhalte und Werke unterliegen dem deutschen Urheberrecht. Beiträge Dritter sind
            als solche gekennzeichnet. Die Vervielfältigung oder Verbreitung bedarf der schriftlichen Zustimmung.
          </p>
        </div>
      </section>
    </>
  );
};

export default Impressum;