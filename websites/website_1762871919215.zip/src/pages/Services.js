import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';
import LazyImage from '../components/LazyImage';
import { Link } from 'react-router-dom';

const features = [
  {
    title: 'Workflows',
    description:
      'Automatisieren Sie komplexe Kampagnen mit Drag & Drop. Versionierung, A/B-Tests und Sandbox-Umgebungen inklusive.',
    bullets: ['Visueller Workflow Builder', 'Bedingungen, Splits, Loops', 'Realtime Monitoring & Rollback'],
    image: 'https://picsum.photos/900/600?random=121',
  },
  {
    title: 'E-Mail Automation',
    description:
      'Gestalten Sie E-Mail Journeys mit dynamischen Inhalten, AI-Assist und kanalübergreifenden Sequenzen.',
    bullets: ['AI für Betreffzeilen & Sendezeiten', 'Modulare Komponentenbibliothek', 'Dark Mode Preview & QA'],
    image: 'https://picsum.photos/900/600?random=122',
  },
  {
    title: 'Segmentierung',
    description: 'Segmentieren Sie Kontakte anhand Verhalten, Scoring, Attributen und externen Datenquellen.',
    bullets: ['Live-Segmente mit Behavioral Events', 'Lead- und Account-Scoring', 'Data Warehouse Connectoren'],
    image: 'https://picsum.photos/900/600?random=123',
  },
  {
    title: 'Formulare & Landing Pages',
    description:
      'Erfassen Sie Leads responsiv mit eingebetteten Formularen, Progressive Profiling und DSGVO-konformen Einwilligungen.',
    bullets: ['Drag & Drop Formulareditor', 'Mehrstufige Landing Pages', 'Double-Opt-In und Einwilligungsverwaltung'],
    image: 'https://picsum.photos/900/600?random=124',
  },
  {
    title: 'Analytics & Attribution',
    description:
      'Beobachten Sie Funnel, Kampagnen und Customer Journeys in Echtzeit. Alerts informieren über Abweichungen.',
    bullets: ['Attribution über Touchpoints hinweg', 'Dashboard Builder', 'Export zu BI-Tools und Data Warehouses'],
    image: 'https://picsum.photos/900/600?random=125',
  },
  {
    title: 'Integrationen',
    description:
      'Verbinden Sie Zyfrentica nahtlos mit CRM, Ads, Collaboration und Data-Stores. Offene APIs inklusive.',
    bullets: ['CRM Integration (Salesforce, HubSpot, Dynamics)', 'Ads- & Social-Connectoren', 'REST & GraphQL APIs'],
    image: 'https://picsum.photos/900/600?random=126',
  },
];

const governance = [
  {
    title: 'Rollen & Berechtigungen',
    text: 'Definieren Sie granulare Rollen – von der Kampagnenredaktion bis zur Freigabe. Audit Logs dokumentieren jede Änderung.',
  },
  {
    title: 'Brand-Safeguards',
    text: 'Styleguides, Content-Bibliotheken und Freigabeprozesse bewahren Ihre Markenqualität über alle Teams hinweg.',
  },
  {
    title: 'DSGVO & Audit Readiness',
    text: 'Einwilligungen, Double-Opt-In, Consent Logs und Exportfunktionen machen die DSGVO-Compliance transparent.',
  },
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Zyfrentica | Funktionen im Überblick</title>
        <meta
          name="description"
          content="Entdecken Sie Workflows, E-Mail Automation, Segmentierung, Formulare, Analytics und Integrationen von Zyfrentica – der Plattform für Marketing Automatisierung."
        />
        <link rel="canonical" href="https://www.zyfrentica.de/funktionen" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="badge">Produkt</span>
            <h1>Funktionen für orchestrierte Customer Journeys</h1>
            <p>
              Zyfrentica vereint Workflow Builder, E-Mail Automation, Segmentierung, Formulare, Analytics und
              Integrationen in einer Plattform – designed für Marketing, Vertrieb und Customer Success.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakt" className="btn btnPrimary">
                Demo anfordern
              </Link>
              <Link to="/use-cases" className="btn btnSecondary">
                Use Cases ansehen
              </Link>
            </div>
          </div>
        </div>
      </section>

      {features.map((feature, index) => (
        <section key={feature.title} className={styles.featureSection}>
          <div className="container">
            <div className={`${styles.featureGrid} ${index % 2 === 1 ? styles.reverse : ''}`}>
              <LazyImage
                src={feature.image}
                alt={`${feature.title} Screenshot`}
                className={styles.featureImageWrapper}
                imgClassName={styles.featureImage}
              />
              <div className={styles.featureContent}>
                <h2>{feature.title}</h2>
                <p>{feature.description}</p>
                <ul>
                  {feature.bullets.map((bullet) => (
                    <li key={bullet}>{bullet}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>
      ))}

      <section className={styles.governance}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2 className="sectionTitle">Governance inklusive</h2>
            <p className="sectionSubtitle">
              Sicherheit, DSGVO und Qualitätssicherung gehören zu unserem Funktionsumfang – kein Add-on, sondern Basis.
            </p>
          </div>
          <div className={styles.governanceGrid}>
            {governance.map((item) => (
              <article key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.metrics}>
        <div className="container">
          <div className={styles.metricsGrid}>
            <article>
              <h3>Monitoring & Alerts</h3>
              <p>
                Behalten Sie KPIs im Blick: Öffnungs- und Klickrate, Revenue Contribution oder NPS. Alerts informieren,
                wenn definierte Grenzwerte überschritten werden.
              </p>
            </article>
            <article>
              <h3>Workflow Analytics</h3>
              <p>
                Jeder Workflow besitzt eine eigene Analytics-Ansicht. Analysieren Sie Conversion-Raten pro Pfad,
                Drop-Offs und Durchlaufzeiten.
              </p>
            </article>
            <article>
              <h3>API & Erweiterbarkeit</h3>
              <p>
                Unsere APIs sind umfassend dokumentiert. Webhooks, Event-Streaming sowie SDKs ermöglichen individuelle
                Erweiterungen und Integrationen.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.finalBox}>
            <div>
              <h2>Funktionen live erleben</h2>
              <p>
                Wir zeigen Ihnen, wie der Workflow Builder, E-Mail Automation, Segmentierung, Formulare, Analytics und
                Integrationen zusammenspielen.
              </p>
            </div>
            <Link to="/kontakt" className="btn btnPrimary">
              Demo anfordern
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;