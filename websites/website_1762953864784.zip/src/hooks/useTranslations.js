import translations from '../content/translations';
import { useLanguage } from '../context/LanguageContext';

const useTranslations = () => {
  const { language } = useLanguage();
  return translations[language] || translations.en;
};

export default useTranslations;