import { useState } from 'react';
import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './CoursePage.module.css';

const CoursePage = () => {
  const copy = useTranslations();
  const { language } = useLanguage();
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.coursePage.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.coursePage.intro} />
        <link rel="canonical" href="https://tuprogresohoy.com/curso" />
        <link rel="alternate" href="https://tuprogresohoy.com/curso" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/curso" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div className={styles.introCard}>
          <h1 className="section-title">{copy.coursePage.title}</h1>
          <p className="section-subtitle">{copy.coursePage.intro}</p>

          <div>
            <h2>{language === 'en' ? 'Overview' : 'Resumen'}</h2>
            <ul className={styles.list}>
              {copy.coursePage.overview.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>

          <div>
            <h2>{language === 'en' ? 'You will receive' : 'Recibirás'}</h2>
            <ul className={styles.list}>
              {copy.coursePage.whatYouGet.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>

          <p>{copy.coursePage.note}</p>

          <div className={styles.ctaRow}>
            <a href="#lead-form" className="btn btn-primary">
              {copy.coursePage.cta}
            </a>
            <a href="/datos" className="btn btn-outline">
              {language === 'en' ? 'Review methodology' : 'Revisar metodología'}
            </a>
          </div>

          <img
            src="https://picsum.photos/1200/600?random=12"
            alt={language === 'en' ? 'Mini-course preview' : 'Vista previa del mini-curso'}
            className={`${styles.bannerImage} ${imageLoaded ? 'loaded' : ''}`}
            loading="lazy"
            onLoad={() => setImageLoaded(true)}
          />
        </div>
      </div>
    </div>
  );
};

export default CoursePage;