import { useState } from 'react';
import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './BlogPage.module.css';

const BlogPage = () => {
  const copy = useTranslations();
  const { language } = useLanguage();
  const [loadedImages, setLoadedImages] = useState({});

  const handleImageLoad = (index) => {
    setLoadedImages((prev) => ({ ...prev, [index]: true }));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.blogPage.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.blogPage.intro} />
        <link rel="canonical" href="https://tuprogresohoy.com/blog" />
        <link rel="alternate" href="https://tuprogresohoy.com/blog" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/blog" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div className={styles.header}>
          <h1 className="section-title">{copy.blogPage.title}</h1>
          <p className="section-subtitle">{copy.blogPage.intro}</p>
          <div className={styles.categories}>
            {copy.blogPage.categories.map((category) => (
              <span key={category} className={styles.category}>
                {category}
              </span>
            ))}
          </div>
          <p>{copy.blogPage.callout}</p>
        </div>
        <div className={styles.postGrid}>
          {copy.blogPreview.posts.map((post, index) => (
            <article key={post.title} className={styles.postCard}>
              <img
                src={post.image}
                alt={post.alt}
                className={`${styles.thumbnail} ${loadedImages[index] ? 'loaded' : ''}`}
                loading="lazy"
                onLoad={() => handleImageLoad(index)}
              />
              <div className={styles.postContent}>
                <span className={styles.postMeta}>{post.date}</span>
                <h2>{post.title}</h2>
                <p>{post.excerpt}</p>
                <a href="/#lead-form" className="btn btn-primary">
                  {language === 'en' ? 'Start learning' : 'Comenzar a aprender'}
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;