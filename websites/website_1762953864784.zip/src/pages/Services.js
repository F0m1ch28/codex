import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './Services.module.css';

const Services = () => {
  const copy = useTranslations();
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.servicesPage.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.servicesPage.intro} />
        <link rel="canonical" href="https://tuprogresohoy.com/servicios" />
        <link rel="alternate" href="https://tuprogresohoy.com/servicios" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/servicios" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div>
          <h1 className="section-title">{copy.servicesPage.title}</h1>
          <p className="section-subtitle">{copy.servicesPage.intro}</p>
        </div>
        <div className={styles.offerings}>
          {copy.servicesPage.offerings.map((offering) => (
            <article key={offering.title} className={styles.card}>
              <h2>{offering.title}</h2>
              <p>{offering.description}</p>
            </article>
          ))}
        </div>
        <p className={styles.note}>{copy.servicesPage.note}</p>
      </div>
    </div>
  );
};

export default Services;