import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './DataMethodologyPage.module.css';

const DataMethodologyPage = () => {
  const copy = useTranslations();
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.dataPage.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.dataPage.intro} />
        <link rel="canonical" href="https://tuprogresohoy.com/datos" />
        <link rel="alternate" href="https://tuprogresohoy.com/datos" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/datos" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div>
          <h1 className="section-title">{copy.dataPage.title}</h1>
          <p className="section-subtitle">{copy.dataPage.intro}</p>
        </div>
        {copy.dataPage.sections.map((section) => (
          <article key={section.heading} className={styles.sectionCard}>
            <h2>{section.heading}</h2>
            <p>{section.body}</p>
          </article>
        ))}
        <p className={styles.footerNote}>{copy.dataPage.footer}</p>
      </div>
    </div>
  );
};

export default DataMethodologyPage;