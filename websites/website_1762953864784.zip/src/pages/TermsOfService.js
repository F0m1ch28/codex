import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './TermsOfService.module.css';

const TermsOfService = () => {
  const copy = useTranslations();
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.terms.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.terms.updated} />
        <link rel="canonical" href="https://tuprogresohoy.com/terms" />
        <link rel="alternate" href="https://tuprogresohoy.com/terms" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/terms" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div>
          <h1 className="section-title">{copy.terms.title}</h1>
          <p className="section-subtitle">{copy.terms.updated}</p>
        </div>
        {copy.terms.sections.map((section) => (
          <section key={section.heading} className={styles.section}>
            <h3>{section.heading}</h3>
            <p>{section.body}</p>
          </section>
        ))}
        <p>{copy.terms.acceptance}</p>
      </div>
    </div>
  );
};

export default TermsOfService;