import { useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './ThankYouPage.module.css';

const ThankYouPage = () => {
  const copy = useTranslations();
  const { language } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const userName = location.state?.name;

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.thankYouPage.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.thankYouPage.intro} />
        <link rel="canonical" href="https://tuprogresohoy.com/gracias" />
        <link rel="alternate" href="https://tuprogresohoy.com/gracias" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/gracias" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <h1 className="section-title">{copy.thankYouPage.title}</h1>
        <p className="section-subtitle">
          {userName ? `${userName}, ` : ''}
          {copy.thankYouPage.intro}
        </p>
        <ul className={styles.steps}>
          {copy.thankYouPage.nextSteps.map((step) => (
            <li key={step}>{step}</li>
          ))}
        </ul>
        <button type="button" className="btn btn-primary" onClick={() => navigate('/')}>
          {copy.thankYouPage.back}
        </button>
      </div>
    </div>
  );
};

export default ThankYouPage;