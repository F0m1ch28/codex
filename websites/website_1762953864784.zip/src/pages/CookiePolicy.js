import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  const copy = useTranslations();
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.cookies.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.cookies.intro} />
        <link rel="canonical" href="https://tuprogresohoy.com/cookies" />
        <link rel="alternate" href="https://tuprogresohoy.com/cookies" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/cookies" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div>
          <h1 className="section-title">{copy.cookies.title}</h1>
          <p className="section-subtitle">{copy.cookies.intro}</p>
        </div>
        {copy.cookies.sections.map((section) => (
          <section key={section.heading} className={styles.card}>
            <h3>{section.heading}</h3>
            <p>{section.body}</p>
          </section>
        ))}
      </div>
    </div>
  );
};

export default CookiePolicy;