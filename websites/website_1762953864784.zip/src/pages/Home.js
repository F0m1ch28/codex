import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './Home.module.css';

const formatValue = (value) => {
  if (typeof value !== 'number') return value;
  if (value >= 100) return Math.round(value);
  return parseFloat(value.toFixed(2));
};

const Home = () => {
  const { language } = useLanguage();
  const copy = useTranslations();
  const navigate = useNavigate();
  const location = useLocation();
  const statsData = useMemo(() => copy.stats, [copy]);
  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('all');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    interest: '',
    consent: false
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    setStatValues(statsData.map(() => 0));
    const intervals = [];
    statsData.forEach((stat, index) => {
      const target = stat.value;
      const duration = 1600;
      const stepTime = 32;
      const steps = duration / stepTime;
      const increment = target / steps;
      intervals[index] = setInterval(() => {
        setStatValues((prev) => {
          const updated = [...prev];
          const nextValue = updated[index] + increment;
          if (
            (increment >= 0 && nextValue >= target) ||
            (increment < 0 && nextValue <= target)
          ) {
            updated[index] = target;
            clearInterval(intervals[index]);
          } else {
            updated[index] = nextValue;
          }
          return updated;
        });
      }, stepTime);
    });
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsData, language]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % copy.testimonials.items.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [copy.testimonials.items.length]);

  useEffect(() => {
    setSuccessMessage('');
    setErrors({});
    setFormData({
      name: '',
      email: '',
      phone: '',
      interest: '',
      consent: false
    });
  }, [language, location.pathname]);

  const filteredProjects = copy.projects.items.filter(
    (item) => projectFilter === 'all' || item.category === projectFilter
  );

  const handleNavTestimonials = (direction) => {
    setCurrentTestimonial((prev) => {
      if (direction === 'prev') {
        return prev === 0 ? copy.testimonials.items.length - 1 : prev - 1;
      }
      return (prev + 1) % copy.testimonials.items.length;
    });
  };

  const handleFormChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = copy.errors.required;
    if (!formData.email.trim()) {
      newErrors.email = copy.errors.required;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = copy.errors.email;
    }
    if (!formData.interest) newErrors.interest = copy.errors.required;
    if (!formData.consent) newErrors.consent = copy.errors.consent;
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitting(true);
    setSuccessMessage('');
    setTimeout(() => {
      console.log('form_submit', { event: 'form_submit', form: 'lead_form', formData });
      setSubmitting(false);
      setSuccessMessage(copy.success.submitted);
      navigate('/gracias', { state: { name: formData.name, language } });
    }, 900);
  };

  const handleCourseCta = () => {
    console.log('course_cta', { event: 'course_cta', origin: 'home_mini_course' });
    navigate('/curso');
  };

  const faqSchema = copy.faq.items.map((item) => ({
    '@type': 'Question',
    name: item.question,
    acceptedAnswer: {
      '@type': 'Answer',
      text: item.answer
    }
  }));

  const schemaData = [
    {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'Tu Progreso Hoy',
      url: 'https://tuprogresohoy.com',
      logo: 'https://tuprogresohoy.com/logo.png',
      contactPoint: {
        '@type': 'ContactPoint',
        contactType: 'customer support',
        email: 'hola@tuprogresohoy.com'
      }
    },
    {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: 'Tu Progreso Hoy',
      url: 'https://tuprogresohoy.com',
      potentialAction: {
        '@type': 'SearchAction',
        target: 'https://tuprogresohoy.com/buscar?query={search_term_string}',
        'query-input': 'required name=search_term_string'
      }
    },
    {
      '@context': 'https://schema.org',
      '@type': 'Course',
      name: language === 'en'
        ? 'Mini-course on responsible financial planning'
        : 'Mini-curso sobre planificación financiera responsable',
      description: copy.miniCourse.summary,
      provider: {
        '@type': 'Organization',
        name: 'Tu Progreso Hoy',
        sameAs: 'https://tuprogresohoy.com'
      }
    },
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: faqSchema
    }
  ];

  return (
    <>
      <Helmet>
        <html lang={language} />
        <title>{copy.common.tagline} | {copy.common.siteName}</title>
        <meta name="description" content={copy.common.description} />
        <link rel="canonical" href="https://tuprogresohoy.com/" />
        <link rel="alternate" href="https://tuprogresohoy.com/" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/" hrefLang="es-AR" />
        <script type="application/ld+json">
          {JSON.stringify(schemaData)}
        </script>
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <span aria-hidden="true">{copy.hero.highlight}</span>
              <h1 className={styles.heroTitle}>{copy.hero.title}</h1>
              <p className={styles.heroSubtitle}>{copy.hero.subtitle}</p>
              <ul className={styles.heroPoints}>
                {copy.hero.points.map((point) => (
                  <li key={point} className={styles.heroPoint}>
                    {point}
                  </li>
                ))}
              </ul>
              <div className={styles.heroCtas}>
                <button
                  type="button"
                  className={`${styles.primaryCta}`}
                  onClick={() => {
                    console.log('course_cta', { event: 'course_cta', origin: 'hero_primary' });
                    navigate('/curso');
                  }}
                >
                  {copy.hero.primaryCta}
                </button>
                <button
                  type="button"
                  className={`${styles.secondaryCta}`}
                  onClick={() => navigate('/datos')}
                >
                  {copy.hero.secondaryCta}
                </button>
              </div>
            </div>
            <div className={styles.metrics} aria-live="polite">
              <div className={styles.metricsSummary}>{copy.metricSummary}</div>
              {copy.stats.map((stat, index) => (
                <div key={stat.id} className={styles.statCard}>
                  <div className={styles.statLabel}>{stat.label}</div>
                  <div className={styles.statValue}>
                    {formatValue(statValues[index])}
                    {stat.suffix}
                  </div>
                  <div className={styles.statChange}>
                    <span aria-hidden="true">↗</span>
                    {stat.change}
                  </div>
                  <div className={styles.statHelper}>{stat.helper}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.dataVisuals}>
        <div className={styles.dataInner}>
          <div>
            <h2 className="section-title">{copy.dataVisuals.title}</h2>
            <p className="section-subtitle">{copy.dataVisuals.description}</p>
          </div>
          <div className={styles.dataList}>
            {copy.dataVisuals.items.map((item) => (
              <article key={item.title} className={styles.dataItem}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.miniCourse}>
        <div className={styles.miniCourseCard}>
          <h2 className="section-title">{copy.miniCourse.title}</h2>
          <p className="section-subtitle">{copy.miniCourse.summary}</p>
          <ul className={styles.miniCourseBullets}>
            {copy.miniCourse.bullets.map((bullet) => (
              <li key={bullet}>{bullet}</li>
            ))}
          </ul>
          <div className={styles.ctaButtons}>
            <button
              type="button"
              className="btn btn-primary"
              onClick={handleCourseCta}
            >
              {copy.miniCourse.cta}
            </button>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.processInner}>
          <div>
            <h2 className="section-title">{copy.process.title}</h2>
          </div>
          <div className={styles.processGrid}>
            {copy.process.steps.map((step, index) => (
              <article
                key={step.title}
                className={styles.processStep}
                data-step={index + 1}
              >
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className={styles.servicesInner}>
          <div>
            <h2 className="section-title">{copy.servicesSection.title}</h2>
            <p className="section-subtitle">{copy.servicesSection.description}</p>
          </div>
          <div className={styles.servicesGrid}>
            {copy.servicesSection.cards.map((card) => (
              <article key={card.title} className={styles.serviceCard}>
                <h3>{card.title}</h3>
                <p>{card.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.testimonialsInner}>
          <div>
            <h2 className="section-title" style={{ color: '#fff' }}>
              {copy.testimonials.title}
            </h2>
          </div>
          <article className={styles.testimonialCard}>
            <p className={styles.testimonialQuote}>
              “{copy.testimonials.items[currentTestimonial].quote}”
            </p>
            <div className={styles.testimonialMeta}>
              <strong>{copy.testimonials.items[currentTestimonial].name}</strong>
              <span>{copy.testimonials.items[currentTestimonial].role}</span>
            </div>
            <div className={styles.testimonialNav}>
              <button
                type="button"
                className={styles.navButton}
                onClick={() => handleNavTestimonials('prev')}
                aria-label="Previous testimonial"
              >
                ‹
              </button>
              <button
                type="button"
                className={styles.navButton}
                onClick={() => handleNavTestimonials('next')}
                aria-label="Next testimonial"
              >
                ›
              </button>
            </div>
          </article>
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.teamInner}>
          <div>
            <h2 className="section-title">{copy.team.title}</h2>
            <p className="section-subtitle">{copy.team.intro}</p>
          </div>
          <div className={styles.teamGrid}>
            {copy.team.members.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img
                  src={member.img}
                  alt={member.alt}
                  className={styles.teamImage}
                  loading="lazy"
                  onLoad={(event) => event.currentTarget.classList.add(styles.loaded)}
                />
                <h3>{member.name}</h3>
                <strong>{member.role}</strong>
                <p>{member.bio}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.projectsInner}>
          <div>
            <h2 className="section-title">{copy.projects.title}</h2>
          </div>
          <div className={styles.projectFilters} role="group" aria-label="Project filters">
            {copy.projects.filters.map((filter) => (
              <button
                key={filter.id}
                type="button"
                className={`${styles.filterButton} ${
                  projectFilter === filter.id ? styles.filterActive : ''
                }`}
                onClick={() => setProjectFilter(filter.id)}
              >
                {filter.label}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={project.alt}
                  className={styles.projectImage}
                  loading="lazy"
                  onLoad={(event) => event.currentTarget.classList.add(styles.loaded)}
                />
                <div className={styles.projectContent}>
                  <h4>{project.title}</h4>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.faqInner}>
          <h2 className="section-title">{copy.faq.title}</h2>
          <div className={styles.faqList}>
            {copy.faq.items.map((item, index) => {
              const isOpen = errors.activeFaq === index;
              return (
                <div
                  key={item.question}
                  className={`${styles.faqItem} ${isOpen ? styles.faqItemActive : ''}`}
                >
                  <button
                    type="button"
                    className={styles.faqButton}
                    aria-expanded={isOpen}
                    onClick={() =>
                      setErrors((prev) => ({
                        ...prev,
                        activeFaq: prev.activeFaq === index ? null : index
                      }))
                    }
                  >
                    {item.question}
                    <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
                  </button>
                  <div className={`${styles.faqAnswer} ${isOpen ? styles.faqAnswerOpen : ''}`}>
                    <p>{item.answer}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.blogInner}>
          <div>
            <h2 className="section-title">{copy.blogPreview.title}</h2>
          </div>
          <div className={styles.blogGrid}>
            {copy.blogPreview.posts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img
                  src={post.image}
                  alt={post.alt}
                  className={styles.blogImage}
                  loading="lazy"
                  onLoad={(event) => event.currentTarget.classList.add(styles.loaded)}
                />
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => navigate('/blog')}
                  >
                    {language === 'en' ? 'Read more' : 'Leer más'}
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaInner}>
          <h2 className="section-title" style={{ color: '#fff' }}>
            {copy.ctaSection.title}
          </h2>
          <p className="section-subtitle" style={{ color: 'rgba(248, 250, 252, 0.85)' }}>
            {copy.ctaSection.subtitle}
          </p>
          <button
            type="button"
            className="btn btn-outline"
            onClick={() => {
              console.log('course_cta', { event: 'course_cta', origin: 'home_secondary' });
              navigate('/servicios');
            }}
          >
            {copy.ctaSection.button}
          </button>
        </div>
      </section>

      <section className={styles.leadFormSection} id="lead-form">
        <div className={styles.leadFormCard}>
          <div>
            <h2 className="section-title">{copy.leadForm.title}</h2>
            <p className="section-subtitle">{copy.leadForm.description}</p>
          </div>
          <form onSubmit={handleSubmit} className={styles.formGrid} noValidate>
            <div className={styles.fieldGroup}>
              <label htmlFor="lead-name">{copy.leadForm.fields.name}</label>
              <input
                id="lead-name"
                type="text"
                name="name"
                className={styles.input}
                value={formData.name}
                onChange={handleFormChange}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="lead-email">{copy.leadForm.fields.email}</label>
              <input
                id="lead-email"
                type="email"
                name="email"
                className={styles.input}
                value={formData.email}
                onChange={handleFormChange}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="lead-phone">{copy.leadForm.fields.phone}</label>
              <input
                id="lead-phone"
                type="tel"
                name="phone"
                className={styles.input}
                value={formData.phone}
                onChange={handleFormChange}
              />
            </div>

            <div className={styles.fieldGroup}>
              <label htmlFor="lead-interest">{copy.leadForm.fields.interest}</label>
              <select
                id="lead-interest"
                name="interest"
                className={styles.select}
                value={formData.interest}
                onChange={handleFormChange}
                aria-invalid={Boolean(errors.interest)}
              >
                {copy.leadForm.interestOptions.map((option) => (
                  <option key={option.value || 'blank'} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              {errors.interest && <span className={styles.error}>{errors.interest}</span>}
            </div>

            <div className={styles.fieldGroup} style={{ gridColumn: '1 / -1' }}>
              <label className={styles.checkboxGroup}>
                <input
                  type="checkbox"
                  name="consent"
                  checked={formData.consent}
                  onChange={handleFormChange}
                />
                {copy.leadForm.fields.consent}
              </label>
              {errors.consent && <span className={styles.error}>{errors.consent}</span>}
            </div>

            <div style={{ gridColumn: '1 / -1', display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                {submitting
                  ? language === 'en'
                    ? 'Submitting...'
                    : 'Enviando...'
                  : copy.leadForm.submit}
              </button>
              {successMessage && <span className={styles.success}>{successMessage}</span>}
            </div>
          </form>
          <p>{copy.disclaimer}</p>
        </div>
      </section>
    </>
  );
};

export default Home;