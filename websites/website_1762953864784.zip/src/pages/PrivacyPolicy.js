import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicy = () => {
  const copy = useTranslations();
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.privacy.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.privacy.updated} />
        <link rel="canonical" href="https://tuprogresohoy.com/privacy" />
        <link rel="alternate" href="https://tuprogresohoy.com/privacy" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/privacy" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div>
          <h1 className="section-title">{copy.privacy.title}</h1>
          <p className="section-subtitle">{copy.privacy.updated}</p>
        </div>
        {copy.privacy.sections.map((section) => (
          <section key={section.heading} className={styles.section}>
            <h3>{section.heading}</h3>
            <p>{section.body}</p>
          </section>
        ))}
        <p>{copy.privacy.contact}</p>
      </div>
    </div>
  );
};

export default PrivacyPolicy;