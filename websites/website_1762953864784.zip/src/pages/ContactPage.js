import { useState } from 'react';
import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const copy = useTranslations();
  const { language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = copy.errors.required;
    if (!formData.email.trim()) {
      newErrors.email = copy.errors.required;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = copy.errors.email;
    }
    if (!formData.topic) newErrors.topic = copy.errors.required;
    if (!formData.message.trim()) newErrors.message = copy.errors.required;
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }
    setSuccess('');
    console.log('form_submit', { event: 'form_submit', form: 'contact_form', formData });
    setSuccess(copy.contactPage.success);
    setFormData({
      name: '',
      email: '',
      topic: '',
      message: ''
    });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.contactPage.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.contactPage.intro} />
        <link rel="canonical" href="https://tuprogresohoy.com/contacto" />
        <link rel="alternate" href="https://tuprogresohoy.com/contacto" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/contacto" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div className={styles.grid}>
          <aside className={styles.infoCard}>
            <h1 className="section-title">{copy.contactPage.title}</h1>
            <p>{copy.contactPage.intro}</p>
            <p>{copy.contact.quickResponse}</p>
            <p>{copy.contact.callout}</p>
            <p>{copy.contactPage.office}</p>
          </aside>
          <form className={styles.formCard} onSubmit={handleSubmit} noValidate>
            <div className={styles.formGrid}>
              <div className={styles.field}>
                <label htmlFor="contact-name">{copy.contactPage.form.name}</label>
                <input
                  id="contact-name"
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={styles.input}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-email">{copy.contactPage.form.email}</label>
                <input
                  id="contact-email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={styles.input}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-topic">{copy.contactPage.form.topic}</label>
                <select
                  id="contact-topic"
                  name="topic"
                  value={formData.topic}
                  onChange={handleChange}
                  className={styles.select}
                >
                  {copy.contactPage.topics.map((topic) => (
                    <option key={topic.value || 'blank'} value={topic.value}>
                      {topic.label}
                    </option>
                  ))}
                </select>
                {errors.topic && <span className={styles.error}>{errors.topic}</span>}
              </div>
              <div className={styles.field} style={{ gridColumn: '1 / -1' }}>
                <label htmlFor="contact-message">{copy.contactPage.form.message}</label>
                <textarea
                  id="contact-message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  className={styles.textarea}
                  rows={5}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <button type="submit" className="btn btn-primary">
                {copy.contactPage.form.submit}
              </button>
              {success && <span className={styles.success}>{success}</span>}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;