import { Helmet } from 'react-helmet';
import useTranslations from '../hooks/useTranslations';
import { useLanguage } from '../context/LanguageContext';
import styles from './About.module.css';

const About = () => {
  const copy = useTranslations();
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <Helmet>
        <html lang={language} />
        <title>{copy.aboutPage.title} | {copy.common.siteName}</title>
        <meta name="description" content={copy.aboutPage.mission} />
        <link rel="canonical" href="https://tuprogresohoy.com/about" />
        <link rel="alternate" href="https://tuprogresohoy.com/about" hrefLang="en-AR" />
        <link rel="alternate" href="https://tuprogresohoy.com/about" hrefLang="es-AR" />
      </Helmet>
      <div className={styles.inner}>
        <div>
          <h1 className="section-title">{copy.aboutPage.title}</h1>
          <p className="section-subtitle">{copy.aboutPage.mission}</p>
        </div>
        <section className={styles.story}>
          <h2>{language === 'en' ? 'Our vision' : 'Nuestra visión'}</h2>
          <p>{copy.aboutPage.vision}</p>
          {copy.aboutPage.story.map((paragraph) => (
            <p key={paragraph}>{paragraph}</p>
          ))}
        </section>
        <section>
          <h2>{language === 'en' ? 'Timeline' : 'Cronología'}</h2>
          <div className={styles.timeline}>
            {copy.aboutPage.timeline.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <strong>{item.year}</strong>
                <span>{item.text}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;