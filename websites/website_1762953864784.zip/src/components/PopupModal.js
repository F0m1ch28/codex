import { useEffect, useState } from 'react';
import useTranslations from '../hooks/useTranslations';
import styles from './PopupModal.module.css';

const PopupModal = () => {
  const copy = useTranslations();
  const [open, setOpen] = useState(false);
  const [dontShow, setDontShow] = useState(false);

  useEffect(() => {
    const acknowledged = localStorage.getItem('tph-popup-ack');
    if (!acknowledged) {
      const timer = setTimeout(() => setOpen(true), 1800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleClose = () => {
    if (dontShow) {
      localStorage.setItem('tph-popup-ack', 'acknowledged');
    }
    setOpen(false);
    console.log('popup_ack', { event: 'popup_ack', dontShow });
  };

  if (!open) return null;

  return (
    <div className={styles.overlay} role="dialog" aria-modal="true" aria-label={copy.popup.title}>
      <div className={styles.modal}>
        <h2 className={styles.title}>{copy.popup.title}</h2>
        <p>{copy.popup.message}</p>
        <label className={styles.checkbox}>
          <input
            type="checkbox"
            checked={dontShow}
            onChange={(event) => setDontShow(event.target.checked)}
          />
          {copy.popup.checkbox}
        </label>
        <div className={styles.actions}>
          <button type="button" className={styles.closeButton} onClick={handleClose}>
            {copy.popup.close}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PopupModal;