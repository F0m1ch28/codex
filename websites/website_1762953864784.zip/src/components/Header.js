import { useEffect, useState } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import useTranslations from '../hooks/useTranslations';
import styles from './Header.module.css';

const Header = () => {
  const { language, setLanguage } = useLanguage();
  const copy = useTranslations();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    { to: '/', label: copy.nav.home },
    { to: '/curso', label: copy.nav.course },
    { to: '/datos', label: copy.nav.data },
    { to: '/blog', label: copy.nav.blog },
    { to: '/about', label: copy.nav.about },
    { to: '/servicios', label: copy.nav.services },
    { to: '/contacto', label: copy.nav.contact }
  ];

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const handleLanguageChange = (value) => {
    setLanguage(value);
  };

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label={copy.common.siteName}>
          <span>{copy.common.siteName}</span>
        </Link>
        <button
          type="button"
          className={`${styles.navToggle} ${menuOpen ? styles.navOpen : ''}`}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
        >
          <span className={styles.burger} aria-hidden="true" />
          <span className="sr-only">Toggle navigation</span>
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${menuOpen ? styles.open : ''}`}
          aria-label="Primary"
        >
          <ul className={styles.navList}>
            {navLinks.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className={styles.langSwitcher} role="group" aria-label="Language selector">
            <button
              type="button"
              className={`${styles.langButton} ${language === 'en' ? styles.langActive : ''}`}
              onClick={() => handleLanguageChange('en')}
              aria-label={copy.common.languageToggle.enAria}
            >
              {copy.common.languageToggle.enLabel}
            </button>
            <button
              type="button"
              className={`${styles.langButton} ${language === 'es' ? styles.langActive : ''}`}
              onClick={() => handleLanguageChange('es')}
              aria-label={copy.common.languageToggle.esAria}
            >
              {copy.common.languageToggle.esLabel}
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;