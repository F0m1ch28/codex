import { useEffect, useState } from 'react';
import useTranslations from '../hooks/useTranslations';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const copy = useTranslations();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('tph-cookie-consent');
    if (!consent) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  const handleChoice = (value) => {
    localStorage.setItem('tph-cookie-consent', value);
    setVisible(false);
    console.log('cookie_consent', { event: 'cookie_consent', value });
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent">
      <div className={styles.header}>
        <span>{copy.cookie.title}</span>
      </div>
      <p>{copy.cookie.message}</p>
      <div className={styles.actions}>
        <button
          type="button"
          className={`${styles.button} ${styles.accept}`}
          onClick={() => handleChoice('accepted')}
        >
          {copy.cookie.accept}
        </button>
        <button
          type="button"
          className={`${styles.button} ${styles.decline}`}
          onClick={() => handleChoice('declined')}
        >
          {copy.cookie.decline}
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;