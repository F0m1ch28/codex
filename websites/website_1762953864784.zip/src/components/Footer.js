import { Link } from 'react-router-dom';
import useTranslations from '../hooks/useTranslations';
import styles from './Footer.module.css';

const Footer = () => {
  const copy = useTranslations();

  return (
    <footer className={styles.footer}>
      <div className={styles.footerInner}>
        <div className={styles.top}>
          <div className={styles.brand}>
            <h3>{copy.common.siteName}</h3>
            <p>{copy.common.tagline}</p>
          </div>
          <div className={styles.columns}>
            <div className={styles.column}>
              <h4>{copy.nav.home}</h4>
              <ul>
                <li>
                  <Link to="/">{copy.nav.home}</Link>
                </li>
                <li>
                  <Link to="/curso">{copy.nav.course}</Link>
                </li>
                <li>
                  <Link to="/datos">{copy.nav.data}</Link>
                </li>
                <li>
                  <Link to="/blog">{copy.nav.blog}</Link>
                </li>
              </ul>
            </div>
            <div className={styles.column}>
              <h4>{copy.nav.services}</h4>
              <ul>
                <li>
                  <Link to="/servicios">{copy.nav.services}</Link>
                </li>
                <li>
                  <Link to="/about">{copy.nav.about}</Link>
                </li>
                <li>
                  <Link to="/contacto">{copy.nav.contact}</Link>
                </li>
              </ul>
            </div>
            <div className={styles.column}>
              <h4>{copy.common.socialTitle}</h4>
              <div className={styles.social}>
                <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                  in
                </a>
                <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
                  YT
                </a>
                <a href="mailto:hola@tuprogresohoy.com" aria-label="Email">
                  @
                </a>
              </div>
              <p>
                {copy.common.contactEmailLabel}: hola@tuprogresohoy.com
                <br />
                {copy.common.address}
              </p>
            </div>
          </div>
        </div>
        <div className={styles.divider} aria-hidden="true" />
        <div className={styles.bottom}>
          <span className={styles.rights}>
            © {new Date().getFullYear()} {copy.common.siteName}. {copy.common.footerTagline}.
          </span>
          <div>
            <Link to="/privacy" style={{ marginRight: '1rem' }}>
              {copy.nav.privacy}
            </Link>
            <Link to="/terms" style={{ marginRight: '1rem' }}>
              {copy.nav.terms}
            </Link>
            <Link to="/cookies">{copy.nav.cookies}</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;