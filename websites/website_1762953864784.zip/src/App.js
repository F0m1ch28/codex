import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import PopupModal from './components/PopupModal';
import ScrollToTop, { ScrollRestoration } from './components/ScrollToTop';
import Home from './pages/Home';
import CoursePage from './pages/CoursePage';
import DataMethodologyPage from './pages/DataMethodologyPage';
import BlogPage from './pages/BlogPage';
import ContactPage from './pages/ContactPage';
import ThankYouPage from './pages/ThankYouPage';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import CookiePolicy from './pages/CookiePolicy';
import About from './pages/About';
import Services from './pages/Services';
import { LanguageProvider } from './context/LanguageContext';

const App = () => (
  <LanguageProvider>
    <Router>
      <ScrollRestoration />
      <Helmet>
        <link rel="alternate" href="https://tuprogresohoy.com/" hrefLang="x-default" />
      </Helmet>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/curso" element={<CoursePage />} />
          <Route path="/datos" element={<DataMethodologyPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/about" element={<About />} />
          <Route path="/servicios" element={<Services />} />
          <Route path="/contacto" element={<ContactPage />} />
          <Route path="/gracias" element={<ThankYouPage />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/terms" element={<TermsOfService />} />
          <Route path="/cookies" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <PopupModal />
      <ScrollToTop />
    </Router>
  </LanguageProvider>
);

export default App;