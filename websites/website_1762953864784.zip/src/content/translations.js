const translations = {
  en: {
    common: {
      siteName: 'Tu Progreso Hoy',
      tagline: 'Smart finances for your future',
      description:
        'Educational hub that tracks ARS/USD and inflation to help you plan with responsible context.',
      languageToggle: {
        enLabel: 'EN',
        esLabel: 'ES',
        enAria: 'Switch site language to English',
        esAria: 'Switch site language to Spanish'
      },
      footerTagline: 'Better steps, better future',
      contactEmailLabel: 'Email',
      contactPhoneLabel: 'Phone',
      address: 'Buenos Aires, Argentina',
      socialTitle: 'Community'
    },
    nav: {
      home: 'Home',
      course: 'Mini-course',
      data: 'Data methodology',
      blog: 'Blog',
      about: 'About',
      services: 'Learning paths',
      contact: 'Contact',
      privacy: 'Privacy',
      terms: 'Terms',
      cookies: 'Cookies',
      thankYou: 'Thank you'
    },
    hero: {
      title: 'Smart finances for your future',
      subtitle:
        'Clear analysis and market data for secure financial decisions. Educational platform with essential data, without direct financial advice.',
      highlight: 'Datos confiables para tu presupuesto',
      points: [
        'Reliable data for your budget',
        'Responsible decisions, clear plans',
        'Financial wisdom with trends',
        'Better steps, better future'
      ],
      primaryCta: 'Get free trial lesson',
      secondaryCta: 'Explore methodology'
    },
    stats: [
      {
        id: 'arsUsd',
        label: 'ARS reference to USD (informal)',
        value: 0.0012,
        suffix: '',
        change: '+0.6%',
        helper: 'Updated with blended market sources'
      },
      {
        id: 'inflation',
        label: 'Projected monthly inflation',
        value: 18.6,
        suffix: '%',
        change: '-0.4 pts',
        helper: 'Based on national and private monitors'
      },
      {
        id: 'budget',
        label: 'Household essentials index',
        value: 64,
        suffix: '/100',
        change: '+3 pts',
        helper: 'Signals variations in regular expenses'
      }
    ],
    metricSummary: 'Follow trends, detect opportunities and plan your financial future',
    dataVisuals: {
      title: 'Sabiduría financiera con tendencias',
      description:
        'Information layers compare official and informal exchange references plus inflation baskets to give early warnings on purchasing power shifts.',
      items: [
        {
          title: 'Multi-source exchange panel',
          description:
            'Combines official publications, analyst consensus and alternative market averages for resilient comparisons.'
        },
        {
          title: 'Inflation momentum bands',
          description:
            'Charts projected variation by category to detect acceleration or slowdown months before they materialize.'
        },
        {
          title: 'Scenario simulator',
          description:
            'Adjust expectations with custom targets and watch how it shapes weekly and monthly allocations.'
        }
      ]
    },
    miniCourse: {
      title: 'Mini-course: decisiones responsables, planes claros',
      summary:
        'Reliable information supporting your responsible money choices. From information to knowledge: grow your financial wisdom step by step.',
      bullets: [
        'Understand ARS/USD dynamics without jargon.',
        'Design adaptable buffers around inflation spikes.',
        'Create mindful check-ins for family or business finances.'
      ],
      cta: 'Start the free module'
    },
    process: {
      title: 'Ruta de análisis responsable',
      steps: [
        {
          title: 'Context briefing',
          description:
            'Receive concise digests that translate macro headlines into everyday language.'
        },
        {
          title: 'Data exploration',
          description:
            'Interact with charts and tables organized by theme to connect signals quickly.'
        },
        {
          title: 'Scenario notes',
          description:
            'Draft action notes aligned with realistic thresholds and personal priorities.'
        },
        {
          title: 'Ongoing refinement',
          description: 'Review progress monthly to confirm that plans stay aligned with life goals.'
        }
      ]
    },
    servicesSection: {
      title: 'Learning paths',
      description: 'Análisis claros y datos de mercado para decisiones financieras seguras.',
      cards: [
        {
          title: 'Exchange rate tracker',
          description: 'Weekly brief plus intraday snapshots to interpret ARS/USD moves calmly.'
        },
        {
          title: 'Inflation insights',
          description: 'Category-by-category timelines to understand changes in essential baskets.'
        },
        {
          title: 'Budget practice labs',
          description: 'Guided worksheets transform complex indicators into manageable routines.'
        }
      ]
    },
    testimonials: {
      title: 'Community voices',
      items: [
        {
          quote:
            'The dashboards keep our planning grounded in facts and avoid rushed reactions.',
          name: 'Luis P.',
          role: 'Community organizer'
        },
        {
          quote:
            'With the mini-course we aligned our household priorities around shared milestones.',
          name: 'Mariana S.',
          role: 'Small business owner'
        },
        {
          quote: 'I appreciate how every chart comes with context and responsible language.',
          name: 'Carolina D.',
          role: 'Finance student'
        }
      ]
    },
    team: {
      title: 'Equipo Tu Progreso Hoy',
      intro: 'Información confiable que respalda tus elecciones responsables de dinero.',
      members: [
        {
          name: 'Valentina Ortiz',
          role: 'Economic analyst',
          bio: 'Synthesizes official releases and independent monitors to keep metrics balanced.',
          img: 'https://picsum.photos/400/400?random=31',
          alt: 'Portrait of economic analyst Valentina Ortiz'
        },
        {
          name: 'Julián Mercado',
          role: 'Data storyteller',
          bio: 'Transforms complex datasets into visuals that empower daily decisions.',
          img: 'https://picsum.photos/400/400?random=32',
          alt: 'Portrait of data storyteller Julián Mercado'
        },
        {
          name: 'Rocío Álvarez',
          role: 'Learning designer',
          bio: 'Creates step-by-step lessons so each concept becomes an actionable habit.',
          img: 'https://picsum.photos/400/400?random=33',
          alt: 'Portrait of learning designer Rocío Álvarez'
        },
        {
          name: 'Mateo Giménez',
          role: 'Community curator',
          bio: 'Collects feedback from readers and aligns new content with their needs.',
          img: 'https://picsum.photos/400/400?random=34',
          alt: 'Portrait of community curator Mateo Giménez'
        }
      ]
    },
    projects: {
      title: 'Recent explorations',
      filters: [
        { id: 'all', label: 'All' },
        { id: 'trends', label: 'Trends' },
        { id: 'budget', label: 'Budget' },
        { id: 'education', label: 'Education' }
      ],
      items: [
        {
          id: 1,
          title: 'Currency sensitivity map',
          description: 'Heatmap connecting ARS segments with USD-linked contracts.',
          category: 'trends',
          image: 'https://picsum.photos/1200/800?random=41',
          alt: 'Visualization showing currency sensitivity map'
        },
        {
          id: 2,
          title: 'Household essentials pulse',
          description:
            'Weekly tracker that compares supermarket baskets against inflation signals.',
          category: 'budget',
          image: 'https://picsum.photos/1200/800?random=42',
          alt: 'Dashboard with household essentials indicators'
        },
        {
          id: 3,
          title: 'Mini-course storyboard',
          description: 'Learning flow aligning videos, worksheets and live check-ins.',
          category: 'education',
          image: 'https://picsum.photos/1200/800?random=43',
          alt: 'Storyboard of financial mini-course content'
        },
        {
          id: 4,
          title: 'Regional inflation radar',
          description: 'Compares regional data to anticipate localized price pressures.',
          category: 'trends',
          image: 'https://picsum.photos/1200/800?random=44',
          alt: 'Chart comparing inflation radar by region'
        }
      ]
    },
    faq: {
      title: 'Preguntas frecuentes',
      items: [
        {
          question: 'Does Tu Progreso Hoy give financial advice?',
          answer:
            'Tu Progreso Hoy is an educational platform with essential data, without direct financial advice. We focus on context so you can reflect and decide responsibly.'
        },
        {
          question: 'How often are ARS/USD figures updated?',
          answer:
            'Rates are refreshed daily with automatic checks plus manual validation to confirm unusual moves or market holidays.'
        },
        {
          question: 'Can I use the charts for presentations?',
          answer:
            'Yes, you can share screenshots or embed links as long as you credit Tu Progreso Hoy and reference the update date.'
        },
        {
          question: 'What is included in the mini-course?',
          answer:
            'The mini-course includes short videos, interactive labs and templates so you can adapt the insights to your own priorities.'
        }
      ]
    },
    blogPreview: {
      title: 'Latest insights',
      posts: [
        {
          title: 'How ARS/USD corridors evolved in the last quarter',
          excerpt:
            'Review the signals that shaped the latest moves and what they mean for weekly planning.',
          image: 'https://picsum.photos/800/600?random=21',
          alt: 'Financial charts showing ARS USD corridors',
          date: 'Apr 12, 2024'
        },
        {
          title: 'Inflation baskets: reading beyond the headline number',
          excerpt:
            'Learn how to interpret category momentum to anticipate everyday impacts.',
          image: 'https://picsum.photos/800/600?random=22',
          alt: 'Illustration of inflation basket categories',
          date: 'Apr 8, 2024'
        },
        {
          title: 'Building routines for responsible money choices',
          excerpt: 'Step-by-step guide to connect data check-ins with personal goals.',
          image: 'https://picsum.photos/800/600?random=23',
          alt: 'Person reviewing financial routine checklist',
          date: 'Apr 3, 2024'
        }
      ]
    },
    ctaSection: {
      title: 'Sigue tendencias, detecta oportunidades y planifica tu futuro financiero',
      subtitle:
        'Join a community that embraces information, reflection and responsible choices.',
      button: 'Join the learning path'
    },
    disclaimer:
      'Plataforma educativa con datos esenciales, sin consejos financieros directos. La información compartida es orientativa y debe contrastarse con asesores independientes.',
    leadForm: {
      title: 'Get free trial lesson',
      description: 'Enter your details to access the first module and receive weekly insights.',
      fields: {
        name: 'Name',
        email: 'Email',
        phone: 'Phone (optional)',
        interest: 'Interest area',
        consent: 'I agree to receive educational communications.'
      },
      interestOptions: [
        { value: '', label: 'Select an option' },
        { value: 'planning', label: 'Household planning' },
        { value: 'business', label: 'Small business context' },
        { value: 'learning', label: 'Personal learning' }
      ],
      submit: 'Request access'
    },
    errors: {
      required: 'This field is required.',
      email: 'Please enter a valid email address.',
      consent: 'Please confirm your consent.'
    },
    success: {
      submitted: 'Form submitted successfully.'
    },
    cookie: {
      title: 'Cookie preferences',
      message: 'We use non-essential cookies to understand navigation and improve content.',
      accept: 'Accept',
      decline: 'Decline'
    },
    popup: {
      title: 'Important notice',
      message: 'We do not provide financial services. No proporcionamos servicios financieros.',
      checkbox: "Don't show again",
      close: 'Understood'
    },
    contact: {
      quickResponse: 'We respond within two working days.',
      callout: 'Reach out for collaborations, data questions or learning support.'
    },
    coursePage: {
      title: 'Mini-course on responsible financial planning',
      intro: 'Finanzas inteligentes para tu futuro con módulos breves y accionables.',
      overview: [
        'Module 1: Understanding ARS/USD signals with calm language.',
        'Module 2: Designing budgets that adapt to inflation waves.',
        'Module 3: Practicing mindful reviews with templates and checklists.'
      ],
      whatYouGet: [
        'Video lessons with subtitles in English and Spanish.',
        'Downloadable worksheets to track data weekly.',
        'Live Q&A sessions to clarify concepts responsibly.'
      ],
      note: 'Enrollment is free and focuses on reflection, not speculation.',
      cta: 'Reserve your seat'
    },
    dataPage: {
      title: 'Data methodology and sources',
      intro: 'Datos confiables para tu presupuesto con controles cruzados permanentes.',
      sections: [
        {
          heading: 'Exchange rate sources',
          body:
            'Combines official central bank releases, blended private quotes and monitored online marketplaces.'
        },
        {
          heading: 'Inflation tracking',
          body:
            'Aligns national statistics with provincial surveys, retail panels and wholesale price leads.'
        },
        {
          heading: 'Quality assurance',
          body:
            'Applies anomaly detection, manual review and transparent change logs for every dataset.'
        }
      ],
      footer: 'Each dataset is timestamped and accompanied by methodology notes.'
    },
    blogPage: {
      title: 'Educational articles',
      intro: 'Discover practical explainers that turn complex news into actionable knowledge.',
      categories: ['Exchange', 'Inflation', 'Planning'],
      callout:
        'De la información al conocimiento: crece tu sabiduría financiera paso a paso.'
    },
    aboutPage: {
      title: 'About Tu Progreso Hoy',
      mission:
        'Our mission is to empower households and small teams with responsible financial knowledge.',
      vision: 'We believe better information leads to better steps and a better future.',
      story: [
        'Born in Buenos Aires, we saw how volatility demanded calm explanations.',
        'We gather economists, educators and communicators to translate data into clarity.',
        'Every resource is built with accessibility, empathy and responsibility in mind.'
      ],
      timeline: [
        { year: '2021', text: 'Started as a weekly newsletter on ARS/USD shifts.' },
        { year: '2022', text: 'Launched visual dashboards and inflation explainers.' },
        {
          year: '2023',
          text: 'Introduced multi-language mini-course for responsible planning.'
        }
      ]
    },
    servicesPage: {
      title: 'Learning paths and resources',
      intro:
        'Choose the combination of dashboards, explainers and guided sessions that works for you.',
      offerings: [
        {
          title: 'Monthly insights pack',
          description:
            'Summary sheets plus deep dives on exchange moves and inflation patterns.'
        },
        {
          title: 'Workshop series',
          description:
            'Interactive sessions that connect data interpretation with practical routines.'
        },
        {
          title: 'Custom data clinics',
          description:
            'One-on-one reviews to tailor indicators to your team or family context.'
        }
      ],
      note: 'All services maintain a strictly educational scope.'
    },
    contactPage: {
      title: 'Contact Tu Progreso Hoy',
      intro:
        'Share your questions, collaboration ideas or feedback. We reply within two working days.',
      form: {
        name: 'Name',
        email: 'Email',
        topic: 'Topic',
        message: 'Message',
        submit: 'Send message'
      },
      topics: [
        { value: '', label: 'Choose a topic' },
        { value: 'press', label: 'Press inquiry' },
        { value: 'partnership', label: 'Partnership idea' },
        { value: 'support', label: 'Product support' }
      ],
      office: 'Office hours: Monday to Friday, 9:00 - 17:00 (ART).',
      success: 'Thanks for reaching out. We will get back to you soon.'
    },
    thankYouPage: {
      title: 'Thank you!',
      intro: 'Your request has been received. Check your inbox for the welcome message.',
      nextSteps: [
        'Add hola@tuprogresohoy.com to your contacts so our emails arrive safely.',
        'Explore the latest insights on the blog while you wait.',
        'Prepare your questions for the live mini-course session.'
      ],
      back: 'Return to Home'
    },
    privacy: {
      title: 'Privacy Policy',
      updated: 'Last updated: April 2024',
      sections: [
        {
          heading: 'Information we collect',
          body:
            'We gather contact details and voluntary preferences to deliver educational materials.'
        },
        {
          heading: 'How we use information',
          body:
            'Data is used to send lessons, updates and surveys that improve our educational offer.'
        },
        {
          heading: 'Your rights',
          body: 'You can request access, correction or deletion of your information at any time.'
        }
      ],
      contact: 'For privacy requests, email privacidad@tuprogresohoy.com.'
    },
    terms: {
      title: 'Terms of Service',
      updated: 'Effective as of April 2024',
      sections: [
        {
          heading: 'Purpose',
          body: 'Tu Progreso Hoy provides educational content and does not offer financial services.'
        },
        {
          heading: 'Usage',
          body: 'Content is for personal or internal business use. Redistribution requires attribution.'
        },
        {
          heading: 'Liability',
          body:
            'Decisions remain your responsibility. Always contrast data with official and independent sources.'
        }
      ],
      acceptance: 'By using our platform you agree to these terms.'
    },
    cookies: {
      title: 'Cookie Policy',
      intro: 'We use cookies to measure engagement and improve educational experiences.',
      sections: [
        {
          heading: 'Essential cookies',
          body: 'Necessary for site functionality and security.'
        },
        {
          heading: 'Analytics cookies',
          body: 'Help us understand which resources are most useful.'
        },
        {
          heading: 'Managing cookies',
          body:
            'You can manage preferences in your browser or through our consent banner.'
        }
      ]
    }
  },
  es: {
    common: {
      siteName: 'Tu Progreso Hoy',
      tagline: 'Finanzas inteligentes para tu futuro',
      description:
        'Plataforma educativa que sigue ARS/USD y la inflación para ayudarte a planificar con contexto responsable.',
      languageToggle: {
        enLabel: 'EN',
        esLabel: 'ES',
        enAria: 'Cambiar idioma del sitio a inglés',
        esAria: 'Cambiar idioma del sitio a español'
      },
      footerTagline: 'Mejores pasos, mejor porvenir',
      contactEmailLabel: 'Correo',
      contactPhoneLabel: 'Teléfono',
      address: 'Buenos Aires, Argentina',
      socialTitle: 'Comunidad'
    },
    nav: {
      home: 'Inicio',
      course: 'Mini-curso',
      data: 'Metodología de datos',
      blog: 'Blog',
      about: 'Quiénes somos',
      services: 'Rutas de aprendizaje',
      contact: 'Contacto',
      privacy: 'Privacidad',
      terms: 'Términos',
      cookies: 'Cookies',
      thankYou: 'Gracias'
    },
    hero: {
      title: 'Finanzas inteligentes para tu futuro',
      subtitle:
        'Análisis claros y datos de mercado para decisiones financieras seguras. Plataforma educativa con datos esenciales, sin consejos financieros directos.',
      highlight: 'Datos confiables para tu presupuesto',
      points: [
        'Datos confiables para tu presupuesto',
        'Decisiones responsables, planes claros',
        'Sabiduría financiera con tendencias',
        'Mejores pasos, mejor porvenir'
      ],
      primaryCta: 'Obtener lección de prueba gratuita',
      secondaryCta: 'Explorar metodología'
    },
    stats: [
      {
        id: 'arsUsd',
        label: 'Referencia ARS a USD (informal)',
        value: 0.0012,
        suffix: '',
        change: '+0,6%',
        helper: 'Actualizado con fuentes mixtas del mercado'
      },
      {
        id: 'inflation',
        label: 'Inflación mensual proyectada',
        value: 18.6,
        suffix: '%',
        change: '-0,4 pts',
        helper: 'Basado en organismos nacionales y privados'
      },
      {
        id: 'budget',
        label: 'Índice de esenciales del hogar',
        value: 64,
        suffix: '/100',
        change: '+3 pts',
        helper: 'Señala variaciones en gastos habituales'
      }
    ],
    metricSummary: 'Sigue tendencias, detecta oportunidades y planifica tu futuro financiero',
    dataVisuals: {
      title: 'Sabiduría financiera con tendencias',
      description:
        'Capas de información que comparan referencias oficiales e informales más canastas inflacionarias para alertar sobre cambios en el poder de compra.',
      items: [
        {
          title: 'Panel multifuente de cambiarias',
          description:
            'Combina publicaciones oficiales, consensos de analistas y promedios alternativos para comparaciones resilientes.'
        },
        {
          title: 'Bandas de impulso inflacionario',
          description:
            'Gráficos que muestran variación proyectada por categoría para detectar aceleraciones o enfriamientos con anticipación.'
        },
        {
          title: 'Simulador de escenarios',
          description:
            'Ajusta expectativas con metas personalizadas y observa el efecto en asignaciones semanales y mensuales.'
        }
      ]
    },
    miniCourse: {
      title: 'Mini-curso: decisiones responsables, planes claros',
      summary:
        'Información confiable que respalda tus elecciones responsables de dinero. De la información al conocimiento: crece tu sabiduría financiera paso a paso.',
      bullets: [
        'Comprende la dinámica ARS/USD sin tecnicismos.',
        'Diseña colchones adaptables frente a picos inflacionarios.',
        'Crea revisiones conscientes para finanzas familiares o de negocio.'
      ],
      cta: 'Comenzar módulo gratuito'
    },
    process: {
      title: 'Ruta de análisis responsable',
      steps: [
        {
          title: 'Contexto sintetizado',
          description:
            'Recibí resúmenes que traducen titulares macro a lenguaje cotidiano.'
        },
        {
          title: 'Exploración de datos',
          description:
            'Interactuá con gráficos y tablas organizadas por temas para conectar señales rápidamente.'
        },
        {
          title: 'Notas de escenario',
          description:
            'Redactá acciones alineadas con umbrales realistas y prioridades personales.'
        },
        {
          title: 'Ajuste continuo',
          description:
            'Revisá mensualmente para confirmar que los planes siguen alineados a tus metas de vida.'
        }
      ]
    },
    servicesSection: {
      title: 'Rutas de aprendizaje',
      description: 'Análisis claros y datos de mercado para decisiones financieras seguras.',
      cards: [
        {
          title: 'Seguimiento cambiario',
          description: 'Informe semanal y toma instantánea intradía para interpretar los movimientos ARS/USD con calma.'
        },
        {
          title: 'Panorama inflacionario',
          description: 'Cronogramas por categoría para comprender cambios en canastas esenciales.'
        },
        {
          title: 'Laboratorios de presupuesto',
          description: 'Guías prácticas que transforman indicadores complejos en rutinas manejables.'
        }
      ]
    },
    testimonials: {
      title: 'Voces de la comunidad',
      items: [
        {
          quote:
            'Los tableros mantienen nuestra planificación basada en hechos y evitan decisiones apresuradas.',
          name: 'Luis P.',
          role: 'Referente barrial'
        },
        {
          quote:
            'Con el mini-curso alineamos prioridades del hogar alrededor de hitos compartidos.',
          name: 'Mariana S.',
          role: 'Emprendedora'
        },
        {
          quote:
            'Agradezco que cada gráfico venga con contexto y lenguaje responsable.',
          name: 'Carolina D.',
          role: 'Estudiante de finanzas'
        }
      ]
    },
    team: {
      title: 'Equipo Tu Progreso Hoy',
      intro: 'Información confiable que respalda tus elecciones responsables de dinero.',
      members: [
        {
          name: 'Valentina Ortiz',
          role: 'Analista económica',
          bio: 'Sintetiza publicaciones oficiales y mediciones independientes para mantener métricas equilibradas.',
          img: 'https://picsum.photos/400/400?random=31',
          alt: 'Retrato de la analista económica Valentina Ortiz'
        },
        {
          name: 'Julián Mercado',
          role: 'Narrador de datos',
          bio: 'Convierte conjuntos complejos en visuales que empoderan decisiones diarias.',
          img: 'https://picsum.photos/400/400?random=32',
          alt: 'Retrato del narrador de datos Julián Mercado'
        },
        {
          name: 'Rocío Álvarez',
          role: 'Diseñadora educativa',
          bio: 'Crea lecciones paso a paso para que cada concepto se transforme en hábito accionable.',
          img: 'https://picsum.photos/400/400?random=33',
          alt: 'Retrato de la diseñadora educativa Rocío Álvarez'
        },
        {
          name: 'Mateo Giménez',
          role: 'Curador comunitario',
          bio: 'Recoge la voz de lectores y alinea nuevos contenidos con sus necesidades.',
          img: 'https://picsum.photos/400/400?random=34',
          alt: 'Retrato del curador comunitario Mateo Giménez'
        }
      ]
    },
    projects: {
      title: 'Exploraciones recientes',
      filters: [
        { id: 'all', label: 'Todas' },
        { id: 'trends', label: 'Tendencias' },
        { id: 'budget', label: 'Presupuesto' },
        { id: 'education', label: 'Educación' }
      ],
      items: [
        {
          id: 1,
          title: 'Mapa de sensibilidad cambiaria',
          description:
            'Mapa de calor que conecta segmentos en ARS con contratos referidos a USD.',
          category: 'trends',
          image: 'https://picsum.photos/1200/800?random=41',
          alt: 'Visualización del mapa de sensibilidad cambiaria'
        },
        {
          id: 2,
          title: 'Pulso de esenciales del hogar',
          description:
            'Tablero semanal que compara canastas de supermercados con señales inflacionarias.',
          category: 'budget',
          image: 'https://picsum.photos/1200/800?random=42',
          alt: 'Dashboard con indicadores de esenciales del hogar'
        },
        {
          id: 3,
          title: 'Storyboard del mini-curso',
          description:
            'Flujo educativo que alinea videos, guías y encuentros en vivo.',
          category: 'education',
          image: 'https://picsum.photos/1200/800?random=43',
          alt: 'Storyboard del contenido del mini-curso'
        },
        {
          id: 4,
          title: 'Radar inflacionario regional',
          description:
            'Compara datos regionales para anticipar presiones de precios localizadas.',
          category: 'trends',
          image: 'https://picsum.photos/1200/800?random=44',
          alt: 'Gráfico comparando radar inflacionario por región'
        }
      ]
    },
    faq: {
      title: 'Preguntas frecuentes',
      items: [
        {
          question: '¿Tu Progreso Hoy brinda asesoramiento financiero?',
          answer:
            'Tu Progreso Hoy es una plataforma educativa con datos esenciales, sin consejos financieros directos. Nos enfocamos en brindar contexto para que puedas reflexionar y decidir con responsabilidad.'
        },
        {
          question: '¿Con qué frecuencia se actualizan las cifras ARS/USD?',
          answer:
            'Las referencias se refrescan diariamente con verificaciones automáticas y revisión manual para confirmar movimientos inusuales o feriados.'
        },
        {
          question: '¿Puedo usar los gráficos en presentaciones?',
          answer:
            'Sí, podés compartir capturas o enlaces siempre que cites a Tu Progreso Hoy e indiques la fecha de actualización.'
        },
        {
          question: '¿Qué incluye el mini-curso?',
          answer:
            'Incluye videos breves, laboratorios interactivos y plantillas para adaptar los aprendizajes a tus prioridades.'
        }
      ]
    },
    blogPreview: {
      title: 'Últimos análisis',
      posts: [
        {
          title: 'Cómo evolucionaron los corredores ARS/USD en el último trimestre',
          excerpt:
            'Repasá las señales que dieron forma a los últimos movimientos y su impacto en la planificación semanal.',
          image: 'https://picsum.photos/800/600?random=21',
          alt: 'Gráficos financieros con corredores ARS USD',
          date: '12 Abr 2024'
        },
        {
          title: 'Canastas inflacionarias: mirar más allá del número titular',
          excerpt:
            'Aprendé a interpretar el impulso por categoría para anticipar efectos cotidianos.',
          image: 'https://picsum.photos/800/600?random=22',
          alt: 'Ilustración de categorías de canasta inflacionaria',
          date: '8 Abr 2024'
        },
        {
          title: 'Crear rutinas para elecciones responsables de dinero',
          excerpt:
            'Guía paso a paso para conectar chequeos de datos con tus metas personales.',
          image: 'https://picsum.photos/800/600?random=23',
          alt: 'Persona revisando lista de control financiera',
          date: '3 Abr 2024'
        }
      ]
    },
    ctaSection: {
      title: 'Sigue tendencias, detecta oportunidades y planifica tu futuro financiero',
      subtitle:
        'Sumate a una comunidad que abraza la información, la reflexión y las decisiones responsables.',
      button: 'Sumarme a la ruta de aprendizaje'
    },
    disclaimer:
      'Plataforma educativa con datos esenciales, sin consejos financieros directos. La información compartida es orientativa y debe contrastarse con asesores independientes.',
    leadForm: {
      title: 'Obtener lección de prueba gratuita',
      description:
        'Dejá tus datos para acceder al primer módulo y recibir actualizaciones semanales.',
      fields: {
        name: 'Nombre',
        email: 'Correo',
        phone: 'Teléfono (opcional)',
        interest: 'Área de interés',
        consent: 'Acepto recibir comunicaciones educativas.'
      },
      interestOptions: [
        { value: '', label: 'Selecciona una opción' },
        { value: 'planning', label: 'Organización del hogar' },
        { value: 'business', label: 'Contexto para negocio' },
        { value: 'learning', label: 'Aprendizaje personal' }
      ],
      submit: 'Solicitar acceso'
    },
    errors: {
      required: 'Este campo es obligatorio.',
      email: 'Ingresá un correo válido.',
      consent: 'Confirmá tu consentimiento.'
    },
    success: {
      submitted: 'Formulario enviado correctamente.'
    },
    cookie: {
      title: 'Preferencias de cookies',
      message:
        'Usamos cookies no esenciales para comprender la navegación y mejorar los contenidos.',
      accept: 'Aceptar',
      decline: 'Rechazar'
    },
    popup: {
      title: 'Aviso importante',
      message: 'We do not provide financial services. No proporcionamos servicios financieros.',
      checkbox: 'No volver a mostrar',
      close: 'Entendido'
    },
    contact: {
      quickResponse: 'Respondemos dentro de dos días hábiles.',
      callout: 'Escribinos para colaboraciones, dudas de datos o apoyo en el aprendizaje.'
    },
    coursePage: {
      title: 'Mini-curso sobre planificación financiera responsable',
      intro: 'Finanzas inteligentes para tu futuro con módulos breves y accionables.',
      overview: [
        'Módulo 1: Comprender señales ARS/USD con lenguaje sereno.',
        'Módulo 2: Diseñar colchones que se adaptan a ondas inflacionarias.',
        'Módulo 3: Practicar revisiones conscientes con plantillas y listas de control.'
      ],
      whatYouGet: [
        'Lecciones en video con subtítulos en inglés y español.',
        'Hojas descargables para seguir datos cada semana.',
        'Sesiones en vivo de preguntas y respuestas para aclarar conceptos con responsabilidad.'
      ],
      note: 'La inscripción es gratuita y se enfoca en reflexión, no en especulación.',
      cta: 'Reservar tu lugar'
    },
    dataPage: {
      title: 'Metodología y fuentes de datos',
      intro: 'Datos confiables para tu presupuesto con controles cruzados permanentes.',
      sections: [
        {
          heading: 'Fuentes cambiarias',
          body:
            'Combina publicaciones del banco central, cotizaciones privadas mixtas y monitoreo de mercados en línea.'
        },
        {
          heading: 'Seguimiento de inflación',
          body:
            'Alinea estadísticas nacionales con relevamientos provinciales, paneles minoristas y señales mayoristas.'
        },
        {
          heading: 'Garantía de calidad',
          body:
            'Aplica detección de anomalías, revisión manual y registros transparentes para cada conjunto de datos.'
        }
      ],
      footer: 'Cada dataset se entrega con sello de tiempo y notas metodológicas.'
    },
    blogPage: {
      title: 'Artículos educativos',
      intro:
        'Descubrí explicaciones prácticas que transforman noticias complejas en conocimiento accionable.',
      categories: ['Cambio', 'Inflación', 'Planificación'],
      callout:
        'De la información al conocimiento: crece tu sabiduría financiera paso a paso.'
    },
    aboutPage: {
      title: 'Quiénes somos',
      mission:
        'Nuestra misión es empoderar hogares y equipos pequeños con conocimiento financiero responsable.',
      vision: 'Creemos que mejor información conduce a mejores pasos y a un mejor porvenir.',
      story: [
        'Nacimos en Buenos Aires al notar que la volatilidad requería explicaciones serenas.',
        'Reunimos a economistas, educadores y comunicadores para traducir datos en claridad.',
        'Cada recurso se construye con accesibilidad, empatía y responsabilidad.'
      ],
      timeline: [
        { year: '2021', text: 'Iniciamos como boletín semanal sobre movimientos ARS/USD.' },
        {
          year: '2022',
          text: 'Lanzamos tableros visuales y explicadores de inflación.'
        },
        {
          year: '2023',
          text: 'Presentamos el mini-curso multilingüe para planificación responsable.'
        }
      ]
    },
    servicesPage: {
      title: 'Rutas de aprendizaje y recursos',
      intro:
        'Elegí la combinación de tableros, explicadores y sesiones guiadas que mejor se adapte a vos.',
      offerings: [
        {
          title: 'Paquete mensual de insights',
          description:
            'Hojas resumen más análisis profundos sobre movimientos cambiarios y patrones inflacionarios.'
        },
        {
          title: 'Serie de talleres',
          description:
            'Encuentros interactivos que conectan interpretación de datos con rutinas prácticas.'
        },
        {
          title: 'Clínicas de datos a medida',
          description:
            'Revisiones uno a uno para adaptar indicadores a tu equipo o entorno familiar.'
        }
      ],
      note: 'Todos los servicios mantienen un alcance estrictamente educativo.'
    },
    contactPage: {
      title: 'Contacto Tu Progreso Hoy',
      intro:
        'Compartí tus consultas, ideas de colaboración o comentarios. Respondemos dentro de dos días hábiles.',
      form: {
        name: 'Nombre',
        email: 'Correo',
        topic: 'Tema',
        message: 'Mensaje',
        submit: 'Enviar mensaje'
      },
      topics: [
        { value: '', label: 'Elegí un tema' },
        { value: 'press', label: 'Consulta de prensa' },
        { value: 'partnership', label: 'Idea de alianza' },
        { value: 'support', label: 'Soporte del producto' }
      ],
      office: 'Horario de atención: lunes a viernes, 9:00 - 17:00 (ART).',
      success: 'Gracias por escribir. Te responderemos muy pronto.'
    },
    thankYouPage: {
      title: '¡Gracias!',
      intro: 'Recibimos tu solicitud. Revisá tu bandeja para el mensaje de bienvenida.',
      nextSteps: [
        'Agregá hola@tuprogresohoy.com a tus contactos para asegurar la entrega.',
        'Visitá el blog mientras esperás la bienvenida.',
        'Prepará tus preguntas para la sesión en vivo del mini-curso.'
      ],
      back: 'Volver al inicio'
    },
    privacy: {
      title: 'Política de Privacidad',
      updated: 'Actualizado: Abril 2024',
      sections: [
        {
          heading: 'Información que recopilamos',
          body:
            'Recopilamos datos de contacto y preferencias voluntarias para entregar materiales educativos.'
        },
        {
          heading: 'Cómo usamos la información',
          body:
            'Los datos se utilizan para enviar lecciones, novedades y encuestas que mejoran nuestra oferta educativa.'
        },
        {
          heading: 'Tus derechos',
          body:
            'Podés solicitar acceso, corrección o eliminación de tu información en cualquier momento.'
        }
      ],
      contact: 'Para solicitudes de privacidad escribí a privacidad@tuprogresohoy.com.'
    },
    terms: {
      title: 'Términos de Servicio',
      updated: 'Vigente desde Abril 2024',
      sections: [
        {
          heading: 'Propósito',
          body:
            'Tu Progreso Hoy provee contenido educativo y no ofrece servicios financieros.'
        },
        {
          heading: 'Uso',
          body:
            'El contenido es para uso personal o interno. La redistribución requiere atribución.'
        },
        {
          heading: 'Responsabilidad',
          body:
            'Las decisiones dependen de vos. Contrastá siempre los datos con fuentes oficiales e independientes.'
        }
      ],
      acceptance: 'Al usar la plataforma aceptás estos términos.'
    },
    cookies: {
      title: 'Política de Cookies',
      intro:
        'Utilizamos cookies para medir interacción y mejorar la experiencia educativa.',
      sections: [
        {
          heading: 'Cookies esenciales',
          body: 'Necesarias para el funcionamiento y la seguridad del sitio.'
        },
        {
          heading: 'Cookies analíticas',
          body:
            'Nos ayudan a comprender qué recursos resultan más útiles.'
        },
        {
          heading: 'Gestión de cookies',
          body:
            'Podés administrar preferencias desde tu navegador o a través de nuestro banner de consentimiento.'
        }
      ]
    }
  }
};

export default translations;