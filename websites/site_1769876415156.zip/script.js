const I18N = {
  en: {
    general: {
      companyName: "danswholesaleplants",
      tagline: "Digital wayfinding research for complex public spaces"
    },
    skipToContent: "Skip to main content",
    nav: {
      home: "Home",
      services: "Services",
      about: "About",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    },
    header: {
      menuToggle: "Open navigation",
      languageToggleLabel: "Language selection",
      language: {
        fr: "FR",
        en: "EN"
      }
    },
    buttons: {
      exploreApproach: "Discover our approach",
      exploreServices: "View services",
      viewCase: "Read more",
      viewAllPosts: "See full article",
      backHome: "Return to homepage",
      contactUs: "Reach our team",
      readPost: "Open post",
      browseInsights: "Browse insights",
      manageCookies: "Manage cookies"
    },
    hero: {
      stat1Label: "Spatial audits",
      stat2Label: "User paths mapped",
      stat3Label: "Interactive nodes"
    },
    home: {
      hero: {
        title: "Spatial orientation systems for intricate Belgian public environments",
        subtitle: "danswholesaleplants analyses pedestrian journeys, interprets digital signage ecosystems, and composes adaptive cartography to sustain intuitive navigation across Brussels landmarks and national infrastructure.",
        button: "Discover our approach",
        metric1: "36 site-wide diagnostics",
        metric2: "412 trajectory scenarios",
        metric3: "128 responsive waypoints",
        imageAlt: "Researchers examining interactive floor plan with layered spatial analytics",
        imageCaption: "Iterative mapping of indoor and outdoor movement networks."
      },
      featured: {
        title: "Research lines and analytical anchors",
        subtitle: "A modular exploration of orientation, digital guidance, and spatial accessibility within dense civic fabrics.",
        cards: {
          one: {
            title: "Indoor navigation diagnostics",
            text: "Data-led assessments of circulation knots, threshold transitions, and micro-decision zones inside multi-level campuses.",
            imageAlt: "Diagram highlighting interior navigation channels with key nodes",
            link: "Read more"
          },
          two: {
            title: "Digital signage ecosystems",
            text: "Cohesive language, screen choreography, and adaptive triggers for live guidance in public infrastructure.",
            imageAlt: "Digital signage wall displaying wayfinding layers",
            link: "Read more"
          },
          three: {
            title: "Cartographic experience design",
            text: "Schematic layering, scale harmonisation, and tactile overlays that enable shared situational awareness.",
            imageAlt: "Architect holding layered cartographic prototype",
            link: "Read more"
          },
          four: {
            title: "Pedestrian forecasting models",
            text: "Predictive flows and corridor saturation modelling to balance accessibility, comfort, and clarity.",
            imageAlt: "Projected heatmap of pedestrian densities over building map",
            link: "Read more"
          }
        }
      },
      recommendations: {
        title: "Recommendations for complex environments",
        subtitle: "Guidelines extracted from transport hubs, administrative buildings, and cultural institutions across Belgium.",
        points: {
          one: {
            title: "Synchronise physical and digital cues",
            text: "Align static iconography, dynamic screens, and mobile layers so users encounter coherent signals regardless of entry channel."
          },
          two: {
            title: "Sequence decisions proactively",
            text: "Position information before stress points, providing orientation anchors prior to bifurcations, lifts, or security thresholds."
          },
          three: {
            title: "Visualise flows continuously",
            text: "Monitor circulation intensities in real time and adapt guidance loops to redirect demand before congestion forms."
          },
          four: {
            title: "Integrate multisensory guidance",
            text: "Combine tonal contrast, acoustic prompts, and tactile surfaces to sustain inclusive navigation for diverse cognitive profiles."
          }
        }
      },
      testimonials: {
        title: "Testimonials from collaborative partners",
        subtitle: "Institutional voices describing the impact of spatial UX interventions.",
        cards: {
          one: {
            quote: "The spatial narrative audit revealed invisible friction points in our civic centre. The resulting guidance hierarchy noticeably reduced hesitation zones.",
            author: "Urban Strategy Unit, City of Brussels"
          },
          two: {
            quote: "Their team dissected how travellers interpret screens versus static diagrams. Our signage refresh now mirrors user logic at every interchange.",
            author: "Mobility Directorate, Charleroi Transport Node"
          },
          three: {
            quote: "The evaluation method created a common vocabulary for designers, facility teams, and accessibility advisors to co-manage a shared experience.",
            author: "Cultural Infrastructure Platform, Flanders"
          }
        }
      },
      insights: {
        title: "Latest orientation insights",
        subtitle: "Selected writing on flux management, interactive mapping, and urban circulation.",
        cards: {
          one: {
            title: "Tracing movement narratives through Brussels civic interiors",
            excerpt: "Longitudinal mapping of overlapping user journeys reveals how micro-decisions aggregate and alter the readability of large-scale spaces.",
            date: "April 2024",
            link: "Read the article"
          },
          two: {
            title: "Designing adaptive signage suites for care campuses",
            excerpt: "Digital directories must anticipate emotional states, diverse literacies, and evolving clinical protocols without overwhelming first-time visitors.",
            date: "March 2024",
            link: "Read the article"
          },
          three: {
            title: "Quantifying accessibility signals in multimodal hubs",
            excerpt: "Accessibility cannot be bolted on; stations demand systemic calibration of lighting, acoustics, and synchronized tactile messaging.",
            date: "February 2024",
            link: "Read the article"
          }
        },
        action: "Explore the full blog"
      }
    },
    services: {
      hero: {
        title: "Orientation services grounded in observational evidence",
        subtitle: "We interpret built environments through trajectory analytics, prototyping digital signage flows, and orchestrating cross-channel guidance layers.",
        imageAlt: "Specialist reviewing wayfinding prototypes in design lab"
      },
      list: {
        title: "Key service streams",
        items: {
          one: {
            title: "Pedestrian mobility analysis",
            text: "Quantifying dwell times, route selections, and behavioural loops within labyrinthine interiors to identify clarity deficits."
          },
          two: {
            title: "Digital signage design",
            text: "Structuring visual hierarchies, motion rhythms, and multilingual messaging for responsive public screens."
          },
          three: {
            title: "Interactive map development",
            text: "Translating complex layouts into intuitive, layered interfaces accessible across kiosks, tablets, and large displays."
          },
          four: {
            title: "Accessibility research",
            text: "Auditing inclusive navigation markers, sensory pathways, and cognitive load within public infrastructures."
          },
          five: {
            title: "Visual guidance consultation",
            text: "Embedding orientation strategies into architectural programmes and urban transformation projects."
          }
        }
      },
      process: {
        title: "Process architecture",
        steps: {
          one: {
            title: "Immersive diagnostics",
            text: "Field observations, video tracking, and participatory journeys capture how real occupants interpret current guidance."
          },
          two: {
            title: "System mapping",
            text: "We align architectural constraints, technological platforms, and user expectations to chart holistic orientation systems."
          },
          three: {
            title: "Scenario prototyping",
            text: "Interactive testing of signage families, mapping layers, and multisensory prompts validates clarity before deployment."
          }
        }
      },
      outcomes: {
        title: "What institutions gain",
        text: "Clearer spatial narratives, decreased detours, smoother modal transfers, and measurable alignment between infrastructure intent and user behaviour."
      }
    },
    about: {
      hero: {
        title: "Cultivating spatial literacy for public infrastructures",
        subtitle: "danswholesaleplants curates multidisciplinary expertise to decode how people read environments and how environments can read people."
      },
      history: {
        title: "Origins and trajectory",
        paragraphs: {
          one: "Founded in Brussels, the practice emerged from collaborations between architects, data scientists, and service designers investigating navigation within federal buildings.",
          two: "Early projects combined analogue signage audits with sensor-based flow monitoring, highlighting the need for a hybrid discipline bridging information design and architecture."
        }
      },
      approach: {
        title: "Approach to orientation UX",
        paragraphs: {
          one: "We frame every assignment as a choreography of signals, thresholds, and behavioural cues. Instead of isolated touchpoints, we weave networks where each sign, light, and sound reinforces a coherent journey.",
          two: "Empirical evidence guides our prototypes: thermal mapping, video ethnography, remote surveys, and participatory workshops supply layered insight into spatial cognition."
        }
      },
      values: {
        title: "Values driving our work",
        items: {
          one: "Empathy for diverse mobilities",
          two: "Evidence-informed experimentation",
          three: "Transparent collaboration with stakeholders",
          four: "Continuous iteration and evaluation"
        }
      },
      team: {
        title: "Interdisciplinary team",
        paragraph: "Our contributors include cartographers, UX writers, sound designers, and accessibility advocates. Together, they convert infrastructural complexity into legible sequences for everyone."
      },
      evolution: {
        title: "Evolving practice",
        paragraph: "Current explorations focus on dynamic signage governance, participatory mapping, and predictive analytics that anticipate shifts in movement patterns across Belgian urban projects."
      }
    },
    blog: {
      hero: {
        title: "Research log on orientation and spatial UX",
        subtitle: "Analytical essays documenting experiments, findings, and frameworks from collaborations across public environments."
      },
      cards: {
        one: {
          title: "Tracing movement narratives through Brussels civic interiors",
          excerpt: "Understanding how micro-decisions aggregate into large-scale circulation patterns within administrative complexes.",
          date: "April 2024"
        },
        two: {
          title: "Designing adaptive signage suites for care campuses",
          excerpt: "Integrating responsive digital touchpoints with calm architectural cues in sensitive care settings.",
          date: "March 2024"
        },
        three: {
          title: "Quantifying accessibility signals in multimodal hubs",
          excerpt: "Measuring the density and clarity of inclusive cues across rail and tram interfaces.",
          date: "February 2024"
        },
        four: {
          title: "Forecasting pedestrian behaviour for seasonal peaks",
          excerpt: "Scenario modelling to anticipate circulation shifts during cultural and civic events.",
          date: "January 2024"
        },
        five: {
          title: "Synthesising tactile pathways with visual storytelling",
          excerpt: "Aligning tactile paving, lighting, and iconography into a single narrative for diverse users.",
          date: "December 2023"
        }
      },
      cta: {
        title: "Looking for a specific theme?",
        subtitle: "Use the site navigation or contact us with your research question."
      }
    },
    posts: {
      post1: {
        title: "Tracing movement narratives through Brussels civic interiors",
        intro: "Large civic interiors often appear orderly on architectural drawings, yet the lived experience of moving through them is far from linear. During a year-long study within Brussels administrative complexes, we mapped how occupants truly navigate corridors, atria, and service zones. The project revealed that orientation hinges on reconciling official programming with the improvised shortcuts, pauses, and detours chosen by everyday users.",
        section1: {
          heading: "Establishing interpretive baselines",
          p1: "We began by collecting journey logs from civil servants, visitors, and maintenance teams. Participants annotated floor plans, photographed confusing nodes, and described the emotions associated with different sequences. These stories exposed inconsistency: lifts described as straightforward on diagrams felt labyrinthine after security, while signage near social services was overwhelmed by ad-hoc notices.",
          p2: "To frame these accounts within measurable evidence, we captured thermal traces of footfall densities over six weeks. Heatmaps highlighted decision bottlenecks, especially where vertical circulation merged with complex cross corridors. Correlating the qualitative notes with heat data helped us prioritise areas where people hesitated, circled back, or clustered around informal helpers."
        },
        section2: {
          subheading: "Sensorial intersections within hybrid corridors",
          p1: "Hybrid corridors connect public counters, workspaces, and semi-private meeting rooms. The mix demands sensitive orientation because noise thresholds, lighting gradients, and privacy expectations shift abruptly. Our observations showed that users relied heavily on ambient cues—daylight direction, material changes, even air temperature—to judge alignment more than on the official signage family.",
          p2: "By layering decibel readings with video snippets, we found that announcements intended for open atria spilled into quiet negotiation zones, prompting people to retreat. We recommended acoustic zoning paired with subtle light bands embedded in the floor, guiding flows while respecting the acoustic needs of adjacent rooms."
        },
        section3: {
          heading: "Planning actionable interventions",
          p1: "Interventions focused on re-sequencing information. Instead of repeating identical directories on every level, we created decision briefs: concise panels tailored to the next set of choices. Each brief combined iconography, directional cues, and reassurance cues describing amenities, enabling visitors to anticipate the next spatial chapter before reaching it.",
          p2: "We also embedded live occupancy indicators into lift lobbies to reduce uncertainty around wait times. The combination of predictive messaging, acoustic adjustments, and narrative panels reduced average wander time by nine minutes, demonstrating that navigation clarity emerges from layered storytelling rather than isolated signage."
        },
        conclusion: "The Brussels study confirmed that spatial orientation is an evolving dialogue between building systems and occupant tactics. By documenting narratives, calibrating sensory cues, and prototyping responsive guidance, civic interiors can grow hospitable without sacrificing complexity."
      },
      post2: {
        title: "Designing adaptive signage suites for care campuses",
        intro: "Care campuses assemble clinics, administrative services, learning centres, and green spaces into sprawling neighbourhoods. Signage must honour clinical sensitivity while accommodating families, staff, and logistics teams. Our exploration across Flemish care campuses sought to harmonise digital directories, printed systems, and architectural markers so people feel oriented and reassured from arrival to exit.",
        section1: {
          heading: "Balancing reassurance with efficiency",
          p1: "First-time visitors often arrive carrying emotional load and limited time. When directional content is terse, it can feel abrupt; when it is verbose, it becomes overwhelming. We prototyped message sets with varying tone, icon density, and reading levels, then evaluated comprehension with 72 participants. The most effective patterns combined concise actions with situational cues, such as describing what to expect after key turns.",
          p2: "Digital kiosks introduced another balancing act. We noticed that lists sorted alphabetically forced anxious visitors to scan every entry. Switching to intent-based categories—appointments, urgent support, amenities, and staff routes—reduced search time significantly. Personalised printouts summarised the chosen path and the emotional tone set by the kiosk remained calm and supportive."
        },
        section2: {
          subheading: "Coordinating spatial narratives across media",
          p1: "Static signs, projection mapping, and window decals operated in silos. We convened architecture, nursing, and facilities teams to write a shared narrative script. Each stage of the journey—arrival, orientation, transit, waiting, and respite—received a purpose statement. Designers translated the script into colour temperatures, typography weights, and audio chimes, ensuring consistency across media.",
          p2: "Wayfinding beacons were layered with daylight-responsive lighting to guide night arrivals without introducing glare. For staff navigating service corridors, back-of-house monitors displayed dynamic updates on lift status and corridor congestion. This backstage visibility helped logistics teams avoid patient flows, keeping public paths calmer and more predictable."
        },
        section3: {
          heading: "Embedding feedback loops",
          p1: "Adaptive signage cannot remain static after installation. We embedded QR codes that collect quick feedback and signal to the operations team when confusion arises. Weekly dashboards summarised recurring questions, enabling micro-adjustments in wording or route recommendations.",
          p2: "After six months, emergency detours were introduced to accommodate renovation works. Because storytelling principles were already in place, temporary signage echoed the established tone and iconography, preventing disruptions from feeling improvised. Visitors reported higher confidence, and staff noted smoother coordination across departments."
        },
        conclusion: "Care campuses need signage that anticipates emotion, translates complex routing into meaningful stories, and remains adaptable. The synthesis of narrative scripts, responsive technology, and continuous listening turns orientation into a compassionate experience."
      },
      post3: {
        title: "Quantifying accessibility signals in multimodal hubs",
        intro: "Transport hubs perform as living organisms: passengers switch between trains, trams, buses, and pedestrian plazas in compressed time windows. Accessibility cannot be addressed by isolated features; it requires systemic calibration. Our audit of Belgian multimodal hubs quantified how accessibility cues overlap, conflict, or disappear when demand surges.",
        section1: {
          heading: "Mapping accessibility densities",
          p1: "We constructed a taxonomy of cues: tactile paving, contrast edges, auditory prompts, haptic interfaces, and human assistance points. Using lidar scans and manual surveys, we measured how often these cues appeared together. Stations with high density provided overlapping guidance, while low-density zones forced users to rely on a single sense.",
          p2: "Temporal data presented another dimension. Cleaning schedules, peak commuting hours, and event nights altered cue availability. For example, temporary retail kiosks frequently covered tactile paths during weekend markets. Highlighting these conflicts allowed operators to reorganise licences and preserve critical guidance."
        },
        section2: {
          subheading: "Synchronising information across modes",
          p1: "Each transport operator maintained its own signage language. Passengers transferring from regional trains to urban trams encountered conflicting icon shapes and colour codes. We facilitated a design lab where the operators co-created a shared visual grammar. The agreement aligned typography, lighting temperature, and icon proportions without erasing brand identity.",
          p2: "Digital announcements were reprogrammed to follow a predictable structure: orientation cue, time cue, and reassurance cue. For visually impaired passengers, haptic bands embedded in handrails pulsed softly when platforms changed. The multimodal narrative became legible even when one channel failed."
        },
        section3: {
          heading: "Evaluating impact through lived experience",
          p1: "Accessibility metrics must extend beyond compliance checklists. We invited passenger councils to rate confidence levels before and after interventions. Confidence improved most where overlapping cues were introduced, validating the density approach.",
          p2: "The audit closed with a governance framework. It assigned accountability for each cue type, set inspection rhythms, and created escalation routes when signals degraded. Stations now operate with a collective awareness that accessibility is a shared, dynamic responsibility."
        },
        conclusion: "By quantifying cue density, harmonising languages, and co-owning governance, multimodal hubs transform accessibility from a static obligation into a resilient system that adapts to daily flux."
      },
      post4: {
        title: "Forecasting pedestrian behaviour for seasonal peaks",
        intro: "Seasonal events in Belgian cities generate dramatic surges of pedestrian activity. Cultural festivals, administrative deadlines, and tourist influxes reshape familiar environments. We developed forecasting models that merge historical counts, event calendars, weather predictions, and sensor feeds to anticipate how flows reconfigure public interiors.",
        section1: {
          heading: "Constructing hybrid datasets",
          p1: "Historical data alone could not predict irregular spikes. We combined archived turnstile counts with anonymised mobile location data and municipal event permits. Machine learning models detected correlations between event type, weather, and dwell time. Rain drove people into interior concourses, while cold spells extended waiting in covered plazas.",
          p2: "The models were enriched with qualitative inputs from facility teams. They described unofficial patterns, such as students using administrative corridors as study spaces during exam weeks. These narratives helped the algorithms assign weight to situational anomalies."
        },
        section2: {
          subheading: "Translating forecasts into orientation strategies",
          p1: "Once forecasts identified pressure points, we prepared adaptive guidance plans. Temporary routes were pre-scripted with signage kits, while digital directories were programmed with scenarios that activate automatically. Staff rosters integrated orientation stewards during predicted peaks, ensuring human support complemented signage.",
          p2: "We also adjusted environmental cues. For expected evening surges, we intensified lighting gradients and reinforced audio prompts. When forecasts suggested families with children, we introduced wayfinding to quiet zones and rest areas."
        },
        section3: {
          heading: "Measuring effectiveness post-event",
          p1: "After each event, we compared predicted dwell times with actual sensor readings. Deviations fed back into the model, sharpening future accuracy. We also surveyed visitors to gauge perceived clarity; many reported smoother transfers and reduced tension.",
          p2: "The forecasting framework transformed event management. Instead of reactive signage, institutions now maintain ready-to-deploy guidance narratives that respect the unique rhythms of seasonal peaks."
        },
        conclusion: "Predictive orientation empowers institutions to pre-empt chaos. By marrying data science with empathetic scenario design, seasonal surges become orchestrated rather than improvised."
      },
      post5: {
        title: "Synthesising tactile pathways with visual storytelling",
        intro: "Inclusive orientation relies on more than adding tactile strips alongside visual maps. Our research in Belgian museums and transport galleries investigated how tactile cues can converse with visual storytelling to create a richly layered guidance narrative.",
        section1: {
          heading: "Decoding tactile semantics",
          p1: "Users with visual impairments described tactile paving as a language with dialects. Inconsistent textures caused confusion. We catalogued existing patterns and co-designed a refined palette with advocacy groups. Each texture was assigned a semantic value—approach, decision, caution—mirrored by specific visual cues.",
          p2: "To maintain coherence, we created a tactile legend accessible via 3D-printed cards at entry points. These cards aligned with digital screens displaying animated loops explaining the same semantics, enabling mixed groups to share understanding."
        },
        section2: {
          subheading: "Harmonising sensory timelines",
          p1: "Visual storytelling often unfolds across large murals or projections, while tactile cues offer immediate guidance underfoot. We synchronised these timelines by embedding subtle lighting pulses along tactile paths, indicating upcoming narrative moments such as artwork clusters or historical milestones.",
          p2: "Audio descriptions were choreographed to trigger when visitors entered designated zones, ensuring that tactile exploration, visual graphics, and soundscapes reinforced one another."
        },
        section3: {
          heading: "Evaluating experiential cohesion",
          p1: "Mixed groups tested the pathways, reporting how confidently they could stay together. Success was highest when tactile cues, visual markers, and narrator prompts referenced the same story beats. Divergence caused groups to fragment.",
          p2: "The project concluded with maintenance guidelines emphasising that tactile storytelling requires continual care. Staff received training on how to inspect textures, recalibrate lighting, and refresh audio loops, safeguarding the integrity of the multisensory narrative."
        },
        conclusion: "When tactile pathways and visual storytelling operate as one narrative, inclusive orientation transcends compliance. Visitors experience enriched, shared journeys through complex environments."
      }
    },
    contact: {
      hero: {
        title: "Connect with the orientation research team",
        subtitle: "We collaborate with institutions seeking deeper insight into spatial navigation, digital signage ecosystems, and inclusive circulation design."
      },
      details: {
        title: "Direct contact lines",
        phoneLabel: "Call coordination office",
        emailLabel: "Write to our research desk",
        addressLabel: "Visit our workspace",
        phone: "+32 2 123 45 67",
        email: "contact@danswholesaleplants.com",
        address: "Rue de la Loi 200, 1040 Brussels, Belgium"
      },
      form: {
        title: "Share your spatial question",
        subtitle: "Outline your environment, challenges, and desired outcomes. We respond within two working days.",
        nameLabel: "Full name",
        namePlaceholder: "Enter your name",
        emailLabel: "Email address",
        emailPlaceholder: "Enter your email",
        organisationLabel: "Organisation",
        organisationPlaceholder: "Institution or department",
        subjectLabel: "Subject",
        subjectPlaceholder: "Topic of your enquiry",
        messageLabel: "Message",
        messagePlaceholder: "Describe the navigation challenge, context, and desired insights",
        submit: "Send message"
      },
      map: {
        title: "Map of our Brussels base",
        caption: "The studio is located within the European district, accessible via Arts-Loi interchange."
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        subtitle: "Clarifications on scope, process, and collaboration formats."
      },
      items: {
        one: {
          question: "Do you produce physical signage?",
          answer: "We focus on research, prototyping, and system orchestration. Fabrication is coordinated with specialised partners once evidence-based specifications are final."
        },
        two: {
          question: "Which environments benefit most from your work?",
          answer: "Transport hubs, administrative complexes, cultural venues, and university campuses with overlapping flows and multilingual audiences gain the greatest value."
        },
        three: {
          question: "How do you gather user evidence?",
          answer: "We combine field observation, journey mapping workshops, sensor analytics, participatory interviews, and accessibility auditing."
        },
        four: {
          question: "Can you integrate with existing digital platforms?",
          answer: "Yes. We review current platforms, data streams, and governance to ensure orientation layers remain maintainable and interoperable."
        },
        five: {
          question: "What is the typical timeframe for a study?",
          answer: "Initial diagnostics can be completed within eight weeks, while comprehensive orientation masterplans for large sites may span several months."
        },
        six: {
          question: "How do you ensure accessibility is embedded?",
          answer: "Accessibility experts participate from the first workshop onward, co-writing guidance principles and testing prototypes with diverse users."
        }
      }
    },
    footer: {
      contactTitle: "Contact references",
      tagline: "Grounding wayfinding strategy in behavioural insight and spatial storytelling.",
      phone: "+32 2 123 45 67 — Contact page",
      email: "contact@danswholesaleplants.com — Contact page",
      address: "Rue de la Loi 200, 1040 Brussels, Belgium",
      cookiePreferences: "Cookie preferences",
      copyright: "© {year} danswholesaleplants. All rights reserved."
    },
    terms: {
      hero: {
        title: "Terms and conditions",
        subtitle: "Conditions governing the informational resources provided on this website."
      },
      sections: {
        s1: {
          title: "1. Purpose",
          text: "These terms define the framework for accessing and using the danswholesaleplants website, which shares research on spatial orientation."
        },
        s2: {
          title: "2. Non-commercial scope",
          text: "Content is offered solely for informational and educational purposes. No sales, transactions, or commercial engagements are conducted."
        },
        s3: {
          title: "3. Intellectual property",
          text: "Texts, visuals, and data visualisations remain the property of danswholesaleplants unless otherwise credited. Reuse requires prior written consent."
        },
        s4: {
          title: "4. Third-party references",
          text: "External links are provided for context. We do not control third-party content and bear no responsibility for their accuracy."
        },
        s5: {
          title: "5. Accuracy of information",
          text: "Research summaries represent our understanding at publication time. Findings may evolve as environments or data change."
        },
        s6: {
          title: "6. User responsibilities",
          text: "Users must evaluate whether the information suits their specific environment. Any implementation remains under their responsibility."
        },
        s7: {
          title: "7. Accessibility commitments",
          text: "We strive to ensure digital accessibility. Feedback on improvements is welcome through the contact form."
        },
        s8: {
          title: "8. Technical availability",
          text: "We aim for continuous availability of the website but do not guarantee uninterrupted access. Maintenance may occur without notice."
        },
        s9: {
          title: "9. Data collection",
          text: "Only minimal analytic data may be collected, as described in the Privacy Policy, to understand readership trends."
        },
        s10: {
          title: "10. Cookie usage",
          text: "Cookies are utilised for necessary functions and optional preferences. Users can manage consent via the cookie banner."
        },
        s11: {
          title: "11. Liability",
          text: "danswholesaleplants is not liable for direct or indirect consequences arising from interpretation or use of the information."
        },
        s12: {
          title: "12. Modifications",
          text: "We may amend these terms to reflect legal requirements or operational updates. Revisions take effect upon publication."
        },
        s13: {
          title: "13. Governing law",
          text: "These terms are governed by Belgian law. Any disputes fall under the jurisdiction of Brussels courts."
        },
        s14: {
          title: "14. Contact",
          text: "Questions regarding these terms can be directed to contact@danswholesaleplants.com."
        }
      }
    },
    privacy: {
      hero: {
        title: "Privacy policy",
        subtitle: "How we process limited data related to website usage."
      },
      sections: {
        s1: {
          title: "1. Data controller",
          text: "danswholesaleplants, Rue de la Loi 200, 1040 Brussels, Belgium, oversees the handling of any personal data linked to this site."
        },
        s2: {
          title: "2. Data collected",
          text: "We collect only data voluntarily submitted through the contact form and aggregated analytics if consented to via cookies."
        },
        s3: {
          title: "3. Purpose of processing",
          text: "Submitted information is used to respond to research enquiries. Analytics help assess readership trends and improve content relevance."
        },
        s4: {
          title: "4. Legal basis",
          text: "Processing is based on consent granted through the form or cookie banner. Consent can be withdrawn at any time."
        },
        s5: {
          title: "5. Storage duration",
          text: "Contact form submissions are retained for a maximum of twelve months. Analytics data is stored according to cookie lifespans."
        },
        s6: {
          title: "6. Data sharing",
          text: "We do not sell or exchange data. Trusted service providers may host the website under confidentiality obligations."
        },
        s7: {
          title: "7. Security",
          text: "Technical measures such as encrypted transport (HTTPS) and access controls protect data against unauthorised access."
        },
        s8: {
          title: "8. User rights",
          text: "Users may request access, correction, deletion, or limitation of their data by emailing contact@danswholesaleplants.com."
        },
        s9: {
          title: "9. Cookies",
          text: "Cookie categories and retention periods are detailed in the Cookies Policy. Preferences can be modified at any time."
        },
        s10: {
          title: "10. Updates",
          text: "This policy may change to reflect legal or operational updates. The publication date indicates the latest revision."
        }
      }
    },
    cookiesPage: {
      hero: {
        title: "Cookies policy",
        subtitle: "Overview of cookies employed on this site and how to control them."
      },
      intro: "Cookies are small text files stored on your device to support key features and improve analytical understanding. You can customise each category through the consent banner.",
      table: {
        headers: {
          name: "Cookie name",
          provider: "Provider",
          type: "Category",
          purpose: "Purpose",
          duration: "Duration"
        },
        rows: {
          one: {
            name: "site_session",
            provider: "danswholesaleplants",
            type: "Necessary",
            purpose: "Preserves language selection and essential session preferences.",
            duration: "1 year"
          },
          two: {
            name: "pref_layout",
            provider: "danswholesaleplants",
            type: "Preferences",
            purpose: "Stores layout choices for reading experience such as font size.",
            duration: "6 months"
          },
          three: {
            name: "analytics_insight",
            provider: "danswholesaleplants",
            type: "Analytics",
            purpose: "Collects anonymised statistics on page views and navigation paths.",
            duration: "13 months"
          },
          four: {
            name: "outreach_context",
            provider: "danswholesaleplants",
            type: "Marketing",
            purpose: "Registers whether outreach banners were viewed to avoid repetition.",
            duration: "3 months"
          }
        }
      },
      controls: "Cookie preferences can be updated at any time via the banner or the footer link."
    },
    refund: {
      hero: {
        title: "Refund policy",
        subtitle: "Clarifying terms regarding the non-commercial nature of our work."
      },
      sections: {
        s1: {
          title: "1. Informational resources only",
          text: "The website provides research insights without any paid services or goods; therefore refunds do not apply."
        },
        s2: {
          title: "2. Contact enquiries",
          text: "Messages sent through the contact form are invitations to dialogue. No contractual obligation or payment is initiated."
        },
        s3: {
          title: "3. Workshop references",
          text: "Any mention of workshops or studies describes past collaborations. They are not for sale via the site."
        },
        s4: {
          title: "4. Downloadable materials",
          text: "If downloadable documents are shared, they are offered free of charge and without exchange of funds."
        },
        s5: {
          title: "5. External partners",
          text: "Partners referenced on the site manage their own terms. danswholesaleplants does not intermediate transactions."
        },
        s6: {
          title: "6. Future engagements",
          text: "Should paid collaborations be discussed offline, dedicated agreements will outline payment and cancellation clauses."
        },
        s7: {
          title: "7. Responsibility",
          text: "Users remain responsible for how they interpret and apply the shared information."
        },
        s8: {
          title: "8. Amendments",
          text: "This policy may evolve if the organisation’s operations change. Updates will appear on this page."
        },
        s9: {
          title: "9. Queries",
          text: "Questions about this policy can be addressed to contact@danswholesaleplants.com."
        },
        s10: {
          title: "10. Jurisdiction",
          text: "Any dispute related to informational usage is subject to Belgian law."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Disclaimer",
        subtitle: "Clarifying limits of responsibility regarding the content provided."
      },
      sections: {
        s1: {
          title: "Informational nature",
          text: "The content reflects research observations and does not constitute professional advice or guarantees of outcome."
        },
        s2: {
          title: "No liability",
          text: "danswholesaleplants declines responsibility for decisions taken solely on the basis of this content."
        },
        s3: {
          title: "External resources",
          text: "Links to external sites are provided for context; we do not endorse or control their information."
        },
        s4: {
          title: "Updates",
          text: "Findings may be revised as projects evolve. Users should verify that information is current before applying it."
        },
        s5: {
          title: "Contact",
          text: "For clarifications, please write to contact@danswholesaleplants.com."
        }
      }
    },
    thankYou: {
      title: "Thank you for your message",
      subtitle: "We have received your enquiry and will respond within two working days.",
      link: "Return to homepage"
    },
    notFound: {
      title: "Page not found",
      description: "The page you are looking for may have been renamed or archived.",
      link: "Back to homepage"
    },
    meta: {
      home: {
        title: "danswholesaleplants — Spatial orientation research in Belgium",
        description: "Insights on digital signage, indoor navigation, cartography, and accessible orientation systems for Belgian public environments."
      },
      services: {
        title: "Services — danswholesaleplants orientation research",
        description: "Overview of analytical services covering pedestrian mobility, digital signage, interactive mapping, accessibility, and visual guidance."
      },
      about: {
        title: "About — danswholesaleplants spatial UX practice",
        description: "Discover the multidisciplinary team exploring orientation, signage ecosystems, and inclusive spatial storytelling."
      },
      blog: {
        title: "Blog — Orientation insights by danswholesaleplants",
        description: "Analytical articles on navigation, signage, accessibility, and pedestrian forecasting in public infrastructures."
      },
      post1: {
        title: "Tracing movement narratives through Brussels civic interiors",
        description: "A deep dive into how users negotiate complex civic interiors and how storytelling improves navigation."
      },
      post2: {
        title: "Designing adaptive signage suites for care campuses",
        description: "Frameworks for harmonising digital directories, signage, and architectural cues in care campuses."
      },
      post3: {
        title: "Quantifying accessibility signals in multimodal hubs",
        description: "Methodology for measuring density and effectiveness of accessibility cues across transport hubs."
      },
      post4: {
        title: "Forecasting pedestrian behaviour for seasonal peaks",
        description: "Predictive orientation techniques for Belgian public spaces during seasonal surges."
      },
      post5: {
        title: "Synthesising tactile pathways with visual storytelling",
        description: "Integrating tactile guidance with visual narratives to elevate inclusive orientation."
      },
      contact: {
        title: "Contact — danswholesaleplants Brussels research office",
        description: "Reach the team to discuss spatial orientation, signage ecosystems, and accessibility research."
      },
      faq: {
        title: "FAQ — danswholesaleplants orientation research",
        description: "Answers to common questions about spatial UX research and collaboration formats."
      },
      terms: {
        title: "Terms and conditions — danswholesaleplants",
        description: "Conditions governing the informational resources provided on this website."
      },
      privacy: {
        title: "Privacy policy — danswholesaleplants",
        description: "How danswholesaleplants processes limited personal data and cookie preferences."
      },
      cookies: {
        title: "Cookies policy — danswholesaleplants",
        description: "Details on cookies used on the site and ways to manage consent."
      },
      refund: {
        title: "Refund policy — danswholesaleplants",
        description: "Statement on the non-commercial scope of danswholesaleplants’ informational website."
      },
      disclaimer: {
        title: "Disclaimer — danswholesaleplants",
        description: "Clarifications on the informational nature of the content provided."
      },
      thankYou: {
        title: "Thank you — danswholesaleplants",
        description: "Confirmation that your message has been received."
      },
      notFound: {
        title: "404 — Page not found",
        description: "The requested page could not be located on danswholesaleplants."
      }
    },
    cookieBanner: {
      title: "Cookie preferences",
      description: "We use cookies to ensure the site functions correctly, remember your preferences, and understand how content is explored.",
      manage: "Manage preferences",
      acceptAll: "Accept all",
      declineAll: "Decline all",
      save: "Save preferences",
      toggles: {
        necessary: "Necessary cookies",
        preferences: "Preference cookies",
        analytics: "Analytics cookies",
        marketing: "Marketing cookies"
      },
      details: {
        necessary: "Required for basic site functionality such as language choice.",
        preferences: "Remember interface adjustments you make while browsing.",
        analytics: "Help us learn how visitors engage with our articles.",
        marketing: "Allow us to display occasional outreach banners."
      }
    },
    feedback: {
      form: {
        sent: "Message sent successfully.",
        error: "Please complete the required fields."
      }
    }
  },
  fr: {
    general: {
      companyName: "danswholesaleplants",
      tagline: "Recherche en signalétique numérique pour espaces publics complexes"
    },
    skipToContent: "Aller au contenu principal",
    nav: {
      home: "Accueil",
      services: "Services",
      about: "À propos",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    },
    header: {
      menuToggle: "Ouvrir la navigation",
      languageToggleLabel: "Sélection de la langue",
      language: {
        fr: "FR",
        en: "EN"
      }
    },
    buttons: {
      exploreApproach: "Découvrir notre approche",
      exploreServices: "Voir les services",
      viewCase: "En savoir plus",
      viewAllPosts: "Voir l’article complet",
      backHome: "Retour à l’accueil",
      contactUs: "Contacter l’équipe",
      readPost: "Ouvrir l’article",
      browseInsights: "Explorer les analyses",
      manageCookies: "Gérer les cookies"
    },
    hero: {
      stat1Label: "Audits spatiaux",
      stat2Label: "Parcours cartographiés",
      stat3Label: "Points interactifs"
    },
    home: {
      hero: {
        title: "Systèmes d’orientation spatiale pour les environnements publics belges complexes",
        subtitle: "danswholesaleplants analyse les parcours piétons, décrypte les écosystèmes de signalétique numérique et compose des cartographies adaptatives pour soutenir une navigation intuitive dans les repères bruxellois et les infrastructures nationales.",
        button: "Découvrir notre approche",
        metric1: "36 diagnostics de site",
        metric2: "412 scénarios de trajectoires",
        metric3: "128 points de guidage",
        imageAlt: "Chercheurs examinant un plan interactif avec analyses spatiales superposées",
        imageCaption: "Cartographie itérative des réseaux de déplacements intérieurs et extérieurs."
      },
      featured: {
        title: "Axes de recherche et ancrages analytiques",
        subtitle: "Exploration modulaire de l’orientation, du guidage numérique et de l’accessibilité dans des tissus civiques denses.",
        cards: {
          one: {
            title: "Diagnostics de navigation intérieure",
            text: "Évaluations basées sur les données des nœuds de circulation, des transitions et des micro-décisions dans les campus multi-niveaux.",
            imageAlt: "Schéma soulignant les axes intérieurs avec nœuds clés",
            link: "En savoir plus"
          },
          two: {
            title: "Écosystèmes de signalétique numérique",
            text: "Langage cohérent, chorégraphie des écrans et déclencheurs adaptatifs pour un guidage en temps réel dans l’infrastructure publique.",
            imageAlt: "Mur de signalétique numérique affichant des couches de guidage",
            link: "En savoir plus"
          },
          three: {
            title: "Design cartographique expérientiel",
            text: "Superposition, harmonisation d’échelles et interfaces tactiles afin de partager une compréhension situationnelle.",
            imageAlt: "Architecte tenant un prototype cartographique stratifié",
            link: "En savoir plus"
          },
          four: {
            title: "Modèles prédictifs piétons",
            text: "Prévision des flux et modélisation des saturations de corridors pour équilibrer accessibilité, confort et lisibilité.",
            imageAlt: "Carte de densités piétonnes projetée sur un plan de bâtiment",
            link: "En savoir plus"
          }
        }
      },
      recommendations: {
        title: "Recommandations pour environnements complexes",
        subtitle: "Principes issus de gares, bâtiments administratifs et institutions culturelles en Belgique.",
        points: {
          one: {
            title: "Synchroniser signaux physiques et numériques",
            text: "Aligner iconographie, écrans dynamiques et couches mobiles pour offrir des repères cohérents quel que soit le canal d’entrée."
          },
          two: {
            title: "Anticiper les décisions clés",
            text: "Positionner l’information avant les points de tension afin de préparer les usagers aux bifurcations, ascenseurs ou contrôles."
          },
          three: {
            title: "Visualiser les flux en continu",
            text: "Suivre les intensités de circulation en temps réel et ajuster les boucles de guidage pour redistribuer la demande avant congestion."
          },
          four: {
            title: "Intégrer un guidage multisensoriel",
            text: "Assembler contrastes, repères sonores et surfaces tactiles pour soutenir une navigation inclusive pour tous les profils cognitifs."
          }
        }
      },
      testimonials: {
        title: "Témoignages de partenaires institutionnels",
        subtitle: "Points de vue sur l’impact des interventions en UX spatiale.",
        cards: {
          one: {
            quote: "L’audit narratif a révélé des points de friction invisibles dans notre centre civique. La hiérarchie de guidage obtenue a réduit les zones d’hésitation.",
            author: "Cellule Stratégie Urbaine, Ville de Bruxelles"
          },
          two: {
            quote: "L’équipe a analysé la manière dont voyageurs lisent écrans et plans. Notre refonte reproduit désormais la logique utilisateur à chaque correspondance.",
            author: "Direction Mobilité, Noeud de Charleroi"
          },
          three: {
            quote: "La méthode d’évaluation a créé un vocabulaire commun pour designers, exploitation et conseillers accessibilité afin de piloter une expérience partagée.",
            author: "Plateforme d’Infrastructures Culturelles, Flandre"
          }
        }
      },
      insights: {
        title: "Derniers éclairages sur l’orientation",
        subtitle: "Sélection d’articles sur la gestion des flux et la cartographie immédiate.",
        cards: {
          one: {
            title: "Suivre les récits de déplacement dans les intérieurs bruxellois",
            excerpt: "La cartographie longitudinale des micro-décisions révèle comment la lisibilité des grands espaces est transformée.",
            date: "Avril 2024",
            link: "Lire l’article"
          },
          two: {
            title: "Composer des suites de signalétique adaptatives pour campus de soins",
            excerpt: "Des répertoires numériques doivent anticiper les états émotionnels et les littératies sans saturer les visiteurs.",
            date: "Mars 2024",
            link: "Lire l’article"
          },
          three: {
            title: "Quantifier les signaux d’accessibilité dans les hubs multimodaux",
            excerpt: "L’accessibilité doit être systémique : éclairage, acoustique et messages tactiles synchronisés.",
            date: "Février 2024",
            link: "Lire l’article"
          }
        },
        action: "Explorer le blog"
      }
    },
    services: {
      hero: {
        title: "Services d’orientation basés sur l’observation",
        subtitle: "Nous interprétons les environnements construits via l’analyse des trajectoires, la conception de signalétiques numériques et l’orchestration de couches de guidage.",
        imageAlt: "Spécialiste observant des prototypes de signalétique dans un atelier"
      },
      list: {
        title: "Principaux axes de services",
        items: {
          one: {
            title: "Analyse de mobilité piétonne",
            text: "Mesure des temps d’arrêt, choix de parcours et boucles comportementales dans les intérieurs labyrinthiques."
          },
          two: {
            title: "Design de signalétique numérique",
            text: "Structuration des hiérarchies visuelles, rythmes animés et messages multilingues pour écrans publics réactifs."
          },
          three: {
            title: "Développement de cartes interactives",
            text: "Transformation des plans complexes en interfaces stratifiées accessibles sur bornes, tablettes et grands formats."
          },
          four: {
            title: "Recherche sur l’accessibilité",
            text: "Audit des repères inclusifs, parcours sensoriels et charge cognitive dans les infrastructures publiques."
          },
          five: {
            title: "Conseil en guidage visuel",
            text: "Intégration de stratégies d’orientation dans les programmes architecturaux et projets urbains en mutation."
          }
        }
      },
      process: {
        title: "Architecture de processus",
        steps: {
          one: {
            title: "Diagnostics immersifs",
            text: "Observations in situ, captations vidéo et parcours participatifs pour comprendre l’interprétation réelle du guidage."
          },
          two: {
            title: "Cartographie des systèmes",
            text: "Alignement des contraintes architecturales, plateformes numériques et attentes usagers pour composer des réseaux d’orientation."
          },
          three: {
            title: "Prototypage de scénarios",
            text: "Tests interactifs des familles de signalétique, couches cartographiques et repères multisensoriels avant déploiement."
          }
        }
      },
      outcomes: {
        title: "Bénéfices pour les institutions",
        text: "Narration spatiale clarifiée, détours réduits, transitions fluides et alignement mesurable entre intentions et usages."
      }
    },
    about: {
      hero: {
        title: "Cultiver la littératie spatiale des infrastructures publiques",
        subtitle: "danswholesaleplants réunit des compétences pluridisciplinaires pour décrypter la lecture des espaces et concevoir des environnements lisibles."
      },
      history: {
        title: "Origines et trajectoire",
        paragraphs: {
          one: "Née à Bruxelles, la pratique résulte de collaborations entre architectes, data scientists et designers de service étudiant la navigation dans les bâtiments fédéraux.",
          two: "Les premiers projets combinaient audits de signalétique analogue et suivi de flux, révélant la nécessité d’une discipline hybride entre design informationnel et architecture."
        }
      },
      approach: {
        title: "Approche de l’UX spatiale",
        paragraphs: {
          one: "Chaque mission est pensée comme une chorégraphie de signaux, seuils et repères comportementaux. Nous tissons des réseaux où signe, lumière et son renforcent un récit cohérent.",
          two: "Les preuves empiriques guident nos prototypes : cartographies thermiques, ethnographies vidéo, enquêtes à distance et ateliers participatifs."
        }
      },
      values: {
        title: "Valeurs fondatrices",
        items: {
          one: "Empathie pour les mobilités diverses",
          two: "Expérimentation fondée sur la preuve",
          three: "Collaboration transparente entre parties prenantes",
          four: "Itération et évaluation continues"
        }
      },
      team: {
        title: "Équipe interdisciplinaire",
        paragraph: "Cartographes, rédacteurs UX, designers sonores et défenseurs de l’accessibilité convertissent la complexité en séquences lisibles pour chacun."
      },
      evolution: {
        title: "Évolutions en cours",
        paragraph: "Les recherches actuelles explorent la gouvernance des signalétiques dynamiques, la cartographie participative et l’analytique prédictive des flux urbains belges."
      }
    },
    blog: {
      hero: {
        title: "Carnet de recherche sur l’orientation et l’UX spatiale",
        subtitle: "Essais analytiques documentant expérimentations, résultats et cadres méthodologiques."
      },
      cards: {
        one: {
          title: "Suivre les récits de déplacement dans les intérieurs bruxellois",
          excerpt: "Comprendre comment les micro-décisions façonnent les circulations dans les complexes administratifs.",
          date: "Avril 2024"
        },
        two: {
          title: "Composer des suites de signalétique adaptatives pour campus de soins",
          excerpt: "Intégrer des points numériques réactifs à une atmosphère architecturale apaisée.",
          date: "Mars 2024"
        },
        three: {
          title: "Quantifier les signaux d’accessibilité dans les hubs multimodaux",
          excerpt: "Mesurer la densité et l’efficacité des repères inclusifs sur les interfaces ferroviaires et tramways.",
          date: "Février 2024"
        },
        four: {
          title: "Anticiper le comportement piéton lors des pics saisonniers",
          excerpt: "Modéliser les scénarios pour prévoir les transformations de circulation lors d’événements.",
          date: "Janvier 2024"
        },
        five: {
          title: "Synthétiser cheminements tactiles et narration visuelle",
          excerpt: "Aligner revêtements tactiles, éclairage et iconographie pour un récit commun.",
          date: "Décembre 2023"
        }
      },
      cta: {
        title: "Vous cherchez un thème précis ?",
        subtitle: "Utilisez la navigation ou contactez-nous pour toute question de recherche."
      }
    },
    posts: {
      post1: {
        title: "Suivre les récits de déplacement dans les intérieurs civiques bruxellois",
        intro: "Les grands intérieurs civiques paraissent ordonnés sur plan, pourtant l’expérience réelle reste loin d’être linéaire. Pendant un an, nous avons cartographié la manière dont occupants et visiteurs évoluent entre couloirs, atriums et zones de service. La démarche a montré que l’orientation dépend de la réconciliation entre programmation officielle et raccourcis improvisés du quotidien.",
        section1: {
          heading: "Établir des lignes de base interprétatives",
          p1: "Nous avons collecté des carnets de parcours auprès d’agents, visiteurs et équipes techniques. Les participants annotaient les plans, photographiaient les nœuds confus et décrivaient leurs ressentis. Ces récits ont révélé des incohérences : des ascenseurs jugés simples sur les schémas devenaient labyrinthiques après la sécurité, et des avis officiels étaient masqués par des affiches improvisées.",
          p2: "Pour relier ces témoignages à des preuves mesurables, nous avons capté des traces thermiques de densité de passage pendant six semaines. Les cartes de chaleur ont mis en évidence des goulots décisionnels, notamment là où la circulation verticale croisait des couloirs transversaux. En croisant notes qualitatives et données thermiques, nous avons priorisé les zones générant hésitations et retours en arrière."
        },
        section2: {
          subheading: "Intersections sensorielles dans les couloirs hybrides",
          p1: "Les couloirs hybrides connectent guichets publics, espaces de travail et salles semi-privées. Le mélange exige un guidage sensible car bruit, lumière et attentes d’intimité changent brusquement. Les observations ont montré que les usagers se fiaient surtout aux indices ambiants — direction de la lumière, matériaux, température — plus qu’à la famille de signalétique officielle.",
          p2: "En superposant mesures acoustiques et extraits vidéo, nous avons constaté que certaines annonces destinées aux atriums envahissaient les zones de négociation calme. Nous avons recommandé des zonages sonores couplés à de fines bandes lumineuses intégrées au sol, afin d’orienter les flux tout en respectant les besoins des espaces adjacents."
        },
        section3: {
          heading: "Planifier des interventions actionnables",
          p1: "Les interventions se sont concentrées sur la séquence d’information. Au lieu de répéter des répertoires identiques à chaque niveau, nous avons conçu des brèves décisionnelles : panneaux concis adaptés à la prochaine série de choix. Chaque brève combinait pictogrammes, indices directionnels et messages rassurants décrivant les commodités à venir.",
          p2: "Nous avons également intégré des indicateurs de fréquentation en temps réel aux halls d’ascenseurs afin de réduire l’incertitude. La combinaison de messages prédictifs, d’ajustements acoustiques et de panneaux narratifs a diminué le temps moyen d’errance de neuf minutes, prouvant que la clarté naît d’un récit stratifié plutôt que d’une signalétique isolée."
        },
        conclusion: "L’étude bruxelloise confirme que l’orientation résulte d’un dialogue mouvant entre systèmes bâtis et tactiques usagers. En documentant les récits, calibrant les indices sensoriels et prototypant des guidages réactifs, les intérieurs civiques deviennent hospitaliers sans perdre leur complexité."
      },
      post2: {
        title: "Composer des suites de signalétique adaptatives pour campus de soins",
        intro: "Les campus de soins rassemblent cliniques, services administratifs, centres d’apprentissage et jardins en véritables quartiers. La signalétique doit soutenir la sensibilité clinique tout en guidant familles, équipes et logistique. Notre exploration en Flandre visait à harmoniser répertoires numériques, systèmes imprimés et marqueurs architecturaux pour instaurer orientation et rassurance.",
        section1: {
          heading: "Équilibrer rassurance et efficacité",
          p1: "Les nouveaux arrivants portent souvent une charge émotionnelle et peu de temps. Des messages trop secs paraissent brusques, des textes trop longs saturent. Nous avons prototypé des séries avec différents tons, densités d’icônes et niveaux de lecture, testées auprès de 72 participants. Les formats les plus performants combinaient actions concises et indices de situation, décrivant ce qui suit après chaque embranchement.",
          p2: "Les bornes numériques représentaient un autre équilibre. Les listes alphabétiques obligeaient à tout parcourir. En adoptant des catégories par intention — rendez-vous, soutien urgent, services, itinéraires internes — le temps de recherche a fortement diminué. Des impressions personnalisées résumaient le parcours choisi tout en conservant un ton calme."
        },
        section2: {
          subheading: "Coordonner le récit spatial entre médias",
          p1: "Panneaux statiques, projections et sérigraphies fonctionnaient en silos. Nous avons réuni architectes, équipes soignantes et services techniques pour écrire un script narratif commun. Chaque étape — arrivée, orientation, transit, attente, ressourcement — recevait un objectif. Les designers ont traduit ce script en températures de couleur, poids typographiques et signaux sonores.",
          p2: "Les balises de guidage ont été superposées à un éclairage sensible au jour pour accompagner les arrivées nocturnes sans créer d’éblouissement. Pour les équipes naviguant en coulisses, des écrans internes affichaient l’état des ascenseurs et la densité des couloirs, évitant l’interférence avec le public."
        },
        section3: {
          heading: "Installer des boucles de rétroaction",
          p1: "Une signalétique adaptative doit évoluer. Nous avons intégré des QR codes recueillant des retours rapides afin de signaler toute incompréhension. Des tableaux de bord hebdomadaires résumaient les questions récurrentes pour ajuster formulations ou recommandations de parcours.",
          p2: "Six mois plus tard, des déviations d’urgence ont été instaurées durant des travaux. Grâce aux principes narratifs, la signalisation temporaire reprenait ton et iconographie établis, évitant la sensation d’improvisation. Les visiteurs ont exprimé davantage de confiance et les équipes ont constaté une meilleure coordination."
        },
        conclusion: "Les campus de soins demandent une signalétique qui anticipe l’émotion, traduit la complexité et reste modulable. Script narratif, technologie réactive et écoute continue transforment l’orientation en expérience attentive."
      },
      post3: {
        title: "Quantifier les signaux d’accessibilité dans les hubs multimodaux",
        intro: "Les hubs de transport fonctionnent comme des organismes : voyageurs et passants combinent trains, trams, bus et espaces piétons en un temps réduit. L’accessibilité ne peut se limiter à des dispositifs isolés ; elle exige une calibration systémique. Notre audit des hubs belges a quantifié la manière dont les repères inclusifs se superposent, se contredisent ou disparaissent lors des pics.",
        section1: {
          heading: "Cartographier la densité des repères",
          p1: "Nous avons établi un inventaire des repères : bandes tactiles, contrastes, annonces sonores, interfaces haptiques et points d’assistance humaine. À l’aide de scans lidar et de relevés manuels, nous avons mesuré leur co-présence. Les stations fortement dotées proposaient un guidage redondant, tandis que les zones faibles imposaient un seul canal.",
          p2: "La temporalité a ajouté une dimension. Nettoyages, pointe de navetteurs et soirées festives modifiaient la disponibilité des repères. Par exemple, des kiosques temporaires recouvraient souvent les bandes tactiles le week-end. Mettre ces conflits en lumière a permis de réorganiser les licences commerciales."
        },
        section2: {
          subheading: "Synchroniser l’information entre modes",
          p1: "Chaque opérateur possédait sa propre grammaire graphique. Les passagers passant du train régional au tram urbain faisaient face à des icônes divergentes. Nous avons animé un laboratoire où les opérateurs ont co-créé un vocabulaire visuel commun, alignant typographie, température lumineuse et proportions sans effacer leur identité.",
          p2: "Les annonces numériques ont été reprogrammées selon une structure constante : repère d’orientation, repère temporel, repère rassurant. Pour les voyageurs malvoyants, des bandes haptiques intégrées aux rampes vibraient doucement lors d’un changement de quai. Le récit multimodal restait lisible même si un canal était indisponible."
        },
        section3: {
          heading: "Évaluer l’impact par l’expérience vécue",
          p1: "Les indicateurs d’accessibilité doivent dépasser les listes de conformité. Nous avons invité des conseils de voyageurs à mesurer leur confiance avant et après interventions. Les progrès les plus nets apparaissaient là où les repères se superposaient, confirmant l’approche par densité.",
          p2: "L’audit a abouti à un cadre de gouvernance attribuant une responsabilité à chaque famille de repères, définissant des rythmes d’inspection et un circuit d’escalade. Les stations opèrent désormais avec la conscience partagée que l’accessibilité est un système vivant."
        },
        conclusion: "En quantifiant la densité des indices, en harmonisant les langages et en partageant la gouvernance, les hubs multimodaux transforment l’accessibilité en dispositif résilient."
      },
      post4: {
        title: "Anticiper le comportement piéton lors des pics saisonniers",
        intro: "Les événements saisonniers belges génèrent de fortes vagues piétonnes. Festivals, échéances administratives et afflux touristiques reconfigurent les lieux familiers. Nous avons développé des modèles de prévision fusionnant historiques, calendriers, météo et capteurs pour anticiper ces transformations.",
        section1: {
          heading: "Construire des jeux de données hybrides",
          p1: "Les historiques seuls ne prévoyaient pas les pics irréguliers. Nous avons combiné passages enregistrés, données anonymisées de mobilité et permis municipaux. Les modèles détectaient des corrélations entre type d’événement, météo et temps d’attente. La pluie poussait vers les concourses intérieurs, tandis que le froid rallongeait la présence dans les galeries couvertes.",
          p2: "Les équipes opérationnelles ont enrichi les modèles par des récits : étudiants révisant dans les couloirs, habitants utilisant des shortcuts. Ces connaissances ont ajusté le poids accordé aux anomalies."
        },
        section2: {
          subheading: "Traduire les prévisions en stratégies de guidage",
          p1: "Une fois les points de pression identifiés, nous avons préparé des plans de guidage adaptatifs. Les parcours temporaires étaient scénarisés avec kits de signalétique, tandis que les répertoires numériques étaient programmés pour s’activer automatiquement. Les plannings intégraient des médiateurs d’orientation lors des pics attendus.",
          p2: "Nous avons ajusté les repères environnementaux : gradients lumineux renforcés pour les soirs d’affluence, messages audio plus présents pour les familles."
        },
        section3: {
          heading: "Mesurer l’efficacité après événement",
          p1: "Après chaque événement, nous avons comparé les temps de parcours prévus et observés. Les écarts alimentaient le modèle, améliorant la précision. Des enquêtes mesuraient la clarté perçue ; la majorité constatait des transferts plus fluides.",
          p2: "Le cadre prédictif a transformé la gestion événementielle. Au lieu d’une signalétique réactive, les institutions disposent désormais de récits prêts à déployer respectant les rythmes saisonniers."
        },
        conclusion: "La prévision des flux permet d’anticiper le désordre. En associant science des données et scénarios empathiques, les pics saisonniers deviennent orchestrés."
      },
      post5: {
        title: "Synthétiser cheminements tactiles et narration visuelle",
        intro: "L’orientation inclusive dépasse l’ajout de bandes tactiles à côté des cartes visuelles. Nos recherches dans des musées et galeries de transport belges ont étudié comment cues tactiles et narration visuelle peuvent dialoguer pour créer un guidage riche.",
        section1: {
          heading: "Décoder la sémantique tactile",
          p1: "Les usagers non-voyants décrivent les bandes tactiles comme une langue aux dialectes. Des textures incohérentes créent de la confusion. Nous avons recensé les patrons existants et co-conçu une palette avec des associations. Chaque texture porte une valeur sémantique — approche, décision, prudence — reflétée par des indices visuels spécifiques.",
          p2: "Pour assurer la cohérence, nous avons créé une légende tactile via cartes imprimées en 3D aux entrées. Ces cartes étaient synchronisées avec des écrans diffusant des boucles animées expliquant la même sémantique, favorisant une compréhension partagée."
        },
        section2: {
          subheading: "Harmoniser les temporalités sensorielles",
          p1: "La narration visuelle se déploie souvent sur des fresques ou projections, tandis que les repères tactiles offrent un guidage immédiat. Nous avons synchronisé ces temporalités grâce à des pulsations lumineuses discrètes le long des bandes tactiles, signalant les moments du récit tels que regroupements d’œuvres ou jalons historiques.",
          p2: "Les descriptions audio étaient déclenchées à l’entrée de zones dédiées afin que exploration tactile, graphismes visuels et paysages sonores se renforcent mutuellement."
        },
        section3: {
          heading: "Évaluer la cohésion expérientielle",
          p1: "Des groupes mixtes ont testé les parcours et évalué leur capacité à rester ensemble. Le succès était maximal lorsque repères tactiles, visuels et audio faisaient référence aux mêmes séquences. Toute divergence provoquait un éclatement.",
          p2: "Le projet s’est terminé par un guide de maintenance rappelant que la narration tactile demande un entretien continu. Les équipes ont été formées pour inspecter textures, recalibrer éclairage et actualiser les boucles audio."
        },
        conclusion: "Lorsque chemins tactiles et narration visuelle agissent comme un seul récit, l’orientation inclusive dépasse la conformité. Les visiteurs vivent des parcours enrichis et partagés."
      }
    },
    contact: {
      hero: {
        title: "Contacter l’équipe de recherche en orientation",
        subtitle: "Nous collaborons avec les institutions qui souhaitent approfondir la navigation spatiale, la signalétique numérique et la circulation inclusive."
      },
      details: {
        title: "Coordonnées directes",
        phoneLabel: "Appeler le bureau de coordination",
        emailLabel: "Écrire au pôle recherche",
        addressLabel: "Nous rendre visite",
        phone: "+32 2 123 45 67",
        email: "contact@danswholesaleplants.com",
        address: "Rue de la Loi 200, 1040 Bruxelles, Belgique"
      },
      form: {
        title: "Partagez votre question spatiale",
        subtitle: "Précisez votre environnement, les enjeux et les résultats attendus. Réponse sous deux jours ouvrés.",
        nameLabel: "Nom complet",
        namePlaceholder: "Indiquez votre nom",
        emailLabel: "Adresse e-mail",
        emailPlaceholder: "Indiquez votre e-mail",
        organisationLabel: "Organisation",
        organisationPlaceholder: "Institution ou service",
        subjectLabel: "Sujet",
        subjectPlaceholder: "Thématique de votre demande",
        messageLabel: "Message",
        messagePlaceholder: "Décrivez le défi de navigation, le contexte et les objectifs souhaités",
        submit: "Envoyer le message"
      },
      map: {
        title: "Carte de notre base bruxelloise",
        caption: "Le studio est situé dans le quartier européen, accessible via l’interchange Arts-Loi."
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        subtitle: "Précisions sur le périmètre, la méthode et les formats de collaboration."
      },
      items: {
        one: {
          question: "Produisez-vous la signalétique physique ?",
          answer: "Nous nous concentrons sur la recherche, le prototypage et l’orchestration du système. La fabrication est confiée à des partenaires spécialisés après validation."
        },
        two: {
          question: "Quels environnements tirent le plus d’enseignements ?",
          answer: "Les hubs de transport, complexes administratifs, lieux culturels et campus universitaires à flux multiples profitent le plus de notre expertise."
        },
        three: {
          question: "Comment collectez-vous les preuves utilisateur ?",
          answer: "Observation de terrain, ateliers de cartographie, analytics de capteurs, entretiens participatifs et audits d’accessibilité."
        },
        four: {
          question: "Pouvez-vous intégrer des plateformes existantes ?",
          answer: "Oui. Nous évaluons plateformes, flux de données et gouvernance pour assurer la maintenabilité des couches d’orientation."
        },
        five: {
          question: "Quel délai pour une étude ?",
          answer: "Un diagnostic initial se réalise en huit semaines, tandis qu’un masterplan complet peut s’étendre sur plusieurs mois."
        },
        six: {
          question: "Comment garantissez-vous l’accessibilité ?",
          answer: "Les experts accessibilité interviennent dès le premier atelier, co-rédigent les principes et testent les prototypes avec des usagers divers."
        }
      }
    },
    footer: {
      contactTitle: "Références de contact",
      tagline: "Ancrer la stratégie de signalétique dans l’observation comportementale et la narration spatiale.",
      phone: "+32 2 123 45 67 — Page contact",
      email: "contact@danswholesaleplants.com — Page contact",
      address: "Rue de la Loi 200, 1040 Bruxelles, Belgique",
      cookiePreferences: "Préférences cookies",
      copyright: "© {year} danswholesaleplants. Tous droits réservés."
    },
    terms: {
      hero: {
        title: "Conditions générales",
        subtitle: "Cadre applicable aux ressources informationnelles proposées sur ce site."
      },
      sections: {
        s1: {
          title: "1. Objet",
          text: "Les présentes conditions encadrent l’accès et l’utilisation du site danswholesaleplants, dédié à la recherche sur l’orientation spatiale."
        },
        s2: {
          title: "2. Portée non commerciale",
          text: "Les contenus sont fournis à des fins d’information et d’étude. Aucune vente ni transaction n’est réalisée via le site."
        },
        s3: {
          title: "3. Propriété intellectuelle",
          text: "Les textes, visuels et datavisualisations demeurent la propriété de danswholesaleplants sauf mention contraire. Toute réutilisation nécessite une autorisation écrite."
        },
        s4: {
          title: "4. Références externes",
          text: "Les liens sortants offrent un contexte. Nous ne contrôlons pas ces contenus et déclinons toute responsabilité quant à leur exactitude."
        },
        s5: {
          title: "5. Exactitude des informations",
          text: "Les synthèses reflètent notre compréhension à la date de publication. Les résultats peuvent évoluer selon les sites ou données."
        },
        s6: {
          title: "6. Responsabilité des utilisateurs",
          text: "Chaque utilisateur évalue la pertinence des informations pour son environnement. Toute mise en œuvre reste sous sa responsabilité."
        },
        s7: {
          title: "7. Engagement accessibilité",
          text: "Nous travaillons à rendre le site accessible. Les retours sont encouragés via le formulaire de contact."
        },
        s8: {
          title: "8. Disponibilité technique",
          text: "Nous visons une disponibilité continue sans la garantir. Des maintenances peuvent survenir sans préavis."
        },
        s9: {
          title: "9. Collecte de données",
          text: "Seules les données minimales décrites dans la Politique de confidentialité peuvent être recueillies pour analyser l’audience."
        },
        s10: {
          title: "10. Utilisation des cookies",
          text: "Les cookies servent aux fonctions essentielles et aux préférences optionnelles. La gestion du consentement se fait via la bannière."
        },
        s11: {
          title: "11. Responsabilité",
          text: "danswholesaleplants n’est pas responsable des conséquences directes ou indirectes de l’usage du contenu."
        },
        s12: {
          title: "12. Modifications",
          text: "Nous pouvons adapter ces conditions selon les exigences légales ou opérationnelles. Les modifications s’appliquent dès leur publication."
        },
        s13: {
          title: "13. Droit applicable",
          text: "Les conditions sont régies par le droit belge. Tout litige relève des tribunaux de Bruxelles."
        },
        s14: {
          title: "14. Contact",
          text: "Toute question relative aux conditions peut être adressée à contact@danswholesaleplants.com."
        }
      }
    },
    privacy: {
      hero: {
        title: "Politique de confidentialité",
        subtitle: "Traitement des données limitées liées à la consultation du site."
      },
      sections: {
        s1: {
          title: "1. Responsable de traitement",
          text: "danswholesaleplants, Rue de la Loi 200, 1040 Bruxelles, Belgique, assure la gestion des éventuelles données personnelles."
        },
        s2: {
          title: "2. Données collectées",
          text: "Seules les données communiquées via le formulaire de contact et les statistiques agrégées avec consentement peuvent être collectées."
        },
        s3: {
          title: "3. Finalité du traitement",
          text: "Les informations servent à répondre aux demandes de recherche. Les statistiques aident à orienter les contenus."
        },
        s4: {
          title: "4. Base légale",
          text: "Le traitement repose sur le consentement obtenu via le formulaire ou la bannière de cookies. Le consentement peut être retiré à tout moment."
        },
        s5: {
          title: "5. Durée de conservation",
          text: "Les messages sont conservés au maximum douze mois. Les données analytiques suivent la durée de vie des cookies."
        },
        s6: {
          title: "6. Partage de données",
          text: "Aucune donnée n’est vendue ni échangée. Des prestataires d’hébergement peuvent y accéder sous obligation de confidentialité."
        },
        s7: {
          title: "7. Sécurité",
          text: "Des mesures techniques comme le transport chiffré (HTTPS) et des contrôles d’accès protègent les données."
        },
        s8: {
          title: "8. Droits des utilisateurs",
          text: "Accès, rectification, suppression ou limitation peuvent être demandés à contact@danswholesaleplants.com."
        },
        s9: {
          title: "9. Cookies",
          text: "Les catégories et durées sont détaillées dans la Politique de cookies. Les préférences sont modifiables à tout moment."
        },
        s10: {
          title: "10. Mise à jour",
          text: "Cette politique peut évoluer. La date de publication signale la dernière révision."
        }
      }
    },
    cookiesPage: {
      hero: {
        title: "Politique de cookies",
        subtitle: "Détail des cookies utilisés et modalités de contrôle."
      },
      intro: "Les cookies sont de petits fichiers texte enregistrés sur votre appareil pour assurer certaines fonctionnalités et améliorer la compréhension analytique. Vous pouvez ajuster chaque catégorie via la bannière de consentement.",
      table: {
        headers: {
          name: "Nom du cookie",
          provider: "Fournisseur",
          type: "Catégorie",
          purpose: "Finalité",
          duration: "Durée"
        },
        rows: {
          one: {
            name: "site_session",
            provider: "danswholesaleplants",
            type: "Nécessaire",
            purpose: "Conserve la sélection de langue et les préférences essentielles de session.",
            duration: "1 an"
          },
          two: {
            name: "pref_layout",
            provider: "danswholesaleplants",
            type: "Préférences",
            purpose: "Enregistre les ajustements d’interface comme la taille de police.",
            duration: "6 mois"
          },
          three: {
            name: "analytics_insight",
            provider: "danswholesaleplants",
            type: "Analyse",
            purpose: "Collecte des statistiques anonymes sur les pages consultées et parcours de lecture.",
            duration: "13 mois"
          },
          four: {
            name: "outreach_context",
            provider: "danswholesaleplants",
            type: "Marketing",
            purpose: "Indique si des bannières d’information ont été vues pour éviter les répétitions.",
            duration: "3 mois"
          }
        }
      },
      controls: "Les préférences peuvent être mises à jour à tout moment via la bannière ou le lien en pied de page."
    },
    refund: {
      hero: {
        title: "Politique de remboursement",
        subtitle: "Précisions sur le caractère non commercial de nos activités."
      },
      sections: {
        s1: {
          title: "1. Ressources informationnelles",
          text: "Le site diffuse des analyses sans proposer de services ou biens payants ; la notion de remboursement ne s’applique pas."
        },
        s2: {
          title: "2. Demandes de contact",
          text: "Les messages envoyés via le formulaire initient un échange uniquement. Aucun engagement contractuel ni paiement n’est généré."
        },
        s3: {
          title: "3. Références d’ateliers",
          text: "Les ateliers mentionnés décrivent des collaborations passées et ne sont pas vendus via le site."
        },
        s4: {
          title: "4. Documents téléchargeables",
          text: "Tout document fourni l’est à titre gracieux et sans contrepartie financière."
        },
        s5: {
          title: "5. Partenaires externes",
          text: "Les partenaires cités gèrent leurs propres conditions. danswholesaleplants n’intervient pas dans d’éventuelles transactions."
        },
        s6: {
          title: "6. Engagements futurs",
          text: "Si des collaborations rémunérées sont discutées hors ligne, des accords dédiés définiront paiements et clauses d’annulation."
        },
        s7: {
          title: "7. Responsabilité",
          text: "Les utilisateurs demeurent responsables de l’interprétation et de l’usage des informations partagées."
        },
        s8: {
          title: "8. Modifications",
          text: "Cette politique peut évoluer si les activités changent. Les mises à jour seront publiées ici."
        },
        s9: {
          title: "9. Questions",
          text: "Pour toute question, merci d’écrire à contact@danswholesaleplants.com."
        },
        s10: {
          title: "10. Juridiction",
          text: "Tout différend relatif à l’usage informatif est soumis au droit belge."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Avertissement",
        subtitle: "Limites de responsabilité concernant les contenus proposés."
      },
      sections: {
        s1: {
          title: "Nature informative",
          text: "Les contenus reflètent des observations de recherche et ne constituent ni recommandation professionnelle ni garantie de résultat."
        },
        s2: {
          title: "Absence de responsabilité",
          text: "danswholesaleplants décline toute responsabilité pour les décisions fondées uniquement sur ces informations."
        },
        s3: {
          title: "Ressources externes",
          text: "Les liens externes sont fournis à titre contextuel ; nous ne les contrôlons pas."
        },
        s4: {
          title: "Mises à jour",
          text: "Les conclusions peuvent évoluer. Il convient de vérifier l’actualité des informations avant usage."
        },
        s5: {
          title: "Contact",
          text: "Pour toute précision, contactez contact@danswholesaleplants.com."
        }
      }
    },
    thankYou: {
      title: "Merci pour votre message",
      subtitle: "Nous avons bien reçu votre demande et répondrons sous deux jours ouvrés.",
      link: "Retour à l’accueil"
    },
    notFound: {
      title: "Page introuvable",
      description: "La page recherchée a peut-être été renommée ou archivée.",
      link: "Retour à l’accueil"
    },
    meta: {
      home: {
        title: "danswholesaleplants — Recherche sur l’orientation spatiale en Belgique",
        description: "Analyses sur la signalétique numérique, la navigation intérieure, la cartographie et l’accessibilité pour les environnements publics belges."
      },
      services: {
        title: "Services — recherche en orientation danswholesaleplants",
        description: "Présentation des services analytiques couvrant mobilité piétonne, signalétique numérique, cartes interactives et accessibilité."
      },
      about: {
        title: "À propos — pratique UX spatiale danswholesaleplants",
        description: "Découvrez l’équipe pluridisciplinaire explorant orientation, signalétique et narration spatiale inclusive."
      },
      blog: {
        title: "Blog — éclairages orientation par danswholesaleplants",
        description: "Articles analytiques sur navigation, signalétique, accessibilité et prévision des flux dans les infrastructures publiques."
      },
      post1: {
        title: "Suivre les récits de déplacement dans les intérieurs civiques bruxellois",
        description: "Analyse détaillée sur la manière dont les usagers négocient les intérieurs complexes et sur l’apport de la narration."
      },
      post2: {
        title: "Composer des suites de signalétique adaptatives pour campus de soins",
        description: "Cadres pour harmoniser répertoires numériques, signalétique et marqueurs architecturaux."
      },
      post3: {
        title: "Quantifier les signaux d’accessibilité dans les hubs multimodaux",
        description: "Méthodologie pour mesurer la densité et l’efficacité des repères inclusifs dans les hubs de transport."
      },
      post4: {
        title: "Anticiper le comportement piéton lors des pics saisonniers",
        description: "Techniques de guidage prédictif pour les espaces publics belges en période de pointe."
      },
      post5: {
        title: "Synthétiser cheminements tactiles et narration visuelle",
        description: "Intégration des guides tactiles et de la narration visuelle pour une orientation inclusive."
      },
      contact: {
        title: "Contact — bureau bruxellois danswholesaleplants",
        description: "Contactez l’équipe pour discuter orientation spatiale, signalétique numérique et accessibilité."
      },
      faq: {
        title: "FAQ — recherche en orientation danswholesaleplants",
        description: "Réponses aux questions fréquentes sur l’UX spatiale et les collaborations."
      },
      terms: {
        title: "Conditions générales — danswholesaleplants",
        description: "Conditions encadrant l’usage des ressources informationnelles du site."
      },
      privacy: {
        title: "Politique de confidentialité — danswholesaleplants",
        description: "Gestion des données personnelles et préférences cookies."
      },
      cookies: {
        title: "Politique de cookies — danswholesaleplants",
        description: "Détails sur les cookies utilisés et les options de consentement."
      },
      refund: {
        title: "Politique de remboursement — danswholesaleplants",
        description: "Déclaration sur le caractère non commercial du site."
      },
      disclaimer: {
        title: "Avertissement — danswholesaleplants",
        description: "Limites et responsabilités relatives au contenu diffusé."
      },
      thankYou: {
        title: "Merci — danswholesaleplants",
        description: "Confirmation de la réception de votre message."
      },
      notFound: {
        title: "404 — Page introuvable",
        description: "La page demandée est indisponible sur danswholesaleplants."
      }
    },
    cookieBanner: {
      title: "Préférences de cookies",
      description: "Nous utilisons des cookies pour assurer le bon fonctionnement du site, mémoriser vos préférences et comprendre l’exploration des contenus.",
      manage: "Gérer les préférences",
      acceptAll: "Tout accepter",
      declineAll: "Tout refuser",
      save: "Enregistrer",
      toggles: {
        necessary: "Cookies nécessaires",
        preferences: "Cookies de préférences",
        analytics: "Cookies d’analyse",
        marketing: "Cookies marketing"
      },
      details: {
        necessary: "Indispensables au fonctionnement du site comme le choix de la langue.",
        preferences: "Mémorisent les ajustements d’interface effectués pendant la navigation.",
        analytics: "Nous aident à comprendre comment les lecteurs parcourent nos articles.",
        marketing: "Permettent d’afficher ponctuellement des bannières d’information."
      }
    },
    feedback: {
      form: {
        sent: "Message envoyé avec succès.",
        error: "Merci de compléter les champs requis."
      }
    }
  }
};

const DEFAULT_LANG = "fr";
const LANGUAGE_KEY = "site_lang";
const COOKIE_KEY = "cookie_consent";

let currentLang = DEFAULT_LANG;

function getStoredLang() {
  const stored = localStorage.getItem(LANGUAGE_KEY);
  return stored && I18N[stored] ? stored : DEFAULT_LANG;
}

function resolveKey(lang, key) {
  return key.split(".").reduce((acc, part) => (acc ? acc[part] : undefined), I18N[lang]) ?? "";
}

function formatValue(value) {
  if (typeof value === "string") {
    return value.replace("{year}", new Date().getFullYear());
  }
  return value;
}

function applyTranslations(lang) {
  const textElements = document.querySelectorAll("[data-i18n]");
  textElements.forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (!key) return;
    const value = formatValue(resolveKey(lang, key));
    if (value !== undefined) {
      el.textContent = value;
    }
  });

  const placeholderElements = document.querySelectorAll("[data-i18n-placeholder]");
  placeholderElements.forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const value = formatValue(resolveKey(lang, key));
    if (value !== undefined) {
      el.setAttribute("placeholder", value);
    }
  });

  const titleEl = document.querySelector("[data-i18n-title]");
  if (titleEl) {
    const key = titleEl.getAttribute("data-i18n-title");
    const value = formatValue(resolveKey(lang, key));
    if (value) {
      document.title = value;
    }
  }

  const metaEl = document.querySelector("[data-i18n-meta]");
  if (metaEl) {
    const key = metaEl.getAttribute("data-i18n-meta");
    const value = formatValue(resolveKey(lang, key));
    if (value) {
      metaEl.setAttribute("content", value);
    }
  }

  const altElements = document.querySelectorAll("[data-i18n-alt]");
  altElements.forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const value = formatValue(resolveKey(lang, key));
    if (value !== undefined) {
      el.setAttribute("alt", value);
    }
  });

  const ariaElements = document.querySelectorAll("[data-i18n-aria-label]");
  ariaElements.forEach((el) => {
    const key = el.getAttribute("data-i18n-aria-label");
    const value = formatValue(resolveKey(lang, key));
    if (value !== undefined) {
      el.setAttribute("aria-label", value);
    }
  });

  document.documentElement.setAttribute("lang", lang);
}

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem(LANGUAGE_KEY, lang);
  applyTranslations(lang);
  updateLanguageButtons(lang);
}

function updateLanguageButtons(lang) {
  const buttons = document.querySelectorAll(".lang-btn");
  buttons.forEach((btn) => {
    if (btn.getAttribute("data-lang") === lang) {
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
    } else {
      btn.classList.remove("active");
      btn.setAttribute("aria-pressed", "false");
    }
  });
}

function initLanguage() {
  const lang = getStoredLang();
  currentLang = lang;
  applyTranslations(lang);
  updateLanguageButtons(lang);
  const langButtons = document.querySelectorAll(".lang-btn");
  langButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const selected = btn.getAttribute("data-lang");
      if (selected && selected !== currentLang) {
        setLang(selected);
        showToast("feedback.form.sent", 2); // subtle confirmation
      }
    });
  });
}

function initNavigation() {
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");
  const languageToggle = document.querySelector(".language-toggle");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("active");
      navLinks.classList.toggle("active");
      if (languageToggle) {
        languageToggle.classList.toggle("active");
      }
    });

    navLinks.addEventListener("click", (event) => {
      if (event.target.tagName.toLowerCase() === "a") {
        navToggle.classList.remove("active");
        navLinks.classList.remove("active");
        if (languageToggle) {
          languageToggle.classList.remove("active");
        }
      }
    });
  }
}

function initAnimations() {
  const fadeElements = document.querySelectorAll("[data-animate]");
  fadeElements.forEach((section) => {
    section.classList.add("fade-element");
  });

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  fadeElements.forEach((section) => observer.observe(section));
}

function showToast(key, durationSeconds = 4.5) {
  const container = document.querySelector(".toast-container");
  if (!container) return;
  const message = formatValue(resolveKey(currentLang, key));
  if (!message) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("fade-out");
  }, (durationSeconds - 1) * 1000);
  setTimeout(() => {
    toast.remove();
  }, durationSeconds * 1000);
}

function initForms() {
  const form = document.querySelector("form[data-form='contact']");
  if (!form) return;
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const requiredFields = form.querySelectorAll("[required]");
    let valid = true;
    requiredFields.forEach((field) => {
      if (!field.value.trim()) {
        valid = false;
      }
    });
    if (!valid) {
      showToast("feedback.form.error");
      return;
    }
    showToast("feedback.form.sent");
    setTimeout(() => {
      form.submit();
    }, 400);
  });
}

function getCookiePreferences() {
  const stored = localStorage.getItem(COOKIE_KEY);
  if (!stored) {
    return null;
  }
  try {
    return JSON.parse(stored);
  } catch (error) {
    return null;
  }
}

function saveCookiePreferences(prefs) {
  localStorage.setItem(COOKIE_KEY, JSON.stringify(prefs));
}

function applyCookiePreferencesToUI(prefs) {
  const toggles = document.querySelectorAll(".cookie-toggle input[type='checkbox']");
  toggles.forEach((input) => {
    const type = input.getAttribute("data-cookie-type");
    if (!type) return;
    if (type === "necessary") {
      input.checked = true;
    } else {
      input.checked = Boolean(prefs[type]);
    }
  });
}

function readPreferencesFromUI() {
  const result = {
    necessary: true,
    preferences: false,
    analytics: false,
    marketing: false
  };
  const toggles = document.querySelectorAll(".cookie-toggle input[type='checkbox']");
  toggles.forEach((input) => {
    const type = input.getAttribute("data-cookie-type");
    if (!type) return;
    result[type] = input.checked;
  });
  return result;
}

function closeCookieBanner() {
  const banner = document.querySelector(".cookie-banner");
  if (banner) {
    banner.classList.remove("visible");
    setTimeout(() => {
      banner.classList.add("hidden");
    }, 350);
  }
}

function openCookieBanner() {
  const banner = document.querySelector(".cookie-banner");
  if (banner) {
    banner.classList.remove("hidden");
    requestAnimationFrame(() => {
      banner.classList.add("visible");
    });
  }
}

function initCookieBanner() {
  const banner = document.querySelector(".cookie-banner");
  if (!banner) return;

  const manageBtn = banner.querySelector("[data-cookie-action='manage']");
  const acceptBtn = banner.querySelector("[data-cookie-action='accept']");
  const declineBtn = banner.querySelector("[data-cookie-action='decline']");
  const saveBtn = banner.querySelector("[data-cookie-action='save']");
  const preferencesPanel = banner.querySelector(".cookie-preferences");
  const footerManage = document.querySelector(".cookie-manage");

  const storedPrefs = getCookiePreferences();
  if (storedPrefs) {
    applyCookiePreferencesToUI(storedPrefs);
    banner.classList.add("hidden");
  } else {
    banner.classList.remove("hidden");
    requestAnimationFrame(() => {
      banner.classList.add("visible");
    });
  }

  if (manageBtn && preferencesPanel) {
    manageBtn.addEventListener("click", () => {
      preferencesPanel.classList.toggle("hidden");
    });
  }

  const toggles = banner.querySelectorAll(".cookie-toggle input[type='checkbox']");
  toggles.forEach((input) => {
    if (input.dataset.cookieType !== "necessary") {
      input.addEventListener("change", () => {
        const prefs = readPreferencesFromUI();
        saveCookiePreferences(prefs);
      });
    }
  });

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      const consent = {
        necessary: true,
        preferences: true,
        analytics: true,
        marketing: true
      };
      saveCookiePreferences(consent);
      applyCookiePreferencesToUI(consent);
      closeCookieBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      const consent = {
        necessary: true,
        preferences: false,
        analytics: false,
        marketing: false
      };
      saveCookiePreferences(consent);
      applyCookiePreferencesToUI(consent);
      closeCookieBanner();
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      const prefs = readPreferencesFromUI();
      saveCookiePreferences(prefs);
      closeCookieBanner();
    });
  }

  if (footerManage) {
    footerManage.addEventListener("click", () => {
      applyCookiePreferencesToUI(getCookiePreferences() || { necessary: true });
      openCookieBanner();
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initNavigation();
  initAnimations();
  initForms();
  initCookieBanner();
});

/* Additional HTML files will follow referencing these styles and scripts. */