document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".nav-links a");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("is-open")) {
          siteNav.classList.remove("is-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const consentKey = "yaigraCookieConsent";

  if (cookieBanner) {
    const savedConsent = localStorage.getItem(consentKey);
    if (!savedConsent) {
      cookieBanner.classList.add("is-active");
    } else {
      cookieBanner.classList.add("is-hidden");
    }

    const hideBanner = (status) => {
      localStorage.setItem(consentKey, status);
      cookieBanner.classList.remove("is-active");
      cookieBanner.classList.add("is-hidden");
    };

    acceptBtn?.addEventListener("click", () => hideBanner("accepted"));
    declineBtn?.addEventListener("click", () => hideBanner("declined"));
  }

  const featureButtons = document.querySelectorAll("[data-feature-button]");
  const featureTitle = document.querySelector("[data-feature-output-title]");
  const featureText = document.querySelector("[data-feature-output]");
  const featureImage = document.querySelector("[data-feature-image]");

  if (featureButtons.length && featureTitle && featureText && featureImage) {
    featureButtons.forEach((button) => {
      button.addEventListener("click", () => {
        featureButtons.forEach((btn) => btn.classList.remove("is-active"));
        button.classList.add("is-active");

        const title = button.getAttribute("data-feature-title");
        const text = button.getAttribute("data-feature-text");
        const image = button.getAttribute("data-feature-image");

        if (title) {
          featureTitle.textContent = title;
        }
        if (text) {
          featureText.textContent = text;
        }
        if (image) {
          featureImage.setAttribute("src", image);
          featureImage.setAttribute("alt", title || "Игровой режим");
        }
      });
    });
  }
});