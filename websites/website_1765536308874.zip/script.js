const COOKIE_KEY = "qbm_cookie_choice";

const hideCookieBanner = (banner) => {
  if (!banner) return;
  banner.classList.remove("is-visible");
  setTimeout(() => banner.setAttribute("hidden", "hidden"), 350);
};

document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector("[data-nav-toggle]");
  const nav = document.querySelector("[data-nav]");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", !expanded);
      nav.classList.toggle("is-open");
    });
  }

  const currentPage = document.body.dataset.page;
  if (currentPage) {
    document.querySelectorAll(".nav-link").forEach((link) => {
      if (link.dataset.page === currentPage) {
        link.classList.add("is-active");
        link.setAttribute("aria-current", "page");
      } else {
        link.classList.remove("is-active");
        link.removeAttribute("aria-current");
      }
    });
  }

  const banner = document.querySelector("[data-cookie-banner]");
  if (banner) {
    const savedChoice = localStorage.getItem(COOKIE_KEY);
    if (!savedChoice) {
      banner.removeAttribute("hidden");
      requestAnimationFrame(() => banner.classList.add("is-visible"));
    }
    const accept = banner.querySelector("[data-cookie-accept]");
    const decline = banner.querySelector("[data-cookie-decline]");

    accept?.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "accepted");
      hideCookieBanner(banner);
    });

    decline?.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "declined");
      hideCookieBanner(banner);
    });
  }

  const slider = document.querySelector("[data-slider]");
  if (slider) {
    const slides = slider.querySelectorAll(".hero-slide");
    const dots = slider.querySelectorAll("[data-slider-dot]");
    let index = 0;
    let timer;

    const activate = (nextIndex) => {
      slides[index]?.classList.remove("is-active");
      dots[index]?.classList.remove("is-active");
      index = nextIndex;
      slides[index]?.classList.add("is-active");
      dots[index]?.classList.add("is-active");
    };

    const start = () => {
      stop();
      timer = setInterval(() => {
        const next = (index + 1) % slides.length;
        activate(next);
      }, 6000);
    };

    const stop = () => timer && clearInterval(timer);

    dots.forEach((dot, dotIndex) => {
      dot.addEventListener("click", () => {
        activate(dotIndex);
        start();
      });
    });

    slider.addEventListener("mouseenter", stop);
    slider.addEventListener("mouseleave", start);

    activate(0);
    start();
  }

  const contactForm = document.querySelector("[data-form-contact]");
  if (contactForm) {
    const status = contactForm.querySelector("[data-form-status]");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (status) {
        status.textContent = "Рахмет! Сіздің өтінішіңіз қабылданды. Біз 24 сағат ішінде хабарласамыз.";
        status.style.color = "#003366";
      }
      contactForm.reset();
    });
  }
});