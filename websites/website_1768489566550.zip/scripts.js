document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            siteNav.classList.toggle('is-active');
            document.body.classList.toggle('nav-open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('is-active')) {
                    siteNav.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                    document.body.classList.remove('nav-open');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('hagersoxqrCookiePreference');
        if (!storedPreference) {
            requestAnimationFrame(() => {
                cookieBanner.classList.add('visible');
            });
        }

        const handlePreference = (preference, href) => {
            localStorage.setItem('hagersoxqrCookiePreference', preference);
            cookieBanner.classList.remove('visible');
            if (href) {
                window.open(href, '_blank', 'noopener,noreferrer');
            }
        };

        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(actionBtn => {
            actionBtn.addEventListener('click', event => {
                event.preventDefault();
                const action = actionBtn.getAttribute('data-cookie-action');
                handlePreference(action, actionBtn.getAttribute('href'));
            });
        });

        const dismissBtn = cookieBanner.querySelector('.cookie-dismiss');
        if (dismissBtn) {
            dismissBtn.addEventListener('click', () => {
                cookieBanner.classList.remove('visible');
            });
        }
    }
});