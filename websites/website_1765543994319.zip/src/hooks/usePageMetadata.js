import { useEffect } from 'react';

const usePageMetadata = ({ title, description }) => {
  useEffect(() => {
    if (title) {
      document.title = `${title} | Imagination Unleashed`;
    }
    if (description) {
      const metaTag = document.querySelector('meta[name="description"]');
      if (metaTag) {
        metaTag.setAttribute('content', description);
      } else {
        const newMeta = document.createElement('meta');
        newMeta.name = 'description';
        newMeta.content = description;
        document.head.appendChild(newMeta);
      }
    }
  }, [title, description]);
};

export default usePageMetadata;