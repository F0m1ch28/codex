import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'imaginationCookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 700);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.message}>
        <strong>Cookies notice:</strong> We use cookies to enhance your experience. By continuing to visit this site you agree to our use of cookies.
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.acceptBtn} onClick={handleAccept}>
          Accept
        </button>
        <Link to="/cookie-policy" className={styles.learnBtn}>
          Learn More
        </Link>
      </div>
    </aside>
  );
};

export default CookieBanner;