import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.content}>
      <div className={styles.brandBlock}>
        <div className={styles.brandTitle}>Imagination Unleashed</div>
        <p className={styles.brandCopy}>
          Curating premium toys that nurture creativity, confidence, and endless wonder for children across the Netherlands.
        </p>
      </div>
      <div className={styles.linkBlock}>
        <h4>Explore</h4>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/categories">Toy Categories</Link></li>
          <li><Link to="/about">About Us</Link></li>
          <li><Link to="/shipping">Shipping</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>
      </div>
      <div className={styles.linkBlock}>
        <h4>Policies</h4>
        <ul>
          <li><Link to="/terms">Terms of Service</Link></li>
          <li><Link to="/privacy">Privacy Policy</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
        </ul>
      </div>
      <div className={styles.linkBlock}>
        <h4>Contact</h4>
        <address className={styles.address}>
          Toy Street 123<br />
          1011 AB Amsterdam<br />
          Netherlands
        </address>
        <a href="tel:+31201234567" className={styles.contactLink}>+31 20 123 4567</a>
        <a href="mailto:info@imaginationplaystore.nl" className={styles.contactLink}>info@imaginationplaystore.nl</a>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <span>© 2023 Imagination Unleashed. All rights reserved.</span>
      <span><a href="https://www.imaginationplaystore.nl" target="_blank" rel="noreferrer">www.imaginationplaystore.nl</a></span>
    </div>
  </footer>
);

export default Footer;