import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isNavOpen, setIsNavOpen] = useState(false);

  const toggleMenu = () => {
    setIsNavOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsNavOpen(false);
  };

  return (
    <header className={styles.header} aria-label="Primary">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.brand} onClick={closeMenu} aria-label="Imagination Unleashed home">
          <span className={styles.logoIcon} aria-hidden="true">✨</span>
          <span className={styles.brandName}>Imagination Unleashed</span>
        </NavLink>

        <button
          className={styles.menuToggle}
          onClick={toggleMenu}
          aria-label="Toggle navigation menu"
          aria-expanded={isNavOpen}
        >
          <span className={styles.menuIcon} />
        </button>

        <nav className={`${styles.nav} ${isNavOpen ? styles.navOpen : ''}`} aria-label="Main navigation">
          <NavLink
            to="/"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Home
          </NavLink>
          <NavLink
            to="/categories"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Toy Categories
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            About Us
          </NavLink>
          <NavLink
            to="/shipping"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Shipping
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            onClick={closeMenu}
          >
            Contact
          </NavLink>
        </nav>

        <div className={styles.cart} aria-hidden="true">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" role="presentation">
            <path
              d="M7 4h-2l-1 2v2h2l3.6 7.59-1.35 2.44C7.16 19.93 7.67 21 8.58 21H19v-2H9.42l.1-.18L10.55 17h7.9c.7 0 1.31-.36 1.64-.92l3.42-6.07L21.16 8H6.21l-.94-2H7V4z"
              fill="currentColor"
            />
          </svg>
        </div>
      </div>
    </header>
  );
};

export default Header;