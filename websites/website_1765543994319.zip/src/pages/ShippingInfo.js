import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './ShippingInfo.module.css';

const ShippingInfo = () => {
  usePageMetadata({
    title: 'Shipping Information',
    description:
      'Learn about Imagination Unleashed delivery options across the Netherlands, including eco packaging, timelines, and tracking details.'
  });

  return (
    <div className={styles.wrapper}>
      <section className={styles.header}>
        <h1>Delivery Throughout the Netherlands</h1>
        <p>
          We partner with trusted Dutch couriers to bring joyful play experiences to every province. From bustling cities to charming coastal towns, our packaging keeps toys safe, colourful, and ready for imaginative adventures.
        </p>
      </section>

      <section className={styles.grid}>
        <article className={styles.card}>
          <h2>Shipping Timeline</h2>
          <ul>
            <li><strong>Amsterdam, Utrecht, Rotterdam, The Hague:</strong> dispatched within 1 business day.</li>
            <li><strong>Rest of the Netherlands:</strong> delivery within 2–3 business days.</li>
            <li><strong>Wadden Islands:</strong> allow an additional business day due to ferry schedules.</li>
          </ul>
        </article>
        <article className={styles.card}>
          <h2>Packaging Promise</h2>
          <p>
            Every order is packed using recyclable materials and reusable cotton wraps. Toys arrive with illustrated play guides tailored to the Dutch curriculum and seasonal play ideas.
          </p>
          <ul>
            <li>Water-based ink tissue paper.</li>
            <li>Protective honeycomb sleeves for delicate parts.</li>
            <li>Personalised card with child&rsquo;s name upon request.</li>
          </ul>
        </article>
        <article className={styles.card}>
          <h2>Tracking & Support</h2>
          <p>
            As soon as your parcel leaves our Amsterdam studio, you receive a track & trace link. Our team monitors each shipment until it reaches your doorstep.
          </p>
          <ul>
            <li>Live updates via email in English and Dutch.</li>
            <li>Delivery window notifications on the morning of arrival.</li>
            <li>Direct WhatsApp support for last-mile adjustments.</li>
          </ul>
        </article>
      </section>

      <section className={styles.extra}>
        <div>
          <h2>Click & Collect in Amsterdam</h2>
          <p>
            Prefer to pick up your parcel? Book a collection slot at our Toy Street 123 studio and enjoy a mini play demo while we prepare your order.
          </p>
        </div>
        <div>
          <h2>Gift Deliveries</h2>
          <p>
            Surprise a loved one anywhere in the Netherlands. We remove invoices, add handwritten cards, and wrap gifts in colourful, recyclable packaging.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <h2>Questions about your parcel?</h2>
        <p>Our support team is available Monday to Saturday, 09:00–18:00 CET.</p>
        <a className="btn" href="/contact">Contact Shipping Support</a>
      </section>
    </div>
  );
};

export default ShippingInfo;