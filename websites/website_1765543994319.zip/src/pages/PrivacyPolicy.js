import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicy = () => {
  usePageMetadata({
    title: 'Privacy Policy',
    description:
      'Understand how Imagination Unleashed collects, uses, and protects personal data for customers across the Netherlands.'
  });

  return (
    <div className={styles.wrapper}>
      <h1>Privacy Policy</h1>
      <p className={styles.updated}>Last updated: 15 January 2024</p>

      <section>
        <h2>1. Introduction</h2>
        <p>
          This Privacy Policy explains how Imagination Unleashed collects and processes personal data through www.imaginationplaystore.nl. We comply with the General Data Protection Regulation (GDPR) and Dutch privacy laws.
        </p>
      </section>

      <section>
        <h2>2. Data We Collect</h2>
        <ul>
          <li>Contact details such as name, email, phone number, and delivery address.</li>
          <li>Order history, preferences, and communications with our team.</li>
          <li>Website usage information through cookies and analytics tools.</li>
        </ul>
      </section>

      <section>
        <h2>3. How We Use Data</h2>
        <p>We use personal data to:</p>
        <ul>
          <li>Process and deliver toy orders across the Netherlands.</li>
          <li>Respond to inquiries and provide play recommendations.</li>
          <li>Send updates about new collections when you opt in.</li>
          <li>Improve our website, services, and logistical planning.</li>
        </ul>
      </section>

      <section>
        <h2>4. Legal Basis</h2>
        <p>
          We process data based on contract fulfilment, legitimate interests in improving services, and consent for marketing communications.
        </p>
      </section>

      <section>
        <h2>5. Data Sharing</h2>
        <p>
          We share limited data with logistics partners, payment providers, and communication platforms strictly for service delivery. Partners are vetted and bound by privacy agreements.
        </p>
      </section>

      <section>
        <h2>6. Retention</h2>
        <p>
          Personal data is retained for as long as necessary to provide services and meet legal obligations. Order information is typically stored for seven years under Dutch tax law.
        </p>
      </section>

      <section>
        <h2>7. Your Rights</h2>
        <p>
          You may request access, correction, deletion, or transfer of your data. You can also withdraw marketing consent at any time. Contact us via info@imaginationplaystore.nl to exercise these rights.
        </p>
      </section>

      <section>
        <h2>8. Cookies</h2>
        <p>
          Our cookie usage is detailed in the Cookie Policy. You can manage preferences via your browser settings.
        </p>
      </section>

      <section>
        <h2>9. Contact</h2>
        <p>
          For privacy inquiries, email info@imaginationplaystore.nl or write to Toy Street 123, 1011 AB Amsterdam, Netherlands.
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicy;