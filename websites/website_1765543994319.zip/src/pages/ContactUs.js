import React, { useState } from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './ContactUs.module.css';

const ContactUs = () => {
  usePageMetadata({
    title: 'Contact Imagination Unleashed',
    description:
      'Get in touch with Imagination Unleashed in Amsterdam for toy recommendations, shipping support, or partnership inquiries.'
  });

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: 'Toy recommendation',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [response, setResponse] = useState(null);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please share your name so we can greet you properly.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'An email address helps us reply promptly.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email.trim())) {
      newErrors.email = 'This email address does not look quite right.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Tell us a bit more about how we can help.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const onChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const onSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      setResponse(null);
      return;
    }
    setResponse('Thank you for your message! Our play experts will respond within one business day.');
    setFormData({
      name: '',
      email: '',
      topic: 'Toy recommendation',
      message: ''
    });
    setErrors({});
  };

  return (
    <div className={styles.wrapper}>
      <section className={styles.info}>
        <h1>Contact Our Play Experts</h1>
        <p>
          Whether you’re planning a memorable birthday surprise, curating a classroom corner, or tracking a parcel, we’re here for you. Visit us, call, or send a message using the form and we will respond swiftly.
        </p>
        <div className={styles.contactGrid}>
          <div>
            <h2>Studio Address</h2>
            <address>
              Toy Street 123<br />
              1011 AB Amsterdam<br />
              Netherlands
            </address>
          </div>
          <div>
            <h2>Business Hours</h2>
            <p>Monday – Saturday: 09:00–18:00 CET</p>
            <p>Sunday: 10:00–16:00 CET</p>
          </div>
          <div>
            <h2>Get in Touch</h2>
            <a href="tel:+31201234567">+31 20 123 4567</a>
            <a href="mailto:info@imaginationplaystore.nl">info@imaginationplaystore.nl</a>
            <p>WhatsApp: +31 20 123 4567</p>
          </div>
        </div>
      </section>

      <section className={styles.formSection} aria-labelledby="contact-form-heading">
        <h2 id="contact-form-heading">Send us a message</h2>
        <form className={styles.form} onSubmit={onSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Your name</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={onChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
              placeholder="e.g., Maaike Janssen"
            />
            {errors.name && <span className={styles.error} id="name-error">{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email address</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={onChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
              placeholder="you@example.nl"
            />
            {errors.email && <span className={styles.error} id="email-error">{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="topic">Topic</label>
            <select id="topic" name="topic" value={formData.topic} onChange={onChange}>
              <option value="Toy recommendation">Toy recommendation</option>
              <option value="Shipping question">Shipping question</option>
              <option value="Partnership inquiry">Partnership inquiry</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div className={styles.field}>
            <label htmlFor="message">How can we help?</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={onChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
              placeholder="Share details about your request..."
            />
            {errors.message && <span className={styles.error} id="message-error">{errors.message}</span>}
          </div>
          <button type="submit" className="btn">Send Message</button>
          {response && <p className={styles.success} role="status">{response}</p>}
        </form>
      </section>
    </div>
  );
};

export default ContactUs;