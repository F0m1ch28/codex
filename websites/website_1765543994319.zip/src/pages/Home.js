import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './Home.module.css';

const Home = () => {
  usePageMetadata({
    title: 'Premium Quality Toys for Kids',
    description:
      'Discover premium, imagination-sparking toys curated for children across the Netherlands. Imagination Unleashed delivers safe, educational, and joyful play essentials.'
  });

  const testimonials = useMemo(
    () => [
      {
        quote:
          'Our daughter’s imagination has blossomed thanks to the storytelling sets. The quality is outstanding and the delivery across Amsterdam was lightning fast.',
        name: 'Sanne de Vries',
        role: 'Parent in Amsterdam',
        avatar: 'https://picsum.photos/200/200?random=11'
      },
      {
        quote:
          'As an early years teacher, I value toys that encourage curiosity. The STEM kits are cleverly designed and inspire the children to ask questions every day.',
        name: 'Lotte Jansen',
        role: 'Teacher in Utrecht',
        avatar: 'https://picsum.photos/200/200?random=12'
      },
      {
        quote:
          'The sensory play bundles are a dream for our toddler. Safe materials, vibrant colours, and such thoughtful packaging made in the Netherlands.',
        name: 'Milan Bakker',
        role: 'Parent in Rotterdam',
        avatar: 'https://picsum.photos/200/200?random=13'
      }
    ],
    []
  );

  const statsConfig = useMemo(
    () => [
      { label: 'Families across NL', end: 1800 },
      { label: 'Curated toy makers', end: 65 },
      { label: 'Eco-friendly collections', end: 42 }
    ],
    []
  );

  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [stats, setStats] = useState(statsConfig.map(() => 0));

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  useEffect(() => {
    const duration = 1300;
    const frameRate = 30;
    const totalFrames = Math.round(duration / (1000 / frameRate));
    let frame = 0;

    const counter = setInterval(() => {
      frame += 1;
      setStats(
        statsConfig.map(({ end }) => Math.round((end * frame) / totalFrames))
      );
      if (frame === totalFrames) {
        clearInterval(counter);
      }
    }, 1000 / frameRate);

    return () => clearInterval(counter);
  }, [statsConfig]);

  const goToTestimonial = (direction) => {
    setActiveTestimonial((prev) => {
      if (direction === 'next') {
        return (prev + 1) % testimonials.length;
      }
      if (direction === 'prev') {
        return (prev - 1 + testimonials.length) % testimonials.length;
      }
      return prev;
    });
  };

  return (
    <div className={styles.home}>
      <section
        className={styles.hero}
        aria-labelledby="hero-heading"
      >
        <div className={styles.heroContent}>
          <h1 id="hero-heading">Premium Quality Toys for Kids</h1>
          <p>
            From Amsterdam to Groningen, Imagination Unleashed delivers carefully curated toys that spark wonder, celebrate learning, and create colourful play moments for every child in the Netherlands.
          </p>
          <div className={styles.heroActions}>
            <Link to="/categories" className="btn">
              Explore Our Toys
            </Link>
            <Link to="/about" className={`btn ${styles.heroSecondary}`}>
              Learn About Our Story
            </Link>
          </div>
          <div className={styles.heroHighlights} role="list">
            <div role="listitem">
              <span className={styles.heroIcon} aria-hidden="true">🛡️</span>
              EN-71 safety compliant
            </div>
            <div role="listitem">
              <span className={styles.heroIcon} aria-hidden="true">🚲</span>
              Designed for Dutch lifestyles
            </div>
            <div role="listitem">
              <span className={styles.heroIcon} aria-hidden="true">🌱</span>
              Sustainable materials
            </div>
          </div>
        </div>
        <div className={styles.heroVisual}>
          <img
            src="https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1000&q=80"
            alt="Children playing with colourful wooden blocks"
          />
        </div>
      </section>

      <section className={styles.values} aria-labelledby="values-heading">
        <h2 id="values-heading" className="section-title">Our Playtime Values</h2>
        <p className="section-subtitle">
          Each toy in our collection is hand-picked to nurture imagination, encourage collaborative play, and meet rigorous European safety standards.
        </p>
        <div className={styles.valueGrid}>
          <article className={styles.valueCard}>
            <div className={styles.valueIcon} aria-hidden="true">
              <svg viewBox="0 0 64 64" role="presentation">
                <path d="M12 24l20-12 20 12v20l-20 12-20-12V24z" fill="#ffe9a0" />
                <path d="M12 24l20 12 20-12" stroke="#475cc7" strokeWidth="3" fill="none" />
              </svg>
            </div>
            <h3>Safe by Design</h3>
            <p>All items meet EN-71 and REACH standards, ensuring safe play for babies, toddlers, and curious school-aged children.</p>
          </article>
          <article className={styles.valueCard}>
            <div className={styles.valueIcon} aria-hidden="true">
              <svg viewBox="0 0 64 64" role="presentation">
                <circle cx="32" cy="32" r="28" fill="#c7f5d9" />
                <path d="M20 38l6 6 18-18" stroke="#1f295a" strokeWidth="4" fill="none" />
              </svg>
            </div>
            <h3>Durable Quality</h3>
            <p>Premium craftsmanship with responsibly sourced wood, organic cotton, and water-based paints built to last through generations.</p>
          </article>
          <article className={styles.valueCard}>
            <div className={styles.valueIcon} aria-hidden="true">
              <svg viewBox="0 0 64 64" role="presentation">
                <rect x="8" y="22" width="48" height="28" rx="6" fill="#ffb5e8" />
                <path d="M16 18h32" stroke="#475cc7" strokeWidth="4" strokeLinecap="round" />
              </svg>
            </div>
            <h3>Creative Learning</h3>
            <p>Interactive play experiences that boost problem solving, language development, and empathy through storytelling.</p>
          </article>
          <article className={styles.valueCard}>
            <div className={styles.valueIcon} aria-hidden="true">
              <svg viewBox="0 0 64 64" role="presentation">
                <path d="M12 36c6 0 10-8 20-8s14 8 20 8 10-4 10-4v20H2V32s4 4 10 4z" fill="#a8e4ff" />
                <circle cx="32" cy="22" r="10" fill="#475cc7" />
              </svg>
            </div>
            <h3>Joyful Community</h3>
            <p>Working closely with Dutch educators and families to keep play authentic, inclusive, and truly joyful.</p>
          </article>
        </div>
      </section>

      <section className={styles.categories} aria-labelledby="categories-heading">
        <h2 id="categories-heading" className="section-title">Featured Categories</h2>
        <p className="section-subtitle">
          Browse our most loved collections, each carefully assembled to support every stage of childhood curiosity.
        </p>
        <div className={styles.categoryGrid}>
          <Link to="/categories" className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1526045478516-99145907023c?auto=format&fit=crop&w=800&q=80"
              alt="Educational toy kits with colourful shapes"
            />
            <div className={styles.categoryBody}>
              <h3>Educational Toys</h3>
              <p>STEM kits, language builders, and Montessori-inspired play companions.</p>
            </div>
          </Link>
          <Link to="/categories" className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1596460107910-9af534c0d9f1?auto=format&fit=crop&w=800&q=80"
              alt="Toddler playing with wooden stacking toy"
            />
            <div className={styles.categoryBody}>
              <h3>Toddler Games</h3>
              <p>Chunky puzzles, sensory boards, and multi-texture discovery sets.</p>
            </div>
          </Link>
          <Link to="/categories" className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&w=800&q=80"
              alt="Children dressed as astronauts imagining space adventures"
            />
            <div className={styles.categoryBody}>
              <h3>Imagination Play</h3>
              <p>Scenic play worlds, costume kits, and storytelling prompts.</p>
            </div>
          </Link>
          <Link to="/categories" className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1522202757854-08883a029ccb?auto=format&fit=crop&w=800&q=80"
              alt="Parent and child playing with colourful blocks together"
            />
            <div className={styles.categoryBody}>
              <h3>Family Game Time</h3>
              <p>Cooperative board games that bring every Dutch household together.</p>
            </div>
          </Link>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-heading">
        <div className={styles.testimonialContainer}>
          <h2 id="testimonials-heading" className="section-title">Parents & Educators Love Us</h2>
          <div className={styles.testimonialSlider}>
            <button
              type="button"
              className={styles.sliderBtn}
              onClick={() => goToTestimonial('prev')}
              aria-label="Previous testimonial"
            >
              ‹
            </button>
            <article className={styles.testimonialCard} aria-live="polite">
              <img
                src={testimonials[activeTestimonial].avatar}
                alt={`${testimonials[activeTestimonial].name} portrait`}
                className={styles.testimonialAvatar}
              />
              <p className={styles.quote}>&ldquo;{testimonials[activeTestimonial].quote}&rdquo;</p>
              <div className={styles.testimonialMeta}>
                <strong>{testimonials[activeTestimonial].name}</strong>
                <span>{testimonials[activeTestimonial].role}</span>
              </div>
            </article>
            <button
              type="button"
              className={styles.sliderBtn}
              onClick={() => goToTestimonial('next')}
              aria-label="Next testimonial"
            >
              ›
            </button>
          </div>
          <div className={styles.dots} role="tablist" aria-label="Testimonials">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why} aria-labelledby="why-heading">
        <h2 id="why-heading" className="section-title">Why Choose Imagination Unleashed?</h2>
        <div className={styles.whyContent}>
          <ul className={styles.whyList}>
            <li>
              <span aria-hidden="true">🎨</span>
              Playful product curation by early years specialists based in the Netherlands.
            </li>
            <li>
              <span aria-hidden="true">🚚</span>
              Reliable delivery to every Dutch province with trackable parcels.
            </li>
            <li>
              <span aria-hidden="true">🧸</span>
              Collaboration with boutique European toy makers committed to ethical production.
            </li>
            <li>
              <span aria-hidden="true">💡</span>
              Enriching play guides accompanying each order to inspire confident learning.
            </li>
          </ul>
          <div className={styles.stats}>
            {statsConfig.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <div className={styles.statNumber}>
                  {stats[index]}
                  <span className={styles.plus}>+</span>
                </div>
                <div className={styles.statLabel}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-heading">
        <div className={styles.ctaContent}>
          <h2 id="cta-heading">Explore Our Joyful Collection</h2>
          <p>
            Ready to reimagine play? Browse our full catalogue of premium toys crafted to nurture imagination, creativity, and confidence at every age.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/categories" className="btn">
              View Toy Categories
            </Link>
            <Link to="/contact" className="btn btn-secondary">
              Ask Our Play Experts
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;