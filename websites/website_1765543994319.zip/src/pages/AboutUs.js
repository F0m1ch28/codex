import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './AboutUs.module.css';

const AboutUs = () => {
  usePageMetadata({
    title: 'About Imagination Unleashed',
    description:
      'Imagination Unleashed is a Netherlands-based online toy store passionate about premium, educational, and sustainable play experiences for children.'
  });

  const team = [
    {
      name: 'Eva Vermeer',
      role: 'Founder & Head Curator',
      bio: 'Eva collaborates with artisan toy makers across Europe to bring imaginative play companions to Dutch families.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Jasper Willems',
      role: 'Play Psychologist',
      bio: 'Jasper specialises in early childhood development and ensures every collection supports confident learning.',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Lina Hofstede',
      role: 'Sustainability Lead',
      bio: 'Lina sources eco-friendly materials and partners with workshops committed to ethical, low-impact production.',
      image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
    }
  ];

  return (
    <div className={styles.wrapper}>
      <section className={styles.hero}>
        <h1>Our Netherlands Play Story</h1>
        <p>
          Imagination Unleashed began in a bright Amsterdam loft where a group of educators, designers, and parents dreamed of a toy store that valued mindful play over fleeting trends. Today, we collaborate with Dutch childcare centres, family concept stores, and artisan makers to deliver premium toys across the Netherlands.
        </p>
      </section>

      <section className={styles.mission} aria-labelledby="mission-heading">
        <div className={styles.missionContent}>
          <h2 id="mission-heading">Play with Purpose</h2>
          <p>
            We believe play is the foundation of every child&rsquo;s emotional, social, and cognitive growth. Our team carefully reviews each toy for sensory richness, storytelling potential, and longevity. We champion small-batch production, natural materials, and inclusive narratives that reflect the diverse families of the Netherlands.
          </p>
          <div className={styles.pillars}>
            <div>
              <span aria-hidden="true">🌍</span>
              Locally inspired, globally minded curation.
            </div>
            <div>
              <span aria-hidden="true">🤝</span>
              Partnerships with educators and therapists.
            </div>
            <div>
              <span aria-hidden="true">🎈</span>
              Wonder-filled experiences in every delivery.
            </div>
          </div>
        </div>
        <div className={styles.missionVisual}>
          <img
            src="https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?auto=format&fit=crop&w=900&q=80"
            alt="Colorful toy store shelves"
          />
        </div>
      </section>

      <section className={styles.teamSection} aria-labelledby="team-heading">
        <h2 id="team-heading">Meet the Play Experts</h2>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={member.name} className={styles.teamPhoto} />
              <div className={styles.teamBody}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.timeline} aria-labelledby="timeline-heading">
        <h2 id="timeline-heading">Milestones Along the Way</h2>
        <div className={styles.timelineList}>
          <div className={styles.timelineItem}>
            <h3>2018</h3>
            <p>Imagination Unleashed opens in Amsterdam, offering curated play boxes for local families.</p>
          </div>
          <div className={styles.timelineItem}>
            <h3>2020</h3>
            <p>Launch of our national delivery service reaching Groningen, Maastricht, and the Wadden Islands.</p>
          </div>
          <div className={styles.timelineItem}>
            <h3>2022</h3>
            <p>Collaboration with Dutch primary schools to design classroom play corners for creative learning.</p>
          </div>
          <div className={styles.timelineItem}>
            <h3>2023</h3>
            <p>Recognised by families nationwide for championing sustainable, inclusive play experiences.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;