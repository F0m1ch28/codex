import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './ToyCategories.module.css';

const ToyCategories = () => {
  usePageMetadata({
    title: 'Toy Categories',
    description:
      'Browse premium toy categories from Imagination Unleashed including educational toys, toddler games, and imaginative playsets delivered across the Netherlands.'
  });

  const categories = [
    {
      name: 'STEM & Logic Builders',
      description:
        'Engineering puzzles, robotics starters, and coding-free logic kits that challenge problem-solving skills for ages 5 and up.',
      items: ['Eco-friendly robotics', 'Magnetic design tiles', 'Dutch canal bridge builders'],
      image: 'https://images.unsplash.com/photo-1527689368864-3a821dbccc34?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Early Sensory Play',
      description:
        'Textured play mats, music shakers, and water-safe stacking toys supporting the earliest stages of play discovery.',
      items: ['Organic cotton cuddle sets', 'High-contrast visual cards', 'Rhythm and movement drums'],
      image: 'https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Creative Arts & Crafting',
      description:
        'Mess-friendly art kits featuring Dutch-inspired palettes, sustainable craft materials, and guided creative prompts.',
      items: ['Canal house collage sets', 'Biodegradable finger paints', 'Story starter craft boxes'],
      image: 'https://images.unsplash.com/photo-1586258937010-1b845de645b0?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Role Play & Story Worlds',
      description:
        'Beautifully detailed play worlds that encourage communication, empathy, and collaborative storytelling sessions.',
      items: ['Wooden market stands', 'Space explorer missions', 'Nature discovery forts'],
      image: 'https://images.unsplash.com/photo-1520986606214-8b456906c813?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Family Game Night',
      description:
        'Cooperative board games and team challenges that bring Dutch households together through shared laughter.',
      items: ['Canal adventure board game', 'Mindful movement cards', 'Story dice in Dutch & English'],
      image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=900&q=80'
    },
    {
      name: 'Outdoor Explorers',
      description:
        'Weather-ready discoveries designed for the dunes, parks, and forests throughout the Netherlands.',
      items: ['Bug discovery backpacks', 'Storm-friendly kites', 'Rainproof treasure maps'],
      image: 'https://images.unsplash.com/photo-1440288736878-766bd5839edb?auto=format&fit=crop&w=900&q=80'
    }
  ];

  return (
    <div className={styles.wrapper}>
      <section className={styles.intro}>
        <h1>Toy Categories</h1>
        <p>
          Discover imaginative collections crafted for every stage of childhood. Each category is curated by our play experts in Amsterdam and delivered quickly to households throughout the Netherlands.
        </p>
      </section>

      <section className={styles.categorySection} aria-label="Toy categories">
        {categories.map((category) => (
          <article key={category.name} className={styles.categoryCard}>
            <div className={styles.imageWrap}>
              <img src={category.image} alt={category.name} />
            </div>
            <div className={styles.categoryBody}>
              <h2>{category.name}</h2>
              <p>{category.description}</p>
              <ul>
                {category.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.support} aria-labelledby="support-heading">
        <h2 id="support-heading">Need personalised guidance?</h2>
        <p>
          Our play consultants are ready to suggest the best combinations for birthdays, classroom corners, and imaginative family moments.
          Tell us about your child&rsquo;s interests and we will curate a custom toy bundle.
        </p>
        <a className="btn" href="/contact">
          Speak with a Play Consultant
        </a>
      </section>
    </div>
  );
};

export default ToyCategories;