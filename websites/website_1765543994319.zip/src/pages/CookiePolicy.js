import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  usePageMetadata({
    title: 'Cookie Policy',
    description:
      'Read how Imagination Unleashed uses cookies to enhance the online toy shopping experience in the Netherlands.'
  });

  return (
    <div className={styles.wrapper}>
      <h1>Cookie Policy</h1>
      <p className={styles.updated}>Last updated: 15 January 2024</p>

      <section>
        <h2>1. What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device to help websites operate efficiently and provide tailored experiences. They cannot be used to run programs or deliver viruses.
        </p>
      </section>

      <section>
        <h2>2. Cookies We Use</h2>
        <ul>
          <li><strong>Essential cookies:</strong> Enable navigation and secure checkout sessions.</li>
          <li><strong>Analytics cookies:</strong> Help us understand how visitors discover our toy collections so we can improve the experience.</li>
          <li><strong>Preference cookies:</strong> Store language and location choices for faster browsing.</li>
        </ul>
      </section>

      <section>
        <h2>3. Managing Cookies</h2>
        <p>
          You can accept or decline cookies through the banner on our site or by adjusting browser settings. Most browsers automatically accept cookies but allow you to modify preferences.
        </p>
      </section>

      <section>
        <h2>4. Third-Party Tools</h2>
        <p>
          We may use trusted analytics and customer service tools that set their own cookies. These partners comply with GDPR and only access information required for their services.
        </p>
      </section>

      <section>
        <h2>5. Updates</h2>
        <p>
          We may update this policy to reflect changes in technology or regulations in the Netherlands or EU. The latest version will always be available on this page.
        </p>
      </section>

      <section>
        <h2>6. Contact</h2>
        <p>
          For questions about cookies, please email info@imaginationplaystore.nl or write to Toy Street 123, 1011 AB Amsterdam, Netherlands.
        </p>
      </section>
    </div>
  );
};

export default CookiePolicy;