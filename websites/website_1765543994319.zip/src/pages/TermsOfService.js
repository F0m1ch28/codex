import React from 'react';
import usePageMetadata from '../hooks/usePageMetadata';
import styles from './TermsOfService.module.css';

const TermsOfService = () => {
  usePageMetadata({
    title: 'Terms of Service',
    description:
      'Review the Imagination Unleashed terms of service covering product information, delivery, and customer responsibilities in the Netherlands.'
  });

  return (
    <div className={styles.wrapper}>
      <h1>Terms of Service</h1>
      <p className={styles.updated}>Last updated: 15 January 2024</p>

      <section>
        <h2>1. Overview</h2>
        <p>
          Imagination Unleashed operates the website www.imaginationplaystore.nl. By visiting our site, engaging with our services, or completing a purchase you accept the following terms. These terms apply to customers located in the Netherlands and any other territories where we deliver.
        </p>
      </section>

      <section>
        <h2>2. Product Information</h2>
        <p>
          We aim to present toy descriptions, materials, and age recommendations accurately. Colours may vary slightly due to monitor calibration. All toys comply with EN-71 and relevant EU directives. If a product does not match its description, please contact us within 14 days of delivery for support.
        </p>
      </section>

      <section>
        <h2>3. Orders & Availability</h2>
        <p>
          Placing an order constitutes an offer to purchase. Confirmation emails acknowledge receipt but do not guarantee availability. We may contact you if an item is no longer available and suggest alternatives or provide a refund.
        </p>
      </section>

      <section>
        <h2>4. Delivery</h2>
        <p>
          We deliver across the Netherlands using trusted couriers. Estimated delivery windows are outlined on our Shipping Information page. Title and risk transfer to you when the parcel is delivered to the provided address.
        </p>
      </section>

      <section>
        <h2>5. Returns</h2>
        <p>
          You may return unopened, unused items within 30 days. Please contact us to initiate a return and obtain instructions. Customised items are non-returnable unless faulty.
        </p>
      </section>

      <section>
        <h2>6. Liability</h2>
        <p>
          We are not liable for indirect or consequential damages arising from product use. Our liability is limited to the amount paid for the relevant order, except where prohibited by Dutch law.
        </p>
      </section>

      <section>
        <h2>7. Customer Responsibilities</h2>
        <p>
          Please follow age recommendations, safety instructions, and supervision guidelines. Inspect toys regularly and remove damaged parts to ensure safe play.
        </p>
      </section>

      <section>
        <h2>8. Governing Law</h2>
        <p>
          These terms are governed by Dutch law. Any disputes will be handled by the competent court in Amsterdam, the Netherlands.
        </p>
      </section>

      <section>
        <h2>9. Contact</h2>
        <p>
          Questions about the terms can be sent to info@imaginationplaystore.nl or by post to Toy Street 123, 1011 AB Amsterdam, Netherlands.
        </p>
      </section>
    </div>
  );
};

export default TermsOfService;