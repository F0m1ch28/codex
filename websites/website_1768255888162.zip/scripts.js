document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookie-banner");
    if (!banner) {
        return;
    }
    const storedChoice = localStorage.getItem("monroewjdxCookieChoice");
    if (storedChoice) {
        banner.classList.add("is-hidden");
        return;
    }
    const buttons = banner.querySelectorAll(".cookie-btn");
    buttons.forEach(function (button) {
        const choice = button.dataset.choice;
        if (choice === "accept" || choice === "decline") {
            button.addEventListener("click", function (event) {
                event.preventDefault();
                localStorage.setItem("monroewjdxCookieChoice", choice);
                banner.classList.add("is-hidden");
            });
        }
    });
});