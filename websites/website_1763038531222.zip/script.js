document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  const scrollTopButton = document.getElementById('scrollTopButton');
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookiesButton = document.getElementById('acceptCookies');
  const yearSpan = document.getElementById('jahr');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen.toString());
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', event => {
      const targetId = anchor.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
        event.preventDefault();
        targetElement.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  if (scrollTopButton) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 240) {
        scrollTopButton.classList.add('visible');
      } else {
        scrollTopButton.classList.remove('visible');
      }
    });

    scrollTopButton.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (cookieBanner && acceptCookiesButton) {
    const accepted = localStorage.getItem('sovinertyliaCookiesAccepted');
    if (accepted === 'true') {
      cookieBanner.classList.add('hidden');
      cookieBanner.setAttribute('aria-hidden', 'true');
    } else {
      cookieBanner.classList.remove('hidden');
      cookieBanner.setAttribute('aria-hidden', 'false');
    }

    acceptCookiesButton.addEventListener('click', () => {
      localStorage.setItem('sovinertyliaCookiesAccepted', 'true');
      cookieBanner.classList.add('hidden');
      cookieBanner.setAttribute('aria-hidden', 'true');
    });
  }

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
});