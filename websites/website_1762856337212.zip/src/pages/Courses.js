import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Courses.module.css';

const Courses = () => (
  <>
    <Helmet htmlAttributes={{ lang: 'ru' }}>
      <title>Курсы NovaGate — графический дизайн, UI/UX и веб-дизайн</title>
      <meta
        name="description"
        content="Подробное описание курсов NovaGate Design Academy: графический дизайн, UI/UX и веб-дизайн. Структура, инструменты, практические проекты."
      />
      <meta
        name="keywords"
        content="курсы графического дизайна, курсы UI/UX, курсы веб-дизайна, обучение дизайну Москва"
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Выберите курс, который раскрывает ваш потенциал</h1>
      <p>
        Мы разработали три основные программы, которые можно проходить последовательно или комбинировать. Каждая включает проектные сессии, живые консультации и доступ к цифровой библиотеке NovaGate.
      </p>
    </section>

    <section className={styles.courseBlocks}>
      <article id="graphic" className={styles.courseCard}>
        <div className={styles.courseHeader}>
          <span className={styles.label}>Графический дизайн</span>
          <h2>Авторская айдентика и визуальные коммуникации</h2>
        </div>
        <div className={styles.courseContent}>
          <div className={styles.courseImage}>
            <img src="https://picsum.photos/900/650?random=81" alt="Рабочий стол графического дизайнера" loading="lazy" />
          </div>
          <div className={styles.courseDetails}>
            <p>
              Курс помогает пройти путь от основы композиции до создания комплексной visual identity. В процессе обучения решаем задачи брендинга, упаковки, постеров и digital-коммуникаций.
            </p>
            <h3>Ключевые модули</h3>
            <ul>
              <li>Типографика и работа с цветом</li>
              <li>Adobe Photoshop / Illustrator</li>
              <li>Создание брендбука и гайдлайнов</li>
              <li>Дизайн рекламных кампаний</li>
            </ul>
            <h3>Практика</h3>
            <p>Каждый студент разрабатывает айдентику для реального заказчика и защищает проект перед экспертной комиссией.</p>
          </div>
        </div>
      </article>

      <article id="uiux" className={styles.courseCard}>
        <div className={styles.courseHeader}>
          <span className={styles.label}>UI/UX дизайн</span>
          <h2>Проектирование цифровых продуктов и сервисов</h2>
        </div>
        <div className={styles.courseContent}>
          <div className={styles.courseImage}>
            <img src="https://picsum.photos/900/650?random=82" alt="Студент проектирует интерфейс в Figma" loading="lazy" />
          </div>
          <div className={styles.courseDetails}>
            <p>
              Обучаем системному подходу к продукту: от исследования и гипотез до разработки дизайн-системы. Практикуем Figma, проведение интервью, анализ метрик и взаимодействие с разработчиками.
            </p>
            <h3>Ключевые модули</h3>
            <ul>
              <li>UX-исследования и CJM</li>
              <li>Информационная архитектура</li>
              <li>UI-паттерны и создание дизайн-систем</li>
              <li>Прототипирование и пользовательские тесты</li>
            </ul>
            <h3>Практика</h3>
            <p>Выпускники собирают кейс цифрового продукта: мобильное приложение или веб-сервис, включая исследования и визуальную презентацию.</p>
          </div>
        </div>
      </article>

      <article id="web" className={styles.courseCard}>
        <div className={styles.courseHeader}>
          <span className={styles.label}>Веб-дизайн</span>
          <h2>Адаптивные сайты и digital-коммуникации</h2>
        </div>
        <div className={styles.courseContent}>
          <div className={styles.courseImage}>
            <img src="https://picsum.photos/900/650?random=83" alt="Дизайнер создаёт макет сайта" loading="lazy" />
          </div>
          <div className={styles.courseDetails}>
            <p>
              Углубляемся в дизайн веб-проектов: информационная архитектура, адаптивная сетка, работа с WordPress и Webflow, настройка анимации и передача макетов разработчикам.
            </p>
            <h3>Ключевые модули</h3>
            <ul>
              <li>Контент-стратегия и UX для сайтов</li>
              <li>Responsive и компонентный подход</li>
              <li>Webflow, WordPress и handoff командам</li>
              <li>Анимация и микроинтеракции</li>
            </ul>
            <h3>Практика</h3>
            <p>Студенты создают лендинг или корпоративный сайт, настраивают адаптацию и презентуют проект с прототипом и анимацией.</p>
          </div>
        </div>
      </article>
    </section>
  </>
);

export default Courses;