import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Program.module.css';

const Program = () => (
  <>
    <Helmet htmlAttributes={{ lang: 'ru' }}>
      <title>Программа обучения — структура курсов NovaGate</title>
      <meta
        name="description"
        content="Структура программы NovaGate Design Academy: модули, продолжительность, практические проекты, сертификация и сопровождение."
      />
      <meta
        name="keywords"
        content="программа обучения дизайн, модули курса дизайна, практические проекты дизайна"
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Структура программы NovaGate</h1>
      <p>
        Мы строим обучение по модульному принципу. Каждый блок фокусируется на конкретных навыках и завершаетcя практическим проектом с защитой перед наставниками и экспертами.
      </p>
    </section>

    <section className={styles.modules}>
      <div className={styles.sectionHeader}>
        <h2>Основные модули</h2>
        <p>Комбинируйте модули под ваши задачи — куратор поможет выстроить индивидуальную траекторию.</p>
      </div>
      <div className={styles.moduleGrid}>
        {[
          {
            title: 'Исследование и стратегия',
            duration: '3 недели',
            content: 'Дискавери, формулировка гипотез, брифинг заказчика, выбор инструментов исследования.',
          },
          {
            title: 'Дизайн-система и визуальный язык',
            duration: '4 недели',
            content: 'Работа с сеткой, типографикой, цветовыми палитрами и компонентами. Создание UI-китов и гайдлайнов.',
          },
          {
            title: 'Прототипирование и тестирование',
            duration: '2 недели',
            content: 'Интерактивные прототипы, user testing, A/B эксперименты и iterating на основе обратной связи.',
          },
          {
            title: 'Финальная защита и портфолио',
            duration: '2 недели',
            content: 'Подготовка презентации, сторителлинг, оформление кейса и публичная защита перед экспертами индустрии.',
          },
        ].map((module) => (
          <article key={module.title} className={styles.moduleCard}>
            <h3>{module.title}</h3>
            <span>{module.duration}</span>
            <p>{module.content}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.projects}>
      <div className={styles.projectsContent}>
        <h2>Практические проекты</h2>
        <p>
          Уже в процессе обучения студенты работают с реальными брифами. Мы сотрудничаем с IT-компаниями, креативными студиями и социальными инициативами, поэтому ваши кейсы будут основаны на актуальных задачах.
        </p>
        <ul>
          <li>Workshop-сессии с приглашёнными art-director’ами</li>
          <li>Наставники помогают выстраивать процесс и защищать решения</li>
          <li>Доступ к библиотеке шаблонов, UI-китов и презентаций</li>
        </ul>
      </div>
      <div className={styles.projectsImage}>
        <img src="https://picsum.photos/1000/720?random=91" alt="Пример командного воркшопа NovaGate" loading="lazy" />
      </div>
    </section>

    <section className={styles.timeline}>
      <div className={styles.sectionHeader}>
        <h2>Продолжительность и поддержка</h2>
        <p>Каждый поток длится от 12 до 16 недель. Дополнительно доступны консультации кураторов и карьерные сессии.</p>
      </div>
      <div className={styles.timelineGrid}>
        {[
          { stage: 'Недели 1–4', text: 'Погружение, исследование, разработка концепции и первые презентации драфтов.' },
          { stage: 'Недели 5–8', text: 'Проработка дизайн-системы, интерактивные прототипы, тестирование и ретроспективы.' },
          { stage: 'Недели 9–12', text: 'Финализация проектов, подготовка портфолио, мастермайнды и карьерные консультации.' },
          { stage: 'После курса', text: 'Доступ к сообществу выпускников, закрытым вебинарам и поддержке менторов.' },
        ].map((step) => (
          <article key={step.stage} className={styles.timelineCard}>
            <h3>{step.stage}</h3>
            <p>{step.text}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.certification}>
      <div className={styles.certContent}>
        <h2>Сертификация и карьерная поддержка</h2>
        <p>
          По итогам обучения вы получаете именной сертификат NovaGate, а также методические рекомендации по портфолио и резюме.
          Мы проводим карьерные сессии и помогаем подготовиться к собеседованиям.
        </p>
        <div className={styles.certHighlights}>
          <div>
            <h3>Сертификат</h3>
            <p>Документ подтверждает освоенные навыки и включает рекомендации кураторов.</p>
          </div>
          <div>
            <h3>Карьерные консультации</h3>
            <p>Мастермайнды по портфолио, поддержка HR-партнёров, рекомендации по личному бренду.</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Program;