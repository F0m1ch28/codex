import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contacts.module.css';

const Contacts = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState({ error: '', success: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
    setStatus({ error: '', success: '' });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formState.name || !formState.email || !formState.message) {
      setStatus({ error: 'Пожалуйста, заполните все обязательные поля.', success: '' });
      return;
    }
    if (!/\S+@\S+\.\S+/.test(formState.email)) {
      setStatus({ error: 'Введите корректный email.', success: '' });
      return;
    }
    setStatus({ error: '', success: 'Спасибо! Мы свяжемся с вами в ближайшее время.' });
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet htmlAttributes={{ lang: 'ru' }}>
        <title>Контакты NovaGate — обратная связь и карта</title>
        <meta
          name="description"
          content="Связаться с NovaGate Design Academy: адрес в Москве, телефон, email, форма записи и карта расположения."
        />
        <meta
          name="keywords"
          content="контакты NovaGate, записаться на курс дизайна, адрес академии дизайна Москва"
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Свяжитесь с командой NovaGate</h1>
        <p>Расскажите, чем мы можем помочь: подобрать курс, подсказать по программе или рассказать об академии.</p>
      </section>

      <section className={styles.content}>
        <div className={styles.contactInfo}>
          <h2>Контактные данные</h2>
          <p>Наш координатор ответит на вопросы в рабочие часы: будние дни с 10:00 до 19:00 (московское время).</p>
          <ul>
            <li>
              <strong>Адрес:</strong> Тверская улица 15, 125009 Москва, Россия
            </li>
            <li>
              <strong>Телефон:</strong> <a href="tel:+74951234567">+7 495 123 45 67</a>
            </li>
            <li>
              <strong>Email:</strong> <a href="mailto:info@novagate.ru">info@novagate.ru</a>
            </li>
          </ul>
          <div className={styles.mapWrapper} aria-label="Карта расположения NovaGate Design Academy">
            <iframe
              title="Карта NovaGate Design Academy"
              src="https://yandex.ru/map-widget/v1/?um=constructor%3A0f2a084f8ffdc57d12f8b9df1f42be28db21d582eddd8519580a64aa9a0f47fd&amp;source=constructor"
              width="100%"
              height="320"
              frameBorder="0"
              loading="lazy"
            />
          </div>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Заявка на консультацию</h2>
          <label htmlFor="name">Имя</label>
          <input
            id="name"
            name="name"
            type="text"
            value={formState.name}
            onChange={handleChange}
            placeholder="Как к вам обратиться"
            required
          />
          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            value={formState.email}
            onChange={handleChange}
            placeholder="example@novagate.ru"
            required
          />
          <label htmlFor="message">Расскажите о своих целях</label>
          <textarea
            id="message"
            name="message"
            value={formState.message}
            onChange={handleChange}
            rows="5"
            placeholder="Например: хочу перейти в UI/UX или собрать портфолио"
            required
          />
          {status.error && <p className={styles.error}>{status.error}</p>}
          {status.success && <p className={styles.success}>{status.success}</p>}
          <button type="submit">Отправить заявку</button>
        </form>
      </section>
    </>
  );
};

export default Contacts;