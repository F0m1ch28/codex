import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet htmlAttributes={{ lang: 'ru' }}>
      <title>О NovaGate Design Academy — история, миссия и методология</title>
      <meta
        name="description"
        content="Узнайте больше о NovaGate Design Academy: история создания академии, миссия, методология обучения и команда кураторов."
      />
      <meta
        name="keywords"
        content="академия дизайна Москва, обучение дизайну, методология дизайна, команда дизайнеров"
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <span className={styles.badge}>О нас</span>
        <h1>NovaGate Design Academy — экосистема для развития дизайнеров</h1>
        <p>
          Мы появились в 2017 году как команда дизайнеров-практиков, которые хотели делиться опытом с начинающими специалистами.
          Сегодня NovaGate — это образовательная академия с курируемыми программами, цифровой студией и сообществом выпускников по всей России.
        </p>
      </div>
      <div className={styles.heroImage}>
        <img src="https://picsum.photos/1200/800?random=61" alt="Команда NovaGate обсуждает концепцию курса" loading="lazy" />
      </div>
    </section>

    <section className={styles.history}>
      <div className={styles.sectionHeader}>
        <h2>Как всё начиналось</h2>
        <p>Мы прошли путь от локальных воркшопов до комплексной образовательной платформы с гибкими программами.</p>
      </div>
      <div className={styles.timeline}>
        {[
          { year: '2017', text: 'Первые офлайн-воркшопы по графическому дизайну в Москве. Создание методических материалов и приглашение кураторов.' },
          { year: '2019', text: 'Запуск модульной программы по UI/UX, подключение Figma и Miro, появление индивидуальных проектных наставников.' },
          { year: '2021', text: 'Переход на гибридный формат: онлайн-платформа, цифровая библиотека, коллаборации с дизайн-студиями и IT-компаниями.' },
          { year: '2023', text: 'Создание NovaGate Lab — пространства для экспериментальных проектов, исследовательских спринтов и коллабораций со студентами.' },
        ].map((item) => (
          <article key={item.year} className={styles.timelineCard}>
            <span>{item.year}</span>
            <p>{item.text}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.mission}>
      <div className={styles.missionContent}>
        <h2>Миссия и ценности</h2>
        <p>
          Мы верим, что дизайн — это не только визуальные решения, но и стратегия развития продукта, бизнеса и общества. Поэтому наши программы
          развивают критическое мышление, умение работать в команде и презентовать идеи.
        </p>
        <ul>
          <li>Создаём интеллект-карту навыков для каждого студента.</li>
          <li>Развиваем культуру проектов: от исследования до защиты.</li>
          <li>Поддерживаем выпускников и помогаем в профессиональной адаптации.</li>
        </ul>
      </div>
      <div className={styles.missionImage}>
        <img src="https://picsum.photos/960/720?random=62" alt="Презентация студенческого проекта NovaGate" loading="lazy" />
      </div>
    </section>

    <section className={styles.methodology}>
      <div className={styles.sectionHeader}>
        <h2>Методология обучения</h2>
        <p>Наш подход сочетает исследовательские практики, обратную связь и менторство от дизайнеров-практиков.</p>
      </div>
      <div className={styles.methodGrid}>
        {[
          {
            title: 'Проектно-ориентированное обучение',
            text: 'Каждый модуль завершается кейсом, который попадает в портфолио. Студенты учатся работать с реальными брифами и защитой решений.',
          },
          {
            title: 'Спринты и рефлексия',
            text: 'Мы используем регулярные спринты, ретроспективы и дизайн-ревью, чтобы студенты увидели прогресс и смогли скорректировать траекторию.',
          },
          {
            title: 'Наставничество и менторинг',
            text: 'У каждого потока есть куратор, который помогает с постановкой целей, даёт обратную связь и делится опытом из реальных проектов.',
          },
          {
            title: 'Акцент на коммуникацию',
            text: 'Учимся презентовать, аргументировать и принимать решения на основе данных, а не только эстетики.',
          },
        ].map((item) => (
          <article key={item.title} className={styles.methodCard}>
            <h3>{item.title}</h3>
            <p>{item.text}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.team}>
      <div className={styles.sectionHeader}>
        <h2>Команда управления академией</h2>
        <p>Мы объединяем экспертов из продуктового дизайна, брендинга, стратегического менеджмента и EdTech.</p>
      </div>
      <div className={styles.teamGrid}>
        {[
          {
            name: 'Анна Кораблёва',
            role: 'Сооснователь и директор программы',
            bio: 'Куратор стратегических проектов, работает в дизайне более 12 лет, запускала продуктовые команды в крупных IT-компаниях.',
            image: 'https://picsum.photos/400/400?random=71',
          },
          {
            name: 'Илья Кравченко',
            role: 'Academic Lead и руководитель методологии',
            bio: 'Автор методических курсов, исследователь UX-процессов, спикер конференций по дизайну и цифровым продуктам.',
            image: 'https://picsum.photos/400/400?random=72',
          },
          {
            name: 'Вероника Дацко',
            role: 'Community Manager и координатор проектов',
            bio: 'Строит работу сообщества NovaGate, отвечает за партнёрства и помогает студентам в коммуникации с заказчиками.',
            image: 'https://picsum.photos/400/400?random=73',
          },
        ].map((member) => (
          <article key={member.name} className={styles.teamCard}>
            <div className={styles.avatar}>
              <img src={member.image} alt={member.name} loading="lazy" />
            </div>
            <div className={styles.teamInfo}>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default About;