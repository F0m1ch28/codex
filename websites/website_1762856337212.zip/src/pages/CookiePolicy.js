import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet htmlAttributes={{ lang: 'ru' }}>
      <title>Политика использования Cookie — NovaGate Design Academy</title>
      <meta
        name="description"
        content="Политика использования cookie NovaGate Design Academy. Какие файлы cookie применяются на сайте и как ими управлять."
      />
    </Helmet>
    <section className={styles.wrapper}>
      <h1>Политика использования cookie</h1>
      <p>Настоящий документ описывает, какие файлы cookie применяются на сайте novagate.ru и как вы можете управлять ими.</p>

      <h2>Что такое cookie</h2>
      <p>Cookie — небольшие текстовые файлы, которые сохраняются на вашем устройстве и помогают обеспечить корректную работу сайта и персонализацию контента.</p>

      <h2>Типы cookie</h2>
      <ul>
        <li><strong>Технические:</strong> обеспечивают работу функционала сайта.</li>
        <li><strong>Аналитические:</strong> помогают анализировать взаимодействие пользователей с платформой.</li>
        <li><strong>Функциональные:</strong> запоминают ваши предпочтения и настройки.</li>
      </ul>

      <h2>Управление cookie</h2>
      <p>Вы можете изменить настройки cookie в браузере или удалить сохранённые файлы. Обратите внимание, что отказ от технических cookie может повлиять на работу сайта.</p>

      <h2>Контакты</h2>
      <p>По вопросам использования cookie обращайтесь на <a href="mailto:info@novagate.ru">info@novagate.ru</a>.</p>
    </section>
  </>
);

export default CookiePolicy;