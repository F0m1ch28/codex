import React, { useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  const statsRef = useRef(null);
  const [statsActive, setStatsActive] = useState(false);
  const [counters, setCounters] = useState({
    graduates: 0,
    mentors: 0,
    projects: 0,
    cities: 0,
  });
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [expandedFaq, setExpandedFaq] = useState(0);

  const targetCounters = {
    graduates: 1200,
    mentors: 28,
    projects: 460,
    cities: 19,
  };

  const projects = [
    {
      title: 'Мобильный интерфейс сервиса доставки',
      category: 'UI/UX',
      image: 'https://picsum.photos/1200/800?random=41',
    },
    {
      title: 'Айдентика арт-резиденции',
      category: 'Графический дизайн',
      image: 'https://picsum.photos/1200/800?random=42',
    },
    {
      title: 'Лендинг EdTech платформы',
      category: 'Веб-дизайн',
      image: 'https://picsum.photos/1200/800?random=43',
    },
    {
      title: 'Дашборд аналитики',
      category: 'UI/UX',
      image: 'https://picsum.photos/1200/800?random=44',
    },
    {
      title: 'Серия постеров фестиваля',
      category: 'Графический дизайн',
      image: 'https://picsum.photos/1200/800?random=45',
    },
    {
      title: 'Редизайн интернет-магазина',
      category: 'Веб-дизайн',
      image: 'https://picsum.photos/1200/800?random=46',
    },
  ];

  const testimonials = [
    {
      name: 'Ксения Перова',
      role: 'Выпускница курса UI/UX',
      quote:
        'NovaGate помогла мне системно разобраться в дизайне цифровых продуктов. В процессе обучения я собрала портфолио и уже в третий месяц получила оффер в продуктовую команду.',
      image: 'https://picsum.photos/200/200?random=51',
    },
    {
      name: 'Александр Громов',
      role: 'Выпускник курса графического дизайна',
      quote:
        'Преподаватели делятся реальным опытом и поддерживают от первой концепции до финальной презентации. Особенно понравился блок по бренд-стратегии и типографике.',
      image: 'https://picsum.photos/200/200?random=52',
    },
    {
      name: 'Мария Савельева',
      role: 'Выпускница курса веб-дизайна',
      quote:
        'Благодаря проектной работе и обратной связи кураторов я научилась создавать адаптивные сайты и работать с анимацией. Сейчас продолжаю сотрудничать с NovaGate как приглашённый дизайнер.',
      image: 'https://picsum.photos/200/200?random=53',
    },
  ];

  const faqItems = [
    {
      question: 'Можно ли обучаться онлайн из другого города?',
      answer: 'Да, вы можете подключаться к живым занятиям онлайн и получать доступ к записям. Все консультации проходят в удобном формате с гибким расписанием.',
    },
    {
      question: 'Сколько времени требуется на обучение каждую неделю?',
      answer: 'В среднем студенты выделяют 6–8 часов в неделю: две онлайн-встречи с наставниками, практикум и самостоятельную работу над кейсами.',
    },
    {
      question: 'Какие программы и инструменты использует академия?',
      answer: 'Мы работаем с Figma, Adobe Photoshop и Illustrator, Miro, Notion, а также даём доступ к библиотеке UI-китов и шаблонов для командной работы.',
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          setStatsActive(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsActive) return;

    const duration = 1600;
    const frame = 16;
    const steps = duration / frame;

    let currentStep = 0;

    const interval = setInterval(() => {
      currentStep += 1;
      setCounters({
        graduates: Math.min(Math.round((targetCounters.graduates / steps) * currentStep), targetCounters.graduates),
        mentors: Math.min(Math.round((targetCounters.mentors / steps) * currentStep), targetCounters.mentors),
        projects: Math.min(Math.round((targetCounters.projects / steps) * currentStep), targetCounters.projects),
        cities: Math.min(Math.round((targetCounters.cities / steps) * currentStep), targetCounters.cities),
      });

      if (currentStep >= steps) {
        clearInterval(interval);
      }
    }, frame);

    return () => clearInterval(interval);
  }, [statsActive]);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const filteredProjects = selectedCategory === 'Все' ? projects : projects.filter((project) => project.category === selectedCategory);

  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'EducationalOrganization',
    name: 'NovaGate Design Academy',
    url: 'https://novagate.ru',
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Тверская улица 15',
      addressLocality: 'Москва',
      postalCode: '125009',
      addressCountry: 'RU',
    },
    email: 'info@novagate.ru',
    telephone: '+7 495 123 45 67',
    sameAs: ['https://behance.net', 'https://dribbble.com', 'https://vk.com'],
    description: 'Современная академия дизайна в Москве и онлайн. Курсы графического дизайна, UI/UX и веб-дизайна.',
  };

  return (
    <>
      <Helmet htmlAttributes={{ lang: 'ru' }}>
        <title>NovaGate Design Academy — создавай профессиональный дизайн</title>
        <meta
          name="description"
          content="Курсы дизайна в Москве и онлайн. NovaGate Design Academy обучает графическому дизайну, UI/UX и веб-дизайну с практическими проектами и поддержкой кураторов."
        />
        <meta
          name="keywords"
          content="курсы дизайна Москва, обучение графическому дизайну, курсы UI/UX, веб-дизайн онлайн, дизайн образование, академия дизайна"
        />
        <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.badge}>Российская образовательная платформа</span>
          <h1 className={styles.title}>Создавай профессиональный дизайн, который ценят команды и бренды</h1>
          <p className={styles.subtitle}>
            Обучение в NovaGate — это проектные спринты, кураторство экспертов и доступ к цифровой студии, где рождаются заметные визуальные решения.
          </p>
          <div className={styles.heroActions}>
            <a className={styles.primaryCta} href="#courses" aria-label="Перейти к курсам NovaGate">
              Записаться на консультацию
            </a>
            <a className={styles.secondaryCta} href="/programma">
              Посмотреть программу
            </a>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Студенты NovaGate работают над дизайн-проектом"
            className={styles.heroImage}
            loading="eager"
          />
        </div>
      </section>

      <section className={styles.intro} ref={statsRef}>
        <div className={styles.introText}>
          <h2>NovaGate Design Academy — пространство, где дизайнеры растут быстрее</h2>
          <p>
            Мы создали академию для тех, кто хочет уверенно управлять визуальными решениями, понимать пользователя и внедрять дизайн в бизнес-процессы. Основной фокус — практика, обратная связь и работа в команде.
          </p>
        </div>
        <div className={styles.statsGrid}>
          <article className={styles.statCard}>
            <span className={styles.statValue}>{counters.graduates}+</span>
            <p className={styles.statLabel}>выпускников построили портфолио и продолжили карьеру в креативных индустриях</p>
          </article>
          <article className={styles.statCard}>
            <span className={styles.statValue}>{counters.mentors}</span>
            <p className={styles.statLabel}>приглашённых кураторов из студий и продуктовых команд</p>
          </article>
          <article className={styles.statCard}>
            <span className={styles.statValue}>{counters.projects}</span>
            <p className={styles.statLabel}>реализованных студенческих кейсов с реальными заказчиками</p>
          </article>
          <article className={styles.statCard}>
            <span className={styles.statValue}>{counters.cities}</span>
            <p className={styles.statLabel}>городов России и мира, откуда учатся наши студенты</p>
          </article>
        </div>
      </section>

      <section className={styles.courses} id="courses">
        <header className={styles.sectionHeader}>
          <h2>Курсы, которые развивают дизайнерское мышление и инструментарий</h2>
          <p>Выбирайте направление, комбинируйте модули и собирайте собственную траекторию обучения вместе с наставниками NovaGate.</p>
        </header>
        <div className={styles.courseGrid}>
          <article className={styles.courseCard}>
            <div className={styles.icon}>🎨</div>
            <h3>Графический дизайн</h3>
            <p>Осваиваем композицию, типографику, фирменный стиль и работу с Adobe Photoshop/Illustrator на реальных брифах.</p>
            <ul>
              <li>Создание айдентики и бренд-носителей</li>
              <li>Работа с визуальным storytelling</li>
              <li>Верстка печатных и цифровых макетов</li>
            </ul>
            <a href="/kursy#graphic" className={styles.link}>
              Подробнее о курсе
            </a>
          </article>
          <article className={styles.courseCard}>
            <div className={styles.icon}>🧭</div>
            <h3>UI/UX дизайн</h3>
            <p>Изучаем исследования, CJM, прототипирование и интерфейсную анимацию в Figma. Формируем дизайн-системы.</p>
            <ul>
              <li>Проведение интервью и user testing</li>
              <li>Создание интерактивных прототипов</li>
              <li>Внедрение дизайн-оптимизаций</li>
            </ul>
            <a href="/kursy#uiux" className={styles.link}>
              Подробнее о курсе
            </a>
          </article>
          <article className={styles.courseCard}>
            <div className={styles.icon}>🌐</div>
            <h3>Веб-дизайн</h3>
            <p>Проектируем адаптивные сайты, подключаем WordPress и Webflow, настраиваем микровзаимодействия и презентацию.</p>
            <ul>
              <li>Создание лендингов и многостраничных сайтов</li>
              <li>Работа с responsive grids</li>
              <li>Интеграция нативных анимаций</li>
            </ul>
            <a href="/kursy#web" className={styles.link}>
              Подробнее о курсе
            </a>
          </article>
        </div>
      </section>

      <section className={styles.process}>
        <header className={styles.sectionHeader}>
          <h2>Как проходит обучение</h2>
          <p>Каждый модуль строится вокруг проектного подхода с поддержкой кураторов и обратной связью от профессионального сообщества.</p>
        </header>
        <div className={styles.processTimeline}>
          {[
            { step: '01', title: 'Диагностика целей', text: 'Определяем ваши задачи, собираем референсы и формируем индивидуальный план развития.' },
            { step: '02', title: 'Проектные спринты', text: 'Раз в неделю вы сдаёте промежуточный результат и получаете корректировки от наставника.' },
            { step: '03', title: 'Командные воркшопы', text: 'Практикуем работу в команде, учимся презентовать решения и защищаем концепции.' },
            { step: '04', title: 'Портфолио и сертификация', text: 'Собираем кейсы для портфолио, помогаем подготовиться к собеседованиям и выдаём сертификат.' },
          ].map((item) => (
            <article key={item.step} className={styles.processCard}>
              <span className={styles.processStep}>{item.step}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.projects}>
        <header className={styles.sectionHeader}>
          <h2>Проекты студентов</h2>
          <p>Портфолио выпускников NovaGate — это разнообразные кейсы для брендов, IT-команд и общественных инициатив.</p>
        </header>
        <div className={styles.controls} role="tablist" aria-label="Фильтр проектов по направлениям">
          {['Все', 'Графический дизайн', 'UI/UX', 'Веб-дизайн'].map((category) => (
            <button
              key={category}
              type="button"
              role="tab"
              className={`${styles.filterButton} ${selectedCategory === category ? styles.filterActive : ''}`}
              aria-pressed={selectedCategory === category}
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className={styles.projectInfo}>
                <span className={styles.projectCategory}>{project.category}</span>
                <h3>{project.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.teamContent}>
          <h2>Команда наставников и сообщество NovaGate</h2>
          <p>
            Все преподаватели — практикующие дизайнеры. Они ведут собственные проекты, делятся рабочими методиками и поддерживают студентов от концепта до финального кейса.
          </p>
          <ul className={styles.benefitsList}>
            <li>Наставничество и обратная связь каждую неделю</li>
            <li>Еженедельные дизайн-ревью и разборы трендов</li>
            <li>Закрытый чат сообщества и карьерные консультации</li>
          </ul>
          <a className={styles.primaryCta} href="/prepodavateli">
            Познакомиться с преподавателями
          </a>
        </div>
        <div className={styles.teamGrid}>
          {[
            {
              name: 'Диана Лайт',
              role: 'Lead Product Designer, Figma Expert',
              image: 'https://picsum.photos/400/400?random=31',
            },
            {
              name: 'Михаил Орлов',
              role: 'Art Director, бренд-стратег',
              image: 'https://picsum.photos/400/400?random=32',
            },
            {
              name: 'Полина Соколова',
              role: 'Webflow Creator, motion designer',
              image: 'https://picsum.photos/400/400?random=33',
            },
          ].map((mentor) => (
            <article key={mentor.name} className={styles.teamCard}>
              <div className={styles.teamImage}>
                <img src={mentor.image} alt={`${mentor.name} — ${mentor.role}`} loading="lazy" />
              </div>
              <div className={styles.teamInfo}>
                <h3>{mentor.name}</h3>
                <p>{mentor.role}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <header className={styles.sectionHeader}>
          <h2>Отзывы выпускников</h2>
          <p>Мы ценим честную обратную связь и растём вместе с сообществом студентов NovaGate.</p>
        </header>
        <div className={styles.testimonialSlider} role="region" aria-live="polite">
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
              aria-hidden={index !== activeTestimonial}
            >
              <div className={styles.testimonialHeader}>
                <img src={testimonial.image} alt={testimonial.name} loading="lazy" />
                <div>
                  <h3>{testimonial.name}</h3>
                  <span>{testimonial.role}</span>
                </div>
              </div>
              <p className={styles.testimonialText}>{testimonial.quote}</p>
            </article>
          ))}
          <div className={styles.sliderControls}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Переключить отзыв ${index + 1}`}
              />
            ))}
          </div>
        </div>
        <div className={styles.ctaPanel}>
          <h3>Готовы усилить свои навыки и собрать профессиональное портфолио?</h3>
          <p>Оставьте заявку — координатор подберёт программу и ответит на вопросы.</p>
          <a className={styles.primaryCta} href="/kontakty">
            Получить консультацию
          </a>
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.faqContent}>
          <h2>Частые вопросы</h2>
          <p>Если не нашли ответ, напишите координаторам — мы на связи в рабочие часы академии.</p>
          <a className={styles.secondaryCta} href="mailto:info@novagate.ru">
            Связаться по email
          </a>
        </div>
        <div className={styles.accordion} role="tablist">
          {faqItems.map((item, index) => (
            <article key={item.question} className={styles.accordionItem}>
              <button
                className={styles.accordionButton}
                onClick={() => setExpandedFaq((prev) => (prev === index ? -1 : index))}
                aria-expanded={expandedFaq === index}
                aria-controls={`faq-panel-${index}`}
              >
                <span>{item.question}</span>
                <span className={styles.accordionIcon}>{expandedFaq === index ? '−' : '+'}</span>
              </button>
              <div
                id={`faq-panel-${index}`}
                className={`${styles.accordionPanel} ${expandedFaq === index ? styles.panelOpen : ''}`}
                role="region"
              >
                <p>{item.answer}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <header className={styles.sectionHeader}>
          <h2>Свежие материалы блога</h2>
          <p>Делимся инсайтами об индустрии, подборками референсов и рекомендациями по развитию навыков.</p>
        </header>
        <div className={styles.blogGrid}>
          {[
            {
              title: 'Как создавать дизайн-систему: гайд от преподавателей NovaGate',
              date: '12 апреля 2024',
              image: 'https://picsum.photos/800/600?random=21',
            },
            {
              title: 'Тренды графического дизайна 2024: материалы и примеры',
              date: '04 апреля 2024',
              image: 'https://picsum.photos/800/600?random=22',
            },
            {
              title: 'Онбординг в продукте: чек-лист для UX-дизайнера',
              date: '28 марта 2024',
              image: 'https://picsum.photos/800/600?random=23',
            },
          ].map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <div className={styles.blogImage}>
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className={styles.blogInfo}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <a href="/kursy" className={styles.link}>
                  Читать статью
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Home;