import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Teachers.module.css';

const teachers = [
  {
    name: 'Диана Лайт',
    role: 'Lead Product Designer в цифровом банке',
    expertise: 'UX-исследования, дизайн-системы, Product strategy',
    bio: 'Выстраивает команды продуктового дизайна более 10 лет. В NovaGate отвечает за модуль по UX-исследованиям и тренды интерфейсов.',
    image: 'https://picsum.photos/400/400?random=101',
  },
  {
    name: 'Михаил Орлов',
    role: 'Арт-директор брендингового агентства',
    expertise: 'Айдентика, визуальные коммуникации, бренд-стратегия',
    bio: 'Работал с федеральными медиа, культурными проектами и технологическими стартапами. Ведёт воркшопы по storytelling и презентациям.',
    image: 'https://picsum.photos/400/400?random=102',
  },
  {
    name: 'Полина Соколова',
    role: 'Webflow Creator и motion designer',
    expertise: 'Анимация, UX writing, no-code',
    bio: 'Проектирует динамичные сайты для EdTech и SaaS. Готовит студентов к работе с Webflow и настраивает handoff процесс.',
    image: 'https://picsum.photos/400/400?random=103',
  },
  {
    name: 'Антон Плеханов',
    role: 'Senior Graphic Designer в креативном кластере',
    expertise: 'Типографика, дизайн плакатов, печать',
    bio: 'Создаёт визуальные решения для культурных событий и фестивалей. В академии ведёт модуль плаката и печатных коммуникаций.',
    image: 'https://picsum.photos/400/400?random=104',
  },
  {
    name: 'Ева Маркина',
    role: 'UX Writer и сервис-дизайнер',
    expertise: 'Контент-дизайн, сервисные сценарии, аудит',
    bio: 'Помогает продуктовым командам выстраивать коммуникацию и текст. Проводит занятия по работе с тоном и голосом бренда.',
    image: 'https://picsum.photos/400/400?random=105',
  },
  {
    name: 'Павел Нестеров',
    role: 'Digital Producer',
    expertise: 'Командные процессы, управление проектами, Agile',
    bio: 'Наставник project-части, помогает студентам выстраивать работу с заказчиками, вести календарь и оформлять отчётность.',
    image: 'https://picsum.photos/400/400?random=106',
  },
];

const Teachers = () => (
  <>
    <Helmet htmlAttributes={{ lang: 'ru' }}>
      <title>Преподаватели NovaGate — команда наставников</title>
      <meta
        name="description"
        content="Познакомьтесь с преподавателями NovaGate Design Academy: эксперты по графическому дизайну, UI/UX и веб-дизайну."
      />
      <meta
        name="keywords"
        content="преподаватели дизайна, наставники по дизайну, команда NovaGate"
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Преподаватели и наставники NovaGate</h1>
      <p>
        Мы приглашаем в академию практикующих специалистов. Они ведут проекты в ведущих студиях, стартапах и продуктовых командах, делятся опытом и помогают студентам расти.
      </p>
    </section>

    <section className={styles.grid}>
      {teachers.map((teacher) => (
        <article key={teacher.name} className={styles.card}>
          <div className={styles.avatar}>
            <img src={teacher.image} alt={teacher.name} loading="lazy" />
          </div>
          <div className={styles.info}>
            <h2>{teacher.name}</h2>
            <span className={styles.role}>{teacher.role}</span>
            <span className={styles.expertise}>{teacher.expertise}</span>
            <p>{teacher.bio}</p>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default Teachers;