import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Courses from './pages/Courses';
import Program from './pages/Program';
import Teachers from './pages/Teachers';
import Contacts from './pages/Contacts';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import styles from './App.module.css';

const AppContent = () => {
  const location = useLocation();

  useEffect(() => {
    document.body.setAttribute('data-route', location.pathname);
  }, [location.pathname]);

  return (
    <div className={styles.appWrapper}>
      <Header />
      <main className={styles.mainContent} aria-live="polite">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/o-nas" element={<About />} />
          <Route path="/kursy" element={<Courses />} />
          <Route path="/programma" element={<Program />} />
          <Route path="/prepodavateli" element={<Teachers />} />
          <Route path="/kontakty" element={<Contacts />} />
          <Route path="/usloviya" element={<Terms />} />
          <Route path="/konfidentsialnost" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

const App = () => <AppContent />;

export default App;