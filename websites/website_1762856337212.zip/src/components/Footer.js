import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Футер сайта">
    <div className={styles.container}>
      <div className={styles.column}>
        <div className={styles.brand}>
          <span className={styles.brandTitle}>NovaGate Design Academy</span>
          <p className={styles.brandText}>
            Российская академия дизайна, где креативность сочетается с практикой. Мы объединяем студентов, кураторов и цифровые инструменты, чтобы вы создавали проекты профессионального уровня.
          </p>
        </div>
        <div className={styles.legal}>
          <span>© {new Date().getFullYear()} NovaGate. Все права защищены.</span>
        </div>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Навигация</h3>
        <nav className={styles.links} aria-label="Навигация по разделам сайта">
          <NavLink to="/o-nas">О нас</NavLink>
          <NavLink to="/kursy">Курсы</NavLink>
          <NavLink to="/programma">Программа</NavLink>
          <NavLink to="/prepodavateli">Преподаватели</NavLink>
          <NavLink to="/kontakty">Контакты</NavLink>
        </nav>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Документы</h3>
        <nav className={styles.links} aria-label="Юридическая информация">
          <NavLink to="/usloviya">Пользовательское соглашение</NavLink>
          <NavLink to="/konfidentsialnost">Политика конфиденциальности</NavLink>
          <NavLink to="/cookie-policy">Политика Cookies</NavLink>
        </nav>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Контакты</h3>
        <address className={styles.address}>
          <span>Адрес: Тверская улица 15, 125009 Москва, Россия</span>
          <a href="tel:+74951234567">Телефон: +7 495 123 45 67</a>
          <a href="mailto:info@novagate.ru">Email: info@novagate.ru</a>
        </address>
        <div className={styles.socials} aria-label="Социальные сети">
          <a href="https://behance.net" target="_blank" rel="noopener noreferrer" aria-label="Behance NovaGate">
            Behance
          </a>
          <a href="https://dribbble.com" target="_blank" rel="noopener noreferrer" aria-label="Dribbble NovaGate">
            Dribbble
          </a>
          <a href="https://vk.com" target="_blank" rel="noopener noreferrer" aria-label="VK NovaGate">
            VK
          </a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;