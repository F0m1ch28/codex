import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 12);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`} role="banner">
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="На главную NovaGate Design Academy">
          <span className={styles.logoMark}>NovaGate</span>
          <span className={styles.logoSub}>Design Academy</span>
        </Link>
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          <NavLink to="/" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Главная
          </NavLink>
          <NavLink to="/o-nas" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            О нас
          </NavLink>
          <NavLink to="/kursy" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Курсы
          </NavLink>
          <NavLink to="/programma" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Программа
          </NavLink>
          <NavLink to="/prepodavateli" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Преподаватели
          </NavLink>
          <NavLink to="/kontakty" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Контакты
          </NavLink>
          <a className={styles.phoneLink} href="tel:+74951234567">
            +7 495 123 45 67
          </a>
        </nav>
        <button
          className={`${styles.burger} ${isMenuOpen ? styles.burgerActive : ''}`}
          type="button"
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Меню"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;