import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('novagate-cookie-consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('novagate-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookie">
      <p className={styles.text}>
        Мы используем cookie, чтобы адаптировать обучение под ваши задачи и улучшать работу платформы. Продолжая пользоваться сайтом, вы соглашаетесь с{' '}
        <a href="/cookie-policy">Политикой использования cookie</a>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Принять
      </button>
    </aside>
  );
};

export default CookieBanner;