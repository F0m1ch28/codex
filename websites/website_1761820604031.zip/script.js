document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen.toString());
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (navMenu.classList.contains('open')) {
          navMenu.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const animatedItems = document.querySelectorAll('[data-animate]');
  if (animatedItems.length) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    animatedItems.forEach(item => observer.observe(item));
  }

  const contactForm = document.querySelector('#contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();

      const status = contactForm.querySelector('.form-status');
      if (status) {
        status.textContent = 'Grazie! La tua richiesta è stata inviata con successo.';
      }

      contactForm.reset();
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptCookiesBtn = document.querySelector('#acceptCookies');
  const cookieKey = 'pip-cookie-consent';

  if (cookieBanner && acceptCookiesBtn) {
    const hasConsent = localStorage.getItem(cookieKey);
    if (!hasConsent) {
      requestAnimationFrame(() => cookieBanner.classList.add('visible'));
    }

    acceptCookiesBtn.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'accepted');
      cookieBanner.classList.remove('visible');
    });
  }

  const yearSpan = document.querySelectorAll('#current-year');
  yearSpan.forEach(span => {
    span.textContent = new Date().getFullYear();
  });
});