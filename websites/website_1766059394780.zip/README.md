Aurora Horizons Travel is a multi-page brochure website for a bespoke travel atelier.
Pages include home, about, destinations, experiences, insights journal, contact, privacy policy, terms of service, and FAQ.
Responsive layouts use semantic HTML, modern CSS, and adaptive Pexels photography with Picture and srcset.
Cookies banner with preference management is implemented in script.js and available on every page.
Additional assets: robots.txt, sitemap.xml, favicon placeholder, web manifest, logo SVG, and brand guidelines.
To view locally, open index.html in a modern browser. No build process required.