document.addEventListener('DOMContentLoaded', () => {
  const storageKey = 'auroraHorizonsCookies';
  const cookiesBanner = document.querySelector('[data-js="cookies-banner"]');
  if (!cookiesBanner) {
    return;
  }

  const acceptBtn = cookiesBanner.querySelector('[data-js="accept-cookies"]');
  const rejectBtn = cookiesBanner.querySelector('[data-js="reject-cookies"]');
  const customizeBtn = cookiesBanner.querySelector('[data-js="customize-cookies"]');
  const saveBtn = cookiesBanner.querySelector('[data-js="save-cookies"]');
  const cancelBtn = cookiesBanner.querySelector('[data-js="cancel-customize"]');
  const preferencesForm = cookiesBanner.querySelector('[data-js="cookies-preferences"]');
  const checkboxes = preferencesForm ? Array.from(preferencesForm.querySelectorAll('input[type="checkbox"]')) : [];

  const storedPreferences = (() => {
    try {
      const item = localStorage.getItem(storageKey);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.warn('Unable to parse cookie preferences.', error);
      return null;
    }
  })();

  if (!storedPreferences || !storedPreferences.acknowledged) {
    cookiesBanner.classList.add('is-visible');
  }

  const storePreferences = (prefs) => {
    const payload = {
      ...prefs,
      acknowledged: true,
      updatedAt: new Date().toISOString()
    };
    localStorage.setItem(storageKey, JSON.stringify(payload));
  };

  const applyStoredPreferences = () => {
    if (!storedPreferences || !checkboxes.length) return;
    checkboxes.forEach((checkbox) => {
      if (checkbox.disabled) return;
      checkbox.checked = Boolean(storedPreferences[checkbox.name]);
    });
  };

  applyStoredPreferences();

  const closeBanner = () => {
    cookiesBanner.classList.remove('is-visible', 'is-customizing');
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      const preferences = {};
      checkboxes.forEach((checkbox) => {
        preferences[checkbox.name] = true;
      });
      preferences.essential = true;
      storePreferences(preferences);
      closeBanner();
    });
  }

  if (rejectBtn) {
    rejectBtn.addEventListener('click', () => {
      const preferences = {};
      checkboxes.forEach((checkbox) => {
        preferences[checkbox.name] = checkbox.disabled ? true : false;
      });
      preferences.essential = true;
      storePreferences(preferences);
      closeBanner();
    });
  }

  if (customizeBtn) {
    customizeBtn.addEventListener('click', () => {
      cookiesBanner.classList.add('is-customizing');
    });
  }

  if (cancelBtn) {
    cancelBtn.addEventListener('click', () => {
      cookiesBanner.classList.remove('is-customizing');
      applyStoredPreferences();
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const preferences = {};
      checkboxes.forEach((checkbox) => {
        preferences[checkbox.name] = checkbox.disabled ? true : checkbox.checked;
      });
      storePreferences(preferences);
      closeBanner();
    });
  }

  const navToggle = document.querySelector('[data-js="nav-toggle"]');
  const navMenu = document.querySelector('[data-js="nav-menu"]');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }
});