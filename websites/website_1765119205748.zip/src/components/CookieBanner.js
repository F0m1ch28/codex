import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const accepted = window.localStorage.getItem('cookiesAccepted');
    if (!accepted) {
      const timeout = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timeout);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('cookiesAccepted', 'true');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Ми використовуємо cookie для покращення роботи сайту. Детальніше у{' '}
        <Link to="/cookie-policy">Політиці щодо cookie</Link>.
      </div>
      <button type="button" className={styles.button} onClick={acceptCookies}>
        Погоджуюся
      </button>
    </div>
  );
};

export default CookieBanner;