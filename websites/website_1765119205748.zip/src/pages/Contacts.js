import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Contacts.module.css';

const initialFormState = {
  name: '',
  email: '',
  city: '',
  message: '',
};

const Contacts = () => {
  usePageMeta({
    title: 'Контакти — Професійне дресирування собак',
    description:
      'Зв’яжіться з нашою командою у Варшаві та Кракові: форма для запису на тренування, email info@dog-training.pl, телефон уточнюйте через форму.',
    keywords:
      'контакти дресирування, кінолог Варшава контакти, кінолог Краків контакти, запис на дресирування',
  });

  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Вкажіть ім’я.';
    if (!formData.email.trim()) {
      newErrors.email = 'Вкажіть email.';
    } else if (!/^[\w-.]+@[\w-]+\.[a-z]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Email має бути у форматі user@example.com';
    }
    if (!formData.city.trim()) newErrors.city = 'Вкажіть місто або регіон.';
    if (!formData.message.trim()) newErrors.message = 'Опишіть ваш запит.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setStatus('');
      return;
    }
    setStatus('Дякуємо! Ми зв’яжемося з вами протягом 24 годин.');
    setFormData(initialFormState);
    setErrors({});
  };

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <div className="container">
          <h1>Контакти та запис на тренування</h1>
          <p>
            Заповніть форму або напишіть нам на{' '}
            <a href="mailto:info@dog-training.pl">info@dog-training.pl</a> —
            команда координаторів підбере тренера у Варшаві або Кракові.
          </p>
        </div>
      </section>

      <section className={styles.contactGrid}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formWrapper}>
              <h2>Форма для запису</h2>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label>
                  Ім’я*
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby="name-error"
                  />
                  {errors.name && (
                    <span id="name-error" className={styles.error}>
                      {errors.name}
                    </span>
                  )}
                </label>
                <label>
                  Email*
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby="email-error"
                  />
                  {errors.email && (
                    <span id="email-error" className={styles.error}>
                      {errors.email}
                    </span>
                  )}
                </label>
                <label>
                  Місто / регіон*
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.city)}
                    aria-describedby="city-error"
                  />
                  {errors.city && (
                    <span id="city-error" className={styles.error}>
                      {errors.city}
                    </span>
                  )}
                </label>
                <label>
                  Ваш запит*
                  <textarea
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby="message-error"
                  />
                  {errors.message && (
                    <span id="message-error" className={styles.error}>
                      {errors.message}
                    </span>
                  )}
                </label>
                <p className={styles.formNote}>
                  Телефон уточнюйте через форму — ми передзвонимо або надамо
                  зручний канал для зв’язку.
                </p>
                <button type="submit" className={styles.submitBtn}>
                  Надіслати
                </button>
                {status && (
                  <p className={styles.success} aria-live="polite">
                    {status}
                  </p>
                )}
              </form>
            </div>
            <div className={styles.infoWrapper}>
              <h2>Де ми працюємо</h2>
              <div className={styles.infoCard}>
                <h3>Варшава</h3>
                <p>
                  Тренування у парках Бєляни, Мокотув, а також закритий манеж на
                  заході міста. Попередній запис обов’язковий.
                </p>
                <p>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@dog-training.pl">info@dog-training.pl</a>
                </p>
              </div>
              <div className={styles.infoCard}>
                <h3>Краків</h3>
                <p>
                  Заняття на майданчику в Подгуже, виїзні тренування у лісопарках
                  Wolski та Tyniecki. Можливі групові воркшопи.
                </p>
                <p>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@dog-training.pl">info@dog-training.pl</a>
                </p>
              </div>
              <div className={styles.infoCard}>
                <h3>Графік роботи</h3>
                <p>Пн–Пт: 09:00 – 20:00</p>
                <p>Сб: 10:00 – 16:00, Нд — за попереднім записом.</p>
                <p>
                  Консультації оновлюємо оперативно протягом робочого дня,
                  термінові ситуації розглядаємо в пріоритеті.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contacts;