import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Terms.module.css';

const CookiePolicy = () => {
  usePageMeta({
    title: 'Політика щодо cookie — Професійне дресирування собак',
    description:
      'Політика щодо використання cookie на сайті “Професійне дресирування собак”: типи файлів, мета застосування, налаштування.',
    keywords:
      'політика cookie, файли cookie, налаштування cookie',
  });

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Політика щодо файлів cookie</h1>
        <p className={styles.updated}>Останнє оновлення: 10 квітня 2024 року</p>

        <section className={styles.section}>
          <h2>1. Що таке cookie</h2>
          <p>
            Cookie — це невеликі текстові файли, які зберігаються у вашому
            браузері для забезпечення коректної роботи сайту та аналізу відвідуваності.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Які cookie ми використовуємо</h2>
          <ul>
            <li>Функціональні cookie — забезпечують роботу форми зворотного зв’язку.</li>
            <li>Аналітичні cookie — допомагають нам розуміти, як користувачі взаємодіють з сайтом, щоб покращувати контент.</li>
          </ul>
        </section>

        <section className={styles.section}>
          <h2>3. Як керувати cookie</h2>
          <p>
            Ви можете змінити налаштування cookie у браузері або відмовитися від
            їх використання через банер на сайті. Зверніть увагу, що відхилення
            деяких cookie може вплинути на роботу форми.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Зв’язок</h2>
          <p>
            Запитання та пропозиції щодо cookie надсилайте на{' '}
            <a href="mailto:info@dog-training.pl">info@dog-training.pl</a>.
          </p>
        </section>
      </div>
    </div>
  );
};

export default CookiePolicy;