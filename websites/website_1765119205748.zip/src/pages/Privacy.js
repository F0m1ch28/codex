import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Terms.module.css';

const Privacy = () => {
  usePageMeta({
    title: 'Політика конфіденційності — Професійне дресирування собак',
    description:
      'Політика конфіденційності вебсайту “Професійне дресирування собак”: збір та обробка персональних даних, права користувачів, безпека.',
    keywords:
      'політика конфіденційності, захист даних, приватність',
  });

  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Політика конфіденційності</h1>
        <p className={styles.updated}>Останнє оновлення: 10 квітня 2024 року</p>

        <section className={styles.section}>
          <h2>1. Яку інформацію ми збираємо</h2>
          <p>
            Ми збираємо дані, які ви надаєте добровільно через контактну форму:
            ім’я, email, місто та опис запиту. Ці дані потрібні для консультацій
            та організації тренувань.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Як ми використовуємо дані</h2>
          <p>
            Отримані дані використовуються для зв’язку з вами, надання
            інформації про послуги та організації навчального процесу. Ми не
            передаємо інформацію третім особам без вашої явної згоди.
          </p>
        </section>

        <section className={styles.section}>
          <h2>3. Збереження та безпека</h2>
          <p>
            Ми застосовуємо технічні та організаційні заходи для захисту
            персональних даних. Доступ до даних мають лише уповноважені члени
            команди.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Ваші права</h2>
          <p>
            Ви можете звернутися із запитом на доступ, виправлення або видалення
            даних, написавши на{' '}
            <a href="mailto:info@dog-training.pl">info@dog-training.pl</a>.
            Ми відповімо протягом 30 днів.
          </p>
        </section>

        <section className={styles.section}>
          <h2>5. Cookie та аналітика</h2>
          <p>
            Сайт може використовувати cookie для покращення роботи та збору
            статистики. Деталі описані у Політиці щодо cookie.
          </p>
        </section>
      </div>
    </div>
  );
};

export default Privacy;