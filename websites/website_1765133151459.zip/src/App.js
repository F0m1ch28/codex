import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import Services from './pages/Services';
import About from './pages/About';
import Trainers from './pages/Trainers';
import Contacts from './pages/Contacts';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

import styles from './App.module.css';

const App = () => {
  return (
    <div className={styles.app}>
      <Header />
      <main className={styles.main}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/poslugi" element={<Services />} />
          <Route path="/pro-nas" element={<About />} />
          <Route path="/nashi-trenery" element={<Trainers />} />
          <Route path="/kontakty" element={<Contacts />} />
          <Route path="/umovy-vykorystannia" element={<Terms />} />
          <Route path="/polityka-konfidentsiinosti" element={<Privacy />} />
          <Route path="/polityka-cookie" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;