import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Trainers.module.css';

const Trainers = () => {
  usePageMeta({
    title: 'Наші тренери | Професійна дресирування собак',
    description:
      'Познайомтеся з командою сертифікованих кінологів, які працюють з німецькими вівчарками у Варшаві та Кракові.',
    keywords:
      'тренери собак, кінолог Варшава, кінолог Краків, інструктор з дресирування',
  });

  const trainers = [
    {
      name: 'Олена Гриневич',
      role: 'Головна тренерка, Варшава',
      experience: '10 років роботи з вівчарками, спеціалізація — послух і виставкові програми.',
      strengths: [
        'розробка індивідуальних планів',
        'підготовка до IPO, BH-VT',
        'робота з молодими собаками',
      ],
      image: 'https://picsum.photos/420/420?random=301',
    },
    {
      name: 'Андрій Лось',
      role: 'Старший кінолог, Краків',
      experience: 'Експерт з корекції поведінки, член European Association for Canine Professionals.',
      strengths: ['поведінкова діагностика', 'підготовка службових собак', 'робота з реактивністю'],
      image: 'https://picsum.photos/420/420?random=302',
    },
    {
      name: 'Катаржина Висоцька',
      role: 'Тренерка з соціалізації',
      experience: 'Психолог за освітою, відповідає за сімейні програми та адаптацію у міському середовищі.',
      strengths: ['соціалізація щенят', 'робота з дітьми', 'побудова ритуалів'],
      image: 'https://picsum.photos/420/420?random=303',
    },
    {
      name: 'Марек Шиманський',
      role: 'Інструктор з nosework',
      experience: 'Спеціалізується на нюхових задачах, допомагає розвивати концентрацію та робочу мотивацію.',
      strengths: ['nosework', 'ігрові методики', 'мотиваційні тренування'],
      image: 'https://picsum.photos/420/420?random=304',
    },
  ];

  const certifications = [
    'Сертифікати IACP, FCI та Polish Kennel Club.',
    'Регулярна участь у семінарах від топових тренерів Європи.',
    'Партнерство з ветеринарними поведінковими спеціалістами.',
    'Участь у міжнародних виставках та змаганнях як хендлери й експерти.',
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Наші тренери</h1>
          <p>
            У нас працює міждисциплінарна команда спеціалістів. Кожен тренер відповідає за свій
            напрямок — від послуху та соціалізації до спеціальної підготовки та виставок.
          </p>
        </div>
      </section>

      <section className={styles.trainers}>
        <div className="container">
          <div className={styles.trainersGrid}>
            {trainers.map((trainer) => (
              <article key={trainer.name} className={styles.trainerCard}>
                <div className={styles.imageWrapper}>
                  <img src={trainer.image} alt={trainer.name} loading="lazy" />
                </div>
                <h2>{trainer.name}</h2>
                <p className={styles.role}>{trainer.role}</p>
                <p className={styles.experience}>{trainer.experience}</p>
                <ul className={styles.strengths}>
                  {trainer.strengths.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.certifications}>
        <div className="container">
          <h2 className="sectionTitle">Чому нам довіряють</h2>
          <ul className={styles.certList}>
            {certifications.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
};

export default Trainers;