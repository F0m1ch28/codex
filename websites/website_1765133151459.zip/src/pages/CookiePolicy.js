import React from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Legal.module.css';

const CookiePolicy = () => {
  usePageMeta({
    title: 'Політика щодо файлів cookie | Професійна дресирування собак',
    description:
      'Як ми використовуємо файли cookie на сайті Професійна дресирування собак та як ви можете керувати налаштуваннями.',
    keywords:
      'політика cookie, використання cookie, налаштування файлів cookie',
  });

  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <h1 className={styles.title}>Політика щодо файлів cookie</h1>
        <p className={styles.meta}>Оновлено: 1 квітня 2024 року</p>

        <section className={styles.section}>
          <h2>1. Що таке cookie</h2>
          <p>
            Cookie — це невеликі текстові файли, що зберігаються на вашому пристрої під час
            відвідування сайту. Вони дозволяють запам’ятовувати налаштування та покращувати досвід
            користувача.
          </p>
        </section>

        <section className={styles.section}>
          <h2>2. Типи cookie, які ми використовуємо</h2>
          <ul>
            <li>
              <strong>Сесійні cookie</strong> — забезпечують роботу окремих функцій сайту під час
              відвідування.
            </li>
            <li>
              <strong>Аналітичні cookie</strong> — допомагають розуміти, як користувачі взаємодіють
              із сайтом, щоб покращувати контент.
            </li>
            <li>
              <strong>Функціональні cookie</strong> — зберігають ваші налаштування (наприклад,
              мову).
            </li>
          </ul>
        </section>

        <section className={styles.section}>
          <h2>3. Керування cookie</h2>
          <p>
            Ви можете керувати cookie через налаштування браузера. Видалення або блокування cookie
            може вплинути на роботу окремих розділів сайту.
          </p>
        </section>

        <section className={styles.section}>
          <h2>4. Зміни політики</h2>
          <p>
            Ми можемо оновлювати політику cookie, щоб відобразити зміни у технологіях чи
            законодавстві. Будь ласка, переглядайте цю сторінку для актуальної інформації.
          </p>
        </section>

        <section className={styles.section}>
          <h2>5. Контактна інформація</h2>
          <p>
            Якщо у вас є запитання щодо використання cookie, напишіть нам на{' '}
            <a href="mailto:info@dogs-training.pl">info@dogs-training.pl</a>.
          </p>
        </section>
      </div>
    </div>
  );
};

export default CookiePolicy;