import React from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import styles from './About.module.css';

const StrategyImage = 'https://picsum.photos/900/600?random=201';
const TrainingImage = 'https://picsum.photos/900/600?random=202';
const EvaluationImage = 'https://picsum.photos/900/600?random=203';

const About = () => {
  usePageMeta({
    title: 'Про нас | Професійна дресирування собак',
    description:
      'Дізнайтеся про команду кінологів, підхід до дресирування німецьких вівчарок і стандарти роботи у Варшаві та Кракові.',
    keywords:
      'кінологічний центр, дресирування собак Варшава, дресирування собак Краків, тренери німецьких вівчарок',
  });

  const values = [
    {
      title: 'Партнерство з власником',
      description:
        'Тренування — це командна робота. Ми навчаємо людину розуміти собаку, щоб результат був стабільним і довготривалим.',
    },
    {
      title: 'Безпечні методики',
      description:
        'Використовуємо позитивні техніки, адаптовані до темпераменту собаки. Відстежуємо реакцію на кожному етапі.',
    },
    {
      title: 'Міжнародні стандарти',
      description:
        'Наші програми відповідають вимогам FCI та IACP. Постійно підвищуємо кваліфікацію на тренінгах в Європі.',
    },
  ];

  const timeline = [
    {
      year: '2012',
      title: 'Створення команди у Варшаві',
      description:
        'Засновники центру об’єднали кінологів із фокусом на роботу з вівчарками та розпочали перші програми у столиці.',
    },
    {
      year: '2016',
      title: 'Відкриття тренувальної бази у Кракові',
      description:
        'Запустили сучасний майданчик із закритим манежем, зоні соціалізації та простором для занять із молодими собаками.',
    },
    {
      year: '2019',
      title: 'Запуск онлайн-кабінету',
      description:
        'Впровадили систему віддаленого супроводу власників: відеозвіти, аналітика прогресу, рекомендації між заняттями.',
    },
    {
      year: '2023',
      title: 'Розширення спеціалізацій',
      description:
        'Додали програми з виставкової підготовки, сімейної адаптації та підвищили кількість групових занять у двох містах.',
    },
  ];

  const locations = [
    {
      city: 'Варшава',
      description:
        'Головний офіс, закрита зала площею 200 м², відкритий майданчик з різнорівневими зонами та комфортна територія для консультацій.',
    },
    {
      city: 'Краків',
      description:
        'База з тренувальною інфраструктурою, кімнатою соціалізації, міськими маршрутами та можливістю виїзних занять у Малопольському воєводстві.',
    },
  ];

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div>
              <span className="tag">Професійна дресирування собак</span>
              <h1>Команда, яка живе кінологією</h1>
              <p>
                Наші тренери понад десять років працюють з німецькими вівчарками різних ліній.
                Проводимо діагностику, розробляємо програми та супроводжуємо власників на кожному
                етапі навчання.
              </p>
            </div>
            <img src={StrategyImage} alt="Команда кінологів у Варшаві" />
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2 className="sectionTitle">Наші принципи</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <h2 className="sectionTitle">Історія розвитку</h2>
          <div className={styles.timeline}>
            {timeline.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{item.year}</span>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.trainingApproach}>
        <div className="container">
          <div className={styles.trainingGrid}>
            <div>
              <h2 className="sectionTitle">Погляд на тренування</h2>
              <p>
                У дресируванні німецької вівчарки важливі сталість, системність та повага до
                природних інстинктів. Ми вибудовуємо програми з акцентом на побудову контакту,
                підтримку емоційної рівноваги та розвиток робочої мотивації собаки.
              </p>
              <ul className={styles.list}>
                <li>Фокус на безпеці, здоров&apos;ї та психоемоційному стані собаки.</li>
                <li>Підбір методів із урахуванням досвіду та особливостей власника.</li>
                <li>Регулярні звіти, відеоаналіз, адаптація вправ до реальних умов.</li>
              </ul>
            </div>
            <img src={TrainingImage} alt="Тренування вівчарки на майданчику" />
          </div>
        </div>
      </section>

      <section className={styles.locations}>
        <div className="container">
          <h2 className="sectionTitle">Де ми працюємо</h2>
          <div className={styles.locationsGrid}>
            {locations.map((location) => (
              <article key={location.city} className={styles.locationCard}>
                <h3>{location.city}</h3>
                <p>{location.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.evaluation}>
        <div className="container">
          <div className={styles.evaluationGrid}>
            <img src={EvaluationImage} alt="Оцінка поведінки собаки" />
            <div>
              <h2 className="sectionTitle">Оцінка та супровід</h2>
              <p>
                Кожний клієнт проходить через структуровану діагностику. Ми аналізуємо поведінку,
                реакції на зовнішні подразники, стан здоров&apos;я та очікування власника. Після
                цього готуємо рекомендації і план дій з чіткими етапами.
              </p>
              <p>
                У процесі роботи ми документуємо прогрес, надаємо доступ до онлайн-кабінету, де
                зберігаються вправи, відеоматеріали та поради. Це дозволяє підтримувати результат
                після завершення офіційної програми.
              </p>
              <Link to="/kontakty" className="primaryButton">
                Замовити діагностику
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;