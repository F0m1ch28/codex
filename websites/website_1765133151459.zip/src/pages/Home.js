import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Home.module.css';

const HeroImage =
  'https://picsum.photos/1600/900?random=101&blur=1&grayscale=0&gravity=center';
const AboutImage =
  'https://picsum.photos/800/600?random=102&grayscale=0';
const ProcessImage =
  'https://picsum.photos/800/600?random=103&grayscale=0';
const TeamImageOne =
  'https://picsum.photos/400/400?random=104';
const TeamImageTwo =
  'https://picsum.photos/400/400?random=105';
const ProjectImageOne =
  'https://picsum.photos/1200/800?random=106';
const ProjectImageTwo =
  'https://picsum.photos/1200/800?random=107';
const ProjectImageThree =
  'https://picsum.photos/1200/800?random=108';
const ProjectImageFour =
  'https://picsum.photos/1200/800?random=109';
const ProjectImageFive =
  'https://picsum.photos/1200/800?random=110';
const ProjectImageSix =
  'https://picsum.photos/1200/800?random=111';

const Home = () => {
  usePageMeta({
    title: 'Професійна дресирування собак | Німецькі вівчарки у Варшаві та Кракові',
    description:
      'Індивідуальні програми дресирування німецьких вівчарок у Варшаві та Кракові. Професійні кінологи, сучасні методики, безпечний підхід.',
    keywords:
      'дресирування собак, німецька вівчарка, кінолог Варшава, кінолог Краків, навчання собак, корекція поведінки',
  });

  const statsConfig = useMemo(
    () => [
      { label: 'років досвіду', value: 12 },
      { label: 'кінологічних програм', value: 145 },
      { label: 'сертифікованих тренерів', value: 6 },
      { label: 'задоволених власників', value: 310 },
    ],
    []
  );

  const [stats, setStats] = useState(statsConfig.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Всі');
  const [openFaqIndex, setOpenFaqIndex] = useState(null);
  const [formData, setFormData] = useState({ name: '', phone: '', message: '' });
  const [errors, setErrors] = useState({});

  const advantages = [
    {
      title: 'Досвідчені тренери',
      description:
        'Команда кінологів із міжнародними сертифікатами IACP, FCI та десятками успішних кейсів у Європі.',
      icon: '🎖️',
    },
    {
      title: 'Індивідуальний підхід',
      description:
        'Програми підбираються після детальної оцінки темпераменту, потреб родини та побуту собаки.',
      icon: '🧭',
    },
    {
      title: 'Сучасні методи',
      description:
        'Використовуємо позитивне підкріплення, ігрові методики та науково обґрунтовані техніки.',
      icon: '🔬',
    },
    {
      title: 'Дві локації',
      description: 'Повноцінні центри тренувань у Варшаві та Кракові, виїзні заняття та онлайн-кабінети.',
      icon: '📍',
    },
  ];

  const servicesPreview = [
    {
      title: 'Курс послуху',
      summary:
        'Розвиваємо слухняність, закріплюємо базові команди, формуємо сильний контакт із власником.',
      link: '/poslugi',
    },
    {
      title: 'Корекція поведінки',
      summary:
        'Опрацьовуємо надмірний гавкіт, агресію, страхи та небажані звички за структурованою програмою.',
      link: '/poslugi',
    },
    {
      title: 'Підготовка до виставок',
      summary:
        'Відпрацьовуємо стійку, рингові елементи та представлення собаки під час офіційних заходів.',
      link: '/poslugi',
    },
  ];

  const processSteps = [
    {
      title: 'Діагностика та консультація',
      description:
        'Проводимо спостереження за собакою, інтерв’ю з власником, формуємо рекомендації.',
    },
    {
      title: 'Створення програми',
      description:
        'Розробляємо покроковий план тренувань, визначаємо формат занять та інструменти контролю.',
    },
    {
      title: 'Практичні заняття',
      description:
        'Працюємо на майданчику, у міських умовах та вдома для побудови стійких навичок поведінки.',
    },
    {
      title: 'Моніторинг та підтримка',
      description:
        'Відстежуємо прогрес, коригуємо вправи, готуємо підсумковий звіт і рекомендації для власника.',
    },
  ];

  const testimonials = [
    {
      name: 'Марта Ковалевська',
      city: 'Варшава',
      quote:
        'Після курсу наша вівчарка навчилась стримано реагувати на інших собак і працювати поруч без повідця. Підхід дуже людяний й професійний.',
    },
    {
      name: 'Ігор та Анна Новіцькі',
      city: 'Краків',
      quote:
        'Команда детально пояснювала кожне завдання. Тренери навчали не тільки собаку, а й нас, як правильно підтримувати результат.',
    },
    {
      name: 'Оля Рудницька',
      city: 'Варшава',
      quote:
        'Дуже сподобалось, що заняття проводилися в різних умовах. Тепер собака спокійно їздить трамваєм і слухається у парку.',
    },
  ];

  const projects = [
    {
      title: 'Розвиток послуху в міському середовищі',
      category: 'Послух',
      image: ProjectImageOne,
    },
    {
      title: 'Корекція страхів у молодої вівчарки',
      category: 'Корекція поведінки',
      image: ProjectImageTwo,
    },
    {
      title: 'Підготовка до виставок FCI',
      category: 'Виставки',
      image: ProjectImageThree,
    },
    {
      title: 'Патрульна підготовка',
      category: 'Спецпідготовка',
      image: ProjectImageFour,
    },
    {
      title: 'Сімейна соціалізація',
      category: 'Послух',
      image: ProjectImageFive,
    },
    {
      title: 'Онлайн супровід власника',
      category: 'Консультації',
      image: ProjectImageSix,
    },
  ];

  const faqItems = [
    {
      question: 'Скільки триває базова програма дресирування німецької вівчарки?',
      answer:
        'Середня тривалість — від 8 до 12 тижнів залежно від віку, темпераменту та цілей. Ми формуємо графік після діагностики.',
    },
    {
      question: 'Чи можна поєднувати заняття на майданчику і вдома?',
      answer:
        'Так, ми комбінуємо тренування на наших локаціях у Варшаві або Кракові з візитами до дому власника та практикою у вашому районі.',
    },
    {
      question: 'Які методи ви використовуєте?',
      answer:
        'Працюємо на принципах позитивного підкріплення, чітких правил та поступової адаптації. Не використовуємо жорстких методів.',
    },
    {
      question: 'Чи проводите онлайн-консультації?',
      answer:
        'Ми проводимо відеоконференції, надаємо рекомендації та відстежуємо домашні завдання через онлайн-кабінет.',
    },
    {
      question: 'Чи є групові заняття?',
      answer:
        'Так, ми формуємо невеликі групи після проходження індивідуальної підготовки, коли собака готова до контролю серед інших.',
    },
  ];

  const blogPosts = [
    {
      title: '5 ключових етапів соціалізації німецької вівчарки',
      date: '3 квітня 2024',
      excerpt:
        'Розповідаємо, як поєднати тренування на майданчику та у місті, щоб сформувати стабільну поведінку та упевненість.',
      link: '/poslugi',
    },
    {
      title: 'Як підготувати собаку до переїзду у нове місто',
      date: '22 березня 2024',
      excerpt:
        'Поради для власників, які планують зміну середовища разом із собакою: транспорт, знайомство з новими місцями, ритуали.',
      link: '/pro-nas',
    },
    {
      title: 'Роль власника у тренуваннях: практичні рекомендації',
      date: '10 березня 2024',
      excerpt:
        'Як підтримувати результат між заняттями та закріплювати нові навички собаки у повсякденних ситуаціях.',
      link: '/nashi-trenery',
    },
  ];

  useEffect(() => {
    let frame = 0;
    const totalFrames = 40;
    const interval = setInterval(() => {
      frame += 1;
      setStats(
        statsConfig.map((item) =>
          Math.min(item.value, Math.round((item.value * frame) / totalFrames))
        )
      );
      if (frame === totalFrames) {
        clearInterval(interval);
      }
    }, 40);
    return () => clearInterval(interval);
  }, [statsConfig]);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const categories = ['Всі', 'Послух', 'Корекція поведінки', 'Виставки', 'Спецпідготовка', 'Консультації'];
  const filteredProjects =
    activeCategory === 'Всі'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const handleFaqToggle = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  const handleFormChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Будь ласка, вкажіть ім'я.";
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Будь ласка, залиште номер телефону для зв’язку.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Опишіть запит коротко (мінімум 10 символів).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (!validateForm()) {
      return;
    }
    alert('Дякуємо! Ми зв’яжемося з вами найближчим часом.');
    setFormData({ name: '', phone: '', message: '' });
    setErrors({});
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero} style={{ backgroundImage: `url(${HeroImage})` }}>
        <div className={styles.heroOverlay} />
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <span className="tag fadeInUp">Варшава · Краків</span>
            <h1 className={`${styles.heroTitle} fadeInUp`}>
              Професійна дресирування німецьких вівчарок
            </h1>
            <p className={`${styles.heroSubtitle} fadeInUp`}>
              Вибудовуємо впевнену поведінку, послух та довіру між собакою і власником. Програми, що
              адаптуються під ваш стиль життя.
            </p>
            <div className={styles.heroButtons}>
              <Link to="/kontakty" className="primaryButton fadeInUp">
                Записатися на консультацію
              </Link>
              <Link to="/poslugi" className="secondaryButton fadeInUp">
                Переглянути послуги
              </Link>
            </div>
          </div>
          <div className={styles.heroStats}>
            {statsConfig.map((item, index) => (
              <div key={item.label} className={`${styles.heroStatCard} shadowCard`}>
                <span className={styles.statValue}>{stats[index]}+</span>
                <span className={styles.statLabel}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className="container">
          <h2 className="sectionTitle">Наші переваги</h2>
          <p className="sectionSubtitle">
            Ми поєднуємо експертизу кінологів, сучасні методи навчання та глибоке розуміння
            психіки німецьких вівчарок.
          </p>
          <div className={styles.advantagesGrid}>
            {advantages.map((advantage) => (
              <article key={advantage.title} className={`${styles.advantageCard} gradientBorder`}>
                <div className={styles.advantageInner}>
                  <span className={styles.advantageIcon}>{advantage.icon}</span>
                  <h3>{advantage.title}</h3>
                  <p>{advantage.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.aboutBreed}>
        <div className="container">
          <div className={styles.aboutGrid}>
            <div className={styles.aboutText}>
              <h2 className="sectionTitle">Чому варто інвестувати у дресирування вівчарки</h2>
              <p>
                Німецька вівчарка — собака з потужним інтелектом, високою працездатністю й природним
                бажанням співпрацювати з людиною. Правильно налаштоване середовище тренувань
                дозволяє розкрити її потенціал у сімейній, спортивній або професійній діяльності.
              </p>
              <ul className={styles.aboutList}>
                <li>Розвиток стійких навичок послуху та концентрації у різних ситуаціях.</li>
                <li>Підтримка фізичної та ментальної форми через структуровані заняття.</li>
                <li>Попередження поведінкових проблем завдяки ранній соціалізації.</li>
              </ul>
              <Link to="/pro-nas" className="secondaryButton">
                Дізнатися більше про підхід
              </Link>
            </div>
            <div className={styles.aboutMedia}>
              <div className="gradientBorder">
                <img src={AboutImage} alt="Дресирування німецької вівчарки" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <h2 className="sectionTitle">Основні напрямки роботи</h2>
          <p className="sectionSubtitle">
            Ми структурували послуги так, щоб ви отримали повний цикл підготовки — від базового
            послуху до спеціалізованих програм.
          </p>
          <div className={styles.servicesGrid}>
            {servicesPreview.map((service) => (
              <article key={service.title} className={`${styles.serviceCard} shadowCard`}>
                <h3>{service.title}</h3>
                <p>{service.summary}</p>
                <Link to={service.link} className={styles.serviceLink}>
                  Деталі послуги →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.processHeader}>
            <div>
              <h2 className="sectionTitle">Як будується співпраця</h2>
              <p className="sectionSubtitle">
                Прозорий маршрут — від першої зустрічі до закріплення результату на практиці.
              </p>
            </div>
            <div className={styles.processImageWrapper}>
              <img src={ProcessImage} alt="Тренувальний процес з вівчаркою" />
            </div>
          </div>
          <div className={styles.processSteps}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processCard}>
                <span className={styles.processIndex}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <h2 className="sectionTitle">Відгуки власників</h2>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
              >
                <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
                <div className={styles.testimonialAuthor}>
                  <span>{testimonial.name}</span>
                  <small>{testimonial.city}</small>
                </div>
              </article>
            ))}
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Відгук ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <h2 className="sectionTitle">Команда, якій довіряють</h2>
          <p className="sectionSubtitle">
            Наші головні тренери очолюють програми у Варшаві та Кракові, супроводжуючи кожного
            клієнта від першої консультації до фінальної атестації.
          </p>
          <div className={styles.teamGrid}>
            <article className={styles.teamCard}>
              <div className={styles.teamImage}>
                <img src={TeamImageOne} alt="Тренерка Олена Гриневич" loading="lazy" />
              </div>
              <h3>Олена Гриневич</h3>
              <p className={styles.teamRole}>Головна тренерка, Варшава</p>
              <p className={styles.teamBio}>
                10 років роботи з вівчарками службових та сімейних ліній. Спеціалізація — послух у
                міських умовах, підготовка до IPO.
              </p>
            </article>
            <article className={styles.teamCard}>
              <div className={styles.teamImage}>
                <img src={TeamImageTwo} alt="Кінолог Андрій Лось" loading="lazy" />
              </div>
              <h3>Андрій Лось</h3>
              <p className={styles.teamRole}>Старший кінолог, Краків</p>
              <p className={styles.teamBio}>
                Експерт з корекції поведінки та сценаріїв сімейної соціалізації. Сертифікований
                інструктор FCI, куратор програм для молодих собак.
              </p>
            </article>
          </div>
          <Link to="/nashi-trenery" className="secondaryButton">
            Уся команда
          </Link>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <h2 className="sectionTitle">Проєкти та кейси</h2>
          <div className={styles.filterBar}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  activeCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <h2 className="sectionTitle">Поширені запитання</h2>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={item.question} className={`${styles.faqItem} ${isOpen ? styles.faqOpen : ''}`}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => handleFaqToggle(index)}
                    aria-expanded={isOpen}
                  >
                    <span>{item.question}</span>
                    <span className={styles.faqIcon}>{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && <p className={styles.faqAnswer}>{item.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <h2 className="sectionTitle">Останні матеріали</h2>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>
                  Читати →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <div>
              <h2>Готові до першого заняття?</h2>
              <p>
                Залиште заявку, і ми підберемо програму відповідно до віку та характеру вашої
                німецької вівчарки.
              </p>
            </div>
            <Link to="/kontakty" className="primaryButton">
              Написати нам
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.contactForm}>
        <div className="container">
          <div className={styles.formWrapper}>
            <div className={styles.formIntro}>
              <h2 className="sectionTitle">Залиште запит на консультацію</h2>
              <p>
                Ми зв’яжемося з вами протягом робочого дня, щоб обговорити цілі тренувань, формат і
                зручний графік занять.
              </p>
              <ul className={styles.contactDetails}>
                <li>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+48123456789">+48 123 456 789</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@dogs-training.pl">info@dogs-training.pl</a>
                </li>
                <li>
                  <strong>Офіс:</strong> вул. Канонічна, 12, 00-278 Варшава, Польща
                </li>
              </ul>
            </div>
            <form className={styles.form} onSubmit={handleFormSubmit} noValidate>
              <label className={styles.label}>
                Ім&apos;я
                <input
                  type="text"
                  name="name"
                  placeholder="Як до вас звертатися?"
                  value={formData.name}
                  onChange={handleFormChange}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </label>
              <label className={styles.label}>
                Телефон
                <input
                  type="tel"
                  name="phone"
                  placeholder="+48 ..."
                  value={formData.phone}
                  onChange={handleFormChange}
                />
                {errors.phone && <span className={styles.error}>{errors.phone}</span>}
              </label>
              <label className={styles.label}>
                Коротке повідомлення
                <textarea
                  name="message"
                  rows="4"
                  placeholder="Опишіть завдання або питання"
                  value={formData.message}
                  onChange={handleFormChange}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </label>
              <button type="submit" className="primaryButton">
                Надіслати
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;