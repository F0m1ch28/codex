import React, { useState } from 'react';
import usePageMeta from '../hooks/usePageMeta';
import styles from './Contacts.module.css';

const Contacts = () => {
  usePageMeta({
    title: 'Контакти | Професійна дресирування собак',
    description:
      'Зв’яжіться з нами, щоб обрати програму дресирування німецької вівчарки у Варшаві або Кракові. Консультації та діагностика.',
    keywords:
      'контакти кінолога, запис на дресирування, консультація кінолога Варшава, консультація кінолога Краків',
  });

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    city: 'Варшава',
    message: '',
  });
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Вкажіть ім'я.";
    if (!formData.phone.trim()) newErrors.phone = 'Залиште номер телефону для зв’язку.';
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Опишіть запит (мінімум 10 символів).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    alert('Дякуємо за звернення! Ми перетелефонуємо найближчим часом.');
    setFormData({
      name: '',
      phone: '',
      email: '',
      city: 'Варшава',
      message: '',
    });
    setErrors({});
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Контакти</h1>
          <p>
            Ми проводимо консультації та заняття у двох містах: Варшава і Краків. Залиште заявку або
            звертайтеся будь-яким зручним способом.
          </p>
        </div>
      </section>

      <section className={styles.contactInfo}>
        <div className="container">
          <div className={styles.infoGrid}>
            <div className={styles.infoCard}>
              <h2>Зв’язок</h2>
              <ul>
                <li>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+48123456789">+48 123 456 789</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@dogs-training.pl">info@dogs-training.pl</a>
                </li>
                <li>
                  <strong>Офіс:</strong> вул. Канонічна, 12, 00-278 Варшава, Польща
                </li>
                <li>
                  <strong>Графік:</strong> Пн–Сб 09:00–19:00 (за попереднім записом)
                </li>
              </ul>
            </div>
            <div className={styles.mapCard}>
              <iframe
              title="Офіс Професійна дресирування собак у Варшаві"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2443.971090952575!2d21.0107684772328!3d52.249729755582654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471ecc62519a9523%3A0x8c0b09a2a5f2d6d5!2sKanonicza%2012%2C%2000-278%20Warszawa!5e0!3m2!1suk!2spl!4v1700000000000!5m2!1suk!2spl"
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.formSection}>
        <div className="container">
          <div className={styles.formCard}>
            <div className={styles.formIntro}>
              <h2>Замовити консультацію</h2>
              <p>
                Заповніть форму, і наш менеджер узгодить з вами дату діагностики або першого
                заняття. Ми працюємо з клієнтами за попереднім записом.
              </p>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label>
                Ім&apos;я
                <input
                  type="text"
                  name="name"
                  placeholder="Ваше ім'я"
                  value={formData.name}
                  onChange={handleChange}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </label>
              <label>
                Телефон
                <input
                  type="tel"
                  name="phone"
                  placeholder="+48 ..."
                  value={formData.phone}
                  onChange={handleChange}
                />
                {errors.phone && <span className={styles.error}>{errors.phone}</span>}
              </label>
              <label>
                Email (за бажанням)
                <input
                  type="email"
                  name="email"
                  placeholder="example@domain.com"
                  value={formData.email}
                  onChange={handleChange}
                />
              </label>
              <label>
                Місто
                <select name="city" value={formData.city} onChange={handleChange}>
                  <option value="Варшава">Варшава</option>
                  <option value="Краків">Краків</option>
                  <option value="Онлайн">Онлайн консультація</option>
                </select>
              </label>
              <label>
                Повідомлення
                <textarea
                  name="message"
                  rows="4"
                  placeholder="Опишіть ваш запит"
                  value={formData.message}
                  onChange={handleChange}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </label>
              <button type="submit" className="primaryButton">
                Надіслати заявку
              </button>
              <p className={styles.notice}>
                Надсилаючи форму, ви погоджуєтеся з{' '}
                <a href="/polityka-konfidentsiinosti">політикою конфіденційності</a>.
              </p>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contacts;