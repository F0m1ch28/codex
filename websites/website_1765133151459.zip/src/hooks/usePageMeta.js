import { useEffect } from 'react';

const ensureMetaTag = (name, content) => {
  if (!content) return;
  let element = document.querySelector(`meta[name="${name}"]`);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute('name', name);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
};

const usePageMeta = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    ensureMetaTag('description', description);
    ensureMetaTag('keywords', keywords);
  }, [title, description, keywords]);
};

export default usePageMeta;