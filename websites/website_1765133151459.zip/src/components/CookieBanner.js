import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem('cookie-consent');
    if (!storedConsent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('cookie-consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={`container ${styles.bannerInner}`}>
        <div>
          <p className={styles.title}>Ми використовуємо cookie 🍪</p>
          <p className={styles.text}>
            Це допомагає покращувати сервіс, аналізувати взаємодію та адаптувати матеріали.
            Детальніше у <Link to="/polityka-cookie">політиці щодо файлів cookie</Link>.
          </p>
        </div>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Зрозуміло
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;