import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleToggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const handleCloseMenu = () => {
    setIsMenuOpen(false);
  };

  const navLinks = [
    { path: '/', label: 'Головна' },
    { path: '/poslugi', label: 'Послуги' },
    { path: '/pro-nas', label: 'Про нас' },
    { path: '/nashi-trenery', label: 'Наші тренери' },
    { path: '/kontakty', label: 'Контакти' },
  ];

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ''}`}>
      <div className={`container ${styles.headerInner}`}>
        <Link to="/" className={styles.logo} onClick={handleCloseMenu}>
          <span className={styles.logoAccent}>Професійна</span> дресирування
        </Link>

        <button
          className={styles.toggleButton}
          onClick={handleToggleMenu}
          aria-expanded={isMenuOpen}
          aria-label="Перемкнути меню"
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`${styles.navigation} ${isMenuOpen ? styles.navigationOpen : ''}`}>
          <ul className={styles.navList}>
            {navLinks.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                  }
                  onClick={handleCloseMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/kontakty" className={styles.navCta} onClick={handleCloseMenu}>
            Записатися
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;