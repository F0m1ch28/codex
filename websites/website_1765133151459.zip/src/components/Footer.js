import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.footerInner}`}>
        <div className={styles.brand}>
          <p className={styles.brandName}>Професійна дресирування собак</p>
          <p className={styles.brandText}>
            Комплексні програми дресирування для німецьких вівчарок у Варшаві та Кракові. Створюємо
            міцні партнерські відносини між людьми і собаками.
          </p>
        </div>

        <div className={styles.columns}>
          <div className={styles.column}>
            <p className={styles.columnTitle}>Контакти</p>
            <ul className={styles.columnList}>
              <li>вул. Канонічна, 12, 00-278 Варшава, Польща</li>
              <li>
                Телефон:{' '}
                <a href="tel:+48123456789" className={styles.link}>
                  +48 123 456 789
                </a>
              </li>
              <li>
                Email:{' '}
                <a href="mailto:info@dogs-training.pl" className={styles.link}>
                  info@dogs-training.pl
                </a>
              </li>
            </ul>
          </div>

          <div className={styles.column}>
            <p className={styles.columnTitle}>Навігація</p>
            <ul className={styles.columnList}>
              <li>
                <Link to="/poslugi">Послуги</Link>
              </li>
              <li>
                <Link to="/pro-nas">Про нас</Link>
              </li>
              <li>
                <Link to="/nashi-trenery">Наші тренери</Link>
              </li>
              <li>
                <Link to="/kontakty">Контакти</Link>
              </li>
            </ul>
          </div>

          <div className={styles.column}>
            <p className={styles.columnTitle}>Політики</p>
            <ul className={styles.columnList}>
              <li>
                <Link to="/umovy-vykorystannia">Умови використання</Link>
              </li>
              <li>
                <Link to="/polityka-konfidentsiinosti">Політика конфіденційності</Link>
              </li>
              <li>
                <Link to="/polityka-cookie">Політика щодо файлів cookie</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className={styles.bottomBar}>
        <div className="container">
          <p className={styles.copy}>
            © {new Date().getFullYear()} Професійна дресирування собак. Усі права захищено.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;