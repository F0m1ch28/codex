document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav__toggle");
  const navMenu = document.querySelector("[data-nav-menu]");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const isOpen = navMenu.classList.toggle("is-open");
      navToggle.classList.toggle("is-open", isOpen);
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  const banner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const consentKey = "websiteCookieConsent";
  if (banner && acceptBtn && declineBtn) {
    const saved = localStorage.getItem(consentKey);
    if (!saved) {
      setTimeout(() => banner.classList.add("is-visible"), 600);
    }

    const handleConsent = (value) => {
      localStorage.setItem(consentKey, JSON.stringify({ value, timestamp: new Date().toISOString() }));
      banner.classList.remove("is-visible");
    };

    acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    declineBtn.addEventListener("click", () => handleConsent("declined"));
  }

  const contactForm = document.querySelector("[data-contact-form]");
  if (contactForm) {
    const messageNode = contactForm.querySelector(".form__message");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const name = formData.get("name").trim();
      const email = formData.get("email").trim();
      const message = formData.get("message").trim();

      if (!name || !email || !message) {
        messageNode.textContent = "Пожалуйста, заполните обязательные поля.";
        messageNode.classList.remove("form__message--success");
        messageNode.classList.add("form__message--error");
        return;
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        messageNode.textContent = "Введите корректный адрес электронной почты.";
        messageNode.classList.remove("form__message--success");
        messageNode.classList.add("form__message--error");
        return;
      }

      contactForm.reset();
      messageNode.textContent = "Спасибо! Мы свяжемся с вами в ближайшее время.";
      messageNode.classList.remove("form__message--error");
      messageNode.classList.add("form__message--success");
    });
  }

  const cookieSettingsLink = document.getElementById("cookie-settings-link");
  if (cookieSettingsLink && banner) {
    cookieSettingsLink.addEventListener("click", (event) => {
      event.preventDefault();
      banner.classList.add("is-visible");
    });
  }
});