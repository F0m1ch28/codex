import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'techsolutions-cookie-consent';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(STORAGE_KEY, 'declined');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4 className={styles.title}>We value your privacy</h4>
        <p className={styles.message}>
          We use cookies to enhance your browsing experience, analyze site traffic, and support our marketing efforts. You can accept or decline cookies at any time.
        </p>
        <div className={styles.actions}>
          <button className={styles.decline} onClick={handleDecline}>
            Decline
          </button>
          <button className={styles.accept} onClick={handleAccept}>
            Accept
          </button>
        </div>
      </div>
    </aside>
  );
}

export default CookieBanner;