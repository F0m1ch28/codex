import React, { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('aurora-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('aurora-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          We use cookies to personalize content, to provide social media
          features, and to analyze our traffic. By clicking “Accept”, you agree
          to our use of cookies.
        </p>
        <div className="cookie-actions">
          <button className="button button-secondary" onClick={acceptCookies}>
            Accept
          </button>
          <a className="cookie-link" href="/privacy">
            Learn more
          </a>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;