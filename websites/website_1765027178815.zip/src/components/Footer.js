import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="logo footer-logo">
            <span className="logo-mark">AD</span>
            <span className="logo-type">
              Aurora <span>Dynamics</span>
            </span>
          </div>
          <p>
            Aurora Dynamics partners with ambitious organizations to deliver
            measurable impact through strategy, technology, and experience-led
            innovation.
          </p>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
              Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>

        <div className="footer-column">
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">About Aurora Dynamics</Link>
            </li>
            <li>
              <Link to="/#team">Leadership</Link>
            </li>
            <li>
              <Link to="/#projects">Case Studies</Link>
            </li>
            <li>
              <Link to="/#insights">Insights</Link>
            </li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Solutions</h4>
          <ul>
            <li>
              <Link to="/services">Digital Strategy</Link>
            </li>
            <li>
              <Link to="/services">Product Innovation</Link>
            </li>
            <li>
              <Link to="/services">Experience Design</Link>
            </li>
            <li>
              <Link to="/services">Intelligent Automation</Link>
            </li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Contact</h4>
          <ul>
            <li>
              <a href="mailto:hello@auroradynamics.com">hello@auroradynamics.com</a>
            </li>
            <li>+1 (415) 555-0199</li>
            <li>300 Market Street, Suite 1200</li>
            <li>San Francisco, CA 94105</li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Aurora Dynamics. All rights reserved.</p>
        <div className="footer-bottom-links">
          <Link to="/privacy">Privacy Policy</Link>
          <Link to="/terms">Terms of Service</Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;