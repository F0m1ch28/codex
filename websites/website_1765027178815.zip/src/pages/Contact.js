import React, { useState } from 'react';

const Contact = () => {
  const initialState = {
    name: '',
    email: '',
    company: '',
    message: ''
  };

  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide a business email.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.company.trim()) newErrors.company = 'Please enter your company name.';
    if (!formData.message.trim()) newErrors.message = 'Tell us a bit about your goals.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      setFormData(initialState);
    }, 1500);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container page-hero-grid">
          <div>
            <p className="eyebrow">Contact us</p>
            <h1>Let’s shape the future of your organization.</h1>
            <p>
              Share your vision, challenges, or upcoming initiatives. We’ll connect you with the right leaders across strategy,
              design, and engineering to explore how Aurora Dynamics can partner with you.
            </p>
            <div className="contact-meta">
              <div>
                <h3>Email</h3>
                <a href="mailto:hello@auroradynamics.com">hello@auroradynamics.com</a>
              </div>
              <div>
                <h3>Phone</h3>
                <a href="tel:+14155550199">+1 (415) 555-0199</a>
              </div>
              <div>
                <h3>HQ</h3>
                <p>300 Market Street, Suite 1200, San Francisco, CA</p>
              </div>
            </div>
          </div>
          <div className="contact-card">
            {submitted ? (
              <div className="contact-success" role="status">
                <h2>Thank you!</h2>
                <p>
                  We’ve received your message and a member of our team will reach out within one business day.
                </p>
              </div>
            ) : (
              <form className="contact-form" onSubmit={handleSubmit} noValidate>
                <div className="form-group">
                  <label htmlFor="name">Full name</label>
                  <input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(event) =>
                      setFormData({ ...formData, name: event.target.value })
                    }
                    aria-invalid={errors.name ? 'true' : 'false'}
                  />
                  {errors.name && <span className="error">{errors.name}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="email">Business email</label>
                  <input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(event) =>
                      setFormData({ ...formData, email: event.target.value })
                    }
                    aria-invalid={errors.email ? 'true' : 'false'}
                  />
                  {errors.email && <span className="error">{errors.email}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="company">Company / Organization</label>
                  <input
                    id="company"
                    type="text"
                    value={formData.company}
                    onChange={(event) =>
                      setFormData({ ...formData, company: event.target.value })
                    }
                    aria-invalid={errors.company ? 'true' : 'false'}
                  />
                  {errors.company && <span className="error">{errors.company}</span>}
                </div>
                <div className="form-group">
                  <label htmlFor="message">How can we help?</label>
                  <textarea
                    id="message"
                    rows="4"
                    value={formData.message}
                    onChange={(event) =>
                      setFormData({ ...formData, message: event.target.value })
                    }
                    aria-invalid={errors.message ? 'true' : 'false'}
                  />
                  {errors.message && <span className="error">{errors.message}</span>}
                </div>
                <button
                  type="submit"
                  className="button button-primary button-large"
                  disabled={submitting}
                >
                  {submitting ? 'Sending...' : 'Submit message'}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;