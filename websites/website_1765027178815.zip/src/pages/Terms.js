import React from 'react';

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero slim">
        <div className="container">
          <p className="eyebrow">Terms of Service</p>
          <h1>General Terms & Conditions</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container legal-container">
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing or using the Aurora Dynamics website or services, you agree to be bound by these Terms of Service.
            If you do not agree to these terms, please do not use our services.
          </p>

          <h2>2. Services</h2>
          <p>
            Aurora Dynamics provides advisory, design, and technology services. Specific terms of service engagements
            are defined within individual statements of work and master services agreements.
          </p>

          <h2>3. Intellectual Property</h2>
          <p>
            All content provided on this site is the intellectual property of Aurora Dynamics unless otherwise noted.
            You may not use, reproduce, or distribute any materials without prior written consent.
          </p>

          <h2>4. Confidentiality</h2>
          <p>
            We maintain strict confidentiality of client information and expect the same level of discretion from our partners.
          </p>

          <h2>5. Limitation of Liability</h2>
          <p>
            Aurora Dynamics will not be liable for any indirect, incidental, special, or consequential damages arising
            out of or in connection with our services or website usage.
          </p>

          <h2>6. Governing Law</h2>
          <p>
            These terms are governed by the laws of the State of California, without regard to its conflict of law provisions.
          </p>

          <h2>7. Contact</h2>
          <p>
            For questions regarding these terms, please contact us at <a href="mailto:legal@auroradynamics.com">legal@auroradynamics.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;