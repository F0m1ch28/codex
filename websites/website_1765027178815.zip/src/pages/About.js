import React from 'react';

const About = () => {
  const principles = [
    {
      title: 'Outcome-obsessed',
      description:
        'We anchor every engagement in measurable business value and track progress relentlessly.'
    },
    {
      title: 'Co-creation first',
      description:
        'We work shoulder-to-shoulder with your teams to build capability, ownership, and lasting momentum.'
    },
    {
      title: 'Human-centered',
      description:
        'We design experiences that empower people—customers, employees, and partners alike.'
    },
    {
      title: 'Adaptable by design',
      description:
        'We anticipate change, designing systems and experiences that evolve with your business.'
    }
  ];

  const milestones = [
    {
      year: '2017',
      title: 'Aurora Dynamics founded',
      description:
        'Born from a vision to align strategy, design, and engineering within a single collaborative studio.'
    },
    {
      year: '2019',
      title: 'Global delivery hubs launched',
      description:
        'Expanded to Toronto, Berlin, and Singapore to provide 24/7 agility and access to specialized talent.'
    },
    {
      year: '2021',
      title: 'Impact lab introduced',
      description:
        'Created Aurora Impact Lab to accelerate sustainability and ESG solutions with measurable ROI.'
    },
    {
      year: '2023',
      title: 'Enterprise AI practice scaled',
      description:
        'Implemented responsible AI frameworks and automation for Fortune 200 clients across industries.'
    }
  ];

  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container page-hero-grid">
          <div>
            <p className="eyebrow">About Aurora Dynamics</p>
            <h1>Shaping the future with bold ideas and disciplined execution.</h1>
            <p>
              Aurora Dynamics is a digital transformation consultancy helping leaders evolve their organizations
              through data, technology, and experience design. We operate as multidisciplinary partners,
              combining strategic foresight with hands-on delivery to convert ambition into sustainable advantage.
            </p>
          </div>
          <div className="page-hero-media">
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Aurora Dynamics team workshop"
              className="responsive-image"
              onLoad={(event) => event.currentTarget.classList.add('loaded')}
            />
          </div>
        </div>
      </section>

      <section className="values-section">
        <div className="container">
          <div className="section-heading">
            <p className="eyebrow">Our DNA</p>
            <h2>Principles that power every engagement.</h2>
          </div>
          <div className="values-grid">
            {principles.map((principle) => (
              <article className="value-card" key={principle.title}>
                <h3>{principle.title}</h3>
                <p>{principle.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="milestones-section">
        <div className="container">
          <div className="section-heading">
            <p className="eyebrow">Our Journey</p>
            <h2>The milestones that shaped Aurora Dynamics.</h2>
          </div>
          <div className="timeline">
            {milestones.map((milestone) => (
              <div className="timeline-item" key={milestone.year}>
                <div className="timeline-year">{milestone.year}</div>
                <div className="timeline-content">
                  <h3>{milestone.title}</h3>
                  <p>{milestone.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="culture-section">
        <div className="container culture-grid">
          <div>
            <p className="eyebrow">Culture</p>
            <h2>A collaborative studio built for continuous learning.</h2>
            <p>
              We invest in cross-functional squads where strategists, designers, engineers, and change leaders
              co-create. Our culture celebrates curiosity, experimentation, and inclusive leadership.
            </p>
            <p>
              Every engagement includes capability uplift—knowledge share sessions, playbooks, and embedded coaches—
              so your teams can carry the momentum forward.
            </p>
          </div>
          <div className="culture-media">
            <img
              src="https://picsum.photos/800/600?random=24"
              alt="Collaborative workshop session"
              className="responsive-image"
              onLoad={(event) => event.currentTarget.classList.add('loaded')}
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;