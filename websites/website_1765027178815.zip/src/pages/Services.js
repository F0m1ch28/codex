import React, { useState } from 'react';

const Services = () => {
  const services = [
    {
      id: 'strategy',
      title: 'Digital Strategy & Transformation',
      description:
        'Build a clear vision and roadmap backed by actionable data, stakeholder alignment, and prioritized initiatives.',
      detailPoints: [
        'Transformation roadmaps & investment cases',
        'Executive stakeholder alignment and operating model design',
        'Capability maturity assessment and change management',
        'Value-tracking dashboards and OKR frameworks'
      ]
    },
    {
      id: 'product',
      title: 'Product Innovation & Delivery',
      description:
        'Launch new products and services faster with design-led experimentation and scalable engineering practices.',
      detailPoints: [
        'Innovation sprints and opportunity framing',
        'Human-centered research and concept validation',
        'Product architecture, prototyping, and agile delivery',
        'Launch orchestration and growth experimentation'
      ]
    },
    {
      id: 'experience',
      title: 'Experience Design & Service Blueprinting',
      description:
        'Deliver cohesive omnichannel experiences that delight users and empower your teams to deliver excellence.',
      detailPoints: [
        'Experience audits and journey mapping',
        'Service design, blueprinting, and governance',
        'Design systems and accessibility enablement',
        'Employee experience and enablement playbooks'
      ]
    },
    {
      id: 'automation',
      title: 'AI, Automation & Analytics',
      description:
        'Unlock new value through intelligent automation, AI augmentation, and modern data ecosystems.',
      detailPoints: [
        'AI readiness and responsible AI frameworks',
        'Automation opportunity discovery and pilot programs',
        'Cloud data architectures and governance',
        'Full-stack analytics products and dashboards'
      ]
    }
  ];

  const [activeService, setActiveService] = useState(services[0]);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container page-hero-grid">
          <div>
            <p className="eyebrow">Our Services</p>
            <h1>Integrated capabilities that move the needle, fast.</h1>
            <p>
              Whether you are igniting a new venture, modernizing core systems, or scaling automation,
              Aurora Dynamics pairs bold vision with disciplined execution to deliver measurable transformation.
            </p>
          </div>
          <div className="page-hero-media">
            <img
              src="https://picsum.photos/800/600?random=26"
              alt="Service delivery workshop"
              className="responsive-image"
              onLoad={(event) => event.currentTarget.classList.add('loaded')}
            />
          </div>
        </div>
      </section>

      <section className="service-switcher">
        <div className="container">
          <div className="service-tabs" role="tablist">
            {services.map((service) => (
              <button
                key={service.id}
                className={`service-tab ${activeService.id === service.id ? 'active' : ''}`}
                onClick={() => setActiveService(service)}
                role="tab"
                aria-selected={activeService.id === service.id}
              >
                {service.title}
              </button>
            ))}
          </div>

          <div className="service-detail" role="tabpanel">
            <div className="service-detail-header">
              <h2>{activeService.title}</h2>
              <p>{activeService.description}</p>
            </div>
            <ul className="service-detail-list">
              {activeService.detailPoints.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="engagement-model">
        <div className="container engagement-grid">
          <div>
            <p className="eyebrow">Engagement model</p>
            <h2>Flexible collaboration built around your priorities.</h2>
          </div>
          <div>
            <div className="engagement-card">
              <h3>Advisory partnership</h3>
              <p>
                Strategic guidance, executive alignment, and capability building for leaders driving digital change.
              </p>
            </div>
            <div className="engagement-card">
              <h3>Integrated delivery squads</h3>
              <p>
                Cross-functional teams embedded with your organization to accelerate delivery and knowledge transfer.
              </p>
            </div>
            <div className="engagement-card">
              <h3>Transformation accelerator</h3>
              <p>
                Intensive 6–12 week programs focused on unlocking high-impact opportunities with rapid prototypes and pilots.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="cta-section slim">
        <div className="container cta-container">
          <div>
            <h2>Let’s design your next breakthrough together.</h2>
            <p>Share your goals and we’ll tailor an engagement to deliver immediate and lasting value.</p>
          </div>
          <div className="cta-actions">
            <a className="button button-primary button-large" href="/contact">
              Book a working session
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;