import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  const stats = useMemo(
    () => [
      { label: 'Projects Delivered', value: 128 },
      { label: 'Client Satisfaction', value: 98, suffix: '%' },
      { label: 'Transformation ROI', value: 42, suffix: 'x' },
      { label: 'Countries Served', value: 16 }
    ],
    []
  );
  const statsRef = useRef(null);
  const [statValues, setStatValues] = useState(stats.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const [activeCategory, setActiveCategory] = useState('All');
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const services = [
    {
      title: 'Digital Strategy & Roadmapping',
      description:
        'Align technology investments with business outcomes through data-backed roadmaps and value-led prioritization.',
      icon: '🧭',
      link: '/services'
    },
    {
      title: 'Product Innovation Studios',
      description:
        'Ideate, prototype, and launch new digital products with cross-functional teams specializing in rapid innovation.',
      icon: '🚀',
      link: '/services'
    },
    {
      title: 'Experience Transformation',
      description:
        'Design cohesive, human-centered experiences that increase engagement and drive loyalty across every touchpoint.',
      icon: '🎨',
      link: '/services'
    },
    {
      title: 'AI & Automation Enablement',
      description:
        'Build intelligent, automated workflows that scale operations, enhance decision-making, and unlock new efficiencies.',
      icon: '🤖',
      link: '/services'
    }
  ];

  const processSteps = [
    {
      step: '01',
      title: 'Discover & Diagnose',
      description:
        'We immerse ourselves in your organization to understand where value is trapped and how to unlock it.'
    },
    {
      step: '02',
      title: 'Co-Create Solutions',
      description:
        'Cross-functional teams co-design solutions using data, design sprints, and iterative prototyping.'
    },
    {
      step: '03',
      title: 'Launch & Scale',
      description:
        'We launch fast, measure relentlessly, and scale what works with full knowledge transfer to your teams.'
    },
    {
      step: '04',
      title: 'Continuous Evolution',
      description:
        'We embed capabilities that enable you to continuously adapt and innovate long after launch.'
    }
  ];

  const testimonials = [
    {
      quote:
        'Aurora Dynamics helped us define a multi-year digital vision and execute it in less than 12 months. Their hybrid strategy and delivery model is unmatched.',
      name: 'Marissa Chen',
      role: 'Chief Digital Officer, Helios Financial',
      avatar: 'https://picsum.photos/200/200?random=21'
    },
    {
      quote:
        'From ideation to launch, the Aurora team became an extension of our organization. We achieved 5x faster deployment while improving customer satisfaction.',
      name: 'Dominic Romero',
      role: 'VP of Innovation, Horizon Mobility',
      avatar: 'https://picsum.photos/200/200?random=22'
    },
    {
      quote:
        'Their automation framework delivered measurable ROI in weeks. Aurora Dynamics brings clarity, energy, and rigor to every engagement.',
      name: 'Priya Nair',
      role: 'Operations Lead, Nexus Healthcare',
      avatar: 'https://picsum.photos/200/200?random=23'
    }
  ];

  const team = [
    {
      name: 'Elena Martinez',
      role: 'Founder & CEO',
      expertise: 'Vision-led transformation, enterprise strategy',
      image: 'https://picsum.photos/400/400?random=31'
    },
    {
      name: 'Noah Williams',
      role: 'Chief Experience Officer',
      expertise: 'Service design, innovation labs, design ops',
      image: 'https://picsum.photos/400/400?random=32'
    },
    {
      name: 'Amara Patel',
      role: 'Head of Engineering',
      expertise: 'Cloud-native platforms, AI integration',
      image: 'https://picsum.photos/400/400?random=33'
    },
    {
      name: 'Jonas Fischer',
      role: 'Director of Insights',
      expertise: 'Data strategy, research, analytics enablement',
      image: 'https://picsum.photos/400/400?random=34'
    }
  ];

  const projectCategories = ['All', 'Strategy', 'Technology', 'Experience'];
  const projects = [
    {
      title: 'Helios Digital Core Modernization',
      category: 'Technology',
      description:
        'Modernized legacy banking systems with microservices architecture and secure cloud adoption.',
      image: 'https://picsum.photos/1200/800?random=41'
    },
    {
      title: 'Nexus Patient Experience Platform',
      category: 'Experience',
      description:
        'Redesigned patient journeys with omnichannel engagement and intelligent triage.',
      image: 'https://picsum.photos/1200/800?random=42'
    },
    {
      title: 'Horizon Mobility Innovation Roadmap',
      category: 'Strategy',
      description:
        'Defined a 3-year innovation portfolio delivering new revenue streams through connected mobility.',
      image: 'https://picsum.photos/1200/800?random=43'
    },
    {
      title: 'Vertex Operations Automation',
      category: 'Technology',
      description:
        'Implemented intelligent automation reducing manual processes by 73% within six months.',
      image: 'https://picsum.photos/1200/800?random=44'
    },
    {
      title: 'PulseCare Service Blueprint',
      category: 'Experience',
      description:
        'Created a unified service blueprint aligning medical staff, partners, and patients around shared outcomes.',
      image: 'https://picsum.photos/1200/800?random=45'
    },
    {
      title: 'Luminate Sustainability Dashboard',
      category: 'Strategy',
      description:
        'Developed an executive dashboard that connects ESG goals with operational performance.',
      image: 'https://picsum.photos/1200/800?random=46'
    }
  ];

  const faqs = [
    {
      question: 'How do you measure the impact of digital transformation initiatives?',
      answer:
        'We define value hypotheses at the outset and co-create a scorecard that blends financial, operational, and experience metrics. We report progress weekly with transparent data and iterate rapidly to ensure measurable outcomes.'
    },
    {
      question: 'Do you work with in-house teams or provide full delivery squads?',
      answer:
        'Both. We integrate with in-house teams to upskill and accelerate delivery, and we provide specialized squads for strategy, design, and engineering. Our flexible engagement model adapts to your organization’s needs.'
    },
    {
      question: 'What industries does Aurora Dynamics specialize in?',
      answer:
        'We have deep experience in financial services, healthcare, mobility, retail, and sustainability. Our approach is built on adaptable playbooks that tailor to each industry’s unique challenges and regulations.'
    },
    {
      question: 'How quickly can we see results?',
      answer:
        'We typically deliver tangible outcomes within the first 6-8 weeks of engagement, focusing on high-leverage opportunities that compound over time.'
    }
  ];

  const blogPosts = [
    {
      title: '2024 Digital Transformation Playbook',
      description:
        'Nine strategic moves to future-proof your organization and deliver exponential value in 2024 and beyond.',
      date: 'February 2, 2024',
      image: 'https://picsum.photos/800/600?random=51'
    },
    {
      title: 'AI-Augmented Teams: The Human Advantage',
      description:
        'A practical framework for building AI-augmented teams that balance automation with human ingenuity.',
      date: 'January 18, 2024',
      image: 'https://picsum.photos/800/600?random=52'
    },
    {
      title: 'Designing for Trust in Regulated Industries',
      description:
        'Five experience design principles that increase trust and compliance without sacrificing agility.',
      date: 'December 11, 2023',
      image: 'https://picsum.photos/800/600?random=53'
    }
  ];

  useEffect(() => {
    const animateOnScroll = () => {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('in-view');
            }
          });
        },
        { threshold: 0.18 }
      );
      const elements = document.querySelectorAll('[data-animate]');
      elements.forEach((el) => observer.observe(el));
      return () => observer.disconnect();
    };
    animateOnScroll();
  }, []);

  useEffect(() => {
    if (!statsRef.current || statsAnimated) return;
    const node = statsRef.current;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsAnimated) {
            stats.forEach((stat, index) => {
              const start = 0;
              const end = stat.value;
              const duration = 1600;
              const startTime = performance.now();

              const animate = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const eased = 1 - Math.pow(1 - progress, 3);
                setStatValues((prev) => {
                  const updated = [...prev];
                  updated[index] = Math.round(start + eased * (end - start));
                  return updated;
                });
                if (progress < 1) {
                  requestAnimationFrame(animate);
                }
              };
              requestAnimationFrame(animate);
            });
            setStatsAnimated(true);
          }
        });
      },
      { threshold: 0.4 }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [stats, statsAnimated]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) =>
        prev === testimonials.length - 1 ? 0 : prev + 1
      );
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const filteredProjects =
    activeCategory === 'All'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const [openFAQIndex, setOpenFAQIndex] = useState(0);

  return (
    <div className="home-page">
      <section className="hero" id="hero">
        <div className="hero-media" data-animate>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Business leaders collaborating on digital strategy"
            className="hero-image responsive-image"
            onLoad={(event) => event.currentTarget.classList.add('loaded')}
          />
        </div>
        <div className="container hero-content" data-animate>
          <p className="eyebrow">Digital Transformation Partners</p>
          <h1>
            Accelerate innovation with <span>confidence</span> and measurable impact.
          </h1>
          <p className="lead">
            Aurora Dynamics helps enterprises unlock value, modernize operations,
            and design experiences that delight customers and teams alike.
          </p>
          <div className="hero-actions">
            <Link to="/contact" className="button button-primary button-large">
              Schedule a strategy session
            </Link>
            <Link to="/#projects" className="button button-outline">
              Explore recent work
            </Link>
          </div>
          <div className="hero-highlight">
            <span className="pulse-dot" aria-hidden="true" />
            <p>
              Trusted by global leaders to deliver <strong>42x ROI</strong> on transformation investments.
            </p>
          </div>
        </div>
      </section>

      <section className="stats" aria-label="Company performance statistics">
        <div className="container stats-container" ref={statsRef} data-animate>
          {stats.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <span className="stat-value">
                {statValues[index]}
                {stat.suffix || '+'}
              </span>
              <span className="stat-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="services-section" id="services">
        <div className="container">
          <div className="section-heading" data-animate>
            <p className="eyebrow">Capabilities</p>
            <h2>End-to-end expertise to activate your transformation agenda.</h2>
            <p>
              From strategic planning and customer experience design to enterprise engineering and automation,
              we orchestrate the disciplines needed to deliver lasting change.
            </p>
          </div>
          <div className="services-grid">
            {services.map((service, index) => (
              <article className="service-card" key={service.title} data-animate>
                <div className="service-icon" aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to={service.link} className="text-link">
                  Learn more
                </Link>
                <span className="service-index">0{index + 1}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process-section" id="process">
        <div className="container">
          <div className="section-heading" data-animate>
            <p className="eyebrow">How we work</p>
            <h2>Structured for speed, designed for scalability.</h2>
            <p>
              Our collaborative operating model brings strategy, human-centered design, and engineering together from day one.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step) => (
              <div className="process-step" key={step.step} data-animate>
                <span className="process-number">{step.step}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials-section" id="testimonials">
        <div className="container testimonials-container">
          <div className="testimonial-intro" data-animate>
            <p className="eyebrow">Client Stories</p>
            <h2>Leaders trust Aurora Dynamics to deliver the extraordinary.</h2>
            <p>
              We embed with your teams, align stakeholders, and orchestrate momentum that turns bold ambition into measurable success.
            </p>
          </div>
          <div className="testimonial-carousel" data-animate>
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`testimonial-card ${
                  index === currentTestimonial ? 'active' : ''
                }`}
                aria-hidden={index === currentTestimonial ? 'false' : 'true'}
              >
                <div className="testimonial-quote">“{testimonial.quote}”</div>
                <div className="testimonial-profile">
                  <img
                    src={testimonial.avatar}
                    alt={`${testimonial.name} portrait`}
                    className="testimonial-avatar responsive-image"
                    onLoad={(event) => event.currentTarget.classList.add('loaded')}
                  />
                  <div>
                    <h3>{testimonial.name}</h3>
                    <p>{testimonial.role}</p>
                  </div>
                </div>
              </article>
            ))}
            <div className="testimonial-controls" role="tablist">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`dot ${index === currentTestimonial ? 'active' : ''}`}
                  aria-label={`Show testimonial ${index + 1}`}
                  onClick={() => setCurrentTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team-section" id="team">
        <div className="container">
          <div className="section-heading" data-animate>
            <p className="eyebrow">Leadership</p>
            <h2>Guided by seasoned strategists, technologists, and designers.</h2>
          </div>
          <div className="team-grid">
            {team.map((member) => (
              <article className="team-card" key={member.name} data-animate>
                <div className="team-media">
                  <img
                    src={member.image}
                    alt={`${member.name}, ${member.role}`}
                    className="responsive-image"
                    onLoad={(event) => event.currentTarget.classList.add('loaded')}
                  />
                </div>
                <div className="team-content">
                  <h3>{member.name}</h3>
                  <p className="team-role">{member.role}</p>
                  <p>{member.expertise}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects-section" id="projects">
        <div className="container">
          <div className="section-heading" data-animate>
            <p className="eyebrow">Work</p>
            <h2>Outcomes that reimagine industries and accelerate growth.</h2>
          </div>
          <div className="projects-filter" role="tablist" data-animate>
            {projectCategories.map((category) => (
              <button
                key={category}
                className={`filter-button ${category === activeCategory ? 'active' : ''}`}
                onClick={() => setActiveCategory(category)}
                role="tab"
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title} data-animate>
                <div className="project-media">
                  <img
                    src={project.image}
                    alt={`${project.title} case study visual`}
                    className="responsive-image"
                    onLoad={(event) => event.currentTarget.classList.add('loaded')}
                  />
                </div>
                <div className="project-content">
                  <p className="project-category">{project.category}</p>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section" id="faq">
        <div className="container faq-container">
          <div className="faq-intro" data-animate>
            <p className="eyebrow">FAQ</p>
            <h2>Clarity from the very first conversation.</h2>
            <p>
              We strive to make every engagement transparent, collaborative, and outcome-driven.
              Here are answers to the questions we hear most often.
            </p>
            <Link to="/contact" className="button button-outline">
              Talk with our team
            </Link>
          </div>
          <div className="faq-accordion" data-animate>
            {faqs.map((faq, index) => (
              <div
                className={`faq-item ${openFAQIndex === index ? 'open' : ''}`}
                key={faq.question}
              >
                <button
                  className="faq-question"
                  onClick={() =>
                    setOpenFAQIndex(openFAQIndex === index ? -1 : index)
                  }
                  aria-expanded={openFAQIndex === index}
                >
                  {faq.question}
                  <span className="faq-icon" aria-hidden="true">
                    {openFAQIndex === index ? '−' : '+'}
                  </span>
                </button>
                <div className="faq-answer">
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section" id="insights">
        <div className="container">
          <div className="section-heading" data-animate>
            <p className="eyebrow">Insights</p>
            <h2>Latest thinking from the Aurora Dynamics studio.</h2>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title} data-animate>
                <div className="blog-media">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="responsive-image"
                    onLoad={(event) => event.currentTarget.classList.add('loaded')}
                  />
                </div>
                <div className="blog-content">
                  <p className="blog-date">{post.date}</p>
                  <h3>{post.title}</h3>
                  <p>{post.description}</p>
                  <a href="#!" className="text-link">
                    Read insight
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section" id="cta">
        <div className="container cta-container" data-animate>
          <div>
            <p className="eyebrow">Let’s build momentum</p>
            <h2>
              Your next leap forward starts with a conversation.
            </h2>
            <p>
              Schedule a collaborative working session with Aurora Dynamics to explore your next digital breakthrough.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="button button-primary button-large">
              Book a discovery call
            </Link>
            <Link to="/services" className="button button-outline">
              View service offering
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;