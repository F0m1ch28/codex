import React from 'react';

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero slim">
        <div className="container">
          <p className="eyebrow">Privacy Policy</p>
          <h1>Protecting your information is our priority.</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container legal-container">
          <h2>Information we collect</h2>
          <p>
            We collect personal information you provide directly (such as name, email, and company) when you contact us,
            subscribe to insights, or engage our services.
          </p>

          <h2>How we use information</h2>
          <p>
            Personal data is used to respond to inquiries, deliver contracted services, send relevant communications,
            and improve our offerings.
          </p>

          <h2>Cookies and tracking</h2>
          <p>
            We use cookies to enhance your experience, analyze site usage, and support marketing efforts. You may adjust
            your browser settings to decline cookies; however, this may limit certain features.
          </p>

          <h2>Data security</h2>
          <p>
            Aurora Dynamics uses administrative, technical, and physical safeguards to protect your information.
            We retain personal data only as long as necessary for the purposes described above.
          </p>

          <h2>Your rights</h2>
          <p>
            Depending on your location, you may have rights to access, correct, or delete your personal data.
            To exercise these rights, contact us at <a href="mailto:privacy@auroradynamics.com">privacy@auroradynamics.com</a>.
          </p>

          <h2>Updates</h2>
          <p>
            We may update this policy periodically. Changes will be posted on this page with an updated effective date.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;