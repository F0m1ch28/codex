document.addEventListener("DOMContentLoaded", function () {
    const banner = document.getElementById("cookieBanner");
    if (!banner) {
        return;
    }

    const acceptBtn = document.getElementById("cookieAccept");
    const declineBtn = document.getElementById("cookieDecline");
    const storedConsent = localStorage.getItem("antialuxiuCookieConsent");

    if (storedConsent === "accepted" || storedConsent === "declined") {
        banner.classList.remove("is-visible");
    } else {
        banner.classList.add("is-visible");
    }

    if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
            localStorage.setItem("antialuxiuCookieConsent", "accepted");
            banner.classList.remove("is-visible");
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", function () {
            localStorage.setItem("antialuxiuCookieConsent", "declined");
            banner.classList.remove("is-visible");
        });
    }
});