document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      siteNav.classList.toggle('open');
      navToggle.classList.toggle('open');
    });

    const navLinks = siteNav.querySelectorAll('a');
    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('open')) {
          siteNav.classList.remove('open');
          navToggle.classList.remove('open');
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const preference = localStorage.getItem('abhCookiePreference');
    if (preference) {
      cookieBanner.classList.add('hidden');
    }

    const acceptBtn = cookieBanner.querySelector('.cookie-accept');
    const declineBtn = cookieBanner.querySelector('.cookie-decline');

    const dismissBanner = (value) => {
      localStorage.setItem('abhCookiePreference', value);
      cookieBanner.classList.add('hidden');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => dismissBanner('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => dismissBanner('declined'));
    }
  }
});