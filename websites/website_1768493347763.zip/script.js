document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.getElementById('primary-navigation');

    if (navToggle && navigation) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navigation.classList.toggle('open');
            document.body.classList.toggle('nav-open', !expanded);
        });

        navigation.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navToggle.getAttribute('aria-expanded') === 'true') {
                    navToggle.click();
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('marshaCookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
            setTimeout(() => cookieBanner.remove(), 450);
        }

        cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(function (button) {
            button.addEventListener('click', function () {
                const choice = button.getAttribute('data-cookie-choice') || 'undecided';
                const targetLink = button.getAttribute('data-cookie-link');
                localStorage.setItem('marshaCookieConsent', choice);
                cookieBanner.classList.add('hidden');
                setTimeout(() => cookieBanner.remove(), 450);
                if (targetLink) {
                    window.open(targetLink, '_blank', 'noopener');
                }
            });
        });
    }
});