import React, { useEffect, useState } from "react";

const counters = [
  { value: 148, label: "Gadget-Reviews", suffix: "+" },
  { value: 63, label: "Vergleichsmatrizen", suffix: "" },
  { value: 3120, label: "Community-Mitglieder", suffix: "" },
  { value: 18, label: "Partner-Labs in DE", suffix: "" },
];

const StatsCounter = () => {
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById("stats-counter");
      if (element) {
        const rect = element.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom >= 0) {
          setAnimated(true);
        }
      }
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section id="stats-counter" className="section">
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {counters.map((item) => (
          <div key={item.label} className="stat-card">
            <span className="text-4xl font-heading text-accent">
              {animated ? item.value : "0"}
              {item.suffix}
            </span>
            <p className="text-sm text-body/70 uppercase tracking-[0.2em]">{item.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default StatsCounter;