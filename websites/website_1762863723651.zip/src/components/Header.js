import React, { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";

const navItems = [
  { label: "Start", to: "/" },
  { label: "Reviews", to: "/reviews" },
  { label: "Frühzugang", to: "/early" },
  { label: "Vergleiche", to: "/compare" },
  { label: "Karte", to: "/karte" },
  { label: "Blog", to: "/blog" },
  { label: "Hilfe", to: "/faq" },
];

const Header = () => {
  const [isMenuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-overlay/90 backdrop-blur-md shadow-lg" : "bg-base/95"
      }`}
      role="banner"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex items-center justify-between py-4">
          <NavLink to="/" className="flex items-center space-x-2" aria-label="Slexorifyx Startseite">
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-primary/20 border border-primary/30 text-primary font-mono font-semibold">
              SX
            </span>
            <div className="flex flex-col leading-tight">
              <span className="font-heading font-bold text-xl text-surface">Slexorifyx</span>
              <span className="text-xs uppercase tracking-[0.2em] text-accent">
                Gadget Insight Hub
              </span>
            </div>
          </NavLink>
          <nav className="hidden lg:flex items-center space-x-6" aria-label="Hauptnavigation">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `nav-link ${
                    isActive ? "text-accent border-b-2 border-accent" : "text-surface/80"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <a
              href="/kontakt"
              className="btn-primary ml-4"
              aria-label="Kontakt aufnehmen"
            >
              Kontakt
            </a>
          </nav>
          <button
            className="lg:hidden inline-flex items-center justify-center rounded-md border border-surface/10 p-2 text-surface/80 hover:text-accent focus:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-base"
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={isMenuOpen}
            aria-controls="mobile-navigation"
          >
            <span className="sr-only">Navigation umschalten</span>
            <svg
              className="h-6 w-6"
              stroke="currentColor"
              fill="none"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              {isMenuOpen ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              )}
            </svg>
          </button>
        </div>
      </div>
      <div
        id="mobile-navigation"
        className={`lg:hidden overflow-hidden transition-[max-height] duration-500 ${
          isMenuOpen ? "max-h-[520px]" : "max-h-0"
        }`}
      >
        <nav
          className="px-4 pb-6 space-y-1 bg-overlay/95 backdrop-blur-xl border-t border-surface/10"
          aria-label="Mobile Navigation"
        >
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `block px-3 py-3 rounded-lg text-sm font-medium tracking-wide ${
                  isActive
                    ? "bg-primary/20 text-accent"
                    : "text-surface/80 hover:bg-surface/10"
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <a href="/kontakt" className="btn-primary block text-center mt-4">
            Kontakt aufnehmen
          </a>
        </nav>
      </div>
    </header>
  );
};

export default Header;