import React from "react";
import { NavLink } from "react-router-dom";
import PartnerBadge from "./PartnerBadge";

const Footer = () => {
  return (
    <footer className="bg-base border-t border-surface/20 text-surface/70 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <h3 className="font-heading text-lg text-surface mb-3">Slexorifyx</h3>
            <p className="text-sm leading-relaxed">
              Der deutsche Hub für Tech-Vorreiter:innen: geprüfte Reviews, transparente Kriterien und
              verlässliche Frühzugänge über zertifizierte Partner.
            </p>
            <div className="mt-4 flex space-x-3">
              <PartnerBadge label="Zertifizierter Partner" tone="primary" />
              <PartnerBadge label="Affiliate-Hinweis" tone="accent" />
            </div>
          </div>
          <div>
            <h4 className="footer-heading">Navigation</h4>
            <ul className="space-y-2">
              <li>
                <NavLink to="/reviews" className="footer-link">
                  Reviews
                </NavLink>
              </li>
              <li>
                <NavLink to="/compare" className="footer-link">
                  Vergleiche
                </NavLink>
              </li>
              <li>
                <NavLink to="/early" className="footer-link">
                  Frühzugang
                </NavLink>
              </li>
              <li>
                <NavLink to="/karte" className="footer-link">
                  Partnerkarte
                </NavLink>
              </li>
              <li>
                <NavLink to="/faq" className="footer-link">
                  Hilfe &amp; FAQ
                </NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="footer-heading">Rechtliches</h4>
            <ul className="space-y-2">
              <li>
                <NavLink to="/impressum" className="footer-link">
                  Impressum
                </NavLink>
              </li>
              <li>
                <NavLink to="/policy" className="footer-link">
                  Datenschutz
                </NavLink>
              </li>
              <li>
                <NavLink to="/cookies" className="footer-link">
                  Cookies
                </NavLink>
              </li>
              <li>
                <NavLink to="/terms" className="footer-link">
                  Nutzungsbedingungen
                </NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="footer-heading">Kontakt</h4>
            <p className="text-sm">
              Für Presse, Partnerschaften oder Support nutzen Sie bitte unser{" "}
              <NavLink to="/kontakt" className="underline text-accent">
                Kontaktformular
              </NavLink>
              . Telefonische Rücksprache erfolgt individuell bei Bedarf.
            </p>
            <div className="mt-4 text-xs font-mono text-surface/50">
              Analytics: serverseitig, IP anonymisiert, keine Cookies.
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-surface/10 pt-6 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-surface/50">
          <span>&copy; {new Date().getFullYear()} Slexorifyx GmbH. Alle Rechte vorbehalten.</span>
          <span>Core Web Vitals ≥ 90 | DSGVO-konform | Standort: Berlin, Deutschland</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;