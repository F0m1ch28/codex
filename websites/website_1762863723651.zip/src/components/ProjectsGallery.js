import React, { useState } from "react";

const projects = [
  {
    tag: "AR/VR",
    title: "Immersive Smart Glass Beta",
    image: "https://picsum.photos/1200/800?random=31",
    description: "Exklusives Hands-on bei AudiTech Labs München mit Field-Test Auswertung.",
  },
  {
    tag: "Smart Home",
    title: "GridSense Energiemanager",
    image: "https://picsum.photos/1200/800?random=32",
    description: "Vergleich von drei Energiemanagement-Systemen mit Live-Daten Simulation.",
  },
  {
    tag: "Mobility",
    title: "E-Scooter Fleet Rollout",
    image: "https://picsum.photos/1200/800?random=33",
    description: "Pilotprogramm in Hamburg inklusive Wartungs- und Safety-Benchmarks.",
  },
  {
    tag: "Audio",
    title: "Open-Ear Headphones Sprint",
    image: "https://picsum.photos/1200/800?random=34",
    description: "Blindtests mit 80 Teilnehmer:innen und detaillierten Frequency Response Charts.",
  },
];

const filterOptions = ["Alle", "AR/VR", "Smart Home", "Mobility", "Audio"];

const ProjectsGallery = () => {
  const [filter, setFilter] = useState("Alle");

  const filtered = projects.filter((project) => filter === "Alle" || project.tag === filter);

  return (
    <section className="section">
      <div className="section-header">
        <span className="eyebrow">Projekte</span>
        <h2 className="section-title">Aktuelle Programmhöhepunkte</h2>
        <p className="section-description">
          Ein Auszug aus Partnerprogrammen, die wir zuletzt begleitet haben – mit Fokus auf
          Markteinführung, Qualitätssicherung und Community-Feedback.
        </p>
      </div>
      <div className="flex flex-wrap gap-3 mb-6">
        {filterOptions.map((option) => (
          <button
            key={option}
            onClick={() => setFilter(option)}
            className={`tag-button ${filter === option ? "tag-active" : ""}`}
          >
            {option}
          </button>
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        {filtered.map((project) => (
          <article key={project.title} className="project-card">
            <img
              src={project.image}
              alt={`${project.title} Projektvisualisierung`}
              className="project-image"
              loading="lazy"
            />
            <div className="p-6">
              <span className="tag">{project.tag}</span>
              <h3 className="text-xl font-heading text-surface mt-3 mb-2">{project.title}</h3>
              <p className="text-sm text-body/80">{project.description}</p>
              <div className="mt-4 flex items-center space-x-3">
                <a href="/compare" className="btn-secondary">
                  Vergleichen
                </a>
                <a href="/kontakt" className="btn-ghost">
                  Route anzeigen
                </a>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};

export default ProjectsGallery;