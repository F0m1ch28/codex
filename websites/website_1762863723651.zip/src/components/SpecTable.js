import React from "react";
import styles from "./SpecTable.module.css";

const SpecTable = ({ specs }) => (
  <aside className={styles.wrapper} aria-label="Gerätespezifikationen">
    <h2 className={styles.heading}>Technische Daten</h2>
    <dl className={styles.list}>
      {specs.map((item) => (
        <div key={item.label} className={styles.row}>
          <dt>{item.label}</dt>
          <dd>{item.value}</dd>
        </div>
      ))}
    </dl>
  </aside>
);

export default SpecTable;