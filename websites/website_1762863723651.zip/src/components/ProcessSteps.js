import React from "react";

const steps = [
  {
    title: "Scouting",
    description:
      "Frühzeitiges Scouting von Herstellern und Labs. NDAs und Beta-Verträge werden rechtlich geprüft.",
    icon: "🔍",
  },
  {
    title: "Testing Pipeline",
    description:
      "24h Laborfenster mit standardisierten Benchmarks, Messung von Thermals, Akkuausdauer und Connectivity.",
    icon: "🧪",
  },
  {
    title: "Review & Zugriff",
    description:
      "Reviewer liefern Scorecards, Video-Assets und Vergleichsdaten. Frühzugänge werden qualifiziert vergeben.",
    icon: "🚀",
  },
];

const ProcessSteps = () => (
  <section className="section">
    <div className="section-header">
      <span className="eyebrow">Ablauf</span>
      <h2 className="section-title">So funktioniert Slexorifyx</h2>
      <p className="section-description">
        Von der ersten Geräte-Ankündigung bis zum hands-on Review: Ein klar strukturierter Prozess
        sorgt für Qualität und Geschwindigkeit.
      </p>
    </div>
    <div className="grid gap-6 md:grid-cols-3">
      {steps.map((step, index) => (
        <article key={step.title} className="card">
          <div className="text-3xl">{step.icon}</div>
          <h3 className="text-lg font-heading text-surface mt-3 mb-2">
            {index + 1}. {step.title}
          </h3>
          <p className="text-sm text-body/80">{step.description}</p>
        </article>
      ))}
    </div>
  </section>
);

export default ProcessSteps;