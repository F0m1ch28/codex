import React from "react";

const TestCriteria = () => (
  <section className="section">
    <div className="section-header">
      <span className="eyebrow">Transparente Methodik</span>
      <h2 className="section-title">Unsere Testkriterien</h2>
      <p className="section-description">
        Jede Review folgt einem fest dokumentierten Kriterienkatalog. Gewichtung und Bewertung werden
        offen gelegt – für nachvollziehbare Entscheidungen.
      </p>
    </div>
    <div className="grid gap-6 md:grid-cols-3">
      {[
        {
          title: "Performance & Benchmarks",
          text: "GPC-Brusttests, thermische Stabilität, inklusive Stromverbrauchsmessung – reproduzierbar und offen dokumentiert.",
        },
        {
          title: "Alltagsnutzen",
          text: "UX-Evaluation, Update-Politik und Reparierbarkeit fließen mit 30 % Gewichtung in die Gesamtbewertung ein.",
        },
        {
          title: "Nachhaltigkeit",
          text: "Akkus, Materialien und Lieferkettentransparenz werden als eigenständige Score-Kategorie ausgewiesen.",
        },
      ].map((item) => (
        <article key={item.title} className="card">
          <h3 className="text-lg font-heading text-surface mb-2">{item.title}</h3>
          <p className="text-sm text-body/80">{item.text}</p>
        </article>
      ))}
    </div>
  </section>
);

export default TestCriteria;