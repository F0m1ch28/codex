import React, { useEffect, useRef, useState } from "react";

const loadGoogleMaps = (apiKey, callback) => {
  if (window.google && window.google.maps) {
    callback();
    return;
  }
  const existingScript = document.querySelector("script[data-google-maps]");
  if (existingScript) {
    existingScript.addEventListener("load", callback);
    return;
  }
  const script = document.createElement("script");
  script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&language=de&region=DE`;
  script.async = true;
  script.defer = true;
  script.dataset.googleMaps = "true";
  script.onload = callback;
  document.body.appendChild(script);
};

const MapView = ({ markers }) => {
  const mapRef = useRef(null);
  const [mapError, setMapError] = useState(false);

  useEffect(() => {
    const apiKey = process.env.REACT_APP_GOOGLE_MAPS_KEY || "DUMMY_KEY";
    loadGoogleMaps(apiKey, () => {
      try {
        const map = new window.google.maps.Map(mapRef.current, {
          center: { lat: 52.52, lng: 13.405 },
          zoom: 6,
          styles: [
            { elementType: "geometry", stylers: [{ color: "#0A0F1F" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#0A0F1F" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#E5E7EB" }] },
            {
              featureType: "water",
              stylers: [{ color: "#3B82F6" }],
            },
          ],
          disableDefaultUI: true,
          gestureHandling: "greedy",
        });

        const infoWindow = new window.google.maps.InfoWindow();

        markers.forEach((marker) => {
          const mapMarker = new window.google.maps.Marker({
            position: { lat: marker.lat, lng: marker.lng },
            map,
            title: marker.title,
            icon: {
              path: window.google.maps.SymbolPath.CIRCLE,
              scale: 8,
              strokeWeight: 2,
              strokeColor: "#3B82F6",
              fillColor: "#22D3EE",
              fillOpacity: 0.8,
            },
          });

          mapMarker.addListener("mouseover", () => {
            infoWindow.setContent(`<div style="color:#0A0F1F;font-weight:600;">${marker.title}</div>`);
            infoWindow.open(map, mapMarker);
          });
          mapMarker.addListener("mouseout", () => infoWindow.close());
        });
      } catch (error) {
        setMapError(true);
      }
    });
  }, [markers]);

  if (mapError) {
    return (
      <iframe
        title="Slexorifyx Partnerkarte"
        src="https://www.google.com/maps/d/embed?mid=1"
        className="w-full h-96 border-0 rounded-xl"
        loading="lazy"
      />
    );
  }

  return (
    <div
      ref={mapRef}
      className="w-full h-96 rounded-xl border border-surface/20"
      role="img"
      aria-label="Karte der Slexorifyx Partnerstandorte"
    />
  );
};

export default MapView;