import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./ReviewCard.module.css";
import PartnerBadge from "./PartnerBadge";

const ReviewCard = ({ review }) => {
  return (
    <article className={styles.card} aria-labelledby={`review-${review.slug}`}>
      <div className={styles.mediaWrapper}>
        <img
          src={review.image}
          alt={review.imageAlt}
          className={styles.image}
          loading="lazy"
        />
        <span className={styles.score} aria-label={`Score ${review.score} von 10`}>
          {review.score}
        </span>
      </div>
      <div className={styles.content}>
        <header className={styles.header}>
          <PartnerBadge label={review.category} tone="accent" />
          <h3 id={`review-${review.slug}`} className={styles.title}>
            {review.title}
          </h3>
          <p className={styles.subline}>{review.subtitle}</p>
        </header>
        <div className={styles.meta}>
          <span>{review.date}</span>
          <span>OS: {review.os}</span>
          <span>UVP: {review.price}</span>
        </div>
        <p className={styles.excerpt}>{review.excerpt}</p>
        <footer className={styles.footer}>
          <NavLink to={`/reviews/${review.slug}`} className="btn-secondary">
            Review lesen
          </NavLink>
          <NavLink to="/compare" className="btn-ghost">
            Vergleichen
          </NavLink>
        </footer>
      </div>
    </article>
  );
};

export default ReviewCard;