import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("slexorifyx-consent");
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1600);
      return () => clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    localStorage.setItem("slexorifyx-consent", JSON.stringify({ essential: true }));
    setVisible(false);
  };

  return (
    visible && (
      <aside
        className="fixed bottom-0 inset-x-0 z-[200] bg-overlay/95 backdrop-blur-xl border-t border-primary/40 text-surface px-4 py-4 sm:px-6"
        role="dialog"
        aria-live="polite"
      >
        <div className="max-w-5xl mx-auto flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="font-heading text-lg">Cookies? Nur essentiell.</h2>
            <button
              className="text-sm underline text-accent"
              onClick={() => setExpanded((prev) => !prev)}
              aria-expanded={expanded}
            >
              Details
            </button>
          </div>
          <p className="text-xs text-surface/70 leading-relaxed">
            Wir setzen ausschließlich technisch notwendige Cookies für Sitzungsverwaltung ein. Für
            Reichweitenanalyse nutzen wir ein serverseitiges Tracking ohne personenbezogene Daten.
            Einverstanden? Dann bestätigen Sie bitte mit einem zweiten Klick.
          </p>
          {expanded && (
            <div className="bg-base/80 border border-surface/20 rounded-lg p-3 text-xs space-y-2">
              <p>
                <strong>Essentiell:</strong> Session-ID (lokal, 24h), Consent-Status.
              </p>
              <p>
                <strong>Analyse:</strong> rein serverseitig, IP anonymisiert, keine Drittanbieter.
              </p>
            </div>
          )}
          <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-3 gap-3">
            <button
              className="btn-secondary"
              onClick={() => setExpanded(true)}
              aria-label="Cookie Einstellungen anzeigen"
            >
              Einstellungen
            </button>
            <button
              className="btn-primary"
              onClick={accept}
              aria-label="Cookie Auswahl bestätigen"
            >
              Zustimmung speichern
            </button>
          </div>
        </div>
      </aside>
    )
  );
};

export default CookieBanner;