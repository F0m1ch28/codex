import React from "react";

const HeroHighlight = () => (
  <div className="grid gap-4 sm:grid-cols-3">
    {[
      {
        stat: "27",
        label: "exklusive Frühzugänge",
        detail: "Registrierte Betaprogramme mit NDA-Begleitung",
      },
      {
        stat: "94%",
        label: "Vertrauens-Score",
        detail: "Community Rating für Testtransparenz",
      },
      {
        stat: "48h",
        label: "Review-Turnaround",
        detail: "Zeit von Embargo bis Veröffentlichung",
      },
    ].map((item) => (
      <div key={item.label} className="highlight-card">
        <span className="text-3xl font-heading text-accent">{item.stat}</span>
        <h3 className="text-sm text-surface uppercase tracking-[0.25em]">{item.label}</h3>
        <p className="text-xs text-body/70">{item.detail}</p>
      </div>
    ))}
  </div>
);

export default HeroHighlight;