import React, { useState } from "react";

const NewsletterForm = () => {
  const [email, setEmail] = useState("");
  const [feedback, setFeedback] = useState("");

  const onSubmit = (event) => {
    event.preventDefault();
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      setFeedback("Bitte geben Sie eine gültige E-Mail-Adresse ein.");
      return;
    }
    setFeedback("Danke! Sie erhalten die nächste Early-Access-Mail am Montag.");
    setEmail("");
  };

  return (
    <form onSubmit={onSubmit} className="newsletter" aria-label="Newsletter Anmeldung">
      <label htmlFor="newsletter-email" className="sr-only">
        E-Mail-Adresse
      </label>
      <input
        id="newsletter-email"
        type="email"
        name="email"
        value={email}
        onChange={(event) => setEmail(event.target.value)}
        placeholder="you@example.de"
        className="newsletter-input"
        required
      />
      <button type="submit" className="btn-primary">
        Frühzugang sichern
      </button>
      {feedback && <p className="newsletter-feedback">{feedback}</p>}
    </form>
  );
};

export default NewsletterForm;