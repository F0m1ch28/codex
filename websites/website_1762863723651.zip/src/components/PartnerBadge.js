import React from "react";
import styles from "./PartnerBadge.module.css";

const toneMap = {
  primary: styles.primary,
  accent: styles.accent,
  success: styles.success,
};

const PartnerBadge = ({ label, tone = "primary" }) => {
  return (
    <span className={`${styles.badge} ${toneMap[tone] || styles.primary}`} aria-label={label}>
      {label}
    </span>
  );
};

export default PartnerBadge;