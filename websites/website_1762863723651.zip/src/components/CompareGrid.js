import React from "react";
import styles from "./CompareGrid.module.css";

const CompareGrid = ({ devices }) => (
  <section className={styles.grid} aria-label="Vergleichstabelle">
    <div className={styles.headerCell}>Kriterium</div>
    {devices.map((device) => (
      <div key={device.name} className={styles.headerDevice}>
        <h3>{device.name}</h3>
        <p>{device.short}</p>
      </div>
    ))}
    {["Display", "Chipset", "Akku", "Kamera", "Preis"].map((criterion) => (
      <React.Fragment key={criterion}>
        <div className={styles.label}>{criterion}</div>
        {devices.map((device) => (
          <div key={`${device.name}-${criterion}`} className={styles.value}>
            {device[criterion.toLowerCase()]}
          </div>
        ))}
      </React.Fragment>
    ))}
  </section>
);

export default CompareGrid;