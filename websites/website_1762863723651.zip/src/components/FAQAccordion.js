import React, { useState } from "react";

const items = [
  {
    question: "Wie werde ich für Frühzugänge qualifiziert?",
    answer:
      "Verifizieren Sie Ihr Profil mit realer Anschrift in Deutschland und wählen Sie die gewünschten Kategorien. Partner entscheiden anhand von Profilen, Score und NDA-Bereitschaft.",
  },
  {
    question: "Wie transparent sind eure Affiliate-Links?",
    answer:
      "Jeder Affiliate-Link ist klar markiert. Wir arbeiten ausschließlich mit geprüften Händlern und weisen Preisvergleiche in EUR inkl. MwSt. aus.",
  },
  {
    question: "Welche Benchmarks setzt ihr ein?",
    answer:
      "Wir nutzen eine Kombination aus GFXBench, 3DMark Wildlife, PCMark for Android, Geekbench und eigenen Battery-Drain-Tests. Alle Metriken sind reproduzierbar dokumentiert.",
  },
];

const FAQAccordion = () => {
  const [active, setActive] = useState(null);

  return (
    <section className="section">
      <div className="section-header">
        <span className="eyebrow">FAQ</span>
        <h2 className="section-title">Antworten auf häufige Fragen</h2>
        <p className="section-description">
          Klarheit vor Commitment: Hier finden Sie die wichtigsten Antworten rund um Slexorifyx.
        </p>
      </div>
      <div className="space-y-4">
        {items.map((item, index) => {
          const open = active === index;
          return (
            <div key={item.question} className="accordion-card">
              <button
                className="accordion-trigger"
                onClick={() => setActive(open ? null : index)}
                aria-expanded={open}
              >
                <span>{item.question}</span>
                <span aria-hidden="true">{open ? "−" : "+"}</span>
              </button>
              {open && <div className="accordion-content">{item.answer}</div>}
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default FAQAccordion;