import React, { useEffect, useState } from "react";

const testimonials = [
  {
    quote:
      "Durch Slexorifyx konnten wir unser Retail-Team bereits vor Launch des XR-Headsets schulen – inklusive fundierter Benchmarks.",
    author: "Mara Kühn",
    role: "Retail Lead, TechHaus Berlin",
  },
  {
    quote:
      "Die Vergleiche sparen uns Stunden. Besonders die Exportfunktion ist Gold wert für unsere PR-Briefings.",
    author: "Tim Acar",
    role: "Head of Communications, Nordlicht Mobile",
  },
  {
    quote:
      "Transparente Kriterien und ehrliche Kritik – genau das brauchen Early Adopter. Der Map-Filter für Events ist super.",
    author: "Lena Hofmann",
    role: "Product Evangelist, Klangwerk",
  },
];

const TestimonialsCarousel = () => {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);
  const testimonial = testimonials[index];

  return (
    <section className="section bg-base/70 border border-surface/10 rounded-3xl">
      <div className="section-header">
        <span className="eyebrow">Community Stimmen</span>
        <h2 className="section-title">Vertrauen durch echte Stimmen</h2>
      </div>
      <blockquote className="text-lg text-surface/90 leading-relaxed">
        “{testimonial.quote}”
      </blockquote>
      <div className="mt-6 flex items-center justify-between">
        <div>
          <span className="font-heading text-surface">{testimonial.author}</span>
          <p className="text-sm text-body/70">{testimonial.role}</p>
        </div>
        <div className="flex space-x-2">
          {testimonials.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setIndex(idx)}
              className={`w-2.5 h-2.5 rounded-full transition ${
                idx === index ? "bg-accent" : "bg-surface/20"
              }`}
              aria-label={`Testimonial ${idx + 1} anzeigen`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsCarousel;