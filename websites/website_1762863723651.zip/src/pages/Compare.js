import React, { useState } from "react";
import { Helmet } from "react-helmet";
import CompareGrid from "../components/CompareGrid";

const inventory = [
  {
    name: "FluxPhone Pro",
    short: "Camera Flagship",
    display: "6.7\" LTPO OLED / 120Hz",
    chipset: "NeuroCore X1",
    akku: "4800 mAh / 65W",
    kamera: "50 MP 1\" Hauptsensor",
    preis: "999 €",
  },
  {
    name: "Aether Tab X",
    short: "Tablet Hybrid",
    display: "13\" OLED / 120Hz",
    chipset: "Aether M2",
    akku: "11000 mAh / 45W",
    kamera: "12 MP Ultra Wide",
    preis: "799 €",
  },
  {
    name: "Nova Slate 15",
    short: "Creator Laptop",
    display: "15\" Mini-LED / 165Hz",
    chipset: "Nova Fusion 7",
    akku: "90 Wh / 100W USB-C",
    kamera: "1080p Studio Cam",
    preis: "1499 €",
  },
];

const Compare = () => {
  const [devices, setDevices] = useState(inventory.slice(0, 3));

  const exportCSV = () => {
    const headers = ["Name", "Display", "Chipset", "Akku", "Kamera", "Preis"];
    const rows = devices.map((device) => [
      device.name,
      device.display,
      device.chipset,
      device.akku,
      device.kamera,
      device.preis,
    ]);
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(";"), ...rows.map((row) => row.join(";"))].join("\n");
    const link = document.createElement("a");
    link.href = encodeURI(csvContent);
    link.download = "slexorifyx-compare.csv";
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const exportPNG = () => {
    alert("Export als PNG wird serverseitig generiert. Bitte kontaktieren Sie uns für den Zugang.");
  };

  return (
    <>
      <Helmet>
        <title>Vergleiche – Slexorifyx</title>
        <meta
          name="description"
          content="Vergleichen Sie bis zu vier Geräte parallel und exportieren Sie Daten als CSV oder PNG."
        />
      </Helmet>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Vergleiche</span>
          <h1 className="section-title">Entscheiden Sie datenbasiert</h1>
          <p className="section-description">
            Wählen Sie bis zu vier Geräte aus unserer Datenbank. Tech-Teams können die Ergebnisse als
            CSV exportieren, Design-Teams als PNG anfordern.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 mb-6">
          {inventory.map((device) => (
            <button
              key={device.name}
              className={`tag-button ${
                devices.find((d) => d.name === device.name) ? "tag-active" : ""
              }`}
              onClick={() =>
                setDevices((prev) => {
                  const exists = prev.find((item) => item.name === device.name);
                  if (exists) {
                    return prev.filter((item) => item.name !== device.name);
                  }
                  if (prev.length >= 4) return prev;
                  return [...prev, device];
                })
              }
            >
              {device.name}
            </button>
          ))}
        </div>
        <CompareGrid devices={devices} />
        <div className="flex flex-wrap gap-3 mt-6">
          <button onClick={exportCSV} className="btn-secondary">
            Export CSV
          </button>
          <button onClick={exportPNG} className="btn-ghost">
            Export PNG
          </button>
        </div>
      </section>
    </>
  );
};

export default Compare;