import React from "react";
import { Helmet } from "react-helmet";

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum – Slexorifyx</title>
      <meta
        name="description"
        content="Impressum der Slexorifyx GmbH gemäß § 5 TMG und § 55 RStV."
      />
    </Helmet>
    <section className="section prose">
      <h1>Impressum</h1>
      <p>Slexorifyx GmbH</p>
      <p>Industriestraße 12</p>
      <p>10115 Berlin</p>
      <p>Vertreten durch: Alina Richter, Geschäftsführer</p>
      <p>E-Mail: siehe Kontaktformular</p>
      <p>Registergericht: Amtsgericht Berlin-Charlottenburg</p>
      <p>HRB 123456 | USt-IdNr.: DE123456789</p>
    </section>
  </>
);

export default Impressum;