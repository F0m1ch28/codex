import React from "react";
import { Helmet } from "react-helmet";

const services = [
  {
    title: "Review-as-a-Service",
    description:
      "Verifizierte Tests in unseren Partnerlabs, inklusive Video-Assets, Scorecards und Exportdaten.",
  },
  {
    title: "Beta Program Management",
    description:
      "NDA-Handhabung, Teilnehmer-Scoring und Feedback-Zusammenfassung innerhalb von 48 Stunden.",
  },
  {
    title: "Retail Enablement",
    description:
      "Schulungspakete für Retail-Teams inklusive Demo-Hardware, Checklisten und Argumentationsleitfäden.",
  },
];

const Services = () => (
  <>
    <Helmet>
      <title>Services – Slexorifyx</title>
      <meta
        name="description"
        content="Professionelle Services von Slexorifyx: Reviews, Beta-Programm-Management und Retail Enablement."
      />
    </Helmet>
    <section className="section">
      <div className="section-header">
        <span className="eyebrow">Services</span>
        <h1 className="section-title">Unsere Leistungen</h1>
        <p className="section-description">
          Von unabhängigen Tests bis hin zur Aktivierung Ihrer Community. Wir stellen sicher, dass
          jedes Gadget mit Transparenz an den Markt geht.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {services.map((service) => (
          <article key={service.title} className="card">
            <h2 className="text-xl font-heading text-surface">{service.title}</h2>
            <p className="text-sm text-body/80 mt-2">{service.description}</p>
            <a href="/kontakt" className="btn-link mt-4 inline-flex">
              Termin anfragen
            </a>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Services;