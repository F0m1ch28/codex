import React from "react";
import { Helmet } from "react-helmet";
import NewsletterForm from "../components/NewsletterForm";

const programs = [
  {
    name: "FluxPhone Pro Creator Beta",
    type: "Beta",
    deadline: "Bewerbung bis 20. September",
    spots: "20 Plätze",
    location: "Remote + Berlin Lab",
  },
  {
    name: "GridSense Home Launch",
    type: "Preorder Preview",
    deadline: "Bewerbung bis 30. September",
    spots: "50 Plätze",
    location: "Hamburg",
  },
  {
    name: "Nova Slate 15 Developer Sprint",
    type: "Event",
    deadline: "Launch Event 10. Oktober",
    spots: "100 Plätze",
    location: "München",
  },
];

const EarlyAccess = () => (
  <>
    <Helmet>
      <title>Frühzugang Programme – Slexorifyx</title>
      <meta
        name="description"
        content="Aktive Betaprogramme, Vorbesteller-Previews und Events für neue Gadgets in Deutschland."
      />
    </Helmet>
    <section className="section">
      <div className="section-header">
        <span className="eyebrow">Frühzugang</span>
        <h1 className="section-title">Aktive Beta-, Preorder- und Eventslots</h1>
        <p className="section-description">
          Programmslots werden nach Qualifikation vergeben. Teilnahmebedingungen sind transparent
          dokumentiert und werden vor Freigabe geprüft.
        </p>
      </div>
      <div className="space-y-6">
        {programs.map((program) => (
          <article key={program.name} className="program-card">
            <header>
              <span className="tag">{program.type}</span>
              <h2 className="text-xl font-heading text-surface mt-2">{program.name}</h2>
            </header>
            <dl className="program-meta">
              <div>
                <dt>Deadline</dt>
                <dd>{program.deadline}</dd>
              </div>
              <div>
                <dt>Plätze</dt>
                <dd>{program.spots}</dd>
              </div>
              <div>
                <dt>Standort</dt>
                <dd>{program.location}</dd>
              </div>
            </dl>
            <div className="program-actions">
              <a href="/kontakt" className="btn-primary">
                Frühzugang sichern
              </a>
              <a href="/terms" className="btn-ghost">
                Teilnahmebedingungen
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
    <section className="section">
      <div className="section-header">
        <span className="eyebrow">Transparenz</span>
        <h2 className="section-title">Regeln für Teilnahme</h2>
      </div>
      <ul className="rules-list">
        <li>Deutscher Wohnsitz oder nachweisbarer Unternehmenssitz.</li>
        <li>Verpflichtung zur Rückgabe oder NDA-konformen Vernichtung von Testgeräten.</li>
        <li>Feedback innerhalb von 48 Stunden nach Abschluss einer Testphase.</li>
        <li>Keine öffentliche Veröffentlichung vor Embargo-Ende.</li>
        <li>Transparente Kennzeichnung bei Content-Veröffentlichung.</li>
      </ul>
    </section>
    <section className="section newsletter-section">
      <div className="section-header">
        <span className="eyebrow">Beta-Radar</span>
        <h2 className="section-title">Benachrichtigung aktivieren</h2>
      </div>
      <NewsletterForm />
    </section>
  </>
);

export default EarlyAccess;