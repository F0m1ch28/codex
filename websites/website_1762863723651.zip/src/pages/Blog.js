import React from "react";
import { Helmet } from "react-helmet";
import { NavLink } from "react-router-dom";

const posts = [
  {
    slug: "fruehzugang-checkliste",
    title: "Frühzugang Checkliste für Teams",
    excerpt:
      "Welche Unterlagen braucht ihr, wie funktioniert NDA-Handling und welche KPI werden bewertet?",
    date: "15. August 2023",
    image: "https://picsum.photos/800/600?random=71",
  },
  {
    slug: "benchmarks-transparenz",
    title: "Benchmark-Transparenz bei Wearables",
    excerpt:
      "Warum Herzfrequenzmessung in Laboren anders ausfällt als im Alltag und wie wir das ausgleichen.",
    date: "1. August 2023",
    image: "https://picsum.photos/800/600?random=72",
  },
];

const Blog = () => (
  <>
    <Helmet>
      <title>Blog – Slexorifyx</title>
      <meta
        name="description"
        content="Insights, Checklisten und Hintergrundwissen rund um Gadgets, Frühzugänge und Testmethodik."
      />
    </Helmet>
    <section className="section">
      <div className="section-header">
        <span className="eyebrow">Insights</span>
        <h1 className="section-title">Blog &amp; Updates</h1>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        {posts.map((post) => (
          <article key={post.slug} className="project-card">
            <img
              src={post.image}
              alt={`${post.title} Vorschaubild`}
              className="project-image"
              loading="lazy"
            />
            <div className="p-6">
              <span className="text-xs uppercase tracking-[0.2em] text-accent">{post.date}</span>
              <h2 className="text-xl font-heading text-surface mt-2 mb-2">{post.title}</h2>
              <p className="text-sm text-body/80">{post.excerpt}</p>
              <NavLink to={`/blog/${post.slug}`} className="btn-secondary mt-4 inline-flex">
                Weiterlesen
              </NavLink>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;