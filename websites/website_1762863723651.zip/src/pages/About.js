import React from "react";
import { Helmet } from "react-helmet";

const teamMembers = [
  {
    name: "Svenja Lorenz",
    role: "Head of Testing",
    image: "https://picsum.photos/400/400?random=81",
  },
  {
    name: "Baran Köhler",
    role: "Lead Partnerships",
    image: "https://picsum.photos/400/400?random=82",
  },
  {
    name: "Jasmin Nguyen",
    role: "Chief Analyst",
    image: "https://picsum.photos/400/400?random=83",
  },
];

const About = () => (
  <>
    <Helmet>
      <title>Über uns – Slexorifyx</title>
      <meta
        name="description"
        content="Lernen Sie das Slexorifyx Team kennen – Expert:innen für Testmethodik, Partnerschaften und Analyse."
      />
    </Helmet>
    <section className="section">
      <div className="section-header">
        <span className="eyebrow">Über uns</span>
        <h1 className="section-title">Das Team hinter Slexorifyx</h1>
        <p className="section-description">
          Wir kombinieren Labor-Expertise mit Community-Vertrauen. Unser Team arbeitet in Berlin mit
          Partnerlabs in ganz Deutschland.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {teamMembers.map((member) => (
          <article key={member.name} className="team-card">
            <img
              src={member.image}
              alt={`${member.name}, ${member.role}`}
              className="team-image"
              loading="lazy"
            />
            <div className="p-5">
              <h3 className="text-lg font-heading text-surface">{member.name}</h3>
              <p className="text-sm text-body/70">{member.role}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default About;