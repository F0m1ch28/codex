import React from "react";
import { Helmet } from "react-helmet";

const Terms = () => (
  <>
    <Helmet>
      <title>Nutzungsbedingungen – Slexorifyx</title>
      <meta
        name="description"
        content="Nutzungsbedingungen für die Plattform Slexorifyx – gültig für Nutzer:innen in Deutschland."
      />
    </Helmet>
    <section className="section prose">
      <h1>Nutzungsbedingungen</h1>
      <p>Letzte Aktualisierung: 1. August 2023</p>
      <p>
        Durch die Nutzung von Slexorifyx akzeptieren Sie diese Bedingungen. Inhalte sind urheberrechtlich
        geschützt. Reviews dürfen verlinkt, nicht jedoch ohne Freigabe reproduziert werden.
      </p>
      <h2>Haftung</h2>
      <p>
        Wir prüfen Informationen sorgfältig, übernehmen aber keine Gewähr für Preise, Verfügbarkeiten oder
        Drittanbieterangaben. Frühzugänge unterliegen den Konditionen der jeweiligen Partner.
      </p>
      <h2>Benutzerpflichten</h2>
      <ul>
        <li>Keine Weitergabe von Beta-Geräten ohne schriftliche Zustimmung.</li>
        <li>Einhaltung von Embargos und NDA-Klauseln.</li>
        <li>Keine automatisierte Datenerfassung.</li>
      </ul>
    </section>
  </>
);

export default Terms;