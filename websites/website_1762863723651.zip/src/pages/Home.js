import React from "react";
import { Helmet } from "react-helmet";
import { NavLink } from "react-router-dom";
import HeroHighlight from "../components/HeroHighlight";
import StatsCounter from "../components/StatsCounter";
import ProcessSteps from "../components/ProcessSteps";
import TestimonialsCarousel from "../components/TestimonialsCarousel";
import ProjectsGallery from "../components/ProjectsGallery";
import FAQAccordion from "../components/FAQAccordion";
import NewsletterForm from "../components/NewsletterForm";
import TestCriteria from "../components/TestCriteria";
import MapView from "../components/MapView";
import ReviewCard from "../components/ReviewCard";

const sampleReviews = [
  {
    slug: "quantum-pulse-s1",
    title: "Quantum Pulse S1 Review",
    subtitle: "Premium Wearable mit präzisem Health-Tracking",
    category: "Wearables",
    date: "12. September 2023",
    os: "PulseOS",
    price: "449 €",
    score: "8.7",
    excerpt:
      "Sehr genaue Sensorik, hervorragende Verarbeitung und deutliche Fortschritte bei Datenschutz-Einstellungen.",
    image: "https://picsum.photos/800/600?random=41",
    imageAlt: "Quantum Pulse S1 Wearable",
  },
  {
    slug: "aether-tab-x",
    title: "Aether Tab X Review",
    subtitle: "OLED-Tablet mit Desktop-Ambitionen",
    category: "Tablets",
    date: "5. September 2023",
    os: "AetherOS 5",
    price: "799 €",
    score: "9.0",
    excerpt:
      "Beste Multitasking-Performance im Vergleichsfeld, inklusive optionalem eGPU-Dock und 120Hz OLED.",
    image: "https://picsum.photos/800/600?random=42",
    imageAlt: "Aether Tab X Tablet",
  },
  {
    slug: "fluxphone-pro",
    title: "FluxPhone Pro Review",
    subtitle: "Camera-First Smartphone mit KI-Tuning",
    category: "Smartphones",
    date: "28. August 2023",
    os: "FluxOS 13",
    price: "999 €",
    score: "8.4",
    excerpt:
      "Fantastische Nachtfotografie und modulare Linsen. Software noch mit kleineren Stabilitätsproblemen.",
    image: "https://picsum.photos/800/600?random=43",
    imageAlt: "FluxPhone Pro Smartphone",
  },
];

const partnerMarkers = [
  { lat: 52.52, lng: 13.405, title: "Berlin – Beta Lab Mitte" },
  { lat: 48.1351, lng: 11.582, title: "München – XR Experience Hub" },
  { lat: 53.5511, lng: 9.9937, title: "Hamburg – Mobility Test Center" },
];

const Home = () => {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Slexorifyx GmbH",
    url: "https://www.slexorifyx.de",
    logo: "https://www.slexorifyx.de/logo.png",
    sameAs: [
      "https://www.linkedin.com/company/slexorifyx",
      "https://www.youtube.com/@slexorifyx",
    ],
    address: {
      "@type": "PostalAddress",
      streetAddress: "Industriestraße 12",
      addressLocality: "Berlin",
      postalCode: "10115",
      addressCountry: "DE",
    },
    contactPoint: [
      {
        "@type": "ContactPoint",
        contactType: "customer support",
        email: "support@slexorifyx.de",
        availableLanguage: ["de", "en"],
      },
    ],
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.7",
      reviewCount: "312",
    },
  };

  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Slexorifyx – Sei früher dran. Entscheide besser.</title>
        <meta
          name="description"
          content="Slexorifyx liefert frühe Zugänge, verlässliche Reviews und klare Vergleiche für neue Gadgets in Deutschland."
        />
        <meta name="robots" content="index,follow" />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>
      <section className="hero">
        <div className="hero-content">
          <span className="eyebrow">Verified Gadget Access</span>
          <h1 className="hero-title">Sei früher dran. Entscheide besser.</h1>
          <p className="hero-subtitle">
            Echte Tests, klare Vergleiche und Frühzugang über geprüfte Partner in Deutschland.
            Ausrichtung auf Tech-Teams, Creator:innen und ambitionierte Early Adopter.
          </p>
          <div className="hero-actions">
            <NavLink to="/early" className="btn-primary">
              Frühzugang finden
            </NavLink>
            <NavLink to="/reviews" className="btn-secondary">
              Reviews ansehen
            </NavLink>
          </div>
          <div className="mt-6 text-xs text-body/60 max-w-xl">
            Affiliate-Links sind gekennzeichnet. Preise inkl. MwSt. und Versand nach Deutschland.
          </div>
        </div>
        <div className="hero-media">
          <img
            src="https://picsum.photos/1600/900?random=21"
            alt="Professionelle Techniker testen ein neues Gadget"
            className="hero-image"
          />
        </div>
      </section>

      <HeroHighlight />
      <StatsCounter />
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Aktuelle Reviews</span>
          <h2 className="section-title">Top-Gadgets im Fokus</h2>
          <p className="section-description">
            Jede Review enthält offene Scorecards, Preisvergleiche und lokale Bezugsquellen.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {sampleReviews.map((review) => (
            <ReviewCard key={review.slug} review={review} />
          ))}
        </div>
      </section>

      <ProcessSteps />
      <ProjectsGallery />
      <TestimonialsCarousel />
      <TestCriteria />

      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Partnernetzwerk</span>
          <h2 className="section-title">Mini-Karte – geprüfte Standorte</h2>
          <p className="section-description">
            Labs, Demo-Stationen und Eventflächen in ganz Deutschland. Weitere Filter finden Sie auf
            der Partnerkarte.
          </p>
        </div>
        <MapView markers={partnerMarkers} />
        <div className="mt-6 text-sm">
          <NavLink to="/karte" className="btn-secondary">
            Vollständige Karte öffnen
          </NavLink>
        </div>
      </section>

      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Vergleiche</span>
          <h2 className="section-title">Top-Vergleiche der Woche</h2>
          <p className="section-description">
            Exportieren Sie Ergebnisse als CSV oder PNG für Ihr Team. Bis zu vier Geräte können
            nebeneinander ausgewertet werden.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            "OLED Tablets 2023",
            "Wearable Sleep Tracker",
            "Smart Home Energy Kits",
            "Creator Laptops 14 Zoll",
          ].map((item) => (
            <article key={item} className="comparison-card">
              <h3>{item}</h3>
              <p>Vergleich von Specs, Laufzeiten und Preisentwicklungen.</p>
              <NavLink to="/compare" className="btn-link">
                Vergleichen
              </NavLink>
            </article>
          ))}
        </div>
      </section>

      <FAQAccordion />

      <section className="section newsletter-section">
        <div className="section-header">
          <span className="eyebrow">Newsletter</span>
          <h2 className="section-title">Beta-Spots zuerst sichern</h2>
          <p className="section-description">
            Jeden Montag verschicken wir Gating-Links für neue Betaprogramme. Keine Werbung, nur
            Fakten.
          </p>
        </div>
        <NewsletterForm />
      </section>

      <section className="section">
        <div className="cta-panel">
          <div>
            <h2 className="text-3xl font-heading text-surface mb-3">
              Bereit für den nächsten Launch?
            </h2>
            <p className="text-sm text-body/70">
              Registrieren Sie Ihr Team, sichern Sie Testgeräte oder buchen Sie ein Review-Slot im
              Partnerlab.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <NavLink to="/kontakt" className="btn-primary">
              Kontakt aufnehmen
            </NavLink>
            <NavLink to="/services" className="btn-secondary">
              Services entdecken
            </NavLink>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;