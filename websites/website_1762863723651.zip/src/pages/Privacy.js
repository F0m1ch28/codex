import React from "react";
import { Helmet } from "react-helmet";

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutz – Slexorifyx</title>
      <meta
        name="description"
        content="Datenschutzhinweise von Slexorifyx – DSGVO-konforme Verarbeitung, keine Drittanbieter-Cookies."
      />
    </Helmet>
    <section className="section prose">
      <h1>Datenschutzerklärung</h1>
      <p>
        Wir verarbeiten personenbezogene Daten ausschließlich zur Bereitstellung des Dienstes. Grundlage ist
        Art. 6 Abs. 1 lit. b DSGVO. Es erfolgt keine Weitergabe an Dritte ohne Einwilligung.
      </p>
      <h2>Analytics</h2>
      <p>
        Unsere Reichweitenanalyse erfolgt serverseitig. IP-Adressen werden unmittelbar anonymisiert. Es werden
        keine Cookies oder Pixel externer Anbieter gesetzt.
      </p>
      <h2>Kontaktformular</h2>
      <p>
        Angaben aus Kontaktformularen werden zur Bearbeitung Ihres Anliegens gespeichert und nach Abschluss
        gelöscht, sofern keine gesetzlichen Aufbewahrungsfristen entgegenstehen.
      </p>
    </section>
  </>
);

export default Privacy;