import React from "react";
import { useParams } from "react-router-dom";
import { Helmet } from "react-helmet";

const articles = {
  "fruehzugang-checkliste": {
    title: "Frühzugang Checkliste für Teams",
    content: [
      "Verifizieren Sie Ihr Unternehmen oder Creator-Profil, inklusive realer Adresse in Deutschland.",
      "Definieren Sie klare Ziele für den Frühzugang: Review, internes Testing oder Event-Vorbereitung.",
      "Planen Sie Zeit für Feedback und dokumentieren Sie Ihre Ergebnisse strukturiert.",
    ],
  },
  "benchmarks-transparenz": {
    title: "Benchmark-Transparenz bei Wearables",
    content: [
      "Laborwerte sind reproduzierbar, jedoch nicht identisch mit realen Alltagsszenarien.",
      "Wir kombinieren Labor- und Feldtests, um Abweichungen offen zu legen.",
      "Transparente Rohdaten stehen Partnern in anonymisierter Form zur Verfügung.",
    ],
  },
};

const BlogArticle = () => {
  const { artikel } = useParams();
  const article = articles[artikel];

  if (!article) {
    return (
      <section className="section">
        <h1 className="section-title">Artikel nicht gefunden</h1>
      </section>
    );
  }

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: article.title,
    datePublished: "2023-08-15",
    author: {
      "@type": "Person",
      name: "Slexorifyx Redaktion",
    },
  };

  return (
    <>
      <Helmet>
        <title>{article.title} – Slexorifyx</title>
        <meta name="description" content={article.content[0]} />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>
      <article className="section prose">
        <h1>{article.title}</h1>
        {article.content.map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </article>
    </>
  );
};

export default BlogArticle;