import React from "react";
import { Helmet } from "react-helmet";

const Cookies = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie – Slexorifyx</title>
      <meta
        name="description"
        content="Informationen zu Cookies bei Slexorifyx: ausschließlich technisch notwendige Cookies."
      />
    </Helmet>
    <section className="section prose">
      <h1>Cookie-Richtlinie</h1>
      <p>
        Slexorifyx verwendet nur notwendige Cookies für Sitzungsverwaltung und Consent-Speicherung. Keine
        Tracking- oder Marketing-Cookies.
      </p>
      <h2>Essentielle Cookies</h2>
      <table>
        <thead>
          <tr>
            <th>Cookie</th>
            <th>Zweck</th>
            <th>Laufzeit</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>slex-session</td>
            <td>Sitzungsverwaltung</td>
            <td>24 Stunden</td>
          </tr>
          <tr>
            <td>slex-consent</td>
            <td>Speichert Consent-Einstellungen</td>
            <td>12 Monate</td>
          </tr>
        </tbody>
      </table>
    </section>
  </>
);

export default Cookies;