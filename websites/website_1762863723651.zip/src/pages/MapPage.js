import React, { useState } from "react";
import { Helmet } from "react-helmet";
import MapView from "../components/MapView";

const markers = [
  { lat: 52.52, lng: 13.405, title: "Berlin – Beta Lab" },
  { lat: 50.1109, lng: 8.6821, title: "Frankfurt – Demo Hub" },
  { lat: 48.1351, lng: 11.582, title: "München – Event Space" },
  { lat: 51.2277, lng: 6.7735, title: "Düsseldorf – Abholpunkt" },
];

const MapPage = () => {
  const [search, setSearch] = useState("");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: markers.map((marker, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: marker.title,
      item: {
        "@type": "Place",
        name: marker.title,
        geo: {
          "@type": "GeoCoordinates",
          latitude: marker.lat,
          longitude: marker.lng,
        },
        address: {
          "@type": "PostalAddress",
          addressCountry: "DE",
        },
      },
    })),
  };

  return (
    <>
      <Helmet>
        <title>Partnerkarte – Slexorifyx</title>
        <meta
          name="description"
          content="Finden Sie Slexorifyx Partner, Demo-Spots, Abholpunkte und Events auf der Karte in Deutschland."
        />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Partnernetzwerk</span>
          <h1 className="section-title">Karte: Labs, Demos &amp; Events</h1>
          <p className="section-description">
            Nutzen Sie die Filter, um Partner, Demo-Stationen, Abholpunkte oder Events zu finden.
          </p>
        </div>
        <div className="filter-bar">
          <label className="w-full md:w-auto">
            Ort / PLZ
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="z.B. 10115 oder München"
            />
          </label>
          <fieldset className="filter-group" role="group" aria-label="Kategorien filtern">
            <legend>Filter</legend>
            {["Partner", "Demo", "Abholpunkt", "Event"].map((label) => (
              <label key={label} className="filter-checkbox">
                <input type="checkbox" defaultChecked />
                <span>{label}</span>
              </label>
            ))}
          </fieldset>
        </div>
        <MapView markers={markers} />
        <p className="mt-4 text-xs text-body/60">
          Hinweis: Daten werden alle 24h aktualisiert. Kein Tracking gegenüber Google, bis Sie die Karte
          aktiv laden.
        </p>
      </section>
    </>
  );
};

export default MapPage;