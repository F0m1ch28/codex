import React, { useState } from "react";
import { Helmet } from "react-helmet";

const Contact = () => {
  const [status, setStatus] = useState("");

  const submit = (event) => {
    event.preventDefault();
    setStatus("Danke! Wir melden uns innerhalb von 24 Stunden.");
  };

  return (
    <>
      <Helmet>
        <title>Kontakt – Slexorifyx</title>
        <meta
          name="description"
          content="Kontaktieren Sie das Slexorifyx Team für Presse, Partnerprogramme oder Support."
        />
      </Helmet>
      <section className="section max-w-3xl mx-auto">
        <div className="section-header">
          <span className="eyebrow">Kontakt</span>
          <h1 className="section-title">Wir sind für Sie da</h1>
          <p className="section-description">
            Bitte nutzen Sie unser Formular. Telefonate werden individuell nach Bedarf koordiniert.
          </p>
        </div>
        <form className="contact-form" onSubmit={submit} noValidate>
          <label>
            Name
            <input type="text" name="name" required placeholder="Ihr Name" />
          </label>
          <label>
            E-Mail
            <input type="email" name="email" required placeholder="you@example.de" />
          </label>
          <label>
            Grund
            <select name="reason" required>
              <option value="">Bitte wählen</option>
              <option value="partnership">Partnerschaft</option>
              <option value="press">Presse</option>
              <option value="support">Support</option>
            </select>
          </label>
          <label>
            Nachricht
            <textarea name="message" rows="5" required placeholder="Ihr Anliegen" />
          </label>
          <div className="flex items-center space-x-3 text-xs text-body/60">
            <input id="privacy" type="checkbox" required />
            <label htmlFor="privacy">
              Ich stimme der Verarbeitung gemäß Datenschutz zu. Keine Weitergabe an Dritte.
            </label>
          </div>
          <button type="submit" className="btn-primary w-full sm:w-auto mt-4">
            Nachricht senden
          </button>
          {status && <p className="form-feedback">{status}</p>}
        </form>
      </section>
    </>
  );
};

export default Contact;