import React, { useState } from "react";
import { Helmet } from "react-helmet";
import ReviewCard from "../components/ReviewCard";
import NewsletterForm from "../components/NewsletterForm";

const categories = ["Alle", "Smartphones", "Wearables", "Tablets", "Audio", "Smart Home"];
const osOptions = ["Alle", "Android", "iOS", "HarmonyOS", "Custom"];
const ratings = ["Alle", "≥ 9", "≥ 8", "≥ 7", "≤ 6"];

const reviewData = [
  {
    slug: "aurora-ear-max",
    title: "Aurora Ear Max",
    subtitle: "Adaptive ANC für urbanes Pendeln",
    category: "Audio",
    date: "02. September 2023",
    os: "Custom",
    price: "279 €",
    score: "8.9",
    excerpt:
      "Sehr ausgewogene Tuning-Optionen via App, hervorragende Akkulaufzeit. Multipoint-Pairing top.",
    image: "https://picsum.photos/800/600?random=51",
    imageAlt: "Aurora Ear Max Ohrhörer",
  },
  {
    slug: "zen-pod-3-pro",
    title: "Zen Pod 3 Pro",
    subtitle: "Smart Home Zum Nachrüsten",
    category: "Smart Home",
    date: "25. August 2023",
    os: "HarmonyOS",
    price: "199 €",
    score: "8.2",
    excerpt:
      "Sehr gute Matter-Integration, zuverlässige Routinen. Fehlende Datenschutzoptionen kosten Punkte.",
    image: "https://picsum.photos/800/600?random=52",
    imageAlt: "Zen Pod 3 Pro Smart Home Hub",
  },
  {
    slug: "nova-slate-15",
    title: "Nova Slate 15",
    subtitle: "Mobile Workstation mit Mini-LED",
    category: "Tablets",
    date: "17. August 2023",
    os: "Android",
    price: "1199 €",
    score: "9.1",
    excerpt:
      "Mini-LED Display mit 165Hz, top Tastatur-Dock, lange Laufzeit. Software noch nicht perfekt lokalisiert.",
    image: "https://picsum.photos/800/600?random=53",
    imageAlt: "Nova Slate 15 Tablet",
  },
  {
    slug: "pulse-track-6",
    title: "Pulse Track 6",
    subtitle: "Wearable mit präzisem Tracking",
    category: "Wearables",
    date: "11. August 2023",
    os: "Custom",
    price: "299 €",
    score: "8.5",
    excerpt:
      "Starke Herzfrequenzmessung inkl. medizinischer APIs. Display in Sonne etwas schwach.",
    image: "https://picsum.photos/800/600?random=54",
    imageAlt: "Pulse Track 6 Wearable",
  },
];

const Reviews = () => {
  const [category, setCategory] = useState("Alle");
  const [os, setOs] = useState("Alle");
  const [rating, setRating] = useState("Alle");

  const filtered = reviewData.filter((item) => {
    const matchCategory = category === "Alle" || item.category === category;
    const matchOs = os === "Alle" || item.os === os;
    let matchRating = true;
    if (rating === "≥ 9") matchRating = parseFloat(item.score) >= 9;
    if (rating === "≥ 8") matchRating = parseFloat(item.score) >= 8;
    if (rating === "≥ 7") matchRating = parseFloat(item.score) >= 7;
    if (rating === "≤ 6") matchRating = parseFloat(item.score) <= 6;
    return matchCategory && matchOs && matchRating;
  });

  const breadcrumbsLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Start", item: "https://www.slexorifyx.de/" },
      { "@type": "ListItem", position: 2, name: "Reviews", item: "https://www.slexorifyx.de/reviews" },
    ],
  };

  return (
    <>
      <Helmet>
        <title>Reviews – Slexorifyx</title>
        <meta
          name="description"
          content="Fundierte Gadget-Reviews mit offen gelegten Testkriterien, Benchmarks und Preisvergleich speziell für Deutschland."
        />
        <script type="application/ld+json">{JSON.stringify(breadcrumbsLd)}</script>
      </Helmet>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Reviews</span>
          <h1 className="section-title">Analyse statt Hype</h1>
          <p className="section-description">
            Filtern Sie nach Kategorie, Betriebssystem, Veröffentlichungsdatum oder Score. Alle Tests
            erfolgen mit dokumentierten Methodiken.
          </p>
        </div>
        <div className="filter-bar">
          <label>
            Kategorie
            <select value={category} onChange={(event) => setCategory(event.target.value)}>
              {categories.map((cat) => (
                <option key={cat}>{cat}</option>
              ))}
            </select>
          </label>
          <label>
            OS
            <select value={os} onChange={(event) => setOs(event.target.value)}>
              {osOptions.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </label>
          <label>
            Rating
            <select value={rating} onChange={(event) => setRating(event.target.value)}>
              {ratings.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </label>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {filtered.map((review) => (
            <ReviewCard key={review.slug} review={review} />
          ))}
        </div>
      </section>
      <section className="section newsletter-section">
        <div className="section-header">
          <span className="eyebrow">Kein Launch verpassen</span>
          <h2 className="section-title">Review Drops zuerst im Posteingang</h2>
        </div>
        <NewsletterForm />
      </section>
    </>
  );
};

export default Reviews;