import React from "react";
import { useParams, NavLink } from "react-router-dom";
import { Helmet } from "react-helmet";
import SpecTable from "../components/SpecTable";
import MapView from "../components/MapView";
import PartnerBadge from "../components/PartnerBadge";

const reviewDetails = {
  "quantum-pulse-s1": {
    title: "Quantum Pulse S1 – Ganzkörper-Sensorik der nächsten Generation",
    imageGallery: [
      "https://picsum.photos/1200/800?random=61",
      "https://picsum.photos/1200/800?random=62",
      "https://picsum.photos/1200/800?random=63",
    ],
    specs: [
      { label: "Sensoren", value: "EKG, HRV, Blutsauerstoff, Hauttemperatur" },
      { label: "Display", value: "1,8\" MicroLED, 1000 nits" },
      { label: "Akkulaufzeit", value: "72 Stunden Alltagsnutzung" },
      { label: "Wasserschutz", value: "5 ATM" },
      { label: "OS", value: "PulseOS 3.2" },
      { label: "Speicher", value: "32 GB intern" },
    ],
    benchmarks: [
      { name: "Stresstest 30min Lauf", value: "Herzfrequenzabweichung <1,8%" },
      { name: "GPS Genauigkeit", value: "±1,2 m in urbanem Setting" },
      { name: "Sensor Drift", value: "0,4% nach 48h" },
    ],
    pros: [
      "Sehr präzise Sensorik mit medizinischen APIs",
      "Hervorragende App-Lokalisierung und Datenschutzfunktionen",
      "Austauschbare Armbänder, Tool-free",
    ],
    cons: ["Preislich im oberen Segment", "Kein Offline-Musikspeicher", "Nur induktives Laden"],
    pricing: [
      { partner: "TechStore DE", price: "449 €", note: "Affiliate", url: "/#" },
      { partner: "Pulse Direkt", price: "429 €", note: "Partner", url: "/#" },
    ],
    summary:
      "Der Quantum Pulse S1 zeigt, wie präzise Sensorik und saubere Datenschutzkonzepte zusammenspielen können. Unsere Tests belegen eine minimale Abweichung in Stresssituationen und einen zuverlässigen GPS-Track. Die starke Hardware wird durch eine durchdachte App begleitet – nur die Ladeoptionen sind limitiert.",
  },
};

const ReviewDetail = () => {
  const { slug } = useParams();
  const review = reviewDetails[slug];

  if (!review) {
    return (
      <section className="section">
        <h1 className="section-title">Review nicht gefunden</h1>
        <NavLink to="/reviews" className="btn-secondary">
          Zurück zu den Reviews
        </NavLink>
      </section>
    );
  }

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: review.title,
    image: review.imageGallery,
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "8.7",
      bestRating: "10",
      ratingCount: "132",
    },
    review: [
      {
        "@type": "Review",
        reviewRating: {
          "@type": "Rating",
          ratingValue: "8.7",
          bestRating: "10",
        },
        author: {
          "@type": "Person",
          name: "Slexorifyx Review Team",
        },
        reviewBody: review.summary,
      },
    ],
  };

  return (
    <>
      <Helmet>
        <title>{review.title} – Slexorifyx Review</title>
        <meta name="description" content={review.summary} />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>
      <section className="section lg:grid lg:grid-cols-[1fr_auto] lg:gap-10">
        <article>
          <header className="section-header items-start">
            <span className="eyebrow">Review</span>
            <h1 className="section-title text-left">{review.title}</h1>
          </header>
          <div className="gallery">
            {review.imageGallery.map((src, idx) => (
              <img
                key={src}
                src={src}
                alt={`${review.title} Ansicht ${idx + 1}`}
                loading="lazy"
                className="gallery-image"
              />
            ))}
          </div>
          <section className="mt-8 prose">
            <h2>Zusammenfassung</h2>
            <p>{review.summary}</p>
            <h2>Benchmarks</h2>
            <ul>
              {review.benchmarks.map((item) => (
                <li key={item.name}>
                  <strong>{item.name}:</strong> {item.value}
                </li>
              ))}
            </ul>
            <h2>Pro &amp; Kontra</h2>
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="card bg-success/10 border border-success/30">
                <h3 className="text-success font-heading">Pro</h3>
                <ul className="marker:text-success list-disc list-inside text-sm text-body/80">
                  {review.pros.map((pro) => (
                    <li key={pro}>{pro}</li>
                  ))}
                </ul>
              </div>
              <div className="card bg-primary/5 border border-primary/20">
                <h3 className="text-primary font-heading">Kontra</h3>
                <ul className="marker:text-primary list-disc list-inside text-sm text-body/80">
                  {review.cons.map((con) => (
                    <li key={con}>{con}</li>
                  ))}
                </ul>
              </div>
            </div>
            <h2>Preisübersicht Deutschland</h2>
            <table className="price-table" aria-label="Preisübersicht">
              <thead>
                <tr>
                  <th>Partner</th>
                  <th>Preis</th>
                  <th>Hinweis</th>
                  <th>Aktion</th>
                </tr>
              </thead>
              <tbody>
                {review.pricing.map((row) => (
                  <tr key={row.partner}>
                    <td>{row.partner}</td>
                    <td>{row.price}</td>
                    <td>
                      <PartnerBadge
                        label={row.note}
                        tone={row.note === "Affiliate" ? "accent" : "primary"}
                      />
                    </td>
                    <td>
                      <a href={row.url} className="btn-primary">
                        Route anzeigen
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="mt-8 flex flex-wrap gap-3">
              <NavLink to="/compare" className="btn-secondary">
                Vergleichen
              </NavLink>
              <NavLink to="/reviews" className="btn-ghost">
                Weitere Reviews
              </NavLink>
            </div>
          </section>
        </article>
        <SpecTable specs={review.specs} />
      </section>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Partnerkarte</span>
          <h2 className="section-title">Verfügbarkeit in Deutschland</h2>
        </div>
        <MapView
          markers={[
            { lat: 52.52, lng: 13.405, title: "Berlin – Pulse Pop-up Store" },
            { lat: 50.1109, lng: 8.6821, title: "Frankfurt – Partner Demo Zone" },
          ]}
        />
      </section>
    </>
  );
};

export default ReviewDetail;