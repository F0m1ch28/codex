import React from "react";
import { Helmet } from "react-helmet";
import FAQAccordion from "../components/FAQAccordion";

const FAQ = () => (
  <>
    <Helmet>
      <title>FAQ – Slexorifyx</title>
      <meta
        name="description"
        content="Antworten zu Frühzugang, Reviews, Datenverarbeitung und Partnernetzwerk."
      />
    </Helmet>
    <FAQAccordion />
  </>
);

export default FAQ;