import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTop";
import Home from "./pages/Home";
import Reviews from "./pages/Reviews";
import ReviewDetail from "./pages/ReviewDetail";
import EarlyAccess from "./pages/EarlyAccess";
import Compare from "./pages/Compare";
import MapPage from "./pages/MapPage";
import Blog from "./pages/Blog";
import BlogArticle from "./pages/BlogArticle";
import FAQ from "./pages/FAQ";
import Contact from "./pages/Contact";
import About from "./pages/About";
import Services from "./pages/Services";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Cookies from "./pages/Cookies";
import Impressum from "./pages/Impressum";

const App = () => {
  return (
    <div className="bg-base text-body min-h-screen">
      <Header />
      <main id="main-content" className="pt-24 pb-16">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="/reviews/:slug" element={<ReviewDetail />} />
          <Route path="/early" element={<EarlyAccess />} />
          <Route path="/compare" element={<Compare />} />
          <Route path="/karte" element={<MapPage />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:artikel" element={<BlogArticle />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/policy" element={<Privacy />} />
          <Route path="/cookies" element={<Cookies />} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;