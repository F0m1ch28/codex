import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('aurion_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('aurion_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  return (
    isVisible && (
      <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent notice">
        <div className={styles.content}>
          <p>
            We use cookies to enhance site navigation and analyze usage. By clicking accept, you agree to our cookie policy.
          </p>
          <div className={styles.actions}>
            <a className={styles.link} href="/cookie-policy">
              Learn more
            </a>
            <button type="button" className={styles.button} onClick={handleAccept}>
              Accept
            </button>
          </div>
        </div>
      </div>
    )
  );
};

export default CookieBanner;