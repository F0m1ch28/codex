import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const handleCloseMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="Aurion Energy Advisory home">
          <span className={styles.logoMark}>Aurion</span>
          <span className={styles.logoText}>Energy Advisory</span>
        </Link>
        <button
          type="button"
          className={styles.menuToggle}
          onClick={handleToggleMenu}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation menu"
        >
          <span className={styles.menuIcon} />
        </button>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Primary">
          <ul id="primary-navigation" className={styles.navList}>
            <li>
              <NavLink to="/about" className={({ isActive }) => (isActive ? styles.activeLink : undefined)} onClick={handleCloseMenu}>
                About
              </NavLink>
            </li>
            <li>
              <NavLink to="/services" className={({ isActive }) => (isActive ? styles.activeLink : undefined)} onClick={handleCloseMenu}>
                Services
              </NavLink>
            </li>
            <li>
              <NavLink to="/projects" className={({ isActive }) => (isActive ? styles.activeLink : undefined)} onClick={handleCloseMenu}>
                Projects
              </NavLink>
            </li>
            <li>
              <NavLink to="/team" className={({ isActive }) => (isActive ? styles.activeLink : undefined)} onClick={handleCloseMenu}>
                Team
              </NavLink>
            </li>
            <li>
              <NavLink to="/contact" className={({ isActive }) => (isActive ? styles.activeLink : undefined)} onClick={handleCloseMenu}>
                Contact
              </NavLink>
            </li>
          </ul>
          <div className={styles.ctaWrapper}>
            <Link to="/contact" className={styles.ctaButton} onClick={handleCloseMenu}>
              Partner with Aurion
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;