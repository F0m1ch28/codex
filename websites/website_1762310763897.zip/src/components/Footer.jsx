import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`${styles.top} container`}>
      <div className={styles.brand}>
        <h2 className={styles.logo}>Aurion Energy Advisory</h2>
        <p>
          Engineering insight for energy infrastructure, oilfield research, and industrial projects across Canada.
        </p>
        <div className={styles.contact}>
          <p><strong>Address:</strong> 460 Bay St, Toronto, ON M5H 2Y4, Canada</p>
          <p><strong>Phone:</strong> <a href="tel:+14167924583">+1 (416) 792-4583</a></p>
          <p><strong>Email:</strong> <a href="mailto:info@aurionenergyadvisory.ca">info@aurionenergyadvisory.ca</a></p>
        </div>
      </div>
      <nav className={styles.links} aria-label="Footer">
        <h3>Company</h3>
        <ul>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/services">Services</Link></li>
          <li><Link to="/projects">Projects</Link></li>
          <li><Link to="/team">Team</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>
      </nav>
      <nav className={styles.links} aria-label="Governance">
        <h3>Governance</h3>
        <ul>
          <li><Link to="/terms">Terms of Use</Link></li>
          <li><Link to="/policy">Privacy Policy</Link></li>
          <li><Link to="/cookie-policy">Cookie Policy</Link></li>
        </ul>
      </nav>
      <div className={styles.social}>
        <h3>Connect</h3>
        <a
          href="https://www.linkedin.com"
          target="_blank"
          rel="noreferrer"
          aria-label="Aurion Energy Advisory on LinkedIn"
        >
          LinkedIn
        </a>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Aurion Energy Advisory. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;