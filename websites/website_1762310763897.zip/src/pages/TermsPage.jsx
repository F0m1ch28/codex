import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './TermsPage.module.css';

const TermsPage = () => (
  <>
    <Helmet>
      <title>Terms of Use | Aurion Energy Advisory</title>
      <meta
        name="description"
        content="Review the terms of use for Aurion Energy Advisory’s website and services."
      />
      <meta
        name="keywords"
        content="terms of use, consulting firm, energy consulting Canada"
      />
    </Helmet>

    <section className="section section--alt">
      <div className="container">
        <div className={styles.wrapper}>
          <h1>Terms of Use</h1>
          <p>Last updated: January 2024</p>
          <h2>Acceptance of Terms</h2>
          <p>
            By accessing this website, you agree to these Terms of Use. Aurion Energy Advisory may update these terms periodically. Continued use of the site indicates acceptance of any modifications.
          </p>
          <h2>Use of Content</h2>
          <p>
            All content on this site is provided for informational purposes. You may not reproduce, distribute, or modify content without prior written permission from Aurion Energy Advisory.
          </p>
          <h2>Accuracy of Information</h2>
          <p>
            We endeavor to provide accurate and current information. However, we do not warrant that the content is complete, reliable, or suitable for any particular purpose.
          </p>
          <h2>Third-Party Links</h2>
          <p>
            This website may contain links to third-party websites. Aurion Energy Advisory is not responsible for the content or practices of those sites and provides such links for convenience only.
          </p>
          <h2>Limitation of Liability</h2>
          <p>
            Aurion Energy Advisory shall not be liable for any direct or indirect damages arising from the use or inability to use this website.
          </p>
          <h2>Governing Law</h2>
          <p>
            These terms are governed by the laws of the Province of Ontario and the laws of Canada applicable therein.
          </p>
          <h2>Contact</h2>
          <p>
            Questions about these terms can be directed to <a href="mailto:info@aurionenergyadvisory.ca">info@aurionenergyadvisory.ca</a>.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default TermsPage;