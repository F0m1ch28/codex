import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './TeamPage.module.css';

const TeamPage = () => {
  const teamMembers = [
    {
      name: 'Andre Bellemare, P.Geo.',
      role: 'Principal Geoscientist',
      bio: 'Specializes in reservoir modeling, seismic interpretation, and subsurface risk assessments across major basins.',
      image: 'https://picsum.photos/400/400?random=701',
      alt: 'Portrait of Andre Bellemare reviewing geological data',
    },
    {
      name: 'Leah Banerjee, P.Eng.',
      role: 'Senior Mechanical Engineer',
      bio: 'Leads mechanical design, heavy-lift planning, and commissioning for complex industrial installations.',
      image: 'https://picsum.photos/400/400?random=702',
      alt: 'Portrait of Leah Banerjee overseeing mechanical engineering work',
    },
    {
      name: 'Calvin Morris, PMP',
      role: 'Program Manager',
      bio: 'Coordinates multidisciplinary teams, project controls, and stakeholder communication.',
      image: 'https://picsum.photos/400/400?random=703',
      alt: 'Portrait of Calvin Morris managing project operations',
    },
    {
      name: 'Nadia Chen, MSc',
      role: 'Environmental Specialist',
      bio: 'Develops environmental impact assessments and sustainability programs aligned with regulatory requirements.',
      image: 'https://picsum.photos/400/400?random=704',
      alt: 'Portrait of Nadia Chen leading environmental assessments',
    },
    {
      name: 'Robert Standing, CRSP',
      role: 'Health & Safety Lead',
      bio: 'Implements safety systems, conducts site audits, and fosters a proactive safety culture across projects.',
      image: 'https://picsum.photos/400/400?random=705',
      alt: 'Portrait of Robert Standing delivering a safety briefing',
    },
    {
      name: 'Isabelle Fontaine, P.Eng.',
      role: 'Electrical Systems Engineer',
      bio: 'Designs power systems, grid integration plans, and digital monitoring solutions for renewable and conventional assets.',
      image: 'https://picsum.photos/400/400?random=706',
      alt: 'Portrait of Isabelle Fontaine analyzing electrical systems',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Team | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Meet the consultants, engineers, and specialists powering Aurion Energy Advisory’s projects across Canada."
        />
        <meta
          name="keywords"
          content="consulting firm, energy consulting Canada, industrial engineering, oil and gas Canada"
        />
      </Helmet>

      <section className="section section--alt">
        <div className="container">
          <div className={styles.header}>
            <h1>Team</h1>
            <p>
              Our consultants, engineers, and project specialists combine field experience with strategic insight. Aurion teams bring pragmatic thinking and collaborative energy to every engagement.
            </p>
          </div>
          <div className={styles.grid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.card}>
                <img src={member.image} alt={member.alt} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{member.name}</h2>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default TeamPage;