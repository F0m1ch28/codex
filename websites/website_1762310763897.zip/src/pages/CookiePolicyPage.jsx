import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Aurion Energy Advisory</title>
      <meta
        name="description"
        content="Understand how Aurion Energy Advisory uses cookies and how you can manage cookie preferences."
      />
      <meta
        name="keywords"
        content="cookie policy, consulting firm, energy consulting Canada"
      />
    </Helmet>

    <section className="section section--alt">
      <div className="container">
        <div className={styles.wrapper}>
          <h1>Cookie Policy</h1>
          <p>Last updated: January 2024</p>
          <h2>What Are Cookies?</h2>
          <p>
            Cookies are small text files placed on your device to store data. They help improve your browsing experience and provide anonymous analytics.
          </p>
          <h2>Types of Cookies We Use</h2>
          <ul>
            <li><strong>Essential Cookies:</strong> Required for site functionality and secure navigation.</li>
            <li><strong>Performance Cookies:</strong> Collect anonymous data on how visitors use our website.</li>
          </ul>
          <h2>Managing Cookies</h2>
          <p>
            Most web browsers allow you to manage cookie preferences. You can set browsers to block or delete cookies, although some site features may not function as intended.
          </p>
          <h2>Changes to This Policy</h2>
          <p>
            We may update this Cookie Policy periodically. Updates will be posted on this page with the revised date.
          </p>
          <h2>Contact</h2>
          <p>
            For questions about cookies, contact us at <a href="mailto:info@aurionenergyadvisory.ca">info@aurionenergyadvisory.ca</a>.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;