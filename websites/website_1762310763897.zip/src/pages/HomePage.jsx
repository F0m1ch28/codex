import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './HomePage.module.css';

const HomePage = () => {
  const heroImage = 'https://picsum.photos/1200/800?random=101';
  const expertiseData = [
    {
      title: 'Energy Consulting',
      description:
        'Strategic analysis, regulatory alignment, and infrastructure planning tailored to Canadian energy markets.',
      image: 'https://picsum.photos/600/400?random=201',
      alt: 'Engineers reviewing energy strategy in a control room',
    },
    {
      title: 'Oilfield Research',
      description:
        'Reservoir assessment, subsurface modeling, and data-backed recommendations for upstream performance.',
      image: 'https://picsum.photos/600/400?random=202',
      alt: 'Geoscientists analyzing subsurface data on digital screens',
    },
    {
      title: 'Engineering Installations',
      description:
        'Cranes, logistics, and heavy-lift coordination for complex industrial build-outs across the energy value chain.',
      image: 'https://picsum.photos/600/400?random=203',
      alt: 'Industrial crane installation at an energy project site',
    },
  ];

  const projects = [
    {
      name: 'Northern Gas Compression Upgrade',
      description:
        'Delivered full lifecycle engineering for a compression station modernization, improving throughput and reliability.',
      image: 'https://picsum.photos/800/600?random=301',
      alt: 'Gas compression facility with modernized infrastructure',
    },
    {
      name: 'Atlantic Offshore Subsea Study',
      description:
        'Conducted subsea asset integrity review and environmental baselining for offshore operations in Atlantic Canada.',
      image: 'https://picsum.photos/800/600?random=302',
      alt: 'Offshore platform with subsea equipment',
    },
    {
      name: 'Prairie Wind Integration Program',
      description:
        'Integrated wind assets into existing grid infrastructure with adaptive load management and digital monitoring.',
      image: 'https://picsum.photos/800/600?random=303',
      alt: 'Wind turbines integrated into regional energy network',
    },
    {
      name: 'Arctic Logistics Hub',
      description:
        'Coordinated modular equipment transport, crane installation, and winterized safety planning for a remote hub.',
      image: 'https://picsum.photos/800/600?random=304',
      alt: 'Heavy equipment and cranes operating in a remote arctic site',
    },
  ];

  const testimonials = [
    {
      quote:
        'Aurion aligned complex stakeholder requirements and delivered a clear blueprint for our energy transition roadmap.',
      name: 'Jenna Wallace',
      role: 'Director of Operations, Coastal Energy Co.',
    },
    {
      quote:
        'Their oilfield research team provided actionable insight that enhanced our exploration success in Western Canada.',
      name: 'Leonard Graham',
      role: 'VP Exploration, Frontier Resources',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Aurion Energy Advisory | Engineering the Future of Energy</title>
        <meta
          name="description"
          content="Aurion Energy Advisory delivers energy consulting, oilfield research, and industrial engineering solutions across Canada."
        />
        <meta
          name="keywords"
          content="energy consulting Canada, oilfield research, industrial engineering, crane installation, energy infrastructure, consulting firm, oil and gas Canada, sustainable engineering, industrial projects"
        />
      </Helmet>
      <section className={styles.hero} style={{ backgroundImage: `url(${heroImage})` }}>
        <div className={styles.overlay}>
          <div className={`${styles.heroContent} container`}>
            <p className={styles.kicker}>Trusted Canadian expertise</p>
            <h1>Engineering the Future of Energy</h1>
            <p>
              Aurion Energy Advisory guides operators, developers, and investors through the evolving energy landscape with
              evidence-based consulting and resilient engineering delivery.
            </p>
            <div className={styles.heroActions}>
              <Link to="/services" className="btn-primary">
                Explore Services
              </Link>
              <Link to="/contact" className="btn-secondary">
                Start a Conversation
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.intro}>
            <h2 className="section-title">The Aurion Advantage</h2>
            <p className="section-subtitle">
              We combine strategy, field intelligence, and engineering execution to help clients deliver energy infrastructure that is safe, efficient, and ready for tomorrow&apos;s demands.
            </p>
            <ul className={styles.introList}>
              <li>Advisory depth across upstream, midstream, and power sectors</li>
              <li>Integrated teams of consultants, engineers, and logistics specialists</li>
              <li>Commitment to sustainability, safety, and Indigenous partnerships</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="section section--alt">
        <div className="container">
          <h2 className="section-title">Our Expertise</h2>
          <div className={styles.expertiseGrid}>
            {expertiseData.map((item) => (
              <article key={item.title} className={styles.expertiseCard}>
                <img src={item.image} alt={item.alt} loading="lazy" />
                <div className={styles.cardContent}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.focusGrid}>
            <div>
              <h2 className="section-title">Oilfield Research & Compliance</h2>
              <p>
                Our research team blends geology, digital models, and regulatory insight to evaluate basins, optimize drilling plans, and ensure compliance with provincial and federal frameworks.
              </p>
              <ul className={styles.bulletList}>
                <li>Reservoir simulation and decline analysis</li>
                <li>Environmental baseline assessments</li>
                <li>Regulatory submissions and stakeholder engagement</li>
              </ul>
            </div>
            <img
              src="https://picsum.photos/800/600?random=305"
              alt="Oilfield researchers reviewing geological data in a modern lab"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section section--alt">
        <div className="container">
          <div className={styles.focusGridAlt}>
            <img
              src="https://picsum.photos/800/600?random=306"
              alt="Cranes and heavy-lift equipment installing industrial modules"
              loading="lazy"
            />
            <div>
              <h2 className="section-title">Engineering Solutions & Logistics</h2>
              <p>
                From crane mobilization to remote site logistics, Aurion orchestrates the mechanical, civil, and operational elements that bring industrial facilities online safely.
              </p>
              <ul className={styles.bulletList}>
                <li>Heavy lift planning and rigging design</li>
                <li>Construction management and commissioning</li>
                <li>Multi-modal logistics for challenging environments</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Sustainability Commitments</h2>
          <p className="section-subtitle">
            Our sustainability practice helps clients reduce emissions, embed cleaner technologies, and create measurable community benefits aligned with Canadian standards.
          </p>
          <div className={styles.sustainabilityGrid}>
            <div>
              <h3>Climate-Aligned Design</h3>
              <p>
                We integrate low-carbon alternatives, electrification strategies, and data-backed carbon accounting to support climate-aligned infrastructure decisions.
              </p>
            </div>
            <div>
              <h3>Indigenous Collaboration</h3>
              <p>
                Aurion prioritizes respectful partnerships, capacity building, and transparent engagement with Indigenous communities in every region we operate.
              </p>
            </div>
            <div>
              <h3>Operational Excellence</h3>
              <p>
                Continuous improvement plans, proactive maintenance, and safety-first culture ensure lasting performance while minimizing environmental impacts.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--alt">
        <div className="container">
          <h2 className="section-title">Featured Projects</h2>
          <div className={styles.projectsGrid}>
            {projects.map((project) => (
              <article key={project.name} className={styles.projectCard}>
                <img src={project.image} alt={project.alt} loading="lazy" />
                <div className={styles.projectContent}>
                  <h3>{project.name}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Client Perspectives</h2>
          <div className={styles.testimonialGrid}>
            {testimonials.map((testimonial) => (
              <blockquote key={testimonial.name} className={styles.testimonialCard}>
                <p>“{testimonial.quote}”</p>
                <footer>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} section section--alt`}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Partner with Aurion</h2>
            <p>
              Bring Canada’s leading energy consulting and engineering specialists onto your project. We are ready to align your objectives with actionable roadmaps and field-proven delivery.
            </p>
            <Link to="/contact" className="btn-primary">
              Connect with Our Team
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;