import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <>
      <Helmet>
        <title>Contact Aurion Energy Advisory | Toronto Energy Consulting</title>
        <meta
          name="description"
          content="Contact Aurion Energy Advisory in Toronto for energy consulting, oilfield research, and engineering services across Canada."
        />
        <meta
          name="keywords"
          content="energy consulting Canada, consulting firm, industrial engineering, energy infrastructure"
        />
      </Helmet>

      <section className="section section--alt">
        <div className="container">
          <div className={styles.header}>
            <h1>Contact</h1>
            <p>
              Let’s discuss how Aurion Energy Advisory can support your next initiative. Share your project goals and our team will respond promptly.
            </p>
          </div>

          <div className={styles.grid}>
            <div className={styles.details}>
              <h2>Office</h2>
              <p><strong>Address:</strong> 460 Bay St, Toronto, ON M5H 2Y4, Canada</p>
              <p><strong>Phone:</strong> <a href="tel:+14167924583">+1 (416) 792-4583</a></p>
              <p><strong>Email:</strong> <a href="mailto:info@aurionenergyadvisory.ca">info@aurionenergyadvisory.ca</a></p>
              <p><strong>LinkedIn:</strong> <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">Aurion Energy Advisory</a></p>
              <div className={styles.mapWrapper} aria-label="Aurion Energy Advisory location map">
                <iframe
                  title="Aurion Energy Advisory office map"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2887.09572798213!2d-79.38325012340676!3d43.65115895349561!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34c71d765c3b%3A0xa3ba93926ab9dd98!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"
                  width="100%"
                  height="280"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>

            <form className={styles.form} onSubmit={handleSubmit}>
              <h2>Send a Message</h2>
              <div className={styles.field}>
                <label htmlFor="name">Name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="organization">Organization</label>
                <input
                  id="organization"
                  name="organization"
                  type="text"
                  value={formData.organization}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  required
                />
              </div>
              <button type="submit" className="btn-primary">
                Submit
              </button>
              {submitted && (
                <p className={styles.confirmation} role="status">
                  Thank you. Your message has been sent. Our team will connect with you shortly.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;