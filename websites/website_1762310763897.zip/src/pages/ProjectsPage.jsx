import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ProjectsPage.module.css';

const ProjectsPage = () => {
  const projects = [
    {
      name: 'Coastal LNG Terminal Readiness',
      description:
        'Delivered commissioning support, crane services, and logistics coordination for a coastal LNG terminal in British Columbia.',
      image: 'https://picsum.photos/800/600?random=601',
      alt: 'LNG terminal with industrial cranes and ships at dock',
    },
    {
      name: 'Northern Pipeline Reliability Study',
      description:
        'Conducted integrity review and mitigation planning for a 2,000 km pipeline network operating in remote Canadian terrain.',
      image: 'https://picsum.photos/800/600?random=602',
      alt: 'Pipeline infrastructure running through northern landscapes',
    },
    {
      name: 'Hydrogen Integration Pilot',
      description:
        'Evaluated hydrogen blending, safety protocols, and operational readiness for a pilot facility connected to existing gas infrastructure.',
      image: 'https://picsum.photos/800/600?random=603',
      alt: 'Hydrogen facility with engineers monitoring equipment',
    },
    {
      name: 'Offshore Wind Interconnection',
      description:
        'Provided interconnection design, environmental assessments, and grid integration planning for an offshore wind array.',
      image: 'https://picsum.photos/800/600?random=604',
      alt: 'Offshore wind turbines with transmission infrastructure',
    },
    {
      name: 'Saskatchewan Enhanced Recovery',
      description:
        'Implemented reservoir modeling and production optimization strategies that improved recovery factors while maintaining compliance.',
      image: 'https://picsum.photos/800/600?random=605',
      alt: 'Oilfield site with enhanced recovery equipment',
    },
    {
      name: 'Remote Mining Power Hub',
      description:
        'Designed hybrid power solutions and delivered heavy-lift operations for a remote mining client transitioning to cleaner energy.',
      image: 'https://picsum.photos/800/600?random=606',
      alt: 'Industrial power hub supporting a remote mining operation',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Projects | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Explore Aurion Energy Advisory projects across LNG terminals, pipelines, hydrogen integration, offshore wind, and remote power solutions in Canada."
        />
        <meta
          name="keywords"
          content="industrial engineering, energy infrastructure, oil and gas Canada, sustainable engineering, industrial projects"
        />
      </Helmet>

      <section className="section section--alt">
        <div className="container">
          <div className={styles.header}>
            <h1>Projects & Impact</h1>
            <p>
              Aurion partners with clients to deliver engineering certainty across the energy value chain. Our portfolio spans from remote installations to large-scale infrastructure programs.
            </p>
          </div>
          <div className={styles.grid}>
            {projects.map((project) => (
              <article key={project.name} className={styles.card}>
                <img src={project.image} alt={project.alt} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{project.name}</h2>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default ProjectsPage;