import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PrivacyPage.module.css';

const PrivacyPage = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Aurion Energy Advisory</title>
      <meta
        name="description"
        content="Learn how Aurion Energy Advisory collects, uses, and protects your personal information."
      />
      <meta
        name="keywords"
        content="privacy policy, consulting firm, energy consulting Canada"
      />
    </Helmet>

    <section className="section section--alt">
      <div className="container">
        <div className={styles.wrapper}>
          <h1>Privacy Policy</h1>
          <p>Last updated: January 2024</p>
          <h2>Information We Collect</h2>
          <p>
            We collect information that you provide voluntarily, such as contact details submitted through forms. We may also gather analytical data about site usage to improve our services.
          </p>
          <h2>How We Use Information</h2>
          <p>
            Aurion Energy Advisory uses collected information to respond to inquiries, deliver services, and enhance user experience. We do not sell or trade personal information.
          </p>
          <h2>Data Security</h2>
          <p>
            We apply administrative, technical, and physical safeguards to protect personal information against unauthorized access, disclosure, or misuse.
          </p>
          <h2>Cookies</h2>
          <p>
            This site uses cookies to improve functionality and understand user interactions. You can manage cookie preferences through your browser settings.
          </p>
          <h2>Third-Party Services</h2>
          <p>
            We may engage third-party service providers for analytics or communications. These providers are obligated to protect your information in accordance with applicable laws.
          </p>
          <h2>Your Rights</h2>
          <p>
            You may request access to, correction of, or deletion of your personal information by contacting us at <a href="mailto:info@aurionenergyadvisory.ca">info@aurionenergyadvisory.ca</a>.
          </p>
          <h2>Contact</h2>
          <p>
            Questions or concerns about this Privacy Policy can be directed to our Toronto office or via email.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default PrivacyPage;