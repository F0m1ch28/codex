import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ServicesPage.module.css';

const ServicesPage = () => {
  const services = [
    {
      title: 'Energy Consulting',
      description:
        'Market analysis, regulatory strategy, and asset optimization tailored to Canadian energy frameworks and evolving policy landscapes.',
      image: 'https://picsum.photos/600/400?random=501',
      alt: 'Consultants analyzing energy data in a modern office',
    },
    {
      title: 'Oilfield Research',
      description:
        'Reservoir studies, seismic interpretation, and compliance readiness to support exploration and development decisions.',
      image: 'https://picsum.photos/600/400?random=502',
      alt: 'Research team studying geological samples for oilfield analysis',
    },
    {
      title: 'Installation & Commissioning',
      description:
        'Heavy-lift planning, crane operations, and commissioning management for industrial facilities and energy infrastructure.',
      image: 'https://picsum.photos/600/400?random=503',
      alt: 'Cranes installing modules at an energy construction site',
    },
    {
      title: 'Environmental Assessment',
      description:
        'Environmental impact assessments, baseline studies, and mitigation strategies aligned with provincial and federal regulations.',
      image: 'https://picsum.photos/600/400?random=504',
      alt: 'Environmental engineers conducting an assessment outdoors',
    },
    {
      title: 'Project Management',
      description:
        'Integrated project controls, risk management, and contractor coordination ensuring timely, safe delivery of complex projects.',
      image: 'https://picsum.photos/600/400?random=505',
      alt: 'Project managers collaborating over industrial project plans',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Services | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Discover Aurion Energy Advisory services including energy consulting, oilfield research, installation, environmental assessment, and project management."
        />
        <meta
          name="keywords"
          content="energy consulting Canada, oilfield research, industrial engineering, crane installation, energy infrastructure, sustainable engineering"
        />
      </Helmet>

      <section className="section section--alt">
        <div className="container">
          <div className={styles.header}>
            <h1>Services</h1>
            <p>
              Aurion Energy Advisory delivers integrated services that connect strategic insight with technical execution. Our teams apply cross-disciplinary expertise to ensure your project is informed, compliant, and engineered to perform.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <img src={service.image} alt={service.alt} loading="lazy" />
                <div className={styles.serviceContent}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.process}>
            <h2 className="section-title">Our Delivery Framework</h2>
            <p className="section-subtitle">
              We align stakeholders, data, and field execution using a structured framework that adapts to the pace of modern energy projects.
            </p>
            <div className={styles.processSteps}>
              <div>
                <h3>1. Diagnose</h3>
                <p>Clarify opportunities with market assessments, asset reviews, and stakeholder priorities.</p>
              </div>
              <div>
                <h3>2. Design</h3>
                <p>Develop strategic roadmaps, engineering plans, and compliance pathways grounded in data.</p>
              </div>
              <div>
                <h3>3. Deliver</h3>
                <p>Coordinate technical teams, logistics, and contractors to execute efficiently and safely.</p>
              </div>
              <div>
                <h3>4. Optimize</h3>
                <p>Monitor performance, embed continuous improvement, and enable long-term resilience.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;