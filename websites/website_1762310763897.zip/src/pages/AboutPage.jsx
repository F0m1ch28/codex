import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  const leadership = [
    {
      name: 'Elena Park, P.Eng.',
      role: 'Founder & Principal Consultant',
      bio: 'Elena brings twenty years of upstream and midstream experience, leading integrated teams across Canada and the North Sea.',
      image: 'https://picsum.photos/400/400?random=401',
      alt: 'Portrait of Elena Park leading energy consulting projects',
    },
    {
      name: 'Marco Silva, MBA',
      role: 'Director, Strategic Advisory',
      bio: 'Marco guides regulatory strategy, stakeholder engagement, and energy transition planning for public and private clients.',
      image: 'https://picsum.photos/400/400?random=402',
      alt: 'Portrait of Marco Silva specializing in strategic advisory',
    },
    {
      name: 'Sophie Tremblay, PMP',
      role: 'Director, Project Delivery',
      bio: 'Sophie oversees complex project programs, ensuring safe execution and seamless coordination for installations nationwide.',
      image: 'https://picsum.photos/400/400?random=403',
      alt: 'Portrait of Sophie Tremblay overseeing project delivery',
    },
  ];

  return (
    <>
      <Helmet>
        <title>About Aurion Energy Advisory | History, Leadership, Mission</title>
        <meta
          name="description"
          content="Learn about Aurion Energy Advisory’s history, leadership team, mission, safety culture, and sustainability commitments in Canada."
        />
        <meta
          name="keywords"
          content="energy consulting Canada, consulting firm, sustainable engineering, industrial projects"
        />
      </Helmet>
      <section className="section section--alt">
        <div className="container">
          <div className={styles.hero}>
            <h1>Our Story</h1>
            <p>
              Aurion Energy Advisory was founded in Toronto with a vision to deliver independent guidance and hands-on engineering support for Canada’s evolving energy landscape. From shale development to offshore operations and renewable integration, we work side-by-side with clients to transform complexity into clarity.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.historyGrid}>
            <div>
              <h2 className="section-title">History & Growth</h2>
              <p>
                Our roots trace back to specialized consulting on oilfield development in Western Canada. Over time, we expanded into infrastructure planning, heavy-lift engineering, and sustainability strategy. Today, Aurion supports national and international projects with multidisciplinary teams and trusted partner networks.
              </p>
            </div>
            <img
              src="https://picsum.photos/800/600?random=404"
              alt="Historical timeline of energy engineering projects in Canada"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section section--alt">
        <div className="container">
          <h2 className="section-title">Leadership</h2>
          <div className={styles.leadershipGrid}>
            {leadership.map((leader) => (
              <article key={leader.name} className={styles.leaderCard}>
                <img src={leader.image} alt={leader.alt} loading="lazy" />
                <div>
                  <h3>{leader.name}</h3>
                  <p className={styles.role}>{leader.role}</p>
                  <p>{leader.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2 className="section-title">Mission</h2>
              <p>
                We empower energy decision makers with clear insight, resilient project delivery, and a relentless focus on operational excellence. Our mission is to guide the energy sector toward a balanced, sustainable future based on trusted data and collaborative engineering.
              </p>
            </div>
            <div>
              <h2 className="section-title">Values</h2>
              <ul className={styles.valuesList}>
                <li><strong>Integrity:</strong> Objective assessments and transparent communication at every step.</li>
                <li><strong>Safety:</strong> Field-proven procedures and proactive risk management as a foundation.</li>
                <li><strong>Innovation:</strong> Embracing digital tools, analytics, and creative problem solving.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--alt">
        <div className="container">
          <div className={styles.safetyGrid}>
            <div>
              <h2 className="section-title">Safety & Assurance</h2>
              <p>
                Aurion’s safety culture is embedded into our processes, training, and field execution. We maintain up-to-date certifications, align with provincial regulations, and cultivate a mindset where every team member is responsible for protecting people, assets, and the environment.
              </p>
            </div>
            <img
              src="https://picsum.photos/800/600?random=405"
              alt="Safety briefing conducted at an energy project site"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.sustainability}>
            <h2 className="section-title">Sustainability</h2>
            <p>
              Sustainability for Aurion is about practicality, resilience, and measurable performance. Our teams align project design with carbon reduction goals, support Indigenous partnerships, and deliver environmental stewardship across the entire asset life cycle.
            </p>
            <ul className={styles.valuesList}>
              <li>Lifecycle emissions modeling and mitigation plans</li>
              <li>Community engagement and benefit-sharing frameworks</li>
              <li>Adaptive reuse and technology upgrades for existing assets</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;