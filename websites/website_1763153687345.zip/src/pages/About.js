import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>О студии ArtVista — команда, подход и ценности</title>
      <meta
        name="description"
        content="Узнайте о команде ArtVista: арт-директора, дизайнеры, иллюстраторы и продюсеры. Мы сочетает творческую смелость и стратегию."
      />
      <meta
        name="keywords"
        content="творческая студия, команда дизайнеров, художественная студия, визуальное искусство"
      />
    </Helmet>
    <section className={`${styles.hero} container`}>
      <div className={styles.heroText}>
        <p className={styles.tag}>О нас</p>
        <h1>ArtVista — сообщество художников и стратегов визуальной культуры.</h1>
        <p>
          Мы строим дизайн через призму искусства и исследовательского подхода. Каждая идея проходит
          путь от первой зарисовки до детализированного решения, которое работает в реальном мире и
          вызывает эмоции.
        </p>
      </div>
      <div className={styles.heroImage}>
        <img src="https://picsum.photos/id/1074/640/600" alt="Команда ArtVista за рабочим процессом" />
      </div>
    </section>

    <section className={`${styles.values} container`}>
      <div className={styles.sectionHeader}>
        <h2>Что нас вдохновляет и направляет</h2>
        <p>
          Мы видим проект как совместное путешествие: от исследования до запуска. Центр внимания —
          человеческий опыт, который мы усиливаем визуальными инструментами.
        </p>
      </div>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Культура эксперимента</h3>
          <p>
            Проводим творческие спринты, тестируем формы, материалы и технологии, чтобы находить
            уникальные решения.
          </p>
        </article>
        <article>
          <h3>Этика и устойчивость</h3>
          <p>
            Заботимся о долгосрочном влиянии наших проектов, подбираем экологичные материалы и
            поддерживаем локальные инициативы.
          </p>
        </article>
        <article>
          <h3>Коммуникация и прозрачность</h3>
          <p>
            Строим открытый диалог с клиентами, проводим воркшопы и совместно формируем визуальные
            стратегии.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2>Команда ArtVista</h2>
          <p>
            Наши специалисты — выпускники профильных школ искусства и дизайна, обладатели премий и
            опытные кураторы выставок.
          </p>
        </div>
        <div className={styles.teamGrid}>
          <article>
            <img src="https://picsum.photos/id/1005/400/420" alt="Арт-директор ArtVista" />
            <h3>Алексей Миронов</h3>
            <p>Арт-директор и сооснователь. Курирует визуальную стратегию и арт-проекты.</p>
          </article>
          <article>
            <img src="https://picsum.photos/id/1012/400/420" alt="Креативный продюсер ArtVista" />
            <h3>Ирина Соколова</h3>
            <p>Креативный продюсер, отвечает за кураторство и взаимодействие с художниками.</p>
          </article>
          <article>
            <img src="https://picsum.photos/id/1018/400/420" alt="Lead-дизайнер ArtVista" />
            <h3>Мария Лебедева</h3>
            <p>Lead-дизайнер, специализируется на айдентике и цифровых продуктах.</p>
          </article>
          <article>
            <img src="https://picsum.photos/id/1027/400/420" alt="Руководитель исследований" />
            <h3>Дмитрий Корнеев</h3>
            <p>Руководит исследовательской лабораторией и user experience направлением.</p>
          </article>
        </div>
      </div>
    </section>

    <section className={`${styles.timeline} container`}>
      <div className={styles.sectionHeader}>
        <h2>Путь студии</h2>
      </div>
      <ol className={styles.timelineList}>
        <li>
          <span>2014</span>
          <p>Основание студии и запуск первых арт-коллабораций с галереями.</p>
        </li>
        <li>
          <span>2017</span>
          <p>Создание собственной арт-резиденции и участие в европейских фестивалях.</p>
        </li>
        <li>
          <span>2020</span>
          <p>Запуск цифрового направления: VR-инсталляции, интерактивный дизайн и AR-кампании.</p>
        </li>
        <li>
          <span>2023</span>
          <p>Расширение команды и открытие эксперимента с генеративным искусством.</p>
        </li>
      </ol>
    </section>
  </>
);

export default About;