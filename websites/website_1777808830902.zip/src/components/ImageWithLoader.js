import React, { useState } from 'react';
import styles from './ImageWithLoader.module.css';

const ImageWithLoader = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`${styles.wrapper} ${className || ''}`}>
      {!loaded && <div className={styles.placeholder} aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        className={`${styles.image} ${loaded ? styles.visible : ''}`}
        onLoad={() => setLoaded(true)}
      />
    </div>
  );
};

export default ImageWithLoader;