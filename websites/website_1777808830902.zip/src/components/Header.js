import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const navItems = [
  { to: '/', label: createText('Home', 'Главная') },
  { to: '/reviews', label: createText('Reviews', 'Обзоры') },
  { to: '/comparison', label: createText('Comparison', 'Сравнение') },
  { to: '/services', label: createText('Services', 'Услуги') },
  { to: '/about', label: createText('About', 'О нас') },
  { to: '/contact', label: createText('Contact', 'Контакты') }
];

const Header = () => {
  const { language, toggleLanguage } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoAccent}>GR</span>
          <span className={styles.logoText}>{getText(createText('Gambling Reviews', 'Gambling Reviews'), language)}</span>
        </NavLink>

        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Primary">
          <ul>
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                  onClick={closeMenu}
                  end={item.to === '/'}
                >
                  {getText(item.label, language)}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className={styles.actions}>
          <button
            type="button"
            onClick={toggleLanguage}
            className={styles.languageToggle}
            aria-label={getText(createText('Toggle language', 'Сменить язык'), language)}
          >
            {language === 'en' ? 'RU' : 'EN'}
          </button>
          <button
            type="button"
            className={`${styles.menuButton} ${menuOpen ? styles.open : ''}`}
            onClick={handleToggleMenu}
            aria-label={menuOpen ? 'Close navigation' : 'Open navigation'}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;