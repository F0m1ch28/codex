import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const CookieBanner = () => {
  const { language } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const preference = localStorage.getItem('gr-cookie-preference');
    if (!preference) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem('gr-cookie-preference', choice);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive">
      <div className={styles.content}>
        <p>
          {getText(
            createText(
              'We use cookies for analytics to improve your experience. You can decline non-essential cookies.',
              'Мы используем cookies для аналитики и улучшения сервиса. Вы можете отказаться от необязательных cookies.'
            ),
            language
          )}
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.decline}
            onClick={() => handleChoice('declined')}
          >
            {getText(createText('Decline', 'Отклонить'), language)}
          </button>
          <button
            type="button"
            className={styles.accept}
            onClick={() => handleChoice('accepted')}
          >
            {getText(createText('Accept', 'Принять'), language)}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;