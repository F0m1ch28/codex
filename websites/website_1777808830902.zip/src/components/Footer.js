import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const quickLinks = [
  { to: '/', label: createText('Home', 'Главная') },
  { to: '/reviews', label: createText('Reviews', 'Обзоры') },
  { to: '/comparison', label: createText('Comparison', 'Сравнение') },
  { to: '/services', label: createText('Services', 'Услуги') },
  { to: '/about', label: createText('About', 'О нас') },
  { to: '/contact', label: createText('Contact', 'Контакты') }
];

const policyLinks = [
  { to: '/terms', label: createText('Terms of Service', 'Условия использования') },
  { to: '/privacy', label: createText('Privacy Policy', 'Политика конфиденциальности') },
  { to: '/cookies', label: createText('Cookie Policy', 'Политика использования cookies') }
];

const Footer = () => {
  const { language } = useLanguage();

  return (
    <footer className={styles.footer}>
      <div className={styles.grid}>
        <div className={styles.brand}>
          <div className={styles.brandName}>Gambling Reviews</div>
          <p>
            {getText(
              createText(
                'Independent gambling product reviews, comparisons, and responsible play guidance. We never facilitate real-money wagering.',
                'Независимые обзоры азартных продуктов, сравнение и рекомендации по ответственному поведению. Мы не предоставляем доступ к реальным ставкам.'
              ),
              language
            )}
          </p>
          <p className={styles.disclaimer}>
            {getText(
              createText(
                'All insights are informational. Always follow local regulations and gamble responsibly.',
                'Вся информация носит справочный характер. Соблюдайте местные законы и играйте ответственно.'
              ),
              language
            )}
          </p>
        </div>

        <div className={styles.column}>
          <h4>{getText(createText('Quick Links', 'Навигация'), language)}</h4>
          <ul>
            {quickLinks.map((link) => (
              <li key={link.to}>
                <Link to={link.to}>{getText(link.label, language)}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div className={styles.column}>
          <h4>{getText(createText('Policies', 'Политика'), language)}</h4>
          <ul>
            {policyLinks.map((link) => (
              <li key={link.to}>
                <Link to={link.to}>{getText(link.label, language)}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div className={styles.column}>
          <h4>{getText(createText('Contact', 'Контакты'), language)}</h4>
          <ul className={styles.contactList}>
            <li>123 Gaming Street, Suite 100, London, UK</li>
            <li><a href="tel:+442071234567">+44 20 7123 4567</a></li>
            <li><a href="mailto:info@gamblingreview.com">info@gamblingreview.com</a></li>
          </ul>
        </div>
      </div>

      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Gambling Reviews. All rights reserved.</span>
        <span>{getText(createText('Empowering responsible gaming decisions worldwide.', 'Ответственные игровые решения по всему миру.'), language)}</span>
      </div>
    </footer>
  );
};

export default Footer;