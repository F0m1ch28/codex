import { createText } from '../utils/i18n';

const reviews = [
  {
    id: 1,
    name: 'Aurora Royale Casino',
    slug: 'aurora-royale-casino',
    tagline: createText(
      'Boutique slot lounge with curated missions and agile safeguards.',
      'Бутик-казино со слотами, миссиями и гибкими мерами защиты.'
    ),
    summary: createText(
      'Aurora Royale Casino focuses on highly curated slot drops, daily missions, and informed wagering dashboards — ideal for volatility hunters needing clarity.',
      'Aurora Royale Casino делает ставку на тщательно подобранные слоты, ежедневные миссии и прозрачные дашборды ставок — отличный выбор для любителей волатильности.'
    ),
    description: createText(
      'The platform blends cinematic design with granular control over game volatility and budget reminders. Independent RNG certificates and an affordability hub make it a premium choice for players wanting flexibility without sacrificing safeguards.',
      'Платформа сочетает кинематографичный дизайн с детальным контролем волатильности и напоминаниями о бюджете. Независимые сертификаты RNG и центр финансовой доступности делают её премиальной для игроков, ценящих защиту.'
    ),
    rating: 4.6,
    category: 'Slots',
    logo: 'https://via.placeholder.com/96x96.png?text=AR',
    banner: 'https://picsum.photos/1200/600?random=410',
    bonus: {
      title: createText('Welcome Adventure Bundle', 'Приветственный набор приключений'),
      details: createText(
        'Personalised missions unlock staged free spin batches and loyalty tokens tracked in real time. No direct cash promos, only progression-based rewards.',
        'Персональные миссии открывают пакеты фриспинов и токены лояльности в реальном времени. Никаких прямых денежных бонусов — только награды за прогресс.'
      ),
      terms: createText(
        'Mission wagering meters refresh nightly with built-in cool-off prompts.',
        'Счётчики отыгрыша обновляются каждую ночь и сопровождаются напоминаниями о перерыве.'
      )
    },
    pros: [
      createText('2,300+ slot titles with volatility and hit rate filters.', 'Более 2 300 слотов с фильтрами волатильности и частоты выигрышей.'),
      createText('Transparent mission dashboards with loss-limit alerting.', 'Прозрачные дашборды миссий с напоминаниями об ограничении потерь.'),
      createText('In-depth affordability assessments before high-stake play.', 'Глубокая проверка финансовых возможностей перед высокими ставками.')
    ],
    cons: [
      createText('Limited live casino catalog.', 'Ограниченный выбор live-игр.'),
      createText('No cryptocurrency payment methods.', 'Отсутствуют криптоплатежи.')
    ],
    features: [
      {
        title: createText('Security & Licensing', 'Безопасность и лицензии'),
        detail: createText('Licensed in Malta and Curaçao with quarterly security penetration tests.', 'Лицензии на Мальте и Кюрасао, ежеквартальное тестирование безопасности.')
      },
      {
        title: createText('Game Portfolio', 'Игровой портфель'),
        detail: createText('2,300+ games with volatility, RTP, and hit rate filters accessible via a smart search grid.', 'Более 2 300 игр с фильтрами волатильности, RTP и частоты выигрышей через интеллектуальный поиск.')
      },
      {
        title: createText('Responsible Play', 'Ответственная игра'),
        detail: createText('Mandatory session reminders and affordability reviews for higher-tier missions.', 'Обязательные напоминания о сессии и финансовая проверка для высокоуровневых миссий.')
      }
    ],
    comparison: {
      security: createText('SSL 256-bit encryption with quarterly third-party penetration audits.', 'Шифрование SSL 256 бит и ежеквартальные внешние тесты на проникновение.'),
      payoutSpeed: createText('Average withdrawal approval within 24 hours after verification.', 'Среднее одобрение вывода — 24 часа после верификации.'),
      support: createText('24/7 live chat with escalation path to RG duty managers.', 'Круглосуточный чат с возможностью эскалации ответственным менеджерам.'),
      mobileExperience: createText('Progressive web app, biometric login, mission widgets.', 'PWA, биометрический вход, виджеты миссий.'),
      responsiblePlay: createText('Dynamic cooling-off recommendations enforced through UI prompts.', 'Динамические рекомендации по перерывам через интерфейсные подсказки.'),
      licensing: createText('MGA + Curaçao eGaming.', 'MGA + Curaçao eGaming.'),
      withdrawalTransparency: createText('Real-time withdrawal tracker with fee disclosure.', 'Трекер вывода в реальном времени с указанием комиссий.'),
      innovation: createText('Volatility lab visualising risk vs reward heatmaps.', 'Лаборатория волатильности с тепловыми картами риска и награды.')
    },
    faqs: [
      {
        question: createText('How often are missions refreshed?', 'Как часто обновляются миссии?'),
        answer: createText('Daily at 04:00 UTC with five tiers aligned to player activity and responsible limits.', 'Ежедневно в 04:00 UTC, пять уровней зависят от активности и установленных лимитов.')
      },
      {
        question: createText('Is there an affordability assessment?', 'Есть ли проверка платежеспособности?'),
        answer: createText('Yes, triggered automatically when mission stakes exceed personalised safe thresholds.', 'Да, автоматически включается при превышении персональных безопасных порогов.')
      }
    ],
    tags: ['Slots', 'Missions', 'Responsible Play'],
    relatedSlugs: ['meridian-vault-gaming', 'zenith-play-hub'],
    certifications: ['ISO 27001', 'GamCare Associate'],
    lastUpdated: createText('Updated March 2024', 'Обновлено в марте 2024')
  },
  {
    id: 2,
    name: 'Meridian Vault Gaming',
    slug: 'meridian-vault-gaming',
    tagline: createText(
      'Live casino powerhouse with multilingual dealers and advanced AML protocols.',
      'Лидер live-игр с многоязычными дилерами и продвинутым AML.'
    ),
    summary: createText(
      'Meridian Vault Gaming specialises in live tables sourced from European studios, combining premium production with affordability monitoring and multi-lingual support.',
      'Meridian Vault Gaming специализируется на live-играх из европейских студий, сочетая премиальную трансляцию с финансовым мониторингом и поддержкой на разных языках.'
    ),
    description: createText(
      'From baccarat to localized game shows, Meridian Vault offers immersive streams with delay monitoring dashboards and responsible play overlays. The operator shines for CIS audiences thanks to dedicated Russian-speaking hosts and compliance workflows.',
      'От баккары до локализованных шоу — Meridian Vault предоставляет погружение с контролем задержек и подсказками ответственной игры. Платформа особенно актуальна для СНГ благодаря русскоязычным дилерам и продуманным комплаенс-процессам.'
    ),
    rating: 4.7,
    category: 'Live Casino',
    logo: 'https://via.placeholder.com/96x96.png?text=MV',
    banner: 'https://picsum.photos/1200/600?random=411',
    bonus: {
      title: createText('Live Lounge Loyalty Path', 'Программа лояльности Live Lounge'),
      details: createText(
        'Accumulate trust points from verified sessions to unlock studio tours, strategy webinars, and loss-limit coaching.',
        'Накапливайте trust-поинты за верифицированные сессии и получайте туры по студиям, вебинары и коучинг по лимитам.'
      ),
      terms: createText(
        'Loyalty tier reviews happen monthly with compliance oversight.',
        'Пересмотр уровней лояльности проводится ежемесячно под контролем комплаенса.'
      )
    },
    pros: [
      createText('30+ live tables with Russian, English, Kazakh dealers.', 'Более 30 live-столов с дилерами на русском, английском и казахском.'),
      createText('Real-time stream diagnostics with latency compensation.', 'Диагностика потока в реальном времени и компенсация задержек.'),
      createText('Dedicated affordability advocates available by appointment.', 'Выделенные консультанты по финансовой доступности по предварительной записи.')
    ],
    cons: [
      createText('Slots and RNG table coverage limited compared to competitors.', 'Слот и RNG-покрытие ограничено по сравнению с конкурентами.'),
      createText('Tier upgrades require manual compliance review.', 'Повышение уровня требует ручного комплаенс-рассмотрения.')
    ],
    features: [
      {
        title: createText('Live Studio Quality', 'Качество live-студий'),
        detail: createText('HD and 4K streams with predictive bandwidth adjustment.', 'HD и 4K потоки с предиктивной подстройкой пропускной способности.')
      },
      {
        title: createText('Dealer Expertise', 'Профессионализм дилеров'),
        detail: createText('Croupiers certified in responsible gaming messaging.', 'Крупье сертифицированы по ответственному взаимодействию.')
      },
      {
        title: createText('AML Procedures', 'AML-процедуры'),
        detail: createText('Risk scoring engine cross-references player behaviour with geo-risk alerts.', 'Встроенный скоринг сопоставляет поведение игроков с георисковыми сигналами.')
      }
    ],
    comparison: {
      security: createText('Enterprise-grade encryption with SOC 2 audits.', 'Корпоративное шифрование, аудит по SOC 2.'),
      payoutSpeed: createText('Manual review for withdrawals, typically within 36 hours.', 'Ручная проверка выводов, обычно до 36 часов.'),
      support: createText('Live support in EN/RU/KZ with RG escalation hotline.', 'Поддержка на EN/RU/KZ с горячей линией ответственной игры.'),
      mobileExperience: createText('Native iOS/Android apps with portrait mode tables.', 'Нативные приложения iOS/Android с портретным режимом.'),
      responsiblePlay: createText('Live dealer reminders embedded into chat overlays.', 'Напоминания дилеров встроены в чаты.'),
      licensing: createText('Isle of Man Gambling Supervision Commission.', 'Комиссия по надзору за азартными играми острова Мэн.'),
      withdrawalTransparency: createText('Manual reviewers provide feedback on every delayed request.', 'При задержке вывода даётся персональное объяснение.'),
      innovation: createText('Latency tuning tool for players with variable bandwidth.', 'Инструмент настройки задержки для нестабильного соединения.')
    },
    faqs: [
      {
        question: createText('Are dealers fluent in Russian?', 'Говорят ли дилеры по-русски?'),
        answer: createText('Yes, dedicated Russian-speaking tables operate daily with alternating shifts.', 'Да, ежедневно работают столы с русскоязычными дилерами.')
      },
      {
        question: createText('Do they track live session duration?', 'Отслеживается ли длительность live-сессий?'),
        answer: createText('Yes, overlays notify players every 45 minutes with suggested breaks.', 'Да, подсказки каждые 45 минут рекомендуют перерывы.')
      }
    ],
    tags: ['Live Dealer', 'Compliance', 'CIS'],
    relatedSlugs: ['aurora-royale-casino', 'halcyon-gaming-lounge'],
    certifications: ['eCOGRA', 'GamStop Partner'],
    lastUpdated: createText('Updated March 2024', 'Обновлено в марте 2024')
  },
  {
    id: 3,
    name: 'Zenith Play Hub',
    slug: 'zenith-play-hub',
    tagline: createText(
      'Mobile-first casino hub with adaptive UI and instant limit controls.',
      'Мобильный хаб казино с адаптивным UI и мгновенными лимитами.'
    ),
    summary: createText(
      'Zenith Play Hub delivers seamless mobile experiences for slots, instant games, and casual titles. Adaptive layouts, biometric login, and session budgeting tools make it stand out.',
      'Zenith Play Hub обеспечивает плавный мобильный опыт для слотов и казуальных игр. Адаптивные интерфейсы, биометрический вход и бюджетирование сессий выделяют платформу.'
    ),
    description: createText(
      'The platform prioritises mobile UX with gesture-based navigation and Day/Night themes for reduced strain. Responsible gaming is front-loaded via budget presets and instant limit toggles. Ideal for players prioritising mobility.',
      'Платформа ставит мобильный UX на первое место: жесты для навигации, дневные/ночные темы для снижения нагрузки на глаза. Инструменты ответственной игры доступны сразу — пресеты бюджета и моментальные лимиты.'
    ),
    rating: 4.5,
    category: 'Mobile',
    logo: 'https://via.placeholder.com/96x96.png?text=ZP',
    banner: 'https://picsum.photos/1200/600?random=412',
    bonus: {
      title: createText('Momentum Missions', 'Миссии Momentum'),
      details: createText(
        'Weekly mobile missions reward consistent budgeting behaviour with cosmetic themes and non-monetary perks.',
        'Еженедельные мобильные миссии поощряют соблюдение бюджета косметическими темами и немонетарными бонусами.'
      ),
      terms: createText(
        'Budget adherence is required to unlock mission progression.',
        'Для прогресса нужно придерживаться установленного бюджета.'
      )
    },
    pros: [
      createText('Adaptive layouts for more than 50 screen sizes.', 'Адаптивная верстка для более 50 размеров экранов.'),
      createText('Instant limit adjustments accessible from any screen.', 'Мгновенное изменение лимитов с любого экрана.'),
      createText('Offline sandbox demos for learning new games.', 'Офлайн-демо для ознакомления с играми.')
    ],
    cons: [
      createText('Desktop experience is simplified compared to mobile.', 'Десктоп-версия менее функциональна.'),
      createText('Limited live dealer catalogue.', 'Небольшой выбор live-игр.')
    ],
    features: [
      {
        title: createText('Mobile UX', 'Мобильный UX'),
        detail: createText('Adaptive gestures, theming, and battery-friendly rendering.', 'Адаптивные жесты, темы и энергосберегающее отображение.')
      },
      {
        title: createText('Limit Controls', 'Контроль лимитов'),
        detail: createText('Preset budgets, on-the-fly exclusion, and cooling-off automation.', 'Готовые бюджеты, мгновенное исключение и автоматические перерывы.')
      },
      {
        title: createText('Game Catalogue', 'Каталог игр'),
        detail: createText('Slots, crash games, and casual titles curated for mobile play.', 'Слоты, crash-игры и казуальные тайтлы, адаптированные под мобильную игру.')
      }
    ],
    comparison: {
      security: createText('Device-specific encryption keys with biometric fallback.', 'Шифрование с учётом устройства и биометрического входа.'),
      payoutSpeed: createText('E-wallet payouts within 12-18 hours after ID verification.', 'Выплаты на e-wallet в течение 12-18 часов после ID-проверки.'),
      support: createText('In-app chat with callback scheduling.', 'Чат в приложении с возможностью заказа звонка.'),
      mobileExperience: createText('Best-in-class; gesture controls and offline sandbox.', 'Лидер по мобильному UX: жесты и офлайн-режим.'),
      responsiblePlay: createText('Budget adherence rewarded with cosmetic upgrades.', 'Соблюдение бюджета поощряется косметическими апгрейдами.'),
      licensing: createText('Alderney Gambling Control Commission.', 'Комиссия по азартным играм Олдерни.'),
      innovation: createText('Day/Night mode linked to circadian rhythm reminders.', 'Дневной/ночной режим синхронизирован с циркадными напоминаниями.')
    },
    faqs: [
      {
        question: createText('Can I set limits instantly?', 'Можно ли мгновенно установить лимиты?'),
        answer: createText('Yes, limit toggles appear on every screen including during gameplay.', 'Да, переключатели лимитов есть на каждом экране вплоть до игрового процесса.')
      },
      {
        question: createText('Is there a desktop version?', 'Есть ли десктоп-версия?'),
        answer: createText('A simplified desktop lobby exists but lacks full mission functionality.', 'Есть упрощённая десктоп-версия без полного функционала миссий.')
      }
    ],
    tags: ['Mobile', 'Responsible Play', 'UX'],
    relatedSlugs: ['aurora-royale-casino', 'halcyon-gaming-lounge'],
    certifications: ['GamCare Associate'],
    lastUpdated: createText('Updated February 2024', 'Обновлено в феврале 2024')
  },
  {
    id: 4,
    name: 'Halcyon Gaming Lounge',
    slug: 'halcyon-gaming-lounge',
    tagline: createText(
      'Strategy-forward platform with collaborative bankroll tools.',
      'Платформа с упором на стратегию и совместное управление банкроллом.'
    ),
    summary: createText(
      'Halcyon Gaming Lounge combines strategy resources, co-op bankroll dashboards, and tournament-style leaderboards to help friends play responsibly together.',
      'Halcyon Gaming Lounge объединяет стратегии, совместные дашборды банкролла и лидерборды турниров, помогая друзьям играть ответственно.'
    ),
    description: createText(
      'Ideal for communities, Halcyon provides shared notes, limit agreements, and analyst webinars. It de-emphasises high stakes, focusing instead on social play with safety nets.',
      'Идеально для команд: общие заметки, соглашения по лимитам и вебинары аналитиков. Платформа снижает значимость высоких ставок и концентрируется на социальном взаимодействии с защитными механизмами.'
    ),
    rating: 4.4,
    category: 'Strategy',
    logo: 'https://via.placeholder.com/96x96.png?text=HG',
    banner: 'https://picsum.photos/1200/600?random=413',
    bonus: {
      title: createText('Collaborative Bankroll Perks', 'Преимущества совместного банкролла'),
      details: createText(
        'Teams earn coaching sessions and strategy breakdowns by maintaining shared limits and healthy play ratios.',
        'Команды получают коучинг и анализ стратегий за соблюдение общих лимитов и здоровых пропорций игры.'
      ),
      terms: createText(
        'Requires consent from all team members and adherence to responsible play checkpoints.',
        'Требуется согласие всех участников и соблюдение контрольных точек ответственной игры.'
      )
    },
    pros: [
      createText('Shared bankroll dashboards with permission layers.', 'Совместные дашборды банкролла с настройкой прав.'),
      createText('Weekly analyst webinars on strategy and safeguarding.', 'Еженедельные вебинары аналитиков по стратегии и защите.'),
      createText('Transparent leaderboards with no monetary prizes.', 'Прозрачные лидерборды без денежных призов.')
    ],
    cons: [
      createText('Limited single-player personalization.', 'Ограниченная персонализация для одиночной игры.'),
      createText('Fewer live dealer options.', 'Мало live-опций.')
    ],
    features: [
      {
        title: createText('Co-op Tools', 'Инструменты кооперации'),
        detail: createText('Share bankroll goals, agree on session limits, and track team health metrics.', 'Совместные цели банкролла, лимиты сессий и метрики здоровья команды.')
      },
      {
        title: createText('Educational Hub', 'Образовательный раздел'),
        detail: createText('Analyst webinars, strategy decks, and responsible play courses.', 'Вебинары аналитиков, стратегические презентации и курсы ответственной игры.')
      },
      {
        title: createText('Tournament Framework', 'Турнирная система'),
        detail: createText('Friendly competitions with badges and coaching rewards, never cash.', 'Дружеские турниры с бейджами и коучингом вместо денежных призов.')
      }
    ],
    comparison: {
      security: createText('Secure team workspaces with audit logs.', 'Безопасные командные пространства с журналами аудита.'),
      payoutSpeed: createText('Standard e-wallet payouts within 24-48 hours.', 'Обычные выплаты на e-wallet за 24-48 часов.'),
      support: createText('Team facilitators available during group sessions.', 'Консультанты для командных сессий.'),
      mobileExperience: createText('Responsive co-op dashboard optimised for tablets.', 'Адаптивный кооперативный дашборд для планшетов.'),
      responsiblePlay: createText('Mandatory limit agreements for team rooms.', 'Обязательные соглашения по лимитам для команд.'),
      licensing: createText('Kahnawake Gaming Commission.', 'Комиссия Канаваке.'),
      innovation: createText('Collaborative bankroll agreements with automated reminders.', 'Совместные соглашения по банкроллу с автоматическими напоминаниями.')
    },
    faqs: [
      {
        question: createText('How do team limits work?', 'Как работают командные лимиты?'),
        answer: createText('All members approve a shared limit plan before playing together.', 'Все участники утверждают общий план лимитов перед игрой.')
      },
      {
        question: createText('Are tournaments for money?', 'Есть ли денежные призы?'),
        answer: createText('No, tournaments award coaching sessions and recognition only.', 'Нет, турниры дают коучинг и признание, но не деньги.')
      }
    ],
    tags: ['Strategy', 'Cooperative', 'Education'],
    relatedSlugs: ['meridian-vault-gaming', 'zenith-play-hub'],
    certifications: ['Gamblers Anonymous Partner'],
    lastUpdated: createText('Updated January 2024', 'Обновлено в январе 2024')
  }
];

export default reviews;