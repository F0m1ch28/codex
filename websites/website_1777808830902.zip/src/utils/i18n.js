export const createText = (en, ru) => ({ en, ru });

export const getText = (value, language = 'en') => {
  if (!value) return '';
  if (typeof value === 'string') return value;
  return value[language] || value.en || '';
};