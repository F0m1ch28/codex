import React from 'react';
import styles from './About.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';
import ImageWithLoader from '../components/ImageWithLoader';

const hero = {
  title: createText('Meet the Analysts Behind Gambling Reviews', 'Познакомьтесь с аналитиками Gambling Reviews'),
  subtitle: createText(
    'We are a collective of compliance officers, former casino managers, data scientists, and UX researchers dedicated to safer, more transparent gambling experiences.',
    'Мы — команда комплаенс-специалистов, бывших менеджеров казино, дата-сайентистов и UX-исследователей, которые стремятся к ответственному и прозрачному азарту.'
  )
};

const mission = {
  title: createText('Our Mission', 'Наша миссия'),
  paragraphs: [
    createText(
      'Deliver unbiased, in-depth reviews of gambling products so players and industry teams can make informed choices without promotional bias.',
      'Предоставлять независимые, глубокие обзоры азартных продуктов, чтобы игроки и профессионалы принимали решения без рекламной предвзятости.'
    ),
    createText(
      'Elevate responsible gaming standards by highlighting tools, policies, and cultures that genuinely protect players.',
      'Повышать стандарты ответственной игры, демонстрируя сервисы, политики и культуры, которые действительно защищают игроков.'
    ),
    createText(
      'Advocate for clarity in bonuses, payments, and data protection to empower everyone engaging with casino platforms.',
      'Содействовать прозрачности бонусов, платежей и защиты данных, чтобы каждый пользователь казино-платформ чувствовал контроль.'
    )
  ]
};

const methodology = [
  {
    title: createText('Field-Tested Checklists', 'Полевые чек-листы'),
    detail: createText(
      'We maintain 46-point scorecards covering licensing, RNG audits, payment transparency, and customer support quality.',
      'Мы используем 46-пунктные чек-листы, охватывающие лицензирование, RNG-аудиты, прозрачность платежей и качество поддержки.'
    )
  },
  {
    title: createText('Dual Review Sign-Off', 'Двойное утверждение обзора'),
    detail: createText(
      'Every review is validated by two specialists: a technical analyst and a responsible gambling advocate.',
      'Каждый обзор подтверждается двумя специалистами: техническим аналитиком и экспертом по ответственной игре.'
    )
  },
  {
    title: createText('Reader Feedback Loop', 'Петля обратной связи'),
    detail: createText(
      'We implement reader input within 14 days, ensuring our content reflects current player sentiment.',
      'Мы учитываем отзывы читателей в течение 14 дней, чтобы материалы отражали актуальные настроения игроков.'
    )
  }
];

const teamMembers = [
  {
    name: 'Elena Markovic',
    role: createText('Head of Compliance Research', 'Руководитель комплаенс-исследований'),
    bio: createText(
      'Former European regulator advisor leading responsible gaming frameworks.',
      'Бывший консультант европейского регулятора, отвечает за разработку рамок ответственной игры.'
    ),
    image: 'https://picsum.photos/400/400?random=311'
  },
  {
    name: 'Daniel Mbeki',
    role: createText('Lead UX Auditor', 'Ведущий UX-аудитор'),
    bio: createText(
      'UX strategist with 9 years optimising casino onboarding and fairness displays.',
      'UX-стратег с 9-летним опытом оптимизации онбординга и отображения честности.',
    ),
    image: 'https://picsum.photos/400/400?random=312'
  },
  {
    name: 'Anastasia Petrovna',
    role: createText('Data Scientist', 'Дата-сайентист'),
    bio: createText(
      'Builds predictive models to flag risky bonus mechanics and high-friction funnels.',
      'Создаёт модели для выявления рискованных бонусных механик и узких мест в воронке.',
    ),
    image: 'https://picsum.photos/400/400?random=313'
  },
  {
    name: 'Luis Alvarez',
    role: createText('Player Advocate', 'Представитель игроков'),
    bio: createText(
      'Moderates player interviews and ensures our language remains actionable and clear.',
      'Проводит интервью с игроками и следит, чтобы наши выводы были понятными и полезными.'
    ),
    image: 'https://picsum.photos/400/400?random=314'
  }
];

const About = () => {
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroText}>
          <h1>{getText(hero.title, language)}</h1>
          <p>{getText(hero.subtitle, language)}</p>
        </div>
        <div className={styles.heroImage}>
          <ImageWithLoader
            src="https://picsum.photos/1200/700?random=308"
            alt={getText(createText('Team collaborating on gambling analytics', 'Команда работает над аналитикой азартных игр'), language)}
          />
        </div>
      </section>

      <section className={styles.mission}>
        <h2>{getText(mission.title, language)}</h2>
        {mission.paragraphs.map((paragraph, index) => (
          <p key={index}>{getText(paragraph, language)}</p>
        ))}
      </section>

      <section className={styles.methodology}>
        <h2>{getText(createText('How We Work', 'Как мы работаем'), language)}</h2>
        <div className={styles.methodGrid}>
          {methodology.map((item) => (
            <article key={item.title.en} className={styles.methodCard}>
              <h3>{getText(item.title, language)}</h3>
              <p>{getText(item.detail, language)}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <h2>{getText(createText('Editorial & Research Team', 'Редакционная и исследовательская команда'), language)}</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <ImageWithLoader
                src={member.image}
                alt={member.name}
                className={styles.portrait}
              />
              <h3>{member.name}</h3>
              <span>{getText(member.role, language)}</span>
              <p>{getText(member.bio, language)}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.values}>
        <h2>{getText(createText('Our Core Values', 'Наши основные ценности'), language)}</h2>
        <ul className={styles.valueList}>
          <li>
            <h3>{getText(createText('Neutrality', 'Нейтральность'), language)}</h3>
            <p>{getText(createText('Independent editorial charter without affiliate pressure.', 'Независимая редакционная политика без партнёрского давления.'), language)}</p>
          </li>
          <li>
            <h3>{getText(createText('Transparency', 'Прозрачность'), language)}</h3>
            <p>{getText(createText('Methodology and data points are published with every review.', 'Методология и метрики публикуются в каждом обзоре.'), language)}</p>
          </li>
          <li>
            <h3>{getText(createText('Responsibility', 'Ответственность'), language)}</h3>
            <p>{getText(createText('Championing player wellbeing and safe gambling standards.', 'Поддерживаем благополучие игроков и стандарты безопасной игры.'), language)}</p>
          </li>
        </ul>
      </section>
    </div>
  );
};

export default About;