import React, { useMemo, useState } from 'react';
import styles from './Reviews.module.css';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import reviewsData from '../data/reviewsData';
import { createText, getText } from '../utils/i18n';

const Reviews = () => {
  const { language } = useLanguage();
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');

  const categories = useMemo(() => {
    const unique = new Set(reviewsData.map((review) => review.category));
    return ['all', ...Array.from(unique)];
  }, []);

  const filteredReviews = useMemo(() => {
    return reviewsData.filter((review) => {
      const matchesCategory = category === 'all' || review.category === category;
      const matchesSearch =
        review.name.toLowerCase().includes(search.toLowerCase()) ||
        getText(review.summary, language).toLowerCase().includes(search.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [category, search, language]);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>{getText(createText('Casino Product Reviews', 'Обзоры казино-продуктов'), language)}</h1>
        <p>{getText(createText('Compare ratings, bonus mechanics, and responsible play safeguards across platforms.', 'Сравнивайте рейтинги, бонусные механики и меры ответственной игры на разных платформах.'), language)}</p>
      </section>

      <section className={styles.filters}>
        <div className={styles.filterGroup}>
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              className={`${styles.filterButton} ${category === cat ? styles.active : ''}`}
              onClick={() => setCategory(cat)}
            >
              {cat === 'all' ? getText(createText('All', 'Все'), language) : cat}
            </button>
          ))}
        </div>
        <div className={styles.searchGroup}>
          <label htmlFor="review-search" className="sr-only">Search reviews</label>
          <input
            id="review-search"
            type="search"
            placeholder={getText(createText('Search reviews...', 'Поиск обзоров...'), language)}
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </div>
      </section>

      <section className={styles.grid}>
        {filteredReviews.map((review) => (
          <article key={review.slug} className={styles.card}>
            <header>
              <img src={review.logo} alt={`${review.name} logo`} />
              <div>
                <h3>{review.name}</h3>
                <span className={styles.rating}>{review.rating.toFixed(1)} / 5</span>
              </div>
            </header>
            <p>{getText(review.summary, language)}</p>
            <ul className={styles.tagList}>
              <li>{review.category}</li>
              {review.tags.slice(0, 2).map((tag) => (
                <li key={tag}>{tag}</li>
              ))}
            </ul>
            <Link to={`/review/${review.slug}`} className={styles.cardLink}>
              {getText(createText('Read review', 'Читать обзор'), language)}
            </Link>
          </article>
        ))}
        {filteredReviews.length === 0 && (
          <div className={styles.empty}>
            {getText(createText('No reviews match your filters. Try a different term.', 'Нет обзоров по выбранным фильтрам. Попробуйте изменить запрос.'), language)}
          </div>
        )}
      </section>
    </div>
  );
};

export default Reviews;