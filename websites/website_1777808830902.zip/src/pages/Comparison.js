import React, { useMemo, useState } from 'react';
import styles from './Comparison.module.css';
import reviews from '../data/reviewsData';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const metricsOrder = [
  'security',
  'payoutSpeed',
  'support',
  'mobileExperience',
  'responsiblePlay',
  'licensing',
  'withdrawalTransparency',
  'innovation'
];

const Comparison = () => {
  const { language } = useLanguage();
  const [selectedSlugs, setSelectedSlugs] = useState([]);

  const handleSelect = (slug) => {
    setSelectedSlugs((prev) => {
      if (prev.includes(slug)) {
        return prev.filter((item) => item !== slug);
      }
      if (prev.length >= 4) {
        return prev;
      }
      return [...prev, slug];
    });
  };

  const selectedReviews = useMemo(
    () => reviews.filter((review) => selectedSlugs.includes(review.slug)),
    [selectedSlugs]
  );

  const allMetrics = useMemo(() => {
    const set = new Set(metricsOrder);
    selectedReviews.forEach((review) => {
      Object.keys(review.comparison).forEach((metric) => set.add(metric));
    });
    return Array.from(set);
  }, [selectedReviews]);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>{getText(createText('Casino Comparison Matrix', 'Матрица сравнения казино'), language)}</h1>
        <p>{getText(createText('Select up to four products to compare policies, user experience, and safety controls side-by-side.', 'Выберите до четырёх продуктов, чтобы сравнить политики, UX и меры безопасности.'), language)}</p>
      </section>

      <section className={styles.selector}>
        <h2>{getText(createText('Select products', 'Выберите продукты'), language)}</h2>
        <div className={styles.selectorGrid}>
          {reviews.map((review) => (
            <label key={review.slug} className={`${styles.selectorCard} ${selectedSlugs.includes(review.slug) ? styles.selected : ''}`}>
              <input
                type="checkbox"
                checked={selectedSlugs.includes(review.slug)}
                onChange={() => handleSelect(review.slug)}
              />
              <div className={styles.selectorContent}>
                <img src={review.logo} alt={`${review.name} logo`} />
                <div>
                  <h3>{review.name}</h3>
                  <span>{review.rating.toFixed(1)} / 5</span>
                  <p>{getText(review.summary, language)}</p>
                </div>
              </div>
            </label>
          ))}
        </div>
        {selectedSlugs.length >= 4 && (
          <p className={styles.notice}>
            {getText(createText('Maximum of four products can be compared at once.', 'Одновременно можно сравнить максимум четыре продукта.'), language)}
          </p>
        )}
      </section>

      <section className={styles.matrix}>
        {selectedReviews.length === 0 ? (
          <p className={styles.empty}>
            {getText(createText('Select products to generate a comparison table.', 'Выберите продукты, чтобы увидеть таблицу сравнения.'), language)}
          </p>
        ) : (
          <div className={styles.tableWrapper}>
            <table>
              <thead>
                <tr>
                  <th>{getText(createText('Metric', 'Показатель'), language)}</th>
                  {selectedReviews.map((review) => (
                    <th key={review.slug}>{review.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allMetrics.map((metric) => (
                  <tr key={metric}>
                    <td className={styles.metricName}>{metric.replace(/([A-Z])/g, ' $1')}</td>
                    {selectedReviews.map((review) => (
                      <td key={`${review.slug}-${metric}`}>
                        {review.comparison[metric]
                          ? getText(review.comparison[metric], language)
                          : getText(createText('Not specified', 'Не указано'), language)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className={styles.disclaimer}>
          {getText(createText('All insights are editorial opinions and not financial advice. Always check local regulations before playing.', 'Вся информация — редакционное мнение, а не финансовая рекомендация. Перед игрой всегда проверяйте местное законодательство.'), language)}
        </p>
      </section>
    </div>
  );
};

export default Comparison;