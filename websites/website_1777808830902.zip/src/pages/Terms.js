import React from 'react';
import styles from './Legal.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const Terms = () => {
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <h1>{getText(createText('Terms of Service', 'Условия использования'), language)}</h1>
      <p>{getText(createText('Last updated: March 2024', 'Последнее обновление: март 2024'), language)}</p>

      <section>
        <h2>{getText(createText('1. Overview', '1. Общие положения'), language)}</h2>
        <p>{getText(createText('Gambling Reviews provides editorial analyses of gambling-related products. The site does not facilitate betting, financial transactions, or the creation of user accounts for gambling platforms.', 'Gambling Reviews предоставляет редакционные обзоры азартных продуктов. Сайт не осуществляет размещение ставок, финансовые операции или создание аккаунтов на платформах.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('2. Eligibility', '2. Допуск'), language)}</h2>
        <p>{getText(createText('You must be of legal age in your jurisdiction to consume gambling-related content. By using the site, you confirm compliance with local laws.', 'Вы должны достигнуть совершеннолетия в своей юрисдикции для просмотра материалов о азартных играх. Используя сайт, вы подтверждаете соблюдение местного законодательства.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('3. Editorial Independence', '3. Редакционная независимость'), language)}</h2>
        <p>{getText(createText('All reviews and comparisons are written without influence from operators. We do not accept sponsored posts or affiliate commissions.', 'Все обзоры и сравнения готовятся без влияния со стороны операторов. Мы не размещаем спонсорский контент и не работаем по партнёрским схемам.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('4. Limitation of Liability', '4. Ограничение ответственности'), language)}</h2>
        <p>{getText(createText('We strive for accuracy but cannot guarantee completeness. Gambling Reviews is not liable for decisions made based on our content. Always verify details directly with the operator.', 'Мы стремимся к точности, но не гарантируем полноту. Gambling Reviews не несёт ответственности за решения, принятые на основе наших материалов. Всегда уточняйте информацию у операторов.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('5. Changes to Terms', '5. Изменения условий'), language)}</h2>
        <p>{getText(createText('We may update these terms at any time. Continued use of the site constitutes acceptance of updates.', 'Мы можем обновлять условия в любое время. Продолжение использования сайта означает согласие с обновлёнными условиями.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('6. Contact', '6. Контакты'), language)}</h2>
        <p>info@gamblingreview.com</p>
      </section>
    </div>
  );
};

export default Terms;