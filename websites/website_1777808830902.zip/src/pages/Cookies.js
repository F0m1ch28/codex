import React from 'react';
import styles from './Legal.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const Cookies = () => {
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <h1>{getText(createText('Cookie Policy', 'Политика использования cookies'), language)}</h1>
      <p>{getText(createText('Last updated: March 2024', 'Последнее обновление: март 2024'), language)}</p>

      <section>
        <h2>{getText(createText('1. Essential Cookies', '1. Основные cookies'), language)}</h2>
        <p>{getText(createText('Required for core site functionality such as remembering language selection.', 'Необходимы для базовых функций, например для запоминания выбранного языка.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('2. Analytics Cookies', '2. Аналитические cookies'), language)}</h2>
        <p>{getText(createText('Help us monitor site performance. These cookies are optional and can be declined via the banner.', 'Помогают отслеживать работу сайта. Эти cookies необязательны и могут быть отклонены через баннер.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('3. Managing Preferences', '3. Управление предпочтениями'), language)}</h2>
        <p>{getText(createText('Use the cookie banner or adjust browser settings to change your preferences at any time.', 'Используйте баннер или настройки браузера для изменения предпочтений в любое время.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('4. Contact', '4. Контакты'), language)}</h2>
        <p>info@gamblingreview.com</p>
      </section>
    </div>
  );
};

export default Cookies;