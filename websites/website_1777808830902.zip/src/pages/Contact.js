import React, { useState } from 'react';
import styles from './Contact.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const strings = {
  title: createText('Contact Our Team', 'Свяжитесь с нашей командой'),
  subtitle: createText(
    'Need a custom audit, have a press enquiry, or want to share feedback? We respond within one business day.',
    'Нужен индивидуальный аудит, пресс-запрос или хотите поделиться обратной связью? Ответим в течение одного рабочего дня.'
  ),
  formTitle: createText('Send Us a Message', 'Отправьте сообщение'),
  nameLabel: createText('Full name', 'Полное имя'),
  emailLabel: createText('Email address', 'Email'),
  messageLabel: createText('How can we help?', 'Чем мы можем помочь?'),
  consentLabel: createText(
    'I consent to the processing of my personal data in accordance with the privacy policy.',
    'Я даю согласие на обработку моих персональных данных в соответствии с политикой конфиденциальности.'
  ),
  submit: createText('Submit message', 'Отправить сообщение'),
  success: createText('Thank you! Your message has been sent successfully.', 'Спасибо! Ваше сообщение успешно отправлено.'),
  error: createText('Please fill in all required fields correctly.', 'Пожалуйста, заполните все обязательные поля корректно.')
};

const requiredErrors = {
  name: createText('Please provide your name.', 'Пожалуйста, укажите имя.'),
  email: createText('Please provide a valid email address.', 'Пожалуйста, укажите корректный email.'),
  message: createText('Please include a message.', 'Пожалуйста, напишите сообщение.'),
  consent: createText('Please confirm your consent.', 'Пожалуйста, подтвердите согласие.')
};

const Contact = () => {
  const { language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    consent: false
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = getText(requiredErrors.name, language);
    if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = getText(requiredErrors.email, language);
    if (!formData.message.trim()) newErrors.message = getText(requiredErrors.message, language);
    if (!formData.consent) newErrors.consent = getText(requiredErrors.consent, language);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setStatus({ type: 'success', message: getText(strings.success, language) });
      setFormData({ name: '', email: '', message: '', consent: false });
    } else {
      setStatus({ type: 'error', message: getText(strings.error, language) });
    }
  };

  return (
    <div className={styles.page}>
      <section className={styles.intro}>
        <h1>{getText(strings.title, language)}</h1>
        <p>{getText(strings.subtitle, language)}</p>
      </section>

      <section className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>{getText(strings.formTitle, language)}</h2>
          <label htmlFor="name">{getText(strings.nameLabel, language)}</label>
          <input
            id="name"
            name="name"
            type="text"
            value={formData.name}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={errors.name ? 'true' : 'false'}
          />
          {errors.name && <span className={styles.error}>{errors.name}</span>}

          <label htmlFor="email">{getText(strings.emailLabel, language)}</label>
          <input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={errors.email ? 'true' : 'false'}
          />
          {errors.email && <span className={styles.error}>{errors.email}</span>}

          <label htmlFor="message">{getText(strings.messageLabel, language)}</label>
          <textarea
            id="message"
            name="message"
            rows="5"
            value={formData.message}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={errors.message ? 'true' : 'false'}
          />
          {errors.message && <span className={styles.error}>{errors.message}</span>}

          <label className={styles.checkbox}>
            <input
              type="checkbox"
              name="consent"
              checked={formData.consent}
              onChange={handleChange}
              aria-required="true"
            />
            <span>{getText(strings.consentLabel, language)}</span>
          </label>
          {errors.consent && <span className={styles.error}>{errors.consent}</span>}

          <button type="submit" className={styles.primaryButton}>
            {getText(strings.submit, language)}
          </button>
          {status && (
            <p className={status.type === 'success' ? styles.success : styles.error}>
              {status.message}
            </p>
          )}
        </form>

        <aside className={styles.sidebar}>
          <div className={styles.contactCard}>
            <h3>{getText(createText('Direct Contacts', 'Прямые контакты'), language)}</h3>
            <ul>
              <li>
                <strong>Email</strong>
                <a href="mailto:info@gamblingreview.com">info@gamblingreview.com</a>
              </li>
              <li>
                <strong>Phone</strong>
                <a href="tel:+442071234567">+44 20 7123 4567</a>
              </li>
              <li>
                <strong>{getText(createText('Address', 'Адрес'), language)}</strong>
                <span>123 Gaming Street, Suite 100, London, UK</span>
              </li>
            </ul>
          </div>
          <div className={styles.contactCard}>
            <h3>{getText(createText('Media & Partnerships', 'Пресса и партнёрство'), language)}</h3>
            <p>{getText(createText('Reach out for interviews, quotes, or collaborative research opportunities.', 'Свяжитесь для интервью, комментариев или совместных исследований.'), language)}</p>
            <a className={styles.secondaryButton} href="mailto:media@gamblingreview.com">
              media@gamblingreview.com
            </a>
          </div>
        </aside>
      </section>
    </div>
  );
};

export default Contact;