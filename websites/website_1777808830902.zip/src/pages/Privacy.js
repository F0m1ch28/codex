import React from 'react';
import styles from './Legal.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const Privacy = () => {
  const { language } = useLanguage();

  return (
    <div className={styles.page}>
      <h1>{getText(createText('Privacy Policy', 'Политика конфиденциальности'), language)}</h1>
      <p>{getText(createText('Last updated: March 2024', 'Последнее обновление: март 2024'), language)}</p>

      <section>
        <h2>{getText(createText('1. Data Overview', '1. Обзор данных'), language)}</h2>
        <p>{getText(createText('We collect minimal personal data: contact form submissions and newsletter signups. Data is used solely to respond to enquiries or deliver requested updates.', 'Мы собираем минимум персональных данных: сообщения из контактной формы и подписки на рассылку. Данные используются только для ответов или отправки запрошенных материалов.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('2. Cookies', '2. Cookies'), language)}</h2>
        <p>{getText(createText('Analytics cookies help us understand site usage. You can opt out via the cookie banner. Essential cookies support core functionality.', 'Аналитические cookies помогают нам понимать использование сайта. Вы можете отказаться через баннер. Основные cookies обеспечивают базовые функции сайта.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('3. Data Storage', '3. Хранение данных'), language)}</h2>
        <p>{getText(createText('We store data on secure servers within the UK/EU and retain it only as long as necessary for the stated purpose.', 'Данные хранятся на защищённых серверах в Великобритании/ЕС и удерживаются только столько, сколько необходимо для заявленных целей.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('4. Third Parties', '4. Третьи стороны'), language)}</h2>
        <p>{getText(createText('We use reputable email and analytics providers compliant with GDPR and other applicable laws. We do not sell personal data.', 'Мы используем проверенных провайдеров email и аналитики, соответствующих GDPR и другим законам. Мы не продаём персональные данные.'), language)}</p>
      </section>

      <section>
        <h2>{getText(createText('5. Your Rights', '5. Ваши права'), language)}</h2>
        <p>{getText(createText('You may request access, correction, or deletion of your data by contacting info@gamblingreview.com.', 'Вы можете запросить доступ, корректировку или удаление ваших данных, написав на info@gamblingreview.com.'), language)}</p>
      </section>
    </div>
  );
};

export default Privacy;