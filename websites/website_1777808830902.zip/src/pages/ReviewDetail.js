import React, { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import styles from './ReviewDetail.module.css';
import reviews from '../data/reviewsData';
import { useLanguage } from '../context/LanguageContext';
import { getText, createText } from '../utils/i18n';

const ReviewDetail = () => {
  const { slug } = useParams();
  const { language } = useLanguage();

  const review = useMemo(
    () => reviews.find((item) => item.slug === slug),
    [slug]
  );

  if (!review) {
    return (
      <div className={styles.page}>
        <section className={styles.notFound}>
          <h1>{getText(createText('Review not found', 'Обзор не найден'), language)}</h1>
          <Link to="/reviews" className={styles.primaryButton}>
            {getText(createText('Back to reviews', 'Вернуться к обзорам'), language)}
          </Link>
        </section>
      </div>
    );
  }

  const related = reviews.filter((item) => review.relatedSlugs.includes(item.slug));

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <img src={review.logo} alt={`${review.name} logo`} className={styles.logo} />
          <div>
            <h1>{review.name}</h1>
            <p>{getText(review.tagline, language)}</p>
            <div className={styles.meta}>
              <span className={styles.rating}>{review.rating.toFixed(1)} / 5</span>
              <span>{getText(review.lastUpdated, language)}</span>
            </div>
          </div>
        </div>
        <img
          src={review.banner}
          alt={`${review.name} overview`}
          className={styles.heroImage}
        />
      </section>

      <section className={styles.summary}>
        <h2>{getText(createText('Executive Summary', 'Краткое резюме'), language)}</h2>
        <p>{getText(review.summary, language)}</p>
      </section>

      <section className={styles.bonus}>
        <h2>{getText(createText('Bonus Overview', 'Обзор бонусов'), language)}</h2>
        <div className={styles.bonusCard}>
          <h3>{getText(review.bonus.title, language)}</h3>
          <p>{getText(review.bonus.details, language)}</p>
          <p className={styles.bonusTerms}>{getText(review.bonus.terms, language)}</p>
        </div>
      </section>

      <section className={styles.prosCons}>
        <div>
          <h3>{getText(createText('Pros', 'Преимущества'), language)}</h3>
          <ul>
            {review.pros.map((item) => (
              <li key={item.en}>{getText(item, language)}</li>
            ))}
          </ul>
        </div>
        <div>
          <h3>{getText(createText('Cons', 'Недостатки'), language)}</h3>
          <ul>
            {review.cons.map((item) => (
              <li key={item.en}>{getText(item, language)}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className={styles.features}>
        <h2>{getText(createText('Feature Breakdown', 'Подробный анализ функций'), language)}</h2>
        <div className={styles.featureGrid}>
          {review.features.map((feature) => (
            <article key={feature.title.en} className={styles.featureCard}>
              <h3>{getText(feature.title, language)}</h3>
              <p>{getText(feature.detail, language)}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.comparison}>
        <h2>{getText(createText('Key Comparison Metrics', 'Ключевые показатели сравнения'), language)}</h2>
        <table>
          <thead>
            <tr>
              <th>{getText(createText('Metric', 'Показатель'), language)}</th>
              <th>{getText(createText('Detail', 'Описание'), language)}</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(review.comparison).map(([key, value]) => (
              <tr key={key}>
                <td>{key.replace(/([A-Z])/g, ' $1')}</td>
                <td>{getText(value, language)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <Link to="/comparison" className={styles.secondaryButton}>
          {getText(createText('Add to comparison matrix', 'Добавить в матрицу сравнения'), language)}
        </Link>
      </section>

      <section className={styles.faq}>
        <h2>{getText(createText('Review FAQ', 'FAQ обзора'), language)}</h2>
        <div className={styles.faqList}>
          {review.faqs.map((faq) => (
            <details key={faq.question.en}>
              <summary>{getText(faq.question, language)}</summary>
              <p>{getText(faq.answer, language)}</p>
            </details>
          ))}
        </div>
      </section>

      {related.length > 0 && (
        <section className={styles.related}>
          <h2>{getText(createText('Related Reviews', 'Похожие обзоры'), language)}</h2>
          <div className={styles.relatedGrid}>
            {related.map((item) => (
              <article key={item.slug} className={styles.relatedCard}>
                <img src={item.logo} alt={`${item.name} logo`} />
                <div>
                  <h3>{item.name}</h3>
                  <p>{getText(item.summary, language)}</p>
                  <Link to={`/review/${item.slug}`} className={styles.cardLink}>
                    {getText(createText('View review', 'Смотреть обзор'), language)}
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default ReviewDetail;