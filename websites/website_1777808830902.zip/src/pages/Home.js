import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';
import reviews from '../data/reviewsData';
import ImageWithLoader from '../components/ImageWithLoader';

const heroContent = {
  title: createText(
    'Navigate Gambling Products with Confidence',
    'Ориентируйтесь в азартных продуктах уверенно'
  ),
  subtitle: createText(
    'Independent breakdowns of casino platforms, bonus mechanics, and player safeguards tailored for the CIS audience and beyond.',
    'Независимый анализ казино-платформ, бонусных механик и мер защиты игроков для аудитории стран СНГ и других регионов.'
  ),
  ctaPrimary: createText('Explore Top Reviews', 'Изучить лучшие обзоры'),
  ctaSecondary: createText('Compare Products', 'Сравнить продукты'),
  disclaimer: createText(
    'We analyse experiences only. No wagering or financial transactions are available on this site.',
    'Мы анализируем только пользовательский опыт. Никаких ставок или финансовых операций на сайте нет.'
  )
};

const statsData = [
  {
    value: 128,
    suffix: '+',
    label: createText('Audited gambling products', 'Аудировано азартных платформ'),
    description: createText('Updated quarterly with fresh compliance checks.', 'Ежеквартальные обновления и проверки соответствия.')
  },
  {
    value: 46,
    suffix: '',
    label: createText('Point comparison matrix', 'Параметров в матрице сравнения'),
    description: createText('Covering security, fairness, UX, and responsible play.', 'Безопасность, честность, UX и ответственная игра.')
  },
  {
    value: 32,
    suffix: '',
    label: createText('Expert contributors', 'Экспертов-обозревателей'),
    description: createText('Former pit bosses, analysts, and compliance officers.', 'Бывшие менеджеры казино, аналитики и специалисты по комплаенсу.')
  }
];

const howItWorksSteps = [
  {
    title: createText('We benchmark safety first', 'Прежде всего оцениваем безопасность'),
    description: createText('Licensing, encryption, game fairness testing, and AML controls are reviewed before anything else.', 'Перед остальными параметрами анализируем лицензирование, шифрование, честность игр и AML-контроль.')
  },
  {
    title: createText('Player journey simulations', 'Симуляции пользовательского пути'),
    description: createText('Our team creates anonymous accounts to test onboarding, bonus clarity, support, and withdrawal experience.', 'Команда создаёт анонимные аккаунты для проверки онбординга, прозрачности бонусов, поддержки и вывода средств.')
  },
  {
    title: createText('Transparent scoring framework', 'Прозрачная система оценок'),
    description: createText('Scores are generated across 10 weighted categories with documentation you can audit yourself.', 'Оценки формируются по 10 категорий с коэффициентами и документируются для вашей проверки.')
  }
];

const processSteps = [
  {
    title: createText('Discovery', 'Исследование'),
    text: createText('We map regulatory status, target markets, software providers, and responsible-gaming footprint.', 'Мы анализируем лицензии, целевые рынки, поставщиков софта и меры ответственной игры.')
  },
  {
    title: createText('Testing', 'Тестирование'),
    text: createText('Hands-on experience across desktop and mobile, including payment sandboxes and bonus mission tracking.', 'Практический тест на desktop и мобильных платформах, включая оплату в sandbox и отслеживание бонусных миссий.')
  },
  {
    title: createText('Validation', 'Валидация'),
    text: createText('Independent reviewers sign off every verdict, ensuring no marketing bias enters our matrix.', 'Независимые эксперты утверждают выводы, исключая маркетинговую предвзятость.')
  },
  {
    title: createText('Publishing', 'Публикация'),
    text: createText('Each report is dated, assigned a maintenance owner, and scheduled for quarterly refresh.', 'Каждый обзор датирован, закреплён за аналитиком и планово пересматривается каждые три месяца.')
  }
];

const testimonials = [
  {
    name: 'Olga Cherkasova',
    role: createText('Responsible Gaming Consultant', 'Консультант по ответственной игре'),
    quote: createText(
      '“Gambling Reviews became my go-to reference for CIS venues. Their matrices show exactly where limits are enforced seriously.”',
      '«Gambling Reviews — мой главный источник по платформам СНГ. Их матрицы наглядно показывают, где лимиты действительно работают.»'
    )
  },
  {
    name: 'Marcus Everett',
    role: createText('Casino UX Strategist', 'UX-стратег казино'),
    quote: createText(
      '“The product deep dives help us benchmark against the best-in-class without promotional fluff.”',
      '«Глубокие обзоры помогают нам сравниваться с лидерами рынка без рекламного шума.»'
    )
  },
  {
    name: 'Aigerim Tulegenova',
    role: createText('iGaming Compliance Officer', 'Специалист по комплаенсу iGaming'),
    quote: createText(
      '“I appreciate the team’s focus on AML and affordability checks. The insights make regulatory reporting easier.”',
      '«Мне нравится фокус команды на AML и проверках доступности. Их выводы упрощают составление отчётов для регуляторов.»'
    )
  }
];

const projectCategories = [
  { key: 'all', label: createText('All Projects', 'Все проекты') },
  { key: 'research', label: createText('Research', 'Исследования') },
  { key: 'compliance', label: createText('Compliance', 'Комплаенс') },
  { key: 'ux', label: createText('UX Audits', 'UX-аудиты') }
];

const projectItems = [
  {
    id: 1,
    category: 'research',
    title: createText('CIS Bonus Archetype Study', 'Исследование бонусных архетипов СНГ'),
    description: createText(
      'Mapping bonus mission sentiment across 18 operators with responsible-play recommendations.',
      'Карта восприятия бонусных миссий у 18 операторов с мерами ответственной игры.'
    ),
    image: 'https://picsum.photos/1200/800?random=401'
  },
  {
    id: 2,
    category: 'compliance',
    title: createText('AML Control Benchmark', 'Бенчмарк AML-контролей'),
    description: createText(
      'Third-party evaluation of KYC automation against updated EU directives.',
      'Независимая оценка автоматизации KYC в соответствии с новыми директивами ЕС.'
    ),
    image: 'https://picsum.photos/1200/800?random=402'
  },
  {
    id: 3,
    category: 'ux',
    title: createText('Mobile Lobby UX Sprint', 'UX-спринт мобильного лобби'),
    description: createText(
      'Session recordings and heatmaps driving a 27% uplift in mission completion clarity.',
      'Записи сессий и тепловые карты повысили завершение миссий на 27%.'
    ),
    image: 'https://picsum.photos/1200/800?random=403'
  },
  {
    id: 4,
    category: 'research',
    title: createText('Live Dealer Latency Report', 'Отчёт о задержках live-игр'),
    description: createText(
      'Measured average latency per provider to help players choose smoother experiences.',
      'Измерение задержек у провайдеров для выбора наиболее плавной игры.'
    ),
    image: 'https://picsum.photos/1200/800?random=404'
  }
];

const faqItems = [
  {
    question: createText('Do you feature real-money gambling?', 'Публикуете ли вы реальные азартные игры?'),
    answer: createText(
      'No. We only review platforms and share analytical opinions. We never provide betting functionality or transactional services.',
      'Нет. Мы публикуем аналитические обзоры и мнения. Никаких ставок или транзакций на сайте нет.'
    )
  },
  {
    question: createText('How often are reviews updated?', 'Как часто обновляются обзоры?'),
    answer: createText(
      'Every review is revisited at least once per quarter, or sooner if a platform changes its policies or launches major features.',
      'Каждый обзор пересматривается минимум раз в квартал или раньше, если платформа меняет политику или запускает важные функции.'
    )
  },
  {
    question: createText('Do you accept sponsored content?', 'Принимаете ли вы платный контент?'),
    answer: createText(
      'No. To maintain neutrality, we do not accept sponsored placements or affiliate commissions.',
      'Нет. Чтобы сохранять нейтральность, мы не публикуем спонсорские материалы и не работаем по партнёрским ссылкам.'
    )
  }
];

const blogPosts = [
  {
    title: createText('How to Evaluate Casino Bonus Wagering Terms Transparently', 'Как прозрачно оценивать условия отыгрыша бонусов казино'),
    excerpt: createText(
      'Learn the checklist our auditors use to determine whether bonus requirements align with responsible gaming frameworks.',
      'Узнайте чек-лист, по которому наши аудиторы проверяют соответствие бонусных требований принципам ответственной игры.'
    ),
    link: '#',
    date: createText('March 26, 2024', '26 марта 2024'),
    image: 'https://picsum.photos/800/600?random=405'
  },
  {
    title: createText('The Rise of Mission-Based Loyalty Programs', 'Рост миссионных программ лояльности'),
    excerpt: createText(
      'Mission-based loyalty keeps players engaged, but only when paired with meaningful limit controls.',
      'Миссионные программы удерживают игроков, но только в сочетании с эффективными лимитами.'
    ),
    link: '#',
    date: createText('April 05, 2024', '5 апреля 2024'),
    image: 'https://picsum.photos/800/600?random=406'
  },
  {
    title: createText('UX Patterns That Encourage Responsible Play', 'UX-паттерны для ответственной игры'),
    excerpt: createText(
      'Design techniques that inform players about wagering impact without intrusive prompts.',
      'Дизайн-приёмы, помогающие информировать игроков о влиянии ставок без навязчивых уведомлений.'
    ),
    link: '#',
    date: createText('April 18, 2024', '18 апреля 2024'),
    image: 'https://picsum.photos/800/600?random=407'
  }
];

const newsletterText = {
  title: createText('Join the Responsible Gaming Insights Newsletter', 'Подпишитесь на рассылку о ответственной игре'),
  subtitle: createText(
    'Monthly updates with compliance alerts, UX research results, and new review releases.',
    'Ежемесячные обновления с комплаенс-новостями, UX-исследованиями и новыми обзорами.'
  ),
  placeholder: createText('Your email address', 'Ваш email'),
  consent: createText(
    'I agree to receive educational emails from Gambling Reviews.',
    'Я согласен получать образовательные письма от Gambling Reviews.'
  ),
  button: createText('Subscribe', 'Подписаться'),
  success: createText('Subscription confirmed — check your inbox for a welcome note.', 'Подписка подтверждена — проверьте почту для приветственного письма.'),
  error: createText('Something went wrong. Please try again in a moment.', 'Что-то пошло не так. Попробуйте ещё раз немного позже.'),
  invalidEmail: createText('Please enter a valid email address.', 'Введите корректный email.'),
  consentError: createText('Please confirm you agree to receive updates.', 'Подтвердите согласие на получение рассылки.')
};

const ctaSection = {
  title: createText('Ready to Benchmark Your Casino Product?', 'Готовы сравнить свою казино-платформу?'),
  subtitle: createText(
    'Request a bespoke audit or explore our public review library to refine your roadmap.',
    'Закажите индивидуальный аудит или изучите библиотеку обзоров, чтобы улучшить свою стратегию.'
  ),
  button: createText('Talk to an Analyst', 'Связаться с аналитиком')
};

const Home = () => {
  const { language } = useLanguage();
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [projectFilter, setProjectFilter] = useState('all');
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterConsent, setNewsletterConsent] = useState(false);
  const [newsletterStatus, setNewsletterStatus] = useState(null);

  const featuredReviews = useMemo(
    () => [...reviews].sort((a, b) => b.rating - a.rating).slice(0, 3),
    []
  );

  const filteredProjects = useMemo(() => {
    if (projectFilter === 'all') return projectItems;
    return projectItems.filter((item) => item.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    let animationFrame;
    const duration = 1200;
    const start = performance.now();

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setCounts(
        statsData.map((item) => Math.round(item.value * progress))
      );
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [language]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail || !/\S+@\S+\.\S+/.test(newsletterEmail)) {
      setNewsletterStatus({ type: 'error', message: getText(newsletterText.invalidEmail, language) });
      return;
    }
    if (!newsletterConsent) {
      setNewsletterStatus({ type: 'error', message: getText(newsletterText.consentError, language) });
      return;
    }
    setNewsletterStatus({ type: 'success', message: getText(newsletterText.success, language) });
    setNewsletterEmail('');
    setNewsletterConsent(false);
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>{getText(heroContent.title, language)}</h1>
          <p>{getText(heroContent.subtitle, language)}</p>
          <div className={styles.heroActions}>
            <Link to="/reviews" className={styles.primaryButton}>
              {getText(heroContent.ctaPrimary, language)}
            </Link>
            <Link to="/comparison" className={styles.secondaryButton}>
              {getText(heroContent.ctaSecondary, language)}
            </Link>
          </div>
          <span className={styles.heroDisclaimer}>
            {getText(heroContent.disclaimer, language)}
          </span>
        </div>
        <div className={styles.heroVisual}>
          <ImageWithLoader
            src="https://picsum.photos/1600/900?random=301"
            alt={getText(createText('Abstract gambling analytics dashboard', 'Абстрактная аналитика азартных игр'), language)}
          />
        </div>
      </section>

      <section className={styles.stats} aria-label="Key metrics">
        {statsData.map((item, index) => (
          <div key={item.label.en} className={styles.statCard}>
            <div className={styles.statValue}>
              {counts[index]}
              {item.suffix}
            </div>
            <div className={styles.statLabel}>{getText(item.label, language)}</div>
            <p>{getText(item.description, language)}</p>
          </div>
        ))}
      </section>

      <section className={styles.featured}>
        <div className={styles.sectionHeader}>
          <h2>{getText(createText('Featured Casino Reviews', 'Избранные обзоры казино'), language)}</h2>
          <p>{getText(createText('Our editorial board’s top choices this month.', 'Лучшие рекомендации редакции на этот месяц.'), language)}</p>
        </div>
        <div className={styles.cardGrid}>
          {featuredReviews.map((review) => (
            <article key={review.slug} className={styles.reviewCard}>
              <div className={styles.reviewHeader}>
                <img src={review.logo} alt={`${review.name} logo`} />
                <div>
                  <h3>{review.name}</h3>
                  <span className={styles.rating}>{review.rating.toFixed(1)} / 5</span>
                </div>
              </div>
              <p>{getText(review.summary, language)}</p>
              <ul className={styles.tagList}>
                {review.tags.slice(0, 3).map((tag) => (
                  <li key={tag}>{tag}</li>
                ))}
              </ul>
              <Link to={`/review/${review.slug}`} className={styles.cardLink}>
                {getText(createText('Read full review', 'Читать обзор'), language)}
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.howItWorks}>
        <div className={styles.sectionHeader}>
          <h2>{getText(createText('How Our Review Process Works', 'Как работает наш процесс обзора'), language)}</h2>
          <p>{getText(createText('A transparent framework refined with regulators and player communities.', 'Прозрачная методология в сотрудничестве с регуляторами и игровыми сообществами.'), language)}</p>
        </div>
        <div className={styles.howGrid}>
          {howItWorksSteps.map((step) => (
            <div key={step.title.en} className={styles.howItem}>
              <h3>{getText(step.title, language)}</h3>
              <p>{getText(step.description, language)}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.sectionHeader}>
          <h2>{getText(createText('Our Analytical Workflow', 'Наш аналитический рабочий процесс'), language)}</h2>
          <p>{getText(createText('Every casino audit follows a proven blueprint from discovery to publication.', 'Каждый аудит казино следует выверенному плану от исследования до публикации.'), language)}</p>
        </div>
        <div className={styles.processTimeline}>
          {processSteps.map((step, index) => (
            <div key={step.title.en} className={styles.processStep}>
              <div className={styles.processIndex}>{index + 1}</div>
              <div>
                <h3>{getText(step.title, language)}</h3>
                <p>{getText(step.text, language)}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>{getText(createText('Voices From the Industry', 'Мнения отраслевых экспертов'), language)}</h2>
          <p>{getText(createText('Specialists across compliance, UX, and responsible play rely on our research.', 'Специалисты по комплаенсу, UX и ответственной игре доверяют нашим исследованиям.'), language)}</p>
        </div>
        <div className={styles.testimonialDisplay}>
          <blockquote>
            <p>“{getText(testimonials[activeTestimonial].quote, language)}”</p>
            <footer>
              <strong>{testimonials[activeTestimonial].name}</strong>
              <span>{getText(testimonials[activeTestimonial].role, language)}</span>
            </footer>
          </blockquote>
          <div className={styles.testimonialControls}>
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                className={`${styles.dot} ${index === activeTestimonial ? styles.activeDot : ''}`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Show testimonial from ${testimonial.name}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.sectionHeader}>
          <h2>{getText(createText('Recent Analytical Projects', 'Недавние аналитические проекты'), language)}</h2>
          <p>{getText(createText('Internal and partner initiatives that shaped our latest benchmarks.', 'Внутренние и партнёрские проекты, определившие наши свежие бенчмарки.'), language)}</p>
        </div>
        <div className={styles.projectFilters} role="tablist">
          {projectCategories.map((category) => (
            <button
              key={category.key}
              type="button"
              className={`${styles.filterButton} ${projectFilter === category.key ? styles.activeFilter : ''}`}
              onClick={() => setProjectFilter(category.key)}
            >
              {getText(category.label, language)}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <ImageWithLoader
                src={project.image}
                alt={getText(project.title, language)}
                className={styles.projectImage}
              />
              <div className={styles.projectBody}>
                <h3>{getText(project.title, language)}</h3>
                <p>{getText(project.description, language)}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <div className={styles.sectionHeader}>
          <h2>{getText(createText('Frequently Asked Questions', 'Часто задаваемые вопросы'), language)}</h2>
          <p>{getText(createText('Straight answers to the most common queries from our readers.', 'Ответы на наиболее популярные вопросы наших читателей.'), language)}</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <details key={item.question.en} className={styles.faqItem}>
              <summary>{getText(item.question, language)}</summary>
              <p>{getText(item.answer, language)}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.sectionHeader}>
          <h2>{getText(createText('Latest Insights & Guides', 'Свежие исследования и гайды'), language)}</h2>
          <p>{getText(createText('Keep pace with regulations, UX trends, and safer gambling innovations.', 'Следите за регуляторикой, UX-трендами и инновациями ответственной игры.'), language)}</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title.en} className={styles.blogCard}>
              <ImageWithLoader
                src={post.image}
                alt={getText(post.title, language)}
                className={styles.blogImage}
              />
              <div className={styles.blogContent}>
                <span className={styles.blogDate}>{getText(post.date, language)}</span>
                <h3>{getText(post.title, language)}</h3>
                <p>{getText(post.excerpt, language)}</p>
                <a href={post.link} className={styles.cardLink}>
                  {getText(createText('Read insight', 'Читать материал'), language)}
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.newsletter}>
        <div className={styles.sectionHeader}>
          <h2>{getText(newsletterText.title, language)}</h2>
          <p>{getText(newsletterText.subtitle, language)}</p>
        </div>
        <form className={styles.newsletterForm} onSubmit={handleNewsletterSubmit}>
          <label htmlFor="newsletter-email" className="sr-only">Email</label>
          <input
            id="newsletter-email"
            type="email"
            value={newsletterEmail}
            onChange={(event) => setNewsletterEmail(event.target.value)}
            placeholder={getText(newsletterText.placeholder, language)}
            required
          />
          <label className={styles.checkboxLabel}>
            <input
              type="checkbox"
              checked={newsletterConsent}
              onChange={(event) => setNewsletterConsent(event.target.checked)}
            />
            <span>{getText(newsletterText.consent, language)}</span>
          </label>
          <button type="submit" className={styles.primaryButton}>
            {getText(newsletterText.button, language)}
          </button>
        </form>
        {newsletterStatus && (
          <p className={newsletterStatus.type === 'success' ? styles.success : styles.error}>
            {newsletterStatus.message}
          </p>
        )}
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaBody}>
          <h2>{getText(ctaSection.title, language)}</h2>
          <p>{getText(ctaSection.subtitle, language)}</p>
          <Link to="/contact" className={styles.primaryButton}>
            {getText(ctaSection.button, language)}
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;