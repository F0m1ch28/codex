import React, { useState } from 'react';
import styles from './Services.module.css';
import { useLanguage } from '../context/LanguageContext';
import { createText, getText } from '../utils/i18n';

const services = [
  {
    key: 'audits',
    title: createText('Casino Product Audits', 'Аудиты казино-продуктов'),
    description: createText(
      'Full-spectrum evaluation spanning security posture, UX flow, payment clarity, and responsible gaming toolkit.',
      'Полноценная оценка безопасности, пользовательских сценариев, прозрачности платежей и инструментов ответственной игры.'
    ),
    deliverables: [
      createText('46-point benchmark report', '46-пунктный бенчмарк-отчёт'),
      createText('Action-ready UX wireframes', 'UX-wireframe c готовыми действиями'),
      createText('Regulatory compliance heatmap', 'Тепловая карта комплаенса')
    ]
  },
  {
    key: 'workshops',
    title: createText('Responsible Play Workshops', 'Воркшопы по ответственной игре'),
    description: createText(
      'Interactive workshops for product, marketing, and support teams on implementing meaningful guardrails.',
      'Интерактивные воркшопы для продуктовых, маркетинговых и support-команд по реализации эффективных ограничений.'
    ),
    deliverables: [
      createText('Onsite or remote sessions', 'Очные или дистанционные сессии'),
      createText('Custom limit-setting frameworks', 'Индивидуальные схемы лимитов'),
      createText('KPI alignment playbooks', 'Playbook по выравниванию KPI')
    ]
  },
  {
    key: 'intelligence',
    title: createText('Competitive Intelligence', 'Конкурентная аналитика'),
    description: createText(
      'Quarterly scanning of CIS and global platforms with highlights on innovation, regulation, and player sentiment.',
      'Квартальный обзор платформ СНГ и мира с акцентом на инновации, регуляторку и мнение игроков.'
    ),
    deliverables: [
      createText('Trend dashboards', 'Дашборды трендов'),
      createText('Executive briefings', 'Брифинги для руководства'),
      createText('Opportunity roadmaps', 'Дорожные карты возможностей')
    ]
  }
];

const benefits = [
  {
    title: createText('Tailored for CIS Markets', 'Адаптировано для рынка СНГ'),
    detail: createText(
      'Insights tuned to local regulations, payment culture, and player expectations.',
      'Инсайты с учётом местных регуляций, платёжной культуры и ожиданий игроков.'
    )
  },
  {
    title: createText('Multidisciplinary Experts', 'Междисциплинарная команда'),
    detail: createText(
      'Compliance, data science, and player advocacy within one aligned team.',
      'Комплаенс, аналитика и защита игроков в одной слаженной команде.'
    )
  },
  {
    title: createText('Actionable Deliverables', 'Практические результаты'),
    detail: createText(
      'We deliver ready-to-implement recommendations, not just scorecards.',
      'Мы предоставляем готовые к внедрению рекомендации, а не только отчёты с оценками.'
    )
  }
];

const Services = () => {
  const { language } = useLanguage();
  const [activeService, setActiveService] = useState(services[0].key);

  const currentService = services.find((service) => service.key === activeService);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <h1>{getText(createText('Strategic Services for Gambling Operators & Innovators', 'Стратегические услуги для операторов и инноваторов азартной индустрии'), language)}</h1>
        <p>{getText(createText('From deep-dive audits to bespoke workshops, we help teams elevate responsibility, UX, and compliance.', 'От глубоких аудитов до индивидуальных воркшопов — помогаем командам повышать ответственность, UX и соответствие требованиям.'), language)}</p>
      </section>

      <section className={styles.selector}>
        <div className={styles.selectorButtons}>
          {services.map((service) => (
            <button
              key={service.key}
              type="button"
              onClick={() => setActiveService(service.key)}
              className={`${styles.selectorButton} ${activeService === service.key ? styles.active : ''}`}
            >
              {getText(service.title, language)}
            </button>
          ))}
        </div>
        <article className={styles.serviceDetail}>
          <h2>{getText(currentService.title, language)}</h2>
          <p>{getText(currentService.description, language)}</p>
          <h3>{getText(createText('Deliverables', 'Результаты работы'), language)}</h3>
          <ul>
            {currentService.deliverables.map((item) => (
              <li key={item.en}>{getText(item, language)}</li>
            ))}
          </ul>
        </article>
      </section>

      <section className={styles.benefits}>
        <h2>{getText(createText('Why Teams Partner With Us', 'Почему выбирают нас'), language)}</h2>
        <div className={styles.benefitGrid}>
          {benefits.map((benefit) => (
            <div key={benefit.title.en} className={styles.benefitCard}>
              <h3>{getText(benefit.title, language)}</h3>
              <p>{getText(benefit.detail, language)}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <h2>{getText(createText('Let’s Design Your Next Audit or Workshop', 'Давайте спланируем ваш следующий аудит или воркшоп'), language)}</h2>
        <p>{getText(createText('Share your objectives and we will assemble the right team of specialists within 48 hours.', 'Расскажите о целях — мы соберём нужную команду специалистов в течение 48 часов.'), language)}</p>
        <a className={styles.primaryButton} href="/contact">
          {getText(createText('Request a Consultation', 'Запросить консультацию'), language)}
        </a>
      </section>
    </div>
  );
};

export default Services;