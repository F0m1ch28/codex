document.addEventListener('DOMContentLoaded', function () {
  const header = document.querySelector('.site-header');
  if (header) {
    const navToggle = header.querySelector('.nav-toggle');
    const nav = header.querySelector('.primary-nav');
    if (navToggle && nav) {
      navToggle.addEventListener('click', function () {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        nav.classList.toggle('open', !expanded);
      });
      nav.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          if (window.innerWidth < 900) {
            nav.classList.remove('open');
            navToggle.setAttribute('aria-expanded', 'false');
          }
        });
      });
      window.addEventListener('resize', function () {
        if (window.innerWidth >= 900) {
          nav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    }
  }

  const year = new Date().getFullYear();
  document.querySelectorAll('.current-year').forEach(function (el) {
    el.textContent = year;
  });

  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const cookieDecline = document.getElementById('cookie-decline');
  const cookieKey = 'hhmCookieConsent';
  if (cookieBanner && cookieAccept && cookieDecline) {
    const stored = localStorage.getItem(cookieKey);
    if (!stored) {
      cookieBanner.classList.add('active');
    }
    const handleChoice = function (value) {
      localStorage.setItem(cookieKey, value);
      cookieBanner.classList.remove('active');
    };
    cookieAccept.addEventListener('click', function () {
      handleChoice('accepted');
    });
    cookieDecline.addEventListener('click', function () {
      handleChoice('declined');
    });
  }

  const fadeElements = document.querySelectorAll('.fade-in');
  if (fadeElements.length > 0) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    fadeElements.forEach(function (element) {
      observer.observe(element);
    });
  }

  const toast = document.getElementById('global-toast');
  const showToast = function (message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('visible');
    setTimeout(function () {
      toast.classList.remove('visible');
    }, 2600);
  };

  const forms = document.querySelectorAll('form[data-hhm-form]');
  forms.forEach(function (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const action = form.getAttribute('action') || 'thank-you.html';
      showToast('Submission received. Redirecting...');
      setTimeout(function () {
        window.location.href = action;
      }, 1200);
    });
  });
});