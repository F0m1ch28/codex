import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.grid}`}>
      <div className={styles.brand}>
        <h3>GreenTech Solutions</h3>
        <p>Ihr Münchner Partner für maßgeschneiderte Solarlösungen in ganz Bayern.</p>
        <div className={styles.contactInfo}>
          <a href="tel:+498912345678" aria-label="Telefonnummer GreenTech Solutions">
            +49 89 12345678
          </a>
          <a href="mailto:info@greentech-solutions.de" aria-label="E-Mail an GreenTech Solutions">
            info@greentech-solutions.de
          </a>
        </div>
      </div>
      <div className={styles.column}>
        <h4>Navigation</h4>
        <ul>
          <li>
            <Link to="/">Startseite</Link>
          </li>
          <li>
            <Link to="/ueber-uns">Über Uns</Link>
          </li>
          <li>
            <Link to="/leistungen">Leistungen</Link>
          </li>
          <li>
            <Link to="/projekte">Projekte</Link>
          </li>
          <li>
            <Link to="/kontakt">Kontakt</Link>
          </li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Rechtliches</h4>
        <ul>
          <li>
            <Link to="/nutzungsbedingungen">Nutzungsbedingungen</Link>
          </li>
          <li>
            <Link to="/datenschutz">Datenschutzerklärung</Link>
          </li>
          <li>
            <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>
          </li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Büro</h4>
        <address>
          Musterstraße 123
          <br />
          80331 München
          <br />
          Deutschland
        </address>
        <p className={styles.officeHours}>
          Mo–Fr: 08:00–18:00 Uhr
          <br />
          Sa: 09:00–14:00 Uhr
        </p>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} GreenTech Solutions. Alle Rechte vorbehalten.</p>
    </div>
  </footer>
);

export default Footer;