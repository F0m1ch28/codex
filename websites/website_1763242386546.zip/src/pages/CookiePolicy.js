import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from '../styles/Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie | GreenTech Solutions</title>
      <meta
        name="description"
        content="Cookie-Richtlinie von GreenTech Solutions. Erfahren Sie, welche Cookies wir einsetzen und wie Sie Ihre Einwilligung verwalten."
      />
      <link rel="canonical" href="https://www.greentech-solutions.de/cookie-richtlinie" />
    </Helmet>

    <section className={styles.wrapper}>
      <div className="container">
        <div className={styles.header}>
          <h1>Cookie-Richtlinie</h1>
          <p>
            In dieser Richtlinie erklären wir, welche Cookies wir einsetzen, zu welchen Zwecken und wie Sie Ihre
            Einwilligung verwalten können.
          </p>
        </div>

        <article className={styles.section}>
          <h2>1. Was sind Cookies?</h2>
          <p>
            Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden. Sie helfen dabei, unsere Website
            nutzerfreundlich und effizient zu gestalten.
          </p>
        </article>

        <article className={styles.section}>
          <h2>2. Einsatz von Cookies</h2>
          <ul>
            <li>
              <strong>Essenziell:</strong> Notwendig, damit zentrale Funktionen wie das Cookie-Banner oder Formulare
              korrekt arbeiten.
            </li>
            <li>
              <strong>Statistik (optional):</strong> Dienen der Analyse des Nutzerverhaltens, um unser Angebot zu
              verbessern. Wir setzen diese Cookies nur mit Ihrer Einwilligung ein.
            </li>
          </ul>
        </article>

        <article className={styles.section}>
          <h2>3. Verwaltung Ihrer Einwilligung</h2>
          <p>
            Sie können Ihre Cookie-Einstellungen jederzeit über das Banner am unteren Bildschirmrand anpassen. Bereits
            gesetzte Cookies können Sie in Ihrem Browser löschen.
          </p>
        </article>

        <article className={styles.section}>
          <h2>4. Speicherdauer</h2>
          <p>
            Essenzielle Cookies laufen in der Regel nach spätestens 12 Monaten ab. Analyse-Cookies werden spätestens nach
            6 Monaten gelöscht, sofern Sie nicht zuvor Ihre Einwilligung widerrufen.
          </p>
        </article>

        <article className={styles.section}>
          <h2>5. Kontakt</h2>
          <p>
            Bei Fragen rund um den Einsatz von Cookies wenden Sie sich an{' '}
            <a href="mailto:datenschutz@greentech-solutions.de">datenschutz@greentech-solutions.de</a>.
          </p>
        </article>

        <div className={styles.notice}>
          <p>Stand: März 2024. Zukünftige Anpassungen werden an dieser Stelle veröffentlicht.</p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicy;