```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import { useLanguage } from "../contexts/LanguageContext";

const Cookies = () => {
  const { t } = useLanguage();

  return (
    <>
      <Helmet>
        <title>Cookies Policy | Tu Progreso Hoy</title>
      </Helmet>
      <section className="legal-page">
        <h1>{t("Cookies Policy", "Política de Cookies")}</h1>
        <p>
          {t(
            "Tu Progreso Hoy uses cookies to personalise content, remember preferences, and understand engagement.",
            "Tu Progreso Hoy utiliza cookies para personalizar contenido, recordar preferencias y comprender el engagement."
          )}
        </p>
        <h2>{t("Types of Cookies", "Tipos de cookies")}</h2>
        <ul>
          <li>{t("Necessary: essential for site functionality.", "Necesarias: esenciales para el funcionamiento.")}</li>
          <li>{t("Analytics: optional insights on usage patterns.", "Analíticas: opcionales para patrones de uso.")}</li>
          <li>{t("Marketing: optional, used for storytelling campaigns.", "Marketing: opcionales para campañas de storytelling.")}</li>
        </ul>
        <h2>{t("Managing Preferences", "Gestión de preferencias")}</h2>
        <p>
          {t(
            "Use the cookie banner to opt in or out of non-essential cookies. Preferences can be updated anytime via your browser settings.",
            "Utiliza el banner de cookies para optar o no por cookies no esenciales. Puedes actualizar la configuración desde tu navegador."
          )}
        </p>
      </section>
    </>
  );
};

export default Cookies;
```

---