```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import { useLanguage } from "../contexts/LanguageContext";

const Terms = () => {
  const { t } = useLanguage();

  return (
    <>
      <Helmet>
        <title>Terms of Use | Tu Progreso Hoy</title>
      </Helmet>
      <section className="legal-page">
        <h1>{t("Terms of Use", "Términos de uso")}</h1>
        <p>
          {t(
            "By accessing Tu Progreso Hoy, you agree to responsible use of our educational content and data insights.",
            "Al acceder a Tu Progreso Hoy aceptas el uso responsable de nuestro contenido educativo e insights de datos."
          )}
        </p>
        <h2>{t("Educational Purpose", "Propósito educativo")}</h2>
        <p>
          {t(
            "Tu Progreso Hoy is an educational platform. Content aims to inform and empower but does not replace personalized financial advice.",
            "Tu Progreso Hoy es una plataforma educativa. El contenido busca informar y empoderar pero no reemplaza asesoría financiera personalizada."
          )}
        </p>
        <h2>{t("User Conduct", "Conducta del usuario")}</h2>
        <p>
          {t(
            "Users must not misrepresent data, duplicate proprietary content, or use the platform for unlawful purposes.",
            "Los usuarios no deben tergiversar datos, duplicar contenido propietario ni usar la plataforma de forma ilícita."
          )}
        </p>
        <h2>{t("Liability", "Responsabilidad")}</h2>
        <p>
          {t(
            "Tu Progreso Hoy is not liable for decisions made solely on our educational materials.",
            "Tu Progreso Hoy no es responsable por decisiones basadas únicamente en nuestro material educativo."
          )}
        </p>
      </section>
    </>
  );
};

export default Terms;
```

---