```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import { useLanguage } from "../contexts/LanguageContext";

const Privacy = () => {
  const { t } = useLanguage();

  return (
    <>
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
      </Helmet>
      <section className="legal-page">
        <h1>{t("Privacy Policy", "Política de privacidad")}</h1>
        <p>
          {t(
            "Tu Progreso Hoy values your privacy. This policy explains the data we collect, how we process it, and your rights under Argentine law.",
            "Tu Progreso Hoy valora tu privacidad. Esta política explica los datos que recolectamos, cómo los procesamos y tus derechos bajo la ley argentina."
          )}
        </p>
        <h2>{t("Data Collection", "Recolección de datos")}</h2>
        <p>
          {t(
            "We collect contact information when you opt into newsletters, courses, or contact forms. Analytics data is collected only if you consent via the cookie banner.",
            "Recolectamos información de contacto cuando te anotas al newsletter, cursos o formularios. Los datos analíticos se obtienen solo con tu consentimiento mediante el banner de cookies."
          )}
        </p>
        <h2>{t("Use of Data", "Uso de datos")}</h2>
        <p>
          {t(
            "Data supports communication about course updates, inflation insights, and community announcements. We do not sell or rent personal data.",
            "Los datos se usan para comunicar actualizaciones del curso, insights de inflación y anuncios comunitarios. No vendemos ni alquilamos información personal."
          )}
        </p>
        <h2>{t("Your Rights", "Tus derechos")}</h2>
        <p>
          {t(
            "You can access, rectify, or delete your data by contacting hola@tuprogresohoy.com. We answer requests within 5 business days.",
            "Puedes acceder, rectificar o eliminar tus datos escribiendo a hola@tuprogresohoy.com. Respondemos en un máximo de 5 días hábiles."
          )}
        </p>
      </section>
    </>
  );
};

export default Privacy;
```

---