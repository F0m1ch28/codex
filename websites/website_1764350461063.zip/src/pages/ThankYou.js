```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import { useLanguage } from "../contexts/LanguageContext";
import { Link } from "react-router-dom";

const ThankYou = () => {
  const { t } = useLanguage();

  return (
    <>
      <Helmet>
        <title>Thank You | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Confirmation for Tu Progreso Hoy subscriptions and inquiries."
        />
      </Helmet>
      <section className="thankyou-section">
        <div className="thankyou-card">
          <h1>{t("Thank you!", "¡Gracias!")}</h1>
          <p>
            {t(
              "Please check your inbox to confirm your email. Once confirmed, you'll receive updates, insights, or trial details within 24 hours.",
              "Revisa tu bandeja de entrada para confirmar tu correo. Una vez confirmado, recibirás actualizaciones, insights o detalles del trial en 24 horas."
            )}
          </p>
          <Link to="/" className="primary-button">
            {t("Return to homepage", "Volver al inicio")}
          </Link>
          <Link to="/resources" className="secondary-button">
            {t("Browse latest resources", "Explorar recursos recientes")}
          </Link>
        </div>
      </section>
    </>
  );
};

export default ThankYou;
```

---