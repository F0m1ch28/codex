```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import { ParallaxBanner } from "react-scroll-parallax";
import { motion } from "framer-motion";
import TrackerCard from "../components/TrackerCard";
import ProgressBadge from "../components/ProgressBadge";
import { useLanguage } from "../contexts/LanguageContext";
import { heroPromises, timelineData, courseOutline } from "../data/companyData";
import { Link } from "react-router-dom";

const Home = () => {
  const { t } = useLanguage();

  return (
    <>
      <Helmet>
        <title>Tu Progreso Hoy | Argentina Inflation Intelligence & Course</title>
        <meta
          name="description"
          content="Datos verificados para planificar tu presupuesto. De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
        />
      </Helmet>

      <section className="hero-section" aria-labelledby="hero-heading">
        <ParallaxBanner
          layers={[
            { image: "/images/argentina-flag-layer.png", speed: -20 },
            { image: "/images/data-grid-layer.png", speed: -10 },
            {
              amount: 0.3,
              children: (
                <div className="hero-gradient" aria-hidden="true">
                  <div className="floating-particles">
                    {Array.from({ length: 24 }).map((_, index) => (
                      <span key={index} style={{ animationDelay: `${index * 0.4}s` }} />
                    ))}
                  </div>
                </div>
              )
            }
          ]}
          className="hero-parallax"
        >
          <div className="hero-content">
            <motion.h1
              id="hero-heading"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              Tu Progreso Hoy
            </motion.h1>
            <motion.p
              className="hero-subtitle"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              {t(
                "Datos verificados para planificar tu presupuesto.",
                "Datos verificados para planificar tu presupuesto."
              )}
            </motion.p>
            <motion.p
              className="hero-description"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              {t(
                "Conocimiento financiero impulsado por tendencias. De la información al aprendizaje: fortalece tu criterio financiero paso a paso.",
                "Conocimiento financiero impulsado por tendencias. De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
              )}
            </motion.p>
            <motion.div
              className="hero-cta"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
            >
              <Link to="/course" className="primary-button">
                {t("Explore the Starter Course", "Explorar el curso inicial")}
              </Link>
              <Link to="/inflation" className="secondary-button">
                {t("Review Inflation Methodology", "Revisar metodología")}
              </Link>
            </motion.div>
          </div>
        </ParallaxBanner>
        <div className="hero-tracker">
          <TrackerCard />
        </div>
      </section>

      <section className="promise-grid" aria-label={t("Key promises", "Promesas clave")}>
        {heroPromises.map((promise, idx) => (
          <motion.article
            key={idx}
            className="promise-card"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: idx * 0.1 }}
          >
            <h3>{t(promise.title_en, promise.title_es)}</h3>
            <p>{t(promise.description_en, promise.description_es)}</p>
            <div className="card-overlay" aria-hidden="true" />
          </motion.article>
        ))}
      </section>

      <section className="story-section" id="story">
        <motion.div
          className="story-intro"
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <h2>{t("Why Tu Progreso Hoy exists", "Por qué existe Tu Progreso Hoy")}</h2>
          <p>
            {t(
              "We believe clarity breeds confidence. When inflation narratives feel overwhelming, Tu Progreso Hoy provides emotionally intelligent explanations, curated data, and actionable rituals to regain control.",
              "Creemos que la claridad genera confianza. Cuando la narrativa inflacionaria abruma, Tu Progreso Hoy ofrece explicaciones empáticas, datos curados y rituales accionables para retomar el control."
            )}
          </p>
        </motion.div>
        <div className="story-content">
          <motion.div
            className="timeline"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={{
              hidden: { opacity: 0, x: -20 },
              visible: {
                opacity: 1,
                x: 0,
                transition: { staggerChildren: 0.2, delayChildren: 0.2 }
              }
            }}
          >
            <h3>{t("Milestones", "Hitos")}</h3>
            <ul>
              {timelineData.map((item) => (
                <motion.li key={item.year} variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}>
                  <span className="timeline-year">{item.year}</span>
                  <div>
                    <strong>{t(item.label_en, item.label_es)}</strong>
                    <p>{t(item.detail_en, item.detail_es)}</p>
                  </div>
                </motion.li>
              ))}
            </ul>
          </motion.div>
          <motion.div
            className="story-vision"
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h3>{t("Mission & Vision", "Misión y visión")}</h3>
            <p>
              {t(
                "Our mission is to translate complex economic signals into human stories, empowering Argentina to make conscious financial decisions.",
                "Nuestra misión es traducir señales económicas complejas en historias humanas, empoderando a Argentina para decisiones financieras conscientes."
              )}
            </p>
            <p>
              {t(
                "Our vision is a community where inflation awareness, responsible planning, and personal values converge in daily choices.",
                "Nuestra visión es una comunidad donde la conciencia inflacionaria, la planificación responsable y los valores personales convergen en las decisiones diarias."
              )}
            </p>
          </motion.div>
        </div>
      </section>

      <section className="course-preview" id="course-overview">
        <div className="course-header">
          <h2>{t("Course Overview", "Resumen del curso")}</h2>
          <p>
            {t(
              "Information to learning: De la información al aprendizaje: fortalece tu criterio financiero paso a paso.",
              "De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
            )}
          </p>
        </div>
        <div className="course-modules">
          {courseOutline.map((module, idx) => (
            <motion.article
              key={module.module}
              className="module-card"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
            >
              <ProgressBadge
                step={module.module}
                label_en={module.title_en}
                label_es={module.title_es}
                completed={idx < 2}
              />
              <p>{t(module.summary_en, module.summary_es)}</p>
              <Link to="/course" className="text-link">
                {t("Explore module details →", "Conocer detalles del módulo →")}
              </Link>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="insights-dashboard">
        <div className="dashboard-grid">
          <motion.div
            className="insight-card large"
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h3>{t("Daily Momentum", "Momentum diario")}</h3>
            <p>
              {t(
                "We layer macro announcements, historical deviations, and social signals to craft practical daily narratives.",
                "Superponemos anuncios macro, desvíos históricos y señales sociales para crear narrativas prácticas diarias."
              )}
            </p>
            <ul>
              <li>{t("CPI heatmaps with layered insights.", "Heatmaps del IPC con insights escalonados.")}</li>
              <li>{t("ARS sentiment pulse from verified outlets.", "Pulso de sentimiento del ARS de medios verificados.")}</li>
              <li>{t("Budgeting calculators tuned for Argentina.", "Calculadoras de presupuesto calibradas a Argentina.")}</li>
            </ul>
          </motion.div>
          <motion.div
            className="insight-card"
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <h3>{t("Responsible Decisions", "Decisiones responsables")}</h3>
            <p>
              {t(
                "Información confiable que respalda elecciones responsables sobre tu dinero.",
                "Información confiable que respalda elecciones responsables sobre tu dinero."
              )}
            </p>
          </motion.div>
          <motion.div
            className="insight-card"
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <h3>{t("Community Recognition", "Reconocimiento comunitario")}</h3>
            <ul className="badge-list">
              <li>
                <span className="badge-icon" aria-hidden="true">🏅</span>
                {t("Beta testers highlight emotional clarity.", "Beta testers destacan claridad emocional.")}
              </li>
              <li>
                <span className="badge-icon" aria-hidden="true">🎓</span>
                {t("Educators recommend it for first-semester economics.", "Educadores lo recomiendan en primer semestre.")}
              </li>
              <li>
                <span className="badge-icon" aria-hidden="true">🔍</span>
                {t("Analysts cite our weekly ARS insights.", "Analistas citan nuestros insights semanales del ARS.")}
              </li>
            </ul>
          </motion.div>
        </div>
      </section>

      <section className="testimonials" aria-label={t("Testimonials", "Testimonios")}>
        <div className="testimonial-header">
          <h2>{t("Voices from our community", "Voces de nuestra comunidad")}</h2>
          <p>
            {t(
              "Pasos acertados hoy, mejor futuro mañana. Hear from learners who turned anxiety into purposeful planning.",
              "Pasos acertados hoy, mejor futuro mañana. Historias de quienes transformaron la ansiedad en planificación consciente."
            )}
          </p>
        </div>
        <div className="testimonial-grid">
          <article>
            <header>Sofía, 28 – Product Designer</header>
            <p>
              {t(
                "I feared checking the exchange rate. Now, the daily pulses help me decide calmly, even when headlines shout.",
                "Temía revisar el tipo de cambio. Hoy los pulsos diarios me ayudan a decidir con calma aunque los titulares griten."
              )}
            </p>
          </article>
          <article>
            <header>Gonzalo, 42 – Teacher</header>
            <p>
              {t(
                "Seeing data and narratives in Spanish and English helped me grasp the signal behind volatility.",
                "Ver datos y narrativas en ambos idiomas me ayudó a comprender la señal detrás de la volatilidad."
              )}
            </p>
          </article>
          <article>
            <header>Lucía, 35 – Emprendedora</header>
            <p>
              {t(
                "The course modules respect my pace and values. I feel guided without being told what to do.",
                "Los módulos respetan mi ritmo y mis valores. Me siento guiada sin que me digan qué hacer."
              )}
            </p>
          </article>
        </div>
      </section>

      <section className="immersive-journey">
        <div className="journey-visual" role="img" aria-label={t("Customer journey illustration", "Ilustración del journey del cliente")} />
        <div className="journey-steps">
          <h2>{t("Your learning journey", "Tu recorrido de aprendizaje")}</h2>
          <ol>
            <li>
              <strong>{t("Discover", "Descubrir")}</strong>
              <p>
                {t(
                  "Interactive briefings and trackers invite you to reflect on the trends shaping your purchasing power.",
                  "Briefings interactivos y trackers te invitan a reflexionar sobre las tendencias que definen tu poder de compra."
                )}
              </p>
            </li>
            <li>
              <strong>{t("Absorb", "Incorporar")}</strong>
              <p>
                {t(
                  "Micro-lessons, emotional cues, and breezy recaps keep learning gentle yet consistent.",
                  "Microlecciones, señales emocionales y resúmenes ligeros mantienen un aprendizaje suave pero constante."
                )}
              </p>
            </li>
            <li>
              <strong>{t("Transform", "Transformar")}</strong>
              <p>
                {t(
                  "Track progress with gamified badges, celebrate milestones, and translate insight into daily rituals.",
                  "Monitorea tu progreso con insignias gamificadas, celebra hitos y lleva el insight a rituales cotidianos."
                )}
              </p>
            </li>
          </ol>
        </div>
      </section>

      <section className="cta-section" id="cta">
        <div className="cta-inner">
          <h2>{t("Ready to reinterpret Argentina's inflation story?", "¿Listo para reinterpretar la historia inflacionaria de Argentina?")}</h2>
          <p>
            {t(
              "Platforma educativa con datos esenciales, sin asesoría financiera directa.",
              "Plataforma educativa con datos esenciales, sin asesoría financiera directa."
            )}
          </p>
          <form className="cta-form" action="/thank-you">
            <label htmlFor="bottom-name" className="sr-only">
              {t("Name", "Nombre")}
            </label>
            <input
              id="bottom-name"
              name="name"
              type="text"
              placeholder={t("Full name", "Nombre completo")}
              required
            />
            <label htmlFor="bottom-email" className="sr-only">
              {t("Email", "Correo")}
            </label>
            <input
              id="bottom-email"
              name="email"
              type="email"
              placeholder={t("Email address", "Correo electrónico")}
              required
            />
            <button type="submit" className="primary-button large">
              Получить бесплатный пробный урок
            </button>
            <p className="double-opt-text">
              {t(
                "After submitting, check your email to confirm subscription (double opt-in).",
                "Tras enviar, revisa tu correo para confirmar la suscripción (doble opt-in)."
              )}
            </p>
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;
```

---