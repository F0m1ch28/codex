```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { motion } from "framer-motion";
import { useLanguage } from "../contexts/LanguageContext";
import { faqInflation } from "../data/companyData";

const cpiData = [
  { month: "Jan", cpi: 6.7, arsUsd: 358 },
  { month: "Feb", cpi: 7.2, arsUsd: 366 },
  { month: "Mar", cpi: 7.8, arsUsd: 374 },
  { month: "Apr", cpi: 8.1, arsUsd: 382 },
  { month: "May", cpi: 7.4, arsUsd: 388 }
];

const Inflation = () => {
  const { t } = useLanguage();

  return (
    <>
      <Helmet>
        <title>Inflation Insights | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Methodology, CPI/FX context, and FAQs explaining Tu Progreso Hoy's Argentina inflation intelligence."
        />
      </Helmet>

      <section className="page-hero">
        <div className="page-hero-content">
          <h1>{t("Inflation Intelligence Methodology", "Metodología de inteligencia inflacionaria")}</h1>
          <p>
            {t(
              "We blend official CPI releases, high-frequency FX data, and socio-economic narratives to create a cohesive inflation lens.",
              "Combinamos datos oficiales del IPC, información cambiaria de alta frecuencia y narrativas socioeconómicas para crear una lente inflacionaria integral."
            )}
          </p>
        </div>
      </section>

      <section className="methodology-grid">
        <article>
          <h2>{t("Data Verification", "Verificación de datos")}</h2>
          <p>
            {t(
              "Each data source undergoes validation: origin authority, update cadence, and methodological notes. Datasets include BCRA releases, INDEC CPI, IMF forecasts, and curated price trackers.",
              "Cada fuente pasa una validación: autoridad de origen, cadencia de actualización y notas metodológicas. Incluimos datos del BCRA, IPC de INDEC, proyecciones del FMI y trackers de precios curados."
            )}
          </p>
        </article>
        <article>
          <h2>{t("Narrative Layering", "Capa narrativa")}</h2>
          <p>
            {t(
              "We contextualize numbers through stories: policy decisions, consumer sentiment, and everyday implications for Argentines across regions.",
              "Contextualizamos los números con historias: decisiones de política, sentimiento del consumidor e implicancias cotidianas para argentinos en diversas regiones."
            )}
          </p>
        </article>
        <article>
          <h2>{t("Scenario Planning", "Planificación de escenarios")}</h2>
          <p>
            {t(
              "Our scenario canvas compares optimistic, base, and stress paths with probabilities updated every fortnight.",
              "Nuestro canvas de escenarios compara rutas optimistas, base y de estrés con probabilidades actualizadas quincenalmente."
            )}
          </p>
        </article>
      </section>

      <section className="chart-section">
        <h2>{t("CPI vs ARS→USD trend", "Tendencia IPC vs ARS→USD")}</h2>
        <p>
          {t(
            "Overlay CPI monthly change with ARS movement to visualize cross-currents that influence purchasing power.",
            "Superponemos la variación mensual del IPC con el movimiento del ARS para visualizar corrientes cruzadas que impactan tu poder de compra."
          )}
        </p>
        <div className="chart-wrapper" role="img" aria-label={t("Line chart of CPI and ARS trends", "Gráfico de líneas del IPC y tendencia del ARS")}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={cpiData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="month" stroke="#94A3B8" />
              <YAxis
                yAxisId="left"
                stroke="#2563EB"
                tickFormatter={(value) => `${value}%`}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#1F3A6F"
                tickFormatter={(value) => `${value}`}
              />
              <Tooltip
                contentStyle={{ background: "#0F172A", color: "#F8FAFC", borderRadius: "0.75rem" }}
              />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="cpi"
                stroke="#2563EB"
                strokeWidth={3}
                dot={{ r: 5, strokeWidth: 2, fill: "#F8FAFC" }}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="arsUsd"
                stroke="#1F3A6F"
                strokeWidth={3}
                dot={{ r: 5, strokeWidth: 2, fill: "#F8FAFC" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="faq-section">
        <h2>{t("FAQs", "Preguntas frecuentes")}</h2>
        <div className="faq-accordion">
          {faqInflation.map((faq, idx) => (
            <motion.details
              key={faq.question_en}
              className="faq-item"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
            >
              <summary>{t(faq.question_en, faq.question_es)}</summary>
              <p>{t(faq.answer_en, faq.answer_es)}</p>
            </motion.details>
          ))}
        </div>
      </section>

      <section className="cta-slim">
        <h2>{t("Need the human story behind the numbers?", "¿Necesitas la historia humana detrás de los números?")}</h2>
        <p>
          {t(
            "Decisiones responsables, objetivos nítidos. Connect the data to your everyday context inside the course.",
            "Decisiones responsables, objetivos nítidos. Conecta los datos con tu contexto diario dentro del curso."
          )}
        </p>
        <a href="/course" className="primary-button">
          {t("Dive into the Course Modules", "Ir a los módulos del curso")}
        </a>
      </section>
    </>
  );
};

export default Inflation;
```

---