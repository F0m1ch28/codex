```javascript
import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { useLanguage } from "../contexts/LanguageContext";
import { resourceArticles } from "../data/companyData";

const categories = ["All", "Inflation Insight", "Personal Finance", "Glossary", "Case Study"];

const Resources = () => {
  const { t } = useLanguage();
  const [params] = useSearchParams();
  const [activeCategory, setActiveCategory] = useState("All");
  const query = params.get("q")?.toLowerCase() || "";

  const filteredArticles = useMemo(() => {
    return resourceArticles.filter((article) => {
      const matchesCategory =
        activeCategory === "All" || article.category === activeCategory;
      const matchesQuery =
        !query ||
        article.title_en.toLowerCase().includes(query) ||
        article.summary_en.toLowerCase().includes(query) ||
        article.tags.some((tag) => tag.toLowerCase().includes(query));
      return matchesCategory && matchesQuery;
    });
  }, [activeCategory, query]);

  return (
    <>
      <Helmet>
        <title>Resources | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Bilingual articles, glossaries, and case studies on Argentina inflation, ARS→USD, and personal finance rituals."
        />
      </Helmet>

      <section className="page-hero">
        <div className="page-hero-content">
          <h1>{t("Insights & Resources", "Insights y recursos")}</h1>
          <p>
            {t(
              "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.",
              "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera."
            )}
          </p>
        </div>
      </section>

      <section className="resource-filters" aria-label={t("Filter articles", "Filtrar artículos")}>
        <div className="category-toggle">
          {categories.map((category) => (
            <button
              key={category}
              className={category === activeCategory ? "filter-btn active" : "filter-btn"}
              onClick={() => setActiveCategory(category)}
            >
              {t(category, category)}
            </button>
          ))}
        </div>
        {query && (
          <p className="search-result">
            {t("Showing results for", "Mostrando resultados para")} <strong>{query}</strong>
          </p>
        )}
      </section>

      <section className="resource-list">
        {filteredArticles.length === 0 && (
          <div className="empty-state">
            <p>{t("No resources match your filters yet.", "No hay recursos que coincidan con tus filtros aún.")}</p>
          </div>
        )}
        <div className="resource-grid">
          {filteredArticles.map((article, idx) => (
            <motion.article
              key={article.id}
              className="resource-card"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.08, duration: 0.5 }}
            >
              <header>
                <span className="resource-category">{t(article.category, article.category)}</span>
                <span className="reading-time">{article.readingTime} {t("read", "lectura")}</span>
              </header>
              <h3>{t(article.title_en, article.title_es)}</h3>
              <p>{t(article.summary_en, article.summary_es)}</p>
              <div className="resource-tags">
                {article.tags.map((tag) => (
                  <span key={tag} className="tag">
                    #{tag}
                  </span>
                ))}
              </div>
              <a href={`/resources/${article.id}`} className="text-link">
                {t("View full story →", "Ver historia completa →")}
              </a>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="newsletter-block">
        <div className="newsletter-content">
          <h2>{t("Stay informed", "Mantente informado")}</h2>
          <p>
            {t(
              "Receive curated weekly digests summarizing macro shifts, local testimonies, and course highlights.",
              "Recibe resúmenes semanales curados con cambios macro, testimonios locales y lo mejor del curso."
            )}
          </p>
        </div>
        <div className="newsletter-widget">
          <iframe
            title={t("Newsletter preview", "Vista previa del newsletter")}
            src="https://www.youtube.com/embed/7SIR3GhIW8c"
            loading="lazy"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
          <p className="note">
            {t(
              "A quick look at how we transform data into immersive stories.",
              "Una mirada rápida a cómo transformamos datos en historias inmersivas."
            )}
          </p>
        </div>
      </section>
    </>
  );
};

export default Resources;
```

---