```javascript
import React, { useState } from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import { useLanguage } from "../contexts/LanguageContext";

const steps = [
  {
    id: "details",
    title_en: "Your Details",
    title_es: "Tus datos"
  },
  {
    id: "message",
    title_en: "Your Message",
    title_es: "Tu mensaje"
  }
];

const Contact = () => {
  const { t } = useLanguage();
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    topic: "",
    message: ""
  });
  const [submitted, setSubmitted] = useState(false);

  const nextStep = () => setStep((prev) => Math.min(prev + 1, steps.length - 1));
  const prevStep = () => setStep((prev) => Math.max(prev - 1, 0));

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <>
      <Helmet>
        <title>Contact | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Reach Tu Progreso Hoy via contact form, map to Buenos Aires office, and social channels."
        />
      </Helmet>

      <section className="page-hero">
        <div className="page-hero-content">
          <h1>{t("Contact Tu Progreso Hoy", "Contacta a Tu Progreso Hoy")}</h1>
          <p>
            {t(
              "We listen to your story. Share context, questions, or partnership ideas.",
              "Escuchamos tu historia. Comparte contexto, preguntas o ideas de colaboración."
            )}
          </p>
        </div>
      </section>

      <section className="contact-layout">
        <div className="contact-map">
          <iframe
            title={t("Map of Buenos Aires office", "Mapa de la oficina en Buenos Aires")}
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3286.026964479194!2d-58.38155668477064!3d-34.60368406501471!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95a335311ed044a9%3A0x2eee9120de468a1!2sAv.%209%20de%20Julio%201000%2C%20C1043AAO%20CABA%2C%20Argentina!5e0!3m2!1ses!2sar!4v1700000000000"
            allowFullScreen
            loading="lazy"
          />
          <div className="map-overlay">
            <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
            <p>{t("Phone", "Teléfono")}: +54 11 5555-1234</p>
            <p>{t("Email", "Correo")}: hola@tuprogresohoy.com</p>
          </div>
        </div>

        <div className="contact-form-wrapper">
          <div className="form-progress" aria-label={t("Form progress", "Progreso del formulario")}>
            {steps.map((item, idx) => (
              <div key={item.id} className={`progress-step ${idx <= step ? "active" : ""}`}>
                <span className="step-index">{idx + 1}</span>
                <span className="step-label">{t(item.title_en, item.title_es)}</span>
              </div>
            ))}
          </div>

          {submitted ? (
            <div className="submission-message">
              <h2>{t("Thank you for reaching out!", "¡Gracias por contactarnos!")}</h2>
              <p>
                {t(
                  "Our team will respond within two business days. Meanwhile, explore the latest insights on the resources page.",
                  "Nuestro equipo responderá dentro de dos días hábiles. Mientras tanto, explora los últimos insights en Recursos."
                )}
              </p>
            </div>
          ) : (
            <form className="contact-form" onSubmit={handleSubmit}>
              {step === 0 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.4 }}
                >
                  <label htmlFor="name">{t("Full name", "Nombre completo")}</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />

                  <label htmlFor="email">{t("Email address", "Correo electrónico")}</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />

                  <label htmlFor="topic">{t("Topic", "Tema")}</label>
                  <select
                    id="topic"
                    name="topic"
                    value={formData.topic}
                    onChange={handleChange}
                    required
                  >
                    <option value="">{t("Select a topic", "Selecciona un tema")}</option>
                    <option value="course">{t("Course questions", "Preguntas sobre el curso")}</option>
                    <option value="data">{t("Data insights", "Datos e insights")}</option>
                    <option value="partners">{t("Partnerships", "Alianzas")}</option>
                    <option value="media">{t("Media", "Prensa")}</option>
                  </select>

                  <div className="form-navigation">
                    <button type="button" className="primary-button" onClick={nextStep}>
                      {t("Next", "Siguiente")}
                    </button>
                  </div>
                </motion.div>
              )}

              {step === 1 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4 }}
                >
                  <label htmlFor="message">{t("Message", "Mensaje")}</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="5"
                    value={formData.message}
                    onChange={handleChange}
                    required
                  />
                  <div className="form-navigation">
                    <button type="button" className="secondary-button" onClick={prevStep}>
                      {t("Back", "Volver")}
                    </button>
                    <button type="submit" className="primary-button">
                      {t("Submit inquiry", "Enviar consulta")}
                    </button>
                  </div>
                </motion.div>
              )}
            </form>
          )}
        </div>
      </section>

      <section className="contact-social-proof">
        <div>
          <h2>{t("Recent community interactions", "Interacciones recientes de la comunidad")}</h2>
          <ul>
            <li>
              <strong>@Florencia</strong> {t("shared how the budgeting ritual calmed her monthly planning.", "compartió cómo el ritual de presupuesto calmó su planificación mensual.")}
            </li>
            <li>
              <strong>@BancoDelTiempo</strong> {t("referenced our ARS tracker in their latest newsletter.", "referenció nuestro tracker ARS en su último newsletter.")}
            </li>
            <li>
              <strong>@EduFinanzasAR</strong> {t("invited us to discuss responsible inflation narratives.", "nos invitó a discutir narrativas responsables de inflación.")}
            </li>
          </ul>
        </div>
        <div className="live-chat-placeholder">
          <h3>{t("Live chat (beta)", "Chat en vivo (beta)")}</h3>
          <p>
            {t(
              "We're piloting human-assisted chat hours every Thursday. Leave your email to get notified when slots open.",
              "Estamos piloteando un chat asistido los jueves. Deja tu correo para recibir notificación cuando se abran los cupos."
            )}
          </p>
          <form action="/thank-you">
            <label htmlFor="livechat-email" className="sr-only">
              {t("Email", "Correo")}
            </label>
            <input id="livechat-email" name="email" type="email" placeholder="correo@ejemplo.com" required />
            <button type="submit" className="secondary-button">
              {t("Notify me", "Notificarme")}
            </button>
          </form>
        </div>
      </section>
    </>
  );
};

export default Contact;
```

---