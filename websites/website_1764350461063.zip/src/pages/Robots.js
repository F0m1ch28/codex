```javascript
import React from "react";

const Robots = () => {
  const robotsText = `User-agent: *
Allow: /

Sitemap: https://tuprogresohoy.com/sitemap.xml
`;

  return (
    <pre className="robots-output" aria-label="Robots.txt">
      {robotsText}
    </pre>
  );
};

export default Robots;
```

---