```javascript
import React from "react";

const SitemapXml = () => {
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="https://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://tuprogresohoy.com/</loc></url>
  <url><loc>https://tuprogresohoy.com/inflation</loc></url>
  <url><loc>https://tuprogresohoy.com/course</loc></url>
  <url><loc>https://tuprogresohoy.com/resources</loc></url>
  <url><loc>https://tuprogresohoy.com/contact</loc></url>
  <url><loc>https://tuprogresohoy.com/thank-you</loc></url>
  <url><loc>https://tuprogresohoy.com/privacy</loc></url>
  <url><loc>https://tuprogresohoy.com/cookies</loc></url>
  <url><loc>https://tuprogresohoy.com/terms</loc></url>
</urlset>`;

  return (
    <pre className="xml-output" aria-label="Sitemap XML">
      {xml}
    </pre>
  );
};

export default SitemapXml;
```

---