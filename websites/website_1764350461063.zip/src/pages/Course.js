```javascript
import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import { useLanguage } from "../contexts/LanguageContext";
import { courseOutline } from "../data/companyData";

const Course = () => {
  const { t } = useLanguage();

  return (
    <>
      <Helmet>
        <title>Course | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Course syllabus, modules, and target audience for Tu Progreso Hoy's bilingual personal finance starter program."
        />
      </Helmet>

      <section className="page-hero course-hero">
        <div className="course-hero-content">
          <h1>{t("Personal Finance Starter Course", "Curso inicial de finanzas personales")}</h1>
          <p>
            {t(
              "Conocimiento financiero impulsado por tendencias. De la información al aprendizaje: fortalece tu criterio financiero paso a paso.",
              "Conocimiento financiero impulsado por tendencias. De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
            )}
          </p>
        </div>
      </section>

      <section className="course-syllabus">
        <h2>{t("Syllabus Overview", "Resumen del plan de estudios")}</h2>
        <div className="syllabus-grid">
          {courseOutline.map((module, idx) => (
            <motion.article
              key={module.module}
              className="syllabus-card"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
            >
              <span className="module-number">{module.module}</span>
              <h3>{t(module.title_en, module.title_es)}</h3>
              <p>{t(module.summary_en, module.summary_es)}</p>
              <ul>
                <li>{t("Interactive exercises & reflective prompts", "Ejercicios interactivos y prompts reflexivos")}</li>
                <li>{t("Weekly live forums & bilingual recaps", "Foros semanales y resúmenes bilingües")}</li>
                <li>{t("Gamified milestones with progress badges", "Hitos gamificados con insignias de progreso")}</li>
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="course-audience">
        <div>
          <h2>{t("Who is this for?", "¿Para quién es?")}</h2>
          <ul>
            <li>
              {t(
                "Professionals navigating salary adjustments and inflation renegotiations.",
                "Profesionales que renegocian salarios ante la inflación."
              )}
            </li>
            <li>
              {t(
                "Entrepreneurs balancing revenue stability with currency volatility.",
                "Emprendedores equilibrando ingresos con volatilidad cambiaria."
              )}
            </li>
            <li>
              {t(
                "Students building confidence in economics and responsible planning.",
                "Estudiantes que buscan confianza en economía y planificación responsable."
              )}
            </li>
          </ul>
        </div>
        <div className="course-cta-card">
          <h3>{t("Course perks", "Beneficios del curso")}</h3>
          <ul>
            <li>{t("Bi-weekly live Q&A with analysts and educators.", "Q&A quincenal con analistas y educadores.")}</li>
            <li>{t("Downloadable templates and budgeting rituals.", "Plantillas descargables y rituales de presupuesto.")}</li>
            <li>{t("Community check-ins to celebrate responsible decisions.", "Encuentros comunitarios para celebrar decisiones responsables.")}</li>
          </ul>
          <a href="#course-form" className="primary-button">
            {t("Secure your trial lesson", "Asegura tu lección de prueba")}
          </a>
        </div>
      </section>

      <section className="course-progress" id="course-form">
        <div className="progress-intro">
          <h2>{t("Track your transformation", "Sigue tu transformación")}</h2>
          <p>
            {t(
              "Our gamified dashboard rewards consistency. Progress badges reflect skills mastered, from ARS awareness to budgeting rituals.",
              "Nuestro panel gamificado premia la constancia. Las insignias reflejan habilidades dominadas, desde conciencia del ARS hasta rituales de presupuesto."
            )}
          </p>
        </div>
        <div className="progress-badges">
          <div className="badge">
            <span className="badge-level">Level 1</span>
            <strong>{t("Trend Watcher", "Observador de tendencias")}</strong>
            <p>{t("Identifies CPI and FX correlations weekly.", "Identifica correlaciones IPC-FX semanalmente.")}</p>
          </div>
          <div className="badge">
            <span className="badge-level">Level 2</span>
            <strong>{t("Budget Architect", "Arquitecto del presupuesto")}</strong>
            <p>{t("Builds responsive budgets with scenario back-ups.", "Crea presupuestos con escenarios alternos.")}</p>
          </div>
          <div className="badge">
            <span className="badge-level">Level 3</span>
            <strong>{t("Decision Storyteller", "Narrador de decisiones")}</strong>
            <p>{t("Communicates financial choices confidently to peers.", "Comunica decisiones financieras con confianza.")}</p>
          </div>
        </div>
        <form className="course-enroll-form" action="/thank-you" method="get">
          <fieldset>
            <legend>{t("Enroll for the free trial lesson", "Inscríbete a la lección de prueba")}</legend>
            <label htmlFor="full-name">{t("Full name", "Nombre completo")}</label>
            <input id="full-name" name="name" type="text" required />

            <label htmlFor="email">{t("Email", "Correo")}</label>
            <input id="email" name="email" type="email" required />

            <label htmlFor="goal">{t("What do you hope to achieve?", "¿Qué esperas lograr?")}</label>
            <textarea id="goal" name="goal" rows="3" />

            <button type="submit" className="primary-button large">
              Получить бесплатный пробный урок
            </button>
            <p className="double-opt-text">
              {t("Double opt-in applies: confirm through the email we send.", "Aplica doble opt-in: confirma desde el correo que enviamos.")}
            </p>
          </fieldset>
        </form>
      </section>
    </>
  );
};

export default Course;
```

---