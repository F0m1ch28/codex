```javascript
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import DisclaimerModal from "./components/DisclaimerModal";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import Inflation from "./pages/Inflation";
import Course from "./pages/Course";
import Resources from "./pages/Resources";
import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import Privacy from "./pages/Privacy";
import Cookies from "./pages/Cookies";
import Terms from "./pages/Terms";
import SitemapXml from "./pages/SitemapXml";
import Robots from "./pages/Robots";
import { useLanguage } from "./contexts/LanguageContext";

const pageTransition = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
  exit: { opacity: 0, y: -12, transition: { duration: 0.4, ease: "easeIn" } }
};

const App = () => {
  const { language } = useLanguage();

  return (
    <Router>
      <ScrollToTop />
      <div className={`app-shell lang-${language}`}>
        <Header />
        <main id="main-content" className="app-main">
          <AnimatePresence mode="wait">
            <Routes>
              <Route
                path="/"
                element={
                  <motion.div key="home" {...pageTransition}>
                    <Home />
                  </motion.div>
                }
              />
              <Route
                path="/inflation"
                element={
                  <motion.div key="inflation" {...pageTransition}>
                    <Inflation />
                  </motion.div>
                }
              />
              <Route
                path="/course"
                element={
                  <motion.div key="course" {...pageTransition}>
                    <Course />
                  </motion.div>
                }
              />
              <Route
                path="/resources"
                element={
                  <motion.div key="resources" {...pageTransition}>
                    <Resources />
                  </motion.div>
                }
              />
              <Route
                path="/contact"
                element={
                  <motion.div key="contact" {...pageTransition}>
                    <Contact />
                  </motion.div>
                }
              />
              <Route
                path="/thank-you"
                element={
                  <motion.div key="thankyou" {...pageTransition}>
                    <ThankYou />
                  </motion.div>
                }
              />
              <Route
                path="/privacy"
                element={
                  <motion.div key="privacy" {...pageTransition}>
                    <Privacy />
                  </motion.div>
                }
              />
              <Route
                path="/cookies"
                element={
                  <motion.div key="cookies" {...pageTransition}>
                    <Cookies />
                  </motion.div>
                }
              />
              <Route
                path="/terms"
                element={
                  <motion.div key="terms" {...pageTransition}>
                    <Terms />
                  </motion.div>
                }
              />
              <Route path="/sitemap.xml" element={<SitemapXml />} />
              <Route path="/robots.txt" element={<Robots />} />
            </Routes>
          </AnimatePresence>
        </main>
        <Footer />
        <CookieBanner />
        <DisclaimerModal />
      </div>
    </Router>
  );
};

export default App;
```

---