```javascript
import React, { createContext, useContext, useMemo, useState } from "react";

const LanguageContext = createContext();

const LANGUAGE_KEY = "tph_lang";

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(
    () => localStorage.getItem(LANGUAGE_KEY) || "en"
  );

  const switchLanguage = (lang) => {
    setLanguage(lang);
    localStorage.setItem(LANGUAGE_KEY, lang);
    document.documentElement.lang = lang === "es" ? "es" : "en";
  };

  const value = useMemo(
    () => ({
      language,
      switchLanguage,
      t: (enText, esText) => (language === "es" && esText ? esText : enText)
    }),
    [language]
  );

  return (
    <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
```

---