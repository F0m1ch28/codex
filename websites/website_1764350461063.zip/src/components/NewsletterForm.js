```javascript
import React, { useState } from "react";
import useSound from "use-sound";
import { useLanguage } from "../contexts/LanguageContext";

const clickSoundSrc =
  "data:audio/wav;base64,UklGRpwAAABXQVZFZm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YSgAAACAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA=";

const NewsletterForm = () => {
  const { t } = useLanguage();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle"); // idle | sent
  const [play] = useSound(clickSoundSrc, { volume: 0.3 });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) return;
    play();
    setStatus("sent");
  };

  return (
    <div className="newsletter-form">
      {status === "idle" ? (
        <form onSubmit={handleSubmit} aria-label={t("Newsletter signup", "Suscripción a newsletter")}>
          <label htmlFor="newsletter-email" className="sr-only">
            {t("Enter your email", "Ingresa tu correo")}
          </label>
          <input
            id="newsletter-email"
            type="email"
            name="email"
            placeholder={t("Email address", "Correo electrónico")}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
          />
          <button type="submit" className="primary-button">
            {t("Subscribe", "Suscribirse")}
          </button>
        </form>
      ) : (
        <div className="newsletter-confirmation">
          <p>
            {t(
              "Almost there! Check your inbox to confirm and activate your subscription.",
              "¡Casi listo! Revisa tu inbox para confirmar y activar tu suscripción."
            )}
          </p>
          <p className="double-opt">
            {t(
              "Double opt-in ensures your consent and protects your data.",
              "El doble opt-in asegura tu consentimiento y protege tus datos."
            )}
          </p>
        </div>
      )}
    </div>
  );
};

export default NewsletterForm;
```

---