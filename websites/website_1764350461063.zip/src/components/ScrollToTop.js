```javascript
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import useScrollAnimation from "../hooks/useScrollAnimation";

const ScrollToTop = () => {
  const { pathname } = useLocation();
  const scrollProgress = useScrollAnimation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);

  return (
    <motion.div
      className="scroll-progress"
      aria-hidden="true"
      style={{ width: `${scrollProgress}%` }}
    />
  );
};

export default ScrollToTop;
```

---