```javascript
import React from "react";
import { useLanguage } from "../contexts/LanguageContext";

const ProgressBadge = ({ step, label_en, label_es, completed }) => {
  const { t } = useLanguage();
  return (
    <div className={`progress-badge ${completed ? "completed" : ""}`}>
      <span className="step">{step}</span>
      <span className="label">{t(label_en, label_es)}</span>
    </div>
  );
};

export default ProgressBadge;
```

---