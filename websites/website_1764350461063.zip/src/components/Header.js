```javascript
import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { Bars3Icon, XMarkIcon, MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "../contexts/LanguageContext";

const navItems = [
  { to: "/", label_en: "Home", label_es: "Inicio" },
  { to: "/inflation", label_en: "Inflation Intelligence", label_es: "Inteligencia inflación" },
  { to: "/course", label_en: "Course", label_es: "Curso" },
  { to: "/resources", label_en: "Resources", label_es: "Recursos" },
  { to: "/contact", label_en: "Contact", label_es: "Contacto" }
];

const Header = () => {
  const { t, language, switchLanguage } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    navigate(`/resources?q=${encodeURIComponent(query.trim())}`);
    setSearchOpen(false);
    setQuery("");
  };

  return (
    <header className="site-header">
      <div className="header-inner">
        <NavLink to="/" className="brand" aria-label="Tu Progreso Hoy">
          <span className="brand-mark">TPH</span>
          <span className="brand-text">Tu Progreso Hoy</span>
        </NavLink>
        <nav className="desktop-nav" aria-label={t("Primary menu", "Menú principal")}>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                isActive ? "nav-link active" : "nav-link"
              }
            >
              {t(item.label_en, item.label_es)}
            </NavLink>
          ))}
        </nav>
        <div className="header-actions">
          <button
            className="search-button"
            onClick={() => setSearchOpen(true)}
            aria-label={t("Open search", "Abrir búsqueda")}
          >
            <MagnifyingGlassIcon />
          </button>
          <div className="language-toggle" role="group" aria-label="Language selector">
            <button
              className={language === "en" ? "lang-btn active" : "lang-btn"}
              onClick={() => switchLanguage("en")}
              type="button"
            >
              EN
            </button>
            <button
              className={language === "es" ? "lang-btn active" : "lang-btn"}
              onClick={() => switchLanguage("es")}
              type="button"
            >
              ES
            </button>
          </div>
          <button
            className="mobile-menu-btn"
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-label={menuOpen ? t("Close menu", "Cerrar menú") : t("Open menu", "Abrir menú")}
          >
            {menuOpen ? <XMarkIcon /> : <Bars3Icon />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            className="mobile-nav"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.28 }}
          >
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  isActive ? "mobile-nav-link active" : "mobile-nav-link"
                }
                onClick={() => setMenuOpen(false)}
              >
                {t(item.label_en, item.label_es)}
              </NavLink>
            ))}
          </motion.nav>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {searchOpen && (
          <motion.div
            className="search-overlay"
            role="dialog"
            aria-modal="true"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="search-modal"
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
            >
              <button
                className="search-close"
                aria-label={t("Close search", "Cerrar búsqueda")}
                onClick={() => setSearchOpen(false)}
              >
                <XMarkIcon />
              </button>
              <form onSubmit={handleSearch} className="search-form">
                <label htmlFor="site-search" className="sr-only">
                  {t("Search resources", "Buscar recursos")}
                </label>
                <input
                  id="site-search"
                  type="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={t("Search articles, trends, lessons...", "Busca artículos, tendencias, lecciones...")}
                  autoFocus
                />
                <button type="submit" className="primary-button">
                  {t("Search", "Buscar")}
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
```

---