```javascript
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "../contexts/LanguageContext";

const mockData = [
  { date: "2024-03-01", rate: 355.21, change: 0.12 },
  { date: "2024-03-08", rate: 362.87, change: 2.15 },
  { date: "2024-03-15", rate: 371.05, change: 2.26 },
  { date: "2024-03-22", rate: 369.11, change: -0.52 },
  { date: "2024-03-29", rate: 374.88, change: 1.57 }
];

const TrackerCard = () => {
  const { t } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(mockData.length - 1);
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % mockData.length);
      setPulse(true);
      setTimeout(() => setPulse(false), 600);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const { date, rate, change } = mockData[currentIndex];

  return (
    <motion.div
      className={`tracker-card ${pulse ? "pulse" : ""}`}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <header>
        <h3>ARS → USD Tracker</h3>
        <span>{t("Updated", "Actualizado")}: {date}</span>
      </header>
      <div className="rate-display">
        <strong>{rate.toFixed(2)}</strong>
        <span>ARS / USD</span>
      </div>
      <p className={`change ${change >= 0 ? "positive" : "negative"}`}>
        {change >= 0 ? "+" : ""}
        {(change).toFixed(2)}%
        <span>{t("weekly movement", "variación semanal")}</span>
      </p>
      <div className="tracker-footer">
        <p>
          {t(
            "Análisis transparentes y datos de mercado para decidir con seguridad.",
            "Análisis transparentes y datos de mercado para decidir con seguridad."
          )}
        </p>
      </div>
    </motion.div>
  );
};

export default TrackerCard;
```

---