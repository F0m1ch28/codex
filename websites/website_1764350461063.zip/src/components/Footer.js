```javascript
import React from "react";
import { NavLink } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import { siteMeta } from "../data/companyData";
import NewsletterForm from "./NewsletterForm";

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="site-footer">
      <div className="footer-gradient" aria-hidden="true" />
      <div className="footer-inner">
        <div className="footer-brand">
          <span className="brand-mark">TPH</span>
          <p className="footer-tagline">
            {t(
              "Datos verificados para planificar tu presupuesto.",
              "Datos verificados para planificar tu presupuesto."
            )}
          </p>
          <address>
            <strong>{t("Contact", "Contacto")}</strong>
            <span>{siteMeta.contact.address}</span>
            <a href={`tel:${siteMeta.contact.phone.replace(/\s+/g, "")}`}>
              {siteMeta.contact.phone}
            </a>
            <a href={`mailto:${siteMeta.contact.email}`}>
              {siteMeta.contact.email}
            </a>
          </address>
        </div>

        <div className="footer-links">
          <div>
            <h4>{t("Platform", "Plataforma")}</h4>
            <NavLink to="/inflation">{t("Inflation Intelligence", "Inteligencia inflación")}</NavLink>
            <NavLink to="/course">{t("Course Overview", "Resumen del curso")}</NavLink>
            <NavLink to="/resources">{t("Resources", "Recursos")}</NavLink>
            <NavLink to="/contact">{t("Contact", "Contacto")}</NavLink>
          </div>
          <div>
            <h4>{t("Policies", "Políticas")}</h4>
            <NavLink to="/privacy">{t("Privacy Policy", "Política de Privacidad")}</NavLink>
            <NavLink to="/cookies">{t("Cookies Policy", "Política de Cookies")}</NavLink>
            <NavLink to="/terms">{t("Terms of Use", "Términos de Uso")}</NavLink>
            <a href="/sitemap.xml">{t("Sitemap", "Mapa del sitio")}</a>
          </div>
          <div>
            <h4>{t("Follow", "Seguir")}</h4>
            {siteMeta.social.map((link) => (
              <a key={link.label} href={link.url} target="_blank" rel="noreferrer">
                {link.label}
              </a>
            ))}
          </div>
        </div>

        <div className="footer-newsletter">
          <h4>{t("Stay in sync", "Mantente al día")}</h4>
          <p>
            {t(
              "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.",
              "Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera."
            )}
          </p>
          <NewsletterForm />
          <small>
            {t(
              "We practice double opt-in to ensure you genuinely want to receive insights.",
              "Utilizamos doble opt-in para asegurar que realmente desees recibir insights."
            )}
          </small>
        </div>
      </div>
      <div className="footer-bottom">
        <p>
          &copy; {new Date().getFullYear()} Tu Progreso Hoy. {t("All rights reserved.", "Todos los derechos reservados.")}
        </p>
      </div>
    </footer>
  );
};

export default Footer;
```

---