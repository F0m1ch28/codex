```javascript
import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "../contexts/LanguageContext";

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const timer = setTimeout(() => setOpen(true), 1600);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="disclaimer-overlay"
          role="alertdialog"
          aria-modal="true"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="disclaimer-modal"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 30, opacity: 0 }}
          >
            <h3>{t("Important Disclaimer", "Aviso importante")}</h3>
            <p>Мы не предоставляем финансовые услуги.</p>
            <p>We do not provide financial services.</p>
            <p>
              {t(
                "Información confiable que respalda elecciones responsables sobre tu dinero.",
                "Información confiable que respalda elecciones responsables sobre tu dinero."
              )}
            </p>
            <button className="primary-button" onClick={() => setOpen(false)}>
              {t("Understood", "Entendido")}
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DisclaimerModal;
```

---