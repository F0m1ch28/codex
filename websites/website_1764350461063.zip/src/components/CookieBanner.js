```javascript
import React, { useEffect, useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";

const COOKIE_KEY = "tph_cookie_consent";

const CookieBanner = () => {
  const { t } = useLanguage();
  const [visible, setVisible] = useState(false);
  const [preferences, setPreferences] = useState({
    necessary: true,
    analytics: false,
    marketing: false
  });

  useEffect(() => {
    const stored = localStorage.getItem(COOKIE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const savePreferences = (custom = false) => {
    localStorage.setItem(
      COOKIE_KEY,
      JSON.stringify(custom ? preferences : { necessary: true, analytics: true, marketing: true })
    );
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-modal="true">
      <div className="cookie-inner">
        <h3>{t("Cookies & Privacy Preferences", "Preferencias de cookies y privacidad")}</h3>
        <p>
          {t(
            "We use cookies to improve your learning experience. Adjust your preferences or accept all.",
            "Utilizamos cookies para mejorar tu experiencia de aprendizaje. Ajusta tus preferencias o acepta todas."
          )}
        </p>
        <div className="cookie-options">
          <label className="cookie-checkbox">
            <input type="checkbox" checked readOnly />
            <span>{t("Necessary (always on)", "Necesarias (siempre activas)")}</span>
          </label>
          <label className="cookie-checkbox">
            <input
              type="checkbox"
              checked={preferences.analytics}
              onChange={(e) =>
                setPreferences((prev) => ({ ...prev, analytics: e.target.checked }))
              }
            />
            <span>{t("Analytics insights", "Analítica para insights")}</span>
          </label>
          <label className="cookie-checkbox">
            <input
              type="checkbox"
              checked={preferences.marketing}
              onChange={(e) =>
                setPreferences((prev) => ({ ...prev, marketing: e.target.checked }))
              }
            />
            <span>{t("Marketing storytelling", "Storytelling de marketing")}</span>
          </label>
        </div>
        <div className="cookie-actions">
          <button className="secondary-button" onClick={() => savePreferences(true)}>
            {t("Save preferences", "Guardar preferencias")}
          </button>
          <button className="primary-button" onClick={() => savePreferences(false)}>
            {t("Accept all cookies", "Aceptar todas las cookies")}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
```

---