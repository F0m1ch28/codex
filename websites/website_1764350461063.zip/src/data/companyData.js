```javascript
export const siteMeta = {
  name: "Tu Progreso Hoy",
  slogan: "Datos verificados para planificar tu presupuesto.",
  description:
    "A bilingual educational SaaS for Argentina-based individuals seeking clarity on inflation trends and foundational personal finance.",
  keywords: [
    "argentina inflation",
    "ars usd",
    "finanzas personales",
    "budgeting argentina",
    "curso finanzas",
    "economic trends",
    "datos confiables"
  ],
  contact: {
    address: "Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina",
    phone: "+54 11 5555-1234",
    email: "hola@tuprogresohoy.com"
  },
  social: [
    {
      label: "LinkedIn",
      url: "https://www.linkedin.com/company/tu-progreso-hoy"
    },
    {
      label: "Twitter",
      url: "https://www.twitter.com/tuprogresohoy"
    },
    {
      label: "YouTube",
      url: "https://www.youtube.com/@tuprogresohoy"
    }
  ]
};

export const heroPromises = [
  {
    title_en: "Conocimiento financiero impulsado por tendencias.",
    title_es: "Conocimiento financiero impulsado por tendencias.",
    description_en:
      "We decode Argentina's inflation and ARS→USD shifts with storytelling dashboards, transparent data, and context-rich briefings.",
    description_es:
      "Interpretamos la inflación argentina y los movimientos ARS→USD con paneles narrativos, datos transparentes y briefs llenos de contexto."
  },
  {
    title_en: "Decisiones responsables, objetivos nítidos.",
    title_es: "Decisiones responsables, objetivos nítidos.",
    description_en:
      "Step-by-step learning journeys combine data, exercises, and local case studies to build clarity without overwhelming jargon.",
    description_es:
      "Recorridos de aprendizaje paso a paso con datos, prácticas y casos locales para construir claridad sin jerga abrumadora."
  },
  {
    title_en: "Pasos acertados hoy, mejor futuro mañana.",
    title_es: "Pasos acertados hoy, mejor futuro mañana.",
    description_en:
      "Track, digest, and act on market signals to design budgets that respect your goals and the Argentine context.",
    description_es:
      "Registra, comprende y actúa según las señales del mercado para diseñar presupuestos alineados a tus metas y al contexto argentino."
  }
];

export const timelineData = [
  {
    year: "2018",
    label_en: "Initial research on ARS volatility",
    label_es: "Investigación inicial sobre volatilidad del ARS",
    detail_en:
      "Our founders interviewed 120 Argentines to understand daily budgeting challenges amid inflation.",
    detail_es:
      "Realizamos entrevistas con 120 argentinos para comprender el día a día financiero bajo la inflación."
  },
  {
    year: "2020",
    label_en: "First prototype testing",
    label_es: "Primer prototipo en pruebas",
    detail_en:
      "Beta dashboards launched with focus groups in Buenos Aires, Rosario, and Córdoba.",
    detail_es:
      "Lanzamos dashboards beta con grupos focales en Buenos Aires, Rosario y Córdoba."
  },
  {
    year: "2022",
    label_en: "Course curriculum crafted",
    label_es: "Currícula del curso diseñada",
    detail_en:
      "Financial educators and economists co-created a bilingual starter course tailored for Argentina.",
    detail_es:
      "Educadores financieros y economistas co-crearon un curso bilingüe adaptado a Argentina."
  },
  {
    year: "2024",
    label_en: "Tu Progreso Hoy platform launch",
    label_es: "Lanzamiento de la plataforma Tu Progreso Hoy",
    detail_en:
      "Integrated inflation intelligence, experiential learning, and community-powered planning tools.",
    detail_es:
      "Integramos inteligencia de inflación, aprendizaje vivencial y herramientas colaborativas de planificación."
  }
];

export const courseOutline = [
  {
    module: "Module 1",
    title_en: "Understanding Argentina's Inflation DNA",
    title_es: "Comprender el ADN de la inflación argentina",
    summary_en:
      "Decode CPI components, exchange rate regimes, and structural insights with interactive maps and simulations.",
    summary_es:
      "Descifra componentes del IPC, regímenes cambiarios e insights estructurales con mapas y simulaciones."
  },
  {
    module: "Module 2",
    title_en: "ARS→USD Trackers & Safety Nets",
    title_es: "Trackers ARS→USD y redes de seguridad",
    summary_en:
      "Build dashboards, interpret spreads, and evaluate official vs. blue rate scenarios responsibly.",
    summary_es:
      "Construye tableros, interpreta spreads y evalúa escenarios oficial vs. blue de manera responsable."
  },
  {
    module: "Module 3",
    title_en: "Personal Budgeting Rituals",
    title_es: "Rituales de budgeting personal",
    summary_en:
      "Design your own cash-flow ecosystem with local case studies, savings habits, and adaptive frameworks.",
    summary_es:
      "Diseña un ecosistema de flujo de caja con casos locales, hábitos de ahorro y marcos adaptativos."
  },
  {
    module: "Module 4",
    title_en: "From Insight to Action",
    title_es: "Del insight a la acción",
    summary_en:
      "Translate trends into step-by-step decisions while honoring your values and risk tolerance.",
    summary_es:
      "Convierte tendencias en decisiones paso a paso respetando tus valores y tolerancia al riesgo."
  }
];

export const resourceArticles = [
  {
    id: "trend-brief-jan-2024",
    category: "Inflation Insight",
    title_en: "January 2024 CPI vs. ARS Trajectory",
    title_es: "CPI de enero 2024 frente a la trayectoria del ARS",
    summary_en:
      "Comparative analysis of inflation baskets, wage negotiations, and forward-looking indicators.",
    summary_es:
      "Análisis comparativo de canastas de inflación, paritarias e indicadores prospectivos.",
    readingTime: "6 min",
    tags: ["argentina inflation", "economic trends"]
  },
  {
    id: "glossary-ars",
    category: "Glossary",
    title_en: "Glossary: ARS & FX Essentials",
    title_es: "Glosario: esenciales del ARS y FX",
    summary_en:
      "Bilingual definitions for common FX terms, parallel rates, and inflation-linked instruments in Argentina.",
    summary_es:
      "Definiciones bilingües sobre términos FX, tipos de cambio paralelos e instrumentos indexados en Argentina.",
    readingTime: "8 min",
    tags: ["ars usd", "datos confiables"]
  },
  {
    id: "budgeting-rituals",
    category: "Personal Finance",
    title_en: "Three Budgeting Rituals for Volatile Months",
    title_es: "Tres rituales de budgeting para meses volátiles",
    summary_en:
      "How to keep discipline when the peso shifts daily, with templates and accountability cues.",
    summary_es:
      "Cómo sostener la disciplina cuando el peso se mueve a diario, con plantillas y recordatorios.",
    readingTime: "7 min",
    tags: ["finanzas personales", "budgeting argentina"]
  },
  {
    id: "case-study-sophia",
    category: "Case Study",
    title_en: "Sophia's Path: From Overwhelm to Clarity",
    title_es: "El camino de Sofía: del agobio a la claridad",
    summary_en:
      "A 28-year-old designer reorganizes her earnings and emergency fund with Tu Progreso Hoy trackers.",
    summary_es:
      "Una diseñadora de 28 reorganiza ingresos y fondo de emergencia con los trackers de Tu Progreso Hoy.",
    readingTime: "5 min",
    tags: ["curso finanzas", "economic trends"]
  }
];

export const faqInflation = [
  {
    question_en: "What primary data sources feed the ARS→USD tracker?",
    question_es: "¿Qué fuentes alimentan el tracker ARS→USD?",
    answer_en:
      "We blend Central Bank of Argentina releases, reputable FX platforms, and curated market makers. Análisis transparentes y datos de mercado para decidir con seguridad.",
    answer_es:
      "Combinamos publicaciones del BCRA, plataformas cambiarias confiables y market makers curados. Análisis transparentes y datos de mercado para decidir con seguridad."
  },
  {
    question_en: "Does the platform provide financial advice?",
    question_es: "¿La plataforma ofrece asesoría financiera?",
    answer_en:
      "Información confiable que respalda elecciones responsables sobre tu dinero. Plataforma educativa con datos esenciales, sin asesoría financiera directa.",
    answer_es:
      "Información confiable que respalda elecciones responsables sobre tu dinero. Plataforma educativa con datos esenciales, sin asesoría financiera directa."
  },
  {
    question_en: "How often are inflation insights refreshed?",
    question_es: "¿Con qué frecuencia se actualizan los insights?",
    answer_en:
      "Core inflation dashboards refresh weekly. Macro context, forecasts, and scenario narratives refresh bi-weekly or when major policy changes occur.",
    answer_es:
      "Los tableros centrales se actualizan semanalmente. El contexto macro, pronósticos y narrativas de escenarios se renuevan cada dos semanas o ante cambios importantes."
  }
];
```

---