```javascript
import React from "react";
import { createRoot } from "react-dom/client";
import { HelmetProvider } from "react-helmet-async";
import { ParallaxProvider } from "react-scroll-parallax";
import App from "./App";
import "./styles/global.css";
import "./styles/components/animations.css";
import "./styles/components/buttons.css";
import "./styles/components/cards.css";
import { LanguageProvider } from "./contexts/LanguageContext";

const container = document.getElementById("root");
const root = createRoot(container);

root.render(
  <React.StrictMode>
    <HelmetProvider>
      <LanguageProvider>
        <ParallaxProvider>
          <App />
        </ParallaxProvider>
      </LanguageProvider>
    </HelmetProvider>
  </React.StrictMode>
);
```

---