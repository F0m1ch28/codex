```javascript
import { useEffect } from "react";
import { useInView } from "react-intersection-observer";
import { motionValues, animate } from "framer-motion";

export const useScrollReveal = (options = {}) => {
  const { ref, inView } = useInView({
    threshold: 0.2,
    triggerOnce: true,
    ...options
  });

  return {
    ref,
    animation: {
      initial: { opacity: 0, y: 24 },
      animate: inView ? { opacity: 1, y: 0 } : {},
      transition: { duration: 0.7, ease: [0.25, 0.1, 0.25, 1] }
    }
  };
};

export const useAnimatedCounter = (value, duration = 1.4) => {
  const count = motionValues(0);

  useEffect(() => {
    const controls = animate(count, value, {
      duration,
      ease: [0.17, 0.67, 0.4, 0.85]
    });
    return () => controls.stop();
  }, [count, value, duration]);

  return count;
};
```

---