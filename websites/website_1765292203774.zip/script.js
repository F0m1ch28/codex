document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const storageKey = 'pb_cookie_consent';

  if (!banner || !acceptBtn || !declineBtn) return;

  const status = localStorage.getItem(storageKey);
  if (!status) {
    banner.classList.add('is-visible');
  }

  const closeBanner = (value) => {
    localStorage.setItem(storageKey, value);
    banner.classList.remove('is-visible');
  };

  acceptBtn.addEventListener('click', () => closeBanner('accepted'));
  declineBtn.addEventListener('click', () => closeBanner('declined'));
});