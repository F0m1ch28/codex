document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", (!expanded).toString());
            navToggle.classList.toggle("is-active");
            navMenu.classList.toggle("is-open");
        });

        navMenu.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (navMenu.classList.contains("is-open")) {
                    navMenu.classList.remove("is-open");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const consent = localStorage.getItem("wdg-cookie-consent");
        if (consent) {
            cookieBanner.classList.add("hidden");
        }

        cookieBanner.querySelectorAll("[data-consent]").forEach(function (button) {
            button.addEventListener("click", function (event) {
                const value = button.dataset.consent;
                localStorage.setItem("wdg-cookie-consent", value);
                setTimeout(function () {
                    cookieBanner.classList.add("hidden");
                }, 120);
            });
        });
    }
});