import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policies.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Política de Cookies | EoliaCore Wind Systems</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <h1>Política de Cookies</h1>
    <p>Última actualización: 20 de mayo de 2024</p>
    <section>
      <h2>¿Qué son las cookies?</h2>
      <p>
        Las cookies son archivos que se descargan en tu dispositivo al acceder a determinados sitios web. Permiten almacenar y recuperar información sobre hábitos de navegación para mejorar el servicio.
      </p>
    </section>
    <section>
      <h2>Tipos de cookies utilizadas</h2>
      <ul>
        <li><strong>Técnicas:</strong> necesarias para el funcionamiento del sitio y la gestión del consentimiento.</li>
        <li><strong>Analíticas:</strong> nos ayudan a comprender el rendimiento del sitio y la interacción de los usuarios. Se recopilan de forma agregada.</li>
      </ul>
    </section>
    <section>
      <h2>Gestión del consentimiento</h2>
      <p>
        Al acceder al sitio puedes aceptar o configurar las cookies analíticas. Puedes retirar tu consentimiento en cualquier momento eliminando las cookies de tu navegador o comunicándote con nosotros en info@eoliacore.com.
      </p>
    </section>
    <section>
      <h2>Actualizaciones</h2>
      <p>
        Revisamos periódicamente este aviso para incluir nuevos servicios o normativas. Te recomendamos consultarlo de forma recurrente.
      </p>
    </section>
  </div>
);

export default CookiePolicyPage;