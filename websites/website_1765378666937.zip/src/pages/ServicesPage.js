import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ServicesPage.module.css';

const serviceLines = [
  {
    title: 'Due diligence y permisos',
    description: 'Análisis de recurso, evaluación ambiental y soporte documental para licitaciones de parques eólicos marinos.'
  },
  {
    title: 'Integración de datos y SCADA',
    description: 'Consolidación de fuentes heterogéneas, creación de paneles operativos y alertas inteligentes para equipos onshore/offshore.'
  },
  {
    title: 'Operaciones de mantenimiento',
    description: 'Planificación de campañas, logística de barcos y helicópteros, protocolos de inspección y formación específica.'
  },
  {
    title: 'Consultoría estratégica',
    description: 'Evaluación de portafolios, análisis de redes eléctricas, roadmap tecnológico y alineamiento con objetivos regulatorios.'
  }
];

const ServicesPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Servicios | EoliaCore Wind Systems</title>
      <meta
        name="description"
        content="Servicios de EoliaCore Wind Systems: due diligence offshore, integración de datos SCADA, operaciones de mantenimiento y consultoría estratégica."
      />
    </Helmet>

    <header className={styles.header}>
      <h1>Servicios profesionales para maximizar la energía eólica offshore</h1>
      <p>
        Nuestros servicios combinan ingeniería, analítica y acompañamiento estratégico. Diseñamos soluciones a medida para promotores, utilities y administraciones públicas.
      </p>
    </header>

    <section className={styles.grid}>
      {serviceLines.map(line => (
        <article className={styles.card} key={line.title}>
          <h3>{line.title}</h3>
          <p>{line.description}</p>
        </article>
      ))}
    </section>
  </div>
);

export default ServicesPage;