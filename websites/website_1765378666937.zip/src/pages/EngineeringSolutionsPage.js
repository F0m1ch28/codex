import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './EngineeringSolutionsPage.module.css';

const engineeringPillars = [
  {
    title: 'Conceptualización y diseño',
    description:
      'Evaluación de emplazamientos, layout óptimo, diseños de cimentaciones y verificación de cargas estructurales conforme a normas IEC.'
  },
  {
    title: 'Planificación constructiva',
    description:
      'Coordinación con astilleros, definición de cadenas logísticas, simulación de operaciones de izado y transporte offshore.'
  },
  {
    title: 'Puesta en servicio',
    description:
      'Procedimientos de commissioning, pruebas FAT/SAT, integración de SCADA y establecimiento de protocolos de seguridad marina.'
  },
  {
    title: 'Operación y mantenimiento',
    description:
      'Modelos predictivos, planificación de recursos portuarios, inspecciones remotas mediante drones y soporte 24/7 desde el centro de control.'
  }
];

const differentiation = [
  'Algoritmos de optimización que evalúan miles de combinaciones de layout y distancias de estela en minutos.',
  'Biblioteca propia de componentes con históricos de fallos para seleccionar equipos robustos según condición marina.',
  'Dashboards operativos que integran metocean, SCADA y logística portuaria para priorizar intervenciones.',
  'Equipos de campo entrenados en protocolos HSE específicos para trabajos en altura y maniobras marinas.'
];

const EngineeringSolutionsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Soluciones de Ingeniería | EoliaCore Wind Systems</title>
      <meta
        name="description"
        content="EoliaCore Wind Systems diseña y ejecuta soluciones de ingeniería eólica offshore: diseño de parques, logística portuaria, puesta en servicio y mantenimiento."
      />
    </Helmet>

    <header className={styles.header}>
      <div>
        <h1>Soluciones de ingeniería eólica para entornos offshore</h1>
        <p>
          Orquestamos proyectos desde la fase conceptual hasta la operación comercial. Nuestros ingenieros trabajan con modelos precisos y datos actualizados para garantizar que cada decisión se traduzca en disponibilidad y generación de energía.
        </p>
      </div>
      <img
        src="https://picsum.photos/seed/eoliacore-engineering/1400/750"
        alt="Ingenieros observando una turbina marina sobre planos técnicos"
        loading="lazy"
      />
    </header>

    <section className={styles.section}>
      <h2>Pilares del servicio</h2>
      <div className={styles.grid}>
        {engineeringPillars.map(item => (
          <article className={styles.card} key={item.title}>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.section}>
      <h2>Cómo garantizamos resultados</h2>
      <div className={styles.split}>
        <div>
          <h3>Metodología probada</h3>
          <p>
            Cada proyecto se gestiona con un gemelo digital que agrupa disciplinas: ingeniería aero-hidrodinámica, estructural, eléctrica y logística. Validamos escenarios con nuestros clientes antes de ejecutarlos en campo.
          </p>
          <p>
            Las simulaciones se conectan con datos reales, asegurando que las hipótesis iniciales evolucionen según el comportamiento operativo. Las revisiones periódicas permiten ajustar la estrategia sin desviaciones costosas.
          </p>
        </div>
        <div className={styles.listBox}>
          <h3>Diferenciales clave</h3>
          <ul>
            {differentiation.map(item => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Resultados en cifras</h2>
      <div className={styles.metrics}>
        <div className={styles.metricCard}>
          <span className={styles.metricValue}>18</span>
          <span className={styles.metricLabel}>Subestaciones offshore integradas</span>
        </div>
        <div className={styles.metricCard}>
          <span className={styles.metricValue}>96%</span>
          <span className={styles.metricLabel}>Disponibilidad media anual de turbinas monitorizadas</span>
        </div>
        <div className={styles.metricCard}>
          <span className={styles.metricValue}>15</span>
          <span className={styles.metricLabel}>Puertos españoles adaptados a logística eólica marina</span>
        </div>
      </div>
    </section>
  </div>
);

export default EngineeringSolutionsPage;