import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './HomePage.module.css';

const statsConfig = [
  { label: 'Parques eólicos monitorizados', value: 28, suffix: '+' },
  { label: 'Terabytes de datos analizados al mes', value: 320, suffix: '' },
  { label: 'Ingenieras e ingenieros especializados', value: 45, suffix: '' },
  { label: 'Proyectos costeros en ejecución', value: 12, suffix: '' }
];

const expertiseData = [
  {
    title: 'Ingeniería Eólica Offshore',
    description: 'Modelado integral de cimentaciones, cableado y sistemas de evacuación para emplazamientos marinos complejos.',
    icon: '🌊'
  },
  {
    title: 'Optimización de Turbinas',
    description: 'Gemelos digitales, control activo de yaw y análisis aeroelástico para maximizar el rendimiento anual.',
    icon: '🌀'
  },
  {
    title: 'Infraestructura Costera',
    description: 'Diseño de hubs portuarios, operaciones de mantenimiento y resiliencia frente a tormentas atlánticas.',
    icon: '🏗️'
  },
  {
    title: 'Análisis Técnico',
    description: 'Integración de SCADA, meteorología marina y datos satelitales para decisiones en tiempo casi real.',
    icon: '📊'
  }
];

const technologyHighlights = [
  {
    title: 'Gemelos digitales del parque',
    copy: 'Simulamos cada turbina con modelos CFD y datos SCADA para validar decisiones de operación en minutos.'
  },
  {
    title: 'Sensórica marina avanzada',
    copy: 'Boyas LIDAR, cámaras hiperespectrales y radares de oleaje alimentan modelos de predicción de carga estructural.'
  },
  {
    title: 'Analítica predictiva',
    copy: 'Algoritmos de mantenimiento anticipan fallos críticos y optimizan ventanas de intervención offshore.'
  }
];

const processSteps = [
  {
    title: 'Investigación de emplazamiento',
    content: 'Levantamiento batimétrico, climatología de vientos y análisis de suelos marinos con partners locales.'
  },
  {
    title: 'Modelado y simulación',
    content: 'CFD multiescala, estudios de estela y análisis estructural de torre y cimentación.'
  },
  {
    title: 'Integración tecnológica',
    content: 'Implementamos sensores IoT, redes de datos redundantes y plataformas de control unificado.'
  },
  {
    title: 'Despliegue operativo',
    content: 'Planes de instalación, logística portuaria y protocolos de seguridad para operaciones offshore.'
  },
  {
    title: 'Monitorización continua',
    content: 'Paneles en tiempo real, mantenimiento predictivo y evaluación de performance para cada turbina.'
  }
];

const projectsData = [
  {
    title: 'Parque flotante Tramuntana',
    category: 'offshore',
    description: 'Diseñamos la estructura de fondeo y controlamos la estela del mayor proyecto flotante en el Mediterráneo occidental.',
    region: 'Costa Brava, Cataluña',
    image: 'https://picsum.photos/seed/eoliacore-project-1/1200/800'
  },
  {
    title: 'Optimización Aerodinámica Levante',
    category: 'optimización',
    description: 'Aplicamos control inteligente de yaw y pitch para incrementar un 8% el factor de carga anual en vientos variables.',
    region: 'Golfo de Valencia',
    image: 'https://picsum.photos/seed/eoliacore-project-2/1200/800'
  },
  {
    title: 'Hub O&M Cantábrico',
    category: 'infraestructura',
    description: 'Plan maestro del puerto base para operaciones offshore con enfoque en seguridad y tiempos de respuesta meteo-oceánicos.',
    region: 'Avilés, Asturias',
    image: 'https://picsum.photos/seed/eoliacore-project-3/1200/800'
  },
  {
    title: 'Monitorización de cables export',
    category: 'infraestructura',
    description: 'Gemelo digital térmico de cables submarinos para reducir riesgos de hotspots y fallos de aislamiento.',
    region: 'Bahía de Cádiz, Andalucía',
    image: 'https://picsum.photos/seed/eoliacore-project-4/1200/800'
  },
  {
    title: 'Recalibración de sensores SCADA',
    category: 'optimización',
    description: 'Calibración cruzada con LIDAR remoto para lograr lecturas precisas incluso en condiciones de turbulencia marina severa.',
    region: 'Costa da Morte, Galicia',
    image: 'https://picsum.photos/seed/eoliacore-project-5/1200/800'
  }
];

const teamMembers = [
  {
    name: 'Laura Benítez',
    role: 'Directora de Ingeniería Offshore',
    bio: 'Especialista en estructuras flotantes y dinámica de amarre con experiencia en el Mar del Norte y el Atlántico.',
    image: 'https://picsum.photos/seed/eoliacore-team-1/400/400'
  },
  {
    name: 'Javier Ortega',
    role: 'Líder de Analítica de Turbinas',
    bio: 'Doctor en aeroelasticidad, desarrolla algoritmos de control adaptativo y modelos de vida útil de componentes.',
    image: 'https://picsum.photos/seed/eoliacore-team-2/400/400'
  },
  {
    name: 'Marina Sanz',
    role: 'Responsable de Infraestructura Costera',
    bio: 'Diseña hubs portuarios resilientes e integra normativas ambientales en proyectos de gran escala.',
    image: 'https://picsum.photos/seed/eoliacore-team-3/400/400'
  },
  {
    name: 'Andrés Villalba',
    role: 'Arquitecto de Datos Oceánicos',
    bio: 'Combina sensores LIDAR, radar HF y satélite para entregar modelos predictivos de viento y oleaje.',
    image: 'https://picsum.photos/seed/eoliacore-team-4/400/400'
  }
];

const testimonials = [
  {
    quote: 'La precisión de sus gemelos digitales nos permitió ajustar el layout offshore sin retrasar el calendario de construcción.',
    name: 'Isabel Romero',
    position: 'Directora Técnica · IberAtlantic Wind',
    image: 'https://picsum.photos/seed/eoliacore-client-1/200/200'
  },
  {
    quote: 'EoliaCore transformó nuestros datos SCADA dispersos en una plataforma operativa con alertas predictivas útiles a bordo.',
    name: 'Manuel Quiroga',
    position: 'Operations Manager · Cantábrico Offshore',
    image: 'https://picsum.photos/seed/eoliacore-client-2/200/200'
  },
  {
    quote: 'Su enfoque en logística portuaria y meteorología marina redujo en un 25% nuestras ventanas de inactividad en mantenimiento.',
    name: 'Soraya Gil',
    position: 'Jefa de Mantenimiento · BlueCoast Turbines',
    image: 'https://picsum.photos/seed/eoliacore-client-3/200/200'
  }
];

const blogPosts = [
  {
    title: 'Dinámica de estela en parques eólicos flotantes del Mediterráneo',
    date: '15 abril 2024',
    excerpt: 'Cómo combinar simulaciones LES y datos LIDAR para reducir interferencias y mejorar la densidad energética.',
    image: 'https://picsum.photos/seed/eoliacore-blog-1/800/600'
  },
  {
    title: 'Checklist técnico para hubs portuarios dedicados a offshore wind',
    date: '28 marzo 2024',
    excerpt: 'Revisión de infraestructuras críticas, capacidades grúa y protocolos de seguridad marina en puertos españoles.',
    image: 'https://picsum.photos/seed/eoliacore-blog-2/800/600'
  },
  {
    title: 'Claves del mantenimiento predictivo basado en vibraciones',
    date: '08 marzo 2024',
    excerpt: 'Sensores multispectrales, modelos de fallo y priorización de tareas para extender la vida útil de componentes.',
    image: 'https://picsum.photos/seed/eoliacore-blog-3/800/600'
  }
];

const faqData = [
  {
    question: '¿Cómo integra EoliaCore los datos SCADA con la modelización meteo-oceánica?',
    answer:
      'Unificamos los flujos de datos en una capa de integración temporal que sincroniza SCADA, boyas LIDAR y radares de oleaje. De esta manera, cada turbina se correlaciona con el estado del mar y del viento, permitiendo decisiones operativas de alta precisión.'
  },
  {
    question: '¿Qué alcance tiene vuestro soporte en proyectos offshore en España?',
    answer:
      'Acompañamos desde la previabilidad hasta la operación. Esto incluye estudios de emplazamiento, ingeniería de detalle, puesta en servicio y monitorización continua con cuadros de mando personalizados.'
  },
  {
    question: '¿Trabajáis con plataformas flotantes y cimentaciones fijas?',
    answer:
      'Sí. Nuestro equipo de ingeniería aborda tanto soluciones flotantes semi-sumergibles como cimentaciones monopilote y jacket, adaptando el diseño a las condiciones de cada costa.'
  },
  {
    question: '¿Ofrecéis formación para equipos operativos?',
    answer:
      'Desarrollamos programas in situ y virtuales para dotar a los equipos de operación y mantenimiento de herramientas analíticas, protocolos de seguridad y buenas prácticas digitales.'
  }
];

const geographyHighlights = [
  'Corredor Cantábrico: operaciones de mantenimiento avanzadas bajo condiciones atlánticas exigentes.',
  'Arco Mediterráneo: optimización de parques flotantes y estudios de estela en aguas profundas.',
  'Canarias: planificación logística y resiliencia ante fenómenos meteorológicos extremos.'
];

const HomePage = () => {
  const [animatedStats, setAnimatedStats] = useState(statsConfig.map(() => 0));
  const [activeFilter, setActiveFilter] = useState('todos');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [openFAQ, setOpenFAQ] = useState(null);

  useEffect(() => {
    const timers = statsConfig.map((stat, index) => {
      const increment = Math.max(1, Math.ceil(stat.value / 60));
      return setInterval(() => {
        setAnimatedStats(prev => {
          const next = [...prev];
          const newValue = Math.min(stat.value, prev[index] + increment);
          next[index] = newValue;
          if (newValue === stat.value) {
            clearInterval(timers[index]);
          }
          return next;
        });
      }, 40);
    });

    return () => {
      timers.forEach(timer => clearInterval(timer));
    };
  }, []);

  useEffect(() => {
    const sliderTimer = setInterval(() => {
      setTestimonialIndex(prev => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(sliderTimer);
  }, []);

  const categories = useMemo(() => {
    const cats = new Set(projectsData.map(project => project.category));
    return ['todos', ...Array.from(cats)];
  }, []);

  const filteredProjects =
    activeFilter === 'todos'
      ? projectsData
      : projectsData.filter(project => project.category === activeFilter);

  const handleFAQToggle = index => {
    setOpenFAQ(prev => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>EoliaCore Wind Systems | Plataforma de ingeniería eólica offshore en España</title>
        <meta
          name="description"
          content="EoliaCore Wind Systems integra ingeniería offshore, optimización de turbinas y analítica costera para impulsar la energía eólica en España con soluciones avanzadas."
        />
        <meta
          name="keywords"
          content="energía eólica, offshore wind, turbinas marinas, aerogeneradores, parques eólicos, ingeniería costera, optimización aerodinámica, mantenimiento predictivo, energía renovable España, infraestructura eólica"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <div className={styles.heroContent}>
            <span className={styles.eyebrow}>Plataforma de ingeniería y datos eólicos</span>
            <h1 className={styles.heroTitle}>
              EoliaCore Wind Systems potencia la energía offshore que impulsa a España.
            </h1>
            <p className={styles.heroDescription}>
              Alineamos investigación marina, ingeniería de turbinas y analítica predictiva para que cada megavatio generado en el mar alcance su máximo rendimiento y resiliencia.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contacto" className={styles.primaryBtn}>
                Planificar un proyecto
              </Link>
              <Link to="/investigacion" className={styles.secondaryBtn}>
                Explorar nuestra investigación
              </Link>
            </div>
          </div>
          <div className={styles.heroMedia}>
            <img
              src="https://picsum.photos/seed/eoliacore-hero/1600/900"
              alt="Parque eólico offshore durante el amanecer"
              className={styles.heroImage}
              loading="lazy"
            />
          </div>
        </div>
        <div className={styles.statsStrip}>
          {statsConfig.map((stat, index) => (
            <div className={styles.statCard} key={stat.label}>
              <span className={styles.statValue}>
                {animatedStats[index]}
                {stat.suffix}
              </span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section} id="quienes-somos">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Quiénes somos</span>
          <h2 className={styles.sectionTitle}>Ingeniería eólica offshore nacida en Madrid con vocación atlántica.</h2>
          <p className={styles.sectionDescription}>
            EoliaCore Wind Systems acompaña a promotores, utilities y administraciones a lo largo de todo el ciclo de vida de un parque eólico marino. Nuestras soluciones combinan investigación académica aplicada, ingeniería de detalle y plataformas analíticas construidas específicamente para entornos costeros ibéricos.
          </p>
        </div>
        <div className={styles.aboutContent}>
          <div className={styles.aboutText}>
            <p>
              Desde Paseo de la Castellana coordinamos equipos multidisciplinares especializados en aerodinámica, oceanografía operativa, energía digital y logística portuaria. Esta base nacional se complementa con alianzas internacionales para garantizar acceso a tecnología de vanguardia sin perder el foco regulatorio y ambiental español.
            </p>
            <p>
              Nuestros proyectos abarcan parques en el Cantábrico, el Atlántico andaluz, el Mediterráneo y los archipiélagos. Adaptamos la estrategia a cada zona, analizando vientos dominantes, oleaje, biodiversidad y limitaciones de redes eléctricas para tomar decisiones replicables y robustas.
            </p>
            <Link to="/nosotros" className={styles.inlineLink}>
              Conocer más sobre el equipo →
            </Link>
          </div>
          <div className={styles.aboutImageWrapper}>
            <img
              src="https://picsum.photos/seed/eoliacore-about/1000/800"
              alt="Ingenieras analizando datos eólicos en un centro de control"
              className={styles.aboutImage}
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.section} id="experiencia">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Nuestra experiencia</span>
          <h2 className={styles.sectionTitle}>Competencias que abarcan del modelado CFD a la logística portuaria.</h2>
          <p className={styles.sectionDescription}>
            Cuatro áreas de especialización permiten cubrir la cadena de valor completa de la energía eólica marina, siempre con métricas de rendimiento y fiabilidad verificables.
          </p>
        </div>
        <div className={styles.expertiseGrid}>
          {expertiseData.map(item => (
            <article className={styles.expertiseCard} key={item.title}>
              <span className={styles.expertiseIcon} aria-hidden="true">
                {item.icon}
              </span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section} id="tecnologia">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Enfoque tecnológico</span>
          <h2 className={styles.sectionTitle}>Tecnologías propias para decisiones offshore críticas.</h2>
          <p className={styles.sectionDescription}>
            Integrar sensores marinos, plataformas cloud y modelos de predicción es imprescindible para operar en condiciones cambiantes. EoliaCore desarrolla stacks específicos que fusionan datos, simulan escenarios y entregan indicadores a bordo y en tierra.
          </p>
        </div>
        <div className={styles.techGrid}>
          {technologyHighlights.map(item => (
            <div className={styles.techCard} key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.copy}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.section} id="enfoque">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Nuestro enfoque</span>
          <h2 className={styles.sectionTitle}>Un proceso que transforma datos en ventaja operativa.</h2>
        </div>
        <div className={styles.processTimeline}>
          {processSteps.map((step, index) => (
            <div className={styles.processStep} key={step.title}>
              <span className={styles.processNumber}>{index + 1}</span>
              <div className={styles.processContent}>
                <h3>{step.title}</h3>
                <p>{step.content}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.geographySection}`} id="geografia">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Ámbito geográfico</span>
          <h2 className={styles.sectionTitle}>Especialistas en costas españolas y rutas logísticas europeas.</h2>
          <p className={styles.sectionDescription}>
            Operamos en los principales hubs offshore del país, coordinando permisos, proveedores y equipos técnicos junto con autoridades portuarias.
          </p>
        </div>
        <div className={styles.geographyGrid}>
          <div className={styles.geographyCard}>
            <img
              src="https://picsum.photos/seed/eoliacore-geography/1000/700"
              alt="Mapa ilustrativo de proyectos eólicos en España"
              loading="lazy"
            />
          </div>
          <div className={styles.geographyCard}>
            <ul className={styles.geographyList}>
              {geographyHighlights.map(item => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <Link to="/soluciones-ingenieria" className={styles.inlineLink}>
              Ver proyectos costeros →
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.projectsSection}`} id="proyectos">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Casos de éxito</span>
          <h2 className={styles.sectionTitle}>Proyectos recientes que redefinen la eólica marina.</h2>
        </div>
        <div className={styles.filterBar} role="tablist" aria-label="Filtrar proyectos por categoría">
          {categories.map(category => (
            <button
              type="button"
              key={category}
              role="tab"
              aria-selected={activeFilter === category}
              className={`${styles.filterButton} ${activeFilter === category ? styles.filterButtonActive : ''}`}
              onClick={() => setActiveFilter(category)}
            >
              {category === 'todos' ? 'Todos' : category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map(project => (
            <article className={styles.projectCard} key={project.title}>
              <img src={project.image} alt={project.title} className={styles.projectImage} loading="lazy" />
              <div className={styles.projectBody}>
                <div className={styles.projectMeta}>
                  <span className={styles.projectTag}>{project.category}</span>
                  <span>{project.region}</span>
                </div>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.teamSection}`} id="equipo">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Equipo</span>
          <h2 className={styles.sectionTitle}>Personas que unen ingeniería, oceanografía y analítica.</h2>
        </div>
        <div className={styles.teamGrid}>
          {teamMembers.map(member => (
            <article className={styles.teamCard} key={member.name}>
              <img src={member.image} alt={member.name} className={styles.teamImage} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span className={styles.teamRole}>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialSection}`} id="testimonios">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Testimonios</span>
          <h2 className={styles.sectionTitle}>Voces de clientes que confían en nuestro criterio técnico.</h2>
        </div>
        <div className={styles.testimonialCard}>
          <img
            src={testimonials[testimonialIndex].image}
            alt={testimonials[testimonialIndex].name}
            className={styles.testimonialImage}
            loading="lazy"
          />
          <p className={styles.testimonialQuote}>
            “{testimonials[testimonialIndex].quote}”
          </p>
          <span className={styles.testimonialAuthor}>{testimonials[testimonialIndex].name}</span>
          <span className={styles.testimonialPosition}>{testimonials[testimonialIndex].position}</span>
          <div className={styles.testimonialControls}>
            <button
              type="button"
              onClick={() => setTestimonialIndex(prev => (prev === 0 ? testimonials.length - 1 : prev - 1))}
              className={styles.testimonialButton}
              aria-label="Testimonio anterior"
            >
              ←
            </button>
            <button
              type="button"
              onClick={() => setTestimonialIndex(prev => (prev + 1) % testimonials.length)}
              className={styles.testimonialButton}
              aria-label="Siguiente testimonio"
            >
              →
            </button>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.faqSection}`} id="faq">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Preguntas frecuentes</span>
          <h2 className={styles.sectionTitle}>Resolvemos las dudas más habituales de nuestros partners.</h2>
        </div>
        <div className={styles.faqList}>
          {faqData.map((item, index) => (
            <article className={styles.faqItem} key={item.question}>
              <button
                type="button"
                className={styles.faqQuestion}
                onClick={() => handleFAQToggle(index)}
                aria-expanded={openFAQ === index}
              >
                <span>{item.question}</span>
                <span aria-hidden="true">{openFAQ === index ? '−' : '+'}</span>
              </button>
              {openFAQ === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.blogSection}`} id="blog">
        <div className={styles.sectionHeader}>
          <span className={styles.sectionTag}>Últimas notas técnicas</span>
          <h2 className={styles.sectionTitle}>Insights que nacen de proyectos reales y datos en campo.</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map(post => (
            <article className={styles.blogCard} key={post.title}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className={styles.blogContent}>
                <span className={styles.blogMeta}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/investigacion" className={styles.inlineLink}>
                  Leer más →
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.section} ${styles.ctaSection}`} id="contacto">
        <div className={styles.ctaInner}>
          <div>
            <span className={styles.sectionTag}>Contacto</span>
            <h2 className={styles.sectionTitle}>Co-diseñemos la próxima referencia eólica offshore en España.</h2>
            <p className={styles.sectionDescription}>
              Escríbenos para coordinar una sesión estratégica presencial en Paseo de la Castellana o una reunión virtual con nuestro equipo multidisciplinar.
            </p>
          </div>
          <div className={styles.contactDetails}>
            <div className={styles.contactItem}>
              <span className={styles.contactLabel}>Dirección</span>
              <a href="https://maps.app.goo.gl/" target="_blank" rel="noopener noreferrer" className={styles.contactLink}>
                Paseo de la Castellana 95, 28046 Madrid, Spain
              </a>
            </div>
            <div className={styles.contactItem}>
              <span className={styles.contactLabel}>Teléfono</span>
              <a href="tel:+34910473892" className={styles.contactLink}>
                +34 910 47 38 92
              </a>
            </div>
            <div className={styles.contactItem}>
              <span className={styles.contactLabel}>Correo</span>
              <a href="mailto:info@eoliacore.com" className={styles.contactLink}>
                info@eoliacore.com
              </a>
            </div>
          </div>
          <Link to="/contacto" className={styles.ctaButton}>
            Escribir al equipo
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;