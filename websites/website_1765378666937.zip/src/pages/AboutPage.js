import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './AboutPage.module.css';

const milestones = [
  {
    year: '2018',
    detail: 'Nacimiento de EoliaCore Wind Systems en Madrid y primeros estudios de viabilidad para parques offshore en el Cantábrico.'
  },
  {
    year: '2020',
    detail: 'Creación del laboratorio de gemelos digitales y despliegue de la primera plataforma de mantenimiento predictivo.'
  },
  {
    year: '2022',
    detail: 'Apertura de oficina técnica en Galicia y consolidación de alianzas con universidades españolas.'
  },
  {
    year: '2024',
    detail: 'Lanzamiento de la suite Digital Ocean Grid y coordinación de proyectos flotantes en el Mediterráneo.'
  }
];

const values = [
  { title: 'Precisión', description: 'Tomamos decisiones basadas en datos validados y modelos transparentes.' },
  { title: 'Colaboración', description: 'Integramos equipos multidisciplinares con partners, proveedores y autoridades.' },
  { title: 'Resiliencia', description: 'Diseñamos infraestructuras preparadas para operar en condiciones extremas.' },
  { title: 'Sostenibilidad', description: 'Consideramos el impacto ambiental en cada fase del ciclo de vida del proyecto.' }
];

const AboutPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Nosotros | EoliaCore Wind Systems</title>
      <meta
        name="description"
        content="Conoce al equipo de EoliaCore Wind Systems, su historia, valores y trayectoria liderando la ingeniería eólica offshore en España."
      />
    </Helmet>

    <header className={styles.hero}>
      <h1>Una compañía española con visión oceanográfica global</h1>
      <p>
        Desde 2018 trabajamos para acelerar la transición energética marina. Nuestros proyectos conectan investigación universitaria, ingeniería industrial y necesidades operativas de las principales costas españolas.
      </p>
      <img src="https://picsum.photos/seed/eoliacore-about-hero/1400/700" alt="Equipo de EoliaCore colaborando en un taller técnico" loading="lazy" />
    </header>

    <section className={styles.section}>
      <h2>Valores que guían cada decisión</h2>
      <div className={styles.valuesGrid}>
        {values.map(value => (
          <article key={value.title}>
            <h3>{value.title}</h3>
            <p>{value.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.section}>
      <h2>Nuestro recorrido</h2>
      <div className={styles.timeline}>
        {milestones.map(item => (
          <div className={styles.milestone} key={item.year}>
            <span className={styles.year}>{item.year}</span>
            <p>{item.detail}</p>
          </div>
        ))}
      </div>
    </section>
  </div>
);

export default AboutPage;