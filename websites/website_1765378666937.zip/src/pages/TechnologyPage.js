import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './TechnologyPage.module.css';

const technologyStacks = [
  {
    name: 'Digital Ocean Grid',
    description: 'Motor de simulación que combina CFD, análisis de oleaje y modelado eléctrico para crear escenarios operativos en minutos.'
  },
  {
    name: 'SCADA Fusion Layer',
    description: 'Plataforma que consolida datos SCADA, meteorología marina, inspecciones visuales y sensores submarinos en un único panel operativo.'
  },
  {
    name: 'Atlas Eólico Dinámico',
    description: 'Mapas meteorológicos de alta resolución para horizontes de 6 a 48 horas, alimentados por IA y datos satelitales.'
  }
];

const securityPractices = [
  'Encriptación extremo a extremo en tránsito y en reposo con estándares AES-256.',
  'Autenticación multifactor y control de accesos por roles alineados con ISO 27001.',
  'Monitorización continua de integridad y registros de auditoría para cada interacción.',
  'Infraestructura desplegada en centros de datos europeos con certificaciones Tier III.'
];

const TechnologyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Tecnología | EoliaCore Wind Systems</title>
      <meta
        name="description"
        content="EoliaCore Wind Systems desarrolla plataformas tecnológicas para la eólica offshore: gemelos digitales, integración SCADA y analítica predictiva con seguridad avanzada."
      />
    </Helmet>

    <header className={styles.intro}>
      <h1>Arquitectura tecnológica diseñada para el mar</h1>
      <p>
        Las condiciones cambiantes del entorno marítimo exigen sistemas que reaccionen en tiempo real, se integren con hardware complejo y mantengan la ciberseguridad como pilar. En EoliaCore desarrollamos capas tecnológicas que conectan sensores, modelos y equipos operativos sin fricciones.
      </p>
      <img
        src="https://picsum.photos/seed/eoliacore-technology/1400/700"
        alt="Centro de control con paneles de datos eólicos"
        loading="lazy"
      />
    </header>

    <section className={styles.section}>
      <h2>Pilares de nuestra pila tecnológica</h2>
      <div className={styles.grid}>
        {technologyStacks.map(stack => (
          <article className={styles.card} key={stack.name}>
            <h3>{stack.name}</h3>
            <p>{stack.description}</p>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.section}>
      <h2>Interoperabilidad y datos abiertos</h2>
      <p>
        Nuestras soluciones se integran con sistemas de terceros mediante APIs estandarizadas, OPC-UA y protocolos seguros MQTT. Esto permite que promotores y operadores mantengan el control de sus datos y puedan migrar sin quedar anclados a un único proveedor.
      </p>
      <div className={styles.highlight}>
        <h3>Herramientas destacadas</h3>
        <ul>
          <li>Panel táctico para operaciones offshore compatible con tablets reforzadas.</li>
          <li>Biblioteca de algoritmos para análisis de vibraciones y detección de anomalías.</li>
          <li>Repositorio de eventos y lecciones aprendidas accesible por proyecto.</li>
        </ul>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Seguridad y resiliencia digital</h2>
      <div className={styles.split}>
        <div>
          <p>
            La tecnología eólica marina debe resistir condiciones meteorológicas extremas y ciberataques sofisticados. Utilizamos arquitecturas redundantes, backups geodistribuidos y pruebas de estrés periódicas para asegurar la continuidad operativa.
          </p>
        </div>
        <div className={styles.listBox}>
          <ul>
            {securityPractices.map(item => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  </div>
);

export default TechnologyPage;