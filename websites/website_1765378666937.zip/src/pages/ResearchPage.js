import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ResearchPage.module.css';

const ResearchPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Investigación | EoliaCore Wind Systems</title>
      <meta
        name="description"
        content="Descubre las líneas de investigación de EoliaCore Wind Systems: modelado CFD, sensórica marina, analítica predictiva y evaluación ambiental para parques eólicos offshore."
      />
      <meta
        name="keywords"
        content="investigación eólica offshore, modelado CFD, sensórica marina, análisis de estela, energía renovable España"
      />
    </Helmet>

    <header className={styles.intro}>
      <h1>Investigación aplicada a la eólica marina española</h1>
      <p>
        Nuestras líneas de investigación nacen en entornos reales: boyas LIDAR desplegadas en el Cantábrico, sensores en parques precomerciales del Mediterráneo y datos SCADA de promotores nacionales. Cada avance tecnológico se contrasta con normativa, operación y vida útil de los componentes.
      </p>
      <img
        src="https://picsum.photos/seed/eoliacore-research/1400/600"
        alt="Investigadora revisando datos de viento offshore"
        loading="lazy"
      />
    </header>

    <section className={styles.section}>
      <h2>Áreas científicas prioritarias</h2>
      <div className={styles.grid}>
        <article className={styles.card}>
          <h3>Modelado CFD multiescala</h3>
          <p>
            Simulamos capas límite marinas, estelas y turbulencia con metodologías LES y RANS acopladas, validando la precisión con datos in situ. Esto nos permite optimizar layouts y estrategias de control en parques de gran densidad.
          </p>
        </article>
        <article className={styles.card}>
          <h3>Oceanografía operativa</h3>
          <p>
            Procesamos radares HF, boyas de oleaje y altímetros satelitales para construir pronósticos que integran viento, oleaje y corrientes. La información se utiliza para definir ventanas seguras de operación y transporte.
          </p>
        </article>
        <article className={styles.card}>
          <h3>Mantenimiento predictivo</h3>
          <p>
            Desarrollamos modelos basados en vibraciones y análisis de aceites que predicen fallos con semanas de antelación. Los modelos se calibran con históricos reales y se actualizan mediante aprendizaje continuo.
          </p>
        </article>
        <article className={styles.card}>
          <h3>Evaluación ambiental</h3>
          <p>
            Aplicamos metodologías de bajo impacto para protecciones de fauna, ruido submarino y compatibilidad con corredores marítimos. Colaboramos con universidades para monitorizar biodiversidad costera.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Infraestructura científica propia</h2>
      <div className={styles.split}>
        <div>
          <ul className={styles.list}>
            <li>Laboratorio de prototipado con túnel de viento, canal de oleaje y plataforma de pruebas para sensores.</li>
            <li>Centro de datos en Madrid con pipelines de ingestión para registros SCADA, meteo y oceanografía de alta frecuencia.</li>
            <li>Gemelos digitales que combinan simuladores Ansys, OpenFOAM y herramientas propietarias en Kubernetes.</li>
            <li>Red de estaciones costeras propias conectadas con redes nacionales (Puertos del Estado y AEMET).</li>
          </ul>
        </div>
        <div>
          <p>
            Esta infraestructura nos permite ensayar decisiones antes de su despliegue, reduciendo riesgos y sincronizando la investigación con la operación diaria. Todo el conocimiento se comparte mediante informes ejecutivos y paneles interactivos para los equipos de nuestros clientes.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.section}>
      <h2>Colaboraciones y proyectos competitivos</h2>
      <p>
        Participamos en consorcios europeos de energía marina, proyectos CDTI y clústeres autonómicos. Trabajamos junto a universidades y centros tecnológicos españoles como la UPC, la Universidad de Cantabria y Tecnalia, integrando su conocimiento en soluciones comerciales.
      </p>
      <div className={styles.highlight}>
        <h3>Proyecto destacado: BlueTwin</h3>
        <p>
          Plataforma de gemelo digital para parques flotantes en aguas mediterráneas, financiada por la Unión Europea. EoliaCore lidera el diseño del modelo aerodinámico y el módulo de mantenimiento predictivo, consiguiendo reducir la incertidumbre de producción en un 12%.
        </p>
      </div>
    </section>
  </div>
);

export default ResearchPage;