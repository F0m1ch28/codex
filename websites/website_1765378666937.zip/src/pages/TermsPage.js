import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policies.module.css';

const TermsPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Términos y Condiciones | EoliaCore Wind Systems</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <h1>Términos y Condiciones</h1>
    <p>Última actualización: 20 de mayo de 2024</p>
    <section>
      <h2>1. Objeto</h2>
      <p>
        El presente documento regula el uso del sitio web eoliacore.com y los servicios ofrecidos por EoliaCore Wind Systems, con domicilio en Paseo de la Castellana 95, 28046 Madrid, Spain. Al acceder a este sitio aceptas los términos aquí descritos.
      </p>
    </section>
    <section>
      <h2>2. Uso del sitio</h2>
      <p>
        Los contenidos están dirigidos a profesionales y organizaciones del sector energético. Te comprometes a utilizar la información de forma lícita, respetando la propiedad intelectual y evitando actividades que puedan dañar el funcionamiento del sitio o la reputación de la compañía.
      </p>
    </section>
    <section>
      <h2>3. Propiedad intelectual</h2>
      <p>
        Las marcas, textos, gráficos y contenidos son propiedad de EoliaCore Wind Systems o de terceros con licencia. Queda prohibida la reproducción total o parcial sin autorización expresa.
      </p>
    </section>
    <section>
      <h2>4. Responsabilidad</h2>
      <p>
        EoliaCore Wind Systems actúa con diligencia para ofrecer información precisa pero no garantiza la ausencia de errores. No nos responsabilizamos de decisiones basadas exclusivamente en el contenido del sitio sin asesoramiento profesional.
      </p>
    </section>
    <section>
      <h2>5. Legislación aplicable</h2>
      <p>
        Estos términos se rigen por la legislación española. Cualquier disputa se someterá a los tribunales de Madrid, salvo que una normativa específica determine otro fuero.
      </p>
    </section>
    <section>
      <h2>6. Contacto</h2>
      <p>
        Para consultas relacionadas con estos términos puedes escribir a <a href="mailto:info@eoliacore.com">info@eoliacore.com</a> o llamar al +34 910 47 38 92.
      </p>
    </section>
  </div>
);

export default TermsPage;