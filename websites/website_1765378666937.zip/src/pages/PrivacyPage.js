import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policies.module.css';

const PrivacyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Política de Privacidad | EoliaCore Wind Systems</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <h1>Política de Privacidad</h1>
    <p>Última actualización: 20 de mayo de 2024</p>
    <section>
      <h2>Responsable del tratamiento</h2>
      <p>
        EoliaCore Wind Systems, Paseo de la Castellana 95, 28046 Madrid, Spain. Puedes contactar en <a href="mailto:info@eoliacore.com">info@eoliacore.com</a> o por teléfono al +34 910 47 38 92.
      </p>
    </section>
    <section>
      <h2>Datos tratados</h2>
      <p>
        Gestionamos datos identificativos y profesionales facilitados a través de formularios, correos o reuniones. También obtenemos datos de navegación anónimos mediante cookies técnicas y analíticas.
      </p>
    </section>
    <section>
      <h2>Finalidades</h2>
      <ul>
        <li>Responder a consultas y solicitudes de información.</li>
        <li>Gestionar relaciones comerciales y contractuales.</li>
        <li>Enviar comunicaciones técnicas relacionadas con servicios eólicos, siempre con consentimiento previo.</li>
        <li>Analizar el uso del sitio para mejorar la experiencia digital.</li>
      </ul>
    </section>
    <section>
      <h2>Legitimación</h2>
      <p>
        El tratamiento se basa en tu consentimiento, en la ejecución de un contrato o en el interés legítimo de la compañía para mantener relaciones profesionales.
      </p>
    </section>
    <section>
      <h2>Conservación</h2>
      <p>
        Conservamos los datos durante la vigencia de la relación y posteriormente según los plazos legales aplicables. Los datos con fines comerciales se mantienen mientras exista consentimiento válido.
      </p>
    </section>
    <section>
      <h2>Derechos</h2>
      <p>
        Puedes ejercer los derechos de acceso, rectificación, supresión, oposición, limitación y portabilidad enviando una solicitud a info@eoliacore.com. También puedes reclamar ante la Agencia Española de Protección de Datos.
      </p>
    </section>
  </div>
);

export default PrivacyPage;