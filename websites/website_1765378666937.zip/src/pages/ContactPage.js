import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    organizacion: '',
    interes: '',
    mensaje: ''
  });
  const [status, setStatus] = useState('');

  const handleChange = event => {
    const { name, value } = event.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = event => {
    event.preventDefault();
    if (!formData.nombre || !formData.email || !formData.mensaje) {
      setStatus('Completa los campos obligatorios para que podamos contactarte.');
      return;
    }
    setStatus('Gracias por tu interés. Nuestro equipo se pondrá en contacto contigo en menos de 24 horas laborables.');
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contacto | EoliaCore Wind Systems</title>
        <meta
          name="description"
          content="Contacta con EoliaCore Wind Systems para planificar proyectos eólicos offshore, solicitar análisis de turbinas o coordinar logística costera en España."
        />
      </Helmet>

      <header className={styles.header}>
        <h1>Coordinemos tu próximo hito offshore</h1>
        <p>
          Escríbenos para concertar una sesión en Paseo de la Castellana 95 o una reunión virtual. Adaptaremos la conversación a tu necesidad: viabilidad de parque, optimización de turbinas, integración tecnológica o soporte operativo.
        </p>
      </header>

      <div className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formGroup}>
            <label htmlFor="nombre">Nombre completo *</label>
            <input
              id="nombre"
              name="nombre"
              type="text"
              value={formData.nombre}
              onChange={handleChange}
              placeholder="Nombre y apellidos"
              required
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="email">Correo profesional *</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="nombre@empresa.com"
              required
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="organizacion">Organización</label>
            <input
              id="organizacion"
              name="organizacion"
              type="text"
              value={formData.organizacion}
              onChange={handleChange}
              placeholder="Nombre de la empresa o institución"
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="interes">Interés principal</label>
            <select id="interes" name="interes" value={formData.interes} onChange={handleChange}>
              <option value="">Selecciona una opción</option>
              <option value="estudios">Estudios de viabilidad y diseño</option>
              <option value="optimización">Optimización de turbinas y datos</option>
              <option value="infraestructura">Infraestructura y logística costera</option>
              <option value="operacion">Operación y mantenimiento</option>
              <option value="otro">Otro</option>
            </select>
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="mensaje">Mensaje *</label>
            <textarea
              id="mensaje"
              name="mensaje"
              rows="5"
              value={formData.mensaje}
              onChange={handleChange}
              placeholder="Cuéntanos sobre tu proyecto o consulta"
              required
            />
          </div>
          <button type="submit" className={styles.submitButton}>
            Enviar mensaje
          </button>
          {status && (
            <p className={styles.status} role="status" aria-live="polite">
              {status}
            </p>
          )}
        </form>

        <aside className={styles.sidebar}>
          <div className={styles.infoBlock}>
            <h2>Datos de contacto directo</h2>
            <p>
              Paseo de la Castellana 95, 28046 Madrid, Spain<br />
              <a href="tel:+34910473892">+34 910 47 38 92</a><br />
              <a href="mailto:info@eoliacore.com">info@eoliacore.com</a>
            </p>
          </div>
          <div className={styles.infoBlock}>
            <h2>Horario de atención</h2>
            <p>Lunes a viernes · 08:30 - 18:30 CET</p>
          </div>
          <div className={styles.mapWrapper} aria-label="Ubicación en Madrid">
            <iframe
              title="Mapa de EoliaCore Wind Systems en Paseo de la Castellana 95"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.6272916762486!2d-3.69083342412929!3d40.45772905596125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd42290b0aa69d63%3A0x9df2f5bbf69c5f33!2sPaseo%20de%20la%20Castellana%2C%2095%2C%2028046%20Madrid!5e0!3m2!1ses!2ses!4v1716200000000!5m2!1ses!2ses"
              loading="lazy"
            />
          </div>
        </aside>
      </div>
    </div>
  );
};

export default ContactPage;