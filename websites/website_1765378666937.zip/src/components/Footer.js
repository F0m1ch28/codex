import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Pie de página corporativo">
      <div className={styles.container}>
        <div className={styles.columnBrand}>
          <div className={styles.brand}>
            <span className={styles.brandMark}>EoliaCore</span>
            <span className={styles.brandSub}>Wind Systems</span>
          </div>
          <p className={styles.brandDescription}>
            Plataforma española de ingeniería eólica offshore que integra analítica avanzada, simulación oceánica y diseño de infraestructura costera resiliente.
          </p>
          <div className={styles.contactInfo}>
            <a className={styles.contactLink} href="https://maps.app.goo.gl/" target="_blank" rel="noopener noreferrer">
              Paseo de la Castellana 95, 28046 Madrid, Spain
            </a>
            <a className={styles.contactLink} href="tel:+34910473892">
              +34 910 47 38 92
            </a>
            <a className={styles.contactLink} href="mailto:info@eoliacore.com">
              info@eoliacore.com
            </a>
          </div>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Navegación</h4>
          <ul className={styles.linkList}>
            <li><Link to="/" className={styles.footerLink}>Inicio</Link></li>
            <li><Link to="/nosotros" className={styles.footerLink}>Nosotros</Link></li>
            <li><Link to="/investigacion" className={styles.footerLink}>Investigación</Link></li>
            <li><Link to="/soluciones-ingenieria" className={styles.footerLink}>Soluciones</Link></li>
            <li><Link to="/tecnologia" className={styles.footerLink}>Tecnología</Link></li>
            <li><Link to="/contacto" className={styles.footerLink}>Contacto</Link></li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Cumplimiento</h4>
          <ul className={styles.linkList}>
            <li><Link to="/terminos" className={styles.footerLink}>Términos y Condiciones</Link></li>
            <li><Link to="/privacidad" className={styles.footerLink}>Política de Privacidad</Link></li>
            <li><Link to="/cookies" className={styles.footerLink}>Política de Cookies</Link></li>
          </ul>
          <div className={styles.status}>
            <span className={styles.statusLabel}>Miembro</span>
            <span className={styles.statusValue}>Asociación Empresarial Eólica</span>
          </div>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Actualizaciones</h4>
          <p className={styles.newsletterText}>
            Recibe perspectivas técnicas sobre aerodinámica offshore, mantenimiento predictivo y estrategia regulatoria en España.
          </p>
          <form className={styles.newsletterForm} onSubmit={e => e.preventDefault()}>
            <label htmlFor="newsletter-email" className="sr-only">Correo electrónico</label>
            <input
              id="newsletter-email"
              type="email"
              placeholder="Tu correo profesional"
              className={styles.newsletterInput}
              aria-label="Correo electrónico para novedades"
              required
            />
            <button type="submit" className={styles.newsletterButton}>Suscribirme</button>
          </form>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p className={styles.copyright}>
          © {currentYear} EoliaCore Wind Systems. Innovación eólica offshore desde Madrid.
        </p>
      </div>
    </footer>
  );
};

export default Footer;