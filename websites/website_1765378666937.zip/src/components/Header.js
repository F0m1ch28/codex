import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setMenuOpen(prev => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Encabezado principal">
      <div className={styles.container}>
        <div className={styles.logo} aria-label="EoliaCore Wind Systems">
          <span className={styles.logoMark}>EoliaCore</span>
          <span className={styles.logoSub}>Wind Systems</span>
        </div>
        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="navegacion-principal"
          aria-label={menuOpen ? 'Cerrar menú' : 'Abrir menú'}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="navegacion-principal"
          className={`${styles.navigation} ${menuOpen ? styles.navigationOpen : ''}`}
          aria-label="Navegación principal"
        >
          <NavLink to="/" end className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Inicio
          </NavLink>
          <NavLink to="/nosotros" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Nosotros
          </NavLink>
          <NavLink to="/investigacion" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Investigación
          </NavLink>
          <NavLink to="/soluciones-ingenieria" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Soluciones
          </NavLink>
          <NavLink to="/servicios" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Servicios
          </NavLink>
          <NavLink to="/tecnologia" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Tecnología
          </NavLink>
          <NavLink to="/contacto" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Contacto
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;