import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem('eoliacore-cookie-consent');
    if (!stored) {
      setTimeout(() => setVisible(true), 1000);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('eoliacore-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Aviso de cookies">
      <p className={styles.message}>
        Utilizamos cookies analíticas para optimizar nuestros gemelos digitales y ofrecerte métricas fiables. Puedes conocer los detalles en nuestra{' '}
        <Link to="/cookies" className={styles.link}>Política de Cookies</Link>.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.buttonPrimary} onClick={acceptCookies}>
          Entendido
        </button>
        <Link to="/cookies" className={styles.buttonSecondary}>
          Configurar
        </Link>
      </div>
    </div>
  );
};

export default CookieBanner;