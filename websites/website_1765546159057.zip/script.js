```javascript
document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelectorAll(".nav-link");
  const cookieBanner = document.querySelector(".cookie-banner");

  if (navToggle) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      body.classList.toggle("nav-open", !expanded);
    });
  }

  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      if (body.classList.contains("nav-open") && navToggle) {
        body.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  if (cookieBanner) {
    const consent = localStorage.getItem("ite_cookie_consent");
    if (consent === "accepted" || consent === "declined") {
      hideCookieBanner(cookieBanner);
    }

    cookieBanner.addEventListener("click", (event) => {
      const target = event.target;
      if (target.matches("[data-consent]")) {
        const decision = target.getAttribute("data-consent");
        localStorage.setItem("ite_cookie_consent", decision);
        hideCookieBanner(cookieBanner);
      }
    });
  }
});

function hideCookieBanner(banner) {
  banner.classList.add("is-hidden");
  banner.setAttribute("hidden", "");
}
```