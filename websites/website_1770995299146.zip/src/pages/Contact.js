import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';

const ContactsPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, представьтесь, чтобы мы знали, как обратиться к вам.';
    }
    const email = formData.email.trim();
    if (!email) {
      newErrors.email = 'Укажите адрес электронной почты для ответа.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Введите корректный адрес почты.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Расскажите подробнее о запросе (минимум 10 символов).';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setFormData({ name: '', email: '', message: '' });
    navigate('/thank-you', { replace: true });
  };

  return (
    <div className="page-wrapper">
      <Helmet>
        <title>Контакты и безопасность | Rainbow Space</title>
        <meta
          name="description"
          content="Свяжитесь с командой Rainbow Space, узнайте о горячей линии и практиках цифровой безопасности."
        />
      </Helmet>
      <header className="page-header">
        <span className="page-kicker">Контакты и безопасность</span>
        <h1>Мы рядом, когда нужна поддержка</h1>
        <p>
          Свяжитесь с нами безопасным способом. Мы ответим, подберём ресурсы и поможем сориентироваться
          в сложной ситуации. Все обращения остаются конфиденциальными.
        </p>
      </header>

      <section className="section">
        <div className="contact-grid">
          <article className="contact-card">
            <h2>Как с нами связаться</h2>
            <ul className="information-list">
              <li><strong>Email:</strong> <a href="mailto:info@rainbow-space.ru">info@rainbow-space.ru</a></li>
              <li><strong>Горячая линия психологической поддержки:</strong> <a href="tel:8800XXXxxxx">8-800-XXX-XX-XX</a></li>
              <li>Анонимный чат: доступ по запросу — напишите нам письмо, и мы пришлём приглашение.</li>
            </ul>
            <p>Мы стараемся отвечать на письма в течение 24-48 часов. В экстренных случаях лучше звонить на горячую линию.</p>
          </article>
          <article className="contact-card">
            <h2>Цифровая безопасность</h2>
            <p>Перед тем как написать, проверьте, что используете личное устройство и защищённое соединение.</p>
            <ul className="information-list">
              <li>Удалите сообщения после консультации, если делитесь чувствительной информацией.</li>
              <li>Используйте VPN и двухфакторную аутентификацию, когда это возможно.</li>
              <li>Напишите нам, если нужна помощь с настройкой приватности — мы проводим индивидуальные сессии.</li>
            </ul>
          </article>
        </div>
      </section>

      <section className="section alt-bg">
        <div className="contact-form-wrapper">
          <h2 className="section-title">Форма обратной связи</h2>
          <p>Введите краткий запрос, и мы свяжемся в ответном письме. Если хотите, можете использовать псевдоним.</p>
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <label htmlFor="name">Имя (можно псевдоним)</label>
            <input
              type="text"
              id="name"
              name="name"
              className={"input-field ${errors.name ? 'has-error' : ''}"}
              value={formData.name}
              onChange={handleChange}
              placeholder="Как к вам обращаться"
            />
            {errors.name && <span className="error-text">{errors.name}</span>}

            <label htmlFor="email">Электронная почта</label>
            <input
              type="email"
              id="email"
              name="email"
              className={"input-field ${errors.email ? 'has-error' : ''}"}
              value={formData.email}
              onChange={handleChange}
              placeholder="your@email.ru"
            />
            {errors.email && <span className="error-text">{errors.email}</span>}

            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              className={"textarea-field ${errors.message ? 'has-error' : ''}"}
              value={formData.message}
              onChange={handleChange}
              placeholder="Опишите запрос или ситуацию"
              rows={5}
            />
            {errors.message && <span className="error-text">{errors.message}</span>}

            <button type="submit" className="primary-btn">Отправить</button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default ContactsPage;