import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

const ThankYouPage = () => (
  <div className="page-wrapper">
    <Helmet>
      <title>Спасибо за обращение | Rainbow Space</title>
      <meta
        name="description"
        content="Спасибо за обращение в Rainbow Space. Мы свяжемся с вами в ближайшее время."
      />
    </Helmet>
    <section className="section thank-you">
      <h1>Спасибо за доверие!</h1>
      <p>
        Мы получили ваше сообщение и ответим как можно скорее. Если вы не получите письмо в течение двух дней,
        проверьте папку «Спам» или напишите нам повторно.
      </p>
      <Link to="/" className="primary-btn">Вернуться на главную</Link>
    </section>
  </div>
);

export default ThankYouPage;