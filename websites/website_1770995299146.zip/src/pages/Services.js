import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

const resources = [
  {
    title: 'Психологическая поддержка',
    description:
      'Подбор специалистов, работающих с ЛГБТК+ людьми, группы взаимопомощи, практики самопомощи и дыхательные упражнения.',
    tips: ['Индивидуальные консультации', 'Групповые обсуждения', 'Библиотека упражнений']
  },
  {
    title: 'Юридическая безопасность',
    description:
      'Пошаговые инструкции по оформлению документов, защите на работе и взаимодействию с организациями.',
    tips: ['Шаблоны заявлений', 'Гид по правам и возможностям', 'Поддержка юристов-волонтёров']
  },
  {
    title: 'Социальные ресурсы',
    description:
      'Каталог инициатив, горячих линий и кризисных центров, готовых ответить на специфические запросы сообщества.',
    tips: ['Анонимные чаты', 'Проверенные НКО и фонды', 'Инструкции по безопасному обращению']
  },
  {
    title: 'Образовательные материалы',
    description:
      'Статьи, вебинары и подкасты о психическом здоровье, инклюзивности и практиках поддержки друзей и близких.',
    tips: ['Видеолекции', 'Методички для союзников', 'Подборки книг и фильмов']
  }
];

const ResourcesPage = () => (
  <div className="page-wrapper">
    <Helmet>
      <title>Ресурсы и поддержка | Rainbow Space</title>
      <meta
        name="description"
        content="Подборки психологической, юридической и социальной помощи для ЛГБТК+ людей на платформе Rainbow Space."
      />
    </Helmet>
    <header className="page-header">
      <span className="page-kicker">Ресурсы и поддержка</span>
      <h1>Инструменты, которые помогают чувствовать себя увереннее</h1>
      <p>
        Мы собрали проверенные материалы, контакты специалистов и рекомендации сообщества.
        Все ресурсы проходят модерацию и регулярно обновляются.
      </p>
    </header>

    <section className="section">
      <div className="resource-grid">
        {resources.map((resource) => (
          <article className="resource-card" key={resource.title}>
            <h2>{resource.title}</h2>
            <p>{resource.description}</p>
            <ul className="information-list">
              {resource.tips.map((tip) => (
                <li key={tip}>{tip}</li>
              ))}
            </ul>
          </article>
        ))}
      </div>
    </section>

    <section className="section alt-bg">
      <div className="cta-content">
        <h2>Не нашли подходящий ресурс?</h2>
        <p>
          Команда Rainbow Space сопровождает индивидуальные запросы. Мы постараемся найти
          специалиста или вариант помощи, который будет комфортным именно для вас.
        </p>
        <Link to="/contacts" className="primary-btn">Связаться с нами</Link>
      </div>
    </section>
  </div>
);

export default ResourcesPage;