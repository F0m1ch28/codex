import React from 'react';
import { Helmet } from 'react-helmet';

const teamMembers = [
  { name: 'Алексей (он/они)', role: 'Координатор сообщества', image: 'https://picsum.photos/seed/team1/200', bio: 'Организует группы поддержки и отвечает за взаимодействие с партнёрами и экспертами.' },
  { name: 'Лера (она)', role: 'Психолог-консультант', image: 'https://picsum.photos/seed/team2/200', bio: 'Помогает участникам работать с тревогой и стрессом, ведёт обучающие вебинары по самоценности.' },
  { name: 'Сэм (они)', role: 'Специалист по цифровой безопасности', image: 'https://picsum.photos/seed/team3/200', bio: 'Создаёт инструкции по приватности, настраивает защищённые каналы связи и обучает волонтёров.' }
];

const milestones = [
  { year: '2020', detail: 'Первые закрытые онлайн-встречи для подростков и молодых взрослых.' },
  { year: '2021', detail: 'Запуск базы проверенных психологов, готовых работать анонимно и онлайн.' },
  { year: '2022', detail: 'Создание кризисного чата и 24/7 горячей линии вместе с партнёрами.' },
  { year: '2023', detail: 'Обновлённый ресурсный центр, юридический справочник и библиотека материалов.' }
];

const AboutPage = () => (
  <div className="page-wrapper">
    <Helmet>
      <title>О Rainbow Space | Наша история и команда</title>
      <meta
        name="description"
        content="Узнайте, как создавалось безопасное сообщество Rainbow Space, познакомьтесь с командой и ценностями проекта."
      />
    </Helmet>
    <header className="page-header">
      <span className="page-kicker">О нас</span>
      <h1>Rainbow Space — сообщество, которое родилось из взаимной поддержки</h1>
      <p>
        Мы начали как маленькая группа взаимопомощи, а теперь объединяем людей по всей стране.
        Мы продолжаем расти, опираясь на уважение, конфиденциальность и любовь к разнообразию.
      </p>
    </header>

    <section className="section">
      <h2 className="section-title">Наш путь</h2>
      <div className="timeline">
        {milestones.map((item) => (
          <div className="timeline-item" key={item.year}>
            <span className="timeline-year">{item.year}</span>
            <p>{item.detail}</p>
          </div>
        ))}
      </div>
    </section>

    <section className="section alt-bg">
      <h2 className="section-title">Команда Rainbow Space</h2>
      <div className="team-grid">
        {teamMembers.map((member) => (
          <article className="team-card" key={member.name}>
            <img src={member.image} alt={"Команда: ${member.name}"} loading="lazy" />
            <h3>{member.name}</h3>
            <span className="team-role">{member.role}</span>
            <p>{member.bio}</p>
          </article>
        ))}
      </div>
    </section>

    <section className="section">
      <h2 className="section-title">Наши ценности</h2>
      <div className="mission-grid">
        <div className="mission-card">
          <h3>Бережность</h3>
          <p>Каждый диалог проходит через призму заботы и уважения. Мы не допускаем дискриминации и следим за безопасной атмосферой.</p>
        </div>
        <div className="mission-card">
          <h3>Прозрачность</h3>
          <p>Мы открыто рассказываем о процессах, партнёрствах и методах работы. Участники знают, кто и как принимает решения.</p>
        </div>
        <div className="mission-card">
          <h3>Ответственность</h3>
          <p>Команда обучается у специалистов и постоянно повышает квалификацию, чтобы помочь эффективно и профессионально.</p>
        </div>
      </div>
    </section>
  </div>
);

export default AboutPage;