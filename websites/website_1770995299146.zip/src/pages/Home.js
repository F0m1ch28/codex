import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

const quickLinks = [
  {
    title: 'Ресурсы и поддержка',
    description: 'Подборки психологической, юридической и социальной помощи.',
    to: '/resources',
    accent: '#FF0018'
  },
  {
    title: 'События и встречи',
    description: 'Безопасные онлайн и офлайн форматы общения и обучения.',
    to: '/events',
    accent: '#008018'
  },
  {
    title: 'Истории сообщества',
    description: 'Блог с вдохновляющими рассказами и практическими советами.',
    to: '/blog',
    accent: '#0000F9'
  }
];

const testimonials = [
  {
    name: 'Аня, 24',
    quote:
      '«Rainbow Space — первое место, где я смогла честно сказать о себе. Поддержка модераторов и участников просто бесценна.»',
    avatar: 'https://picsum.photos/seed/rainbow1/96'
  },
  {
    name: 'Илья, 29',
    quote:
      '«Участие в онлайн-группе помогло справиться с тревогой. Рад, что нашёл людей с похожим опытом.»',
    avatar: 'https://picsum.photos/seed/rainbow2/96'
  },
  {
    name: 'Диана, 31',
    quote:
      '«Спасибо за раздел с юридическими советами. Они помогли мне спокойно оформить документы и почувствовать контроль над ситуацией.»',
    avatar: 'https://picsum.photos/seed/rainbow3/96'
  }
];

const galleryImages = [
  { src: 'https://picsum.photos/seed/pride11/480/320', alt: 'Абстрактные радужные волны' },
  { src: 'https://picsum.photos/seed/pride12/480/320', alt: 'Световые линии в цветах радуги' },
  { src: 'https://picsum.photos/seed/pride13/480/320', alt: 'Люди держатся за руки в круге' },
  { src: 'https://picsum.photos/seed/pride14/480/320', alt: 'Мягкие градиенты в тёплых цветах' }
];

const HomePage = () => (
  <div className="home-page">
    <Helmet>
      <title>Rainbow Space — безопасное пространство для ЛГБТК+ людей</title>
      <meta
        name="description"
        content="Rainbow Space (Радужное пространство) — современное сообщество поддержки и информационный ресурс для ЛГБТК+ людей в России."
      />
    </Helmet>
    <section className="hero">
      <div className="container hero-content">
        <div className="hero-text">
          <span className="hero-kicker">Радужное Пространство</span>
          <h1 className="hero-title">Безопасное пространство для каждого</h1>
          <p className="hero-subtitle">
            Сообщество Rainbow Space объединяет людей, готовых поддерживать, делиться опытом
            и создавать культуру уважения. Здесь можно получить помощь, знания и вдохновение,
            оставаясь в безопасности.
          </p>
          <div className="hero-actions">
            <Link to="/resources" className="primary-btn">Перейти к ресурсам</Link>
            <Link to="/contacts" className="secondary-btn">Нужна помощь</Link>
          </div>
        </div>
        <div className="hero-visual" aria-hidden="true">
          <div className="hero-rainbow" />
          <div className="hero-quote">
            <p>
              «Когда рядом есть люди, которые принимают меня, мне становится легче дышать. Rainbow Space стал именно таким местом.»
            </p>
            <span>— участница сообщества</span>
          </div>
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <h2 className="section-title">Наша миссия</h2>
        <p className="section-subtitle">
          Мы создаём пространство, где доступна профессиональная помощь и дружеская поддержка.
          Здесь безопасно говорить о себе, учиться и строить планы на будущее.
        </p>
        <div className="mission-grid">
          <div className="mission-card">
            <h3>Поддержка 24/7</h3>
            <p>Кураторская команда и волонтёры помогают найти ресурсы в сложных ситуациях и остаются рядом столько, сколько нужно.</p>
          </div>
          <div className="mission-card">
            <h3>Информация без страха</h3>
            <p>Мы проверяем рекомендации, юридические советы и материалы специалистов, чтобы информация была актуальной и безопасной.</p>
          </div>
          <div className="mission-card">
            <h3>Сообщество равных</h3>
            <p>У каждого есть голос. Мы ценим разнообразие опыта и поддерживаем диалог, основанный на уважении и осторожности.</p>
          </div>
        </div>
      </div>
    </section>

    <section className="section alt-bg">
      <div className="container">
        <h2 className="section-title">Быстрый доступ к важному</h2>
        <div className="quick-links">
          {quickLinks.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="quick-link-card"
              style={{ borderTopColor: item.accent }}
            >
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <span className="quick-link-arrow" aria-hidden="true">→</span>
            </Link>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container support-section">
        <div className="support-card">
          <h2 className="section-title">Зачем нужна поддержка</h2>
          <p>
            Жить открыто — смелый шаг, особенно в условиях неопределённости. Мы не требуем откровенности:
            каждый сам решает, что рассказать о себе. Главное — знать, что рядом есть те, кто понял и
            принял твой путь.
          </p>
          <p>
            Вместе мы создаём практики заботы — взаимное прослушивание, совместные проекты и фокус на
            психическом здоровье. Если тяжело, обязательно расскажи нам об этом.
          </p>
        </div>
        <div className="support-card emphasis">
          <h3>Как мы обеспечиваем безопасность</h3>
          <ul className="information-list">
            <li>Анонимные никнеймы и закрытые группы без публичных ссылок.</li>
            <li>Модерация диалогов и оперативная реакция на тревожные ситуации.</li>
            <li>Шифрованные каналы связи и индивидуальные консультации по защите данных.</li>
          </ul>
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <h2 className="section-title">Отзывы участников</h2>
        <div className="testimonials-grid">
          {testimonials.map((item) => (
            <article className="testimonial-card" key={item.name}>
              <img src={item.avatar} alt={"Фото участника ${item.name}"} loading="lazy" />
              <blockquote className="testimonial-text">{item.quote}</blockquote>
              <span className="testimonial-author">{item.name}</span>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section alt-bg">
      <div className="container">
        <h2 className="section-title">Галерея радужных настроений</h2>
        <div className="gallery-grid">
          {galleryImages.map((image) => (
            <figure className="gallery-item" key={image.src}>
              <img src={image.src} alt={image.alt} loading="lazy" />
            </figure>
          ))}
        </div>
      </div>
    </section>

    <section className="section cta-section">
      <div className="container cta-content">
        <h2>Присоединись к ежемесячной рассылке</h2>
        <p>
          Получай подборки ресурсов, анонсы встреч и истории людей, которые вдохновляют. Мы пишем
          аккуратно и без лишних писем.
        </p>
        <Link to="/contacts" className="primary-btn">Оставить контакт</Link>
      </div>
    </section>
  </div>
);

export default HomePage;