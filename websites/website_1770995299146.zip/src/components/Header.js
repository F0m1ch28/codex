import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

const navLinks = [
  { to: '/', label: 'Главная' },
  { to: '/about', label: 'О нас' },
  { to: '/resources', label: 'Ресурсы' },
  { to: '/events', label: 'События' },
  { to: '/blog', label: 'Блог' },
  { to: '/contacts', label: 'Контакты' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const handleLinkClick = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link to="/" className="logo" aria-label="Rainbow Space — перейти на главную">
          <span className="logo-mark" aria-hidden="true">🌈</span>
          Rainbow Space
        </Link>
        <button
          className={"nav-toggle ${isMenuOpen ? 'open' : ''}"}
          onClick={handleToggle}
          aria-label="Открыть меню"
          aria-expanded={isMenuOpen}
        >
          <span className="nav-toggle-bar" />
          <span className="nav-toggle-bar" />
          <span className="nav-toggle-bar" />
        </button>
        <nav className={"main-nav ${isMenuOpen ? 'open' : ''}"} aria-label="Основное меню">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => "nav-link ${isActive ? 'active' : ''}"}
              onClick={handleLinkClick}
            >
              {link.label}
            </NavLink>
          ))}
          <div className="nav-legal">
            <Link to="/terms" className="nav-link meta-link" onClick={handleLinkClick}>
              Условия
            </Link>
            <Link to="/privacy" className="nav-link meta-link" onClick={handleLinkClick}>
              Конфиденциальность
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;