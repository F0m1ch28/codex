import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer">
    <div className="container footer-inner">
      <div className="footer-column">
        <h3>Rainbow Space</h3>
        <p>
          Радужное пространство поддержки для ЛГБТК+ людей в России и русскоязычных странах. Мы создаём место,
          где слышат, уважают и помогают.
        </p>
        <div className="social-links" aria-label="Социальные сети">
          <a href="https://t.me" target="_blank" rel="noopener noreferrer">Telegram</a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">Instagram*</a>
          <a href="https://vk.com" target="_blank" rel="noopener noreferrer">VK</a>
        </div>
        <small className="footer-note">*Запрещённая в РФ организация — ссылка ведёт на информационные материалы сообщества.</small>
      </div>
      <div className="footer-column">
        <h4>Навигация</h4>
        <ul>
          <li><Link to="/">Главная</Link></li>
          <li><Link to="/resources">Ресурсы и поддержка</Link></li>
          <li><Link to="/events">События</Link></li>
          <li><Link to="/blog">Блог</Link></li>
        </ul>
      </div>
      <div className="footer-column">
        <h4>Контакты</h4>
        <ul>
          <li><Link to="/contacts">Телефон: 8-800-XXX-XX-XX</Link></li>
          <li><Link to="/contacts">info@rainbow-space.ru</Link></li>
          <li><Link to="/cookie-policy">Cookie</Link></li>
          <li><Link to="/privacy">Политика конфиденциальности</Link></li>
          <li><Link to="/terms">Условия использования</Link></li>
        </ul>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} Rainbow Space. Бережное сообщество, построенное вместе.</p>
    </div>
  </footer>
);

export default Footer;