import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('rainbow-space-cookie-consent');
    if (!storedConsent) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem('rainbow-space-cookie-consent', choice);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
    }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          Мы используем файлы cookie, чтобы запомнить ваши настройки и сделать сайт стабильным.
          Вы можете узнать подробности в <Link to="/cookie-policy">политике использования cookie</Link>.
        </p>
        <div className="cookie-actions">
          <button type="button" className="secondary-btn" onClick={() => handleChoice('declined')}>
            Отклонить
          </button>
          <button type="button" className="primary-btn" onClick={() => handleChoice('accepted')}>
            Принять
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;