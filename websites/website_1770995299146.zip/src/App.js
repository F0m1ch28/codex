import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import ResourcesPage from './pages/Services';
import ContactsPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsPage from './pages/TermsOfService';
import PrivacyPage from './pages/PrivacyPolicy';

const EventsPage = () => (
  <div className="page-wrapper">
    <Helmet>
      <title>События и новости | Rainbow Space</title>
      <meta
        name="description"
        content="Актуальные события, новостные дайджесты и безопасные встречи Rainbow Space для ЛГБТК+ сообщества."
      />
    </Helmet>
    <header className="page-header">
      <span className="page-kicker">События и новости</span>
      <h1>Будь в курсе, но выбирай что подходит тебе</h1>
      <p>
        Мы делимся безопасными форматами участия — от камерных онлайн-встреч до образовательных
        семинаров и новостей сообщества. Ты сам(а) выбираешь, когда и в каком формате присоединиться.
      </p>
    </header>
    <section className="section">
      <h2 className="section-title">Ближайшие события</h2>
      <div className="events-grid">
        <article className="event-card">
          <h3>Онлайн-встреча «Голос и поддержка»</h3>
          <p>Закрытая группа взаимопомощи с участием психолога. Регистрация обязательна, количество мест ограничено.</p>
          <ul className="information-list">
            <li>Формат: видеоконференция с модератором</li>
            <li>Дата: каждый второй вторник месяца</li>
            <li>Регистрация через форму обратной связи</li>
          </ul>
        </article>
        <article className="event-card">
          <h3>Образовательный вебинар «Права и возможности»</h3>
          <p>Практические советы по юридической безопасности, взаимодействию с работодателем и защите личных границ.</p>
          <ul className="information-list">
            <li>Спикер: правозащитная инициатива «Равные»</li>
            <li>Формат вопросов — анонимный чат</li>
            <li>Запись доступна зарегистрированным участникам</li>
          </ul>
        </article>
        <article className="event-card">
          <h3>Радужные выходные в формате «тихой вечеринки»</h3>
          <p>Небольшое офлайн-пространство, где можно расслабиться, познакомиться и почувствовать безопасность.</p>
          <ul className="information-list">
            <li>Локация сообщается после регистрации</li>
            <li>Действует правило «никаких фото без согласия»</li>
            <li>Поддержка менторов на площадке</li>
          </ul>
        </article>
      </div>
    </section>
    <section className="section">
      <h2 className="section-title">Как мы отбираем новости</h2>
      <div className="mission-grid">
        <div className="mission-card">
          <h3>Безопасность на первом месте</h3>
          <p>Новости проверяются кураторской командой: мы не публикуем материалы, которые могут раскрыть личность или навредить читателям.</p>
        </div>
        <div className="mission-card">
          <h3>Фокус на устойчивости</h3>
          <p>Мы делимся историями, которые вдохновляют, поддерживают и помогают бережно проживать сложные темы.</p>
        </div>
        <div className="mission-card">
          <h3>Простота участия</h3>
          <p>Каждое событие сопровождается чётким описанием условий, требований и каналов связи с организаторами.</p>
        </div>
      </div>
    </section>
    <section className="section cta-section">
      <div className="cta-content">
        <h2>Хочешь предложить своё мероприятие?</h2>
        <p>Напиши нам, и команда модераторов поможет адаптировать формат под безопасные правила сообщества Rainbow Space.</p>
      </div>
    </section>
  </div>
);

const BlogPage = () => (
  <div className="page-wrapper">
    <Helmet>
      <title>Блог и истории | Rainbow Space</title>
      <meta
        name="description"
        content="Личные истории, инструкции по безопасности и экспертные статьи для ЛГБТК+ людей на платформе Rainbow Space."
      />
    </Helmet>
    <header className="page-header">
      <span className="page-kicker">Блог / Статьи</span>
      <h1>Голоса сообщества и практичные рекомендации</h1>
      <p>
        В блоге Rainbow Space мы делимся опытами, которые помогают справляться с ежедневными вызовами,
        сохранять психическое здоровье и находить поддержку рядом.
      </p>
    </header>
    <section className="section">
      <div className="blog-grid">
        <article className="blog-card">
          <span className="tag">Истории</span>
          <h2>Путь к принятию: как я нашла своё безопасное пространство</h2>
          <p>
            Марина делится, как переписка в анонимном чатике переросла в крепкую дружбу и чувство защищенности.
            Полезные советы, как аккуратно знакомиться и сохранять конфиденциальность.
          </p>
          <small>Автор: Марина, участница сообщества</small>
        </article>
        <article className="blog-card">
          <span className="tag">Инструкция</span>
          <h2>Цифровая гигиена для ЛГБТК+ людей</h2>
          <p>
            Разбираем, как настроить приватность в соцсетях, защитить переписку и не потерять связь с близкими.
            Подборка доступных приложений и чек-лист по безопасности.
          </p>
          <small>Автор: техно-эксперт RainTech</small>
        </article>
        <article className="blog-card">
          <span className="tag">Эксперт</span>
          <h2>Поддержка подростков: советы для родителей</h2>
          <p>
            Психолог Юлия рассказывает, как говорить с ребёнком о идентичности, что делать с тревогой и где найти
            профессиональную помощь в русскоязычном пространстве.
          </p>
          <small>Автор: Юлия Грин, психолог</small>
        </article>
      </div>
    </section>
    <section className="section">
      <h2 className="section-title">Как поделиться своей историей</h2>
      <p>
        Любая история, вопрос или заметка проходит деликатную модерацию. Мы всегда можем скрыть личные данные,
        отредактировать текст вместе с вами и помочь подобрать иллюстрации. Напишите нам через форму на странице
        «Контакты», и редактор откликнется в течение двух дней.
      </p>
    </section>
  </div>
);

const CookiePolicyPage = () => (
  <div className="page-wrapper">
    <Helmet>
      <title>Политика использования cookie | Rainbow Space</title>
      <meta
        name="description"
        content="Как сайт Rainbow Space использует cookie-файлы и какие настройки конфиденциальности доступны пользователям."
      />
    </Helmet>
    <header className="page-header">
      <span className="page-kicker">Правовая информация</span>
      <h1>Политика использования файлов cookie</h1>
      <p>
        Мы используем минимальный набор cookie, чтобы сайт Rainbow Space работал стабильно и оставался
        комфортным для посетителей. Ниже описано, что именно сохраняется и какие у вас есть выборы.
      </p>
    </header>
    <section className="section legal-section">
      <h2>1. Основные понятия</h2>
      <p>
        Cookie — это небольшие текстовые файлы, которые сохраняются в вашем браузере. Они помогают нам
        помнить ваши настройки и улучшать качество сервиса, не нарушая приватность.
      </p>
      <h2>2. Какие cookie мы используем</h2>
      <ul className="legal-list">
        <li><strong>Технические cookie</strong> — нужны для работы формы обратной связи и сохранения выбранного языка.</li>
        <li><strong>Cookie согласия</strong> — фиксируют ваш выбор «Принять» или «Отклонить» в баннере.</li>
        <li>Мы не используем файлы cookie для рекламного таргетинга или профилирования.</li>
      </ul>
      <h2>3. Как управлять cookie</h2>
      <p>
        Баннер при первом посещении позволяет принять или отклонить использование cookie. Вы можете в любой момент очистить их
        через настройки браузера и перезагрузить страницу — баннер появится снова. Технические файлы, необходимые
        для работы сайта, можно отключить в настройках браузера, но это может повлиять на функциональность.
      </p>
      <h2>4. Контакты</h2>
      <p>
        По вопросам обработки cookie напишите нам на <a href="/contacts">страницу контактов</a>. Мы ответим в течение двух рабочих дней.
      </p>
    </section>
  </div>
);

const App = () => (
  <div className="app-shell">
    <Helmet>
      <html lang="ru" />
    </Helmet>
    <Header />
    <main className="main-content">
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/resources" element={<ResourcesPage />} />
        <Route path="/events" element={<EventsPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/contacts" element={<ContactsPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/cookie-policy" element={<CookiePolicyPage />} />
        <Route path="/thank-you" element={<ThankYouPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </div>
);

export default App;