document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('primary-navigation');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookies = document.getElementById('acceptCookies');
    const yearSpan = document.getElementById('current-year');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 600) {
                    navMenu.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
                document.getElementById('scrollTopBtn')?.classList.remove('show');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    const handleScroll = () => {
        if (window.scrollY > 300) {
            scrollBtn?.classList.add('show');
        } else {
            scrollBtn?.classList.remove('show');
        }
    };

    window.addEventListener('scroll', handleScroll);

    scrollBtn?.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const cookieConsent = localStorage.getItem('pureMapleCookieConsent');

    if (!cookieConsent && cookieBanner) {
        cookieBanner.style.display = 'flex';
    } else if (cookieBanner) {
        cookieBanner.style.display = 'none';
    }

    acceptCookies?.addEventListener('click', () => {
        localStorage.setItem('pureMapleCookieConsent', 'accepted');
        if (cookieBanner) {
            cookieBanner.style.display = 'none';
        }
    });
});