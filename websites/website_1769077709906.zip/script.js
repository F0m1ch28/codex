(function () {
  const storageAvailable = (() => {
    try {
      const testKey = '__dse_test__';
      window.localStorage.setItem(testKey, testKey);
      window.localStorage.removeItem(testKey);
      return true;
    } catch (error) {
      return false;
    }
  })();

  const storage = storageAvailable ? window.localStorage : {
    getItem: () => null,
    setItem: () => undefined
  };

  let toastTimeout;
  let toastElement;

  function getToastElement() {
    if (!toastElement) {
      toastElement = document.createElement('div');
      toastElement.className = 'toast';
      document.body.appendChild(toastElement);
    }
    return toastElement;
  }

  function showToast(message) {
    const el = getToastElement();
    el.textContent = message;
    el.classList.add('is-visible');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      el.classList.remove('is-visible');
    }, 3200);
  }

  function initNavigation() {
    const navToggle = document.querySelector('.mobile-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
      navToggle.addEventListener('click', () => {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        navList.classList.toggle('is-open');
      });

      navList.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
          navList.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        });
      });
    }
  }

  function initAnimations() {
    const animatedItems = document.querySelectorAll('[data-animate]');
    if (!animatedItems.length) {
      return;
    }

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      animatedItems.forEach((item) => item.classList.add('is-visible'));
      return;
    }

    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.25, rootMargin: '0px 0px -50px 0px' }
    );

    animatedItems.forEach((item) => observer.observe(item));
  }

  function initCookieBanner() {
    const banner = document.querySelector('[data-cookie-banner]');
    if (!banner) {
      return;
    }

    const storedChoice = storage.getItem('dse_cookie_choice');
    if (storedChoice) {
      banner.classList.add('hidden');
      return;
    }

    const acceptBtn = banner.querySelector('[data-cookie-accept]');
    const declineBtn = banner.querySelector('[data-cookie-decline]');

    const handleChoice = (choice) => {
      storage.setItem('dse_cookie_choice', choice);
      banner.classList.add('hidden');
      showToast(choice === 'accepted' ? 'Preferencias de cookies registradas.' : 'Cookies analíticas desactivadas.');
    };

    acceptBtn?.addEventListener('click', () => handleChoice('accepted'));
    declineBtn?.addEventListener('click', () => handleChoice('declined'));
  }

  function initForms() {
    const forms = document.querySelectorAll('form[data-redirect]');
    forms.forEach((form) => {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const redirectTarget = form.getAttribute('data-redirect') || 'thank-you.html';
        showToast('Formulario enviado. Redirigiendo...');
        setTimeout(() => {
          window.location.href = redirectTarget;
        }, 1200);
      });
    });
  }

  function ready() {
    initNavigation();
    initAnimations();
    initCookieBanner();
    initForms();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ready);
  } else {
    ready();
  }
})();