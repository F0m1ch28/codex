(function () {
  document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var mainNav = document.querySelector('.main-nav');
    if (navToggle && mainNav) {
      navToggle.addEventListener('click', function () {
        var expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        mainNav.classList.toggle('open');
      });
      mainNav.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          mainNav.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        });
      });
    }

    var cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
      var acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
      var declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
      var storageKey = 'noel-atelier-cookie-choice';
      var storedChoice = null;
      try {
        storedChoice = localStorage.getItem(storageKey);
      } catch (error) {
        storedChoice = null;
      }
      if (!storedChoice) {
        setTimeout(function () {
          cookieBanner.classList.add('show');
        }, 600);
      }
      function setChoice(choice) {
        try {
          localStorage.setItem(storageKey, choice);
        } catch (error) {
          /* localStorage unavailable */
        }
        cookieBanner.classList.remove('show');
      }
      if (acceptBtn) {
        acceptBtn.addEventListener('click', function () {
          setChoice('accepted');
        });
      }
      if (declineBtn) {
        declineBtn.addEventListener('click', function () {
          setChoice('declined');
        });
      }
    }

    var builderForm = document.getElementById('builderForm');
    if (builderForm) {
      var preview = {
        title: document.getElementById('previewTitle'),
        theme: document.getElementById('previewTheme'),
        image: document.getElementById('previewImage'),
        price: document.getElementById('previewPrice'),
        message: document.getElementById('previewMessage'),
        delivery: document.getElementById('previewDelivery')
      };
      var charCounter = builderForm.querySelector('[data-char-count]');
      var themeSelect = builderForm.querySelector('[name="theme"]');
      var sizeSelect = builderForm.querySelector('[name="size"]');
      var treatSelect = builderForm.querySelector('[name="treat"]');
      var deliveryDate = builderForm.querySelector('[name="delivery-date"]');
      var messageField = builderForm.querySelector('[name="message"]');
      var addonInputs = builderForm.querySelectorAll('input[type="checkbox"][data-addon]');
      var themeLibrary = {
        'christmas-magic': {
          title: 'Christmas Magic',
          description: 'Twinkling reds, evergreen accents, cinnamon warmth.',
          image: 'https://picsum.photos/seed/christmasmagic/640/420'
        },
        'birthday-spark': {
          title: 'Birthday Spark',
          description: 'Confetti hues, birthday ribbons, celebratory sparkle.',
          image: 'https://picsum.photos/seed/birthdayspark/640/420'
        },
        'winter-spa': {
          title: 'Winter Spa Serenity',
          description: 'Snowy whites, eucalyptus calm, spa indulgences.',
          image: 'https://picsum.photos/seed/winterspa/640/420'
        },
        'gourmet-luxe': {
          title: 'Gourmet Luxe',
          description: 'Handcrafted truffles, fine cheeses, artisan delights.',
          image: 'https://picsum.photos/seed/gourmetluxe/640/420'
        }
      };
      var sizeCosts = {
        petite: 75,
        classic: 105,
        grand: 145
      };
      var treatCosts = {
        gourmet: 0,
        sparkling: 18,
        pamper: 22
      };
      function formatCurrency(value) {
        return '$' + value.toFixed(2);
      }
      function updatePreview() {
        var selectedTheme = themeSelect ? themeSelect.value : null;
        var selectedSize = sizeSelect ? sizeSelect.value : 'petite';
        var selectedTreat = treatSelect ? treatSelect.value : 'gourmet';
        var themeData = themeLibrary[selectedTheme] || themeLibrary['christmas-magic'];
        var total = sizeCosts[selectedSize] || 0;
        total += treatCosts[selectedTreat] || 0;
        addonInputs.forEach(function (input) {
          if (input.checked) {
            var addonPrice = Number(input.getAttribute('data-addon')) || 0;
            total += addonPrice;
          }
        });
        if (preview.title && themeData) {
          preview.title.textContent = themeData.title + ' Gift Box';
        }
        if (preview.theme) {
          var sizeText = selectedSize.charAt(0).toUpperCase() + selectedSize.slice(1);
          var description = themeData ? themeData.description : '';
          preview.theme.textContent = sizeText + ' • ' + description;
        }
        if (preview.image && themeData) {
          preview.image.src = themeData.image;
          preview.image.alt = themeData.title + ' gift box preview';
        }
        if (preview.price) {
          preview.price.textContent = formatCurrency(total);
        }
        if (preview.delivery) {
          if (deliveryDate && deliveryDate.value) {
            var deliveryValue = new Date(deliveryDate.value + 'T00:00:00');
            var formatted = deliveryValue.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
            preview.delivery.textContent = 'Scheduled for ' + formatted + '.';
          } else {
            preview.delivery.textContent = 'Flexible dispatch within 48 hours.';
          }
        }
        if (preview.message) {
          var messageValue = messageField ? messageField.value.trim() : '';
          preview.message.textContent = messageValue ? '“' + messageValue + '”' : '“Your message will appear here in beautiful calligraphy.”';
        }
        if (charCounter && messageField) {
          var max = Number(messageField.getAttribute('maxlength')) || 150;
          var remaining = Math.max(0, max - messageField.value.length);
          charCounter.textContent = remaining + ' characters remaining';
        }
      }
      builderForm.addEventListener('input', updatePreview);
      builderForm.addEventListener('change', updatePreview);
      updatePreview();
    }

    var filterButtons = document.querySelectorAll('[data-filter]');
    var occasionCards = document.querySelectorAll('[data-occasion]');
    if (filterButtons.length && occasionCards.length) {
      filterButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          var target = button.getAttribute('data-filter');
          filterButtons.forEach(function (btn) {
            btn.classList.remove('is-active');
          });
          button.classList.add('is-active');
          occasionCards.forEach(function (card) {
            var category = card.getAttribute('data-occasion');
            if (target === 'all' || category === target) {
              card.classList.remove('is-hidden');
            } else {
              card.classList.add('is-hidden');
            }
          });
        });
      });
    }
  });
})();