(function () {
  const helpers = {
    formatPhone(phone) {
      if (typeof phone !== "string") return "";
      const cleaned = phone.replace(/[^\d+]/g, "");
      return cleaned;
    },
    currentYear() {
      return new Date().getFullYear();
    }
  };

  window.blhankHelpers = helpers;
})();