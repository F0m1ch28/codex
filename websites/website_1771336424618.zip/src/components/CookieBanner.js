import React from "react";
import styles from "./CookieBanner.module.css";

const STORAGE_KEY = "blhank_cookie_consent";

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Cookie Notice</h4>
        <p>
          We use cookies to improve your experience, analyze usage, and tailor insights for our US audience.
          You can manage your preferences anytime in our cookie policy.
        </p>
        <div className={styles.actions}>
          <button onClick={acceptCookies} className={styles.primary}>
            Accept
          </button>
          <button onClick={declineCookies} className={styles.secondary}>
            Decline
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;