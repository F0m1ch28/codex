import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isScrolled, setIsScrolled] = React.useState(false);
  const menuButtonRef = React.useRef(null);
  const navigate = useNavigate();

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  React.useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setIsMenuOpen(false);
        menuButtonRef.current?.focus();
      }
    };
    if (isMenuOpen) {
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isMenuOpen]);

  const closeMenuAndNavigate = (path) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <header className={"${styles.header} ${isScrolled ? styles.scrolled : ""}"}>
      <div className={styles.inner}>
        <button
          className={styles.brand}
          onClick={() => closeMenuAndNavigate("/")}
          aria-label="blhank home"
        >
          blhank
        </button>
        <nav
          className={"${styles.nav} ${isMenuOpen ? styles.open : ""}"}
          aria-label="Main navigation"
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ""}"
            }
            onClick={() => setIsMenuOpen(false)}
          >
            Home
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ""}"
            }
            onClick={() => setIsMenuOpen(false)}
          >
            About
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ""}"
            }
            onClick={() => setIsMenuOpen(false)}
          >
            Services
          </NavLink>
          <NavLink
            to="/cases"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ""}"
            }
            onClick={() => setIsMenuOpen(false)}
          >
            Cases
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ""}"
            }
            onClick={() => setIsMenuOpen(false)}
          >
            Blog
          </NavLink>
          <NavLink
            to="/careers"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ""}"
            }
            onClick={() => setIsMenuOpen(false)}
          >
            Careers
          </NavLink>
          <NavLink
            to="/contacts"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ""}"
            }
            onClick={() => setIsMenuOpen(false)}
          >
            Contact
          </NavLink>
        </nav>
        <button
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation menu"
          ref={menuButtonRef}
        >
          <span className={styles.menuIcon} />
        </button>
      </div>
    </header>
  );
};

export default Header;