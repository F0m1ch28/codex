import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  const year = window.blhankHelpers?.currentYear
    ? window.blhankHelpers.currentYear()
    : new Date().getFullYear();

  return (
    <footer className={styles.footer} aria-labelledby="footer-title">
      <div className={styles.inner}>
        <div className={styles.brandBlock}>
          <h2 id="footer-title" className={styles.title}>
            blhank
          </h2>
          <p className={styles.tagline}>
            Advancing bank independent growth for forward-looking companies across the United States.
          </p>
          <div className={styles.socials}>
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              <span aria-hidden="true">in</span>
            </a>
            <a
              href="https://www.twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Twitter"
            >
              <span aria-hidden="true">tw</span>
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
            >
              <span aria-hidden="true">yt</span>
            </a>
          </div>
        </div>

        <div className={styles.linksBlock}>
          <h3 className={styles.columnTitle}>Company</h3>
          <Link to="/about" className={styles.link}>
            About
          </Link>
          <Link to="/services" className={styles.link}>
            Services
          </Link>
          <Link to="/cases" className={styles.link}>
            Case Studies
          </Link>
          <Link to="/careers" className={styles.link}>
            Careers
          </Link>
          <Link to="/blog" className={styles.link}>
            Insights
          </Link>
        </div>

        <div className={styles.linksBlock}>
          <h3 className={styles.columnTitle}>Support</h3>
          <Link to="/privacy-policy" className={styles.link}>
            Privacy Policy
          </Link>
          <Link to="/terms-conditions" className={styles.link}>
            Terms &amp; Conditions
          </Link>
          <Link to="/disclaimer" className={styles.link}>
            Disclaimer
          </Link>
          <Link to="/cookie-policy" className={styles.link}>
            Cookie Policy
          </Link>
        </div>

        <div className={styles.contactBlock}>
          <h3 className={styles.columnTitle}>Contact</h3>
          <button
            type="button"
            className={styles.contactLink}
            onClick={() => window.location.assign("/contacts")}
          >
            +1 802-383-1500
          </button>
          <button
            type="button"
            className={styles.contactLink}
            onClick={() => window.location.assign("/contacts")}
          >
            info@blhank.pro
          </button>
          <address className={styles.address}>
            Itech Us Inc
            <br />
            20 Kimball Ave #303n
            <br />
            South Burlington, VT 05403
          </address>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>&copy; {year} blhank. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;