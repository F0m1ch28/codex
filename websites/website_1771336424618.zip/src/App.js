import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTopButton from "./components/ScrollToTop";
import HomePage from "./pages/Home";
import AboutPage from "./pages/About";
import ServicesPage from "./pages/Services";
import BlogPage from "./pages/Blog";
import CasesPage from "./pages/Cases";
import CareersPage from "./pages/Careers";
import ContactPage from "./pages/Contact";
import ThankYouPage from "./pages/ThankYou";
import TermsOfServicePage from "./pages/TermsOfService";
import PrivacyPolicyPage from "./pages/PrivacyPolicy";
import DisclaimerPage from "./pages/Disclaimer";
import CookiePolicyPage from "./pages/CookiePolicy";
import NotFoundPage from "./pages/NotFound";
import styles from "./App.module.css";

const RouteChangeHandler = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname]);

  return null;
};

function App() {
  return (
    <div className={styles.appShell}>
      <RouteChangeHandler />
      <Header />
      <main className={styles.mainContent} id="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/cases" element={<CasesPage />} />
          <Route path="/careers" element={<CareersPage />} />
          <Route path="/contacts" element={<ContactPage />} />
          <Route path="/thank-you" element={<ThankYouPage />} />
          <Route path="/terms-conditions" element={<TermsOfServicePage />} />
          <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
          <Route path="/disclaimer" element={<DisclaimerPage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;