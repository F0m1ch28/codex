import React from "react";
import { Helmet } from "react-helmet";
import { useNavigate } from "react-router-dom";
import styles from "./Contact.module.css";

const initialState = {
  name: "",
  email: "",
  message: ""
};

const ContactPage = () => {
  const [formData, setFormData] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Please share your name.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "We need a valid email address to respond.";
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      newErrors.email = "Enter a valid email address.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Tell us how we can help.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setFormData(initialState);
    navigate("/thank-you", { replace: true });
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact blhank | Schedule a Consultation</title>
        <meta
          name="description"
          content="Reach blhank to discuss bank independent strategies. Call +1 802-383-1500 or email info@blhank.pro."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Let’s explore your bank independent roadmap.</h1>
        <p>
          Share your priorities and our strategists will respond within one business day. Together we’ll design an
          engagement that matches your pace.
        </p>
      </header>

      <section className={styles.layout}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formGroup}>
            <label htmlFor="name">Full name</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? "name-error" : undefined}
              required
            />
            {errors.name && (
              <span className={styles.error} id="name-error">
                {errors.name}
              </span>
            )}
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="email">Work email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? "email-error" : undefined}
              required
            />
            {errors.email && (
              <span className={styles.error} id="email-error">
                {errors.email}
              </span>
            )}
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="message">How can we help?</label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows="6"
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? "message-error" : undefined}
              required
            />
            {errors.message && (
              <span className={styles.error} id="message-error">
                {errors.message}
              </span>
            )}
          </div>

          <button type="submit" className={styles.submitButton}>
            Submit and connect
          </button>
        </form>

        <aside className={styles.details} aria-labelledby="contact-details-heading">
          <h2 id="contact-details-heading">Contact details</h2>
          <p className={styles.detailHighlight}>
            Phone: <a href="tel:+18023831500">+1 802-383-1500</a>
          </p>
          <p className={styles.detailHighlight}>
            Email: <a href="mailto:info@blhank.pro">info@blhank.pro</a>
          </p>
          <p>Itech Us Inc</p>
          <address>
            20 Kimball Ave #303n<br />
            South Burlington, VT 05403
          </address>
          <img
            src="https://images.unsplash.com/photo-1529429617124-aee01c999332?auto=format&fit=crop&w=1200&q=80"
            alt="View of blhank South Burlington office exterior"
            loading="lazy"
          />
        </aside>
      </section>
    </div>
  );
};

export default ContactPage;