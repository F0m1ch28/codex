import React from "react";
import { Helmet } from "react-helmet";
import styles from "./LegalPage.module.css";

const PrivacyPolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Privacy Policy | blhank</title>
      <meta
        name="description"
        content="Learn how blhank collects, uses, and protects personal information from clients and website visitors."
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Privacy Policy</h1>
      <p>Effective date: January 1, 2024</p>
    </header>
    <section className={styles.section}>
      <h2>Information we collect</h2>
      <p>
        We collect information you voluntarily provide, such as contact details and project information. We may also gather analytics
        data to improve the site experience.
      </p>
    </section>
    <section className={styles.section}>
      <h2>How we use information</h2>
      <p>
        Your information is used to deliver services, respond to inquiries, and share relevant updates about blhank offerings. We do not sell personal data.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Data protection</h2>
      <p>
        We implement administrative and technical safeguards to protect your information. Access is limited to authorized personnel.
      </p>
    </section>
    <section className={styles.section}>
      <h2>Your rights</h2>
      <p>
        You may request access, updates, or deletion of your information by contacting info@blhank.pro. We will respond within a reasonable timeframe.
      </p>
    </section>
  </div>
);

export default PrivacyPolicyPage;