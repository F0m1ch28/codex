import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";

const services = [
  {
    title: "Cash Independence Roadmaps",
    description:
      "Design robust treasury architectures that reduce reliance on traditional bank lending through diversified liquidity strategies.",
    image: "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=900&q=80"
  },
  {
    title: "Embedded Finance Advisory",
    description:
      "Integrate embedded solutions and alternative finance platforms within your operating model to unlock new revenue streams.",
    image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=900&q=80"
  },
  {
    title: "Resilience Diagnostics",
    description:
      "Assess counterparty concentration risk, run bank disruption simulations, and build resilient operating contingencies.",
    image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&w=900&q=80"
  },
  {
    title: "Regulatory Navigation",
    description:
      "Stay ahead of US regulatory innovation with proactive governance and documentation frameworks tailored to independent models.",
    image: "https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=900&q=80"
  }
];

const testimonials = [
  {
    quote:
      "blhank helped us transition 70% of our treasury from bank credit to diversified partnerships without sacrificing control or speed.",
    name: "Karen Hudson",
    role: "Chief Financial Officer, BlueTerrain Energy",
    avatar: "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80"
  },
  {
    quote:
      "Their team is uniquely positioned at the intersection of finance and technology. We now have a clear independence roadmap for the next five years.",
    name: "Miguel Alvarez",
    role: "Head of Strategy, Northlight Logistics",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80"
  }
];

const featuredCases = [
  {
    title: "Scaling a DTC brand beyond bank credit limits",
    summary: "How we unlocked $45M in alternative liquidity for a national consumer retailer in under six months.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
    link: "/cases"
  },
  {
    title: "Modernizing treasury for a clean energy portfolio",
    summary: "Designing a resilient cash ecosystem with predictive forecasting and partner diversification.",
    image: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
    link: "/cases"
  },
  {
    title: "Independent banking infrastructure for SaaS growth",
    summary: "How a SaaS unicorn achieved uninterrupted expansion during bank volatility events.",
    image: "https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=900&q=80",
    link: "/cases"
  }
];

const teamPhotos = [
  "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=600&q=80",
  "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=600&q=80"
];

const HomePage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>blhank | Bank Independent Growth Partners</title>
        <meta
          name="description"
          content="blhank delivers bank independent strategies, treasury resilience, and embedded finance innovation for US enterprises."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="hero-heading">
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <p className={styles.superTitle}>Bank Independent by Design</p>
          <h1 id="hero-heading">
            Build a resilient financial engine that thrives beyond traditional banks.
          </h1>
          <p className={styles.heroText}>
            blhank partners with US finance, operations, and innovation leaders to craft bank independent ecosystems,
            diversify capital, and stay ahead when market confidence shifts.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contacts" className={styles.primaryButton}>
              Schedule a discovery call
            </Link>
            <Link to="/services" className={styles.secondaryButton}>
              Explore our playbooks
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.intro} aria-labelledby="intro-heading">
        <div className={styles.introContent}>
          <h2 id="intro-heading">Trusted advisors for independence-first leaders</h2>
          <p>
            From Burlington, VT to boardrooms across the US, our strategists, technologists, and risk specialists
            align finance and operations teams around a unified independence roadmap. We connect the dots between
            treasury modernization, alternative liquidity, embedded finance, and compliant governance.
          </p>
          <Link to="/about" className={styles.linkArrow}>
            Meet the team that makes independence possible
          </Link>
        </div>
        <div className={styles.introVisual}>
          <img
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1000&q=80"
            alt="blhank team strategizing around a table"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.services} aria-labelledby="services-heading">
        <div className={styles.sectionHeader}>
          <h2 id="services-heading">Signature services for bank independent transformation</h2>
          <p>
            We bridge strategy and execution with agile delivery, transparent governance, and hands-on change management.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <img src={service.image} alt="" loading="lazy" />
              <div className={styles.serviceBody}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.whyUs} aria-labelledby="why-heading">
        <div className={styles.sectionHeader}>
          <h2 id="why-heading">Why leading operators choose blhank</h2>
        </div>
        <div className={styles.whyGrid}>
          <div className={styles.whyCard}>
            <h3>Independence-first mindset</h3>
            <p>
              We reverse traditional bank-first thinking by prioritizing internal resilience, alternative partners,
              and new growth levers.
            </p>
          </div>
          <div className={styles.whyCard}>
            <h3>Cross-functional execution</h3>
            <p>
              Our teams integrate seamlessly with finance, procurement, technology, and legal stakeholders for
              coordinated delivery.
            </p>
          </div>
          <div className={styles.whyCard}>
            <h3>Real-time intelligence</h3>
            <p>
              We leverage proprietary monitoring to flag banking volatility early and activate pre-built contingency playbooks.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-heading">
        <div className={styles.sectionHeader}>
          <h2 id="testimonials-heading">Voices of resilient finance leaders</h2>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial) => (
            <figure key={testimonial.name} className={styles.testimonialCard}>
              <blockquote>{testimonial.quote}</blockquote>
              <div className={styles.testimonialFooter}>
                <img src={testimonial.avatar} alt="" loading="lazy" />
                <figcaption>
                  <span className={styles.testimonialName}>{testimonial.name}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </figcaption>
              </div>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <div className={styles.sectionHeader}>
          <h2 id="team-heading">People-first culture, coast-to-coast coverage</h2>
          <p>
            We combine Vermont-crafted hospitality with nationwide reach, assembling teams onsite and virtually to orchestrate critical transformations.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {teamPhotos.map((photo, index) => (
            <img
              key={photo}
              src={photo}
              alt={"blhank team member ${index + 1}"}
              loading="lazy"
            />
          ))}
        </div>
      </section>

      <section className={styles.featured} aria-labelledby="featured-heading">
        <div className={styles.sectionHeader}>
          <h2 id="featured-heading">Featured independence wins</h2>
          <p>
            Explore how organizations are future-proofing their financial operations and moving faster than market volatility.
          </p>
        </div>
        <div className={styles.featuredGrid}>
          {featuredCases.map((item) => (
            <article key={item.title} className={styles.featuredCard}>
              <img src={item.image} alt="" loading="lazy" />
              <div className={styles.featuredBody}>
                <h3>{item.title}</h3>
                <p>{item.summary}</p>
                <Link to={item.link} className={styles.linkArrow}>
                  Dive into the full story
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.geography} aria-labelledby="geo-heading">
        <div className={styles.geoCard}>
          <h2 id="geo-heading">Serving the US with Vermont-crafted precision</h2>
          <p>
            From our headquarters in South Burlington, Vermont, blhank partners with finance teams in New York,
            San Francisco, Austin, Miami, and beyond. We bring consistent strategy leadership to multi-site and fully remote operations.
          </p>
          <ul>
            <li>Strategic workshops in every US time zone</li>
            <li>On-demand crisis response pods</li>
            <li>Regional partner network across 30+ states</li>
          </ul>
        </div>
        <div className={styles.geoVisual}>
          <img
            src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=80"
            alt="Aerial view of US city skyline at sunset"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-heading">
        <div className={styles.ctaCard}>
          <h2 id="cta-heading">Let’s map your bank independent future</h2>
          <p>
            We’ll assess your current exposure, identify quick wins, and design a tailored roadmap within 15 business days.
          </p>
          <Link to="/contacts" className={styles.primaryButton}>
            Connect with blhank strategists
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;