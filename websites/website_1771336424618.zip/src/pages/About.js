import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const AboutPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About blhank | Bank Independent Specialists</title>
        <meta
          name="description"
          content="Discover blhank’s mission to build bank independent organizations, meet our leadership team, and explore our Vermont headquarters."
        />
      </Helmet>

      <section className={styles.hero} aria-labelledby="about-heading">
        <div className={styles.heroContent}>
          <h1 id="about-heading">We create bank independent organizations with heart and precision.</h1>
          <p>
            blhank was founded by finance strategists and technologists who witnessed how bank concentration can
            undermine brilliant businesses. From day one, we’ve been devoted to helping leaders unlock resilience,
            agility, and control.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80"
          alt="blhank headquarters collaboration space"
          loading="lazy"
          className={styles.heroImage}
        />
      </section>

      <section className={styles.office} aria-labelledby="office-heading">
        <div className={styles.officeText}>
          <h2 id="office-heading">South Burlington headquarters crafted for collaboration</h2>
          <p>
            Our Vermont office blends innovation labs, data visualization studios, and conversation lounges overlooking
            the Green Mountains. It’s where we host intensive independence sprints with executives who need focused
            guidance and a fresh perspective.
          </p>
          <p>
            We design every engagement to feel bespoke. Whether clients visit our Burlington studio or connect remotely,
            they gain a partner that understands both the urgency of financial independence and the human dynamics of change.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1529429617124-aee01c999332?auto=format&fit=crop&w=1200&q=80"
          alt="Collaborative workspace in the blhank Vermont office"
          loading="lazy"
        />
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <h2 id="team-heading">Meet the team shaping resilient finance ecosystems</h2>
        <p className={styles.teamIntro}>
          Our collective spans strategy, treasury, alternative finance, regulatory compliance, and product engineering — allowing us to deliver
          integrated solutions that stand up under real-world pressure.
        </p>
        <div className={styles.teamGrid}>
          <figure className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?auto=format&fit=crop&w=500&q=80"
              alt="Portrait of founder and CEO Julia Spencer"
              loading="lazy"
            />
            <figcaption>
              <h3>Julia Spencer</h3>
              <p>Founder &amp; CEO</p>
            </figcaption>
          </figure>
          <figure className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=500&q=80"
              alt="Portrait of Chief Strategy Officer Malik Greene"
              loading="lazy"
            />
            <figcaption>
              <h3>Malik Greene</h3>
              <p>Chief Strategy Officer</p>
            </figcaption>
          </figure>
          <figure className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=500&q=80"
              alt="Portrait of Head of Treasury Innovation Priya Patel"
              loading="lazy"
            />
            <figcaption>
              <h3>Priya Patel</h3>
              <p>Head of Treasury Innovation</p>
            </figcaption>
          </figure>
          <figure className={styles.teamCard}>
            <img
              src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=500&q=80"
              alt="Portrait of Regulatory Lead Andrea Williams"
              loading="lazy"
            />
            <figcaption>
              <h3>Andrea Williams</h3>
              <p>Regulatory Lead</p>
            </figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.values} aria-labelledby="values-heading">
        <h2 id="values-heading">Values that guide every engagement</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Empathy first</h3>
            <p>
              We listen deeply to understand the pressures finance teams shoulder. Every recommendation balances independence with cultural adoption.
            </p>
          </article>
          <article>
            <h3>Evidence-driven</h3>
            <p>
              Our insights come from data, constant research, and lessons learned from building modern treasury stacks in complex industries.
            </p>
          </article>
          <article>
            <h3>Transparent partnership</h3>
            <p>
              We operate as an embedded ally, sharing knowledge, training teams, and architecting playbooks that clients continue using long after delivery.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;