import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const servicesData = [
  {
    title: "Independence Blueprint",
    description:
      "Comprehensive diagnostics of your banking dependencies, liquidity profile, supplier payments, and revenue streams. Deliverables include a prioritized roadmap and contingency matrix tailored to your operating cadence.",
    bullets: [
      "90-day action plan to diversify capital sources",
      "Cross-functional governance model with clarity on roles",
      "Scenario simulations to evaluate resilience under stress"
    ]
  },
  {
    title: "Treasury Modernization",
    description:
      "Build a modern treasury stack that blends internal capabilities with curated non-bank partners. We orchestrate vendor selection, API integrations, data flows, and change management.",
    bullets: [
      "Cash flow forecasting and visibility dashboards",
      "API-enabled payments orchestration and reconciliations",
      "Real-time risk monitoring across partners and accounts"
    ]
  },
  {
    title: "Embedded Finance Acceleration",
    description:
      "Unlock embedded lending, payments, and treasury offerings that convert customers into loyal communities. We ensure alignment with regulatory frameworks and customer experience goals.",
    bullets: [
      "Product-market fit assessments and GTM strategy",
      "Risk controls and legal documentation workflows",
      "Vendor collaborations with measurable performance metrics"
    ]
  },
  {
    title: "Regulatory Navigation",
    description:
      "Stay ahead of the evolving US regulatory landscape. We align your independence strategy with compliance obligations and help you communicate confidently with regulators and investors.",
    bullets: [
      "Regulation-by-regulation readiness mapping",
      "Policy development and board reporting templates",
      "Training for finance, operations, and product teams"
    ]
  }
];

const ServicesPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | blhank Bank Independent Solutions</title>
        <meta
          name="description"
          content="Explore blhank services spanning independence blueprints, treasury modernization, embedded finance, and regulatory navigation."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Strategic services engineered for bank independent outcomes.</h1>
        <p>
          Each engagement combines enterprise-grade advisory with hands-on execution. We build strategies that scale, integrate seamlessly, and
          sustain momentum long after the initial engagement concludes.
        </p>
      </header>

      <section className={styles.services} aria-label="Service offerings">
        {servicesData.map((service) => (
          <article key={service.title} className={styles.card}>
            <div className={styles.cardHeader}>
              <h2>{service.title}</h2>
            </div>
            <p>{service.description}</p>
            <ul>
              {service.bullets.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>
    </div>
  );
};

export default ServicesPage;