import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Blog.module.css";

const posts = [
  {
    title: "Five questions to evaluate bank dependency risk in 2024",
    description:
      "The events of the last year exposed concentration risks. We unpack the five essential diagnostics every executive team should run now.",
    author: "Julia Spencer",
    date: "January 12, 2024",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
  },
  {
    title: "Embedded finance as a resilience multiplier",
    description:
      "Embedded finance is more than a buzzword. Here’s how independence-oriented organizations are using it to create new capital routes.",
    author: "Malik Greene",
    date: "February 06, 2024",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80"
  },
  {
    title: "When banking partners consolidate: a playbook",
    description:
      "Competition among banks is tightening. We share a six-step playbook to protect operations when your primary bank merges.",
    author: "Priya Patel",
    date: "March 02, 2024",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80"
  }
];

const BlogPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Insights | blhank Bank Independent Blog</title>
        <meta
          name="description"
          content="Stay informed with blhank insights covering independence diagnostics, embedded finance, and treasury resilience."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Insights that keep independence leaders ahead.</h1>
        <p>
          Straightforward analysis, actionable playbooks, and behind-the-scenes lessons from engagements across the US.
        </p>
      </header>

      <section className={styles.grid} aria-label="Blog articles">
        {posts.map((post) => (
          <article key={post.title} className={styles.card}>
            <img src={post.image} alt="" loading="lazy" />
            <div className={styles.content}>
              <p className={styles.meta}>
                {post.author} &mdash; {post.date}
              </p>
              <h2>{post.title}</h2>
              <p>{post.description}</p>
              <a
                href="https://blhank.pro/blog"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.link}
              >
                Continue reading ↗
              </a>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default BlogPage;