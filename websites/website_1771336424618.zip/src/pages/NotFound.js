import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import styles from "./NotFound.module.css";

const NotFoundPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Page Not Found | blhank</title>
      <meta
        name="description"
        content="The page you are looking for cannot be found. Return to the blhank homepage."
      />
    </Helmet>
    <section className={styles.card}>
      <h1>We couldn’t find that page.</h1>
      <p>Let’s get you back to bank independent insights.</p>
      <Link to="/">Return home</Link>
    </section>
  </div>
);

export default NotFoundPage;