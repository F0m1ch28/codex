import React from "react";
import { Helmet } from "react-helmet";
import styles from "./LegalPage.module.css";

const TermsOfServicePage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Terms &amp; Conditions | blhank</title>
      <meta
        name="description"
        content="Review the terms and conditions governing the use of blhank services, content, and website."
      />
    </Helmet>
    <header className={styles.header}>
      <h1>Terms &amp; Conditions</h1>
      <p>Effective date: January 1, 2024</p>
    </header>
    <section className={styles.section}>
      <h2>1. Acceptance of terms</h2>
      <p>
        By accessing blhank services or this website, you agree to comply with and be bound by these terms. If you do not agree,
        please discontinue use immediately.
      </p>
    </section>
    <section className={styles.section}>
      <h2>2. Services</h2>
      <p>
        blhank provides strategic advisory services focused on bank independent solutions. All engagements are governed by separate
        statements of work and signed agreements.
      </p>
    </section>
    <section className={styles.section}>
      <h2>3. Intellectual property</h2>
      <p>
        All content, trademarks, and materials found on this site are owned by blhank or our licensors. You may not reproduce or
        distribute any materials without prior written consent.
      </p>
    </section>
    <section className={styles.section}>
      <h2>4. Limitation of liability</h2>
      <p>
        blhank is not liable for any indirect or consequential damages arising from the use of our services or information provided on this site.
      </p>
    </section>
    <section className={styles.section}>
      <h2>5. Governing law</h2>
      <p>
        These terms are governed by the laws of the State of Vermont, without regard to its conflict of law principles.
      </p>
    </section>
  </div>
);

export default TermsOfServicePage;