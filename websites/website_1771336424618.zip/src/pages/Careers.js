import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Careers.module.css";

const openings = [
  {
    title: "Independence Strategy Lead",
    location: "Hybrid - South Burlington, VT or Remote (US)",
    description:
      "Guide clients through independence assessments and roadmap design. Requires 8+ years in strategy or treasury consulting."
  },
  {
    title: "Treasury Technology Architect",
    location: "Remote (US)",
    description:
      "Architect modern treasury stacks with API-first solutions. Experience with ERP integration and data engineering preferred."
  },
  {
    title: "Regulatory Program Manager",
    location: "South Burlington, VT",
    description:
      "Lead regulatory workstreams aligning independence strategies with US compliance requirements. Background in financial services regulation required."
  }
];

const benefits = [
  "Healthcare, dental, and vision coverage from day one",
  "Distributed-first culture with purposeful in-person summits",
  "Annual independence research stipend and conference budget",
  "Generous PTO and sabbatical program after three years"
];

const CareersPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Careers | Join blhank</title>
        <meta
          name="description"
          content="Join the blhank team and help US companies achieve bank independence through strategy, technology, and regulatory expertise."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Build the future of bank independence with us.</h1>
        <p>
          We’re seeking curious minds who love turning complex financial challenges into elegant, resilient solutions.
          At blhank, you’ll collaborate with leaders shaping the next era of independence.
        </p>
      </header>

      <section className={styles.openings} aria-label="Current openings">
        {openings.map((role) => (
          <article key={role.title} className={styles.card}>
            <h2>{role.title}</h2>
            <p className={styles.location}>{role.location}</p>
            <p>{role.description}</p>
            <a
              href="mailto:info@blhank.pro?subject=Career%20Opportunity%20Inquiry"
              className={styles.apply}
            >
              Introduce yourself →
            </a>
          </article>
        ))}
      </section>

      <section className={styles.benefits} aria-labelledby="benefits-heading">
        <div className={styles.benefitsCard}>
          <h2 id="benefits-heading">What it’s like to work at blhank</h2>
          <ul>
            {benefits.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
        <img
          src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80"
          alt="blhank team collaborating during a workshop"
          loading="lazy"
        />
      </section>
    </div>
  );
};

export default CareersPage;