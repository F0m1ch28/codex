import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import styles from "./ThankYou.module.css";

const ThankYouPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Thank You | blhank</title>
        <meta
          name="description"
          content="Thank you for reaching out to blhank. Our team will respond within one business day."
        />
      </Helmet>

      <section className={styles.card}>
        <h1>Thank you for reaching out to blhank.</h1>
        <p>
          Our strategists will review your message and respond within one business day.
          In the meantime, explore how other leaders are accelerating their bank independent journey.
        </p>
        <div className={styles.actions}>
          <Link to="/cases">View case studies</Link>
          <Link to="/blog">Read latest insights</Link>
        </div>
      </section>
    </div>
  );
};

export default ThankYouPage;