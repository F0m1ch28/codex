import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Cases.module.css";

const cases = [
  {
    title: "Rebalancing liquidity for a national healthcare provider",
    description:
      "We reduced reliance on a single bank from 82% to 38% while expanding access to patient financing via trusted partners.",
    outcome: "Unlocked $60M in diversified liquidity and created a 3-hour crisis activation playbook.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80"
  },
  {
    title: "Supply chain resiliency for consumer electronics",
    description:
      "Designed a payment orchestration layer and negotiated alternative financing to support global supplier expansion.",
    outcome: "Achieved 98% payment continuity during bank outages and improved gross margin by 1.8 points.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80"
  },
  {
    title: "Embedded treasury for SaaS expansion",
    description:
      "Implemented an API-first treasury infrastructure that integrates with revenue operations and customer billing.",
    outcome: "Cut treasury reconciliation time by 65% and enabled $30M growth without additional bank credit.",
    image: "https://images.unsplash.com/photo-1529603992308-5fbb62cc6ab3?auto=format&fit=crop&w=1200&q=80"
  }
];

const CasesPage = () => {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Case Studies | blhank Bank Independent Wins</title>
        <meta
          name="description"
          content="Read blhank case studies showcasing bank independent transformations across healthcare, consumer electronics, and SaaS."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Real-world proof of resilient independence.</h1>
        <p>
          Every engagement combines strategy, technology, and governance. These snapshots highlight measurable results,
          not just theoretical frameworks.
        </p>
      </header>

      <section className={styles.grid} aria-label="Case studies">
        {cases.map((item) => (
          <article key={item.title} className={styles.card}>
            <img src={item.image} alt="" loading="lazy" />
            <div className={styles.body}>
              <h2>{item.title}</h2>
              <p>{item.description}</p>
              <div className={styles.outcome}>
                <span>Outcome</span>
                <p>{item.outcome}</p>
              </div>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default CasesPage;