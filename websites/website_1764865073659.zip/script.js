document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.querySelectorAll('#year');
  yearEl.forEach(el => el.textContent = new Date().getFullYear());

  const navToggle = document.querySelector('.nav-toggle');
  const menu = document.getElementById('primary-menu');
  if (navToggle && menu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      menu.classList.toggle('active');
    });
  }

  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const consent = localStorage.getItem('cm-cookie-consent');
  if (!consent) {
    banner.classList.add('active');
  }

  banner.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const decision = target.dataset.cookie;
    if (!decision) return;

    if (decision === 'accept') {
      localStorage.setItem('cm-cookie-consent', 'accepted');
    } else {
      localStorage.setItem('cm-cookie-consent', 'declined');
    }
    banner.classList.remove('active');
  });
});