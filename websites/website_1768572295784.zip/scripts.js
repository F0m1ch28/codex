document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const navToggle = document.querySelector('.nav-toggle');
    const navListLinks = document.querySelectorAll('.nav-list a');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookieBtn = document.getElementById('cookie-accept');
    const declineCookieBtn = document.getElementById('cookie-decline');

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            body.classList.toggle('nav-open');
        });
    }

    navListLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (body.classList.contains('nav-open')) {
                body.classList.remove('nav-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });

    const cookiesPreference = localStorage.getItem('electrsleb_cookie_preference');
    if (!cookiesPreference && cookieBanner) {
        cookieBanner.classList.add('is-visible');
    }

    const handleCookieChoice = (choice) => {
        localStorage.setItem('electrsleb_cookie_preference', choice);
        cookieBanner.classList.remove('is-visible');
    };

    if (acceptCookieBtn) {
        acceptCookieBtn.addEventListener('click', () => handleCookieChoice('accepted'));
    }

    if (declineCookieBtn) {
        declineCookieBtn.addEventListener('click', () => handleCookieChoice('declined'));
    }
});