"use strict";

document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("open");
        });
        document.addEventListener("click", (event) => {
            if (!siteNav.contains(event.target) && !navToggle.contains(event.target)) {
                siteNav.classList.remove("open");
            }
        });
    }

    const currentYearEl = document.getElementById("current-year");
    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedConsent = localStorage.getItem("mapleCookieConsent");
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
        }
        cookieBanner.querySelectorAll("[data-consent]").forEach((element) => {
            element.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = element.dataset.consent === "accept" ? "accepted" : "declined";
                localStorage.setItem("mapleCookieConsent", choice);
                cookieBanner.classList.add("hidden");
            });
        });
    }

    document.querySelectorAll(".subscribe-form").forEach((form) => {
        form.addEventListener("submit", (event) => {
            const emailField = form.querySelector("input[type='email']");
            if (emailField && emailField.value.trim() === "") {
                event.preventDefault();
                emailField.focus();
                emailField.setAttribute("aria-invalid", "true");
            } else {
                emailField.removeAttribute("aria-invalid");
            }
        });
    });

    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            const requiredFields = ["name", "email", "organization", "message", "topic"];
            const invalid = requiredFields.some((fieldName) => {
                const field = contactForm.querySelector(`[name='${fieldName}']`);
                if (!field) {
                    return false;
                }
                if (field.value.trim() === "") {
                    field.setAttribute("aria-invalid", "true");
                    field.classList.add("field-error");
                    return true;
                }
                field.removeAttribute("aria-invalid");
                field.classList.remove("field-error");
                return false;
            });
            if (invalid) {
                event.preventDefault();
            }
        });
    }

    if (document.body.classList.contains("page-posts")) {
        const posts = Array.from(document.querySelectorAll(".post-item"));
        const searchInput = document.getElementById("post-search");
        const categoryFilter = document.getElementById("category-filter");
        const paginationControls = document.getElementById("pagination-controls");
        const resultsCount = document.getElementById("results-count");
        const POSTS_PER_PAGE = 6;
        let currentPage = 1;
        let filteredPosts = posts.slice();

        const updateResultsCount = () => {
            if (resultsCount) {
                resultsCount.textContent = `${filteredPosts.length} article${filteredPosts.length === 1 ? "" : "s"} available`;
            }
        };

        const renderPosts = () => {
            posts.forEach((post) => {
                post.style.display = "none";
            });
            const start = (currentPage - 1) * POSTS_PER_PAGE;
            const end = start + POSTS_PER_PAGE;
            filteredPosts.slice(start, end).forEach((post) => {
                post.style.display = "grid";
            });
            if (filteredPosts.length <= POSTS_PER_PAGE) {
                paginationControls.innerHTML = "";
                return;
            }
            const totalPages = Math.ceil(filteredPosts.length / POSTS_PER_PAGE);
            paginationControls.innerHTML = "";
            for (let page = 1; page <= totalPages; page += 1) {
                const button = document.createElement("button");
                button.type = "button";
                button.textContent = page.toString();
                if (page === currentPage) {
                    button.classList.add("active");
                }
                button.addEventListener("click", () => {
                    currentPage = page;
                    renderPosts();
                });
                paginationControls.appendChild(button);
            }
        };

        const applyFilters = () => {
            const term = searchInput.value.trim().toLowerCase();
            const category = categoryFilter.value;
            filteredPosts = posts.filter((post) => {
                const matchesCategory = category === "all" || post.dataset.category === category;
                const matchesTerm =
                    term.length === 0 ||
                    post.dataset.title.includes(term) ||
                    post.dataset.summary.includes(term);
                return matchesCategory && matchesTerm;
            });
            currentPage = 1;
            updateResultsCount();
            renderPosts();
        };

        if (searchInput && categoryFilter && paginationControls) {
            posts.forEach((post) => {
                post.dataset.title = post.querySelector("h3").textContent.trim().toLowerCase();
                const summary = post.querySelector(".post-summary");
                post.dataset.summary = summary ? summary.textContent.trim().toLowerCase() : "";
            });
            searchInput.addEventListener("input", () => {
                applyFilters();
            });
            categoryFilter.addEventListener("change", () => {
                applyFilters();
            });
            updateResultsCount();
            renderPosts();
        }
    }
});