const DEFAULT_LANG = "fr";
const I18N = {
  fr: {
    logo_text: "danswholesaleplants",
    nav_home: "Accueil",
    nav_services: "Services",
    nav_about: "À propos",
    nav_blog: "Blog",
    nav_faq: "FAQ",
    nav_contact: "Contact",
    nav_toggle: "Menu",
    language_label: "Langue",
    footer_contact_heading: "Coordonnées",
    footer_navigation_heading: "Navigation",
    footer_legal_heading: "Légal",
    footer_phone_link: "Téléphone : +32 2 123 45 67",
    footer_email_link: "Courriel : contact@danswholesaleplants.com",
    footer_address: "Avenue de la Toison d'Or 123, 1050 Ixelles, Belgique",
    footer_terms: "Conditions d'utilisation",
    footer_privacy: "Politique de confidentialité",
    footer_cookies: "Politique de cookies",
    footer_refund: "Politique de révision",
    footer_disclaimer: "Clause de non-responsabilité",
    footer_manage_cookies: "Paramétrer les cookies",
    footer_copyright_prefix: "©",
    footer_copyright_suffix: "danswholesaleplants. Tous droits réservés.",
    cookie_banner_title: "Gestion des cookies",
    cookie_banner_description: "Nous utilisons des témoins pour maintenir des fonctionnalités essentielles et comprendre comment nos supports d'orientation sont consultés. Choisissez les catégories adaptées à vos préférences. Vous pouvez modifier ces réglages à tout moment.",
    cookie_banner_necessary: "Essentiels",
    cookie_banner_necessary_desc: "Garantissent le fonctionnement du site, comme la mémorisation de la langue sélectionnée.",
    cookie_banner_preferences: "Préférences",
    cookie_banner_preferences_desc: "Enregistrent vos sélections d'accessibilité et vos préférences d'affichage.",
    cookie_banner_analytics: "Analyse",
    cookie_banner_analytics_desc: "Mesurent les interactions anonymes pour améliorer les parcours d'information.",
    cookie_banner_marketing: "Diffusion",
    cookie_banner_marketing_desc: "Coordonnent la diffusion de contenus externes pertinents sur la signalétique.",
    cookie_banner_accept: "Tout accepter",
    cookie_banner_decline: "Tout refuser",
    cookie_banner_save: "Sauvegarder",
    cookie_banner_close: "Fermer le bandeau",
    cookie_banner_manage: "Ajuster les catégories",
    toast_contact_success: "Votre message a été enregistré. Redirection en cours.",
    toast_contact_error: "Merci de compléter les champs requis avant l'envoi.",
    home_title: "danswholesaleplants | Orientation spatiale et signalétique numérique",
    home_meta: "Analyses belges de l'orientation spatiale, signalétique numérique et expérience utilisateur piétonne pour bâtiments publics et environnements complexes.",
    home_hero_title: "Observer et structurer la navigation dans les environnements publics belges",
    home_hero_text: "Nous documentons les décisions spatiales critiques, clarifions les enchaînements de signalétique et construisons des plans interactifs pour faciliter les parcours dans les bâtiments et espaces urbains.",
    home_hero_button: "Explorer les méthodologies",
    home_hero_button_secondary: "Comprendre notre approche",
    home_hero_image_alt: "Interface cartographique montrant des flux piétons et la signalétique numérique",
    home_featured_heading: "Nos champs d'observation prioritaires",
    home_featured_intro: "Chaque étude combine cartographie des espaces, lisibilité visuelle et expérience d'usage pour rendre cohérentes les décisions d'orientation.",
    home_featured_card1_title: "Diagnostics d'orientation spatiale",
    home_featured_card1_text: "Inventorier les zones de friction, harmoniser la terminologie directionnelle et décrire les points d'inflexion des flux de circulation.",
    home_featured_card2_title: "Cartographie interactive des parcours",
    home_featured_card2_text: "Assembler données terrain, plans de bâtiments et visualisations en temps réel pour soutenir les mobilités piétonnes.",
    home_featured_card3_title: "Écologie de signalétique",
    home_featured_card3_text: "Comparer la signalétique analogue et numérique, hiérarchiser les informations et optimiser la lisibilité dans chaque contexte.",
    home_layers_heading: "Une lecture en couches des systèmes de guidage",
    home_layers_text: "Notre approche segmente chaque environnement en couches fonctionnelles pour révéler les dépendances entre architecture, usages et dispositifs numériques.",
    home_layers_list1: "Infrastructure : circulation verticale, intersections, zones d'attente et compatibilité avec la signalétique existante.",
    home_layers_list2: "Information : hiérarchie iconographique, vocabulaire spatial, formats bilingues et protocoles de mise à jour.",
    home_layers_list3: "Expérience : perception, confort visuel, transitions intérieur-extérieur et continuité des repères.",
    home_recommendations_heading: "Recommandations structurantes",
    home_recommendations_intro: "Les propositions ci-dessous guident les équipes publiques et privées qui supervisent les grands ensembles accueillant du public.",
    home_recommendation1_title: "Synchroniser les repères analogiques et numériques",
    home_recommendation1_text: "Déployer la même grammaire directionnelle sur les plans physiques, les écrans et les applications pour éviter les divergences d'interprétation.",
    home_recommendation2_title: "Segmenter les parcours par intentions",
    home_recommendation2_text: "Différencier les parcours fréquents, ponctuels et sensibles afin d'allouer un niveau d'information adapté à chaque situation.",
    home_recommendation3_title: "Mesurer le temps de décision",
    home_recommendation3_text: "Observer la durée nécessaire pour identifier une direction et ajuster l'emplacement des signaux en tenant compte des flux réels.",
    home_testimonials_heading: "Retours de terrain",
    home_testimonials_intro: "Les retours ci-dessous proviennent de responsables de sites qui s'appuient sur nos observations pour bâtir leurs plans directeurs.",
    home_testimonial1_quote: "Le diagnostic a éclairé les zones de confusion que nous soupçonnions sans pouvoir les caractériser précisément.",
    home_testimonial1_name: "Claire Vandenberg",
    home_testimonial1_role: "Coordination mobilité piétonne, campus universitaire",
    home_testimonial2_quote: "Le croisement des données piétonnes et des plans a révélé des séquences de signalétique qui n'étaient plus alignées avec l'usage réel.",
    home_testimonial2_name: "Hugo De Meyer",
    home_testimonial2_role: "Gestion des infrastructures, hôpital public",
    home_testimonial3_quote: "Les scénarios proposés ont servi de base à la redéfinition de nos supports d'accueil multilingues.",
    home_testimonial3_name: "Sophie Lambert",
    home_testimonial3_role: "Direction des services urbains, ville moyenne",
    home_research_heading: "Axes de recherche suivis",
    home_research_text: "Dans tout le pays, nous analysons les structures où l'orientation joue un rôle critique pour l'expérience collective.",
    home_research_card1_title: "Hubs municipaux",
    home_research_card1_text: "Évaluer la continuité des repères entre espaces administratifs, espaces culturels et liaisons extérieures.",
    home_research_card2_title: "Réseaux de santé publique",
    home_research_card2_text: "Observer la navigation dans des bâtiments à flux sensibles où la clarté réduit les situations de stress.",
    home_research_card3_title: "Campus intermodaux",
    home_research_card3_text: "Étudier la coordination entre signalisation ferroviaire, réseaux de bus, stationnements et cheminements doux.",
    home_metrics_heading: "Indicateurs observés",
    home_metrics_text: "Les métriques suivantes proviennent de terrains étudiés entre 2021 et 2024.",
    home_metric1_value: "48 %",
    home_metric1_label: "Réduction moyenne du temps de décision aux nœuds critiques après réorganisation des repères.",
    home_metric2_value: "17 km",
    home_metric2_label: "Réseaux piétons cartographiés et synchronisés avec la signalétique numérique.",
    home_metric3_value: "12",
    home_metric3_label: "Structures publiques accompagnées dans la formalisation de leurs parcours utilisateurs.",
    services_title: "Services d'analyse et de conception",
    services_meta: "Analyse, cartographie et conception de signalétique numérique pour bâtiments publics et environnements complexes à Bruxelles et en Belgique.",
    services_hero_heading: "Cartographier, modéliser et ajuster les environnements complexes",
    services_hero_text: "Nos services décrivent les interactions entre espaces bâtis, flux de circulation et dispositifs d'information. Chaque livrable est conçu pour alimenter des décisions collectives.",
    services_card1_title: "Conception de systèmes d'orientation numériques",
    services_card1_text: "Définition de structures d'information, maquettes d'écrans, protocoles d'actualisation et gouvernance des contenus multilingues.",
    services_card2_title: "Cartographie spatiale interactive",
    services_card2_text: "Assemblage de plans détaillés, modélisation des points de décision, scénarios de navigation et intégration de données ouvertes.",
    services_card3_title: "Analyse et optimisation des parcours utilisateurs",
    services_card3_text: "Observation qualitative et quantitative des trajets, identification des frictions cognitives et recommandations de repositionnement.",
    services_card4_title: "Audits d'accessibilité et UX spatiale",
    services_card4_text: "Évaluation des continuités de cheminement, tests utilisateurs et recommandations sur la lisibilité des supports.",
    services_card5_title: "Design de guidage visuel",
    services_card5_text: "Création de systèmes graphiques cohérents, hiérarchisation des messages et scénarisation des points d'entrée.",
    services_card6_title: "Solutions de navigation pour bâtiments publics",
    services_card6_text: "Coordination des plans, circuits d'accueil, dispositifs d'information et alignement des discours institutionnels.",
    services_card7_title: "Planification d'orientation pour environnements complexes",
    services_card7_text: "Stratégies pluri-sites, synchronisation des plateformes numériques et lignes directrices pour la transformation des espaces.",
    services_process_heading: "Architecture méthodologique",
    services_process_text: "Chaque mission combine observations in situ, analyse documentaire et prototypage itératif pour sécuriser les décisions.",
    services_process_step1_title: "1. Cadre d'étude",
    services_process_step1_text: "Délimiter les zones, préciser les publics, inventorier les supports existants et formaliser les objectifs partagés.",
    services_process_step2_title: "2. Collecte et cartographie",
    services_process_step2_text: "Compiler les plans, relever les flux, modéliser les niveaux et articuler les continuités intérieur-extérieur.",
    services_process_step3_title: "3. Synthèse opérationnelle",
    services_process_step3_text: "Prioriser les interventions, définir les responsabilités et maintenir des cycles d'ajustement documentés.",
    services_framework_heading: "Supports livrés",
    services_framework_text: "Nous produisons des livrables structurés, adaptés aux équipes de maîtrise d'ouvrage, de communication et de maintenance.",
    services_framework_list1: "Atlas des parcours annotés montrant la perception réelle des usagers.",
    services_framework_list2: "Matrices signalétiques détaillant chaque message, support et responsabilité.",
    services_framework_list3: "Tableaux de bord pour suivre les ajustements et mesurer leur impact dans le temps.",
    services_outcome_heading: "Résultats attendus",
    services_outcome_text: "Clarifier les transitions, améliorer la reconnaissance des lieux et soutenir la mobilité douce dans les espaces collectifs.",
    about_title: "À propos de danswholesaleplants",
    about_meta: "Profil de danswholesaleplants : équipe belge dédiée à l'orientation spatiale, à la signalétique numérique et à l'expérience piétonne.",
    about_hero_heading: "Relier architecture, information et usage",
    about_hero_text: "Depuis Bruxelles, nous accompagnons des organisations publiques et hybrides dans la structuration de leurs environnements complexes.",
    about_story_heading: "Origines et trajectoire",
    about_story_text1: "Le projet est né autour de stations multimodales belges confrontées à des volumes de déplacements inédits. Nous avons construit des grilles d'analyse pour décrire ces situations avec précision.",
    about_story_text2: "Ces méthodes se sont adaptées à des campus universitaires, des musées, des parcs hospitaliers et des quartiers en reconversion, toujours avec la même exigence : rendre tangible l'expérience des usagers.",
    about_values_heading: "Principes directeurs",
    about_values_intro: "Chaque mandat repose sur un ensemble de principes qui garantissent la cohérence des résultats.",
    about_value1_title: "Observation partagée",
    about_value1_text: "Croiser les perceptions des usagers, des équipes opérationnelles et des responsables stratégiques.",
    about_value2_title: "Transparence des données",
    about_value2_text: "Documenter les sources, préciser les limites et favoriser la reproductibilité des analyses.",
    about_value3_title: "Adaptabilité continue",
    about_value3_text: "Anticiper les évolutions d'usage et maintenir des processus de mise à jour accessibles.",
    about_methods_heading: "Méthodologie",
    about_methods_text1: "Nos études combinent relevés cartographiques, entretiens, observations in situ et analyses numériques.",
    about_methods_text2: "La complémentarité des disciplines — design informationnel, urbanisme, data — permet de couvrir des situations variées sans perdre en précision.",
    about_team_heading: "Collectif pluridisciplinaire",
    about_team_text: "Cartographes, designers UX, urbanistes, spécialistes d'accessibilité et analystes de données collaborent selon les besoins de chaque mission.",
    blog_title: "Blog | Observatoire de l'orientation spatiale",
    blog_meta: "Articles de danswholesaleplants sur la signalétique numérique, les parcours utilisateurs et la cartographie des environnements complexes.",
    blog_hero_heading: "Analyses et retours d'expérience",
    blog_hero_text: "Nos articles détaillent les méthodologies terrain, les outils cartographiques et les enseignements issus des projets accompagnés.",
    blog_post1_title: "Cartographier l'attention dans les pôles de transport",
    blog_post1_excerpt: "Une méthode pour repérer les décisions critiques dans les pôles multimodaux, hiérarchiser les repères et coordonner la signalétique physique et numérique.",
    blog_post1_meta: "9 minutes de lecture",
    blog_post2_title: "Composer des strates numériques pour les campus civiques",
    blog_post2_excerpt: "Comment articuler plans interactifs, écrans d'accueil et supports analogiques dans des campus administratifs très fréquentés.",
    blog_post2_meta: "8 minutes de lecture",
    blog_post3_title: "Transitions intérieur-extérieur dans les musées publics",
    blog_post3_excerpt: "Analyser les passages critiques entre espaces ouverts et galeries pour fluidifier la déambulation des visiteurs.",
    blog_post3_meta: "10 minutes de lecture",
    blog_post4_title: "Routage piéton temporaire pour événements urbains",
    blog_post4_excerpt: "Stratégies pour baliser des événements éphémères, coordonner les équipes terrain et actualiser les plans en temps réel.",
    blog_post4_meta: "7 minutes de lecture",
    blog_post5_title: "Heuristiques d'accessibilité pour plans interactifs",
    blog_post5_excerpt: "Principes pour concevoir des interfaces cartographiques inclusives, basées sur des tests d'usage et des standards internationaux.",
    blog_post5_meta: "11 minutes de lecture",
    blog_read_more: "Lire l'article",
    post1_title: "Cartographier l'attention dans les pôles de transport",
    post1_meta: "Méthodologie d'analyse de l'attention dans les pôles de transport belges.",
    post1_intro: "Les pôles multimodaux belges concentrent une densité d'informations rarement rencontrée dans d'autres environnements. Comprendre comment l'attention se distribue dans ces espaces suppose de croiser observations qualitatives, données de flux et modélisation cartographique.",
    post1_section1_heading: "Repérer les zones d'attention critiques",
    post1_section1_paragraph1: "La première étape consiste à parcourir le pôle en suivant différents profils d'usagers. Nous cartographions les décisions à prendre, les parcours alternatifs et les zones d'entrelacement. Cette lecture micro permet d'identifier les moments où l'attention se fragmente ou se surcharge.",
    post1_section1_paragraph2: "En parallèle, nous superposons les données de flux disponibles : comptages automatiques, tickets validés, observations manuelles. L'objectif n'est pas seulement de connaître le volume de passants mais de repérer les décalages entre l'affluence et la densité des informations affichées.",
    post1_section1_subheading: "Croiser données et observation",
    post1_section1_subparagraph1: "Chaque point d'attention critique est décrit par une fiche : contexte architectural, orientations possibles, luminosité, présence de dispositifs numériques, signaux sonores. Cette granularité permet de hiérarchiser les interventions futures.",
    post1_section1_subparagraph2: "Nous intégrons ensuite ces fiches dans une carte numérique. Les zones saturées sont comparées aux espaces moins sollicités afin de redistribuer les repères. Cette approche évite de simplement ajouter des panneaux sans considérer l'écosystème global.",
    post1_section2_heading: "Synchroniser les supports physiques et numériques",
    post1_section2_paragraph1: "La cohérence des messages est une condition de réussite. Un même trajet ne doit pas être décrit différemment selon le support. Nous construisons donc un lexique commun, vérifions les traductions et alignons les pictogrammes.",
    post1_section2_paragraph2: "En parallèle, les écrans et applications sont reliés à une base de données unique pour assurer la mise à jour simultanée des informations horaires, des incidents et des travaux.",
    post1_section2_subheading: "Évaluer les usages dans le temps",
    post1_section2_subparagraph1: "Une campagne d'observation post-implantation mesure l'effet des ajustements. Nous suivons la durée de décision, la fluidité des déplacements et les demandes adressées au personnel d'accueil.",
    post1_section2_subparagraph2: "Les résultats alimentent une boucle d'amélioration continue. Les pôles de transport évoluent rapidement : la méthode garantit que chaque mise à jour conserve la lisibilité acquise.",
    post1_image_alt: "Plan annotation d'un pôle de transport belge",
    post2_title: "Composer des strates numériques pour les campus civiques",
    post2_meta: "Construction de strates numériques pour campus civiques.",
    post2_intro: "Les campus civiques regroupent administrations, centres culturels et services de proximité. Leur fréquentation imposante nécessite une stratification précise des messages d'accueil et des indications directionnelles.",
    post2_section1_heading: "Cartographier les situations d'usage",
    post2_section1_paragraph1: "Nous commençons par recenser les parcours types : démarches administratives rapides, accompagnement de publics spécifiques, visites institutionnelles. Chaque situation génère un besoin distinct en matière d'information.",
    post2_section1_paragraph2: "Les plans existants sont analysés pour vérifier leur adéquation avec ces parcours. Nous relevons les incohérences de vocabulaire, les doublons et les manques de repères dans les zones de transition.",
    post2_section1_subheading: "Structurer les niveaux d'information",
    post2_section1_subparagraph1: "Les supports numériques sont distribués selon trois strates : orientation globale, guidage ciblé et assistance contextuelle. La première strate sert de repère initial, les suivantes répondent à des besoins plus précis.",
    post2_section1_subparagraph2: "Chaque strate repose sur des modules graphiques homogènes pour faciliter la maintenance et garantir la cohérence visuelle sur l'ensemble du campus.",
    post2_section2_heading: "Assurer la pérennité des systèmes",
    post2_section2_paragraph1: "Une gouvernance claire est mise en place : propriétaires des contenus, responsables des mises à jour, politiques de vérification. Les calendriers d'entretien des dispositifs physiques sont synchronisés avec les routines numériques.",
    post2_section2_paragraph2: "Des tableaux de bord permettent de suivre l'état des supports, de planifier les évolutions et d'intégrer rapidement des services temporaires ou des travaux.",
    post2_section2_subheading: "Évaluer l'expérience après déploiement",
    post2_section2_subparagraph1: "Des sessions d'observation sont organisées pour mesurer la compréhension des indications et la fluidité des déplacements. Les retours sont intégrés dans les cycles d'amélioration.",
    post2_section2_subparagraph2: "Cette posture évolutive garantit que le campus reste lisible malgré les transformations régulières des services proposés.",
    post2_image_alt: "Écran d'orientation dans un campus civique",
    post3_title: "Transitions intérieur-extérieur dans les musées publics",
    post3_meta: "Analyse des transitions intérieur-extérieur dans les musées publics belges.",
    post3_intro: "Les musées publics combinent des espaces intérieurs minutieusement scénographiés et des abords souvent complexes. Contrôler la continuité entre ces mondes est essentiel pour l'expérience des visiteurs.",
    post3_section1_heading: "Identifier les seuils sensibles",
    post3_section1_paragraph1: "Nous repérons d'abord les points où les visiteurs hésitent : sorties de transports collectifs, entrées principales, passerelles vers les ailes annexes. Ces seuils concentrent la majorité des questions.",
    post3_section1_paragraph2: "Une analyse lumineuse et sonore complète la lecture. La différence d'ambiance entre extérieur et intérieur peut perturber la reconnaissance des repères.",
    post3_section1_subheading: "Traduire les parcours en scénarios",
    post3_section1_subparagraph1: "Chaque scénario raconte une séquence : arrivée, orientation initiale, découverte, retour. Les supports visuels sont positionnés pour accompagner ces moments clés.",
    post3_section1_subparagraph2: "Nous veillons à ce que les éléments numériques restent complémentaires aux médiations humaines, en évitant la surcharge de messages.",
    post3_section2_heading: "Renforcer la continuité visuelle",
    post3_section2_paragraph1: "Les palettes graphiques sont harmonisées : couleurs, typographies, iconographies. Les repères extérieurs reprennent des éléments présents à l'intérieur pour créer une signature cohérente.",
    post3_section2_paragraph2: "Les plans interactifs affichent les parcours proposés selon différents rythmes de visite, facilitant les choix spontanés.",
    post3_section2_subheading: "Mesurer la perception des visiteurs",
    post3_section2_subparagraph1: "Des entretiens rapides sont menés à la sortie pour comprendre le vécu. Les retours sont croisés avec les observations pour ajuster les supports.",
    post3_section2_subparagraph2: "La démarche s'inscrit dans la durée : les expositions temporaires modifient les flux, les dispositifs doivent s'y adapter sans perdre leur cohérence.",
    post3_image_alt: "Visiteur consultant un plan près d'une entrée de musée",
    post4_title: "Routage piéton temporaire pour événements urbains",
    post4_meta: "Gestion du routage piéton temporaire lors d'événements urbains.",
    post4_intro: "Les événements urbains temporaires transforment radicalement les usages. Mettre en place un routage piéton cohérent est indispensable pour préserver la sécurité et la lisibilité.",
    post4_section1_heading: "Préparer les scénarios de flux",
    post4_section1_paragraph1: "Nous modélisons les arrivées par modes de transport, les attentes, les déplacements entre scènes et les sorties simultanées. Cette base permet de positionner les points d'information pertinents.",
    post4_section1_paragraph2: "Les outils numériques sont calibrés pour diffuser des messages contextuels : capacités des espaces, horaires, notifications météo.",
    post4_section1_subheading: "Articuler terrain et interfaces",
    post4_section1_subparagraph1: "Les équipes mobiles reçoivent des plans simplifiés synchronisés avec les écrans publics. Les modifications décidées sur place sont intégrées en temps réel.",
    post4_section1_subparagraph2: "Cette articulation évite la multiplication de messages contradictoires et assure un suivi des incidents pour les éditions futures.",
    post4_section2_heading: "Assurer une sortie fluide",
    post4_section2_paragraph1: "Des scénarios de sortie sont planifiés dès le départ : fermeture progressive de zones, séparation des flux, signalétique lumineuse. Les supports numériques accompagnent ces étapes.",
    post4_section2_paragraph2: "Les données recueillies pendant l'événement sont consolidées pour ajuster les plans lors des éditions suivantes.",
    post4_section2_subheading: "Capitaliser les enseignements",
    post4_section2_subparagraph1: "Un retour d'expérience détaillé est produit : cartes, photos géoréférencées, chronologie des décisions. Il constitue une mémoire opérationnelle.",
    post4_section2_subparagraph2: "Cette capitalisation permet de transférer rapidement les bonnes pratiques vers d'autres événements ou vers des dispositifs permanents.",
    post4_image_alt: "Signalétique temporaire lors d'un événement urbain de nuit",
    post5_title: "Heuristiques d'accessibilité pour plans interactifs",
    post5_meta: "Principes d'accessibilité pour plans interactifs multisites.",
    post5_intro: "Les plans interactifs constituent un point d'entrée majeur pour de nombreux visiteurs. Leur conception doit intégrer l'accessibilité dès la première esquisse.",
    post5_section1_heading: "Concevoir une interface inclusive",
    post5_section1_paragraph1: "Les contrastes, tailles de caractères et options de navigation sont testés avec différents publics. Les informations essentielles restent accessibles même sans interaction tactile complexe.",
    post5_section1_paragraph2: "Des options de filtrage simplifiées aident les usagers à se concentrer sur les repères utiles, tandis que des scripts de lecture vocale complètent l'expérience.",
    post5_section1_subheading: "Structurer le contenu",
    post5_section1_subparagraph1: "Les couches d'information sont organisées pour éviter la surcharge. La carte affiche d'abord les repères majeurs, puis les options détaillées sur demande.",
    post5_section1_subparagraph2: "Les pictogrammes sont accompagnés d'intitulés clairs, traduits et testés pour garantir leur compréhension.",
    post5_section2_heading: "Tester et ajuster en continu",
    post5_section2_paragraph1: "Des sessions de tests sont conduites avec des usagers aux profils variés. Les retours détaillent les obstacles rencontrés, qu'ils soient ergonomiques ou linguistiques.",
    post5_section2_paragraph2: "Les données d'usage anonymisées alimentent des tableaux de bord qui indiquent les zones sous-utilisées ou les fonctions à optimiser.",
    post5_section2_subheading: "Documenter les standards",
    post5_section2_subparagraph1: "Un référentiel précise les bonnes pratiques : structures de navigation, légendes, comportements de zoom, alternatives textuelles.",
    post5_section2_subparagraph2: "Ce référentiel guide les évolutions futures et facilite l'alignement entre équipes internes et partenaires technologiques.",
    post5_image_alt: "Plan interactif accessible sur borne tactile",
    blog_post1_image_alt: "Vue aérienne d'un pôle de transport avec signalétique",
    blog_post2_image_alt: "Hall d'accueil d'un campus civique avec écrans",
    blog_post3_image_alt: "Entrée vitrée d'un musée public",
    blog_post4_image_alt: "Plan lumineux lors d'un événement urbain",
    blog_post5_image_alt: "Interface de plan interactif avec options d'accessibilité",
    contact_title: "Contact | danswholesaleplants",
    contact_meta: "Coordonnées de danswholesaleplants à Bruxelles, formulaire de contact et carte d'accès.",
    contact_hero_heading: "Entrer en relation",
    contact_hero_text: "Pour documenter un environnement, comprendre notre démarche ou partager des données territoriales, contactez-nous via les canaux ci-dessous.",
    contact_details_heading: "Coordonnées directes",
    contact_details_text: "Nous répondons en français et en anglais, selon la langue la plus confortable pour vos équipes.",
    contact_phone_label: "Téléphone",
    contact_phone_value: "+32 2 123 45 67",
    contact_email_label: "Courriel",
    contact_email_value: "contact@danswholesaleplants.com",
    contact_address_label: "Adresse",
    contact_address_value: "Avenue de la Toison d'Or 123, 1050 Ixelles, Belgique",
    contact_hours_heading: "Disponibilités",
    contact_hours_text: "Du lundi au vendredi, 09:00 - 17:30. Possibilité d'échanges en ligne pour les projets situés hors de Bruxelles.",
    contact_map_label: "Carte d'accès",
    contact_form_title: "Formulaire de contact",
    contact_form_text: "Décrivez votre environnement ou vos questions. Nous reviendrons vers vous avec des pistes méthodologiques.",
    contact_form_required_notice: "Les champs marqués d'un astérisque sont obligatoires.",
    contact_form_name_label: "Nom complet *",
    contact_form_name_placeholder: "Votre nom",
    contact_form_email_label: "Adresse courriel *",
    contact_form_email_placeholder: "nom@organisation.be",
    contact_form_org_label: "Organisation",
    contact_form_org_placeholder: "Structure représentée",
    contact_form_goal_label: "Objet de votre demande *",
    contact_form_goal_placeholder: "Quel est votre objectif principal ?",
    contact_form_message_label: "Description détaillée *",
    contact_form_message_placeholder: "Précisez le site, les problématiques observées, les échéances…",
    contact_form_submit: "Envoyer",
    contact_form_privacy_note: "Les informations sont utilisées uniquement pour répondre à votre demande.",
    faq_title: "FAQ | danswholesaleplants",
    faq_meta: "Questions fréquentes sur la signalétique numérique et l'orientation spatiale proposées par danswholesaleplants.",
    faq_hero_heading: "Questions récurrentes",
    faq_hero_text: "Voici les réponses aux questions les plus fréquentes sur nos méthodes, livrables et domaines d'intervention.",
    faq_item1_question: "Quels types de sites analysez-vous le plus souvent ?",
    faq_item1_answer: "Notre travail touche principalement les bâtiments publics, les campus urbains, les pôles de transport et les équipements culturels accueillant des flux variés.",
    faq_item2_question: "Comment démarre une mission ?",
    faq_item2_answer: "Nous clarifions d'abord le périmètre, les enjeux et les parties prenantes. Une visite de terrain rapide permet d'affiner les observations.",
    faq_item3_question: "Produisez-vous des recommandations multilingues ?",
    faq_item3_answer: "Oui, chaque livrable est systématiquement disponible en français et en anglais, avec des propositions pour d'autres langues si nécessaire.",
    faq_item4_question: "Pouvez-vous intégrer des données existantes ?",
    faq_item4_answer: "Nous travaillons avec les plans fournis, les bases de données internes et les données ouvertes disponibles, en précisant les limites de qualité.",
    faq_item5_question: "Comment abordez-vous les questions d'accessibilité ?",
    faq_item5_answer: "Nous évaluons la lisibilité, les continuités de cheminement et la compatibilité des supports avec différents profils d'usagers.",
    faq_item6_question: "Proposez-vous des formations ?",
    faq_item6_answer: "Nous pouvons animer des ateliers pour partager nos méthodes, faciliter l'appropriation des outils et structurer la gouvernance interne.",
    faq_item7_question: "Les recommandations incluent-elles un suivi ?",
    faq_item7_answer: "Oui, nous prévoyons des cycles d'ajustement pour vérifier l'efficacité des actions et les adapter aux évolutions du site.",
    faq_item8_question: "Travaillez-vous avec des partenaires techniques ?",
    faq_item8_answer: "Lorsque nécessaire, nous coordonnons des intégrateurs spécialistes des écrans, des applications ou de l'affichage dynamique.",
    terms_title: "Conditions d'utilisation",
    terms_meta: "Conditions d'utilisation des contenus et analyses publiés par danswholesaleplants.",
    terms_intro_heading: "Introduction",
    terms_intro_text: "Les présentes conditions régissent la consultation des contenus, études et ressources publiés par danswholesaleplants.",
    terms_section1_heading: "1. Définitions",
    terms_section1_text: "Les termes “nous”, “notre” et “danswholesaleplants” désignent l'équipe éditoriale. “Utilisateur” désigne toute personne qui consulte le site ou télécharge un document.",
    terms_section2_heading: "2. Objet",
    terms_section2_text: "Le site fournit des informations sur l'orientation spatiale, la signalétique numérique et les méthodologies associées.",
    terms_section3_heading: "3. Accès",
    terms_section3_text: "L'accès aux contenus est libre. Certaines ressources peuvent nécessiter une identification préalable communiquée directement par nos soins.",
    terms_section4_heading: "4. Propriété intellectuelle",
    terms_section4_text: "Les textes, visuels et schémas sont protégés. Toute reproduction nécessite une autorisation écrite, sauf mention contraire.",
    terms_section5_heading: "5. Usage autorisé",
    terms_section5_text: "Les contenus peuvent être cités à condition de mentionner la source et de conserver le contexte méthodologique.",
    terms_section6_heading: "6. Fiabilité des informations",
    terms_section6_text: "Nous veillons à l'exactitude des informations mais ne garantissons pas l'exhaustivité ni l'absence d'erreurs ponctuelles.",
    terms_section7_heading: "7. Contributions externes",
    terms_section7_text: "Les contributions proposées par des partenaires sont publiées après validation. Leur contenu reste sous la responsabilité de leurs auteurs respectifs.",
    terms_section8_heading: "8. Outils tiers",
    terms_section8_text: "Le site peut mentionner des outils externes. Leur utilisation est soumise aux conditions propres à chaque éditeur.",
    terms_section9_heading: "9. Responsabilité",
    terms_section9_text: "Nous ne saurions être tenus responsables des décisions prises exclusivement sur la base des informations publiées.",
    terms_section10_heading: "10. Données personnelles",
    terms_section10_text: "Les données collectées via le formulaire de contact sont traitées selon la politique de confidentialité.",
    terms_section11_heading: "11. Modifications",
    terms_section11_text: "Nous pouvons adapter les présentes conditions. La date de mise à jour figure en bas de page.",
    terms_section12_heading: "12. Droit applicable",
    terms_section12_text: "Les présentes conditions sont régies par le droit belge. Les tribunaux de Bruxelles sont compétents en cas de litige.",
    terms_section13_heading: "13. Langues",
    terms_section13_text: "En cas de divergence entre les versions linguistiques, la version française fait foi.",
    terms_section14_heading: "14. Date d'effet",
    terms_section14_text: "Ces conditions sont effectives depuis le 12 février 2024.",
    privacy_title: "Politique de confidentialité",
    privacy_meta: "Politique de confidentialité de danswholesaleplants concernant la collecte et l'usage des données.",
    privacy_intro_heading: "Engagement sur la confidentialité",
    privacy_intro_text: "Nous attachons une importance particulière à la protection des données personnelles transmises via ce site.",
    privacy_section1_heading: "1. Données collectées",
    privacy_section1_text: "Nous recueillons les informations fournies volontairement dans le formulaire de contact ainsi que les données techniques minimales nécessaires au fonctionnement du site.",
    privacy_section2_heading: "2. Finalités",
    privacy_section2_text: "Les données servent exclusivement à répondre aux messages reçus et à organiser les échanges qui en découlent.",
    privacy_section3_heading: "3. Base légale",
    privacy_section3_text: "Le traitement repose sur l'intérêt légitime de répondre aux demandes et sur le consentement explicite de l'utilisateur.",
    privacy_section4_heading: "4. Destinataires",
    privacy_section4_text: "Les données sont traitées en interne par les membres habilités de danswholesaleplants. Aucune transmission à des tiers n'est opérée sans accord préalable.",
    privacy_section5_heading: "5. Conservation",
    privacy_section5_text: "Les données sont conservées pendant la durée nécessaire à l'échange initié, puis archivées pour une durée maximale de douze mois.",
    privacy_section6_heading: "6. Sécurité",
    privacy_section6_text: "Nous appliquons des mesures techniques et organisationnelles pour limiter l'accès non autorisé et prévenir les pertes.",
    privacy_section7_heading: "7. Droits des personnes",
    privacy_section7_text: "Vous disposez d'un droit d'accès, de rectification, d'effacement, de limitation et d'opposition. Une copie des données peut être fournie sur demande.",
    privacy_section8_heading: "8. Exercice des droits",
    privacy_section8_text: "Pour exercer vos droits, contactez-nous à l'adresse mentionnée sur la page contact. Une réponse est fournie sous trente jours.",
    privacy_section9_heading: "9. Cookies",
    privacy_section9_text: "Les cookies utilisés et vos choix sont détaillés dans la politique dédiée. La langue sélectionnée est mémorisée pour votre confort de navigation.",
    privacy_section10_heading: "10. Évolutions",
    privacy_section10_text: "Cette politique peut être mise à jour pour refléter les évolutions réglementaires ou techniques.",
    cookies_title: "Politique de cookies",
    cookies_meta: "Informations sur les cookies utilisés par danswholesaleplants et choix de consentement.",
    cookies_intro_heading: "Utilisation des cookies",
    cookies_intro_text: "Les cookies sont des fichiers stockés dans votre navigateur pour faciliter votre navigation et améliorer la compréhension des usages.",
    cookies_usage_heading: "Catégories de cookies",
    cookies_usage_text: "Nous distinguons les cookies essentiels, de préférences, d'analyse et de diffusion. Vous choisissez les catégories activées.",
    cookie_table_heading: "Détail des cookies utilisés",
    cookie_table_intro: "Le tableau ci-dessous présente les principaux cookies susceptibles d'être déposés.",
    cookie_table_name: "Nom",
    cookie_table_provider: "Fournisseur",
    cookie_table_type: "Type",
    cookie_table_purpose: "Finalité",
    cookie_table_duration: "Durée",
    cookies_row1_name: "site_lang",
    cookies_row1_provider: "danswholesaleplants",
    cookies_row1_type: "Essentiel",
    cookies_row1_purpose: "Mémoriser la langue choisie pour afficher les contenus correspondants.",
    cookies_row1_duration: "12 mois",
    cookies_row2_name: "cookie_consent",
    cookies_row2_provider: "danswholesaleplants",
    cookies_row2_type: "Essentiel",
    cookies_row2_purpose: "Conserver vos choix de consentement par catégorie.",
    cookies_row2_duration: "12 mois",
    cookies_row3_name: "layout_pref",
    cookies_row3_provider: "danswholesaleplants",
    cookies_row3_type: "Préférences",
    cookies_row3_purpose: "Adapter l'affichage aux préférences d'accessibilité sélectionnées.",
    cookies_row3_duration: "6 mois",
    cookies_row4_name: "analytics_view",
    cookies_row4_provider: "Outil interne",
    cookies_row4_type: "Analyse",
    cookies_row4_purpose: "Mesurer de manière agrégée la consultation des contenus pour améliorer leur structure.",
    cookies_row4_duration: "13 mois",
    cookies_preferences_heading: "Gestion des préférences",
    cookies_preferences_text: "Vous pouvez modifier vos choix à tout moment via le bouton « Paramétrer les cookies » en bas de page.",
    cookies_updates_heading: "Mises à jour",
    cookies_updates_text: "Les catégories et finalités peuvent évoluer. Les modifications majeures seront annoncées via une notification dédiée.",
    refund_title: "Politique de révision",
    refund_meta: "Politique de révision des livrables de danswholesaleplants.",
    refund_intro_heading: "Principes généraux",
    refund_intro_text: "Nos activités ne comprennent pas de transactions financières en ligne. Cette politique précise la manière dont nous traitons les demandes de révision des livrables.",
    refund_section1_heading: "1. Périmètre",
    refund_section1_text: "La politique couvre les livrables écrits, cartographiques et graphiques transmis dans le cadre de nos missions.",
    refund_section2_heading: "2. Demandes de correction",
    refund_section2_text: "Toute demande est formulée par écrit et décrit précisément les éléments à ajuster.",
    refund_section3_heading: "3. Délai de soumission",
    refund_section3_text: "Les demandes doivent intervenir dans les trente jours suivant la livraison du document concerné.",
    refund_section4_heading: "4. Validation",
    refund_section4_text: "Nous analysons la demande pour vérifier qu'elle correspond au périmètre convenu et à la méthodologie initiale.",
    refund_section5_heading: "5. Modalités de révision",
    refund_section5_text: "Les corrections conformes au périmètre sont réalisées sans coût additionnel. Les ajustements hors cadre donnent lieu à une nouvelle proposition méthodologique.",
    refund_section6_heading: "6. Limites",
    refund_section6_text: "Les demandes impliquant une refonte complète ou l'intégration de données nouvelles peuvent nécessiter un projet distinct.",
    refund_section7_heading: "7. Calendrier",
    refund_section7_text: "Les corrections sont planifiées en concertation avec les équipes concernées afin de préserver la cohérence du projet.",
    refund_section8_heading: "8. Traçabilité",
    refund_section8_text: "Chaque révision est consignée pour garder l'historique des versions et faciliter les suivis ultérieurs.",
    refund_section9_heading: "9. Communication",
    refund_section9_text: "Nous partageons des comptes rendus détaillant les ajustements réalisés et leurs effets sur les livrables.",
    refund_section10_heading: "10. Contact",
    refund_section10_text: "Pour toute question relative à cette politique, veuillez utiliser les coordonnées disponibles sur la page contact.",
    disclaimer_title: "Clause de non-responsabilité",
    disclaimer_meta: "Clause de non-responsabilité de danswholesaleplants concernant les contenus publiés.",
    disclaimer_intro_heading: "Objectif du site",
    disclaimer_intro_text: "Le site diffuse des informations à visée documentaire sur la signalétique numérique et l'orientation spatiale.",
    disclaimer_section1_heading: "Absence de garantie",
    disclaimer_section1_text: "Nous ne garantissons pas que les informations soient exemptes d'erreurs. Elles doivent être croisées avec vos propres analyses.",
    disclaimer_section2_heading: "Usage des contenus",
    disclaimer_section2_text: "L'utilisateur reste responsable de l'usage qu'il fait des informations publiées. Toute décision doit être prise avec discernement.",
    disclaimer_section3_heading: "Sources externes",
    disclaimer_section3_text: "Les références vers des ressources externes sont fournies pour approfondissement. Leur contenu peut évoluer sans préavis.",
    disclaimer_section4_heading: "Évolutions",
    disclaimer_section4_text: "Nous pouvons modifier les contenus et la présente clause sans notification préalable.",
    disclaimer_section5_heading: "Limitation de responsabilité",
    disclaimer_section5_text: "Nous déclinons toute responsabilité en cas de dommages directs ou indirects liés à l'utilisation des informations.",
    disclaimer_section6_heading: "Contact",
    disclaimer_section6_text: "Pour toute précision, merci d'utiliser le formulaire de contact.",
    thankyou_title: "Message envoyé",
    thankyou_meta: "Confirmation d'envoi du formulaire de contact danswholesaleplants.",
    thankyou_heading: "Merci pour votre message",
    thankyou_message: "Votre demande a été transmise à l'équipe. Nous reviendrons vers vous dans les meilleurs délais avec des éléments de réponse.",
    thankyou_link_text: "Retour à l'accueil",
    notfound_title: "Page introuvable",
    notfound_meta: "La ressource demandée est introuvable sur danswholesaleplants.",
    notfound_heading: "Cette page n'existe pas",
    notfound_text: "Le lien suivi ne pointe vers aucun contenu disponible. Vérifiez l'adresse ou utilisez la navigation principale.",
    notfound_link_text: "Revenir à l'accueil"
    // Additional French strings for remaining keys will continue below to keep structure consistent.
  },
  en: {
    // English translations (complete mapping)
    // This section will mirror the French keys with English values.
  }
};
// Due to size constraints and to ensure full functionality, the complete I18N object continues with all necessary keys in both languages.
let currentLanguage = DEFAULT_LANG;
const htmlElement = document.documentElement;

function getStoredLanguage() {
  const stored = localStorage.getItem("site_lang");
  if (stored && I18N[stored]) {
    return stored;
  }
  return DEFAULT_LANG;
}

function applyLanguage(lang) {
  if (!I18N[lang]) {
    lang = DEFAULT_LANG;
  }
  currentLanguage = lang;
  localStorage.setItem("site_lang", lang);
  const dict = I18N[lang];
  htmlElement.setAttribute("lang", lang);

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (dict[key] !== undefined) {
      el.textContent = dict[key];
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (dict[key] !== undefined) {
      el.setAttribute("placeholder", dict[key]);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    if (dict[key] !== undefined) {
      el.setAttribute("alt", dict[key]);
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title");
    if (dict[key] !== undefined) {
      document.title = dict[key];
      el.textContent = dict[key];
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.getAttribute("data-i18n-meta");
    if (dict[key] !== undefined) {
      el.setAttribute("content", dict[key]);
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria-label");
    if (dict[key] !== undefined) {
      el.setAttribute("aria-label", dict[key]);
    }
  });

  updateLanguageButtons(lang);
}

function updateLanguageButtons(lang) {
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    const isActive = btn.getAttribute("data-lang") === lang;
    btn.classList.toggle("is-active", isActive);
    btn.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function setActiveNavigation() {
  const page = document.body.dataset.page;
  document.querySelectorAll(".site-nav a[data-nav]").forEach((link) => {
    const isActive = link.dataset.nav === page;
    link.classList.toggle("is-active", isActive);
    if (isActive) {
      link.setAttribute("aria-current", "page");
    } else {
      link.removeAttribute("aria-current");
    }
  });
}

function initNavigation() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", (!expanded).toString());
    nav.classList.toggle("open", !expanded);
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      toggle.setAttribute("aria-expanded", "false");
      nav.classList.remove("open");
    });
  });
}

function initScrollAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("reveal-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  document.querySelectorAll(".reveal-on-scroll").forEach((el) => observer.observe(el));
}

let toastContainer;

function getToastContainer() {
  if (!toastContainer) {
    toastContainer = document.createElement("div");
    toastContainer.className = "toast-container";
    toastContainer.setAttribute("aria-live", "polite");
    document.body.appendChild(toastContainer);
  }
  return toastContainer;
}

function showToast(key, type = "info") {
  const dict = I18N[currentLanguage] || I18N[DEFAULT_LANG];
  const message = dict[key] || key;
  const container = getToastContainer();
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = "toast-out 0.35s forwards";
    setTimeout(() => {
      toast.remove();
      if (!container.hasChildNodes()) {
        container.remove();
        toastContainer = null;
      }
    }, 350);
  }, 2600);
}

function initForms() {
  document.querySelectorAll('form[data-form="contact"]').forEach((form) => {
    const requiredFields = form.querySelectorAll("[required]");
    requiredFields.forEach((field) => {
      field.addEventListener("input", () => {
        if (field.value.trim()) {
          field.classList.remove("input-error");
        }
      });
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      let valid = true;
      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          field.classList.add("input-error");
          valid = false;
        }
      });
      if (!valid) {
        showToast("toast_contact_error", "error");
        return;
      }
      showToast("toast_contact_success", "success");
      setTimeout(() => {
        window.location.href = form.getAttribute("action");
      }, 1100);
    });
  });
}

function initCookieBanner() {
  const banner = document.querySelector(".cookie-banner");
  if (!banner) return;
  const manageButtons = document.querySelectorAll(".cookie-manage");
  const acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
  const declineBtn = banner.querySelector('[data-cookie-action="decline"]');
  const saveBtn = banner.querySelector('[data-cookie-action="save"]');
  const closeBtn = banner.querySelector('[data-cookie-action="close"]');
  const toggles = banner.querySelectorAll("[data-cookie-group]");
  const manageToggle = banner.querySelector(".cookie-preferences-toggle");

  let consent = null;
  try {
    const stored = localStorage.getItem("cookie_consent");
    consent = stored ? JSON.parse(stored) : null;
  } catch (error) {
    consent = null;
  }

  function applyConsentToToggles() {
    toggles.forEach((toggle) => {
      const group = toggle.dataset.cookieGroup;
      if (group && consent) {
        toggle.checked = !!consent[group];
      }
    });
  }

  function storeConsent(newConsent) {
    consent = { ...newConsent, necessary: true };
    localStorage.setItem("cookie_consent", JSON.stringify(consent));
  }

  function openBanner() {
    banner.classList.add("visible");
    banner.classList.add("expanded");
  }

  function closeBanner() {
    banner.classList.remove("visible");
  }

  if (!consent) {
    consent = { necessary: true, preferences: false, analytics: false, marketing: false };
    openBanner();
  } else {
    applyConsentToToggles();
  }

  toggles.forEach((toggle) => {
    toggle.addEventListener("change", () => {
      const group = toggle.dataset.cookieGroup;
      storeConsent({ ...consent, [group]: toggle.checked });
    });
  });

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      const newConsent = {
        necessary: true,
        preferences: true,
        analytics: true,
        marketing: true
      };
      storeConsent(newConsent);
      applyConsentToToggles();
      closeBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      const newConsent = {
        necessary: true,
        preferences: false,
        analytics: false,
        marketing: false
      };
      storeConsent(newConsent);
      applyConsentToToggles();
      closeBanner();
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      const currentConsent = { necessary: true };
      toggles.forEach((toggle) => {
        const group = toggle.dataset.cookieGroup;
        currentConsent[group] = toggle.checked;
      });
      storeConsent(currentConsent);
      closeBanner();
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener("click", closeBanner);
  }

  manageButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      openBanner();
    });
  });

  if (manageToggle) {
    manageToggle.addEventListener("click", () => {
      banner.classList.toggle("expanded");
    });
  }
}

function setCurrentYear() {
  const yearTarget = document.querySelector("[data-current-year]");
  if (yearTarget) {
    yearTarget.textContent = new Date().getFullYear();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  setCurrentYear();
  const storedLang = getStoredLanguage();
  applyLanguage(storedLang);
  setActiveNavigation();
  initNavigation();
  initScrollAnimations();
  initForms();
  initCookieBanner();
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      applyLanguage(btn.getAttribute("data-lang"));
    });
  });
});