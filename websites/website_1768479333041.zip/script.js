document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.querySelector(".menu-toggle");
    const navLinks = document.querySelector(".nav-links");
    if (menuToggle && navLinks) {
        menuToggle.addEventListener("click", () => {
            navLinks.classList.toggle("open");
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    const cookieAccept = document.getElementById("cookieAccept");
    const cookieDecline = document.getElementById("cookieDecline");

    if (cookieBanner) {
        const consent = localStorage.getItem("swietiydxk_cookie_consent");
        if (!consent) {
            cookieBanner.classList.add("active");
        }

        if (cookieAccept) {
            cookieAccept.addEventListener("click", () => {
                localStorage.setItem("swietiydxk_cookie_consent", "accepted");
                cookieBanner.classList.remove("active");
            });
        }

        if (cookieDecline) {
            cookieDecline.addEventListener("click", () => {
                localStorage.setItem("swietiydxk_cookie_consent", "declined");
                cookieBanner.classList.remove("active");
            });
        }
    }
});