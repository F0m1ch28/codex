import React from 'react';
import Meta from '../components/Meta';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <div className={styles.legal}>
    <Meta
      title="Cookie Policy | Imagination Unleashed"
      description="Understand how Imagination Unleashed uses cookies to improve your browsing experience."
      keywords="cookie policy, cookies, imagination unleashed cookies"
    />

    <h1>Cookie Policy</h1>
    <p>Last updated: 01 May 2024</p>

    <h2>What Are Cookies?</h2>
    <p>
      Cookies are small text files stored on your device to help websites
      function and offer enhanced experiences.
    </p>

    <h2>Types of Cookies We Use</h2>
    <ul>
      <li>
        <strong>Essential Cookies:</strong> Required for navigation and secure
        checkout processes.
      </li>
      <li>
        <strong>Performance Cookies:</strong> Anonymous analytics to understand
        how visitors use our site, enabling improvements.
      </li>
      <li>
        <strong>Preference Cookies:</strong> Remember your location, language,
        and saved play preferences.
      </li>
    </ul>

    <h2>Managing Cookies</h2>
    <p>
      You can adjust cookie settings via your browser at any time. Opting out of
      essential cookies may impact site functionality.
    </p>

    <h2>Consent</h2>
    <p>
      On your first visit, we present a banner requesting consent. Your choice
      is stored for future visits and can be updated by clearing your browser
      cookies.
    </p>

    <h2>Contact</h2>
    <p>
      Questions can be directed to{' '}
      <a href="mailto:info@imaginationplaystore.nl">
        info@imaginationplaystore.nl
      </a>
      .
    </p>
  </div>
);

export default CookiePolicy;