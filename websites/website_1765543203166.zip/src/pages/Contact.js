import React, { useState } from 'react';
import Meta from '../components/Meta';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  message: '',
  interest: 'General enquiry',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setSubmitted(false);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <div className={styles.contactPage}>
      <Meta
        title="Contact Imagination Unleashed"
        description="Get in touch with our Amsterdam-based toy experts for personalised recommendations, partnerships, or shipping support."
        keywords="contact toy store, Dutch toy shop contact, play advisor Netherlands"
      />

      <section className={styles.hero}>
        <h1>Let’s Talk Play!</h1>
        <p>
          Reach out to our friendly advisors for personalised toy selections,
          partnership opportunities, or support with your order.
        </p>
      </section>

      <section className={styles.grid}>
        <div className={styles.contactDetails}>
          <h2>Contact Details</h2>
          <p>
            <strong>Email:</strong>{' '}
            <a href="mailto:info@imaginationplaystore.nl">
              info@imaginationplaystore.nl
            </a>
          </p>
          <p>
            <strong>Phone:</strong>{' '}
            <a href="tel:+31201234567">+31 20 123 4567</a>
          </p>
          <p>
            <strong>Address:</strong> Toy Street 123, 1011 AB Amsterdam,
            Netherlands
          </p>
          <div className={styles.officeHours}>
            <h3>Office Hours</h3>
            <p>Monday – Friday: 09:00 – 17:30 CET</p>
            <p>Saturday: 10:00 – 16:00 CET</p>
          </div>
          <div className={styles.mapPlaceholder} aria-hidden="true">
            <span>📍</span>
            <p>Find us along the canals near Amsterdam Centraal.</p>
          </div>
        </div>

        <form className={styles.form} onSubmit={handleSubmit}>
          <fieldset>
            <legend>Send a Message</legend>
            <label htmlFor="name">Full Name</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              required
            />

            <label htmlFor="email">Email Address</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              required
            />

            <label htmlFor="interest">What can we help with?</label>
            <select
              id="interest"
              name="interest"
              value={formData.interest}
              onChange={handleChange}
            >
              <option>General enquiry</option>
              <option>Personalised toy recommendations</option>
              <option>Corporate &amp; school gifting</option>
              <option>Order or shipping support</option>
            </select>

            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              required
            />

            <button type="submit">Send Message</button>
          </fieldset>
          {submitted && (
            <p role="status" className={styles.success}>
              Thanks for reaching out! Our play advisors will respond within one
              business day.
            </p>
          )}
        </form>
      </section>

      <section className={styles.finalCta}>
        <h2>Prefer a playful consultation?</h2>
        <p>
          Book a 20-minute virtual session to co-create a play plan tailored to
          your child’s interests and developmental stage.
        </p>
        <a href="mailto:info@imaginationplaystore.nl?subject=Play%20Consultation%20Request">
          Request a Consultation
        </a>
      </section>
    </div>
  );
};

export default Contact;