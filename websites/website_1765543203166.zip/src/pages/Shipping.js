import React from 'react';
import Meta from '../components/Meta';
import styles from './Shipping.module.css';

const Shipping = () => (
  <div className={styles.shipping}>
    <Meta
      title="Shipping Information | Imagination Unleashed"
      description="Learn how we deliver toys across the Netherlands with eco-friendly packaging, local partners, and speedy service."
      keywords="shipping info Netherlands, toy delivery, eco-friendly packaging"
    />

    <section className={styles.hero}>
      <h1>Shipping Throughout the Netherlands</h1>
      <p>
        Every delivery is handled with care, sustainable packaging, and timely
        updates. From Amsterdam to Groningen, joyful parcels are on their way.
      </p>
    </section>

    <section className={styles.timeline}>
      <h2>Delivery Journey</h2>
      <ol>
        <li>
          <strong>Order Confirmation</strong>
          <p>You receive an email with curated play tips within minutes.</p>
        </li>
        <li>
          <strong>Playful Packing</strong>
          <p>
            Toys are wrapped in recycled tissue, sealed with compostable tape,
            and topped with a handwritten note.
          </p>
        </li>
        <li>
          <strong>Tracked Dispatch</strong>
          <p>
            Partner couriers deliver within 1-2 working days in NL, with carbon
            offsets for every journey.
          </p>
        </li>
      </ol>
    </section>

    <section className={styles.infoGrid}>
      <article>
        <h3>Same-Day Amsterdam</h3>
        <p>
          Orders placed before 12:00 are eligible for bicycle courier delivery
          within the city ring.
        </p>
      </article>
      <article>
        <h3>Gift Wrap</h3>
        <p>
          Complimentary celebration wrap featuring artist collaborations from
          Dutch illustrators.
        </p>
      </article>
      <article>
        <h3>Returns &amp; Exchanges</h3>
        <p>
          30-day window for unopened items. Contact our support team to arrange
          a smooth pick-up.
        </p>
      </article>
    </section>

    <section className={styles.notice}>
      <h2>Holiday &amp; Peak Season</h2>
      <p>
        During Sinterklaas and year-end festivities, we recommend ordering at
        least five days in advance to guarantee arrival. Express upgrades are
        available—just reach out!
      </p>
    </section>

    <section className={styles.contactCta}>
      <h2>Need help with delivery arrangements?</h2>
      <p>
        From corporate gifting to school deliveries, our logistics team is ready
        to help.
      </p>
      <a href="mailto:info@imaginationplaystore.nl">Contact Shipping Support</a>
    </section>
  </div>
);

export default Shipping;