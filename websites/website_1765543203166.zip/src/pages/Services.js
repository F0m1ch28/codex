import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './Services.module.css';

const categories = [
  {
    id: 'creative',
    title: 'Creative Play Studios',
    age: 'Ages 4-8',
    description:
      'Art kits, storytelling sets, and musical instruments that celebrate self-expression.',
    image:
      'https://images.unsplash.com/photo-1567113463300-102a7ebc06ce?auto=format&fit=crop&w=720&q=80',
    tag: 'Creative',
  },
  {
    id: 'stem',
    title: 'STEM Discovery Lab',
    age: 'Ages 5-10',
    description:
      'Science kits, engineering challenges, and programmable robots for curious minds.',
    image:
      'https://images.unsplash.com/photo-1502319775680-54fa3ea0f76d?auto=format&fit=crop&w=720&q=80',
    tag: 'STEM',
  },
  {
    id: 'sensory',
    title: 'Sensory Soothers',
    age: 'Ages 0-3',
    description:
      'Tactile toys, textured mats, and calm sensory companions crafted for early explorers.',
    image:
      'https://images.unsplash.com/photo-1529119368496-4a66b6b43b04?auto=format&fit=crop&w=720&q=80',
    tag: 'Baby',
  },
  {
    id: 'outdoor',
    title: 'Outdoor Imagination',
    age: 'Ages 3-9',
    description:
      'Gardening sets, nature scavenger hunts, and movement games for energetic play.',
    image:
      'https://images.unsplash.com/photo-1503455637927-730bce8583c0?auto=format&fit=crop&w=720&q=80',
    tag: 'Adventure',
  },
  {
    id: 'family-games',
    title: 'Family Game Evenings',
    age: 'All ages',
    description:
      'Cooperative board games and storytelling prompts that bring everyone to the table.',
    image:
      'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=720&q=80',
    tag: 'Family',
  },
  {
    id: 'mindfulness',
    title: 'Mindful Moments',
    age: 'Ages 6-12',
    description:
      'Yoga stories, breathing buddies, and journaling kits to build resilience and calm.',
    image:
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=720&q=80',
    tag: 'Wellbeing',
  },
];

const tags = ['All', 'Baby', 'Creative', 'STEM', 'Family', 'Adventure', 'Wellbeing'];

const Services = () => {
  const [activeTag, setActiveTag] = useState('All');

  const filteredCategories =
    activeTag === 'All'
      ? categories
      : categories.filter((category) => category.tag === activeTag);

  return (
    <div className={styles.services}>
      <Meta
        title="Toy Categories | Imagination Unleashed"
        description="Browse curated toy categories from sensory baby play to STEM discovery kits. Find the perfect imaginative match for every child."
        keywords="toy categories, creative play, STEM toys, sensory toys, Netherlands toy shop"
      />

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Playful Toy Categories</h1>
          <p>
            Explore vibrant collections built around developmental milestones
            and playful passions. Filter by theme to uncover the perfect match
            for your child.
          </p>
          <div className={styles.filters} role="tablist" aria-label="Toy category filters">
            {tags.map((tag) => (
              <button
                key={tag}
                type="button"
                role="tab"
                aria-selected={activeTag === tag}
                className={`${styles.filterButton} ${
                  activeTag === tag ? styles.filterActive : ''
                }`}
                onClick={() => setActiveTag(tag)}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.categorySection}>
        <div className={styles.categoryGrid}>
          {filteredCategories.map((category) => (
            <article key={category.id} className={styles.categoryCard} id={category.id}>
              <div className={styles.imageWrapper}>
                <img src={category.image} alt={category.title} />
                <span className={styles.tagLabel}>{category.tag}</span>
              </div>
              <div className={styles.cardContent}>
                <h2>{category.title}</h2>
                <p className={styles.ageRange}>{category.age}</p>
                <p>{category.description}</p>
                <Link
                  to={
                    category.id === 'sensory'
                      ? '/baby-toddler-games'
                      : category.id === 'stem'
                      ? '/educational-toys'
                      : '/contact'
                  }
                  className={styles.cardLink}
                >
                  Ask our Play Advisors
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.playProcess}>
        <div className={styles.processHeading}>
          <h2>How We Curate Play Experiences</h2>
          <p>
            Our play specialists partner with Dutch educators to ensure every
            collection supports curiosity, creativity, and confidence.
          </p>
        </div>
        <ol className={styles.processSteps}>
          <li>
            <h3>Research &amp; Insights</h3>
            <p>
              We analyze developmental frameworks and family feedback to
              identify emerging play needs.
            </p>
          </li>
          <li>
            <h3>Hands-on Testing</h3>
            <p>
              Families across the Netherlands test products for durability,
              engagement, and inclusive design.
            </p>
          </li>
          <li>
            <h3>Play Guide Creation</h3>
            <p>
              Each toy ships with playful prompts and expert tips to maximize
              the learning journey at home.
            </p>
          </li>
          <li>
            <h3>Continuous Support</h3>
            <p>
              Our advisors remain available to refresh collections as your child
              grows and their interests evolve.
            </p>
          </li>
        </ol>
      </section>

      <section className={styles.ctaStrip}>
        <h2>Need a personalised play plan?</h2>
        <p>
          Our team will build a bespoke selection aligned with your child’s
          interests, abilities, and personality.
        </p>
        <Link to="/contact" className={styles.ctaButton}>
          Talk to a Play Expert
        </Link>
      </section>
    </div>
  );
};

export default Services;