import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './Home.module.css';

const Home = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!email) {
      return;
    }
    setSubmitted(true);
    setEmail('');
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className={styles.home}>
      <Meta
        title="Imagination Unleashed | Premium Kids Toy Store in the Netherlands"
        description="Discover premium educational toys, baby games, and creative play sets at Imagination Unleashed. Delight families across the Netherlands with safe, sustainable fun."
        keywords="kids toys, educational toys, premium toy store Netherlands, toddler toys, imagination play"
      />

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroEyebrow}>Premium Dutch Toy Store</p>
          <h1>Imagination Unleashed</h1>
          <p className={styles.heroDescription}>
            Spark curiosity with joyful, high-quality toys that grow alongside
            your little ones. Discover inspired playthings curated for learning,
            laughter, and limitless imagination.
          </p>
          <div className={styles.heroActions}>
            <Link to="/categories" className={styles.heroButton}>
              Explore Toys
            </Link>
            <Link to="/about" className={styles.secondaryButton}>
              Our Story
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80"
            alt="Children playing joyfully with colorful wooden toys"
          />
          <span className={styles.heroBadge}>Safe • Sustainable • Joyful</span>
        </div>
      </section>

      <section className={styles.featured} aria-labelledby="featured-categories">
        <div className={styles.sectionHeading}>
          <h2 id="featured-categories">Featured Toy Worlds</h2>
          <p>
            Hand-picked collections that brighten playtime for every age and
            stage.
          </p>
        </div>
        <div className={styles.categoryGrid}>
          <article className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80"
              alt="Educational wooden blocks arranged on a play table"
            />
            <h3>Educational Explorers</h3>
            <p>STEM challenges, logic quests, and literacy adventures.</p>
            <Link to="/educational-toys" className={styles.cardLink}>
              Discover Educational Toys
            </Link>
          </article>
          <article className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1581447109212-0e3ca3934097?auto=format&fit=crop&w=600&q=80"
              alt="Smiling toddler crawling among soft play blocks"
            />
            <h3>Baby &amp; Toddler Wonder</h3>
            <p>Gentle sensory play, tummy-time friends, and first puzzles.</p>
            <Link to="/baby-toddler-games" className={styles.cardLink}>
              Explore Baby Play
            </Link>
          </article>
          <article className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1617813489478-3a497bb7d95a?auto=format&fit=crop&w=600&q=80"
              alt="Child painting with vibrant colors during craft time"
            />
            <h3>Creative Studios</h3>
            <p>Craft kits, musical moments, and storytelling sparks.</p>
            <Link to="/categories" className={styles.cardLink}>
              View All Categories
            </Link>
          </article>
          <article className={styles.categoryCard}>
            <img
              src="https://images.unsplash.com/photo-1527631746610-bca00a040d62?auto=format&fit=crop&w=600&q=80"
              alt="Parents and children constructing a science project together"
            />
            <h3>Family Game Nights</h3>
            <p>Collaborative games that build teamwork and laughter.</p>
            <Link to="/categories#family-games" className={styles.cardLink}>
              See Family Games
            </Link>
          </article>
        </div>
      </section>

      <section className={styles.promise}>
        <div className={styles.sectionHeading}>
          <h2>Our Promise to Dutch Families</h2>
          <p>
            Every collection is lovingly curated to balance safety, durability,
            and the power of imaginative play.
          </p>
        </div>
        <div className={styles.promiseContent}>
          <ul className={styles.promiseList}>
            <li>
              <strong>Certified Safe Materials</strong>
              <p>
                Tested to the highest EU standards with eco-conscious finishes
                gentle on tiny hands.
              </p>
            </li>
            <li>
              <strong>Designed for Growth</strong>
              <p>
                Open-ended play that adapts from toddler giggles to school-age
                discoveries.
              </p>
            </li>
            <li>
              <strong>Thoughtful Curation</strong>
              <p>
                Educators, designers, and parents collaborate on every
                collection we launch.
              </p>
            </li>
          </ul>
          <div className={styles.statsBox}>
            <h3>Playful Impact</h3>
            <dl className={styles.statsList}>
              <div>
                <dt>4,500+</dt>
                <dd>Families discovering new play adventures each year.</dd>
              </div>
              <div>
                <dt>120</dt>
                <dd>Premium brands sourced across Europe and beyond.</dd>
              </div>
              <div>
                <dt>30%</dt>
                <dd>Average increase in creative confidence reported by parents.</dd>
              </div>
            </dl>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHeading}>
          <h2>Benefits of Play</h2>
          <p>Every toy is chosen to nurture core skills in joyful ways.</p>
        </div>
        <div className={styles.benefitGrid}>
          <article>
            <h3>Creative Expression</h3>
            <p>
              Artful kits and storytelling prompts build confidence,
              imagination, and emotional intelligence.
            </p>
          </article>
          <article>
            <h3>Curiosity &amp; Discovery</h3>
            <p>
              STEM experiments and sensory play fuel inquisitive minds and
              encourage lifelong learning.
            </p>
          </article>
          <article>
            <h3>Motor Skills Mastery</h3>
            <p>
              Fine and gross motor activities strengthen coordination through
              fun and movement.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="parent-testimonials">
        <div className={styles.sectionHeading}>
          <h2 id="parent-testimonials">Loved by Dutch Families</h2>
          <p>Real stories from parents whose homes are now buzzing with play.</p>
        </div>
        <div className={styles.testimonialGrid}>
          <figure>
            <img
              src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80"
              alt="Portrait of a smiling mother"
            />
            <blockquote>
              “Every package feels like a celebration. My son has transformed
              our living room into a science lab!”
            </blockquote>
            <figcaption>— Lotte, Utrecht</figcaption>
          </figure>
          <figure>
            <img
              src="https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?auto=format&fit=crop&w=200&q=80"
              alt="Portrait of a happy father"
            />
            <blockquote>
              “The play prompts included with each toy make it so easy to bond
              with our toddler. We adore the quality.”
            </blockquote>
            <figcaption>— Pieter, Rotterdam</figcaption>
          </figure>
          <figure>
            <img
              src="https://images.unsplash.com/photo-1504593811423-6dd665756598?auto=format&fit=crop&w=200&q=80"
              alt="Portrait of a cheerful parent"
            />
            <blockquote>
              “Fast delivery in Amsterdam and the toys truly grow with our
              daughter. Worth every giggle.”
            </blockquote>
            <figcaption>— Saskia, Amsterdam</figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.shipping}>
        <div>
          <h2>Nationwide Dutch Delivery</h2>
          <p>
            From Groningen to Maastricht, playful parcels arrive swiftly and
            sustainably. Learn about delivery schedules, eco-packaging, and gift
            wrapping options.
          </p>
        </div>
        <Link to="/shipping" className={styles.shippingLink}>
          Shipping Information
        </Link>
      </section>

      <section className={styles.newsletter} aria-labelledby="newsletter-title">
        <div className={styles.sectionHeading}>
          <h2 id="newsletter-title">Join the Playful Dispatch</h2>
          <p>
            Be first to know about new collections, play guides, and seasonal
            inspiration crafted with Dutch educators.
          </p>
        </div>
        <form onSubmit={handleNewsletterSubmit} className={styles.newsletterForm}>
          <label htmlFor="newsletter-email" className="sr-only">
            Email address
          </label>
          <input
            id="newsletter-email"
            type="email"
            name="email"
            placeholder="you@example.com"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            required
            aria-label="Email address"
          />
          <button type="submit">Subscribe</button>
        </form>
        {submitted && (
          <p className={styles.successMessage} role="status">
            Thank you! Look out for sparkling play ideas in your inbox.
          </p>
        )}
      </section>

      <section className={styles.finalCta}>
        <div className={styles.finalCtaContent}>
          <h2>Open a World of Imaginative Play</h2>
          <p>
            Your next adventure awaits—crafted with care, backed by educators,
            and delivered with Dutch delight. Start exploring now.
          </p>
          <Link to="/categories" className={styles.finalCtaButton}>
            Start the Adventure
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;