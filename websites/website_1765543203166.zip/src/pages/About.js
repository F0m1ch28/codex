import React from 'react';
import Meta from '../components/Meta';
import styles from './About.module.css';

const About = () => (
  <div className={styles.about}>
    <Meta
      title="About Imagination Unleashed | Dutch Premium Toy Store"
      description="Learn about Imagination Unleashed, the Amsterdam-based toy store dedicated to creative play, safe materials, and educator-led curation."
      keywords="about us, Dutch toy store, creative play experts, team of educators"
    />

    <section className={styles.hero}>
      <h1>We turn everyday moments into play-filled stories.</h1>
      <p>
        Founded in Amsterdam, Imagination Unleashed is a collective of parents,
        designers, and educators determined to elevate playtime for families
        across the Netherlands.
      </p>
    </section>

    <section className={styles.story}>
      <div>
        <h2>Our Story</h2>
        <p>
          What began as a small pop-up on the canals grew into a nationwide
          online destination for families seeking purposeful playthings. We
          collaborate with artisans, sustainable brands, and education experts to
          craft collections that nurture curiosity and confidence.
        </p>
        <p>
          From eco-friendly materials to inclusive design, every decision is
          rooted in the belief that play is the bridge to a brighter future.
        </p>
      </div>
      <div className={styles.storyStats}>
        <div>
          <strong>2016</strong>
          <span>Our launch year (and first toy fair)</span>
        </div>
        <div>
          <strong>45</strong>
          <span>Educators contributing to play guides</span>
        </div>
        <div>
          <strong>100%</strong>
          <span>Plastic-free shipping experience</span>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <h2>Meet the Play Collective</h2>
      <div className={styles.teamGrid}>
        <article>
          <img
            src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=420&q=80"
            alt="Portrait of founder Elena"
          />
          <h3>Elena Vermeer</h3>
          <p>Founder &amp; Chief Play Curator</p>
          <p className={styles.bio}>
            Former art educator weaving together design and pedagogy to craft
            joyful experiences for kids.
          </p>
        </article>
        <article>
          <img
            src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=420&q=80"
            alt="Portrait of play researcher Malik"
          />
          <h3>Malik Janssen</h3>
          <p>Head of Play Research</p>
          <p className={styles.bio}>
            Specialises in STEM play, leading testing labs alongside Dutch
            primary schools.
          </p>
        </article>
        <article>
          <img
            src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=420&q=80"
            alt="Portrait of operations lead Noor"
          />
          <h3>Noor Pieters</h3>
          <p>Operations &amp; Sustainability Lead</p>
          <p className={styles.bio}>
            Oversees eco-packaging initiatives and ensures every order arrives
            with minimal footprint.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.process}>
      <h2>How Imagination Comes to Life</h2>
      <div className={styles.processGrid}>
        <div>
          <span>1</span>
          <h3>Discover</h3>
          <p>
            We scout European toy makers and host community workshops to spot
            emerging play themes.
          </p>
        </div>
        <div>
          <span>2</span>
          <h3>Test</h3>
          <p>
            Children across Amsterdam, Utrecht, and Eindhoven join play labs to
            test for engagement and delight.
          </p>
        </div>
        <div>
          <span>3</span>
          <h3>Curate</h3>
          <p>
            Educators and designers assemble themed collections paired with
            printable play guides for parents.
          </p>
        </div>
        <div>
          <span>4</span>
          <h3>Support</h3>
          <p>
            Our advisory team helps families evolve their play spaces as
            children grow and interests shift.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.faq}>
      <h2>Frequently Asked Questions</h2>
      <details>
        <summary>Do you offer guidance for different age groups?</summary>
        <p>
          Absolutely. Each collection features age markers, and our play advisors
          can craft tailored suggestions for siblings or mixed-age play.
        </p>
      </details>
      <details>
        <summary>How do you ensure toys are sustainable?</summary>
        <p>
          We prioritise FSC-certified woods, recycled textiles, and low-impact
          dyes. Packaging is plastic-free and fully recyclable.
        </p>
      </details>
      <details>
        <summary>Can schools collaborate with Imagination Unleashed?</summary>
        <p>
          Yes—schools across the Netherlands partner with us for classroom kits,
          workshops, and resource co-creation. Reach out via our contact page to
          begin.
        </p>
      </details>
    </section>

    <section className={styles.contactCta}>
      <h2>Partner with Us</h2>
      <p>
        From educational institutions to family-centred events, we love building
        playful experiences that delight communities.
      </p>
      <a href="mailto:info@imaginationplaystore.nl">Collaborate with Imagination Unleashed</a>
    </section>
  </div>
);

export default About;