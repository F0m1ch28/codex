import React from 'react';
import Meta from '../components/Meta';
import styles from './Legal.module.css';

const Terms = () => (
  <div className={styles.legal}>
    <Meta
      title="Terms of Service | Imagination Unleashed"
      description="Review the terms and conditions for using Imagination Unleashed, the premium Dutch toy store."
      keywords="terms of service, conditions, imagination unleashed"
    />

    <h1>Terms of Service</h1>
    <p>Last updated: 01 May 2024</p>

    <h2>1. Overview</h2>
    <p>
      Imagination Unleashed provides premium children’s toys via our website
      www.imaginationplaystore.nl. By accessing or using our services, you agree
      to these Terms.
    </p>

    <h2>2. Eligibility</h2>
    <p>
      Our services are intended for individuals aged 18 or older. By placing an
      order, you confirm you are legally capable of entering into contracts.
    </p>

    <h2>3. Orders</h2>
    <ul>
      <li>We reserve the right to decline orders that do not meet our criteria.</li>
      <li>
        Confirmation emails are sent immediately; please review details and
        contact us if corrections are needed.
      </li>
      <li>
        Custom play bundles may require additional information from the customer.
      </li>
    </ul>

    <h2>4. Intellectual Property</h2>
    <p>
      All content, including imagery, product descriptions, and branding, is the
      property of Imagination Unleashed or its partners. Content may not be
      reproduced without permission.
    </p>

    <h2>5. Liability</h2>
    <p>
      We curate products that meet EU safety requirements; however, adult
      supervision is recommended. Our liability is limited to the maximum extent
      permitted by Dutch law.
    </p>

    <h2>6. Amendments</h2>
    <p>
      We may update these Terms as our services evolve. Continued use after
      updates constitutes acceptance.
    </p>

    <h2>7. Contact</h2>
    <p>
      Questions regarding these Terms can be sent to{' '}
      <a href="mailto:info@imaginationplaystore.nl">
        info@imaginationplaystore.nl
      </a>
      .
    </p>
  </div>
);

export default Terms;