import React from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './EducationalToys.module.css';

const EducationalToys = () => (
  <div className={styles.educational}>
    <Meta
      title="Educational Toys | Imagination Unleashed"
      description="Discover hands-on educational toys that nurture STEM skills, literacy, and curiosity. Crafted for joyful learning at home."
      keywords="educational toys, STEM kits, learning toys, Netherlands educational store"
    />

    <section className={styles.hero}>
      <div className={styles.heroText}>
        <h1>Educational Toys for Bright Minds</h1>
        <p>
          Inspire discovery with thoughtfully designed STEM sets, literacy
          adventures, and logic games. Every piece is teacher-approved and ready
          for joyful learning.
        </p>
        <Link to="/contact" className={styles.heroButton}>
          Ask for Recommendations
        </Link>
      </div>
      <div className={styles.heroImage}>
        <img
          src="https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=860&q=80"
          alt="Child observing a science experiment with enthusiasm"
        />
      </div>
    </section>

    <section className={styles.features}>
      <div>
        <h2>Designed with Educators</h2>
        <p>
          Our advisory board of Dutch teachers helps us select toys that align
          with classroom competencies and encourage cross-curricular learning.
        </p>
      </div>
      <div>
        <h2>STEAM Adventure Kits</h2>
        <p>
          Chemistry labs, circuitry challenges, and robotics companions
          transform the kitchen table into a studio of experimentation.
        </p>
      </div>
      <div>
        <h2>Storytelling &amp; Language</h2>
        <p>
          Literacy games and creative writing prompts develop communication
          skills while nurturing empathy and imagination.
        </p>
      </div>
    </section>

    <section className={styles.collection}>
      <h2>Educator Favourites</h2>
      <div className={styles.cardGrid}>
        <article>
          <img
            src="https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=720&q=80"
            alt="Child assembling a robot toy"
          />
          <h3>Robotics Buddies</h3>
          <p>
            Modular robots with story-driven missions encourage critical
            thinking and coding basics.
          </p>
        </article>
        <article>
          <img
            src="https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=720&q=80"
            alt="Hands painting colorful geometric shapes"
          />
          <h3>Math &amp; Art Symmetry</h3>
          <p>
            Patterns, puzzles, and artful shapes build numeracy through tactile,
            creative play.
          </p>
        </article>
        <article>
          <img
            src="https://images.unsplash.com/photo-1511108690759-009324a90311?auto=format&fit=crop&w=720&q=80"
            alt="Mother and child reading a book together"
          />
          <h3>Story Worlds</h3>
          <p>
            Interactive books and puppet theatres make language skills bloom and
            foster confident readers.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.blogPreview}>
      <h2>Learning Lab Insights</h2>
      <div className={styles.blogGrid}>
        <article>
          <span>Play Guide</span>
          <h3>How to turn a STEM kit into a family challenge night</h3>
          <p>
            Step-by-step tips to guide teamwork, track discoveries, and keep
            curiosity thriving beyond the initial experiment.
          </p>
          <Link to="/contact">Request the full guide</Link>
        </article>
        <article>
          <span>Expert Advice</span>
          <h3>Boosting literacy with storytelling dice</h3>
          <p>
            Encourage expressive language with prompts that adapt for various
            ages and abilities.
          </p>
          <Link to="/contact">Ask for reading recommendations</Link>
        </article>
        <article>
          <span>Parent Q&amp;A</span>
          <h3>Choosing the right science toy for siblings</h3>
          <p>
            Blend age ranges and interests with open-ended kits that invite
            collaboration and independent play.
          </p>
          <Link to="/contact">Chat with a play advisor</Link>
        </article>
      </div>
    </section>

    <section className={styles.ctaBanner}>
      <div>
        <h2>Ready to build your learning corner?</h2>
        <p>
          Combine curated bundles with printable play prompts tailored to your
          child’s age and passions.
        </p>
      </div>
      <Link to="/contact">Design My Play Plan</Link>
    </section>
  </div>
);

export default EducationalToys;