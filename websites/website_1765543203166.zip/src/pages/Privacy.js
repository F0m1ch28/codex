import React from 'react';
import Meta from '../components/Meta';
import styles from './Legal.module.css';

const Privacy = () => (
  <div className={styles.legal}>
    <Meta
      title="Privacy Policy | Imagination Unleashed"
      description="Read how Imagination Unleashed handles personal data collected through our Dutch toy store."
      keywords="privacy policy, data protection, imagination unleashed privacy"
    />

    <h1>Privacy Policy</h1>
    <p>Last updated: 01 May 2024</p>

    <h2>1. Data Controller</h2>
    <p>
      Imagination Unleashed, Toy Street 123, 1011 AB Amsterdam, Netherlands,
      acts as the data controller for personal data collected on our website.
    </p>

    <h2>2. Information We Collect</h2>
    <ul>
      <li>Contact information provided via forms (name, email, phone).</li>
      <li>Order details and preferences necessary for fulfilment.</li>
      <li>
        Website analytics using privacy-friendly tools to improve user
        experience.
      </li>
    </ul>

    <h2>3. How We Use Data</h2>
    <p>
      Data is used to process orders, respond to enquiries, provide personalised
      recommendations, and send newsletters if opted in.
    </p>

    <h2>4. Legal Basis</h2>
    <p>
      We rely on contractual necessity, legitimate interest, and consent where
      applicable, in line with GDPR requirements.
    </p>

    <h2>5. Data Sharing</h2>
    <p>
      Personal data is shared only with essential service providers (e.g.,
      couriers) under strict confidentiality agreements.
    </p>

    <h2>6. Data Retention</h2>
    <p>
      We retain data only as long as necessary to fulfil services or comply with
      legal obligations.
    </p>

    <h2>7. Your Rights</h2>
    <ul>
      <li>Access, rectify, or erase your personal data.</li>
      <li>Restrict processing or object to specific uses.</li>
      <li>Withdraw consent for marketing communications at any time.</li>
    </ul>

    <h2>8. Contact</h2>
    <p>
      To exercise your rights, contact{' '}
      <a href="mailto:info@imaginationplaystore.nl">
        info@imaginationplaystore.nl
      </a>
      .
    </p>
  </div>
);

export default Privacy;