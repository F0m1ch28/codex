import React from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import styles from './BabyToddlerGames.module.css';

const BabyToddlerGames = () => (
  <div className={styles.baby}>
    <Meta
      title="Baby & Toddler Games | Imagination Unleashed"
      description="Gentle sensory toys and toddler games that nurture early development. Discover safe, sustainable joy for little explorers."
      keywords="baby games, toddler toys, sensory play Netherlands, developmental toys"
    />

    <section className={styles.hero}>
      <h1>Baby &amp; Toddler Playtime</h1>
      <p>
        Welcome the earliest giggles with sensory textures, soothing sounds, and
        first puzzles designed to spark curiosity from the very first months.
      </p>
      <img
        src="https://images.unsplash.com/photo-1585730117101-2ba4e139e79c?auto=format&fit=crop&w=960&q=80"
        alt="Laughing baby surrounded by soft pastel toys"
      />
    </section>

    <section className={styles.development}>
      <h2>Supporting Every Milestone</h2>
      <div className={styles.milestoneGrid}>
        <article>
          <h3>Tummy-Time Triumphs</h3>
          <p>
            Plush prop pillows and high-contrast cards strengthen core muscles
            while inspiring gaze tracking and focus.
          </p>
        </article>
        <article>
          <h3>Fine Motor Fun</h3>
          <p>
            Stackers, shape sorters, and bead mazes nurture coordination with
            joyful repetition and sensory delight.
          </p>
        </article>
        <article>
          <h3>First Words &amp; Rhythms</h3>
          <p>
            Sound makers and soft storybooks encourage early language
            interaction, bonding, and rhythm playtime.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.playMoments}>
      <div className={styles.playCard}>
        <img
          src="https://images.unsplash.com/photo-1597941447217-2a58bb72c288?auto=format&fit=crop&w=720&q=80"
          alt="Parent and baby playing with sensory board"
        />
        <div>
          <h3>Sensory Boards</h3>
          <p>
            Multi-texture panels crafted from natural woods and fabrics help
            babies explore safely while enhancing tactile awareness.
          </p>
        </div>
      </div>
      <div className={styles.playCard}>
        <img
          src="https://images.unsplash.com/photo-1581579438747-1c572c4e6d83?auto=format&fit=crop&w=720&q=80"
          alt="Toddler balancing on a foam play set"
        />
        <div>
          <h3>Movement Mats</h3>
          <p>
            Soft climbing sets and playful balance boards encourage gross motor
            confidence for adventurous toddlers.
          </p>
        </div>
      </div>
      <div className={styles.playCard}>
        <img
          src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=720&q=80"
          alt="Toddler engaged in a water play activity"
        />
        <div>
          <h3>Water Wonder</h3>
          <p>
            Mess-free water mats and floating friends add soothing sensory
            experiences to bathtime and backyard moments.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.care}>
      <h2>Parent Peace of Mind</h2>
      <ul className={styles.careList}>
        <li>
          <strong>European Safety Standards</strong> – Tested for tiny mouths,
          soft edges, and non-toxic finishes.
        </li>
        <li>
          <strong>Easy-Clean Materials</strong> – Wipeable surfaces and washable
          fabrics designed for daily adventures.
        </li>
        <li>
          <strong>Guided Play Prompts</strong> – Age-specific ideas to explore
          sensory play and bonding rituals.
        </li>
      </ul>
    </section>

    <section className={styles.cta}>
      <h2>Curate a Baby Play Basket</h2>
      <p>
        Share your little one’s stage and we’ll design a personalised basket of
        sensory treasures delivered across the Netherlands.
      </p>
      <Link to="/contact">Start My Basket</Link>
    </section>
  </div>
);

export default BabyToddlerGames;