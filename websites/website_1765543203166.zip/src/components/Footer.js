import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.brand}>
        <h2>Imagination Unleashed</h2>
        <p>
          Premium-quality toys that inspire curiosity, creativity, and lifelong
          learning for children across the Netherlands.
        </p>
        <div className={styles.socials} aria-label="Social media">
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noreferrer"
            aria-label="Instagram"
          >
            🌈
          </a>
          <a
            href="https://www.facebook.com"
            target="_blank"
            rel="noreferrer"
            aria-label="Facebook"
          >
            🎈
          </a>
          <a
            href="https://www.pinterest.com"
            target="_blank"
            rel="noreferrer"
            aria-label="Pinterest"
          >
            ✨
          </a>
        </div>
      </div>
      <div className={styles.links}>
        <h3>Explore</h3>
        <ul>
          <li>
            <Link to="/categories">Toy Categories</Link>
          </li>
          <li>
            <Link to="/educational-toys">Educational Toys</Link>
          </li>
          <li>
            <Link to="/baby-toddler-games">Baby &amp; Toddler</Link>
          </li>
          <li>
            <Link to="/about">About Imagination Unleashed</Link>
          </li>
        </ul>
      </div>
      <div className={styles.resources}>
        <h3>Customer Care</h3>
        <ul>
          <li>
            <Link to="/shipping">Shipping Info</Link>
          </li>
          <li>
            <Link to="/contact">Contact Support</Link>
          </li>
          <li>
            <Link to="/terms">Terms of Service</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>
      <div className={styles.contact}>
        <h3>Contact</h3>
        <p>
          Toy Street 123<br />
          1011 AB Amsterdam<br />
          Netherlands
        </p>
        <p>
          <a href="tel:+31201234567">+31 20 123 4567</a>
          <br />
          <a href="mailto:info@imaginationplaystore.nl">
            info@imaginationplaystore.nl
          </a>
        </p>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>&copy; {new Date().getFullYear()} Imagination Unleashed. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;