import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      const consent = window.localStorage.getItem('imagination-cookie-consent');
      if (consent !== 'accepted') {
        setVisible(true);
      }
    } catch (error) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    try {
      window.localStorage.setItem('imagination-cookie-consent', 'accepted');
    } catch (error) {
      // Continue silently if localStorage is unavailable
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        We use playful cookies to make sure your visit feels magical. Read more in our{' '}
        <Link to="/cookie-policy">Cookie Policy</Link>.
      </p>
      <button type="button" onClick={handleAccept}>
        Got it!
      </button>
    </div>
  );
};

export default CookieBanner;