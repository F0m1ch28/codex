import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import styles from './ScrollToTop.module.css';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => {
      if (window.pageYOffset > 240) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      className={`${styles.scrollButton} ${visible ? styles.visible : ''}`}
      onClick={handleClick}
      aria-label="Scroll back to top"
    >
      ↑
    </button>
  );
};

export default ScrollToTop;