document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('open');
            navToggle.classList.toggle('active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                navToggle.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const consentKey = 'wheresmlhi_cookie_consent';
    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const decisionButtons = cookieBanner.querySelectorAll('[data-decision]');
        const storedConsent = localStorage.getItem(consentKey);
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }
        decisionButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const decision = button.getAttribute('data-decision');
                localStorage.setItem(consentKey, decision);
                cookieBanner.classList.add('hidden');
            });
        });
    }
});