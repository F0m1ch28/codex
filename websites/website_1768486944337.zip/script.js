document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-links a');

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
            document.body.classList.toggle('nav-open', isOpen);
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (nav.classList.contains('open')) {
                    nav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                    document.body.classList.remove('nav-open');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('gcCookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('banner-hidden');
        }

        const cookieActions = cookieBanner.querySelectorAll('.cookie-action[data-consent]');
        cookieActions.forEach(action => {
            action.addEventListener('click', (event) => {
                event.preventDefault();
                const value = action.dataset.consent;
                if (value) {
                    localStorage.setItem('gcCookieConsent', value);
                }
                cookieBanner.classList.add('banner-hidden');
                const target = action.getAttribute('href');
                if (target && target !== '#') {
                    window.location.href = target;
                }
            });
        });
    }
});