import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";

const NotFound: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Page Not Found — DevLayer</title>
        <meta name="robots" content="noindex" />
      </Helmet>
      <section className="section bg-mist">
        <div className="max-w-4xl mx-auto px-5 text-center">
          <h1 className="font-display text-ink text-5xl mb-4">404</h1>
          <p className="text-lg text-slateEdge/80 mb-6">
            The page you’re looking for isn’t available. Explore our latest essays or return to the home page.
          </p>
          <Link to="/" className="btn-primary">
            Go home
          </Link>
        </div>
      </section>
    </>
  );
};

export default NotFound;