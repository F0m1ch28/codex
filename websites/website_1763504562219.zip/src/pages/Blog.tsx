import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

type Category = "Workflow" | "Systems" | "Tooling" | "Culture" | "All";

interface BlogSummary {
  title: string;
  slug: string;
  summary: string;
  category: Exclude<Category, "All">;
  readingTime: string;
  published: string;
}

const posts: BlogSummary[] = [
  {
    title: "Why Context Switching Kills Productivity",
    slug: "/blog/why-context-switching-kills-productivity",
    summary:
      "Inside the minds of developer workflows suffering from fragmented attention. Strategies for regaining momentum without sacrificing collaboration.",
    category: "Workflow",
    readingTime: "12 min read",
    published: "September 5, 2023"
  },
  {
    title: "Cloud Patterns for Scale",
    slug: "/blog/cloud-patterns-for-scale",
    summary:
      "A catalog of pragmatic patterns that help modern software systems scale gracefully across unpredictable workloads.",
    category: "Systems",
    readingTime: "14 min read",
    published: "October 12, 2023"
  },
  {
    title: "The Evolution of DevOps Culture",
    slug: "/blog/the-evolution-of-devops-culture",
    summary:
      "Tracing how devops culture matured into platform engineering practice with new rituals, tools, and mindsets.",
    category: "Culture",
    readingTime: "11 min read",
    published: "December 2, 2023"
  }
];

const Blog: React.FC = () => {
  const [category, setCategory] = useState<Category>("All");

  const filteredPosts = useMemo(() => {
    if (category === "All") return posts;
    return posts.filter((post) => post.category === category);
  }, [category]);

  return (
    <>
      <Helmet>
        <title>DevLayer Essays — Workflow, Systems, Tooling, Culture</title>
        <meta
          name="description"
          content="Browse DevLayer essays covering developer workflows, software systems, cloud infrastructure, tooling signals, and devops culture."
        />
        <link rel="canonical" href="https://devlayer.com/blog" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <span className="badge mb-6">Essays</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            Essays on developer workflows, software systems, and engineering culture.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            Explore deeply researched narratives spanning distributed computing, platform engineering, cloud infrastructure,
            and the psychology of collaboration.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-6xl mx-auto px-5">
          <div className="flex flex-wrap gap-3 justify-center md:justify-start mb-10">
            {["All", "Workflow", "Systems", "Tooling", "Culture"].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat as Category)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                  category === cat
                    ? "bg-azurePulse text-white"
                    : "bg-mist text-slateEdge border border-slateEdge/20 hover:border-azurePulse"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid gap-6">
            {filteredPosts.map((post) => (
              <motion.article
                key={post.slug}
                className="layer-card flex flex-col md:flex-row md:items-center md:justify-between gap-6"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div>
                  <span className="badge mb-3">{post.category}</span>
                  <h2 className="font-display text-2xl text-ink mb-2">{post.title}</h2>
                  <p className="text-sm text-slateEdge/80 leading-7 mb-4">{post.summary}</p>
                  <p className="text-xs text-slateEdge/60">
                    {post.published} • {post.readingTime}
                  </p>
                </div>
                <Link to={post.slug} className="btn-primary whitespace-nowrap">
                  Read essay
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;