import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const About: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>About DevLayer — Mission, Methodology, Editorial Values</title>
        <meta
          name="description"
          content="Learn about DevLayer’s mission, editorial values, contributors, methodology, ethics, and history as a Canadian developer-focused platform."
        />
        <link rel="canonical" href="https://devlayer.com/about" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5">
          <span className="badge mb-6">About DevLayer</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            Mission-driven editorial work for developer workflows and software systems.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            DevLayer documents how engineering teams across Canada modernize software systems, refine developer workflows,
            and nurture devops culture. We combine technical writing with field research to translate architecture decisions into
            narratives that empower platform engineering teams.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-6xl mx-auto px-5 grid gap-8 lg:grid-cols-2">
          <div className="layer-card">
            <h2 className="font-display text-2xl text-ink mb-4">Editorial Values</h2>
            <ul className="list-disc list-inside space-y-3 text-sm text-slateEdge/80 leading-7">
              <li>
                <strong>Rigour.</strong> Every assertion about software systems, developer workflows, or cloud infrastructure is grounded in verifiable evidence and peer review.
              </li>
              <li>
                <strong>Empathy.</strong> We write with respect for the humans behind distributed computing, devops culture, and engineering psychology.
              </li>
              <li>
                <strong>Clarity.</strong> Technical writing should invite understanding without sacrificing nuance or precision.
              </li>
              <li>
                <strong>Ethics.</strong> Contributors follow consent-driven research protocols and respect confidentiality agreements.
              </li>
            </ul>
          </div>

          <div className="layer-card">
            <h2 className="font-display text-2xl text-ink mb-4">Methodology</h2>
            <p className="text-sm text-slateEdge/80 leading-7">
              Our methodology blends qualitative interviews, architecture analysis, telemetry review, and workflow observation.
              We spend time inside engineering rituals—stand-ups, pairing sessions, retrospectives—to capture how devops culture
              shapes real outcomes. We compare findings against industry benchmarks and academic research on platform engineering,
              distributed computing, and engineering psychology.
            </p>
          </div>

          <div className="layer-card">
            <h2 className="font-display text-2xl text-ink mb-4">Contributors</h2>
            <p className="text-sm text-slateEdge/80 leading-7 mb-4">
              DevLayer collaborates with editorial fellows, platform engineers, SRE leaders, product strategists, and research
              partners across Canada. Each story credits the subject matter experts who made it possible.
            </p>
            <ul className="text-sm text-slateEdge/75 space-y-2">
              <li>• Field Researchers specializing in developer workflows.</li>
              <li>• Technical Writers trained in software systems analysis.</li>
              <li>• Visual Designers crafting data-rich diagrams and schematics.</li>
              <li>• Review Board ensuring ethical compliance and narrative integrity.</li>
            </ul>
          </div>

          <div className="layer-card">
            <h2 className="font-display text-2xl text-ink mb-4">Ethics Charter</h2>
            <p className="text-sm text-slateEdge/80 leading-7">
              We obtain explicit consent before conducting interviews or referencing internal tooling. Sensitive details about
              cloud infrastructure or developer workflows are obfuscated unless partners allow publication. Our sources review
              contextual quotes to confirm accuracy.
            </p>
          </div>
        </div>
      </section>

      <section className="section bg-mist">
        <div className="max-w-6xl mx-auto px-5 grid gap-8 lg:grid-cols-[0.6fr_1.4fr] items-center">
          <img
            src="https://picsum.photos/800/600?random=150"
            alt="Historic computing references in the DevLayer archives"
            loading="lazy"
            className="rounded-3xl shadow-layered"
          />
          <div>
            <h2 className="font-display text-2xl text-ink mb-4">Platform History</h2>
            <p className="text-sm text-slateEdge/80 leading-7">
              DevLayer emerged in 2020 when a network of Canadian engineers wanted deeper coverage of platform engineering decisions.
              We started as a newsletter on developer workflows inside remote-first companies. The community grew into a full editorial
              platform, hosting archives of computing history alongside contemporary research. Today, our HQ is at 333 Bay St, Toronto,
              where writers, researchers, and designers collaborate.
            </p>
            <p className="text-sm text-slateEdge/80 leading-7 mt-4">
              Our archives include RFC dossiers, oral histories, and annotated diagrams from historic infrastructure projects.
              Every artifact informs our modern reporting on distributed computing and devops culture.
            </p>
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-6xl mx-auto px-5">
          <h2 className="font-display text-2xl text-ink mb-6">Impact Statements</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                title: "Workflow Literacy",
                text: "Teams use DevLayer stories to align around shared language for CI/CD pipelines, code review protocols, and pairing rituals."
              },
              {
                title: "System Visibility",
                text: "Our diagrams and structured data help leadership see how developer workflows intersect with cloud infrastructure decisions."
              },
              {
                title: "Culture Reflection",
                text: "By documenting engineering psychology, we help squads hold informed conversations about burnout, communication, and attention."
              }
            ].map((item) => (
              <motion.div
                key={item.title}
                className="layer-card"
                whileHover={{ y: -8 }}
              >
                <h3 className="font-display text-xl text-ink mb-3">{item.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;