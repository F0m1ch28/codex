import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

interface FormValues {
  name: string;
  email: string;
  organization: string;
  topic: string;
  message: string;
}

const initialForm: FormValues = {
  name: "",
  email: "",
  organization: "",
  topic: "",
  message: ""
};

const Contact: React.FC = () => {
  const [formValues, setFormValues] = useState<FormValues>(initialForm);
  const [errors, setErrors] = useState<Partial<FormValues>>({});
  const navigate = useNavigate();

  const validate = (): boolean => {
    const newErrors: Partial<FormValues> = {};
    if (!formValues.name.trim()) newErrors.name = "Name is required.";
    if (!formValues.email.includes("@")) newErrors.email = "Valid email is required.";
    if (!formValues.message.trim()) newErrors.message = "Message cannot be empty.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (field: keyof FormValues) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormValues({ ...formValues, [field]: event.target.value });
    setErrors({ ...errors, [field]: undefined });
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    navigate("/contact/thanks");
  };

  return (
    <>
      <Helmet>
        <title>Contact DevLayer — Share Your Engineering Story</title>
        <meta
          name="description"
          content="Connect with DevLayer. Schedule research collaborations, share developer workflow stories, or request editorial coverage."
        />
        <link rel="canonical" href="https://devlayer.com/contact" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <span className="badge mb-6">Contact</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            Let’s document your developer workflow story.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            Tell us about your software systems, cloud infrastructure journey, platform engineering roadmap, or devops culture experiment.
            We respond within two business days.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-6xl mx-auto px-5 grid gap-8 lg:grid-cols-[1fr_0.8fr]">
          <motion.form
            className="layer-card space-y-5"
            onSubmit={handleSubmit}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div>
              <label htmlFor="name" className="text-sm text-slateEdge/70 font-medium">
                Name *
              </label>
              <input id="name" value={formValues.name} onChange={handleChange("name")} />
              {errors.name && <p className="text-sm text-red-500 mt-1">{errors.name}</p>}
            </div>
            <div>
              <label htmlFor="email" className="text-sm text-slateEdge/70 font-medium">
                Work Email *
              </label>
              <input id="email" type="email" value={formValues.email} onChange={handleChange("email")} />
              {errors.email && <p className="text-sm text-red-500 mt-1">{errors.email}</p>}
            </div>
            <div>
              <label htmlFor="organization" className="text-sm text-slateEdge/70 font-medium">
                Organization
              </label>
              <input
                id="organization"
                value={formValues.organization}
                onChange={handleChange("organization")}
              />
            </div>
            <div>
              <label htmlFor="topic" className="text-sm text-slateEdge/70 font-medium">
                Primary Topic
              </label>
              <select id="topic" value={formValues.topic} onChange={handleChange("topic")}>
                <option value="">Select a topic</option>
                <option value="developer workflows">Developer workflows</option>
                <option value="software systems">Software systems</option>
                <option value="cloud infrastructure">Cloud infrastructure</option>
                <option value="platform engineering">Platform engineering</option>
                <option value="devops culture">Devops culture</option>
                <option value="engineering psychology">Engineering psychology</option>
              </select>
            </div>
            <div>
              <label htmlFor="message" className="text-sm text-slateEdge/70 font-medium">
                Message *
              </label>
              <textarea
                id="message"
                value={formValues.message}
                onChange={handleChange("message")}
                placeholder="Share context, timelines, and desired outcomes."
              />
              {errors.message && <p className="text-sm text-red-500 mt-1">{errors.message}</p>}
            </div>
            <button type="submit" className="btn-primary w-full md:w-auto">
              Submit
            </button>
          </motion.form>

          <div className="space-y-6">
            <div className="layer-card">
              <h2 className="font-display text-xl text-ink mb-4">Direct Details</h2>
              <p className="text-sm text-slateEdge/80 leading-7">
                Address: 333 Bay St, Toronto, ON M5H 2R2, Canada
                <br />
                Phone: <a href="tel:+14169056621" className="text-azurePulse">+1 (416) 905-6621</a>
                <br />
                Email: <a href="mailto:hello@devlayer.com" className="text-azurePulse">hello@devlayer.com</a>
                <br />
                GitHub: <a href="https://github.com/devlayer" className="text-azurePulse">github.com/devlayer</a>
                <br />
                LinkedIn: <a href="https://www.linkedin.com/company/devlayer" className="text-azurePulse">linkedin.com/company/devlayer</a>
              </p>
            </div>
            <div className="layer-card">
              <h2 className="font-display text-xl text-ink mb-4">Visit</h2>
              <iframe
                title="DevLayer Toronto Office Map"
                src="https://maps.google.com/maps?q=333%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202R2%2C%20Canada&t=&z=15&ie=UTF8&iwloc=&output=embed"
                className="w-full h-64 rounded-xl border-0"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;