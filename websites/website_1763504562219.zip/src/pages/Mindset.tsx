import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const mindsetTopics = [
  {
    title: "Attention Design",
    detail:
      "Create communication systems that honor deep work while maintaining alignment. Techniques include async summaries, intent-based meeting invites, and reflective huddles."
  },
  {
    title: "Burnout Monitoring",
    detail:
      "Observe subtle signals—muted participation, review fatigue, incident dread. Pair quantitative metrics with qualitative check-ins to intervene early."
  },
  {
    title: "Communication Ecology",
    detail:
      "Balance synchronous and asynchronous channels. Establish shared agreements about when to escalate versus when to document."
  },
  {
    title: "Focus Frameworks",
    detail:
      "Use focus blocks, pair programming rotations, and story mapping to distribute cognitive load across teams."
  }
];

const Mindset: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Developer Mindset — DevLayer</title>
        <meta
          name="description"
          content="DevLayer explores developer cognition, burnout, communication, and focus to elevate engineering psychology."
        />
        <link rel="canonical" href="https://devlayer.com/mindset" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <span className="badge mb-6">Mindset</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            Engineering psychology for sustainable teams.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            We study how cognition, emotion, and collaboration intersect with developer workflows. Our research guides teams through
            focused communication, burnout prevention, and shared purpose.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-6xl mx-auto px-5 grid gap-6 md:grid-cols-2">
          {mindsetTopics.map((topic) => (
            <motion.div key={topic.title} className="layer-card" whileHover={{ y: -8 }}>
              <h2 className="font-display text-2xl text-ink mb-3">{topic.title}</h2>
              <p className="text-sm text-slateEdge/80 leading-7">{topic.detail}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Mindset;