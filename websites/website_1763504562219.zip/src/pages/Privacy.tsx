import React from "react";
import { Helmet } from "react-helmet-async";

const Privacy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>DevLayer Privacy Statement</title>
        <meta
          name="description"
          content="DevLayer privacy statement covering cookies, analytics, data handling, third-party services, and user rights."
        />
        <link rel="canonical" href="https://devlayer.com/privacy" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-4xl mx-auto px-5">
          <h1 className="font-display text-ink text-4xl mb-6">Privacy Statement</h1>
          <p className="text-sm text-slateEdge/80 leading-7">
            This privacy statement describes how DevLayer collects, uses, and protects information from visitors of devlayer.com.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-4xl mx-auto px-5 space-y-8 text-sm text-slateEdge/80 leading-7">
          <div>
            <h2 className="font-display text-2xl text-ink mb-3">1. Cookies & Tracking</h2>
            <p>
              DevLayer uses essential cookies for session consistency and analytics cookies to understand aggregate reader behavior.
              Visitors can accept or decline analytics cookies via the cookie banner. Declining will not impact access to editorial content.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">2. Analytics</h2>
            <p>
              We rely on privacy-conscious analytics platforms to observe traffic patterns, page performance, and feature engagement.
              Data is anonymized and used to refine article structure, navigation, and developer workflow coverage. No personal
              profiles are created.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">3. Data Handling</h2>
            <p>
              Contact form submissions collect name, email, organization, topic, and message content. This information is stored securely,
              used for responding to inquiries, and retained only as long as necessary for ongoing conversations. Newsletter signups are
              managed via an email service provider compliant with Canadian privacy laws.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">4. Third-Party Services</h2>
            <p>
              DevLayer may integrate with email distribution services, collaboration platforms, or embedded media providers. Each third-party
              service maintains its own privacy and data handling practices. We select partners that align with rigorous standards and ensure
              contractual safeguards are in place.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">5. User Rights</h2>
            <p>
              Individuals may request access to or deletion of their personal data by emailing privacy@devlayer.com. We will verify the
              requestor's identity before releasing or deleting information. Canadian residents benefit from the protections of PIPEDA and
              other applicable legislation.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">6. Security</h2>
            <p>
              DevLayer uses industry-standard security practices, including encryption in transit and restricted access controls. While no
              system can be completely secure, we continuously review safeguards to protect submitted information.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">7. Contact</h2>
            <p>
              For questions about privacy, data handling, or cookie practices, contact hello@devlayer.com or call +1 (416) 905-6621.
            </p>
          </div>

          <div className="bg-mist rounded-2xl p-6">
            <p className="text-sm text-slateEdge/70">
              DevLayer content remains for educational use only. This privacy statement may be updated as our tooling evolves. The latest version
              will always be available on this page.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Privacy;