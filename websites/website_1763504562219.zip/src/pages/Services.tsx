import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const servicePackages = [
  {
    title: "Editorial Investigations",
    description:
      "Longform stories that unpack mission-critical software systems, blending telemetry, architecture diagrams, and human perspectives.",
    includes: [
      "In-depth interviews with platform engineering stakeholders",
      "Architecture analysis and distributed computing context",
      "Technical writing tailored for developer workflows"
    ]
  },
  {
    title: "Workflow Diagnostic Reports",
    description:
      "Applied research focused on developer workflows, release pipelines, and attention management inside engineering squads.",
    includes: [
      "Journey maps tracking developer workflows end-to-end",
      "Recommendations for devops culture and communication rituals",
      "Supporting visuals explaining cloud infrastructure dependencies"
    ]
  },
  {
    title: "Toolchain Spotlights",
    description:
      "Hands-on explorations of platform engineering toolchains with rigorous evaluation criteria and storytelling suited for adoption.",
    includes: [
      "Scenario-based experiments inside real environments",
      "Comparative analysis across developer experience metrics",
      "Clear articulation of engineering psychology observations"
    ]
  },
  {
    title: "Learning Series & Workshops",
    description:
      "Cohort-based learning experiences helping teams integrate systems thinking, engineering psychology, and mindful collaboration.",
    includes: [
      "Live sessions anchored in current DevLayer research",
      "Practical exercises aligned with platform engineering roles",
      "Resource kits and checklists for continued iteration"
    ]
  }
];

const Services: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>DevLayer Services — Editorial Research & Workflow Diagnostics</title>
        <meta
          name="description"
          content="Explore DevLayer services: editorial investigations, workflow diagnostics, toolchain spotlights, and learning series focused on developer workflows and software systems."
        />
        <link rel="canonical" href="https://devlayer.com/services" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <span className="badge mb-6">Services</span>
          <h1 className="font-display text-ink text-4xl leading-tight mb-6">
            Editorial research and storytelling for software systems and the people who build them.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            DevLayer partners with engineering leaders to capture developer workflows, cloud infrastructure choices, and devops culture shifts.
            Our services turn complex narratives into practical playbooks anchored in technical writing excellence.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-6xl mx-auto px-5 grid gap-8 md:grid-cols-2">
          {servicePackages.map((service) => (
            <motion.div
              key={service.title}
              className="layer-card"
              whileHover={{ y: -10 }}
            >
              <h2 className="font-display text-2xl text-ink mb-3">{service.title}</h2>
              <p className="text-sm text-slateEdge/80 leading-7 mb-4">{service.description}</p>
              <ul className="list-disc list-inside text-sm text-slateEdge/80 leading-7 space-y-2">
                {service.includes.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="section bg-mist">
        <div className="max-w-6xl mx-auto px-5 grid gap-8 lg:grid-cols-[0.8fr_1.2fr] items-center">
          <img
            src="https://picsum.photos/1200/800?random=250"
            alt="Collaborative editorial planning session"
            loading="lazy"
            className="rounded-3xl shadow-layered"
          />
          <div>
            <h2 className="font-display text-2xl text-ink mb-4">Working Together</h2>
            <p className="text-sm text-slateEdge/80 leading-7">
              We begin with a listening session covering current challenges in developer workflows, cloud infrastructure, or
              engineering culture. Together we define research questions, success signals, and ethical guardrails. Engagements
              typically run from four to twelve weeks depending on depth.
            </p>
            <div className="grid sm:grid-cols-2 gap-4 mt-6">
              {[
                { label: "Kickoff", detail: "Research alignment and scope definition" },
                { label: "Fieldwork", detail: "Interviews, observation, and telemetry review" },
                { label: "Narrative Draft", detail: "Layered storytelling, diagrams, and quotes" },
                { label: "Review & Release", detail: "Fact-check, approvals, and publication planning" }
              ].map((item) => (
                <div key={item.label} className="gradient-panel">
                  <h3 className="font-display text-lg text-ink">{item.label}</h3>
                  <p className="text-xs text-slateEdge/75 mt-2 leading-6">{item.detail}</p>
                </div>
              ))}
            </div>
            <a href="/contact" className="btn-primary mt-8 inline-flex">
              Schedule a discovery call
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;