import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "The Evolution of DevOps Culture",
  "description": "How devops culture matured into platform engineering and reshaped developer workflows across organizations.",
  "author": {
    "@type": "Person",
    "name": "DevLayer Editorial Team"
  },
  "publisher": {
    "@type": "Organization",
    "name": "DevLayer",
    "logo": {
      "@type": "ImageObject",
      "url": "https://picsum.photos/400/400?random=88"
    }
  },
  "datePublished": "2023-12-02",
  "image": "https://picsum.photos/1200/800?random=303",
  "articleSection": "Devops Culture"
};

const BlogDevOpsEvolution: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>The Evolution of DevOps Culture — DevLayer</title>
        <meta
          name="description"
          content="Explore the evolution of devops culture and how platform engineering, developer workflows, and engineering psychology interconnect."
        />
        <meta property="og:title" content="The Evolution of DevOps Culture — DevLayer" />
        <meta
          property="og:description"
          content="Explore the evolution of devops culture and how platform engineering, developer workflows, and engineering psychology interconnect."
        />
        <meta property="og:url" content="https://devlayer.com/blog/the-evolution-of-devops-culture" />
        <meta property="og:image" content="https://picsum.photos/1200/800?random=303" />
        <link rel="canonical" href="https://devlayer.com/blog/the-evolution-of-devops-culture" />
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>

      <article className="section bg-white">
        <div className="max-w-3xl mx-auto px-5">
          <span className="badge mb-6">Devops Culture</span>
          <h1 className="font-display text-ink text-4xl mb-4">
            The Evolution of DevOps Culture
          </h1>
          <p className="text-sm text-slateEdge/60 mb-6">
            December 2, 2023 • 11 min read
          </p>
          <img
            src="https://picsum.photos/1200/800?random=303"
            alt="Team collaborating around devops metrics"
            loading="lazy"
            className="rounded-3xl shadow-layered mb-8"
          />

          <motion.div
            className="space-y-6 text-sm text-slateEdge/85 leading-7"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <p>
              Devops began as a response to friction between development and operations. Over the last decade, it evolved into a new
              discipline: platform engineering. Processes matured, tooling grew sophisticated, and the cultural contract shifted from
              simple handoffs to shared ownership.
            </p>

            <h2 className="font-display text-ink text-2xl mb-3">Language Matters</h2>
            <p>
              Early devops stories focused on automation. Today, language highlights empathy, psychological safety, and developer workflows.
              We observed teams replacing phrases like “throw it over the wall” with “walk it together.” Shift the words and you shift the mindset.
            </p>

            <h3 className="font-display text-xl text-ink mb-2">Platform Engineering Emerges</h3>
            <p>
              Platform engineering extends devops beyond tooling. It structures reusable components, service catalogs, and paved paths.
              The aim: empower product teams while preserving guardrails. In Canada’s growing tech hubs, platform squads act as connective tissue.
            </p>

            <blockquote>
              Platform engineering is devops with a product mindset—built for scale, grounded in developer experience, and respectful of human bandwidth.
            </blockquote>

            <h2 className="font-display text-ink text-2xl mb-3">Psychology of Collaboration</h2>
            <p>
              Successful teams invest in engineering psychology practices. They host blameless retrospectives, experiment with communication cadences,
              and design rituals that reduce anxiety. These practices sustain energy through incidents and migrations.
            </p>

            <h2 className="font-display text-ink text-2xl mb-3">Telemetry as Storytelling</h2>
            <p>
              Observability platforms now narrate teamwork. Dashboards highlight developer workflows, not just system health. We saw squads creating
              “experience panels” showing wait times for reviews, branch lifetime, and deployment frequency. Metrics become meaningful when they tell
              stories about people.
            </p>

            <p>
              Devops culture will keep evolving. Platform engineering will refine service abstractions, cloud infrastructure patterns will mature,
              and developer workflows will adapt to new constraints. DevLayer remains committed to documenting every layer.
            </p>

            <p className="text-sm text-slateEdge/60 mt-8">
              For educational use only. Share your devops culture journey at{" "}
              <a href="mailto:hello@devlayer.com" className="text-azurePulse">hello@devlayer.com</a>.
            </p>
          </motion.div>

          <div className="mt-10">
            <Link to="/blog" className="btn-secondary">
              Back to essays
            </Link>
          </div>
        </div>
      </article>
    </>
  );
};

export default BlogDevOpsEvolution;