import React from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";

const ContactThanks: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Thank You — DevLayer Contact Confirmation</title>
        <meta
          name="description"
          content="Thanks for contacting DevLayer. Your message has been routed through our Sendler integration."
        />
        <link rel="canonical" href="https://devlayer.com/contact/thanks" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <span className="badge mb-6">Message Received</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            Thank you. Your message is on our way.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8 max-w-3xl mx-auto">
            We’ve routed your note through the Sendler PHP integration for secure handling.
            A member of the DevLayer editorial team will respond shortly with next steps.
          </p>
          <Link to="/" className="btn-primary mt-8 inline-flex">
            Return home
          </Link>
        </div>
      </section>
    </>
  );
};

export default ContactThanks;