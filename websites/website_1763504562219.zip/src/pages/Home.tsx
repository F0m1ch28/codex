import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { motion, animate } from "framer-motion";

interface StatItem {
  label: string;
  value: number;
  suffix?: string;
}

interface FeatureItem {
  title: string;
  description: string;
  link: string;
}

interface WorkflowItem {
  title: string;
  description: string;
  signal: string;
}

interface MindsetInsight {
  title: string;
  summary: string;
}

interface HistoryNote {
  title: string;
  era: string;
  description: string;
}

interface Highlight {
  title: string;
  detail: string;
}

interface ReadingItem {
  title: string;
  summary: string;
  tags: string[];
}

interface Service {
  name: string;
  detail: string;
  focus: string;
}

interface ProcessStep {
  step: number;
  title: string;
  description: string;
}

interface Testimonial {
  name: string;
  role: string;
  quote: string;
}

interface TeamMember {
  name: string;
  role: string;
  focus: string;
  image: string;
}

interface Project {
  name: string;
  category: "Workflow" | "Systems" | "Tooling" | "Culture";
  summary: string;
  insight: string;
}

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

interface BlogPreviewItem {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
}

const stats: StatItem[] = [
  { label: "Research Hours Logged", value: 480, suffix: "+" },
  { label: "Workflow Patterns Documented", value: 126 },
  { label: "Platforms Observed", value: 38 },
  { label: "Active Contributors", value: 18 }
];

const whatWeExplore: FeatureItem[] = [
  {
    title: "Software Systems",
    description:
      "Architecture decisions, distributed computing patterns, and the invisible agreements that keep complex codebases reliable.",
    link: "/blog"
  },
  {
    title: "Developer Workflows",
    description:
      "CI/CD rituals, build pipelines, IDE ergonomics, and the small habits that accelerate platform engineering teams.",
    link: "/workflows"
  },
  {
    title: "Engineering Psychology",
    description:
      "Shared cognition, devops culture, and the mindful practices that sustain healthy communication across squads.",
    link: "/mindset"
  }
];

const featuredEssays: FeatureItem[] = [
  {
    title: "Why Context Switching Drains Throughput",
    description:
      "Tracing the invisible friction of fragmented attention inside multi-service teams and how to rebuild focus.",
    link: "/blog/why-context-switching-kills-productivity"
  },
  {
    title: "Cloud Patterns for Scale",
    description:
      "A curated survey of pragmatic patterns that keep event-driven systems resilient during irregular load spikes.",
    link: "/blog/cloud-patterns-for-scale"
  },
  {
    title: "The Evolution of DevOps Culture",
    description:
      "From ops tickets to shared ownership: language, rituals, and dashboards that reshape collaboration.",
    link: "/blog/the-evolution-of-devops-culture"
  }
];

const workflowPatterns: WorkflowItem[] = [
  {
    title: "Branch Health Beacons",
    description:
      "Lightweight telemetry that turns every pull request into a story about risk, velocity, and pairing opportunities.",
    signal: "Workflow"
  },
  {
    title: "Reusable Pipeline Choreography",
    description:
      "Blueprints for reducing toil while maintaining auditable traceability through multi-stage CI/CD stacks.",
    signal: "Systems"
  },
  {
    title: "Environment Drift Watch",
    description:
      "Dashboards that monitor parity across environments so platform engineering teams can shift from reaction to prevention.",
    signal: "Tooling"
  },
  {
    title: "Incident Afterglow Sessions",
    description:
      "Rituals that connect infrastructure incidents with human narratives, strengthening engineering psychology.",
    signal: "Culture"
  }
];

const toolingSignals: WorkflowItem[] = [
  {
    title: "Observability Dialtones",
    description:
      "How distributed tracing reveals ownership gaps and informs workflow agreements across service boundaries.",
    signal: "Systems"
  },
  {
    title: "IDE Telemetry Sketches",
    description:
      "Patterns for capturing editor signals to balance deep work against necessary swarm reviews.",
    signal: "Tooling"
  },
  {
    title: "Provisioning Playground",
    description:
      "Self-serve sandboxes that allow experimentation without jeopardizing regulated infrastructure.",
    signal: "Workflow"
  }
];

const mindsetInsights: MindsetInsight[] = [
  {
    title: "Cognitive Load Valves",
    summary:
      "Assessing how knowledge repositories relieve mental strain and allow teams to focus on creative engineering."
  },
  {
    title: "Signal-Rich Communication",
    summary:
      "Designing asynchronous updates that respect attention budgets and still keep distributed squads aligned."
  },
  {
    title: "Burnout Early Warnings",
    summary:
      "Recognizing micro-behaviours inside retrospectives that hint at exhaustion before it spreads."
  }
];

const codeHistory: HistoryNote[] = [
  {
    title: "RFC 1122 Revisited",
    era: "1989",
    description:
      "Lessons from the requirements for internet hosts and how they still influence microservice responsibility boundaries."
  },
  {
    title: "Xerox PARC Habits",
    era: "1973",
    description:
      "What the Alto project reveals about small team autonomy and instrumented feedback loops."
  },
  {
    title: "Unix Philosophy Echoes",
    era: "1978",
    description:
      "Filtering the enduring principles that help platform engineers decide when to compose or consolidate services."
  }
];

const editorialHighlights: Highlight[] = [
  {
    title: "Field Research",
    detail:
      "Monthly shadowing sessions inside Canadian engineering teams exploring developer workflows and platform engineering transitions."
  },
  {
    title: "Technical Writing Standards",
    detail:
      "Style guides emphasizing empathetic language, reproducible references, and precise attribution for every architecture claim."
  },
  {
    title: "Distribution Experiments",
    detail:
      "Multi-format releases across email, community forums, and partner labs to understand knowledge diffusion."
  }
];

const readingQueue: ReadingItem[] = [
  {
    title: "Temporal Coupling in Microservices",
    summary: "A study of event storming sessions that restructure release cadences.",
    tags: ["distributed computing", "developer workflows"]
  },
  {
    title: "Cognitive Apprenticeship for Platform Engineers",
    summary: "Exploring mentorship models that elevate infrastructure intuition.",
    tags: ["platform engineering", "engineering psychology"]
  },
  {
    title: "Resilience Theater vs. Reality",
    summary: "How to bridge tabletop exercises with actual incident telemetry.",
    tags: ["devops culture", "cloud infrastructure"]
  }
];

const services: Service[] = [
  {
    name: "Longform Editorial Analysis",
    detail:
      "Investigative features that unpack complex software systems with data visualizations, architecture diagrams, and contextual interviews.",
    focus: "Software systems"
  },
  {
    name: "Workflow Diagnostics",
    detail:
      "Field notes and journey mapping that surface bottlenecks in code review, deployment pipelines, and pairing rituals.",
    focus: "Developer workflows"
  },
  {
    name: "Toolchain Spotlights",
    detail:
      "Deep dives into emerging platform engineering tools with applied experiments and human-centred evaluation.",
    focus: "Tooling signals"
  },
  {
    name: "Mindset Studio",
    detail:
      "Guided sessions exploring attention management, engineering psychology, and burnout prevention across distributed teams.",
    focus: "Developer mindset"
  }
];

const processSteps: ProcessStep[] = [
  {
    step: 1,
    title: "Discover",
    description:
      "We meet with engineering leaders, survey developer workflows, and review telemetry to frame the research question."
  },
  {
    step: 2,
    title: "Pair",
    description:
      "Writers partner with platform engineers to validate architecture narratives and surface nuanced tradeoffs."
  },
  {
    step: 3,
    title: "Compose",
    description:
      "We assemble narrative layers, evidence, and visuals that make complex systems understandable without diluting accuracy."
  },
  {
    step: 4,
    title: "Validate",
    description:
      "Multi-stage reviews align tone, ethics, and fact checking before publication, ensuring every layer holds."
  }
];

const testimonials: Testimonial[] = [
  {
    name: "Aurora Chen",
    role: "Director of Platform Operations, Vancouver",
    quote:
      "DevLayer translated our infrastructure overhauls into stories that the entire organization could use. The coverage made intangible workflow friction visible."
  },
  {
    name: "Marc Tremblay",
    role: "Principal Engineer, Montréal",
    quote:
      "The editorial team listened to our distributed squads and captured how attention shifts affected release cadence. Their insights informed our new pairing rituals."
  },
  {
    name: "Imani Clarke",
    role: "Engineering Manager, Halifax",
    quote:
      "Their technical writing set the tone for collaborative retrospectives. Teams finally had language for the cultural patterns behind recurring incidents."
  }
];

const teamMembers: TeamMember[] = [
  {
    name: "Rina Patel",
    role: "Editor-in-Chief",
    focus: "Software systems anthropology and technical writing",
    image: "https://picsum.photos/400/400?random=21"
  },
  {
    name: "Jules Okoro",
    role: "Research Lead",
    focus: "Developer workflows, platform engineering diagnostics, and devops culture",
    image: "https://picsum.photos/400/400?random=22"
  },
  {
    name: "Maeve Li",
    role: "Design & Data Visualization",
    focus: "Information architecture, distributed computing diagrams, and reader journey mapping",
    image: "https://picsum.photos/400/400?random=23"
  }
];

const projects: Project[] = [
  {
    name: "Release Cadence Atlas",
    category: "Workflow",
    summary:
      "An interactive study of CI/CD rituals across Canadian scale-ups, highlighting cadence agreements that unlock flow.",
    insight: "Developer workflows"
  },
  {
    name: "Signals from the Cloud Edge",
    category: "Systems",
    summary:
      "Case studies on adaptive scaling models inside event-driven systems handling unpredictable data streams.",
    insight: "Cloud infrastructure"
  },
  {
    name: "Toolchain Field Notes",
    category: "Tooling",
    summary:
      "Hands-on evaluations of platform engineering toolchains emphasizing collaboration within devops culture.",
    insight: "Platform engineering"
  },
  {
    name: "Mindful Stand-Up Playbook",
    category: "Culture",
    summary:
      "Communication frameworks designed to reduce cognitive overload and sustain engineering psychology.",
    insight: "Engineering psychology"
  }
];

const faqItems: FAQItem[] = [
  {
    id: "faq-1",
    question: "How does DevLayer choose which software systems to explore?",
    answer:
      "We select systems that reveal meaningful workflow lessons, emphasize distributed computing challenges, or showcase new approaches to platform engineering. Our research combines interviews, architecture reviews, and telemetry."
  },
  {
    id: "faq-2",
    question: "Can teams collaborate with DevLayer on field studies?",
    answer:
      "Yes. We collaborate with teams across Canada to document developer workflows, cloud infrastructure transformations, and devops culture shifts. Reach out through the contact form to discuss ethical guidelines and scheduling."
  },
  {
    id: "faq-3",
    question: "What standards guide DevLayer’s technical writing?",
    answer:
      "We follow a multi-step review process emphasizing clarity, reproducibility, and responsible sourcing. Every claim referencing software systems, developer workflows, or engineering psychology is validated with primary evidence."
  }
];

const blogPreview: BlogPreviewItem[] = [
  {
    slug: "/blog/why-context-switching-kills-productivity",
    title: "Why Context Switching Drains Throughput",
    excerpt: "Mapping cognitive drag and building focus-preserving rituals inside distributed teams.",
    category: "Mindset"
  },
  {
    slug: "/blog/cloud-patterns-for-scale",
    title: "Cloud Patterns for Scale",
    excerpt: "From service meshes to event sourcing: architectural patterns for resilient cloud infrastructure.",
    category: "Systems"
  },
  {
    slug: "/blog/the-evolution-of-devops-culture",
    title: "The Evolution of DevOps Culture",
    excerpt: "Tracing the language shifts that transformed operations into collaborative platform engineering.",
    category: "Culture"
  }
];

const Home: React.FC = () => {
  const [newsletterEmail, setNewsletterEmail] = useState<string>("");
  const [newsletterStatus, setNewsletterStatus] = useState<"idle" | "success" | "error">("idle");
  const [testimonialIndex, setTestimonialIndex] = useState<number>(0);
  const [projectFilter, setProjectFilter] = useState<Project["category"] | "All">("All");
  const [openFAQ, setOpenFAQ] = useState<string | null>(faqItems[0]?.id ?? null);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 8000);
    return () => window.clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (projectFilter === "All") {
      return projects;
    }
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  const handleNewsletterSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes("@")) {
      setNewsletterStatus("error");
      return;
    }

    setNewsletterStatus("success");
    setNewsletterEmail("");
  };

  const toggleFAQ = (id: string) => {
    setOpenFAQ((prev) => (prev === id ? null : id));
  };

  return (
    <>
      <Helmet>
        <title>DevLayer — Every Layer Tells a Story</title>
        <meta
          name="description"
          content="DevLayer is a Canadian editorial platform examining developer workflows, software systems, cloud infrastructure, platform engineering, and engineering psychology."
        />
        <meta property="og:title" content="DevLayer — Every Layer Tells a Story" />
        <meta
          property="og:description"
          content="Exploring developer workflows, software systems, cloud infrastructure, platform engineering, and devops culture across Canada."
        />
        <meta property="og:url" content="https://devlayer.com/" />
        <link rel="canonical" href="https://devlayer.com/" />
      </Helmet>

      <section className="section bg-mist pt-24">
        <div className="max-w-7xl mx-auto px-5 grid lg:grid-cols-[1.1fr_0.9fr] gap-12 items-center">
          <div>
            <div className="badge mb-6">Every Layer Tells a Story</div>
            <h1 className="font-display text-ink text-4xl sm:text-5xl leading-tight mb-6">
              Developer workflows, cloud infrastructure, and engineering culture told with depth.
            </h1>
            <p className="text-lg text-slateEdge/80 leading-8 max-w-2xl">
              DevLayer documents how software systems evolve, how platform engineering teams make decisions,
              and how engineering psychology shapes devops culture. We translate complex change into narratives
              that help teams see themselves clearly.
            </p>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-10">
              <Link to="/blog" className="btn-primary">
                Explore essays
              </Link>
              <Link to="/contact" className="btn-secondary">
                Share your workflow story
              </Link>
            </div>
          </div>
          <motion.div
            className="gradient-panel shadow-layered"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <img
              src="https://picsum.photos/1600/900?random=101"
              alt="Developers collaborating around systems diagrams"
              loading="lazy"
              className="rounded-2xl shadow-lg"
            />
            <p className="text-sm text-slateEdge/70 mt-4 leading-relaxed">
              “We listen inside code reviews, stand-ups, and retrospectives—translating signals from distributed computing,
              platform engineering, and developer workflows into editorial layers that inform action.”
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Signals from the Field</h2>
          <p className="section-subtitle">
            A snapshot of our ongoing research into developer workflows, cloud infrastructure, and engineering psychology.
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-10">
            {stats.map((item) => (
              <motion.div
                key={item.label}
                className="layer-card text-center"
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 250, damping: 20 }}
              >
                <AnimatedNumber value={item.value} suffix={item.suffix} />
                <p className="text-sm text-slateEdge/70 mt-3">{item.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-mist" id="explore">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">What We Explore</h2>
          <p className="section-subtitle">
            Layered coverage that connects software systems, developer workflows, and the human dynamics of engineering.
          </p>
          <div className="grid gap-6 md:grid-cols-3 mt-10">
            {whatWeExplore.map((item) => (
              <motion.div
                key={item.title}
                className="layer-card flex flex-col"
                whileHover={{ y: -8 }}
              >
                <h3 className="font-display text-2xl text-ink mb-4">{item.title}</h3>
                <p className="text-sm leading-7 text-slateEdge/80 flex-1">{item.description}</p>
                <Link to={item.link} className="btn-secondary mt-6 inline-flex w-max">
                  Continue reading
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white" id="featured-essays">
        <div className="max-w-7xl mx-auto px-5">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
            <div>
              <h2 className="section-title">Featured Essays</h2>
              <p className="section-subtitle">
                Longform technical writing capturing the nuance behind distributed computing, platform engineering,
                developer workflows, and devops culture.
              </p>
            </div>
            <Link to="/blog" className="btn-secondary">
              View archive
            </Link>
          </div>
          <div className="grid gap-6 md:grid-cols-3 mt-12">
            {featuredEssays.map((essay, index) => (
              <motion.article
                key={essay.title}
                className="layer-card"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.12 }}
              >
                <img
                  src={`https://picsum.photos/800/600?random=${index + 110}`}
                  alt={`${essay.title} illustration`}
                  loading="lazy"
                  className="rounded-xl mb-5"
                />
                <h3 className="font-display text-xl text-ink mb-3">{essay.title}</h3>
                <p className="text-sm leading-7 text-slateEdge/80 mb-6">{essay.description}</p>
                <Link to={essay.link} className="btn-primary">
                  Read essay
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-mist" id="workflow-patterns">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Workflow Patterns</h2>
          <p className="section-subtitle">
            Field-tested practices uniting software systems with the humans who operate them.
          </p>
          <div className="grid gap-6 md:grid-cols-2 mt-10">
            {workflowPatterns.map((pattern) => (
              <motion.div
                key={pattern.title}
                className="layer-card"
                whileHover={{ scale: 1.01 }}
              >
                <span className="badge mb-4">{pattern.signal}</span>
                <h3 className="font-display text-xl text-ink mb-3">{pattern.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{pattern.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white" id="tooling-signals">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Tooling Signals</h2>
          <p className="section-subtitle">
            Observations from platform engineering stacks where developer experience meets instrumentation.
          </p>
          <div className="grid gap-6 md:grid-cols-3 mt-10">
            {toolingSignals.map((signal) => (
              <motion.div
                key={signal.title}
                className="layer-card"
                whileHover={{ y: -6 }}
              >
                <span className="badge mb-4">{signal.signal}</span>
                <h3 className="font-display text-xl text-ink mb-3">{signal.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{signal.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-mist" id="developer-mindset">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Developer Mindset</h2>
          <p className="section-subtitle">
            Essays on engineering psychology, attention, and communication that keep teams resilient.
          </p>
          <div className="grid gap-6 md:grid-cols-3 mt-10">
            {mindsetInsights.map((insight) => (
              <motion.div
                key={insight.title}
                className="layer-card"
                whileHover={{ scale: 1.02 }}
              >
                <h3 className="font-display text-xl text-ink mb-3">{insight.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{insight.summary}</p>
              </motion.div>
            ))}
          </div>
          <Link to="/mindset" className="btn-secondary mt-8 inline-flex">
            Visit the Mindset library
          </Link>
        </div>
      </section>

      <section className="section bg-white" id="code-history">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Code History, Reframed</h2>
          <p className="section-subtitle">
            Conversations with the past to inform tomorrow’s distributed computing and platform engineering decisions.
          </p>
          <div className="grid gap-6 md:grid-cols-3 mt-10">
            {codeHistory.map((item) => (
              <motion.div
                key={item.title}
                className="layer-card"
                whileHover={{ y: -6 }}
              >
                <span className="badge mb-3">{item.era}</span>
                <h3 className="font-display text-xl text-ink mb-3">{item.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-mist" id="editorial-highlights">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Editorial Highlights</h2>
          <p className="section-subtitle">
            Standards that keep our technical writing rigorous, ethical, and human-centred.
          </p>
          <div className="grid gap-6 md:grid-cols-3 mt-10">
            {editorialHighlights.map((highlight) => (
              <div key={highlight.title} className="layer-card">
                <h3 className="font-display text-xl text-ink mb-3">{highlight.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{highlight.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white" id="services">
        <div className="max-w-7xl mx-auto px-5">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
            <div>
              <h2 className="section-title">What We Offer</h2>
              <p className="section-subtitle">
                DevLayer collaborates with engineering teams to turn complex software systems and developer workflows
                into clear narratives backed by data.
              </p>
            </div>
            <Link to="/services" className="btn-primary">
              See all services
            </Link>
          </div>
          <div className="grid gap-6 md:grid-cols-2 mt-12">
            {services.map((service) => (
              <motion.div
                key={service.name}
                className="layer-card h-full border-l-4 border-azurePulse/40"
                whileHover={{ y: -10 }}
                transition={{ type: "spring", stiffness: 200, damping: 18 }}
              >
                <span className="badge mb-4">{service.focus}</span>
                <h3 className="font-display text-2xl text-ink mb-3">{service.name}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{service.detail}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-mist" id="process">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Process Blueprint</h2>
          <p className="section-subtitle">
            Our step-by-step method for capturing the layered reality of devops culture, cloud infrastructure, and developer workflows.
          </p>
          <div className="grid gap-6 md:grid-cols-4 mt-12">
            {processSteps.map((step) => (
              <motion.div
                key={step.step}
                className="layer-card relative"
                whileHover={{ scale: 1.02 }}
              >
                <span className="absolute -top-4 left-6 bg-ink text-white rounded-full w-10 h-10 flex items-center justify-center font-semibold">
                  {step.step}
                </span>
                <h3 className="font-display text-xl text-ink mb-3 pt-6">{step.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white" id="testimonials">
        <div className="max-w-5xl mx-auto px-5">
          <h2 className="section-title">Reader Reflections</h2>
          <p className="section-subtitle">
            Voices from engineering leaders who have applied DevLayer’s technical writing inside their organizations.
          </p>
          <div className="layer-card mt-12 relative overflow-hidden">
            <AnimateTestimonial testimonial={testimonials[testimonialIndex]} />
            <div className="flex items-center justify-end space-x-2 mt-6">
              {testimonials.map((_, idx) => (
                <button
                  key={`testimonial-indicator-${idx}`}
                  type="button"
                  aria-label={`Show testimonial ${idx + 1}`}
                  onClick={() => setTestimonialIndex(idx)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    idx === testimonialIndex ? "bg-azurePulse" : "bg-slateEdge/20"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-mist" id="team">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Editorial Team</h2>
          <p className="section-subtitle">
            A collective of technical writers, researchers, and designers translating complex developer workflows into enduring stories.
          </p>
          <div className="grid gap-6 md:grid-cols-3 mt-12">
            {teamMembers.map((member) => (
              <motion.div
                key={member.name}
                className="layer-card text-center"
                whileHover={{ y: -8 }}
              >
                <img
                  src={member.image}
                  alt={`${member.name} portrait`}
                  loading="lazy"
                  className="w-32 h-32 object-cover rounded-full mx-auto shadow-lg mb-5"
                />
                <h3 className="font-display text-xl text-ink">{member.name}</h3>
                <p className="text-sm text-azurePulse mt-1">{member.role}</p>
                <p className="text-sm text-slateEdge/75 mt-3 leading-7">{member.focus}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white" id="projects">
        <div className="max-w-7xl mx-auto px-5">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
            <div>
              <h2 className="section-title">Projects in Focus</h2>
              <p className="section-subtitle">
                Research initiatives tracking developer workflows, software systems, and engineering culture in motion.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {["All", "Workflow", "Systems", "Tooling", "Culture"].map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setProjectFilter(category as Project["category"] | "All")}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    projectFilter === category
                      ? "bg-azurePulse text-white"
                      : "bg-white border border-slateEdge/20 text-slateEdge hover:border-azurePulse"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-2 mt-10">
            {filteredProjects.map((project) => (
              <motion.div
                key={project.name}
                className="layer-card"
                whileHover={{ y: -8 }}
              >
                <span className="badge mb-4">{project.category}</span>
                <h3 className="font-display text-xl text-ink mb-3">{project.name}</h3>
                <p className="text-sm text-slateEdge/80 leading-7 mb-4">{project.summary}</p>
                <p className="text-sm text-azurePulse font-medium">{project.insight}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-mist" id="faq">
        <div className="max-w-5xl mx-auto px-5">
          <h2 className="section-title">Questions & Responses</h2>
          <p className="section-subtitle">
            More about our methodology, ethical guardrails, and collaboration practices.
          </p>
          <div className="space-y-4 mt-10">
            {faqItems.map((item) => (
              <div key={item.id} className="faq-item">
                <button
                  type="button"
                  className="flex items-center justify-between w-full text-left"
                  onClick={() => toggleFAQ(item.id)}
                >
                  <span className="font-display text-lg text-ink">{item.question}</span>
                  <span className="text-azurePulse text-2xl font-bold" aria-hidden>
                    {openFAQ === item.id ? "−" : "+"}
                  </span>
                </button>
                {openFAQ === item.id && (
                  <p className="text-sm text-slateEdge/80 leading-7 mt-4">{item.answer}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white" id="reading-queue">
        <div className="max-w-7xl mx-auto px-5">
          <h2 className="section-title">Reading Queue</h2>
          <p className="section-subtitle">
            Works in progress, upcoming interviews, and archival digs currently on our desk.
          </p>
          <div className="grid gap-6 md:grid-cols-3 mt-10">
            {readingQueue.map((item) => (
              <div key={item.title} className="layer-card">
                <h3 className="font-display text-xl text-ink mb-3">{item.title}</h3>
                <p className="text-sm text-slateEdge/80 leading-7 mb-4">{item.summary}</p>
                <div className="flex flex-wrap gap-2">
                  {item.tags.map((tag) => (
                    <span key={tag} className="badge bg-azurePulse/10 text-azurePulse">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <Link to="/queue" className="btn-secondary mt-8 inline-flex">
            View the full queue
          </Link>
        </div>
      </section>

      <section className="section bg-mist" id="blog-preview">
        <div className="max-w-5xl mx-auto px-5">
          <h2 className="section-title">Latest from the Journal</h2>
          <p className="section-subtitle">
            Fresh analysis connecting developer workflows, cloud infrastructure, and devops culture.
          </p>
          <div className="space-y-6 mt-10">
            {blogPreview.map((post) => (
              <motion.article
                key={post.slug}
                className="layer-card"
                whileHover={{ y: -6 }}
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <span className="badge mb-3">{post.category}</span>
                    <h3 className="font-display text-2xl text-ink mb-2">{post.title}</h3>
                    <p className="text-sm text-slateEdge/80 leading-7">{post.excerpt}</p>
                  </div>
                  <Link to={post.slug} className="btn-primary whitespace-nowrap">
                    Read now
                  </Link>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white" id="newsletter">
        <div className="max-w-5xl mx-auto px-5">
          <div className="gradient-panel shadow-layered">
            <div className="grid md:grid-cols-[0.8fr_1.2fr] gap-8 items-center">
              <div>
                <h2 className="section-title">Newsletter Dispatch</h2>
                <p className="text-sm text-slateEdge/80 leading-7 mt-4">
                  Join the bi-weekly DevLayer briefing for essays on software systems, developer workflows,
                  platform engineering experiments, and engineering psychology field notes.
                </p>
              </div>
              <form onSubmit={handleNewsletterSubmit} className="space-y-4">
                <label htmlFor="newsletter-email" className="text-sm text-slateEdge/70 font-medium">
                  Work email
                </label>
                <input
                  id="newsletter-email"
                  type="email"
                  value={newsletterEmail}
                  onChange={(event) => setNewsletterEmail(event.target.value)}
                  placeholder="you@company.com"
                  required
                />
                <button type="submit" className="btn-primary w-full md:w-auto">
                  Subscribe
                </button>
                {newsletterStatus === "success" && (
                  <p className="text-sm text-azurePulse">
                    Thank you! Check your inbox for a confirmation message.
                  </p>
                )}
                {newsletterStatus === "error" && (
                  <p className="text-sm text-red-500">
                    Please provide a valid email address.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>

      <section className="section-sm bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <h2 className="font-display text-3xl text-ink mb-4">Share Your Layer</h2>
          <p className="text-sm text-slateEdge/80 leading-7 max-w-3xl mx-auto mb-6">
            We’re building a living atlas of developer workflows, cloud infrastructure lessons, and engineering culture stories.
            Invite us into your environment and we’ll capture the rhythms behind the systems.
          </p>
          <Link to="/contact" className="btn-primary">
            Start a conversation
          </Link>
        </div>
      </section>

      <section className="section-sm bg-white">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-slateEdge/60">Disclaimer</p>
          <p className="text-sm text-slateEdge/70 mt-2">
            DevLayer content is for educational use only.
          </p>
        </div>
      </section>
    </>
  );
};

interface AnimatedNumberProps {
  value: number;
  suffix?: string;
}

const AnimatedNumber: React.FC<AnimatedNumberProps> = ({ value, suffix }) => {
  const [displayNumber, setDisplayNumber] = useState<number>(0);

  useEffect(() => {
    const controls = animate(0, value, {
      duration: 1.6,
      ease: "easeOut",
      onUpdate: (latest) => setDisplayNumber(Math.round(latest))
    });
    return () => controls.stop();
  }, [value]);

  return (
    <div className="font-display text-ink text-4xl">
      {displayNumber}
      {suffix}
    </div>
  );
};

interface AnimateTestimonialProps {
  testimonial: Testimonial;
}

const AnimateTestimonial: React.FC<AnimateTestimonialProps> = ({ testimonial }) => (
  <motion.div
    key={testimonial.name}
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.5 }}
  >
    <p className="text-lg text-ink leading-8 italic">“{testimonial.quote}”</p>
    <p className="text-sm text-slateEdge/70 mt-4">
      {testimonial.name} • {testimonial.role}
    </p>
  </motion.div>
);

export default Home;