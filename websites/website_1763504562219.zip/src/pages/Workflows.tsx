import React from "react";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";

const workflowThemes = [
  {
    title: "CI/CD Rhythms",
    content:
      "We study how teams orchestrate pipelines, manage branching strategies, and adopt feature flags. Small tweaks in choreography can transform developer workflows."
  },
  {
    title: "Build Pipelines",
    content:
      "Our reports examine build caching, artifact traceability, and security gating. Every recommendation respects platform engineering constraints."
  },
  {
    title: "IDE Ergonomics",
    content:
      "From custom snippets to telemetry feedback loops, we cover the tools that make daily work smoother and reveal new insights about developer experience."
  },
  {
    title: "Team Rituals",
    content:
      "Stand-ups, async updates, design reviews—rituals shape devops culture. We capture practices that respect attention and nurture engineering psychology."
  }
];

const Workflows: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Workflow Library — DevLayer</title>
        <meta
          name="description"
          content="Explore DevLayer’s workflow library covering CI/CD rhythms, build pipelines, IDE ergonomics, and team rituals."
        />
        <link rel="canonical" href="https://devlayer.com/workflows" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <span className="badge mb-6">Workflow Library</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            Patterns that keep developer workflows focused and resilient.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            Discover rituals, diagnostics, and frameworks that accelerate developer workflows while respecting engineering psychology
            and platform engineering realities.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-6xl mx-auto px-5 grid gap-6 md:grid-cols-2">
          {workflowThemes.map((theme) => (
            <motion.div key={theme.title} className="layer-card" whileHover={{ y: -8 }}>
              <h2 className="font-display text-2xl text-ink mb-3">{theme.title}</h2>
              <p className="text-sm text-slateEdge/80 leading-7">{theme.content}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Workflows;