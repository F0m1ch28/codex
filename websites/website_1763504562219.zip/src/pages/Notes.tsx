import React from "react";
import { Helmet } from "react-helmet-async";

const notes = [
  {
    date: "January 2024",
    title: "Fieldwork in Ottawa",
    detail:
      "We spent a week embedded with a civic tech team exploring developer workflows during a major platform modernization initiative."
  },
  {
    date: "February 2024",
    title: "Research Partnerships",
    detail:
      "New collaboration with University of Waterloo researchers studying engineering psychology inside distributed computing teams."
  },
  {
    date: "March 2024",
    title: "Tooling Signals Update",
    detail:
      "Launching a continuous feedback loop gathering insights on platform engineering tools from Canadian startups."
  }
];

const Notes: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Editorial Notes — DevLayer</title>
        <meta
          name="description"
          content="Short-form editorial notes from DevLayer covering platform updates, research partnerships, and internal commentary."
        />
        <link rel="canonical" href="https://devlayer.com/notes" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-4xl mx-auto px-5 text-center">
          <span className="badge mb-6">Notes</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            Internal commentary & platform updates.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            Periodic snapshots from the DevLayer editorial desk—highlighting research progress, partnerships, and adjustments to our workflow.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-4xl mx-auto px-5 space-y-6">
          {notes.map((note) => (
            <div key={note.title} className="layer-card">
              <span className="badge mb-3">{note.date}</span>
              <h2 className="font-display text-2xl text-ink mb-2">{note.title}</h2>
              <p className="text-sm text-slateEdge/80 leading-7">{note.detail}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Notes;