import React from "react";
import { Helmet } from "react-helmet-async";

const Terms: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>DevLayer Terms of Use</title>
        <meta
          name="description"
          content="Read the DevLayer terms of use covering acceptable usage, intellectual property, disclaimers, jurisdiction, and external references."
        />
        <link rel="canonical" href="https://devlayer.com/terms" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-4xl mx-auto px-5">
          <h1 className="font-display text-ink text-4xl mb-6">Terms of Use</h1>
          <p className="text-sm text-slateEdge/80 leading-7">
            Last updated on {new Date().toLocaleDateString()} by DevLayer, 333 Bay St, Toronto, ON M5H 2R2, Canada.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-4xl mx-auto px-5 space-y-8 text-sm text-slateEdge/80 leading-7">
          <div>
            <h2 className="font-display text-2xl text-ink mb-3">1. Acceptance of Terms</h2>
            <p>
              By accessing devlayer.com you agree to these Terms of Use. If you do not agree, please discontinue use of the
              platform. DevLayer may update these terms at any time. Continued use signifies acceptance of any revisions.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">2. Purpose</h2>
            <p>
              DevLayer provides editorial content for educational use only. Articles and resources do not constitute consulting
              advice. Engineering teams should evaluate whether any described approach suits their own systems, developer workflows,
              cloud infrastructure, platform engineering practices, or devops culture.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">3. Intellectual Property</h2>
            <p>
              All content on devlayer.com—including text, imagery, diagrams, logos, data visualizations, and structured data—is
              the property of DevLayer unless otherwise noted. Users may share links or brief excerpts with attribution.
              Reproduction or derivative works require written permission from DevLayer.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">4. Acceptable Use</h2>
            <p>
              Users agree not to interfere with site functionality, scrape content at scale, or misrepresent affiliation. Any
              use that could impair access for others is prohibited. Automated queries should respect standard rate limiting.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">5. External References</h2>
            <p>
              DevLayer articles may link to external resources for additional context. We are not responsible for the content of
              those third-party sites. Inclusion of a link does not imply endorsement. External resources may have their own terms
              and privacy policies.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">6. Disclaimers & Limitation of Liability</h2>
            <p>
              Content is provided “as is.” DevLayer makes no promises regarding accuracy, completeness, or suitability for any
              specific engineering scenario. To the maximum extent permitted by Canadian law, DevLayer is not liable for any
              damages resulting from your use of the site or reliance on its content.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">7. Jurisdiction</h2>
            <p>
              These Terms of Use are governed by the laws of the Province of Ontario and the laws of Canada applicable therein.
              Any disputes will be resolved in the courts located in Toronto, Ontario.
            </p>
          </div>

          <div>
            <h2 className="font-display text-2xl text-ink mb-3">8. Contact</h2>
            <p>
              Questions about these Terms of Use should be addressed to hello@devlayer.com or by phone at +1 (416) 905-6621.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Terms;