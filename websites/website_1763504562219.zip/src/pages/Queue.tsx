import React from "react";
import { Helmet } from "react-helmet-async";

const queueItems = [
  {
    title: "Incident Dispatch Playbooks",
    summary:
      "Comparing structures used by Canadian fintech teams to orchestrate incident response while protecting focus.",
    tags: ["devops culture", "cloud infrastructure"]
  },
  {
    title: "Developer Workflows in Regulated Environments",
    summary:
      "Studying how healthcare teams balance compliance with experimentation and platform engineering innovation.",
    tags: ["developer workflows", "engineering psychology"]
  },
  {
    title: "Service Catalogs That Stick",
    summary:
      "Documenting why some platform engineering catalogs become trusted companions and others fade into neglect.",
    tags: ["platform engineering", "tooling signals"]
  },
  {
    title: "Distributed Computing Fieldnotes",
    summary:
      "Observing edge computing pilots in the energy sector and the ripple effects on developer experience.",
    tags: ["distributed computing", "software systems"]
  }
];

const Queue: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Reading Queue — DevLayer</title>
        <meta
          name="description"
          content="Preview DevLayer’s upcoming research across developer workflows, software systems, cloud infrastructure, and engineering psychology."
        />
        <link rel="canonical" href="https://devlayer.com/queue" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-5xl mx-auto px-5 text-center">
          <span className="badge mb-6">In Progress</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            DevLayer Reading Queue
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            A preview of investigations currently underway—shining light on developer workflows, cloud infrastructure, platform engineering, and devops culture.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-5xl mx-auto px-5 space-y-6">
          {queueItems.map((item) => (
            <div key={item.title} className="layer-card">
              <h2 className="font-display text-2xl text-ink mb-3">{item.title}</h2>
              <p className="text-sm text-slateEdge/80 leading-7 mb-3">{item.summary}</p>
              <div className="flex flex-wrap gap-2">
                {item.tags.map((tag) => (
                  <span key={tag} className="badge bg-azurePulse/10 text-azurePulse">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Queue;