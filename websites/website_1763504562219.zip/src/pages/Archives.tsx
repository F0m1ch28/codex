import React from "react";
import { Helmet } from "react-helmet-async";

const archiveEntries = [
  {
    title: "RFC 675: Specification of Internet Transmission Control Program",
    year: "1974",
    note: "Foundational document guiding modern distributed computing protocols and platform reliability."
  },
  {
    title: "The Xerox Alto User Experience",
    year: "1973",
    note: "Insights into early developer workflows with graphical interfaces, influencing IDE ergonomics."
  },
  {
    title: "UNIX V6 Source Commentary",
    year: "1977",
    note: "A touchstone for understanding modular software systems and cultural norms around documentation."
  },
  {
    title: "Netflix Simian Army Postmortems",
    year: "2011",
    note: "Case studies reinforcing chaos engineering and devops culture in cloud infrastructure."
  }
];

const Archives: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Archives — DevLayer</title>
        <meta
          name="description"
          content="DevLayer archives of historical computing references, RFCs, legacy documents, and open standards informing modern developer workflows."
        />
        <link rel="canonical" href="https://devlayer.com/archives" />
      </Helmet>

      <section className="section bg-mist">
        <div className="max-w-4xl mx-auto px-5 text-center">
          <span className="badge mb-6">Archives</span>
          <h1 className="font-display text-ink text-4xl mb-6">
            History that informs today’s engineering decisions.
          </h1>
          <p className="text-lg text-slateEdge/80 leading-8">
            We maintain a curated archive of RFCs, oral histories, and legacy documentation to connect past innovations with current developer workflows and cloud infrastructure practices.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="max-w-4xl mx-auto px-5 space-y-6">
          {archiveEntries.map((entry) => (
            <div key={entry.title} className="layer-card">
              <span className="badge mb-3">{entry.year}</span>
              <h2 className="font-display text-2xl text-ink mb-2">{entry.title}</h2>
              <p className="text-sm text-slateEdge/80 leading-7">{entry.note}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Archives;