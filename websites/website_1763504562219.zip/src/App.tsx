import React, { Suspense, lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollManager, { ScrollButton } from "./components/ScrollToTop";
import Loader from "./components/Loader";

const Home = lazy(() => import("./pages/Home"));
const About = lazy(() => import("./pages/About"));
const Services = lazy(() => import("./pages/Services"));
const Contact = lazy(() => import("./pages/Contact"));
const ContactThanks = lazy(() => import("./pages/ContactThanks"));
const Terms = lazy(() => import("./pages/Terms"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Blog = lazy(() => import("./pages/Blog"));
const BlogContextSwitching = lazy(() => import("./pages/BlogContextSwitching"));
const BlogCloudPatterns = lazy(() => import("./pages/BlogCloudPatterns"));
const BlogDevOpsEvolution = lazy(() => import("./pages/BlogDevOpsEvolution"));
const Workflows = lazy(() => import("./pages/Workflows"));
const Mindset = lazy(() => import("./pages/Mindset"));
const Queue = lazy(() => import("./pages/Queue"));
const Archives = lazy(() => import("./pages/Archives"));
const Notes = lazy(() => import("./pages/Notes"));
const NotFound = lazy(() => import("./pages/NotFound"));

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "DevLayer",
  "url": "https://devlayer.com",
  "logo": "https://picsum.photos/400/400?random=88",
  "foundingDate": "2020",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "333 Bay St",
    "addressLocality": "Toronto",
    "addressRegion": "ON",
    "postalCode": "M5H 2R2",
    "addressCountry": "CA"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+1 (416) 905-6621",
    "contactType": "editorial",
    "areaServed": "CA"
  },
  "sameAs": [
    "https://github.com/devlayer",
    "https://www.linkedin.com/company/devlayer"
  ]
};

const App: React.FC = () => {
  return (
    <>
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify(organizationSchema)}
        </script>
      </Helmet>
      <ScrollManager />
      <Header />
      <main className="bg-mist text-slateEdge min-h-screen">
        <Suspense fallback={<Loader />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/workflows" element={<Workflows />} />
            <Route path="/mindset" element={<Mindset />} />
            <Route path="/queue" element={<Queue />} />
            <Route path="/archives" element={<Archives />} />
            <Route path="/notes" element={<Notes />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/contact/thanks" element={<ContactThanks />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/blog" element={<Blog />} />
            <Route
              path="/blog/why-context-switching-kills-productivity"
              element={<BlogContextSwitching />}
            />
            <Route
              path="/blog/cloud-patterns-for-scale"
              element={<BlogCloudPatterns />}
            />
            <Route
              path="/blog/the-evolution-of-devops-culture"
              element={<BlogDevOpsEvolution />}
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollButton />
    </>
  );
};

export default App;