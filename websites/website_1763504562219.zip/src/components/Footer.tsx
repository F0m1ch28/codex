import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer: React.FC = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.wrapper}>
        <div>
          <div className={styles.brand}>DevLayer</div>
          <p className="text-sm text-mist/70 leading-relaxed mt-3 max-w-xs">
            Curated insight on software systems, developer workflows, cloud
            infrastructure, and the psychology of engineering teams across
            Canada and beyond.
          </p>
        </div>

        <div>
          <h3 className={styles.columnTitle}>Navigate</h3>
          <Link to="/" className={styles.link}>
            Home
          </Link>
          <Link to="/about" className={styles.link}>
            About
          </Link>
          <Link to="/services" className={styles.link}>
            Services
          </Link>
          <Link to="/blog" className={styles.link}>
            Essays
          </Link>
          <Link to="/archives" className={styles.link}>
            Archives
          </Link>
        </div>

        <div>
          <h3 className={styles.columnTitle}>Knowledge</h3>
          <Link to="/workflows" className={styles.link}>
            Workflow Patterns
          </Link>
          <Link to="/mindset" className={styles.link}>
            Developer Mindset
          </Link>
          <Link to="/queue" className={styles.link}>
            Reading Queue
          </Link>
          <Link to="/notes" className={styles.link}>
            Editorial Notes
          </Link>
        </div>

        <div>
          <h3 className={styles.columnTitle}>Contact</h3>
          <address className="not-italic text-sm text-mist/80 leading-6">
            DevLayer<br />
            333 Bay St<br />
            Toronto, ON M5H 2R2<br />
            Canada
          </address>
          <p className="mt-3 text-sm text-mist/80">
            Phone: <a href="tel:+14169056621" className="hover:text-azurePulse transition-colors">+1 (416) 905-6621</a>
          </p>
          <p className="mt-3 text-sm text-mist/70">
            Email: <a href="mailto:hello@devlayer.com" className="hover:text-azurePulse transition-colors">hello@devlayer.com</a>
          </p>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} DevLayer. Crafted in Canada for educational use only.</p>
        <div className={styles.socialList}>
          <a
            href="https://github.com/devlayer"
            className={styles.socialLink}
            aria-label="DevLayer on GitHub"
          >
            GitHub
          </a>
          <a
            href="https://www.linkedin.com/company/devlayer"
            className={styles.socialLink}
            aria-label="DevLayer on LinkedIn"
          >
            LinkedIn
          </a>
          <Link to="/privacy" className={styles.socialLink}>
            Privacy
          </Link>
          <Link to="/terms" className={styles.socialLink}>
            Terms
          </Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;