import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { motion } from "framer-motion";

const ScrollManager: React.FC = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);

  return null;
};

export const ScrollButton: React.FC = () => {
  const [show, setShow] = useState<boolean>(false);

  useEffect(() => {
    const onScroll = () => {
      setShow(window.scrollY > 420);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (!show) {
    return null;
  }

  return (
    <motion.button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed right-6 bottom-6 bg-azurePulse text-white px-4 py-3 rounded-full shadow-lg hover:-translate-y-1 transition-transform"
      aria-label="Back to start"
      initial={{ opacity: 0, scale: 0.6 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.6 }}
    >
      Back to start
    </motion.button>
  );
};

export default ScrollManager;