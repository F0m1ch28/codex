import React, { useEffect, useState } from "react";
import styles from "./CookieBanner.module.css";

const STORAGE_KEY = "devlayer-cookie-consent";

const CookieBanner: React.FC = () => {
  const [visible, setVisible] = useState<boolean>(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = window.setTimeout(() => setVisible(true), 1200);
      return () => window.clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  const decline = () => {
    localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        DevLayer uses analytical cookies to understand reader journeys and
        improve editorial planning. Review our{" "}
        <a href="/privacy" className="text-azurePulse underline">
          privacy notes
        </a>{" "}
        to learn more.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.buttonSecondary} onClick={decline}>
          Maybe later
        </button>
        <button type="button" className={styles.buttonPrimary} onClick={accept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;