import React from "react";

const Loader: React.FC = () => {
  return (
    <div className="w-full min-h-[50vh] flex items-center justify-center bg-mist">
      <div className="animate-spin h-12 w-12 border-4 border-azurePulse border-t-transparent rounded-full" aria-label="Loading" />
    </div>
  );
};

export default Loader;