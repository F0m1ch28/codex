import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import styles from "./Header.module.css";

interface NavItem {
  label: string;
  path: string;
}

const navItems: NavItem[] = [
  { label: "Home", path: "/" },
  { label: "About", path: "/about" },
  { label: "Services", path: "/services" },
  { label: "Workflows", path: "/workflows" },
  { label: "Mindset", path: "/mindset" },
  { label: "Blog", path: "/blog" },
  { label: "Queue", path: "/queue" },
  { label: "Contact", path: "/contact" }
];

const Header: React.FC = () => {
  const [open, setOpen] = useState<boolean>(false);

  const handleToggle = () => {
    setOpen((prev) => !prev);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <motion.header
      className={styles.header}
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <div className={styles.inner}>
        <NavLink to="/" className={styles.brand} onClick={handleClose}>
          <span className={styles.logoMark}>DL</span>
          <span>DevLayer</span>
        </NavLink>

        <nav className={styles.navlist} aria-label="Main navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `${styles.navlink} ${isActive ? styles.active : ""}`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <button
          className={styles.mobileToggle}
          aria-expanded={open}
          aria-controls="mobile-navigation"
          onClick={handleToggle}
          type="button"
        >
          <span className="sr-only">Toggle menu</span>
          <motion.span
            initial={false}
            animate={{ rotate: open ? 45 : 0, y: open ? 3 : 0 }}
            className="block w-6 h-0.5 bg-slateEdge mb-1"
          />
          <motion.span
            initial={false}
            animate={{ opacity: open ? 0 : 1 }}
            className="block w-6 h-0.5 bg-slateEdge mb-1"
          />
          <motion.span
            initial={false}
            animate={{ rotate: open ? -45 : 0, y: open ? -3 : 0 }}
            className="block w-6 h-0.5 bg-slateEdge"
          />
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            key="mobile-navigation"
            id="mobile-navigation"
            className={styles.mobileMenu}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
          >
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={handleClose}
                className={({ isActive }) =>
                  `${styles.mobileItem} ${isActive ? "text-azurePulse" : ""}`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </motion.nav>
        )}
      </AnimatePresence>
    </motion.header>
  );
};

export default Header;