/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        ink: "#111827",
        slateEdge: "#334155",
        azurePulse: "#3B82F6",
        mist: "#F1F5F9"
      },
      fontFamily: {
        display: ["'Satoshi'", "sans-serif"],
        body: ["'Inter'", "sans-serif"]
      },
      borderRadius: {
        xl: "1rem"
      },
      boxShadow: {
        layered: "0px 20px 50px rgba(17, 24, 39, 0.15)"
      }
    }
  },
  plugins: []
};