document.addEventListener('DOMContentLoaded', function () {
  var banner = document.getElementById('cookie-banner');
  if (!banner) {
    return;
  }
  var storedPreference = localStorage.getItem('tmwba-cookie-consent');
  if (!storedPreference) {
    banner.classList.add('visible');
  }
  var acceptButton = document.getElementById('accept-cookies');
  var declineButton = document.getElementById('decline-cookies');

  if (acceptButton) {
    acceptButton.addEventListener('click', function () {
      localStorage.setItem('tmwba-cookie-consent', 'accepted');
      banner.classList.remove('visible');
    });
  }

  if (declineButton) {
    declineButton.addEventListener('click', function () {
      localStorage.setItem('tmwba-cookie-consent', 'declined');
      banner.classList.remove('visible');
    });
  }
});