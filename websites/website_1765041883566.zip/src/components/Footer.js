import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div className={styles.brandBlock}>
          <h3 className={styles.brandTitle}>Професійне дресирування собак</h3>
          <p className={styles.brandText}>
            Спеціалізація на німецьких вівчарках, сучасні методики та
            індивідуальний підхід у Варшаві та Кракові.
          </p>
        </div>
        <div>
          <h4 className={styles.columnTitle}>Навігація</h4>
          <ul className={styles.linkList}>
            <li><Link to="/">Головна</Link></li>
            <li><Link to="/about">Про нас</Link></li>
            <li><Link to="/services">Послуги</Link></li>
            <li><Link to="/methodology">Методика</Link></li>
            <li><Link to="/contacts">Контакти</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.columnTitle}>Документи</h4>
          <ul className={styles.linkList}>
            <li><Link to="/terms-of-use">Умови використання</Link></li>
            <li><Link to="/privacy-policy">Політика конфіденційності</Link></li>
            <li><Link to="/cookie-policy">Політика щодо файлів cookie</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.columnTitle}>Контакти</h4>
          <p className={styles.contactItem}><strong>Email:</strong> <a href="mailto:info@dog-training.pl">info@dog-training.pl</a></p>
          <p className={styles.contactItem}><strong>Варшава • Краків</strong></p>
          <p className={styles.contactItem}>Телефон уточнюйте через форму</p>
        </div>
      </div>
      <div className={styles.bottomRow}>
        <p>© {new Date().getFullYear()} Професійне дресирування собак. Усі права захищені.</p>
        <p className={styles.tagline}>Відданість, дисципліна, взаєморозуміння.</p>
      </div>
    </div>
  </footer>
);

export default Footer;