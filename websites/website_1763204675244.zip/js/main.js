document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  const scrollTopButton = document.querySelector('.scroll-top');
  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieAcceptButton = document.querySelector('.cookie-accept');
  const yearEl = document.getElementById('current-year');

  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
      navToggle.classList.toggle('active');
    });

    document.querySelectorAll('.nav-menu a').forEach((link) => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
        navToggle?.setAttribute('aria-expanded', 'false');
        navToggle?.classList.remove('active');
      });
    });
  }

  document.querySelectorAll('a[data-scroll-top]').forEach((link) => {
    link.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'auto' });
    });
  });

  if (scrollTopButton) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 300) {
        scrollTopButton.classList.add('visible');
      } else {
        scrollTopButton.classList.remove('visible');
      }
    });

    scrollTopButton.addEventListener('click', (event) => {
      event.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (cookieBanner && cookieAcceptButton) {
    const consent = localStorage.getItem('fdl_cookie_consent');
    if (consent === 'accepted') {
      cookieBanner.classList.add('hidden');
    }
    cookieAcceptButton.addEventListener('click', () => {
      localStorage.setItem('fdl_cookie_consent', 'accepted');
      cookieBanner.classList.add('hidden');
    });
  }
});