document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            siteNav.classList.toggle("is-open");
        });

        siteNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                siteNav.classList.remove("is-open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("cookie-accept");
    const declineBtn = document.getElementById("cookie-decline");
    const consentKey = "genuscayqg_cookie_consent";

    if (cookieBanner && acceptBtn && declineBtn) {
        const consent = localStorage.getItem(consentKey);
        if (consent) {
            cookieBanner.classList.add("is-hidden");
        }

        acceptBtn.addEventListener("click", function () {
            localStorage.setItem(consentKey, "accepted");
            cookieBanner.classList.add("is-hidden");
        });

        declineBtn.addEventListener("click", function () {
            localStorage.setItem(consentKey, "declined");
            cookieBanner.classList.add("is-hidden");
        });
    }
});