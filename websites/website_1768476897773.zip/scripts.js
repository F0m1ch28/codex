document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.site-nav');
    const navLines = document.querySelectorAll('.nav-toggle-line');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navMenu.classList.toggle('active');
            navToggle.classList.toggle('is-active');
            navLines.forEach((line, index) => {
                line.style.transform = navToggle.classList.contains('is-active')
                    ? `translateY(${index === 0 ? 2 : index === 2 ? -2 : 0}px) rotate(${index === 1 ? 45 : index === 0 ? 10 : -10}deg)`
                    : '';
                line.style.opacity = navToggle.classList.contains('is-active') && index === 1 ? '0' : '1';
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 992) {
                navMenu.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
                navToggle.classList.remove('is-active');
                navLines.forEach((line) => {
                    line.style.transform = '';
                    line.style.opacity = '1';
                });
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAccept = document.querySelector('[data-cookie-accept]');
    const cookieDecline = document.querySelector('[data-cookie-decline]');
    const cookieKey = 'gmndCookieConsent';

    if (cookieBanner && cookieAccept && cookieDecline) {
        const consent = localStorage.getItem(cookieKey);

        if (!consent) {
            cookieBanner.classList.add('active');
        }

        const setConsent = (value) => {
            localStorage.setItem(cookieKey, value);
            cookieBanner.classList.remove('active');
        };

        cookieAccept.addEventListener('click', () => setConsent('accepted'));
        cookieDecline.addEventListener('click', () => setConsent('declined'));
    }

    const yearPlaceholder = document.querySelector('[data-current-year]');
    if (yearPlaceholder) {
        yearPlaceholder.textContent = new Date().getFullYear();
    }

    if (window.mermaid) {
        window.mermaid.initialize({
            startOnLoad: true,
            theme: 'neutral'
        });
    }
});