import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.column}>
        <Link to="/" className={styles.logo}>
          Digital<span>Covers</span>
        </Link>
        <p className={styles.description}>
          DigitalCovers создаёт выразительные цифровые обложки, аватарки и баннеры, помогая
          контент-мейкерам выделяться и удерживать внимание аудитории по всему миру.
        </p>
        <a className={styles.email} href="mailto:support@digitalcovers.com">
          support@digitalcovers.com
        </a>
      </div>
      <div className={styles.column}>
        <h4>Компания</h4>
        <ul>
          <li>
            <Link to="/about">О нас</Link>
          </li>
          <li>
            <Link to="/how-it-works">Как это работает</Link>
          </li>
          <li>
            <Link to="/services">Услуги</Link>
          </li>
          <li>
            <Link to="/contacts">Контакты</Link>
          </li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Каталог</h4>
        <ul>
          <li>
            <Link to="/catalog">Все коллекции</Link>
          </li>
          <li>
            <Link to="/catalog/video-covers">Обложки для видео</Link>
          </li>
          <li>
            <Link to="/catalog/avatars-icons">Аватарки и иконки</Link>
          </li>
          <li>
            <Link to="/catalog/stream-banners">Баннеры для стримов</Link>
          </li>
        </ul>
      </div>
      <div className={styles.column}>
        <h4>Правовая информация</h4>
        <ul>
          <li>
            <Link to="/terms">Условия использования</Link>
          </li>
          <li>
            <Link to="/privacy">Политика конфиденциальности</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;