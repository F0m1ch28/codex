import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('digitalcovers-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('digitalcovers-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Мы используем cookies, чтобы улучшить работу сайта и рекомендовать вам актуальные коллекции.
        Продолжая пользоваться сайтом, вы соглашаетесь с нашей{' '}
        <a href="/cookie-policy">Политикой использования cookies</a>.
      </p>
      <button onClick={acceptCookies} className={styles.button}>
        Согласен
      </button>
    </div>
  );
};

export default CookieBanner;