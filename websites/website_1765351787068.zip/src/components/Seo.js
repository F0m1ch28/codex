import { useEffect, useState } from 'react';

const getHelmet = () =>
  typeof window !== 'undefined' && window.ReactHelmet ? window.ReactHelmet.Helmet : null;

const Seo = ({ title, description, keywords }) => {
  const [helmetReady, setHelmetReady] = useState(() => !!getHelmet());

  useEffect(() => {
    if (!helmetReady) {
      const checkTimer = setInterval(() => {
        if (getHelmet()) {
          setHelmetReady(true);
          clearInterval(checkTimer);
        }
      }, 200);
      return () => clearInterval(checkTimer);
    }
  }, [helmetReady]);

  useEffect(() => {
    if (!helmetReady) {
      if (title) {
        document.title = title;
      }
      if (description) {
        let meta = document.querySelector('meta[name="description"]');
        if (!meta) {
          meta = document.createElement('meta');
          meta.setAttribute('name', 'description');
          document.head.appendChild(meta);
        }
        meta.setAttribute('content', description);
      }
      if (keywords) {
        let keywordsMeta = document.querySelector('meta[name="keywords"]');
        if (!keywordsMeta) {
          keywordsMeta = document.createElement('meta');
          keywordsMeta.setAttribute('name', 'keywords');
          document.head.appendChild(keywordsMeta);
        }
        keywordsMeta.setAttribute('content', keywords);
      }
    }
  }, [helmetReady, title, description, keywords]);

  if (!helmetReady) {
    return null;
  }

  const Helmet = getHelmet();
  if (!Helmet) {
    return null;
  }

  return (
    <Helmet>
      {title && <title>{title}</title>}
      {description && <meta name="description" content={description} />}
      {keywords && <meta name="keywords" content={keywords} />}
    </Helmet>
  );
};

export default Seo;