import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => (
  <>
    <Seo
      title="Политика использования cookies DigitalCovers"
      description="Условия использования файлов cookies на сайте DigitalCovers."
      keywords="cookie policy, DigitalCovers"
    />
    <section className={styles.section}>
      <div className="container">
        <h1>Политика использования cookies</h1>
        <p>
          Cookies помогают нам анализировать посещаемость и улучшать UX. Ниже описано, какие типы
          cookies мы применяем.
        </p>
        <h2>Типы cookies</h2>
        <ul>
          <li>Сессионные — для корректного отображения страниц и навигации.</li>
          <li>Аналитические — чтобы понимать, какие страницы пользуются спросом.</li>
          <li>Функциональные — сохраняют ваши предпочтения (например, выбор языка).</li>
        </ul>
        <h2>Управление cookies</h2>
        <p>
          Вы можете настроить использование cookies через параметры браузера или отказаться,
          используя баннер согласия на сайте.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;