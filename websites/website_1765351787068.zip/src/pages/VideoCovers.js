import React from 'react';
import Seo from '../components/Seo';
import styles from './Category.module.css';

const items = [
  {
    title: 'Motion Pulse',
    description:
      'Акцент на динамичной типографике и неоне — подходит для игровых и tech-обзоров.',
    image: 'https://picsum.photos/900/600?random=91'
  },
  {
    title: 'Edu Focus',
    description: 'Чёткая структурура, зоны под тезисы и крупные цифры для образовательных роликов.',
    image: 'https://picsum.photos/900/600?random=92'
  },
  {
    title: 'Daily Story',
    description:
      'Лёгкая лайфстайл-стилистика с мягкими градиентами и местом под портретный кадр автора.',
    image: 'https://picsum.photos/900/600?random=93'
  },
  {
    title: 'Retro Grid',
    description:
      'Смелые цвета и ретро-паттерны для каналов о поп-культуре, фильмах и комиксах.',
    image: 'https://picsum.photos/900/600?random=94'
  }
];

const VideoCoversPage = () => (
  <>
    <Seo
      title="Обложки для видео — DigitalCovers"
      description="Подборка обложек DigitalCovers для YouTube и других видеоплатформ: динамичные, образовательные и лайфстайл решения."
      keywords="обложки для видео, дизайн обложек, DigitalCovers"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Обложки для видео</h1>
        <p>
          Мы экспериментируем с типографикой, цветом и фотографиями, чтобы ваши ролики притягивали
          внимание в выдаче и рекомендациях.
        </p>
      </div>
    </section>
    <section className={styles.list}>
      <div className="container">
        <div className={styles.grid}>
          {items.map((item) => (
            <article key={item.title} className={styles.card}>
              <img src={item.image} alt={item.title} loading="lazy" />
              <div className={styles.body}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default VideoCoversPage;