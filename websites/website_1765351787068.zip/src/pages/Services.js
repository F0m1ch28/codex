import React from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const servicePackages = [
  {
    title: 'Пакет “Стартовый канал”',
    description:
      'Обложка канала, 6 универсальных превью, аватарка и мини-набор для соцсетей. Подходит для авторов, которые запускают новый формат.'
  },
  {
    title: 'Пакет “Стрим-событие”',
    description:
      'Комплект стартовых и паузных экранов, оверлеи с alerts-панелями, баннеры под партнёров и сетка для соцсетей.'
  },
  {
    title: 'Пакет “Командный”',
    description:
      'Расширенная лицензия, единый доступ для команды, версия макетов в Figma/PSD и кастомизация стилем бренда.'
  }
];

const process = [
  {
    title: 'Брифинг',
    text: 'Расскажите о формате контента, платформе и предпочитаемом визуальном стиле.'
  },
  {
    title: 'Прототип',
    text: 'Мы соберём moodboard, предложим палитру и ключевые композиции перед финальным рендером.'
  },
  {
    title: 'Доставка',
    text: 'Передаём готовые файлы, исходники и файл с рекомендациями по развёртыванию.'
  }
];

const ServicesPage = () => (
  <>
    <Seo
      title="Услуги DigitalCovers"
      description="DigitalCovers предлагает пакеты цифровых дизайнов под ключ: стартовые наборы, оформление стрим-событий и командные решения."
      keywords="услуги digitalcovers, цифровые пакеты, дизайн под ключ"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Услуги и кастомные пакеты</h1>
        <p>
          Помимо готовых коллекций мы помогаем брендам и авторам собрать уникальный визуал под
          задачи кампаний, запусков и событий.
        </p>
      </div>
    </section>

    <section className={styles.packages}>
      <div className="container">
        <h2>Популярные пакеты</h2>
        <div className={styles.packageGrid}>
          {servicePackages.map((pkg) => (
            <div key={pkg.title} className={styles.packageCard}>
              <h3>{pkg.title}</h3>
              <p>{pkg.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.processSection}>
      <div className="container">
        <h2>Как мы работаем</h2>
        <div className={styles.processGrid}>
          {process.map((item, index) => (
            <div key={item.title} className={styles.processCard}>
              <span>{index + 1}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default ServicesPage;