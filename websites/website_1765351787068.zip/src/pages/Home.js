import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const statsData = [
  { label: 'готовых визуальных решений', value: 780 },
  { label: 'креаторов используют DigitalCovers', value: 12500 },
  { label: 'обновлений каталога в год', value: 36 }
];

const categories = [
  {
    title: 'Обложки для видео',
    description:
      'Контрастные визуалы для YouTube, VK Видео и Rutube с понятной структурой и яркими акцентами.',
    link: '/catalog/video-covers',
    icon: '🎬'
  },
  {
    title: 'Аватарки и иконки',
    description:
      'Минимальные или иллюстративные аватарки, идеально читаемые на любых платформах.',
    link: '/catalog/avatars-icons',
    icon: '🪪'
  },
  {
    title: 'Баннеры для стримов',
    description:
      'Адаптивные баннеры для Twitch и Trovo с расположением блоков под донаты и расписание.',
    link: '/catalog/stream-banners',
    icon: '📡'
  }
];

const features = [
  {
    title: 'Уникальный дизайн',
    text: 'Каждый шаблон собирается вручную и проходит проверку на читаемость в мобильных и десктопных интерфейсах.'
  },
  {
    title: 'Мгновенная доставка',
    text: 'После доступа вы получаете файлы и инструкцию по настройке в облаке — никаких задержек и ожиданий.'
  },
  {
    title: 'Поддержка разных форматов',
    text: 'PSD, PNG, Sketch, Figma — мы подготовили варианты для распространённых программ и приложений.'
  },
  {
    title: 'Регулярные обновления',
    text: 'Каждый месяц добавляем свежие пакеты с трендовыми цветовыми схемами и новыми композициями.'
  }
];

const howSteps = [
  {
    title: 'Выберите дизайн',
    text: 'Откройте каталог, отсортируйте по платформе или тематике и найдите визуал, который отражает ваш стиль.'
  },
  {
    title: 'Оформите доступ',
    text: 'Подтвердите заказ — система моментально отправит доступ к облачной папке с материалами.'
  },
  {
    title: 'Скачайте файлы',
    text: 'Загрузите исходники, примените подсказки по кастомизации и выведите обновлённый канал в эфир.'
  }
];

const showcaseImages = [
  {
    src: 'https://picsum.photos/800/600?random=21',
    alt: 'Пример яркой обложки DigitalCovers'
  },
  {
    src: 'https://picsum.photos/800/600?random=22',
    alt: 'Аватарка для стримера в фирменном стиле'
  },
  {
    src: 'https://picsum.photos/800/600?random=23',
    alt: 'Баннер Twitch с расписанием эфиров'
  },
  {
    src: 'https://picsum.photos/800/600?random=24',
    alt: 'Обложка YouTube с ярким акцентом'
  }
];

const servicesData = [
  {
    title: 'Комплекты для YouTube',
    text: 'Полный визуальный пакет: обложки, шапка канала и отдельные элементы для разделов плейлистов.',
    image: 'https://picsum.photos/600/400?random=31'
  },
  {
    title: 'Оформление для стрима',
    text: 'Набор для стрим-комнаты: стартовые экраны, донат-панели и баннеры для социальных ссылок.',
    image: 'https://picsum.photos/600/400?random=32'
  },
  {
    title: 'Социальные мини-форматы',
    text: 'Сторис, превью коротких видео и постеры — всё, чтобы поддерживать узнаваемость в соцсетях.',
    image: 'https://picsum.photos/600/400?random=33'
  }
];

const testimonials = [
  {
    quote:
      'С DigitalCovers мы полностью обновили визуал канала без участия дизайнера. Команда оперативно добавила русскоязычные версии шаблонов.',
    name: 'Алиса Смирнова',
    role: 'YouTube-блогер • 420K подписчиков',
    avatar: 'https://picsum.photos/200/200?random=41'
  },
  {
    quote:
      'Каталог баннеров для стримов помог выровнять все экраны во время марафона. Очень нравится, что в каждом пакете есть гайд с настройками.',
    name: 'RomanPlay',
    role: 'Twitch-партнёр',
    avatar: 'https://picsum.photos/200/200?random=42'
  },
  {
    quote:
      'Взяли корпоративный пакет для внутреннего обучения. Дизайны легко кастомизируются под наш цвет, а команда поддерживает даже после покупки.',
    name: 'Команда Skillwave',
    role: 'EdTech-платформа',
    avatar: 'https://picsum.photos/200/200?random=43'
  }
];

const teamMembers = [
  {
    name: 'Мария Лебедева',
    role: 'Арт-директор',
    image: 'https://picsum.photos/400/400?random=51',
    bio: 'Следит за трендами платформ и курирует визуальную систему DigitalCovers.'
  },
  {
    name: 'Илья Бородин',
    role: 'Ведущий дизайнер',
    image: 'https://picsum.photos/400/400?random=52',
    bio: 'Создаёт адаптивные макеты и проверяет читаемость в разных разрешениях.'
  },
  {
    name: 'София Чжан',
    role: 'Менеджер по работе с авторами',
    image: 'https://picsum.photos/400/400?random=53',
    bio: 'Помогает креаторам настроить визуал и отвечает на вопросы по форматам.'
  }
];

const projectData = [
  {
    id: 1,
    title: 'LIVE Lab Marathon',
    category: 'Стрим',
    description: 'Комплект прозрачных плашек, анимация и экран ожидания для технологичного шоу.',
    image: 'https://picsum.photos/1200/800?random=61'
  },
  {
    id: 2,
    title: 'CyberWave Shorts',
    category: 'Видео',
    description: 'Неоновые обложки для роликов с коротким хронометражем и вертикальным кадром.',
    image: 'https://picsum.photos/1200/800?random=62'
  },
  {
    id: 3,
    title: 'ArtCorner Community',
    category: 'Соцсети',
    description: 'Иллюстративные аватарки и постеры для творческого комьюнити.',
    image: 'https://picsum.photos/1200/800?random=63'
  },
  {
    id: 4,
    title: 'Esport Weekly',
    category: 'Стрим',
    description: 'Брутальные баннеры с сеткой и тёмной темой для еженедельных стримов.',
    image: 'https://picsum.photos/1200/800?random=64'
  },
  {
    id: 5,
    title: 'Podium Talks',
    category: 'Видео',
    description: 'Минималистичные обложки с крупной типографикой для интервью и подкастов.',
    image: 'https://picsum.photos/1200/800?random=65'
  }
];

const faqData = [
  {
    question: 'Можно ли использовать шаблоны для коммерческих проектов?',
    answer:
      'Да. В лицензии DigitalCovers предусмотрено использование в коммерческих и некоммерческих проектах. Ограничение только одно — запрещено перепродавать шаблоны в неизменном виде.'
  },
  {
    question: 'Какие программы я могу использовать для редактирования?',
    answer:
      'Большинство пакетов включает версии PSD, Figma и Canva. В карточке коллекции указаны доступные форматы и советы по настройке.'
  },
  {
    question: 'Будут ли обновляться купленные коллекции?',
    answer:
      'Да, мы регулярно добавляем новые размеры и элементы. Клиенты получают уведомления об обновлениях и доступ к обновлённым файлам без доплаты.'
  },
  {
    question: 'Предоставляете ли вы индивидуальные услуги?',
    answer:
      'Для команд и брендов мы предлагаем кастомные пакеты. Оставьте заявку на странице контактов, чтобы обсудить детали.'
  }
];

const blogPosts = [
  {
    title: 'Как собрать визуальный бренд стримера за выходные',
    excerpt:
      'Рассказываем, на какие элементы обратить внимание, чтобы оформить канал и соцсети в едином стиле.',
    image: 'https://picsum.photos/800/600?random=71',
    link: '/blog/stream-branding'
  },
  {
    title: 'Топ платформ, где важна качественная обложка',
    excerpt:
      'YouTube, VK Видео и площадки-партнёры — делимся наблюдениями из нашей аналитики по переходам.',
    image: 'https://picsum.photos/800/600?random=72',
    link: '/blog/cover-analytics'
  },
  {
    title: 'Гайд по подготовке ассетов для коллабораций',
    excerpt:
      'Собрали чек-лист, который поможет командам быстро согласовать графику при совместных проектах.',
    image: 'https://picsum.photos/800/600?random=73',
    link: '/blog/collab-assets'
  }
];

const HomePage = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Все');
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, index) => {
          const target = statsData[index].value;
          if (value >= target) return target;
          const increment = Math.ceil(target / 40);
          return Math.min(value + increment, target);
        })
      );
    }, 80);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const slider = setTimeout(
      () => setActiveTestimonial((prev) => (prev + 1) % testimonials.length),
      6000
    );
    return () => clearTimeout(slider);
  }, [activeTestimonial]);

  const filters = ['Все', 'Видео', 'Стрим', 'Соцсети'];
  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Все') {
      return projectData;
    }
    return projectData.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <Seo
        title="DigitalCovers — цифровые обложки, аватарки и баннеры для авторов"
        description="Каталог DigitalCovers предлагает яркие и адаптивные дизайны для YouTube, Twitch и соцсетей. Быстрый доступ к шаблонам, поддержка и регулярные обновления."
        keywords="обложки для видео, аватарки, дизайн для стримеров, цифровые товары, баннер для Twitch, графика для YouTube"
      />

      <section
        className={styles.hero}
        style={{
          backgroundImage:
            'linear-gradient(135deg, rgba(15,23,42,0.78) 0%, rgba(15,23,42,0.35) 48%, rgba(99,102,241,0.24) 100%), url(https://picsum.photos/1600/900?random=11)'
        }}
      >
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroKicker}>DigitalCovers</span>
            <h1 className={styles.heroTitle}>Цифровые обложки и аватарки для вашего контента</h1>
            <p className={styles.heroText}>
              Создавайте впечатляющие превью, баннеры и графику для любой площадки. Мы продумали
              композицию, цвета и типографику — вам остаётся добавить свой стиль.
            </p>
            <div className={styles.heroActions}>
              <Link to="/catalog" className={styles.primaryBtn}>
                Смотреть каталог
              </Link>
              <Link to="/how-it-works" className={styles.secondaryLink}>
                Узнать, как это устроено
              </Link>
            </div>
            <div className={styles.statBadges}>
              {statsData.map((stat, index) => (
                <div key={stat.label} className={styles.statBadge}>
                  <strong>{counters[index].toLocaleString('ru-RU')}+</strong>
                  <span>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Категории товаров</h2>
            <p>Готовые решения для ключевых точек контакта с вашей аудиторией.</p>
          </div>
          <div className={styles.categoriesGrid}>
            {categories.map((category) => (
              <Link to={category.link} className={styles.categoryCard} key={category.title}>
                <div className={styles.categoryIcon}>{category.icon}</div>
                <div>
                  <h3>{category.title}</h3>
                  <p>{category.description}</p>
                </div>
                <span className={styles.categoryArrow}>Перейти →</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Услуги и цифровые комплекты</h2>
            <p>
              Собрали пакеты для разных форматов контента. Каждый набор включает гайд по настройке,
              шрифты и дополнительные ресурсы.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article className={styles.serviceCard} key={service.title}>
                <img src={service.image} alt={service.title} loading="lazy" />
                <div className={styles.serviceBody}>
                  <h3>{service.title}</h3>
                  <p>{service.text}</p>
                  <Link to="/services">Подробнее об услугах</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.featuresSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Почему DigitalCovers?</h2>
            <p>
              Мы проектируем визуальные решения, которые легко адаптировать и приятно использовать.
            </p>
          </div>
          <div className={styles.featuresGrid}>
            {features.map((feature) => (
              <div className={styles.featureCard} key={feature.title}>
                <h3>{feature.title}</h3>
                <p>{feature.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Как это работает</h2>
            <p>Три простых шага до обновлённого визуального образа вашего канала.</p>
          </div>
          <div className={styles.processSteps}>
            {howSteps.map((step, index) => (
              <div className={styles.processCard} key={step.title}>
                <span className={styles.processNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
          <div className={styles.processLinkWrapper}>
            <Link to="/how-it-works" className={styles.processLink}>
              Перейти к подробной инструкции
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.showcaseSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Галерея примеров</h2>
            <p>Часть коллекций, которые уже помогают авторам охватывать большую аудиторию.</p>
          </div>
          <div className={styles.showcaseGrid}>
            {showcaseImages.map((image) => (
              <figure key={image.src} className={styles.showcaseCard}>
                <img src={image.src} alt={image.alt} loading="lazy" />
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Отзывы создателей</h2>
            <p>DigitalCovers вдохновляет авторов из разных индустрий.</p>
          </div>
          <div className={styles.testimonialWrapper}>
            <article className={styles.testimonialCard}>
              <img
                src={testimonials[activeTestimonial].avatar}
                alt={testimonials[activeTestimonial].name}
                loading="lazy"
              />
              <blockquote>“{testimonials[activeTestimonial].quote}”</blockquote>
              <div className={styles.testimonialAuthor}>
                <strong>{testimonials[activeTestimonial].name}</strong>
                <span>{testimonials[activeTestimonial].role}</span>
              </div>
            </article>
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={
                    index === activeTestimonial
                      ? `${styles.dot} ${styles.dotActive}`
                      : styles.dot
                  }
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Отзыв ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Команда DigitalCovers</h2>
            <p>Мы объединяем дизайнеров, аналитиков и кураторов, чтобы поддерживать вас ежедневно.</p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamBody}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.teamLinkWrapper}>
            <Link to="/about">Узнать историю команды</Link>
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Проекты клиентов</h2>
            <p>Посмотрите, как наши шаблоны трансформируют каналы и события.</p>
          </div>
          <div className={styles.filterControls}>
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={
                  activeFilter === filter
                    ? `${styles.filterButton} ${styles.filterButtonActive}`
                    : styles.filterButton
                }
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectBody}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>FAQ</h2>
            <p>Собрали самые частые вопросы от авторов и студий.</p>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <div
                key={item.question}
                className={`${styles.faqItem} ${openFaq === index ? styles.faqOpen : ''}`}
              >
                <button
                  className={styles.faqQuestion}
                  onClick={() => setOpenFaq(openFaq === index ? -1 : index)}
                  aria-expanded={openFaq === index}
                >
                  {item.question}
                  <span>{openFaq === index ? '−' : '+'}</span>
                </button>
                <div className={styles.faqAnswer}>
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Блог DigitalCovers</h2>
            <p>Инсайты, тренды и практические советы для авторов и брендов.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogBody}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href={post.link}>Читать материал →</a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Начните улучшать свой контент уже сегодня</h2>
            <p>
              Соберите узнаваемый визуальный образ, увеличьте CTR обложек и выведите ваш канал на
              новый уровень — DigitalCovers готов помочь прямо сейчас.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/catalog" className={styles.primaryBtn}>
                Перейти в каталог
              </Link>
              <Link to="/contacts" className={styles.secondaryLink}>
                Написать нам
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;