import React from 'react';
import Seo from '../components/Seo';
import styles from './Category.module.css';

const items = [
  {
    title: 'Bold Initials',
    description:
      'Крупные буквы и контрастные фоны — отлично читается на мобильных устройствах.',
    image: 'https://picsum.photos/900/600?random=101'
  },
  {
    title: 'Mascot Wave',
    description:
      'Авторские персонажи и мягкая стилизация для игровых стримеров и творческих блогов.',
    image: 'https://picsum.photos/900/600?random=102'
  },
  {
    title: 'Gradient Flow',
    description:
      'Градиентные переходы и геометрия, подходящая для образовательных каналов и экспертов.',
    image: 'https://picsum.photos/900/600?random=103'
  },
  {
    title: 'Minimal Mono',
    description:
      'Чистые формы и нейтральные цвета, если вы хотите подчеркнуть профессиональную подачу.',
    image: 'https://picsum.photos/900/600?random=104'
  }
];

const AvatarsIconsPage = () => (
  <>
    <Seo
      title="Аватарки и иконки — DigitalCovers"
      description="Выразительные аватарки и иконки для стримеров и авторов. Контрастные решения, запоминающиеся персонажи и минималистичные стили."
      keywords="аватарки, иконки для стримов, DigitalCovers"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Аватарки и иконки</h1>
        <p>
          Миниатюрные форматы требуют точной композиции. Мы соблюдаем баланс, чтобы ваш образ был
          узнаваем даже на экране смартфона.
        </p>
      </div>
    </section>
    <section className={styles.list}>
      <div className="container">
        <div className={styles.grid}>
          {items.map((item) => (
            <article key={item.title} className={styles.card}>
              <img src={item.image} alt={item.title} loading="lazy" />
              <div className={styles.body}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default AvatarsIconsPage;