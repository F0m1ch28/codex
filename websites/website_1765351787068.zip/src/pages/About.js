import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const values = [
  {
    title: 'Фокус на создателях',
    description:
      'Изучаем пользовательские сценарии блогеров и стримеров, чтобы предлагать релевантные решения.'
  },
  {
    title: 'Технологичность',
    description:
      'Используем аналитику CTR и A/B тесты для оптимизации обложек и баннеров под реальные показатели.'
  },
  {
    title: 'Прозрачность',
    description:
      'Честно рассказываем о возможностях и ограничениях цифровых пакетов, не обещаем невозможного.'
  }
];

const timeline = [
  {
    year: '2019',
    text: 'DigitalCovers появился как комьюнити дизайнеров, собирающих обложки для YouTube.'
  },
  {
    year: '2020',
    text: 'Запустили первые пакеты для Twitch и провели консультации для 200+ стримеров.'
  },
  {
    year: '2022',
    text: 'Разработали систему обновлений и выпустили редакционные гайды по платформам.'
  },
  {
    year: '2023',
    text: 'Вышли на международный рынок и добавили поддержку Figma и Canva.'
  }
];

const AboutPage = () => (
  <>
    <Seo
      title="О компании DigitalCovers"
      description="Узнайте историю и подход DigitalCovers: мы создаём цифровые дизайны для авторов и брендов, поддерживая их визуально и методологически."
      keywords="о компании, DigitalCovers, команда"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>О DigitalCovers</h1>
        <p>
          Мы верим, что каждый автор достоин сильного визуала. DigitalCovers соединяет опыт
          дизайнеров, аналитиков и продюсеров, чтобы вы могли показать свой контент во всей красе.
        </p>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <h2>Наши принципы</h2>
        <div className={styles.valueGrid}>
          {values.map((value) => (
            <div key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.timelineSection}>
      <div className="container">
        <h2>Путь развития</h2>
        <div className={styles.timeline}>
          {timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span>{item.year}</span>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default AboutPage;