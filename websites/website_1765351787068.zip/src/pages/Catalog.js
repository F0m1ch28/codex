import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Catalog.module.css';

const collections = [
  {
    title: 'Категория: Обложки для видео',
    text: 'Насыщенные композиции для образовательных, игровых и лайфстайл форматов. Шаблоны адаптированы под YouTube, VK Видео и Rutube.',
    link: '/catalog/video-covers',
    image: 'https://picsum.photos/900/600?random=81'
  },
  {
    title: 'Категория: Аватарки и иконки',
    text: 'Мини-дизайны с крупными формами и читаемыми инициалами. Поддержка круглых и квадратных форматов.',
    link: '/catalog/avatars-icons',
    image: 'https://picsum.photos/900/600?random=82'
  },
  {
    title: 'Категория: Баннеры для стримов',
    text: 'Динамичные баннеры с зонами под расписание эфиров и донаты. Поддерживаются Twitch, Trovo и VK Play.',
    link: '/catalog/stream-banners',
    image: 'https://picsum.photos/900/600?random=83'
  }
];

const highlights = [
  {
    title: 'Подборки по тематикам',
    description:
      'Гик-культура, хай-тек, lifestyle, minimal — фильтры помогут найти визуал под ваш контент.'
  },
  {
    title: 'Иллюстрированные варианты',
    description:
      'Коллекции с кастомными иллюстрациями и персонажами для авторов, которые хотят добавить историю.'
  },
  {
    title: 'Совместимость с Canva',
    description:
      'Большинство пакетов содержит версии для Canva, Figma и Photoshop, чтобы вы работали в удобном инструменте.'
  }
];

const CatalogPage = () => (
  <>
    <Seo
      title="Каталог DigitalCovers — цифровые обложки и баннеры"
      description="Изучите каталог DigitalCovers: обложки для видео, аватарки и баннеры для стримов. Подберите визуальные решения под вашу площадку."
      keywords="каталог обложек, цифровые товары, дизайн для стримеров, обложки для видео"
    />
    <section className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <span>Каталог DigitalCovers</span>
          <h1>Выберите идеальный визуал для своего канала</h1>
          <p>
            Мы подготовили адаптивные шаблоны под популярные платформы и собрали коллекции для
            разных жанров: от обучающих курсов до стриминговых шоу.
          </p>
          <Link to="/contacts" className={styles.heroLink}>
            Нужен подбор под задачу? Напишите нам →
          </Link>
        </div>
      </div>
    </section>

    <section className={styles.collectionsSection}>
      <div className="container">
        <div className={styles.grid}>
          {collections.map((collection) => (
            <article key={collection.title} className={styles.card}>
              <img src={collection.image} alt={collection.title} loading="lazy" />
              <div className={styles.body}>
                <h3>{collection.title}</h3>
                <p>{collection.text}</p>
                <Link to={collection.link}>Открыть коллекцию</Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.highlights}>
      <div className="container">
        <h2>Что вы найдёте в каталоге</h2>
        <div className={styles.highlightGrid}>
          {highlights.map((item) => (
            <div key={item.title} className={styles.highlightCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default CatalogPage;