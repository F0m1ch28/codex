import React from 'react';
import Seo from '../components/Seo';
import styles from './Category.module.css';

const items = [
  {
    title: 'Night Shift',
    description:
      'Тёмные баннеры с плоскими схемами и местом под расписание стримов и донаты.',
    image: 'https://picsum.photos/900/600?random=111'
  },
  {
    title: 'Vibrant Pulse',
    description:
      'Яркая волновая графика и выделенные блоки под соцсети — заметно в любой трансляции.',
    image: 'https://picsum.photos/900/600?random=112'
  },
  {
    title: 'Future Grid',
    description:
      'Сетчатая структура и глитч-эффекты, которые создают атмосферу киберспортивного шоу.',
    image: 'https://picsum.photos/900/600?random=113'
  },
  {
    title: 'Calm Focus',
    description:
      'Спокойные пастельные комбинации для коворкинг-стримов и образовательных эфиров.',
    image: 'https://picsum.photos/900/600?random=114'
  }
];

const StreamBannersPage = () => (
  <>
    <Seo
      title="Баннеры для стримов — DigitalCovers"
      description="Баннеры DigitalCovers для Twitch, Trovo и VK Play: информативные панели, стартовые экраны и графика для стрим-комнаты."
      keywords="баннеры, стрим, Twitch баннер, DigitalCovers"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Баннеры для стримов</h1>
        <p>
          Продуманные композиции под блоки о донатах, расписании и партнёрах помогают зрителям
          ориентироваться с первых секунд.
        </p>
      </div>
    </section>
    <section className={styles.list}>
      <div className="container">
        <div className={styles.grid}>
          {items.map((item) => (
            <article key={item.title} className={styles.card}>
              <img src={item.image} alt={item.title} loading="lazy" />
              <div className={styles.body}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default StreamBannersPage;