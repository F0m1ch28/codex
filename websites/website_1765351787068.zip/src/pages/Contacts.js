import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contacts.module.css';

const initialForm = {
  name: '',
  email: '',
  topic: 'Каталог',
  message: ''
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle');

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Введите ваше имя или ник.';
    }
    if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Укажите корректный email.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Пожалуйста, опишите запрос подробнее (минимум 10 символов).';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length > 0) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setStatus('loading');
    setTimeout(() => {
      setStatus('success');
      setFormData(initialForm);
    }, 1200);
  };

  return (
    <>
      <Seo
        title="Контакты DigitalCovers"
        description="Свяжитесь с командой DigitalCovers: вопросы по каталогу, кастомным пакетам и партнёрствам."
        keywords="контакты digitalcovers, поддержка"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Контакты</h1>
          <p>
            Расскажите нам о своей задаче — мы подскажем, какие шаблоны подойдут лучше всего и
            поможем настроить визуал.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Напишите нам</h2>
              <p>
                Мы отвечаем на письма в течение рабочего дня. Укажите ссылки на ваши каналы,
                платформы и желаемые сроки, чтобы мы предложили релевантное решение.
              </p>
              <a href="mailto:support@digitalcovers.com" className={styles.mailLink}>
                support@digitalcovers.com
              </a>
            </div>

            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Имя или ник</label>
                <input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, name: event.target.value }))
                  }
                  placeholder="Например, DigitalCreator"
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, email: event.target.value }))
                  }
                  placeholder="you@example.com"
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="topic">Тема запроса</label>
                <select
                  id="topic"
                  name="topic"
                  value={formData.topic}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, topic: event.target.value }))
                  }
                >
                  <option value="Каталог">Каталог DigitalCovers</option>
                  <option value="Услуги">Кастомный пакет</option>
                  <option value="Партнёрство">Партнёрство</option>
                  <option value="Техподдержка">Технический вопрос</option>
                </select>
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Комментарий</label>
                <textarea
                  id="message"
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={(event) =>
                    setFormData((prev) => ({ ...prev, message: event.target.value }))
                  }
                  placeholder="Опишите задачу, платформу и сроки."
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>

              <button type="submit" className={styles.submit} disabled={status === 'loading'}>
                {status === 'loading' ? 'Отправляем...' : 'Отправить сообщение'}
              </button>
              {status === 'success' && (
                <p className={styles.success}>Спасибо! Мы свяжемся с вами в ближайшее время.</p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactsPage;