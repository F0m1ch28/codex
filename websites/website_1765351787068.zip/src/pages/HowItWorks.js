import React from 'react';
import Seo from '../components/Seo';
import styles from './HowItWorks.module.css';

const steps = [
  {
    title: 'Анализируем ваш формат',
    description:
      'Соберите информацию о контенте: длительность видео, ключевые рубрики, платформа и основной цвет бренда.'
  },
  {
    title: 'Выбираем коллекцию',
    description:
      'Используйте фильтры в каталоге, чтобы найти подходящие шаблоны. При необходимости — пишите на support@digitalcovers.com.'
  },
  {
    title: 'Настраиваем дизайн',
    description:
      'Замените текст и изображения в редакторе. Наша инструкция поможет адаптировать элементы без потери качества.'
  },
  {
    title: 'Публикуем визуал',
    description:
      'Загрузите обновлённые обложки, баннеры и аватарки. Следите за CTR и делитесь результатами — мы будем рады фидбеку.'
  }
];

const extras = [
  {
    title: 'Поддержка',
    description: 'Отвечаем на письма в течение 24 часов и помогаем импортировать файлы в ваш редактор.'
  },
  {
    title: 'Гайды по платформам',
    description: 'Регулярно обновляем инструкции с актуальными размерам, требованиями и советами по оптимизации.'
  },
  {
    title: 'Командные пакеты',
    description: 'Для студий и агентств предоставляем расширенную лицензию и единый доступ для команды.'
  }
];

const HowItWorksPage = () => (
  <>
    <Seo
      title="Как работает DigitalCovers"
      description="Узнайте, как выбрать и адаптировать цифровой дизайн от DigitalCovers: шаги, поддержка и дополнительные преимущества."
      keywords="как это работает, digitalcovers, руководство"
    />
    <section className={styles.hero}>
      <div className="container">
        <h1>Как это работает</h1>
        <p>
          Мы минимизировали время между идеей и новой айдентикой. Следуйте плану, чтобы быстро
          настроить визуал и вдохнуть новую жизнь в канал.
        </p>
      </div>
    </section>

    <section className={styles.stepsSection}>
      <div className="container">
        <div className={styles.timeline}>
          {steps.map((step, index) => (
            <div key={step.title} className={styles.step}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.extras}>
      <div className="container">
        <h2>Дополнительные преимущества</h2>
        <div className={styles.extrasGrid}>
          {extras.map((extra) => (
            <div key={extra.title} className={styles.extraCard}>
              <h3>{extra.title}</h3>
              <p>{extra.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default HowItWorksPage;