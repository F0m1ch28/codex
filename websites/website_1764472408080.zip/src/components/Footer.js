```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <h3 className="footer-title">Tu Progreso Hoy</h3>
          <p className="footer-subtitle">
            Datos verificados para planificar tu presupuesto. <br />
            Decisiones responsables, objetivos nítidos.
          </p>
          <p className="footer-text">
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
        <div>
          <h4 className="footer-heading">Explore</h4>
          <ul className="footer-links">
            <li><NavLink to="/">Home</NavLink></li>
            <li><NavLink to="/inflation">Inflation</NavLink></li>
            <li><NavLink to="/course">Course</NavLink></li>
            <li><NavLink to="/resources">Resources</NavLink></li>
            <li><NavLink to="/faq">FAQ</NavLink></li>
            <li><NavLink to="/contact">Contact</NavLink></li>
          </ul>
        </div>
        <div>
          <h4 className="footer-heading">Legal</h4>
          <ul className="footer-links">
            <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
            <li><NavLink to="/cookies">Cookie Policy</NavLink></li>
            <li><NavLink to="/terms">Terms of Service</NavLink></li>
          </ul>
        </div>
        <div>
          <h4 className="footer-heading">Contact</h4>
          <address className="footer-text">
            Av. 9 de Julio 1000<br />
            C1043 Buenos Aires, Argentina<br />
            <a href="tel:+541155551234" className="footer-link">+54 11 5555-1234</a><br />
            <a href="mailto:hola@tuprogresohoy.com" className="footer-link">
              hola@tuprogresohoy.com
            </a>
          </address>
          <div className="social-links" aria-label="Social media">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
              X / Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>
          Conocimiento financiero impulsado por tendencias. Pasos acertados hoy, mejor futuro mañana.
        </p>
        <p>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;
```