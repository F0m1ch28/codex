```javascript
import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';

const navLinks = [
  { path: '/', label: 'Home / Inicio' },
  { path: '/inflation', label: 'Inflation / Inflación' },
  { path: '/course', label: 'Course / Curso' },
  { path: '/resources', label: 'Resources / Recursos' },
  { path: '/contact', label: 'Contact / Contacto' }
];

function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const closeMenu = () => setIsOpen(false);

  return (
    <header className="header">
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <div className="container header-inner">
        <NavLink to="/" className="brand" onClick={closeMenu}>
          Tu Progreso Hoy
        </NavLink>
        <button
          className="menu-toggle"
          aria-expanded={isOpen}
          aria-controls="primary-navigation"
          onClick={() => setIsOpen((prev) => !prev)}
        >
          <span className="sr-only">Toggle navigation</span>
          <div className="menu-icon" />
        </button>
        <nav
          id="primary-navigation"
          className={`nav ${isOpen ? 'nav-open' : ''}`}
          aria-label="Primary"
        >
          <ul>
            {navLinks.map((link) => (
              <li key={link.path}>
                <NavLink
                  to={link.path}
                  onClick={closeMenu}
                  className={({ isActive }) =>
                    isActive ? 'nav-link active' : 'nav-link'
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
            <li>
              <NavLink
                to="/faq"
                className={({ isActive }) =>
                  isActive ? 'nav-link active' : 'nav-link'
                }
                onClick={closeMenu}
              >
                FAQ
              </NavLink>
            </li>
          </ul>
          <div className="language-switch">
            <span
              className={location.search.includes('lang=es') ? '' : 'active-lang'}
              aria-label="English"
            >
              EN
            </span>
            <span aria-hidden="true"> / </span>
            <span
              className={location.search.includes('lang=es') ? 'active-lang' : ''}
              aria-label="Español"
            >
              ES
            </span>
          </div>
        </nav>
      </div>
    </header>
  );
}

export default Header;
```