```javascript
import React, { useEffect, useRef } from 'react';

function DisclaimerModal({ isOpen, onClose }) {
  const dialogRef = useRef(null);

  useEffect(() => {
    if (isOpen && dialogRef.current) {
      dialogRef.current.focus();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="modal-backdrop" role="presentation">
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="disclaimer-title"
        tabIndex={-1}
        ref={dialogRef}
      >
        <h2 id="disclaimer-title">Disclaimer / Descargo</h2>
        <p className="modal-text">
          Мы не предоставляем финансовые услуги. We do not provide financial services.
        </p>
        <p className="modal-text">
          Plataforma educativa con datos esenciales, sin asesoría financiera directa. Educational
          platform sharing key data insights, no direct financial advisory.
        </p>
        <button type="button" className="btn-primary" onClick={onClose}>
          I Understand / Entiendo
        </button>
      </div>
    </div>
  );
}

export default DisclaimerModal;
```