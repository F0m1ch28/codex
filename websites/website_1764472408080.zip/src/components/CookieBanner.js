```javascript
import React, { useEffect, useState } from 'react';

const COOKIE_KEY = 'tph-cookie-preference';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const storedPreference = localStorage.getItem(COOKIE_KEY);
    if (!storedPreference) {
      setIsVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(COOKIE_KEY, choice);
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="assertive">
      <div className="cookie-content">
        <h3>Cookies / Cookies</h3>
        <p>
          Utilizamos cookies para mejorar tu experiencia y analizar el uso de la plataforma. Puedes
          aceptar o rechazar según tus preferencias. / We use cookies to enhance your experience and
          analyse how the platform performs.
        </p>
        <div className="cookie-actions">
          <button type="button" className="btn-secondary" onClick={() => handleChoice('declined')}>
            Decline / Rechazar
          </button>
          <button type="button" className="btn-primary" onClick={() => handleChoice('accepted')}>
            Accept / Aceptar
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;
```