```javascript
import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HelmetProvider, Helmet } from 'react-helmet-async';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import DisclaimerModal from './components/DisclaimerModal';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import Terms from './pages/Terms';
import Faq from './pages/Faq';
import NotFound from './pages/NotFound';

function App() {
  const [showDisclaimer, setShowDisclaimer] = useState(true);

  return (
    <HelmetProvider>
      <BrowserRouter>
        <Helmet>
          <link rel="alternate" href="https://www.tuprogresohoy.com/" hrefLang="en" />
          <link rel="alternate" href="https://www.tuprogresohoy.com/?lang=es" hrefLang="es-AR" />
          <meta
            name="description"
            content="Tu Progreso Hoy offers verified data and educational resources about inflation in Argentina, helping you build responsible financial knowledge."
          />
        </Helmet>
        <ScrollToTop />
        <Header />
        <main id="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/inflation" element={<Inflation />} />
            <Route path="/course" element={<Course />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<Cookies />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/faq" element={<Faq />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <DisclaimerModal isOpen={showDisclaimer} onClose={() => setShowDisclaimer(false)} />
      </BrowserRouter>
    </HelmetProvider>
  );
}

export default App;
```