```javascript
import React from 'react';

function Terms() {
  return (
    <div className="legal-page container">
      <h1>Terms of Service</h1>
      <p>Last updated: February 2024</p>

      <h2>1. Acceptance</h2>
      <p>
        By accessing Tu Progreso Hoy you agree to these terms. The platform is educational and does not provide
        financial services or individualized recommendations. Мы не предоставляем финансовые услуги.
      </p>

      <h2>2. Eligibility</h2>
      <p>
        You must be at least 18 years old or have parental consent. Users are responsible for complying with local
        laws in Argentina and elsewhere.
      </p>

      <h2>3. Educational Content</h2>
      <p>
        All materials are for educational purposes. Data sources are cited and updated regularly, but no assurance is
        provided on future accuracy. Use the information to strengthen your own judgment.
      </p>

      <h2>4. User Accounts</h2>
      <p>
        When you subscribe, you must provide accurate information and complete the double opt-in confirmation. You are
        responsible for safeguarding your email credentials.
      </p>

      <h2>5. Intellectual Property</h2>
      <p>
        Content and design elements belong to Tu Progreso Hoy unless otherwise noted. You may not reproduce or
        distribute without permission.
      </p>

      <h2>6. Limitation of Liability</h2>
      <p>
        Tu Progreso Hoy is not liable for decisions made using the educational resources. We encourage responsible,
        informed choices supported by multiple sources.
      </p>

      <h2>7. Changes</h2>
      <p>
        Terms may be updated periodically. We will provide notice via email or the website.
      </p>

      <h2>8. Contact</h2>
      <p>
        For questions, email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
      </p>
    </div>
  );
}

export default Terms;
```