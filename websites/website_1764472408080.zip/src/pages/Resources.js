```javascript
import React from 'react';
import FadeInSection from '../components/FadeInSection';

const resources = [
  {
    title: 'Understanding CPI baskets in Argentina',
    summary:
      'Breakdown of goods categories, weightings, and how shifts influence headline inflation. / Desglose de canastas y ponderaciones.',
    link: '#'
  },
  {
    title: 'Glossary: Inflation & FX terms / Glosario inflación y FX',
    summary:
      'Key terminology explained in English and Spanish to keep conversations clear. / Terminología bilingüe.',
    link: '#'
  },
  {
    title: 'Tracking ARS devaluation responsibly',
    summary:
      'Framework for monitoring official and parallel rates without speculation. / Cómo monitorear tasas de cambio de forma responsable.',
    link: '#'
  },
  {
    title: 'Budget resilience checklist / Lista de resiliencia',
    summary:
      'Step-by-step guide to align expenses with inflation expectations for Argentine households. / Guía paso a paso para alinear gastos.',
    link: '#'
  }
];

function Resources() {
  return (
    <div className="page">
      <section className="page-hero resources-hero">
        <div className="container page-hero-content">
          <FadeInSection className="page-hero-text" delay={0.1}>
            <p className="page-tag">Resources / Recursos</p>
            <h1>Knowledge hub for responsible decisions</h1>
            <p>
              Conocimiento financiero impulsado por tendencias. Nuestro repositorio bilingüe te ofrece artículos,
              glosarios y guías descargables para seguir el pulso inflacionario de Argentina.
            </p>
          </FadeInSection>
        </div>
      </section>

      <FadeInSection as="section" className="section" delay={0.15}>
        <div className="container resources-grid">
          {resources.map((item) => (
            <article key={item.title} className="resource-card">
              <h3>{item.title}</h3>
              <p>{item.summary}</p>
              <a className="resource-link" href={item.link}>
                Coming soon / Próximamente
              </a>
            </article>
          ))}
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section newsletter-section" delay={0.2}>
        <div className="container">
          <div className="newsletter-card">
            <h2>Stay Updated / Mantente al día</h2>
            <p>
              Double opt-in newsletter featuring inflation roundups, ARS insights, and course invitations. /
              Newsletter con resúmenes inflacionarios e invitaciones.
            </p>
            <a className="btn-primary" href="/#trial-form">
              Получить бесплатный пробный урок
            </a>
          </div>
        </div>
      </FadeInSection>
    </div>
  );
}

export default Resources;
```