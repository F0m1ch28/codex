```javascript
import React from 'react';
import FadeInSection from '../components/FadeInSection';

const modules = [
  {
    title: 'Module 1 • Setting the Stage',
    description:
      'Analyze Argentina’s inflation history and terminology. Dive into CPI construction and the role of expectations. / Analiza la historia inflacionaria y terminología.'
  },
  {
    title: 'Module 2 • Data in Motion',
    description:
      'Hands-on sessions using dashboards, inflation alerts, and FX correlations. / Talleres prácticos con tableros y correlaciones.'
  },
  {
    title: 'Module 3 • Scenario Planning',
    description:
      'Map best, moderate, and stress scenarios for your budget. Evaluate trade-offs with responsible methodology. / Diseña escenarios para tu presupuesto personal.'
  },
  {
    title: 'Module 4 • Accountability Lab',
    description:
      'Design personal indicators, track commitments, and build review rituals with community feedback. / Crea indicadores personales y rituales de seguimiento.'
  }
];

const audience = [
  'Profesionales jóvenes en Argentina que desean comprender el impacto de la inflación.',
  'Emprededoras y emprendedores que necesitan previsibilidad en costos y cashflow.',
  'Equipos de producto y datos que buscan interpretar señales macro en lenguaje claro.',
  'Personas que quieren fortalecer su criterio financiero sin promesas irreales.'
];

function Course() {
  return (
    <div className="page">
      <section className="page-hero course-hero">
        <div className="container page-hero-content">
          <FadeInSection className="page-hero-text" delay={0.1}>
            <p className="page-tag">Course • Curso</p>
            <h1>Inflation Literacy Starter</h1>
            <p>
              Conocimiento financiero impulsado por tendencias. De la información al aprendizaje: fortalece tu
              criterio financiero paso a paso. Accede a contenido bilingüe, ejercicios prácticos y comunidad.
            </p>
            <a className="btn-primary" href="#enroll">
              Получить бесплатный пробный урок
            </a>
          </FadeInSection>
        </div>
      </section>

      <FadeInSection as="section" className="section" delay={0.15}>
        <div className="container">
          <h2>Program Structure / Estructura</h2>
          <div className="modules-grid">
            {modules.map((module) => (
              <article key={module.title} className="module-card">
                <h3>{module.title}</h3>
                <p>{module.description}</p>
              </article>
            ))}
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section" delay={0.2}>
        <div className="container">
          <h2>Who joins? / ¿Quién se suma?</h2>
          <div className="audience-grid">
            {audience.map((item) => (
              <div key={item} className="audience-card">
                <p>{item}</p>
              </div>
            ))}
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section enroll-section" id="enroll" delay={0.2}>
        <div className="container">
          <div className="enroll-card">
            <h2>Enroll with confidence / Inscríbete con confianza</h2>
            <p>
              Información confiable que respalda elecciones responsables sobre tu dinero. Double opt-in ensures
              clarity and control. No promises, just verifiable data and structured learning.
            </p>
            <ul>
              <li>Live cohort each quarter / Cohorte en vivo cada trimestre.</li>
              <li>Dashboard templates and bilingual glossaries.</li>
              <li>Community sessions to practice decision-making.</li>
            </ul>
            <a className="btn-secondary" href="/contact">
              Talk to us / Hablemos
            </a>
          </div>
        </div>
      </FadeInSection>
    </div>
  );
}

export default Course;
```