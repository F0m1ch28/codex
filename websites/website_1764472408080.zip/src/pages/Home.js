```javascript
import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import FadeInSection from '../components/FadeInSection';

const promiseStatements = [
  'Datos verificados para planificar tu presupuesto.',
  'Decisiones responsables, objetivos nítidos.',
  'Conocimiento financiero impulsado por tendencias.',
  'Pasos acertados hoy, mejor futuro mañana.',
  'Análisis transparentes y datos de mercado para decidir con seguridad.',
  'Información confiable que respalda elecciones responsables sobre tu dinero.',
  'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
  'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.'
];

const testimonials = [
  {
    name: 'Lucía Fernández',
    role: 'Community Manager, Córdoba',
    quote:
      'Tu Progreso Hoy me ayuda a entender la inflación argentina con datos claros. Puedo planificar mis gastos con mayor serenidad.'
  },
  {
    name: 'Martín Rivas',
    role: 'Diseñador UX, Mendoza',
    quote:
      'Las visualizaciones y las alertas por email me permiten seguir el pulso del mercado sin información abrumadora.'
  },
  {
    name: 'Ana Beltrán',
    role: 'Emprendedora, Buenos Aires',
    quote:
      'El curso introductorio me dio fundamentos para evaluar mis decisiones financieras con responsabilidad.'
  }
];

function Home() {
  const [fxData, setFxData] = useState({ rate: null, timestamp: null, change: null });
  const [error, setError] = useState('');
  const [form, setForm] = useState({ name: '', email: '', confirmEmail: '', consent: false, policy: false });
  const [formError, setFormError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    let isMounted = true;

    async function fetchFX() {
      try {
        const response = await fetch('https://api.exchangerate.host/latest?base=ARS&symbols=USD');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const json = await response.json();
        if (isMounted && json?.rates?.USD) {
          setFxData({
            rate: json.rates.USD,
            timestamp: json.date,
            change: null
          });
        }
      } catch (err) {
        if (isMounted) {
          setError('Unable to connect to live exchange feed. Showing latest cached insight.');
          // Provide fallback value
          setFxData({
            rate: 0.0012,
            timestamp: '2024-02-01',
            change: null
          });
        }
      }
    }

    fetchFX();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setFormError('');
    if (!form.name || !form.email || !form.confirmEmail) {
      setFormError('Please complete all fields / Por favor completa todos los campos.');
      return;
    }
    if (form.email !== form.confirmEmail) {
      setFormError('Emails must match / Los correos deben coincidir.');
      return;
    }
    if (!form.consent || !form.policy) {
      setFormError('Please provide the required consents / Debes aceptar los consentimientos.');
      return;
    }
    navigate('/thank-you', {
      state: {
        email: form.email,
        name: form.name,
        source: 'home-form'
      }
    });
  };

  const fxRateDisplay = useMemo(() => {
    if (!fxData.rate) return 'Loading...';
    return `1 ARS → ${(fxData.rate).toFixed(6)} USD`;
  }, [fxData.rate]);

  return (
    <div className="home">
      <section className="hero">
        <div className="hero-overlay" aria-hidden="true" />
        <div className="container hero-content">
          <FadeInSection className="hero-text" delay={0.1}>
            <p className="hero-pill">Argentina • Educación financiera responsable</p>
            <h1>
              Tu Progreso Hoy <br />
              <span className="highlight">Data-driven learning for confident decisions</span>
            </h1>
            <p className="hero-description">
              Datos verificados para planificar tu presupuesto. Conocimiento financiero impulsado por tendencias.
              Análisis transparentes y datos de mercado para decidir con seguridad. Información confiable que
              respalda elecciones responsables sobre tu dinero.
            </p>
            <div className="hero-actions">
              <a className="btn-primary" href="#insights">
                Explore Insights / Explora
              </a>
              <a className="btn-outline" href="#course-overview">
                View Course / Ver Curso
              </a>
            </div>
            <p className="hero-sub">
              Plataforma educativa con datos esenciales, sin asesoría financiera directa.
            </p>
          </FadeInSection>
          <FadeInSection className="hero-card" delay={0.2} aria-live="polite">
            <h2>ARS → USD</h2>
            <p className="hero-rate">{fxRateDisplay}</p>
            <p className="hero-date">
              {fxData.timestamp ? `Last update / Última actualización: ${fxData.timestamp}` : 'Loading...'}
            </p>
            {error && <p className="hero-error">{error}</p>}
            <div className="hero-meta">
              <h3>Why it matters</h3>
              <ul>
                <li>Conoce cómo la inflación impacta tu día a día.</li>
                <li>Monitoriza tendencias cambiarias con contexto.</li>
                <li>Planifica metas con información verificable.</li>
              </ul>
            </div>
          </FadeInSection>
        </div>
        <div className="hero-flag" aria-hidden="true">
          <span className="flag-strip strip-one" />
          <span className="flag-strip strip-two" />
          <span className="flag-strip strip-three" />
        </div>
      </section>

      <FadeInSection as="section" className="section" id="insights" delay={0.1}>
        <div className="container">
          <div className="section-header">
            <h2>Market Pulse / Pulso del Mercado</h2>
            <p>
              Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
              Pasos acertados hoy, mejor futuro mañana.
            </p>
          </div>
          <div className="insights-grid">
            {promiseStatements.map((statement, index) => (
              <article key={statement} className="insight-card">
                <div className="insight-number" aria-hidden="true">
                  {index + 1}
                </div>
                <p>{statement}</p>
              </article>
            ))}
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section parallax-section" id="course-overview" delay={0.15}>
        <div className="container">
          <div className="section-header">
            <h2>Course Overview / Visión del Curso</h2>
            <p>
              De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
              Información bilingüe y escenarios reales en Argentina.
            </p>
          </div>
          <div className="course-grid">
            <div className="course-card">
              <h3>Module 1: Inflation Foundations</h3>
              <p>
                Understand CPI, core inflation, and how ARS dynamics influence purchasing power. /
                Comprende los indicadores clave y su impacto.
              </p>
              <ul>
                <li>Conceptos esenciales explicados en dos idiomas.</li>
                <li>Estudios de caso históricos argentinos.</li>
              </ul>
            </div>
            <div className="course-card">
              <h3>Module 2: Data Literacy</h3>
              <p>
                Learn to interpret inflation dashboards, FX trackers, and official releases. /
                Aprende a interpretar tableros y reportes.
              </p>
              <ul>
                <li>Lectura crítica de datos y gráficos.</li>
                <li>Construye tu propio plan de monitoreo.</li>
              </ul>
            </div>
            <div className="course-card">
              <h3>Module 3: Personal Budget Mapping</h3>
              <p>
                Apply verified datasets to create a flexible, responsible budget roadmap. /
                Traduce los datos en acciones concretas.
              </p>
              <ul>
                <li>Simulaciones interactivas.</li>
                <li>Guía de decisiones responsables.</li>
              </ul>
            </div>
            <div className="course-card">
              <h3>Module 4: Planning Beyond the Curve</h3>
              <p>
                Identify signals, manage uncertainty, and prepare for cost-of-living shifts. /
                Anticipa cambios y fortalece tus objetivos.
              </p>
              <ul>
                <li>Técnicas de resiliencia financiera.</li>
                <li>Plan de seguimiento de tendencias.</li>
              </ul>
            </div>
          </div>
          <div className="cta-box">
            <h3>Ready to begin? / ¿Listo para empezar?</h3>
            <p>
              Información confiable que respalda elecciones responsables sobre tu dinero. Join the
              double opt-in list to access the introductory lesson.
            </p>
            <a className="btn-primary" href="#trial-form">
              Получить бесплатный пробный урок
            </a>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section" delay={0.15}>
        <div className="container">
          <div className="section-header">
            <h2>Voices / Voces</h2>
            <p>
              Análisis transparentes y datos de mercado para decidir con seguridad. Hear from peers
              across Argentina strengthening their financial literacy.
            </p>
          </div>
          <div className="testimonials-grid">
            {testimonials.map((item) => (
              <blockquote key={item.name} className="testimonial-card">
                <p className="testimonial-quote">“{item.quote}”</p>
                <footer>
                  <span className="testimonial-name">{item.name}</span>
                  <span className="testimonial-role">{item.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section form-section" id="trial-form" delay={0.2}>
        <div className="container form-container">
          <div className="form-intro">
            <h2>Join the learning experience / Súmate</h2>
            <p>
              Double opt-in ensures you receive only what you confirm. Once you submit, check your
              inbox to validate your email and unlock the free trial lesson.
            </p>
            <ul>
              <li>Información enviada en inglés y español.</li>
              <li>Alertas sobre inflación argentina y FX ARS → USD.</li>
              <li>Sin promesas irreales, todo se basa en datos verificables.</li>
            </ul>
          </div>
          <form className="form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Full Name / Nombre completo</label>
              <input
                id="name"
                name="name"
                type="text"
                value={form.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="confirmEmail">Confirm Email / Confirmar correo</label>
              <input
                id="confirmEmail"
                name="confirmEmail"
                type="email"
                value={form.confirmEmail}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group checkbox-group">
              <input
                id="consent"
                name="consent"
                type="checkbox"
                checked={form.consent}
                onChange={handleChange}
                required
              />
              <label htmlFor="consent">
                I agree to receive the verification email (double opt-in). / Acepto recibir el correo
                de verificación (doble opt-in).
              </label>
            </div>
            <div className="form-group checkbox-group">
              <input
                id="policy"
                name="policy"
                type="checkbox"
                checked={form.policy}
                onChange={handleChange}
                required
              />
              <label htmlFor="policy">
                I have read the <a href="/privacy">Privacy Policy</a> and <a href="/terms">Terms</a>.
              </label>
            </div>
            {formError && <p className="form-error" role="alert">{formError}</p>}
            <button type="submit" className="btn-primary full-width">
              Получить бесплатный пробный урок
            </button>
          </form>
        </div>
      </FadeInSection>
    </div>
  );
}

export default Home;
```