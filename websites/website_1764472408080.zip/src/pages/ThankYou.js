```javascript
import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import FadeInSection from '../components/FadeInSection';

function ThankYou() {
  const location = useLocation();
  const state = location.state || {};
  const email = state.email;

  return (
    <div className="page">
      <FadeInSection as="section" className="section thankyou-section" delay={0.1}>
        <div className="container">
          <h1>Thank you! / ¡Gracias!</h1>
          <p>
            We just sent a confirmation email to {email || 'your inbox'}. Please open it and confirm to finalize
            the double opt-in process. / Te enviamos un email de confirmación, ábrelo y confirma para finalizar.
          </p>
          <p>
            Once verified, you will receive access to the introductory lesson and our next inflation briefing.
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
          <Link className="btn-primary" to="/">
            Back to Home / Volver al inicio
          </Link>
        </div>
      </FadeInSection>
    </div>
  );
}

export default ThankYou;
```