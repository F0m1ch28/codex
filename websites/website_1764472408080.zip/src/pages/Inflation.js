```javascript
import React from 'react';
import FadeInSection from '../components/FadeInSection';

const methodologySteps = [
  {
    title: 'Data Integrity',
    description:
      'We triangulate official INDEC releases with trusted independent observatories. / Triangulamos los datos oficiales de INDEC con observatorios independientes.'
  },
  {
    title: 'Context Layers',
    description:
      'Inflation numbers are paired with FX movements, wage negotiations, and regional price baskets. / Cruzamos inflación con movimiento cambiario, paritarias y canastas regionales.'
  },
  {
    title: 'Forward Looking Signals',
    description:
      'Monthly reports highlight sequential momentum, base effects, and short-term alerts. / Reportes mensuales con momentum secuencial, efectos base y alertas.'
  }
];

const cpiData = [
  { month: 'Sep 23', value: 12.7 },
  { month: 'Oct 23', value: 8.3 },
  { month: 'Nov 23', value: 12.1 },
  { month: 'Dec 23', value: 25.5 },
  { month: 'Jan 24', value: 20.6 },
  { month: 'Feb 24', value: 13.2 }
];

const fxData = [
  { month: 'Sep 23', value: 0.0029 },
  { month: 'Oct 23', value: 0.0028 },
  { month: 'Nov 23', value: 0.0026 },
  { month: 'Dec 23', value: 0.0012 },
  { month: 'Jan 24', value: 0.0012 },
  { month: 'Feb 24', value: 0.0011 }
];

const faqItems = [
  {
    question: 'Do you provide financial advice? / ¿Brindan asesoramiento?',
    answer:
      'No. Мы не предоставляем финансовые услуги. We provide educational content and market data so you can build your own understanding. No ofrecemos asesoría financiera directa; los datos son para aprendizaje responsable.'
  },
  {
    question: 'How often is the data updated? / ¿Cada cuánto actualizan?',
    answer:
      'Key inflation dashboards refresh monthly following INDEC publications. FX monitors update daily, with alerts when volatility triggers thresholds. / Actualizamos tableros mensuales y monitores diarios.'
  },
  {
    question: 'Can I download the datasets? / ¿Puedo descargar datasets?',
    answer:
      'Yes, subscribers receive CSV snapshots and methodology notes. / Sí, los suscriptores reciben CSV y notas metodológicas.'
  },
  {
    question: 'Is the content bilingual? / ¿Contenido bilingüe?',
    answer:
      'Yes, all learning materials are presented in English and Español to serve diverse audiences in Argentina. / Sí, todo está en inglés y español.'
  }
];

function Inflation() {
  return (
    <div className="page">
      <section className="page-hero">
        <div className="container page-hero-content">
          <FadeInSection className="page-hero-text" delay={0.1}>
            <p className="page-tag">Inflation Intelligence / Inteligencia inflacionaria</p>
            <h1>Transparent Methodology, Local Context</h1>
            <p>
              Datos verificados para planificar tu presupuesto. Análisis transparentes y datos de mercado
              para decidir con seguridad. Descubre cómo traducimos series históricas y señales presentes en
              conocimiento accionable.
            </p>
          </FadeInSection>
        </div>
      </section>

      <FadeInSection as="section" className="section" delay={0.15}>
        <div className="container">
          <h2>How we build the dashboards / Cómo construimos los tableros</h2>
          <div className="methodology-grid">
            {methodologySteps.map((step) => (
              <article key={step.title} className="method-card">
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section" delay={0.2}>
        <div className="container">
          <h2>CPI Momentum / Dinámica IPC</h2>
          <p>
            La siguiente visual resume la variación mensual del IPC general argentino, destacando el salto
            de diciembre tras la devaluación y la desaceleración posterior. / The chart shows monthly CPI
            momentum, underlining shifts after currency moves.
          </p>
          <div className="chart-wrapper" role="img" aria-label="Line chart showing monthly CPI percentages">
            <svg viewBox="0 0 320 200" preserveAspectRatio="xMidYMid meet">
              <defs>
                <linearGradient id="cpiGradient" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" />
                  <stop offset="100%" stopColor="#1F3A6F" stopOpacity="0.3" />
                </linearGradient>
              </defs>
              <polyline
                fill="none"
                stroke="url(#cpiGradient)"
                strokeWidth="3"
                points={cpiData
                  .map((item, index) => {
                    const x = (index / (cpiData.length - 1)) * 300 + 10;
                    const y = 180 - (item.value / 30) * 160;
                    return `${x},${y}`;
                  })
                  .join(' ')}
              />
              {cpiData.map((item, index) => {
                const x = (index / (cpiData.length - 1)) * 300 + 10;
                const y = 180 - (item.value / 30) * 160;
                return (
                  <g key={item.month}>
                    <circle cx={x} cy={y} r="4" fill="#F8FAFC" stroke="#2563EB" strokeWidth="3" />
                    <text x={x} y={y - 12} textAnchor="middle" className="chart-text">
                      {item.value}%
                    </text>
                    <text x={x} y={190} textAnchor="middle" className="chart-axis">
                      {item.month}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section" delay={0.2}>
        <div className="container">
          <h2>ARS → USD context</h2>
          <p>
            FX stability is key for expectations. We depict reference rates to highlight volatility pockets. /
            La estabilidad cambiaria es clave para las expectativas. Visualizamos tasas de referencia.
          </p>
          <div className="chart-wrapper" role="img" aria-label="Line chart of ARS to USD reference rate">
            <svg viewBox="0 0 320 200" preserveAspectRatio="xMidYMid meet">
              <defs>
                <linearGradient id="fxGradient" x1="0" x2="1" y1="0" y2="0">
                  <stop offset="0%" stopColor="#E2E8F0" />
                  <stop offset="100%" stopColor="#2563EB" stopOpacity="0.6" />
                </linearGradient>
              </defs>
              <polyline
                fill="none"
                stroke="url(#fxGradient)"
                strokeWidth="3"
                points={fxData
                  .map((item, index) => {
                    const x = (index / (fxData.length - 1)) * 300 + 10;
                    const y = 180 - ((item.value - 0.001) / 0.002) * 160;
                    return `${x},${y}`;
                  })
                  .join(' ')}
              />
              {fxData.map((item, index) => {
                const x = (index / (fxData.length - 1)) * 300 + 10;
                const y = 180 - ((item.value - 0.001) / 0.002) * 160;
                return (
                  <g key={item.month}>
                    <circle cx={x} cy={y} r="4" fill="#0F172A" stroke="#E2E8F0" strokeWidth="3" />
                    <text x={x} y={y - 12} textAnchor="middle" className="chart-text">
                      {item.value.toFixed(4)}
                    </text>
                    <text x={x} y={190} textAnchor="middle" className="chart-axis">
                      {item.month}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
          <div className="context-box">
            <h3>Interpretación / Interpretation</h3>
            <ul>
              <li>
                La devaluación de diciembre generó una nueva base para la inflación núcleo. / December
                devaluation reset the base for core inflation.
              </li>
              <li>
                Monitorizamos el crawling peg y diferenciales con dólares alternativos. / We track crawling peg
                and parallel spreads.
              </li>
              <li>
                Alertas semanales destacan desvíos frente a metas de política monetaria. / Weekly alerts highlight
                deviations versus monetary targets.
              </li>
            </ul>
          </div>
        </div>
      </FadeInSection>

      <FadeInSection as="section" className="section" delay={0.2}>
        <div className="container">
          <h2>FAQ</h2>
          <div className="faq-list">
            {faqItems.map((item) => (
              <details key={item.question} className="faq-item">
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </FadeInSection>
    </div>
  );
}

export default Inflation;
```