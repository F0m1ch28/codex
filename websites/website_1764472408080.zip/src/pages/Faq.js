```javascript
import React from 'react';

const questions = [
  {
    q: 'What makes Tu Progreso Hoy different?',
    a: 'We combine bilingual education, verified inflation data, and local context specific to Argentina. Datos verificados para planificar tu presupuesto.'
  },
  {
    q: 'Is the course suitable for beginners?',
    a: 'Yes. Content is designed for people starting their financial learning journey. Decisiones responsables, objetivos nítidos.'
  },
  {
    q: 'How does the double opt-in work?',
    a: 'You submit the form, receive a confirmation email, and activate your subscription only after confirming. This ensures informed consent.'
  },
  {
    q: 'Do you track personal investments?',
    a: 'No. Análisis transparentes y datos de mercado para decidir con seguridad, pero sin seguimiento personalizado. Мы не предоставляем финансовые услуги.'
  }
];

function Faq() {
  return (
    <div className="legal-page container">
      <h1>Frequently Asked Questions</h1>
      {questions.map((item) => (
        <div key={item.q} className="faq-block">
          <h2>{item.q}</h2>
          <p>{item.a}</p>
        </div>
      ))}
    </div>
  );
}

export default Faq;
```