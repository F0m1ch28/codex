```javascript
import React, { useState } from 'react';
import FadeInSection from '../components/FadeInSection';

function Contact() {
  const [message, setMessage] = useState({ name: '', email: '', subject: '', inquiry: '', consent: false });
  const [feedback, setFeedback] = useState('');

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setMessage((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!message.name || !message.email || !message.subject || !message.inquiry) {
      setFeedback('Please complete all required fields / Completa todos los campos requeridos.');
      return;
    }
    if (!message.consent) {
      setFeedback('Please confirm consent / Confirma el consentimiento.');
      return;
    }
    setFeedback('Thank you! We will reply within two business days. / ¡Gracias! Responderemos en 2 días hábiles.');
    setMessage({ name: '', email: '', subject: '', inquiry: '', consent: false });
  };

  return (
    <div className="page">
      <section className="page-hero contact-hero">
        <div className="container page-hero-content">
          <FadeInSection className="page-hero-text" delay={0.1}>
            <p className="page-tag">Contact / Contacto</p>
            <h1>Connect with Tu Progreso Hoy</h1>
            <p>
              Información confiable que respalda elecciones responsables sobre tu dinero. Estamos en Buenos
              Aires, conectados con toda Argentina.
            </p>
          </FadeInSection>
        </div>
      </section>

      <FadeInSection as="section" className="section" delay={0.2}>
        <div className="container contact-grid">
          <div>
            <h2>Reach us</h2>
            <p>
              Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina<br />
              <a href="tel:+541155551234">+54 11 5555-1234</a><br />
              <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
            </p>
            <p>
              Office hours / Horario: Monday to Friday, 9:00 – 18:00 ART.
            </p>
            <div className="map-wrapper">
              <iframe
                title="Map of Tu Progreso Hoy office"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1641.4638779059557!2d-58.38159259580037!3d-34.60373821152165!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95a3352c6b5b23f9%3A0xa24ce575a4fcf15a!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1706800000000!5m2!1sen!2sar"
                allowFullScreen=""
                loading="lazy"
              />
            </div>
          </div>
          <form className="form" onSubmit={handleSubmit} noValidate>
            <h2>Send us a note / Envíanos un mensaje</h2>
            <div className="form-group">
              <label htmlFor="contact-name">Name / Nombre</label>
              <input
                id="contact-name"
                name="name"
                type="text"
                value={message.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="contact-email">Email</label>
              <input
                id="contact-email"
                name="email"
                type="email"
                value={message.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="contact-subject">Subject / Asunto</label>
              <input
                id="contact-subject"
                name="subject"
                type="text"
                value={message.subject}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="contact-inquiry">Message / Mensaje</label>
              <textarea
                id="contact-inquiry"
                name="inquiry"
                rows="6"
                value={message.inquiry}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group checkbox-group">
              <input
                id="contact-consent"
                name="consent"
                type="checkbox"
                checked={message.consent}
                onChange={handleChange}
                required
              />
              <label htmlFor="contact-consent">
                I agree to the <a href="/privacy">Privacy Policy</a> and understand this is an educational platform.
              </label>
            </div>
            {feedback && <p className="form-feedback">{feedback}</p>}
            <button type="submit" className="btn-primary">
              Submit / Enviar
            </button>
          </form>
        </div>
      </FadeInSection>
    </div>
  );
}

export default Contact;
```