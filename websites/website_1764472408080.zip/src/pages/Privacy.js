```javascript
import React from 'react';

function Privacy() {
  return (
    <div className="legal-page container">
      <h1>Privacy Policy</h1>
      <p>Effective date: February 2024</p>

      <h2>Information We Collect</h2>
      <p>
        We collect names, emails, and optional profile information when you subscribe or contact us. Analytics data is
        gathered using cookies only if you consent via the cookie banner.
      </p>

      <h2>Use of Information</h2>
      <p>
        Data is used to deliver educational content, send opt-in newsletters, improve analytics, and respond to
        inquiries. Мы не предоставляем финансовые услуги y no vendemos tus datos.
      </p>

      <h2>Legal Basis</h2>
      <p>
        Processing is based on consent and legitimate interest in providing educational services. You may withdraw
        consent at any time via unsubscribe links.
      </p>

      <h2>Data Storage</h2>
      <p>
        Information is stored securely with providers that comply with international standards. We minimize retention
        and delete inactive accounts after 24 months.
      </p>

      <h2>Your Rights</h2>
      <p>
        You can request access, correction, deletion, or portability of your data. Contact
        hola@tuprogresohoy.com to exercise these rights.
      </p>

      <h2>Cookies</h2>
      <p>
        Cookies are optional. You can accept or decline through the cookie banner. Analytics cookies help us understand
        engagement with inflation reports and course materials.
      </p>

      <h2>Contact</h2>
      <p>
        If you have questions, email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
      </p>
    </div>
  );
}

export default Privacy;
```