```javascript
import React from 'react';

function Cookies() {
  return (
    <div className="legal-page container">
      <h1>Cookie Policy</h1>
      <p>
        This policy explains how Tu Progreso Hoy uses cookies. Cookies are small text files stored on your device to
        enhance your experience.
      </p>

      <h2>Types of Cookies</h2>
      <ul>
        <li>
          Essential: Required for security and preference management. / Esenciales para seguridad y preferencias.
        </li>
        <li>
          Analytics (opt-in): Help us understand page performance. Activated only if you accept. / Analíticas (opcional).
        </li>
        <li>
          Functional: Remember your language display choice. / Funcionales: Recuerdan tu idioma preferido.
        </li>
      </ul>

      <h2>Managing Preferences</h2>
      <p>
        Use the on-site cookie banner to accept or decline. You can revisit this decision by clearing your browser
        cookies or contacting us.
      </p>

      <h2>Contact</h2>
      <p>
        For questions about cookies, email <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>.
      </p>
    </div>
  );
}

export default Cookies;
```