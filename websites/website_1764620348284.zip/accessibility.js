export const announceLiveMessage = (message, politeness = 'polite') => {
  if (typeof document === 'undefined') return;
  let liveRegion = document.getElementById('tph-live-region');
  if (!liveRegion) {
    liveRegion = document.createElement('div');
    liveRegion.setAttribute('id', 'tph-live-region');
    liveRegion.setAttribute('aria-live', politeness);
    liveRegion.setAttribute('aria-atomic', 'true');
    liveRegion.style.position = 'absolute';
    liveRegion.style.width = '1px';
    liveRegion.style.height = '1px';
    liveRegion.style.margin = '-1px';
    liveRegion.style.border = '0';
    liveRegion.style.padding = '0';
    liveRegion.style.clip = 'rect(0 0 0 0)';
    liveRegion.style.overflow = 'hidden';
    document.body.appendChild(liveRegion);
  }
  liveRegion.textContent = '';
  window.setTimeout(() => {
    liveRegion.textContent = message;
  }, 100);
};

export const setDocumentLanguage = (lang) => {
  if (typeof document === 'undefined') return;
  document.documentElement.lang = lang;
};

export const focusFirstInteractive = (container) => {
  if (!container) return;
  const focusableSelectors =
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
  const target = container.querySelector(focusableSelectors);
  if (target) target.focus();
};