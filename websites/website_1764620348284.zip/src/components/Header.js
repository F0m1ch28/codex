import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import Button from './Button';
import LanguageToggle from './LanguageToggle';
import { useIntl } from 'react-intl';

const Header = () => {
  const { formatMessage } = useIntl();
  const [open, setOpen] = useState(false);

  const navItems = [
    { to: '/', label: formatMessage({ id: 'nav.home' }) },
    { to: '/inflation', label: formatMessage({ id: 'nav.inflation' }) },
    { to: '/course', label: formatMessage({ id: 'nav.course' }) },
    { to: '/resources', label: formatMessage({ id: 'nav.resources' }) },
    { to: '/contact', label: formatMessage({ id: 'nav.contact' }) }
  ];

  return (
    <header className="header" role="banner">
      <div className="container header-inner">
        <NavLink to="/" className="header-logo">
          {formatMessage({ id: 'brand.name' })}
        </NavLink>
        <nav className="header-nav" aria-label="Primary navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => (isActive ? 'active' : undefined)}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="header-actions" style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
          <LanguageToggle />
          <NavLink to="/course" style={{ textDecoration: 'none' }}>
            <Button variant="secondary" size="sm">
              {formatMessage({ id: 'course.cta' })}
            </Button>
          </NavLink>
          <button
            className="hamburger"
            aria-label="Toggle navigation"
            aria-expanded={open}
            onClick={() => setOpen((prev) => !prev)}
          >
            <span />
          </button>
        </div>
      </div>
      {open && (
        <div className="mobile-menu" role="dialog" aria-label="Mobile navigation">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setOpen(false)}
            >
              {item.label}
            </NavLink>
          ))}
          <NavLink to="/course" onClick={() => setOpen(false)}>
            <Button variant="secondary" size="md" style={{ width: '100%' }}>
              {formatMessage({ id: 'course.cta' })}
            </Button>
          </NavLink>
        </div>
      )}
    </header>
  );
};

export default Header;