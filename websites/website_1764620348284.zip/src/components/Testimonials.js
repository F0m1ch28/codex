import React from 'react';
import Card from './Card';
import { useIntl } from 'react-intl';

const Testimonials = () => {
  const { formatMessage } = useIntl();

  const testimonials = [
    {
      id: 'ana',
      quote: 'testimonial.ana.quote',
      role: 'testimonial.ana.role',
      name: 'Ana'
    },
    {
      id: 'emilio',
      quote: 'testimonial.emilio.quote',
      role: 'testimonial.emilio.role',
      name: 'Emilio'
    },
    {
      id: 'sofia',
      quote: 'testimonial.sofia.quote',
      role: 'testimonial.sofia.role',
      name: 'Sofía'
    }
  ];

  return (
    <section className="py-16 section-light">
      <div className="container">
        <div className="mb-8">
          <h2 className="section-heading">
            {formatMessage({ id: 'home.testimonials.title' })}
          </h2>
          <p className="section-subtitle">
            {formatMessage({ id: 'home.testimonials.subtitle' })}
          </p>
        </div>
        <div className="testimonial-grid">
          {testimonials.map((item) => (
            <Card className="testimonial-card" key={item.id}>
              <p className="testimonial-quote">
                “{formatMessage({ id: item.quote })}”
              </p>
              <div>
                <p className="testimonial-author">{item.name}</p>
                <p className="testimonial-role">
                  {formatMessage({ id: item.role })}
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;