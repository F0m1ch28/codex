import React, { useState } from 'react';
import Button from './Button';
import { useIntl } from 'react-intl';
import { containsBannedWords } from '../utils/bannedWords';

const ContactForm = () => {
  const { formatMessage } = useIntl();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    topic: 'General question',
    message: '',
    consent: false
  });
  const [status, setStatus] = useState({ type: 'idle', message: '' });

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!formData.consent) {
      setStatus({ type: 'error', message: formatMessage({ id: 'contact.form.error.optIn' }) });
      return;
    }

    if (containsBannedWords(`${formData.topic} ${formData.message}`)) {
      setStatus({ type: 'error', message: formatMessage({ id: 'contact.form.error.banned' }) });
      return;
    }

    try {
      const response = await fetch(
        `https://formspree.io/f/${process.env.REACT_APP_FORMSPREE_ID}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          },
          body: JSON.stringify({
            name: formData.name,
            email: formData.email,
            topic: formData.topic,
            message: formData.message,
            source: 'Contact page'
          })
        }
      );

      if (response.ok) {
        setStatus({ type: 'success', message: formatMessage({ id: 'contact.form.success' }) });
        setFormData({
          name: '',
          email: '',
          topic: 'General question',
          message: '',
          consent: false
        });
      } else {
        throw new Error('Failed');
      }
    } catch (error) {
      setStatus({ type: 'error', message: formatMessage({ id: 'contact.form.error' }) });
    }
  };

  return (
    <form className="form-grid" onSubmit={handleSubmit} noValidate>
      <div className="form-grid two-columns">
        <div>
          <label htmlFor="contact-name">{formatMessage({ id: 'contact.form.name' })}</label>
          <input
            id="contact-name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            placeholder="Florencia Díaz"
          />
        </div>
        <div>
          <label htmlFor="contact-email">{formatMessage({ id: 'contact.form.email' })}</label>
          <input
            id="contact-email"
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            placeholder="hola@ejemplo.com"
          />
        </div>
      </div>
      <div>
        <label htmlFor="contact-topic">{formatMessage({ id: 'contact.form.topic' })}</label>
        <select
          id="contact-topic"
          name="topic"
          value={formData.topic}
          onChange={handleChange}
        >
          <option value="General question">
            {formatMessage({ id: 'contact.form.topic.option1' })}
          </option>
          <option value="Course enrollment">
            {formatMessage({ id: 'contact.form.topic.option2' })}
          </option>
          <option value="Press & media">
            {formatMessage({ id: 'contact.form.topic.option3' })}
          </option>
        </select>
      </div>
      <div>
        <label htmlFor="contact-message">{formatMessage({ id: 'contact.form.message' })}</label>
        <textarea
          id="contact-message"
          name="message"
          value={formData.message}
          onChange={handleChange}
          placeholder="Contanos en qué podemos ayudarte..."
        />
      </div>
      <div>
        <label style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <input
            type="checkbox"
            name="consent"
            checked={formData.consent}
            onChange={handleChange}
          />
          {formatMessage({ id: 'contact.form.consent' })}
        </label>
      </div>
      {status.message && (
        <p className={status.type === 'error' ? 'error-text' : 'success-text'}>{status.message}</p>
      )}
      <Button type="submit" variant="primary">
        {formatMessage({ id: 'contact.form.submit' })}
      </Button>
    </form>
  );
};

export default ContactForm;