import React, { useEffect, useRef, useState } from 'react';
import Button from './Button';
import { useIntl } from 'react-intl';
import { focusFirstInteractive } from '../../accessibility';

const STORAGE_KEY = 'tph-disclaimer-ack';

const DisclaimerModal = () => {
  const { formatMessage } = useIntl();
  const [open, setOpen] = useState(false);
  const modalRef = useRef(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const acknowledged = localStorage.getItem(STORAGE_KEY);
    if (!acknowledged) {
      setOpen(true);
    }
  }, []);

  useEffect(() => {
    if (open && modalRef.current) {
      focusFirstInteractive(modalRef.current);
    }
  }, [open]);

  const handleClose = () => {
    setOpen(false);
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, 'true');
    }
  };

  if (!open) return null;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal" ref={modalRef}>
        <h3>{formatMessage({ id: 'disclaimer.title' })}</h3>
        <p>{formatMessage({ id: 'disclaimer.body' })}</p>
        <Button variant="secondary" size="md" onClick={handleClose}>
          {formatMessage({ id: 'disclaimer.accept' })}
        </Button>
      </div>
    </div>
  );
};

export default DisclaimerModal;