import React, { useEffect, useState } from 'react';
import Button from './Button';
import { useIntl } from 'react-intl';

const STORAGE_KEY = 'tph-cookie-preferences';

const CookieBanner = () => {
  const { formatMessage } = useIntl();
  const [visible, setVisible] = useState(false);
  const [preferences, setPreferences] = useState({
    necessary: true,
    analytics: false,
    marketing: false
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setVisible(true);
    } else {
      try {
        const parsed = JSON.parse(stored);
        setPreferences({ necessary: true, ...parsed });
      } catch (error) {
        setVisible(true);
      }
    }
  }, []);

  const savePreferences = (newPrefs) => {
    if (typeof window === 'undefined') return;
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ analytics: newPrefs.analytics, marketing: newPrefs.marketing })
    );
  };

  const handleAcceptAll = () => {
    const updated = { necessary: true, analytics: true, marketing: true };
    setPreferences(updated);
    savePreferences(updated);
    setVisible(false);
  };

  const handleDecline = () => {
    const updated = { ...preferences, analytics: false, marketing: false };
    setPreferences(updated);
    savePreferences(updated);
    setVisible(false);
  };

  const handleSave = () => {
    savePreferences(preferences);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div>
        <h3>{formatMessage({ id: 'cookie.title' })}</h3>
        <p>{formatMessage({ id: 'cookie.description' })}</p>
      </div>
      <div className="cookie-options">
        <label>
          <input type="checkbox" checked disabled />
          Necesarias (always on)
        </label>
        <label>
          <input
            type="checkbox"
            checked={preferences.analytics}
            onChange={(e) =>
              setPreferences((prev) => ({
                ...prev,
                analytics: e.target.checked
              }))
            }
          />
          {formatMessage({ id: 'cookie.analytics' })}
        </label>
        <label>
          <input
            type="checkbox"
            checked={preferences.marketing}
            onChange={(e) =>
              setPreferences((prev) => ({
                ...prev,
                marketing: e.target.checked
              }))
            }
          />
          {formatMessage({ id: 'cookie.marketing' })}
        </label>
      </div>
      <div className="cookie-actions">
        <Button variant="secondary" size="sm" onClick={handleAcceptAll}>
          {formatMessage({ id: 'cookie.acceptAll' })}
        </Button>
        <Button variant="primary" size="sm" onClick={handleSave}>
          {formatMessage({ id: 'cookie.save' })}
        </Button>
        <Button variant="outline" size="sm" onClick={handleDecline}>
          {formatMessage({ id: 'cookie.decline' })}
        </Button>
      </div>
    </div>
  );
};

export default CookieBanner;