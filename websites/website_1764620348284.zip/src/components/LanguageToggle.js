import React from 'react';
import Button from './Button';
import { useLanguage } from '../context/LanguageContext';
import { useIntl } from 'react-intl';

const LanguageToggle = () => {
  const { locale, setLocale } = useLanguage();
  const { formatMessage } = useIntl();

  const handleToggle = (lang) => {
    if (lang !== locale) {
      setLocale(lang);
    }
  };

  return (
    <div className="language-toggle" aria-label="Language toggle">
      <Button
        variant={locale === 'en' ? 'secondary' : 'outline'}
        size="sm"
        onClick={() => handleToggle('en')}
        aria-pressed={locale === 'en'}
      >
        {formatMessage({ id: 'languageToggle.en' })}
      </Button>
      <Button
        variant={locale === 'es' ? 'secondary' : 'outline'}
        size="sm"
        onClick={() => handleToggle('es')}
        aria-pressed={locale === 'es'}
      >
        {formatMessage({ id: 'languageToggle.es' })}
      </Button>
    </div>
  );
};

export default LanguageToggle;