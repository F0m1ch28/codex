import React, { useEffect, useMemo, useState } from 'react';
import axios from 'axios';
import { ResponsiveContainer, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';
import { useIntl } from 'react-intl';

const DataCard = () => {
  const { formatMessage } = useIntl();
  const [data, setData] = useState([]);
  const [latest, setLatest] = useState(null);
  const [change, setChange] = useState(null);
  const [updated, setUpdated] = useState(null);
  const [error, setError] = useState(false);

  const formatter = useMemo(
    () =>
      new Intl.NumberFormat(undefined, {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 4
      }),
    []
  );

  useEffect(() => {
    const fetchRates = async () => {
      const today = new Date();
      const end = today.toISOString().split('T')[0];
      const startDate = new Date();
      startDate.setDate(today.getDate() - 14);
      const start = startDate.toISOString().split('T')[0];

      try {
        const response = await axios.get('https://api.exchangerate.host/timeseries', {
          params: {
            base: 'ARS',
            symbols: 'USD',
            start_date: start,
            end_date: end
          }
        });

        const rates = response.data.rates || {};
        const parsed = Object.keys(rates)
          .map((date) => {
            const value = rates[date].USD;
            return {
              date,
              usd: Number((value * 100).toFixed(4))
            };
          })
          .sort((a, b) => new Date(a.date) - new Date(b.date));

        if (parsed.length > 0) {
          setData(parsed);
          setLatest(parsed[parsed.length - 1].usd);
          if (parsed.length >= 2) {
            const first = parsed[0].usd;
            const last = parsed[parsed.length - 1].usd;
            const diff = ((last - first) / first) * 100;
            setChange(diff.toFixed(2));
          }
          setUpdated(parsed[parsed.length - 1].date);
        }
      } catch (err) {
        setError(true);
        const fallback = [
          { date: '2024-03-18', usd: 0.1234 },
          { date: '2024-03-19', usd: 0.1248 },
          { date: '2024-03-20', usd: 0.1257 },
          { date: '2024-03-21', usd: 0.1265 },
          { date: '2024-03-22', usd: 0.1269 },
          { date: '2024-03-25', usd: 0.1271 },
          { date: '2024-03-26', usd: 0.1275 },
          { date: '2024-03-27', usd: 0.1282 },
          { date: '2024-03-28', usd: 0.1289 },
          { date: '2024-03-29', usd: 0.1291 },
          { date: '2024-04-01', usd: 0.1298 }
        ];
        setData(fallback);
        setLatest(fallback[fallback.length - 1].usd);
        const first = fallback[0].usd;
        const last = fallback[fallback.length - 1].usd;
        const diff = ((last - first) / first) * 100;
        setChange(diff.toFixed(2));
        setUpdated(fallback[fallback.length - 1].date);
      }
    };

    fetchRates();
  }, []);

  return (
    <div className="data-card" aria-live="polite">
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        <h3 className="section-heading" style={{ marginBottom: 0 }}>
          {formatMessage({ id: 'tracker.heading' })}
        </h3>
        <p className="text-muted">{formatMessage({ id: 'tracker.description' })}</p>
        {error && (
          <p className="error-text" role="alert">
            {formatMessage({ id: 'tracker.error' })}
          </p>
        )}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.5rem' }}>
          <div className="stat-highlight" style={{ minWidth: '160px' }}>
            <h3>{latest ? formatter.format(latest) : '—'}</h3>
            <p>{formatMessage({ id: 'tracker.per100' })}</p>
          </div>
          <div className="stat-highlight" style={{ minWidth: '160px' }}>
            <h3>{change ? `${change}%` : '—'}</h3>
            <p>{formatMessage({ id: 'tracker.change' })}</p>
          </div>
        </div>
        <span className="badge-inline">
          {formatMessage({ id: 'tracker.updated' })}: {updated || '—'}
        </span>
      </div>
      <div className="chart-container">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="date" tick={{ fontSize: 12 }} />
            <YAxis
              tick={{ fontSize: 12 }}
              tickFormatter={(value) => value.toFixed(3)}
            />
            <Tooltip
              formatter={(value) => formatter.format(value)}
              labelFormatter={(label) => label}
            />
            <Line
              type="monotone"
              dataKey="usd"
              stroke="#2563eb"
              strokeWidth={3}
              dot={false}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default DataCard;