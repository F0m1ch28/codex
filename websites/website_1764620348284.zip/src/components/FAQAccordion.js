import React, { useState } from 'react';
import { useIntl } from 'react-intl';

const FAQAccordion = ({ items }) => {
  const [openIndex, setOpenIndex] = useState(0);
  const { formatMessage } = useIntl();

  return (
    <div className="accordion">
      {items.map((item, index) => {
        const isOpen = index === openIndex;
        return (
          <div className="accordion-item" key={item.question}>
            <button
              className="accordion-header"
              onClick={() => setOpenIndex(isOpen ? -1 : index)}
              aria-expanded={isOpen}
            >
              <span>{formatMessage({ id: item.question })}</span>
              <span>{isOpen ? '−' : '+'}</span>
            </button>
            {isOpen && (
              <div className="accordion-content">
                <p>{formatMessage({ id: item.answer })}</p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default FAQAccordion;