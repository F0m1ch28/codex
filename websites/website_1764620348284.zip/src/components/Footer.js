import React from 'react';
import { Link } from 'react-router-dom';
import { useIntl } from 'react-intl';

const Footer = () => {
  const { formatMessage } = useIntl();
  const year = new Date().getFullYear();

  return (
    <footer className="footer" role="contentinfo">
      <div className="container footer-grid">
        <div>
          <h4>{formatMessage({ id: 'brand.name' })}</h4>
          <p>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
          <p>{formatMessage({ id: 'footer.address' })}</p>
          <p>
            <a href="mailto:hola@tuprogresohoy.com">
              {formatMessage({ id: 'footer.email' })}
            </a>
          </p>
        </div>
        <div>
          <h4>{formatMessage({ id: 'footer.company' })}</h4>
          <Link to="/about">{formatMessage({ id: 'nav.about' })}</Link>
          <Link to="/faq">{formatMessage({ id: 'nav.faq' })}</Link>
          <Link to="/contact">{formatMessage({ id: 'nav.contact' })}</Link>
        </div>
        <div>
          <h4>{formatMessage({ id: 'footer.course' })}</h4>
          <Link to="/course">{formatMessage({ id: 'nav.course' })}</Link>
          <Link to="/inflation">{formatMessage({ id: 'nav.inflation' })}</Link>
          <Link to="/resources">{formatMessage({ id: 'nav.resources' })}</Link>
        </div>
        <div>
          <h4>{formatMessage({ id: 'footer.legal' })}</h4>
          <Link to="/privacy">{formatMessage({ id: 'nav.privacy' })}</Link>
          <Link to="/cookies">{formatMessage({ id: 'nav.cookies' })}</Link>
          <Link to="/terms">{formatMessage({ id: 'nav.terms' })}</Link>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {year} {formatMessage({ id: 'brand.name' })}. {formatMessage({ id: 'footer.rights' })}</span>
        <a
          href="https://www.linkedin.com"
          target="_blank"
          rel="noreferrer"
        >
          {formatMessage({ id: 'footer.social' })}
        </a>
      </div>
    </footer>
  );
};

export default Footer;