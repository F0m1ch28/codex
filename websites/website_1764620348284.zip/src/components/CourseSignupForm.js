import React, { useState } from 'react';
import Button from './Button';
import { useIntl } from 'react-intl';
import { useNavigate } from 'react-router-dom';
import { containsBannedWords } from '../utils/bannedWords';

const CourseSignupForm = () => {
  const { formatMessage, locale } = useIntl();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    goals: '',
    language: locale === 'es' ? 'Spanish' : 'English',
    consent: false,
    confirm: false
  });
  const [status, setStatus] = useState({ type: 'idle', message: '' });

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus({ type: 'idle', message: '' });

    if (!formData.consent || !formData.confirm) {
      setStatus({ type: 'error', message: formatMessage({ id: 'courseSignup.error.optIn' }) });
      return;
    }

    if (containsBannedWords(`${formData.name} ${formData.goals}`)) {
      setStatus({ type: 'error', message: formatMessage({ id: 'courseSignup.error.banned' }) });
      return;
    }

    try {
      const response = await fetch(
        `https://formspree.io/f/${process.env.REACT_APP_FORMSPREE_ID}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          },
          body: JSON.stringify({
            name: formData.name,
            email: formData.email,
            goals: formData.goals,
            preferredLanguage: formData.language,
            source: 'Course trial'
          })
        }
      );

      if (response.ok) {
        setStatus({ type: 'success', message: formatMessage({ id: 'courseSignup.success' }) });
        setTimeout(() => {
          navigate('/thank-you');
        }, 1200);
      } else {
        throw new Error('Form submission failed');
      }
    } catch (error) {
      setStatus({ type: 'error', message: formatMessage({ id: 'courseSignup.error.generic' }) });
    }
  };

  return (
    <Card className="form-card">
      <div>
        <h3 className="section-heading" style={{ marginBottom: '0.5rem' }}>
          {formatMessage({ id: 'courseSignup.title' })}
        </h3>
        <p className="section-subtitle" style={{ marginBottom: '1.5rem' }}>
          {formatMessage({ id: 'courseSignup.subtitle' })}
        </p>
      </div>
      <form onSubmit={handleSubmit} className="form-grid" noValidate>
        <div className="form-grid two-columns">
          <div>
            <label htmlFor="trial-name">{formatMessage({ id: 'courseSignup.name' })}</label>
            <input
              id="trial-name"
              name="name"
              type="text"
              required
              value={formData.name}
              onChange={handleChange}
              placeholder="Mariana García"
            />
          </div>
          <div>
            <label htmlFor="trial-email">{formatMessage({ id: 'courseSignup.email' })}</label>
            <input
              id="trial-email"
              name="email"
              type="email"
              required
              value={formData.email}
              onChange={handleChange}
              placeholder="tu@correo.com"
            />
          </div>
        </div>
        <div>
          <label htmlFor="trial-language">{formatMessage({ id: 'courseSignup.language' })}</label>
          <select
            id="trial-language"
            name="language"
            value={formData.language}
            onChange={handleChange}
          >
            <option value="English">English</option>
            <option value="Spanish">Español</option>
          </select>
        </div>
        <div>
          <label htmlFor="trial-goals">{formatMessage({ id: 'courseSignup.goals' })}</label>
          <textarea
            id="trial-goals"
            name="goals"
            value={formData.goals}
            onChange={handleChange}
            placeholder="Controlling monthly expenses, negotiating annual contracts..."
          />
        </div>
        <div>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <input
              type="checkbox"
              name="consent"
              checked={formData.consent}
              onChange={handleChange}
            />
            {formatMessage({ id: 'courseSignup.optIn' })}
          </label>
        </div>
        <div>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <input
              type="checkbox"
              name="confirm"
              checked={formData.confirm}
              onChange={handleChange}
            />
            {formatMessage({ id: 'courseSignup.confirm' })}
          </label>
        </div>
        {status.message && (
          <p className={status.type === 'error' ? 'error-text' : 'success-text'}>{status.message}</p>
        )}
        <Button type="submit" variant="primary" size="lg">
          {formatMessage({ id: 'courseSignup.submit' })}
        </Button>
      </form>
    </Card>
  );
};

export default CourseSignupForm;