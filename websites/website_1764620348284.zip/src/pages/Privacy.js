import React from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import { useIntl } from 'react-intl';

const Privacy = () => {
  const { formatMessage } = useIntl();

  const sections = [
    { title: 'privacy.section1.title', body: 'privacy.section1.body' },
    { title: 'privacy.section2.title', body: 'privacy.section2.body' },
    { title: 'privacy.section3.title', body: 'privacy.section3.body' },
    { title: 'privacy.section4.title', body: 'privacy.section4.body' }
  ];

  return (
    <Section className="section-light">
      <div className="mb-8">
        <h1 className="section-heading">{formatMessage({ id: 'privacy.title' })}</h1>
        <p className="section-subtitle">{formatMessage({ id: 'privacy.updated' })}</p>
        <p className="section-subtitle">{formatMessage({ id: 'privacy.intro' })}</p>
      </div>
      <div className="grid" style={{ gap: '1.5rem' }}>
        {sections.map((section) => (
          <Card key={section.title}>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
              {formatMessage({ id: section.title })}
            </h3>
            <p>{formatMessage({ id: section.body })}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
};

export default Privacy;