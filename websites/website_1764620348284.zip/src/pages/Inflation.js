import React from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import FAQAccordion from '../components/FAQAccordion';
import { useIntl } from 'react-intl';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar
} from 'recharts';

const cpiData = [
  { month: '2023-10', index: 105 },
  { month: '2023-11', index: 112 },
  { month: '2023-12', index: 127 },
  { month: '2024-01', index: 134 },
  { month: '2024-02', index: 139 },
  { month: '2024-03', index: 146 },
  { month: '2024-04', index: 152 },
  { month: '2024-05', index: 158 },
  { month: '2024-06', index: 164 },
  { month: '2024-07', index: 171 },
  { month: '2024-08', index: 178 },
  { month: '2024-09', index: 186 }
];

const fxData = [
  { month: '2023-10', official: 365, blue: 880 },
  { month: '2023-11', official: 371, blue: 940 },
  { month: '2023-12', official: 600, blue: 980 },
  { month: '2024-01', official: 820, blue: 1120 },
  { month: '2024-02', official: 890, blue: 1180 },
  { month: '2024-03', official: 940, blue: 1240 },
  { month: '2024-04', official: 980, blue: 1290 },
  { month: '2024-05', official: 1005, blue: 1350 },
  { month: '2024-06', official: 1030, blue: 1420 },
  { month: '2024-07', official: 1055, blue: 1490 },
  { month: '2024-08', official: 1080, blue: 1535 },
  { month: '2024-09', official: 1105, blue: 1580 }
];

const Inflation = () => {
  const { formatMessage } = useIntl();

  const faqItems = [
    { question: 'inflation.faq1.q', answer: 'inflation.faq1.a' },
    { question: 'inflation.faq2.q', answer: 'inflation.faq2.a' },
    { question: 'inflation.faq3.q', answer: 'inflation.faq3.a' },
    { question: 'inflation.faq4.q', answer: 'inflation.faq4.a' }
  ];

  return (
    <>
      <Section className="section-light">
        <div className="mb-8">
          <h1 className="section-heading">
            {formatMessage({ id: 'inflation.heroTitle' })}
          </h1>
          <p className="section-subtitle">
            {formatMessage({ id: 'inflation.heroSubtitle' })}
          </p>
          <span className="badge-inline">
            {formatMessage({ id: 'inflation.lastUpdated' })} 2024-09-30
          </span>
        </div>
        <Card>
          <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
            {formatMessage({ id: 'inflation.methodologyTitle' })}
          </h3>
          <p>{formatMessage({ id: 'inflation.methodologyText' })}</p>
        </Card>
      </Section>

      <Section className="section-alt">
        <div className="grid" style={{ gap: '2rem' }}>
          <Card>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.5rem' }}>
              {formatMessage({ id: 'inflation.cpiTitle' })}
            </h3>
            <p className="text-muted">{formatMessage({ id: 'inflation.note' })}</p>
            <div className="chart-container" style={{ height: '320px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={cpiData}>
                  <defs>
                    <linearGradient id="colorCpi" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="index"
                    stroke="#2563eb"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorCpi)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.5rem' }}>
              {formatMessage({ id: 'inflation.fxTitle' })}
            </h3>
            <p className="text-muted">{formatMessage({ id: 'inflation.context' })}</p>
            <div className="chart-container" style={{ height: '320px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={fxData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="official" fill="#1f3a6f" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="blue" fill="#2563eb" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </Section>

      <Section>
        <h2 className="section-heading">
          {formatMessage({ id: 'inflation.faqTitle' })}
        </h2>
        <FAQAccordion items={faqItems} />
      </Section>
    </>
  );
};

export default Inflation;