import React from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import { useIntl } from 'react-intl';

const Cookies = () => {
  const { formatMessage } = useIntl();

  const sections = [
    { title: 'cookies.section1.title', body: 'cookies.section1.body' },
    { title: 'cookies.section2.title', body: 'cookies.section2.body' },
    { title: 'cookies.section3.title', body: 'cookies.section3.body' }
  ];

  return (
    <Section className="section-light">
      <div className="mb-8">
        <h1 className="section-heading">{formatMessage({ id: 'cookies.title' })}</h1>
        <p className="section-subtitle">{formatMessage({ id: 'cookies.intro' })}</p>
      </div>
      <div className="grid" style={{ gap: '1.5rem' }}>
        {sections.map((section) => (
          <Card key={section.title}>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
              {formatMessage({ id: section.title })}
            </h3>
            <p>{formatMessage({ id: section.body })}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
};

export default Cookies;