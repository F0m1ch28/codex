import React from 'react';
import Section from '../components/Section';
import FAQAccordion from '../components/FAQAccordion';
import { useIntl } from 'react-intl';

const FAQ = () => {
  const { formatMessage } = useIntl();

  const items = [
    { question: 'faq.item1.q', answer: 'faq.item1.a' },
    { question: 'faq.item2.q', answer: 'faq.item2.a' },
    { question: 'faq.item3.q', answer: 'faq.item3.a' },
    { question: 'faq.item4.q', answer: 'faq.item4.a' }
  ];

  return (
    <Section className="section-light">
      <div className="mb-8">
        <h1 className="section-heading">{formatMessage({ id: 'faq.title' })}</h1>
        <p className="section-subtitle">{formatMessage({ id: 'faq.intro' })}</p>
      </div>
      <FAQAccordion items={items} />
      <p className="section-subtitle" style={{ marginTop: '2rem' }}>
        {formatMessage({ id: 'faq.cta' })}
      </p>
    </Section>
  );
};

export default FAQ;