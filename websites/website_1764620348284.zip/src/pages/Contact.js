import React from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import ContactForm from '../components/ContactForm';
import { useIntl } from 'react-intl';

const Contact = () => {
  const { formatMessage } = useIntl();

  return (
    <>
      <Section className="section-light">
        <div className="grid" style={{ gap: '2rem' }}>
          <div>
            <h1 className="section-heading">{formatMessage({ id: 'contact.title' })}</h1>
            <p className="section-subtitle">
              {formatMessage({ id: 'contact.subtitle' })}
            </p>
            <Card>
              <div className="contact-info">
                <p>{formatMessage({ id: 'contact.banner' })}</p>
                <div>
                  <strong>{formatMessage({ id: 'contact.detail.email' })}:</strong>{' '}
                  <a href="mailto:hola@tuprogresohoy.com">{formatMessage({ id: 'footer.email' })}</a>
                </div>
                <div>
                  <strong>{formatMessage({ id: 'contact.detail.phone' })}:</strong>{' '}
                  {formatMessage({ id: 'contact.phoneValue' })}
                </div>
                <div>
                  <strong>{formatMessage({ id: 'contact.detail.hours' })}:</strong>{' '}
                  {formatMessage({ id: 'contact.hoursValue' })}
                </div>
                <div>
                  <strong>{formatMessage({ id: 'contact.detail.address' })}</strong>
                </div>
                <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
                  {formatMessage({ id: 'contact.detail.social' })}
                </a>
              </div>
            </Card>
          </div>
          <img
            src="https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg"
            alt="Equipo de Tu Progreso Hoy / Tu Progreso Hoy team"
            loading="lazy"
          />
        </div>
      </Section>

      <Section className="section-alt">
        <div className="grid" style={{ gap: '2rem' }}>
          <Card>
            <h2 style={{ fontFamily: 'var(--font-heading)', marginBottom: '1rem' }}>
              {formatMessage({ id: 'contact.form.title' })}
            </h2>
            <ContactForm />
          </Card>
          <Card>
            <h2 style={{ fontFamily: 'var(--font-heading)', marginBottom: '1rem' }}>
              {formatMessage({ id: 'contact.mapTitle' })}
            </h2>
            <iframe
              title="Mapa de Buenos Aires"
              className="map-frame"
              src="https://www.google.com/maps?q=Buenos+Aires&output=embed"
              loading="lazy"
            />
          </Card>
        </div>
      </Section>
    </>
  );
};

export default Contact;