import React from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import Button from '../components/Button';
import CourseSignupForm from '../components/CourseSignupForm';
import { useIntl } from 'react-intl';

const Course = () => {
  const { formatMessage } = useIntl();

  const modules = [
    { title: 'course.module1.title', desc: 'course.module1.desc' },
    { title: 'course.module2.title', desc: 'course.module2.desc' },
    { title: 'course.module3.title', desc: 'course.module3.desc' },
    { title: 'course.module4.title', desc: 'course.module4.desc' },
    { title: 'course.module5.title', desc: 'course.module5.desc' },
    { title: 'course.module6.title', desc: 'course.module6.desc' }
  ];

  const targets = [
    'course.target1',
    'course.target2',
    'course.target3'
  ];

  const bonuses = [
    'course.bonus1',
    'course.bonus2',
    'course.bonus3'
  ];

  const highlights = [
    'course.section.highlight1',
    'course.section.highlight2',
    'course.section.highlight3'
  ];

  return (
    <>
      <Section className="section-light">
        <div className="grid" style={{ gap: '3rem' }}>
          <div>
            <h1 className="section-heading">
              {formatMessage({ id: 'course.heroTitle' })}
            </h1>
            <p className="section-subtitle">
              {formatMessage({ id: 'course.heroSubtitle' })}
            </p>
            <Button variant="secondary" size="lg">
              {formatMessage({ id: 'course.cta' })}
            </Button>
          </div>
          <img
            src="https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg"
            alt="Curso Tu Progreso Hoy / Tu Progreso Hoy course"
            loading="lazy"
          />
        </div>
      </Section>

      <Section className="section-alt">
        <div className="mb-8">
          <h2 className="section-heading">
            {formatMessage({ id: 'course.modulesTitle' })}
          </h2>
        </div>
        <div className="grid" style={{ gap: '1.5rem' }}>
          {modules.map((module) => (
            <Card key={module.title}>
              <h3 style={{ fontFamily: 'var(--font-heading)', color: 'var(--primary)', marginBottom: '0.5rem' }}>
                {formatMessage({ id: module.title })}
              </h3>
              <p>{formatMessage({ id: module.desc })}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section>
        <div className="grid" style={{ gap: '2rem' }}>
          <Card>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '1rem' }}>
              {formatMessage({ id: 'course.targetTitle' })}
            </h3>
            <ul style={{ display: 'grid', gap: '0.75rem' }}>
              {targets.map((target) => (
                <li key={target} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                  <span className="badge-inline">✔</span>
                  <p>{formatMessage({ id: target })}</p>
                </li>
              ))}
            </ul>
          </Card>
          <Card>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '1rem' }}>
              {formatMessage({ id: 'course.bonusTitle' })}
            </h3>
            <ul style={{ display: 'grid', gap: '0.75rem' }}>
              {bonuses.map((bonus) => (
                <li key={bonus} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                  <span className="badge-inline">★</span>
                  <p>{formatMessage({ id: bonus })}</p>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </Section>

      <Section className="section-alt">
        <div className="grid" style={{ gap: '1.5rem' }}>
          <Card>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
              {formatMessage({ id: 'course.section.highlightsTitle' })}
            </h3>
            <ul style={{ display: 'grid', gap: '0.75rem' }}>
              {highlights.map((key) => (
                <li key={key} style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                  <span className="badge-inline">▪</span>
                  <p>{formatMessage({ id: key })}</p>
                </li>
              ))}
            </ul>
          </Card>
          <Card>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
              {formatMessage({ id: 'course.section.cta' })}
            </h3>
            <p style={{ marginBottom: '1rem' }}>
              {formatMessage({ id: 'course.section.ctaText' })}
            </p>
            <Button variant="primary">{formatMessage({ id: 'course.cta' })}</Button>
          </Card>
        </div>
      </Section>

      <Section>
        <CourseSignupForm />
      </Section>
    </>
  );
};

export default Course;