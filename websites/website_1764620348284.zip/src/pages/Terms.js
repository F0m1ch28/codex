import React from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import { useIntl } from 'react-intl';

const Terms = () => {
  const { formatMessage } = useIntl();

  const sections = [
    { title: 'terms.section1.title', body: 'terms.section1.body' },
    { title: 'terms.section2.title', body: 'terms.section2.body' },
    { title: 'terms.section3.title', body: 'terms.section3.body' }
  ];

  return (
    <Section className="section-light">
      <div className="mb-8">
        <h1 className="section-heading">{formatMessage({ id: 'terms.title' })}</h1>
        <p className="section-subtitle">{formatMessage({ id: 'terms.intro' })}</p>
      </div>
      <div className="grid" style={{ gap: '1.5rem' }}>
        {sections.map((section) => (
          <Card key={section.title}>
            <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
              {formatMessage({ id: section.title })}
            </h3>
            <p>{formatMessage({ id: section.body })}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
};

export default Terms;