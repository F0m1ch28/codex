import React from 'react';
import Section from '../components/Section';
import Button from '../components/Button';
import { Link } from 'react-router-dom';
import { useIntl } from 'react-intl';

const ThankYou = () => {
  const { formatMessage } = useIntl();

  return (
    <Section className="section-light" style={{ minHeight: '60vh' }}>
      <div className="text-center" style={{ display: 'grid', gap: '1rem', justifyItems: 'center' }}>
        <h1 className="section-heading">{formatMessage({ id: 'thankyou.title' })}</h1>
        <p className="section-subtitle">{formatMessage({ id: 'thankyou.subtitle' })}</p>
        <p className="text-muted">{formatMessage({ id: 'thankyou.nextSteps' })}</p>
        <Link to="/">
          <Button variant="primary" size="md">
            {formatMessage({ id: 'thankyou.cta' })}
          </Button>
        </Link>
      </div>
    </Section>
  );
};

export default ThankYou;