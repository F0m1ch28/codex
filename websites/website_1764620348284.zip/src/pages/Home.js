import React from 'react';
import Section from '../components/Section';
import Button from '../components/Button';
import DataCard from '../components/DataCard';
import CourseSignupForm from '../components/CourseSignupForm';
import Card from '../components/Card';
import Testimonials from '../components/Testimonials';
import { Link } from 'react-router-dom';
import { useIntl } from 'react-intl';

const Home = () => {
  const { formatMessage } = useIntl();

  const featurePhrases = [
    {
      phrase: 'Datos verificados para planificar tu presupuesto.',
      description: formatMessage({ id: 'feature1.desc' })
    },
    {
      phrase: 'Decisiones responsables, objetivos nítidos.',
      description: formatMessage({ id: 'feature2.desc' })
    },
    {
      phrase: 'Conocimiento financiero impulsado por tendencias.',
      description: formatMessage({ id: 'feature3.desc' })
    },
    {
      phrase: 'Pasos acertados hoy, mejor futuro mañana.',
      description: formatMessage({ id: 'feature4.desc' })
    },
    {
      phrase: 'Análisis transparentes y datos de mercado para decidir con seguridad.',
      description: formatMessage({ id: 'feature5.desc' })
    },
    {
      phrase: 'Información confiable que respalda elecciones responsables sobre tu dinero.',
      description: formatMessage({ id: 'feature6.desc' })
    },
    {
      phrase: 'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
      description: formatMessage({ id: 'feature7.desc' })
    },
    {
      phrase: 'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.',
      description: formatMessage({ id: 'feature8.desc' })
    }
  ];

  const overviewCards = [
    {
      title: formatMessage({ id: 'home.section.card1.title' }),
      body: formatMessage({ id: 'home.section.card1.body' })
    },
    {
      title: formatMessage({ id: 'home.section.card2.title' }),
      body: formatMessage({ id: 'home.section.card2.body' })
    },
    {
      title: formatMessage({ id: 'home.section.card3.title' }),
      body: formatMessage({ id: 'home.section.card3.body' })
    },
    {
      title: formatMessage({ id: 'home.section.card4.title' }),
      body: formatMessage({ id: 'home.section.card4.body' })
    }
  ];

  return (
    <>
      <section className="hero">
        <div className="container hero-content">
          <span className="hero-badge">
            {formatMessage({ id: 'hero.badge' })}
          </span>
          <h1 className="hero-title">{formatMessage({ id: 'hero.title' })}</h1>
          <p className="hero-text">{formatMessage({ id: 'hero.subtitle' })}</p>
          <div className="hero-actions">
            <Link to="/course">
              <Button variant="primary" size="lg">
                {formatMessage({ id: 'hero.cta' })}
              </Button>
            </Link>
            <Link to="/inflation">
              <Button variant="outline" size="lg">
                {formatMessage({ id: 'hero.secondaryCta' })}
              </Button>
            </Link>
          </div>
          <div className="hero-metric">
            <div className="metric-item">
              <span className="metric-value">
                {formatMessage({ id: 'hero.metric1.value' })}
              </span>
              <span className="metric-label">
                {formatMessage({ id: 'hero.metric1.label' })}
              </span>
            </div>
            <div className="metric-item">
              <span className="metric-value">
                {formatMessage({ id: 'hero.metric2.value' })}
              </span>
              <span className="metric-label">
                {formatMessage({ id: 'hero.metric2.label' })}
              </span>
            </div>
          </div>
        </div>
      </section>

      <Section>
        <DataCard />
      </Section>

      <Section className="section-light">
        <div className="mb-8">
          <h2 className="section-heading">
            {formatMessage({ id: 'features.title' })}
          </h2>
          <p className="section-subtitle">
            {formatMessage({ id: 'features.subtitle' })}
          </p>
        </div>
        <div className="feature-grid">
          {featurePhrases.map((feature) => (
            <Card key={feature.phrase} className="feature-card">
              <h3>{feature.phrase}</h3>
              <p>{feature.description}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Section className="section-alt">
        <div className="mb-8">
          <h2 className="section-heading">
            {formatMessage({ id: 'home.section.insightsTitle' })}
          </h2>
          <p className="section-subtitle">
            {formatMessage({ id: 'home.section.insightsSubtitle' })}
          </p>
        </div>
        <div className="grid" style={{ gap: '1.5rem' }}>
          {overviewCards.map((item) => (
            <Card key={item.title}>
              <h3 style={{ fontFamily: 'var(--font-heading)', color: 'var(--primary)', marginBottom: '0.5rem' }}>
                {item.title}
              </h3>
              <p>{item.body}</p>
            </Card>
          ))}
        </div>
      </Section>

      <Testimonials />

      <Section>
        <div className="mb-8">
          <h2 className="section-heading">
            {formatMessage({ id: 'courseSignup.title' })}
          </h2>
          <p className="section-subtitle">
            {formatMessage({ id: 'courseSignup.subtitle' })}
          </p>
        </div>
        <CourseSignupForm />
      </Section>
    </>
  );
};

export default Home;