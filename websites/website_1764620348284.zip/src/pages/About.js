import React from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import { useIntl } from 'react-intl';

const About = () => {
  const { formatMessage } = useIntl();

  const values = ['about.value1', 'about.value2', 'about.value3'];

  return (
    <Section className="section-light">
      <div className="grid" style={{ gap: '2rem' }}>
        <div>
          <h1 className="section-heading">{formatMessage({ id: 'about.title' })}</h1>
          <p className="section-subtitle">{formatMessage({ id: 'about.subtitle' })}</p>
          <img
            src="https://images.pexels.com/photos/3184357/pexels-photo-3184357.jpeg"
            alt="Equipo colaborando / Team collaborating"
            loading="lazy"
          />
        </div>
        <Card>
          <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
            {formatMessage({ id: 'about.missionTitle' })}
          </h3>
          <p style={{ marginBottom: '1.5rem' }}>{formatMessage({ id: 'about.mission' })}</p>
          <h4 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
            {formatMessage({ id: 'about.valuesTitle' })}
          </h4>
          <ul style={{ display: 'grid', gap: '0.75rem' }}>
            {values.map((value) => (
              <li key={value} style={{ display: 'flex', gap: '0.65rem', alignItems: 'flex-start' }}>
                <span className="badge-inline">▹</span>
                <p>{formatMessage({ id: value })}</p>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </Section>
  );
};

export default About;