import React, { useState } from 'react';
import Section from '../components/Section';
import Card from '../components/Card';
import Button from '../components/Button';
import { useIntl } from 'react-intl';

const Resources = () => {
  const { formatMessage, locale } = useIntl();
  const [language, setLanguage] = useState(locale === 'es' ? 'es' : 'en');

  const resources = [
    {
      id: 'article1',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg',
      tag: 'Glossary / Glosario',
      links: {
        en: '#',
        es: '#'
      },
      title: 'resources.article1.title',
      excerpt: 'resources.article1.excerpt'
    },
    {
      id: 'article2',
      image: 'https://images.pexels.com/photos/3184357/pexels-photo-3184357.jpeg',
      tag: 'Guide / Guía',
      links: {
        en: '#',
        es: '#'
      },
      title: 'resources.article2.title',
      excerpt: 'resources.article2.excerpt'
    },
    {
      id: 'article3',
      image: 'https://images.pexels.com/photos/669610/pexels-photo-669610.jpeg',
      tag: 'Policy / Política',
      links: {
        en: '#',
        es: '#'
      },
      title: 'resources.article3.title',
      excerpt: 'resources.article3.excerpt'
    }
  ];

  return (
    <Section className="section-light">
      <div className="mb-8">
        <h1 className="section-heading">{formatMessage({ id: 'resources.title' })}</h1>
        <p className="section-subtitle">
          {formatMessage({ id: 'resources.subtitle' })}
        </p>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <Button
            variant={language === 'en' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setLanguage('en')}
          >
            EN
          </Button>
          <Button
            variant={language === 'es' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setLanguage('es')}
          >
            ES
          </Button>
        </div>
      </div>
      <div className="grid" style={{ gap: '1.5rem' }}>
        {resources.map((resource) => (
          <Card className="resource-card" key={resource.id}>
            <img
              src={resource.image}
              alt="Resource illustration / Ilustración de recurso"
              loading="lazy"
            />
            <div className="resource-meta">
              <span className="tag">{resource.tag}</span>
            </div>
            <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem' }}>
              {formatMessage({ id: resource.title })}
            </h3>
            <p>{formatMessage({ id: resource.excerpt })}</p>
            <Button variant="primary" size="sm" onClick={() => window.open(resource.links[language], '_blank')}>
              {formatMessage({ id: 'resources.view' })}
            </Button>
          </Card>
        ))}
      </div>
    </Section>
  );
};

export default Resources;