export const bannedPattern =
  /(guaranteed profit|get rich quick|no risk|100%|milagro|ganar dinero rápido|garantía)/i;

export const containsBannedWords = (text = '') => bannedPattern.test(text);