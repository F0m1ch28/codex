export const messages = {
  en: {
    'brand.name': 'Tu Progreso Hoy',
    'nav.home': 'Home',
    'nav.about': 'About',
    'nav.inflation': 'Inflation',
    'nav.course': 'Course',
    'nav.resources': 'Resources',
    'nav.contact': 'Contact',
    'nav.faq': 'FAQ',
    'nav.privacy': 'Privacy',
    'nav.cookies': 'Cookies',
    'nav.terms': 'Terms',
    'hero.badge': 'Educational platform',
    'hero.title': "Navigate Argentina's economy with clarity",
    'hero.subtitle':
      'Granular insights and weekly lessons transforming daily indicators into better everyday decisions.',
    'hero.cta': 'Explore the course',
    'hero.secondaryCta': 'View inflation analysis',
    'hero.metric1.label': 'Lesson completion rate',
    'hero.metric1.value': '94%',
    'hero.metric2.label': 'Community insights shared',
    'hero.metric2.value': '650+',
    'tracker.heading': 'ARS to USD tracker',
    'tracker.description':
      'Monitor daily exchange movements to adjust your plans in real time.',
    'tracker.per100': 'ARS 100 in USD',
    'tracker.change': '14-day change',
    'tracker.updated': 'Last refreshed',
    'tracker.error': 'We could not update the data. Showing recent reference values.',
    'features.title': 'Key promises from Tu Progreso Hoy',
    'features.subtitle':
      'Every module pairs verified information with exercises so you can move from observation to action.',
    'feature1.desc':
      'Evidence-based metrics keep your household plan aligned with reality.',
    'feature2.desc':
      'Embed responsible decisions and sharpen your financial goals.',
    'feature3.desc':
      'Harness data-driven learning to interpret emerging trends.',
    'feature4.desc':
      'Each step you take today prepares a stronger path for tomorrow.',
    'feature5.desc':
      'Transparent analyses and market signals support thoughtful choices.',
    'feature6.desc':
      'Reliable information supports responsible decisions about your money.',
    'feature7.desc':
      'Track trends, spot opportunities, and design your financial roadmap.',
    'feature8.desc':
      'From information to learning: strengthen your financial criteria progressively.',
    'home.section.insightsTitle': 'What you receive inside the platform',
    'home.section.insightsSubtitle':
      'From weekly breakdowns of inflation drivers to interactive budgeting labs, every resource is tuned for people living in Argentina.',
    'home.section.card1.title': 'Weekly macro briefings',
    'home.section.card1.body':
      'Digestible summaries of CPI, FX, and activity data with context for households and freelancers.',
    'home.section.card2.title': 'Scenario planners',
    'home.section.card2.body':
      'Stress-test your plans with flexible sheets that incorporate taxes, inflation, and currency paths.',
    'home.section.card3.title': 'Community meetups',
    'home.section.card3.body':
      'Live sessions to compare strategies with peers facing similar price dynamics.',
    'home.section.card4.title': 'Expert interviews',
    'home.section.card4.body':
      'Hear from academics, entrepreneurs, and policy analysts shaping the conversation.',
    'home.testimonials.title': 'Learners building their progress',
    'home.testimonials.subtitle':
      'Members from different provinces share how the platform supports decisive planning.',
    'testimonial.ana.quote':
      'El seguimiento diario del peso y las guías de presupuesto me dieron tranquilidad para equilibrar mis ingresos variables.',
    'testimonial.ana.role': 'Freelance designer, Mendoza',
    'testimonial.emilio.quote':
      'Los módulos me ayudaron a explicar la inflación a mi equipo y tomar decisiones salariales responsables.',
    'testimonial.emilio.role': 'Operations lead, Córdoba',
    'testimonial.sofia.quote':
      'La combinación de datos y ejercicios prácticos hizo que por fin tenga una rutina financiera sostenible.',
    'testimonial.sofia.role': 'Comerciante, Ciudad de Buenos Aires',
    'courseSignup.title': 'Get your free trial lesson',
    'courseSignup.subtitle':
      'The first micro-lesson arrives in your inbox with exercises to apply immediately.',
    'courseSignup.name': 'Full name',
    'courseSignup.email': 'Email',
    'courseSignup.goals': 'What are you working toward this quarter?',
    'courseSignup.language': 'Preferred lesson language',
    'courseSignup.languagePlaceholder': 'Select language',
    'courseSignup.optIn':
      'I agree to receive a confirmation email and follow the double opt-in instructions.',
    'courseSignup.confirm':
      'I will confirm my subscription via the confirmation message.',
    'courseSignup.submit': 'Send my trial lesson',
    'courseSignup.error.optIn':
      'Please confirm both consent boxes to proceed.',
    'courseSignup.error.banned':
      'Please rephrase your message without restricted expressions.',
    'courseSignup.error.generic':
      'Something went wrong while sending. Please try again in a moment.',
    'courseSignup.success':
      'Great! Check your inbox to confirm the subscription.',
    'inflation.heroTitle': 'Inflation & currency intelligence',
    'inflation.heroSubtitle':
      'Understand how price movements, agreements, and exchange dynamics interact week by week.',
    'inflation.methodologyTitle': 'Methodology & sources',
    'inflation.methodologyText':
      'We combine INDEC releases, private sector price surveys, central bank communications, and high-frequency data partners. Each chart highlights collection timing and potential revisions.',
    'inflation.cpiTitle': 'Monthly CPI momentum',
    'inflation.fxTitle': 'FX reference bands',
    'inflation.context':
      'Monthly CPI variations are seasonally adjusted to highlight intrinsic momentum. Exchange rate series use the official seller rate and dollar blue mid-point for comparison.',
    'inflation.faqTitle': 'Inflation FAQ',
    'inflation.faq1.q': 'How often are inflation figures updated?',
    'inflation.faq1.a':
      'Official CPI is updated monthly. We supplement it with weekly surveys that feed our early indicators every Friday.',
    'inflation.faq2.q': 'What inflation expectations are included?',
    'inflation.faq2.a':
      'We blend central bank REM expectations with market curves to project quarterly averages.',
    'inflation.faq3.q': 'How do you treat regulated prices?',
    'inflation.faq3.a':
      'Regulated sectors are monitored separately. We flag upcoming adjustments so you can adapt your plan before they hit.',
    'inflation.faq4.q': 'Do you cover regional variations?',
    'inflation.faq4.a':
      'Yes, our dashboards display Greater Buenos Aires vs. national averages and specific provincial snapshots.',
    'inflation.lastUpdated': 'Updated with data through',
    'course.heroTitle': 'Course: Build clarity in volatile contexts',
    'course.heroSubtitle':
      'A six-module learning path guiding you from data interpretation to actionable planning.',
    'course.cta': 'Reserve your seat',
    'course.modulesTitle': 'Syllabus overview',
    'course.module1.title': 'Module 1 · Inflation anatomy',
    'course.module1.desc':
      'Break down CPI components, base effects, and price agreements shaping the monthly print.',
    'course.module2.title': 'Module 2 · Exchange rate strategies',
    'course.module2.desc':
      'Understand official vs. parallel markets, currency controls, and hedging options for individuals.',
    'course.module3.title': 'Module 3 · Income planning',
    'course.module3.desc':
      'Design cash-flow buffers, index incomes, and align expenses with realistic assumptions.',
    'course.module4.title': 'Module 4 · Savings frameworks',
    'course.module4.desc':
      'Evaluate pesos, dollars, and baskets with a focus on liquidity and accessibility.',
    'course.module5.title': 'Module 5 · Scenario simulation',
    'course.module5.desc':
      'Use our planners to test optimistic, central, and stressed paths for your goals.',
    'course.module6.title': 'Module 6 · Accountability rituals',
    'course.module6.desc':
      'Create consistent checkpoints with community feedback and transparent dashboards.',
    'course.targetTitle': 'Who this course is for',
    'course.target1':
      'Independent professionals managing irregular income in an inflationary environment.',
    'course.target2':
      'Families seeking structured routines to evaluate prices, contracts, and commitments.',
    'course.target3':
      'Small teams looking to explain macro dynamics to collaborators transparently.',
    'course.bonusTitle': 'Included resources',
    'course.bonus1': 'Template library with bilingual guidance.',
    'course.bonus2': 'Monthly live Q&A with data specialists.',
    'course.bonus3': 'Private community channel for peer accountability.',
    'resources.title': 'Resource library',
    'resources.subtitle':
      'Complement the course with curated explainers and glossaries available in both languages.',
    'resources.article1.title': 'Inflation glossary for daily decisions',
    'resources.article1.excerpt':
      'Key concepts such as base effects, crawling peg, and tradables explained with plain-language examples.',
    'resources.article2.title': 'Blueprint for peso and dollar budgeting',
    'resources.article2.excerpt':
      'Step-by-step worksheet to manage expenses split between currencies without losing track.',
    'resources.article3.title': 'Reading Argentina’s monetary policy updates',
    'resources.article3.excerpt':
      'Understand how the central bank communicates and what it means for credit and savings.',
    'resources.languageToggle': 'Switch language',
    'contact.title': 'Connect with the Tu Progreso Hoy team',
    'contact.subtitle':
      'Share your questions, partnership ideas, or requests for tailored workshops.',
    'contact.mapTitle': 'Find us in Buenos Aires',
    'contact.detail.email': 'Email',
    'contact.detail.phone': 'Phone',
    'contact.detail.hours': 'Office hours',
    'contact.detail.address': 'Av. Corrientes 1234, CABA, Argentina',
    'contact.hoursValue': 'Monday to Friday · 09:00-18:00 (ART)',
    'contact.phoneValue': '+54 11 5555-1234',
    'contact.form.title': 'Send us a message',
    'contact.form.name': 'Name',
    'contact.form.email': 'Email',
    'contact.form.topic': 'Topic',
    'contact.form.topic.option1': 'General question',
    'contact.form.topic.option2': 'Course enrollment',
    'contact.form.topic.option3': 'Press & media',
    'contact.form.message': 'Message',
    'contact.form.consent':
      'I agree to be contacted regarding my inquiry and understand double opt-in is required.',
    'contact.form.submit': 'Submit message',
    'contact.form.success': 'Thanks! We received your message.',
    'contact.form.error':
      'We could not send the form right now. Please try again shortly.',
    'contact.form.error.optIn': 'Please accept the consent checkbox.',
    'thankyou.title': 'Confirm your inbox',
    'thankyou.subtitle':
      'A confirmation email has been sent. Follow the instructions to activate your subscription.',
    'thankyou.cta': 'Return to home',
    'privacy.title': 'Privacy Policy',
    'privacy.updated': 'Last updated: April 2024',
    'privacy.intro':
      'We collect the minimum personal data required to deliver educational content and improve the platform.',
    'privacy.section1.title': 'Data we collect',
    'privacy.section1.body':
      'When you subscribe or contact us, we collect your name, email address, language preference, and voluntary goals information.',
    'privacy.section2.title': 'How we use your data',
    'privacy.section2.body':
      'We use the data to deliver lessons, send product updates, and respond to inquiries. Aggregated analytics help us understand usage patterns.',
    'privacy.section3.title': 'Data sharing',
    'privacy.section3.body':
      'We do not sell personal data. Trusted processors (email delivery, analytics) handle information under strict agreements.',
    'privacy.section4.title': 'Your rights',
    'privacy.section4.body':
      'Request access, correction, or deletion anytime by emailing privacy@tuprogresohoy.com.',
    'cookies.title': 'Cookies Policy',
    'cookies.intro':
      'Cookies help us provide a consistent experience and understand how the site is used.',
    'cookies.section1.title': 'Necessary cookies',
    'cookies.section1.body':
      'Essential cookies keep the website functional, enabling security, language preferences, and routing.',
    'cookies.section2.title': 'Analytics cookies',
    'cookies.section2.body':
      'Optional analytics help us improve content. They are only enabled if you opt in through the banner.',
    'cookies.section3.title': 'Managing preferences',
    'cookies.section3.body':
      'Update your consent anytime via the banner or by contacting privacy@tuprogresohoy.com.',
    'terms.title': 'Terms & Conditions',
    'terms.intro':
      'These terms govern the use of Tu Progreso Hoy educational services.',
    'terms.section1.title': 'Purpose of the platform',
    'terms.section1.body':
      'Tu Progreso Hoy provides educational content, data visualizations, and planning tools. We do not provide financial services.',
    'terms.section2.title': 'User responsibilities',
    'terms.section2.body':
      'Users agree to review the information critically, respect intellectual property, and comply with Argentine law.',
    'terms.section3.title': 'Limitations',
    'terms.section3.body':
      'Content is informational and does not replace personalized financial advice or professional services.',
    'footer.company': 'Company',
    'footer.course': 'Course',
    'footer.legal': 'Legal',
    'footer.contact': 'Contact',
    'footer.rights': 'All rights reserved.',
    'footer.email': 'hola@tuprogresohoy.com',
    'footer.address': 'Av. Corrientes 1234, CABA',
    'footer.social': 'Follow our updates',
    'cookie.title': 'We respect your privacy',
    'cookie.description':
      'We use cookies to provide core functionality and optional analytics. Choose how you want to proceed.',
    'cookie.analytics': 'Allow analytics cookies',
    'cookie.marketing': 'Allow marketing updates',
    'cookie.acceptAll': 'Accept all',
    'cookie.save': 'Save selection',
    'cookie.decline': 'Necessary only',
    'languageToggle.en': 'English',
    'languageToggle.es': 'Español',
    'disclaimer.title': 'Important notice',
    'disclaimer.body':
      'Мы не предоставляем финансовые услуги. / We do not provide financial services. / No proporcionamos servicios financieros.',
    'disclaimer.accept': 'I understand',
    'about.title': 'About Tu Progreso Hoy',
    'about.subtitle':
      'We build educational experiences that connect data with actionable routines for people living in Argentina.',
    'about.missionTitle': 'Mission',
    'about.mission':
      'Offer transparent, bilingual resources that empower households and teams to interpret economic signals with confidence.',
    'about.valuesTitle': 'Our guiding principles',
    'about.value1':
      'Integrity: every dataset is sourced, documented, and peer reviewed.',
    'about.value2':
      'Empathy: we design for real-life constraints faced by families and professionals.',
    'about.value3':
      'Action: every lesson ends with a concrete step to implement the same day.',
    'faq.title': 'Frequently Asked Questions',
    'faq.intro':
      'Browse answers to common questions about the learning experience.',
    'faq.item1.q': 'Is the platform suited for beginners?',
    'faq.item1.a':
      'Yes. Each module starts with foundational explanations before moving into applied exercises.',
    'faq.item2.q': 'How often is new content published?',
    'faq.item2.a':
      'New lessons and dashboards are added every month, with weekly community notes.',
    'faq.item3.q': 'Can I invite my team?',
    'faq.item3.a':
      'Team plans are available. Contact us to coordinate onboarding and private workshops.',
    'faq.item4.q': 'Do you handle personal financial advice?',
    'faq.item4.a':
      'No. The platform provides educational materials and tools without offering financial services.',
    'faq.cta': 'Still have questions? Reach out through our contact form.',
    'resources.view': 'Read resource',
    'inflation.note':
      'Values displayed as indexed series (base 100 = January).',
    'course.section.cta': 'Ready to start?',
    'course.section.ctaText':
      'Join the next cohort and receive onboarding guidance within 24 hours.',
    'course.section.highlightsTitle': 'Learning highlights',
    'course.section.highlight1':
      'Bilingual content (English/Spanish) with downloadable transcripts.',
    'course.section.highlight2':
      'Progress checkpoints and reflective prompts aligned with each module.',
    'course.section.highlight3':
      'Live office hours to clarify indicators and adapt them to your context.',
    'home.section.overviewTitle': 'Course snapshot',
    'home.section.overviewBody':
      'Six modules blending macro monitoring, scenario planning, and budget rituals tailored for Argentina.',
    'home.section.resourcesTitle': 'Data & insights',
    'home.section.resourcesBody':
      'Stay up to date with inflation, currency, and policy trackers built for everyday planning.',
    'contact.banner':
      'Need a speaker for your organization? Let us know in the message field.',
    'contact.detail.social': 'Community updates on LinkedIn',
    'thankyou.nextSteps':
      'If you do not see the email, check your spam folder or promotions tab.',
    'contact.form.error.banned':
      'Please adjust your message to remove restricted expressions.'
  },
  es: {
    'brand.name': 'Tu Progreso Hoy',
    'nav.home': 'Inicio',
    'nav.about': 'Nosotros',
    'nav.inflation': 'Inflación',
    'nav.course': 'Curso',
    'nav.resources': 'Recursos',
    'nav.contact': 'Contacto',
    'nav.faq': 'Preguntas',
    'nav.privacy': 'Privacidad',
    'nav.cookies': 'Cookies',
    'nav.terms': 'Términos',
    'hero.badge': 'Plataforma educativa',
    'hero.title': 'Navegá la economía argentina con claridad',
    'hero.subtitle':
      'Insights granulares y lecciones semanales que transforman indicadores diarios en decisiones concretas.',
    'hero.cta': 'Explorar el curso',
    'hero.secondaryCta': 'Ver análisis de inflación',
    'hero.metric1.label': 'Tasa de finalización',
    'hero.metric1.value': '94%',
    'hero.metric2.label': 'Aportes de la comunidad',
    'hero.metric2.value': '650+',
    'tracker.heading': 'Seguimiento ARS a USD',
    'tracker.description':
      'Controlá los movimientos diarios del tipo de cambio para ajustar tus planes en tiempo real.',
    'tracker.per100': 'ARS 100 en USD',
    'tracker.change': 'Variación 14 días',
    'tracker.updated': 'Última actualización',
    'tracker.error':
      'No pudimos actualizar los datos. Mostramos valores recientes de referencia.',
    'features.title': 'Promesas clave de Tu Progreso Hoy',
    'features.subtitle':
      'Cada módulo combina información verificada con ejercicios para avanzar de la observación a la acción.',
    'feature1.desc':
      'Los datos respaldados mantienen tu plan familiar alineado con la realidad.',
    'feature2.desc':
      'Incorporá decisiones responsables y objetivos nítidos.',
    'feature3.desc':
      'Potenciá el conocimiento financiero impulsado por tendencias.',
    'feature4.desc':
      'Pasos acertados hoy, mejor futuro mañana.',
    'feature5.desc':
      'Análisis transparentes y datos de mercado para decidir con seguridad.',
    'feature6.desc':
      'Información confiable que respalda elecciones responsables sobre tu dinero.',
    'feature7.desc':
      'Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.',
    'feature8.desc':
      'De la información al aprendizaje: fortalece tu criterio financiero paso a paso.',
    'home.section.insightsTitle': 'Lo que recibís dentro de la plataforma',
    'home.section.insightsSubtitle':
      'Desde desgloses semanales de inflación hasta laboratorios de presupuesto, cada recurso está pensado para personas que viven en Argentina.',
    'home.section.card1.title': 'Briefings macro semanales',
    'home.section.card1.body':
      'Resúmenes claros de IPC, tipo de cambio y actividad con contexto para hogares y freelancers.',
    'home.section.card2.title': 'Simuladores de escenarios',
    'home.section.card2.body':
      'Poné a prueba tus planes con planillas flexibles que contemplan impuestos, inflación y evoluciones cambiarias.',
    'home.section.card3.title': 'Encuentros comunitarios',
    'home.section.card3.body':
      'Sesiones en vivo para comparar estrategias con quienes enfrentan dinámicas de precios similares.',
    'home.section.card4.title': 'Entrevistas a especialistas',
    'home.section.card4.body':
      'Escuchá a académicos, emprendedores y analistas que marcan la conversación.',
    'home.testimonials.title': 'Personas que impulsan su progreso',
    'home.testimonials.subtitle':
      'Integrantes de distintas provincias comparten cómo la plataforma acompaña decisiones concretas.',
    'testimonial.ana.quote':
      'El seguimiento diario del peso y las guías de presupuesto me dieron tranquilidad para equilibrar mis ingresos variables.',
    'testimonial.ana.role': 'Diseñadora freelance, Mendoza',
    'testimonial.emilio.quote':
      'Los módulos me ayudaron a explicar la inflación a mi equipo y tomar decisiones salariales responsables.',
    'testimonial.emilio.role': 'Líder de operaciones, Córdoba',
    'testimonial.sofia.quote':
      'La combinación de datos y ejercicios prácticos hizo que por fin tenga una rutina financiera sostenible.',
    'testimonial.sofia.role': 'Comerciante, Ciudad de Buenos Aires',
    'courseSignup.title': 'Recibí tu clase de prueba gratuita',
    'courseSignup.subtitle':
      'La primera micro-lección llega a tu correo con ejercicios para aplicar al instante.',
    'courseSignup.name': 'Nombre completo',
    'courseSignup.email': 'Correo electrónico',
    'courseSignup.goals': '¿En qué querés avanzar este trimestre?',
    'courseSignup.language': 'Idioma preferido para las lecciones',
    'courseSignup.languagePlaceholder': 'Seleccionar idioma',
    'courseSignup.optIn':
      'Acepto recibir el correo de confirmación y completar el doble opt-in.',
    'courseSignup.confirm':
      'Confirmaré mi suscripción mediante el mensaje recibido.',
    'courseSignup.submit': 'Enviar clase de prueba',
    'courseSignup.error.optIn':
      'Por favor confirmá ambas casillas de consentimiento.',
    'courseSignup.error.banned':
      'Reformulá tu mensaje sin expresiones restringidas, por favor.',
    'courseSignup.error.generic':
      'Ocurrió un error al enviar. Intentalo nuevamente en instantes.',
    'courseSignup.success':
      '¡Listo! Revisá tu bandeja para confirmar la suscripción.',
    'inflation.heroTitle': 'Inteligencia sobre inflación y moneda',
    'inflation.heroSubtitle':
      'Comprendé cómo interactúan los movimientos de precios, acuerdos y dinámica cambiaria semana a semana.',
    'inflation.methodologyTitle': 'Metodología y fuentes',
    'inflation.methodologyText':
      'Combinamos publicaciones del INDEC, relevamientos de precios privados, comunicaciones del BCRA y datos de alta frecuencia. Cada gráfico aclara momentos de recolección y posibles revisiones.',
    'inflation.cpiTitle': 'Índice de precios mensual',
    'inflation.fxTitle': 'Bandas de referencia cambiaria',
    'inflation.context':
      'Las variaciones mensuales de IPC están ajustadas estacionalmente para resaltar la tendencia propia. La serie cambiaria utiliza el oficial vendedor y el dólar blue como comparación.',
    'inflation.faqTitle': 'Preguntas sobre inflación',
    'inflation.faq1.q': '¿Con qué frecuencia se actualizan los datos?',
    'inflation.faq1.a':
      'El IPC oficial se publica mensualmente. Lo complementamos con encuestas semanales que alimentan indicadores tempranos cada viernes.',
    'inflation.faq2.q': '¿Qué expectativas de inflación incluyen?',
    'inflation.faq2.a':
      'Mezclamos expectativas REM del BCRA con curvas de mercado para proyectar promedios trimestrales.',
    'inflation.faq3.q': '¿Cómo tratan los precios regulados?',
    'inflation.faq3.a':
      'Seguimos los sectores regulados por separado y señalamos ajustes previstos para que puedas anticiparte.',
    'inflation.faq4.q': '¿Cubren variaciones regionales?',
    'inflation.faq4.a':
      'Sí, mostramos AMBA frente al promedio nacional y recortes provinciales específicos.',
    'inflation.lastUpdated': 'Actualizado con datos al',
    'inflation.note':
      'Valores mostrados como series indexadas (base 100 = enero).',
    'course.heroTitle': 'Curso: Claridad en contextos volátiles',
    'course.heroSubtitle':
      'Un recorrido de seis módulos que te guía desde la lectura de datos hasta la planificación accionable.',
    'course.cta': 'Reservar mi lugar',
    'course.modulesTitle': 'Programa del curso',
    'course.module1.title': 'Módulo 1 · Anatomía de la inflación',
    'course.module1.desc':
      'Desarmá los componentes del IPC, efectos base y acuerdos de precios que impactan el dato mensual.',
    'course.module2.title': 'Módulo 2 · Estrategias cambiarias',
    'course.module2.desc':
      'Comprendé mercados oficiales y paralelos, controles y opciones de cobertura para individuos.',
    'course.module3.title': 'Módulo 3 · Planificación de ingresos',
    'course.module3.desc':
      'Diseñá colchones, indexá ingresos y alineá gastos con supuestos realistas.',
    'course.module4.title': 'Módulo 4 · Marcos de ahorro',
    'course.module4.desc':
      'Evaluá pesos, dólares y canastas según liquidez y accesibilidad.',
    'course.module5.title': 'Módulo 5 · Simulación de escenarios',
    'course.module5.desc':
      'Usá nuestros planners para probar caminos optimistas, centrales y de estrés.',
    'course.module6.title': 'Módulo 6 · Rituales de seguimiento',
    'course.module6.desc':
      'Creá controles consistentes con feedback comunitario y tableros transparentes.',
    'course.targetTitle': 'Ideal para',
    'course.target1':
      'Profesionales independientes que gestionan ingresos variables en inflación.',
    'course.target2':
      'Familias que buscan rutinas estructuradas para evaluar precios, contratos y compromisos.',
    'course.target3':
      'Equipos pequeños que necesitan explicar la macro a sus colaboradores con transparencia.',
    'course.bonusTitle': 'Recursos incluidos',
    'course.bonus1': 'Biblioteca de plantillas con guía bilingüe.',
    'course.bonus2': 'Sesión mensual de preguntas con especialistas en datos.',
    'course.bonus3': 'Canal privado para accountability entre pares.',
    'course.section.cta': '¿Listo para comenzar?',
    'course.section.ctaText':
      'Sumate a la próxima cohorte y recibí la guía de bienvenida en menos de 24 horas.',
    'course.section.highlightsTitle': 'Destacados del aprendizaje',
    'course.section.highlight1':
      'Contenido bilingüe (español/inglés) con transcripciones descargables.',
    'course.section.highlight2':
      'Checkpoints de progreso y preguntas reflexivas en cada módulo.',
    'course.section.highlight3':
      'Office hours en vivo para aclarar indicadores y llevarlos a tu realidad.',
    'resources.title': 'Biblioteca de recursos',
    'resources.subtitle':
      'Complementá el curso con explicadores y glosarios disponibles en ambos idiomas.',
    'resources.article1.title': 'Glosario de inflación para decisiones cotidianas',
    'resources.article1.excerpt':
      'Conceptos clave como efectos base, crawling peg y transables explicados con ejemplos simples.',
    'resources.article2.title': 'Guía para presupuestar en pesos y dólares',
    'resources.article2.excerpt':
      'Paso a paso para administrar gastos divididos entre monedas sin perder el control.',
    'resources.article3.title': 'Cómo leer los comunicados del BCRA',
    'resources.article3.excerpt':
      'Comprendé qué comunica el Banco Central y cómo impacta en crédito y ahorro.',
    'resources.languageToggle': 'Cambiar idioma',
    'resources.view': 'Ver recurso',
    'contact.title': 'Conectá con el equipo de Tu Progreso Hoy',
    'contact.subtitle':
      'Contanos tus dudas, ideas de colaboración o pedidos de talleres a medida.',
    'contact.mapTitle': 'Estamos en Buenos Aires',
    'contact.detail.email': 'Correo',
    'contact.detail.phone': 'Teléfono',
    'contact.detail.hours': 'Horario de atención',
    'contact.detail.address': 'Av. Corrientes 1234, CABA, Argentina',
    'contact.hoursValue': 'Lunes a viernes · 09:00-18:00 (ART)',
    'contact.phoneValue': '+54 11 5555-1234',
    'contact.form.title': 'Escribinos',
    'contact.form.name': 'Nombre',
    'contact.form.email': 'Correo electrónico',
    'contact.form.topic': 'Motivo',
    'contact.form.topic.option1': 'Consulta general',
    'contact.form.topic.option2': 'Inscripción al curso',
    'contact.form.topic.option3': 'Prensa y medios',
    'contact.form.message': 'Mensaje',
    'contact.form.consent':
      'Acepto ser contactado sobre mi consulta y cumplir con el doble opt-in.',
    'contact.form.submit': 'Enviar mensaje',
    'contact.form.success': '¡Gracias! Recibimos tu mensaje.',
    'contact.form.error':
      'No pudimos enviar el formulario en este momento. Probá nuevamente.',
    'contact.form.error.optIn': 'Por favor aceptá la casilla de consentimiento.',
    'contact.form.error.banned':
      'Ajustá el mensaje removiendo expresiones restringidas, por favor.',
    'contact.banner':
      '¿Necesitás un speaker para tu organización? Contalo en el mensaje.',
    'contact.detail.social': 'Actualizaciones de la comunidad en LinkedIn',
    'thankyou.title': 'Confirmá tu bandeja',
    'thankyou.subtitle':
      'Te enviamos un correo de confirmación. Seguí las instrucciones para activar tu suscripción.',
    'thankyou.cta': 'Volver al inicio',
    'thankyou.nextSteps':
      'Si no ves el correo, revisá spam o promociones.',
    'privacy.title': 'Política de Privacidad',
    'privacy.updated': 'Última actualización: abril 2024',
    'privacy.intro':
      'Recolectamos la mínima información personal necesaria para brindar contenido educativo y mejorar la plataforma.',
    'privacy.section1.title': 'Datos que recopilamos',
    'privacy.section1.body':
      'Al suscribirte o contactarnos obtenemos tu nombre, correo, idioma preferido e información voluntaria sobre objetivos.',
    'privacy.section2.title': 'Uso de los datos',
    'privacy.section2.body':
      'Utilizamos los datos para enviar lecciones, novedades y responder consultas. Analíticas agregadas nos ayudan a entender patrones de uso.',
    'privacy.section3.title': 'Compartir información',
    'privacy.section3.body':
      'No vendemos datos personales. Proveedores confiables (envío de correos, analítica) operan bajo acuerdos estrictos.',
    'privacy.section4.title': 'Tus derechos',
    'privacy.section4.body':
      'Podés solicitar acceso, corrección o eliminación escribiendo a privacy@tuprogresohoy.com.',
    'cookies.title': 'Política de Cookies',
    'cookies.intro':
      'Las cookies nos ayudan a ofrecer una experiencia consistente y entender cómo se utiliza el sitio.',
    'cookies.section1.title': 'Cookies necesarias',
    'cookies.section1.body':
      'Son esenciales para el funcionamiento del sitio, habilitando seguridad, idioma y navegación.',
    'cookies.section2.title': 'Cookies de analítica',
    'cookies.section2.body':
      'Son opcionales y solo se activan si las aceptás en el banner.',
    'cookies.section3.title': 'Gestión de preferencias',
    'cookies.section3.body':
      'Podés actualizar tu consentimiento cuando quieras desde el banner o escribiendo a privacy@tuprogresohoy.com.',
    'terms.title': 'Términos y Condiciones',
    'terms.intro':
      'Estos términos regulan el uso de los servicios educativos de Tu Progreso Hoy.',
    'terms.section1.title': 'Propósito de la plataforma',
    'terms.section1.body':
      'Tu Progreso Hoy ofrece contenido educativo, visualizaciones de datos y herramientas de planificación. No brindamos servicios financieros.',
    'terms.section2.title': 'Responsabilidad de los usuarios',
    'terms.section2.body':
      'Las personas usuarias aceptan revisar la información críticamente, respetar la propiedad intelectual y cumplir la normativa argentina.',
    'terms.section3.title': 'Limitaciones',
    'terms.section3.body':
      'El contenido es informativo y no reemplaza asesoramiento financiero personalizado ni servicios profesionales.',
    'footer.company': 'Compañía',
    'footer.course': 'Curso',
    'footer.legal': 'Legal',
    'footer.contact': 'Contacto',
    'footer.rights': 'Todos los derechos reservados.',
    'footer.email': 'hola@tuprogresohoy.com',
    'footer.address': 'Av. Corrientes 1234, CABA',
    'footer.social': 'Seguí nuestras novedades',
    'cookie.title': 'Respetamos tu privacidad',
    'cookie.description':
      'Usamos cookies para funciones esenciales y analítica opcional. Elegí cómo querés continuar.',
    'cookie.analytics': 'Permitir cookies de analítica',
    'cookie.marketing': 'Permitir comunicaciones de marketing',
    'cookie.acceptAll': 'Aceptar todo',
    'cookie.save': 'Guardar selección',
    'cookie.decline': 'Solo necesarias',
    'languageToggle.en': 'English',
    'languageToggle.es': 'Español',
    'disclaimer.title': 'Aviso importante',
    'disclaimer.body':
      'Мы не предоставляем финансовые услуги. / We do not provide financial services. / No proporcionamos servicios financieros.',
    'disclaimer.accept': 'Entiendo',
    'about.title': 'Sobre Tu Progreso Hoy',
    'about.subtitle':
      'Construimos experiencias educativas que conectan datos con rutinas accionables para quienes viven en Argentina.',
    'about.missionTitle': 'Misión',
    'about.mission':
      'Ofrecer recursos transparentes y bilingües que empoderen a hogares y equipos para interpretar señales económicas con confianza.',
    'about.valuesTitle': 'Principios que nos guían',
    'about.value1':
      'Integridad: cada conjunto de datos tiene fuente, documentación y revisión de pares.',
    'about.value2':
      'Empatía: diseñamos para las restricciones reales que viven familias y profesionales.',
    'about.value3':
      'Acción: cada lección culmina con un paso concreto para implementar en el día.',
    'faq.title': 'Preguntas frecuentes',
    'faq.intro':
      'Revisá respuestas a dudas habituales sobre la experiencia de aprendizaje.',
    'faq.item1.q': '¿La plataforma sirve para principiantes?',
    'faq.item1.a':
      'Sí. Cada módulo comienza con explicaciones básicas antes de avanzar a ejercicios aplicados.',
    'faq.item2.q': '¿Con qué frecuencia hay contenido nuevo?',
    'faq.item2.a':
      'Sumamos lecciones y tableros todos los meses, con notas semanales para la comunidad.',
    'faq.item3.q': '¿Puedo invitar a mi equipo?',
    'faq.item3.a':
      'Ofrecemos planes para equipos. Escribinos para coordinar onboarding y talleres privados.',
    'faq.item4.q': '¿Brindan asesoramiento financiero personal?',
    'faq.item4.a':
      'No. La plataforma provee materiales educativos y herramientas sin ofrecer servicios financieros.',
    'faq.cta': '¿Tenés otra duda? Escribinos desde el formulario de contacto.',
    'resources.languageToggle': 'Cambiar idioma'
  }
};