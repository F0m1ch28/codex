(function () {
  const redirectMap = {
    "/history": "/archives.html",
    "/history/": "/archives.html",
    "/infrastructure": "/maps.html",
    "/infrastructure/": "/maps.html",
    "/systems": "/signals.html",
    "/systems/": "/signals.html",
    "/resilience": "/contexts.html",
    "/resilience/": "/contexts.html"
  };
  const path = window.location.pathname.replace(/\/+$/, "") || "/";
  if (redirectMap[path]) {
    window.location.replace(redirectMap[path]);
  }
})();
document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", function () {
      const isOpen = primaryNav.classList.toggle("is-open");
      navToggle.classList.toggle("is-active", isOpen);
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }
  const consentKey = "northlyx-cookie-consent";
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = cookieBanner ? cookieBanner.querySelector(".cookie-accept") : null;
  const declineBtn = cookieBanner ? cookieBanner.querySelector(".cookie-decline") : null;
  const storedConsent = localStorage.getItem(consentKey);
  if (cookieBanner && storedConsent) {
    cookieBanner.classList.add("is-hidden");
    cookieBanner.setAttribute("aria-hidden", "true");
  }
  function handleConsent(value) {
    if (!cookieBanner) return;
    localStorage.setItem(consentKey, value);
    cookieBanner.classList.add("is-hidden");
    cookieBanner.setAttribute("aria-hidden", "true");
  }
  if (acceptBtn) {
    acceptBtn.addEventListener("click", function () {
      handleConsent("accepted");
    });
  }
  if (declineBtn) {
    declineBtn.addEventListener("click", function () {
      handleConsent("declined");
    });
  }
  function initSignalCanvas() {
    const canvas = document.getElementById("signal-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let width;
    let height;
    let deviceRatio;
    const pulses = [];
    const stars = [];
    function resize() {
      const rect = canvas.getBoundingClientRect();
      deviceRatio = window.devicePixelRatio || 1;
      width = rect.width;
      height = rect.height;
      canvas.width = Math.round(rect.width * deviceRatio);
      canvas.height = Math.round(rect.height * deviceRatio);
      ctx.scale(deviceRatio, deviceRatio);
    }
    function populate() {
      pulses.length = 0;
      stars.length = 0;
      for (let i = 0; i < 6; i += 1) {
        pulses.push({
          radius: Math.random() * (Math.min(width, height) / 4),
          speed: 0.35 + Math.random() * 0.45,
          maxRadius: Math.min(width, height) / 2,
          opacity: 0.4 + Math.random() * 0.4
        });
      }
      for (let i = 0; i < 90; i += 1) {
        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * 1.2,
          alpha: 0.3 + Math.random() * 0.5,
          twinkle: 0.003 + Math.random() * 0.01
        });
      }
    }
    function drawGrid() {
      ctx.save();
      ctx.strokeStyle = "rgba(56, 189, 248, 0.12)";
      ctx.lineWidth = 1;
      const centerX = width / 2;
      const centerY = height / 2;
      const circles = 4;
      for (let i = 1; i <= circles; i += 1) {
        const radius = (Math.min(width, height) / (circles + 1)) * i;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(centerX, 0);
      ctx.lineTo(centerX, height);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, centerY);
      ctx.lineTo(width, centerY);
      ctx.stroke();
      ctx.restore();
    }
    function drawStars() {
      ctx.save();
      stars.forEach((star) => {
        ctx.fillStyle = `rgba(168, 85, 247, ${star.alpha})`;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();
        star.alpha += star.twinkle * (Math.random() > 0.5 ? 1 : -1);
        if (star.alpha > 0.8) {
          star.alpha = 0.8;
        }
        if (star.alpha < 0.2) {
          star.alpha = 0.2;
        }
      });
      ctx.restore();
    }
    function drawPulses() {
      ctx.save();
      ctx.translate(width / 2, height / 2);
      pulses.forEach((pulse) => {
        ctx.beginPath();
        ctx.arc(0, 0, pulse.radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(56, 189, 248, ${pulse.opacity})`;
        ctx.lineWidth = 2;
        ctx.stroke();
        pulse.radius += pulse.speed;
        pulse.opacity -= 0.0018 * pulse.speed;
        if (pulse.radius > pulse.maxRadius || pulse.opacity <= 0) {
          pulse.radius = Math.random() * (Math.min(width, height) / 5);
          pulse.opacity = 0.6 + Math.random() * 0.3;
        }
      });
      ctx.restore();
    }
    function drawSweep() {
      ctx.save();
      ctx.translate(width / 2, height / 2);
      const sweepAngle = Date.now() / 1200;
      const radius = Math.min(width, height) / 2;
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, radius);
      gradient.addColorStop(0, "rgba(34, 197, 94, 0.04)");
      gradient.addColorStop(1, "rgba(34, 197, 94, 0)");
      ctx.rotate(sweepAngle);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius, -0.3, 0.3);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
    function loop() {
      ctx.clearRect(0, 0, width, height);
      drawGrid();
      drawStars();
      drawPulses();
      drawSweep();
      requestAnimationFrame(loop);
    }
    resize();
    populate();
    window.addEventListener("resize", function () {
      resize();
      populate();
    });
    requestAnimationFrame(loop);
  }
  initSignalCanvas();
  const layerButtons = document.querySelectorAll("[data-layer]");
  const layerTargets = document.querySelectorAll(".map-layer");
  if (layerButtons.length && layerTargets.length) {
    layerButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const target = button.getAttribute("data-layer");
        layerButtons.forEach((b) => b.classList.toggle("is-active", b === button));
        layerTargets.forEach((layer) => {
          layer.classList.toggle("is-active", layer.getAttribute("data-layer") === target);
        });
      });
    });
  }
});