document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('primaryNav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('is-active');
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('is-active');
      });
    });
  }

  const yearSpans = document.querySelectorAll('#currentYear');
  const currentYear = new Date().getFullYear();
  yearSpans.forEach(span => {
    span.textContent = currentYear;
  });

  const toast = document.getElementById('formToast');
  const forms = document.querySelectorAll('form[data-redirect="true"]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (toast) {
        toast.textContent = 'Message submitted. Redirecting to confirmation...';
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 3200);
      }
      setTimeout(() => {
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 1200);
    });
  });

  const cookieBanner = document.getElementById('cookieBanner');
  const cookieAccept = document.getElementById('cookieAccept');
  const cookieDecline = document.getElementById('cookieDecline');
  const cookieKey = 'khmt_cookie_choice';

  const hideBanner = () => {
    if (!cookieBanner) return;
    cookieBanner.classList.remove('visible');
    setTimeout(() => {
      if (cookieBanner) cookieBanner.style.display = 'none';
    }, 320);
  };

  if (cookieBanner) {
    const existingChoice = localStorage.getItem(cookieKey);
    if (!existingChoice) {
      cookieBanner.style.display = 'grid';
      requestAnimationFrame(() => cookieBanner.classList.add('visible'));
    }
    if (cookieAccept) {
      cookieAccept.addEventListener('click', () => {
        localStorage.setItem(cookieKey, 'accepted');
        hideBanner();
      });
    }
    if (cookieDecline) {
      cookieDecline.addEventListener('click', () => {
        localStorage.setItem(cookieKey, 'declined');
        hideBanner();
      });
    }
  }

  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    document.querySelectorAll('.animate-on-scroll').forEach(el => observer.observe(el));
  } else {
    document.querySelectorAll('.animate-on-scroll').forEach(el => el.classList.add('is-visible'));
  }
});