document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            var isOpen = siteNav.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen);
        });
        siteNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    var cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        try {
            var choice = localStorage.getItem('sellofmkkk-cookie-choice');
            if (choice) {
                cookieBanner.classList.add('is-hidden');
            }
        } catch (error) {
            console.warn('Cookie preferences unavailable.', error);
        }

        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(function (button) {
            button.addEventListener('click', function () {
                var action = button.getAttribute('data-cookie-action');
                try {
                    localStorage.setItem('sellofmkkk-cookie-choice', action);
                } catch (error) {
                    console.warn('Unable to store cookie preference.', error);
                }
                cookieBanner.classList.add('is-hidden');
            });
        });
    }
});