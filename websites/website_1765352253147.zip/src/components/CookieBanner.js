import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('digitalcovers_cookie_consent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    window.localStorage.setItem('digitalcovers_cookie_consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <p>
          Мы используем cookie для персонализации и аналитики. Подробности в{' '}
          <Link to="/cookie-policy">Политике использования cookie</Link>.
        </p>
      </div>
      <button type="button" className="buttonPrimary" onClick={acceptCookies}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;