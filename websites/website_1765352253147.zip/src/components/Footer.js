import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`container ${styles.footerInner}`}>
        <div className={styles.brandColumn}>
          <h2 className={styles.logo}>
            Digital<span>covers</span>
          </h2>
          <p>
            DigitalCovers — международная платформа визуального контента для авторов, стримеров и креаторов. Мы
            создаём графику, которая помогает контенту выглядеть профессионально и узнаваемо.
          </p>
          <div className={styles.contactDetails}>
            <p>
              <strong>Адрес:</strong> ул. Цифровая, 42, Москва, Россия, 123456
            </p>
            <p>
              <strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            </p>
            <p>
              <strong>Email:</strong> <a href="mailto:info@digitalcovers.ru">info@digitalcovers.ru</a>
            </p>
          </div>
        </div>

        <div className={styles.linksColumn}>
          <h3>Категории</h3>
          <ul>
            <li>
              <Link to="/catalog/oblozhki">Обложки для видео</Link>
            </li>
            <li>
              <Link to="/catalog/avatarki">Аватарки для сообществ</Link>
            </li>
            <li>
              <Link to="/catalog/bannery">Баннеры для стримов</Link>
            </li>
            <li>
              <Link to="/services">Индивидуальные решения</Link>
            </li>
          </ul>
        </div>

        <div className={styles.linksColumn}>
          <h3>Компания</h3>
          <ul>
            <li>
              <Link to="/about">О DigitalCovers</Link>
            </li>
            <li>
              <Link to="/contacts">Свяжитесь с нами</Link>
            </li>
            <li>
              <Link to="/terms">Условия использования</Link>
            </li>
            <li>
              <Link to="/privacy">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Политика cookie</Link>
            </li>
          </ul>
        </div>

        <div className={styles.linksColumn}>
          <h3>Сообщества</h3>
          <ul>
            <li>
              <a href="https://dribbble.com" target="_blank" rel="noopener noreferrer">
                Dribbble
              </a>
            </li>
            <li>
              <a href="https://behance.net" target="_blank" rel="noopener noreferrer">
                Behance
              </a>
            </li>
            <li>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                Instagram
              </a>
            </li>
            <li>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                Twitter
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;