import React from 'react';
import styles from './ProductCard.module.css';

const ProductCard = ({ title, category, image, description }) => {
  return (
    <article className={styles.card}>
      <div className={styles.imageWrapper}>
        <img src={image} alt={title} loading="lazy" />
      </div>
      <div className={styles.content}>
        <span className={styles.category}>{category}</span>
        <h3>{title}</h3>
        {description && <p>{description}</p>}
        <button type="button" className={styles.button}>
          Узнать подробности
        </button>
      </div>
    </article>
  );
};

export default ProductCard;