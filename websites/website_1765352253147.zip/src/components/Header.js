import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`} role="banner">
      <div className={`container ${styles.headerInner}`}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          Digital<span className={styles.logoAccent}>Covers</span>
        </Link>
        <button
          type="button"
          className={styles.mobileToggle}
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Переключить меню"
        >
          <span className={styles.toggleLine} />
          <span className={styles.toggleLine} />
          <span className={styles.toggleLine} />
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isMenuOpen ? styles.open : ''}`}
          aria-label="Основная навигация"
        >
          <ul className={styles.navList}>
            <li>
              <NavLink to="/" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu} end>
                Главная
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/catalog/oblozhki"
                className={({ isActive }) => (isActive ? styles.active : '')}
                onClick={closeMenu}
              >
                Обложки
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/catalog/avatarki"
                className={({ isActive }) => (isActive ? styles.active : '')}
                onClick={closeMenu}
              >
                Аватарки
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/catalog/bannery"
                className={({ isActive }) => (isActive ? styles.active : '')}
                onClick={closeMenu}
              >
                Баннеры
              </NavLink>
            </li>
            <li>
              <NavLink to="/about" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                О компании
              </NavLink>
            </li>
            <li>
              <NavLink to="/services" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                Услуги
              </NavLink>
            </li>
            <li>
              <NavLink to="/contacts" className={({ isActive }) => (isActive ? styles.active : '')} onClick={closeMenu}>
                Контакты
              </NavLink>
            </li>
          </ul>
          <Link to="/catalog/oblozhki" className="buttonPrimary" onClick={closeMenu}>
            Смотреть каталог
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;