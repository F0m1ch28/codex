import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import ScrollToTopOnRoute from './components/ScrollToTopOnRoute';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import CoversCatalog from './pages/CoversCatalog';
import AvatarsCatalog from './pages/AvatarsCatalog';
import BannersCatalog from './pages/BannersCatalog';
import Contacts from './pages/Contacts';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import NotFound from './pages/NotFound';

const App = () => {
  return (
    <div className="app-shell">
      <Header />
      <main id="main-content" className="main-content" tabIndex={-1}>
        <ScrollToTopOnRoute />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog/oblozhki" element={<CoversCatalog />} />
          <Route path="/catalog/avatarki" element={<AvatarsCatalog />} />
          <Route path="/catalog/bannery" element={<BannersCatalog />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contacts" element={<Contacts />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
};

export default App;