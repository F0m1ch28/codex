import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './NotFound.module.css';

const NotFound = () => {
  return (
    <>
      <Seo
        title="Страница не найдена — DigitalCovers"
        description="Запрошенная страница не найдена. Вернитесь на главную DigitalCovers."
        keywords="404, страница не найдена"
      />
      <section className={styles.section}>
        <div className="container">
          <div className={styles.card}>
            <span className={styles.code}>404</span>
            <h1>Похоже, эта страница исчезла</h1>
            <p>
              Возможно, ссылка устарела или была удалена. Проверьте адрес или вернитесь на главную страницу, чтобы
              продолжить знакомство с DigitalCovers.
            </p>
            <Link to="/" className="buttonPrimary">
              Вернуться на главную
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default NotFound;