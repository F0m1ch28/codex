import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const Services = () => {
  const [activeCategory, setActiveCategory] = useState('Все');

  const services = [
    {
      title: 'Брендинговый пакет для канала',
      description: 'Разработка полного визуального стиля: логотип, цветовая палитра, шрифтовая пара и гайдлайны.',
      benefits: ['Работаем по брифу', '3 концепции на выбор', 'Поддержка запуска'],
      image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=900&q=80',
    },
    {
      title: 'Адаптация существующих шаблонов',
      description: 'Подберём цвета, заменим тексты, подготовим файлы под нужные размеры и платформы.',
      benefits: ['Сохранение фирменного стиля', 'Оптимизация под мобильные', 'Подготовка превью'],
      image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=900&q=70',
    },
    {
      title: 'Анимация и интро для видео',
      description: 'Создаём анимированные заставки, переходы и титры для стримов и видеороликов.',
      benefits: ['Motion-графика', 'Файлы в форматах MP4/WebM', 'Звук и синхронизация'],
      image: 'https://images.unsplash.com/photo-1528756514091-dee5ecaa3278?auto=format&fit=crop&w=900&q=80',
    },
  ];

  const workflow = [
    {
      step: '1. Брифование',
      detail: 'Обсуждаем цели, аудиторию и платформы. Собираем референсы и пожелания по стилю.',
    },
    {
      step: '2. Концепция',
      detail: 'Готовим визуальные концепты и прототипы. Совместно выбираем направление.',
    },
    {
      step: '3. Продакшен',
      detail: 'Создаём дизайн-пакеты, подготавливаем файлы, тестируем адаптив.',
    },
    {
      step: '4. Внедрение и поддержка',
      detail: 'Помогаем внедрить визуалы на платформы, предоставляем инструкции и дополнительную поддержку.',
    },
  ];

  const projectCategories = ['Все', 'Стриминг', 'YouTube', 'Социальные сети'];

  const projects = [
    {
      title: 'Overlay для международного турнира',
      category: 'Стриминг',
      image: 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=1000&q=80',
    },
    {
      title: 'Сериал экспертных интервью',
      category: 'YouTube',
      image: 'https://images.unsplash.com/photo-1508921912186-1d1a45ebb3c1?auto=format&fit=crop&w=1000&q=80',
    },
    {
      title: 'Набор Reels для бренда одежды',
      category: 'Социальные сети',
      image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1000&q=80',
    },
    {
      title: 'Пакет «Старт стрима» с анимацией',
      category: 'Стриминг',
      image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1000&q=80',
    },
    {
      title: 'Серия обложек для обучающих курсов',
      category: 'YouTube',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=1000&q=80',
    },
    {
      title: 'Социальный набор для запуска продукта',
      category: 'Социальные сети',
      image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1000&q=80',
    },
  ];

  const filteredProjects =
    activeCategory === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  return (
    <>
      <Seo
        title="Услуги DigitalCovers — кастомный дизайн и брендинг"
        description="Закажите индивидуальные обложки, баннеры и бренд-пакеты для вашего канала. DigitalCovers предлагает кастомизацию и поддержку."
        keywords="индивидуальный дизайн, кастомные баннеры, брендинг канала, услуги DigitalCovers"
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Индивидуальные услуги и кастомизация</h1>
            <p>
              Когда вам нужен уникальный стиль или адаптация под сложный брендбук, команда DigitalCovers берёт проект в
              работу. Мы делаем кастомные пакеты для стримеров, продакшен-студий и образовательных платформ.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.services} aria-labelledby="services-list">
        <div className="container">
          <h2 id="services-list">Что мы предлагаем</h2>
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <img src={service.image} alt={service.title} loading="lazy" />
                <div className={styles.serviceContent}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <ul>
                    {service.benefits.map((benefit) => (
                      <li key={benefit}>{benefit}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <div className="container">
          <h2 id="process-title">Процесс работы</h2>
          <div className={styles.workflowGrid}>
            {workflow.map((stage) => (
              <article key={stage.step} className={styles.workflowCard}>
                <h3>{stage.step}</h3>
                <p>{stage.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-title">
        <div className="container">
          <div className={styles.projectsHeader}>
            <h2 id="projects-title">Недавние проекты</h2>
            <div className={styles.projectFilters}>
              {projectCategories.map((category) => (
                <button
                  type="button"
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`${styles.projectFilterButton} ${
                    activeCategory === category ? styles.projectFilterActive : ''
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectInfo}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;