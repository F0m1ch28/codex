import React from 'react';
import ProductCard from '../components/ProductCard';
import Seo from '../components/Seo';
import styles from './Catalog.module.css';

const BannersCatalog = () => {
  const items = [
    {
      id: 1,
      title: 'Live Studio Set',
      category: 'Баннеры',
      description: 'Комплект стартовых и переходных сцен для Twitch и YouTube.',
      image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 2,
      title: 'Stream Essentials',
      category: 'Баннеры',
      description: 'Плашки «скоро начнём», «перерыв» и «спасибо», выдержанные в едином стиле.',
      image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 3,
      title: 'Influencer Launch',
      category: 'Баннеры',
      description: 'Яркие баннеры для запуска проектов и рекламных кампаний.',
      image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1000&q=70',
    },
    {
      id: 4,
      title: 'Event Stream Pack',
      category: 'Баннеры',
      description: 'Динамичные сцены для живых мероприятий и онлайн-конференций.',
      image: 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 5,
      title: 'Minimal Flow',
      category: 'Баннеры',
      description: 'Чистые макеты для образовательных трансляций и вебинаров.',
      image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 6,
      title: 'Night Mode',
      category: 'Баннеры',
      description: 'Глубокие цвета и неоновые акценты для вечерних стримов.',
      image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1000&q=70',
    },
  ];

  return (
    <>
      <Seo
        title="Каталог баннеров — DigitalCovers"
        description="Готовые баннеры и сцены для стриминговых платформ. Выберите комплект DigitalCovers для своих эфиров."
        keywords="баннеры для стрима, overlay twitch, стримерский дизайн, сцены для трансляций"
      />

      <section className={styles.heroSection}>
        <div className="container">
          <h1>Каталог баннеров</h1>
          <p>
            Полноценные пакеты для стриминга: стартовые сцены, экран ожидания, плашки и уведомления. Всё готово к
            настройке в OBS и Streamlabs.
          </p>
        </div>
      </section>

      <section className={styles.catalogGrid}>
        <div className="container">
          <div className={styles.grid}>
            {items.map((item) => (
              <ProductCard key={item.id} {...item} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default BannersCatalog;