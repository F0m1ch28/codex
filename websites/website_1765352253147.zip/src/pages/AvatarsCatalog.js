import React from 'react';
import ProductCard from '../components/ProductCard';
import Seo from '../components/Seo';
import styles from './Catalog.module.css';

const AvatarsCatalog = () => {
  const items = [
    {
      id: 1,
      title: 'Squad Legends',
      category: 'Аватарки',
      description: 'Серия для команд и киберспортивных сообществ в стиле sci-fi.',
      image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 2,
      title: 'Creator Identity',
      category: 'Аватарки',
      description: 'Персональные аватарки с акцентом на типографику и фирменные цвета.',
      image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 3,
      title: 'Badge Kit',
      category: 'Аватарки',
      description: 'Набор бейджей и иконок для систем подписки и уровней.',
      image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 4,
      title: 'Pixel Portraits',
      category: 'Аватарки',
      description: 'Игровой стиль с пиксельной графикой и яркими градиентами.',
      image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 5,
      title: 'Community Logos',
      category: 'Аватарки',
      description: 'Логотипы для Discord-серверов и комьюнити-порталов.',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 6,
      title: 'Retro Vibez',
      category: 'Аватарки',
      description: 'Вдохновение ретро-волн и синтвейва для музыкальных проектов.',
      image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=80',
    },
  ];

  return (
    <>
      <Seo
        title="Каталог аватарок — DigitalCovers"
        description="Узнаваемые аватарки и логотипы для команд, сообществ и авторского бренда. Изучите коллекцию DigitalCovers."
        keywords="аватарки, логотипы для стрима, дизайн аватарок, цифровые бейджи"
      />

      <section className={styles.heroSection}>
        <div className="container">
          <h1>Каталог аватарок</h1>
          <p>
            Подчеркните стиль канала и объедините комьюнити вокруг визуального образа. В подборке — логотипы, бейджи и
            наборы иконок для разных уровней подписки.
          </p>
        </div>
      </section>

      <section className={styles.catalogGrid}>
        <div className="container">
          <div className={styles.grid}>
            {items.map((item) => (
              <ProductCard key={item.id} {...item} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default AvatarsCatalog;