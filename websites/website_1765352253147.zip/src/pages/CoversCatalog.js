import React from 'react';
import ProductCard from '../components/ProductCard';
import Seo from '../components/Seo';
import styles from './Catalog.module.css';

const CoversCatalog = () => {
  const items = [
    {
      id: 1,
      title: 'Серии «Разбор трендов»',
      category: 'Обложки',
      description: 'Инфографика и крупные заголовки для аналитического контента.',
      image: 'https://images.unsplash.com/photo-1531498860502-7c67cf02f77b?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 2,
      title: 'Neon Pulse',
      category: 'Обложки',
      description: 'Энергичный стиль для гейминг-каналов и обзорщиков.',
      image: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 3,
      title: 'MasterClass Series',
      category: 'Обложки',
      description: 'Минималистичный стиль для образовательных курсов и лекций.',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 4,
      title: 'Create More',
      category: 'Обложки',
      description: 'Яркие акценты и крупная типографика для креативных роликов.',
      image: 'https://images.unsplash.com/photo-1488866022504-f2584929ca5f?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 5,
      title: 'Tech Digest',
      category: 'Обложки',
      description: 'Геометрические узоры и прогрессивная палитра для IT-контента.',
      image: 'https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?auto=format&fit=crop&w=1000&q=80',
    },
    {
      id: 6,
      title: 'Creator Stories',
      category: 'Обложки',
      description: 'Сдержанные цвета и выразительные акценты для подкастов и интервью.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1000&q=80',
    },
  ];

  return (
    <>
      <Seo
        title="Каталог обложек — DigitalCovers"
        description="Готовые обложки для YouTube, обучающих курсов и подкастов. Современные коллекции от DigitalCovers."
        keywords="обложки YouTube, превью видео, дизайн обложек, DigitalCovers обложки"
      />

      <section className={styles.heroSection}>
        <div className="container">
          <h1>Каталог обложек</h1>
          <p>
            Коллекции обложек, созданные для разных форматов: образовательные курсы, игровые стримы, интервью и обзоры.
            Каждая серия включает готовые PSD и PNG файлы для быстрого редактирования.
          </p>
        </div>
      </section>

      <section className={styles.catalogGrid}>
        <div className="container">
          <div className={styles.grid}>
            {items.map((item) => (
              <ProductCard key={item.id} {...item} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default CoversCatalog;