import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import Seo from '../components/Seo';
import styles from './Home.module.css';

const Home = () => {
  const [activeFilter, setActiveFilter] = useState('Все');
  const [openQuestion, setOpenQuestion] = useState('Как быстро я получу дизайн?');

  const advantages = [
    {
      title: 'Высокое качество',
      description:
        'Каждый макет создаётся опытными дизайнерами и проходит ручную проверку перед публикацией.',
      icon: '🎨',
    },
    {
      title: 'Быстрая доставка',
      description:
        'Мгновенное скачивание готовых файлов и настройка под ваши размеры в течение суток.',
      icon: '⚡️',
    },
    {
      title: 'Поддержка форматов',
      description:
        'PSD, PNG, JPG и готовые шаблоны для Photoshop, Figma и Canva — мы подготовили всё заранее.',
      icon: '🧩',
    },
    {
      title: 'Лёгкая интеграция',
      description:
        'Инструкции и видео-гайды помогут быстро адаптировать дизайн под ваш канал или сообщество.',
      icon: '🧭',
    },
  ];

  const stats = [
    { label: 'Уникальных дизайнов', value: '5 400+' },
    { label: 'Авторов по всему миру', value: '28 000+' },
    { label: 'Средняя оценка', value: '4.9/5' },
    { label: 'Минут до готового файла', value: '15' },
  ];

  const categories = [
    {
      title: 'Обложки для видео',
      description: 'Яркие визуалы для YouTube, Vimeo и обучающих платформ.',
      to: '/catalog/oblozhki',
      image:
        'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80',
    },
    {
      title: 'Аватарки и логотипы',
      description: 'Узнаваемый стиль для каналов, дискорд-серверов и сообществ.',
      to: '/catalog/avatarki',
      image:
        'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    },
    {
      title: 'Баннеры для стримов',
      description: 'Подложки, стартовые экраны и переходы для Twitch и Trovo.',
      to: '/catalog/bannery',
      image:
        'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1200&q=80',
    },
  ];

  const popularProducts = [
    {
      id: 1,
      title: 'Неоновая обложка для игровых стримов',
      category: 'Обложки',
      description: 'Акцент на динамику, идеально для запусков новых сезонов и DLC.',
      image: 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=900&q=80',
    },
    {
      id: 2,
      title: 'Минималистичная миниатюра для интервью',
      category: 'Обложки',
      description: 'Чистая композиция и крупная типографика для экспертных видео.',
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80',
    },
    {
      id: 3,
      title: 'Динамический баннер «Скоро в эфире»',
      category: 'Баннеры',
      description: 'Отлично подходит для Twitch и YouTube Live, адаптив под мобильные устройства.',
      image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=900&q=80',
    },
    {
      id: 4,
      title: 'Энергичная аватарка для команды',
      category: 'Аватарки',
      description: 'Командный стиль с геометрическими акцентами и эффектом глубины.',
      image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80',
    },
    {
      id: 5,
      title: 'Анимированный пакет для стримера',
      category: 'Баннеры',
      description: 'Стартовые, пауза и финальные сцены в едином стиле.',
      image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=900&q=80',
    },
    {
      id: 6,
      title: 'Серия миниатюр для образовательного курса',
      category: 'Обложки',
      description: 'Структурированные макеты для длинных серий уроков.',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=900&q=80',
    },
    {
      id: 7,
      title: 'Пакет бейджей для подписчиков',
      category: 'Аватарки',
      description: 'Уровни подписки, выполненные в единой цветовой палитре.',
      image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=900&q=80',
    },
    {
      id: 8,
      title: 'Обложка «Разбор трендов»',
      category: 'Обложки',
      description: 'Контрастные цвета и графики для аналитических роликов.',
      image: 'https://images.unsplash.com/photo-1531498860502-7c67cf02f77b?auto=format&fit=crop&w=900&q=80',
    },
  ];

  const testimonials = [
    {
      quote:
        'DigitalCovers помог выделить мой канал на фоне конкурентов. Обложки привлекают внимание, а CTR вырос на 37%.',
      name: 'Анна Журавлёва',
      role: 'YouTube-креатор и подкастер',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    },
    {
      quote:
        'Нам понравилась скорость. Получили настроенный пакет баннеров за вечер. Теперь эфиры выглядят профессионально.',
      name: 'Team Nexus',
      role: 'Киберспортивная организация',
      avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80',
    },
  ];

  const faq = [
    {
      question: 'Как быстро я получу дизайн?',
      answer:
        'Готовые шаблоны доступны сразу после покупки. Услуги кастомизации занимают от 12 до 48 часов в зависимости от сложности.',
    },
    {
      question: 'Можно ли адаптировать дизайн под мои цвета?',
      answer:
        'Да, мы подберём палитру под ваш бренд. В каждой категории есть опция «Адаптация» — оставьте комментарий при заказе.',
    },
    {
      question: 'Какие инструменты нужны для редактирования?',
      answer:
        'Большинство пакетов идут с файлами PSD и Canva. Также доступны форматы PNG и JPG, которые можно использовать без редактирования.',
    },
    {
      question: 'Предоставляете ли вы поддержку?',
      answer:
        'Команда дизайнеров на связи в рабочие часы. Пишите на info@digitalcovers.ru или через форму на странице контактов.',
    },
  ];

  const blogPosts = [
    {
      title: 'Как оформить YouTube канал в 2024 году',
      excerpt: 'Разбираем тренды визуального брендинга и готовые чек-листы для обложек и баннеров.',
      date: '12 февраля 2024',
      image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80',
      link: '/services',
    },
    {
      title: 'Гайд по Twitch Overlays: что обязательно нужно иметь',
      excerpt: 'Собрали список ключевых экранов и советов по их оформлению для стримеров.',
      date: '28 января 2024',
      image: 'https://images.unsplash.com/photo-1590608897129-79da98d15969?auto=format&fit=crop&w=800&q=80',
      link: '/catalog/bannery',
    },
    {
      title: 'Фирменный стиль для creator-экономики',
      excerpt: 'Рассказываем, как сформировать айдентику и поддерживать единый визуальный язык.',
      date: '10 января 2024',
      image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80',
      link: '/about',
    },
  ];

  const filters = ['Все', 'Обложки', 'Аватарки', 'Баннеры'];
  const filteredProducts =
    activeFilter === 'Все'
      ? popularProducts
      : popularProducts.filter((item) => item.category === activeFilter);

  const toggleQuestion = (question) => {
    setOpenQuestion((prev) => (prev === question ? '' : question));
  };

  return (
    <>
      <Seo
        title="DigitalCovers — Цифровые обложки и аватарки для вашего контента"
        description="DigitalCovers создаёт профессиональные обложки, аватарки и баннеры для авторов по всему миру. Изучите каталоги, вдохновение и услуги кастомизации."
        keywords="обложки для видео, аватарки, баннеры для стримов, миниатюры YouTube, графика для соцсетей, цифровой контент"
      />

      <section
        className={styles.hero}
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1600&q=80')",
        }}
      >
        <div className={`container ${styles.heroContent}`}>
          <span className={styles.heroTag}>Международная платформа цифрового дизайна</span>
          <h1>Цифровые обложки и аватарки для вашего контента</h1>
          <p className={styles.heroSubtitle}>
            Создавайте узнаваемый визуальный стиль для YouTube, Twitch, TikTok и социальных сетей. Мы объединяем лучшие
            практики дизайна и опыт работы с тысячами креаторов.
          </p>
          <div className={styles.heroActions}>
            <Link to="/catalog/oblozhki" className="buttonPrimary">
              Смотреть каталог
            </Link>
            <Link to="/services" className="buttonSecondary">
              Индивидуальные решения
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.advantages} aria-labelledby="advantages-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="advantages-heading">Преимущества DigitalCovers</h2>
            <p>Мы создаём дизайн, который помогает вашему контенту расти и формировать сообщество.</p>
          </div>
          <div className={styles.advantageGrid}>
            {advantages.map((item) => (
              <article key={item.title} className={styles.advantageCard}>
                <span className={styles.advantageIcon} aria-hidden="true">
                  {item.icon}
                </span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
          <div className={styles.statsBar}>
            {stats.map((stat) => (
              <div key={stat.label} className={styles.statItem}>
                <span className={styles.statValue}>{stat.value}</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.categories} aria-labelledby="categories-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="categories-heading">Категории цифровых продуктов</h2>
            <p>Выберите направление, которое подходит вашему проекту, и адаптируйте дизайн под свои задачи.</p>
          </div>
          <div className={styles.categoryGrid}>
            {categories.map((category) => (
              <Link
                key={category.title}
                to={category.to}
                className={styles.categoryCard}
                style={{ backgroundImage: `linear-gradient(125deg, rgba(15,23,42,0.7), rgba(99,102,241,0.55)), url('${category.image}')` }}
              >
                <div className={styles.categoryContent}>
                  <h3>{category.title}</h3>
                  <p>{category.description}</p>
                  <span className={styles.categoryLink}>
                    Изучить коллекцию <span aria-hidden="true">→</span>
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.popular} aria-labelledby="popular-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="popular-heading">Популярные дизайны месяца</h2>
            <p>Вдохновляйтесь и подбирайте решения под свой канал. Фильтруйте по типу контента.</p>
          </div>

          <div className={styles.filterBar} role="group" aria-label="Фильтрация популярных дизайнов">
            {filters.map((filter) => (
              <button
                type="button"
                key={filter}
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>

          <div className={styles.productGrid}>
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>

          <div className={styles.sideContent}>
            <div className={styles.testimonials}>
              <h3>Отзывы авторов</h3>
              <div className={styles.testimonialList}>
                {testimonials.map((testimonial) => (
                  <blockquote key={testimonial.name} className={styles.testimonialCard}>
                    <p>“{testimonial.quote}”</p>
                    <div className={styles.testimonialAuthor}>
                      <img src={testimonial.avatar} alt={testimonial.name} loading="lazy" />
                      <div>
                        <span className={styles.authorName}>{testimonial.name}</span>
                        <span className={styles.authorRole}>{testimonial.role}</span>
                      </div>
                    </div>
                  </blockquote>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="process-heading">Как это работает</h2>
            <p>От выбора дизайна до скачивания файлов — всё продумано и прозрачно.</p>
          </div>

          <div className={styles.processGrid}>
            <article className={styles.processCard}>
              <span className={styles.processStep}>01</span>
              <h3>Выбор дизайна</h3>
              <p>
                Изучите коллекцию и выберите стиль, который отражает характер вашего контента. В каталоге доступны
                превью и структура каждого шаблона.
              </p>
            </article>
            <article className={styles.processCard}>
              <span className={styles.processStep}>02</span>
              <h3>Настройка</h3>
              <p>
                Укажите необходимые размеры, цвета и текст. Наши специалисты адаптируют дизайн под ваши требования или
                подготовят инструкции для самостоятельной настройки.
              </p>
            </article>
            <article className={styles.processCard}>
              <span className={styles.processStep}>03</span>
              <h3>Скачивание</h3>
              <p>
                Получите файлы в нужных форматах и инструкцию по использованию. При необходимости команда сопровождает
                вас на этапе публикации.
              </p>
            </article>
          </div>

          <div className={styles.faq}>
            <h3>FAQ: частые вопросы</h3>
            <div className={styles.faqList}>
              {faq.map((item) => (
                <div key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    onClick={() => toggleQuestion(item.question)}
                    aria-expanded={openQuestion === item.question}
                  >
                    {item.question}
                    <span aria-hidden="true">{openQuestion === item.question ? '−' : '+'}</span>
                  </button>
                  {openQuestion === item.question && <p>{item.answer}</p>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-heading">
        <div className="container">
          <div className={styles.ctaInner}>
            <div className={styles.ctaContent}>
              <h2 id="cta-heading">Начните улучшать ваш контент уже сегодня</h2>
              <p>
                С DigitalCovers аудитория сразу узнаёт ваш канал. Создайте библиотеку визуалов, увеличьте вовлеченность
                и работайте в едином стиле на всех платформах.
              </p>
              <div className={styles.ctaActions}>
                <Link to="/catalog/oblozhki" className="buttonPrimary">
                  Исследовать каталог
                </Link>
                <Link to="/contacts" className="buttonSecondary">
                  Связаться с командой
                </Link>
              </div>
            </div>
            <div className={styles.blogPreview}>
              <h3>Свежие материалы</h3>
              <ul>
                {blogPosts.map((post) => (
                  <li key={post.title}>
                    <Link to={post.link}>
                      <img src={post.image} alt={post.title} loading="lazy" />
                      <div>
                        <span className={styles.blogDate}>{post.date}</span>
                        <h4>{post.title}</h4>
                        <p>{post.excerpt}</p>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;