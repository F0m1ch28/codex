import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contacts.module.css';

const Contacts = () => {
  const [formData, setFormData] = useState({ name: '', email: '', topic: '', message: '' });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus({ type: 'error', message: 'Пожалуйста, заполните обязательные поля формы.' });
      return;
    }
    setStatus({ type: 'success', message: 'Спасибо! Мы свяжемся с вами в ближайшее время.' });
    setFormData({ name: '', email: '', topic: '', message: '' });
  };

  return (
    <>
      <Seo
        title="Контакты DigitalCovers — свяжитесь с нами"
        description="Напишите команде DigitalCovers, чтобы получить консультацию или заказать индивидуальный дизайн. Телефон, email и форма обратной связи."
        keywords="контакты DigitalCovers, связаться с дизайнером, консультация по дизайну"
      />

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.info}>
              <h1>Свяжитесь с DigitalCovers</h1>
              <p>
                Расскажите о проекте, и мы предложим подходящий формат сотрудничества. Отправьте запрос через форму или
                напишите напрямую.
              </p>

              <div className={styles.contactDetails}>
                <div>
                  <span className={styles.label}>Адрес</span>
                  <p>ул. Цифровая, 42, Москва, Россия, 123456</p>
                </div>
                <div>
                  <span className={styles.label}>Телефон</span>
                  <p>
                    <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                  </p>
                </div>
                <div>
                  <span className={styles.label}>Email</span>
                  <p>
                    <a href="mailto:info@digitalcovers.ru">info@digitalcovers.ru</a>
                  </p>
                </div>
              </div>

              <div className={styles.supportHours}>
                <h3>График поддержки</h3>
                <p>Понедельник — пятница: 10:00–19:00 (MSK)</p>
                <p>Суббота: 11:00–16:00 (MSK)</p>
              </div>
            </div>

            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Написать нам</h2>
              <div className={styles.grid}>
                <label>
                  Имя *
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Как к вам обращаться?"
                    required
                  />
                </label>
                <label>
                  Email *
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="example@email.com"
                    required
                  />
                </label>
              </div>
              <label>
                Тема
                <input
                  type="text"
                  name="topic"
                  value={formData.topic}
                  onChange={handleChange}
                  placeholder="Например: «Обложки для нового подкаста»"
                />
              </label>
              <label>
                Сообщение *
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows="6"
                  placeholder="Опишите задачу и желаемые сроки..."
                  required
                />
              </label>
              <button type="submit" className="buttonPrimary">
                Отправить сообщение
              </button>
              {status.message && (
                <p className={status.type === 'success' ? styles.success : styles.error}>{status.message}</p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contacts;