import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const About = () => {
  const team = [
    {
      name: 'Полина Герасимова',
      role: 'Руководитель креативной команды',
      bio: '10 лет в дизайне для media и стриминга. Руководит визуальными стандартами DigitalCovers.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Максим Руденко',
      role: 'Арт-директор',
      bio: 'Разрабатывает уникальные коллекции и следит за трендами индустрии.',
      image: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Елена Ткаченко',
      role: 'Head of Community',
      bio: 'Отвечает за обратную связь с авторами и запуск обучающих инициатив.',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
    },
  ];

  const values = [
    {
      title: 'Уважение к автору',
      description: 'Мы создаём дизайн, который помогает выразить индивидуальность контент-мейкеров.',
    },
    {
      title: 'Честность и прозрачность',
      description: 'Понятные условия использования и поддержка на каждом этапе сотрудничества.',
    },
    {
      title: 'Инновации',
      description: 'Используем новые форматы, анимацию и тренды, чтобы ваши визуалы всегда выглядели свежо.',
    },
  ];

  const milestones = [
    {
      year: '2018',
      title: 'Запуск платформы',
      description: 'DigitalCovers появилась как сервис для YouTube-блогеров и быстро нашла первых клиентов.',
    },
    {
      year: '2020',
      title: 'Выход на международный рынок',
      description: 'Перевели каталоги на английский и испанский, подключили дизайнеров из 7 стран.',
    },
    {
      year: '2022',
      title: 'Интеграция с Twitch и TikTok',
      description: 'Добавили специальные баннеры, интро и шаблоны для вертикального видео.',
    },
    {
      year: '2023',
      title: 'Сообщество DigitalCovers Club',
      description: 'Запустили закрытый клуб с воркшопами и консультациями по развитию контента.',
    },
  ];

  return (
    <>
      <Seo
        title="О компании DigitalCovers — команда и миссия"
        description="Узнайте историю DigitalCovers, познакомьтесь с командой и принципами работы. Мы помогаем авторам развивать визуальный стиль."
        keywords="DigitalCovers команда, история компании, дизайн для стримеров, визуальный стиль"
      />

      <section className={styles.intro}>
        <div className="container">
          <div className={styles.introContent}>
            <h1>Мы помогаем создателям контента говорить визуальным языком</h1>
            <p>
              DigitalCovers — это команда дизайнеров, продуктологов и аналитиков, объединённых одной целью — сделать
              профессиональную графику доступной каждому автору. Мы разрабатываем коллекции визуалов, которые легко
              адаптируются под формат, платформу и аудиторию.
            </p>
            <p>
              Наша миссия — поддерживать креаторов по всему миру, помогая им строить бренды, развивать аудиторию и
              получать удовольствие от процесса создания контента.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.timeline} aria-labelledby="timeline-heading">
        <div className="container">
          <h2 id="timeline-heading">Основные этапы развития</h2>
          <div className={styles.milestoneGrid}>
            {milestones.map((item) => (
              <article key={item.year} className={styles.milestone}>
                <span className={styles.milestoneYear}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.values} aria-labelledby="values-heading">
        <div className="container">
          <h2 id="values-heading">Наши принципы</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <div className="container">
          <div className={styles.teamHeader}>
            <h2 id="team-heading">Команда DigitalCovers</h2>
            <p>
              Мы объединяем людей с международным опытом в графическом дизайне, брендинге и создании мультимедийного
              контента. Каждый проект проходит через команды качества и поддержки.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;