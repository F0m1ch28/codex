document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('[data-nav-toggle]');
    const navMenu = document.querySelector('[data-nav-menu]');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 1024) {
                navMenu.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const consentChoice = localStorage.getItem('chiarotahw_cookie_consent');
        if (consentChoice) {
            cookieBanner.classList.add('is-hidden');
        }
        cookieBanner.querySelectorAll('[data-consent]').forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.dataset.consent;
                localStorage.setItem('chiarotahw_cookie_consent', choice);
                cookieBanner.classList.add('is-hidden');
                const linkTarget = button.getAttribute('href');
                if (linkTarget) {
                    window.open(linkTarget, '_blank', 'noopener');
                }
            });
        });
    }

    document.querySelectorAll('[data-tabs]').forEach(tabGroup => {
        const triggers = tabGroup.querySelectorAll('[data-tab-trigger]');
        const panels = tabGroup.querySelectorAll('[data-tab-panel]');
        if (!triggers.length || !panels.length) {
            return;
        }
        const activateTab = trigger => {
            const target = trigger.dataset.tabTrigger;
            triggers.forEach(btn => btn.classList.remove('is-active'));
            panels.forEach(panel => panel.classList.remove('is-active'));
            trigger.classList.add('is-active');
            const activePanel = tabGroup.querySelector(`[data-tab-panel="${target}"]`);
            if (activePanel) {
                activePanel.classList.add('is-active');
            }
        };
        triggers.forEach(trigger => {
            trigger.addEventListener('click', () => activateTab(trigger));
        });
        activateTab(triggers[0]);
    });

    const progressObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const bar = entry.target;
                const targetValue = parseInt(bar.dataset.progress, 10) || 0;
                bar.style.setProperty('--progress', targetValue);
                bar.classList.add('is-visible');
                progressObserver.unobserve(bar);
            }
        });
    }, { threshold: 0.3 });

    document.querySelectorAll('.progress-bar[data-progress]').forEach(bar => {
        progressObserver.observe(bar);
    });
});