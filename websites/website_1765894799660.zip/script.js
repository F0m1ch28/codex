document.addEventListener("DOMContentLoaded", function () {
  var banner = document.getElementById("cookie-banner");
  if (!banner) {
    return;
  }
  var acceptButton = banner.querySelector('[data-cookie="accept"]');
  var declineButton = banner.querySelector('[data-cookie="decline"]');
  var storageAvailable = true;
  try {
    var testKey = "__cookie_test__";
    window.localStorage.setItem(testKey, testKey);
    window.localStorage.removeItem(testKey);
  } catch (error) {
    storageAvailable = false;
  }
  var consent = storageAvailable ? window.localStorage.getItem("cookieConsent") : null;
  if (consent !== "accepted" && consent !== "declined") {
    requestAnimationFrame(function () {
      banner.classList.remove("is-hidden");
      banner.classList.add("is-visible");
    });
  }
  function setConsent(value) {
    if (storageAvailable) {
      window.localStorage.setItem("cookieConsent", value);
    }
    banner.classList.remove("is-visible");
    banner.classList.add("is-hidden");
  }
  if (acceptButton) {
    acceptButton.addEventListener("click", function () {
      setConsent("accepted");
    });
  }
  if (declineButton) {
    declineButton.addEventListener("click", function () {
      setConsent("declined");
    });
  }
});