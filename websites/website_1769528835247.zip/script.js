const I18N = {
  fr: {
    meta: {
      home: {
        title: "Comunidad IA Salud-Energía - Réseau de professionnels",
        description: "Réseau espagnol reliant santé et énergie autour de l’IA, forums, bibliothèque et projets collaboratifs."
      },
      services: {
        title: "Services collaboratifs - Comunidad IA Salud-Energía",
        description: "Panorama des forums, groupes régionaux, tableaux de projets et accompagnements proposés par la communauté."
      },
      about: {
        title: "À propos - Comunidad IA Salud-Energía",
        description: "Mission, gouvernance, valeurs et perspectives du réseau IA santé-énergie espagnol."
      },
      blog: {
        title: "Blog - Comunidad IA Salud-Energía",
        description: "Analyses, études de cas et retours d’expérience sur l’IA appliquée aux soins et à l’énergie."
      },
      post1: {
        title: "Intégrer données cliniques et énergétiques - Comunidad IA Salud-Energía",
        description: "Article sur la convergence des données cliniques et énergétiques pour renforcer la résilience des hôpitaux espagnols."
      },
      post2: {
        title: "Explicabilité et performance pour l’IA clinique-énergie - Comunidad IA",
        description: "Approches pour équilibrer transparence, performance et adoption interdisciplinaire des modèles d’IA."
      },
      post3: {
        title: "Coordonner les ressources énergétiques distribuées - Comunidad IA",
        description: "Guide stratégique pour piloter des micro-réseaux hospitaliers et renforcer la résilience énergétique."
      },
      post4: {
        title: "Design centré humain et IA clinique-énergie - Comunidad IA",
        description: "Principes de design pour intégrer l’IA dans les organisations hospitalières sans perturber les équipes."
      },
      post5: {
        title: "Mesurer la décarbonation via la maintenance prédictive - Comunidad IA",
        description: "Méthodologie pour quantifier les gains climatiques générés par la maintenance prédictive en milieu hospitalier."
      },
      contact: {
        title: "Contact - Comunidad IA Salud-Energía",
        description: "Coordonnées, formulaire de contact et localisation du siège madrilène de la communauté."
      },
      faq: {
        title: "FAQ - Comunidad IA Salud-Energía",
        description: "Réponses aux questions fréquentes sur l’adhésion, les forums et la gouvernance du réseau."
      },
      terms: {
        title: "Conditions d’utilisation - Comunidad IA Salud-Energía",
        description: "Cadre contractuel, obligations et responsabilités des membres de la communauté."
      },
      privacy: {
        title: "Politique de confidentialité - Comunidad IA Salud-Energía",
        description: "Traitements de données, droits des membres et mesures de sécurité appliqués par la communauté."
      },
      cookies: {
        title: "Politique relative aux cookies - Comunidad IA Salud-Energía",
        description: "Inventaire des cookies et explications sur la gestion des préférences de suivi."
      },
      refund: {
        title: "Politique d’ajustement des contributions - Comunidad IA Salud-Energía",
        description: "Processus de gestion des annulations, reports et réaffectations des engagements communautaires."
      },
      disclaimer: {
        title: "Avertissement - Comunidad IA Salud-Energía",
        description: "Limites de responsabilité et rappels sur la portée informative des contenus publiés."
      },
      thankYou: {
        title: "Merci - Comunidad IA Salud-Energía",
        description: "Confirmation de réception de votre message par la communauté IA Salud-Energía."
      },
      notFound: {
        title: "Page introuvable - Comunidad IA Salud-Energía",
        description: "Erreur 404 : la page demandée n’existe plus ou a été déplacée."
      }
    },
    brand: {
      name: "Comunidad IA Salud-Energía - Red de Profesionales"
    },
    skip: {
      link: "Aller au contenu principal"
    },
    nav: {
      home: "Accueil",
      services: "Services collaboratifs",
      about: "À propos",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact",
      aria: "Navigation principale"
    },
    lang: {
      fr: "Français",
      en: "English",
      switcherLabel: "Sélecteur de langue"
    },
    buttons: {
      openMenu: "Ouvrir le menu",
      closeMenu: "Fermer le menu"
    },
    common: {
      readMore: "Lire la suite",
      learnMore: "En savoir plus",
      viewDetails: "Voir les détails",
      contactTeam: "Contacter l’équipe",
      backToBlog: "Revenir au blog"
    },
    footer: {
      tagline: "Intelligence collective pour les systèmes de santé et d’énergie en Espagne.",
      address: "Calle Innovación 1000, 28027 Madrid, Espagne",
      connectTitle: "Coordonnées",
      phone: "Téléphone : +34 91 555 7844",
      email: "Courriel : contact@comunidad-iaenergiahealthspain.com",
      linksTitle: "Références légales",
      terms: "Conditions d’utilisation",
      privacy: "Politique de confidentialité",
      cookies: "Politique de cookies",
      refund: "Politique d’ajustement",
      disclaimer: "Avertissement",
      rights: "© {year} Comunidad IA Salud-Energía - Red de Profesionales. Tous droits réservés."
    },
    cookieBanner: {
      title: "Gestion des cookies",
      description: "Nous utilisons des cookies pour analyser la participation, mémoriser vos préférences et améliorer la plateforme.",
      accept: "Tout accepter",
      decline: "Tout refuser",
      save: "Enregistrer les préférences",
      manage: "Personnaliser",
      categories: {
        necessary: "Cookies nécessaires",
        necessaryDescription: "Indispensables au fonctionnement du site et toujours actifs.",
        preferences: "Cookies de préférences",
        preferencesDescription: "Lien entre vos choix linguistiques et l’affichage du site.",
        analytics: "Cookies d’analyse",
        analyticsDescription: "Mesurent l’utilisation de manière agrégée pour améliorer les contenus.",
        marketing: "Cookies de communication",
        marketingDescription: "Coordonnent nos communications événementielles sur différents canaux."
      }
    },
    toasts: {
      formSuccess: "Demande transmise. Nous reviendrons vers vous prochainement."
    },
    images: {
      home: {
        heroAlt: "Professionnels analysant des tableaux de données collaboratifs.",
        recommendation1Alt: "Schéma de connecteurs de données.",
        recommendation2Alt: "Réunion autour de cartes énergétiques.",
        recommendation3Alt: "Tableau blanc avec notes interdisciplinaires."
      },
      about: {
        heroAlt: "Diagramme illustrant la mission du réseau Comunidad IA Salud-Energía."
      },
      services: {
        heroAlt: "Vue des infrastructures hospitalières connectées."
      },
      blog: {
        card1Alt: "Table de contrôle énergétique d’un hôpital.",
        card2Alt: "Radiologue observant une carte thermique générée par IA.",
        card3Alt: "Centre de contrôle d’un micro-réseau hospitalier.",
        card4Alt: "Atelier de design pluridisciplinaire dans un hôpital.",
        card5Alt: "Technicien évaluant des capteurs industriels."
      },
      posts: {
        post1HeroAlt: "Ingénieurs comparant graphiques cliniques et énergétiques.",
        post2HeroAlt: "Radiologue observant une visualisation explicable.",
        post3HeroAlt: "Salle technique avec batteries et panneaux de contrôle.",
        post4HeroAlt: "Atelier collaboratif centré sur l’utilisateur.",
        post5HeroAlt: "Intervention de maintenance sur équipement médical."
      }
    },
    home: {
      hero: {
        title: "Collaborer sur l’IA pour la santé et l’énergie en Espagne",
        subtitle: "La Comunidad IA Salud-Energía relie cliniciens, ingénieurs, chercheurs et managers qui articulent innovation médicale et infrastructures résilientes.",
        ctaPrimary: "Explorer la communauté",
        ctaSecondary: "Découvrir les services collaboratifs",
        metric1Value: "1 200",
        metric1Label: "professionnels engagés",
        metric2Value: "38",
        metric2Label: "partenaires hospitaliers",
        metric3Value: "640",
        metric3Label: "ressources partagées",
        figcaption: "Illustration d’équipes croisant données cliniques et énergétiques."
      },
      features: {
        title: "Concevoir des ponts entre soins cliniques et intelligence énergétique",
        intro: "La communauté met à disposition méthodes, gabarits et revues croisées pour aligner les projets d’IA sur la fiabilité opérationnelle des hôpitaux espagnols.",
        card1Title: "Architecture des forums clinique-énergie",
        card1Text: "Plans d’organisation et guides de modération pour conduire des discussions associant excellence diagnostique et résilience des infrastructures.",
        card1Link: "Voir l’architecture du forum",
        card2Title: "Chapitres régionaux",
        card2Text: "Cercles localisés en Andalousie, Catalogne, Madrid et Pays basque partageant des cas d’usage adaptés aux écosystèmes locaux.",
        card2Link: "Rencontrer les chapitres",
        card3Title: "Bibliothèque de preuves",
        card3Text: "Dépôts évalués par les pairs : jeux de données, notebooks de référence et check-lists pour équipes santé et énergie.",
        card3Link: "Parcourir les ressources",
        card4Title: "Radar d’intelligence collaborative",
        card4Text: "Synthèse trimestrielle des algorithmes émergents, modernisations d’infrastructures et évolutions de politiques pertinentes.",
        card4Link: "Consulter le radar"
      },
      recommendations: {
        title: "Recommandations du cercle de pilotage",
        subtitle: "Les coordinateurs bénévoles soulignent les priorités du trimestre.",
        card1Title: "Renforcer les fondations d’interopérabilité des données",
        card1Text: "Aligner vocabulaires FHIR, DICOM, BACnet et facturation énergétique afin de comparer les analyses en toute confiance.",
        card1Action: "Lire le guide",
        card2Title: "Co-concevoir des missions énergie avec des sponsors cliniques",
        card2Text: "Associer équipes techniques et responsables de service pour transformer les objectifs de décarbonation en feuilles de route actionnables.",
        card2Action: "Consulter la check-list",
        card3Title: "Structurer des comités de revue pluridisciplinaires",
        card3Text: "Programmer des séances où biomédical, SI et opérations examinent les sorties d’IA en soulignant sécurité et informations d’infrastructure.",
        card3Action: "Planifier un atelier"
      },
      testimonials: {
        title: "Voix du réseau",
        subtitle: "Des praticiens racontent comment la communauté soutient leurs ambitions partagées.",
        quote1: "Nos ingénieurs d’imagerie discutent désormais des indicateurs énergétiques avec la même clarté que des métriques de qualité d’image grâce au vocabulaire et aux preuves partagés dans le forum.",
        author1: "Laura Méndez",
        role1: "Responsable ingénierie d’imagerie, Hospital Clínic de Barcelona",
        quote2: "Les sessions mensuelles entre pairs nous ont fourni des retours exploitables pour refondre nos conseils de gouvernance et documenter la valeur perçue par le personnel clinique.",
        author2: "Diego Aranda",
        role2: "Coordinateur efficacité énergétique, Servicio Madrileño de Salud",
        quote3: "La bibliothèque communautaire nous a permis de comparer en une semaine plusieurs projets européens et d’orienter notre prochaine proposition de recherche collective.",
        author3: "Sofía Llorente",
        role3: "Responsable projets d’innovation, Instituto de Investigación Sanitaria La Fe"
      },
      timeline: {
        title: "Prochains jalons",
        subtitle: "Participez aux événements collaboratifs organisés en Espagne.",
        item1Title: "Atelier hybride sur les jeux de données fédérés",
        item1Date: "18 avril 2024 · Madrid",
        item1Text: "Plongée dans les standards de métadonnées et le calcul préservant la confidentialité pour les campus hospitaliers.",
        item2Title: "Clinique de cas : optimisation CVC en oncologie",
        item2Date: "8 mai 2024 · Valence (format hybride)",
        item2Text: "Analyse conjointe de scénarios de ventilation, de confort patient et de continuité des soins intensifs.",
        item3Title: "Table ronde politique avec autorités régionales",
        item3Date: "29 mai 2024 · Bilbao",
        item3Text: "Dialogue sur les indicateurs partagés entre services santé, énergie et planification territoriale."
      },
      resources: {
        title: "Dernières ressources partagées",
        subtitle: "Documents sélectionnés par les groupes de travail.",
        resource1Title: "Plan de référence pour la prévision multi-sites",
        resource1Text: "Note méthodologique reliant occupation, usage des équipements et modèles météo.",
        resource1Action: "Accéder au document",
        resource2Title: "Check-list d’intégration de l’IA en maintenance",
        resource2Text: "Plan étape par étape alignant alertes analytiques et rituels opérationnels.",
        resource2Action: "Ouvrir la check-list",
        resource3Title: "Synthèse sur l’éthique des modèles hybrides",
        resource3Text: "Cadre d’évaluation croisant comités cliniques, DPO et responsables énergie.",
        resource3Action: "Lire la synthèse"
      }
    },
    about: {
      hero: {
        title: "À propos de la Comunidad IA Salud-Energía",
        subtitle: "Un réseau professionnel tissant expertise médicale et responsabilité énergétique."
      },
      mission: {
        title: "Mission",
        text: "Nous aidons les hôpitaux et centres de recherche espagnols à aligner l’innovation pilotée par l’IA sur des infrastructures résilientes en facilitant l’échange de connaissances, le mentorat et l’expérimentation partagée."
      },
      model: {
        title: "Modèle opérationnel",
        text: "Des groupes de travail ouverts conçoivent des cadres communs, documentent des protocoles et testent des scénarios sur des bancs d’essai collectifs."
      },
      values: {
        title: "Valeurs",
        item1Title: "Intelligence collective",
        item1Text: "Chaque initiative est co-produite par des cliniciens, ingénieurs, chercheurs et gestionnaires pour refléter la diversité des pratiques.",
        item2Title: "Transparence éthique",
        item2Text: "Nous documentons sources de données, choix algorithmiques et effets attendus pour éclairer les comités de gouvernance.",
        item3Title: "Mesure de l’impact",
        item3Text: "Des indicateurs partagés combinent qualité de soins, continuité énergétique et apprentissages organisationnels."
      },
      partners: {
        title: "Alliances et partenariats",
        text: "Le réseau collabore avec universités, associations professionnelles, agences d’énergie et sociétés savantes pour mutualiser connaissances et infrastructures."
      },
      history: {
        title: "Évolution",
        text: "Créée en 2019 par un groupe de responsables hospitaliers, la communauté s’est étendue à dix régions et maintient un programme annuel de dialogues techniques."
      },
      team: {
        title: "Coordination bénévole",
        text: "Un comité de pilotage élu tous les deux ans anime les chapitres régionaux, maintient la bibliothèque et garantit l’inclusion des disciplines."
      },
      future: {
        title: "Perspectives",
        text: "Les priorités 2024 portent sur la modélisation énergétique multi-sites, l’intégration des évaluations cliniques dans les plans de rénovation et l’alignement des formations professionnelles."
      }
    },
    services: {
      hero: {
        title: "Services collaboratifs de la communauté",
        subtitle: "Neuf dispositifs soutiennent les équipes qui articulent santé et énergie."
      },
      items: {
        item1: {
          title: "Forums thématiques IA et énergie hospitalière",
          text: "Espaces modérés pour confronter modèles de diagnostic, supervision biomédicale et contraintes énergétiques."
        },
        item2: {
          title: "Groupes de mise en réseau régionaux",
          text: "Rencontres locales pour partager contextes réglementaires, fournisseurs et retours d’expérience."
        },
        item3: {
          title: "Tableau collaboratif de projets",
          text: "Inventaire vivant des recherches, pilotes industriels et initiatives entrepreneuriales recherchant des partenaires."
        },
        item4: {
          title: "Bibliothèque mutualisée de publications",
          text: "Accès à des articles, cas d’usage, guides techniques et synthèses d’audits."
        },
        item5: {
          title: "Panel d’experts pour consultations",
          text: "Professionnels volontaires répondant aux questions sur l’architecture, la conformité et les indicateurs."
        },
        item6: {
          title: "Annuaire des membres",
          text: "Recherche multicritère par métier, région et spécialité pour cartographier les compétences disponibles."
        },
        item7: {
          title: "Répertoire des partenaires",
          text: "Panorama des entreprises, associations et organismes soutenant les programmes communautaires."
        },
        item8: {
          title: "Calendrier des événements",
          text: "Agenda des ateliers, webinaires, visites de site et rencontres nationales."
        },
        item9: {
          title: "Section actualités",
          text: "Valorisation des réussites, publications et retours d’expérience des membres."
        }
      },
      framework: {
        title: "Fonctionnement de la participation",
        text: "Chaque service est accessible aux organisations publiques et repose sur la contribution active des membres.",
        point1: "Charte de collaboration validée par les conseils de gouvernance hospitaliers.",
        point2: "Cycle trimestriel d’objectifs et de retours d’expérience partagés.",
        point3: "Capitalisation documentaire dans la bibliothèque commune."
      },
      support: {
        title: "Ressources d’accompagnement",
        text: "Mentors, facilitateurs et experts juridiques apportent un soutien méthodologique lorsque les équipes initient un nouveau chantier."
      }
    },
    blog: {
      hero: {
        title: "Blog et analyses de la communauté",
        subtitle: "Études de cas, cadres méthodologiques et retours d’expérience sur l’IA appliquée à la santé et à l’énergie."
      },
      intro: "Chaque article est rédigé par des membres et relu collectivement afin de refléter la diversité des pratiques espagnoles.",
      cards: {
        post1: {
          title: "Intégrer les données cliniques et énergétiques pour des hôpitaux agiles",
          excerpt: "Comment relier archives médicales et capteurs d’infrastructure pour soutenir la résilience.",
          date: "Publié le 2 avril 2024"
        },
        post2: {
          title: "Équilibrer explicabilité et performance pour l’IA clinique-énergie",
          excerpt: "Cadres de transparence partagés entre radiologues et ingénieurs énergie.",
          date: "Publié le 19 mars 2024"
        },
        post3: {
          title: "Coordonner les ressources énergétiques distribuées dans les réseaux hospitaliers",
          excerpt: "Stratégies pour orchestrer micro-réseaux et priorités cliniques.",
          date: "Publié le 7 mars 2024"
        },
        post4: {
          title: "Ancrer le design centré humain dans les programmes IA hospitaliers",
          excerpt: "Approches pour observer les pratiques et soutenir l’adoption.",
          date: "Publié le 26 février 2024"
        },
        post5: {
          title: "Mesurer la décarbonation via la maintenance prédictive",
          excerpt: "Méthodologie pour relier analyses, émissions et valeur clinique.",
          date: "Publié le 14 février 2024"
        }
      }
    },
    posts: {
      shared: {
        summary: "En bref",
        published: "Publié : ",
        author: "Auteur : ",
        reading: "Temps de lecture : "
      },
      post1: {
        h1: "Intégrer données cliniques et énergétiques pour des hôpitaux plus intelligents",
        lead: "Les hôpitaux espagnols accumulent des flux de données distincts issus des archives d’imagerie, des protocoles cliniques, des capteurs du bâtiment et des consoles de gestion énergétique. Ces référentiels sont généralement administrés par des équipes séparées, de sorte que les initiatives d’IA reçoivent rarement des ensembles synchronisés décrivant l’écosystème complet des soins et de l’infrastructure. L’intégration des télémetries cliniques et énergétiques n’est donc pas qu’un exercice d’ingénierie, mais un engagement de gouvernance : chaque flux doit préserver son contexte, sa traçabilité et ses garde-fous de confidentialité tout en soutenant les questions de résilience opérationnelle et de qualité.",
        h2: "Architecturer des pipelines interopérables",
        p1: "Un pipeline interopérable commence par une sémantique harmonisée. Les équipes qui gèrent les enregistrements HL7 FHIR, les flux BACnet et les registres d’achats d’énergie doivent concevoir une ontologie partagée reliant identifiants de dispositifs, épisodes de soins et zones spatiales. Plutôt que d’ambitionner un entrepôt monolithique, de nombreux pilotes déploient aujourd’hui des couches fédérées qui exposent catalogues de métadonnées et courtiers de requêtes. Cette approche permet aux services d’oncologie ou de radiologie de fournir des instantanés structurés tout en conservant les preuves brutes dans les systèmes cliniques maîtrisés.",
        p2: "Les routines de qualité de données doivent ensuite s’itérer sur tout le cycle de vie. Des scripts de validation nocturne peuvent rapprocher les lectures de capteurs des journaux de maintenance, signalant des dérives de calibration ou des indisponibilités inattendues. Les cliniciens et responsables techniques devraient coanalyser les tableaux d’anomalies pour distinguer bruit opérationnel et alertes précoces. Lorsque les modèles d’IA prédisent la demande de froid ou l’occupation des lits, ils s’appuient sur des références fiables ; sinon, les optimisations risquent de déstabiliser la planification des équipes ou de compromettre les seuils de soins critiques.",
        h3: "Des insights opérationnels à la gouvernance stratégique",
        p3: "Une fois l’ossature technique en place, les comités de gouvernance peuvent se concentrer sur des cas d’usage apportant une valeur partagée. Un service de pneumologie peut souhaiter corréler les indicateurs de qualité de l’air avec la performance des ventilateurs, tandis que les responsables durabilité examinent l’impact sur l’intensité énergétique. Définir des cadres d’évaluation incluant indicateurs de sécurité patient, scores de confort et kWh garantit que les dialogues interdisciplinaires restent ancrés dans des résultats mesurables plutôt que dans un enthousiasme abstrait.",
        p4: "Une communication transparente demeure essentielle lorsque les analyses traversent les hiérarchies. Des synthèses mensuelles regroupant performance des modèles, incidents d’infrastructure et retours des cliniciens aident la direction à comparer les scénarios sans se noyer dans les données brutes. Des narrations visuelles reliant charges de pointe anticipées et contraintes de programmation chirurgicale peuvent déclencher des investissements opportuns dans des systèmes de secours ou des rénovations. De même, documenter les risques résiduels maintient la responsabilité vis-à-vis des comités d’éthique et des administrations publiques.",
        p5: "Enfin, les forums communautaires et les échanges de connaissances prolongent les enseignements au-delà de chaque hôpital. Partager des études de cas anonymisées montrant comment des ensembles combinés ont soutenu des plans de rénovation ou atténué des alarmes critiques aide les pairs à calibrer leurs attentes. Alors que l’Espagne investit dans des campus de santé résilients, l’intégration des intelligences énergétique et clinique devient un levier national de préparation. Chaque itération renforce le tissu collaboratif entre experts biomédicaux, ingénieurs de données et spécialistes des installations.",
        figureCaption: "Schéma reliant dossiers cliniques et infrastructures énergétiques.",
        date: "2 avril 2024",
        author: "Équipe éditoriale Comunidad IA Salud-Energía",
        reading: "Lecture : 7 minutes"
      },
      post2: {
        h1: "Équilibrer explicabilité et performance pour l’IA clinique-énergie",
        lead: "Les systèmes de santé qui expérimentent l’IA pour coordonner flux d’imagerie et opérations techniques peinent souvent à concilier exigences de transparence et ambitions de performance. Les radiologues exigent des justifications pour les anomalies relevées sur les scanners, tandis que les ingénieurs énergie attendent des raisonnements reproductibles lorsque les contrôles prédictifs ajustent les débits de ventilation. Construire une approche partagée de l’explicabilité suppose de comprendre attentes réglementaires et heuristiques quotidiennes, afin que les sorties algorithmiques prolongent l’expertise sans masquer la responsabilité.",
        h2: "Cartographier les attentes des parties prenantes",
        p1: "La cartographie des parties prenantes doit identifier qui consomme chaque sortie de modèle, quels horizons décisionnels ils pilotent et comment ils expriment leur confiance. Pour les équipes de radiologie, l’attention se porte sur des cartes thermiques mettant en évidence des zones de pixels ou des séquences temporelles. Le personnel technique préfère des courbes de tendance et des comparaisons de scénarios soulignant les seuils réglementaires. Traduire ces préférences en exigences d’interface garantit que les pipelines de post-traitement livrent des artefacts auxquels les utilisateurs font confiance.",
        p2: "Des ateliers de codesign convertissent ensuite les attentes en indicateurs mesurables de qualité d’explication. Les participants peuvent évaluer des prototypes selon la clarté, la rapidité et la facilité d’audit, produisant des références qui complètent précision ou erreur absolue moyenne. Intégrer des boucles de retour structurées au cycle de vie du modèle permet aux versions successives de démontrer des gains de communicabilité indispensables à l’adoption.",
        h3: "Opérationnaliser les techniques d’interprétabilité",
        p3: "Le choix de la bonne boîte à outils dépend de l’architecture du modèle. Les réseaux convolutionnels analysant des volumes d’imagerie recourent à Grad-CAM ou à la propagation de pertinence couche par couche, tandis que les arbres boostés orchestrant les charges thermiques bénéficient d’une décomposition par valeurs SHAP. Documenter pourquoi chaque technique convient à une modalité donnée aligne les comités pluridisciplinaires et accélère la validation.",
        p4: "Une mise en œuvre robuste requiert également des artefacts de gouvernance. Les fiches de modèle, journaux de décision et protocoles de secours doivent synthétiser les hypothèses sur l’échantillonnage des données, les intervalles de maintenance ou les voies d’escalade lorsque les explications révèlent des anomalies. Ces artefacts doivent être versionnés et accessibles pour suivre l’évolution des engagements d’interprétabilité.",
        p5: "Enfin, une formation à la communication referme la boucle entre technologie et pratique. Programmer des séances où radiologues, infirmières, maintenance et responsables durabilité répètent les narrations entourant les recommandations d’IA harmonise le langage entre départements. Lorsque les équipes décrivent, questionnent et affinent ensemble les explications, l’organisation transforme l’interprétabilité en discipline d’apprentissage partagée.",
        figureCaption: "Visualisation explicable pour un flux d’imagerie et de ventilation hospitalière.",
        date: "19 mars 2024",
        author: "Équipe éditoriale Comunidad IA Salud-Energía",
        reading: "Lecture : 6 minutes"
      },
      post3: {
        h1: "Coordonner les ressources énergétiques distribuées dans les réseaux hospitaliers",
        lead: "Les réseaux de santé régionaux en Espagne modernisent leurs campus avec des champs photovoltaïques, des batteries et des unités de cogénération. Chaque site peut fonctionner de manière autonome, mais les gains d’efficacité apparaissent lorsque ces actifs coopèrent comme un portefeuille. Coordonner ces ressources avec charges hospitalières, priorités d’urgence et signaux réglementaires exige des algorithmes comprenant contraintes électriques et impératifs cliniques.",
        h2: "Concevoir des stratégies de contrôle extensibles",
        p1: "Des stratégies de contrôle extensibles commencent par des jumeaux numériques simulant scénarios thermiques, électriques et cliniques. Les équipes techniques calibrent ces jumeaux avec occupation historique, plannings de laboratoire et prévisions climatiques, permettant aux algorithmes de tester des politiques de dispatching avant mise en œuvre.",
        p2: "La cybersécurité devient centrale lorsque les micro-réseaux échangent données de charge ou consignes. Normes de chiffrement, procédures d’authentification et canaux de communication redondants doivent être définis en parallèle de la logique d’optimisation. Les plans d’incident intègrent priorités cliniques afin que défenses réseau n’entravent jamais les transferts d’énergie d’urgence.",
        h3: "Mesurer l’impact systémique et la résilience",
        p3: "Pour mesurer l’impact, les équipes agrègent fiabilité, intensité carbone et continuité de service. Des tableaux de bord rassemblent gasoil évité, minutes d’autonomie pour les soins intensifs et coût des actes différés. Les journaux narratifs de décisions enrichissent la mémoire institutionnelle.",
        p4: "La planification de la résilience s’appuie sur des partenariats avec fournisseurs et collectivités : opérateurs de réseau, agences de protection civile et laboratoires académiques apportent jeux de données ou expertise de validation. Des protocoles d’accord clarifient responsabilités lors d’orages ou d’urgences sanitaires.",
        p5: "Coordonner des actifs distribués est un écosystème d’apprentissage continu. À mesure que de nouveaux services émergent, les profils de demande évoluent et nécessitent nouvelles simulations. Les communautés de pratique documentent enseignements, partagent du code et mentorent les nouveaux membres pour maintenir l’élan.",
        figureCaption: "Salle de supervision d’un micro-réseau hospitalier interconnecté.",
        date: "7 mars 2024",
        author: "Équipe éditoriale Comunidad IA Salud-Energía",
        reading: "Lecture : 7 minutes"
      },
      post4: {
        h1: "Ancrer le design centré humain dans les programmes IA hospitaliers",
        lead: "Lorsque des programmes d’IA couvrent flux cliniques et systèmes du bâtiment, leur succès dépend de l’observation du travail réel. Les ingénieurs imaginent des échanges fluides entre blocs opératoires et régulation CVC, mais les environnements concrets comportent ajustements improvisés et coordinations tacites. Le design centré sur l’humain révèle ces nuances.",
        h2: "Observer les workflows sans les perturber",
        p1: "Les phases d’exploration privilégient l’observation ethnographique, en suivant équipes dans services, locaux techniques et centres de pilotage. Cartographier les moments où le personnel improvise met en évidence les opportunités où l’IA peut proposer des rappels ou gérer les exceptions.",
        p2: "Des ateliers de co-création traduisent ces observations en prototypes. Des maquettes mêlent données cliniques, métriques énergétiques et signaux contextuels. En itérant sur papier avant de coder, l’équipe évalue charge cognitive, hiérarchie des alertes et vocabulaire.",
        h3: "Soutenir l’adoption par l’apprentissage continu",
        p3: "En phase pilote, des boucles de retour continues sont indispensables. Carnets numériques et points quotidiens collectent retours et cas limites. Les notes de version transparentes montrent comment les commentaires orientent les évolutions.",
        p4: "La formation devient un parcours. Micro-vidéos, tutorat entre pairs et exercices scénarisés relient recommandations d’IA, sécurité patient et objectifs énergie. Des laboratoires de simulation rejouent des situations complexes pour répéter les décisions.",
        p5: "La gouvernance valorise aussi les indicateurs d’expérience. Enquêtes sur la charge perçue, la confiance et la qualité de collaboration servent d’alerte précoce. Agir sur ces signaux permet de déployer l’IA de manière responsable.",
        figureCaption: "Atelier collaboratif réunissant cliniciens, ingénieurs et gestionnaires.",
        date: "26 février 2024",
        author: "Équipe éditoriale Comunidad IA Salud-Energía",
        reading: "Lecture : 6 minutes"
      },
      post5: {
        h1: "Mesurer la décarbonation via la maintenance prédictive en milieu hospitalier",
        lead: "Les programmes de maintenance prédictive promettent de réduire pannes et émissions en anticipant les défaillances des équipements. Pourtant, de nombreux hôpitaux peinent à quantifier la contribution de ces interventions à la décarbonation. Mettre en place des stratégies de mesure transforme les diagnostics en action climatique durable.",
        h2: "Construire des références robustes",
        p1: "Des références robustes commencent par la segmentation des actifs selon profil énergétique, criticité et durée de vie. Les ingénieurs reconstituent consommation historique, carnets de réparation et accords de service.",
        p2: "La granularité des données est déterminante. Les factures mensuelles offrent une vue macro, mais la maintenance prédictive exige du sous-comptage et des événements horodatés. Nettoyer et aligner ces flux permet d’estimer les défaillances évitées.",
        h3: "Relier économies techniques et valeur clinique",
        p3: "Une fois les références définies, les établissements attribuent les gains à des actions précises. Une alerte évitant une panne de groupe froid supprime le recours au générateur d’urgence, se traduisant en kilogrammes de CO2 définis.",
        p4: "Relier économies techniques et valeur clinique renforce le récit. Les pannes évitées signifient moins de procédures reportées et des environnements stables. Les témoignages du personnel révèlent des bénéfices secondaires.",
        p5: "La transparence boucle la boucle. Publier des tableaux de bord avec notes méthodologiques et intervalles d’incertitude maintient l’alignement. Les sessions d’apprentissage entre pairs comparent les techniques de mesure.",
        figureCaption: "Technicien vérifiant des capteurs lors d’une opération de maintenance prédictive.",
        date: "14 février 2024",
        author: "Équipe éditoriale Comunidad IA Salud-Energía",
        reading: "Lecture : 6 minutes"
      }
    },
    contact: {
      hero: {
        title: "Contact et coordination",
        subtitle: "Échangez avec le comité de la Comunidad IA Salud-Energía."
      },
      info: {
        title: "Coordonnées principales",
        intro: "Nous mettons en relation les équipes selon la thématique ou la région concernée.",
        addressTitle: "Adresse",
        addressText: "Calle Innovación 1000, 28027 Madrid, Espagne",
        phoneTitle: "Téléphone",
        phoneText: "+34 91 555 7844",
        emailTitle: "Courriel",
        emailText: "contact@comunidad-iaenergiahealthspain.com",
        hoursTitle: "Horaires de réponse",
        hoursText: "Du lundi au vendredi, 09:00-18:00 CET. Réunions sur rendez-vous.",
        communityTitle: "Coordinateurs communautaires",
        communityText: "Un binôme clinique et technique anime chaque chapitre régional pour suivre vos demandes."
      },
      map: {
        title: "Carte de localisation",
        description: "Vue interactive de notre siège à Madrid.",
        caption: "Localisation de la Comunidad IA Salud-Energía à Madrid."
      },
      form: {
        title: "Formulaire de contact",
        subtitle: "Décrivez votre besoin pour que nous mobilisions les bons experts.",
        nameLabel: "Nom et prénom",
        namePlaceholder: "Votre nom complet",
        emailLabel: "Adresse électronique",
        emailPlaceholder: "vous@organisation.es",
        organisationLabel: "Organisation",
        organisationPlaceholder: "Nom de votre établissement",
        roleLabel: "Votre rôle",
        optionResearch: "Recherche et innovation",
        optionClinician: "Profession clinique",
        optionEngineer: "Ingénierie ou énergie",
        optionAdministrator: "Administration ou direction",
        messageLabel: "Message",
        messagePlaceholder: "Expliquez votre contexte, vos objectifs ou vos questions.",
        consentLabel: "J’accepte que la Comunidad IA utilise ces informations pour me répondre.",
        submit: "Envoyer",
        notice: "Nous répondons généralement sous dix jours ouvrés via courriel."
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        subtitle: "Réponses aux demandes courantes sur la Comunidad IA Salud-Energía."
      },
      intro: "Le comité met à jour la FAQ à chaque trimestre en fonction des retours des membres.",
      items: {
        q1: "Qui peut rejoindre la communauté ?",
        a1: "Le réseau accueille des professionnels de la santé, de l’énergie, de la recherche, des administrations publiques et des sociétés savantes opérant en Espagne. Les étudiants en fin de cursus peuvent participer s’ils sont accompagnés par un mentor membre.",
        q2: "Comment fonctionnent les forums thématiques ?",
        a2: "Chaque forum dispose d’un animateur, d’un calendrier et d’un espace documentaire. Les discussions se basent sur des cas concrets et produisent des synthèses partagées.",
        q3: "Quel est le rôle des chapitres régionaux ?",
        a3: "Ils connectent les acteurs locaux, organisent des rencontres hybrides et remontent les besoins spécifiques de leur territoire au comité de pilotage.",
        q4: "Comment sont sélectionnés les projets collaboratifs ?",
        a4: "Un processus trimestriel évalue l’alignement stratégique, la faisabilité et les ressources disponibles. Les projets retenus sont accompagnés par un binôme mentor.",
        q5: "Comment la communauté gère-t-elle les données sensibles ?",
        a5: "Les contributions doivent être anonymisées. Les partages de données opérationnelles se font via des environnements sécurisés avec accords spécifiques.",
        q6: "Proposez-vous des formations ?",
        a6: "Oui, des modules courts et des ateliers pratiques sont co-construits avec les membres et annoncés dans le calendrier communautaire.",
        q7: "Comment contribuer à la bibliothèque ?",
        a7: "Les documents peuvent être soumis via un formulaire dédié. Une équipe éditoriale vérifie la qualité, la conformité et les droits de diffusion.",
        q8: "Quels sont les liens avec les institutions publiques ?",
        a8: "Des représentants des ministères de la Santé et de la Transition écologique participent aux réunions stratégiques sans diriger les activités quotidiennes."
      }
    },
    terms: {
      hero: {
        title: "Conditions d’utilisation",
        subtitle: "Règles encadrant la Comunidad IA Salud-Energía.",
        updated: "Dernière mise à jour : 1er mars 2024"
      },
      sections: {
        s1: {
          title: "Objet",
          text: "Les présentes conditions encadrent l’accès et l’utilisation des plateformes communautaires, événements et ressources documentaires. Elles visent à garantir un cadre de collaboration transparent entre les membres."
        },
        s2: {
          title: "Adhésion",
          text: "La participation est ouverte aux professionnels de la santé, de l’énergie, de la recherche et de la gestion publique opérant en Espagne. Toute demande peut être vérifiée par le comité de pilotage pour confirmer la légitimité professionnelle."
        },
        s3: {
          title: "Engagement des membres",
          text: "Chaque membre s’engage à contribuer de manière respectueuse, à citer ses sources et à éviter toute diffusion d’informations confidentielles non autorisées. Les échanges doivent rester alignés avec les objectifs de la communauté."
        },
        s4: {
          title: "Contributions",
          text: "Les documents, exemples de code et retours d’expérience partagés conservent la propriété intellectuelle de leurs auteurs. En publiant un contenu, l’auteur accorde une licence non exclusive pour la consultation interne par les membres."
        },
        s5: {
          title: "Gouvernance",
          text: "Un comité de pilotage élu supervise les groupes de travail, valide les ressources et arbitre les différends. Les décisions stratégiques sont documentées et publiées dans la bibliothèque."
        },
        s6: {
          title: "Plateformes numériques",
          text: "L’accès aux espaces numériques nécessite une authentification individuelle. Les membres protègent leurs identifiants et signalent toute activité suspecte."
        },
        s7: {
          title: "Protection des données",
          text: "Les informations personnelles collectées sont traitées conformément à la politique de confidentialité. Toute utilisation secondaire requiert un consentement explicite."
        },
        s8: {
          title: "Confidentialité",
          text: "Les participants respectent les clauses de confidentialité attachées aux projets en cours. Les cas cliniques ou énergétiques cités doivent être anonymisés avant publication."
        },
        s9: {
          title: "Propriété intellectuelle",
          text: "Les marques, logos et contenus officiels de la communauté ne peuvent être utilisés qu’avec l’accord écrit du comité. Toute adaptation doit préciser la source."
        },
        s10: {
          title: "Événements",
          text: "Les inscriptions aux événements dépendent de la capacité des lieux et du respect des consignes de sécurité. Les organisateurs peuvent adapter le format selon les contraintes sanitaires ou techniques."
        },
        s11: {
          title: "Partenaires",
          text: "Les partenariats avec organismes publics ou privés sont formalisés par conventions spécifiques. Ces accords n’impliquent aucune approbation automatique des solutions des partenaires."
        },
        s12: {
          title: "Responsabilité",
          text: "La communauté n’est pas responsable des décisions opérationnelles prises par les membres sur la base des échanges ou documents partagés. Chaque organisation conserve sa responsabilité."
        },
        s13: {
          title: "Modifications",
          text: "Les conditions peuvent être mises à jour pour refléter l’évolution du cadre réglementaire ou des activités. Les membres sont informés des changements significatifs via les canaux officiels."
        },
        s14: {
          title: "Contact",
          text: "Toute question relative à ces conditions peut être adressée à contact@comunidad-iaenergiahealthspain.com. Une réponse écrite sera fournie dans un délai raisonnable."
        }
      }
    },
    privacy: {
      hero: {
        title: "Politique de confidentialité",
        subtitle: "Transparence sur la manière dont nous traitons vos données personnelles.",
        updated: "Dernière mise à jour : 1er mars 2024"
      },
      sections: {
        s1: {
          title: "Responsable du traitement",
          text: "Le comité de pilotage de la Comunidad IA Salud-Energía agit en tant que responsable du traitement des données personnelles collectées."
        },
        s2: {
          title: "Données collectées",
          text: "Nous collectons des informations d’identification professionnelle, coordonnées, préférences thématiques, contributions documentaires et relevés de participation."
        },
        s3: {
          title: "Sources de collecte",
          text: "Les données proviennent de formulaires en ligne, inscriptions aux événements, contributions directes à la bibliothèque et échanges avec les coordinateurs régionaux."
        },
        s4: {
          title: "Base légale",
          text: "Les traitements s’appuient sur l’intérêt légitime de structurer le réseau professionnel et, lorsque nécessaire, sur le consentement explicite des membres."
        },
        s5: {
          title: "Finalités",
          text: "Les données servent à gérer les accès, animer les groupes de travail, suivre la production de ressources et informer les membres des activités pertinentes."
        },
        s6: {
          title: "Partage",
          text: "Les données peuvent être partagées avec des partenaires institutionnels impliqués dans une activité spécifique, sous réserve de contrats de confidentialité et d’un périmètre défini."
        },
        s7: {
          title: "Durée de conservation",
          text: "Les données sont conservées pendant la durée d’activité du membre puis archivées pendant trois ans, sauf obligation réglementaire contraire."
        },
        s8: {
          title: "Sécurité",
          text: "Des contrôles d’accès, audits réguliers et procédures de sauvegarde protègent les informations contre l’accès non autorisé ou la perte."
        },
        s9: {
          title: "Droits des personnes",
          text: "Chaque membre peut demander l’accès, la rectification, l’effacement ou la limitation du traitement de ses données, ainsi que leur portabilité lorsque applicable."
        },
        s10: {
          title: "Procédures de demande",
          text: "Les demandes sont adressées par courriel à contact@comunidad-iaenergiahealthspain.com et traitées dans un délai maximum de trente jours."
        },
        s11: {
          title: "Mises à jour",
          text: "Cette politique peut être révisée pour refléter des évolutions technologiques ou réglementaires ; la date de révision sera indiquée et les membres informés."
        }
      }
    },
    cookiesPolicy: {
      hero: {
        title: "Politique relative aux cookies",
        subtitle: "Information sur les traceurs utilisés sur nos plateformes."
      },
      intro: "Cette page détaille les cookies déposés lors de l’utilisation de nos sites et espaces collaboratifs.",
      table: {
        caption: "Liste des cookies utilisés par la Comunidad IA Salud-Energía.",
        name: "Nom du cookie",
        provider: "Fournisseur",
        type: "Type",
        purpose: "Finalité",
        duration: "Durée",
        row1: {
          name: "session_id",
          provider: "Comunidad IA Salud-Energía",
          type: "Nécessaire",
          purpose: "Maintient la session sécurisée des membres connectés.",
          duration: "Session"
        },
        row2: {
          name: "language_pref",
          provider: "Comunidad IA Salud-Energía",
          type: "Préférences",
          purpose: "Enregistre la langue sélectionnée via le sélecteur.",
          duration: "12 mois"
        },
        row3: {
          name: "analytics_edge",
          provider: "Matomo auto-hébergé",
          type: "Analyse",
          purpose: "Mesure les pages consultées de manière agrégée.",
          duration: "13 mois"
        },
        row4: {
          name: "event_campaign",
          provider: "Comunidad IA Salud-Energía",
          type: "Communication",
          purpose: "Suit l’inscription à un événement communautaire pour synchroniser les rappels.",
          duration: "3 mois"
        }
      },
      managementTitle: "Gestion des préférences",
      managementText: "Vous pouvez ajuster vos choix via le bandeau de gestion des cookies ou en contactant le comité.",
      disableTitle: "Contrôle via le navigateur",
      disableText: "La plupart des navigateurs permettent de bloquer certains cookies, mais cela peut limiter l’accès à des fonctionnalités sécurisées.",
      updatesTitle: "Évolutions de la politique",
      updatesText: "Toute modification substantielle sera annoncée sur le site et datée sur cette page.",
      contactTitle: "Contact dédié",
      contactText: "Adressez toute question à contact@comunidad-iaenergiahealthspain.com."
    },
    refund: {
      hero: {
        title: "Politique d’ajustement des contributions",
        subtitle: "Procédure de gestion des annulations et reports au sein de la communauté.",
        updated: "Dernière mise à jour : 1er mars 2024"
      },
      sections: {
        s1: {
          title: "Objet",
          text: "Cette politique décrit la manière dont la communauté gère les ajustements des engagements pris lors d’événements, projets ou soutiens logistiques."
        },
        s2: {
          title: "Champ d’application",
          text: "Elle s’applique aux inscriptions confirmées, apports de ressources, heures de mentorat et autres contributions convenues avec le comité."
        },
        s3: {
          title: "Annulation par un membre",
          text: "Toute annulation doit être signalée dès que possible afin de réattribuer la place ou la ressource. Une alternative ou un report peut être proposé selon disponibilité."
        },
        s4: {
          title: "Annulation par la communauté",
          text: "Si un événement ou projet est annulé par le comité, les participants sont prévenus avec une proposition de reprogrammation ou de transfert vers une activité équivalente."
        },
        s5: {
          title: "Réaffectation des ressources",
          text: "Lorsque du matériel ou du temps de spécialiste a été réservé, le comité cherche un nouvel usage ou propose une compensation en heures de mentorat sur une autre thématique."
        },
        s6: {
          title: "Absence non signalée",
          text: "Les absences sans préavis sont consignées pour améliorer la planification des capacités. Après deux occurrences, une discussion est organisée pour comprendre les contraintes rencontrées."
        },
        s7: {
          title: "Report de livrables",
          text: "Les délais de livraison peuvent être ajustés lorsque les équipes justifient des contraintes majeures ; un nouveau calendrier est alors établi conjointement."
        },
        s8: {
          title: "Collaboration avec partenaires",
          text: "Les engagements pris avec des partenaires externes sont réévalués en cas de changement ; toute modification est communiquée par écrit à l’ensemble des parties."
        },
        s9: {
          title: "Mécanisme de médiation",
          text: "En cas de désaccord sur un ajustement, une médiation est proposée avec deux membres du comité de pilotage."
        },
        s10: {
          title: "Contact",
          text: "Les demandes d’ajustement ou de clarification doivent être adressées à contact@comunidad-iaenergiahealthspain.com."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Avertissement",
        subtitle: "Limites de responsabilité de la Comunidad IA Salud-Energía."
      },
      sections: {
        s1: {
          title: "Informations générales",
          text: "Les contenus publiés par la communauté sont fournis à titre informatif et ne constituent pas un avis médical, juridique ou énergétique formel."
        },
        s2: {
          title: "Exactitude des contenus",
          text: "Nous nous efforçons d’assurer la précision des informations, mais celles-ci peuvent évoluer et être incomplètes. Les membres doivent vérifier les données avant toute décision."
        },
        s3: {
          title: "Responsabilité",
          text: "La Comunidad IA Salud-Energía et ses bénévoles ne sont pas responsables des décisions ou actions entreprises sur la base des publications ou discussions."
        },
        s4: {
          title: "Liens externes",
          text: "Les liens vers des sites tiers sont fournis pour convenance ; nous ne contrôlons ni le contenu ni les pratiques de ces sites."
        },
        s5: {
          title: "Avis professionnels",
          text: "Les informations partagées ne remplacent pas les conseils de professionnels certifiés. Chaque organisation doit consulter ses experts pour valider toute démarche."
        },
        s6: {
          title: "Évolution du contenu",
          text: "Nous pouvons modifier ou retirer les contenus sans préavis. Les membres sont invités à vérifier les dates de mise à jour."
        }
      }
    },
    thank: {
      title: "Merci pour votre message",
      subtitle: "Nous analyserons votre demande et coordonnerons les personnes concernées.",
      cta: "Retourner à l’accueil"
    },
    notFound: {
      title: "Page introuvable",
      message: "Le contenu demandé n’est plus disponible ou l’URL est incorrecte.",
      cta: "Revenir à l’accueil"
    }
  },
  en: {
    meta: {
      home: {
        title: "Comunidad IA Salud-Energía - Professional Network",
        description: "Spanish network linking health and energy experts around AI, forums, shared library, and collaborative projects."
      },
      services: {
        title: "Collaborative Services - Comunidad IA Salud-Energía",
        description: "Overview of community forums, regional chapters, project boards, and mentoring resources."
      },
      about: {
        title: "About - Comunidad IA Salud-Energía",
        description: "Mission, governance, values, and roadmap of the Spanish health-energy AI network."
      },
      blog: {
        title: "Blog - Comunidad IA Salud-Energía",
        description: "Analyses, case studies, and field notes on AI for healthcare and energy resilience."
      },
      post1: {
        title: "Integrating Clinical and Energy Data - Comunidad IA Salud-Energía",
        description: "Article on aligning clinical and energy telemetry to strengthen hospital resilience in Spain."
      },
      post2: {
        title: "Explainability and Performance in Clinical-Energy AI - Comunidad IA",
        description: "Approaches to balance transparency, accuracy, and adoption across disciplines."
      },
      post3: {
        title: "Coordinating Distributed Energy Resources - Comunidad IA",
        description: "Strategic guidance for orchestrating hospital microgrids aligned with clinical priorities."
      },
      post4: {
        title: "Human-Centered Design for Clinical-Energy AI - Comunidad IA",
        description: "Design principles to embed AI in hospital operations while supporting frontline teams."
      },
      post5: {
        title: "Measuring Decarbonization from Predictive Maintenance - Comunidad IA",
        description: "Methodology for linking analytics-driven maintenance to measurable climate impact."
      },
      contact: {
        title: "Contact - Comunidad IA Salud-Energía",
        description: "Coordination details, contact form, and Madrid headquarters map."
      },
      faq: {
        title: "FAQ - Comunidad IA Salud-Energía",
        description: "Answers about membership, forums, governance, and community operations."
      },
      terms: {
        title: "Terms of Use - Comunidad IA Salud-Energía",
        description: "Collaboration framework, obligations, and responsibilities for community members."
      },
      privacy: {
        title: "Privacy Policy - Comunidad IA Salud-Energía",
        description: "Data processing practices, member rights, and security measures."
      },
      cookies: {
        title: "Cookie Policy - Comunidad IA Salud-Energía",
        description: "Inventory of cookies and guidance for managing tracking preferences."
      },
      refund: {
        title: "Contribution Adjustment Policy - Comunidad IA Salud-Energía",
        description: "Procedures for handling cancellations, postponements, and reassignment of commitments."
      },
      disclaimer: {
        title: "Disclaimer - Comunidad IA Salud-Energía",
        description: "Responsibility limits and reminders on the informational nature of community content."
      },
      thankYou: {
        title: "Thank You - Comunidad IA Salud-Energía",
        description: "Confirmation that your message has been received by the Comunidad IA Salud-Energía."
      },
      notFound: {
        title: "Page Not Found - Comunidad IA Salud-Energía",
        description: "404 error: the requested page is unavailable or has been moved."
      }
    },
    brand: {
      name: "Comunidad IA Salud-Energía - Red de Profesionales"
    },
    skip: {
      link: "Skip to main content"
    },
    nav: {
      home: "Home",
      services: "Services",
      about: "About",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact",
      aria: "Primary navigation"
    },
    lang: {
      fr: "Français",
      en: "English",
      switcherLabel: "Language switcher"
    },
    buttons: {
      openMenu: "Open menu",
      closeMenu: "Close menu"
    },
    common: {
      readMore: "Read more",
      learnMore: "Learn more",
      viewDetails: "View details",
      contactTeam: "Contact the team",
      backToBlog: "Back to blog"
    },
    footer: {
      tagline: "Collective intelligence for Spain’s health and energy systems.",
      address: "Calle Innovación 1000, 28027 Madrid, Spain",
      connectTitle: "Contact",
      phone: "Phone: +34 91 555 7844",
      email: "Email: contact@comunidad-iaenergiahealthspain.com",
      linksTitle: "Legal references",
      terms: "Terms of use",
      privacy: "Privacy policy",
      cookies: "Cookie policy",
      refund: "Adjustment policy",
      disclaimer: "Disclaimer",
      rights: "© {year} Comunidad IA Salud-Energía - Red de Profesionales. All rights reserved."
    },
    cookieBanner: {
      title: "Cookie management",
      description: "We use cookies to analyse participation, remember your settings, and improve the platform.",
      accept: "Accept all",
      decline: "Decline all",
      save: "Save preferences",
      manage: "Manage options",
      categories: {
        necessary: "Necessary cookies",
        necessaryDescription: "Essential for site operation and always active.",
        preferences: "Preference cookies",
        preferencesDescription: "Store your language selection for consistent display.",
        analytics: "Analytics cookies",
        analyticsDescription: "Measure aggregated usage to improve our content.",
        marketing: "Communication cookies",
        marketingDescription: "Coordinate community event communications across channels."
      }
    },
    toasts: {
      formSuccess: "Request received. We will get back to you soon."
    },
    images: {
      home: {
        heroAlt: "Professionals reviewing collaborative analytics dashboards.",
        recommendation1Alt: "Diagram of data connectors.",
        recommendation2Alt: "Meeting around energy strategy maps.",
        recommendation3Alt: "Whiteboard covered with interdisciplinary notes."
      },
      about: {
        heroAlt: "Diagram illustrating the mission of Comunidad IA Salud-Energía."
      },
      services: {
        heroAlt: "Connected hospital infrastructure overview."
      },
      blog: {
        card1Alt: "Energy control room inside a hospital.",
        card2Alt: "Radiologist examining an AI heatmap.",
        card3Alt: "Hospital microgrid control centre.",
        card4Alt: "Design workshop with healthcare professionals.",
        card5Alt: "Technician inspecting industrial sensors."
      },
      posts: {
        post1HeroAlt: "Engineers comparing clinical and energy charts.",
        post2HeroAlt: "Radiologist looking at an explainable AI visualisation.",
        post3HeroAlt: "Technical room with batteries and control panels.",
        post4HeroAlt: "Collaborative workshop focused on user experience.",
        post5HeroAlt: "Maintenance work on precision medical equipment."
      }
    },
    home: {
      hero: {
        title: "Collaborating on AI for Health and Energy across Spain",
        subtitle: "Comunidad IA Salud-Energía connects clinicians, engineers, researchers, and managers aligning medical innovation with resilient infrastructure.",
        ctaPrimary: "Explore the community",
        ctaSecondary: "View collaborative services",
        metric1Value: "1,200",
        metric1Label: "professionals engaged",
        metric2Value: "38",
        metric2Label: "hospital partners",
        metric3Value: "640",
        metric3Label: "resources shared",
        figcaption: "Illustration of teams combining clinical and energy analytics."
      },
      features: {
        title: "Building bridges between clinical care and energy intelligence",
        intro: "The community curates methods, templates, and peer reviews to align AI projects with operational reliability across Spanish hospitals.",
        card1Title: "Clinical-Energy Forum Architecture",
        card1Text: "Blueprints and moderation guides for discussions linking diagnostic excellence with infrastructure resilience.",
        card1Link: "See forum structure",
        card2Title: "Regional Chapters",
        card2Text: "Local circles in Andalusia, Catalonia, Madrid, and the Basque Country sharing use cases rooted in regional ecosystems.",
        card2Link: "Meet the chapters",
        card3Title: "Evidence Library",
        card3Text: "Peer-reviewed repositories of datasets, benchmark notebooks, and checklists for healthtech and energy teams.",
        card3Link: "Browse resources",
        card4Title: "Collaborative Intelligence Radar",
        card4Text: "Quarterly insights mapping emerging algorithms, facility upgrades, and policy shifts that matter to hospitals.",
        card4Link: "Review the radar"
      },
      recommendations: {
        title: "Recommendations from the steering circle",
        subtitle: "Volunteer coordinators highlight priorities for the coming quarter.",
        card1Title: "Strengthen data interoperability foundations",
        card1Text: "Align FHIR, DICOM, BACnet, and energy billing vocabularies to enable trustworthy analytical comparisons.",
        card1Action: "Read the guideline",
        card2Title: "Design energy missions with clinical sponsors",
        card2Text: "Pair facility teams with department leads to turn decarbonisation goals into actionable roadmaps.",
        card2Action: "Consult the checklist",
        card3Title: "Organise multidisciplinary review boards",
        card3Text: "Schedule sessions where biomedical, IT, and operations staff review AI outputs with safety and infrastructure insights.",
        card3Action: "Plan a workshop"
      },
      testimonials: {
        title: "Voices from the network",
        subtitle: "Practitioners describe how the community supports shared ambitions.",
        quote1: "Our imaging engineers now discuss energy KPIs with the same clarity as image quality metrics because the forum provides shared vocabulary and evidence.",
        author1: "Laura Méndez",
        role1: "Head of Imaging Engineering, Hospital Clínic de Barcelona",
        quote2: "Monthly peer sessions gave us actionable feedback to redesign our governance boards and capture clinicians’ perception of value.",
        author2: "Diego Aranda",
        role2: "Energy Efficiency Coordinator, Servicio Madrileño de Salud",
        quote3: "The community library let us compare several European initiatives within a week and steer our next collective research proposal.",
        author3: "Sofía Llorente",
        role3: "Innovation Projects Lead, Instituto de Investigación Sanitaria La Fe"
      },
      timeline: {
        title: "Upcoming milestones",
        subtitle: "Join collaborative events hosted across Spain.",
        item1Title: "Hybrid workshop on federated clinical-energy datasets",
        item1Date: "18 April 2024 · Madrid",
        item1Text: "Deep dive into metadata standards and privacy-preserving computation for hospital campuses.",
        item2Title: "Case clinic: HVAC optimisation in oncology centres",
        item2Date: "8 May 2024 · Valencia (hybrid)",
        item2Text: "Joint analysis of ventilation scenarios, patient comfort, and critical care continuity.",
        item3Title: "Policy roundtable with regional authorities",
        item3Date: "29 May 2024 · Bilbao",
        item3Text: "Dialogue on shared indicators across health, energy, and territorial planning services."
      },
      resources: {
        title: "Latest shared resources",
        subtitle: "Documents curated by working groups.",
        resource1Title: "Blueprint for multi-site demand forecasting",
        resource1Text: "Methodology note connecting occupancy, equipment usage, and weather models.",
        resource1Action: "Access document",
        resource2Title: "Checklist for integrating AI into maintenance rounds",
        resource2Text: "Step-by-step plan aligning analytics alerts with operational rituals.",
        resource2Action: "Open checklist",
        resource3Title: "Community brief on ethics for hybrid AI models",
        resource3Text: "Assessment framework linking clinical boards, data protection officers, and energy leads.",
        resource3Action: "Read brief"
      }
    },
    about: {
      hero: {
        title: "About Comunidad IA Salud-Energía",
        subtitle: "A professional network weaving health expertise with energy stewardship."
      },
      mission: {
        title: "Mission",
        text: "We help Spanish hospitals and research centres align AI-driven innovation with resilient infrastructure through knowledge exchange, mentoring, and joint experimentation."
      },
      model: {
        title: "Operating model",
        text: "Open working groups co-design common frameworks, document protocols, and test scenarios in shared sandboxes."
      },
      values: {
        title: "Values",
        item1Title: "Collective intelligence",
        item1Text: "Initiatives are co-produced by clinicians, engineers, researchers, and managers to reflect real-world practices.",
        item2Title: "Ethical transparency",
        item2Text: "We document data sources, algorithmic choices, and expected outcomes to support governance boards.",
        item3Title: "Impact measurement",
        item3Text: "Shared indicators combine care quality, energy continuity, and organisational learning."
      },
      partners: {
        title: "Alliances and partnerships",
        text: "The network collaborates with universities, professional associations, energy agencies, and learned societies to pool knowledge and infrastructure."
      },
      history: {
        title: "Evolution",
        text: "Founded in 2019 by hospital leaders, the community now spans ten regions and maintains an annual programme of technical dialogues."
      },
      team: {
        title: "Volunteer coordination",
        text: "An elected steering committee animates regional chapters, maintains the library, and ensures cross-disciplinary inclusion."
      },
      future: {
        title: "Next steps",
        text: "2024 priorities focus on multi-site energy modelling, integrating clinical assessments into renovation plans, and aligning professional training."
      }
    },
    services: {
      hero: {
        title: "Community collaborative services",
        subtitle: "Nine instruments support teams working across health and energy."
      },
      items: {
        item1: {
          title: "Clinical and energy AI forums",
          text: "Moderated spaces where diagnostic models, biomedical oversight, and energy constraints meet."
        },
        item2: {
          title: "Regional networking groups",
          text: "Local meetings to share regulatory contexts, suppliers, and lessons learned."
        },
        item3: {
          title: "Collaborative project board",
          text: "Living inventory of research studies, industrial pilots, and entrepreneurial initiatives seeking partners."
        },
        item4: {
          title: "Shared publication library",
          text: "Access to articles, case studies, technical guides, and audit syntheses."
        },
        item5: {
          title: "Expert consultation panel",
          text: "Volunteer professionals who answer questions on architecture, compliance, and metrics."
        },
        item6: {
          title: "Member directory",
          text: "Multi-criteria search by profession, region, and specialty to map available skills."
        },
        item7: {
          title: "Partner showcase",
          text: "Overview of companies, associations, and sponsors engaged in community programmes."
        },
        item8: {
          title: "Events calendar",
          text: "Agenda of workshops, webinars, site visits, and national meetups."
        },
        item9: {
          title: "News section",
          text: "Highlights member achievements, publications, and field feedback."
        }
      },
      framework: {
        title: "Participation framework",
        text: "Each service is open to public organisations and thrives on the active contribution of members.",
        point1: "Collaboration charter endorsed by hospital governance boards.",
        point2: "Quarterly cycle of shared objectives and feedback loops.",
        point3: "Documentation captured in the shared library."
      },
      support: {
        title: "Support resources",
        text: "Mentors, facilitators, and legal experts provide methodological assistance when teams start new tracks."
      }
    },
    blog: {
      hero: {
        title: "Community blog and analysis",
        subtitle: "Case studies, methodological frameworks, and field notes on AI for health and energy."
      },
      intro: "Each article is authored by members and peer-reviewed to reflect the diversity of Spanish practices.",
      cards: {
        post1: {
          title: "Integrating clinical and energy data for agile hospitals",
          excerpt: "Connecting medical archives and infrastructure sensors to support resilience.",
          date: "Published 2 April 2024"
        },
        post2: {
          title: "Balancing explainability and accuracy for clinical-energy AI",
          excerpt: "Shared transparency frameworks for radiology and energy engineering teams.",
          date: "Published 19 March 2024"
        },
        post3: {
          title: "Coordinating distributed energy resources across hospital networks",
          excerpt: "Strategies to orchestrate microgrids and clinical priorities.",
          date: "Published 7 March 2024"
        },
        post4: {
          title: "Embedding human-centered design in hospital AI programmes",
          excerpt: "Approaches to observe workflows and support adoption.",
          date: "Published 26 February 2024"
        },
        post5: {
          title: "Measuring decarbonisation through predictive maintenance",
          excerpt: "Method linking analytics, emissions, and clinical value.",
          date: "Published 14 February 2024"
        }
      }
    },
    posts: {
      shared: {
        summary: "In brief",
        published: "Published: ",
        author: "Author: ",
        reading: "Reading time: "
      },
      post1: {
        h1: "Integrating Clinical and Energy Data for Smarter Hospitals",
        lead: "Spanish hospitals accumulate distinct data flows from imaging archives, clinical protocols, building sensors, and energy management consoles. These repositories are usually administered by separate teams, meaning AI initiatives rarely receive synchronised datasets describing patient care and infrastructure together. Integrating clinical and energy telemetry is therefore not only a data engineering exercise but a governance commitment: each stream must preserve context, traceability, and privacy safeguards while supporting questions about resilience and quality.",
        h2: "Architecting Interoperable Pipelines",
        p1: "An interoperable pipeline begins with harmonised semantics. Teams stewarding HL7 FHIR records, BACnet feeds, and energy procurement ledgers design a shared ontology linking device identifiers, care episodes, and spatial zones. Instead of pursuing a monolithic warehouse, many pilots deploy federated layers that expose metadata catalogues and query brokers. Oncology wards or radiology suites can then contribute structured snapshots while keeping raw evidence inside controlled clinical systems.",
        p2: "Data quality routines must iterate across the lifecycle. Nightly validation scripts reconcile sensor readings with maintenance logs, flagging calibration drifts or unexpected downtime. Clinicians and facility managers co-review anomaly dashboards to distinguish operational noise from early warnings. When AI models forecast cooling demand or bed occupancy, they rely on trustworthy baselines; otherwise optimisation outputs may destabilise staffing plans or jeopardise critical care thresholds.",
        h3: "From Operational Insights to Strategic Governance",
        p3: "Once the technical scaffolding exists, governance committees prioritise use cases that deliver shared value. A respiratory wing might correlate air quality metrics with ventilator performance, while sustainability leads examine how those interventions affect energy intensity. Evaluation frameworks combining patient safety indicators, comfort scores, and kilowatt-hour metrics keep cross-disciplinary dialogue anchored in measurable outcomes rather than abstract enthusiasm.",
        p4: "Transparent communication is essential when insights cross hierarchies. Monthly briefs synthesising model performance, infrastructure incidents, and clinician feedback help leadership compare scenarios without drowning in raw data. Visual stories linking predicted peak loads with surgical scheduling constraints can trigger timely investments in backup systems or retrofits. Documenting residual risks sustains accountability toward ethics boards and public administrations overseeing health infrastructure.",
        p5: "Community forums and knowledge exchanges extend lessons beyond individual hospitals. Sharing anonymised case studies showing how combined datasets supported renovation plans or mitigated critical alarms helps peers calibrate expectations. As Spain invests in resilient health campuses, integrating energy and clinical intelligence becomes a national lever for preparedness. Each iteration strengthens the collaborative tissue between biomedical experts, data engineers, and facility specialists.",
        figureCaption: "Diagram linking clinical records with energy infrastructure status.",
        date: "2 April 2024",
        author: "Comunidad IA Salud-Energía Editorial Team",
        reading: "7 minutes"
      },
      post2: {
        h1: "Balancing Explainability and Accuracy in Clinical-Energy AI",
        lead: "Health systems experimenting with AI to coordinate imaging workflows and facility operations often struggle to reconcile transparency requirements with ambitious performance targets. Radiologists demand justification for anomalies flagged in CT scans, while energy engineers expect reproducible rationales when controls adjust ventilation. Building a shared approach to explainability requires understanding regulatory expectations and the heuristics professionals use daily so algorithmic outputs extend expertise rather than obscure accountability.",
        h2: "Mapping Stakeholder Expectations",
        p1: "Stakeholder mapping identifies who consumes each model output, their decision horizons, and how they express confidence. Radiology teams may focus on heatmaps highlighting pixel regions or temporal sequences. Facility staff prefer trend lines and scenario comparisons emphasising compliance thresholds. Translating these preferences into interface requirements ensures post-processing pipelines deliver artefacts people trust, whether inside a PACS viewer or a building management console.",
        p2: "Co-design workshops convert expectations into measurable indicators of explanation quality. Participants rate prototypes according to clarity, timeliness, and auditability, generating benchmarks that complement classical metrics such as precision or mean absolute error. Integrating structured feedback loops into the model lifecycle lets successive releases show improvements in communicability alongside accuracy gains.",
        h3: "Operationalising Interpretability Techniques",
        p3: "Selecting the right interpretability toolkit depends on model architecture. Convolutional networks analysing imaging stacks may apply Grad-CAM or Layer-wise Relevance Propagation, while gradient boosted trees orchestrating thermal loads benefit from SHAP value decomposition. Documenting why specific techniques fit given modalities aligns multidisciplinary review boards and accelerates validation.",
        p4: "Robust operationalisation also calls for governance artefacts. Model cards, decision logs, and fail-safe protocols summarise assumptions about sampling, maintenance intervals, or escalation pathways when explanations surface anomalies. These artefacts must be versioned and easy to access so auditors and engineers can trace how interpretability commitments evolve with data, seasons, or regulations.",
        p5: "Communication training closes the loop between technology and human practice. Briefings where radiologists, nurses, maintenance personnel, and sustainability leads rehearse narratives around AI recommendations harmonise language across departments. When teams can describe, challenge, and refine explanations together, interpretability becomes a shared learning discipline that improves safety, efficiency, and trust.",
        figureCaption: "Explainable AI visual overlay for imaging and ventilation coordination.",
        date: "19 March 2024",
        author: "Comunidad IA Salud-Energía Editorial Team",
        reading: "6 minutes"
      },
      post3: {
        h1: "Coordinating Distributed Energy Resources Across Hospital Networks",
        lead: "Regional health networks in Spain are modernising campuses with photovoltaic arrays, battery storage, and cogeneration units. While each site can operate autonomously, real efficiency gains emerge when distributed assets cooperate as a portfolio. Coordinating these resources with hospital loads, emergency priorities, and regulatory signals requires algorithms fluent in electrical constraints and clinical imperatives.",
        h2: "Designing Scalable Control Strategies",
        p1: "Scalable control strategies start with digital twins simulating thermal, electrical, and clinical demand scenarios. Facility teams calibrate twins using historical occupancy, laboratory schedules, and climate forecasts so algorithms test dispatch policies before deployment.",
        p2: "Cybersecurity is pivotal when microgrids exchange load data or setpoints. Encryption standards, authentication, and redundant communication channels must be defined alongside optimisation logic. Incident response plans integrate clinical priorities to ensure defences never hinder emergency power transfers.",
        h3: "Measuring Systemic Impact and Resilience",
        p3: "Teams need multi-dimensional indicators capturing reliability, carbon intensity, and service continuity. Dashboards combine avoided diesel consumption, minutes of autonomy delivered to intensive care, and cost of deferred diagnostics. Narrative decision logs enrich institutional memory.",
        p4: "Resilience planning depends on strong partnerships with utilities, civil protection agencies, and academic laboratories supplying datasets or validation expertise. Memoranda of understanding clarify responsibilities during storms, public health emergencies, or supply disruptions.",
        p5: "Coordinating distributed assets is an ongoing learning ecosystem. As new wards open or diagnostic technologies evolve, demand profiles shift, requiring fresh simulations and updated governance. Communities of practice documenting lessons, sharing code, and mentoring newcomers sustain momentum.",
        figureCaption: "Hospital control room supervising interconnected microgrids.",
        date: "7 March 2024",
        author: "Comunidad IA Salud-Energía Editorial Team",
        reading: "7 minutes"
      },
      post4: {
        h1: "Embedding Human-Centered Design in Clinical Energy AI Programs",
        lead: "When AI programmes touch clinical workflows and building systems, success depends on observing how professionals actually work. Engineers may envision seamless exchanges between operating theatres and HVAC controls, yet real environments feature improvisations and tacit coordination. Human-centred design reveals these nuances, ensuring digital interventions support teams instead of complicating routines.",
        h2: "Observing Workflows Without Disruption",
        p1: "Discovery phases prioritise ethnographic observation, shadowing shifts across wards, plant rooms, and command centres. Mapping where staff improvise highlights opportunities for AI to offer prompts, automate documentation, or resolve exceptions without rigid constraints.",
        p2: "Co-creation sessions turn field observations into prototypes. Multidisciplinary groups sketch interface mock-ups blending clinical data, energy metrics, and contextual cues. Iterating on paper prototypes before coding dashboards helps evaluate cognitive load, alarm hierarchy, and terminology.",
        h3: "Sustaining Adoption Through Continuous Learning",
        p3: "Once solutions enter pilots, feedback loops are essential. Daily stand-ups or digital logbooks capture friction points and emergent edge cases. Facilitators synthesise themes for product teams to address in short cycles, publishing release notes that show how feedback guided updates.",
        p4: "Training cannot be a single seminar. Blended learning with micro-videos, peer coaching, and scenario-based exercises helps staff internalise how AI recommendations connect to patient safety and energy goals. Simulation labs stage complex events so teams rehearse decisions with algorithmic support.",
        p5: "Governance should elevate human experience metrics alongside technical KPIs. Surveys tracking workload perception, trust in AI outputs, and collaboration quality act as early warning signals. Acting on these insights lets hospitals scale AI responsibly while honouring professional expertise.",
        figureCaption: "Co-design workshop bringing together clinicians, engineers, and managers.",
        date: "26 February 2024",
        author: "Comunidad IA Salud-Energía Editorial Team",
        reading: "6 minutes"
      },
      post5: {
        h1: "Measuring Decarbonization Gains from Predictive Maintenance in Hospitals",
        lead: "Predictive maintenance programmes promise to cut downtime and emissions by anticipating failures in chillers, sterilizers, and imaging equipment. Yet many hospitals struggle to quantify decarbonisation outcomes. Without credible baselines and shared indicators, sustainability teams cannot demonstrate progress or justify reinvestment. Measurement strategies turn maintenance insights into durable climate action.",
        h2: "Building Robust Baselines",
        p1: "Robust baselines start with asset segmentation by energy profile, criticality, and lifetime. Engineers reconstruct historical consumption, repair logs, and service levels, combining them with weather-normalised data and activity metrics.",
        p2: "Data granularity matters. Monthly bills provide a macro view, but predictive maintenance relies on sub-metering and timestamped events. Cleaning and aligning feeds lets analysts isolate anomalies, calculate response times, and estimate avoided failures.",
        h3: "Connecting Technical Savings with Clinical Value",
        p3: "Once baselines stand, institutions attribute savings to specific actions. Preventing a chiller breakdown can avoid generator usage, translating into defined kilograms of CO2. Tuning an MRI cooling sequence may reduce peak demand charges.",
        p4: "Linking technical savings to clinical value strengthens the story. Fewer failures mean fewer postponed procedures, stable pharmacy temperatures, and calmer environments. Clinical testimonies validate analytics and reveal secondary benefits.",
        p5: "Transparency closes the loop. Dashboards with methodology notes, uncertainty ranges, and upcoming experiments keep teams aligned. Peer learning sessions share measurement tactics, scripts, and challenge assumptions, building credibility for future upgrades.",
        figureCaption: "Technician validating sensors during a predictive maintenance routine.",
        date: "14 February 2024",
        author: "Comunidad IA Salud-Energía Editorial Team",
        reading: "6 minutes"
      }
    },
    contact: {
      hero: {
        title: "Contact and coordination",
        subtitle: "Reach out to the Comunidad IA Salud-Energía coordination team."
      },
      info: {
        title: "Primary contacts",
        intro: "We connect teams based on topic and regional scope.",
        addressTitle: "Address",
        addressText: "Calle Innovación 1000, 28027 Madrid, Spain",
        phoneTitle: "Phone",
        phoneText: "+34 91 555 7844",
        emailTitle: "Email",
        emailText: "contact@comunidad-iaenergiahealthspain.com",
        hoursTitle: "Response hours",
        hoursText: "Monday to Friday, 09:00-18:00 CET. Meetings by appointment.",
        communityTitle: "Community coordinators",
        communityText: "A clinical-technical duo leads each regional chapter to follow up on your requests."
      },
      map: {
        title: "Location map",
        description: "Interactive view of our headquarters in Madrid.",
        caption: "Location of Comunidad IA Salud-Energía in Madrid."
      },
      form: {
        title: "Contact form",
        subtitle: "Describe your needs so we can mobilise the right experts.",
        nameLabel: "Full name",
        namePlaceholder: "Your full name",
        emailLabel: "Email address",
        emailPlaceholder: "you@organisation.es",
        organisationLabel: "Organisation",
        organisationPlaceholder: "Your institution",
        roleLabel: "Your role",
        optionResearch: "Research and innovation",
        optionClinician: "Clinical profession",
        optionEngineer: "Engineering or energy",
        optionAdministrator: "Administration or leadership",
        messageLabel: "Message",
        messagePlaceholder: "Share context, objectives, or questions.",
        consentLabel: "I agree to Comunidad IA using this information to reply to me.",
        submit: "Submit",
        notice: "We usually respond within ten business days via email."
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        subtitle: "Answers to common requests about Comunidad IA Salud-Energía."
      },
      intro: "The committee updates this FAQ every quarter with member feedback.",
      items: {
        q1: "Who can join the community?",
        a1: "Health, energy, research, public administration, and learned society professionals active in Spain may join. Final-year students can participate when mentored by an existing member.",
        q2: "How do thematic forums operate?",
        a2: "Each forum has a facilitator, schedule, and shared repository. Discussions rely on real cases and produce collective summaries.",
        q3: "What is the role of regional chapters?",
        a3: "They connect local actors, host hybrid meetings, and relay territorially specific needs to the steering committee.",
        q4: "How are collaborative projects selected?",
        a4: "A quarterly process evaluates strategic alignment, feasibility, and available resources. Selected projects receive guidance from a mentor pair.",
        q5: "How does the community handle sensitive data?",
        a5: "Contributions must be anonymised. Operational data sharing happens in secure environments governed by dedicated agreements.",
        q6: "Do you offer training?",
        a6: "Yes, short modules and hands-on workshops are co-created with members and announced in the community calendar.",
        q7: "How can someone contribute to the library?",
        a7: "Materials are submitted via a dedicated form. An editorial team reviews quality, compliance, and distribution rights.",
        q8: "What links exist with public institutions?",
        a8: "Representatives from the Ministries of Health and Ecological Transition join strategic meetings while daily activities remain community-led."
      }
    },
    terms: {
      hero: {
        title: "Terms of use",
        subtitle: "Rules governing Comunidad IA Salud-Energía.",
        updated: "Last updated: 1 March 2024"
      },
      sections: {
        s1: {
          title: "Purpose",
          text: "These terms govern access to community platforms, events, and resources. They aim to provide a transparent collaboration framework for members."
        },
        s2: {
          title: "Membership",
          text: "Participation is open to professionals in health, energy, research, and public management active in Spain. Applications may be verified to confirm professional legitimacy."
        },
        s3: {
          title: "Member commitments",
          text: "Members contribute respectfully, cite their sources, and avoid sharing unauthorised confidential information. Exchanges must stay aligned with community objectives."
        },
        s4: {
          title: "Contributions",
          text: "Documents, code samples, and case studies remain the intellectual property of their authors. Publishing content grants a non-exclusive licence for internal consultation by members."
        },
        s5: {
          title: "Governance",
          text: "An elected steering committee oversees working groups, validates resources, and arbitrates disputes. Strategic decisions are documented and published in the library."
        },
        s6: {
          title: "Digital platforms",
          text: "Access requires individual authentication. Members protect their credentials and report suspicious activity."
        },
        s7: {
          title: "Data protection",
          text: "Personal information is processed according to the privacy policy. Any secondary use requires explicit consent."
        },
        s8: {
          title: "Confidentiality",
          text: "Participants respect confidentiality clauses attached to ongoing projects. Clinical or energy cases must be anonymised before publication."
        },
        s9: {
          title: "Intellectual property",
          text: "Community trademarks, logos, and official content may only be used with written approval. Adaptations must credit the source."
        },
        s10: {
          title: "Events",
          text: "Event registrations depend on venue capacity and safety guidelines. Organisers may adapt formats in response to health or technical constraints."
        },
        s11: {
          title: "Partners",
          text: "Partnerships with public or private organisations are formalised through specific agreements. Such agreements do not imply endorsement of partner solutions."
        },
        s12: {
          title: "Liability",
          text: "The community is not liable for operational decisions made by members based on shared materials. Each organisation retains responsibility for implementation."
        },
        s13: {
          title: "Changes",
          text: "Terms may be updated to reflect regulatory or operational evolution. Members are informed of significant changes through official channels."
        },
        s14: {
          title: "Contact",
          text: "Questions regarding these terms can be sent to contact@comunidad-iaenergiahealthspain.com. A written response will be provided in due course."
        }
      }
    },
    privacy: {
      hero: {
        title: "Privacy policy",
        subtitle: "Transparency about how we process your personal data.",
        updated: "Last updated: 1 March 2024"
      },
      sections: {
        s1: {
          title: "Controller",
          text: "The steering committee of Comunidad IA Salud-Energía acts as the data controller for community activities."
        },
        s2: {
          title: "Data collected",
          text: "We collect professional identification details, contact information, thematic preferences, library contributions, and participation records."
        },
        s3: {
          title: "Sources",
          text: "Data comes from online forms, event registrations, direct contributions to the library, and exchanges with regional coordinators."
        },
        s4: {
          title: "Legal basis",
          text: "Processing is based on the legitimate interest of organising the network and, where required, on explicit member consent."
        },
        s5: {
          title: "Purposes",
          text: "Data supports access management, working group facilitation, resource tracking, and relevant member communication."
        },
        s6: {
          title: "Sharing",
          text: "Information may be shared with institutional partners involved in specific activities under confidentiality agreements."
        },
        s7: {
          title: "Retention",
          text: "Data is kept for the membership duration and archived for three years unless regulations require otherwise."
        },
        s8: {
          title: "Security",
          text: "Access controls, regular audits, and backup procedures protect information from unauthorised access or loss."
        },
        s9: {
          title: "Individual rights",
          text: "Members can request access, rectification, deletion, restriction, or portability of their data where applicable."
        },
        s10: {
          title: "Request process",
          text: "Requests must be sent to contact@comunidad-iaenergiahealthspain.com and are handled within thirty days."
        },
        s11: {
          title: "Updates",
          text: "This policy may be revised for technological or regulatory reasons; the revision date and notifications will be provided."
        }
      }
    },
    cookiesPolicy: {
      hero: {
        title: "Cookie policy",
        subtitle: "Information on the cookies used across our platforms."
      },
      intro: "This page lists the cookies placed while using our websites and collaborative spaces.",
      table: {
        caption: "Cookies used by Comunidad IA Salud-Energía.",
        name: "Cookie name",
        provider: "Provider",
        type: "Type",
        purpose: "Purpose",
        duration: "Duration",
        row1: {
          name: "session_id",
          provider: "Comunidad IA Salud-Energía",
          type: "Necessary",
          purpose: "Keeps member sessions secure after authentication.",
          duration: "Session"
        },
        row2: {
          name: "language_pref",
          provider: "Comunidad IA Salud-Energía",
          type: "Preferences",
          purpose: "Stores the language selected via the toggle.",
          duration: "12 months"
        },
        row3: {
          name: "analytics_edge",
          provider: "Self-hosted Matomo",
          type: "Analytics",
          purpose: "Aggregates visited pages to improve user experience.",
          duration: "13 months"
        },
        row4: {
          name: "event_campaign",
          provider: "Comunidad IA Salud-Energía",
          type: "Communication",
          purpose: "Tracks community event registrations to synchronise reminders.",
          duration: "3 months"
        }
      },
      managementTitle: "Managing preferences",
      managementText: "Adjust your choices via the cookie banner or by contacting the committee.",
      disableTitle: "Browser control",
      disableText: "Most browsers let you block certain cookies, though this may limit secure feature access.",
      updatesTitle: "Policy updates",
      updatesText: "Any significant change will be announced on the site and dated on this page.",
      contactTitle: "Dedicated contact",
      contactText: "Send any question to contact@comunidad-iaenergiahealthspain.com."
    },
    refund: {
      hero: {
        title: "Contribution adjustment policy",
        subtitle: "How the community manages cancellations and rescheduling.",
        updated: "Last updated: 1 March 2024"
      },
      sections: {
        s1: {
          title: "Purpose",
          text: "This policy describes how the community adjusts commitments made for events, projects, or logistical support."
        },
        s2: {
          title: "Scope",
          text: "It covers confirmed registrations, resource allocations, mentoring hours, and other commitments agreed with the committee."
        },
        s3: {
          title: "Member cancellation",
          text: "Notify cancellations as early as possible so the slot or resource can be reassigned. Alternatives or postponements may be offered when feasible."
        },
        s4: {
          title: "Community cancellation",
          text: "If the committee cancels an activity, participants receive notice with a proposal to reschedule or transfer to an equivalent session."
        },
        s5: {
          title: "Resource reallocation",
          text: "When equipment or expert time has been booked, the committee seeks a new usage or offers mentoring hours on another topic."
        },
        s6: {
          title: "No-show",
          text: "Unannounced absences are logged to improve future capacity planning. After two occurrences we schedule a conversation to understand constraints."
        },
        s7: {
          title: "Deliverable postponement",
          text: "Deadlines may be adjusted when teams face major constraints. A new timeline is defined together."
        },
        s8: {
          title: "Partner collaboration",
          text: "Commitments involving external partners are reassessed if circumstances change; all parties are informed in writing."
        },
        s9: {
          title: "Mediation",
          text: "If there is disagreement over an adjustment, mediation with two steering committee members is proposed."
        },
        s10: {
          title: "Contact",
          text: "Send adjustment or clarification requests to contact@comunidad-iaenergiahealthspain.com."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Disclaimer",
        subtitle: "Responsibility limits for Comunidad IA Salud-Energía."
      },
      sections: {
        s1: {
          title: "General information",
          text: "Content published by the community is informational and does not constitute formal medical, legal, or energy advice."
        },
        s2: {
          title: "Content accuracy",
          text: "We strive for accuracy, yet information may evolve or remain incomplete. Members should verify data before acting."
        },
        s3: {
          title: "Responsibility",
          text: "Comunidad IA Salud-Energía and its volunteers are not liable for decisions or actions based on shared materials or discussions."
        },
        s4: {
          title: "External links",
          text: "Links to third-party sites are provided for convenience; we do not control their content or practices."
        },
        s5: {
          title: "Professional advice",
          text: "Shared information is not a substitute for certified professional counsel. Organisations must consult their experts before implementing actions."
        },
        s6: {
          title: "Content updates",
          text: "Content may change or be removed without notice. Members should check update dates regularly."
        }
      }
    },
    thank: {
      title: "Thank you for your message",
      subtitle: "We will review your request and coordinate the relevant contributors.",
      cta: "Return to home"
    },
    notFound: {
      title: "Page not found",
      message: "The content you requested is unavailable or the URL is incorrect.",
      cta: "Return to home"
    }
  }
};
const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const COOKIE_KEY = "cookie_consent";
let currentLang = DEFAULT_LANG;
function getTranslation(lang, key) {
  const segments = key.split(".");
  let result = I18N[lang];
  for (const segment of segments) {
    if (result && Object.prototype.hasOwnProperty.call(result, segment)) {
      result = result[segment];
    } else {
      result = null;
      break;
    }
  }
  if (typeof result === "string") {
    return result;
  }
  if (result == null && lang !== DEFAULT_LANG) {
    return getTranslation(DEFAULT_LANG, key);
  }
  if (typeof result === "string") {
    return result;
  }
  return key;
}
function replacePlaceholders(value) {
  if (typeof value !== "string") {
    return value;
  }
  return value.replace(/\{year\}/g, String(new Date().getFullYear()));
}
function setLanguage(lang) {
  if (!I18N[lang]) {
    lang = DEFAULT_LANG;
  }
  currentLang = lang;
  localStorage.setItem(LANG_KEY, lang);
  document.documentElement.setAttribute("lang", lang);
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18n));
    if (text !== undefined) {
      el.innerHTML = text;
    }
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18nPlaceholder));
    if (text !== undefined) {
      el.setAttribute("placeholder", text);
    }
  });
  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18nAlt));
    if (text !== undefined) {
      el.setAttribute("alt", text);
    }
  });
  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18nAriaLabel));
    if (text !== undefined) {
      el.setAttribute("aria-label", text);
    }
  });
  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18nTitle));
    if (text !== undefined) {
      if (el.tagName.toLowerCase() === "title") {
        el.textContent = text;
      } else {
        el.setAttribute("title", text);
      }
    }
  });
  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18nMeta));
    if (text !== undefined) {
      el.setAttribute("content", text);
    }
  });
  document.querySelectorAll("option[data-i18n]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18n));
    if (text !== undefined) {
      el.textContent = text;
    }
  });
  document.querySelectorAll("[data-i18n-value]").forEach((el) => {
    const text = replacePlaceholders(getTranslation(lang, el.dataset.i18nValue));
    if (text !== undefined) {
      el.setAttribute("value", text);
    }
  });
  const langButtons = document.querySelectorAll(".language-toggle [data-lang]");
  langButtons.forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.lang === lang);
  });
  updateMenuToggleLabel();
}
function updateMenuToggleLabel() {
  const toggle = document.querySelector(".menu-toggle");
  if (!toggle) {
    return;
  }
  const expanded = toggle.getAttribute("aria-expanded") === "true";
  const key = expanded ? "buttons.closeMenu" : "buttons.openMenu";
  toggle.setAttribute("aria-label", replacePlaceholders(getTranslation(currentLang, key)));
}
function initLanguageToggle() {
  document.querySelectorAll(".language-toggle [data-lang]").forEach((btn) => {
    btn.addEventListener("click", () => {
      setLanguage(btn.dataset.lang);
    });
  });
}
function initNavToggle() {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".primary-nav");
  if (!toggle || !nav) {
    return;
  }
  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!expanded));
    nav.classList.toggle("is-open", !expanded);
    updateMenuToggleLabel();
  });
  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      updateMenuToggleLabel();
    });
  });
  document.addEventListener("click", (event) => {
    if (!nav.contains(event.target) && !toggle.contains(event.target)) {
      if (nav.classList.contains("is-open")) {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
        updateMenuToggleLabel();
      }
    }
  });
}
function initAnimations() {
  const observer = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );
  document.querySelectorAll("[data-animate]").forEach((el) => observer.observe(el));
}
function showToast(messageKey) {
  const container = document.querySelector("[data-toast-container]");
  if (!container) {
    return;
  }
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = replacePlaceholders(getTranslation(currentLang, messageKey));
  container.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.add("is-visible");
  });
  setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 3600);
  setTimeout(() => {
    if (toast.parentElement === container) {
      container.removeChild(toast);
    }
  }, 4200);
}
function initForms() {
  document.querySelectorAll("form[data-form]").forEach((form) => {
    form.addEventListener("submit", () => {
      showToast("toasts.formSuccess");
    });
  });
}
function loadConsent() {
  try {
    const stored = localStorage.getItem(COOKIE_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch (error) {
    return null;
  }
}
function storeConsent(state) {
  const payload = {
    necessary: true,
    preferences: !!state.preferences,
    analytics: !!state.analytics,
    marketing: !!state.marketing,
    timestamp: new Date().toISOString()
  };
  localStorage.setItem(COOKIE_KEY, JSON.stringify(payload));
}
function initCookieBanner() {
  const banner = document.querySelector("[data-cookie-banner]");
  if (!banner) {
    return;
  }
  const acceptBtn = banner.querySelector("[data-cookie-accept]");
  const declineBtn = banner.querySelector("[data-cookie-decline]");
  const manageBtn = banner.querySelector("[data-cookie-manage]");
  const saveBtn = banner.querySelector("[data-cookie-save]");
  const prefPanel = banner.querySelector("[data-cookie-preferences]");
  const toggleInputs = banner.querySelectorAll("[data-cookie-toggle]");
  const applyState = (state) => {
    toggleInputs.forEach((input) => {
      if (input.dataset.cookieToggle === "preferences") {
        input.checked = !!state.preferences;
      }
      if (input.dataset.cookieToggle === "analytics") {
        input.checked = !!state.analytics;
      }
      if (input.dataset.cookieToggle === "marketing") {
        input.checked = !!state.marketing;
      }
    });
  };
  let currentState = loadConsent();
  if (currentState) {
    applyState(currentState);
    banner.classList.add("hidden");
  } else {
    banner.classList.remove("hidden");
  }
  toggleInputs.forEach((input) => {
    input.addEventListener("change", () => {
      currentState = currentState || { preferences: false, analytics: false, marketing: false };
      const key = input.dataset.cookieToggle;
      currentState[key] = input.checked;
      storeConsent(currentState);
    });
  });
  acceptBtn.addEventListener("click", () => {
    currentState = { preferences: true, analytics: true, marketing: true };
    applyState(currentState);
    storeConsent(currentState);
    banner.classList.add("hidden");
  });
  declineBtn.addEventListener("click", () => {
    currentState = { preferences: false, analytics: false, marketing: false };
    applyState(currentState);
    storeConsent(currentState);
    banner.classList.add("hidden");
  });
  saveBtn.addEventListener("click", () => {
    currentState = currentState || { preferences: false, analytics: false, marketing: false };
    storeConsent(currentState);
    banner.classList.add("hidden");
  });
  manageBtn.addEventListener("click", () => {
    prefPanel.classList.toggle("is-active");
  });
}
document.addEventListener("DOMContentLoaded", () => {
  const storedLang = localStorage.getItem(LANG_KEY) || DEFAULT_LANG;
  setLanguage(storedLang);
  initLanguageToggle();
  initNavToggle();
  initAnimations();
  initForms();
  initCookieBanner();
});