export const blogPosts = [
  {
    slug: "wertschaetzend-kommunizieren-im-alltag",
    title: "Wertschätzend kommunizieren im Alltag",
    category: "Wertschätzung",
    readingTime: "6 Min.",
    excerpt:
      "Wie Du mit kleinen Veränderungen im Alltag eine Kultur des Zuhörens und Respekts aufbaust.",
    cover: "https://picsum.photos/1200/800?random=41",
    content: [
      {
        heading: "Warum Wertschätzung hörbar sein muss",
        text: "Worte wirken – besonders dann, wenn sie konkret und ehrlich sind. Statt pauschaler Komplimente helfen beobachtbare Beschreibungen. So fühlt sich Dein Gegenüber wirklich gesehen. Du kannst zum Beispiel sagen: „Mir ist aufgefallen, wie ruhig Du geblieben bist, als es hektisch wurde. Das hat den Druck rausgenommen.“"
      },
      {
        heading: "Alltagstaugliche Formulierungen",
        text: "Nimm Dir vor, in jeder Unterhaltung mindestens einmal echtes Interesse zu zeigen. Frage nach den Gedanken, statt sofort zu antworten. Sätze wie „Hilf mir zu verstehen, wie Du das siehst“ öffnen den Raum. Wenn Du Dich bedanken möchtest, verknüpfe es mit der Wirkung: „Danke, dass Du Dich gestern um die Präsentation gekümmert hast. Das hat mir wirklich Druck genommen.“"
      },
      {
        heading: "Dranbleiben macht den Unterschied",
        text: "Kommunikation ist kein Einmalprojekt. Plane bewusst kurze Check-ins ein – mit Partner*in, Kolleg*innen oder Freund*innen. Ein wiederkehrender Termin von 15 Minuten reicht, um Missverständnisse frühzeitig zu klären und nach vorne zu schauen."
      }
    ]
  },
  {
    slug: "konflikte-im-team-loesen",
    title: "Konflikte im Team lösen ohne Schuldzuweisungen",
    category: "Teamarbeit",
    readingTime: "8 Min.",
    excerpt:
      "Mit klaren Strukturen gibst Du Teamgesprächen Fokus und holst alle Stimmen ins Boot.",
    cover: "https://picsum.photos/1200/800?random=42",
    content: [
      {
        heading: "Rahmen setzen, bevor es losgeht",
        text: "Lade das Team mit einem klaren Ziel ein und benenne, was heute nicht geklärt wird. Das schafft Orientierung. Bitte jede Person, in einem Satz zu beschreiben, was ihr wichtig ist – ohne Diskussion. Danach fasst Du zusammen, was Du gehört hast."
      },
      {
        heading: "Neutral moderieren",
        text: "Stell Fragen, die Lösungsräume öffnen. „Was müsste passieren, damit Du sagen kannst: Wir sind einen Schritt weiter?“ Verzichte auf Bewertungen. Wenn Emotionen hochgehen, nimm sie wahr und benenne sie neutral: „Ich merke, hier steckt viel Frust drin. Lass uns schauen, wo der genau herkommt.“"
      },
      {
        heading: "Verbindliche nächste Schritte",
        text: "Zum Abschluss werden konkrete Verantwortlichkeiten geklärt. Schreib mit, wer was bis wann übernimmt, und verschicke die Notizen direkt nach dem Meeting. So bleibt kein Raum für unterschiedliche Interpretationen."
      }
    ]
  },
  {
    slug: "grenzen-setzen-ohne-hart-zu-wirken",
    title: "Grenzen setzen, ohne hart zu wirken",
    category: "Selbstfürsorge",
    readingTime: "7 Min.",
    excerpt:
      "Ich-Botschaften und konkrete Wünsche helfen Dir, klar zu bleiben und trotzdem Verbindung zu halten.",
    cover: "https://picsum.photos/1200/800?random=43",
    content: [
      {
        heading: "Grenzen brauchen Vorbereitung",
        text: "Überlege vor dem Gespräch, was genau Dich stört, welche Bedürfnisse dahinter stehen und wie Du sie in Worte fasst. Eine gute Struktur: Beobachtung, Wirkung, Wunsch. Beispielsweise: „Wenn Du kurzfristig Termine verschiebst, fühle ich mich gestresst, weil ich meinen Tag neu planen muss. Bitte gib mir nächstes Mal zwei Tage vorher Bescheid.“"
      },
      {
        heading: "Konsequent, aber zugewandt bleiben",
        text: "Halte Blickkontakt, sprich ruhig und betone, dass Dir die Beziehung wichtig ist. Lass Pausen zu, damit Dein Gegenüber reagieren kann. Wenn die Antwort ausweicht, wiederhole Deinen Wunsch freundlich, aber bestimmt."
      },
      {
        heading: "Nach dem Gespräch ist vor dem Gespräch",
        text: "Checke nach, ob die vereinbarte Veränderung eingetreten ist. Wenn nicht, erinnere frühzeitig und verweise auf das, was ihr besprochen habt. So baust Du Vertrauen in Deine Grenzen auf – auch bei Dir selbst."
      }
    ]
  },
  {
    slug: "souveraen-mit-kritik-umgehen",
    title: "Souverän mit Kritik umgehen",
    category: "Kritikfähigkeit",
    readingTime: "5 Min.",
    excerpt:
      "Wie Du Kritik hörst, ohne in Verteidigung zu verfallen, und was Dir hilft, konstruktiv zu antworten.",
    cover: "https://picsum.photos/1200/800?random=44",
    content: [
      {
        heading: "Kritik zuerst verstehen",
        text: "Statt direkt zu erklären, warum etwas so gelaufen ist, erkundige Dich. Frage nach konkreten Beispielen, damit Du weißt, worüber gesprochen wird. Wiederhole in eigenen Worten, was Du gehört hast, um Missverständnisse auszuschließen."
      },
      {
        heading: "Eigene Emotionen regulieren",
        text: "Es ist normal, dass Kritik etwas auslöst. Erdung hilft: beide Füße auf den Boden, einmal bewusst atmen. Wenn Du das Gespräch kurz unterbrechen musst, sag es: „Ich brauche einen Augenblick, um darüber nachzudenken.“"
      },
      {
        heading: "Handlungsoptionen klären",
        text: "Suche gemeinsam nach nächsten Schritten. Frage: „Was würde Dir zeigen, dass ich es ernst nehme?“ und schildere, was Du konkret anbieten kannst. So bleibt der Dialog offen."
      }
    ]
  }
];