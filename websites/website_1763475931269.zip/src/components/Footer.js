import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div>
          <h4 className={styles.title}>Silaventino</h4>
          <p className={styles.text}>
            Silaventino hilft Dir, Gespräche fairer zu führen und Konflikte klar
            zu klären – alltagstauglich, respektvoll und mit Blick auf echte
            Verbindungen.
          </p>
        </div>
        <div>
          <h5 className={styles.heading}>Navigation</h5>
          <ul className={styles.list}>
            <li>
              <NavLink to="/guide" className={styles.link}>
                Leitfaden
              </NavLink>
            </li>
            <li>
              <NavLink to="/programs" className={styles.link}>
                Programme
              </NavLink>
            </li>
            <li>
              <NavLink to="/tools" className={styles.link}>
                Tools
              </NavLink>
            </li>
            <li>
              <NavLink to="/blog" className={styles.link}>
                Blog
              </NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h5 className={styles.heading}>Kontakt</h5>
          <address className={styles.address}>
            Musterstraße 12<br />
            10115 Berlin<br />
            Deutschland
          </address>
          <a href="mailto:hallo@silaventino.de" className={styles.link}>
            hallo@silaventino.de
          </a>
          <p className={styles.text}>Telefon: +49 (0)30 1234 5678</p>
        </div>
        <div>
          <h5 className={styles.heading}>Rechtliches</h5>
          <ul className={styles.list}>
            <li>
              <NavLink to="/legal" className={styles.link}>
                AGB
              </NavLink>
            </li>
            <li>
              <NavLink to="/privacy" className={styles.link}>
                Datenschutz
              </NavLink>
            </li>
            <li>
              <NavLink to="/imprint" className={styles.link}>
                Impressum
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Silaventino. Alle Rechte vorbehalten.</p>
      </div>
    </div>
  </footer>
);

export default Footer;