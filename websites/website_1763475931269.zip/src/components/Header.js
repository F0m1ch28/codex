import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "auto";
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ""}`}>
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Zur Startseite">
            Silaventino
          </NavLink>
          <nav className={`${styles.nav} ${menuOpen ? styles.open : ""}`} aria-label="Hauptnavigation">
            <NavLink to="/guide" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
              Leitfaden
            </NavLink>
            <NavLink to="/programs" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
              Programme
            </NavLink>
            <NavLink to="/tools" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
              Tools
            </NavLink>
            <NavLink to="/blog" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
              Blog
            </NavLink>
            <NavLink to="/about" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
              Über uns
            </NavLink>
            <NavLink to="/contact" className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ""}`} onClick={closeMenu}>
              Kontakt
            </NavLink>
            <NavLink to="/programs" className={styles.cta} onClick={closeMenu}>
              Jetzt starten
            </NavLink>
          </nav>
          <button
            className={`${styles.burger} ${menuOpen ? styles.burgerActive : ""}`}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-label="Navigation umschalten"
            aria-expanded={menuOpen}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;