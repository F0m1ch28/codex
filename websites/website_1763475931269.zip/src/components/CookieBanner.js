import React, { useState, useEffect } from "react";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("silaventino-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = () => {
    window.localStorage.setItem("silaventino-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Wir verwenden Cookies, um Dein Nutzungserlebnis zu verbessern. Mit einem
        Klick auf „Einverstanden“ stimmst Du zu. Details findest Du in unserer{" "}
        <a href="/privacy">Datenschutzerklärung</a>.
      </p>
      <button className="primaryButton" onClick={handleConsent}>
        Einverstanden
      </button>
    </div>
  );
};

export default CookieBanner;