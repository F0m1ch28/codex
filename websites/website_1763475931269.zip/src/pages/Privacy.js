import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Privacy.module.css";

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutzerklärung | Silaventino</title>
      <meta
        name="description"
        content="Datenschutz bei Silaventino – erfahre, wie wir Deine Daten schützen und verwenden."
      />
      <link rel="canonical" href="https://www.silaventino.de/privacy" />
    </Helmet>

    <section className={styles.privacy}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>Stand: Januar 2024</p>

        <h2>1. Verantwortliche Stelle</h2>
        <p>
          Silaventino<br />
          Musterstraße 12, 10115 Berlin<br />
          E-Mail: hallo@silaventino.de
        </p>

        <h2>2. Erhobene Daten</h2>
        <p>
          Wir verarbeiten personenbezogene Daten (Name, E-Mail, Nachrichten), die
          Du uns über das Kontaktformular oder per E-Mail übermittelst. Außerdem
          erfassen wir technische Daten (IP-Adresse, Browserinformationen) zur
          Sicherstellung des Betriebs.
        </p>

        <h2>3. Zweck und Rechtsgrundlage</h2>
        <p>
          Die Verarbeitung erfolgt zur Bearbeitung Deiner Anfrage (Art. 6 Abs. 1
          lit. b DSGVO) sowie zur Verbesserung unserer Angebote (Art. 6 Abs. 1
          lit. f DSGVO).
        </p>

        <h2>4. Speicherung</h2>
        <p>
          Daten werden nur so lange gespeichert, wie es für die Bearbeitung
          notwendig ist. Gesetzliche Aufbewahrungsfristen bleiben unberührt.
        </p>

        <h2>5. Weitergabe</h2>
        <p>
          Eine Weitergabe an Dritte erfolgt nur, wenn wir gesetzlich dazu
          verpflichtet sind oder Du ausdrücklich zustimmst.
        </p>

        <h2>6. Rechte der betroffenen Personen</h2>
        <p>
          Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung
          der Verarbeitung sowie Datenübertragbarkeit. Wende Dich dazu an
          hallo@silaventino.de.
        </p>

        <h2>7. Cookies</h2>
        <p>
          Wir setzen Cookies ein, um die Nutzung der Website zu analysieren und
          zu verbessern. Du kannst sie in Deinem Browser deaktivieren. Details
          findest Du im Cookiebanner.
        </p>

        <h2>8. Kontakt zur Aufsichtsbehörde</h2>
        <p>
          Du hast das Recht, Dich bei einer Datenschutzaufsichtsbehörde zu
          beschweren, wenn Du der Meinung bist, dass die Verarbeitung Deiner
          personenbezogenen Daten gegen Datenschutzrecht verstößt.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;