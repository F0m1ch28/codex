import React, { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./Home.module.css";
import { blogPosts } from "../data/blogPosts";

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: "Menschen, die Klarheit gewonnen haben", value: 1200 },
      { label: "Moderierte Konfliktgespräche", value: 380 },
      { label: "Stunden aktives Zuhören trainiert", value: 5400 }
    ],
    []
  );

  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("Alle");

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const increment = Math.ceil(stat.value / 80);
      return setInterval(
        () =>
          setCounters((prev) => {
            const next = [...prev];
            next[index] = Math.min(stat.value, prev[index] + increment);
            return next;
          }),
        40
      );
    });

    return () => intervals.forEach(clearInterval);
  }, [statsData]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(timer);
  }, []);

  const testimonials = [
    {
      quote:
        "Seit ich die Übungen von Silaventino nutze, komme ich in Teamgesprächen viel schneller auf den Punkt – und mein Team zieht wirklich mit.",
      name: "Mara K., Projektleiterin"
    },
    {
      quote:
        "Die klare Struktur aus dem Leitfaden hat uns als Paar geholfen, alte Muster zu durchbrechen. Wir hören einander wieder zu.",
      name: "Samuel & Nora, Eltern aus Köln"
    },
    {
      quote:
        "Die Tools machen schwierige Gespräche planbar. Ich gehe deutlich ruhiger in kritische Termine und bleibe selbstbewusst.",
      name: "Leonie H., HR Business Partnerin"
    }
  ];

  const projects = [
    {
      id: 1,
      title: "Alltagsgespräche entknoten",
      category: "Alltag",
      description:
        "Gemeinsame Routinen für Partnerschaften entwickelt, um Missverständnisse früh zu erkennen.",
      image: "https://picsum.photos/1200/800?random=51"
    },
    {
      id: 2,
      title: "Familienrat etablieren",
      category: "Familie",
      description:
        "Eltern und Jugendliche bauen einen monatlichen Familienrat auf – mit klarer Agenda.",
      image: "https://picsum.photos/1200/800?random=52"
    },
    {
      id: 3,
      title: "Teamkonflikt moderieren",
      category: "Job",
      description:
        "Ein interdisziplinäres Team klärt Rollen und Erwartungen in nur drei Sessions.",
      image: "https://picsum.photos/1200/800?random=53"
    },
    {
      id: 4,
      title: "Feedback-Kultur im Startup",
      category: "Job",
      description:
        "Feedback-Check-ins für ein wachsendes Startup eingeführt, um Reibungsverluste zu reduzieren.",
      image: "https://picsum.photos/1200/800?random=54"
    }
  ];

  const faqItems = [
    {
      question: "Für wen ist Silaventino geeignet?",
      answer:
        "Für Dich, wenn Du Gespräche im Alltag klarer, freundlicher und wirkungsvoller gestalten möchtest – egal ob im privaten Umfeld oder im Job."
    },
    {
      question: "Brauche ich Vorkenntnisse in Kommunikation?",
      answer:
        "Nein. Unsere Inhalte sind praxisnah aufgebaut. Du erhältst Schritt-für-Schritt-Anleitungen, Beispiele und kurze Übungen zum Ausprobieren."
    },
    {
      question: "Ersetzt Silaventino eine Therapie oder Rechtsberatung?",
      answer:
        "Nein. Silaventino vermittelt kommunikative Fähigkeiten und Reflexionsimpulse. Für psychotherapeutische oder rechtliche Anliegen wendest Du Dich bitte an entsprechende Fachstellen."
    },
    {
      question: "Wie starte ich am besten?",
      answer:
        "Beginne mit dem Leitfaden, wähle anschließend ein Programm, das zu Deiner Situation passt, und nutze die Tools zur Vorbereitung Deiner Gespräche."
    }
  ];

  const [openFaq, setOpenFaq] = useState(0);

  const filteredProjects =
    selectedCategory === "Alle"
      ? projects
      : projects.filter((project) => project.category === selectedCategory);

  const blogPreview = blogPosts.slice(0, 3);

  return (
    <>
      <Helmet>
        <title>Silaventino | Besser reden. Konflikte fair lösen.</title>
        <meta
          name="description"
          content="Silaventino unterstützt Dich in Deutschland dabei, Gespräche respektvoller zu führen, Konflikte fair zu lösen und gemeinsam tragfähige Lösungen zu finden."
        />
        <link rel="canonical" href="https://www.silaventino.de/" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>Silaventino</span>
            <h1>Besser reden. Konflikte fair lösen.</h1>
            <p>
              Du willst in heiklen Momenten ruhig bleiben, klar ausdrücken, was
              Dir wichtig ist, und echte Lösungen finden. Silaventino gibt Dir
              dafür Struktur, Mut und praktische Tools.
            </p>
            <div className={styles.heroButtons}>
              <Link to="/programs" className="primaryButton">
                Kommunikation stärken
              </Link>
              <Link to="/guide" className="secondaryButton">
                Leitfaden entdecken
              </Link>
            </div>
          </div>
          <div className={styles.heroMedia} aria-hidden="true">
            <div className={styles.heroImageWrapper}>
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Menschen in einem professionellen Gespräch"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{counters[index]}+</span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <div className="sectionIntro">
            <span>Was Du gewinnst</span>
            <h2>Weniger Streit. Mehr Verständnis. Klarere Gespräche.</h2>
            <p>
              Silaventino kombiniert verständliche Inhalte mit konkreten
              Übungen. So bringst Du neue Kommunikationsgewohnheiten sofort in
              Deinen Alltag.
            </p>
          </div>
          <div className={styles.benefitGrid}>
            {[
              {
                title: "Gespräche vorbereiten",
                text: "Mit unseren Leitfragen erkennst Du Deine Muster, formulierst Ich-Botschaften und wählst passende Worte."
              },
              {
                title: "Aktiv zuhören",
                text: "Trainiere echte Präsenz, paraphrasiere und spiegele Bedürfnisse, damit Dein Gegenüber sich gehört fühlt."
              },
              {
                title: "Sicher auftreten",
                text: "Sammle Sätze und Gesten, die Dich in emotionalen Situationen stärken und handlungsfähig machen."
              },
              {
                title: "Gemeinsame Lösungen",
                text: "Lerne, Optionen offen zu besprechen, Interessen sichtbar zu machen und Vereinbarungen festzuhalten."
              }
            ].map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.topics}>
        <div className="container">
          <div className="sectionIntro">
            <span>Themen</span>
            <h2>Kommunikation, die in Dein Leben passt</h2>
          </div>
          <div className={styles.topicGrid}>
            {[
              {
                title: "Gespräche im Alltag",
                text: "Lerne, Alltagsfrust früh zu benennen, ohne die Stimmung zu kippen.",
                image: "https://picsum.photos/800/600?random=21"
              },
              {
                title: "Familie & Partnerschaft",
                text: "Stärkt Eure Verbindung, indem Ihr Bedürfnisse und Grenzen sichtbar macht.",
                image: "https://picsum.photos/800/600?random=22"
              },
              {
                title: "Job & Team",
                text: "Establiert klare Meeting-Strukturen, Feedback-Routinen und gemeinsame Lösungen.",
                image: "https://picsum.photos/800/600?random=23"
              },
              {
                title: "Schwierige Situationen",
                text: "Bereite Dich auf Konfliktgespräche vor, die lange liegen geblieben sind.",
                image: "https://picsum.photos/800/600?random=24"
              }
            ].map((topic) => (
              <article key={topic.title} className={styles.topicCard}>
                <img src={topic.image} alt={topic.title} loading="lazy" />
                <div>
                  <h3>{topic.title}</h3>
                  <p>{topic.text}</p>
                  <Link to="/programs" className={styles.topicLink}>
                    Mehr erfahren →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why}>
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <span className={styles.whyBadge}>Warum Silaventino</span>
              <h2>Kommunikation, die Dich in die Umsetzung bringt</h2>
              <p>
                Wir verbinden modernes Konfliktwissen mit Übungen, die Du in
                Deinen Alltag integrierst. Klar strukturiert, wertschätzend im
                Ton und immer mit Fokus auf Deine Handlungsspielräume.
              </p>
              <ul className={styles.whyList}>
                <li>Praxisnah: Übungen, Checklisten, Leitfragen</li>
                <li>Alltagstauglich: passt zu Deinem Tempo und Kontext</li>
                <li>Schutzräume: klare Grenzen, kein Überreden</li>
              </ul>
            </div>
            <div className={styles.whyCard}>
              <h3>Dein Fortschritt in fünf Schritten</h3>
              <ol>
                <li>Muster erkennen</li>
                <li>Zuhören üben</li>
                <li>Ich-Botschaften formulieren</li>
                <li>Grenzen klar ausdrücken</li>
                <li>Gemeinsame Lösungen festhalten</li>
              </ol>
              <Link to="/guide" className="primaryButton">
                Leitfaden ansehen
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className="sectionIntro">
            <span>Prozess</span>
            <h2>So begleiten wir Dich durch Konflikte</h2>
            <p>
              Jedes Programm folgt einem klaren Ablauf. Du weißt jederzeit, wo
              Du stehst und was als Nächstes dran ist.
            </p>
          </div>
          <div className={styles.processSteps}>
            {[
              {
                step: "01",
                title: "Check-in & Zielbild",
                text: "Du klärst, worum es wirklich geht und welche Haltung Du mitbringst."
              },
              {
                step: "02",
                title: "Gespräch vorbereiten",
                text: "Wir strukturieren Deine Argumente, Bedürfnisse und Fragen."
              },
              {
                step: "03",
                title: "Durchführung meistern",
                text: "Du bekommst Leitfäden und Notfall-Sätze für kritische Momente."
              },
              {
                step: "04",
                title: "Ergebnisse sichern",
                text: "Wir halten Vereinbarungen fest und planen Follow-ups."
              }
            ].map((item) => (
              <article key={item.step} className={styles.processCard}>
                <span>{item.step}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className="sectionIntro">
            <span>Angebote</span>
            <h2>Programme, die Dich Schritt für Schritt begleiten</h2>
          </div>
          <div className={styles.serviceGrid}>
            {[
              {
                title: "7-Tage-Respektvoll-reden",
                text: "Kleine tägliche Impulse sorgen für spürbare Veränderungen in Deiner Sprache.",
                link: "/programs"
              },
              {
                title: "Konfliktgespräche vorbereiten",
                text: "Strukturiere Dein nächstes Gespräch, entwickle klare Ziele und sichere Vereinbarungen.",
                link: "/programs"
              },
              {
                title: "30 Tage bewusster zuhören",
                text: "Mit Audio-Übungen und Reflexionsfragen trainierst Du Dein aktives Zuhören.",
                link: "/programs"
              }
            ].map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <Link to={service.link} className={styles.serviceLink}>
                  Programm wählen →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className="sectionIntro">
            <span>Stimmen</span>
            <h2>Erfahrungen aus der Silaventino Community</h2>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((testimonial, index) => (
              <blockquote
                key={testimonial.name}
                className={`${styles.testimonial} ${
                  testimonialIndex === index ? styles.visible : ""
                }`}
              >
                <p>„{testimonial.quote}“</p>
                <cite>{testimonial.name}</cite>
              </blockquote>
            ))}
            <div className={styles.testimonialDots} role="tablist">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setTestimonialIndex(index)}
                  className={`${styles.dot} ${
                    testimonialIndex === index ? styles.dotActive : ""
                  }`}
                  aria-label={`Testimonial ${index + 1} anzeigen`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className="sectionIntro">
            <span>Projekte</span>
            <h2>Was andere mit Silaventino erreicht haben</h2>
          </div>
          <div className={styles.filterBar} role="tablist">
            {["Alle", "Alltag", "Familie", "Job"].map((category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${
                  selectedCategory === category ? styles.filterActive : ""
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className="sectionIntro">
            <span>FAQ</span>
            <h2>Antworten auf häufige Fragen</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  className={styles.faqQuestion}
                  onClick={() => setOpenFaq((prev) => (prev === index ? -1 : index)))
                  aria-expanded={openFaq === index}
                >
                  {item.question}
                  <span>{openFaq === index ? "–" : "+"}</span>
                </button>
                {openFaq === index && <p>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className="sectionIntro">
            <span>Blog</span>
            <h2>Frische Impulse für Dein Kommunikationshandwerk</h2>
            <p>
              Entdecke neue Perspektiven, Schritt-für-Schritt-Anleitungen und
              Erfahrungsberichte aus der Praxis.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPreview.map((post) => (
              <article key={post.slug} className={styles.blogCard}>
                <img src={post.cover} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <span>{post.category} · {post.readingTime}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                    Weiterlesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.blogCta}>
            <Link to="/blog" className="primaryButton">
              Alle Artikel im Überblick
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaBox}>
            <h2>Bereit, Deine Kommunikation neu zu denken?</h2>
            <p>
              Lass uns gemeinsam Deine nächsten Gespräche vorbereiten – klar,
              respektvoll und mutig. Du bestimmst das Tempo, Silaventino liefert
              die Struktur.
            </p>
            <div className={styles.ctaButtons}>
              <Link to="/contact" className="primaryButton">
                Gespräch anfragen
              </Link>
              <Link to="/programs" className="secondaryButton">
                Programme ansehen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;