import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Programs.module.css";

const programs = [
  {
    title: "7-Tage-Respektvoll-reden",
    duration: "7 Tage",
    audience: "Für alle, die schnelle Impulse wollen",
    description:
      "Kompakte Tagesübungen mit Reflexion, Beispiel-Sätzen und Mikroaufgaben. Ideal, um neue Gewohnheiten aufzubauen.",
    image: "https://picsum.photos/800/600?random=61"
  },
  {
    title: "Konfliktgespräche vorbereiten",
    duration: "2 Wochen",
    audience: "Für Berufstätige und Paare",
    description:
      "Von der Analyse bis zum Gesprächsleitfaden. Du erhältst strukturierte Vorlagen, Fallbeispiele und Checklisten.",
    image: "https://picsum.photos/800/600?random=62"
  },
  {
    title: "30 Tage bewusster zuhören",
    duration: "30 Tage",
    audience: "Für alle, die tiefer einsteigen möchten",
    description:
      "Audio-Impulse, Reflexionsfragen und Peer-Feedback. Du trainierst Präsenz, Empathie und klare Rückmeldungen.",
    image: "https://picsum.photos/800/600?random=63"
  }
];

const Programs = () => (
  <>
    <Helmet>
      <title>Programme | Silaventino</title>
      <meta
        name="description"
        content="Silaventino Programme unterstützen Dich mit strukturierten Challenges für respektvolle Gespräche und faire Konfliktlösungen."
      />
      <link rel="canonical" href="https://www.silaventino.de/programs" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Programme, die Dich Schritt für Schritt begleiten</h1>
        <p>
          Wähle das Format, das zu Deiner Situation passt. Alle Inhalte sind
          praxisnah, mit Beispielen aus dem Alltag und klaren Übungen.
        </p>
      </div>
    </section>

    <section>
      <div className="container">
        <div className={styles.grid}>
          {programs.map((program) => (
            <article key={program.title} className={styles.card}>
              <img src={program.image} alt={program.title} loading="lazy" />
              <div className={styles.cardBody}>
                <h2>{program.title}</h2>
                <div className={styles.meta}>
                  <span>{program.duration}</span>
                  <span>{program.audience}</span>
                </div>
                <p>{program.description}</p>
                <button className="primaryButton">Programm starten</button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Programs;