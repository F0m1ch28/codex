import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Tools.module.css";

const tools = [
  {
    title: "Gesprächs-Vorbereitungsbogen",
    description:
      "Klare Leitfragen helfen Dir, Ziel, Bedürfnisse und mögliche Stolpersteine zu strukturieren.",
    features: [
      "Checkliste für Deine Gesprächsziele",
      "Raum für mögliche Reaktionen",
      "Plan für Follow-ups"
    ],
    image: "https://picsum.photos/800/600?random=71"
  },
  {
    title: "Ich-Botschaften-Formulierungshilfe",
    description:
      "Dein Tool, um Ich-Botschaften in ruhige, klare Sätze zu bringen – inklusive Beispielsätze.",
    features: [
      "Struktur: Beobachtung, Gefühl, Bedürfnis, Bitte",
      "Formulierungsvorschläge für schwierige Situationen",
      "Tipps für empathische Nachfragen"
    ],
    image: "https://picsum.photos/800/600?random=72"
  },
  {
    title: "Checkliste für schwierige Gespräche",
    description:
      "Nutze die Liste, um Rollen, Erwartungen und nächste Schritte vorab zu klären.",
    features: [
      "Vorbereitung auf Emotionen und Trigger",
      "Notfall-Sätze für heikle Momente",
      "Reflexionsfragen nach dem Gespräch"
    ],
    image: "https://picsum.photos/800/600?random=73"
  }
];

const Tools = () => (
  <>
    <Helmet>
      <title>Tools | Silaventino</title>
      <meta
        name="description"
        content="Nutze Silaventino Tools und Checklisten, um Gespräche strukturiert vorzubereiten und Ich-Botschaften klar zu formulieren."
      />
      <link rel="canonical" href="https://www.silaventino.de/tools" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Tools für Deine Gesprächsvorbereitung</h1>
        <p>
          Lade Dir strukturierte Vorlagen herunter, drucke sie aus oder nutze
          sie digital. Mit klaren Leitfragen behältst Du im Gespräch den Überblick.
        </p>
      </div>
    </section>

    <section>
      <div className="container">
        <div className={styles.grid}>
          {tools.map((tool) => (
            <article key={tool.title} className={styles.card}>
              <img src={tool.image} alt={tool.title} loading="lazy" />
              <div>
                <h2>{tool.title}</h2>
                <p>{tool.description}</p>
                <ul>
                  {tool.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
                <button className="secondaryButton">Tool herunterladen</button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Tools;