import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import styles from "./Guide.module.css";

const steps = [
  {
    title: "Eigene Muster erkennen",
    bullets: [
      "Wann gehst Du in Rückzug, wann wirst Du laut?",
      "Welche Sätze lösen bei Dir Stress aus?",
      "Notiere, was Du Dir stattdessen wünschen würdest."
    ]
  },
  {
    title: "Aktiv zuhören",
    bullets: [
      "Fasse zusammen, was Du gehört hast.",
      "Stelle offene Fragen und lasse Pausen zu.",
      "Achte auf Körpersprache – auch Deine eigene."
    ]
  },
  {
    title: "Ich-Botschaften nutzen",
    bullets: [
      "Beschreibe Beobachtung, Gefühl, Bedürfnis, Bitte.",
      "Bleibe bei Dir, vermeide Bewertungen.",
      "Nutze konkrete Situationen statt Verallgemeinerungen."
    ]
  },
  {
    title: "Grenzen klar und respektvoll ausdrücken",
    bullets: [
      "Benenne Deine Grenze ohne Drohung.",
      "Erkläre, warum Dir diese Grenze wichtig ist.",
      "Schlage Alternativen vor, wenn möglich."
    ]
  },
  {
    title: "Gemeinsame Lösungen finden",
    bullets: [
      "Sammle Ideen, bevor Du bewertest.",
      "Suche nach Optionen, die beide Seiten berücksichtigen.",
      "Halte fest, was wer bis wann übernimmt."
    ]
  }
];

const Guide = () => (
  <>
    <Helmet>
      <title>Leitfaden | Silaventino</title>
      <meta
        name="description"
        content="Der Silaventino Leitfaden begleitet Dich Schritt für Schritt zu klarer Kommunikation und fairen Konfliktlösungen."
      />
      <link rel="canonical" href="https://www.silaventino.de/guide" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Dein Leitfaden für klare Gespräche</h1>
        <p>
          Folge den fünf Schritten, um Konflikte vorbereitet anzugehen. Jede
          Stufe enthält Reflexionsfragen und konkrete Formulierungen, die Dir
          Sicherheit geben.
        </p>
      </div>
    </section>

    <section>
      <div className="container">
        <div className={styles.stepGrid}>
          {steps.map((step, index) => (
            <article key={step.title} className={styles.stepCard}>
              <span>0{index + 1}</span>
              <h2>{step.title}</h2>
              <ul>
                {step.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className={styles.cta}>
          <Link to="/programs" className="primaryButton">
            Nächsten Schritt ansehen
          </Link>
        </div>
      </div>
    </section>
  </>
);

export default Guide;