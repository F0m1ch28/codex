import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Imprint.module.css";

const Imprint = () => (
  <>
    <Helmet>
      <title>Impressum | Silaventino</title>
      <meta
        name="description"
        content="Impressum der Silaventino Plattform. Verantwortliche Angaben gemäß § 5 TMG."
      />
      <link rel="canonical" href="https://www.silaventino.de/imprint" />
    </Helmet>

    <section className={styles.imprint}>
      <div className="container">
        <h1>Impressum</h1>
        <p>
          Silaventino<br />
          Musterstraße 12<br />
          10115 Berlin<br />
          Deutschland
        </p>
        <p>
          Telefon: +49 (0)30 1234 5678<br />
          E-Mail: hallo@silaventino.de
        </p>

        <h2>Vertretungsberechtigte Person</h2>
        <p>Valeria König</p>

        <h2>Umsatzsteuer-ID</h2>
        <p>USt-IdNr.: DE000000000</p>

        <h2>Berufsbezeichnung</h2>
        <p>
          Kommunikationstraining & Konfliktmoderation. Es findet keine
          psychotherapeutische oder rechtliche Beratung statt.
        </p>

        <h2>Haftung für Inhalte</h2>
        <p>
          Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte
          verantwortlich. Nach §§ 8 bis 10 TMG sind wir jedoch nicht verpflichtet,
          übermittelte oder gespeicherte fremde Informationen zu überwachen.
        </p>

        <h2>Haftung für Links</h2>
        <p>
          Für Inhalte externer Links übernehmen wir keine Haftung. Für den Inhalt
          der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich.
        </p>

        <h2>Urheberrecht</h2>
        <p>
          Die durch die Seitenbetreiber erstellten Inhalte unterliegen dem
          deutschen Urheberrecht. Vervielfältigung, Bearbeitung und Verbreitung
          bedürfen unserer schriftlichen Zustimmung.
        </p>
      </div>
    </section>
  </>
);

export default Imprint;