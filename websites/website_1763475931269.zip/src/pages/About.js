import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const team = [
  {
    name: "Valeria König",
    role: "Gründerin & Konfliktmoderatorin",
    bio: "Valeria begleitet Teams und Paare seit über 10 Jahren. Sie steht für klare Strukturen und warmherzige Moderation.",
    image: "https://picsum.photos/400/400?random=31"
  },
  {
    name: "Jannis Blum",
    role: "Kommunikationstrainer",
    bio: "Jannis entwickelt Trainingsformate für aktives Zuhören und empathische Sprache. Er liebt praktische Übungen.",
    image: "https://picsum.photos/400/400?random=32"
  },
  {
    name: "Marta Nguyen",
    role: "Content & Community",
    bio: "Marta sorgt dafür, dass Silaventino Inhalte verständlich, inklusiv und gut zugänglich sind.",
    image: "https://picsum.photos/400/400?random=33"
  }
];

const About = () => (
  <>
    <Helmet>
      <title>Über uns | Silaventino</title>
      <meta
        name="description"
        content="Lerne das Team von Silaventino kennen. Wir unterstützen Menschen in Deutschland bei klarer Kommunikation und fairer Konfliktlösung."
      />
      <link rel="canonical" href="https://www.silaventino.de/about" />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Wir glauben an Gespräche, die verbinden</h1>
        <p>
          Silaventino ist aus der Idee entstanden, Konflikte nicht länger
          aufzuschieben. Wir schaffen Räume, in denen Du Deine Themen mit Ruhe,
          Klarheit und Respekt angehst.
        </p>
      </div>
    </section>

    <section>
      <div className="container">
        <div className={styles.missionGrid}>
          <article>
            <h2>Unsere Mission</h2>
            <p>
              Wir unterstützen Menschen in Deutschland dabei, klare,
              respektvolle Kommunikation in ihren Alltag zu bringen. Uns geht es
              um Handlungskompetenz, nicht um Perfektion. Silaventino richtet
              sich an Menschen, die Verantwortung für ihre Gespräche übernehmen
              wollen.
            </p>
          </article>
          <article>
            <h2>Unser Fokus</h2>
            <p>
              Alltagstauglichkeit steht im Vordergrund. Alle Übungen sind so
              gestaltet, dass Du sie zwischen Terminen, nach Feierabend oder in
              einer ruhigen halben Stunde am Wochenende anwenden kannst.
            </p>
          </article>
          <article>
            <h2>Unser Versprechen</h2>
            <p>
              Wir sind keine psychotherapeutische Praxis und kein Rechtsdienst.
              Wir bieten Dir eine solide Grundlage in Kommunikation und Struktur
              für Konfliktlösungen, basierend auf anerkannten Methoden.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={styles.team}>
      <div className="container">
        <div className="sectionIntro">
          <span>Team</span>
          <h2>Menschen hinter Silaventino</h2>
          <p>
            Wir verbinden Konfliktmoderation, Kommunikationstraining und klare
            Content-Formate, damit Du gut begleitet bist.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <div className={styles.teamInfo}>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.assurance}>
      <div className="container">
        <div className={styles.assuranceBox}>
          <h2>Datenschutz & Seriosität</h2>
          <p>
            Wir behandeln Deine Informationen vertraulich. Daten werden nur für
            die Kontaktaufnahme und interne Planung genutzt. Wir arbeiten nach
            klaren ethischen Leitlinien – transparent, respektvoll,
            verantwortungsbewusst.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default About;