import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import styles from "./Blog.module.css";
import { blogPosts } from "../data/blogPosts";

const Blog = () => {
  const [selectedCategory, setSelectedCategory] = useState("Alle");

  const categories = ["Alle", ...new Set(blogPosts.map((post) => post.category))];

  const filteredPosts =
    selectedCategory === "Alle"
      ? blogPosts
      : blogPosts.filter((post) => post.category === selectedCategory);

  return (
    <>
      <Helmet>
        <title>Blog | Silaventino</title>
        <meta
          name="description"
          content="Inspiration, praktische Tipps und Erfahrungsberichte rund um wertschätzende Kommunikation und faire Konfliktlösung."
        />
        <link rel="canonical" href="https://www.silaventino.de/blog" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Blog & Impulse</h1>
          <p>
            Wir teilen Perspektiven, Methoden und Werkzeuge, die Dich beim
            fairen Umgang mit Konflikten unterstützen.
          </p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className={styles.filterBar}>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`${styles.filterButton} ${
                  selectedCategory === category ? styles.active : ""
                }`}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filteredPosts.map((post) => (
              <article key={post.slug} className={styles.card}>
                <img src={post.cover} alt={post.title} loading="lazy" />
                <div>
                  <span>{post.category} · {post.readingTime}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <Link to={`/blog/${post.slug}`} className={styles.link}>
                    Weiterlesen →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;