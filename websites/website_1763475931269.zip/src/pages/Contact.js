import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Contact.module.css";

const Contact = () => {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Bitte gib Deinen Namen an.";
    if (!formData.email.trim()) {
      newErrors.email = "Bitte gib Deine E-Mail-Adresse an.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Bitte gib eine gültige E-Mail-Adresse an.";
    }
    if (!formData.message.trim()) newErrors.message = "Deine Nachricht fehlt noch.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Silaventino</title>
        <meta
          name="description"
          content="Kontaktiere Silaventino – wir begleiten Dich bei klarer Kommunikation und fairer Konfliktlösung."
        />
        <link rel="canonical" href="https://www.silaventino.de/contact" />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Lass uns gemeinsam den nächsten Schritt planen</h1>
          <p>
            Erzähl uns kurz, worum es für Dich geht. Wir melden uns innerhalb
            von zwei Werktagen mit einem Vorschlag für das weitere Vorgehen.
          </p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">
                Name
                <input
                  id="name"
                  name="name"
                  type="text"
                  placeholder="Dein vollständiger Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  aria-invalid={errors.name ? "true" : "false"}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </label>

              <label htmlFor="email">
                E-Mail
                <input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="mail@beispiel.de"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  aria-invalid={errors.email ? "true" : "false"}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </label>

              <label htmlFor="message">
                Nachricht
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  placeholder="Worum geht es Dir? Welche Unterstützung wünschst Du Dir?"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  aria-invalid={errors.message ? "true" : "false"}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </label>

              <button type="submit" className="primaryButton">
                Nachricht senden
              </button>

              {submitted && (
                <p className={styles.success}>
                  Danke für Deine Nachricht! Wir melden uns so schnell wie möglich.
                </p>
              )}
            </form>

            <div className={styles.info}>
              <h2>Kontaktinformationen</h2>
              <p>
                Silaventino<br />
                Musterstraße 12<br />
                10115 Berlin
              </p>
              <p>
                E-Mail: <a href="mailto:hallo@silaventino.de">hallo@silaventino.de</a><br />
                Telefon: +49 (0)30 1234 5678
              </p>
              <p>
                Wir schützen Deine Daten und nutzen sie ausschließlich zur
                Bearbeitung Deiner Anfrage. Mehr dazu findest Du in unserer{" "}
                <a href="/privacy">Datenschutzerklärung</a>.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;