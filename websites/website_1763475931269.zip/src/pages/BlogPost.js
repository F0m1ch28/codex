import React from "react";
import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import styles from "./BlogPost.module.css";
import { blogPosts } from "../data/blogPosts";

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  if (!post) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>Artikel nicht gefunden</h1>
          <p>
            Der gesuchte Beitrag ist nicht mehr verfügbar oder wurde verschoben.
          </p>
          <Link to="/blog" className="primaryButton">
            Zurück zum Blog
          </Link>
        </div>
      </section>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} | Silaventino Blog</title>
        <meta name="description" content={post.excerpt} />
        <link rel="canonical" href={`https://www.silaventino.de/blog/${post.slug}`} />
      </Helmet>

      <article className={styles.article}>
        <div className="container">
          <header className={styles.header}>
            <span>{post.category} · {post.readingTime}</span>
            <h1>{post.title}</h1>
            <p>{post.excerpt}</p>
          </header>
          <div className={styles.cover}>
            <img src={post.cover} alt={post.title} loading="lazy" />
          </div>
          <div className={styles.content}>
            {post.content.map((section) => (
              <section key={section.heading}>
                <h2>{section.heading}</h2>
                <p>{section.text}</p>
              </section>
            ))}
          </div>
          <footer className={styles.footer}>
            <Link to="/blog" className="secondaryButton">
              Zurück zum Blog
            </Link>
          </footer>
        </div>
      </article>
    </>
  );
};

export default BlogPost;