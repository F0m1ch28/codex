import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Terms.module.css";

const Terms = () => (
  <>
    <Helmet>
      <title>Allgemeine Geschäftsbedingungen | Silaventino</title>
      <meta
        name="description"
        content="AGB der Silaventino Plattform. Transparente Bedingungen für die Nutzung unserer Angebote."
      />
      <link rel="canonical" href="https://www.silaventino.de/legal" />
    </Helmet>

    <section className={styles.legal}>
      <div className="container">
        <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
        <p>Stand: Januar 2024</p>

        <h2>1. Geltungsbereich</h2>
        <p>
          Diese AGB regeln die Nutzung der digitalen Angebote von Silaventino
          (nachfolgend „Anbieter“) durch natürliche Personen (nachfolgend
          „Nutzende“). Abweichende Bedingungen gelten nur, wenn sie schriftlich
          bestätigt wurden.
        </p>

        <h2>2. Leistungen</h2>
        <p>
          Silaventino stellt digitale Inhalte, Programme und Tools zur Verfügung,
          die Fähigkeiten in Kommunikation und Konfliktlösung fördern. Es handelt
          sich nicht um psychotherapeutische oder rechtliche Beratung.
        </p>

        <h2>3. Nutzungsvoraussetzungen</h2>
        <p>
          Nutzende benötigen eine stabile Internetverbindung und ein geeignetes
          Endgerät. Inhalte dürfen ausschließlich für den eigenen Bedarf genutzt
          werden.
        </p>

        <h2>4. Haftung</h2>
        <p>
          Der Anbieter haftet für Vorsatz und grobe Fahrlässigkeit. Für einfache
          Fahrlässigkeit haftet der Anbieter nur bei Verletzung wesentlicher
          Vertragspflichten (Kardinalpflichten). Eine Haftung für indirekte
          Schäden ist ausgeschlossen.
        </p>

        <h2>5. Urheberrecht</h2>
        <p>
          Sämtliche Inhalte sind urheberrechtlich geschützt. Eine Weitergabe oder
          Vervielfältigung ohne Zustimmung ist untersagt.
        </p>

        <h2>6. Datenschutz</h2>
        <p>
          Hinweise zur Verarbeitung personenbezogener Daten befinden sich in der{" "}
          <a href="/privacy">Datenschutzerklärung</a>.
        </p>

        <h2>7. Schlussbestimmungen</h2>
        <p>
          Es gilt deutsches Recht. Gerichtsstand ist, soweit zulässig, Berlin.
          Sollten einzelne Bestimmungen unwirksam sein, bleibt der Vertrag im
          Übrigen wirksam.
        </p>
      </div>
    </section>
  </>
);

export default Terms;