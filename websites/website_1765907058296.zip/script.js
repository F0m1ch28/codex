document.addEventListener("DOMContentLoaded", () => {
  const consentKey = "northEnergyConsent";
  const banners = document.querySelectorAll(".cookie-banner");

  banners.forEach(banner => {
    const storedConsent = localStorage.getItem(consentKey);
    if (storedConsent) {
      banner.classList.add("hide");
    }

    const buttons = banner.querySelectorAll("button[data-consent]");
    buttons.forEach(button => {
      button.addEventListener("click", event => {
        event.preventDefault();
        const value = button.dataset.consent;
        localStorage.setItem(consentKey, value);
        banner.classList.add("hide");
        const redirectTarget = button.dataset.redirect;
        if (redirectTarget) {
          window.open(redirectTarget, "_blank");
        }
      });
    });
  });

  const searchInput = document.getElementById("postSearch");
  const filterButtons = document.querySelectorAll(".filter-button");
  const postCards = document.querySelectorAll(".post-card");
  const paginationButtons = document.querySelectorAll(".pagination button");

  let activeFilter = "all";
  let activePage = "1";

  function updateListing() {
    postCards.forEach(card => {
      const matchesFilter = activeFilter === "all" || card.dataset.category === activeFilter;
      const matchesPage = card.dataset.page === activePage;
      const searchTerm = searchInput ? searchInput.value.trim().toLowerCase() : "";
      const matchesSearch = !searchTerm || card.innerText.toLowerCase().includes(searchTerm);

      if (matchesFilter && matchesPage && matchesSearch) {
        card.classList.remove("hidden");
      } else {
        card.classList.add("hidden");
      }
    });
  }

  if (searchInput) {
    searchInput.addEventListener("input", () => {
      activePage = "1";
      paginationButtons.forEach(btn => btn.classList.toggle("active", btn.dataset.page === activePage));
      updateListing();
    });
  }

  filterButtons.forEach(button => {
    button.addEventListener("click", () => {
      activeFilter = button.dataset.filter;
      filterButtons.forEach(btn => {
        const isActive = btn === button;
        btn.classList.toggle("active", isActive);
        btn.setAttribute("aria-selected", isActive ? "true" : "false");
      });
      activePage = "1";
      paginationButtons.forEach(btn => btn.classList.toggle("active", btn.dataset.page === activePage));
      updateListing();
    });
  });

  paginationButtons.forEach(button => {
    button.addEventListener("click", () => {
      activePage = button.dataset.page;
      paginationButtons.forEach(btn => btn.classList.toggle("active", btn === button));
      updateListing();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  });

  updateListing();

  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    const nameField = contactForm.querySelector("#name");
    const emailField = contactForm.querySelector("#email");
    const messageField = contactForm.querySelector("#message");
    const errorName = document.getElementById("errorName");
    const errorEmail = document.getElementById("errorEmail");
    const errorMessage = document.getElementById("errorMessage");

    contactForm.addEventListener("submit", event => {
      event.preventDefault();
      let isValid = true;

      if (!nameField.value.trim()) {
        errorName.textContent = "Please provide your name.";
        isValid = false;
      } else {
        errorName.textContent = "";
      }

      const emailValue = emailField.value.trim();
      if (!emailValue) {
        errorEmail.textContent = "Please provide an email address.";
        isValid = false;
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) {
        errorEmail.textContent = "Enter a valid email address.";
        isValid = false;
      } else {
        errorEmail.textContent = "";
      }

      if (!messageField.value.trim()) {
        errorMessage.textContent = "Please include a message.";
        isValid = false;
      } else {
        errorMessage.textContent = "";
      }

      if (isValid) {
        window.location.href = "thanks.html";
      }
    });
  }
});