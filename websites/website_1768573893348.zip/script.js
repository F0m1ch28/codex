const navToggle = document.querySelector(".nav-toggle");
const navLinks = document.querySelector(".nav-links");
const navLinkItems = document.querySelectorAll(".nav-links a");
const cookieBanner = document.getElementById("cookieBanner");
const acceptCookiesBtn = document.getElementById("acceptCookies");
const declineCookiesBtn = document.getElementById("declineCookies");
const consentKey = "boomboynvn_cookie_consent";

if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
        navToggle.classList.toggle("active");
        navLinks.classList.toggle("active");
    });

    navLinkItems.forEach(link => {
        link.addEventListener("click", () => {
            navToggle.classList.remove("active");
            navLinks.classList.remove("active");
        });
    });
}

function showCookieBanner() {
    if (!cookieBanner) return;
    const existingConsent = localStorage.getItem(consentKey);
    if (!existingConsent) {
        cookieBanner.classList.add("show");
    }
}

function setCookieConsent(value) {
    localStorage.setItem(consentKey, value);
    if (cookieBanner) {
        cookieBanner.classList.remove("show");
    }
}

if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener("click", () => {
        setCookieConsent("accepted");
    });
}

if (declineCookiesBtn) {
    declineCookiesBtn.addEventListener("click", () => {
        setCookieConsent("declined");
    });
}

document.addEventListener("DOMContentLoaded", showCookieBanner);