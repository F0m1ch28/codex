document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");

  if (navToggle && mainNav) {
    navToggle.addEventListener("click", () => {
      mainNav.classList.toggle("open");
    });
  }

  const banner = document.getElementById("cookie-banner");
  if (banner) {
    const cookiePreference = localStorage.getItem("emjCookiePreference");
    if (!cookiePreference) {
      banner.classList.add("active");
    }

    banner.addEventListener("click", (event) => {
      const action = event.target.getAttribute("data-cookie-action");
      if (!action) return;
      if (action === "accept") {
        localStorage.setItem("emjCookiePreference", "accepted");
      }
      if (action === "decline") {
        localStorage.setItem("emjCookiePreference", "declined");
      }
      banner.classList.remove("active");
    });
  }

  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const nameInput = contactForm.querySelector("#name");
      const emailInput = contactForm.querySelector("#email");
      const orgInput = contactForm.querySelector("#organization");
      const messageInput = contactForm.querySelector("#message");

      let valid = true;

      clearError("name");
      clearError("email");
      clearError("organization");
      clearError("message");

      if (!nameInput.value.trim()) {
        valid = false;
        setError("name", "Please provide your name.");
      }

      const emailValue = emailInput.value.trim();
      if (!emailValue) {
        valid = false;
        setError("email", "Email is required.");
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) {
        valid = false;
        setError("email", "Enter a valid email address.");
      }

      if (!messageInput.value.trim() || messageInput.value.trim().length < 20) {
        valid = false;
        setError("message", "Message should be at least 20 characters long.");
      }

      if (!valid) {
        return;
      }

      contactForm.submit();
    });
  }

  function setError(fieldId, message) {
    const errorElement = document.querySelector(`[data-error-for="${fieldId}"]`);
    if (errorElement) {
      errorElement.textContent = message;
    }
  }

  function clearError(fieldId) {
    const errorElement = document.querySelector(`[data-error-for="${fieldId}"]`);
    if (errorElement) {
      errorElement.textContent = "";
    }
  }

  const postList = document.getElementById("post-list");
  const paginationContainer = document.getElementById("pagination");
  const searchInput = document.getElementById("post-search");
  const filterButtons = document.querySelectorAll(".filter-button");
  const resultsCount = document.getElementById("results-count");

  if (postList && paginationContainer && resultsCount) {
    const posts = Array.from(postList.querySelectorAll(".post-card"));
    const postsPerPage = 6;
    let currentCategory = "all";
    let currentSearch = "";
    let currentPage = 1;

    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        filterButtons.forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");
        currentCategory = button.dataset.category;
        currentPage = 1;
        updateView();
      });
    });

    if (searchInput) {
      searchInput.addEventListener("input", (event) => {
        currentSearch = event.target.value.toLowerCase();
        currentPage = 1;
        updateView();
      });
    }

    function filterPosts() {
      return posts.filter((card) => {
        const categoryMatch = currentCategory === "all" || card.dataset.category === currentCategory;
        const searchMatch = !currentSearch || card.dataset.title.toLowerCase().includes(currentSearch);
        return categoryMatch && searchMatch;
      });
    }

    function renderPagination(totalPosts) {
      paginationContainer.innerHTML = "";
      const totalPages = Math.ceil(totalPosts / postsPerPage);
      if (totalPages <= 1) return;

      for (let i = 1; i <= totalPages; i += 1) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = i.toString();
        if (i === currentPage) {
          button.classList.add("active");
        }
        button.addEventListener("click", () => {
          currentPage = i;
          updateView();
        });
        paginationContainer.appendChild(button);
      }
    }

    function updateView() {
      const filtered = filterPosts();
      const total = filtered.length;
      const totalPages = Math.ceil(total / postsPerPage) || 1;
      if (currentPage > totalPages) {
        currentPage = totalPages;
      }
      posts.forEach((card) => {
        card.style.display = "none";
      });

      const start = (currentPage - 1) * postsPerPage;
      const end = start + postsPerPage;

      filtered.slice(start, end).forEach((card) => {
        card.style.display = "";
      });

      renderPagination(total);
      resultsCount.textContent = total === 1 ? "Showing 1 briefing" : `Showing ${total} briefings`;
    }

    updateView();
  }
});