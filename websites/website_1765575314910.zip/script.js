document.addEventListener("DOMContentLoaded", () => {
  const banner = document.querySelector(".cookie-banner");
  const acceptBtn = banner?.querySelector(".cookie-accept");
  const declineBtn = banner?.querySelector(".cookie-decline");
  const cookieKey = "qazaqlearn_cookie_preference";

  if (banner) {
    const saved = localStorage.getItem(cookieKey);
    if (!saved) {
      requestAnimationFrame(() => banner.classList.add("is-visible"));
    }

    acceptBtn?.addEventListener("click", () => {
      localStorage.setItem(cookieKey, "accepted");
      banner.classList.remove("is-visible");
    });

    declineBtn?.addEventListener("click", () => {
      localStorage.setItem(cookieKey, "declined");
      banner.classList.remove("is-visible");
    });
  }

  const yearSpans = document.querySelectorAll(".current-year");
  const year = new Date().getFullYear();
  yearSpans.forEach((span) => {
    span.textContent = year;
  });
});