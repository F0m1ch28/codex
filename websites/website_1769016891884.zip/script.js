document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.getElementById('primary-navigation');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = siteNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        const navLinks = siteNav.querySelectorAll('a');
        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (siteNav.classList.contains('open')) {
                    siteNav.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('inksteelCookieConsent');
        if (!storedChoice) {
            cookieBanner.classList.add('is-visible');
            cookieBanner.setAttribute('aria-hidden', 'false');
        } else {
            cookieBanner.setAttribute('aria-hidden', 'true');
        }

        cookieBanner.addEventListener('click', function (event) {
            const choice = event.target.dataset.cookieChoice;
            if (!choice) {
                return;
            }
            localStorage.setItem('inksteelCookieConsent', choice);
            cookieBanner.classList.remove('is-visible');
            cookieBanner.setAttribute('aria-hidden', 'true');
        });
    }
});