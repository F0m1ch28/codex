import React, { Suspense, lazy, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header/Header.jsx';
import Footer from './components/Footer/Footer.jsx';
import CookieBanner from './components/CookieBanner/CookieBanner.jsx';
import DisclaimerModal from './components/DisclaimerModal/DisclaimerModal.jsx';
import ScrollToTop from './components/ScrollToTop.jsx';
import { useLanguage } from './hooks/useLanguage.js';
import styles from './styles/modules/AppLayout.module.css';

const HomePage = lazy(() => import('./pages/HomePage.jsx'));
const InflationPage = lazy(() => import('./pages/InflationPage.jsx'));
const CoursePage = lazy(() => import('./pages/CoursePage.jsx'));
const ResourcesPage = lazy(() => import('./pages/ResourcesPage.jsx'));
const ContactPage = lazy(() => import('./pages/ContactPage.jsx'));
const ThankYouPage = lazy(() => import('./pages/ThankYouPage.jsx'));
const PrivacyPolicyPage = lazy(() => import('./pages/PrivacyPolicyPage.jsx'));
const CookiesPolicyPage = lazy(() => import('./pages/CookiesPolicyPage.jsx'));
const TermsPage = lazy(() => import('./pages/TermsPage.jsx'));
const SitemapPage = lazy(() => import('./pages/SitemapPage.jsx'));
const RobotsPage = lazy(() => import('./pages/RobotsPage.jsx'));

const App = () => {
  const { language } = useLanguage();

  useEffect(() => {
    document.documentElement.lang = language === 'es' ? 'es-AR' : 'en';
  }, [language]);

  return (
    <div className={styles.appWrapper}>
      <a href="#main-content" className={styles.skipLink}>
        Skip to content
      </a>
      <DisclaimerModal />
      <CookieBanner />
      <Header />
      <ScrollToTop />
      <main id="main-content" className={styles.main}>
        <Suspense fallback={<div className={styles.loading} role="status">Loading...</div>}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/inflation" element={<InflationPage />} />
            <Route path="/course" element={<CoursePage />} />
            <Route path="/resources" element={<ResourcesPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/thank-you" element={<ThankYouPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/cookies" element={<CookiesPolicyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/sitemap.xml" element={<SitemapPage />} />
            <Route path="/robots.txt" element={<RobotsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
    </div>
  );
};

export default App;
<!-- END FILE -->