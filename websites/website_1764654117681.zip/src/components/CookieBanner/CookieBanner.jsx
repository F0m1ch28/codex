import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styles from './CookieBanner.module.css';
import useLocalStorage from '../../hooks/useLocalStorage.js';

const CookieBanner = ({ storageKey = 'tph-cookie-consent' }) => {
  const [storedConsent, setStoredConsent] = useLocalStorage(storageKey, null);
  const [isVisible, setIsVisible] = useState(storedConsent === null);

  useEffect(() => {
    setIsVisible(storedConsent === null);
  }, [storedConsent]);

  const handleConsent = (value) => {
    setStoredConsent(value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <p className={styles.text}>
          Este sitio utiliza cookies para mejorar la experiencia. Puedes aceptarlas o rechazarlas. Analíticas opcionales se desactivarán si eliges Decline.
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.acceptButton}
            onClick={() => handleConsent('accepted')}
            aria-label="Accept cookies">
            Accept
          </button>
          <button
            type="button"
            className={styles.declineButton}
            onClick={() => handleConsent('declined')}
            aria-label="Decline cookies">
            Decline
          </button>
        </div>
      </div>
    </div>
  );
};

CookieBanner.propTypes = {
  storageKey: PropTypes.string
};

export default CookieBanner;
<!-- END FILE -->