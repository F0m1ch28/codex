import React from 'react';
import PropTypes from 'prop-types';
import styles from './LanguageSwitcher.module.css';
import { useLanguage } from '../../hooks/useLanguage.js';

const LanguageSwitcher = ({ ariaLabel = 'Switch language' }) => {
  const { language, setLanguage } = useLanguage();

  const handleChange = (event) => {
    setLanguage(event.target.value);
  };

  return (
    <label className={styles.wrapper}>
      <span className={styles.label}>{ariaLabel}</span>
      <select
        className={styles.select}
        value={language}
        onChange={handleChange}
        aria-label={ariaLabel}>
        <option value="en">English</option>
        <option value="es">Español</option>
      </select>
    </label>
  );
};

LanguageSwitcher.propTypes = {
  ariaLabel: PropTypes.string
};

export default LanguageSwitcher;
<!-- END FILE -->