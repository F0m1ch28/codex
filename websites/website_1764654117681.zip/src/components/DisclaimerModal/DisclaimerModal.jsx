import React, { useEffect, useState } from 'react';
import styles from './DisclaimerModal.module.css';
import useLocalStorage from '../../hooks/useLocalStorage.js';

const DisclaimerModal = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [storedConsent, setStoredConsent] = useLocalStorage('tph-disclaimer-ack', false);

  useEffect(() => {
    if (!storedConsent) {
      setIsOpen(true);
    }
  }, [storedConsent]);

  const handleClose = () => {
    setStoredConsent(true);
    setIsOpen(false);
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className={styles.backdrop} role="dialog" aria-modal="true" aria-labelledby="disclaimer-heading">
      <div className={styles.modal}>
        <h2 id="disclaimer-heading" className={styles.title}>
          Aviso importante
        </h2>
        <p className={styles.text}>Мы не предоставляем финансовые услуги.</p>
        <p className={styles.text}>We do not provide financial services.</p>
        <p className={styles.text}>No brindamos servicios financieros.</p>
        <button type="button" className={styles.button} onClick={handleClose} autoFocus>
          Понятно
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;
<!-- END FILE -->