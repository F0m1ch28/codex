import React from 'react';
import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../../hooks/useLanguage.js';

const domain = 'https://tuprogresohoy.com';

const SEO = ({ title, description, path }) => {
  const { language } = useLanguage();
  const canonical = `${domain}${path}`;
  const altEn = `${domain}${path}`;
  const altEs = `${domain}${path}?lang=es`;

  return (
    <Helmet>
      <title>{title}</title>
      {description && <meta name="description" content={description} />}
      <link rel="canonical" href={canonical} />
      <link rel="alternate" hrefLang="en" href={altEn} />
      <link rel="alternate" hrefLang="es-AR" href={altEs} />
      <html lang={language === 'es' ? 'es-AR' : 'en'} />
    </Helmet>
  );
};

SEO.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string,
  path: PropTypes.string.isRequired
};

export default SEO;
<!-- END FILE -->