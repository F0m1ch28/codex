import React from 'react';
import { NavLink } from 'react-router-dom';
import { FaChartPie } from 'react-icons/fa';
import styles from './Header.module.css';
import LanguageSwitcher from '../LanguageSwitcher/LanguageSwitcher.jsx';
import { useLanguage } from '../../hooks/useLanguage.js';

const Header = () => {
  const { t } = useLanguage();

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Tu Progreso Hoy home">
          <FaChartPie aria-hidden="true" className={styles.logoIcon} />
          <span className={styles.logoText}>Tu Progreso Hoy</span>
        </NavLink>
        <nav className={styles.navigation} aria-label="Main">
          <NavLink to="/" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
            {t('nav.home')}
          </NavLink>
          <NavLink to="/inflation" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
            {t('nav.inflation')}
          </NavLink>
          <NavLink to="/course" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
            {t('nav.course')}
          </NavLink>
          <NavLink to="/resources" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
            {t('nav.resources')}
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => isActive ? `${styles.link} ${styles.active}` : styles.link}>
            {t('nav.contact')}
          </NavLink>
        </nav>
        <div className={styles.actions}>
          <LanguageSwitcher />
        </div>
      </div>
    </header>
  );
};

export default Header;
<!-- END FILE -->