import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './TrialForm.module.css';
import { validateEmail } from '../../utils/validation.js';
import { useLanguage } from '../../hooks/useLanguage.js';

const TrialForm = () => {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    preferredLanguage: language === 'es' ? 'ES' : 'EN',
    honeypot: ''
  });
  const [errors, setErrors] = useState({});
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [confirmationCode, setConfirmationCode] = useState('');
  const [formMessage, setFormMessage] = useState('');

  const handleInputChange = (event) => {
    const { name, value } = event.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const validateStepOne = () => {
    const stepErrors = {};
    if (!formData.name.trim()) {
      stepErrors.name = 'Name is required.';
    }
    if (!validateEmail(formData.email)) {
      stepErrors.email = 'Please enter a valid email.';
    }
    if (formData.honeypot) {
      stepErrors.honeypot = 'Spam detected.';
    }
    return stepErrors;
  };

  const handleSubmitStepOne = (event) => {
    event.preventDefault();
    const validationErrors = validateStepOne();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setLoading(true);
      setFormMessage('');
      setTimeout(() => {
        setLoading(false);
        setStep(2);
        setFormMessage('We sent a confirmation email. Enter the code TPH-OK to activate your trial.');
      }, 800);
    }
  };

  const handleConfirm = (event) => {
    event.preventDefault();
    if (confirmationCode.trim().toUpperCase() !== 'TPH-OK') {
      setErrors({ confirmation: 'Please enter the confirmation code TPH-OK.' });
      return;
    }
    setLoading(true);
    setErrors({});
    setTimeout(() => {
      setLoading(false);
      navigate('/thank-you', { replace: true, state: { name: formData.name } });
    }, 900);
  };

  return (
    <section className={styles.wrapper} id="trial-form" aria-labelledby="trial-form-title">
      <h2 className={styles.title} id="trial-form-title">
        Obtener el acceso: Получить бесплатный пробный урок
      </h2>
      <p className={styles.subtitle}>
        Double Opt-In is active. Completa ambos pasos para recibir tu primer contenido. Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
      </p>

      {step === 1 && (
        <form className={styles.form} onSubmit={handleSubmitStepOne} noValidate>
          <div className={styles.fieldGroup}>
            <label htmlFor="name" className={styles.label}>Nombre / Name</label>
            <input
              id="name"
              name="name"
              type="text"
              autoComplete="name"
              className={styles.input}
              value={formData.name}
              onChange={handleInputChange}
              aria-invalid={errors.name ? 'true' : 'false'}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="email" className={styles.label}>Email</label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              className={styles.input}
              value={formData.email}
              onChange={handleInputChange}
              aria-invalid={errors.email ? 'true' : 'false'}
              placeholder="nombre@example.com"
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>

          <div className={styles.fieldGroup}>
            <label htmlFor="preferredLanguage" className={styles.label}>Idioma / Language</label>
            <select
              id="preferredLanguage"
              name="preferredLanguage"
              className={styles.select}
              value={formData.preferredLanguage}
              onChange={handleInputChange}>
              <option value="EN">English</option>
              <option value="ES">Español</option>
            </select>
          </div>

          <div className={styles.hiddenField} aria-hidden="true">
            <label htmlFor="honeypot">Leave blank</label>
            <input
              id="honeypot"
              name="honeypot"
              type="text"
              value={formData.honeypot}
              onChange={handleInputChange}
              tabIndex="-1"
              autoComplete="off"
            />
            {errors.honeypot && <span className={styles.error}>{errors.honeypot}</span>}
          </div>

          <button type="submit" className={styles.submit} disabled={loading}>
            {loading ? 'Processing...' : 'Step 1: Submit details'}
          </button>
        </form>
      )}

      {step === 2 && (
        <form className={styles.form} onSubmit={handleConfirm} noValidate>
          <p className={styles.info} role="status">{formMessage}</p>
          <div className={styles.fieldGroup}>
            <label htmlFor="confirmationCode" className={styles.label}>Confirmation Code</label>
            <input
              id="confirmationCode"
              name="confirmationCode"
              type="text"
              className={styles.input}
              value={confirmationCode}
              onChange={(event) => setConfirmationCode(event.target.value)}
              aria-invalid={errors.confirmation ? 'true' : 'false'}
              placeholder="TPH-OK"
            />
            {errors.confirmation && <span className={styles.error}>{errors.confirmation}</span>}
          </div>
          <button type="submit" className={styles.submit} disabled={loading}>
            {loading ? 'Confirming...' : 'Step 2: Confirm subscription'}
          </button>
        </form>
      )}
    </section>
  );
};

export default TrialForm;
<!-- END FILE -->