import React, { useState } from 'react';
import styles from './ContactForm.module.css';
import { validateEmail } from '../../utils/validation.js';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    topic: '',
    message: '',
    consent: false,
    honeypot: ''
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const validateForm = () => {
    const formErrors = {};
    if (!formData.fullName.trim()) {
      formErrors.fullName = 'Name is required.';
    }
    if (!validateEmail(formData.email)) {
      formErrors.email = 'Email is not valid.';
    }
    if (!formData.topic.trim()) {
      formErrors.topic = 'Topic is required.';
    }
    if (!formData.message.trim()) {
      formErrors.message = 'Message cannot be empty.';
    }
    if (!formData.consent) {
      formErrors.consent = 'Consent is required.';
    }
    if (formData.honeypot) {
      formErrors.honeypot = 'Spam detected.';
    }
    return formErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('');
    const validationErrors = validateForm();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        setStatus('Thank you! We will get back to you within one business day.');
        setFormData({
          fullName: '',
          email: '',
          topic: '',
          message: '',
          consent: false,
          honeypot: ''
        });
      }, 1000);
    }
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit} noValidate>
      <div className={styles.field}>
        <label htmlFor="fullName" className={styles.label}>Full Name</label>
        <input
          id="fullName"
          name="fullName"
          type="text"
          className={styles.input}
          value={formData.fullName}
          onChange={handleChange}
          aria-invalid={errors.fullName ? 'true' : 'false'}
        />
        {errors.fullName && <span className={styles.error}>{errors.fullName}</span>}
      </div>

      <div className={styles.field}>
        <label htmlFor="email" className={styles.label}>Email</label>
        <input
          id="email"
          name="email"
          type="email"
          className={styles.input}
          value={formData.email}
          onChange={handleChange}
          aria-invalid={errors.email ? 'true' : 'false'}
        />
        {errors.email && <span className={styles.error}>{errors.email}</span>}
      </div>

      <div className={styles.field}>
        <label htmlFor="topic" className={styles.label}>Topic</label>
        <input
          id="topic"
          name="topic"
          type="text"
          className={styles.input}
          value={formData.topic}
          onChange={handleChange}
          aria-invalid={errors.topic ? 'true' : 'false'}
        />
        {errors.topic && <span className={styles.error}>{errors.topic}</span>}
      </div>

      <div className={styles.field}>
        <label htmlFor="message" className={styles.label}>Message</label>
        <textarea
          id="message"
          name="message"
          className={styles.textarea}
          rows="5"
          value={formData.message}
          onChange={handleChange}
          aria-invalid={errors.message ? 'true' : 'false'}
        />
        {errors.message && <span className={styles.error}>{errors.message}</span>}
      </div>

      <div className={styles.checkboxWrapper}>
        <input
          id="consent"
          name="consent"
          type="checkbox"
          checked={formData.consent}
          onChange={handleChange}
          className={styles.checkbox}
        />
        <label htmlFor="consent" className={styles.checkboxLabel}>
          I agree to receive a follow-up email with resources.
        </label>
      </div>
      {errors.consent && <span className={styles.error}>{errors.consent}</span>}

      <div className={styles.hiddenField} aria-hidden="true">
        <label htmlFor="honeypot">Leave blank</label>
        <input
          id="honeypot"
          name="honeypot"
          type="text"
          value={formData.honeypot}
          onChange={handleChange}
          tabIndex="-1"
          autoComplete="off"
        />
        {errors.honeypot && <span className={styles.error}>{errors.honeypot}</span>}
      </div>

      <button type="submit" className={styles.submit} disabled={loading}>
        {loading ? 'Sending...' : 'Send message'}
      </button>
      <div className={styles.status} role="status" aria-live="polite">{status}</div>
    </form>
  );
};

export default ContactForm;
<!-- END FILE -->