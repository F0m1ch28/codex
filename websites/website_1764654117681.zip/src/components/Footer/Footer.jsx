import React from 'react';
import { Link } from 'react-router-dom';
import { FaLinkedin, FaTwitter, FaYoutube } from 'react-icons/fa';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.brandBlock}>
        <h2 className={styles.brandTitle}>Tu Progreso Hoy</h2>
        <p className={styles.brandText}>
          Datos verificados para planificar tu presupuesto. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
        </p>
        <p className={styles.brandText}>
          Información confiable que respalda elecciones responsables sobre tu dinero.
        </p>
      </div>
      <div className={styles.linksBlock}>
        <h3 className={styles.heading}>Explore</h3>
        <ul className={styles.linkList}>
          <li><Link to="/inflation" className={styles.link}>Inflation</Link></li>
          <li><Link to="/course" className={styles.link}>Course</Link></li>
          <li><Link to="/resources" className={styles.link}>Resources</Link></li>
          <li><Link to="/contact" className={styles.link}>Contact</Link></li>
        </ul>
      </div>
      <div className={styles.contactBlock}>
        <h3 className={styles.heading}>Contact</h3>
        <address className={styles.address}>
          Av. 9 de Julio 1000<br />
          C1043 Buenos Aires, Argentina
        </address>
        <a href="tel:+541155551234" className={styles.contactLink}>+54 11 5555-1234</a>
        <a href="mailto:hola@tuprogresohoy.com" className={styles.contactLink}>hola@tuprogresohoy.com</a>
        <div className={styles.socials} aria-label="Social media">
          <a href="https://www.linkedin.com" className={styles.socialLink} aria-label="LinkedIn">
            <FaLinkedin />
          </a>
          <a href="https://twitter.com" className={styles.socialLink} aria-label="Twitter">
            <FaTwitter />
          </a>
          <a href="https://www.youtube.com" className={styles.socialLink} aria-label="YouTube">
            <FaYoutube />
          </a>
        </div>
      </div>
      <div className={styles.legalBlock}>
        <h3 className={styles.heading}>Legal</h3>
        <ul className={styles.linkList}>
          <li><Link to="/privacy" className={styles.link}>Privacy Policy</Link></li>
          <li><Link to="/cookies" className={styles.link}>Cookies Policy</Link></li>
          <li><Link to="/terms" className={styles.link}>Terms of Use</Link></li>
        </ul>
        <p className={styles.disclaimer}>
          Decisiones responsables, objetivos nítidos. Conocimiento financiero impulsado por tendencias.
        </p>
      </div>
    </div>
    <div className={styles.bottom}>
      <p className={styles.bottomText}>© {new Date().getFullYear()} Tu Progreso Hoy. Pasos acertados hoy, mejor futuro mañana.</p>
    </div>
  </footer>
);

export default Footer;
<!-- END FILE -->