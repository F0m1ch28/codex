import React from 'react';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/ThankYouPage.module.css';

const ThankYouPage = () => (
  <>
    <SEO
      title="Thank You | Tu Progreso Hoy"
      description="Confirmation page for Tu Progreso Hoy trial request."
      path="/thank-you"
    />
    <section className={styles.page}>
      <div className={styles.card}>
        <h1 className={styles.title}>¡Gracias!</h1>
        <p className={styles.lead}>
          Recibimos tu solicitud. Revisa tu correo y confirma para recibir el primer material. Datos verificados para planificar tu presupuesto.
        </p>
        <a href="/" className={styles.link}>
          Volver al inicio
        </a>
      </div>
    </section>
  </>
);

export default ThankYouPage;
<!-- END FILE -->