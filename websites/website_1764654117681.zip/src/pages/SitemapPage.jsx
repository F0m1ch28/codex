import React from 'react';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/TextPage.module.css';

const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://tuprogresohoy.com/</loc></url>
  <url><loc>https://tuprogresohoy.com/inflation</loc></url>
  <url><loc>https://tuprogresohoy.com/course</loc></url>
  <url><loc>https://tuprogresohoy.com/resources</loc></url>
  <url><loc>https://tuprogresohoy.com/contact</loc></url>
  <url><loc>https://tuprogresohoy.com/thank-you</loc></url>
  <url><loc>https://tuprogresohoy.com/privacy</loc></url>
  <url><loc>https://tuprogresohoy.com/cookies</loc></url>
  <url><loc>https://tuprogresohoy.com/terms</loc></url>
  <url><loc>https://tuprogresohoy.com/sitemap.xml</loc></url>
  <url><loc>https://tuprogresohoy.com/robots.txt</loc></url>
</urlset>`;

const SitemapPage = () => (
  <>
    <SEO
      title="Sitemap | Tu Progreso Hoy"
      description="XML sitemap for Tu Progreso Hoy."
      path="/sitemap.xml"
    />
    <section className={styles.page}>
      <h1 className={styles.title}>Sitemap Preview</h1>
      <pre className={styles.pre} aria-label="Sitemap XML">
        {xmlContent}
      </pre>
    </section>
  </>
);

export default SitemapPage;
<!-- END FILE -->