import React from 'react';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/LegalPage.module.css';

const CookiesPolicyPage = () => (
  <>
    <SEO
      title="Cookies Policy | Tu Progreso Hoy"
      description="Cookies policy for Tu Progreso Hoy educational SaaS platform."
      path="/cookies"
    />
    <article className={styles.page}>
      <h1 className={styles.title}>Cookies Policy</h1>
      <p className={styles.updated}>Last updated: March 2024</p>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. What are cookies?</h2>
        <p>Cookies are small files stored on your device to improve functionality. Este sitio utiliza cookies para mejorar la experiencia.</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Types of cookies</h2>
        <ul>
          <li>Essential cookies: required for authentication and security.</li>
          <li>Analytics cookies: optional, used to understand product usage when you accept them.</li>
          <li>Preference cookies: remember language selections.</li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Managing cookies</h2>
        <p>You can accept or decline through our banner. Declining disables analytics cookies. Preference cookies remain active to store your language choice.</p>
      </section>
    </article>
  </>
);

export default CookiesPolicyPage;
<!-- END FILE -->