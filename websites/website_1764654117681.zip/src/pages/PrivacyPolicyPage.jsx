import React from 'react';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/LegalPage.module.css';

const PrivacyPolicyPage = () => (
  <>
    <SEO
      title="Privacy Policy | Tu Progreso Hoy"
      description="Privacy policy for Tu Progreso Hoy educational SaaS platform."
      path="/privacy"
    />
    <article className={styles.page}>
      <h1 className={styles.title}>Privacy Policy</h1>
      <p className={styles.updated}>Last updated: March 2024</p>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Overview</h2>
        <p>Tu Progreso Hoy processes personal data to provide educational services. Our core principle es garantizar decisiones responsables, objetivos nítidos.</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. Data collected</h2>
        <ul>
          <li>Identification data: name, email, language preference.</li>
          <li>Usage data: pages visited, interactions with course modules.</li>
          <li>Voluntary information: survey responses and feedback.</li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Processing purposes</h2>
        <p>We use personal data to deliver course content, send updates, and improve ARS→USD analytics. No data is sold to third parties.</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Legal basis</h2>
        <p>Processing is based on user consent, contractual necessity, and legitimate interest in providing educational resources contextualized for Argentina.</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>5. Rights</h2>
        <p>You may request access, rectification, deletion, or restriction at hola@tuprogresohoy.com. We respond within ten business days.</p>
      </section>
    </article>
  </>
);

export default PrivacyPolicyPage;
<!-- END FILE -->