import React from 'react';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/LegalPage.module.css';

const TermsPage = () => (
  <>
    <SEO
      title="Terms of Use | Tu Progreso Hoy"
      description="Terms and conditions for using Tu Progreso Hoy educational SaaS platform."
      path="/terms"
    />
    <article className={styles.page}>
      <h1 className={styles.title}>Terms of Use</h1>
      <p className={styles.updated}>Effective: March 2024</p>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>1. Service description</h2>
        <p>Tu Progreso Hoy offers educational content, ARS→USD analytics, and downloadable tools. Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>2. User responsibilities</h2>
        <p>Users agree to provide accurate information, respect intellectual property, and apply insights responsibly.</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>3. Limitations</h2>
        <p>The materials are for educational purposes. No guarantees are made regarding specific financial outcomes.</p>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>4. Contact</h2>
        <p>Questions may be directed to hola@tuprogresohoy.com.</p>
      </section>
    </article>
  </>
);

export default TermsPage;
<!-- END FILE -->