import React from 'react';
import { FaCompass, FaCalendarAlt, FaUserCheck } from 'react-icons/fa';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/CoursePage.module.css';

const CoursePage = () => {
  const modules = [
    {
      title: 'Módulo 1 · Diagnóstico',
      items: [
        'Lectura de ingresos en ARS y USD.',
        'Clasificación de gastos y volatilidad mensual.',
        'Plantilla de presupuesto base.'
      ]
    },
    {
      title: 'Módulo 2 · Estrategia cambiaria',
      items: [
        'Escenarios duales: efectivo vs. digital.',
        'Uso de alertas y bandas personalizadas.',
        'Análisis de sensibilidad al tipo de cambio.'
      ]
    },
    {
      title: 'Módulo 3 · Acciones concretas',
      items: [
        'Calendario de metas trimestrales.',
        'Plan de contingencia ante shocks inflacionarios.',
        'Checklist de decisiones responsables.'
      ]
    }
  ];

  return (
    <>
      <SEO
        title="Course Overview | Tu Progreso Hoy"
        description="Explore the personal finance course designed for Argentina with modules, resources, and guidance."
        path="/course"
      />
      <article className={styles.page}>
        <header className={styles.hero}>
          <h1 className={styles.title}>Curso de Finanzas Personales: Tu Progreso Hoy</h1>
          <p className={styles.lead}>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Comprende la inflación, ajusta metas y crea hábitos sostenibles.
          </p>
          <a href="#modules" className={styles.heroButton}>
            Ver módulos
          </a>
        </header>

        <section className={styles.section} aria-labelledby="audience-heading">
          <h2 id="audience-heading" className={styles.sectionTitle}>Para quién es el curso</h2>
          <div className={styles.audienceGrid}>
            <article className={styles.audienceCard}>
              <FaCompass className={styles.icon} aria-hidden="true" />
              <h3 className={styles.cardTitle}>Profesionales dinámicos</h3>
              <p className={styles.cardText}>Necesitas adaptar tus gastos al tipo de cambio y mantener liquidez sin sorpresas.</p>
            </article>
            <article className={styles.audienceCard}>
              <FaCalendarAlt className={styles.icon} aria-hidden="true" />
              <h3 className={styles.cardTitle}>Emprendedores</h3>
              <p className={styles.cardText}>Planifica importaciones, costos dolarizados y compromisos locales con claridad.</p>
            </article>
            <article className={styles.audienceCard}>
              <FaUserCheck className={styles.icon} aria-hidden="true" />
              <h3 className={styles.cardTitle}>Estudiantes y familias</h3>
              <p className={styles.cardText}>Aprende a presupuestar, comparar opciones y tomar decisiones responsables.</p>
            </article>
          </div>
        </section>

        <section className={styles.section} id="modules" aria-labelledby="modules-heading">
          <h2 id="modules-heading" className={styles.sectionTitle}>Programa modular</h2>
          <div className={styles.modules}>
            {modules.map((module) => (
              <div key={module.title} className={styles.moduleCard}>
                <h3 className={styles.moduleTitle}>{module.title}</h3>
                <ul className={styles.moduleList}>
                  {module.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        <section className={styles.section} aria-labelledby="cta-heading">
          <h2 id="cta-heading" className={styles.sectionTitle}>Prueba gratuita</h2>
          <p className={styles.text}>
            Pasos acertados hoy, mejor futuro mañana. Activa tu Double Opt-In y recibe un diagnóstico inicial con recursos descargables.
          </p>
          <a href="/#trial-form" className={styles.ctaLink}>
            Ir a la prueba gratis
          </a>
        </section>
      </article>
    </>
  );
};

export default CoursePage;
<!-- END FILE -->