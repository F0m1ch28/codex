import React, { useMemo } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line } from 'recharts';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/InflationPage.module.css';

const InflationPage = () => {
  const cpiData = useMemo(
    () => [
      { month: 'Jan', yoy: 102 },
      { month: 'Feb', yoy: 104 },
      { month: 'Mar', yoy: 108 },
      { month: 'Apr', yoy: 112 },
      { month: 'May', yoy: 118 },
      { month: 'Jun', yoy: 121 },
      { month: 'Jul', yoy: 125 },
      { month: 'Aug', yoy: 129 },
      { month: 'Sep', yoy: 133 },
      { month: 'Oct', yoy: 137 },
      { month: 'Nov', yoy: 141 },
      { month: 'Dec', yoy: 146 }
    ],
    []
  );

  const fxData = useMemo(
    () => [
      { month: 'Jan', official: 182, blue: 352 },
      { month: 'Feb', official: 188, blue: 361 },
      { month: 'Mar', official: 194, blue: 374 },
      { month: 'Apr', official: 201, blue: 386 },
      { month: 'May', official: 208, blue: 408 },
      { month: 'Jun', official: 214, blue: 425 },
      { month: 'Jul', official: 223, blue: 443 },
      { month: 'Aug', official: 231, blue: 459 },
      { month: 'Sep', official: 240, blue: 482 },
      { month: 'Oct', official: 249, blue: 505 },
      { month: 'Nov', official: 258, blue: 528 },
      { month: 'Dec', official: 269, blue: 552 }
    ],
    []
  );

  return (
    <>
      <SEO
        title="Inflation Insights | Tu Progreso Hoy"
        description="Understand ARS inflation with transparent methodology, CPI analysis, and FX trends for Argentina."
        path="/inflation"
      />
      <article className={styles.page}>
        <header className={styles.header}>
          <h1 className={styles.title}>Inflation dashboard</h1>
          <p className={styles.lead}>
            Análisis transparentes y datos de mercado para decidir con seguridad. Decisiones responsables, objetivos nítidos.
          </p>
        </header>

        <section className={styles.section} aria-labelledby="methodology-heading">
          <h2 id="methodology-heading" className={styles.sectionTitle}>Methodology</h2>
          <p className={styles.text}>
            Nuestro enfoque combina series oficiales del INDEC, datos de consultoras privadas y paridades forward.
            Cada indicador se normaliza para mantener comparabilidad y se recalcula semanalmente. No realizamos pronósticos de inversión:
            interpretamos variaciones, rezagos y sensibilidad al tipo de cambio. Se incluyen supuestos de inflación núcleo y efecto tarifas,
            destacando la brecha entre inflación minorista y mayorista para decisiones presupuestarias realistas.
          </p>
        </section>

        <section className={styles.section} aria-labelledby="cpi-heading">
          <h2 id="cpi-heading" className={styles.sectionTitle}>CPI YoY evolution</h2>
          <div className={styles.chartCard}>
            <ResponsiveContainer width="100%" height={320}>
              <AreaChart data={cpiData}>
                <defs>
                  <linearGradient id="colorCpi" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,23,42,0.1)" />
                <XAxis dataKey="month" stroke="var(--color-text-muted)" />
                <YAxis stroke="var(--color-text-muted)" />
                <Tooltip />
                <Area type="monotone" dataKey="yoy" stroke="#2563EB" fillOpacity={1} fill="url(#colorCpi)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className={styles.caption}>
            Conocimiento financiero impulsado por tendencias. Datos verificados para planificar tu presupuesto incluso ante volatilidad mensual.
          </p>
        </section>

        <section className={styles.section} aria-labelledby="fx-heading">
          <h2 id="fx-heading" className={styles.sectionTitle}>FX comparison</h2>
          <div className={styles.chartCard}>
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={fxData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(15,23,42,0.1)" />
                <XAxis dataKey="month" stroke="var(--color-text-muted)" />
                <YAxis stroke="var(--color-text-muted)" />
                <Tooltip />
                <Line type="monotone" dataKey="official" stroke="#1F3A6F" strokeWidth={3} dot={false} />
                <Line type="monotone" dataKey="blue" stroke="#2563EB" strokeWidth={3} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className={styles.caption}>
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera con escenarios oficiales y blue.
          </p>
        </section>

        <section className={styles.section} aria-labelledby="faq-heading">
          <h2 id="faq-heading" className={styles.sectionTitle}>FAQ</h2>
          <div className={styles.faqGrid}>
            <details className={styles.faqItem}>
              <summary className={styles.faqQuestion}>¿Cada cuánto se actualiza la base?</summary>
              <p className={styles.faqAnswer}>Actualizamos semanalmente con ajustes diarios para el tipo de cambio y mensuales para CPI.</p>
            </details>
            <details className={styles.faqItem}>
              <summary className={styles.faqQuestion}>¿Se incluyen proyecciones?</summary>
              <p className={styles.faqAnswer}>Mostramos escenarios de referencia basados en consenso, sin recomendaciones individuales.</p>
            </details>
            <details className={styles.faqItem}>
              <summary className={styles.faqQuestion}>¿Puedo descargar los datos?</summary>
              <p className={styles.faqAnswer}>Sí, el plan estándar permite descargar series en CSV para integrarlas en tus análisis.</p>
            </details>
          </div>
        </section>
      </article>
    </>
  );
};

export default InflationPage;
<!-- END FILE -->