import React, { useMemo } from 'react';
import { FaShieldAlt, FaRegLightbulb, FaGraduationCap, FaQuoteLeft } from 'react-icons/fa';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import SEO from '../components/SEO/SEO.jsx';
import TrialForm from '../components/forms/TrialForm.jsx';
import styles from '../styles/modules/HomePage.module.css';
import heroFlag from '../assets/images/hero-flag.svg';
import { useLanguage } from '../hooks/useLanguage.js';

const HomePage = () => {
  const { language } = useLanguage();

  const chartData = useMemo(
    () => [
      { month: 'Jun', rate: 0.0048 },
      { month: 'Jul', rate: 0.0046 },
      { month: 'Aug', rate: 0.0043 },
      { month: 'Sep', rate: 0.0041 },
      { month: 'Oct', rate: 0.0040 },
      { month: 'Nov', rate: 0.0042 },
      { month: 'Dec', rate: 0.0044 },
      { month: 'Jan', rate: 0.0045 },
      { month: 'Feb', rate: 0.0047 },
      { month: 'Mar', rate: 0.0049 },
      { month: 'Apr', rate: 0.0051 },
      { month: 'May', rate: 0.0054 }
    ],
    []
  );

  const currentRate = chartData[chartData.length - 1]?.rate ?? 0;
  const previousRate = chartData[chartData.length - 2]?.rate ?? currentRate;
  const rateChange = currentRate - previousRate;
  const changePercentage = ((rateChange / previousRate) * 100).toFixed(2);

  return (
    <>
      <SEO
        title="Tu Progreso Hoy | Datos verificados para planificar tu presupuesto"
        description="Track ARS to USD trends, access inflation insights, and follow a personal finance course designed for Argentina."
        path="/"
      />
      <article className={styles.page}>
        <section className={styles.hero} aria-labelledby="hero-heading">
          <div className={styles.heroBackground} style={{ backgroundImage: `url(${heroFlag})` }} aria-hidden="true" />
          <div className={styles.heroOverlay}>
            <div className={styles.heroContent}>
              <p className={styles.eyebrow}>Buenos Aires · Argentina</p>
              <h1 id="hero-heading" className={styles.title}>
                Datos verificados para planificar tu presupuesto.
              </h1>
              <p className={styles.subtitle}>
                Decisiones responsables, objetivos nítidos. Con Tu Progreso Hoy interpretas la evolución ARS→USD, aplicas Conocimiento financiero impulsado por tendencias y fortaleces tu criterio con el curso de finanzas personales.
              </p>
              <div className={styles.heroBadges}>
                <span className={styles.badge}>ARS→USD Tracker</span>
                <span className={styles.badge}>Personal Finance Fundamentals</span>
                <span className={styles.badge}>Contexto Argentina</span>
              </div>
            </div>
            <div className={styles.heroTracker} aria-label="ARS to USD tracker">
              <div className={styles.trackerCard}>
                <h2 className={styles.trackerTitle}>ARS → USD</h2>
                <p className={styles.trackerValue}>
                  {currentRate.toFixed(4)} <span className={styles.trackerCurrency}>USD</span>
                </p>
                <p className={rateChange >= 0 ? styles.trackerChangePositive : styles.trackerChangeNegative}>
                  {rateChange >= 0 ? '+' : ''}
                  {changePercentage}% vs prev. month
                </p>
                <div className={styles.chartWrapper} role="img" aria-label="Historical ARS to USD chart">
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(31,58,111,0.15)" />
                      <XAxis dataKey="month" stroke="var(--color-text-muted)" />
                      <YAxis domain={['auto', 'auto']} stroke="var(--color-text-muted)" />
                      <Tooltip />
                      <Line type="monotone" dataKey="rate" stroke="#2563EB" strokeWidth={3} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className={styles.promises} aria-labelledby="promise-heading">
          <h2 id="promise-heading" className={styles.sectionTitle}>
            Análisis transparentes y datos de mercado para decidir con seguridad.
          </h2>
          <div className={styles.promiseGrid}>
            <article className={styles.promiseCard}>
              <FaShieldAlt className={styles.promiseIcon} aria-hidden="true" />
              <h3 className={styles.promiseTitle}>{language === 'es' ? 'Contexto confiable' : 'Reliable context'}</h3>
              <p className={styles.promiseText}>
                Información confiable que respalda elecciones responsables sobre tu dinero.
              </p>
            </article>
            <article className={styles.promiseCard}>
              <FaRegLightbulb className={styles.promiseIcon} aria-hidden="true" />
              <h3 className={styles.promiseTitle}>{language === 'es' ? 'Tendencias accionables' : 'Actionable trends'}</h3>
              <p className={styles.promiseText}>
                Conocimiento financiero impulsado por tendencias y comparables históricos en ARS→USD.
              </p>
            </article>
            <article className={styles.promiseCard}>
              <FaGraduationCap className={styles.promiseIcon} aria-hidden="true" />
              <h3 className={styles.promiseTitle}>{language === 'es' ? 'Aprendizaje aplicado' : 'Applied learning'}</h3>
              <p className={styles.promiseText}>
                De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
              </p>
            </article>
          </div>
        </section>

        <section className={styles.insights} aria-labelledby="insights-heading">
          <h2 id="insights-heading" className={styles.sectionTitle}>
            Conocimiento financiero impulsado por tendencias.
          </h2>
          <div className={styles.insightsGrid}>
            <div className={styles.insight}>
              <h3 className={styles.insightTitle}>Mercado cambiario</h3>
              <p className={styles.insightText}>
                Análisis transparentes y datos de mercado para decidir con seguridad. Estudia el diferencial entre tipo de cambio oficial y contado con liquidación.
              </p>
            </div>
            <div className={styles.insight}>
              <h3 className={styles.insightTitle}>Inflación local</h3>
              <p className={styles.insightText}>
                Datos verificados alineados con mediciones nacionales e internacionales, complementados con escenarios de riesgo ajustados al contexto argentino.
              </p>
            </div>
            <div className={styles.insight}>
              <h3 className={styles.insightTitle}>Planificación personal</h3>
              <p className={styles.insightText}>
                Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Pasos acertados hoy, mejor futuro mañana.
              </p>
            </div>
          </div>
        </section>

        <section className={styles.course} aria-labelledby="course-overview-heading">
          <h2 id="course-overview-heading" className={styles.sectionTitle}>
            Curso base de finanzas personales
          </h2>
          <div className={styles.courseGrid}>
            <div className={styles.courseCard}>
              <h3 className={styles.courseTitle}>¿Qué incluye?</h3>
              <ul className={styles.courseList}>
                <li>Introducción a la planificación mensual en ARS.</li>
                <li>Herramientas para evaluar gastos dolarizados.</li>
                <li>Simulaciones de escenarios con ahorro e ingresos en moneda dual.</li>
                <li>Plantillas descargables y ejercicios guiados.</li>
              </ul>
            </div>
            <div className={styles.courseCard}>
              <h3 className={styles.courseTitle}>Para quién</h3>
              <ul className={styles.courseList}>
                <li>Profesionales que buscan estabilidad presupuestaria.</li>
                <li>Emprendedores que proyectan gastos mixtos.</li>
                <li>Estudiantes que desean comprender la inflación.</li>
              </ul>
              <a href="#trial-form" className={styles.courseCTA}>
                Ir a la prueba gratis
              </a>
            </div>
          </div>
        </section>

        <section className={styles.testimonials} aria-labelledby="testimonials-heading">
          <h2 id="testimonials-heading" className={styles.sectionTitle}>
            Historias de progreso
          </h2>
          <div className={styles.testimonialGrid}>
            <figure className={styles.testimonialCard}>
              <FaQuoteLeft className={styles.quoteIcon} aria-hidden="true" />
              <blockquote className={styles.quote}>
                “Tu Progreso Hoy convirtió datos dispersos en decisiones claras para mi emprendimiento gastronómico.”
              </blockquote>
              <figcaption className={styles.quoteAuthor}>María, Palermo</figcaption>
            </figure>
            <figure className={styles.testimonialCard}>
              <FaQuoteLeft className={styles.quoteIcon} aria-hidden="true" />
              <blockquote className={styles.quote}>
                “Pasar del peso al dólar mes a mes ya no es una sorpresa. La plataforma resume lo esencial sin ruido.”
              </blockquote>
              <figcaption className={styles.quoteAuthor}>Julián, Córdoba</figcaption>
            </figure>
          </div>
          <p className={styles.testimonialNote}>
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </section>

        <section className={styles.formSection} aria-labelledby="trial-form-title">
          <TrialForm />
        </section>
      </article>
    </>
  );
};

export default HomePage;
<!-- END FILE -->