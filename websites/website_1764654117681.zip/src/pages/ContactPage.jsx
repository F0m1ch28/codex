import React from 'react';
import { FaEnvelope, FaPhoneAlt, FaMapMarkerAlt } from 'react-icons/fa';
import SEO from '../components/SEO/SEO.jsx';
import ContactForm from '../components/forms/ContactForm.jsx';
import styles from '../styles/modules/ContactPage.module.css';

const ContactPage = () => (
  <>
    <SEO
      title="Contact | Tu Progreso Hoy"
      description="Contact Tu Progreso Hoy team in Buenos Aires for questions about inflation data and finance course."
      path="/contact"
    />
    <article className={styles.page}>
      <header className={styles.header}>
        <h1 className={styles.title}>Hablemos sobre tus objetivos</h1>
        <p className={styles.lead}>
          Datos verificados para planificar tu presupuesto. Contáctanos para coordinar una demostración o solicitar recursos adicionales.
        </p>
      </header>

      <section className={styles.section} aria-labelledby="contact-details-heading">
        <div className={styles.contactInfo}>
          <h2 id="contact-details-heading" className={styles.sectionTitle}>Datos de contacto</h2>
          <div className={styles.infoItem}>
            <FaMapMarkerAlt className={styles.icon} aria-hidden="true" />
            <div>
              <p className={styles.infoLabel}>Oficina</p>
              <address className={styles.infoText}>
                Av. 9 de Julio 1000<br />
                C1043 Buenos Aires, Argentina
              </address>
            </div>
          </div>
          <div className={styles.infoItem}>
            <FaEnvelope className={styles.icon} aria-hidden="true" />
            <div>
              <p className={styles.infoLabel}>Email</p>
              <a href="mailto:hola@tuprogresohoy.com" className={styles.infoLink}>hola@tuprogresohoy.com</a>
            </div>
          </div>
          <div className={styles.infoItem}>
            <FaPhoneAlt className={styles.icon} aria-hidden="true" />
            <div>
              <p className={styles.infoLabel}>Teléfono</p>
              <a href="tel:+541155551234" className={styles.infoLink}>+54 11 5555-1234</a>
            </div>
          </div>
        </div>
        <div className={styles.formWrapper}>
          <ContactForm />
        </div>
      </section>

      <section className={styles.mapSection} aria-labelledby="map-heading">
        <h2 id="map-heading" className={styles.sectionTitle}>Ubicación</h2>
        <div className={styles.mapContainer}>
          <iframe
            title="Tu Progreso Hoy office map"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.0473901094646!2d-58.3840468233354!3d-34.60373437295202!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacf0cf28fd5%3A0x76606b6ade24bdb6!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1709836800000!5m2!1sen!2sar"
            loading="lazy"
            className={styles.map}
            style={{ border: 0 }}
            allowFullScreen=""
          />
        </div>
      </section>
    </article>
  </>
);

export default ContactPage;
<!-- END FILE -->