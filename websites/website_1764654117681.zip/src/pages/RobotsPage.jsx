import React from 'react';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/TextPage.module.css';

const robotsContent = `User-agent: *
Allow: /

Sitemap: https://tuprogresohoy.com/sitemap.xml`;

const RobotsPage = () => (
  <>
    <SEO
      title="Robots.txt | Tu Progreso Hoy"
      description="Robots directives for Tu Progreso Hoy."
      path="/robots.txt"
    />
    <section className={styles.page}>
      <h1 className={styles.title}>Robots.txt Preview</h1>
      <pre className={styles.pre} aria-label="Robots file">
        {robotsContent}
      </pre>
    </section>
  </>
);

export default RobotsPage;
<!-- END FILE -->