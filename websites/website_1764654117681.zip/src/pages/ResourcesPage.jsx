import React, { useState } from 'react';
import { FaBookOpen, FaLanguage } from 'react-icons/fa';
import SEO from '../components/SEO/SEO.jsx';
import styles from '../styles/modules/ResourcesPage.module.css';

const articles = {
  en: [
    {
      title: 'How inflation reshapes monthly budgets',
      excerpt: 'Understand the impact of double-digit inflation on daily decisions and long-term goals in Argentina.',
      link: '#'
    },
    {
      title: 'Planning with dual-currency income',
      excerpt: 'A guide to balancing pesos and dollars in personal cash flow without stress.',
      link: '#'
    }
  ],
  es: [
    {
      title: 'Cómo la inflación redefine el presupuesto mensual',
      excerpt: 'Analiza el impacto de la inflación de dos dígitos en decisiones cotidianas y metas de largo plazo.',
      link: '#'
    },
    {
      title: 'Planificación con ingresos en doble moneda',
      excerpt: 'Guía práctica para equilibrar pesos y dólares en tu flujo personal.',
      link: '#'
    }
  ]
};

const glossary = [
  { term: 'Inflación subyacente', definition: 'Variación de precios excluyendo rubros volátiles, útil para planificar metas de mediano plazo.' },
  { term: 'Brecha cambiaria', definition: 'Diferencia porcentual entre el tipo de cambio oficial y el alternativo (blue o MEP).' },
  { term: 'Canasta básica', definition: 'Conjunto de bienes y servicios esenciales cuyo costo mensual permite medir el poder adquisitivo.' },
  { term: 'Dolarización de costos', definition: 'Proceso de expresar gastos en dólares para reducir el impacto de la devaluación del peso.' }
];

const ResourcesPage = () => {
  const [language, setLanguage] = useState('en');

  return (
    <>
      <SEO
        title="Resources | Tu Progreso Hoy"
        description="Articles, bilingual resources, and glossary to improve financial literacy in Argentina."
        path="/resources"
      />
      <article className={styles.page}>
        <header className={styles.hero}>
          <h1 className={styles.title}>Recursos educativos</h1>
          <p className={styles.lead}>
            Información confiable que respalda elecciones responsables sobre tu dinero. Selecciona el idioma y explora artículos, guías y glosario especializado.
          </p>
          <div className={styles.languageToggle}>
            <FaLanguage aria-hidden="true" className={styles.icon} />
            <span className={styles.toggleLabel}>Language:</span>
            <button
              type="button"
              className={language === 'en' ? styles.toggleButtonActive : styles.toggleButton}
              onClick={() => setLanguage('en')}>
              English
            </button>
            <button
              type="button"
              className={language === 'es' ? styles.toggleButtonActive : styles.toggleButton}
              onClick={() => setLanguage('es')}>
              Español
            </button>
          </div>
        </header>

        <section className={styles.section} aria-labelledby="articles-heading">
          <h2 id="articles-heading" className={styles.sectionTitle}>
            Artículos destacados
          </h2>
          <div className={styles.articleGrid}>
            {articles[language].map((article) => (
              <article key={article.title} className={styles.articleCard}>
                <FaBookOpen className={styles.articleIcon} aria-hidden="true" />
                <h3 className={styles.articleTitle}>{article.title}</h3>
                <p className={styles.articleExcerpt}>{article.excerpt}</p>
                <a href={article.link} className={styles.articleLink}>Read more</a>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.section} aria-labelledby="glossary-heading">
          <h2 id="glossary-heading" className={styles.sectionTitle}>Glosario financiero</h2>
          <dl className={styles.glossary}>
            {glossary.map((item) => (
              <div key={item.term} className={styles.glossaryItem}>
                <dt className={styles.term}>{item.term}</dt>
                <dd className={styles.definition}>{item.definition}</dd>
              </div>
            ))}
          </dl>
        </section>
      </article>
    </>
  );
};

export default ResourcesPage;
<!-- END FILE -->