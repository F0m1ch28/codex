import { useContext } from 'react';
import { LanguageContext } from '../context/LanguageContext.js';

export const useLanguage = () => useContext(LanguageContext);
<!-- END FILE -->