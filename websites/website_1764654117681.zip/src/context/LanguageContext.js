import React, { createContext, useMemo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';

export const LanguageContext = createContext({
  language: 'en',
  setLanguage: () => {},
  t: () => ''
});

const translations = {
  en: {
    nav: {
      home: 'Home',
      inflation: 'Inflation',
      course: 'Course',
      resources: 'Resources',
      contact: 'Contact'
    }
  },
  es: {
    nav: {
      home: 'Inicio',
      inflation: 'Inflación',
      course: 'Curso',
      resources: 'Recursos',
      contact: 'Contacto'
    }
  }
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('tph-language') || 'en';
    }
    return 'en';
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('tph-language', language);
    }
  }, [language]);

  const t = (path) => {
    const segments = path.split('.');
    return segments.reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : path), translations[language]);
  };

  const value = useMemo(() => ({
    language,
    setLanguage,
    t
  }), [language]);

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

LanguageProvider.propTypes = {
  children: PropTypes.node.isRequired
};
<!-- END FILE -->