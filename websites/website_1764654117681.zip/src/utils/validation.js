export const validateEmail = (value) => {
  if (!value) return false;
  // Basic email regex pattern
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(String(value).toLowerCase());
};
<!-- END FILE -->