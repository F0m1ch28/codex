document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navigation = document.querySelector(".primary-navigation");

  if (navToggle && navigation) {
    navToggle.addEventListener("click", () => {
      const isOpen = navigation.getAttribute("data-open") === "true";
      navigation.setAttribute("data-open", String(!isOpen));
      navToggle.setAttribute("aria-expanded", String(!isOpen));
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const storedConsent = localStorage.getItem("caneCookieChoice");

  if (cookieBanner && !storedConsent) {
    cookieBanner.classList.add("active");
  }

  document.querySelectorAll(".cookie-action").forEach((button) => {
    button.addEventListener("click", (event) => {
      const choice = event.currentTarget.dataset.choice;
      localStorage.setItem("caneCookieChoice", choice || "dismissed");
      if (cookieBanner) {
        cookieBanner.classList.remove("active");
      }
    });
  });

  const redirectMap = {
    "/history": "briefs.html",
    "/history/": "briefs.html",
    "/infrastructure": "frameworks.html",
    "/infrastructure/": "frameworks.html",
    "/systems": "indicators.html",
    "/systems/": "indicators.html",
    "/resilience": "interpretation.html",
    "/resilience/": "interpretation.html"
  };

  const currentPath = window.location.pathname;
  if (redirectMap[currentPath]) {
    window.location.replace(redirectMap[currentPath]);
  }
});