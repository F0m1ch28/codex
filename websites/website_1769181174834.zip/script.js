document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');

  if (navToggle && navList && header) {
    navToggle.addEventListener('click', () => {
      const isOpen = header.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      if (isOpen) {
        body.classList.add('no-scroll');
      } else {
        body.classList.remove('no-scroll');
      }
    });

    navList.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        header.classList.remove('nav-open');
        body.classList.remove('no-scroll');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const yearSpans = document.querySelectorAll('.footer-year');
  const currentYear = new Date().getFullYear();
  yearSpans.forEach(span => {
    span.textContent = currentYear;
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('.animate-fade').forEach(section => {
    observer.observe(section);
  });

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('.cookie-accept');
    const declineBtn = cookieBanner.querySelector('.cookie-decline');
    const storedChoice = localStorage.getItem('bc_cookie_choice');
    if (!storedChoice) {
      cookieBanner.classList.add('is-active');
    }
    const handleChoice = (choice) => {
      localStorage.setItem('bc_cookie_choice', choice);
      cookieBanner.classList.remove('is-active');
    };
    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => handleChoice('accept'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => handleChoice('decline'));
    }
  }

  const toast = document.querySelector('.toast');
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    setTimeout(() => {
      toast.classList.remove('is-visible');
    }, 2800);
  };

  const forms = document.querySelectorAll('form[data-redirect]');
  forms.forEach(form => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Mesajul a fost înregistrat. Veți fi redirecționat.');
      const redirectUrl = form.getAttribute('data-redirect') || form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 1600);
    });
  });
});