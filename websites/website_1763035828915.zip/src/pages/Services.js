import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const categories = [
  {
    name: 'Стратегия и консалтинг',
    description:
      'Эволюционная стратегия цифровой трансформации, аудит процессов и целевая модель операционной эффективности.'
  },
  {
    name: 'Технологии и разработка',
    description:
      'Проектирование и разработка цифровых продуктов, построение микросервисных архитектур и внедрение DevOps-практик.'
  },
  {
    name: 'Data & AI',
    description:
      'Создание платформ данных, аналитика, BI-решения, внедрение ML-моделей для прогнозирования и автоматизации.'
  },
  {
    name: 'Операционная поддержка',
    description:
      'Центры компетенций, поддержка и развитие решений, обучение команд и управление изменениями.'
  }
];

const servicesList = [
  {
    title: 'Digital Discovery',
    category: 'Стратегия',
    description:
      'Диагностика цифрового уровня компании, разработка roadmap трансформации на 12-18 месяцев.',
    deliverables: ['Digital maturity assessment', 'Целевая архитектура', 'Backlog инициатив']
  },
  {
    title: 'CTO-as-a-Service',
    category: 'Стратегия',
    description:
      'Временное или проектное руководство технологической повесткой компании: управление портфелем, командами и бюджетами.',
    deliverables: ['CIO advisory', 'Стратегия IT-развития', 'Управление вендорами']
  },
  {
    title: 'Enterprise Architecture',
    category: 'Технологии',
    description:
      'Построение целевой архитектуры, создание стандартизированных решений, управление интеграциями.',
    deliverables: ['TOGAF методологии', 'Интеграционные паттерны', 'Governance модел']
  },
  {
    title: 'Product Engineering',
    category: 'Технологии',
    description:
      'Создание end-to-end digital продуктов: discovery, UX/UI, разработка, QA, внедрение.',
    deliverables: ['Design systems', 'Agile delivery', 'Product analytics']
  },
  {
    title: 'Data Platform Launch',
    category: 'Data & AI',
    description:
      'Внедрение современной платформы данных, self-service BI и механизмов data governance.',
    deliverables: ['Data lakehouse', 'Snowflake / BigQuery', 'Data stewardship']
  },
  {
    title: 'ML & AI Solutions',
    category: 'Data & AI',
    description:
      'Разработка ML-моделей для прогнозирования, рекомендации и автоматизации клиентских процессов.',
    deliverables: ['ML pipeline', 'MLOps', 'Monitoring & retraining']
  },
  {
    title: 'Service Management',
    category: 'Операции',
    description:
      'Организация процессов поддержки, внедрение ITSM-практик и управление SLA.',
    deliverables: ['Service catalogue', 'ITIL процессы', 'Automation scripts']
  },
  {
    title: 'Change Enablement',
    category: 'Операции',
    description:
      'Управление изменениями, разработка программ обучения, сопровождение внедрения решений.',
    deliverables: ['Коммуникационный план', 'Training academy', 'Change adoption metrics']
  }
];

const Services = () => {
  const [activeCategory, setActiveCategory] = React.useState(categories[0].name);

  return (
    <>
      <Helmet>
        <title>Услуги — TechFlow Solutions</title>
        <meta
          name="description"
          content="Консультации по цифровой трансформации, разработка IT-стратегий, создание платформ, Data & AI и операционная поддержка от TechFlow Solutions."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.container}>
          <p className={styles.kicker}>Услуги</p>
          <h1>Комплексные решения для цифрового роста</h1>
          <p>
            Мы берем на себя ответственность за результат и поддерживаем клиента на каждом этапе:
            от формирования стратегии до внедрения и поддержки технологических решений.
          </p>
        </div>
      </section>

      <section className={styles.categories}>
        <div className={styles.container}>
          <div className={styles.categoryTabs} role="tablist" aria-label="Категории услуг">
            {categories.map((category) => (
              <button
                key={category.name}
                type="button"
                onClick={() => setActiveCategory(category.name)}
                className={activeCategory === category.name ? styles.active : ''}
                role="tab"
                aria-selected={activeCategory === category.name}
              >
                {category.name}
              </button>
            ))}
          </div>
          <div className={styles.categoryDescription}>
            {categories.map(
              (category) =>
                activeCategory === category.name && (
                  <p key={category.name}>{category.description}</p>
                )
            )}
          </div>
        </div>
      </section>

      <section className={styles.serviceCards}>
        <div className={styles.container}>
          <div className={styles.grid}>
            {servicesList
              .filter((service) => activeCategory.includes(service.category) || activeCategory === 'Стратегия и консалтинг')
              .map((service) => (
                <article key={service.title} className={styles.card}>
                  <span>{service.category}</span>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <ul>
                    {service.deliverables.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                  <a href="mailto:info@techflow-solutions.ru" aria-label={`Узнать про услугу ${service.title}`}>
                    Обсудить →
                  </a>
                </article>
              ))}
          </div>
        </div>
      </section>

      <section className={styles.advisory}>
        <div className={styles.container}>
          <div className={styles.advisoryCard}>
            <h2>Комбинируем экспертизу под ваши задачи</h2>
            <p>
              Мы формируем команды, адаптированные к отрасли и целям клиента: стратеги, аналитики, архитекторы,
              UX-исследователи, специалисты по данным и инженеры.
            </p>
            <p>
              В работе используем гибридные модели взаимодействия: Managed Services, проектный формат или Embedded-команды.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;