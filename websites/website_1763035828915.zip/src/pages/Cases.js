import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Cases.module.css';

const casesData = [
  {
    title: 'Цифровизация клиентского пути в банке',
    industry: 'FinTech',
    challenge:
      'Фрагментированный клиентский опыт, отсутствие единой клиентской платформы и слабые возможности персонализации.',
    solution:
      'Внедрение омниканальной платформы, построение Customer 360, сегментация на основе машинного обучения и автоматизация коммуникаций.',
    result: ['+22% NPS', '+35% конверсия digital-каналов', 'Время вывода продукта сократилось на 40%']
  },
  {
    title: 'Интеграция производственной экосистемы',
    industry: 'Industry',
    challenge:
      'Разрозненные системы управления производством, сложность обмена данными между цехами и поставщиками.',
    solution:
      'Создание интеграционной шины, внедрение системы мониторинга производственных операций и построение цифрового двойника.',
    result: ['-18% время простоя', '+27% точность планирования', 'Прозрачность цепочки поставок']
  },
  {
    title: 'Переход к data-driven ритейлу',
    industry: 'Retail',
    challenge:
      'Недостаточная аналитика по клиентам, сложные процессы ценообразования и отсутствие единой витрины данных.',
    solution:
      'Запуск data lakehouse, внедрение BI-платформы и динамического ценообразования на основе ML-моделей.',
    result: ['+15% валовая прибыль', 'Единая витрина данных', 'Автоматизация 24 процессов']
  }
];

const Cases = () => (
  <>
    <Helmet>
      <title>Кейсы — TechFlow Solutions</title>
      <meta
        name="description"
        content="Кейсы TechFlow Solutions: цифровизация банков, промышленная интеграция и data-driven трансформация ритейла."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <p className={styles.kicker}>Кейсы</p>
        <h1>Ключевые проекты цифровой трансформации</h1>
        <p>
          Мы сопровождаем клиенты на пути трансформации: от разработки стратегии до внедрения и поддержки решений.
          В основе каждого проекта — измеримый эффект.
        </p>
      </div>
    </section>

    <section className={styles.casesSection}>
      <div className={styles.container}>
        <div className={styles.grid}>
          {casesData.map((item) => (
            <article key={item.title} className={styles.card}>
              <span>{item.industry}</span>
              <h2>{item.title}</h2>
              <div className={styles.contentBlock}>
                <h3>Задача</h3>
                <p>{item.challenge}</p>
              </div>
              <div className={styles.contentBlock}>
                <h3>Решение</h3>
                <p>{item.solution}</p>
              </div>
              <div className={styles.results}>
                <h3>Результаты</h3>
                <ul>
                  {item.result.map((res) => (
                    <li key={res}>{res}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Cases;