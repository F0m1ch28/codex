import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const timeline = [
  {
    year: '2012',
    title: 'Основание компании',
    description:
      'Группа IT-стратегов и инженеров объединилась, чтобы помогать бизнесу адаптироваться к цифровым вызовам.'
  },
  {
    year: '2015',
    title: 'Создание архитектурного офиса',
    description:
      'Сформирована команда архитекторов и аналитиков, внедрены методологии TOGAF и дизайн-мышления.'
  },
  {
    year: '2018',
    title: 'Международные проекты',
    description:
      'Мы расширили присутствие на рынках Европы и Азии, реализуя трансформационные программы для холдингов.'
  },
  {
    year: '2021',
    title: 'Запуск Data & AI практики',
    description:
      'Создан центр компетенций по работе с данными, аналитикой и машинным обучением.'
  }
];

const values = [
  {
    title: 'Партнёрство',
    text: 'Мы выстраиваем долгосрочные отношения, разделяя риски и ответственность за результат.'
  },
  {
    title: 'Прозрачность',
    text: 'Открытая коммуникация и понятные процессы управления проектами для всех участников.'
  },
  {
    title: 'Инновации',
    text: 'Используем передовые технологии, создаём эксперименты и быстро масштабируем успешные практики.'
  },
  {
    title: 'Устойчивость',
    text: 'Строим решения с учетом ESG-повестки и долгосрочного воздействия на бизнес и общество.'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>О компании — TechFlow Solutions</title>
      <meta
        name="description"
        content="TechFlow Solutions — команда IT-консультантов и инженеров с международным опытом, которая помогает компаниям управлять цифровой трансформацией."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className={styles.container}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>О компании</p>
          <h1>Мы создаем цифровую устойчивость бизнеса</h1>
          <p>
            TechFlow Solutions помогает компаниям формировать конкурентные преимущества через технологию.
            Мы объединяем стратегию, архитектуру, разработку и управление изменениями в единую платформу трансформации.
          </p>
        </div>
        <div className={styles.heroCard}>
          <strong>Наша миссия</strong>
          <p>
            Сопровождать клиентов на пути цифровых преобразований, создавая решения, которые делают бизнес гибким,
            устойчивым и ориентированным на человека.
          </p>
        </div>
      </div>
    </section>

    <section className={styles.timelineSection}>
      <div className={styles.container}>
        <h2>История развития</h2>
        <div className={styles.timeline}>
          {timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <div>
                <span>{item.year}</span>
                <h3>{item.title}</h3>
              </div>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.valuesSection}>
      <div className={styles.container}>
        <div className={styles.valuesHeader}>
          <h2>Наши ценности</h2>
          <p>
            Мы соединяем предпринимательское мышление, технологическую экспертизу и глубокое понимание отраслей.
            Это позволяет нам сопровождать клиентов на всех этапах цифрового развития.
          </p>
        </div>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.leadership}>
      <div className={styles.container}>
        <div className={styles.leadershipContent}>
          <h2>Лидерство и команда</h2>
          <p>
            Более 80 экспертов TechFlow Solutions — это архитекторы, инженеры, аналитики данных и консультанты по управлению.
            В основе нашей работы — мультидисциплинарные команды, объединяющие изучение потребностей клиента,
            создание цифрового продукта и внедрение изменений.
          </p>
        </div>
        <div className={styles.imageWrapper}>
          <img
            src="https://picsum.photos/800/600?random=2"
            alt="Команда TechFlow Solutions на стратегической сессии"
            loading="lazy"
          />
        </div>
      </div>
    </section>

    <section className={styles.ctaSection}>
      <div className={styles.container}>
        <div className={styles.ctaCard}>
          <h2>Строим будущее вместе</h2>
          <p>
            Мы открыты к долгосрочным партнерствам и совместному созданию инноваций.
            Расскажите нам о своих задачах, и мы предложим план действий.
          </p>
          <a href="mailto:info@techflow-solutions.ru" className={styles.ctaButton}>
            Написать нам
          </a>
        </div>
      </div>
    </section>
  </>
);

export default About;