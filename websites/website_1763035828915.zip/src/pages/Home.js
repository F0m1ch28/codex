import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Успешных проектов', from: 0, to: 120 },
  { label: 'Лет экспертизы', from: 0, to: 12 },
  { label: 'Экспертов в команде', from: 0, to: 85 },
  { label: 'Стран присутствия', from: 0, to: 6 }
];

const expertiseList = [
  {
    title: 'Enterprise архитектура',
    description: 'Создаем устойчивые архитектурные решения для масштабного роста.',
    icon: '🧩'
  },
  {
    title: 'Цифровая стратегия',
    description: 'Трансформируем бизнес-модели с использованием данных и автоматизации.',
    icon: '🧠'
  },
  {
    title: 'Интеграция систем',
    description: 'Объединяем экосистему решений в единую цифровую платформу.',
    icon: '🔗'
  },
  {
    title: 'Кибербезопасность',
    description: 'Защищаем инфраструктуру и данные на всех уровнях.',
    icon: '🛡️'
  }
];

const approachSteps = [
  {
    number: '01',
    title: 'Диагностика',
    text: 'Анализируем текущие процессы и технологии, формируем целевые показатели.'
  },
  {
    number: '02',
    title: 'Дорожная карта',
    text: 'Определяем приоритеты, формируем реалистичный план трансформации.'
  },
  {
    number: '03',
    title: 'Внедрение',
    text: 'Реализуем решения, обеспечиваем управление изменениями и обучение команды.'
  },
  {
    number: '04',
    title: 'Измерение',
    text: 'Отслеживаем KPI, оптимизируем решения и масштабируем успешные практики.'
  }
];

const technologies = ['AWS', 'Azure', 'Google Cloud', 'Kubernetes', 'Terraform', 'React', 'Node.js', 'Python', 'Snowflake', 'Power BI'];

const advantages = [
  {
    title: 'Бизнес-ориентированный подход',
    text: 'Связываем технологию с конкретными бизнес-целями и измеримыми результатами.'
  },
  {
    title: 'Гибкие модели взаимодействия',
    text: 'Работаем в форматах консалтинга, внедрения, CTO-as-a-service и наставничества.'
  },
  {
    title: 'Экосистема партнёров',
    text: 'Строим решения вместе с ведущими вендорами и стартапами.'
  },
  {
    title: 'Прозрачная коммуникация',
    text: 'Ставим ценность партнёрства и открытую коммуникацию во главу угла.'
  }
];

const process = [
  {
    phase: 'Discovery',
    text: 'Погружаемся в задачи бизнеса, собираем требования и картируем процессы.'
  },
  {
    phase: 'Design',
    text: 'Формируем архитектуру, UX-концепцию и технологические сценарии.'
  },
  {
    phase: 'Development',
    text: 'Реализуем решения, обеспечиваем тестирование и контроль качества.'
  },
  {
    phase: 'Support',
    text: 'Сопровождаем, развиваем и поддерживаем решения 24/7.'
  }
];

const testimonials = [
  {
    quote:
      'TechFlow Solutions помогли нам выстроить цифровую платформу для взаимодействия с партнерами, что сократило время обработки запросов на 37%. Команда слушает и слышит бизнес.',
    author: 'Екатерина Погодина',
    role: 'Директор по развитию, NovaTrade Group'
  },
  {
    quote:
      'Глубокое понимание стратегических задач и способность оперативно масштабировать команду — ключевые факторы успеха нашего проекта. TechFlow остаются надежным партнером.',
    author: 'Алексей Ковалев',
    role: 'CIO, FinAxis Bank'
  },
  {
    quote:
      'Совместно мы разработали и внедрили омниканальную стратегию обслуживания клиентов. Метрики NPS выросли на 22% всего за полгода.',
    author: 'Марина Глинская',
    role: 'CEO, RetailFlow'
  }
];

const teamMembers = [
  {
    name: 'Александр Рудин',
    role: 'Партнер, Digital Strategy',
    bio: '15+ лет опыта в трансформации финансовых организаций, сертифицированный консультант TOGAF.',
    image: 'https://picsum.photos/400/400?random=3'
  },
  {
    name: 'Дарья Климова',
    role: 'Director of Engineering',
    bio: 'Управляет распределенными командами разработки, специализируется на DevOps и архитектуре платформ.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Илья Чернов',
    role: 'Head of Data & AI',
    bio: 'Эксперт в области аналитики и машинного обучения, внедряет ML-инициативы в крупных холдингах.',
    image: 'https://picsum.photos/400/400?random=32'
  }
];

const faqItems = [
  {
    question: 'С чего начинается цифровая трансформация?',
    answer:
      'Мы начинаем с диагностики текущего состояния: анализ бизнес-процессов, инфраструктуры и цифровых активов. На основе этого формируем дорожную карту трансформации.'
  },
  {
    question: 'Как вы оцениваете эффективность проектов?',
    answer:
      'Для каждого проекта определяем KPI и OKR совместно с командой клиента. Используем прозрачные dashboards и регулярные steering-комитеты.'
  },
  {
    question: 'Можно ли подключиться к проекту на этапе реализации?',
    answer:
      'Да, мы подключаемся к действующим инициативам, проводим аудит и предлагаем практические шаги по оптимизации и доведению проекта до результата.'
  },
  {
    question: 'Работаете ли вы с международными командами?',
    answer:
      'У нас есть распределенная команда консультантов и инженеров с опытом работы в разных часовых поясах и на нескольких языках.'
  }
];

const blogPosts = [
  {
    title: 'Как построить продуктовую модель управления IT',
    date: '15 марта 2024',
    excerpt:
      'Переход от проектного подхода к продуктовому требует перестройки процессов, культуры и метрик. Делимся проверенными шагами и рекомендациями.',
    link: '/services'
  },
  {
    title: 'Data Fabric: новая архитектура данных для бизнеса',
    date: '2 февраля 2024',
    excerpt:
      'Почему Data Fabric меняет правила игры и как подготовить инфраструктуру и команды к внедрению новой архитектуры данных.',
    link: '/about'
  },
  {
    title: 'Интеллектуальная автоматизация процессов',
    date: '22 января 2024',
    excerpt:
      'RPA, low-code платформы и AI-помощники помогают ускорять трансформацию. Разбираем лучшие практики на реальных кейсах.',
    link: '/cases'
  }
];

const projectItems = [
  {
    title: 'Платформа для управления страховыми продуктами',
    category: 'InsurTech',
    description:
      'Единое решение для цифровизации продуктового цикла страховой компании: от дизайна продукта до обслуживания клиентов.',
    image: 'https://picsum.photos/1200/800?random=4'
  },
  {
    title: 'Маркетплейс B2B услуг для промышленности',
    category: 'Industry',
    description:
      'Создана экосистема, объединяющая поставщиков и клиентов, интегрированная с ERP и системами логистики.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    title: 'Мобильный банк нового поколения',
    category: 'FinTech',
    description:
      'Нативное приложение с персонализированными сценариями, интегрированное с платформой open banking.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    title: 'Цифровая витрина для e-commerce холдинга',
    category: 'Retail',
    description:
      'Внедрен headless commerce подход, позволяющий быстро запускать новые каналы продаж и сегменты клиентов.',
    image: 'https://picsum.photos/1200/800?random=43'
  }
];

const filters = ['Все', 'FinTech', 'InsurTech', 'Retail', 'Industry'];

const useReveal = () => {
  const ref = React.useRef(null);
  const [isVisible, setIsVisible] = React.useState(false);

  React.useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(node);
        }
      },
      { threshold: 0.2 }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return [ref, isVisible];
};

const Home = () => {
  const [statsRef, statsVisible] = useReveal();
  const [heroRef, heroVisible] = useReveal();
  const [expertRef, expertVisible] = useReveal();
  const [approachRef, approachVisible] = useReveal();
  const [techRef, techVisible] = useReveal();
  const [advantagesRef, advantagesVisible] = useReveal();
  const [processRef, processVisible] = useReveal();
  const [projectsRef, projectsVisible] = useReveal();
  const [testimonialsRef, testimonialsVisible] = useReveal();
  const [faqRef, faqVisible] = useReveal();
  const [counters, setCounters] = React.useState(statsData.map(() => 0));
  const [activeFilter, setActiveFilter] = React.useState('Все');
  const [currentTestimonial, setCurrentTestimonial] = React.useState(0);

  React.useEffect(() => {
    if (!statsVisible) return;

    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, index) => {
          const target = statsData[index].to;
          if (value >= target) return target;
          const increment = Math.ceil(target / 60);
          return Math.min(value + increment, target);
        })
      );
    }, 30);

    return () => clearInterval(interval);
  }, [statsVisible]);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);

    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeFilter === 'Все'
      ? projectItems
      : projectItems.filter((project) => project.category === activeFilter);

  return (
    <>
      <Helmet>
        <title>TechFlow Solutions — Цифровая трансформация вашего бизнеса</title>
        <meta
          name="description"
          content="TechFlow Solutions помогает компаниям строить стратегию цифровой трансформации, внедрять инновационные решения и обеспечивать устойчивый рост."
        />
      </Helmet>
      <section
        className={`${styles.hero} ${styles.reveal} ${heroVisible ? styles.show : ''}`}
        ref={heroRef}
      >
        <div className={styles.heroOverlay} />
        <div className={styles.container}>
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <p className={styles.kicker}>Цифровая платформа роста</p>
              <h1>Цифровая трансформация вашего бизнеса</h1>
              <p className={styles.lead}>
                Мы объединяем стратегию, технологии и людей, чтобы создавать масштабируемые цифровые
                продукты и экосистемы, адаптированные к вашим целям.
              </p>
              <div className={styles.heroActions}>
                <Link to="/contact" className={styles.primaryBtn} aria-label="Запросить консультацию">
                  Запросить консультацию
                </Link>
                <Link to="/services" className={styles.secondaryBtn} aria-label="Посмотреть услуги">
                  Посмотреть услуги
                </Link>
              </div>
              <div className={styles.heroStats}>
                <span>ISO 27001 сертификация</span>
                <span>Гибридный формат сотрудничества</span>
              </div>
            </div>
            <div className={styles.heroMedia}>
              <div className={styles.heroImageWrapper}>
                <img
                  src="https://picsum.photos/1600/900?random=1"
                  alt="Команда TechFlow Solutions за работой над цифровой стратегией"
                  loading="lazy"
                />
                <div className={styles.heroCard}>
                  <p>Digital Discovery</p>
                  <strong>4 недели до roadmap</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section
        className={`${styles.stats} ${styles.reveal} ${statsVisible ? styles.show : ''}`}
        ref={statsRef}
        aria-label="Основные показатели компании"
      >
        <div className={styles.container}>
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <strong aria-live="polite">{counters[index]}+</strong>
                <span>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.expertise} ${styles.reveal} ${expertVisible ? styles.show : ''}`}
        ref={expertRef}
      >
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>Наши экспертизы</p>
            <h2>Глубина технических знаний, сфокусированная на бизнес-результате</h2>
            <p>
              Команда TechFlow Solutions объединяет международный опыт консалтинга, разработки и управления изменениями,
              помогая клиентам формировать устойчивые цифровые платформы.
            </p>
          </div>
          <div className={styles.expertiseGrid}>
            {expertiseList.map((item) => (
              <article key={item.title} className={styles.expertiseCard}>
                <span className={styles.icon} aria-hidden="true">
                  {item.icon}
                </span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <Link to="/services" aria-label={`Подробнее про ${item.title}`}>
                  Узнать больше →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.approach} ${styles.reveal} ${approachVisible ? styles.show : ''}`}
        ref={approachRef}
      >
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>Подход к работе</p>
            <h2>Ведем трансформацию от идеи до устойчивого результата</h2>
          </div>
          <div className={styles.approachGrid}>
            {approachSteps.map((step) => (
              <div key={step.number} className={styles.approachCard}>
                <span>{step.number}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.tech} ${styles.reveal} ${techVisible ? styles.show : ''}`}
        ref={techRef}
      >
        <div className={styles.container}>
          <div className={styles.techInner}>
            <div>
              <p className={styles.kicker}>Технологии</p>
              <h2>Подбираем технологические стеки под стратегию развития</h2>
              <p>
                Наша команда обладает сертификациями ведущих вендоров и использует лучшие практики DevOps,
                DataOps и SecOps, чтобы обеспечить устойчивый результат.
              </p>
            </div>
            <div className={styles.techGrid} aria-label="Список используемых технологий">
              {technologies.map((tech) => (
                <span key={tech}>{tech}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section
        className={`${styles.advantages} ${styles.reveal} ${advantagesVisible ? styles.show : ''}`}
        ref={advantagesRef}
      >
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>Почему мы</p>
            <h2>TechFlow Solutions — партнер, который разделяет ответственность за результат</h2>
          </div>
          <div className={styles.advGrid}>
            {advantages.map((adv) => (
              <article key={adv.title} className={styles.advCard}>
                <h3>{adv.title}</h3>
                <p>{adv.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.process} ${styles.reveal} ${processVisible ? styles.show : ''}`}
        ref={processRef}
      >
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>Процесс работы</p>
            <h2>Прозрачный путь от исследования до поддержки</h2>
          </div>
          <div className={styles.processFlow}>
            {process.map((step, index) => (
              <div key={step.phase} className={styles.processCard}>
                <span>{index + 1}</span>
                <h3>{step.phase}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.projects} ${styles.reveal} ${projectsVisible ? styles.show : ''}`}
        ref={projectsRef}
      >
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>Проекты</p>
            <h2>Трансформационные кейсы клиентов</h2>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Фильтр проектов">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={activeFilter === filter ? styles.filterActive : ''}
                role="tab"
                aria-selected={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImage}>
                  <img
                    src={project.image}
                    alt={`Кейс: ${project.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/cases" aria-label={`Подробнее о кейсе ${project.title}`}>
                    Читать кейс →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.testimonials} ${styles.reveal} ${testimonialsVisible ? styles.show : ''}`}
        ref={testimonialsRef}
      >
        <div className={styles.container}>
          <div className={styles.testimonialsWrapper}>
            <h2>Что говорят наши клиенты</h2>
            <div className={styles.testimonial}>
              <p>{testimonials[currentTestimonial].quote}</p>
              <div>
                <strong>{testimonials[currentTestimonial].author}</strong>
                <span>{testimonials[currentTestimonial].role}</span>
              </div>
            </div>
            <div className={styles.testimonialControls} role="tablist" aria-label="Отзывы клиентов">
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.author}
                  onClick={() => setCurrentTestimonial(index)}
                  className={currentTestimonial === index ? styles.dotActive : ''}
                  aria-label={`Отзыв от ${testimonial.author}`}
                  aria-selected={currentTestimonial === index}
                  role="tab"
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>Команда</p>
            <h2>Эксперты, которые ведут трансформацию</h2>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard} tabIndex={0}>
                <div className={styles.teamImage}>
                  <img
                    src={member.image}
                    alt={`${member.name}, ${member.role}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section
        className={`${styles.faq} ${styles.reveal} ${faqVisible ? styles.show : ''}`}
        ref={faqRef}
      >
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>FAQ</p>
            <h2>Ответы на частые вопросы</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => {
              const [openQuestion, setOpenQuestion] = React.useState(false);
              return (
                <details
                  key={item.question}
                  open={openQuestion}
                  onClick={(event) => {
                    event.preventDefault();
                    setOpenQuestion((prev) => !prev);
                  }}
                >
                  <summary aria-expanded={openQuestion}>
                    <span>{index + 1}</span>
                    {item.question}
                  </summary>
                  <p>{item.answer}</p>
                </details>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className={styles.container}>
          <div className={styles.sectionHeading}>
            <p>Последние инсайты</p>
            <h2>Мы делимся практиками и стратегиями</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} aria-label={`Читать материал: ${post.title}`}>
                  Читать →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.container}>
          <div className={styles.ctaCard}>
            <div>
              <h2>Готовы обсудить цифровое развитие вашей компании?</h2>
              <p>
                Поговорим о стратегических целях, приоритетах и возможностях роста. Мы подготовим
                предварительную гипотезу трансформации и дорожную карту.
              </p>
            </div>
            <Link to="/contact" className={styles.ctaButton} aria-label="Запланировать встречу">
              Запланировать встречу
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;