import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Политика использования cookie — TechFlow Solutions</title>
      <meta
        name="description"
        content="Политика использования cookie TechFlow Solutions — информация об использовании файлов cookie, целях и настройках."
      />
    </Helmet>
    <section className={styles.page}>
      <div className={styles.container}>
        <h1>Политика использования cookie</h1>
        <p>Дата обновления: 1 марта 2024 года</p>
        <h2>1. Что такое cookie</h2>
        <p>
          Cookie — это небольшие файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают анализировать
          поведение пользователей и улучшать качество сервиса.
        </p>
        <h2>2. Какие cookie мы используем</h2>
        <ul>
          <li>Обязательные cookie — обеспечивают корректную работу Сайта.</li>
          <li>Аналитические cookie — помогают понимать, как пользователи взаимодействуют с Сайтом.</li>
          <li>Функциональные cookie — позволяют запоминать ваши предпочтения.</li>
        </ul>
        <h2>3. Управление cookie</h2>
        <p>
          Вы можете управлять cookie через настройки браузера. Ограничение использования cookie может повлиять на функциональность Сайта.
        </p>
        <h2>4. Обновления</h2>
        <p>
          Политика cookie может обновляться. Рекомендуем периодически посещать эту страницу.
        </p>
        <h2>5. Контакт</h2>
        <p>
          Если у вас есть вопросы о cookie, напишите нам на <a href="mailto:info@techflow-solutions.ru">info@techflow-solutions.ru</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;