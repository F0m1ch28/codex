import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const initialState = { name: '', company: '', email: '', phone: '', service: '', message: '' };
  const [formData, setFormData] = React.useState(initialState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = 'Введите ваше имя';
    if (!formData.company.trim()) newErrors.company = 'Укажите компанию';
    if (!formData.email.trim()) {
      newErrors.email = 'Введите email';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Некорректный email';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Укажите телефон';
    } else if (!/^\+?[0-9()\s-]{7,}$/i.test(formData.phone)) {
      newErrors.phone = 'Некорректный номер телефона';
    }
    if (!formData.service.trim()) newErrors.service = 'Выберите интересующую услугу';
    if (!formData.message.trim()) newErrors.message = 'Опишите ваш запрос';

    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты — TechFlow Solutions</title>
        <meta
          name="description"
          content="Свяжитесь с TechFlow Solutions: Москва, Пресненская набережная, 12, офис 345. Телефон +7 (495) 123-45-67, email info@techflow-solutions.ru."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.container}>
          <p className={styles.kicker}>Контакты</p>
          <h1>Начните трансформацию с консультации</h1>
          <p>
            Расскажите нам о вызовах вашего бизнеса — мы предложим стратегию действий и сформируем команду, готовую приступить к работе.
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.container}>
          <div className={styles.infoCard}>
            <h2>Как нас найти</h2>
            <p>
              Москва, Пресненская набережная, 12, офис 345<br />
              <a href="tel:+74951234567">+7 (495) 123-45-67</a><br />
              <a href="mailto:info@techflow-solutions.ru">info@techflow-solutions.ru</a>
            </p>
            <div className={styles.infoDetails}>
              <div>
                <strong>Режим работы</strong>
                <p>Пн-Пт: 09:00-18:00</p>
              </div>
              <div>
                <strong>Социальные сети</strong>
                <p>LinkedIn • Telegram • YouTube</p>
              </div>
            </div>
          </div>

          <form className={styles.form} onSubmit={handleSubmit} noValidate aria-live="polite">
            <h2>Оставьте заявку</h2>
            <div className={styles.field}>
              <label htmlFor="name">Имя*</label>
              <input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="company">Компания*</label>
              <input
                id="company"
                name="company"
                value={formData.company}
                onChange={handleChange}
                aria-invalid={Boolean(errors.company)}
                aria-describedby={errors.company ? 'company-error' : undefined}
              />
              {errors.company && (
                <span id="company-error" className={styles.error}>
                  {errors.company}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="email">Email*</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="phone">Телефон*</label>
              <input
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                aria-invalid={Boolean(errors.phone)}
                aria-describedby={errors.phone ? 'phone-error' : undefined}
              />
              {errors.phone && (
                <span id="phone-error" className={styles.error}>
                  {errors.phone}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="service">Интересующая услуга*</label>
              <select
                id="service"
                name="service"
                value={formData.service}
                onChange={handleChange}
                aria-invalid={Boolean(errors.service)}
                aria-describedby={errors.service ? 'service-error' : undefined}
              >
                <option value="">Выберите направление</option>
                <option value="Digital Discovery">Digital Discovery</option>
                <option value="Enterprise Architecture">Enterprise Architecture</option>
                <option value="Data & AI">Data & AI</option>
                <option value="Product Engineering">Product Engineering</option>
                <option value="CTO-as-a-Service">CTO-as-a-Service</option>
                <option value="Support">Support & Operations</option>
              </select>
              {errors.service && (
                <span id="service-error" className={styles.error}>
                  {errors.service}
                </span>
              )}
            </div>

            <div className={styles.field}>
              <label htmlFor="message">Описание задачи*</label>
              <textarea
                id="message"
                name="message"
                rows="4"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>

            <button type="submit">Отправить</button>
            {submitted && (
              <p className={styles.success} role="status">
                Спасибо! Мы свяжемся с вами в течение рабочего дня.
              </p>
            )}
          </form>
        </div>
      </section>
    </>
  );
};

export default Contact;