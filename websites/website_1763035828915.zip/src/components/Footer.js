import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.overlay} />
    <div className={styles.container}>
      <div className={styles.columnWide}>
        <h3>TechFlow Solutions</h3>
        <p>
          Мы сопровождаем цифровую трансформацию бизнеса: от стратегического планирования
          до внедрения масштабируемых технологических решений и поддержки.
        </p>
        <div className={styles.contact}>
          <a href="tel:+74951234567" aria-label="Позвонить в TechFlow Solutions">
            +7 (495) 123-45-67
          </a>
          <a href="mailto:info@techflow-solutions.ru" aria-label="Написать письмо">
            info@techflow-solutions.ru
          </a>
          <p>Москва, Пресненская набережная, 12, офис 345</p>
        </div>
      </div>
      <div className={styles.column}>
        <h4>Навигация</h4>
        <nav aria-label="Основные ссылки">
          <ul>
            <li>
              <NavLink to="/about">О компании</NavLink>
            </li>
            <li>
              <NavLink to="/services">Услуги</NavLink>
            </li>
            <li>
              <NavLink to="/cases">Кейсы</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Контакты</NavLink>
            </li>
          </ul>
        </nav>
      </div>
      <div className={styles.column}>
        <h4>Правовые документы</h4>
        <nav aria-label="Правовые ссылки">
          <ul>
            <li>
              <NavLink to="/terms">Условия использования</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Политика конфиденциальности</NavLink>
            </li>
            <li>
              <NavLink to="/cookie-policy">Политика использования cookie</NavLink>
            </li>
          </ul>
        </nav>
      </div>
      <div className={styles.column}>
        <h4>Будьте на связи</h4>
        <p>
          Подпишитесь на рассылку, чтобы получать свежие инсайты и практические рекомендации
          по цифровой трансформации.
        </p>
        <form className={styles.form} aria-label="Форма подписки">
          <label htmlFor="footer-email" className="sr-only">
            Электронная почта
          </label>
          <input
            id="footer-email"
            type="email"
            name="email"
            placeholder="Ваш email"
            required
          />
          <button type="submit">Подписаться</button>
        </form>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} TechFlow Solutions. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;