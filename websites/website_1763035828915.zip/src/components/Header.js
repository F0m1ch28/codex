import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Главная' },
  { to: '/about', label: 'О компании' },
  { to: '/services', label: 'Услуги' },
  { to: '/cases', label: 'Кейсы' },
  { to: '/contact', label: 'Контакты' }
];

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  React.useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <header className={styles.header} aria-label="Основная навигация">
      <div className={styles.inner}>
        <NavLink to="/" className={styles.brand} aria-label="TechFlow Solutions">
          <span className={styles.accent}>TechFlow</span> Solutions
        </NavLink>
        <button
          className={styles.menuToggle}
          onClick={() => setIsOpen((prev) => !prev)}
          aria-expanded={isOpen}
          aria-controls="primary-navigation"
          aria-label="Меню"
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${isOpen ? styles.open : ''}`}
        >
          <ul>
            {navLinks.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    isActive ? `${styles.link} ${styles.active}` : styles.link
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <NavLink to="/contact" className={styles.cta} aria-label="Связаться с нами">
            Связаться
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;