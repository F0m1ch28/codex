import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem('tfs_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    window.localStorage.setItem('tfs_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p>
        Мы используем cookie, чтобы улучшить пользовательский опыт и анализировать трафик.
        Подробнее в <Link to="/cookie-policy">политике cookie</Link>.
      </p>
      <button onClick={accept} className={styles.button} aria-label="Принять использование cookie">
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;