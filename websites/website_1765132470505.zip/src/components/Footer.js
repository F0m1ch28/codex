import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="container footer__grid">
        <div className="footer__column">
          <h3 className="footer__title">Професійне дресерування собак</h3>
          <p>
            Комплексні програми тренувань для німецьких вівчарок у Варшаві та Кракові. Допомагаємо собакам
            розкрити їхній потенціал, а власникам — стати впевненими наставниками.
          </p>
          <div className="footer__locations">
            <span>📍 Варшава, Польща</span>
            <span>📍 Краків, Польща</span>
          </div>
        </div>
        <div className="footer__column">
          <h4>Швидкі посилання</h4>
          <ul className="footer__links">
            <li><NavLink to="/">Головна</NavLink></li>
            <li><NavLink to="/pro-nas">Про нас</NavLink></li>
            <li><NavLink to="/posluhy">Послуги</NavLink></li>
            <li><NavLink to="/nash-pidkhid">Наш підхід</NavLink></li>
            <li><NavLink to="/kontakty">Контакти</NavLink></li>
          </ul>
        </div>
        <div className="footer__column">
          <h4>Юридична інформація</h4>
          <ul className="footer__links">
            <li><NavLink to="/umovy-vykorystannia">Умови використання</NavLink></li>
            <li><NavLink to="/polityka-konfidentsiinosti">Політика конфіденційності</NavLink></li>
            <li><NavLink to="/polityka-cookie">Політика щодо файлів cookie</NavLink></li>
          </ul>
        </div>
        <div className="footer__column">
          <h4>Контакти</h4>
          <ul className="footer__contacts">
            <li><a href="tel:+48xxxxxxxxx">+48 XXX XXX XXX</a></li>
            <li><a href="mailto:info@dresyrovannya.pl">info@dresyrovannya.pl</a></li>
            <li>Варшава та Краків, Польща</li>
          </ul>
          <div className="footer__socials" aria-label="Соціальні мережі">
            <a href="#" aria-label="Facebook дресерування">Facebook</a>
            <a href="#" aria-label="Instagram дресерування">Instagram</a>
            <a href="#" aria-label="YouTube дресерування">YouTube</a>
          </div>
        </div>
      </div>
      <div className="footer__bottom">
        <p>© {year} Професійне дресерування собак. Усі права захищено.</p>
      </div>
    </footer>
  );
};

export default Footer;