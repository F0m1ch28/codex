import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const storageKey = 'dogTrainingCookieConsent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const consent = window.localStorage.getItem(storageKey);
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(storageKey, 'accepted');
    }
    setIsVisible(false);
  };

  const handleRemindLater = () => {
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Сповіщення про використання cookie">
      <div className="container cookie-banner__inner">
        <p>
          Ми використовуємо файли cookie, щоб удосконалити роботу сайту та адаптувати контент для власників німецьких вівчарок.
          Продовжуючи перегляд, ви погоджуєтеся з нашою{' '}
          <Link to="/polityka-cookie">політикою використання cookie</Link>.
        </p>
        <div className="cookie-banner__actions">
          <button type="button" className="btn btn--primary" onClick={handleAccept}>
            Прийняти
          </button>
          <button type="button" className="btn btn--ghost" onClick={handleRemindLater}>
            Налаштувати пізніше
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;