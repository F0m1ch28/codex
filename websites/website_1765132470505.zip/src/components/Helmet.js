import { useEffect } from 'react';

const ensureMetaTag = (selector, attribute, value) => {
  let element = document.querySelector(selector);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attribute, value);
    document.head.appendChild(element);
  }
  return element;
};

const Helmet = ({ title, description }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
      const ogTitle = ensureMetaTag('meta[property="og:title"]', 'property', 'og:title');
      ogTitle.setAttribute('content', title);
      const twitterTitle = ensureMetaTag('meta[name="twitter:title"]', 'name', 'twitter:title');
      twitterTitle.setAttribute('content', title);
    }
    if (description) {
      const descriptionTag = ensureMetaTag('meta[name="description"]', 'name', 'description');
      descriptionTag.setAttribute('content', description);

      const ogDescription = ensureMetaTag('meta[property="og:description"]', 'property', 'og:description');
      ogDescription.setAttribute('content', description);

      const twitterDescription = ensureMetaTag('meta[name="twitter:description"]', 'name', 'twitter:description');
      twitterDescription.setAttribute('content', description);
    }
    const ogType = ensureMetaTag('meta[property="og:type"]', 'property', 'og:type');
    ogType.setAttribute('content', 'website');

    const twitterCard = ensureMetaTag('meta[name="twitter:card"]', 'name', 'twitter:card');
    twitterCard.setAttribute('content', 'summary_large_image');
  }, [title, description]);

  return null;
};

export default Helmet;