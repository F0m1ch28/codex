import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const navLinks = [
  { to: '/', label: 'Головна' },
  { to: '/pro-nas', label: 'Про нас' },
  { to: '/posluhy', label: 'Послуги' },
  { to: '/nash-pidkhid', label: 'Наш підхід' },
  { to: '/kontakty', label: 'Контакти' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const navLinkClass = ({ isActive }) =>
    isActive ? 'nav-link nav-link--active' : 'nav-link';

  return (
    <header className={`site-header ${isMenuOpen ? 'is-open' : ''}`}>
      <div className="container header__inner">
        <NavLink to="/" className="header__logo" onClick={closeMenu}>
          <span className="header__logo-mark">🐾</span>
          <span className="header__logo-text">Професійне дресерування собак</span>
        </NavLink>
        <button
          className={`header__toggle ${isMenuOpen ? 'is-active' : ''}`}
          type="button"
          aria-label="Перемикання меню"
          aria-expanded={isMenuOpen}
          onClick={handleToggle}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`header__nav ${isMenuOpen ? 'is-open' : ''}`} aria-label="Головне меню">
          <ul>
            {navLinks.map((link) => (
              <li key={link.to}>
                <NavLink to={link.to} className={navLinkClass} onClick={closeMenu} end={link.to === '/'}>
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <NavLink to="/kontakty" className="btn btn--accent header__cta" onClick={closeMenu}>
            Записатися
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;