import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Outlet, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Methodology from './pages/Methodology';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const Layout = () => (
  <>
    <Header />
    <main className="main-content" role="main">
      <Outlet />
    </main>
    <Footer />
  </>
);

const RouteChangeHandler = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [location.pathname]);

  return null;
};

const App = () => (
  <Router>
    <RouteChangeHandler />
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/pro-nas" element={<About />} />
        <Route path="/posluhy" element={<Services />} />
        <Route path="/nash-pidkhid" element={<Methodology />} />
        <Route path="/kontakty" element={<Contact />} />
        <Route path="/umovy-vykorystannia" element={<Terms />} />
        <Route path="/polityka-konfidentsiinosti" element={<Privacy />} />
        <Route path="/polityka-cookie" element={<CookiePolicy />} />
        <Route path="*" element={<Home />} />
      </Route>
    </Routes>
    <CookieBanner />
    <ScrollToTop />
  </Router>
);

export default App;