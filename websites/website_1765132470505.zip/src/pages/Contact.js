import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Helmet from '../components/Helmet';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus({ type: 'error', message: 'Заповніть, будь ласка, обов’язкові поля.' });
      return;
    }
    setStatus({ type: 'success', message: 'Дякуємо! Ми надішлемо відповідь найближчим часом.' });
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  return (
    <>
      <Helmet
        title="Контакти | Професійне дресерування собак"
        description="Зв’яжіться з кінологами у Варшаві та Кракові. Запис на консультацію, адреси локацій та контактна форма."
      />
      <section className="page-hero">
        <div className="container page-hero__content">
          <span className="section-label">Контакти</span>
          <h1>Звʼяжіться з нашою командою</h1>
          <p>
            Ми відповімо на ваші питання, допоможемо підібрати оптимальний формат тренувань і домовимося про першу
            зустріч у Варшаві або Кракові.
          </p>
        </div>
        <img
          src="https://picsum.photos/1200/730?random=347"
          alt="Консультація кінолога з власником собаки"
          className="page-hero__image"
          loading="lazy"
        />
      </section>

      <section className="page-section">
        <div className="container contact__grid">
          <div className="contact__info">
            <h2>Контактні дані</h2>
            <ul>
              <li><strong>Телефон:</strong> <a href="tel:+48xxxxxxxxx">+48 XXX XXX XXX</a></li>
              <li><strong>Email:</strong> <a href="mailto:info@dresyrovannya.pl">info@dresyrovannya.pl</a></li>
              <li><strong>Локації:</strong> Варшава та Краків, Польща</li>
              <li><strong>Години роботи:</strong> Пн–Сб 8:00–20:00</li>
            </ul>
            <p>
              Ми проводимо виїзні заняття, онлайн-консультації та приймаємо клієнтів на наших тренувальних майданчиках.
              Оберіть зручний спосіб звʼязку, а ми підкажемо наступні кроки.
            </p>
          </div>
          <form className="contact__form" onSubmit={handleSubmit} noValidate>
            <h2>Залишити заявку</h2>
            <label className="form-field">
              <span>Ім’я*</span>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Ваше ім’я"
              />
            </label>
            <label className="form-field">
              <span>Email*</span>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="email@example.com"
              />
            </label>
            <label className="form-field">
              <span>Телефон</span>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+48 XXX XXX XXX"
              />
            </label>
            <label className="form-field">
              <span>Повідомлення*</span>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows="5"
                placeholder="Опишіть ваш запит та поведінку собаки"
              />
            </label>
            <button type="submit" className="btn btn--primary">
              Надіслати
            </button>
            {status.message && (
              <p className={`form-status ${status.type}`} role="status" aria-live="polite">
                {status.message}
              </p>
            )}
            <span className="form-disclaimer">
              Надсилаючи форму, ви погоджуєтеся з нашою{' '}
              <Link to="/polityka-konfidentsiinosti">політикою конфіденційності</Link>.
            </span>
          </form>
        </div>
      </section>

      <section className="page-section page-section--alt">
        <div className="container">
          <h2>Наші локації</h2>
          <div className="map-grid">
            <article>
              <h3>Варшава</h3>
              <p>Майданчик поруч з Park Sielecki, зручний виїзд до центру міста.</p>
              <div className="map-embed">
                <iframe
                  title="Майданчик Варшава"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2443.2178723877743!2d21.04001637682279!3d52.20682107198613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471eca9c3e0841f7%3A0x2728dc7d8dc0a693!2sPark%20Sielecki!5e0!3m2!1suk!2spl!4v1712840000000!5m2!1suk!2spl"
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </article>
            <article>
              <h3>Краків</h3>
              <p>Тренуємося поблизу Zakrzówek та у партнерських клубах Подгуже.</p>
              <div className="map-embed">
                <iframe
                  title="Майданчик Краків"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2560.6825082201475!2d19.919230476707522!3d50.03839197152031!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47165bfa42f2f7a7%3A0x7af94f3750793b5f!2sZakrz%C3%B3wek!5e0!3m2!1suk!2spl!4v1712840001000!5m2!1suk!2spl"
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;