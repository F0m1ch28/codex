import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Helmet from '../components/Helmet';

const statsData = [
  {
    value: 12,
    suffix: '+',
    title: 'років тренерського досвіду',
    description: 'Практика у роботі з німецькими вівчарками та сучасними методиками дресирування.'
  },
  {
    value: 450,
    suffix: '+',
    title: 'вихованих собак',
    description: 'Від щенят до дорослих охоронців — кожна програма адаптована під характер собаки.'
  },
  {
    value: 96,
    suffix: '%',
    title: 'клієнтів рекомендують нас',
    description: 'Власники відзначають дисципліну, слухняність та емоційний зв’язок із собакою.'
  },
  {
    value: 2,
    suffix: '',
    title: 'міста у Польщі',
    description: 'Працюємо у Варшаві та Кракові, проводимо виїзні та стаціонарні заняття.'
  }
];

const services = [
  {
    title: 'Базове навчання слухняності',
    description: 'Закладаємо фундамент послуху: команди, соціалізація, робота з повідком, розвиток довіри до власника.'
  },
  {
    title: 'Корекція поведінки',
    description: 'Працюємо з надмірною збудженістю, охоронним інстинктом, страхами та некерованою реакцією на подразники.'
  },
  {
    title: 'Підготовка собаки-охоронця',
    description: 'Комбінуємо послух, силу та контроль, формуємо надійного захисника дому та сім’ї.'
  },
  {
    title: 'Індивідуальні сесії',
    description: 'Плануємо тренування під ваш ритм життя, приділяємо увагу родинним правилам та побутовому етикету собаки.'
  }
];

const approachPoints = [
  'Аналіз генетичних рис та темпераменту німецької вівчарки',
  'Позитивне підкріплення і мотиваційні ігри замість примусу',
  'Програма, що адаптується до віку, стану здоров’я та цілей сім’ї',
  'Прозора комунікація та домашні завдання для власника',
  'Співпраця з ветеринарами та кінологами Варшави й Кракова'
];

const processSteps = [
  {
    title: 'Діагностика та консультація',
    description: 'Перша зустріч у Варшаві чи Кракові, оцінка поведінки та постановка тренувальних цілей.'
  },
  {
    title: 'Проєкт програми',
    description: 'Створюємо індивідуальний план, підбираємо інвентар, графік занять, вправи для дому.'
  },
  {
    title: 'Інтенсивні тренування',
    description: 'Проводимо сесії на майданчику, вдома та у публічних просторах, закріплюємо контроль над інстинктами.'
  },
  {
    title: 'Оцінка прогресу',
    description: 'Регулярні звіти, відеофідбек, корекція методів залежно від реакції собаки та родини.'
  },
  {
    title: 'Підтримка та супровід',
    description: 'Після завершення курсу залишаємося на звʼязку, допомагаємо з новими викликами та іспитами.'
  }
];

const testimonials = [
  {
    quote: 'Після трьох місяців тренувань наша вівчарка перестала кидатися на велосипедистів і спокійно зустрічає гостей. Кінолог показав, як будувати взаємоповагу без крику.',
    author: 'Олександр і Лада, Варшава',
    project: 'Корекція поведінки та послух'
  },
  {
    quote: 'Шукали тренера, який розуміє робочі лінії вівчарок. Команда підготувала Арча до спортивних змагань, і ми взяли приз у Кракові!',
    author: 'Аня, клуб IGP Краків',
    project: 'Спортивна підготовка'
  },
  {
    quote: 'Індивідуальні заняття допомогли нам адаптувати щеня в квартирі. Вправи прості, але дають відчутний результат вже з першого тижня.',
    author: 'Марек та Агата, Варшава',
    project: 'Базовий курс для щенят'
  }
];

const teamMembers = [
  {
    name: 'Ірина Ковальська',
    role: 'Головна кінологиня, спеціалістка з робочих ліній GSD',
    bio: 'Сертифікована тренерка IGP з 2010 року. Вивчала поведінку собак у Берліні, працювала з поліцейськими кінологами.',
    image: 'https://picsum.photos/400/400?random=331'
  },
  {
    name: 'Павел Новак',
    role: 'Тренер-комунікатор, експерт з поведінкової терапії',
    bio: 'Використовує науковий підхід до корекції стресових реакцій, проводить групові заняття у Варшаві.',
    image: 'https://picsum.photos/400/400?random=332'
  },
  {
    name: 'Олена Гнатюк',
    role: 'Консультантка з підготовки собак-охоронців',
    bio: 'Розробляє програми захисту для сімейних та корпоративних клієнтів, контролює безпеку тренувань.',
    image: 'https://picsum.photos/400/400?random=333'
  }
];

const projectCategories = ['Усі', 'Сімейні програми', 'Охоронна підготовка', 'Спортивні результати'];

const projects = [
  {
    title: 'Соціалізація Рекса в міському середовищі',
    category: 'Сімейні програми',
    description: 'Поступова адаптація до шуму центру Варшави, навчання спокійній ходьбі поруч та відпрацювання команди "до мене".',
    image: 'https://picsum.photos/800/600?random=334'
  },
  {
    title: 'Комплекс охоронних навичок для Нори',
    category: 'Охоронна підготовка',
    description: 'Збалансування інстинкту захисту з точним контролем, робота у форматі укусних вправ та охорона периметру.',
    image: 'https://picsum.photos/800/600?random=335'
  },
  {
    title: 'Спортивний дебют Бена на змаганнях IGP',
    category: 'Спортивні результати',
    description: 'Тренування витривалості, концентрації та відточення елементів слідування, що принесло перший кубок.',
    image: 'https://picsum.photos/800/600?random=336'
  },
  {
    title: 'Програма підтримки для літньої вівчарки',
    category: 'Сімейні програми',
    description: 'Мʼякі вправи на підтримку тонусу, робота над впевненістю та відмовою від тривожного гавкоту.',
    image: 'https://picsum.photos/800/600?random=337'
  }
];

const faqs = [
  {
    question: 'Скільки триває базовий курс для німецької вівчарки?',
    answer: 'Перший базовий курс зазвичай охоплює 10–12 занять протягом 8–10 тижнів. Реальна тривалість залежить від віку собаки, попереднього досвіду та ваших цілей.'
  },
  {
    question: 'Чи проводите ви тренування англійською або польською мовою?',
    answer: 'Так, наша команда володіє українською, польською та англійською мовами. Ми адаптуємо команди та методичні матеріали під мову, яка буде комфортною для власників.'
  },
  {
    question: 'Чи можлива робота з собакою, яка має історію агресії?',
    answer: 'Ми проводимо попередню оцінку ризиків і, за умови безпечних умов, беремося за складні кейси. У таких випадках тренування проходять у закритому форматі та з додатковим обладнанням.'
  },
  {
    question: 'Ви працюєте лише з німецькими вівчарками?',
    answer: 'Наша основна експертиза — саме вівчарки. Проте ми також консультуємо власників споріднених порід, якщо їхні запити близькі до наших програм.'
  }
];

const blogPosts = [
  {
    title: '5 вправ, які обожнюють щенята німецької вівчарки',
    excerpt: 'Поділилися іграми, що розвивають самоконтроль, баланс та слухняність вже з 10 тижнів.',
    date: '12 квітня 2024',
    image: 'https://picsum.photos/700/500?random=338'
  },
  {
    title: 'Як підготуватися до візиту кінолога додому',
    excerpt: 'Чек-лист для родини: від підбору ласощів до налаштування безпечного простору на перше заняття.',
    date: '29 березня 2024',
    image: 'https://picsum.photos/700/500?random=339'
  },
  {
    title: 'Порівнюємо методи корекції страху перед гучними звуками',
    excerpt: 'Розбираємо сенсорні вправи та роботу з дихальними техніками для власників.',
    date: '10 березня 2024',
    image: 'https://picsum.photos/700/500?random=340'
  }
];

const cityHighlights = [
  {
    city: 'Варшава',
    description: 'Тренувальний майданчик у районі Мокотув, виїзд до домівок клієнтів та сесії в парках Łazienki й Pole Mokotowskie.',
    image: 'https://picsum.photos/600/450?random=341'
  },
  {
    city: 'Краків',
    description: 'Заняття на базі в Подгуже, співпраця з кінологічними клубами та історичними локаціями для соціалізації.',
    image: 'https://picsum.photos/600/450?random=342'
  }
];

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('Усі');
  const [openFaq, setOpenFaq] = useState(null);
  const [ctaForm, setCtaForm] = useState({ name: '', email: '', message: '' });
  const [ctaStatus, setCtaStatus] = useState({ type: '', message: '' });

  useEffect(() => {
    const increments = statsData.map((stat) => Math.max(1, Math.floor(stat.value / 40)));
    const interval = setInterval(() => {
      setAnimatedStats((prev) => {
        let completed = true;
        const updated = prev.map((value, index) => {
          const target = statsData[index].value;
          if (value >= target) {
            return target;
          }
          completed = false;
          const next = value + increments[index];
          return next >= target ? target : next;
        });
        if (completed) {
          clearInterval(interval);
        }
        return updated;
      });
    }, 50);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeCategory === 'Усі'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  const handleCtaChange = (event) => {
    const { name, value } = event.target;
    setCtaForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleCtaSubmit = (event) => {
    event.preventDefault();
    if (!ctaForm.name.trim() || !ctaForm.email.trim() || !ctaForm.message.trim()) {
      setCtaStatus({ type: 'error', message: 'Будь ласка, заповніть усі поля форми.' });
      return;
    }
    setCtaStatus({
      type: 'success',
      message: 'Дякуємо! Ми зв’яжемося з вами протягом одного робочого дня.'
    });
    setCtaForm({ name: '', email: '', message: '' });
  };

  const currentTestimonial = testimonials[activeTestimonial];

  return (
    <>
      <Helmet
        title="Професійне дресирування німецьких вівчарок | Варшава та Краків"
        description="Індивідуальні програми дресирування німецьких вівчарок у Варшаві та Кракові. Базові навички, охоронна підготовка, корекція поведінки та підтримка власників."
      />
      <section className="hero">
        <div className="container hero__grid">
          <div className="hero__content">
            <p className="hero__eyebrow">Варшава • Краків • Німецькі вівчарки</p>
            <h1>Професійне дресерування німецьких вівчарок</h1>
            <p className="hero__subtitle">
              Допомагаємо собакам реалізувати потенціал, а власникам — відчути впевненість у кожній прогулянці.
              Від базового послуху до силової підготовки — з турботою та науковим підходом.
            </p>
            <div className="hero__actions">
              <Link to="/kontakty" className="btn btn--primary">
                Записатися на консультацію
              </Link>
              <Link to="/nash-pidkhid" className="btn btn--ghost">
                Дізнатися про методики
              </Link>
            </div>
          </div>
          <div className="hero__media">
            <img
              src="https://picsum.photos/1280/960?random=330"
              alt="Тренування німецької вівчарки з кінологом"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="stats" aria-label="Ключові досягнення">
        <div className="container stats__grid">
          {statsData.map((stat, index) => (
            <article className="stat-card" key={stat.title}>
              <div className="stat-card__value">
                {animatedStats[index]}
                {animatedStats[index] === stat.value ? stat.suffix : ''}
              </div>
              <h3>{stat.title}</h3>
              <p>{stat.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mission" id="mission">
        <div className="container mission__grid">
          <div className="mission__text">
            <span className="section-label">Наша місія</span>
            <h2>Створюємо партнерство між собакою та людиною</h2>
            <p>
              Працюємо з німецькими вівчарками вже понад десятиріччя й знаємо, наскільки важливо поєднати їхній
              драйв та здатність до навчання з емоційною стабільністю. Ми допомагаємо власникам побудувати систему,
              де собака розуміє правила, а людина — вміє підтримати та мотивувати вихованця.
            </p>
            <p>
              Кожна програма — це діалог. Ми слухаємо, що турбує родину, враховуємо особливості міського життя у Польщі,
              і разом виходимо на рівень, коли гуляти містом чи працювати на майданчику стає чистим задоволенням.
            </p>
          </div>
          <div className="mission__media">
            <img
              src="https://picsum.photos/1000/700?random=343"
              alt="Кінолог працює з німецькою вівчаркою на майданчику у Кракові"
              loading="lazy"
            />
            <div className="mission__badge">
              <strong>Відданість професії</strong>
              <p>Супроводжуємо клієнтів до стабільних результатів незалежно від рівня старту.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="services-overview" id="services">
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Послуги</span>
            <h2>Повний цикл навчання для слухняного та врівноваженого пса</h2>
            <p>
              Вибудовуємо шлях від першого знайомства зі шлеєю до охорони території, застосовуючи лише гуманні методи.
            </p>
          </div>
          <div className="services-overview__grid">
            {services.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="service-card__icon" aria-hidden="true">★</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="approach" id="approach">
        <div className="container approach__grid">
          <div className="approach__intro">
            <span className="section-label">Чому ми</span>
            <h2>Наш підхід: глибоке розуміння породи та сучасна наука</h2>
            <p>
              Ми опираємося на кінологічну науку, зберігаючи індивідуальний стиль кожної вівчарки. Завдяки цьому
              господарі отримують керовану, але щасливу собаку, яка довіряє своїй родині.
            </p>
          </div>
          <ul className="approach__list">
            {approachPoints.map((point) => (
              <li key={point}>{point}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="geography" id="geography">
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Географія обслуговування</span>
            <h2>Працюємо в серці Польщі</h2>
            <p>Наша команда проводить тренування у Варшаві та Кракові, а також організовує виїзди у передмістя.</p>
          </div>
          <div className="geography__grid">
            {cityHighlights.map((city) => (
              <article className="city-card" key={city.city}>
                <img src={city.image} alt={`Локація тренувань у місті ${city.city}`} loading="lazy" />
                <div className="city-card__content">
                  <h3>{city.city}</h3>
                  <p>{city.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process" id="process">
        <div className="container process__content">
          <div className="section-heading">
            <span className="section-label">Наш процес</span>
            <h2>П’ять кроків до слухняного та врівноваженого компаньйона</h2>
            <p>
              Від першої діагностики до підтримки після курсу — ми супроводжуємо вас на кожному етапі спільного шляху.
            </p>
          </div>
          <div className="process__timeline">
            {processSteps.map((step, index) => (
              <article className="process-step" key={step.title}>
                <div className="process-step__number">{index + 1}</div>
                <div className="process-step__body">
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials" aria-label="Відгуки клієнтів">
        <div className="container testimonials__inner">
          <div className="testimonials__content">
            <span className="section-label">Відгуки</span>
            <h2>Результати, які говорять самі за себе</h2>
            <p>
              Ми знаємо, що довіра народжується через реальні історії. Розповіді наших клієнтів підтверджують:
              послідовність, терпіння та професійні методики приносять стабільні зміни.
            </p>
            <div className="testimonials__controls">
              <button
                type="button"
                className="btn btn--ghost"
                onClick={() =>
                  setActiveTestimonial((prev) =>
                    prev === 0 ? testimonials.length - 1 : prev - 1
                  )
                }
                aria-label="Попередній відгук"
              >
                Попередній
              </button>
              <button
                type="button"
                className="btn btn--ghost"
                onClick={() =>
                  setActiveTestimonial((prev) =>
                    prev === testimonials.length - 1 ? 0 : prev + 1
                  )
                }
                aria-label="Наступний відгук"
              >
                Наступний
              </button>
            </div>
          </div>
          <div className="testimonial-card" role="group" aria-roledescription="слайд">
            <p className="testimonial-card__quote">“{currentTestimonial.quote}”</p>
            <div className="testimonial-card__meta">
              <span className="testimonial-card__author">{currentTestimonial.author}</span>
              <span className="testimonial-card__project">{currentTestimonial.project}</span>
            </div>
            <div className="testimonial-card__dots" role="tablist" aria-label="Список відгуків">
              {testimonials.map((_, index) => (
                <button
                  key={`dot-${index}`}
                  type="button"
                  className={`testimonial-dot ${index === activeTestimonial ? 'is-active' : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Показати відгук №${index + 1}`}
                  aria-selected={index === activeTestimonial}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team" id="team">
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Команда</span>
            <h2>Кінологи, які закохані у породу</h2>
            <p>
              Ми об’єднали фахівців із поведінкової терапії, спортивного дресирування та охоронної підготовки,
              щоб покрити всі запити власників.
            </p>
          </div>
          <div className="team__grid">
            {teamMembers.map((member) => (
              <article className="team-card" key={member.name}>
                <img src={member.image} alt={`${member.name} - ${member.role}`} loading="lazy" />
                <div className="team-card__body">
                  <h3>{member.name}</h3>
                  <span className="team-card__role">{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Кейси</span>
            <h2>Вражаючі історії наших підопічних</h2>
            <p>
              Кожен проєкт — це командна робота кінолога, собаки та власника. Перегляньте деякі з останніх успіхів.
            </p>
          </div>
          <div className="projects__filters" role="tablist" aria-label="Фільтр кейсів">
            {projectCategories.map((category) => (
              <button
                key={category}
                type="button"
                className={`filter-chip ${activeCategory === category ? 'is-active' : ''}`}
                onClick={() => setActiveCategory(category)}
                aria-pressed={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects__grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className="project-card__body">
                  <span className="project-card__label">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container faq__grid">
          <div className="faq__intro">
            <span className="section-label">FAQ</span>
            <h2>Часті питання про дресирування вівчарок</h2>
            <p>
              Якщо ви не знайшли відповіді — зв’яжіться з нами, і ми підготуємо індивідуальну консультацію для вас.
            </p>
            <Link to="/kontakty" className="btn btn--accent">
              Поставити запитання
            </Link>
          </div>
          <div className="faq__items">
            {faqs.map((faq, index) => (
              <article className={`faq-item ${openFaq === index ? 'is-open' : ''}`} key={faq.question}>
                <button
                  type="button"
                  className="faq-item__question"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={openFaq === index}
                >
                  {faq.question}
                  <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
                </button>
                <div className="faq-item__answer">
                  <p>{faq.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="blog" id="blog">
        <div className="container">
          <div className="section-heading">
            <span className="section-label">Блог</span>
            <h2>Останні матеріали для відповідальних власників</h2>
            <p>
              Регулярно ділимося практичними порадами, відеоматеріалами та чек-листами для щоденних тренувань.
            </p>
          </div>
          <div className="blog__grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className="blog-card__body">
                  <span className="blog-card__date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <span className="blog-card__link">Читати далі</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta" id="cta">
        <div className="container cta__grid">
          <div className="cta__content">
            <span className="section-label">Готові почати?</span>
            <h2>Запишіться на безоплатну консультацію</h2>
            <p>
              Розкажіть нам про свою німецьку вівчарку та цілі, яких ви прагнете досягти. Ми підготуємо персональний
              план і запропонуємо перші кроки.
            </p>
            <ul className="cta__list">
              <li>Онлайн-дзвінок або зустріч на майданчику у Варшаві/Кракові</li>
              <li>Детальне пояснення методик та очікуваних результатів</li>
              <li>Поради з підготовки до першого заняття</li>
            </ul>
          </div>
          <form className="cta__form" onSubmit={handleCtaSubmit} noValidate>
            <label className="form-field">
              <span>Ваше ім’я</span>
              <input
                type="text"
                name="name"
                value={ctaForm.name}
                onChange={handleCtaChange}
                placeholder="Як до вас звертатися?"
              />
            </label>
            <label className="form-field">
              <span>Email</span>
              <input
                type="email"
                name="email"
                value={ctaForm.email}
                onChange={handleCtaChange}
                placeholder="example@email.com"
              />
            </label>
            <label className="form-field">
              <span>Повідомлення</span>
              <textarea
                name="message"
                value={ctaForm.message}
                onChange={handleCtaChange}
                placeholder="Опишіть свою собаку, вік, поведінкові особливості та ваші цілі."
                rows="4"
              />
            </label>
            <button type="submit" className="btn btn--primary">
              Надіслати запит
            </button>
            {ctaStatus.message && (
              <p className={`form-status ${ctaStatus.type}`} role="status" aria-live="polite">
                {ctaStatus.message}
              </p>
            )}
            <span className="form-disclaimer">
              Відправляючи форму, ви погоджуєтеся з нашою{' '}
              <Link to="/polityka-konfidentsiinosti">політикою конфіденційності</Link>.
            </span>
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;