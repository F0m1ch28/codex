const navToggle = document.querySelector(".nav-toggle");
const primaryNav = document.querySelector(".primary-nav");
if (navToggle && primaryNav) {
  navToggle.addEventListener("click", () => {
    navToggle.classList.toggle("is-active");
    primaryNav.classList.toggle("is-open");
  });
}

const cookieBanner = document.querySelector(".cookie-banner");
const acceptBtn = document.querySelector(".cookie-accept");
const declineBtn = document.querySelector(".cookie-decline");

const COOKIE_KEY = "velvetNoelCookieConsent";

function hideCookieBanner() {
  if (cookieBanner) {
    cookieBanner.classList.remove("is-active");
  }
}

function showCookieBanner() {
  if (cookieBanner) {
    cookieBanner.classList.add("is-active");
  }
}

if (cookieBanner) {
  const storedConsent = localStorage.getItem(COOKIE_KEY);
  if (!storedConsent) {
    showCookieBanner();
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "accepted");
      hideCookieBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      localStorage.setItem(COOKIE_KEY, "declined");
      hideCookieBanner();
    });
  }
}

const themeSelect = document.getElementById("themeSelect");
const ribbonSelect = document.getElementById("ribbonSelect");
const messageInput = document.getElementById("messageInput");
const noteInput = document.getElementById("noteInput");
const palettePicker = document.getElementById("palettePicker");
const sizeSelect = document.getElementById("sizeSelect");

const giftBoxDisplay = document.getElementById("giftBoxDisplay");
const giftRibbon = document.getElementById("giftRibbon");
const giftMessage = document.getElementById("giftMessage");
const giftNote = document.getElementById("giftNote");
const tagPreview = document.getElementById("tagPreview");
const sizeLabel = document.getElementById("sizeLabel");

const themeGradients = {
  crimson: "linear-gradient(135deg, #c21832 0%, #f1c40f 100%)",
  emerald: "linear-gradient(135deg, #0f5132 0%, #d1f0d3 100%)",
  midnight: "linear-gradient(135deg, #111827 0%, #6d28d9 100%)",
  blush: "linear-gradient(135deg, #f7a6b5 0%, #ffe4ec 100%)"
};

if (giftBoxDisplay) {
  function updateGiftPreview() {
    const themeValue = themeSelect ? themeSelect.value : "crimson";
    const ribbonValue = ribbonSelect ? ribbonSelect.value : "#f1c40f";
    const messageValue = messageInput && messageInput.value.trim().length ? messageInput.value.trim() : "Merry & Bright";
    const noteValue = noteInput && noteInput.value.trim().length ? noteInput.value.trim() : "A winter wish wrapped in velvet light.";
    const sizeValue = sizeSelect ? sizeSelect.value : "classic";

    giftBoxDisplay.style.background = themeGradients[themeValue] || themeGradients.crimson;
    if (giftRibbon) {
      giftRibbon.style.background = ribbonValue;
      giftRibbon.style.boxShadow = `0 6px 18px ${ribbonValue}33`;
    }
    if (giftMessage) {
      giftMessage.textContent = messageValue;
    }
    if (giftNote) {
      giftNote.textContent = noteValue;
    }
    if (sizeLabel) {
      const sizeText = sizeSelect ? sizeSelect.options[sizeSelect.selectedIndex].text : "Classic (30cm)";
      sizeLabel.textContent = sizeText;
    }
  }

  updateGiftPreview();

  if (themeSelect) {
    themeSelect.addEventListener("change", updateGiftPreview);
  }
  if (ribbonSelect) {
    ribbonSelect.addEventListener("change", updateGiftPreview);
  }
  if (messageInput) {
    messageInput.addEventListener("input", updateGiftPreview);
  }
  if (noteInput) {
    noteInput.addEventListener("input", updateGiftPreview);
  }
  if (sizeSelect) {
    sizeSelect.addEventListener("change", updateGiftPreview);
  }
  if (palettePicker && tagPreview) {
    const paletteButtons = palettePicker.querySelectorAll("button");
    paletteButtons.forEach((button) => {
      button.addEventListener("click", () => {
        paletteButtons.forEach((btn) => btn.classList.remove("is-selected"));
        button.classList.add("is-selected");
        const color = button.getAttribute("data-color") || "#ffffff";
        tagPreview.style.background = color;
        tagPreview.style.color = "#1e1b1d";
      });
    });
    const firstButton = paletteButtons[0];
    if (firstButton) {
      firstButton.classList.add("is-selected");
      tagPreview.style.background = firstButton.getAttribute("data-color");
    }
  }
}

const occasionSelect = document.getElementById("occasionSelect");
const occasionResult = document.getElementById("occasionResult");

if (occasionSelect && occasionResult) {
  occasionSelect.addEventListener("change", () => {
    const value = occasionSelect.value;
    const cards = occasionResult.querySelectorAll(".occasion-card");
    cards.forEach((card) => {
      const isMatch = card.getAttribute("data-occasion") === value;
      card.hidden = !isMatch;
    });
  });
}

const faqList = document.getElementById("faqList");
if (faqList) {
  const faqButtons = faqList.querySelectorAll(".faq-item button");
  faqButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const parent = button.closest(".faq-item");
      if (parent) {
        parent.classList.toggle("is-open");
      }
    });
  });
}