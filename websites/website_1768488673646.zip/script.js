document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.getElementById('primary-navigation');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navToggle.classList.toggle('is-active');
            primaryNav.classList.toggle('is-open');
        });

        primaryNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 1024) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navToggle.classList.remove('is-active');
                    primaryNav.classList.remove('is-open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const cookieStatus = localStorage.getItem('gc-cookie-consent');
    if (cookieBanner && cookieStatus) {
        cookieBanner.classList.add('is-hidden');
    }

    if (cookieBanner) {
        const cookieChoices = cookieBanner.querySelectorAll('.cookie-choice');
        cookieChoices.forEach(function (choice) {
            choice.addEventListener('click', function (event) {
                event.preventDefault();
                const selection = choice.dataset.choice || 'pending';
                localStorage.setItem('gc-cookie-consent', selection);
                cookieBanner.classList.add('is-hidden');
            });
        });
    }
});