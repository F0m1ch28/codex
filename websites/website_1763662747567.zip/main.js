document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      navLinks.classList.toggle("open");
    });

    navLinks.querySelectorAll("a").forEach((link) =>
      link.addEventListener("click", () => {
        navLinks.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      })
    );
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const cookieAccept = document.querySelector("#cookieAccept");
  const cookieDecline = document.querySelector("#cookieDecline");
  const cookieChoice = localStorage.getItem("cookieChoice");

  if (!cookieChoice && cookieBanner) {
    setTimeout(() => cookieBanner.classList.add("active"), 800);
  }

  const closeBanner = (choice) => {
    if (!cookieBanner) return;
    cookieBanner.classList.remove("active");
    localStorage.setItem("cookieChoice", choice);
  };

  cookieAccept?.addEventListener("click", () => closeBanner("accepted"));
  cookieDecline?.addEventListener("click", () => closeBanner("declined"));

  document.querySelectorAll(".accordion button").forEach((button) => {
    button.addEventListener("click", () => {
      const expanded = button.getAttribute("aria-expanded") === "true";
      button.setAttribute("aria-expanded", !expanded);
      const content = button.nextElementSibling;
      content.classList.toggle("active");
    });
  });
});