import React, { useEffect, useMemo, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const generateFallbackData = () => {
  const today = new Date();
  const data = [];
  for (let i = 10; i >= 0; i -= 1) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    data.push({
      date: date.toISOString().split('T')[0],
      rate: 900 + Math.sin(i) * 15 + i * 2
    });
  }
  return data;
};

const ARSTracker = () => {
  const { strings } = useLanguage();
  const [rates, setRates] = useState(generateFallbackData());
  const [lastUpdated, setLastUpdated] = useState(new Date().toISOString());

  useEffect(() => {
    let isMounted = true;

    const fetchRates = async () => {
      try {
        const response = await fetch('https://api.exchangerate.host/latest?base=ARS&symbols=USD');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const json = await response.json();
        if (json && json.rates && json.rates.USD) {
          const rate = 1 / json.rates.USD;
          const newEntry = {
            date: new Date().toISOString().split('T')[0],
            rate: Number(rate.toFixed(2))
          };
          if (isMounted) {
            const updated = [...rates.slice(1), newEntry];
            setRates(updated);
            setLastUpdated(new Date().toISOString());
          }
        }
      } catch (error) {
        // gracefully fallback without dispatching console errors
      }
    };

    fetchRates();
    const interval = setInterval(fetchRates, 1000 * 60 * 60 * 6);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [rates]);

  const chartPath = useMemo(() => {
    if (!rates.length) return '';
    const maxRate = Math.max(...rates.map((item) => item.rate));
    const minRate = Math.min(...rates.map((item) => item.rate));
    const spread = maxRate - minRate || 1;

    return rates
      .map((point, index) => {
        const x = (index / (rates.length - 1)) * 100;
        const y = 100 - ((point.rate - minRate) / spread) * 100;
        return `${index === 0 ? 'M' : 'L'} ${x},${y}`;
      })
      .join(' ');
  }, [rates]);

  return (
    <section className="tracker-section">
      <div className="tracker-header">
        <h2>{strings.tracker.title}</h2>
        <p>{strings.tracker.subtitle}</p>
      </div>
      <div className="tracker-card" role="figure" aria-label="ARS to USD trend">
        <svg className="tracker-chart" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <linearGradient id="lineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#2563EB" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#2563EB" stopOpacity="0.1" />
            </linearGradient>
          </defs>
          <path d={chartPath} fill="none" stroke="url(#lineGradient)" strokeWidth="2" />
        </svg>
        <div className="tracker-data">
          <div>
            <span className="tracker-label">{strings.tracker.lastUpdated}:</span>
            <span className="tracker-value">
              {new Date(lastUpdated).toLocaleString()}
            </span>
          </div>
          <div className="tracker-list">
            {rates.slice(-4).map((item) => (
              <div key={item.date} className="tracker-item">
                <span>{item.date}</span>
                <strong>{item.rate.toFixed(2)} ARS</strong>
              </div>
            ))}
          </div>
        </div>
      </div>
      <p className="tracker-disclaimer">{strings.tracker.disclaimer}</p>
    </section>
  );
};

export default ARSTracker;