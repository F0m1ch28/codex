import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const LanguageSwitcher = ({ current }) => {
  const { switchLanguage } = useLanguage();
  return (
    <div className="language-switcher" role="group" aria-label="Language switcher">
      <button
        type="button"
        className={current === 'en' ? 'lang-btn active' : 'lang-btn'}
        onClick={() => switchLanguage('en')}
      >
        EN
      </button>
      <button
        type="button"
        className={current === 'es' ? 'lang-btn active' : 'lang-btn'}
        onClick={() => switchLanguage('es')}
      >
        ES
      </button>
    </div>
  );
};

export default LanguageSwitcher;