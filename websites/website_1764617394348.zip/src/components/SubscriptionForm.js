import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const SubscriptionForm = () => {
  const { strings } = useLanguage();
  const navigate = useNavigate();
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    consent: false
  });

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormState((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formState.consent) {
      return;
    }
    navigate('/thank-you', { state: { email: formState.email } });
  };

  return (
    <section className="subscription">
      <div className="subscription-card">
        <h2>{strings.subscriptionForm.title}</h2>
        <p>{strings.subscriptionForm.subtitle}</p>
        <form onSubmit={handleSubmit} className="subscription-form">
          <label htmlFor="sub-name">
            {strings.subscriptionForm.nameLabel}
            <input
              id="sub-name"
              name="name"
              type="text"
              required
              value={formState.name}
              onChange={handleChange}
              placeholder="María García"
            />
          </label>
          <label htmlFor="sub-email">
            {strings.subscriptionForm.emailLabel}
            <input
              id="sub-email"
              name="email"
              type="email"
              required
              value={formState.email}
              onChange={handleChange}
              placeholder="nombre@email.com"
            />
          </label>
          <label htmlFor="sub-consent" className="checkbox">
            <input
              id="sub-consent"
              name="consent"
              type="checkbox"
              checked={formState.consent}
              onChange={handleChange}
              required
            />
            <span>{strings.subscriptionForm.consentLabel}</span>
          </label>
          <button type="submit" className="btn primary">
            {strings.subscriptionForm.submit}
          </button>
        </form>
      </div>
    </section>
  );
};

export default SubscriptionForm;