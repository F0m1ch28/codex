import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import LanguageSwitcher from './LanguageSwitcher';

const Header = () => {
  const { strings, language } = useLanguage();

  return (
    <header className="header">
      <div className="header-inner">
        <Link to="/" className="logo">
          <span className="logo-mark">Tu</span>
          <span className="logo-text">Progreso Hoy</span>
        </Link>
        <nav className="nav">
          <NavLink to="/" className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')} end>
            {strings.nav.home}
          </NavLink>
          <NavLink
            to="/inflation"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            {strings.nav.inflation}
          </NavLink>
          <NavLink
            to="/course"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            {strings.nav.course}
          </NavLink>
          <NavLink
            to="/resources"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            {strings.nav.resources}
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            {strings.nav.contact}
          </NavLink>
          <NavLink
            to="/faq"
            className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
          >
            {strings.nav.faq}
          </NavLink>
        </nav>
        <LanguageSwitcher current={language} />
      </div>
    </header>
  );
};

export default Header;