import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const Footer = () => {
  const { strings } = useLanguage();
  return (
    <footer className="footer">
      <div className="footer-grid">
        <div>
          <div className="footer-logo">
            <span className="logo-mark">Tu</span>
            <span className="logo-text">Progreso Hoy</span>
          </div>
          <p>
            Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            <br />
            +54 11 5555-1234
          </p>
        </div>
        <div className="footer-links">
          <Link to="/privacy">{strings.footer.privacy}</Link>
          <Link to="/terms">{strings.footer.terms}</Link>
          <Link to="/cookies">{strings.footer.cookies}</Link>
          <a href="/sitemap.xml" target="_blank" rel="noopener noreferrer">
            {strings.footer.sitemap}
          </a>
        </div>
        <div className="footer-social">
          <p>LinkedIn · <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">Tu Progreso Hoy</a></p>
          <p>Twitter/X · <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">@TuProgresoHoy</a></p>
        </div>
      </div>
      <div className="footer-bottom">{strings.footer.rights}</div>
    </footer>
  );
};

export default Footer;