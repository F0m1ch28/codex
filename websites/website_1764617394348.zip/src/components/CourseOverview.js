import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const CourseOverview = () => {
  const { strings } = useLanguage();
  return (
    <section className="course-overview" id="course-overview">
      <div className="section-heading">
        <h2>{strings.courseOverview.title}</h2>
        <p>{strings.courseOverview.description}</p>
      </div>
      <div className="module-grid">
        {strings.courseOverview.modules.map((module) => (
          <div key={module.name} className="module-card">
            <h3>{module.name}</h3>
            <p>{module.details}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default CourseOverview;