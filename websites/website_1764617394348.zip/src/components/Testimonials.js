import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const Testimonials = () => {
  const { strings } = useLanguage();
  return (
    <section className="testimonials">
      <h2>{strings.testimonials.title}</h2>
      <div className="testimonial-grid">
        {strings.testimonials.items.map((item) => (
          <blockquote key={item.name} className="testimonial-card">
            <p>{item.quote}</p>
            <cite>{item.name}</cite>
          </blockquote>
        ))}
      </div>
    </section>
  );
};

export default Testimonials;