import React from 'react';
import { useLanguage } from '../context/LanguageContext';

const DisclaimerModal = ({ onClose }) => {
  const { strings } = useLanguage();

  return (
    <div className="disclaimer-overlay" role="dialog" aria-modal="true">
      <div className="disclaimer-content">
        <h2>{strings.disclaimer.heading}</h2>
        <ul>
          {strings.disclaimer.lines.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
        <button type="button" className="btn primary" onClick={onClose}>
          {strings.disclaimer.cta}
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;