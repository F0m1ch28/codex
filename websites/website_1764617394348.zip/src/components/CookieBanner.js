import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const { strings } = useLanguage();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const preference = localStorage.getItem('tph_cookie_consent');
    if (!preference) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (decision) => {
    localStorage.setItem('tph_cookie_consent', decision);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>{strings.cookie.message}</p>
      <div className="cookie-actions">
        <button type="button" className="btn secondary" onClick={() => handleConsent('decline')}>
          {strings.cookie.decline}
        </button>
        <button type="button" className="btn primary" onClick={() => handleConsent('accept')}>
          {strings.cookie.accept}
        </button>
      </div>
      <Link to="/cookies" className="cookie-learn">
        {strings.cookie.learnMore}
      </Link>
    </div>
  );
};

export default CookieBanner;