import React, { createContext, useContext, useMemo, useState } from 'react';

const LanguageContext = createContext();

const languagePack = {
  en: {
    nav: {
      home: 'Home',
      inflation: 'Inflation',
      course: 'Course',
      resources: 'Resources',
      contact: 'Contact',
      faq: 'FAQ'
    },
    hero: {
      title: 'Understand Argentina’s Inflation, Progress with Confidence',
      subtitle:
        'Tu Progreso Hoy blends data-driven ARS→USD intelligence with a foundational personal finance course tailored for Argentina.',
      ctaPrimary: 'Explore the Tracker',
      ctaSecondary: 'View the Course Outline',
      badge: 'Trusted Argentina Insights'
    },
    keyPromises: [
      {
        title: 'Real Context',
        description:
          'Daily ARS→USD monitoring plus CPI narratives curated for thoughtful decision-makers.'
      },
      {
        title: 'Actionable Learning',
        description:
          'A starter course that transforms complex financial topics into practical, step-by-step guidance.'
      },
      {
        title: 'Responsible Perspective',
        description:
          'No hype, just transparent resources to help you build resilient habits.'
      }
    ],
    tracker: {
      title: 'Live ARS→USD Monitor',
      subtitle:
        'Spot currency moves with contextual highlights and compare against recent CPI releases.',
      lastUpdated: 'Last updated',
      disclaimer:
        'Exchange values shown are educational estimates sourced from reputable public APIs. Cross-check before making financial decisions.'
    },
    insights: {
      title: 'Argentina Inflation Insights',
      items: [
        'Monthly CPI breakdown aligned with ARS depreciation trends.',
        'Purchasing power stories from Buenos Aires households.',
        'Scenario planning for short and mid-term savings.'
      ]
    },
    courseOverview: {
      title: 'Personal Finance Starter Course',
      description:
        'Learn the essentials of budgeting, protecting your savings, and planning in a high-inflation context.',
      modules: [
        {
          name: 'Module 1 — Inflation Literacy',
          details:
            'Decode CPI releases, official vs. implied FX, and how they reshape everyday decisions.'
        },
        {
          name: 'Module 2 — Personal Cash Flow',
          details:
            'Build a peso-based budget that adapts quickly to price changes and seasonal fluctuations.'
        },
        {
          name: 'Module 3 — Savings Strategies',
          details:
            'Explore diversified saving vehicles, emergency buffers, and responsible hedging.'
        },
        {
          name: 'Module 4 — Mindset & Planning',
          details:
            'Design sustainable money routines and evaluate opportunities without unrealistic promises.'
        }
      ]
    },
    testimonials: {
      title: 'What Learners in Argentina Are Saying',
      items: [
        {
          quote:
            '“The tracker and course together helped me interpret currency swings calmly and plan my monthly spending.”',
          name: 'Lucía R., Palermo'
        },
        {
          quote:
            '“I finally grasp the relationship between ARS movements and inflation, and I have tools to adapt my budget.”',
          name: 'Martín G., Córdoba'
        }
      ]
    },
    subscriptionForm: {
      title: 'Start Your Learning Journey',
      subtitle:
        'Sign up for the double opt-in trial lesson to receive curated insights and the first course module.',
      nameLabel: 'Name',
      emailLabel: 'Email',
      consentLabel:
        'I agree to receive educational emails and understand I must confirm my subscription.',
      submit: 'Получить бесплатный пробный урок'
    },
    thankYou: {
      heading: 'Thank you for joining Tu Progreso Hoy!',
      description:
        'Please check your inbox and confirm your email to activate the double opt-in trial. We will unlock your first lesson after confirmation.',
      backHome: 'Return to Home'
    },
    methodology: {
      title: 'Methodology & Context',
      description:
        'Tu Progreso Hoy aggregates official CPI releases, market surveys, and reputable FX references to contextualize Argentine inflation.',
      pillars: [
        {
          title: 'Data Integrity',
          description:
            'We cross-reference Banco Central, INDEC, and independent monitors to highlight consensus and divergence.'
        },
        {
          title: 'Transparent Assumptions',
          description:
            'Assumptions, models, and data refresh frequencies are published so you can evaluate reliability.'
        },
        {
          title: 'Education First',
          description:
            'All dashboards are paired with explainers and real-world scenarios to build financial literacy.'
        }
      ],
      chartTitle: 'ARS→USD & CPI Trend Snapshot',
      chartDescription:
        'Smoothed monthly view showing the relationship between currency adjustments and inflation prints.'
    },
    faq: {
      title: 'Frequently Asked Questions',
      items: [
        {
          question: 'How often is the ARS→USD tracker updated?',
          answer:
            'We refresh the feed multiple times per day using foreign exchange APIs. When APIs are delayed, we display the latest available data with a timestamp.'
        },
        {
          question:
            'Is Tu Progreso Hoy offering investment advice or financial services?',
          answer:
            'We do not provide financial services or personalized investment advice. Our role is educational so you can make informed decisions independently.'
        },
        {
          question: 'What does a double opt-in trial involve?',
          answer:
            'After submitting the form, you receive an email asking you to confirm your interest. Only after confirmation will you receive lessons and insights.'
        },
        {
          question: 'Can I access content in Spanish?',
          answer:
            'Yes, you can switch to Español at any time using the language selector in the navigation.'
        }
      ]
    },
    coursePage: {
      overviewTitle: 'Course Syllabus at a Glance',
      targetAudienceTitle: 'Who Should Join',
      targetAudience: [
        'Young professionals navigating inflation-linked salaries.',
        'Families coordinating peso and dollar expenses.',
        'Entrepreneurs planning cash flow in volatile conditions.'
      ],
      cta: 'Go to Trial Lesson Form'
    },
    resources: {
      title: 'Resources & Glossary',
      subtitle:
        'Curated bilingual articles and key definitions to support your financial literacy journey.',
      articles: [
        {
          language: 'English',
          title: 'Navigating Inflation Expectations in Argentina',
          description:
            'A guide to understanding inflation expectations, forward rates, and their impact on day-to-day decisions.'
        },
        {
          language: 'Español',
          title: 'Introducción responsable al ahorro en dólares',
          description:
            'Buenas prácticas para diversificar ahorros y evaluar riesgos sin promesas irreales.'
        },
        {
          language: 'Bilingual',
          title: 'Glossary: CPI, FX, Crawling Peg',
          description:
            'Key terms in both English and Spanish to follow Argentina’s economic narrative.'
        }
      ]
    },
    contact: {
      title: 'Contact Tu Progreso Hoy',
      description:
        'Reach out for partnership opportunities, questions about the course, or media inquiries.',
      addressLabel: 'Address',
      phoneLabel: 'Phone',
      emailLabel: 'Email',
      socialLabel: 'Social',
      formTitle: 'Send us a message',
      name: 'Name',
      email: 'Email',
      message: 'Message',
      consent:
        'I agree to the privacy policy and understand the team will respond via email.',
      submit: 'Submit Message',
      mapAlt: 'Map showing location in Buenos Aires'
    },
    footer: {
      rights: '© 2024 Tu Progreso Hoy. All rights reserved.',
      privacy: 'Privacy',
      terms: 'Terms',
      cookies: 'Cookies',
      sitemap: 'Sitemap'
    },
    cookie: {
      message:
        'We use cookies to analyze site engagement and enhance your learning experience. You can opt in or decline.',
      accept: 'Accept',
      decline: 'Decline',
      learnMore: 'Learn more'
    },
    disclaimer: {
      heading: 'Important Notice',
      lines: [
        'Мы не предоставляем финансовые услуги',
        'We do not provide financial services',
        'No brindamos servicios financieros'
      ],
      cta: 'I Understand'
    }
  },
  es: {
    nav: {
      home: 'Inicio',
      inflation: 'Inflación',
      course: 'Curso',
      resources: 'Recursos',
      contact: 'Contacto',
      faq: 'Preguntas'
    },
    hero: {
      title: 'Comprende la inflación argentina, progresa con confianza',
      subtitle:
        'Tu Progreso Hoy combina inteligencia ARS→USD basada en datos con un curso introductorio de finanzas personales diseñado para Argentina.',
      ctaPrimary: 'Explorar el monitor',
      ctaSecondary: 'Ver el programa',
      badge: 'Insights confiables de Argentina'
    },
    keyPromises: [
      {
        title: 'Contexto real',
        description:
          'Seguimiento diario ARS→USD y narrativas del IPC pensadas para quienes toman decisiones con calma.'
      },
      {
        title: 'Aprendizaje accionable',
        description:
          'Curso inicial que transforma temas financieros complejos en pasos prácticos.'
      },
      {
        title: 'Perspectiva responsable',
        description:
          'Sin exageraciones, solo recursos transparentes para construir hábitos resilientes.'
      }
    ],
    tracker: {
      title: 'Monitor ARS→USD en vivo',
      subtitle:
        'Detecta movimientos cambiarios con contexto y compáralos con los últimos datos de IPC.',
      lastUpdated: 'Última actualización',
      disclaimer:
        'Los valores mostrados son estimaciones educativas obtenidas de APIs públicas confiables. Verifica antes de tomar decisiones financieras.'
    },
    insights: {
      title: 'Insights sobre la inflación en Argentina',
      items: [
        'Desglose mensual del IPC alineado con la depreciación del peso.',
        'Historias de poder adquisitivo de hogares porteños.',
        'Escenarios para planificar ahorros en el corto y mediano plazo.'
      ]
    },
    courseOverview: {
      title: 'Curso inicial de finanzas personales',
      description:
        'Aprende lo esencial sobre presupuesto, protección del ahorro y planificación en contexto de alta inflación.',
      modules: [
        {
          name: 'Módulo 1 — Alfabetización en inflación',
          details:
            'Comprende informes de IPC, tipos de cambio oficiales e implícitos y su impacto en el día a día.'
        },
        {
          name: 'Módulo 2 — Flujo de caja personal',
          details:
            'Construye un presupuesto en pesos que se adapte rápido a cambios de precios y estacionalidad.'
        },
        {
          name: 'Módulo 3 — Estrategias de ahorro',
          details:
            'Explora vehículos de ahorro diversificados, fondos de emergencia y coberturas responsables.'
        },
        {
          name: 'Módulo 4 — Mentalidad y planificación',
          details:
            'Diseña rutinas financieras sostenibles y evalúa oportunidades sin promesas irreales.'
        }
      ]
    },
    testimonials: {
      title: 'Lo que dicen quienes aprenden en Argentina',
      items: [
        {
          quote:
            '“El monitor y el curso me ayudaron a interpretar los movimientos cambiarios con calma y planificar mis gastos.”',
          name: 'Lucía R., Palermo'
        },
        {
          quote:
            '“Ahora entiendo la relación entre el peso y la inflación, y tengo herramientas para ajustar mi presupuesto.”',
          name: 'Martín G., Córdoba'
        }
      ]
    },
    subscriptionForm: {
      title: 'Comienza tu camino de aprendizaje',
      subtitle:
        'Regístrate para el periodo de prueba con doble confirmación y recibe insights curados y el primer módulo.',
      nameLabel: 'Nombre',
      emailLabel: 'Correo',
      consentLabel:
        'Acepto recibir correos educativos y entiendo que debo confirmar mi suscripción.',
      submit: 'Получить бесплатный пробный урок'
    },
    thankYou: {
      heading: '¡Gracias por unirte a Tu Progreso Hoy!',
      description:
        'Revisa tu correo y confirma tu dirección para activar la prueba con doble confirmación. Liberaremos tu primera lección tras la confirmación.',
      backHome: 'Volver al inicio'
    },
    methodology: {
      title: 'Metodología y contexto',
      description:
        'Tu Progreso Hoy integra datos del IPC, encuestas de mercado y referencias cambiarias confiables para contextualizar la inflación argentina.',
      pillars: [
        {
          title: 'Integridad de datos',
          description:
            'Contrastamos fuentes del Banco Central, INDEC y monitoreos independientes para resaltar consensos y diferencias.'
        },
        {
          title: 'Supuestos transparentes',
          description:
            'Publicamos supuestos, modelos y frecuencias de actualización para que evalúes la confiabilidad.'
        },
        {
          title: 'Educación primero',
          description:
            'Cada panel se acompaña de explicaciones y escenarios reales para fortalecer la alfabetización financiera.'
        }
      ],
      chartTitle: 'Tendencia ARS→USD e IPC',
      chartDescription:
        'Vista mensual suavizada que muestra la relación entre ajustes cambiarios e inflación.'
    },
    faq: {
      title: 'Preguntas frecuentes',
      items: [
        {
          question: '¿Con qué frecuencia se actualiza el monitor ARS→USD?',
          answer:
            'Actualizamos varias veces por día con APIs de tipo de cambio. Si hay demoras, mostramos el dato más reciente con marca de tiempo.'
        },
        {
          question:
            '¿Tu Progreso Hoy brinda asesoramiento o servicios financieros?',
          answer:
            'No brindamos servicios financieros ni asesoramiento personalizado. Nuestro rol es educativo para que tomes decisiones informadas.'
        },
        {
          question: '¿Qué implica la prueba con doble confirmación?',
          answer:
            'Tras enviar el formulario recibirás un correo para confirmar tu interés. Solo después de confirmarlo recibirás las lecciones e insights.'
        },
        {
          question: '¿Puedo acceder al contenido en inglés?',
          answer:
            'Sí, puedes cambiar a English en cualquier momento desde el selector de idioma en la navegación.'
        }
      ]
    },
    coursePage: {
      overviewTitle: 'Programa del curso',
      targetAudienceTitle: '¿Para quién es?',
      targetAudience: [
        'Profesionales jóvenes con salarios indexados a la inflación.',
        'Familias que gestionan gastos en pesos y dólares.',
        'Emprendedores que deben planificar flujo de caja en contextos volátiles.'
      ],
      cta: 'Ir al formulario de prueba'
    },
    resources: {
      title: 'Recursos y glosario',
      subtitle:
        'Artículos bilingües y definiciones clave para acompañar tu aprendizaje financiero.',
      articles: [
        {
          language: 'English',
          title: 'Navigating Inflation Expectations in Argentina',
          description:
            'Guía para comprender expectativas de inflación, tasas implícitas y su impacto cotidiano.'
        },
        {
          language: 'Español',
          title: 'Introducción responsable al ahorro en dólares',
          description:
            'Buenas prácticas para diversificar ahorros y evaluar riesgos sin promesas irreales.'
        },
        {
          language: 'Bilingüe',
          title: 'Glosario: IPC, FX, Crawling Peg',
          description:
            'Conceptos clave en inglés y español para seguir la narrativa económica argentina.'
        }
      ]
    },
    contact: {
      title: 'Contacto Tu Progreso Hoy',
      description:
        'Escríbenos para alianzas, preguntas sobre el curso o consultas de prensa.',
      addressLabel: 'Dirección',
      phoneLabel: 'Teléfono',
      emailLabel: 'Correo',
      socialLabel: 'Redes',
      formTitle: 'Envíanos un mensaje',
      name: 'Nombre',
      email: 'Correo',
      message: 'Mensaje',
      consent:
        'Acepto la política de privacidad y comprendo que responderán por correo.',
      submit: 'Enviar mensaje',
      mapAlt: 'Mapa de Buenos Aires'
    },
    footer: {
      rights: '© 2024 Tu Progreso Hoy. Todos los derechos reservados.',
      privacy: 'Privacidad',
      terms: 'Términos',
      cookies: 'Cookies',
      sitemap: 'Mapa del sitio'
    },
    cookie: {
      message:
        'Usamos cookies para analizar el uso del sitio y mejorar tu experiencia de aprendizaje. Puedes aceptar o rechazar.',
      accept: 'Aceptar',
      decline: 'Rechazar',
      learnMore: 'Saber más'
    },
    disclaimer: {
      heading: 'Aviso importante',
      lines: [
        'Мы не предоставляем финансовые услуги',
        'We do not provide financial services',
        'No brindamos servicios financieros'
      ],
      cta: 'Entendido'
    }
  }
};

export const LanguageProvider = ({ children }) => {
  const defaultLang = localStorage.getItem('tph_language') || 'en';
  const [language, setLanguage] = useState(defaultLang);

  const switchLanguage = (lang) => {
    setLanguage(lang);
    localStorage.setItem('tph_language', lang);
  };

  const value = useMemo(
    () => ({
      language,
      strings: languagePack[language],
      switchLanguage
    }),
    [language]
  );

  return (
    <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);