import React from 'react';
import { Helmet } from 'react-helmet-async';

const Cookies = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Tu Progreso Hoy</title>
    </Helmet>
    <section className="legal-page">
      <h1>Cookie Policy</h1>
      <p>Effective date: 1 June 2024</p>
      <h2>What Are Cookies?</h2>
      <p>
        Cookies are small text files stored on your device. They help us remember your preferences and analyze site traffic.
      </p>
      <h2>Types of Cookies We Use</h2>
      <ul>
        <li>
          <strong>Essential Cookies:</strong> Required for basic site functionality, such as remembering language preference.
        </li>
        <li>
          <strong>Analytics Cookies:</strong> Optional cookies that help us understand how visitors interact with the site. These are only enabled when you opt in.
        </li>
      </ul>
      <h2>Managing Cookies</h2>
      <p>
        You can update your preferences at any time by clearing cookies in your browser or contacting us at hola@tuprogresohoy.com.
      </p>
      <h2>Third-Party Cookies</h2>
      <p>
        Our embedded map from Google Maps may set cookies to provide location services. Please review Google’s privacy policy for details.
      </p>
      <h2>Updates</h2>
      <p>
        We may revise this policy to reflect changes in technology or regulations. Updated versions will be posted here.
      </p>
    </section>
  </>
);

export default Cookies;