import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../context/LanguageContext';

const FAQ = ({ standalone = true }) => {
  const { language, strings } = useLanguage();
  const [openIndex, setOpenIndex] = useState(0);

  const toggleIndex = (index) => {
    setOpenIndex((prev) => (prev === index ? -1 : index));
  };

  const content = (
    <section className="faq-section">
      <h2>{strings.faq.title}</h2>
      <div className="faq-accordion">
        {strings.faq.items.map((item, index) => (
          <div key={item.question} className="faq-item">
            <button
              type="button"
              className="faq-question"
              onClick={() => toggleIndex(index)}
              aria-expanded={openIndex === index}
            >
              {item.question}
              <span>{openIndex === index ? '−' : '+'}</span>
            </button>
            {openIndex === index && (
              <div className="faq-answer">
                <p>{item.answer}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );

  if (!standalone) {
    return content;
  }

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es-AR'} />
        <title>FAQ | Tu Progreso Hoy</title>
        <link rel="alternate" hrefLang="en" href="https://www.tuprogresohoy.com/faq" />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href="https://www.tuprogresohoy.com/faq?lang=es"
        />
      </Helmet>
      {content}
    </>
  );
};

export default FAQ;