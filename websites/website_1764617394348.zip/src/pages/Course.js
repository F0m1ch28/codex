import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../context/LanguageContext';

const Course = () => {
  const { language, strings } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es-AR'} />
        <title>Personal Finance Starter Course | Tu Progreso Hoy</title>
        <link rel="alternate" hrefLang="en" href="https://www.tuprogresohoy.com/course" />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href="https://www.tuprogresohoy.com/course?lang=es"
        />
      </Helmet>
      <section className="course-page">
        <h1>{strings.courseOverview.title}</h1>
        <p className="course-lead">
          {strings.courseOverview.description}
        </p>
        <div className="module-grid">
          {strings.courseOverview.modules.map((module) => (
            <div key={module.name} className="module-card">
              <h3>{module.name}</h3>
              <p>{module.details}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="target-audience">
        <h2>{strings.coursePage.targetAudienceTitle}</h2>
        <ul>
          {strings.coursePage.targetAudience.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>
      <div className="course-cta">
        <a href="/#course-overview" className="btn primary">
          {strings.coursePage.cta}
        </a>
      </div>
    </>
  );
};

export default Course;