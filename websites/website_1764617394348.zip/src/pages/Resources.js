import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../context/LanguageContext';

const Resources = () => {
  const { language, strings } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es-AR'} />
        <title>Resources & Glossary | Tu Progreso Hoy</title>
        <link
          rel="alternate"
          hrefLang="en"
          href="https://www.tuprogresohoy.com/resources"
        />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href="https://www.tuprogresohoy.com/resources?lang=es"
        />
      </Helmet>
      <section className="resources">
        <h1>{strings.resources.title}</h1>
        <p className="resources-subtitle">{strings.resources.subtitle}</p>
        <div className="resource-grid">
          {strings.resources.articles.map((article) => (
            <article key={article.title} className="resource-card">
              <span className="resource-language">{article.language}</span>
              <h3>{article.title}</h3>
              <p>{article.description}</p>
              <a
                href="https://www.ceicdata.com/en/indicator/argentina/inflation-rate"
                target="_blank"
                rel="noopener noreferrer"
                className="resource-link"
              >
                Read reference →
              </a>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Resources;