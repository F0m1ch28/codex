import React from 'react';
import { Helmet } from 'react-helmet-async';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Service | Tu Progreso Hoy</title>
    </Helmet>
    <section className="legal-page">
      <h1>Terms of Service</h1>
      <p>Effective date: 1 June 2024</p>
      <h2>Acceptance</h2>
      <p>
        By accessing Tu Progreso Hoy, you agree to these Terms of Service and all applicable laws and regulations.
      </p>
      <h2>Educational Purpose</h2>
      <p>
        The website provides educational resources about inflation and personal finance. Мы не предоставляем финансовые услуги. We do not provide financial services. No brindamos servicios financieros.
      </p>
      <h2>User Responsibilities</h2>
      <ul>
        <li>Use the content responsibly and verify information before making financial decisions.</li>
        <li>Provide accurate information when submitting forms and respect the double opt-in process.</li>
      </ul>
      <h2>Intellectual Property</h2>
      <p>
        All content, including text, graphics, and branding, is owned by Tu Progreso Hoy unless otherwise stated.
      </p>
      <h2>Limitation of Liability</h2>
      <p>
        We are not liable for any damages arising from the use of our content. Information is provided “as is” for educational purposes.
      </p>
      <h2>Third-Party Links</h2>
      <p>
        External links are provided for convenience. We are not responsible for their content or privacy practices.
      </p>
      <h2>Termination</h2>
      <p>
        We may restrict access if a user violates these terms or engages in harmful activities.
      </p>
      <h2>Governing Law</h2>
      <p>
        These Terms are governed by the laws of Argentina. Disputes will be handled in the courts of Buenos Aires.
      </p>
      <h2>Contact</h2>
      <p>
        Questions about these Terms? Email hola@tuprogresohoy.com.
      </p>
    </section>
  </>
);

export default Terms;