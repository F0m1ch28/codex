import React from 'react';
import { Helmet } from 'react-helmet-async';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Tu Progreso Hoy</title>
    </Helmet>
    <section className="legal-page">
      <h1>Privacy Policy</h1>
      <p>Effective date: 1 June 2024</p>
      <p>
        Tu Progreso Hoy (“we”, “us”, or “our”) respects your privacy. This Privacy Policy explains how we collect,
        use, disclose, and safeguard your information when you visit our website.
      </p>
      <h2>Information We Collect</h2>
      <ul>
        <li>Personal data such as name and email address submitted through forms.</li>
        <li>Usage data including pages visited, browser type, and interactions, gathered through analytics cookies when you opt in.</li>
      </ul>
      <h2>How We Use Information</h2>
      <ul>
        <li>To provide educational content, respond to inquiries, and deliver the double opt-in trial lesson.</li>
        <li>To improve website performance and user experience when consent is granted.</li>
      </ul>
      <h2>Legal Basis</h2>
      <p>
        We process personal data based on consent and legitimate interests in providing educational services.
      </p>
      <h2>Data Sharing</h2>
      <p>
        We do not sell personal data. Service providers assisting with email communications or hosting may access information under confidentiality agreements.
      </p>
      <h2>Data Retention</h2>
      <p>
        We retain personal information only for as long as necessary to provide services or as required by law.
      </p>
      <h2>Your Rights</h2>
      <p>
        Depending on your jurisdiction, you may request access, correction, or deletion of your personal data by contacting hola@tuprogresohoy.com.
      </p>
      <h2>International Transfers</h2>
      <p>
        Data may be stored in data centers outside Argentina. We apply appropriate safeguards for cross-border transfers.
      </p>
      <h2>Security</h2>
      <p>
        We implement administrative, technical, and physical measures to protect your data. No method of transmission is entirely secure.
      </p>
      <h2>Children</h2>
      <p>
        Our services are not directed to individuals under 16. We do not knowingly collect information from minors.
      </p>
      <h2>Changes</h2>
      <p>
        We may update this Privacy Policy. Revisions will be posted with an updated effective date.
      </p>
      <h2>Contact</h2>
      <p>
        Email: hola@tuprogresohoy.com
      </p>
    </section>
  </>
);

export default Privacy;