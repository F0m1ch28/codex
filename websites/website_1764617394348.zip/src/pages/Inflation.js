import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../context/LanguageContext';
import FAQ from './FAQ';

const Inflation = () => {
  const { language, strings } = useLanguage();

  const cpiData = [
    { month: 'Jan', cpi: 20, fx: 5 },
    { month: 'Feb', cpi: 18, fx: 6 },
    { month: 'Mar', cpi: 16, fx: 7 },
    { month: 'Apr', cpi: 14, fx: 7.5 },
    { month: 'May', cpi: 13, fx: 8 },
    { month: 'Jun', cpi: 12, fx: 8.4 }
  ];

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es-AR'} />
        <title>Argentina Inflation Methodology | Tu Progreso Hoy</title>
        <link
          rel="alternate"
          hrefLang="en"
          href="https://www.tuprogresohoy.com/inflation"
        />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href="https://www.tuprogresohoy.com/inflation?lang=es"
        />
      </Helmet>
      <section className="methodology">
        <h1>{strings.methodology.title}</h1>
        <p>{strings.methodology.description}</p>
        <div className="pillar-grid">
          {strings.methodology.pillars.map((pillar) => (
            <div key={pillar.title} className="pillar-card">
              <h3>{pillar.title}</h3>
              <p>{pillar.description}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="chart-section">
        <h2>{strings.methodology.chartTitle}</h2>
        <p>{strings.methodology.chartDescription}</p>
        <div className="chart-container" role="figure" aria-label="CPI and FX chart">
          <svg viewBox="0 0 300 150" preserveAspectRatio="none">
            <polyline
              fill="none"
              stroke="#2563EB"
              strokeWidth="3"
              points={cpiData
                .map((point, index) => `${(index / (cpiData.length - 1)) * 300},${150 - point.cpi * 5}`)
                .join(' ')}
            />
            <polyline
              fill="none"
              stroke="#1F3A6F"
              strokeWidth="3"
              strokeDasharray="6 4"
              points={cpiData
                .map((point, index) => `${(index / (cpiData.length - 1)) * 300},${150 - point.fx * 12}`)
                .join(' ')}
            />
            {cpiData.map((point, index) => (
              <text
                key={point.month}
                x={(index / (cpiData.length - 1)) * 300}
                y={145}
                textAnchor="middle"
                fontSize="10"
                fill="#0F172A"
              >
                {point.month}
              </text>
            ))}
          </svg>
          <div className="chart-legend">
            <span className="legend-item">
              <span className="legend-dot blue"></span>CPI %
            </span>
            <span className="legend-item">
              <span className="legend-dot navy"></span>ARS→USD (normalized)
            </span>
          </div>
        </div>
      </section>
      <FAQ standalone={false} />
    </>
  );
};

export default Inflation;