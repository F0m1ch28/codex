import React from 'react';
import { Helmet } from 'react-helmet-async';
import Hero from '../components/Hero';
import ARSTracker from '../components/ARSTracker';
import CourseOverview from '../components/CourseOverview';
import Testimonials from '../components/Testimonials';
import SubscriptionForm from '../components/SubscriptionForm';
import { useLanguage } from '../context/LanguageContext';

const Home = () => {
  const { language, strings } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es-AR'} />
        <title>Tu Progreso Hoy | Inflation Insights & Course</title>
        <link rel="alternate" hrefLang="en" href="https://www.tuprogresohoy.com/" />
        <link rel="alternate" hrefLang="es-AR" href="https://www.tuprogresohoy.com/?lang=es" />
      </Helmet>
      <Hero />
      <section className="promise-grid">
        {strings.keyPromises.map((promise) => (
          <div key={promise.title} className="promise-card">
            <h3>{promise.title}</h3>
            <p>{promise.description}</p>
          </div>
        ))}
      </section>
      <ARSTracker />
      <section className="insights">
        <h2>{strings.insights.title}</h2>
        <ul>
          {strings.insights.items.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>
      <CourseOverview />
      <Testimonials />
      <SubscriptionForm />
    </>
  );
};

export default Home;