import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '../context/LanguageContext';

const Contact = () => {
  const { language, strings } = useLanguage();
  const [status, setStatus] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus(
      language === 'en'
        ? 'Thank you! Please check your inbox to confirm your request.'
        : '¡Gracias! Revisa tu correo para confirmar tu solicitud.'
    );
    event.target.reset();
  };

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es-AR'} />
        <title>Contact Tu Progreso Hoy</title>
        <link
          rel="alternate"
          hrefLang="en"
          href="https://www.tuprogresohoy.com/contact"
        />
        <link
          rel="alternate"
          hrefLang="es-AR"
          href="https://www.tuprogresohoy.com/contact?lang=es"
        />
      </Helmet>
      <section className="contact-page">
        <div className="contact-info">
          <h1>{strings.contact.title}</h1>
          <p>{strings.contact.description}</p>
          <div className="contact-details">
            <div>
              <h4>{strings.contact.addressLabel}</h4>
              <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
            </div>
            <div>
              <h4>{strings.contact.phoneLabel}</h4>
              <p>+54 11 5555-1234</p>
            </div>
            <div>
              <h4>{strings.contact.emailLabel}</h4>
              <p>hola@tuprogresohoy.com</p>
            </div>
            <div>
              <h4>{strings.contact.socialLabel}</h4>
              <p>
                LinkedIn · <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">Tu Progreso Hoy</a><br />
                Twitter/X · <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">@TuProgresoHoy</a>
              </p>
            </div>
          </div>
        </div>
        <div className="contact-form-wrapper">
          <h2>{strings.contact.formTitle}</h2>
          <form onSubmit={handleSubmit} className="contact-form">
            <label htmlFor="contact-name">
              {strings.contact.name}
              <input id="contact-name" name="name" type="text" required placeholder="Tu nombre" />
            </label>
            <label htmlFor="contact-email">
              {strings.contact.email}
              <input id="contact-email" name="email" type="email" required placeholder="correo@ejemplo.com" />
            </label>
            <label htmlFor="contact-message">
              {strings.contact.message}
              <textarea
                id="contact-message"
                name="message"
                rows="4"
                required
                placeholder="Cuéntanos en qué podemos ayudarte"
              ></textarea>
            </label>
            <label htmlFor="contact-consent" className="checkbox">
              <input id="contact-consent" name="consent" type="checkbox" required />
              <span>{strings.contact.consent}</span>
            </label>
            <button type="submit" className="btn primary">
              {strings.contact.submit}
            </button>
          </form>
          {status && <p className="status-message">{status}</p>}
        </div>
      </section>
      <section className="map-section">
        <iframe
          title="Tu Progreso Hoy Buenos Aires Map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.112690627544!2d-58.382658884718386!3d-34.603738480459675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccadc0c0c9f4b%3A0xb12e51e74a53ce38!2sAv.%209%20de%20Julio%201000%2C%20C1043%20Buenos%20Aires%2C%20Argentina!5e0!3m2!1sen!2sar!4v1717452090000!5m2!1sen!2sar"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          aria-label={strings.contact.mapAlt}
        ></iframe>
      </section>
    </>
  );
};

export default Contact;