import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const ThankYou = () => {
  const { language, strings } = useLanguage();
  const location = useLocation();
  const email = location.state?.email;

  return (
    <>
      <Helmet>
        <html lang={language === 'en' ? 'en' : 'es-AR'} />
        <title>Thank You | Tu Progreso Hoy</title>
      </Helmet>
      <section className="thank-you">
        <div className="thank-you-card">
          <h1>{strings.thankYou.heading}</h1>
          <p>{strings.thankYou.description}</p>
          {email && (
            <p className="thank-email">
              {language === 'en'
                ? `Confirmation sent to: ${email}`
                : `Confirmación enviada a: ${email}`}
            </p>
          )}
          <Link to="/" className="btn primary">
            {strings.thankYou.backHome}
          </Link>
        </div>
      </section>
    </>
  );
};

export default ThankYou;