document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isOpen = siteNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('acceptCookies');
    const declineBtn = document.getElementById('declineCookies');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('ragtanqCookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        }
        const handleConsent = (value) => {
            localStorage.setItem('ragtanqCookieConsent', value);
            cookieBanner.classList.add('is-hidden');
        };
        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleConsent('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleConsent('declined'));
        }
    }
});