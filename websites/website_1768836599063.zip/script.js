document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-links a');
    const consentBanner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const consentKey = 'botoxiuai-cookie-consent';

    if (toggle && navMenu) {
        toggle.addEventListener('click', () => {
            navMenu.classList.toggle('is-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('is-open');
            });
        });

        document.addEventListener('click', (event) => {
            if (!navMenu.contains(event.target) && event.target !== toggle) {
                navMenu.classList.remove('is-open');
            }
        });
    }

    const setConsent = (value) => {
        try {
            localStorage.setItem(consentKey, value);
        } catch (error) {
            document.cookie = `${consentKey}=${value}; path=/; max-age=${60 * 60 * 24 * 180}`;
        }
    };

    const getConsent = () => {
        try {
            return localStorage.getItem(consentKey);
        } catch (error) {
            const match = document.cookie.match(new RegExp('(^| )' + consentKey + '=([^;]+)'));
            return match ? match[2] : null;
        }
    };

    if (consentBanner) {
        const consent = getConsent();
        if (!consent) {
            consentBanner.style.display = 'flex';
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                setConsent('accepted');
                consentBanner.style.display = 'none';
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                setConsent('declined');
                consentBanner.style.display = 'none';
            });
        }
    }
});