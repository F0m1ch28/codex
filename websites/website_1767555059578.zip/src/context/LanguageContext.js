import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

const LanguageContext = createContext();

const dictionary = {
  en: {
    navHome: 'Home',
    navInflation: 'Inflation Analytics',
    navCourse: 'Course',
    navResources: 'Resources',
    navContact: 'Contact',
    navDisclaimer: 'Disclaimer',
    footerNavigate: 'Navigate',
    footerCompany: 'Company',
    footerAbout: 'About',
    footerServices: 'Services',
    footerPrivacy: 'Privacy Policy',
    footerTerms: 'Terms of Service',
    footerCookies: 'Cookie Policy',
    footerContact: 'Contact',
  },
  es: {
    navHome: 'Inicio',
    navInflation: 'Análisis de inflación',
    navCourse: 'Curso',
    navResources: 'Recursos',
    navContact: 'Contacto',
    navDisclaimer: 'Aviso',
    footerNavigate: 'Navegación',
    footerCompany: 'Compañía',
    footerAbout: 'Nosotros',
    footerServices: 'Servicios',
    footerPrivacy: 'Política de privacidad',
    footerTerms: 'Términos',
    footerCookies: 'Política de cookies',
    footerContact: 'Contacto',
  },
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => localStorage.getItem('tph_language') || 'en');

  useEffect(() => {
    localStorage.setItem('tph_language', language);
  }, [language]);

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === 'en' ? 'es' : 'en'));
  };

  const value = useMemo(
    () => ({
      language,
      toggleLanguage,
      t: (key) => dictionary[language][key] || dictionary.en[key] || key,
    }),
    [language]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
};