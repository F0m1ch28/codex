import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import styles from './Inflation.module.css';

const Inflation = () => {
  const { language } = useLanguage();

  const faqItems = [
    {
      question: 'How frequently is Argentina’s CPI updated?',
      answer:
        'Official CPI data is typically released monthly by INDEC. We supplement it with high-frequency price trackers to anticipate turning points.',
    },
    {
      question: 'What does the ARS→USD tracker include?',
      answer:
        'It reflects a blended view of official, wholesale, and alternative market references, helping you gauge price pressures.',
    },
    {
      question: 'How do you handle inflation forecasts?',
      answer:
        'Our models incorporate trailing CPI, energy imports, monetary aggregates, and policy announcements to create scenario bands.',
    },
    {
      question: 'Can I rely on a single exchange rate for planning?',
      answer:
        'We recommend stress-testing budgets with multiple rates to account for spread volatility across transaction types.',
    },
    {
      question: 'What is the CPI/FX context section?',
      answer:
        'It explains how consumer price indices interact with currency depreciation, showing how inflation expectations move with FX gaps.',
    },
    {
      question: 'Do you provide personalized investment advice?',
      answer:
        'No. Datos verificados para planificar tu presupuesto, but decisions remain yours. We do not provide financial services.',
    },
    {
      question: 'How can businesses use this analysis?',
      answer:
        'Companies use our dashboards to adjust pricing, wages, and inventory purchases based on data-driven inflation expectations.',
    },
  ];

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Argentina Inflation Analytics | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore ARS to USD data, inflation dashboards, and CPI context tailored for Argentina with detailed methodologies."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, economic trends, datos confiables, CPI, FX analysis"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/inflation" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/inflation" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Inflation Analytics for Argentina</h1>
          <p>
            Decisiones responsables, objetivos nítidos. Our methodology blends official releases with near-real-time
            signals to capture peso dynamics through trusted data.
          </p>
        </div>
      </section>
      <section className={styles.methodology}>
        <h2>Methodology Overview</h2>
        <div className={styles.cards}>
          <article>
            <h3>Data Integrity</h3>
            <p>
              We cross-reference INDEC data with private sector price collectors, FX order books, and trade statistics.
              Each datapoint is timestamped and versioned to ensure transparency.
            </p>
          </article>
          <article>
            <h3>Scenario Modeling</h3>
            <p>
              Monte Carlo simulations stress-test inflation paths based on fuel prices, monetary policy, and wage
              agreements. Análisis transparentes y datos de mercado para decidir con seguridad.
            </p>
          </article>
          <article>
            <h3>Visualization</h3>
            <p>
              Dashboards highlight core inflation, tradable vs non-tradable goods, and FX spreads to interpret daily and
              monthly shifts.
            </p>
          </article>
        </div>
      </section>
      <section className={styles.charts}>
        <div className={styles.chartCard}>
          <h3>Inflation Heatmap</h3>
          <img
            src="https://images.pexels.com/photos/669619/pexels-photo-669619.jpeg?auto=compress&cs=tinysrgb&w=900"
            alt="Inflation heatmap placeholder"
            loading="lazy"
          />
          <p>Heatmap showing CPI contributions by category, highlighting acceleration in food, transport, and housing.</p>
        </div>
        <div className={styles.chartCard}>
          <h3>Exchange Rate Corridor</h3>
          <img
            src="https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=900"
            alt="Exchange rate chart"
            loading="lazy"
          />
          <p>
            Corridor comparing official, MEP, and blue-chip swap references with 30-day moving averages for context.
          </p>
        </div>
        <div className={styles.chartCard}>
          <h3>Inflation Scenario Bands</h3>
          <img
            src="https://images.pexels.com/photos/669610/pexels-photo-669610.jpeg?auto=compress&cs=tinysrgb&w=900"
            alt="Scenario bands illustration"
            loading="lazy"
          />
          <p>Projected CPI bands incorporating policy adjustments, energy subsidies, and global commodity trends.</p>
        </div>
      </section>
      <section className={styles.context}>
        <h2>Context: CPI & FX</h2>
        <div className={styles.contextGrid}>
          <article>
            <h3>CPI Signal</h3>
            <p>
              CPI captures price evolution across goods and services. We monitor diffusion indices to see how widespread
              price changes become across Argentina’s regions.
            </p>
          </article>
          <article>
            <h3>FX Influence</h3>
            <p>
              Currency depreciation transmits into inflation through imported goods and expectations. Our FX tracker
              alerts you when spreads widen.
            </p>
          </article>
          <article>
            <h3>Budget Translation</h3>
            <p>
              Datos verificados para planificar tu presupuesto. We translate CPI and FX moves into practical budgeting
              adjustments for households and SMEs.
            </p>
          </article>
        </div>
      </section>
      <section className={styles.faq}>
        <h2>Inflation in Argentina: FAQ</h2>
        <div className={styles.faqList}>
          {faqItems.map((item) => (
            <details key={item.question}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
};

export default Inflation;