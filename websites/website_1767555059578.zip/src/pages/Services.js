import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import styles from './Services.module.css';

const Services = () => {
  const { language } = useLanguage();

  const services = [
    {
      title: 'Inflation Dashboards',
      description:
        'Interactive CPI and ARS→USD visualizations with historical context, scenario analysis, and volatility metrics tailored for Argentina.',
    },
    {
      title: 'Personal Finance Course',
      description:
        'Step-by-step modules that guide budgeting, emergency planning, and currency decisions with Argentina-specific case studies.',
    },
    {
      title: 'Monthly Trend Briefings',
      description:
        'Curated recaps covering fiscal announcements, wage adjustments, and commodity drivers that influence inflation expectations.',
    },
    {
      title: 'Team Workshops',
      description:
        'Facilitated workshops for organizations seeking to train staff on budgeting, expense prioritization, and policy awareness.',
    },
  ];

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Services | Tu Progreso Hoy SaaS Platform</title>
        <meta
          name="description"
          content="Discover Tu Progreso Hoy services: ARS→USD analytics, inflation dashboards, personal finance education, and guided workshops."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, economic trends"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/services" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/services" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.services}>
        <h1>Our Services</h1>
        <p>
          Conocimiento financiero impulsado por tendencias. We build resources that help you interpret signals in a
          rapidly changing economy.
        </p>
        <div className={styles.grid}>
          {services.map((service) => (
            <article key={service.title} className={styles.card}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Services;