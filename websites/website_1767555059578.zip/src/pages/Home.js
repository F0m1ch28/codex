import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import styles from './Home.module.css';

const Home = () => {
  const { language, t } = useLanguage();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [errors, setErrors] = useState({});

  const content = useMemo(
    () => ({
      en: {
        heroTitle: 'Understand Argentina’s Inflation Landscape with Confidence',
        heroSubtitle:
          'Live ARS→USD insights blended with a step-by-step personal finance course designed for households and professionals in Argentina.',
        heroCta: 'Start Your Free Trial Lesson',
        heroSecondary: 'Explore Inflation Analytics',
        promisesTitle: 'Why Tu Progreso Hoy works for today’s Argentina',
        trackerIntro:
          'Monitor the peso through trustworthy signals. Our ARS→USD tracker blends official and market-based references to help you frame timely decisions.',
        insightsTitle: 'Insights and Economic Trends',
        courseTitle: 'Personal Finance Starter Course',
        courseDescription:
          'Learn to manage monthly pesos, align income to inflation realities, and plan currency transitions responsibly with scenario-based exercises.',
        testimonialsTitle: 'What learners in Argentina are saying',
        trialTitle: 'Claim your free trial lesson',
        trialSubtitle:
          'Receive a curated lesson with current ARS→USD context and budgeting tips tailored to Argentine households.',
      },
      es: {
        heroTitle: 'Comprende la inflación argentina con confianza',
        heroSubtitle:
          'Actualizaciones ARS→USD combinadas con un curso práctico de finanzas personales para familias y profesionales en Argentina.',
        heroCta: 'Solicita tu clase de prueba gratuita',
        heroSecondary: 'Ver análisis de inflación',
        promisesTitle: 'Por qué Tu Progreso Hoy funciona para la Argentina actual',
        trackerIntro:
          'Sigue el peso con señales confiables. El tracker ARS→USD integra referencias oficiales y de mercado para guiar decisiones oportunas.',
        insightsTitle: 'Insights y tendencias económicas',
        courseTitle: 'Curso Inicial de Finanzas Personales',
        courseDescription:
          'Aprende a gestionar ingresos en pesos, alinear presupuesto a la inflación y planificar conversiones de moneda con ejercicios situacionales.',
        testimonialsTitle: 'Opiniones de estudiantes en Argentina',
        trialTitle: 'Recibe tu clase de prueba gratuita',
        trialSubtitle:
          'Obtén una lección curada con contexto ARS→USD actual y consejos de presupuesto adaptados a hogares argentinos.',
      },
    }),
    []
  );

  const selected = language === 'es' ? content.es : content.en;

  const keyPromises = [
    'Datos verificados para planificar tu presupuesto.',
    'Decisiones responsables, objetivos nítidos.',
    'Conocimiento financiero impulsado por tendencias.',
    'Pasos acertados hoy, mejor futuro mañana.'
  ];

  const trackerHighlights = [
    {
      title: 'Daily ARS→USD midpoint',
      detail: 'Sourced from market observations updated every 6 hours.',
    },
    {
      title: '30-day volatility lens',
      detail: 'Visualizes historical swings to contextualize daily moves.',
    },
    {
      title: 'Forward-looking scenarios',
      detail: 'Projected paths built from energy, food, and policy signals.',
    },
  ];

  const insights = [
    {
      title: 'Budgeting for Peso Volatility',
      description:
        'Align monthly peso expenses with expected CPI updates to preserve purchasing power while paying essentials first.',
      tag: 'Budgeting Argentina',
    },
    {
      title: 'ARS Liquidity Map',
      description:
        'Track the gap between official and alternative rates to decide whether to exchange or hold cash in short windows.',
      tag: 'ARS→USD',
    },
    {
      title: 'Economic Trends Outlook',
      description:
        'Stay ahead of economic announcements, wage adjustments, and commodity shifts that influence inflation cycles.',
      tag: 'Economic Trends',
    },
  ];

  const testimonials = [
    {
      quote:
        'The dashboards keep me grounded when the peso moves fast. It helps me build realistic monthly budgets.',
      name: 'Mariana G., Córdoba',
      role: 'Small business owner',
      avatar: 'https://i.pravatar.cc/100?img=47',
    },
    {
      quote:
        'It’s the first course that speaks directly about Argentina’s challenges. The bilingual resources are a plus.',
      name: 'Diego A., Rosario',
      role: 'Freelance designer',
      avatar: 'https://i.pravatar.cc/100?img=32',
    },
    {
      quote:
        'I can finally align my salary, savings, and USD goals without guesswork. The trend alerts are excellent.',
      name: 'Lucía M., Buenos Aires',
      role: 'HR analyst',
      avatar: 'https://i.pravatar.cc/100?img=12',
    },
  ];

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    const sanitized = value.replace(/[<>]/g, '');
    setFormData((prev) => ({ ...prev, [name]: sanitized }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = language === 'es' ? 'Ingresa tu nombre.' : 'Please enter your name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = language === 'es' ? 'Ingresa tu email.' : 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = language === 'es' ? 'Email no válido.' : 'Please enter a valid email.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      navigate('/thank-you');
    }
  };

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Tu Progreso Hoy | Argentina Inflation Analytics & Personal Finance Course</title>
        <meta
          name="description"
          content="Monitor argentina inflation, track ARS to USD dynamics, and follow a personal finance starter course designed for Argentina."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, economic trends, datos confiables"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/es" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>{selected.heroTitle}</h1>
          <p>{selected.heroSubtitle}</p>
          <div className={styles.heroActions}>
            <button type="button" className={styles.primaryButton} onClick={() => document.getElementById('trial-form').scrollIntoView({ behavior: 'smooth' })}>
              {selected.heroCta}
            </button>
            <Link to="/inflation" className={styles.secondaryButton}>
              {selected.heroSecondary}
            </Link>
          </div>
          <div className={styles.heroStats}>
            <div>
              <span>ARS→USD</span>
              <strong>LER 842.5</strong>
              <small>Last 24h midpoint</small>
            </div>
            <div>
              <span>Inflation YoY</span>
              <strong>209%</strong>
              <small>Projected CPI (central)</small>
            </div>
            <div>
              <span>Course Members</span>
              <strong>2,350+</strong>
              <small>Argentina-wide learners</small>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.promises}>
        <header>
          <h2>{selected.promisesTitle}</h2>
        </header>
        <div className={styles.promiseGrid}>
          {keyPromises.map((promise) => (
            <article key={promise} className={styles.promiseCard}>
              <p>{promise}</p>
            </article>
          ))}
          <article className={styles.promiseCardAlt}>
            <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
          </article>
        </div>
      </section>

      <section className={styles.tracker} id="tracker">
        <div className={styles.trackerText}>
          <h2>ARS→USD Tracker</h2>
          <p>{selected.trackerIntro}</p>
          <ul className={styles.trackerList}>
            {trackerHighlights.map((item) => (
              <li key={item.title}>
                <strong>{item.title}</strong>
                <span>{item.detail}</span>
              </li>
            ))}
          </ul>
          <p className={styles.trackerDisclaimer}>
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.
          </p>
        </div>
        <div className={styles.chartCard} aria-hidden="true">
          <svg viewBox="0 0 400 220" className={styles.chartSvg}>
            <defs>
              <linearGradient id="lineGradient" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="#2563EB" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#2563EB" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path
              d="M10 180 C 70 120, 110 140, 150 100 S 230 60, 270 110 S 340 160, 390 80"
              stroke="#2563EB"
              strokeWidth="4"
              fill="none"
            />
            <path
              d="M10 200 C 70 140, 110 160, 150 120 S 230 80, 270 130 S 340 180, 390 100 L 390 210 L 10 210 Z"
              fill="url(#lineGradient)"
            />
            <text x="12" y="24" fill="#0F172A" fontSize="18" fontFamily="DM Sans">
              Daily ARS→USD Dynamics
            </text>
          </svg>
          <div className={styles.chartLegend}>
            <span className={styles.legendDot} />
            <span>Illustrative path blending official + market signals</span>
          </div>
        </div>
      </section>

      <section className={styles.insights}>
        <header>
          <h2>{selected.insightsTitle}</h2>
          <p>Información confiable que respalda elecciones responsables sobre tu dinero.</p>
        </header>
        <div className={styles.insightsGrid}>
          {insights.map((insight) => (
            <article key={insight.title} className={styles.insightCard}>
              <span className={styles.insightTag}>{insight.tag}</span>
              <h3>{insight.title}</h3>
              <p>{insight.description}</p>
              <button type="button" className={styles.learnMore} aria-label={"Learn more about ${insight.title}"}>
                Learn more →
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.course}>
        <div className={styles.courseIntro}>
          <h2>{selected.courseTitle}</h2>
          <p>{selected.courseDescription}</p>
          <ul className={styles.courseList}>
            <li>
              <strong>Module 1:</strong> Budgeting Argentina — build resilient household budgets.
            </li>
            <li>
              <strong>Module 2:</strong> ARS/USD Scenarios — interpret FX moves and plan conversions.
            </li>
            <li>
              <strong>Module 3:</strong> Inflation Playbook — align spending with CPI calendars.
            </li>
            <li>
              <strong>Module 4:</strong> Savings & Safeguards — evaluate peso and dollar-based options.
            </li>
          </ul>
          <Link to="/course" className={styles.primaryButton}>
            View full course overview
          </Link>
        </div>
        <div className={styles.courseMedia}>
          <img
            src="https://images.pexels.com/photos/8296973/pexels-photo-8296973.jpeg?auto=compress&cs=tinysrgb&w=800"
            alt="Dashboard showing Argentina inflation analytics"
            loading="lazy"
          />
          <p>Plataforma educativa con datos esenciales, sin asesoría financiera directa.</p>
        </div>
      </section>

      <section className={styles.testimonials}>
        <header>
          <h2>{selected.testimonialsTitle}</h2>
          <p>De la información al aprendizaje: fortalece tu criterio financiero paso a paso.</p>
        </header>
        <div className={styles.testimonialGrid}>
          {testimonials.map((item) => (
            <article key={item.name} className={styles.testimonialCard}>
              <p className={styles.quote}>“{item.quote}”</p>
              <div className={styles.person}>
                <img src={item.avatar} alt={"Portrait of ${item.name}"} loading="lazy" />
                <div>
                  <strong>{item.name}</strong>
                  <span>{item.role}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.trial} id="trial-form">
        <div className={styles.trialContent}>
          <h2>{selected.trialTitle}</h2>
          <p>{selected.trialSubtitle}</p>
          <form className={styles.trialForm} onSubmit={handleSubmit} noValidate>
            <label htmlFor="trial-name">
              {language === 'es' ? 'Nombre' : 'Name'}
              <input
                id="trial-name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleInputChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby="trial-name-error"
              />
              {errors.name && (
                <span id="trial-name-error" className={styles.errorText}>
                  {errors.name}
                </span>
              )}
            </label>
            <label htmlFor="trial-email">
              Email
              <input
                id="trial-email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby="trial-email-error"
              />
              {errors.email && (
                <span id="trial-email-error" className={styles.errorText}>
                  {errors.email}
                </span>
              )}
            </label>
            <button type="submit" className={styles.primaryButton}>
              {language === 'es' ? 'Enviar' : 'Submit'}
            </button>
          </form>
          <small className={styles.disclaimer}>
            We do not provide financial services. / No proporcionamos servicios financieros.
          </small>
        </div>
      </section>
    </>
  );
};

export default Home;