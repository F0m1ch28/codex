import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicy = () => {
  const { language } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Privacy Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Read the privacy policy of Tu Progreso Hoy to understand how we collect, use, and protect your data."
        />
        <meta
          name="keywords"
          content="privacy, argentina inflation, educational SaaS, personal finance course"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/privacy" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/privacy" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.privacy}>
        <h1>Privacy Policy</h1>
        <p>Effective date: January 2024</p>
        <p>
          This Privacy Policy explains how Tu Progreso Hoy collects, uses, and protects the information that you share
          with us. By accessing our services, you agree to the practices outlined below.
        </p>
        <h2>Information We Collect</h2>
        <ul>
          <li>Account details such as name and email address.</li>
          <li>Usage metrics, including pages visited and preferred language, via analytics cookies.</li>
          <li>Communications sent to our team via contact forms.</li>
        </ul>
        <h2>How We Use Information</h2>
        <ul>
          <li>To deliver dashboards, lessons, and notifications relevant to your subscription.</li>
          <li>To improve product features and monitor platform performance.</li>
          <li>To respond to support inquiries and service requests.</li>
        </ul>
        <h2>Cookies</h2>
        <p>
          We use cookies to remember language preferences, maintain sessions, and analyze aggregated usage. You can
          manage cookie consent using the banner provided on the site.
        </p>
        <h2>Data Security</h2>
        <p>
          We implement industry-standard encryption and monitoring. While we strive to protect your information, no
          method is completely secure, and you use the services at your own risk.
        </p>
        <h2>Data Rights</h2>
        <p>
          Users can request access, correction, or deletion of personal data by emailing
          contact@tuprogresohoy.com. We respond within 30 days.
        </p>
        <h2>International Data Transfers</h2>
        <p>
          Our servers may be located outside Argentina. By using the service, you consent to processing in jurisdictions
          that may have different data protection rules.
        </p>
        <h2>Updates</h2>
        <p>
          We may update this policy periodically. Changes will be posted on this page, and the effective date will
          reflect the latest revision.
        </p>
      </section>
    </>
  );
};

export default PrivacyPolicy;