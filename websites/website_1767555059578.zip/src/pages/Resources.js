import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import styles from './Resources.module.css';

const Resources = () => {
  const { language } = useLanguage();

  const items = [
    {
      title: 'Weekly Inflation Brief',
      description: 'Digest inflation announcements and market reactions affecting ARS purchasing power.',
      tag: 'EN',
    },
    {
      title: 'Glosario de finanzas personales',
      description: 'Conceptos clave para interpretar la inflación y el ahorro en Argentina.',
      tag: 'ES',
    },
    {
      title: 'FX Planning Checklist',
      description: 'Step-by-step questions before converting pesos to dollars.',
      tag: 'EN',
    },
    {
      title: 'Budget Template (Peso focus)',
      description: 'Plan monthly expenses with CPI-adjusted categories.',
      tag: 'EN',
    },
    {
      title: 'Tendencias económicas mensuales',
      description: 'Resumen de indicadores macro y expectativas para el próximo mes.',
      tag: 'ES',
    },
    {
      title: 'Emergency Fund Guide',
      description: 'Build and maintain a buffer that accounts for peso volatility.',
      tag: 'EN',
    },
  ];

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Resources | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Access bilingual resources, glossaries, and guides for Argentina inflation analysis and personal finance planning."
        />
        <meta
          name="keywords"
          content="finanzas personales, curso finanzas, argentina inflation, datos confiables, economic trends"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/resources" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/resources" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.resources}>
        <h1>Resource Library</h1>
        <p>Conocimiento financiero impulsado por tendencias. Explore bilingual guides crafted for Argentina.</p>
        <div className={styles.grid}>
          {items.map((item) => (
            <article key={item.title} className={styles.card}>
              <span className={styles.tag}>{item.tag}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <button type="button" className={styles.linkButton} aria-label={"Open resource ${item.title}"}>
                Open resource →
              </button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Resources;