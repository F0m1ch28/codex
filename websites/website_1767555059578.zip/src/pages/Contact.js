import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';
import { useLanguage } from '../context/LanguageContext';

const Contact = () => {
  const { language } = useLanguage();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const labels = {
    name: language === 'es' ? 'Nombre' : 'Name',
    email: 'Email',
    message: language === 'es' ? 'Mensaje' : 'Message',
    submit: language === 'es' ? 'Enviar mensaje' : 'Send message',
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = language === 'es' ? 'Ingresa tu nombre.' : 'Please enter your name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = language === 'es' ? 'Ingresa tu email.' : 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = language === 'es' ? 'Email no válido.' : 'Please enter a valid email.';
    }
    if (!formData.message.trim()) {
      newErrors.message = language === 'es' ? 'Ingresa un mensaje.' : 'Please enter a message.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    const sanitized = value.replace(/[<>]/g, '');
    setFormData((prev) => ({ ...prev, [name]: sanitized }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setSubmitted(false), 5000);
    }
  };

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Contact Tu Progreso Hoy | Argentina SaaS Platform</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy to learn about Argentina-focused inflation analytics, ARS to USD data, and personal finance education."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, datos confiables"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/contact" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/contact" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.contact}>
        <div className={styles.info}>
          <h1>Contact Us</h1>
          <p>
            Connect with our team to discuss data access, course enrollments, or partnership opportunities. We respond
            within one business day.
          </p>
          <div className={styles.details}>
            <p>
              <strong>Address:</strong> Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            </p>
            <p>
              <strong>Phone:</strong>{' '}
              <a href="tel:+541155551234" className={styles.link}>
                +54 11 5555-1234
              </a>
            </p>
            <p>
              <strong>Email:</strong>{' '}
              <a href="mailto:contact@tuprogresohoy.com" className={styles.link}>
                contact@tuprogresohoy.com
              </a>
            </p>
          </div>
          <div className={styles.mapWrapper}>
            <iframe
              title="Tu Progreso Hoy office map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.471111369416!2d-58.3809969227998!3d-34.602236557601716!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccadf40b0ef47%3A0x25debf843a95e6f9!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="contact-name">
            {labels.name}
            <input
              id="contact-name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.errorText}>{errors.name}</span>}
          </label>
          <label htmlFor="contact-email">
            {labels.email}
            <input
              id="contact-email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.errorText}>{errors.email}</span>}
          </label>
          <label htmlFor="contact-message">
            {labels.message}
            <textarea
              id="contact-message"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.errorText}>{errors.message}</span>}
          </label>
          <button type="submit" className={styles.submitButton}>
            {labels.submit}
          </button>
          {submitted && (
            <p className={styles.successMessage}>
              {language === 'es' ? 'Mensaje enviado. Te responderemos pronto.' : 'Message sent. We will reply soon.'}
            </p>
          )}
        </form>
      </section>
    </>
  );
};

export default Contact;