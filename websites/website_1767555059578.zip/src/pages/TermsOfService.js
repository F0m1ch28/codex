import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import styles from './TermsOfService.module.css';

const TermsOfService = () => {
  const { language } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Terms of Service | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Review the terms of service for Tu Progreso Hoy, the educational SaaS focused on Argentina inflation analytics."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, educational SaaS, terms"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/terms" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/terms" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.terms}>
        <h1>Terms of Service</h1>
        <p>
          These Terms of Service govern the use of Tu Progreso Hoy (“we”, “our”, “us”) and all related products,
          dashboards, and educational materials. By accessing the platform you agree to these terms.
        </p>
        <h2>1. Platform Purpose</h2>
        <p>
          Tu Progreso Hoy provides educational content and data visualizations designed to help users interpret
          Argentina’s inflation and ARS→USD dynamics. Platform educativa con datos esenciales, sin asesoría financiera
          directa.
        </p>
        <h2>2. Eligibility</h2>
        <p>
          You must be at least 18 years old to use the service or have the consent of a guardian. By using the platform,
          you confirm that information provided to us is accurate.
        </p>
        <h2>3. Account Responsibilities</h2>
        <p>
          Users are responsible for maintaining the confidentiality of access credentials. Any activity under your
          account is your responsibility. Notify us immediately about unauthorized use.
        </p>
        <h2>4. Data Usage and Limitations</h2>
        <p>
          Content, charts, and downloadable assets are provided for personal or internal business decisions. You may not
          resell or redistribute our content without written consent.
        </p>
        <h2>5. No Financial Advice</h2>
        <p>
          Datos verificados para planificar tu presupuesto. However, our service does not offer individualized financial,
          legal, or investment advice. We do not provide financial services.
        </p>
        <h2>6. Termination</h2>
        <p>
          We may suspend or terminate access if you violate these terms or use the platform in a way that could harm
          other users or our services.
        </p>
        <h2>7. Changes to Terms</h2>
        <p>
          We reserve the right to update the Terms of Service. Continued use after changes indicates acceptance of the
          revised terms.
        </p>
        <h2>8. Contact</h2>
        <p>For questions about these terms, email us at contact@tuprogresohoy.com.</p>
      </section>
    </>
  );
};

export default TermsOfService;