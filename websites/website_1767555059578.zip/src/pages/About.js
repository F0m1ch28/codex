import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import styles from './About.module.css';

const About = () => {
  const { language } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>About Tu Progreso Hoy | Argentina-focused SaaS</title>
        <meta
          name="description"
          content="Learn about Tu Progreso Hoy, the Argentina-focused analytics and education SaaS offering inflation data and personal finance training."
        />
        <meta
          name="keywords"
          content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, datos confiables"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/about" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/about" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.about}>
        <div className={styles.content}>
          <h1>About Tu Progreso Hoy</h1>
          <p>
            Tu Progreso Hoy began as a data observatory built by analysts determined to decode Argentina’s inflation
            and foreign exchange landscape. We combine rigorous quantitative research with approachable education so
            that every household and business can make informed decisions.
          </p>
          <p>
            Our team curates official CPI releases, alternative FX signals, and market sentiment to deliver timely
            dashboards. Each dataset is paired with digestible lessons that encourage responsible financial planning.
          </p>
          <div className={styles.values}>
            <article>
              <h3>Transparency</h3>
              <p>
                Every chart is accompanied by methodology notes and clear data sources. We embrace clarity over hype.
              </p>
            </article>
            <article>
              <h3>Local Perspective</h3>
              <p>
                We are based in Buenos Aires and serve Argentina exclusively, capturing nuances other global platforms
                miss.
              </p>
            </article>
            <article>
              <h3>Education First</h3>
              <p>
                Our mission is to elevate financial literacy. Platform educativa con datos esenciales, sin asesoría
                financiera directa.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;