import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYou = () => {
  const { language } = useLanguage();
  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Thank You | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Thank you page for Tu Progreso Hoy free trial lesson registration."
        />
        <meta
          name="keywords"
          content="argentina inflation, personal finance course, finanzas personales"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/thank-you" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/thank-you" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.thankYou}>
        <div className={styles.card}>
          <h1>Thank you for your interest!</h1>
          <h2>¡Gracias por tu interés!</h2>
          <p>
            Your free trial lesson will be delivered to your email shortly. Check your inbox and spam folder, and add
            contact@tuprogresohoy.com to your trusted list.
          </p>
          <Link to="/" className={styles.backLink}>
            ← Back to home
          </Link>
        </div>
      </section>
    </>
  );
};

export default ThankYou;