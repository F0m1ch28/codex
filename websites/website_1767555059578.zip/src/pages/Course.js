import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import styles from './Course.module.css';

const Course = () => {
  const { language } = useLanguage();

  const modules = [
    {
      title: 'Module 1: Budgeting Fundamentals',
      description:
        'Build a peso-based budget that responds to inflation cycles, with templates for salary earners and freelancers.',
      outcomes: ['Set monthly essentials', 'Prioritize high-impact expenses', 'Create buffer zones'],
    },
    {
      title: 'Module 2: ARS→USD & Inflation Navigation',
      description:
        'Interpret currency moves, map FX spreads, and decide when to convert pesos responsibly.',
      outcomes: ['Understand rate corridors', 'Stress-test conversion plans', 'Track liquidity signals'],
    },
    {
      title: 'Module 3: Saving Anchors',
      description:
        'Deploy emergency buffers, short-term dollar strategies, and peso instruments aligned to goals.',
      outcomes: ['Align goals with timelines', 'Balance liquidity and growth', 'Understand risk disclosures'],
    },
    {
      title: 'Module 4: Future Planning',
      description:
        'Transform macro insights into actionable plans for families, entrepreneurs, and professionals.',
      outcomes: ['Design milestone budgets', 'Build accountability rituals', 'Monitor trend dashboards'],
    },
  ];

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Personal Finance Starter Course | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Discover the Tu Progreso Hoy personal finance starter course designed for Argentina with modules on budgeting, ARS to USD, and inflation planning."
        />
        <meta
          name="keywords"
          content="curso finanzas, finanzas personales, argentina inflation, ars usd, budgeting argentina"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/course" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/course" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Personal Finance Starter Course</h1>
        <p>
          Designed for individuals and teams who want to bridge daily ARS realities with long-term objectives. Pasos
          acertados hoy, mejor futuro mañana.
        </p>
      </section>
      <section className={styles.modules}>
        {modules.map((module) => (
          <article key={module.title} className={styles.moduleCard}>
            <h2>{module.title}</h2>
            <p>{module.description}</p>
            <ul>
              {module.outcomes.map((outcome) => (
                <li key={outcome}>{outcome}</li>
              ))}
            </ul>
          </article>
        ))}
      </section>
      <section className={styles.callToAction}>
        <h2>Ready to start learning?</h2>
        <p>
          From datos confiables to practical exercises, the course guides you to strengthen financial decision-making in
          Argentina.
        </p>
        <Link to="/#trial-form" className={styles.ctaButton}>
          Go to free trial lesson form
        </Link>
      </section>
    </>
  );
};

export default Course;