import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '../context/LanguageContext';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  const { language } = useLanguage();

  return (
    <>
      <Helmet>
        <html lang={language === 'es' ? 'es-AR' : 'en'} />
        <title>Cookie Policy | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Learn how Tu Progreso Hoy uses cookies to improve user experience and analytics."
        />
        <meta
          name="keywords"
          content="cookie policy, argentina SaaS, analytics"
        />
        <link rel="alternate" href="https://tuprogresohoy.com/cookies" hrefLang="en" />
        <link rel="alternate" href="https://tuprogresohoy.com/cookies" hrefLang="es-AR" />
      </Helmet>
      <section className={styles.cookies}>
        <h1>Cookie Policy</h1>
        <p>Last updated: January 2024</p>
        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device to improve user experience. We categorize cookies into
          essential, preference, and analytics types.
        </p>
        <h2>How We Use Cookies</h2>
        <ul>
          <li>Essential cookies maintain session integrity and protect login flows.</li>
          <li>Preference cookies remember your language selection (English or Spanish).</li>
          <li>
            Analytics cookies provide aggregated insights about page usage to help us refine dashboards and lessons.
          </li>
        </ul>
        <h2>Managing Consent</h2>
        <p>
          Use the cookie banner to accept or customize preferences. You can also clear cookies through your browser settings.
        </p>
        <h2>Third-Party Services</h2>
        <p>
          We may use privacy-focused analytics providers. Data is anonymized and stored securely with strict access
          controls.
        </p>
        <h2>Contact</h2>
        <p>Questions about this policy? Email contact@tuprogresohoy.com.</p>
      </section>
    </>
  );
};

export default CookiePolicy;