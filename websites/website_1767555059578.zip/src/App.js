import React, { useEffect, useState } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import DisclaimerModal from './components/DisclaimerModal';
import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import CookiePolicy from './pages/CookiePolicy';
import About from './pages/About';
import Services from './pages/Services';
import styles from './App.module.css';

const App = () => {
  const location = useLocation();
  const [isDisclaimerOpen, setIsDisclaimerOpen] = useState(false);

  useEffect(() => {
    const acknowledged = localStorage.getItem('tph_disclaimer_ack');
    if (!acknowledged) {
      setIsDisclaimerOpen(true);
    }
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const handleOpenDisclaimer = () => {
    setIsDisclaimerOpen(true);
  };

  const handleCloseDisclaimer = () => {
    localStorage.setItem('tph_disclaimer_ack', 'true');
    setIsDisclaimerOpen(false);
  };

  return (
    <div className={styles.appShell}>
      <Header onOpenDisclaimer={handleOpenDisclaimer} />
      <main className={styles.mainContent} role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/inflation" element={<Inflation />} />
          <Route path="/course" element={<Course />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/terms" element={<TermsOfService />} />
          <Route path="/cookies" element={<CookiePolicy />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
        </Routes>
      </main>
      <Footer onOpenDisclaimer={handleOpenDisclaimer} />
      <CookieBanner />
      <ScrollToTopButton />
      <DisclaimerModal isOpen={isDisclaimerOpen} onClose={handleCloseDisclaimer} />
    </div>
  );
};

export default App;