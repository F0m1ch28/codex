import React from 'react';
import styles from './DisclaimerModal.module.css';

const DisclaimerModal = ({ isOpen, onClose }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className={styles.overlay} role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className={styles.modal}>
        <h2 id="disclaimer-title">Disclaimer</h2>
        <p>We do not provide financial services.</p>
        <p>No proporcionamos servicios financieros.</p>
        <p>Мы не предоставляем финансовые услуги.</p>
        <button type="button" className={styles.closeButton} onClick={onClose} aria-label="Close disclaimer modal">
          I Understand / Entiendo
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;