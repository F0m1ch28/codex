import React from 'react';
import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import styles from './Footer.module.css';

const Footer = ({ onOpenDisclaimer }) => {
  const { t } = useLanguage();

  return (
    <footer className={styles.footer}>
      <div className={styles.top}>
        <div className={styles.brand}>
          <h3>Tu Progreso Hoy</h3>
          <p>
            Argentina-focused analytics and learning to help you interpret economic signals with clarity and confidence.
          </p>
        </div>
        <div className={styles.columns}>
          <div>
            <h4>{t('footerNavigate')}</h4>
            <NavLink to="/" className={styles.link}>
              {t('navHome')}
            </NavLink>
            <NavLink to="/inflation" className={styles.link}>
              {t('navInflation')}
            </NavLink>
            <NavLink to="/course" className={styles.link}>
              {t('navCourse')}
            </NavLink>
            <NavLink to="/resources" className={styles.link}>
              {t('navResources')}
            </NavLink>
            <NavLink to="/contact" className={styles.link}>
              {t('navContact')}
            </NavLink>
          </div>
          <div>
            <h4>{t('footerCompany')}</h4>
            <NavLink to="/about" className={styles.link}>
              {t('footerAbout')}
            </NavLink>
            <NavLink to="/services" className={styles.link}>
              {t('footerServices')}
            </NavLink>
            <button type="button" className={styles.linkButton} onClick={onOpenDisclaimer}>
              {t('navDisclaimer')}
            </button>
            <NavLink to="/privacy" className={styles.link}>
              {t('footerPrivacy')}
            </NavLink>
            <NavLink to="/terms" className={styles.link}>
              {t('footerTerms')}
            </NavLink>
            <NavLink to="/cookies" className={styles.link}>
              {t('footerCookies')}
            </NavLink>
          </div>
          <div>
            <h4>{t('footerContact')}</h4>
            <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
            <p>
              <a className={styles.link} href="tel:+541155551234">
                +54 11 5555-1234
              </a>
            </p>
            <p>
              <a className={styles.link} href="mailto:contact@tuprogresohoy.com">
                contact@tuprogresohoy.com
              </a>
            </p>
            <div className={styles.socials}>
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                className={styles.socialLink}
              >
                in
              </a>
              <a
                href="https://www.twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Twitter"
                className={styles.socialLink}
              >
                X
              </a>
              <a
                href="https://www.youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube"
                className={styles.socialLink}
              >
                ▶
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <small>We do not provide financial services. | No proporcionamos servicios financieros.</small>
        <small>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</small>
      </div>
    </footer>
  );
};

export default Footer;