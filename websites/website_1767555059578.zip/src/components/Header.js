import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import styles from './Header.module.css';

const Header = ({ onOpenDisclaimer }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const { language, toggleLanguage, t } = useLanguage();

  const handleToggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Tu Progreso Hoy logo">
          <span className={styles.logoAccent}>Tu</span> Progreso Hoy
        </NavLink>
        <button
          className={styles.menuToggle}
          onClick={handleToggleMenu}
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
        >
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
        </button>
        <nav className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"} aria-label="Main navigation">
          <NavLink to="/" className={({ isActive }) => (isActive ? styles.activeLink : styles.link)} onClick={closeMenu}>
            {t('navHome')}
          </NavLink>
          <NavLink
            to="/inflation"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeMenu}
          >
            {t('navInflation')}
          </NavLink>
          <NavLink
            to="/course"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeMenu}
          >
            {t('navCourse')}
          </NavLink>
          <NavLink
            to="/resources"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeMenu}
          >
            {t('navResources')}
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
            onClick={closeMenu}
          >
            {t('navContact')}
          </NavLink>
          <button
            type="button"
            className={styles.disclaimerButton}
            onClick={() => {
              onOpenDisclaimer();
              closeMenu();
            }}
          >
            {t('navDisclaimer')}
          </button>
          <button
            type="button"
            className={styles.langToggle}
            onClick={toggleLanguage}
            aria-label="Toggle language between English and Spanish"
          >
            {language === 'en' ? 'ES' : 'EN'}
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;