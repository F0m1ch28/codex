import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedConsent = localStorage.getItem('tph_cookie_consent');
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('tph_cookie_consent', 'accepted');
    setVisible(false);
  };

  const handleLearnMore = () => {
    navigate('/cookies');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <strong>Cookies Notice:</strong> We use cookies to analyze traffic and improve your experience. Read our policy
        for detailed information.
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.learnButton} onClick={handleLearnMore}>
          Customize / Learn More
        </button>
        <button type="button" className={styles.acceptButton} onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;