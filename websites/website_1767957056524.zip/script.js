document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('is-open');
        });
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('is-open');
            });
        });
    }

    const regionFilter = document.getElementById('region-filter');
    const sectorFilter = document.getElementById('sector-filter');
    const keywordInput = document.getElementById('investment-keyword');
    const serviceCards = document.querySelectorAll('[data-region][data-sector]');

    const filterServices = () => {
        serviceCards.forEach(card => {
            const region = card.dataset.region;
            const sector = card.dataset.sector;
            const matchesRegion = !regionFilter || regionFilter.value === 'all' || region === regionFilter.value;
            const matchesSector = !sectorFilter || sectorFilter.value === 'all' || sector === sectorFilter.value;
            const keyword = keywordInput ? keywordInput.value.trim().toLowerCase() : '';
            const matchesKeyword = !keyword || card.textContent.toLowerCase().includes(keyword);
            if (matchesRegion && matchesSector && matchesKeyword) {
                card.classList.remove('is-hidden');
            } else {
                card.classList.add('is-hidden');
            }
        });
    };

    regionFilter?.addEventListener('change', filterServices);
    sectorFilter?.addEventListener('change', filterServices);
    keywordInput?.addEventListener('input', filterServices);

    const roiForm = document.getElementById('roi-calculator-form');
    if (roiForm) {
        const capitalInput = document.getElementById('roi-capital');
        const durationInput = document.getElementById('roi-duration');
        const growthInput = document.getElementById('roi-growth');
        const riskInput = document.getElementById('roi-risk');
        const output = document.getElementById('roi-output');

        const calculateRoi = () => {
            const capital = parseFloat(capitalInput.value) || 0;
            const duration = parseInt(durationInput.value, 10) || 0;
            const growthRate = parseFloat(growthInput.value) || 0;
            const riskFactor = parseFloat(riskInput.value) || 0;

            if (capital <= 0 || duration <= 0) {
                output.innerHTML = '<p>Enter a starting allocation and investment horizon to model performance.</p>';
                return;
            }

            const futureValue = capital * Math.pow(1 + growthRate / 100, duration);
            const riskAdjusted = futureValue * (1 - riskFactor / 100);
            const compoundedAnnual = (Math.pow(futureValue / capital, 1 / duration) - 1) * 100;

            output.innerHTML = `
                <p>Projected Portfolio Value: <strong>${futureValue.toLocaleString('en-US', { maximumFractionDigits: 2 })}</strong></p>
                <p>Risk-Adjusted Scenario: <strong>${riskAdjusted.toLocaleString('en-US', { maximumFractionDigits: 2 })}</strong></p>
                <p>Average Annualised Return: <strong>${compoundedAnnual.toFixed(2)}%</strong></p>
                <p style="margin-top:1rem;font-size:0.9rem;">Outcomes are indicative and assume reinvestment. Stress scenarios account for qualitative risk ratings.</p>
            `;
        };

        roiForm.addEventListener('input', calculateRoi);
        calculateRoi();
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('brisrvsb_cookie_consent');
        if (!storedConsent) {
            cookieBanner.classList.add('is-visible');
        }

        cookieBanner.querySelectorAll('.cookie-action').forEach(action => {
            action.addEventListener('click', event => {
                event.preventDefault();
                const choice = action.dataset.choice || 'accept';
                localStorage.setItem('brisrvsb_cookie_consent', choice);
                cookieBanner.classList.remove('is-visible');
                setTimeout(() => {
                    window.location.href = action.getAttribute('href');
                }, 150);
            });
        });

        const cookieClose = cookieBanner.querySelector('.cookie-close');
        cookieClose?.addEventListener('click', () => {
            cookieBanner.classList.remove('is-visible');
        });
    }
});