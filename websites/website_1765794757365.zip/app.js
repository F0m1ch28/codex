(() => {
  const banner = document.querySelector("[data-cookie-banner]");
  if (banner) {
    const acceptBtn = banner.querySelector("[data-cookie-accept]");
    const declineBtn = banner.querySelector("[data-cookie-decline]");
    const cookiePreference = localStorage.getItem("cce-cookie-consent");

    if (!cookiePreference) {
      requestAnimationFrame(() => banner.classList.add("visible"));
    }

    const closeBanner = (value) => {
      localStorage.setItem("cce-cookie-consent", value);
      banner.classList.remove("visible");
    };

    acceptBtn?.addEventListener("click", () => closeBanner("accepted"));
    declineBtn?.addEventListener("click", () => closeBanner("declined"));
  }

  const planButtons = document.querySelectorAll("[data-plan-select]");
  const planSummaryName = document.querySelector("[data-plan-name]");
  const planSummaryDeposit = document.querySelector("[data-plan-deposit]");
  const planSummaryHash = document.querySelector("[data-plan-hash]");
  const planSummaryYield = document.querySelector("[data-plan-yield]");
  const customInput = document.querySelector("[data-plan-custom]");
  const walletDisplay = document.querySelector("[data-wallet-display]");

  const computeHashPower = (deposit) => {
    const baseHash = 120;
    const factor = 8;
    return Math.round(baseHash + deposit * factor);
  };

  const computeDailyYield = (hashPower) => {
    const baseline = 0.004;
    return (hashPower * baseline).toFixed(3);
  };

  const updateSummary = (label, amount) => {
    const numericAmount = Math.max(parseFloat(amount) || 0, 0);
    const hashPower = computeHashPower(numericAmount);
    const dailyYield = computeDailyYield(hashPower);

    if (planSummaryName) planSummaryName.textContent = label;
    if (planSummaryDeposit) planSummaryDeposit.textContent = `${numericAmount.toFixed(2)} USDT`;
    if (planSummaryHash) planSummaryHash.textContent = `${hashPower.toLocaleString()} H/s`;
    if (planSummaryYield) planSummaryYield.textContent = `${dailyYield} coins / 24h`;
    if (walletDisplay) walletDisplay.classList.remove("hidden");
  };

  planButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const label = btn.getAttribute("data-plan-label") ?? "Custom Plan";
      const amount = btn.getAttribute("data-plan-amount") ?? "0";
      if (customInput) customInput.value = "";
      updateSummary(label, amount);
      planButtons.forEach((b) => b.classList.remove("plan-active"));
      btn.classList.add("plan-active");
    });
  });

  if (customInput) {
    customInput.addEventListener("input", (event) => {
      const amount = event.target.value;
      updateSummary("Custom Activation", amount);
      planButtons.forEach((b) => b.classList.remove("plan-active"));
    });
  }

  const registrationForm = document.querySelector("[data-registration-form]");
  const registrationMessage = document.querySelector("[data-registration-message]");

  if (registrationForm && registrationMessage) {
    registrationForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(registrationForm);
      const deposit = parseFloat(formData.get("deposit-amount") || "0");
      if (!deposit || deposit < 10) {
        registrationMessage.className = "error-message";
        registrationMessage.textContent = "Minimum deposit for activation is 10 USDT (TRC20). Please adjust your amount.";
        return;
      }
      registrationMessage.className = "success-message";
      registrationMessage.innerHTML = `Thank you, ${formData.get("full-name")}. Your preliminary allocation of <strong>${computeHashPower(deposit)} H/s</strong> is reserved. Complete your deposit to unlock full extraction speed.`;
      registrationForm.reset();
    });
  }

  const refreshButton = document.querySelector("[data-refresh-stats]");
  const hashBalance = document.querySelector("[data-hash-balance]");
  const totalMined = document.querySelector("[data-total-mined]");
  const nextPayout = document.querySelector("[data-next-payout]");
  const progressBar = document.querySelector("[data-progress]");

  if (refreshButton && hashBalance && totalMined && nextPayout && progressBar) {
    const refreshStats = () => {
      const baseHash = 1840 + Math.random() * 360;
      const mined = 0.842 + Math.random() * 0.27;
      const payoutTime = Math.floor(4 + Math.random() * 12);
      const progress = Math.floor(50 + Math.random() * 45);

      hashBalance.textContent = `${Math.round(baseHash)} H/s`;
      totalMined.textContent = `${mined.toFixed(3)} coins`;
      nextPayout.textContent = `${payoutTime} hours`;
      progressBar.style.width = `${progress}%`;
    };

    refreshButton.addEventListener("click", () => {
      refreshButton.disabled = true;
      refreshButton.textContent = "Syncing…";
      setTimeout(() => {
        refreshStats();
        refreshButton.disabled = false;
        refreshButton.textContent = "Refresh Extraction Data";
      }, 1000 + Math.random() * 600);
    });

    refreshStats();
  }
})();