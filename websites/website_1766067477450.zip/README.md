# Aurora Innovate Experience Platform

Aurora Innovate is a multi-page, fully responsive website showcasing an intelligent experience design studio. The project includes adaptive layouts, accessible navigation, responsive Pexels imagery, and a reusable cookie consent system stored in `localStorage`.

## Structure
- `index.html` – overview and highlights
- `solutions.html` – platform capabilities
- `vision.html` – culture and commitments
- `contact.html` – partnership desk and form
- `policy.html`, `terms.html`, `faq.html` – required compliance pages
- `styles.css` with modular, responsive design rules
- `script.js` handling navigation and cookie preferences
- Additional JSON assets (`assets/data/`) and utilities CSS for scalability

## Features
- Clean semantic HTML, consistent navigation, and footer across pages
- Responsive typography using `clamp()` and mobile-centered text alignments
- `<picture>` elements with unique Pexels imagery and complete `srcset`
- Cookie banner present on every page with Accept/Reject/Customize options
- `localStorage` persistence for consent selections
- Sitemap, robots directives, manifest, and favicon descriptors included

## Getting Started
Open `index.html` in your browser or serve the project directory through a local server for best results. Customize content, colors, or assets via `styles.css` and `assets/data` as needed.

## Development Notes
- Update `robots.txt` and `sitemap.xml` with your production domain before deployment.
- Replace the favicon description with binary assets prior to launch.
- Review consent logic in `script.js` to integrate analytics or marketing scripts conditionally.

Happy launching!