(() => {
  const STORAGE_KEY = 'auroraInnovateCookieConsent';

  const applyPreferences = (banner, preferences) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
    banner.classList.remove('is-visible');
    setTimeout(() => {
      banner.hidden = true;
    }, 280);
    document.documentElement.dataset.analytics = preferences.analytics ? 'allowed' : 'blocked';
    document.documentElement.dataset.marketing = preferences.marketing ? 'allowed' : 'blocked';
  };

  const revealBanner = (banner) => {
    banner.hidden = false;
    requestAnimationFrame(() => {
      banner.classList.add('is-visible');
    });
  };

  document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('[data-nav-toggle]');
    const nav = document.querySelector('[data-nav]');
    if (navToggle && nav) {
      navToggle.addEventListener('click', () => {
        const isOpen = nav.classList.toggle('is-open');
        navToggle.setAttribute('aria-expanded', String(isOpen));
      });

      nav.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
          if (nav.classList.contains('is-open')) {
            nav.classList.remove('is-open');
            navToggle.setAttribute('aria-expanded', 'false');
          }
        });
      });
    }

    const banner = document.querySelector('[data-cookie-banner]');
    if (!banner) {
      return;
    }

    const acceptBtn = banner.querySelector('[data-action="accept"]');
    const rejectBtn = banner.querySelector('[data-action="reject"]');
    const customizeBtn = banner.querySelector('[data-action="customize"]');
    const saveBtn = banner.querySelector('[data-action="save"]');
    const panel = banner.querySelector('[data-custom-panel]');
    const analyticsCheckbox = banner.querySelector('#cookie-analytics');
    const marketingCheckbox = banner.querySelector('#cookie-marketing');

    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const prefs = JSON.parse(stored);
        document.documentElement.dataset.analytics = prefs.analytics ? 'allowed' : 'blocked';
        document.documentElement.dataset.marketing = prefs.marketing ? 'allowed' : 'blocked';
      } catch (error) {
        localStorage.removeItem(STORAGE_KEY);
        revealBanner(banner);
      }
    } else {
      revealBanner(banner);
    }

    acceptBtn?.addEventListener('click', () => {
      applyPreferences(banner, {
        necessary: true,
        analytics: true,
        marketing: true,
        timestamp: new Date().toISOString()
      });
    });

    rejectBtn?.addEventListener('click', () => {
      if (analyticsCheckbox) analyticsCheckbox.checked = false;
      if (marketingCheckbox) marketingCheckbox.checked = false;
      applyPreferences(banner, {
        necessary: true,
        analytics: false,
        marketing: false,
        timestamp: new Date().toISOString()
      });
    });

    customizeBtn?.addEventListener('click', () => {
      if (!panel) return;
      const expanded = panel.hidden === false;
      panel.hidden = expanded;
      customizeBtn.setAttribute('aria-expanded', String(!expanded));
      if (!expanded && analyticsCheckbox) {
        analyticsCheckbox.focus();
      }
    });

    saveBtn?.addEventListener('click', (event) => {
      event.preventDefault();
      const preferences = {
        necessary: true,
        analytics: analyticsCheckbox ? analyticsCheckbox.checked : false,
        marketing: marketingCheckbox ? marketingCheckbox.checked : false,
        timestamp: new Date().toISOString()
      };
      applyPreferences(banner, preferences);
    });
  });
})();