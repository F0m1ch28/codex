import { useEffect } from 'react';

export const usePageMetadata = ({ title, description }) => {
  useEffect(() => {
    if (title) {
      document.title = `${title} | DigitalCovers`;
    } else {
      document.title = 'DigitalCovers — цифровые обложки и баннеры';
    }

    if (description) {
      let metaTag = document.querySelector('meta[name="description"]');
      if (!metaTag) {
        metaTag = document.createElement('meta');
        metaTag.setAttribute('name', 'description');
        document.head.appendChild(metaTag);
      }
      metaTag.setAttribute('content', description);
    }
  }, [title, description]);
};