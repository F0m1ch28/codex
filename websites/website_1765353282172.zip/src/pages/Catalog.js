import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Catalog.module.css';
import { categories } from '../data/categories';
import { products } from '../data/products';
import { usePageMetadata } from '../hooks/usePageMetadata';

const Catalog = () => {
  usePageMetadata({
    title: 'Каталог шаблонов',
    description:
      'Каталог DigitalCovers: обложки для видео, баннеры для стримов, аватарки и шапки для соцсетей с лицензией.'
  });

  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredProducts = products.filter((product) => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return true;
    return (
      product.name.toLowerCase().includes(term) ||
      product.description.toLowerCase().includes(term) ||
      product.tags.some((tag) => tag.toLowerCase().includes(term))
    );
  });

  return (
    <div className={styles.catalog}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroCard}>
            <span className={styles.heroBadge}>DigitalCovers Catalog</span>
            <h1>Каталог цифровых шаблонов</h1>
            <p>
              Выбирайте готовые обложки, баннеры и аватарки для видео, стримов и социальных сетей. Все материалы
              проверены кураторской командой и доступны с лицензией на коммерческое использование.
            </p>
            <div className={styles.search}>
              <label htmlFor="catalog-search" className="sr-only">
                Поиск по каталогу
              </label>
              <input
                id="catalog-search"
                type="search"
                placeholder="Поиск по названию, тегам или формату..."
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection}>
        <div className="container">
          <h2>Популярные направления</h2>
          <div className={styles.categoryGrid}>
            {categories.map((category) => (
              <article key={category.slug} className={styles.categoryCard}>
                <div className={styles.categoryImageWrapper}>
                  <img src={category.image} alt={category.title} />
                </div>
                <div className={styles.categoryContent}>
                  <h3>{category.title}</h3>
                  <p>{category.description}</p>
                  <Link to={`/catalog/${category.slug}`} className={styles.categoryLink}>
                    Смотреть подборку
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.results}>
        <div className="container">
          <div className={styles.resultsHeader}>
            <div>
              <h2>Все шаблоны</h2>
              <p>
                Найдено {filteredProducts.length} шаблонов{searchTerm ? ` по запросу «${searchTerm}»` : ''}.
              </p>
            </div>
            <Link to="/services" className={styles.helperLink}>
              Как использовать каталог →
            </Link>
          </div>
          <div className={styles.productsGrid}>
            {filteredProducts.map((product) => (
              <article key={product.id} className={styles.productCard}>
                <div className={styles.productImageWrapper}>
                  <img src={product.image} alt={product.name} />
                </div>
                <div className={styles.productContent}>
                  <span className={styles.productCategory}>{product.categoryName}</span>
                  <h3>{product.name}</h3>
                  <p>{product.description}</p>
                  <div className={styles.tagList}>
                    {product.tags.map((tag) => (
                      <span key={tag} className={styles.tag}>
                        #{tag}
                      </span>
                    ))}
                  </div>
                  <Link to={`/product/${product.id}`} className={styles.productLink}>
                    Подробнее
                  </Link>
                </div>
              </article>
            ))}
          </div>
          {filteredProducts.length === 0 && (
            <div className={styles.emptyState}>
              <h3>Не нашли подходящий шаблон?</h3>
              <p>
                Используйте другие ключевые слова или напишите нам на support@digitalcovers.example — мы подберём решения
                из закрытых подборок.
              </p>
              <Link to="/contacts" className={styles.emptyLink}>
                Связаться с поддержкой
              </Link>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Catalog;