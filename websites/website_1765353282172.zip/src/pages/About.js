import React from 'react';
import styles from './About.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const timeline = [
  {
    year: '2020',
    title: 'Старт DigitalCovers',
    description: 'Запустили MVP платформы с подборками обложек для видео и базовыми лицензиями.'
  },
  {
    year: '2021',
    title: 'Международный каталог',
    description: 'Добавили поддержку нескольких валют и подключили авторов из ЕС, США и СНГ.'
  },
  {
    year: '2022',
    title: 'Инструменты для стримеров',
    description: 'Расширили платформу баннерами и пакетами сцен с инструкциями по OBS и Streamlabs.'
  },
  {
    year: '2023',
    title: 'Комьюнити авторов',
    description: 'Запустили программу менторства, образовательные вебинары и блог DigitalCovers.'
  }
];

const team = [
  {
    name: 'Наталья Соколова',
    role: 'Основатель и CEO',
    bio: '10 лет в диджитал-агентствах, руководила креативными командами для EdTech и финтех-проектов.',
    photo: 'https://picsum.photos/seed/digitalcovers-team1/400/400'
  },
  {
    name: 'Илья Петров',
    role: 'Креативный директор',
    bio: 'Графический дизайнер, создал более 200 бренд-пакетов для YouTube-каналов и стримеров.',
    photo: 'https://picsum.photos/seed/digitalcovers-team2/400/400'
  },
  {
    name: 'Диана Абрамова',
    role: 'Head of Community',
    bio: 'Работает с авторами DigitalCovers, курирует программы поддержки и обучение дизайнеров.',
    photo: 'https://picsum.photos/seed/digitalcovers-team3/400/400'
  },
  {
    name: 'Роман Верещагин',
    role: 'Technical Lead',
    bio: 'Отвечает за инфраструктуру каталога, автоматизацию загрузки файлов и систему лицензирования.',
    photo: 'https://picsum.photos/seed/digitalcovers-team4/400/400'
  }
];

const values = [
  {
    title: 'Честные лицензии',
    description:
      'Мы уверены, что авторы должны зарабатывать на своём контенте. Лицензии и выплаты прозрачны и перечисляются вовремя.'
  },
  {
    title: 'Качество и кураторство',
    description:
      'Перед публикацией каждый шаблон проходит проверку на соответствие техническим требованиям и трендам.'
  },
  {
    title: 'Поддержка создателей',
    description:
      'Команда отвечает на запросы в течение 12 часов и помогает адаптировать шаблоны под конкретные кейсы.'
  }
];

const About = () => {
  usePageMetadata({
    title: 'О компании DigitalCovers',
    description:
      'DigitalCovers — команда дизайнеров и кураторов, которые создают маркетплейс цифровых обложек и баннеров для создателей контента.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.badge}>О компании</span>
            <h1>DigitalCovers — платформа, которая создаёт дизайн вместе с сообществом</h1>
            <p>
              Мы верим, что визуальная идентичность должна быть доступной. Поэтому строим международное сообщество
              дизайнеров и создателей, которое делится шаблонами, идеями и опытом.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <article className={styles.missionCard}>
              <h2>Наша миссия</h2>
              <p>
                Помогать авторам и брендам занимать своё место в цифровом пространстве, создавая узнаваемый визуал без
                долгих подготовок и огромных бюджетов. DigitalCovers — это экосистема с каталогом, обучением и
                поддержкой.
              </p>
            </article>
            <article className={styles.missionCard}>
              <h2>Команда</h2>
              <p>
                Мы собрали дизайнеров, маркетологов, разработчиков и комьюнити-менеджеров из разных стран. Это помогает
                нам учитывать специфику площадок и трендов в разных регионах.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2>Хронология DigitalCovers</h2>
          <div className={styles.timelineGrid}>
            {timeline.map((item) => (
              <article key={item.year} className={styles.timelineItem}>
                <span className={styles.timelineYear}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <h2>Команда DigitalCovers</h2>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.photo} alt={member.name} />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Наши ценности</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.join}>
        <div className="container">
          <div className={styles.joinCard}>
            <div>
              <h2>Присоединяйтесь к комьюнити DigitalCovers</h2>
              <p>
                Хотите продавать шаблоны или создавать визуал для брендов? Напишите нам на partners@digitalcovers.example
                и расскажите о себе. Мы открыты к сотрудничеству с дизайнерами, иллюстраторами и студиями.
              </p>
            </div>
            <a href="mailto:partners@digitalcovers.example" className={styles.joinButton}>
              Стать автором
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;