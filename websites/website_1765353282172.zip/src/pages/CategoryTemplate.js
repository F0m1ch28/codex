import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CategoryTemplate.module.css';
import { products } from '../data/products';
import { usePageMetadata } from '../hooks/usePageMetadata';

const CategoryTemplate = ({
  title,
  description,
  categorySlug,
  heroImage,
  metaDescription,
  highlights
}) => {
  usePageMetadata({
    title,
    description: metaDescription || description
  });

  const filteredProducts = products.filter((product) => product.category === categorySlug);

  return (
    <div className={styles.page}>
      <section
        className={styles.hero}
        style={{ backgroundImage: `linear-gradient(135deg, rgba(15, 23, 42, 0.75), rgba(30, 64, 175, 0.65)), url(${heroImage})` }}
      >
        <div className="container">
          <div className={styles.heroInner}>
            <h1>{title}</h1>
            <p>{description}</p>
            <Link to="/catalog" className={styles.heroLink}>
              Вернуться к каталогу
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.highlights}>
        <div className="container">
          <div className={styles.highlightGrid}>
            {highlights.map((highlight) => (
              <article key={highlight.title} className={styles.highlightCard}>
                <h3>{highlight.title}</h3>
                <p>{highlight.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.listing}>
        <div className="container">
          <h2>Подборка шаблонов</h2>
          <div className={styles.grid}>
            {filteredProducts.map((product) => (
              <article key={product.id} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img src={product.image} alt={product.name} />
                </div>
                <div className={styles.cardContent}>
                  <h3>{product.name}</h3>
                  <p>{product.description}</p>
                  <ul className={styles.featureList}>
                    {product.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                  <Link to={`/product/${product.id}`} className={styles.cardLink}>
                    Подробнее о шаблоне
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.bottomCta}>
            <h3>Нужна адаптация под ваш бренд?</h3>
            <p>
              Свяжитесь с нами, если хотите адаптировать выбранный шаблон или заказать кастомную серию.
              Мы поможем найти дизайнера или собрать пакет под ваш канал.
            </p>
            <Link to="/contacts" className={styles.contactCta}>
              Связаться с DigitalCovers
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CategoryTemplate;