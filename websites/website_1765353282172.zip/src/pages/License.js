import React from 'react';
import styles from './License.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const License = () => {
  usePageMetadata({
    title: 'Лицензия DigitalCovers',
    description:
      'Правила использования цифровых шаблонов DigitalCovers, разрешения и ограничения лицензии.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Лицензия DigitalCovers Pro</h1>
          <p>
            DigitalCovers Pro — это лицензия на использование цифровых шаблонов, которая подходит как для персональных,
            так и для коммерческих проектов. Ниже описаны основные условия.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <article className={styles.block}>
            <h2>Разрешено</h2>
            <ul>
              <li>Использовать шаблоны в личных и коммерческих проектах без ограничения по географии.</li>
              <li>Редактировать, изменять цвета, шрифты и композиции в соответствии с потребностями вашего бренда.</li>
              <li>Использовать материалы в монетизируемых каналах, подкастах, стримах и рекламных кампаниях.</li>
              <li>Передавать исходники подрядчикам и членам команды при сохранении лицензии в рамках проекта.</li>
            </ul>
          </article>

          <article className={styles.block}>
            <h2>Запрещено</h2>
            <ul>
              <li>Продавать или распространять шаблоны как есть или с минимальными изменениями на сторонних площадках.</li>
              <li>Использовать материалы в продуктах, нарушающих законы, содержащих политическую или агрессивную риторику.</li>
              <li>Передавать лицензию третьим лицам вне вашего проекта без согласия DigitalCovers и автора.</li>
            </ul>
          </article>

          <article className={styles.block}>
            <h2>Права авторов</h2>
            <p>
              Правообладатели сохраняют авторские права на созданные материалы. Покупка лицензии предоставляет право
              использования, но не передачу авторства. Авторы получают вознаграждение за каждую продажу и могут
              обновлять свои работы.
            </p>
          </article>

          <article className={styles.block}>
            <h2>Вопросы по лицензии</h2>
            <p>
              Если вам нужна расширенная лицензия или передача прав на кастомный проект, напишите на
              support@digitalcovers.example. Мы поможем подобрать индивидуальное решение.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default License;