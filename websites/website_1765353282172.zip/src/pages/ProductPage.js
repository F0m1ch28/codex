import React from 'react';
import { useParams, Link } from 'react-router-dom';
import styles from './ProductPage.module.css';
import { products } from '../data/products';
import { usePageMetadata } from '../hooks/usePageMetadata';

const ProductPage = () => {
  const { productId } = useParams();
  const product = products.find((item) => item.id === productId);

  usePageMetadata({
    title: product ? product.name : 'Шаблон не найден',
    description: product
      ? `${product.name} — шаблон категории ${product.categoryName}. Готовые файлы и лицензия DigitalCovers.`
      : 'Шаблон DigitalCovers не найден.'
  });

  if (!product) {
    return (
      <div className={styles.page}>
        <section className={styles.hero}>
          <div className="container">
            <h1>Шаблон не найден</h1>
            <p>Похоже, ссылка неактуальна или товар был снят с публикации.</p>
            <Link to="/catalog" className={styles.backLink}>
              Вернуться к каталогу
            </Link>
          </div>
        </section>
      </div>
    );
  }

  const relatedProducts = products
    .filter((item) => item.category === product.category && item.id !== product.id)
    .slice(0, 3);

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.preview}>
              <img src={product.image} alt={product.name} />
            </div>
            <div className={styles.details}>
              <span className={styles.category}>{product.categoryName}</span>
              <h1>{product.name}</h1>
              <p>{product.description}</p>
              <ul className={styles.features}>
                {product.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <div className={styles.actions}>
                <Link to="/contacts" className={styles.primary}>
                  Запросить консультацию
                </Link>
                <a href="mailto:support@digitalcovers.example" className={styles.secondary}>
                  Написать в поддержку
                </a>
              </div>
              <div className={styles.meta}>
                <span>Лицензия: DigitalCovers Pro</span>
                <span>Форматы: Figma, PSD, PNG, SVG (зависит от комплекта)</span>
                <span>Поддержка: support@digitalcovers.example</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.related}>
        <div className="container">
          <h2>Похожие шаблоны</h2>
          <div className={styles.relatedGrid}>
            {relatedProducts.map((item) => (
              <article key={item.id} className={styles.relatedCard}>
                <img src={item.image} alt={item.name} />
                <div className={styles.relatedContent}>
                  <span>{item.categoryName}</span>
                  <h3>{item.name}</h3>
                  <p>{item.description}</p>
                  <Link to={`/product/${item.id}`} className={styles.relatedLink}>
                    Открыть
                  </Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.relatedFooter}>
            <Link to={`/catalog/${product.category}`} className={styles.backLink}>
              Смотреть все шаблоны категории
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProductPage;