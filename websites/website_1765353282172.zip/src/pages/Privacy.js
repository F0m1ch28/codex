import React from 'react';
import styles from './Privacy.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const Privacy = () => {
  usePageMetadata({
    title: 'Политика конфиденциальности',
    description:
      'Политика обработки персональных данных пользователей платформы DigitalCovers.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Политика конфиденциальности DigitalCovers</h1>
          <p>Последнее обновление: 15 февраля 2024 года.</p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article>
            <h2>1. Какие данные мы собираем</h2>
            <p>
              Мы собираем контактные данные (имя, email), информацию о покупках, а также данные, необходимые для
              использования сервиса. Файлы cookie используются для аналитики и улучшения интерфейса.
            </p>
          </article>
          <article>
            <h2>2. Как мы используем данные</h2>
            <p>
              Данные помогают нам предоставлять сервис, отправлять уведомления о заказах, обновления по лицензии и
              отвечать на запросы. Мы не передаём данные третьим лицам без согласия пользователя и требований закона.
            </p>
          </article>
          <article>
            <h2>3. Хранение данных</h2>
            <p>
              Персональные данные хранятся на защищённых серверах в соответствии с применимым законодательством. Мы
              используем современные меры безопасности.
            </p>
          </article>
          <article>
            <h2>4. Права пользователя</h2>
            <p>
              Вы можете запросить копию данных, внести изменения или удалить данные. Для этого напишите на
              support@digitalcovers.example.
            </p>
          </article>
          <article>
            <h2>5. Cookie и аналитика</h2>
            <p>
              Мы используем cookie для анализа работы сайта. Вы можете управлять cookie через настройки браузера.
              Подробнее — в <a href="/cookie-policy">политике cookie</a>.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Privacy;