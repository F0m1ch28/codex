import React from 'react';
import CategoryTemplate from './CategoryTemplate';

const highlights = [
  {
    title: 'Сцены и панели',
    description: 'Комплекты включают оффлайн-сцены, starting soon, брейки и панели для донатов и правил.'
  },
  {
    title: 'Инструкции по OBS',
    description: 'Каждый шаблон содержит гайд по настройке в OBS, Streamlabs или Lightstream.'
  },
  {
    title: 'Анимационные элементы',
    description: 'Работайте с анимированными фонами, глитч-эффектами и лупами для живого стрима.'
  }
];

const StreamBanners = () => (
  <CategoryTemplate
    title="Баннеры для стримов"
    description="Универсальные наборы для Twitch, Trovo, VK Play Live и YouTube Gaming. Включают статичные и анимированные сцены, панели и оффлайн-баннеры."
    categorySlug="stream-banners"
    heroImage="https://picsum.photos/seed/digitalcovers-stream-category/1600/900"
    metaDescription="Баннеры для стримов: сцены, панели и оффлайн-баннеры для Twitch и других платформ."
    highlights={highlights}
  />
);

export default StreamBanners;