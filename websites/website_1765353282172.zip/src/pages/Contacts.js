import React from 'react';
import styles from './Contacts.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const Contacts = () => {
  usePageMetadata({
    title: 'Контакты DigitalCovers',
    description:
      'Свяжитесь с командой DigitalCovers: поддержка пользователей, авторов и партнёров.'
  });

  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    message: ''
  });

  const [status, setStatus] = React.useState(null);
  const [errors, setErrors] = React.useState({});

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Укажите ваше имя.';
    if (!formData.email.trim()) {
      newErrors.email = 'Заполните email.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(formData.email)) {
      newErrors.email = 'Похоже, адрес email указан с ошибкой.';
    }
    if (!formData.message.trim()) newErrors.message = 'Расскажите о вашей задаче или вопросе.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      setStatus(null);
      return;
    }
    setStatus('Заявка отправлена! Мы свяжемся с вами по email в течение рабочего дня.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Контакты</h1>
          <p>
            Напишите нам, если вам нужна помощь с выбором шаблонов, лицензией или вы хотите стать автором DigitalCovers.
          </p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Офис и поддержка</h2>
              <p>
                Email поддержки: <strong>support@digitalcovers.example</strong>
                <br />
                Для авторов: <strong>partners@digitalcovers.example</strong>
              </p>
              <p>
                Телефон: <strong>+7 (495) 123-45-67</strong>
                <br />
                Адрес: ул. Цифровая, д. 1, офис 404, Москва, Россия, 123456
              </p>
              <div className={styles.hours}>
                <h3>График работы службы поддержки</h3>
                <p>Понедельник — пятница: 09:00–20:00 (MSK)</p>
                <p>Суббота — воскресенье: дежурная команда отвечает в течение 12 часов.</p>
              </div>
            </div>
            <div className={styles.formWrapper}>
              <h2>Свяжитесь с нами</h2>
              <form onSubmit={handleSubmit} className={styles.form} noValidate>
                <label htmlFor="contact-name">Ваше имя</label>
                <input
                  id="contact-name"
                  type="text"
                  value={formData.name}
                  onChange={(event) => setFormData({ ...formData, name: event.target.value })}
                  aria-invalid={errors.name ? 'true' : 'false'}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}

                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  type="email"
                  value={formData.email}
                  onChange={(event) => setFormData({ ...formData, email: event.target.value })}
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}

                <label htmlFor="contact-message">Сообщение</label>
                <textarea
                  id="contact-message"
                  rows="5"
                  value={formData.message}
                  onChange={(event) => setFormData({ ...formData, message: event.target.value })}
                  aria-invalid={errors.message ? 'true' : 'false'}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}

                <button type="submit" className={styles.submit}>
                  Отправить
                </button>
                {status && <div className={styles.status}>{status}</div>}
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contacts;