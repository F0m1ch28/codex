import React from 'react';
import CategoryTemplate from './CategoryTemplate';

const highlights = [
  {
    title: 'Структура под плейлисты',
    description: 'Создавайте серии обложек с единой композицией, чтобы зрители легко ориентировались в плейлистах.'
  },
  {
    title: 'Адаптация для Shorts и Reels',
    description: 'Каждый шаблон снабжён вертикальной версией для коротких видео и сторис.'
  },
  {
    title: 'Настраиваемая типографика',
    description: 'Работаем со шрифтами, поддерживающими кириллицу и латиницу без согласований.'
  }
];

const VideoCovers = () => (
  <CategoryTemplate
    title="Обложки для видео"
    description="Привлекайте внимание к вашим роликам с помощью ярких и структурированных превью. Подборка включает шаблоны для YouTube, RuTube, VK Видео и образовательных платформ."
    categorySlug="video-covers"
    heroImage="https://picsum.photos/seed/digitalcovers-video-category/1600/900"
    metaDescription="Обложки для видео на YouTube, RuTube и VK Видео — готовые шаблоны с лицензией DigitalCovers."
    highlights={highlights}
  />
);

export default VideoCovers;