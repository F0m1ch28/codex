import React from 'react';
import styles from './HowItWorks.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const stepsBuyer = [
  {
    title: 'Изучите каталог и фильтры',
    text: 'Используйте фильтры по платформам, стилям и форматам. Каждая карточка содержит предпросмотр и список форматов.'
  },
  {
    title: 'Добавьте шаблон в план',
    text: 'Соберите подборку из нескольких шаблонов, чтобы обсуждать их с командой. Никаких ограничений по количеству.'
  },
  {
    title: 'Скачайте исходники и гайд',
    text: 'После активации лицензии вы получаете архив с файлами, гайд по редактированию и лицензией DigitalCovers Pro.'
  }
];

const stepsAuthor = [
  {
    title: 'Подайте заявку и портфолио',
    text: 'Пришлите свои работы на partners@digitalcovers.example. Кураторы отвечают в течение 5 рабочих дней.'
  },
  {
    title: 'Получите доступ к кабинету',
    text: 'Мы выдаём инструкцию по форматам, требованиям к файлам и описаниям. Можно загружать наборы серийно.'
  },
  {
    title: 'Получайте выплаты',
    text: 'Выплаты осуществляются раз в месяц. Авторы получают детальную статистику и рекомендации по трендам.'
  }
];

const resources = [
  {
    title: 'Гайды по платформам',
    description: 'Подробные инструкции по YouTube, Twitch, Telegram, LinkedIn и другим площадкам.',
    link: '/catalog'
  },
  {
    title: 'Обучающие вебинары',
    description: 'Разбираем кейсы и показываем, как адаптировать шаблоны под вашу стратегию.',
    link: '/about'
  },
  {
    title: 'Подборки трендов',
    description: 'Еженедельные подборки по трендовым стилям и тематическим нишам.',
    link: '/catalog/video-covers'
  }
];

const HowItWorks = () => {
  usePageMetadata({
    title: 'Как работает платформа',
    description:
      'Узнайте, как работает DigitalCovers для покупателей и авторов: шаги, инструменты и поддержка.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Как работает DigitalCovers</h1>
            <p>
              Платформа соединяет дизайнеров и создателей контента. Мы сделали процесс простым как для покупателей, так
              и для авторов шаблонов.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.steps}>
        <div className="container">
          <div className={styles.stepsGrid}>
            <div className={styles.stepsColumn}>
              <h2>Создателям контента</h2>
              {stepsBuyer.map((step, index) => (
                <article key={step.title} className={styles.stepCard}>
                  <span className={styles.stepNumber}>{index + 1}</span>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </article>
              ))}
            </div>
            <div className={styles.stepsColumn}>
              <h2>Авторам и дизайнерам</h2>
              {stepsAuthor.map((step, index) => (
                <article key={step.title} className={styles.stepCard}>
                  <span className={styles.stepNumber}>{index + 1}</span>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.resources}>
        <div className="container">
          <h2>Инструменты и материалы</h2>
          <div className={styles.resourceGrid}>
            {resources.map((resource) => (
              <article key={resource.title} className={styles.resourceCard}>
                <h3>{resource.title}</h3>
                <p>{resource.description}</p>
                <a href={resource.link} className={styles.resourceLink}>
                  Узнать больше
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.support}>
        <div className="container">
          <div className={styles.supportCard}>
            <div>
              <h2>Поможем подобрать нужный пакет</h2>
              <p>
                Опишите вашу задачу, и мы подготовим индивидуальную подборку шаблонов, предложим авторов для кастомного
                дизайна и поделимся лучшими практиками.
              </p>
            </div>
            <a href="mailto:support@digitalcovers.example" className={styles.supportButton}>
              Написать в поддержку
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HowItWorks;