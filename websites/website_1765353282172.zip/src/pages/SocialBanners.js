import React from 'react';
import CategoryTemplate from './CategoryTemplate';

const highlights = [
  {
    title: 'Кросс-платформенная сетка',
    description: 'На каждый шаблон припадает адаптация для Telegram, VK, YouTube, Twitter и LinkedIn.'
  },
  {
    title: 'Кириллическая типографика',
    description: 'Мы проверяем поддержку кириллицы, чтобы тексты в шапках и карточках были без артефактов.'
  },
  {
    title: 'SMM-гайды',
    description: 'Вместе с файлами получаете советы по публикации и комбинациям форматов для кампаний.'
  }
];

const SocialBanners = () => (
  <CategoryTemplate
    title="Шапки для соцсетей"
    description="Подготовьте единый визуал для социальных сетей, чтобы аудитория узнавала ваш бренд в каждой публикации. Подборка включает шапки, карусели и посты."
    categorySlug="social-banners"
    heroImage="https://picsum.photos/seed/digitalcovers-social-category/1600/900"
    metaDescription="Шапки и баннеры для соцсетей: Telegram, YouTube, VK и LinkedIn в одном пакете."
    highlights={highlights}
  />
);

export default SocialBanners;