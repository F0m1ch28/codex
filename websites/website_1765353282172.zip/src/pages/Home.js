import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import { categories } from '../data/categories';
import { products } from '../data/products';
import { usePageMetadata } from '../hooks/usePageMetadata';

const statsData = [
  { label: 'готовых дизайнов', value: 7400 },
  { label: 'активных авторов', value: 280 },
  { label: 'проектов, оформленных с DigitalCovers', value: 15400 },
  { label: 'минут на запуск брендинга', value: 15 }
];

const processSteps = [
  {
    title: 'Выберите дизайн',
    description:
      'Используйте фильтры и подборки, чтобы найти шаблон под вашу задачу — от превью до оффлайн-баннеров.'
  },
  {
    title: 'Скачайте файлы',
    description:
      'Получайте исходники в популярных форматах: Figma, PSD, PNG, SVG или XD. Никаких скрытых ограничений.'
  },
  {
    title: 'Настройте под себя',
    description:
      'Меняйте текст, цвета и композиции. Каждый шаблон снабжён гайдлайном и предустановленными стилями.'
  },
  {
    title: 'Публикуйте и растите',
    description:
      'Используйте готовый визуал в YouTube, Twitch, Telegram, подкастах и других каналах, где важна узнаваемость.'
  }
];

const audience = [
  {
    title: 'YouTube и видеоблогеры',
    description:
      'Привлекайте внимание к новым роликам с обложками, которые выделяются в выдаче и плейлистах.'
  },
  {
    title: 'Стримеры и киберспорт',
    description:
      'Настраивайте сцены, оффлайн-блоки и панельки за считанные минуты и держите канал в едином стиле.'
  },
  {
    title: 'Подкастеры и авторские медиа',
    description:
      'Создавайте серию обложек и карточек выпусков, чтобы аудитория сразу узнавала ваш контент.'
  },
  {
    title: 'SMM-команды и агентства',
    description:
      'Готовые пакеты помогают запускать кампании без долгих брифов и ускоряют согласования с клиентами.'
  }
];

const benefits = [
  'Проверенные лицензии и честные условия для авторов',
  'Файлы с поддержкой кириллицы и адаптацией под соцсети',
  'Редакционная команда обновляет подборки каждую неделю',
  'Глобальная поддержка: ответ в течение 12 часов, даже в выходные'
];

const testimonialsData = [
  {
    name: 'Алексей Воронов',
    role: 'YouTube-продюсер канала про технологии',
    message:
      'За последние полгода мы обновили визуал на канале трижды. DigitalCovers спасает, когда нужно быстро адаптировать обложки под серию видео и сохранить единый стиль.',
    avatar: 'https://picsum.photos/seed/digitalcovers-testimonial1/200/200'
  },
  {
    name: 'Мария Дракова',
    role: 'Стример VK Play Live',
    message:
      'Комплект баннеров с анимацией для стриминга собрал больше кликов на донаты и подписки. Понравилось, что в ките есть гайд по настройке OBS.',
    avatar: 'https://picsum.photos/seed/digitalcovers-testimonial2/200/200'
  },
  {
    name: 'Иван Кац',
    role: 'Креативный директор smm-агентства',
    message:
      'Каталог помогает закрывать задачи малого бизнеса без дорогих фотосессий. Мы быстро собираем moodboard и выдаём клиенту готовый визуал в рамках бюджета.',
    avatar: 'https://picsum.photos/seed/digitalcovers-testimonial3/200/200'
  }
];

const faqData = [
  {
    question: 'Можно ли использовать шаблоны в коммерческих проектах?',
    answer:
      'Да. Каждый продукт снабжён лицензией DigitalCovers Pro, которая разрешает коммерческое использование, включая монетизацию каналов и спонсированные интеграции.'
  },
  {
    question: 'Что входит в пакет после покупки?',
    answer:
      'Вы получите исходники в заявленных форматах, набор шрифтов (при наличии бесплатных лицензий), гайд по адаптации и предпросмотры. Описание каждого товара содержит полный перечень.'
  },
  {
    question: 'Можно ли редактировать цвета и шрифты?',
    answer:
      'Все шаблоны созданы в редакторе, позволяющем менять стили. Мы указываем поддержку кириллицы и прикладываем альтернативы, если оригинальный шрифт платный.'
  },
  {
    question: 'Как стать автором на DigitalCovers?',
    answer:
      'Отправьте портфолио на partners@digitalcovers.example. Команда кураторов проверит работы и свяжется, чтобы обсудить условия размещения и процент от продаж.'
  }
];

const blogPosts = [
  {
    title: 'Как выбрать обложку, которая удерживает зрителя на YouTube',
    excerpt:
      'Спойлер: не только контраст, но и типографика. Собрали пять практических выводов из аналитики кликов по превью.',
    link: '/how-it-works'
  },
  {
    title: 'Гайд по оформлению стрим-канала: чек-лист из 12 пунктов',
    excerpt:
      'От статичных сцен до анимированных алертов — разбираем, что влияет на вовлечённость аудитории во время трансляции.',
    link: '/catalog/stream-banners'
  },
  {
    title: 'Подготовка бренд-пакета для соцсетей за выходные',
    excerpt:
      'Рассказываем, как комбинировать готовые шаблоны и фирменный стиль, чтобы сохранить узнаваемость на всех площадках.',
    link: '/catalog/social-banners'
  }
];

const projectsData = [
  {
    title: 'TechNova Media',
    category: 'video',
    description: 'Серия обложек и карточек премьер для технологического медиа о стартапах.',
    image: 'https://picsum.photos/seed/digitalcovers-project1/1200/800'
  },
  {
    title: 'StreamLab Gaming',
    category: 'stream',
    description: 'Полное переоформление Twitch-канала: сцены, алерты, панели и панорамы.',
    image: 'https://picsum.photos/seed/digitalcovers-project2/1200/800'
  },
  {
    title: 'Morning Podcast',
    category: 'podcast',
    description: 'Минималистичная сетка обложек для еженедельного подкаста о продуктивности.',
    image: 'https://picsum.photos/seed/digitalcovers-project3/1200/800'
  },
  {
    title: 'Travel Pulse',
    category: 'social',
    description: 'Адаптивные шапки и сторис для тревел-сообщества в Telegram и Instagram.',
    image: 'https://picsum.photos/seed/digitalcovers-project4/1200/800'
  }
];

const Home = () => {
  usePageMetadata({
    title: 'DigitalCovers — маркетплейс графического контента',
    description:
      'Профессиональные обложки, баннеры и аватарки для блогеров, стримеров и студий. Готовые цифровые шаблоны с лицензией DigitalCovers.'
  });

  const [animatedStats, setAnimatedStats] = React.useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [activeProjectFilter, setActiveProjectFilter] = React.useState('all');
  const [openFaq, setOpenFaq] = React.useState(null);

  React.useEffect(() => {
    let step = 0;
    const steps = 32;
    const interval = setInterval(() => {
      step += 1;
      setAnimatedStats(
        statsData.map((stat) => {
          const progress = Math.min(stat.value, Math.round((stat.value / steps) * step));
          return progress;
        })
      );
      if (step >= steps) {
        clearInterval(interval);
      }
    }, 40);
    return () => clearInterval(interval);
  }, []);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6500);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeProjectFilter === 'all'
      ? projectsData
      : projectsData.filter((project) => project.category === activeProjectFilter);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  const popularProducts = products.slice(0, 6);

  return (
    <div className={styles.home}>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <div className={styles.heroBadge}>Платформа для цифрового оформления каналов</div>
            <h1 className={styles.headline}>
              Продавайте и покупайте уникальный цифровой дизайн для видео, стримов и соцсетей
            </h1>
            <p className={styles.subheadline}>
              DigitalCovers объединяет авторов и бренды со всего мира. Выбирайте обложки, баннеры и
              аватарки с лицензией, чтобы дать вашему контенту узнаваемость и стиль.
            </p>
            <div className={styles.ctaGroup}>
              <Link to="/catalog" className={styles.primaryCta}>
                Смотреть каталог
              </Link>
              <Link to="/how-it-works" className={styles.secondaryCta}>
                Как это работает
              </Link>
            </div>
            <div className={styles.heroMeta}>
              <div>
                <span className={styles.metaTitle}>Для авторов</span>
                <span className={styles.metaText}>Размещайте шаблоны и получайте вознаграждение</span>
              </div>
              <div>
                <span className={styles.metaTitle}>Для брендов</span>
                <span className={styles.metaText}>Соберите единый визуал без долгих согласований</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {animatedStats[index].toLocaleString('ru-RU')}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.categories}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Категории каталога</h2>
              <p>От обложек для видео до баннеров для стримов — все шаблоны готовы к редактированию.</p>
            </div>
            <Link to="/catalog" className={styles.sectionLink}>
              Открыть полный каталог →
            </Link>
          </div>
          <div className={styles.categoriesGrid}>
            {categories.map((category) => (
              <article
                key={category.slug}
                className={styles.categoryCard}
                style={{ backgroundImage: `url(${category.image})` }}
              >
                <div className={styles.categoryOverlay}>
                  <h3 className={styles.categoryTitle}>{category.title}</h3>
                  <p className={styles.categoryDescription}>{category.description}</p>
                  <div className={styles.categoryFooter}>
                    <Link to={`/catalog/${category.slug}`} className={styles.categoryLink}>
                      Смотреть подборку
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.popularProducts}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Популярные шаблоны недели</h2>
              <p>Свежие релизы от авторов DigitalCovers, которые уже работают у создателей контента.</p>
            </div>
          </div>
          <div className={styles.productsGrid}>
            {popularProducts.map((product) => (
              <article key={product.id} className={styles.productCard}>
                <div className={styles.productImageWrapper}>
                  <img src={product.image} alt={product.name} className={styles.productImage} />
                </div>
                <div className={styles.productContent}>
                  <span className={styles.productCategory}>{product.categoryName}</span>
                  <h3 className={styles.productTitle}>{product.name}</h3>
                  <p className={styles.productExcerpt}>{product.description}</p>
                  <Link to={`/product/${product.id}`} className={styles.productLink}>
                    Подробнее о шаблоне
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Как работает DigitalCovers</h2>
              <p>Простой путь от идеи до готового брендинга вашего канала или проекта.</p>
            </div>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <article key={step.title} className={styles.processStep}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.audience}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Для кого мы создаём DigitalCovers</h2>
              <p>Продукты платформы помогают авторам, агентствам и брендам всех размеров.</p>
            </div>
          </div>
          <div className={styles.audienceGrid}>
            {audience.map((item) => (
              <article key={item.title} className={styles.audienceCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Преимущества платформы</h2>
              <p>Почему DigitalCovers выбирают авторы и маркетологи в разных странах.</p>
            </div>
          </div>
          <ul className={styles.advantagesList}>
            {benefits.map((benefit) => (
              <li key={benefit}>{benefit}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Кейсы авторов DigitalCovers</h2>
              <p>Собрали проекты, оформленные с помощью наших пакетов и шаблонов.</p>
            </div>
          </div>
          <div className={styles.filterGroup}>
            <button
              type="button"
              className={`${styles.filterButton} ${
                activeProjectFilter === 'all' ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveProjectFilter('all')}
            >
              Все
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${
                activeProjectFilter === 'video' ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveProjectFilter('video')}
            >
              Видео
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${
                activeProjectFilter === 'stream' ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveProjectFilter('stream')}
            >
              Стримы
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${
                activeProjectFilter === 'podcast' ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveProjectFilter('podcast')}
            >
              Подкасты
            </button>
            <button
              type="button"
              className={`${styles.filterButton} ${
                activeProjectFilter === 'social' ? styles.filterButtonActive : ''
              }`}
              onClick={() => setActiveProjectFilter('social')}
            >
              Соцсети
            </button>
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={project.title} />
                </div>
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Отзывы авторов и клиентов</h2>
              <p>Повышаем качество визуального контента благодаря обратной связи комьюнити.</p>
            </div>
          </div>
          <div className={styles.testimonialList}>
            {testimonialsData.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
              >
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className={styles.testimonialAvatar}
                />
                <p className={styles.testimonialMessage}>“{testimonial.message}”</p>
                <span className={styles.testimonialName}>{testimonial.name}</span>
                <span className={styles.testimonialRole}>{testimonial.role}</span>
              </article>
            ))}
          </div>
          <div className={styles.testimonialNav}>
            {testimonialsData.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.navDot} ${
                  index === activeTestimonial ? styles.navDotActive : ''
                }`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Показать отзыв ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Часто задаваемые вопросы</h2>
              <p>Ответы на типовые вопросы о лицензии, форматах и работе с шаблонами.</p>
            </div>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <article key={item.question} className={styles.faqItem}>
                <button
                  className={styles.faqQuestion}
                  onClick={() => toggleFaq(index)}
                  aria-expanded={openFaq === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{openFaq === index ? '−' : '+'}</span>
                </button>
                <div
                  className={`${styles.faqAnswer} ${openFaq === index ? styles.faqAnswerOpen : ''}`}
                >
                  <p>{item.answer}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <div>
              <h2>Свежие материалы блога</h2>
              <p>Подборки, инструкции и инсайты о визуальном оформлении каналов.</p>
            </div>
            <Link to="/how-it-works" className={styles.sectionLink}>
              Все материалы →
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.blogLink}>
                  Читать →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Готовы придать вашему контенту новый уровень?</h2>
              <p>
                Присоединяйтесь к DigitalCovers, чтобы находить дизайн для каналов, стримов и
                соцсетей, который работает на узнаваемость и рост аудитории.
              </p>
            </div>
            <div className={styles.ctaButtons}>
              <Link to="/catalog" className={styles.primaryCta}>
                Найти шаблон
              </Link>
              <a href="mailto:partners@digitalcovers.example" className={styles.secondaryCta}>
                Стать автором
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;