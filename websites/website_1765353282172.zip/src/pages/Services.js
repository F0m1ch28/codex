import React from 'react';
import styles from './Services.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const services = [
  {
    title: 'Подборка шаблонов под бренд',
    description:
      'Мы анализируем вашу нишу и готовим подборку шаблонов, которые можно адаптировать под фирменный стиль.'
  },
  {
    title: 'Адаптация и кастомизация',
    description:
      'Оформление выбранных шаблонов: настройка цветовой схемы, типографики и композиции под ваши требования.'
  },
  {
    title: 'Сопровождение запуска',
    description:
      'Помогаем внедрить новую визуальную систему в ваши каналы и создаём чек-листы для команды.'
  }
];

const authorSupport = [
  {
    title: 'Редакционная поддержка',
    text: 'Кураторы помогают авторам с концепциями, проверяют технические файлы и улучшают описание.'
  },
  {
    title: 'Аналитика и тренды',
    text: 'Мы делимся аналитикой по продажам и трендам, чтобы авторы обновляли коллекции вовремя.'
  },
  {
    title: 'Маркетинговая поддержка',
    text: 'Продвигаем работы авторов в подборках, рассылках и социальных сетях DigitalCovers.'
  }
];

const Services = () => {
  usePageMetadata({
    title: 'Сервисы и услуги',
    description:
      'Экосистема DigitalCovers: помощь в подборе шаблонов, кастомизация и поддержка авторов.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Сервисы DigitalCovers</h1>
          <p>
            Помимо каталога, мы предлагаем поддержку создателей контента и авторов шаблонов. Подберите сервис, который
            ускорит запуск вашего визуала.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <h2>Для компаний и команд</h2>
          <div className={styles.serviceGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.authors}>
        <div className="container">
          <h2>Для авторов</h2>
          <div className={styles.authorGrid}>
            {authorSupport.map((item) => (
              <article key={item.title} className={styles.authorCard}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Нужна консультация?</h2>
              <p>
                Расскажите о вашей задаче — мы предложим подходящий сервис, команду и инструменты DigitalCovers, чтобы
                ускорить запуск.
              </p>
            </div>
            <a href="mailto:support@digitalcovers.example" className={styles.ctaButton}>
              Получить консультацию
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;