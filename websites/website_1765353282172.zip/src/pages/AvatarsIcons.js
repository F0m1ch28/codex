import React from 'react';
import CategoryTemplate from './CategoryTemplate';

const highlights = [
  {
    title: 'Векторные исходники',
    description: 'Легко масштабируйте аватарки и иконки без потери качества благодаря файлам SVG и AI.'
  },
  {
    title: 'Цветовые палитры',
    description: 'Каждый набор дополняется палитрой и рекомендациями по сочетаниям, чтобы поддерживать бренд.'
  },
  {
    title: 'Готовые mockup',
    description: 'Используйте PSD и Figma mockup, чтобы презентовать обновлённый визуал команде или клиенту.'
  }
];

const AvatarsIcons = () => (
  <CategoryTemplate
    title="Аватарки и иконки"
    description="Подчеркните личный бренд или стиль канала с помощью уникальных аватарок и иконок. Наборы охватывают тематические подборки от подкастов до гейминга."
    categorySlug="avatars-icons"
    heroImage="https://picsum.photos/seed/digitalcovers-avatars-category/1600/900"
    metaDescription="Аватарки и иконки DigitalCovers: векторные пакеты, цветовые палитры, mockup и лицензии."
    highlights={highlights}
  />
);

export default AvatarsIcons;