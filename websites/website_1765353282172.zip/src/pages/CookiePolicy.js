import React from 'react';
import styles from './CookiePolicy.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const CookiePolicy = () => {
  usePageMetadata({
    title: 'Политика использования cookie',
    description:
      'Как DigitalCovers использует файлы cookie и аналогичные технологии для аналитики и персонализации.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Политика использования cookie</h1>
          <p>Последнее обновление: 15 февраля 2024 года.</p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article>
            <h2>Что такое cookie</h2>
            <p>
              Cookie — это небольшие файлы, которые сохраняются на вашем устройстве. Они помогают нам анализировать
              трафик и запоминать настройки.
            </p>
          </article>
          <article>
            <h2>Какие cookie мы используем</h2>
            <ul>
              <li>Функциональные — для работы сайта и сохранения настроек пользователя.</li>
              <li>Аналитические — для понимания статистики посещений и улучшения сервиса.</li>
            </ul>
          </article>
          <article>
            <h2>Управление cookie</h2>
            <p>
              Вы можете изменить настройки cookie в браузере. Обратите внимание, что отключение некоторых cookie может
              повлиять на работу отдельных функций сайта.
            </p>
          </article>
          <article>
            <h2>Контакты</h2>
            <p>
              По вопросам, связанным с cookie, обращайтесь на email{' '}
              <a href="mailto:support@digitalcovers.example">support@digitalcovers.example</a>.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default CookiePolicy;