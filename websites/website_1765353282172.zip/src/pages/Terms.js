import React from 'react';
import styles from './Terms.module.css';
import { usePageMetadata } from '../hooks/usePageMetadata';

const Terms = () => {
  usePageMetadata({
    title: 'Условия использования',
    description:
      'Условия использования сервиса DigitalCovers. Правовые положения для пользователей платформы.'
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Условия использования DigitalCovers</h1>
          <p>Последнее обновление: 15 февраля 2024 года.</p>
        </div>
      </section>
      <section className={styles.content}>
        <div className="container">
          <article>
            <h2>1. Общие положения</h2>
            <p>
              Используя сайт и сервисы DigitalCovers, вы соглашаетесь с настоящими условиями использования. Если вы не
              согласны с условиями, пожалуйста, не используйте платформу.
            </p>
          </article>
          <article>
            <h2>2. Регистрация и аккаунт</h2>
            <p>
              Для покупки и загрузки шаблонов может потребоваться регистрация. Вы обязуетесь предоставлять достоверную
              информацию и защищать данные учётной записи.
            </p>
          </article>
          <article>
            <h2>3. Контент и лицензия</h2>
            <p>
              Все материалы, размещённые на DigitalCovers, защищены авторским правом. Пользователь получает право
              использования шаблонов согласно лицензии DigitalCovers Pro. Полное описание лицензии доступно на странице{' '}
              <a href="/license">Лицензия</a>.
            </p>
          </article>
          <article>
            <h2>4. Ответственность</h2>
            <p>
              DigitalCovers несёт ответственность за предоставление доступа к товарам. Мы не отвечаем за последствия,
              вызванные неправильным использованием файлов и несоблюдением условий лицензии.
            </p>
          </article>
          <article>
            <h2>5. Изменения условий</h2>
            <p>
              Мы можем обновлять условия использования. Все изменения вступают в силу с момента публикации и применяются
              к последующим взаимодействиям с сервисом.
            </p>
          </article>
          <article>
            <h2>6. Контакты</h2>
            <p>
              По вопросам условий использования обращайтесь на email{' '}
              <a href="mailto:support@digitalcovers.example">support@digitalcovers.example</a>.
            </p>
          </article>
        </div>
      </section>
    </div>
  );
};

export default Terms;