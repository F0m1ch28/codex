import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.inner}`}>
      <div className={styles.brand}>
        <span className={styles.logo}>DigitalCovers</span>
        <p className={styles.description}>
          DigitalCovers — международная платформа для дизайнеров и создателей контента. Мы помогаем находить готовые
          обложки, баннеры и аватарки, которые выделяют ваши проекты.
        </p>
        <div className={styles.contacts}>
          <a href="mailto:support@digitalcovers.example" className={styles.contactLink}>
            support@digitalcovers.example
          </a>
          <a href="tel:+74951234567" className={styles.contactLink}>
            +7 (495) 123-45-67
          </a>
          <span className={styles.contactText}>
            ул. Цифровая, д. 1, офис 404, Москва, Россия, 123456
          </span>
        </div>
      </div>
      <div className={styles.columns}>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Навигация</h4>
          <Link to="/" className={styles.link}>Главная</Link>
          <Link to="/catalog" className={styles.link}>Каталог</Link>
          <Link to="/services" className={styles.link}>Сервисы</Link>
          <Link to="/how-it-works" className={styles.link}>Как это работает</Link>
          <Link to="/about" className={styles.link}>О нас</Link>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Категории</h4>
          <Link to="/catalog/video-covers" className={styles.link}>Обложки для видео</Link>
          <Link to="/catalog/avatars-icons" className={styles.link}>Аватарки и иконки</Link>
          <Link to="/catalog/stream-banners" className={styles.link}>Баннеры для стримов</Link>
          <Link to="/catalog/social-banners" className={styles.link}>Шапки для соцсетей</Link>
        </div>
        <div className={styles.column}>
          <h4 className={styles.columnTitle}>Правовая информация</h4>
          <Link to="/license" className={styles.link}>Лицензия</Link>
          <Link to="/terms" className={styles.link}>Условия использования</Link>
          <Link to="/privacy" className={styles.link}>Политика конфиденциальности</Link>
          <Link to="/cookie-policy" className={styles.link}>Политика использования cookie</Link>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <div className="container">
        <p className={styles.copy}>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
      </div>
    </div>
  </footer>
);

export default Footer;