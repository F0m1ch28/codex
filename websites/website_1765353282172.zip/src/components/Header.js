import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Главная' },
  { to: '/catalog', label: 'Каталог' },
  { to: '/services', label: 'Сервисы' },
  { to: '/how-it-works', label: 'Как это работает' },
  { to: '/about', label: 'О нас' },
  { to: '/license', label: 'Лицензия' },
  { to: '/contacts', label: 'Контакты' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);

  React.useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [menuOpen]);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link to="/" className={styles.logo} aria-label="DigitalCovers">
          <span className={styles.logoMark}>DC</span>
          <span className={styles.logoText}>DigitalCovers</span>
        </Link>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
              }
              onClick={closeMenu}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className={styles.actions}>
          <Link to="/catalog" className={styles.cta}>
            Смотреть каталог
          </Link>
          <button
            className={styles.mobileToggle}
            onClick={handleToggle}
            aria-expanded={menuOpen}
            aria-controls="primary-navigation"
            aria-label="Переключить меню"
          >
            <span className={styles.toggleBar} />
            <span className={styles.toggleBar} />
            <span className={styles.toggleBar} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;