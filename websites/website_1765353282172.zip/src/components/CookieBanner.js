import React from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'digitalcovers_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h3 className={styles.title}>Мы используем cookie</h3>
        <p className={styles.text}>
          Cookie помогают сделать DigitalCovers удобнее: мы анализируем трафик и сохраняем настройки. Подробнее — в{' '}
          <a href="/cookie-policy" className={styles.link}>
            политике cookie
          </a>
          .
        </p>
      </div>
      <div className={styles.actions}>
        <button className={styles.decline} onClick={() => handleConsent('declined')}>
          Отклонить
        </button>
        <button className={styles.accept} onClick={() => handleConsent('accepted')}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;