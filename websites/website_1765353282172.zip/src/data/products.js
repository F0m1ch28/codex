export const products = [
  {
    id: 'neo-wave-intro',
    name: 'Neo Wave Intro Pack',
    category: 'video-covers',
    categoryName: 'Обложки для видео',
    image: 'https://picsum.photos/seed/neo-wave-intro/960/640',
    description:
      'Темная неоновая палитра с сочными градиентами и синхронной типографикой для динамичных видео.',
    features: [
      'PSD и Figma-файлы с полностью редактируемыми слоями',
      'Сетки для форматов 16:9 и 9:16',
      'Встроенный пакет из 6 отдельных обложек'
    ],
    tags: ['YouTube', 'Неон', 'Динамика']
  },
  {
    id: 'pulse-stream-banner',
    name: 'Pulse Stream Banner Set',
    category: 'stream-banners',
    categoryName: 'Баннеры для стримов',
    image: 'https://picsum.photos/seed/pulse-stream-banner/960/640',
    description:
      'Комплект адаптивных панелей и оффлайн-баннеров с глитч-эффектами для стримеров.',
    features: [
      '12 панелей для Twitch и Trovo',
      'Шаблоны оффлайн и starting soon',
      'Слои с настраиваемыми анимационными эффектами'
    ],
    tags: ['Twitch', 'Glitch', 'Streaming']
  },
  {
    id: 'stellar-avatar-pack',
    name: 'Stellar Avatar Pack',
    category: 'avatars-icons',
    categoryName: 'Аватарки и иконки',
    image: 'https://picsum.photos/seed/stellar-avatar-pack/960/640',
    description:
      'Коллекция космических аватаров и иконок для каналов, подкастов и социальных сетей.',
    features: [
      '20 вариантов аватаров в PNG и SVG',
      'Цветовые палитры для брендирования',
      'Готовые mockup-файлы для презентации'
    ],
    tags: ['Подкаст', 'Космос', 'Иконки']
  },
  {
    id: 'aura-social-suite',
    name: 'Aura Social Suite',
    category: 'social-banners',
    categoryName: 'Шапки для соцсетей',
    image: 'https://picsum.photos/seed/aura-social-suite/960/640',
    description:
      'Универсальные шапки и посты для Telegram, VK и LinkedIn с акцентом на технологичный стиль.',
    features: [
      'Файлы в форматах PSD, Sketch и XD',
      'Настраиваемые сетки для основных соцсетей',
      'Типографические стили с поддержкой кириллицы'
    ],
    tags: ['Telegram', 'Бизнес', 'Минимализм']
  },
  {
    id: 'retro-wave-cover',
    name: 'Retro Wave Cover Pack',
    category: 'video-covers',
    categoryName: 'Обложки для видео',
    image: 'https://picsum.photos/seed/retro-wave-cover/960/640',
    description:
      'Набор обложек в стиле ретровейв с яркими градиентами и сочными закатами.',
    features: [
      '5 композиций в формате PSD и PNG',
      'Палитра в стиле Synthwave',
      'Адаптация под YouTube Shorts'
    ],
    tags: ['Retro', 'Synthwave', 'Shorts']
  },
  {
    id: 'nightfall-stream-kit',
    name: 'Nightfall Stream Kit',
    category: 'stream-banners',
    categoryName: 'Баннеры для стримов',
    image: 'https://picsum.photos/seed/nightfall-stream-kit/960/640',
    description:
      'Контрастный тёмный набор оффлайн и стартовых сцен с акцентом на читаемость текста.',
    features: [
      'Файлы OBS и Streamlabs OVL',
      'Слои для смены иллюстраций',
      'Комплект алертов в PNG'
    ],
    tags: ['OBS', 'Night mode', 'Streamer']
  },
  {
    id: 'minimalist-avatar-grid',
    name: 'Minimalist Avatar Grid',
    category: 'avatars-icons',
    categoryName: 'Аватарки и иконки',
    image: 'https://picsum.photos/seed/minimalist-avatar-grid/960/640',
    description:
      'Минималистичные штриховые аватарки и бейджи, идеально подходящие брендам в социальных сетях.',
    features: [
      'Символьные сетки 1:1 и 4:5',
      'Палитра в формате ASE',
      'Векторные исходники в AI и SVG'
    ],
    tags: ['Minimal', 'Badge', 'Vector']
  },
  {
    id: 'horizon-social-kit',
    name: 'Horizon Social Kit',
    category: 'social-banners',
    categoryName: 'Шапки для соцсетей',
    image: 'https://picsum.photos/seed/horizon-social-kit/960/640',
    description:
      'Лёгкие воздушные композиции для каналов о путешествиях, lifestyle и wellbeing.',
    features: [
      '10 вариантов для разных платформ',
      'Текстовые стили с кириллицей и латиницей',
      'Готовые mockup для презентаций'
    ],
    tags: ['Travel', 'Lifestyle', 'Branding']
  }
];