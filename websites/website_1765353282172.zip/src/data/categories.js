export const categories = [
  {
    slug: 'video-covers',
    title: 'Обложки для видео',
    description:
      'Выразительные заставки и превью для роликов на YouTube, RuTube, VK Видео и других площадках.',
    image: 'https://picsum.photos/seed/digitalcovers-video/800/560',
    accent: '#6366f1'
  },
  {
    slug: 'avatars-icons',
    title: 'Аватарки и иконки',
    description:
      'Подпишите ваши каналы, подкасты и сообщества узнаваемыми аватарами и иконками.',
    image: 'https://picsum.photos/seed/digitalcovers-avatars/800/560',
    accent: '#8b5cf6'
  },
  {
    slug: 'stream-banners',
    title: 'Баннеры для стримов',
    description:
      'Оформление оффлайн-баннеров, панелей и превью для стримеров Twitch, Trovo, VK Play Live.',
    image: 'https://picsum.photos/seed/digitalcovers-stream/800/560',
    accent: '#06b6d4'
  },
  {
    slug: 'social-banners',
    title: 'Шапки для соцсетей',
    description:
      'Адаптивные шапки и карусели для YouTube, Telegram-каналов, Twitter, LinkedIn и других соцсетей.',
    image: 'https://picsum.photos/seed/digitalcovers-social/800/560',
    accent: '#14b8a6'
  }
];