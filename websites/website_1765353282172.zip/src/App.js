import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import VideoCovers from './pages/VideoCovers';
import AvatarsIcons from './pages/AvatarsIcons';
import StreamBanners from './pages/StreamBanners';
import SocialBanners from './pages/SocialBanners';
import ProductPage from './pages/ProductPage';
import About from './pages/About';
import HowItWorks from './pages/HowItWorks';
import License from './pages/License';
import Contacts from './pages/Contacts';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import Services from './pages/Services';
import styles from './App.module.css';

const RouteScrollToTop = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [pathname]);

  return null;
};

function App() {
  return (
    <div className={styles.app}>
      <Header />
      <CookieBanner />
      <ScrollToTopButton />
      <main className={styles.main}>
        <RouteScrollToTop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/catalog/video-covers" element={<VideoCovers />} />
          <Route path="/catalog/avatars-icons" element={<AvatarsIcons />} />
          <Route path="/catalog/stream-banners" element={<StreamBanners />} />
          <Route path="/catalog/social-banners" element={<SocialBanners />} />
          <Route path="/product/:productId" element={<ProductPage />} />
          <Route path="/about" element={<About />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route path="/license" element={<License />} />
          <Route path="/contacts" element={<Contacts />} />
          <Route path="/services" element={<Services />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;