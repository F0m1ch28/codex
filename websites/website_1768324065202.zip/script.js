document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    const cookieBanner = document.getElementById("cookieBanner");
    const cookieButtons = document.querySelectorAll(".cookie-btn");
    const subscribeForm = document.getElementById("subscribeForm");
    const contactForm = document.getElementById("contactForm");
    const searchInput = document.getElementById("searchInput");
    const filterChips = document.querySelectorAll(".chip[data-category]");
    const paginationButtons = document.querySelectorAll(".pagination-button");
    const articles = document.querySelectorAll("[data-article]");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navLinks.classList.toggle("active");
            navToggle.setAttribute(
                "aria-expanded",
                navLinks.classList.contains("active")
            );
        });

        navLinks.addEventListener("click", (event) => {
            if (event.target.matches("a")) {
                navLinks.classList.remove("active");
            }
        });
    }

    const storedCookieChoice = localStorage.getItem("bureauwzhvCookieChoice");
    if (!storedCookieChoice && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    if (cookieButtons.length && cookieBanner) {
        cookieButtons.forEach((btn) => {
            btn.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = btn.dataset.choice || "dismissed";
                localStorage.setItem("bureauwzhvCookieChoice", choice);
                cookieBanner.classList.remove("active");
                window.location.href = btn.getAttribute("href");
            });
        });
    }

    function redirectToThanks() {
        window.location.href = "thanks.html";
    }

    if (subscribeForm) {
        subscribeForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const emailInput = subscribeForm.querySelector("input[type='email']");
            if (!emailInput || !emailInput.value.trim()) {
                emailInput.focus();
                return;
            }
            redirectToThanks();
        });
    }

    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            const requiredFields = contactForm.querySelectorAll("[required]");
            for (const field of requiredFields) {
                if (!field.value.trim()) {
                    field.focus();
                    return;
                }
            }
            redirectToThanks();
        });
    }

    function applyFilters() {
        const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : "";
        const activeChip = document.querySelector(".chip[data-category].active");
        const activeCategory = activeChip ? activeChip.dataset.category : "all";

        articles.forEach((article) => {
            const title = article.querySelector(".card-title")?.textContent.toLowerCase() || "";
            const excerpt = article.querySelector(".card-snippet")?.textContent.toLowerCase() || "";
            const category = article.dataset.article || "";
            const matchesSearch = title.includes(searchTerm) || excerpt.includes(searchTerm);
            const matchesCategory = activeCategory === "all" || category === activeCategory;
            const isVisible = matchesSearch && matchesCategory;
            article.style.display = isVisible ? "" : "none";
        });
        applyPagination();
    }

    if (filterChips.length) {
        filterChips.forEach((chip) => {
            chip.addEventListener("click", () => {
                filterChips.forEach((c) => c.classList.remove("active"));
                chip.classList.add("active");
                applyFilters();
            });
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", () => {
            applyFilters();
        });
    }

    function applyPagination() {
        if (!paginationButtons.length) return;
        let activePage = document.querySelector(".pagination-button.active");
        const pageNumber = activePage ? Number(activePage.dataset.page) : 1;
        const visibleArticles = Array.from(articles).filter((article) => article.style.display !== "none");
        const perPage = 6;
        visibleArticles.forEach((article, index) => {
            const pageIndex = Math.floor(index / perPage) + 1;
            article.dataset.pageIndex = pageIndex;
            article.style.display = pageIndex === pageNumber ? "" : "none";
        });
    }

    if (paginationButtons.length) {
        paginationButtons.forEach((button) => {
            button.addEventListener("click", () => {
                paginationButtons.forEach((btn) => btn.classList.remove("active"));
                button.classList.add("active");
                applyPagination();
            });
        });
        applyPagination();
    }

    const lazyImages = document.querySelectorAll("img[loading='lazy']");
    if ("IntersectionObserver" in window && lazyImages.length) {
        const lazyObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    const dataSrc = img.getAttribute("data-src");
                    if (dataSrc) {
                        img.src = dataSrc;
                        img.removeAttribute("data-src");
                    }
                    observer.unobserve(img);
                }
            });
        }, { rootMargin: "80px" });

        lazyImages.forEach((img) => lazyObserver.observe(img));
    }
});