document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const navToggle = document.querySelector('[data-nav-toggle]');
    const navMenu = document.querySelector('[data-nav-menu]');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
            if (isOpen) {
                navMenu.querySelector('a')?.focus();
            } else {
                navToggle.focus();
            }
        });
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('[data-cookie-banner]');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('cookieChoice');
        if (!storedChoice) {
            setTimeout(() => {
                cookieBanner.classList.add('is-visible');
            }, 800);
        }
        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(anchor => {
            anchor.addEventListener('click', () => {
                const action = anchor.dataset.cookieAction || 'undecided';
                localStorage.setItem('cookieChoice', action);
                cookieBanner.classList.remove('is-visible');
            });
        });
    }

    document.querySelectorAll('[data-neural-network]').forEach(container => {
        const canvas = container.querySelector('.neural-field');
        if (!canvas) {
            return;
        }
        const nodeCount = Number(container.dataset.neuralNetwork) || 24;
        const nodes = [];
        for (let i = 0; i < nodeCount; i += 1) {
            const node = document.createElement('span');
            node.className = 'neuron-node';
            const left = Math.random() * 100;
            const top = Math.random() * 100;
            node.style.left = `${left}%`;
            node.style.top = `${top}%`;
            node.style.animationDelay = `${Math.random() * 4}s`;
            canvas.appendChild(node);
            nodes.push({ element: node, left, top });
        }
        const connectionCount = Math.min(60, nodeCount * 3);
        for (let j = 0; j < connectionCount; j += 1) {
            const source = nodes[Math.floor(Math.random() * nodes.length)];
            const target = nodes[Math.floor(Math.random() * nodes.length)];
            if (!source || !target || source === target) {
                continue;
            }
            const connection = document.createElement('span');
            connection.className = 'neuron-connection';
            const dx = target.left - source.left;
            const dy = target.top - source.top;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const angle = Math.atan2(dy, dx) * (180 / Math.PI);
            connection.style.left = `${source.left}%`;
            connection.style.top = `${source.top}%`;
            connection.style.height = `${distance}%`;
            connection.style.transform = `rotate(${angle}deg)`;
            connection.style.opacity = (Math.random() * 0.4 + 0.1).toFixed(2);
            canvas.appendChild(connection);
        }
    });

    const openModal = modal => {
        modal.classList.add('is-visible');
        modal.setAttribute('aria-hidden', 'false');
        body.classList.add('has-modal');
        const focusable = modal.querySelector('button, [href], input, textarea, select');
        focusable?.focus();
    };

    const closeModal = modal => {
        modal.classList.remove('is-visible');
        modal.setAttribute('aria-hidden', 'true');
        body.classList.remove('has-modal');
    };

    document.querySelectorAll('[data-modal-target]').forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.dataset.modalTarget;
            const modal = document.getElementById(targetId);
            if (modal) {
                openModal(modal);
            }
        });
    });

    document.querySelectorAll('[data-modal-close]').forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal');
            if (modal) {
                closeModal(modal);
            }
        });
    });

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', evt => {
            if (evt.target === modal) {
                closeModal(modal);
            }
        });
        modal.addEventListener('keyup', evt => {
            if (evt.key === 'Escape') {
                closeModal(modal);
            }
        });
    });

    const filterGroups = document.querySelectorAll('[data-filter-group]');
    filterGroups.forEach(group => {
        const buttons = group.querySelectorAll('[data-filter]');
        const itemsSelector = group.dataset.filterGroup;
        const items = document.querySelectorAll(itemsSelector);
        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const value = button.dataset.filter;
                buttons.forEach(b => b.classList.remove('is-active'));
                button.classList.add('is-active');
                items.forEach(item => {
                    if (value === 'all' || item.dataset.category === value) {
                        item.classList.remove('is-hidden');
                    } else {
                        item.classList.add('is-hidden');
                    }
                });
            });
        });
    });

    document.querySelectorAll('[data-infograph]').forEach(block => {
        const toggle = block.querySelector('[data-infograph-toggle]');
        const details = block.querySelector('.infographic-details');
        if (toggle && details) {
            toggle.addEventListener('click', () => {
                const isActive = block.classList.toggle('is-active');
                toggle.setAttribute('aria-expanded', String(isActive));
            });
        }
    });
});