import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Breeds.module.css';

const breedsData = [
  {
    name: 'Мейн-кун',
    size: 'Крупная',
    coat: 'Длинная',
    character: 'Ласковая, уравновешенная',
    image:
      'https://images.unsplash.com/photo-1543852786-1cf6624b9987?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Британская короткошерстная',
    size: 'Средняя',
    coat: 'Короткая',
    character: 'Спокойная, независимая',
    image:
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Сфинкс',
    size: 'Средняя',
    coat: 'Без шерсти',
    character: 'Общительная, нежная',
    image:
      'https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Сиамская',
    size: 'Средняя',
    coat: 'Короткая',
    character: 'Разговорчивая, активная',
    image:
      'https://images.unsplash.com/photo-1508672019048-805c876b67e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Бенгальская',
    size: 'Средняя',
    coat: 'Короткая',
    character: 'Игривый охотник',
    image:
      'https://images.unsplash.com/photo-1519052537078-e6302a4968d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Русская голубая',
    size: 'Средняя',
    coat: 'Короткая',
    character: 'Тактичная, спокойная',
    image:
      'https://images.unsplash.com/photo-1519710164239-da123dc03ef4?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Абиссинская',
    size: 'Средняя',
    coat: 'Короткая',
    character: 'Энергичная, любознательная',
    image:
      'https://images.unsplash.com/photo-1625316708584-10a6f9f9252f?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Сибирская',
    size: 'Крупная',
    coat: 'Длинная',
    character: 'Отважная, дружелюбная',
    image:
      'https://images.unsplash.com/photo-1489844097929-c8d5b91c456e?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Рэгдолл',
    size: 'Крупная',
    coat: 'Полудлинная',
    character: 'Нежная, ориентирована на человека',
    image:
      'https://images.unsplash.com/photo-1611068799904-9c78d86978c9?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  },
  {
    name: 'Шотландская вислоухая',
    size: 'Средняя',
    coat: 'Короткая/полудлинная',
    character: 'Мягкая, спокойная',
    image:
      'https://images.unsplash.com/photo-1596854307943-279f1cb11e3d?ixlib=rb-4.0.3&auto=format&fit=crop&w=640&q=80'
  }
];

const BreedsPage = () => {
  const [query, setQuery] = useState('');

  const filteredBreeds = useMemo(() => {
    const lowerQuery = query.trim().toLowerCase();
    return breedsData.filter((breed) =>
      breed.name.toLowerCase().includes(lowerQuery)
    );
  }, [query]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Породы кошек — Мир Кошек</title>
        <meta
          name="description"
          content="Кatalog пород кошек: характеристики, тип шерсти, темперамент и рекомендации по уходу."
        />
      </Helmet>
      <section className={styles.header}>
        <h1>Породы кошек</h1>
        <p>
          Узнайте, чем отличаются популярные породы, чтобы подобрать компаньона,
          соответствующего вашему образу жизни.
        </p>
        <label htmlFor="breed-search" className={styles.searchLabel}>
          <span className="visually-hidden">Поиск по породе</span>
          <input
            id="breed-search"
            type="search"
            placeholder="Найдите породу по названию"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            className={styles.searchInput}
          />
        </label>
      </section>
      <section className={styles.grid}>
        {filteredBreeds.map((breed) => (
          <article key={breed.name} className={styles.card}>
            <img
              src={breed.image}
              alt={"Кошка породы ${breed.name}"}
              className={styles.image}
              loading="lazy"
            />
            <div className={styles.cardContent}>
              <h2>{breed.name}</h2>
              <ul className={styles.infoList}>
                <li>
                  <strong>Размер:</strong> {breed.size}
                </li>
                <li>
                  <strong>Шерсть:</strong> {breed.coat}
                </li>
                <li>
                  <strong>Характер:</strong> {breed.character}
                </li>
              </ul>
            </div>
          </article>
        ))}
        {filteredBreeds.length === 0 && (
          <p className={styles.emptyState}>
            Мы пока не описали такую породу. Попробуйте изменить запрос.
          </p>
        )}
      </section>
    </div>
  );
};

export default BreedsPage;