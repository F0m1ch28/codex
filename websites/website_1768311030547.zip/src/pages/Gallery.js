import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Gallery.module.css';

const galleryImages = [
  {
    url: 'https://images.unsplash.com/photo-1504203700686-0f3b3deb1977?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Сфинкс в тёплом свитере'
  },
  {
    url: 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Британский кот на оранжевом фоне'
  },
  {
    url: 'https://images.unsplash.com/photo-1514888286974-6d03bde4ba4?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Рыжий котёнок играет с прутиком'
  },
  {
    url: 'https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Пушистый кот при солнечном свете'
  },
  {
    url: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Кошка в профиль смотрит вдаль'
  },
  {
    url: 'https://images.unsplash.com/photo-1559235038-1b511a996f57?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Кот в зелёном поле'
  },
  {
    url: 'https://images.unsplash.com/photo-1516214104705-6f87b7b3cd90?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Белый кот и яркий фон'
  },
  {
    url: 'https://images.unsplash.com/photo-1425082661705-1834bfd09dca?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Серый кот отдыхает на пледе'
  },
  {
    url: 'https://images.unsplash.com/photo-1574158622682-e40e69881006?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Коллекция разноцветных котят'
  },
  {
    url: 'https://images.unsplash.com/photo-1511044568932-338cba0ad803?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Мейн-кун лежит на кровати'
  },
  {
    url: 'https://images.unsplash.com/photo-1543852786-1cf6624b9987?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Пушистый кот в зимнем лесу'
  },
  {
    url: 'https://images.unsplash.com/photo-1580738826664-cf2c99315878?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Котёнок в корзинке'
  },
  {
    url: 'https://images.unsplash.com/photo-1568152950566-c1bf43f4ab28?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Сиамская кошка на подоконнике'
  },
  {
    url: 'https://images.unsplash.com/photo-1586042091266-1acbfc70b1fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Котёнок играет с растениями'
  },
  {
    url: 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Два котёнка спят рядом'
  },
  {
    url: 'https://images.unsplash.com/photo-1595433562696-a8b1cb8d6365?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Белая кошка среди цветов'
  },
  {
    url: 'https://images.unsplash.com/photo-1581804928342-4e3405e39c91?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Серый котёнок с большими глазами'
  },
  {
    url: 'https://images.unsplash.com/photo-1510414696678-2415ad8474aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Кошка с разноцветными глазами'
  },
  {
    url: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Фотогеничный кот с шарфом'
  },
  {
    url: 'https://images.unsplash.com/photo-1568834904496-627699075748?ixlib=rb-4.0.3&auto=format&fit=crop&w=900&q=80',
    alt: 'Котёнок выглядывает из одеяла'
  }
];

const GalleryPage = () => {
  const [selectedImage, setSelectedImage] = useState(null);

  const handleOpenModal = (image) => {
    setSelectedImage(image);
  };

  const handleCloseModal = () => {
    setSelectedImage(null);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Галерея — Мир Кошек</title>
        <meta
          name="description"
          content="Подборка вдохновляющих фотографий кошек со всего мира. Нажмите на изображение, чтобы рассмотреть детали."
        />
      </Helmet>
      <header className={styles.header}>
        <h1>Галерея</h1>
        <p>
          Наслаждайтесь моментами, которые дарят кошки: их искренностью,
          игривостью и безусловной любовью к дому.
        </p>
      </header>
      <div className={styles.gallery}>
        {galleryImages.map((image) => (
          <button
            key={image.url}
            type="button"
            className={styles.galleryItem}
            onClick={() => handleOpenModal(image)}
          >
            <img src={image.url} alt={image.alt} loading="lazy" />
          </button>
        ))}
      </div>

      {selectedImage && (
        <div
          className={styles.modal}
          role="dialog"
          aria-modal="true"
          aria-label="Просмотр увеличенного изображения"
        >
          <div className={styles.modalContent}>
            <button
              type="button"
              onClick={handleCloseModal}
              className={styles.modalClose}
              aria-label="Закрыть изображение"
            >
              ×
            </button>
            <img src={selectedImage.url} alt={selectedImage.alt} />
            <p className={styles.modalCaption}>{selectedImage.alt}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default GalleryPage;