import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYouPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Спасибо за сообщение — Мир Кошек</title>
      <meta
        name="description"
        content="Спасибо, что связались с порталом «Мир Кошек». Мы ценим ваше доверие и ответим в ближайшее время."
      />
    </Helmet>
    <div className={styles.card}>
      <h1>Спасибо!</h1>
      <p>
        Ваше сообщение отправлено команде «Мир Кошек». Мы внимательно прочтём его
        и скоро ответим.
      </p>
      <Link to="/" className={styles.button}>
        Вернуться на главную
      </Link>
    </div>
  </div>
);

export default ThankYouPage;