import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const popularBreeds = [
  {
    name: 'Мейн-кун',
    description:
      'Крупная, добродушная кошка с роскошной шерстью и интеллигентными манерами.',
    image:
      'https://images.unsplash.com/photo-1511044568932-338cba0ad803?ixlib=rb-4.0.3&auto=format&fit=crop&w=700&q=80'
  },
  {
    name: 'Британская короткошерстная',
    description:
      'Спокойный характер, плюшевая шерсть и безграничная преданность людям.',
    image:
      'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-4.0.3&auto=format&fit=crop&w=700&q=80'
  },
  {
    name: 'Сфинкс',
    description:
      'Порода без шерсти с открытым взглядом и невероятно нежным темпераментом.',
    image:
      'https://images.unsplash.com/photo-1504203700686-0f3b3deb1977?ixlib=rb-4.0.3&auto=format&fit=crop&w=700&q=80'
  },
  {
    name: 'Сибирская',
    description:
      'Сильная и гармоничная кошка, отлично приспосабливается к семье и детям.',
    image:
      'https://images.unsplash.com/photo-1611064146893-44bbc37349c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=700&q=80'
  }
];

const interestingFacts = [
  'Кошки различают голоса людей и чаще откликаются на мягкие интонации.',
  'Усы помогают кошкам оценивать ширину пространства и даже направление ветра.',
  'Кошки спят до 16 часов в сутки, но в любой момент готовы к активным играм.',
  'Шерсть кошек естественным образом отталкивает воду благодаря микроструктуре.',
  'Кошачье мурлыканье способствует заживлению тканей благодаря вибрациям.',
  'Кошки могут помнить приятные события и выражать признательность ласками.'
];

const previewGallery = [
  'https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1518020382113-a7e8fc38eac9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1504595403659-9088ce801e29?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1543852786-1cf6624b9987?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1514516430032-7f40ed986a80?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
];

const testimonials = [
  {
    quote:
      'Благодаря порталу я нашла ветеринарную клинику и смогла подобрать питание для своей кошки Муры. Удобно и очень душевно.',
    author: 'Анна, Москва',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  },
  {
    quote:
      'Статьи о поведении помогли понять характер моего кота. Теперь мы лучше слышим друг друга.',
    author: 'Игорь, Санкт-Петербург',
    image:
      'https://images.unsplash.com/photo-1504595403659-9088ce801e29?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  },
  {
    quote:
      'Галерея с фото вдохновила меня на съемку домашнего фотоальбома. Спасибо за идеи!',
    author: 'Марина, Казань',
    image:
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80'
  }
];

const HomePage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Мир Кошек — Главная</title>
      <meta
        name="description"
        content="Портал «Мир Кошек»: породы, уход, здоровье, вдохновляющие истории и полезные советы для владельцев кошек."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className={styles.heroContent}>
        <h1 className={styles.heroTitle}>Добро пожаловать в мир кошек</h1>
        <p className={styles.heroSubtitle}>
          Здесь живут истории о дружбе и заботе. Узнайте, как сделать жизнь
          вашей кошки ещё счастливее.
        </p>
        <Link to="/breeds" className={styles.ctaButton}>
          Узнать больше
        </Link>
      </div>
      <div className={styles.heroImage} role="presentation" />
    </section>

    <section className={styles.breedsSection}>
      <div className={styles.sectionHeader}>
        <h2>Популярные породы</h2>
        <p>
          Мы собрали проверенную информацию о темпераменте, уходе и особенностях
          любимых пород.
        </p>
      </div>
      <div className={styles.breedsGrid}>
        {popularBreeds.map((breed) => (
          <article key={breed.name} className={styles.breedCard}>
            <img
              src={breed.image}
              alt={"Порода ${breed.name}"}
              className={styles.breedImage}
              loading="lazy"
            />
            <div className={styles.breedContent}>
              <h3>{breed.name}</h3>
              <p>{breed.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className={styles.factsSection}>
      <div className={styles.sectionHeader}>
        <h2>Интересные факты</h2>
        <p>
          Делимся открытиями о кошках, которые вы можете применить в повседневной
          заботе.
        </p>
      </div>
      <ul className={styles.factsList}>
        {interestingFacts.map((fact, index) => (
          <li key={fact} className={styles.factItem}>
            <span className={styles.factNumber}>{index + 1}</span>
            <p>{fact}</p>
          </li>
        ))}
      </ul>
    </section>

    <section className={styles.careSection}>
      <div className={styles.careText}>
        <h2>Советы по уходу</h2>
        <p>
          Подготовили практичные рекомендации по питанию, грумингу и созданию
          уютного пространства. Каждая статья основана на мнении специалистов и
          опыте владельцев.
        </p>
        <Link to="/care" className={styles.secondaryButton}>
          Перейти к советам
        </Link>
      </div>
      <div className={styles.careImage} role="presentation" />
    </section>

    <section className={styles.testimonialsSection}>
      <div className={styles.sectionHeader}>
        <h2>Истории наших читателей</h2>
        <p>
          Нам доверяют семьи из разных уголков страны. Их добрые слова вдохновляют
          нас развивать портал.
        </p>
      </div>
      <div className={styles.testimonialsGrid}>
        {testimonials.map((item) => (
          <blockquote key={item.author} className={styles.testimonialCard}>
            <img
              src={item.image}
              alt={"Фото читателя: ${item.author}"}
              className={styles.testimonialImage}
              loading="lazy"
            />
            <p className={styles.testimonialQuote}>“{item.quote}”</p>
            <cite className={styles.testimonialAuthor}>{item.author}</cite>
          </blockquote>
        ))}
      </div>
    </section>

    <section className={styles.gallerySection}>
      <div className={styles.sectionHeader}>
        <h2>Галерея вдохновения</h2>
        <p>
          Улыбнитесь вместе с котиками со всего света и делитесь своими снимками.
        </p>
      </div>
      <div className={styles.galleryGrid}>
        {previewGallery.map((imageUrl, index) => (
          <Link
            to="/gallery"
            key={imageUrl}
            className={styles.galleryItem}
            aria-label={"Открыть галерею, фото ${index + 1}"}
          >
            <img src={imageUrl} alt={"Фотография кошки ${index + 1}"} />
          </Link>
        ))}
      </div>
    </section>

    <section className={styles.contactsSection}>
      <div className={styles.contactsCard}>
        <h2>Наши контакты</h2>
        <p>
          Присоединяйтесь к сообществу «Мир Кошек». Мы открыты к партнёрству,
          готовы ответить на вопросы и поддержать вас.
        </p>
        <ul className={styles.contactsList}>
          <li>г. Москва, ул. Кошачья, д. 15, офис 9</li>
          <li>+7 (495) 123-45-67</li>
          <li>info@mir-koshek.ru</li>
        </ul>
        <Link to="/contacts" className={styles.ctaButton}>
          Написать нам
        </Link>
      </div>
    </section>
  </div>
);

export default HomePage;