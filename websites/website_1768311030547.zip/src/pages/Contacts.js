import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import styles from './Contacts.module.css';

const initialState = {
  name: '',
  email: '',
  subject: '',
  message: ''
};

const ContactsPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (formData.name.trim().length < 2) {
      newErrors.name = 'Укажите имя не короче двух символов.';
    }
    if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email.trim())
    ) {
      newErrors.email = 'Введите корректный email.';
    }
    if (formData.subject.trim().length < 3) {
      newErrors.subject = 'Тема сообщения должна содержать минимум 3 символа.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message =
        'Сообщение должно быть информативным: не менее 10 символов.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      navigate('/thank-you');
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты — Мир Кошек</title>
        <meta
          name="description"
          content="Свяжитесь с командой портала «Мир Кошек»: адрес в Москве, телефон, email и удобная контактная форма."
        />
      </Helmet>
      <header className={styles.header}>
        <h1>Связаться с нами</h1>
        <p>
          Мы ценим ваши истории и вопросы. Заполните форму или воспользуйтесь
          контактами — ответим в ближайшее время.
        </p>
      </header>
      <div className={styles.container}>
        <section className={styles.info}>
          <h2>Контактные данные</h2>
          <ul className={styles.infoList}>
            <li>
              <strong>Адрес:</strong> г. Москва, ул. Кошачья, д. 15, офис 9
            </li>
            <li>
              <strong>Телефон:</strong> +7 (495) 123-45-67
            </li>
            <li>
              <strong>Email:</strong> info@mir-koshek.ru
            </li>
          </ul>
          <p>
            Делитесь своими историями, предлагайте темы для статей или
            присылайте фотографии питомцев — мы с радостью расскажем о них.
          </p>
        </section>
        <section className={styles.formSection}>
          <h2>Написать сообщение</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <label className={styles.label} htmlFor="name">
              Имя
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                className={"${styles.input} ${
                  errors.name ? styles.inputError : ''
                }"}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.errorText}>
                  {errors.name}
                </span>
              )}
            </label>

            <label className={styles.label} htmlFor="email">
              Email
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                className={"${styles.input} ${
                  errors.email ? styles.inputError : ''
                }"}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.errorText}>
                  {errors.email}
                </span>
              )}
            </label>

            <label className={styles.label} htmlFor="subject">
              Тема сообщения
              <input
                id="subject"
                name="subject"
                type="text"
                value={formData.subject}
                onChange={handleChange}
                className={"${styles.input} ${
                  errors.subject ? styles.inputError : ''
                }"}
                aria-invalid={Boolean(errors.subject)}
                aria-describedby={errors.subject ? 'subject-error' : undefined}
              />
              {errors.subject && (
                <span id="subject-error" className={styles.errorText}>
                  {errors.subject}
                </span>
              )}
            </label>

            <label className={styles.label} htmlFor="message">
              Сообщение
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                className={"${styles.textarea} ${
                  errors.message ? styles.inputError : ''
                }"}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.errorText}>
                  {errors.message}
                </span>
              )}
            </label>

            <button type="submit" className={styles.submitButton}>
              Отправить
            </button>
          </form>
        </section>
      </div>
    </div>
  );
};

export default ContactsPage;