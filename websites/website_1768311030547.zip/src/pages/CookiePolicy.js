import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования cookie — Мир Кошек</title>
      <meta
        name="description"
        content="Узнайте, какие cookie-файлы использует портал «Мир Кошек» и как управлять настройками."
      />
    </Helmet>
    <h1>Политика использования cookie</h1>
    <p>
      Cookie помогают нам улучшать работу портала и понимать, какие разделы
      наиболее полезны. Вы можете изменить своё решение в настройках браузера.
    </p>
    <h2>Типы cookie</h2>
    <ul>
      <li>
        <strong>Обязательные:</strong> обеспечивают корректную работу форм и
        навигации.
      </li>
      <li>
        <strong>Аналитические:</strong> помогают понимать интересы читателей и
        улучшать контент.
      </li>
      <li>
        <strong>Функциональные:</strong> запоминают ваши предпочтения.
      </li>
    </ul>
    <h2>Управление настройками</h2>
    <p>
      Вы можете отключить cookie в настройках браузера. Помните, что это может
      повлиять на работу некоторых функций портала.
    </p>
  </div>
);

export default CookiePolicyPage;