import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="На главную страницу">
          <span className={styles.logoIcon} aria-hidden="true">
            🐾
          </span>
          <span className={styles.logoText}>Мир Кошек</span>
        </Link>
        <button
          type="button"
          className={styles.burger}
          onClick={handleToggleMenu}
          aria-label={isMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={isMenuOpen}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          className={"${styles.nav} ${isMenuOpen ? styles.navOpen : ''}"}
          aria-label="Основная навигация"
        >
          <NavLink
            to="/"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ''}"
            }
            onClick={closeMenu}
          >
            Главная
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ''}"
            }
            onClick={closeMenu}
          >
            О нас
          </NavLink>
          <NavLink
            to="/breeds"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ''}"
            }
            onClick={closeMenu}
          >
            Породы
          </NavLink>
          <NavLink
            to="/care"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ''}"
            }
            onClick={closeMenu}
          >
            Уход
          </NavLink>
          <NavLink
            to="/health"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ''}"
            }
            onClick={closeMenu}
          >
            Здоровье
          </NavLink>
          <NavLink
            to="/gallery"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ''}"
            }
            onClick={closeMenu}
          >
            Галерея
          </NavLink>
          <NavLink
            to="/contacts"
            className={({ isActive }) =>
              "${styles.navLink} ${isActive ? styles.active : ''}"
            }
            onClick={closeMenu}
          >
            Контакты
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;