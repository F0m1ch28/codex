import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'cat-world-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const savedConsent = window.localStorage.getItem(STORAGE_KEY);
    if (!savedConsent) {
      setIsVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem(STORAGE_KEY, value);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.text}>
          Мы используем cookie, чтобы сделать навигацию по порталу «Мир Кошек»
          удобнее. Вы можете изменить решение в любое время в политике cookie.
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={"${styles.button} ${styles.accept}"}
            onClick={() => handleConsent('accepted')}
          >
            Принять
          </button>
          <button
            type="button"
            className={"${styles.button} ${styles.decline}"}
            onClick={() => handleConsent('declined')}
          >
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;