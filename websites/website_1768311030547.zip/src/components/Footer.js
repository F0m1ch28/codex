import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.brandBlock}>
        <Link to="/" className={styles.logo} aria-label="На главную страницу">
          <span className={styles.logoIcon} aria-hidden="true">
            🐾
          </span>
          <span className={styles.logoText}>Мир Кошек</span>
        </Link>
        <p className={styles.description}>
          Теплый информационный портал для ответственных владельцев и любителей
          кошек. Мы делимся опытом, поддерживаем заботу и вдохновляем историями.
        </p>
      </div>
      <div className={styles.linksBlock}>
        <h3 className={styles.heading}>Навигация</h3>
        <ul className={styles.linkList}>
          <li>
            <Link to="/about" className={styles.link}>
              О нас
            </Link>
          </li>
          <li>
            <Link to="/breeds" className={styles.link}>
              Породы
            </Link>
          </li>
          <li>
            <Link to="/care" className={styles.link}>
              Уход
            </Link>
          </li>
          <li>
            <Link to="/health" className={styles.link}>
              Здоровье
            </Link>
          </li>
          <li>
            <Link to="/gallery" className={styles.link}>
              Галерея
            </Link>
          </li>
        </ul>
      </div>
      <div className={styles.linksBlock}>
        <h3 className={styles.heading}>Документы</h3>
        <ul className={styles.linkList}>
          <li>
            <Link to="/terms" className={styles.link}>
              Условия использования
            </Link>
          </li>
          <li>
            <Link to="/privacy" className={styles.link}>
              Политика конфиденциальности
            </Link>
          </li>
          <li>
            <Link to="/cookie-policy" className={styles.link}>
              Cookie-файлы
            </Link>
          </li>
        </ul>
      </div>
      <div className={styles.contactsBlock}>
        <h3 className={styles.heading}>Связь с нами</h3>
        <p className={styles.contactIntro}>
          Переходите на страницу контактов и пишите нам — мы всегда рады
          обратной связи.
        </p>
        <Link to="/contacts" className={styles.contactLink}>
          +7 (495) 123-45-67
        </Link>
        <Link to="/contacts" className={styles.contactLink}>
          info@mir-koshek.ru
        </Link>
        <div className={styles.socials} aria-label="Социальные сети">
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.socialLink}
          >
            Instagram
          </a>
          <a
            href="https://vk.com"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.socialLink}
          >
            VK
          </a>
          <a
            href="https://t.me"
            target="_blank"
            rel="noopener noreferrer"
            className={styles.socialLink}
          >
            Telegram
          </a>
        </div>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>© {new Date().getFullYear()} Мир Кошек. Все права защищены.</p>
    </div>
  </footer>
);

export default Footer;