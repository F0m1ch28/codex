import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import BreedsPage from './pages/Breeds';
import CarePage from './pages/Care';
import HealthPage from './pages/Health';
import GalleryPage from './pages/Gallery';
import ContactsPage from './pages/Contacts';
import TermsPage from './pages/Terms';
import PrivacyPage from './pages/Privacy';
import CookiePolicyPage from './pages/CookiePolicy';
import ThankYouPage from './pages/ThankYou';

const App = () => (
  <Routes>
    <Route path="/" element={<Layout />}>
      <Route index element={<HomePage />} />
      <Route path="about" element={<AboutPage />} />
      <Route path="breeds" element={<BreedsPage />} />
      <Route path="care" element={<CarePage />} />
      <Route path="health" element={<HealthPage />} />
      <Route path="gallery" element={<GalleryPage />} />
      <Route path="contacts" element={<ContactsPage />} />
      <Route path="terms" element={<TermsPage />} />
      <Route path="privacy" element={<PrivacyPage />} />
      <Route path="cookie-policy" element={<CookiePolicyPage />} />
      <Route path="thank-you" element={<ThankYouPage />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
);

export default App;