document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navMenu.classList.toggle("open");
        });
    }

    const consentKey = "cordedjbjcCookieConsent";
    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const consentButtons = cookieBanner.querySelectorAll("[data-consent]");
        const storedConsent = localStorage.getItem(consentKey);

        if (!storedConsent) {
            cookieBanner.classList.add("active");
        }

        consentButtons.forEach((btn) => {
            btn.addEventListener("click", function (event) {
                event.preventDefault();
                const choice = this.getAttribute("data-consent");
                localStorage.setItem(consentKey, choice);
                cookieBanner.classList.remove("active");
            });
        });
    }

    const faqItems = document.querySelectorAll(".faq-item");
    if (faqItems.length) {
        faqItems.forEach((item) => {
            const trigger = item.querySelector("button");
            trigger.addEventListener("click", () => {
                const isActive = item.classList.contains("active");
                faqItems.forEach((el) => el.classList.remove("active"));
                if (!isActive) {
                    item.classList.add("active");
                }
            });
        });
    }
});