document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('navToggle');
  const navList = document.querySelector('.nav-list');
  const body = document.body;
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookies = document.getElementById('acceptCookies');
  const declineCookies = document.getElementById('declineCookies');
  const contactForm = document.getElementById('contactForm');
  const formSuccess = document.getElementById('formSuccess');

  // Mobile navigation toggle
  if (navToggle) {
    navToggle.addEventListener('click', () => {
      const isOpen = navList.style.display === 'flex';
      navList.style.display = isOpen ? 'none' : 'flex';
    });
  }

  // Close mobile nav on link click
  document.querySelectorAll('.nav-list a').forEach(link => {
    link.addEventListener('click', () => {
      if (window.innerWidth < 768) {
        navList.style.display = 'none';
      }
    });
  });

  // Active navigation highlight
  const currentPage = body.getAttribute('data-page');
  document.querySelectorAll('.nav-list a').forEach(link => {
    if (link.dataset.page === currentPage) {
      link.classList.add('active');
    }
  });

  // Smooth scroll for internal anchors
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', e => {
      const targetId = anchor.getAttribute('href').substring(1);
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        e.preventDefault();
        targetEl.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  // Cookie banner logic
  if (cookieBanner && acceptCookies && declineCookies) {
    const cookiePreference = localStorage.getItem('peakvision-cookie-preference');

    if (!cookiePreference) {
      setTimeout(() => {
        cookieBanner.classList.add('show');
      }, 600);
    }

    acceptCookies.addEventListener('click', () => {
      localStorage.setItem('peakvision-cookie-preference', 'accepted');
      cookieBanner.classList.remove('show');
    });

    declineCookies.addEventListener('click', () => {
      localStorage.setItem('peakvision-cookie-preference', 'declined');
      cookieBanner.classList.remove('show');
    });
  }

  // Current year in footer
  const currentYearSpan = document.getElementById('currentYear');
  if (currentYearSpan) {
    currentYearSpan.textContent = new Date().getFullYear();
  }

  // Contact form validation
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      let isValid = true;

      const fields = [
        { id: 'name', message: 'Please enter your name.' },
        { id: 'email', message: 'Please enter a valid email address.', validate: value => /\S+@\S+\.\S+/.test(value) },
        { id: 'message', message: 'Please provide project details.' },
        { id: 'consent', message: 'You must agree to the privacy policy.', type: 'checkbox' }
      ];

      fields.forEach(field => {
        const input = document.getElementById(field.id);
        const errorEl = document.querySelector(`[data-error-for="${field.id}"]`);

        if (!input || !errorEl) return;

        let value = field.type === 'checkbox' ? input.checked : input.value.trim();
        let validField = value !== '' && value !== false;

        if (field.validate && value) {
          validField = field.validate(input.value);
        }

        if (!validField) {
          isValid = false;
          errorEl.textContent = field.message;
        } else {
          errorEl.textContent = '';
        }
      });

      if (isValid) {
        contactForm.reset();
        formSuccess.textContent = 'Thank you! Your message has been sent.';
        setTimeout(() => {
          formSuccess.textContent = '';
        }, 5000);
      }
    });
  }
});