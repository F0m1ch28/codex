document.addEventListener("DOMContentLoaded", function () {
  const yearTargets = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearTargets.forEach((el) => {
    el.textContent = currentYear;
  });

  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.getElementById("primary-navigation");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("is-visible");
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (primaryNav.classList.contains("is-visible")) {
          primaryNav.classList.remove("is-visible");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll("[data-animate]").forEach((el) => observer.observe(el));

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieKey = "anfaconference-cookie-choice";
  if (cookieBanner) {
    const storedChoice = localStorage.getItem(cookieKey);
    if (!storedChoice) {
      cookieBanner.classList.add("is-visible");
    } else {
      cookieBanner.classList.add("is-hidden");
    }

    cookieBanner.querySelectorAll("[data-cookie-choice]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const choice = btn.getAttribute("data-cookie-choice");
        localStorage.setItem(cookieKey, choice);
        cookieBanner.classList.remove("is-visible");
        cookieBanner.classList.add("is-hidden");
      });
    });
  }

  const globalToast = document.getElementById("global-toast");
  function showToast(message) {
    if (!globalToast) return;
    globalToast.textContent = message;
    globalToast.classList.add("is-visible");
    setTimeout(() => {
      globalToast.classList.remove("is-visible");
    }, 4000);
  }

  document.querySelectorAll("form[data-redirect]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const successMessage = form.getAttribute("data-success") || "Your submission has been received.";
      showToast(successMessage);
      const redirectTarget = form.getAttribute("data-redirect") || form.getAttribute("action");
      setTimeout(() => {
        if (redirectTarget) {
          window.location.href = redirectTarget;
        }
      }, 1600);
    });
  });
});