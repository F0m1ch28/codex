document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      const isOpen = primaryNav.classList.toggle('is-open');
      navToggle.classList.toggle('is-active', isOpen);
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth >= 768) {
        primaryNav.classList.remove('is-open');
        navToggle.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    let consentValue = null;
    try {
      consentValue = localStorage.getItem('rsbCookieConsent');
    } catch (error) {
      consentValue = null;
    }

    if (!consentValue) {
      cookieBanner.classList.add('is-visible');
      cookieBanner.setAttribute('aria-hidden', 'false');
    } else {
      cookieBanner.setAttribute('aria-hidden', 'true');
    }

    const buttons = cookieBanner.querySelectorAll('[data-cookie-action]');
    buttons.forEach(function (button) {
      button.addEventListener('click', function () {
        const action = this.getAttribute('data-cookie-action');
        try {
          localStorage.setItem('rsbCookieConsent', action);
        } catch (error) {
          /* graceful fallback */
        }
        cookieBanner.classList.remove('is-visible');
        cookieBanner.setAttribute('aria-hidden', 'true');
      });
    });
  }
});