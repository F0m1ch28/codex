document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    const navOverlay = document.querySelector(".nav-overlay");

    if (navToggle) {
        navToggle.addEventListener("click", () => {
            navLinks.classList.toggle("open");
            navOverlay.classList.toggle("visible");
        });
    }

    if (navOverlay) {
        navOverlay.addEventListener("click", () => {
            navLinks.classList.remove("open");
            navOverlay.classList.remove("visible");
        });
    }

    document.querySelectorAll(".nav-links a").forEach(link => {
        link.addEventListener("click", () => {
            navLinks.classList.remove("open");
            navOverlay.classList.remove("visible");
        });
    });

    const cookieBanner = document.getElementById("cookieBanner");
    const cookieButtons = document.querySelectorAll(".cookie-btn");
    const cookiePreference = localStorage.getItem("gcqg_cookie_pref");

    if (!cookiePreference && cookieBanner) {
        cookieBanner.classList.add("visible");
    }

    cookieButtons.forEach(button => {
        button.addEventListener("click", function (event) {
            event.preventDefault();
            const action = this.dataset.action === "accept" ? "accepted" : "declined";
            localStorage.setItem("gcqg_cookie_pref", action);
            if (cookieBanner) {
                cookieBanner.classList.remove("visible");
            }
            window.open(this.href, "_blank");
        });
    });
});