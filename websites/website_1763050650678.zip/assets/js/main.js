document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  const scrollBtn = document.getElementById('scrollTop');
  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const navLinks = document.querySelectorAll('[data-scroll-top="true"]');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
    });
  }

  if (navLinks.length) {
    navLinks.forEach((link) => {
      link.addEventListener('click', (event) => {
        const href = link.getAttribute('href');
        if (href && href.startsWith('#')) {
          const target = document.querySelector(href);
          if (target) {
            event.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
            setTimeout(() => target.scrollIntoView({ behavior: 'smooth', block: 'start' }), 250);
          }
        }
        if (navMenu && navMenu.classList.contains('open')) {
          navMenu.classList.remove('open');
          if (navToggle) {
            navToggle.setAttribute('aria-expanded', 'false');
          }
        }
      });
    });
  }

  if (scrollBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 320) {
        scrollBtn.classList.add('show');
      } else {
        scrollBtn.classList.remove('show');
      }
    });

    scrollBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (cookieBanner && cookieAccept) {
    const consent = localStorage.getItem('torenvaCookieConsent');
    if (consent === 'accepted') {
      cookieBanner.classList.add('hidden');
    }

    cookieAccept.addEventListener('click', () => {
      localStorage.setItem('torenvaCookieConsent', 'accepted');
      cookieBanner.classList.add('hidden');
    });
  }
});