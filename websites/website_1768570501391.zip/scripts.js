document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            primaryNav.classList.toggle('active');
        });

        primaryNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                primaryNav.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-accept');
    const declineButton = document.querySelector('.cookie-decline');

    if (cookieBanner && acceptButton && declineButton) {
        const bannerStatus = localStorage.getItem('statemisjq_cookie_choice');
        if (!bannerStatus) {
            cookieBanner.classList.add('active');
        }

        const closeBanner = (choice) => {
            localStorage.setItem('statemisjq_cookie_choice', choice);
            cookieBanner.classList.remove('active');
        };

        acceptButton.addEventListener('click', () => closeBanner('accepted'));
        declineButton.addEventListener('click', () => closeBanner('declined'));
    }
});