import { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('cookie-consent', 'granted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Ми використовуємо cookie для покращення взаємодії з сайтом та аналітики.
        Продовжуючи користуватися сайтом, ви погоджуєтеся з нашою політикою
        щодо cookie.
      </p>
      <div className={styles.actions}>
        <a className={styles.link} href="/polityka-cookie">
          Дізнатись більше
        </a>
        <button type="button" className={styles.button} onClick={handleAccept}>
          Прийняти
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;