import { useState } from 'react';
import Meta from '../components/Meta';
import styles from './Services.module.css';

const categories = [
  {
    key: 'diagnostics',
    title: 'Діагностика та планування',
    description:
      'Стартуємо з індивідуальної зустрічі та тестових вправ, щоб визначити темперамент, рівень керованості та поведінкові виклики.',
    benefits: [
      'Оцінка мотивацій, тригерів та умов життя',
      'Перевірка базових команд та реакцій',
      'Формування маршруту з чіткими цілями',
    ],
  },
  {
    key: 'obedience',
    title: 'ОКД та слухняність',
    description:
      'Покроково будуємо керованість у статичному й динамічному середовищі, закріплюємо команди у реальному місті.',
    benefits: [
      'Формування витримки, чіткої реакції на команди',
      'Робота з відволіканнями: люди, тварини, транспорт',
      'Передача навичок власнику та відео-розбори',
    ],
  },
  {
    key: 'behavior',
    title: 'Корекція поведінки',
    description:
      'Комплексно підходимо до агресії, страхів, гіперактивності. Працюємо з емоційною сферою та альтернативними моделями поведінки.',
    benefits: [
      'Аналіз причин небажаної поведінки',
      'Зміна середовища та побудова нових ритуалів',
      'Робота з власником: реакція на складні ситуації',
    ],
  },
  {
    key: 'security',
    title: 'Службова та охоронна підготовка',
    description:
      'Готуємо вівчарок до охорони об’єктів, патрулювання, пошукових завдань. Працюємо з професійними екіпіровками.',
    benefits: [
      'Робота над інстинктами, затриманням, охороною предмету',
      'Відпрацювання сценаріїв із фігурантом',
      'Атестація та супровід запуску команди',
    ],
  },
];

const modules = [
  {
    title: 'Модуль «Старт»',
    details:
      '2 тижні: знайомство, оцінка, формування поведінкової карти та домашніх ритуалів. Підготовка до основного навчання.',
  },
  {
    title: 'Модуль «База»',
    details:
      '6 тижнів: відпрацювання команд, контроль збудження, закріплення навичок у різних середовищах.',
  },
  {
    title: 'Модуль «Місто»',
    details:
      'Робота у Варшаві та Кракові: транспорт, парки, бізнес-центри. Вчимо собаку залишатися зібраною серед подразників.',
  },
  {
    title: 'Модуль «Профі»',
    details:
      'Спеціалізована підготовка: охорона, пошук, робота з фігурантом, розширений контроль.',
  },
];

const extras = [
  'Відеоаналіз занять та методичні матеріали',
  'Онлайн-консультації між тренуваннями',
  'Підтримка після завершення курсу: чек-листи, повторні тестування',
  'Спільні групові тренування та воркшопи з комунікації',
];

const ServicesPage = () => {
  const [activeCategory, setActiveCategory] = useState(categories[0].key);

  const currentCategory = categories.find(
    (category) => category.key === activeCategory
  );

  return (
    <>
      <Meta
        title="Послуги | Професійне дресерування собак"
        description="Індивідуальні програми дресирування німецьких вівчарок: діагностика, ОКД, корекція поведінки, службова підготовка. Працюємо у Варшаві та Кракові."
      />

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <h1>Програми, які адаптуються під вашого собаку</h1>
            <p>
              Ми будуємо індивідуальний маршрут: від діагностики та базових
              навичок до професійної підготовки. Кожен блок — це реальний
              результат, який відчуваєте ви та ваша вівчарка.
            </p>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://picsum.photos/1200/800?random=6"
              alt="Тренер дає команду німецькій вівчарці"
            />
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection}>
        <div className="container">
          <div className={styles.tabs} role="tablist">
            {categories.map((category) => (
              <button
                key={category.key}
                type="button"
                role="tab"
                aria-selected={activeCategory === category.key}
                className={`${styles.tabButton} ${
                  activeCategory === category.key ? styles.tabActive : ''
                }`}
                onClick={() => setActiveCategory(category.key)}
              >
                {category.title}
              </button>
            ))}
          </div>

          <article className={styles.categoryCard}>
            <div className={styles.categoryContent}>
              <h2>{currentCategory?.title}</h2>
              <p>{currentCategory?.description}</p>
              <ul className={styles.benefitsList}>
                {currentCategory?.benefits.map((benefit) => (
                  <li key={benefit}>{benefit}</li>
                ))}
              </ul>
            </div>
            <div className={styles.categoryImage}>
              <img
                src={`https://picsum.photos/800/600?random=${Math.floor(
                  Math.random() * 50 + 80
                )}`}
                alt={currentCategory?.title}
              />
            </div>
          </article>
        </div>
      </section>

      <section className={styles.modulesSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Модульна система навчання</h2>
            <p>
              Ви знаєте, що буде далі. Після кожного модуля звіряємо прогрес і
              коригуємо план.
            </p>
          </header>
          <div className={styles.modulesGrid}>
            {modules.map((module) => (
              <article key={module.title} className={styles.moduleCard}>
                <h3>{module.title}</h3>
                <p>{module.details}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.extraSection}>
        <div className={`container ${styles.extraInner}`}>
          <div className={styles.extraContent}>
            <h2>Що ви отримуєте додатково</h2>
            <p>
              Ми продумали сервіс так, щоб вам було комфортно підтримувати
              результат самостійно. Працюємо як партнери.
            </p>
            <ul className={styles.extraList}>
              {extras.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
          <div className={styles.extraImage}>
            <img
              src="https://picsum.photos/1200/800?random=16"
              alt="Кінолог консультує власника собаки"
            />
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;