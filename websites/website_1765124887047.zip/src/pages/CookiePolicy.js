import Meta from '../components/Meta';
import styles from './Legal.module.css';

const CookiePolicyPage = () => (
  <>
    <Meta
      title="Політика щодо cookie | Професійне дресерування собак"
      description="Деталі про використання cookie на сайті Професійне дресерування собак."
    />
    <section className={styles.legalSection}>
      <div className="container">
        <h1>Політика щодо cookie</h1>
        <p className={styles.lead}>
          Cookie допомагають нам забезпечити стабільну роботу сайту та аналізувати
          його відвідуваність. Нижче описано, як ми їх застосовуємо.
        </p>

        <article className={styles.legalCard}>
          <h2>1. Що таке cookie?</h2>
          <p>
            Cookie — це невеликі текстові файли, які зберігаються у вашому
            браузері. Вони дозволяють запам’ятати налаштування та аналізувати
            використання сайту.
          </p>
        </article>

        <article className={styles.legalCard}>
          <h2>2. Які cookie ми використовуємо</h2>
          <ul>
            <li>Обов’язкові — для базової роботи сайту.</li>
            <li>Аналітичні — допомагають зрозуміти, які сторінки найцікавіші.</li>
          </ul>
        </article>

        <article className={styles.legalCard}>
          <h2>3. Як керувати cookie</h2>
          <p>
            Ви можете вимкнути cookie у налаштуваннях браузера. Зверніть увагу,
            що це може вплинути на коректність роботи сайту.
          </p>
        </article>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;