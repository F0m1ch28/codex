document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            var isOpen = siteNav.classList.toggle('is-open');
            navToggle.classList.toggle('is-open', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        siteNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 768 && siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    var yearSpan = document.getElementById('currentYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    var cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        var cookiePreference = localStorage.getItem('spherozneeCookiePref');

        function hideBanner() {
            cookieBanner.classList.remove('is-visible');
        }

        function showBanner() {
            cookieBanner.classList.add('is-visible');
        }

        if (!cookiePreference) {
            setTimeout(showBanner, 600);
        }

        cookieBanner.addEventListener('click', function (event) {
            var action = event.target.getAttribute('data-cookie-action');
            if (!action) {
                return;
            }
            if (action === 'accept') {
                localStorage.setItem('spherozneeCookiePref', 'accepted');
            } else if (action === 'decline') {
                localStorage.setItem('spherozneeCookiePref', 'declined');
            }
            hideBanner();
        });
    }
});