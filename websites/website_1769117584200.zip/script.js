document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.getElementById('primaryNav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      primaryNav.setAttribute('aria-hidden', String(isExpanded));
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        primaryNav.setAttribute('aria-hidden', 'true');
      });
    });
  }

  const currentYearNodes = document.querySelectorAll('.current-year');
  const yearValue = new Date().getFullYear();
  currentYearNodes.forEach(node => {
    node.textContent = yearValue;
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('.fade-section').forEach(section => observer.observe(section));

  const cookieBanner = document.getElementById('cookieBanner');
  const COOKIE_KEY = 'georgienye-cookie-choice';

  if (cookieBanner) {
    const storedChoice = localStorage.getItem(COOKIE_KEY);
    if (!storedChoice) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-active'));
    }

    cookieBanner.querySelectorAll('[data-cookie-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.cookieAction;
        localStorage.setItem(COOKIE_KEY, action);
        cookieBanner.classList.remove('is-active');
      });
    });
  }

  function ensureToast() {
    let toast = document.getElementById('formToast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'formToast';
      toast.className = 'toast';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'polite');
      toast.textContent = 'Form submitted. Redirecting...';
      document.body.appendChild(toast);
    }
    return toast;
  }

  const forms = document.querySelectorAll('form[data-observe-form]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const toast = ensureToast();
      toast.classList.add('is-visible');
      setTimeout(() => {
        toast.classList.remove('is-visible');
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 2200);
    });
  });
});