document.addEventListener('DOMContentLoaded', function () {
    const header = document.querySelector('.site-header');
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelectorAll('.site-nav-list a');

    if (header && navToggle) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            header.classList.toggle('nav-open');
        });

        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                if (header.classList.contains('nav-open')) {
                    header.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const cookieKey = 'brashlodjv-cookie-choice';
        const storedChoice = localStorage.getItem(cookieKey);
        if (storedChoice) {
            cookieBanner.classList.add('is-hidden');
        }

        const cookieButtons = cookieBanner.querySelectorAll('[data-cookie-choice]');
        cookieButtons.forEach((button) => {
            button.addEventListener('click', function (event) {
                if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                    return;
                }
                event.preventDefault();
                const choice = this.getAttribute('data-cookie-choice');
                localStorage.setItem(cookieKey, choice);
                cookieBanner.classList.add('is-hidden');
            });
        });
    }
});