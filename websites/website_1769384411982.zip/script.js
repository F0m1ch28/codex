document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".mobile-nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      siteNav.classList.toggle("open", !isExpanded);
    });

    window.addEventListener("resize", () => {
      if (window.innerWidth >= 768) {
        navToggle.setAttribute("aria-expanded", "false");
        siteNav.classList.remove("open");
      }
    });
  }

  const sections = document.querySelectorAll(".fade-section");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries, observerRef) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            observerRef.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.18 }
    );
    sections.forEach((section) => observer.observe(section));
  } else {
    sections.forEach((section) => section.classList.add("in-view"));
  }

  const yearHolders = document.querySelectorAll("[data-year]");
  const currentYear = new Date().getFullYear();
  yearHolders.forEach((el) => {
    el.textContent = String(currentYear);
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieAccept = document.getElementById("cookie-accept");
  const cookieDecline = document.getElementById("cookie-decline");
  const cookieKey = "graceCookieConsent";

  if (cookieBanner && cookieAccept && cookieDecline) {
    const storedConsent = localStorage.getItem(cookieKey);
    if (storedConsent) {
      cookieBanner.classList.add("hidden");
    }

    cookieAccept.addEventListener("click", () => {
      localStorage.setItem(cookieKey, "accepted");
      cookieBanner.classList.add("hidden");
    });

    cookieDecline.addEventListener("click", () => {
      localStorage.setItem(cookieKey, "declined");
      cookieBanner.classList.add("hidden");
    });
  }

  const toast = document.getElementById("form-toast");
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("visible");
    setTimeout(() => {
      toast.classList.remove("visible");
    }, 2400);
  };

  const forms = document.querySelectorAll('form[data-enhanced="true"]');
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Your message is being routed. Redirecting...");
      const redirectTarget = form.getAttribute("action") || "thank-you.html";
      setTimeout(() => {
        window.location.href = redirectTarget;
      }, 1400);
    });
  });
});