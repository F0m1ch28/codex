document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.getElementById("primary-navigation");
    const scrollButton = document.querySelector(".scroll-to-top");
    const cookieBanner = document.getElementById("cookie-banner");
    const cookieAccept = document.getElementById("cookie-accept");
    const contactForm = document.getElementById("contact-form");
    const formStatus = document.getElementById("form-status");
    const yearSpan = document.getElementById("year");

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            primaryNav.classList.toggle("open");
        });

        primaryNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                primaryNav.classList.remove("open");
            });
        });
    }

    history.scrollRestoration = "manual";

    document.querySelectorAll('a[data-scroll-top="true"]').forEach(link => {
        link.addEventListener("click", () => {
            window.scrollTo({ top: 0 });
        });
    });

    const handleScrollButton = () => {
        if (!scrollButton) return;
        if (window.scrollY > 300) {
            scrollButton.classList.add("show");
        } else {
            scrollButton.classList.remove("show");
        }
    };

    window.addEventListener("scroll", handleScrollButton);

    if (scrollButton) {
        scrollButton.addEventListener("click", () => {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        });
    }

    if (cookieBanner && cookieAccept) {
        const consentGiven = localStorage.getItem("nlsCookieConsent");
        if (consentGiven === "accepted") {
            cookieBanner.classList.add("hidden");
        }

        cookieAccept.addEventListener("click", () => {
            localStorage.setItem("nlsCookieConsent", "accepted");
            cookieBanner.classList.add("hidden");
        });
    }

    if (contactForm && formStatus) {
        contactForm.addEventListener("submit", event => {
            event.preventDefault();

            const name = contactForm.name.value.trim();
            const email = contactForm.email.value.trim();
            const message = contactForm.message.value.trim();

            if (!name || !email || !message) {
                formStatus.textContent = "Please complete all fields before sending.";
                formStatus.style.color = "#ff9a9a";
                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                formStatus.textContent = "Enter a valid email address.";
                formStatus.style.color = "#ff9a9a";
                return;
            }

            formStatus.textContent = "Thank you! Your message has been received.";
            formStatus.style.color = "#6ec1e4";
            contactForm.reset();
        });
    }
});