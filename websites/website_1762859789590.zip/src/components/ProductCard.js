import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { FiArrowUpRight, FiStar, FiCheckCircle } from 'react-icons/fi';
import styles from './ProductCard.module.css';

const ProductCard = ({ product, isCompared, onToggleCompare, maxReached }) => (
  <article className={styles.card}>
    <div className={styles.media}>
      <img src={product.images.studio} alt={`${product.name} Studioaufnahme`} loading="lazy" />
      <span className={styles.category}>{product.category}</span>
      <button
        type="button"
        className={`${styles.compareBtn} ${isCompared ? styles.active : ''}`}
        onClick={() => onToggleCompare(product.id)}
        aria-pressed={isCompared}
        aria-label={`${product.name} ${isCompared ? 'aus Vergleich entfernen' : 'zum Vergleich hinzufügen'}`}
        disabled={!isCompared && maxReached}
      >
        {isCompared ? 'Vergleich aktiv' : 'Vergleichen'}
      </button>
    </div>
    <div className={styles.body}>
      <header className={styles.header}>
        <h3>{product.name}</h3>
        <div className={styles.rating} aria-label={`Bewertung ${product.rating} von 10`}>
          <FiStar aria-hidden="true" />
          <span>{product.rating.toFixed(1)}</span>
        </div>
      </header>
      <p className={styles.description}>{product.shortDescription}</p>
      <ul className={styles.features} aria-label="Top Highlights">
        {product.highlights.slice(0, 3).map((item) => (
          <li key={item}>
            <FiCheckCircle aria-hidden="true" />
            {item}
          </li>
        ))}
      </ul>
    </div>
    <footer className={styles.footer}>
      <div>
        <span className={styles.priceLabel}>Startpreis</span>
        <span className={styles.price}>{product.price.toLocaleString('de-DE')} €</span>
      </div>
      <Link to={`/produkte/${product.id}`} className={styles.link} aria-label={`${product.name} Detailseite öffnen`}>
        Zum Review <FiArrowUpRight aria-hidden="true" />
      </Link>
    </footer>
  </article>
);

ProductCard.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.string,
    name: PropTypes.string,
    category: PropTypes.string,
    price: PropTypes.number,
    rating: PropTypes.number,
    shortDescription: PropTypes.string,
    highlights: PropTypes.arrayOf(PropTypes.string),
    images: PropTypes.shape({
      studio: PropTypes.string
    })
  }).isRequired,
  isCompared: PropTypes.bool.isRequired,
  onToggleCompare: PropTypes.func.isRequired,
  maxReached: PropTypes.bool.isRequired
};

export default ProductCard;