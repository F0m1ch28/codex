import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('trp_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  if (!visible) {
    return null;
  }

  const handleConsent = (value) => {
    localStorage.setItem('trp_cookie_consent', value);
    setVisible(false);
  };

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <div>
        <h2>Cookies für ein besseres Erlebnis</h2>
        <p>
          Wir verwenden Cookies, um Inhalte zu personalisieren, Funktionen für soziale Medien anbieten zu können und die
          Zugriffe auf unsere Website zu analysieren. Mehr Infos findest du in unserer{' '}
          <Link to="/datenschutz">Datenschutzerklärung</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" onClick={() => handleConsent('declined')} className={styles.secondary}>
          Nur notwendige
        </button>
        <button type="button" onClick={() => handleConsent('accepted')} className={styles.primary}>
          Alle akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;