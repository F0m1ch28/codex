import React, { useEffect, useState } from 'react';
import styles from './NewsletterPopup.module.css';

const NewsletterPopup = () => {
  const [visible, setVisible] = useState(false);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const hasClosed = localStorage.getItem('trp_newsletter_popup');
    if (!hasClosed) {
      const timer = setTimeout(() => setVisible(true), 4000);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleClose = () => {
    localStorage.setItem('trp_newsletter_popup', 'closed');
    setVisible(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
    localStorage.setItem('trp_newsletter_popup', 'subscribed');
    setTimeout(() => setVisible(false), 2200);
  };

  if (!visible) return null;

  return (
    <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="Newsletter Anmeldeformular">
      <div className={styles.card}>
        <button type="button" className={styles.close} onClick={handleClose} aria-label="Popup schließen">
          ×
        </button>
        <h2>Early Access sichern</h2>
        <p>
          Erhalte exklusive Einblicke und werde benachrichtigt, sobald neue Deep-Dive-Reviews live gehen. Für echte Tech-Enthusiasten.
        </p>
        {submitted ? (
          <div className={styles.success} role="status">
            Danke! Wir melden uns bald mit exklusiven Inhalten.
          </div>
        ) : (
          <form onSubmit={handleSubmit} className={styles.form}>
            <label htmlFor="popup-email" className="sr-only">
              E-Mail-Adresse
            </label>
            <input
              id="popup-email"
              type="email"
              name="email"
              required
              placeholder="E-Mail-Adresse"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <button type="submit">Jetzt anmelden</button>
          </form>
        )}
      </div>
    </div>
  );
};

export default NewsletterPopup;