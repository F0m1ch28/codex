import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiX, FiChevronDown } from 'react-icons/fi';
import { useCompare } from '../context/CompareContext';
import styles from './ComparisonDrawer.module.css';

const ComparisonDrawer = () => {
  const { comparedProductDetails, removeProduct, clearComparison } = useCompare();
  const [expanded, setExpanded] = useState(true);

  if (!comparedProductDetails.length) {
    return null;
  }

  return (
    <aside className={`${styles.drawer} ${expanded ? styles.open : ''}`} aria-label="Produktvergleich">
      <button
        type="button"
        className={styles.toggle}
        onClick={() => setExpanded((prev) => !prev)}
        aria-expanded={expanded}
        aria-controls="vergleichsdaten"
      >
        Schnellvergleich {expanded ? 'verbergen' : 'anzeigen'}
        <FiChevronDown aria-hidden="true" className={expanded ? styles.rotated : ''} />
      </button>
      <div id="vergleichsdaten" className={styles.content}>
        <header className={styles.header}>
          <h3>Vergleich ({comparedProductDetails.length}/3)</h3>
          <button type="button" onClick={clearComparison} className={styles.clearBtn}>
            Alle entfernen
          </button>
        </header>
        <div className={styles.tableWrapper}>
          <table>
            <thead>
              <tr>
                <th>Produkt</th>
                {comparedProductDetails.map((item) => (
                  <th key={item.id}>
                    <div className={styles.productHead}>
                      <span>{item.name}</span>
                      <button
                        type="button"
                        onClick={() => removeProduct(item.id)}
                        aria-label={`${item.name} aus Vergleich entfernen`}
                      >
                        <FiX aria-hidden="true" />
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Kategorie</td>
                {comparedProductDetails.map((item) => (
                  <td key={`${item.id}-cat`}>{item.category}</td>
                ))}
              </tr>
              <tr>
                <td>Bewertung</td>
                {comparedProductDetails.map((item) => (
                  <td key={`${item.id}-rating`}>{item.rating.toFixed(1)}/10</td>
                ))}
              </tr>
              <tr>
                <td>Preis</td>
                {comparedProductDetails.map((item) => (
                  <td key={`${item.id}-price`}>{item.price.toLocaleString('de-DE')} €</td>
                ))}
              </tr>
              <tr>
                <td>Top Feature</td>
                {comparedProductDetails.map((item) => (
                  <td key={`${item.id}-feature`}>{item.highlights[0]}</td>
                ))}
              </tr>
              <tr>
                <td>Mehr Details</td>
                {comparedProductDetails.map((item) => (
                  <td key={`${item.id}-link`}>
                    <Link to={`/produkte/${item.id}`} className={styles.link}>
                      Zum Review
                    </Link>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </aside>
  );
};

export default ComparisonDrawer;