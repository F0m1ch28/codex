import React from 'react';
import { Link } from 'react-router-dom';
import { FaYoutube, FaLinkedin, FaTwitter, FaInstagram } from 'react-icons/fa';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Seitenfooter">
    <div className={styles.container}>
      <div className={styles.brand}>
        <Link to="/" className={styles.logo} aria-label="Zur Startseite">
          <span>Tech</span>Review
        </Link>
        <p>
          Die Tech Review Plattform liefert detaillierte Analysen, klare Vergleiche und
          praxisnahe Einblicke in die spannendsten Technologien von heute und morgen.
        </p>
        <div className={styles.socials} aria-label="Social Media">
          <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
            <FaTwitter aria-hidden="true" />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
            <FaLinkedin aria-hidden="true" />
          </a>
          <a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
            <FaInstagram aria-hidden="true" />
          </a>
          <a href="https://youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
            <FaYoutube aria-hidden="true" />
          </a>
        </div>
      </div>
      <div className={styles.column}>
        <h3>Navigation</h3>
        <Link to="/produkte">Produktübersicht</Link>
        <Link to="/services">Services</Link>
        <Link to="/blog">Blog</Link>
        <Link to="/team">Team</Link>
        <Link to="/kontakt">Kontakt</Link>
      </div>
      <div className={styles.column}>
        <h3>Rechtliches</h3>
        <Link to="/impressum">Impressum</Link>
        <Link to="/datenschutz">Datenschutz</Link>
        <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>
        <Link to="/nutzungsbedingungen">Nutzungsbedingungen</Link>
      </div>
      <div className={styles.column}>
        <h3>Kontakt</h3>
        <p>Berlin, Deutschland</p>
        <p>E-Mail: Wird vom Kunden ergänzt</p>
        <p>Telefon: Wird vom Kunden ergänzt</p>
        <Link to="/ueber-uns" className={styles.moreLink}>
          Mehr über uns
        </Link>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>&copy; {new Date().getFullYear()} Tech Review Plattform. Alle Rechte vorbehalten.</p>
    </div>
  </footer>
);

export default Footer;