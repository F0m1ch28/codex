import React, { useEffect, useState } from 'react';
import styles from './ReviewNotification.module.css';
import products from '../data/products';

const ReviewNotification = () => {
  const [visible, setVisible] = useState(false);
  const featuredProduct = products[1];

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 7000);
    const autoHide = setTimeout(() => setVisible(false), 17000);
    return () => {
      clearTimeout(timer);
      clearTimeout(autoHide);
    };
  }, []);

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.toast} role="status" aria-live="polite">
      <p>
        Neue Review live: <strong>{featuredProduct.name}</strong> – entdecke jetzt den Langzeittest!
      </p>
      <a href={`/produkte/${featuredProduct.id}`} className={styles.link}>
        Zum Review
      </a>
    </div>
  );
};

export default ReviewNotification;