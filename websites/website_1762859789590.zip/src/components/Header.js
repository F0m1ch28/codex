import React, { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { FiMenu, FiX } from 'react-icons/fi';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={styles.header} aria-label="Hauptnavigation">
      <div className={styles.wrapper}>
        <NavLink to="/" className={styles.logo} aria-label="Zur Startseite">
          <span className={styles.logoHighlight}>Tech</span>Review
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Primäre Navigation">
          <NavLink
            to="/"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            end
          >
            Start
          </NavLink>
          <NavLink
            to="/produkte"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Produkte
          </NavLink>
          <NavLink
            to="/services"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Services
          </NavLink>
          <NavLink
            to="/blog"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Blog
          </NavLink>
          <NavLink
            to="/ueber-uns"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Über uns
          </NavLink>
          <NavLink
            to="/team"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Team
          </NavLink>
          <NavLink
            to="/kontakt"
            className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
          >
            Kontakt
          </NavLink>
        </nav>
        <a className={styles.ctaButton} href="#newsletter" aria-label="Newsletter abonnieren">
          Early Access
        </a>
        <button
          type="button"
          className={styles.menuButton}
          aria-expanded={menuOpen}
          aria-controls="mobile-navigation"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          {menuOpen ? <FiX aria-hidden="true" /> : <FiMenu aria-hidden="true" />}
          <span className="sr-only">Menü</span>
        </button>
      </div>
      <nav
        id="mobile-navigation"
        className={`${styles.mobileNav} ${menuOpen ? styles.show : ''}`}
        aria-label="Mobile Navigation"
      >
        <NavLink to="/" className={styles.mobileLink} end>
          Start
        </NavLink>
        <NavLink to="/produkte" className={styles.mobileLink}>
          Produkte
        </NavLink>
        <NavLink to="/services" className={styles.mobileLink}>
          Services
        </NavLink>
        <NavLink to="/blog" className={styles.mobileLink}>
          Blog
        </NavLink>
        <NavLink to="/ueber-uns" className={styles.mobileLink}>
          Über uns
        </NavLink>
        <NavLink to="/team" className={styles.mobileLink}>
          Team
        </NavLink>
        <NavLink to="/kontakt" className={styles.mobileLink}>
          Kontakt
        </NavLink>
      </nav>
    </header>
  );
};

export default Header;