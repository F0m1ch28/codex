import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import productsData from '../data/products';

const CompareContext = createContext();

export const CompareProvider = ({ children }) => {
  const [selectedProducts, setSelectedProducts] = useState(() => {
    if (typeof window === 'undefined') return [];
    const stored = localStorage.getItem('trp_compare');
    return stored ? JSON.parse(stored) : [];
  });

  useEffect(() => {
    localStorage.setItem('trp_compare', JSON.stringify(selectedProducts));
  }, [selectedProducts]);

  const toggleProduct = (productId) => {
    setSelectedProducts((prev) => {
      if (prev.includes(productId)) {
        return prev.filter((id) => id !== productId);
      }
      if (prev.length >= 3) {
        return prev;
      }
      return [...prev, productId];
    });
  };

  const removeProduct = (productId) => {
    setSelectedProducts((prev) => prev.filter((id) => id !== productId));
  };

  const clearComparison = () => {
    setSelectedProducts([]);
  };

  const comparedProductDetails = useMemo(
    () =>
      selectedProducts
        .map((id) => productsData.find((item) => item.id === id))
        .filter(Boolean),
    [selectedProducts]
  );

  const value = {
    selectedProducts,
    comparedProductDetails,
    toggleProduct,
    removeProduct,
    clearComparison,
    maxReached: selectedProducts.length >= 3
  };

  return <CompareContext.Provider value={value}>{children}</CompareContext.Provider>;
};

export const useCompare = () => useContext(CompareContext);