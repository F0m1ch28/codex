const team = [
  {
    id: 'team-1',
    name: 'Miriam Vogt',
    role: 'Chefredaktion & Display-Expertin',
    bio: 'Leitet seit 8 Jahren Tech-Redaktionen, spezialisiert auf Display- und Audio-Labs.',
    image: 'https://picsum.photos/400/400?random=350',
    linkedIn: 'https://www.linkedin.com',
    focus: ['Display-Analysen', 'Audio-Reviews', 'Testing Standards']
  },
  {
    id: 'team-2',
    name: 'Lukas Steiner',
    role: 'Head of Labs & Automation',
    bio: 'Verantwortlich für das Berliner Testlabor und sämtliche Messprotokolle.',
    image: 'https://picsum.photos/400/400?random=351',
    linkedIn: 'https://www.linkedin.com',
    focus: ['Laboraufbau', 'Smart Home', 'Benchmarking']
  },
  {
    id: 'team-3',
    name: 'Dr. Lea Wagner',
    role: 'Gesundheitstechnologie',
    bio: 'Medizintechnikerin mit Fokus auf Wearables und datengetriebene Gesundheit.',
    image: 'https://picsum.photos/400/400?random=352',
    linkedIn: 'https://www.linkedin.com',
    focus: ['Wearables', 'Health Insights', 'Datenethik']
  },
  {
    id: 'team-4',
    name: 'Hendrik Maas',
    role: 'Senior Editor Hardware',
    bio: 'Testet Performance-Hardware im Dauereinsatz und baut Vergleichsdatenbanken.',
    image: 'https://picsum.photos/400/400?random=353',
    linkedIn: 'https://www.linkedin.com',
    focus: ['Performance Tests', 'AI Hardware', 'Benchmarks']
  }
];

export default team;