const blogPosts = [
  {
    id: 'deep-dive-mini-led',
    title: 'Mini-LED vs. OLED: Was bringt die neue Display-Generation wirklich?',
    excerpt:
      'Wir vergleichen Mini-LED, OLED und klassische IPS-Panels im Praxisalltag und erklären die Unterschiede bei Kontrast, Farbraum und Stromverbrauch.',
    category: 'Display-Technologien',
    author: 'Miriam Vogt',
    date: '2024-05-29',
    image: 'https://picsum.photos/800/600?random=320',
    readTime: '8 Min',
    tags: ['Mini-LED', 'OLED', 'Display', 'Kolumne']
  },
  {
    id: 'smart-home-security-2024',
    title: 'So sicher sind Smart-Home-Systeme 2024 wirklich',
    excerpt:
      'Von Matter bis lokalen Automationen: Wir zeigen, wie du dein Smart Home vor Angriffen schützt und welche Hersteller auf Security-by-Design setzen.',
    category: 'Smart Home',
    author: 'Lukas Steiner',
    date: '2024-04-16',
    image: 'https://picsum.photos/800/600?random=321',
    readTime: '6 Min',
    tags: ['Security', 'Smart Home', 'Matter']
  },
  {
    id: 'wearables-health',
    title: 'Wearables als Gesundheits-Coach: Chancen und Grenzen',
    excerpt:
      'Welche Messwerte sind wirklich valide? Und wie gehst du mit Health-Daten bewusst um? Ein Blick in aktuelle Studien und unsere Laborwerte.',
    category: 'Health Tech',
    author: 'Dr. Lea Wagner',
    date: '2024-03-08',
    image: 'https://picsum.photos/800/600?random=322',
    readTime: '7 Min',
    tags: ['Wearables', 'Gesundheit', 'Daten']
  },
  {
    id: 'ai-in-laptops',
    title: 'Was bringen KI-Beschleuniger in Notebooks?',
    excerpt:
      'Intel, AMD und Qualcomm rüsten Notebooks mit speziellen NPU-Einheiten aus. Wir testen, welche Workflows davon profitieren.',
    category: 'AI Hardware',
    author: 'Hendrik Maas',
    date: '2024-06-11',
    image: 'https://picsum.photos/800/600?random=323',
    readTime: '9 Min',
    tags: ['AI', 'NPU', 'Laptops']
  }
];

export default blogPosts;