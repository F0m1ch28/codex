const products = [
  {
    id: 'sonic-pulse-x1',
    name: 'Sonic Pulse X1 Kopfhörer',
    category: 'Audio',
    price: 299,
    rating: 9.3,
    reviewScore: 9.3,
    releaseDate: '2024-05-15',
    availability: 'Sofort lieferbar',
    shortDescription:
      'Adaptive Noise Cancelling, Studio-tauglicher Klang und KI-gestützter Sound-Profiling für jede Hörumgebung.',
    description:
      'Die Sonic Pulse X1 sind Over-Ear-Kopfhörer für audiophile Enthusiasten. Dank automatischer Klangkalibrierung, Dolby Atmos-Unterstützung und multipoint Bluetooth verbinden sie sich nahtlos mit all deinen Geräten. Unser Langzeittest zeigt: 32 Stunden Akkulaufzeit, eine intuitive Touch-Steuerung und ein robustes Reiseetui machen den X1 zum idealen Begleiter für unterwegs.',
    highlights: [
      '32h Akku mit Turbo-Schnellladung',
      'KI-gesteuerte Geräuschunterdrückung',
      'Lossless Streaming via LC3 Codec',
      'Unabhängiger Studio-Soundcheck bestanden'
    ],
    pros: ['Überragender Klang bei jedem Genre', 'Hervorragende Verarbeitung', 'Sehr stabile Bluetooth-Verbindung'],
    cons: ['Kein analoger 6,3mm Adapter im Lieferumfang', 'App erfordert Registrierung'],
    specs: {
      Treiber: '42 mm Carbon Fiber',
      Codecs: 'AAC, aptX HD, LDAC, LC3',
      Mikrofone: '6 adaptive Beamforming-Mikros',
      Ladezeit: '15 min für 12h Wiedergabe',
      Gewicht: '280 g'
    },
    images: {
      studio: 'https://picsum.photos/800/600?random=201',
      handsOn: 'https://picsum.photos/800/600?random=202',
      unboxing: 'https://picsum.photos/800/600?random=203',
      features: [
        'https://picsum.photos/800/600?random=204',
        'https://picsum.photos/800/600?random=205',
        'https://picsum.photos/800/600?random=206'
      ],
      lifestyle: [
        'https://picsum.photos/800/600?random=207',
        'https://picsum.photos/800/600?random=208'
      ],
      before: 'https://picsum.photos/800/600?random=209',
      after: 'https://picsum.photos/800/600?random=210',
      infographic: 'https://picsum.photos/800/600?random=211',
      software: [
        'https://picsum.photos/800/600?random=212',
        'https://picsum.photos/800/600?random=213'
      ]
    },
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    tags: ['Noise Cancelling', 'Bluetooth 5.3', 'Adaptive EQ', 'Hi-Res Audio'],
    comments: [
      {
        id: 'c1',
        author: 'Anna Keller',
        date: '2024-06-10',
        text: 'Nutze die X1 seit zwei Wochen im Großraumbüro – die Ruhe ist unbezahlbar. Danke für den ausführlichen Test!'
      },
      {
        id: 'c2',
        author: 'Jonas M.',
        date: '2024-06-18',
        text: 'Der Gaming-Modus mit niedriger Latenz hat mich überzeugt. Würde mir aber noch eine matte Farbvariante wünschen.'
      }
    ]
  },
  {
    id: 'aurora-hub-2',
    name: 'Aurora SmartHome Hub 2',
    category: 'Smart Home',
    price: 189,
    rating: 8.8,
    reviewScore: 8.8,
    releaseDate: '2024-03-22',
    availability: 'Vorbestellung möglich',
    shortDescription:
      'Der KI-basierte Smart-Home-Hub lernt deine Routinen und orchestriert Licht, Klima und Sicherheit mit präzisen Automationen.',
    description:
      'Der Aurora SmartHome Hub 2 bündelt Matter-, Thread- und Zigbee-Geräte in einer intuitiven Oberfläche und bietet On-Device-KI für automatisierte Szenen. Im Test punktete er mit sekundenschnellen Reaktionszeiten, lokaler Datenspeicherung und einem hervorragenden Sicherheitskonzept inklusive Hardware-Encryption.',
    highlights: [
      'Matter & Thread Support out of the box',
      'Szenenerstellung mit Sprachbefehlen',
      'Lokale Datenverarbeitung für mehr Privatsphäre',
      'Automatisches Energie-Monitoring'
    ],
    pros: ['Breite Gerätekompatibilität', 'Sehr gute App-Lokalisation', 'Einfache Einrichtung via NFC'],
    cons: ['Kein integrierter Lautsprecher', 'Zigbee-Reichweite könnte größer sein'],
    specs: {
      Prozessor: 'Quad-Core Edge NPU',
      Speicher: '4 GB RAM, 32 GB eMMC',
      Konnektivität: 'Wi-Fi 6, Thread, Zigbee 3.0, BLE',
      Sicherheit: 'TPM 2.0, Secure Boot',
      Energieverbrauch: '4,5 W Durchschnitt'
    },
    images: {
      studio: 'https://picsum.photos/800/600?random=220',
      handsOn: 'https://picsum.photos/800/600?random=221',
      unboxing: 'https://picsum.photos/800/600?random=222',
      features: [
        'https://picsum.photos/800/600?random=223',
        'https://picsum.photos/800/600?random=224'
      ],
      lifestyle: [
        'https://picsum.photos/800/600?random=225',
        'https://picsum.photos/800/600?random=226'
      ],
      before: 'https://picsum.photos/800/600?random=227',
      after: 'https://picsum.photos/800/600?random=228',
      infographic: 'https://picsum.photos/800/600?random=229',
      software: [
        'https://picsum.photos/800/600?random=230',
        'https://picsum.photos/800/600?random=231',
        'https://picsum.photos/800/600?random=232'
      ]
    },
    videoUrl: 'https://www.youtube.com/embed/a3ICNMQW7Ok',
    tags: ['Smart Home', 'Matter', 'Automation', 'Security'],
    comments: [
      {
        id: 'c3',
        author: 'Laura S.',
        date: '2024-05-02',
        text: 'Die Automation mit Sonnenaufgangs-Trigger funktioniert beeindruckend zuverlässig!'
      }
    ]
  },
  {
    id: 'nebula-ultrabook-15',
    name: 'Nebula Ultrabook 15',
    category: 'Laptops',
    price: 1899,
    rating: 9.1,
    reviewScore: 9.1,
    releaseDate: '2024-02-11',
    availability: 'Auf Lager',
    shortDescription:
      'Ultraflaches 15-Zoll-Notebook mit Mini-LED-Display, 3K-Auflösung, 120 Hz und 18 Stunden Akkulaufzeit.',
    description:
      'Das Nebula Ultrabook 15 richtet sich an Kreative und Entwickler. Im Test überzeugte das 3K-Mini-LED-Panel mit 1.000 Nits Spitzenhelligkeit, die Aluminium-Unibody-Struktur und die leistungsstarke Vapor-Chamber-Kühlung. Trotz 16 mm Bauhöhe liefert der Intel Core Ultra eine starke Performance bei gleichzeitig leisem Betrieb.',
    highlights: [
      'Mini-LED Panel mit 100% DCI-P3',
      'NVMe PCIe 4.0 SSD mit 2 TB',
      'Thunderbolt 4 & Wi-Fi 7',
      'Smarte Lüftersteuerung mit Biomimik'
    ],
    pros: ['Brillantes Display mit 120 Hz', 'Top-Tastatur mit 1,5 mm Hub', 'Lange Akkulaufzeit trotz Leistung'],
    cons: ['Nur zwei USB-A Ports', 'Preislich im Premiumsegment'],
    specs: {
      Prozessor: 'Intel Core Ultra 7',
      Grafikeinheit: 'Intel Arc integrierte Grafik',
      RAM: '32 GB LPDDR5X',
      Speicher: '2 TB NVMe SSD',
      Anschlüsse: '2x Thunderbolt 4, 2x USB-A 3.2, HDMI 2.1'
    },
    images: {
      studio: 'https://picsum.photos/800/600?random=240',
      handsOn: 'https://picsum.photos/800/600?random=241',
      unboxing: 'https://picsum.photos/800/600?random=242',
      features: [
        'https://picsum.photos/800/600?random=243',
        'https://picsum.photos/800/600?random=244'
      ],
      lifestyle: [
        'https://picsum.photos/800/600?random=245',
        'https://picsum.photos/800/600?random=246'
      ],
      before: 'https://picsum.photos/800/600?random=247',
      after: 'https://picsum.photos/800/600?random=248',
      infographic: 'https://picsum.photos/800/600?random=249',
      software: [
        'https://picsum.photos/800/600?random=250',
        'https://picsum.photos/800/600?random=251'
      ]
    },
    videoUrl: 'https://www.youtube.com/embed/V-_O7nl0Ii0',
    tags: ['Ultrabook', 'Mini-LED', 'Thunderbolt 4', 'Wi-Fi 7'],
    comments: [
      {
        id: 'c4',
        author: 'Dr. Felix Hartung',
        date: '2024-04-08',
        text: 'Endlich ein Ultrabook, das Rendering und Beleuchtung für ArchViz schafft, ohne laut zu werden.'
      }
    ]
  },
  {
    id: 'photon-one',
    name: 'Photon One Smartphone',
    category: 'Smartphones',
    price: 1099,
    rating: 8.9,
    reviewScore: 8.9,
    releaseDate: '2024-04-30',
    availability: 'In ausgewählten Märkten',
    shortDescription:
      'Flaggschiff-Kamera mit variabler Blende, 6,8" LTPO Display und satellitengestützter SOS-Kommunikation.',
    description:
      'Das Photon One bringt ein variables Kamerasystem mit 1-Zoll-Sensor, eine maßgeschneiderte Imaging-Engine und Titanrahmen. Im Alltagstest überzeugten die Nachtaufnahmen, die flüssige 1-120 Hz LTPO-Anzeige und eine Software, die fünf Jahre Major-Updates verspricht.',
    highlights: [
      '1" Sensor mit variabler Blende f/1.4 - f/4.0',
      'Satelliten-SOS ohne Zusatzkosten im ersten Jahr',
      'LTPO 2.0 Display mit 2.500 Nits Peak',
      'Reverse Wireless Charging 15 W'
    ],
    pros: ['Exzellente Kameraqualität', 'Sehr gute Akkulaufzeit', 'Robuste Titan-Verarbeitung'],
    cons: ['Software wirkt in einigen Menüs überladen', 'Kein microSD-Slot'],
    specs: {
      Prozessor: 'Photon Neural Chip X2',
      Speicher: '256 GB / 512 GB UFS 4.0',
      RAM: '12 GB LPDDR5X',
      Display: '6,8" LTPO AMOLED, 1440p',
      Akku: '5.000 mAh, 80 W kabelgebunden'
    },
    images: {
      studio: 'https://picsum.photos/800/600?random=260',
      handsOn: 'https://picsum.photos/800/600?random=261',
      unboxing: 'https://picsum.photos/800/600?random=262',
      features: [
        'https://picsum.photos/800/600?random=263',
        'https://picsum.photos/800/600?random=264',
        'https://picsum.photos/800/600?random=265'
      ],
      lifestyle: [
        'https://picsum.photos/800/600?random=266',
        'https://picsum.photos/800/600?random=267'
      ],
      before: 'https://picsum.photos/800/600?random=268',
      after: 'https://picsum.photos/800/600?random=269',
      infographic: 'https://picsum.photos/800/600?random=270',
      software: [
        'https://picsum.photos/800/600?random=271',
        'https://picsum.photos/800/600?random=272',
        'https://picsum.photos/800/600?random=273'
      ]
    },
    videoUrl: 'https://www.youtube.com/embed/ysz5S6PUM-U',
    tags: ['Flaggschiff', 'Kamera', 'Satellit', 'LTPO'],
    comments: [
      {
        id: 'c5',
        author: 'Sabrina L.',
        date: '2024-05-20',
        text: 'Endlich detailreiche RAW-Aufnahmen auch nachts. Die Fotovergleiche hier waren super hilfreich.'
      }
    ]
  },
  {
    id: 'pulsefit-sense',
    name: 'PulseFit Sense Wearable',
    category: 'Wearables',
    price: 349,
    rating: 8.6,
    reviewScore: 8.6,
    releaseDate: '2024-01-19',
    availability: 'Sofort lieferbar',
    shortDescription:
      'Multisport-Uhr mit Dual-Band GPS, 14-Tage-Akku und klinisch validierter Herzfrequenzanalyse für anspruchsvolle Athlet:innen.',
    description:
      'PulseFit Sense kombiniert robuste Materialien mit einem hellen AMOLED-Display und liefert präzise Trainingsdaten. Die neue Recovery-Score-Analyse basiert auf HRV, Hauttemperatur und Schlafstadien. In unserem Test überzeugte vor allem die schnelle Synchronisation und die offene API für Trainingsplattformen.',
    highlights: [
      'Dual-Band GPS mit Multi-GNSS',
      'AMOLED 1,43" Display mit Saphirglas',
      'Recovery Score & Stressmonitoring',
      'Offline Maps & Musiksteuerung'
    ],
    pros: ['Sehr genaue Herzfrequenzmessung', 'Umfassendes Trainings-Ökosystem', 'Starker Akku'],
    cons: ['Kein LTE-Modul', 'App wirkt auf kleinen Displays vollgepackt'],
    specs: {
      Materialien: 'Titanrahmen, Saphirglas',
      Wasserfestigkeit: '10 ATM',
      Sensoren: 'EKG-Ready, Hauttemperatur, SpO2',
      Akku: '420 mAh, 14 Tage typ.',
      Plattform: 'Pulse OS 4 mit App-Store'
    },
    images: {
      studio: 'https://picsum.photos/800/600?random=280',
      handsOn: 'https://picsum.photos/800/600?random=281',
      unboxing: 'https://picsum.photos/800/600?random=282',
      features: [
        'https://picsum.photos/800/600?random=283',
        'https://picsum.photos/800/600?random=284'
      ],
      lifestyle: [
        'https://picsum.photos/800/600?random=285',
        'https://picsum.photos/800/600?random=286'
      ],
      before: 'https://picsum.photos/800/600?random=287',
      after: 'https://picsum.photos/800/600?random=288',
      infographic: 'https://picsum.photos/800/600?random=289',
      software: [
        'https://picsum.photos/800/600?random=290',
        'https://picsum.photos/800/600?random=291'
      ]
    },
    videoUrl: 'https://www.youtube.com/embed/aqz-KE-bpKQ',
    tags: ['Fitness', 'Wearable', 'Recovery', 'GPS'],
    comments: [
      {
        id: 'c6',
        author: 'Marcel D.',
        date: '2024-03-15',
        text: 'Die HRV-Insights helfen mir echt beim Trainingsplan. Danke für den verständlichen Erklärabschnitt im Test.'
      }
    ]
  }
];

export default products;