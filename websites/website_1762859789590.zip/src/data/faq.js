const faq = [
  {
    id: 'faq1',
    question: 'Wie testet ihr Produkte im Labor?',
    answer:
      'Unsere Reviews folgen einem klaren Messprotokoll: Gerätemessungen mit kalibrierten Tools, Praxistests in Alltagsszenarien und Vergleichsdatenbanken. Jede Bewertung von 1–10 spiegelt sowohl Messwerte als auch subjektive Eindrücke wider.'
  },
  {
    id: 'faq2',
    question: 'Kann ich Produkte für Tests vorschlagen?',
    answer:
      'Ja, sende uns einfach eine Nachricht über das Kontaktformular mit deinem Vorschlag. Wir prüfen jede Anfrage und geben innerhalb von 72 Stunden Feedback.'
  },
  {
    id: 'faq3',
    question: 'Wie funktioniert der Produktvergleich?',
    answer:
      'Du kannst bis zu drei Produkte gleichzeitig markieren. Unser Vergleich zeigt die wichtigsten Kennzahlen sowie das stärkste Highlight – perfekt für schnelle Entscheidungen.'
  },
  {
    id: 'faq4',
    question: 'Sind eure Reviews unabhängig?',
    answer:
      'Absolut. Wir finanzieren uns über transparente Partnerschaften, kennzeichnen Sponsored Content und behalten die redaktionelle Freiheit, um ehrliche Bewertungen zu garantieren.'
  }
];

export default faq;