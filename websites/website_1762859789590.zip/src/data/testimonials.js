const testimonials = [
  {
    id: 't1',
    quote:
      'Die Tiefe der Messungen und die nachvollziehbaren Diagramme sind einzigartig. Wir planen unsere Beschaffungen nach deren Tests.',
    name: 'Svenja Reich',
    title: 'Head of Procurement, DigitalWerk GmbH',
    avatar: 'https://picsum.photos/200/200?random=360'
  },
  {
    id: 't2',
    quote:
      'Dank der Vergleichsfunktion sparen wir Stunden, wenn wir neue Geräte evaluieren. Die Pro/Contra-Listen sind gold wert.',
    name: 'Markus Tietz',
    title: 'CTO, FinLink AG',
    avatar: 'https://picsum.photos/200/200?random=361'
  },
  {
    id: 't3',
    quote:
      'Die Redaktion spricht Klartext. Kein Marketing-Blabla, sondern echte Daten aus dem Labor – so muss Tech-Journalismus sein.',
    name: 'Chiara Brand',
    title: 'Produktmanagerin, Synapse Labs',
    avatar: 'https://picsum.photos/200/200?random=362'
  }
];

export default testimonials;