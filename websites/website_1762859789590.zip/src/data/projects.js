const projects = [
  {
    id: 'p1',
    title: 'Studio24 Audio Benchmark',
    category: 'Audio',
    image: 'https://picsum.photos/1200/800?random=380',
    description: 'Messreihe für Kopfhörer und Lautsprecher mit Fokus auf neutralen Referenzsound.',
    tags: ['Audio', 'Benchmark', 'Studio']
  },
  {
    id: 'p2',
    title: 'Smart Living Berlin Loft',
    category: 'Smart Home',
    image: 'https://picsum.photos/1200/800?random=381',
    description: 'Praxislabor in Berlin mit echten Wohnsituationen für Smart-Home-Produkte.',
    tags: ['Smart Home', 'IoT', 'Automation']
  },
  {
    id: 'p3',
    title: 'Mobile Camera Shootout',
    category: 'Mobile',
    image: 'https://picsum.photos/1200/800?random=382',
    description: 'Jährlicher Smartphone-Kamera-Test mit über 2.500 Referenzbildern.',
    tags: ['Smartphone', 'Kamera', 'Vergleich']
  },
  {
    id: 'p4',
    title: 'AI Performance Lab',
    category: 'AI Hardware',
    image: 'https://picsum.photos/1200/800?random=383',
    description: 'Messungen von NPU- und GPU-Leistung in realen KI-Workflows.',
    tags: ['AI', 'Hardware', 'Benchmark']
  }
];

export default projects;