import React from 'react';
import { Helmet } from 'react-helmet';
import { FiFlag, FiCompass, FiHeart } from 'react-icons/fi';
import styles from './About.module.css';
import team from '../data/team';

const About = () => (
  <>
    <Helmet>
      <title>Über uns | Tech Review Plattform</title>
      <meta
        name="description"
        content="Lerne das Team der Tech Review Plattform kennen. Unsere Mission: Transparente Tech-Tests mit Laborqualität aus Berlin."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <span className={styles.tag}>Über uns</span>
        <h1>Wir schaffen Vertrauen in Technologie.</h1>
        <p>
          Unser Team aus Journalist:innen, Ingenieur:innen und Datenexpert:innen testet Produkte mit Leidenschaft und
          Transparenz. In Berlin betreiben wir ein eigenes Testlabor, in dem wir Qualität messbar machen.
        </p>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <div className={styles.valuesGrid}>
          <div className={styles.valueCard}>
            <FiFlag aria-hidden="true" />
            <h3>Unabhängig</h3>
            <p>
              Redaktionelle Freiheit steht über allem. Kooperationen sind stets transparent gekennzeichnet – Tests bleiben
              unbeeinflusst.
            </p>
          </div>
          <div className={styles.valueCard}>
            <FiCompass aria-hidden="true" />
            <h3>Präzise</h3>
            <p>
              Kalibrierte Messgeräte, reproduzierbare Testbedingungen und stetige Validierung sichern unsere Ergebnisse.
            </p>
          </div>
          <div className={styles.valueCard}>
            <FiHeart aria-hidden="true" />
            <h3>Community-nah</h3>
            <p>
              Feedback unserer Leser:innen fließt in Nachtests und Updates ein. Wir hören zu und liefern Antworten.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.story}>
      <div className="container">
        <div className={styles.storyGrid}>
          <div>
            <h2>Unsere Geschichte</h2>
            <p>
              Die Tech Review Plattform entstand 2018 aus dem Wunsch, Tech-Journalismus neu zu denken. Statt
              Pressematerial neu zu formulieren, wollten wir Produkte wirklich verstehen. Mit Unterstützung von Berliner
              Maker-Spaces bauten wir unser erstes Messlabor auf – heute kombinieren wir professionelle Audio-, Display-
              und Netzwerkmesstechnik in einer 450-Quadratmeter-Laborsuite.
            </p>
          </div>
          <div>
            <h3>Highlights</h3>
            <ul>
              <li>2020: Launch der ersten offenen Vergleichsdatenbank</li>
              <li>2021: Aufbau unseres In-House-Fotostudios für Lifestyle- & Produktfotografie</li>
              <li>2023: Einführung der KI-basierten Datenanalyse für Langzeitreviews</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <section className={styles.teamSection}>
      <div className="container">
        <h2>Team im Überblick</h2>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <article key={member.id} className={styles.member}>
              <img src={member.image} alt={`${member.name} im Büro`} />
              <div>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <p className={styles.bio}>{member.bio}</p>
                <div className={styles.focus}>
                  {member.focus.map((focus) => (
                    <span key={focus}>{focus}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default About;