import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { FiSearch, FiPlayCircle, FiShield, FiClock, FiTrendingUp, FiLayers } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import products from '../data/products';
import blogPosts from '../data/blogPosts';
import testimonials from '../data/testimonials';
import faq from '../data/faq';
import projects from '../data/projects';
import { useCompare } from '../context/CompareContext';
import ProductCard from '../components/ProductCard';
import styles from './Home.module.css';

const Home = () => {
  const { selectedProducts, toggleProduct, maxReached } = useCompare();
  const [category, setCategory] = useState('Alle');
  const [minRating, setMinRating] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [countdown, setCountdown] = useState({});
  const [stats, setStats] = useState({ reviews: 0, labor: 0, stunden: 0 });
  const [faqOpen, setFaqOpen] = useState(faq[0].id);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');

  const heroImage = 'https://picsum.photos/1600/900?random=100';

  const upcomingDate = useMemo(() => new Date('2024-12-15T10:00:00'), []);

  useEffect(() => {
    const tick = () => {
      const now = new Date().getTime();
      const distance = upcomingDate.getTime() - now;

      if (distance < 0) {
        setCountdown({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      setCountdown({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((distance / (1000 * 60)) % 60),
        seconds: Math.floor((distance / 1000) % 60)
      });
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [upcomingDate]);

  useEffect(() => {
    const targets = { reviews: 128, labor: 450, stunden: 2200 };
    const duration = 1800;
    const start = performance.now();

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      setStats({
        reviews: Math.floor(progress * targets.reviews),
        labor: Math.floor(progress * targets.labor),
        stunden: Math.floor(progress * targets.stunden)
      });

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, []);

  const categories = ['Alle', ...new Set(products.map((item) => item.category))];

  const filteredProducts = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return products.filter((product) => {
      const matchesCategory = category === 'Alle' || product.category === category;
      const matchesRating = product.rating >= minRating;
      const matchesSearch =
        term.length === 0 ||
        product.name.toLowerCase().includes(term) ||
        product.tags.some((tag) => tag.toLowerCase().includes(term));
      return matchesCategory && matchesRating && matchesSearch;
    });
  }, [category, minRating, searchTerm]);

  useEffect(() => {
    if (!searchTerm) {
      setSuggestions([]);
      return;
    }
    const matches = products
      .filter((product) => product.name.toLowerCase().includes(searchTerm.toLowerCase()))
      .slice(0, 5)
      .map((product) => product.name);
    setSuggestions(matches);
  }, [searchTerm]);

  const heroCTAId = 'hero-cta';

  const testimonial = testimonials[testimonialIndex];

  const filteredProjects = projects.filter(
    (project) => projectFilter === 'Alle' || project.category === projectFilter
  );

  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Tech Review Plattform | Tiefgehende Tech-Tests & Vergleiche</title>
        <meta
          name="description"
          content="Moderne Tech-Review-Plattform aus Berlin mit Laboranalysen, Produktvergleichen, Video-Reviews und fundierten Pro/Contra-Bewertungen."
        />
      </Helmet>

      <section
        className={styles.hero}
        style={{ backgroundImage: `linear-gradient(135deg, rgba(8,15,30,0.75), rgba(8,15,30,0.9)), url(${heroImage})` }}
      >
        <div className={`${styles.heroContent} container`}>
          <span className={styles.badge}>Aus Berlin. Für Tech-Enthusiasten.</span>
          <h1>
            Entscheidungen treffen, <span>die zählen.</span>
          </h1>
          <p>
            Wir kombinieren Messdaten, Praxis-Insights und Community-Feedback, um dir das klarste Bild zu liefern –
            inklusive Vergleichsfunktion, Video-Reviews und transparenten 1–10 Ratings.
          </p>
          <div className={styles.heroActions}>
            <a href="#produktfilter" id={heroCTAId} className="btn">
              Jetzt Produkte vergleichen
            </a>
            <a href="#video-review" className="btn btn-secondary">
              Aktuelles Video ansehen
            </a>
          </div>
          <div className={styles.heroStats} role="presentation">
            <div>
              <strong>{stats.reviews}+</strong>
              <span>ausführliche Reviews</span>
            </div>
            <div>
              <strong>{stats.labor} qm</strong>
              <span>Testlaborfläche</span>
            </div>
            <div>
              <strong>{stats.stunden}</strong>
              <span>Teststunden im Jahr</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.filters} id="produktfilter">
        <div className="container">
          <div className={styles.filterHeader}>
            <h2>Finde dein perfektes Tech-Produkt</h2>
            <p>Nutze Kategorien, Mindestbewertung und smarte Suche mit Autovervollständigung.</p>
          </div>
          <div className={styles.filterGrid}>
            <div className={styles.searchField}>
              <label htmlFor="produktsuche">
                <FiSearch aria-hidden="true" /> Produkt oder Feature suchen
              </label>
              <input
                type="text"
                id="produktsuche"
                name="produktsuche"
                placeholder="z. B. Noise Cancelling, LTPO, Satellite SOS..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                aria-autocomplete="list"
                aria-controls="search-suggestions"
              />
              {suggestions.length > 0 && (
                <ul id="search-suggestions" className={styles.suggestions} role="listbox">
                  {suggestions.map((item) => (
                    <li key={item}>
                      <button type="button" onClick={() => setSearchTerm(item)}>{item}</button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className={styles.categoryField}>
              <span>Kategorie</span>
              <div className={styles.categoryButtons}>
                {categories.map((item) => (
                  <button
                    type="button"
                    key={item}
                    className={category === item ? styles.active : ''}
                    onClick={() => setCategory(item)}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.ratingField}>
              <label htmlFor="ratingRange">Mindestbewertung: {minRating}</label>
              <input
                type="range"
                id="ratingRange"
                min="0"
                max="10"
                step="0.5"
                value={minRating}
                onChange={(e) => setMinRating(Number(e.target.value))}
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.productGridSection} aria-labelledby="produktliste">
        <div className="container">
          <div className={styles.sectionHeading}>
            <div>
              <h2 id="produktliste">Aktuelle Top-Reviews</h2>
              <p>Unsere neuesten Tests mit Pro/Contra, Video-Einblicken und Vergleichsfunktion.</p>
            </div>
            <Link to="/produkte" className={styles.sectionLink}>
              Alle Produkte erkunden
            </Link>
          </div>
          <div className={styles.productGrid}>
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isCompared={selectedProducts.includes(product.id)}
                onToggleCompare={toggleProduct}
                maxReached={maxReached}
              />
            ))}
          </div>
          {filteredProducts.length === 0 && (
            <div className={styles.emptyState}>
              <h3>Keine Produkte gefunden</h3>
              <p>Versuche eine andere Kombination aus Kategorie, Bewertung oder Suchbegriff.</p>
              <button type="button" className="btn btn-secondary" onClick={() => setMinRating(0)}>
                Filter zurücksetzen
              </button>
            </div>
          )}
        </div>
      </section>

      <section className={styles.ratingSystem} aria-labelledby="rating-system">
        <div className="container">
          <div className={styles.ratingContent}>
            <h2 id="rating-system">Unsere Bewertungsskala von 1 bis 10</h2>
            <p>
              Jede Zahl ist verdient. 8 steht für „Sehr gut mit kleinen Schwächen“, 9 bedeutet „Benchmark in seiner
              Klasse“ und eine 10 vergeben wir nur, wenn Innovation, Verarbeitung und Nutzererlebnis im Zusammenspiel
              überzeugen. Klare Pro/Contra-Listen helfen dir bei der Entscheidung.
            </p>
            <div className={styles.ratingScale}>
              {[6, 7, 8, 9, 10].map((score) => (
                <div className={styles.ratingItem} key={score}>
                  <span>{score}</span>
                  <p>
                    {score === 10 && 'State-of-the-Art, setzt neue Standards'}
                    {score === 9 && 'Hervorragend, klare Empfehlung'}
                    {score === 8 && 'Sehr gut, nur kleine Abstriche'}
                    {score === 7 && 'Gut, aber Konkurrenz im Blick behalten'}
                    {score === 6 && 'Solide, jedoch mit relevanten Schwächen'}
                  </p>
                </div>
              ))}
            </div>
          </div>
          <div className={styles.proContra}>
            <h3>Pro & Contra – klar strukturiert</h3>
            <ul className={styles.proList} aria-label="Beispiel Pro">
              <li>Messdaten mit Diagrammen visualisiert</li>
              <li>Praxisbeispiele aus dem Alltagsteam</li>
              <li>Community-Fragen fließen in Updates ein</li>
            </ul>
            <ul className={styles.conList} aria-label="Beispiel Contra">
              <li>Wir benennen Schwachstellen direkt</li>
              <li>Alternative Empfehlungen, falls nötig</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.comingSoon} aria-labelledby="coming-soon">
        <div className="container">
          <div className={styles.timerCopy}>
            <span className={styles.tag}>Coming Soon</span>
            <h2 id="coming-soon">Next-Gen Foldables – Live Review in</h2>
            <p>Unser großes Kamera- & Alltagstest-Event zu drei neuen Foldables startet bald.</p>
            <div className={styles.countdown} role="timer">
              <div>
                <span>{countdown.days ?? 0}</span>
                <small>Tage</small>
              </div>
              <div>
                <span>{countdown.hours ?? 0}</span>
                <small>Stunden</small>
              </div>
              <div>
                <span>{countdown.minutes ?? 0}</span>
                <small>Minuten</small>
              </div>
              <div>
                <span>{countdown.seconds ?? 0}</span>
                <small>Sekunden</small>
              </div>
            </div>
          </div>
          <div className={styles.timerInfo}>
            <h3>Was dich erwartet</h3>
            <ul>
              <li>Live-Benchmarks mit Temperaturprofilen</li>
              <li>Kamera Shootout bei Nacht & Tageslicht</li>
              <li>Hands-On-Stream mit Community Q&A</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.process} aria-labelledby="prozess">
        <div className="container">
          <div className={styles.sectionHeading}>
            <div>
              <h2 id="prozess">Unser Review-Workflow</h2>
              <p>Transparente Schritte vom Unboxing bis zum finalen Fazit.</p>
            </div>
          </div>
          <div className={styles.processGrid}>
            {[
              { title: 'Unboxing & Erste Eindrücke', description: 'Detailaufnahme, Lieferumfang, Qualitätseindruck' },
              { title: 'Labor & Messdaten', description: 'Kalibrierte Messgeräte für Display, Audio, Akkus' },
              { title: 'Praxis & Vergleich', description: 'Real-Life Tests, Langzeitnutzung, Community-Feedback' },
              { title: 'Fazit & Updates', description: 'Pro/Contra, Alternativen, laufende Updates nach Firmware' }
            ].map((step, index) => (
              <div key={step.title} className={styles.processCard}>
                <span>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="video-review" className={styles.videoSection} aria-labelledby="video-review-title">
        <div className="container">
          <div className={styles.videoContent}>
            <div>
              <span className={styles.tag}>Video Review</span>
              <h2 id="video-review-title">Hands-On mit dem Sonic Pulse X1</h2>
              <p>Unser Studio zeigt alle Neuerungen, den Klangvergleich und Tipps für optimale EQ-Profile.</p>
              <a
                className="btn"
                href="https://www.youtube.com/channel/UC_x5XG1OV2P6uZZ5FSM9Ttw"
                target="_blank"
                rel="noreferrer"
              >
                Mehr Videos auf YouTube
              </a>
            </div>
            <div className={styles.videoWrapper}>
              <iframe
                src={products[0].videoUrl}
                title="Sonic Pulse X1 Review"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services} aria-labelledby="services-title">
        <div className="container">
          <div className={styles.sectionHeading}>
            <div>
              <h2 id="services-title">Services für Marken & Unternehmen</h2>
              <p>Individuelle Kooperationen in transparenter Zusammenarbeit.</p>
            </div>
            <Link to="/services" className={styles.sectionLink}>
              Zu unseren Services
            </Link>
          </div>
          <div className={styles.servicesGrid}>
            {[
              {
                icon: <FiShield aria-hidden="true" />,
                title: 'Laborzertifizierte Tests',
                text: 'Neutrale Prüfberichte mit kalibrierten Messungen und Audit-Option.'
              },
              {
                icon: <FiClock aria-hidden="true" />,
                title: 'Launch & Event Coverage',
                text: 'Live-Berichterstattung, Hands-on Videos und Streams aus unserem Studio.'
              },
              {
                icon: <FiTrendingUp aria-hidden="true" />,
                title: 'Datengetriebene Insights',
                text: 'Benchmark-Dashboards und Wettbewerbsanalysen als PDF oder API.'
              },
              {
                icon: <FiLayers aria-hidden="true" />,
                title: 'Content & Workshops',
                text: 'Tech-Workshops, Whitepaper und Content-Produktionen im Co-Branding.'
              }
            ].map((service) => (
              <article className={styles.serviceCard} key={service.title}>
                <div className={styles.serviceIcon}>{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <Link to="/services" aria-label={`${service.title} Details`} className={styles.serviceLink}>
                  Mehr erfahren
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-title">
        <div className="container">
          <div className={styles.sectionHeading}>
            <div>
              <h2 id="projects-title">Benchmark-Projekte</h2>
              <p>Unsere Labs entwickelten umfangreiche Testszenarien für verschiedene Produktkategorien.</p>
            </div>
            <div className={styles.projectFilters} role="group" aria-label="Projekte filtern">
              {['Alle', 'Audio', 'Smart Home', 'Mobile', 'AI Hardware'].map((item) => (
                <button
                  type="button"
                  key={item}
                  className={projectFilter === item ? styles.active : ''}
                  onClick={() => setProjectFilter(item)}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={`${project.title} Projekt`} loading="lazy" />
                <div className={styles.projectBody}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className={styles.projectTags}>
                    {project.tags.map((tag) => (
                      <span key={tag}>{tag}</span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="stimmen">
        <div className="container">
          <div className={styles.sectionHeading}>
            <div>
              <h2 id="stimmen">Was unsere Partner sagen</h2>
              <p>Stimmen aus Unternehmen, die unsere Daten täglich nutzen.</p>
            </div>
            <div className={styles.testimonialControls}>
              <button
                type="button"
                onClick={() =>
                  setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
                }
                aria-label="Vorheriges Testimonial"
              >
                ←
              </button>
              <button
                type="button"
                onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonials.length)}
                aria-label="Nächstes Testimonial"
              >
                →
              </button>
            </div>
          </div>
          <div className={styles.testimonialCard} role="figure">
            <img src={testimonial.avatar} alt={`${testimonial.name} Portrait`} />
            <blockquote>{testimonial.quote}</blockquote>
            <figcaption>
              {testimonial.name} · <span>{testimonial.title}</span>
            </figcaption>
          </div>
        </div>
      </section>

      <section className={styles.teamPreview} aria-labelledby="team-preview-title">
        <div className="container">
          <div className={styles.sectionHeading}>
            <div>
              <h2 id="team-preview-title">Lab-Team im Fokus</h2>
              <p>Vereint Redaktion, Labor und Datenwissenschaft.</p>
            </div>
            <Link to="/team" className={styles.sectionLink}>
              Team kennenlernen
            </Link>
          </div>
          <div className={styles.teamGrid}>
            {products.slice(0, 3).map((product, idx) => (
              <article key={product.id} className={styles.teamCard}>
                <img
                  src={`https://picsum.photos/400/400?random=${360 + idx}`}
                  alt={`Teammitglied im Labor ${idx + 1}`}
                  loading="lazy"
                />
                <div>
                  <h3>{['Miriam', 'Lukas', 'Lea'][idx]}</h3>
                  <p>{['Chefredaktion', 'Labor Lead', 'Health Tech'][idx]}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-title">
        <div className="container">
          <h2 id="faq-title">FAQs</h2>
          <div className={styles.faqList}>
            {faq.map((item) => (
              <div key={item.id} className={styles.faqItem}>
                <button
                  type="button"
                  onClick={() => setFaqOpen((prev) => (prev === item.id ? null : item.id))}
                  aria-expanded={faqOpen === item.id}
                  aria-controls={`faq-panel-${item.id}`}
                >
                  {item.question}
                  <span>{faqOpen === item.id ? '−' : '+'}</span>
                </button>
                <div
                  id={`faq-panel-${item.id}`}
                  className={`${styles.faqAnswer} ${faqOpen === item.id ? styles.open : ''}`}
                >
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogPreview} aria-labelledby="blog-preview-title">
        <div className="container">
          <div className={styles.sectionHeading}>
            <div>
              <h2 id="blog-preview-title">Neu im Blog</h2>
              <p>Tiefgründige Analysen, Interviews und Opinion Pieces.</p>
            </div>
            <Link to="/blog" className={styles.sectionLink}>
              Alle Artikel lesen
            </Link>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.slice(0, 3).map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={`${post.title} Vorschaubild`} loading="lazy" />
                <div>
                  <span>{post.category}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <div className={styles.blogMeta}>
                    <span>{post.author}</span>
                    <span>{post.date}</span>
                    <span>{post.readTime}</span>
                  </div>
                  <Link to="/blog" className={styles.blogLink}>
                    Weiterlesen
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-title">
        <div className="container">
          <div className={styles.ctaContent}>
            <h2 id="cta-title">Bereit für die nächste Entscheidungsrunde?</h2>
            <p>
              Abonniere unseren Newsletter oder buche ein Beratungsgespräch, um Insights direkt aus dem Labor zu
              erhalten.
            </p>
            <div className={styles.ctaActions}>
              <a href="#newsletter" className="btn">
                Newsletter abonnieren
              </a>
              <Link to="/kontakt" className="btn btn-secondary">
                Beratung vereinbaren
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.newsletter} id="newsletter">
        <div className="container">
          <div className={styles.newsletterCard}>
            <div>
              <span className={styles.tag}>Newsletter</span>
              <h2>Updates aus dem Testlabor</h2>
              <p>Monatliche Highlights, Benchmarks und exklusive Event-Einladungen – direkt in dein Postfach.</p>
            </div>
            <form
              className={styles.newsletterForm}
              onSubmit={(e) => {
                e.preventDefault();
                e.target.reset();
              }}
            >
              <label htmlFor="newsletter-email" className="sr-only">
                E-Mail-Adresse
              </label>
              <input
                id="newsletter-email"
                name="email"
                type="email"
                placeholder="E-Mail-Adresse"
                required
                aria-required="true"
              />
              <button type="submit" className="btn">
                Anmelden
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;