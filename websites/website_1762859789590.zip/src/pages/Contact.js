import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '', consent: false });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) newErrors.name = 'Name wird benötigt.';
    if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(formState.email)) newErrors.email = 'Bitte gültige E-Mail angeben.';
    if (formState.message.trim().length < 10) newErrors.message = 'Nachricht bitte ausführlicher formulieren.';
    if (!formState.consent) newErrors.consent = 'Bitte Zustimmung zur Kontaktaufnahme bestätigen.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormState({ name: '', email: '', message: '', consent: false });
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | Tech Review Plattform</title>
        <meta name="description" content="Kontaktiere die Tech Review Plattform in Berlin. Wir freuen uns auf deine Nachricht." />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt</h1>
          <p>Schreib uns für Kooperationen, Presseanfragen oder Feedback. Wir melden uns werktags innerhalb von 48 Stunden.</p>
        </div>
      </section>

      <section className={styles.grid}>
        <div className="container">
          <div className={styles.layout}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Nachricht senden</h2>
              <label htmlFor="contact-name">Name</label>
              <input
                id="contact-name"
                name="name"
                type="text"
                value={formState.name}
                onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                aria-invalid={errors.name ? 'true' : 'false'}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}

              <label htmlFor="contact-email">E-Mail</label>
              <input
                id="contact-email"
                name="email"
                type="email"
                value={formState.email}
                onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                aria-invalid={errors.email ? 'true' : 'false'}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}

              <label htmlFor="contact-message">Nachricht</label>
              <textarea
                id="contact-message"
                name="message"
                rows="5"
                value={formState.message}
                onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}

              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  checked={formState.consent}
                  onChange={(e) => setFormState({ ...formState, consent: e.target.checked })}
                />
                Ich stimme zu, dass meine Angaben zur Kontaktaufnahme gespeichert werden.
              </label>
              {errors.consent && <span className={styles.error}>{errors.consent}</span>}

              <button type="submit" className="btn">
                Nachricht senden
              </button>
              {submitted && <div className={styles.success}>Danke! Deine Nachricht wurde gesendet.</div>}
            </form>

            <aside className={styles.info}>
              <h2>Standort Berlin</h2>
              <p>Tech Review Plattform<br />Berlin, Germany</p>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Tech Review Plattform Berlin"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2429.885913219587!2d13.404954376947484!3d52.52000697981337!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a851c6f66873ed%3A0x7c0c58f42d806021!2sBerlin!5e0!3m2!1sde!2sde!4v1680094100000!5m2!1sde!2sde"
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;