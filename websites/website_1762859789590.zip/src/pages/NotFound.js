import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './NotFound.module.css';

const NotFound = () => (
  <>
    <Helmet>
      <title>Seite nicht gefunden | Tech Review Plattform</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>404</h1>
        <p>Die gesuchte Seite wurde nicht gefunden. Vielleicht hilft unsere Startseite weiter.</p>
        <Link to="/" className="btn">
          Zur Startseite
        </Link>
      </div>
    </section>
  </>
);

export default NotFound;