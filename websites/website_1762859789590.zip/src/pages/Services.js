import React from 'react';
import { Helmet } from 'react-helmet';
import { FiBarChart2, FiCamera, FiCpu, FiUsers } from 'react-icons/fi';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Services | Tech Review Plattform</title>
      <meta
        name="description"
        content="Unsere Services für Hersteller, Agenturen und Unternehmen: Labor-Tests, Content-Produktionen, Datenanalysen und Workshops."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Services für Technologieanbieter & Unternehmen</h1>
        <p>
          Wir unterstützen Teams bei Produkt-Launches, Datenanalysen und Content-Produktionen. Transparent, zertifizierbar
          und mit messbaren Ergebnissen.
        </p>
      </div>
    </section>

    <section className={styles.services}>
      <div className="container">
        <div className={styles.grid}>
          {[
            {
              icon: <FiCpu aria-hidden="true" />,
              title: 'Zertifizierte Produkttests',
              text: 'Laborprüfungen mit Messprotokollen, Video-Dokumentation und Freigabeprozess.'
            },
            {
              icon: <FiCamera aria-hidden="true" />,
              title: 'Content-Produktionen',
              text: 'Hands-On Videos, Fotostrecken und erklärende Grafiken in unserem Studio.'
            },
            {
              icon: <FiBarChart2 aria-hidden="true" />,
              title: 'Daten & Benchmarks',
              text: 'Kundenspezifische Benchmark-Dashboards, Wettbewerbsanalysen und API-Zugänge.'
            },
            {
              icon: <FiUsers aria-hidden="true" />,
              title: 'Workshops & Trainings',
              text: 'Erlebnisorientierte Workshops zu Produktstrategie, Review-Kommunikation und Tech-Trends.'
            }
          ].map((service) => (
            <article key={service.title} className={styles.card}>
              <div className={styles.icon}>{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.contact}>
      <div className="container">
        <h2>Projekt anfragen</h2>
        <p>Schreibe uns über das Kontaktformular, wir melden uns innerhalb von 48 Stunden.</p>
      </div>
    </section>
  </>
);

export default Services;