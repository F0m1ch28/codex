import React from 'react';
import { Helmet } from 'react-helmet';
import blogPosts from '../data/blogPosts';
import styles from './Blog.module.css';

const Blog = () => (
  <>
    <Helmet>
      <title>Blog | Tech Review Plattform</title>
      <meta
        name="description"
        content="Aktuelle Artikel, Analysen und Meinungen aus der Tech Review Plattform. Deep Dives zu Displays, Smart Home, Wearables und AI."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Blog & Analysen</h1>
        <p>Aktuelle Trends, Deep Dives aus dem Labor und Einschätzungen unseres Redaktionsteams.</p>
      </div>
    </section>
    <section className={styles.gridSection}>
      <div className="container">
        <div className={styles.grid}>
          {blogPosts.map((post) => (
            <article key={post.id} className={styles.card}>
              <img src={post.image} alt={`${post.title} Artikelbild`} loading="lazy" />
              <div className={styles.body}>
                <span>{post.category}</span>
                <h2>{post.title}</h2>
                <p>{post.excerpt}</p>
                <div className={styles.meta}>
                  <span>{post.author}</span>
                  <span>{post.date}</span>
                  <span>{post.readTime}</span>
                </div>
                <div className={styles.tags}>
                  {post.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Blog;