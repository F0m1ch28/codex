import React from 'react';
import { Helmet } from 'react-helmet';
import { FiLinkedin } from 'react-icons/fi';
import team from '../data/team';
import styles from './Team.module.css';

const Team = () => (
  <>
    <Helmet>
      <title>Team | Tech Review Plattform</title>
      <meta
        name="description"
        content="Lerne das Team der Tech Review Plattform kennen. Expertinnen und Experten aus Redaktion, Labor und Datenanalyse."
      />
    </Helmet>
    <section className={styles.hero}>
      <div className="container">
        <h1>Team</h1>
        <p>Ein interdisziplinäres Team aus Journalist:innen, Ingenieur:innen und Datenanalyst:innen.</p>
      </div>
    </section>
    <section className={styles.gridSection}>
      <div className="container">
        <div className={styles.grid}>
          {team.map((member) => (
            <article key={member.id} className={styles.card}>
              <img src={member.image} alt={`${member.name} im modernen Büro`} loading="lazy" />
              <div className={styles.cardBody}>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.role}</p>
                <p>{member.bio}</p>
                <div className={styles.tags}>
                  {member.focus.map((focus) => (
                    <span key={focus}>{focus}</span>
                  ))}
                </div>
                <a href={member.linkedIn} className={styles.link} target="_blank" rel="noreferrer">
                  <FiLinkedin aria-hidden="true" /> LinkedIn
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Team;