import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie-Richtlinie | Tech Review Plattform</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Cookie-Richtlinie</h1>
        <p>
          Wir nutzen Cookies und ähnliche Technologien, um unsere Website zu verbessern, Reichweiten zu messen und
          personalisierte Inhalte anzubieten. Du kannst Cookies über den Banner akzeptieren oder ablehnen.
        </p>
        <h2>Funktionale Cookies</h2>
        <p>Speichern deine Einstellungen, z. B. welche Produkte im Vergleich liegen.</p>
        <h2>Analyse</h2>
        <p>Wir setzen DSGVO-konforme Analyse-Lösungen ein, die IPs anonymisieren.</p>
        <h2>Opt-out</h2>
        <p>Deine Einwilligung kannst du jederzeit über den Cookie-Banner widerrufen.</p>
      </div>
    </section>
  </>
);

export default CookiePolicy;