import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Impressum = () => (
  <>
    <Helmet>
      <title>Impressum | Tech Review Plattform</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Impressum</h1>
        <p>
          Tech Review Plattform<br />
          Berlin, Deutschland
        </p>
        <h2>Kontakt</h2>
        <p>
          E-Mail: Wird vom Kunden ergänzt<br />
          Telefon: Wird vom Kunden ergänzt
        </p>
        <h2>Verantwortlich für den Inhalt</h2>
        <p>Das Redaktionsteam der Tech Review Plattform.</p>
      </div>
    </section>
  </>
);

export default Impressum;