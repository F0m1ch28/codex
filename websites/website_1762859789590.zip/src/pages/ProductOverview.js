import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import products from '../data/products';
import { useCompare } from '../context/CompareContext';
import ProductCard from '../components/ProductCard';
import styles from './ProductOverview.module.css';

const ProductOverview = () => {
  const { selectedProducts, toggleProduct, maxReached } = useCompare();
  const [category, setCategory] = useState('Alle');
  const [maxPrice, setMaxPrice] = useState(2000);

  const categories = ['Alle', ...new Set(products.map((item) => item.category))];
  const maxProductPrice = Math.max(...products.map((product) => product.price));

  const filtered = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory = category === 'Alle' || product.category === category;
      const matchesPrice = product.price <= maxPrice;
      return matchesCategory && matchesPrice;
    });
  }, [category, maxPrice]);

  return (
    <>
      <Helmet>
        <title>Produktübersicht | Tech Review Plattform</title>
        <meta
          name="description"
          content="Alle getesteten Produkte in der Übersicht: Filtere nach Kategorien, Preisen und Bewertungen."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Produktübersicht</h1>
          <p>Filtere nach Kategorie und Preis, markiere Favoriten für den direkten Vergleich und springe in die Reviews.</p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className="container">
          <div className={styles.filterBar}>
            <div className={styles.filterGroup}>
              <span>Kategorie</span>
              <div className={styles.buttons}>
                {categories.map((item) => (
                  <button
                    type="button"
                    key={item}
                    className={category === item ? styles.active : ''}
                    onClick={() => setCategory(item)}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.filterGroup}>
              <label htmlFor="priceRange">Maximaler Preis: {maxPrice} €</label>
              <input
                id="priceRange"
                type="range"
                min="100"
                max={Math.ceil(maxProductPrice / 100) * 100}
                step="50"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
              />
            </div>
          </div>

          <div className={styles.grid}>
            {filtered.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isCompared={selectedProducts.includes(product.id)}
                onToggleCompare={toggleProduct}
                maxReached={maxReached}
              />
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default ProductOverview;