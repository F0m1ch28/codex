import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Nutzungsbedingungen | Tech Review Plattform</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Nutzungsbedingungen</h1>
        <p>
          Die Nutzung unserer Inhalte ist ausschließlich für private und interne Zwecke gestattet. Eine kommerzielle
          Weiterverwendung bedarf unserer schriftlichen Zustimmung.
        </p>
        <h2>Haftung</h2>
        <p>
          Trotz sorgfältiger Recherche übernehmen wir keine Gewähr für absolute Fehlerfreiheit. Entscheidungen sollten auf
          Basis der eigenen Prüfung erfolgen.
        </p>
        <h2>Vergleichsfunktion</h2>
        <p>
          Daten werden regelmäßig aktualisiert, können jedoch sich verändernde Marktpreise nur bedingt widerspiegeln.
        </p>
        <h2>Änderungen</h2>
        <p>Wir behalten uns vor, diese Bedingungen jederzeit zu aktualisieren.</p>
      </div>
    </section>
  </>
);

export default Terms;