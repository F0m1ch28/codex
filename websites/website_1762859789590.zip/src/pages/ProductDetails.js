import React, { useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { FiShare2, FiThumbsUp, FiThumbsDown } from 'react-icons/fi';
import products from '../data/products';
import { useCompare } from '../context/CompareContext';
import styles from './ProductDetails.module.css';

const ProductDetails = () => {
  const { id } = useParams();
  const product = useMemo(() => products.find((item) => item.id === id), [id]);
  const { selectedProducts, toggleProduct, maxReached } = useCompare();

  const [activeImage, setActiveImage] = useState(product?.images.studio ?? '');
  const [comments, setComments] = useState(product?.comments ?? []);
  const [commentForm, setCommentForm] = useState({ author: '', text: '' });

  if (!product) {
    return (
      <section className="container">
        <h1>Produkt nicht gefunden</h1>
        <p>Dieses Review wurde eventuell entfernt oder befindet sich noch in Arbeit.</p>
      </section>
    );
  }

  const shareUrl = typeof window !== 'undefined' ? window.location.href : `https://www.tech-review-plattform.de/produkte/${product.id}`;

  const handleComment = (event) => {
    event.preventDefault();
    if (!commentForm.author.trim() || !commentForm.text.trim()) return;
    setComments((prev) => [
      ...prev,
      {
        id: `${Date.now()}`,
        author: commentForm.author,
        text: commentForm.text,
        date: new Date().toISOString().slice(0, 10)
      }
    ]);
    setCommentForm({ author: '', text: '' });
  };

  const detailImages = [
    product.images.studio,
    product.images.handsOn,
    product.images.unboxing,
    ...product.images.features,
    ...product.images.lifestyle
  ];

  return (
    <>
      <Helmet>
        <title>{product.name} Review | Tech Review Plattform</title>
        <meta
          name="description"
          content={`Unser ausführlicher Testbericht zum ${product.name}. Pro/Contra, Laborergebnisse, Hands-On Video und Vergleich.`}
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.gallery}>
              <div className={styles.mainImage}>
                <img src={activeImage} alt={`${product.name} Detailansicht`} />
              </div>
              <div className={styles.thumbnails} role="list">
                {detailImages.map((image) => (
                  <button
                    type="button"
                    key={image}
                    onClick={() => setActiveImage(image)}
                    className={activeImage === image ? styles.active : ''}
                    aria-label="Produktbild auswählen"
                  >
                    <img src={image} alt={`${product.name} Vorschaubild`} loading="lazy" />
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.details}>
              <span className={styles.category}>{product.category}</span>
              <h1>{product.name}</h1>
              <p>{product.description}</p>
              <div className={styles.meta}>
                <div>
                  <span>Bewertung</span>
                  <strong>{product.rating.toFixed(1)}/10</strong>
                </div>
                <div>
                  <span>Preis</span>
                  <strong>{product.price.toLocaleString('de-DE')} €</strong>
                </div>
                <div>
                  <span>Verfügbarkeit</span>
                  <strong>{product.availability}</strong>
                </div>
              </div>
              <div className={styles.actions}>
                <button
                  type="button"
                  className="btn"
                  onClick={() => toggleProduct(product.id)}
                  disabled={!selectedProducts.includes(product.id) && maxReached}
                >
                  {selectedProducts.includes(product.id) ? 'Im Vergleich' : 'Zum Vergleich hinzufügen'}
                </button>
                <div className={styles.share}>
                  <span>Teilen</span>
                  <a
                    href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(product.name)}`}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="Auf Twitter teilen"
                  >
                    <FiShare2 />
                  </a>
                  <a
                    href={`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(product.name)}`}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="Auf LinkedIn teilen"
                  >
                    <FiShare2 />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.highlights}>
        <div className="container">
          <div className={styles.highlightGrid}>
            <div>
              <h2>Highlights</h2>
              <ul>
                {product.highlights.map((highlight) => (
                  <li key={highlight}>
                    <FiThumbsUp aria-hidden="true" />
                    {highlight}
                  </li>
                ))}
              </ul>
            </div>
            <div className={styles.proContra}>
              <h3>Pro</h3>
              <ul>
                {product.pros.map((pro) => (
                  <li key={pro}>
                    <FiThumbsUp aria-hidden="true" /> {pro}
                  </li>
                ))}
              </ul>
              <h3>Contra</h3>
              <ul>
                {product.cons.map((con) => (
                  <li key={con}>
                    <FiThumbsDown aria-hidden="true" /> {con}
                  </li>
                ))}
              </ul>
            </div>
            <div className={styles.specs}>
              <h3>Technische Daten</h3>
              <dl>
                {Object.entries(product.specs).map(([key, value]) => (
                  <div key={key}>
                    <dt>{key}</dt>
                    <dd>{value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.video} aria-labelledby="hands-on-video">
        <div className="container">
          <h2 id="hands-on-video">Hands-On Video</h2>
          <div className={styles.videoWrapper}>
            <iframe
              src={product.videoUrl}
              title={`${product.name} Video Review`}
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          </div>
        </div>
      </section>

      <section className={styles.gallerySection} aria-labelledby="galerie">
        <div className="container">
          <h2 id="galerie">Bildgalerie</h2>
          <div className={styles.imageGrid}>
            <img src={product.images.unboxing} alt={`${product.name} Unboxing`} />
            {product.images.features.map((img) => (
              <img key={img} src={img} alt={`${product.name} Feature`} loading="lazy" />
            ))}
            {product.images.lifestyle.map((img) => (
              <img key={img} src={img} alt={`${product.name} im Einsatz`} loading="lazy" />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.beforeAfter}>
        <div className="container">
          <h2>Before & After</h2>
          <div className={styles.beforeAfterGrid}>
            <div>
              <span>Before</span>
              <img src={product.images.before} alt={`${product.name} vorher`} loading="lazy" />
            </div>
            <div>
              <span>After</span>
              <img src={product.images.after} alt={`${product.name} nachher`} loading="lazy" />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.infographic}>
        <div className="container">
          <h2>Infografik</h2>
          <img src={product.images.infographic} alt={`${product.name} technische Infografik`} loading="lazy" />
        </div>
      </section>

      <section className={styles.software}>
        <div className="container">
          <h2>Software & App Einblicke</h2>
          <div className={styles.softwareGrid}>
            {product.images.software.map((img) => (
              <img key={img} src={img} alt={`${product.name} App Screenshot`} loading="lazy" />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.comments} aria-labelledby="community">
        <div className="container">
          <h2 id="community">Community-Diskussion</h2>
          <div className={styles.commentList}>
            {comments.map((comment) => (
              <article key={comment.id}>
                <header>
                  <strong>{comment.author}</strong>
                  <span>{comment.date}</span>
                </header>
                <p>{comment.text}</p>
              </article>
            ))}
          </div>
          <form className={styles.commentForm} onSubmit={handleComment}>
            <h3>Eigene Erfahrung teilen</h3>
            <label htmlFor="comment-name">Name</label>
            <input
              id="comment-name"
              value={commentForm.author}
              onChange={(e) => setCommentForm({ ...commentForm, author: e.target.value })}
              required
            />
            <label htmlFor="comment-text">Kommentar</label>
            <textarea
              id="comment-text"
              rows="4"
              value={commentForm.text}
              onChange={(e) => setCommentForm({ ...commentForm, text: e.target.value })}
              required
            />
            <button type="submit" className="btn">
              Kommentar senden
            </button>
          </form>
        </div>
      </section>
    </>
  );
};

export default ProductDetails;