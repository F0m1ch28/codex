import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutz | Tech Review Plattform</title>
      <meta name="robots" content="noindex" />
    </Helmet>
    <section className={styles.section}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>
          Wir nehmen den Schutz persönlicher Daten ernst. Diese Seite beschreibt, welche Daten wir erheben und wie sie
          verarbeitet werden. Nach DSGVO informieren wir transparent über Zwecke, Rechtsgrundlagen und Speicherdauern.
        </p>
        <h2>Verantwortliche Stelle</h2>
        <p>Tech Review Plattform, Berlin, Deutschland.</p>
        <h2>Server-Logfiles</h2>
        <p>
          Bei jedem Zugriff werden IP-Adresse, Zeitpunkt, angeforderte Ressource und User-Agent gespeichert. Diese Daten
          dienen der Sicherstellung des Betriebs und werden nach 30 Tagen gelöscht.
        </p>
        <h2>Newsletter</h2>
        <p>
          Für unseren Newsletter nutzen wir das Double-Opt-In-Verfahren. Die E-Mail-Adresse wird für den Versand und
          Nachweis der Einwilligung gespeichert. Eine Abmeldung ist jederzeit möglich.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;