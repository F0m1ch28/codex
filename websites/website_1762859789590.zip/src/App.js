import React from 'react';
import { Routes, Route, Outlet } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import NewsletterPopup from './components/NewsletterPopup';
import ReviewNotification from './components/ReviewNotification';
import ComparisonDrawer from './components/ComparisonDrawer';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import ProductOverview from './pages/ProductOverview';
import ProductDetails from './pages/ProductDetails';
import Team from './pages/Team';
import Blog from './pages/Blog';
import Impressum from './pages/Impressum';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';
import Terms from './pages/Terms';
import NotFound from './pages/NotFound';

const Layout = () => (
  <>
    <Header />
    <main className="main-content" id="hauptinhalt">
      <Outlet />
    </main>
    <Footer />
  </>
);

function App() {
  return (
    <>
      <ScrollToTop />
      <ReviewNotification />
      <NewsletterPopup />
      <CookieBanner />
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/produkte" element={<ProductOverview />} />
          <Route path="/produkte/:id" element={<ProductDetails />} />
          <Route path="/services" element={<Services />} />
          <Route path="/team" element={<Team />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/kontakt" element={<Contact />} />
          <Route path="/ueber-uns" element={<About />} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/datenschutz" element={<Privacy />} />
          <Route path="/cookie-richtlinie" element={<CookiePolicy />} />
          <Route path="/nutzungsbedingungen" element={<Terms />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
      <ComparisonDrawer />
    </>
  );
}

export default App;