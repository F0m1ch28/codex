import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTopButton';
import styles from './App.module.css';

const HomePage = lazy(() => import('./pages/Home'));
const CatalogPage = lazy(() => import('./pages/Catalog'));
const VideoCoversPage = lazy(() => import('./pages/VideoCovers'));
const AvatarsIconsPage = lazy(() => import('./pages/AvatarsIcons'));
const SocialMediaPage = lazy(() => import('./pages/SocialMedia'));
const AboutPage = lazy(() => import('./pages/About'));
const ContactsPage = lazy(() => import('./pages/Contacts'));
const HelpPage = lazy(() => import('./pages/Help'));
const TermsOfUsePage = lazy(() => import('./pages/TermsOfUse'));
const PrivacyPolicyPage = lazy(() => import('./pages/PrivacyPolicy'));
const CookiePolicyPage = lazy(() => import('./pages/CookiePolicy'));
const ServicesPage = lazy(() => import('./pages/Services'));

function App() {
  return (
    <div className={styles.appWrapper}>
      <Header />
      <main id="mainContent" className={styles.main}>
        <Suspense fallback={<div className={styles.loader} role="status" aria-live="polite">Загрузка...</div>}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/catalog" element={<CatalogPage />} />
            <Route path="/catalog/video-covers" element={<VideoCoversPage />} />
            <Route path="/catalog/avatars-icons" element={<AvatarsIconsPage />} />
            <Route path="/catalog/social-media" element={<SocialMediaPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contacts" element={<ContactsPage />} />
            <Route path="/help" element={<HelpPage />} />
            <Route path="/terms-of-use" element={<TermsOfUsePage />} />
            <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
            <Route path="/services" element={<ServicesPage />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;