import React from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import SEO from '../components/SEO';
import styles from './Catalog.module.css';

const featuredCollections = [
  {
    title: 'Neon Pulse',
    description: 'Неоновые, динамичные визуалы для лайв-стримов и музыкальных каналов.',
    image: 'https://picsum.photos/800/600?random=24',
    tags: ['Twitch', 'After Effects', 'PNG'],
  },
  {
    title: 'Soft Stories',
    description: 'Мягкая пастельная палитра, созданная для lifestyle и fashion-контента.',
    image: 'https://picsum.photos/800/600?random=25',
    tags: ['Instagram', 'Stories', 'PSD'],
  },
  {
    title: 'Tech Pulse',
    description: 'Футуристичная графика для IT-каналов и подкастов о технологиях.',
    image: 'https://picsum.photos/800/600?random=26',
    tags: ['YouTube', 'PNG', 'SVG'],
  },
  {
    title: 'Gaming Legends',
    description: 'Смелые образы и кистевые эффекты для геймерских команд и сообществ.',
    image: 'https://picsum.photos/800/600?random=27',
    tags: ['Discord', 'PNG', 'PSD'],
  },
  {
    title: 'Podcast Essentials',
    description: 'Обложки для подкастов и музыкальных плейлистов в формате квадрат и story.',
    image: 'https://picsum.photos/800/600?random=28',
    tags: ['Spotify', 'SVG', 'PNG'],
  },
  {
    title: 'Edu Pro',
    description: 'Сдержанные, информативные дизайны для образовательных платформ и курсов.',
    image: 'https://picsum.photos/800/600?random=29',
    tags: ['YouTube', 'VK', 'PSD'],
  },
];

const CatalogPage = () => {
  return (
    <>
      <SEO
        title="Каталог цифровых дизайнов — DigitalCovers"
        description="Просмотрите коллекции DigitalCovers: обложки для видео, аватарки и графика для соцсетей. Тысячи готовых решений для контент-креаторов."
        keywords="каталог дизайнов, шаблоны, обложки для видео, аватарки, графика для соцсетей"
      />
      <section className={`${styles.hero}`}>
        <div className="container">
          <span className={styles.tagline}>Каталог DigitalCovers</span>
          <h1>Вдохновляющие коллекции для вашего контента</h1>
          <p>Откройте библиотеку DigitalCovers: готовые обложки, аватарки и комплекты графики для крупнейших платформ. Фильтруйте по нишам, стилям и форматам.</p>
          <div className={styles.heroActions}>
            <Link to="/catalog/video-covers" className="buttonPrimary">Обложки для видео</Link>
            <Link to="/services" className="buttonSecondary">Индивидуальный заказ</Link>
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Категории каталога</h2>
          <p className="sectionSubtitle">Выберите направление, чтобы быстро перейти к подборке материалов, адаптированных под вашу платформу.</p>
        </div>
        <div className={styles.categories}>
          <Link to="/catalog/video-covers" className={styles.categoryCard}>
            <h3>Обложки для видео</h3>
            <p>Яркие композиции и акценты, которые удерживают внимание и повышают CTR роликов.</p>
            <span>Смотреть →</span>
          </Link>
          <Link to="/catalog/avatars-icons" className={styles.categoryCard}>
            <h3>Аватарки и иконки</h3>
            <p>Экспрессивные аватары для личных брендов, команд и сообществ.</p>
            <span>Смотреть →</span>
          </Link>
          <Link to="/catalog/social-media" className={styles.categoryCard}>
            <h3>Графика для соцсетей</h3>
            <p>Комплекты постов, сторис и заголовков для Telegram, VK, Instagram и TikTok.</p>
            <span>Смотреть →</span>
          </Link>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Подборки недели</h2>
          <p className="sectionSubtitle">Команда кураторов DigitalCovers обновляет коллекции каждую неделю, чтобы вы работали с актуальными визуальными трендами.</p>
        </div>
        <div className={styles.productsGrid}>
          {featuredCollections.map((collection) => (
            <ProductCard key={collection.title} {...collection} />
          ))}
        </div>
      </section>

      <section className={styles.banner}>
        <div className="container">
          <div className={styles.bannerInner}>
            <div>
              <h2>Нужна помощь с выбором дизайна?</h2>
              <p>Команда DigitalCovers поможет подобрать решения под ваш канал, нишу и бренд. Расскажите о проекте, и мы подготовим персональную подборку.</p>
            </div>
            <Link to="/contacts" className="buttonPrimary">Связаться с командой</Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default CatalogPage;