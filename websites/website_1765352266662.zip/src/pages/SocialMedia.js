import React from 'react';
import ProductCard from '../components/ProductCard';
import SEO from '../components/SEO';
import styles from './SocialMedia.module.css';

const socialMediaDesigns = [
  {
    title: 'Telegram Broadcast',
    description: 'Полный комплект визуалов для Telegram-канала: обложки, посты и закрепы.',
    image: 'https://picsum.photos/800/600?random=42',
    tags: ['Telegram', 'PNG', 'PSD'],
  },
  {
    title: 'VK Community',
    description: 'Шапки и посты для VK со встроенными шаблонами акций и опросов.',
    image: 'https://picsum.photos/800/600?random=43',
    tags: ['VK', 'PNG', 'PSD'],
  },
  {
    title: 'Instagram Motion',
    description: 'Шаблоны Reels и Stories с акцентом на анимацию и типографику.',
    image: 'https://picsum.photos/800/600?random=44',
    tags: ['Instagram', 'Stories', 'Video'],
  },
  {
    title: 'TikTok Snippets',
    description: 'Обложки и графика для TikTok-профиля и превью роликов.',
    image: 'https://picsum.photos/800/600?random=45',
    tags: ['TikTok', 'PNG', 'Shorts'],
  },
  {
    title: 'LinkedIn Pulse',
    description: 'Профессиональные карточки для корпоративных обновлений и кейсов.',
    image: 'https://picsum.photos/800/600?random=46',
    tags: ['LinkedIn', 'Corporate', 'PowerPoint'],
  },
  {
    title: 'Community Stories',
    description: 'Готовые stories и посты для вовлечения подписчиков на разных платформах.',
    image: 'https://picsum.photos/800/600?random=47',
    tags: ['Instagram', 'TikTok', 'Canva'],
  },
];

const SocialMediaPage = () => {
  return (
    <>
      <SEO
        title="Графика для соцсетей — DigitalCovers"
        description="Комплекты визуалов для соцсетей: Telegram, VK, Instagram, TikTok. Создайте цельный образ бренда с DigitalCovers."
        keywords="графика для соцсетей, Telegram дизайн, Instagram шаблоны, TikTok оформление"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Графика для соцсетей</h1>
          <p>Адаптируйте дизайн под формат постов, сторис и обложек на всех ключевых площадках. Подберите стиль и соберите визуальную систему за один вечер.</p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <h2 className="sectionTitle">Коллекции</h2>
        <div className={styles.grid}>
          {socialMediaDesigns.map((item) => (
            <ProductCard key={item.title} {...item} />
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Создайте контент-план с единым визуалом</h2>
              <p>Получите шаблоны для постов, сторис и обложек, чтобы публиковать контент быстрее и поддерживать стиль бренда во всех каналах.</p>
            </div>
            <a href="https://digitalcovers.ru" className="buttonSecondary">Скачать примеры</a>
          </div>
        </div>
      </section>
    </>
  );
};

export default SocialMediaPage;