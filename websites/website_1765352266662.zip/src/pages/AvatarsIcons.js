import React from 'react';
import ProductCard from '../components/ProductCard';
import SEO from '../components/SEO';
import styles from './AvatarsIcons.module.css';

const avatars = [
  {
    title: 'Vibrant Faces',
    description: 'Серия смелых аватарок для стримеров и креативных брендов.',
    image: 'https://picsum.photos/800/600?random=36',
    tags: ['PNG', 'SVG', 'Discord'],
  },
  {
    title: 'Minimal Corporate',
    description: 'Лаконичные иконки для деловых сообществ и подкастов.',
    image: 'https://picsum.photos/800/600?random=37',
    tags: ['LinkedIn', 'PNG', 'Vector'],
  },
  {
    title: 'Gradient Stories',
    description: 'Градиентные аватарки и сторис-рамки для Instagram и TikTok.',
    image: 'https://picsum.photos/800/600?random=38',
    tags: ['Instagram', 'PNG', 'Canva'],
  },
  {
    title: 'Team Spirit',
    description: 'Набор командных аватарок для eSports и Discord-коммьюнити.',
    image: 'https://picsum.photos/800/600?random=39',
    tags: ['Discord', 'Gaming', 'PSD'],
  },
  {
    title: 'Podcast Hosts',
    description: 'Иллюстрированные аватарки с акцентом на индивидуальность ведущих.',
    image: 'https://picsum.photos/800/600?random=40',
    tags: ['Spotify', 'SVG', 'PNG'],
  },
  {
    title: 'Community Badges',
    description: 'Бейджи и иконки для поощрения участников сообществ.',
    image: 'https://picsum.photos/800/600?random=41',
    tags: ['Telegram', 'Gamification', 'PNG'],
  },
];

const AvatarsIconsPage = () => {
  return (
    <>
      <SEO
        title="Аватарки и иконки — DigitalCovers"
        description="Выразительные аватарки и иконки для Telegram, Discord, Instagram и других платформ. Коллекции DigitalCovers помогут подчеркнуть характер вашего бренда."
        keywords="аватарки, иконки, цифровой дизайн, Discord, Telegram, Instagram"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Аватарки и иконки</h1>
          <p>Создайте узнаваемый образ на любой платформе: Telegram, Discord, Instagram, TikTok или VK. Подбирайте стиль, сочетайте с шапками и анимацией.</p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <h2 className="sectionTitle">Коллекции</h2>
        <div className={styles.grid}>
          {avatars.map((item) => (
            <ProductCard key={item.title} {...item} />
          ))}
        </div>
      </section>

      <section className={styles.tips}>
        <div className="container">
          <h2>Что входит в набор?</h2>
          <div className={styles.tipsGrid}>
            <div>
              <h3>Файлы для разных платформ</h3>
              <p>Каждый комплект включает версии для круглых и квадратных аватаров, а также иконки для кнопок и сторис.</p>
            </div>
            <div>
              <h3>Готовность к анимации</h3>
              <p>Мы добавляем слои и рекомендации, чтобы легко оживить аватарку в After Effects или Canva.</p>
            </div>
            <div>
              <h3>Цветовые вариации</h3>
              <p>Несколько цветовых схем помогают настроить аватар под сезонные кампании или коллаборации.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AvatarsIconsPage;