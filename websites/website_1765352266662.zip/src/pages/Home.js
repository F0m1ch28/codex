import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import HeroSection from '../components/HeroSection';
import CategoryGrid from '../components/CategoryGrid';
import ProductCard from '../components/ProductCard';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const categories = [
  {
    title: 'Обложки для видео',
    description: 'Готовые шаблоны для YouTube, Twitch и Rutube с акцентом на кликабельность и читаемость.',
    link: '/catalog/video-covers',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    alt: 'Коллаж с обложками для видео',
  },
  {
    title: 'Аватарки и иконки',
    description: 'Выразительные аватарки и иконки для Telegram, Discord, Instagram и других платформ.',
    link: '/catalog/avatars-icons',
    image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=1200&q=80',
    alt: 'Пример ярких цифровых аватарок',
  },
  {
    title: 'Графика для соцсетей',
    description: 'Дизайн постов, сторис и обложек для ВКонтакте, Instagram, TikTok и Telegram-каналов.',
    link: '/catalog/social-media',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80',
    alt: 'Коллаж постов для социальных сетей',
  },
];

const howItWorks = [
  {
    title: 'Выберите дизайн',
    description: 'Просмотрите коллекции и выберите стиль, который отражает ваш контент и аудиторию.',
    icon: '🔍',
  },
  {
    title: 'Скачайте файлы',
    description: 'Моментальный доступ к файлам в PNG, PSD и SVG для гибкого редактирования.',
    icon: '⬇️',
  },
  {
    title: 'Настройте под себя',
    description: 'Добавьте текст, цвета и элементы бренда — адаптируйте дизайн под свой стиль.',
    icon: '🎨',
  },
  {
    title: 'Публикуйте',
    description: 'Загружайте готовые изображения и повышайте вовлечённость вашей аудитории.',
    icon: '🚀',
  },
];

const advantages = [
  {
    title: 'Уникальный визуальный стиль',
    description: 'Каждый дизайн создаётся командой DigitalCovers и проходит строгий контроль качества.',
    icon: '✨',
  },
  {
    title: 'Готовые к публикации файлы',
    description: 'Файлы оптимизированы под платформы YouTube, Twitch, Telegram, Instagram и другие.',
    icon: '📁',
  },
  {
    title: 'Поддержка форматов',
    description: 'Вы получаете несколько форматов: PNG, PSD, SVG. Это удобно для быстрой адаптации.',
    icon: '🧩',
  },
  {
    title: 'Регулярное обновление',
    description: 'Каждую неделю мы добавляем новые коллекции и трендовые стили без доплат.',
    icon: '🔄',
  },
];

const projects = [
  {
    title: 'Серия обложек для обучающего канала',
    category: 'Видео',
    image: 'https://images.unsplash.com/photo-1618005198919-d3d4b5a92eee?auto=format&fit=crop&w=1200&q=80',
  },
  {
    title: 'Комплект графики для Telegram-сообщества',
    category: 'Соцсети',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1200&q=80',
  },
  {
    title: 'Аватарки для команды киберспортсменов',
    category: 'Брендинг',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80',
  },
  {
    title: 'Оформление Twitch-канала',
    category: 'Видео',
    image: 'https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=1200&q=80',
  },
];

const testimonials = [
  {
    name: 'Алексей Каменев',
    role: 'YouTube-креатор, канал о путешествиях',
    quote: 'DigitalCovers полностью изменил мои обложки. CTR вырос почти в два раза, а узнаваемость бренда значительно улучшилась.',
    avatar: 'https://picsum.photos/200/200?random=16',
  },
  {
    name: 'Дарья Соколова',
    role: 'SMM-специалист, digital-агентство',
    quote: 'Я ценю скорость — каталог DigitalCovers позволяет быстро подобрать графику для клиентов и адаптировать её под кампании.',
    avatar: 'https://picsum.photos/200/200?random=17',
  },
  {
    name: 'Илья Мартынов',
    role: 'Стример на Twitch',
    quote: 'Оформление стрима стало цельным и профессиональным. Поддержка помогла с адаптацией под разные разрешения.',
    avatar: 'https://picsum.photos/200/200?random=18',
  },
];

const faqItems = [
  {
    question: 'Можно ли редактировать файлы после покупки?',
    answer: 'Да, все дизайны поставляются в популярных форматах (PNG, PSD, SVG), что позволяет изменять текст, цвета и композицию в любимых редакторах.',
  },
  {
    question: 'Как часто обновляется каталог?',
    answer: 'Новые коллекции добавляются каждую неделю. Вы получаете доступ к свежим трендам и сезонным подборкам для соцсетей.',
  },
  {
    question: 'Предоставляете ли вы индивидуальный дизайн?',
    answer: 'Да, у нас есть услуга кастомного дизайна. Оставьте заявку через форму или свяжитесь по email support@digitalcovers.ru.',
  },
];

const blogPosts = [
  {
    title: 'Как повысить CTR YouTube обложек: 5 практик',
    image: 'https://picsum.photos/800/600?random=21',
    link: '/catalog/video-covers',
    excerpt: 'Разбираем ключевые элементы, которые делают обложку заметной: контраст, композиция, типографика и эмоция.',
  },
  {
    title: 'Стильный Telegram-канал: гайд по визуальной айдентике',
    image: 'https://picsum.photos/800/600?random=22',
    link: '/catalog/social-media',
    excerpt: 'Показываем, как выстроить единый визуальный язык для постов, обложек и stories, чтобы аудитория узнавала вас моментально.',
  },
  {
    title: 'Где использовать анимированные аватарки и как их подготавливать',
    image: 'https://picsum.photos/800/600?random=23',
    link: '/catalog/avatars-icons',
    excerpt: 'Рассматриваем форматы, размеры и технические требования к анимированным аватаркам на различных платформах.',
  },
];

const HomePage = () => {
  const [statsValues, setStatsValues] = useState([0, 0, 0, 0]);
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeProjectCategory, setActiveProjectCategory] = useState('Все');
  const [openFaqIndex, setOpenFaqIndex] = useState(null);

  const stats = useMemo(
    () => [
      { label: 'Готовых дизайнов', value: 3200 },
      { label: 'Клиентов по всему миру', value: 980 },
      { label: 'Платформ в фокусе', value: 12 },
      { label: 'Обновлений в год', value: 48 },
    ],
    []
  );

  useEffect(() => {
    const duration = 1600;
    const steps = 40;
    const interval = duration / steps;
    const increments = stats.map((stat) => Math.ceil(stat.value / steps));

    const timer = setInterval(() => {
      setStatsValues((prev) => {
        const nextValues = prev.map((val, index) => {
          if (val >= stats[index].value) {
            return stats[index].value;
          }
          const nextVal = val + increments[index];
          return nextVal > stats[index].value ? stats[index].value : nextVal;
        });
        return nextValues;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [stats]);

  useEffect(() => {
    const slider = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(slider);
  }, []);

  const filteredProjects =
    activeProjectCategory === 'Все'
      ? projects
      : projects.filter((project) => project.category === activeProjectCategory);

  const toggleFaq = (index) => {
    setOpenFaqIndex((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <SEO
        title="DigitalCovers — профессиональная графика для вашего контента"
        description="Обложки для видео, аватарки, графика для соцсетей и тысячи готовых цифровых дизайнов. DigitalCovers помогает блогерам, стримерам и брендам выделяться."
        keywords="обложки для видео, аватарки, цифровой дизайн, графика для соцсетей, шаблоны, DigitalCovers"
      />

      <HeroSection
        title="Профессиональная графика для вашего контента"
        subtitle="Обложки для видео, аватарки и визуальные решения для соцсетей. Готовые коллекции и индивидуальные проекты от команды DigitalCovers."
        description="Мы создаём дизайн, который усиливает ваш бренд и увеличивает вовлечённость аудитории. Получите доступ к библиотеке премиум-материалов и адаптируйте их под ваши задачи."
        primaryCta={{ label: 'Смотреть каталог', to: '/catalog' }}
        secondaryCta={{ label: 'Связаться с нами', to: '/contacts' }}
        backgroundImage="https://picsum.photos/1600/900?random=1"
      />

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Популярные категории</h2>
          <p className="sectionSubtitle">Подберите готовое оформление или вдохновитесь нашими подборками для YouTube, Twitch, Telegram и других платформ.</p>
        </div>
        <CategoryGrid categories={categories} />
      </section>

      <section className={`${styles.statsSection}`}>
        <div className="container">
          <div className={styles.statsWrapper}>
            {stats.map((stat, index) => (
              <div className={styles.statCard} key={stat.label}>
                <span className={styles.statNumber}>{statsValues[index]}+</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Как это работает</h2>
          <p className="sectionSubtitle">Всё просто: выберите дизайн, скачайте файлы, адаптируйте под свой стиль и делитесь с аудиторией через пару минут.</p>
        </div>
        <div className={styles.stepsGrid}>
          {howItWorks.map((step) => (
            <div className={styles.stepCard} key={step.title}>
              <div className={styles.stepIcon} aria-hidden="true">{step.icon}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Преимущества DigitalCovers</h2>
          <p className="sectionSubtitle">Мы внимательно следим за трендами в дизайне, чтобы вы могли сосредоточиться на создании контента.</p>
        </div>
        <div className={styles.advantagesGrid}>
          {advantages.map((item) => (
            <div className={styles.advantageCard} key={item.title}>
              <div className={styles.advantageIcon} aria-hidden="true">{item.icon}</div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Выбор редакции</h2>
          <p className="sectionSubtitle">Подборка дизайнов, которые особенно полюбились нашим клиентам за визуальную выразительность и гибкость кастомизации.</p>
        </div>
        <div className={styles.productsGrid}>
          <ProductCard
            title="Bold Stream: динамичные обложки для стримов"
            description="Смелая типографика и выразительный цвет. Подходит для Twitch, VK Play Live и YouTube Live."
            image="https://picsum.photos/800/600?random=2"
            tags={['Twitch', 'YouTube', 'PSD']}
          />
          <ProductCard
            title="Minimal Stories: лаконичный набор для соцсетей"
            description="Минималистичная эстетика для Instagram и Telegram. Идеально для личных брендов."
            image="https://picsum.photos/800/600?random=3"
            tags={['Instagram', 'Telegram', 'PNG']}
          />
          <ProductCard
            title="Creators Squad: героические аватарки"
            description="Коллекция аватарок в стиле комиксов для креативных команд и медиа-проектов."
            image="https://picsum.photos/800/600?random=4"
            tags={['Discord', 'SVG', 'PNG']}
          />
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Реализованные проекты</h2>
            <p className="sectionSubtitle">Посмотрите, как наши арт-директоры переосмыслили визуальные решения для блогеров, агентств и онлайн-школ.</p>
          </div>
          <div className={styles.projectFilters}>
            {['Все', 'Видео', 'Соцсети', 'Брендинг'].map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${activeProjectCategory === category ? styles.filterActive : ''}`}
                onClick={() => setActiveProjectCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <figure className={styles.projectCard} key={project.title}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <figcaption>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Отзывы контент-креаторов</h2>
          <p className="sectionSubtitle">Мы работаем с блогерами, стримерами и брендами, которым важен визуал и скорость. Вот что они говорят.</p>
        </div>
        <div className={styles.testimonials}>
          <button type="button" className={styles.sliderButton} onClick={() => setTestimonialIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))} aria-label="Предыдущий отзыв">
            ←
          </button>
          <div className={styles.testimonialCard}>
            <img src={testimonials[testimonialIndex].avatar} alt={`Фото клиента ${testimonials[testimonialIndex].name}`} />
            <blockquote>
              <p>“{testimonials[testimonialIndex].quote}”</p>
            </blockquote>
            <div className={styles.testimonialAuthor}>
              <strong>{testimonials[testimonialIndex].name}</strong>
              <span>{testimonials[testimonialIndex].role}</span>
            </div>
          </div>
          <button type="button" className={styles.sliderButton} onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonials.length)} aria-label="Следующий отзыв">
            →
          </button>
        </div>
        <div className={styles.dots}>
          {testimonials.map((_, index) => (
            <button
              key={index}
              type="button"
              className={`${styles.dot} ${testimonialIndex === index ? styles.dotActive : ''}`}
              onClick={() => setTestimonialIndex(index)}
              aria-label={`Показать отзыв ${index + 1}`}
            />
          ))}
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.sectionHeader}>
          <h2 className="sectionTitle">Частые вопросы</h2>
          <p className="sectionSubtitle">Ответы на самые популярные вопросы о работе с каталогом DigitalCovers.</p>
        </div>
        <div className={styles.faq}>
          {faqItems.map((item, index) => (
            <div className={`${styles.faqItem} ${openFaqIndex === index ? styles.faqOpen : ''}`} key={item.question}>
              <button type="button" className={styles.faqQuestion} onClick={() => toggleFaq(index)} aria-expanded={openFaqIndex === index}>
                <span>{item.question}</span>
                <span className={styles.faqIcon}>{openFaqIndex === index ? '−' : '+'}</span>
              </button>
              <div className={styles.faqAnswer}>
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className="sectionTitle">Свежие материалы</h2>
            <p className="sectionSubtitle">Гайды и вдохновение для тех, кто хочет улучшать визуальный стиль контента.</p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article className={styles.blogCard} key={post.title}>
                <div className={styles.blogImage}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogBody}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link}>Читать подробнее →</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaWrapper}>
            <div>
              <h2>Начните использовать профессиональную графику уже сегодня</h2>
              <p>Присоединяйтесь к сообществу DigitalCovers, чтобы делиться свежим визуалом и создавать контент, который выделяется с первого кадра.</p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/catalog" className="buttonPrimary">
                В каталог
              </Link>
              <Link to="/contacts" className="buttonSecondary">
                Связаться с нами
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;