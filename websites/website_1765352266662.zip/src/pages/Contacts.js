import React from 'react';
import ContactForm from '../components/ContactForm';
import SEO from '../components/SEO';
import styles from './Contacts.module.css';

const ContactsPage = () => {
  return (
    <>
      <SEO
        title="Контакты DigitalCovers"
        description="Свяжитесь с командой DigitalCovers. Email support@digitalcovers.ru, телефон +7 (495) 123-45-67, офис в Москве."
        keywords="контакты DigitalCovers, support@digitalcovers.ru, телефон DigitalCovers"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Связаться с DigitalCovers</h1>
          <p>Мы готовы помочь с выбором дизайна, консультациями по кастомным проектам и любыми вопросами по платформе.</p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.grid}>
          <div className={styles.info}>
            <h2>Контактная информация</h2>
            <p><strong>Email:</strong> <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a></p>
            <p><strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a></p>
            <p><strong>Юридический адрес:</strong> 123456, Россия, г. Москва, ул. Цифровая, д. 1, офис 10.</p>
            <div className={styles.highlight}>
              <h3>График работы</h3>
              <p>Понедельник—пятница: 10:00–19:00 (МСК)</p>
              <p>Суббота—воскресенье: 12:00–17:00 (поддержка по email)</p>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>

      <section className={styles.map}>
        <div className="container">
          <iframe
            title="Офис DigitalCovers"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2240.973058147715!2d37.62039387743115!3d55.753960980552056!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a5a8b35ce17%3A0x9dc52bced41dad85!2z0JzQvtGB0LrQstCw0Y8g0L7QsdC70LDRgdGC0YDQvtC2!5e0!3m2!1sru!2sru!4v1683123452721!5m2!1sru!2sru"
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>
    </>
  );
};

export default ContactsPage;