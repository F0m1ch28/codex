import React from 'react';
import ProductCard from '../components/ProductCard';
import SEO from '../components/SEO';
import styles from './VideoCovers.module.css';

const videoCovers = [
  {
    title: 'Pulse Motion',
    description: 'Экспрессивные композиции с живой типографикой для динамичных роликов.',
    image: 'https://picsum.photos/800/600?random=30',
    tags: ['YouTube', 'PNG', 'PSD'],
  },
  {
    title: 'Documentary Focus',
    description: 'Сдержанные обложки, созданные для документальных и образовательных видео.',
    image: 'https://picsum.photos/800/600?random=31',
    tags: ['YouTube', '16:9', 'PSD'],
  },
  {
    title: 'Streaming Night',
    description: 'Night-mode дизайн идеально подходит для вечерних стримов и подкастов.',
    image: 'https://picsum.photos/800/600?random=32',
    tags: ['Twitch', 'PNG', 'Overlay'],
  },
  {
    title: 'Retro Arcade',
    description: 'Пиксель-арт стиль для геймерских шоу и ретро-стримов.',
    image: 'https://picsum.photos/800/600?random=33',
    tags: ['Twitch', 'PNG', 'GIF'],
  },
  {
    title: 'Creator Spotlight',
    description: 'Яркие обложки с фокусом на героя выпуска и ключевые тезисы.',
    image: 'https://picsum.photos/800/600?random=34',
    tags: ['YouTube', 'PSD', 'Typography'],
  },
  {
    title: 'Tech Waves',
    description: 'Футуристичный дизайн в холодной палитре для техно-каналов и обзоров.',
    image: 'https://picsum.photos/800/600?random=35',
    tags: ['YouTube', 'PNG', 'Figma'],
  },
];

const VideoCoversPage = () => {
  return (
    <>
      <SEO
        title="Обложки для видео — DigitalCovers"
        description="Каталог готовых обложек для YouTube и Twitch. Выберите стиль, адаптируйте и публикуйте свои видео с DigitalCovers."
        keywords="обложки youtube, дизайн обложек, Twitch оформление, DigitalCovers"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Обложки для видео</h1>
          <p>Увеличьте CTR ваших роликов с помощью обложек, разработанных по best practices. Лучше читаемость, больше кликов и узнаваемый стиль канала.</p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <h2 className="sectionTitle">Подборки для YouTube и Twitch</h2>
        <div className={styles.grid}>
          {videoCovers.map((item) => (
            <ProductCard key={item.title} {...item} />
          ))}
        </div>
      </section>

      <section className={styles.tips}>
        <div className="container">
          <h2>Советы по настройке обложек</h2>
          <ul>
            <li>Делайте главный объект крупным и оставляйте контрастный фон для читаемости на мобильных устройствах.</li>
            <li>Используйте короткие, ёмкие заголовки и выделяйте ключевые слова с помощью цвета или акцента.</li>
            <li>Проверяйте обложку в разных размерах (360px и 720px), чтобы убедиться, что детали остаются заметными.</li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default VideoCoversPage;