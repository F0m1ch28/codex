import React from 'react';
import SEO from '../components/SEO';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => {
  return (
    <>
      <SEO
        title="Политика использования Cookies — DigitalCovers"
        description="Подробности о том, как DigitalCovers использует cookies и технологии отслеживания."
        keywords="политика cookies, DigitalCovers cookies"
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Политика использования cookies</h1>
          <p>DigitalCovers использует cookies, чтобы улучшать опыт работы с платформой, персонализировать рекомендации и анализировать взаимодействия.</p>

          <h2>Какие cookies мы используем</h2>
          <ul>
            <li><strong>Обязательные:</strong> обеспечивают базовую работоспособность сайта.</li>
            <li><strong>Аналитические:</strong> помогают понимать, как посетители используют сервис.</li>
            <li><strong>Функциональные:</strong> запоминают ваши настройки и предпочтения.</li>
          </ul>

          <h2>Как управлять cookies</h2>
          <p>Вы можете отключить cookies в настройках браузера или воспользоваться режимом «инкогнито». Обратите внимание, что отключение некоторых cookies может ограничить функциональность сервиса.</p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicyPage;