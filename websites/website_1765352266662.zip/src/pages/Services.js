import React from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Services.module.css';

const services = [
  {
    title: 'Индивидуальный бренд-пак',
    description: 'Разрабатываем уникальную визуальную систему: обложки, шапки, аватарки и графику для соцсетей под ваш бренд.',
    deliverables: ['Moodboard и концепт', 'До 5 вариантов дизайна', 'Настройка под платформы'],
  },
  {
    title: 'Express-адаптация',
    description: 'Настроим выбранные дизайны из каталога под вашу нишу, заменим тексты, цвета и логотипы в течение 48 часов.',
    deliverables: ['Выбор 3–5 шаблонов', 'Персонализация шрифтов и цветов', 'Файлы в нужных форматах'],
  },
  {
    title: 'Motion-пак для видео',
    description: 'Добавим анимацию к обложкам и заставкам, подготовим графику для интро и аутро ваших роликов.',
    deliverables: ['Motion-концепт', 'Адаптация под YouTube/Twitch', 'Пакет AE и экспортированные файлы'],
  },
];

const processSteps = [
  {
    title: 'Брифинг',
    detail: 'Определяем цели, аудиторию, платформы и визуальные предпочтения.',
  },
  {
    title: 'Концепция',
    detail: 'Предлагаем варианты стиля и цветовые решения, согласовываем направление.',
  },
  {
    title: 'Продакшн',
    detail: 'Создаём финальные дизайны, тестируем на разных устройствах и вносит правки.',
  },
  {
    title: 'Передача',
    detail: 'Отдаём готовые файлы, гайд по использованию и рекомендации по публикациям.',
  },
];

const ServicesPage = () => {
  return (
    <>
      <SEO
        title="Услуги DigitalCovers"
        description="Индивидуальные дизайн-пакеты, адаптация шаблонов и motion-дизайн от DigitalCovers. Выберите решение под вашу задачу."
        keywords="индивидуальный дизайн, адаптация шаблонов, motion-дизайн DigitalCovers"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Услуги DigitalCovers</h1>
          <p>Помимо каталога, мы создаём кастомные проекты, адаптируем шаблоны и сопровождаем запуск визуальной айдентики под ключ.</p>
          <Link to="/contacts" className="buttonPrimary">Обсудить проект</Link>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <h2 className="sectionTitle">Что мы предлагаем</h2>
        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <article className={styles.serviceCard} key={service.title}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <ul>
                {service.deliverables.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <h2 className="sectionTitle">Процесс работы</h2>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <div className={styles.processCard} key={step.title}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;