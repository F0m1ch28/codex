import React from 'react';
import SEO from '../components/SEO';
import styles from './Help.module.css';

const faqs = [
  {
    question: 'Как получить доступ к файлам после покупки?',
    answer: 'После оформления заказа вы получаете ссылку на скачивание. Файлы остаются доступны в личном кабинете, и вы можете скачивать их повторно.',
  },
  {
    question: 'Можно ли использовать дизайн в коммерческих проектах?',
    answer: 'Да, все материалы предоставляются с лицензией на коммерческое использование. Важно не перепродавать исходные файлы без изменений.',
  },
  {
    question: 'Как запросить индивидуальный дизайн?',
    answer: 'Заполните форму на странице контактов или напишите на support@digitalcovers.ru с описанием задачи, сроками и референсами.',
  },
  {
    question: 'Предоставляете ли вы возврат средств?',
    answer: 'Если вы не получили файлы или столкнулись с технической проблемой, напишите нам. Мы поможем решить вопрос или предложим возврат.',
  },
];

const HelpPage = () => {
  return (
    <>
      <SEO
        title="Помощь и FAQ — DigitalCovers"
        description="Ответы на популярные вопросы, инструкции по работе с каталогом и поддержке DigitalCovers."
        keywords="DigitalCovers FAQ, помощь, поддержка DigitalCovers"
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Помощь и ответы на вопросы</h1>
          <p>Наши специалисты собрали ключевые вопросы, чтобы вы могли быстро разобраться с заказами, форматами и поддержкой DigitalCovers.</p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.faqList}>
          {faqs.map((item) => (
            <div className={styles.faqItem} key={item.question}>
              <h3>{item.question}</h3>
              <p>{item.answer}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.support}>
        <div className="container">
          <div className={styles.supportCard}>
            <h2>Не нашли ответ?</h2>
            <p>Напишите нам на <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a> или оставьте заявку через форму — мы ответим в течение рабочего дня.</p>
            <a href="/contacts" className="buttonPrimary">Связаться с поддержкой</a>
          </div>
        </div>
      </section>
    </>
  );
};

export default HelpPage;