import React from 'react';
import SEO from '../components/SEO';
import styles from './About.module.css';

const values = [
  {
    title: 'Дизайн с характером',
    description: 'Мы всегда ищем визуальные метафоры, которые усиливают смысл вашего контента и запоминаются аудитории.',
  },
  {
    title: 'Скорость и гибкость',
    description: 'Каталог обновляется каждую неделю, а индивидуальные проекты стартуют в течение двух рабочих дней.',
  },
  {
    title: 'Поддержка 24/7',
    description: 'Команда заботится о клиентах: помогаем выбрать, адаптировать и подготовить файлы для любого канала.',
  },
];

const team = [
  {
    name: 'Наталья Громова',
    role: 'Креативный директор',
    bio: '10 лет в digital-дизайне, курировала визуал для крупных медиа-платформ и онлайн-школ.',
    photo: 'https://picsum.photos/400/400?random=5',
  },
  {
    name: 'Максим Орлов',
    role: 'Lead Motion Designer',
    bio: 'Специализируется на анимации и обложках для YouTube-каналов, знает лучшие практики CTR.',
    photo: 'https://picsum.photos/400/400?random=6',
  },
  {
    name: 'Екатерина Цветкова',
    role: 'Art Producer',
    bio: 'Отвечает за подбор трендов и координацию команд, чтобы каталог всегда был актуальным.',
    photo: 'https://picsum.photos/400/400?random=7',
  },
];

const AboutPage = () => {
  return (
    <>
      <SEO
        title="О компании DigitalCovers"
        description="DigitalCovers — команда дизайнеров и продюсеров, создающих цифровые обложки, аватарки и графику для контент-креаторов."
        keywords="DigitalCovers, о компании, команда, дизайн для YouTube, дизайн для соцсетей"
      />
      <section className={styles.hero}>
        <div className="container">
          <span className={styles.badge}>О компании</span>
          <h1>DigitalCovers создаёт дизайн, который выделяет контент</h1>
          <p>Мы помогаем блогерам, стримерам и брендам рассказывать истории, которые хочется смотреть и делиться. От первой идеи до готовой графики — всё внутри одной команды.</p>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.story}>
          <div>
            <h2 className="sectionTitle">История DigitalCovers</h2>
            <p>DigitalCovers родился как проект арт-директоров, которые помогали друзьям-блогерам оформлять каналы. Постепенно мы превратили экспертизу в библиотеку из тысяч готовых решений, а теперь работаем с контент-мейкерами из 20+ стран.</p>
            <p>Мы объединяем дизайнеров, иллюстраторов и motion-специалистов, чтобы вы могли за считанные часы получить визуал мирового уровня.</p>
          </div>
          <img src="https://picsum.photos/800/600?random=8" alt="Команда DigitalCovers за работой" />
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <h2 className="sectionTitle">Ценности команды</h2>
        <div className={styles.values}>
          {values.map((value) => (
            <div className={styles.valueCard} key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <h2 className="sectionTitle">Команда DigitalCovers</h2>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <div className={styles.teamCard} key={member.name}>
                <img src={member.photo} alt={member.name} loading="lazy" />
                <div>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} container`}>
        <div className={styles.timeline}>
          <div>
            <h2 className="sectionTitle">Рост и ключевые этапы</h2>
            <p>DigitalCovers развивался вместе с создателями контента. Мы внедряли новые форматы, расширяли команды и запускали сервисы поддержки, которые делают работу с визуалом проще.</p>
          </div>
          <ul className={styles.timelineList}>
            <li>
              <span className={styles.timelineYear}>2018</span>
              <p>Запуск первых коллекций обложек для YouTube и Twitch, команда — 4 дизайнера.</p>
            </li>
            <li>
              <span className={styles.timelineYear}>2020</span>
              <p>Добавили направление графики для соцсетей и создали редакцию кураторов.</p>
            </li>
            <li>
              <span className={styles.timelineYear}>2022</span>
              <p>Запустили международные коллаборации и программу кастомных проектов.</p>
            </li>
            <li>
              <span className={styles.timelineYear}>2023</span>
              <p>Обновили платформу, подключили автоматизированные рекомендации и расширили библиотеку до 3000+ дизайнов.</p>
            </li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default AboutPage;