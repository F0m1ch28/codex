import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className="container">
        <div className={styles.grid}>
          <div>
            <div className={styles.brand}>
              <span className={styles.brandMark}>DC</span>
              <span className={styles.brandName}>DigitalCovers</span>
            </div>
            <p className={styles.description}>
              DigitalCovers — международный онлайн-магазин цифрового дизайна. Мы создаём выразительные обложки для видео, аватарки и графику, которая помогает контент-мейкерам выделяться.
            </p>
            <div className={styles.socials}>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube DigitalCovers">
                YouTube
              </a>
              <a href="https://www.twitch.tv" target="_blank" rel="noreferrer" aria-label="Twitch DigitalCovers">
                Twitch
              </a>
              <a href="https://t.me" target="_blank" rel="noreferrer" aria-label="Telegram DigitalCovers">
                Telegram
              </a>
              <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram DigitalCovers">
                Instagram
              </a>
            </div>
          </div>

          <div>
            <h4 className={styles.columnTitle}>Разделы</h4>
            <ul className={styles.links}>
              <li><Link to="/">Главная</Link></li>
              <li><Link to="/catalog">Каталог</Link></li>
              <li><Link to="/catalog/video-covers">Обложки для видео</Link></li>
              <li><Link to="/catalog/avatars-icons">Аватарки и иконки</Link></li>
              <li><Link to="/catalog/social-media">Графика для соцсетей</Link></li>
            </ul>
          </div>

          <div>
            <h4 className={styles.columnTitle}>Компания</h4>
            <ul className={styles.links}>
              <li><Link to="/about">О компании</Link></li>
              <li><Link to="/services">Услуги по запросу</Link></li>
              <li><Link to="/help">Помощь / FAQ</Link></li>
              <li><Link to="/terms-of-use">Условия использования</Link></li>
              <li><Link to="/privacy-policy">Политика конфиденциальности</Link></li>
              <li><Link to="/cookie-policy">Политика Cookies</Link></li>
            </ul>
          </div>

          <div>
            <h4 className={styles.columnTitle}>Контакты</h4>
            <address className={styles.address}>
              <span>123456, Россия, г. Москва, ул. Цифровая, д. 1, офис 10.</span>
              <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              <a href="mailto:support@digitalcovers.ru">support@digitalcovers.ru</a>
            </address>
            <p className={styles.legal}>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;