import React, { useState } from 'react';
import styles from './ContactForm.module.css';

const initialState = {
  name: '',
  email: '',
  message: '',
  topic: 'Общий вопрос',
};

const ContactForm = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Введите ваше имя.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Введите ваш email.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Проверьте корректность email.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Опишите ваш запрос.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setSubmitted(true);
      setFormData(initialState);
    }
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit} noValidate>
      <div className={styles.fieldGroup}>
        <label htmlFor="name">Имя</label>
        <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} placeholder="Как к вам обращаться?" aria-invalid={Boolean(errors.name)} />
        {errors.name && <span className={styles.error}>{errors.name}</span>}
      </div>

      <div className={styles.fieldGroup}>
        <label htmlFor="email">Email</label>
        <input id="email" name="email" type="email" value={formData.email} onChange={handleChange} placeholder="name@example.com" aria-invalid={Boolean(errors.email)} />
        {errors.email && <span className={styles.error}>{errors.email}</span>}
      </div>

      <div className={styles.fieldGroup}>
        <label htmlFor="topic">Тема обращения</label>
        <select id="topic" name="topic" value={formData.topic} onChange={handleChange}>
          <option>Общий вопрос</option>
          <option>Индивидуальный дизайн</option>
          <option>Сотрудничество и партнёрство</option>
          <option>Помощь с заказом</option>
        </select>
      </div>

      <div className={styles.fieldGroup}>
        <label htmlFor="message">Сообщение</label>
        <textarea id="message" name="message" rows="5" value={formData.message} onChange={handleChange} placeholder="Расскажите, что именно вам нужно" aria-invalid={Boolean(errors.message)} />
        {errors.message && <span className={styles.error}>{errors.message}</span>}
      </div>

      <button type="submit" className="buttonPrimary">Отправить сообщение</button>

      {submitted && (
        <div className={styles.success} role="status">
          Спасибо! Мы получили ваше сообщение и ответим в ближайшее время на указанный email.
        </div>
      )}
    </form>
  );
};

export default ContactForm;