import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={`container ${styles.headerInner}`}>
        <Link to="/" className={styles.logo} aria-label="DigitalCovers — на главную">
          <span className={styles.logoMark}>DC</span>
          <span className={styles.logoText}>DigitalCovers</span>
        </Link>

        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          <NavLink to="/" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Главная
          </NavLink>
          <NavLink to="/catalog" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Каталог
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            О нас
          </NavLink>
          <NavLink to="/contacts" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Контакты
          </NavLink>
          <NavLink to="/help" className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)} onClick={closeMenu}>
            Помощь
          </NavLink>
        </nav>

        <div className={styles.actions}>
          <Link to="/catalog" className={styles.carouselButton} onClick={closeMenu}>
            Каталог
          </Link>
          <button className={styles.menuButton} onClick={toggleMenu} aria-expanded={isMenuOpen} aria-controls="main-navigation" aria-label="Меню">
            <span className={styles.menuLine} />
            <span className={styles.menuLine} />
            <span className={styles.menuLine} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;