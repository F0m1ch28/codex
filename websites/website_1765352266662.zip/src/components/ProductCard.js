import React from 'react';
import styles from './ProductCard.module.css';

const ProductCard = ({ image, title, description, tags }) => {
  return (
    <article className={styles.card}>
      <div className={styles.visual}>
        <img src={image} alt={title} loading="lazy" />
        <div className={styles.overlay}>
          <span>Открыть детали</span>
        </div>
      </div>
      <div className={styles.body}>
        <h3 className={styles.title}>{title}</h3>
        <p className={styles.description}>{description}</p>
        <div className={styles.tags}>
          {tags.map((tag) => (
            <span key={tag}>{tag}</span>
          ))}
        </div>
      </div>
    </article>
  );
};

export default ProductCard;