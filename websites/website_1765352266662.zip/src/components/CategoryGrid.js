import React from 'react';
import { Link } from 'react-router-dom';
import styles from './CategoryGrid.module.css';

const CategoryGrid = ({ categories }) => {
  return (
    <div className={styles.grid}>
      {categories.map((category) => (
        <Link to={category.link} className={styles.card} key={category.title}>
          <div className={styles.imageWrapper}>
            <img src={category.image} alt={category.alt} loading="lazy" />
            <span className={styles.label}>{category.title}</span>
          </div>
          <div className={styles.body}>
            <p>{category.description}</p>
            <span className={styles.cta}>Открыть категорию →</span>
          </div>
        </Link>
      ))}
    </div>
  );
};

export default CategoryGrid;