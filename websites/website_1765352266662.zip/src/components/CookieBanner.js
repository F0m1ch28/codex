import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'digitalcovers_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление о cookie">
      <div className={styles.content}>
        <p>
          Мы используем файлы cookies, чтобы обеспечить удобную работу сайта и анализировать использование сервиса. Продолжая пользоваться сайтом, вы соглашаетесь с{' '}
          <a href="/cookie-policy">политикой использования cookies</a>.
        </p>
        <button className={styles.button} onClick={acceptCookies}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;