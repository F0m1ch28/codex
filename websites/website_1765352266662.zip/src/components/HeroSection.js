import React from 'react';
import { Link } from 'react-router-dom';
import styles from './HeroSection.module.css';

const HeroSection = ({ title, subtitle, description, primaryCta, secondaryCta, backgroundImage }) => {
  return (
    <section className={styles.hero}>
      <div className={`${styles.heroInner} container`}>
        <div className={styles.content}>
          <div className={styles.badge}>Цифровой дизайн мирового класса</div>
          <h1 className={styles.title}>{title}</h1>
          <p className={styles.subtitle}>{subtitle}</p>
          {description && <p className={styles.description}>{description}</p>}
          <div className={styles.actions}>
            {primaryCta && (
              <Link to={primaryCta.to} className="buttonPrimary">
                {primaryCta.label}
              </Link>
            )}
            {secondaryCta && (
              <Link to={secondaryCta.to} className="buttonSecondary">
                {secondaryCta.label}
              </Link>
            )}
          </div>
          <ul className={styles.highlights}>
            <li><span role="img" aria-hidden="true">🎬</span> Обложки для YouTube и Twitch</li>
            <li><span role="img" aria-hidden="true">💬</span> Аватарки и иконки для соцсетей</li>
            <li><span role="img" aria-hidden="true">⚡</span> Готовые файлы в PNG, PSD, SVG</li>
          </ul>
        </div>
        <div className={styles.visual} aria-hidden="true">
          <img src={backgroundImage} alt="Пример цифрового дизайна DigitalCovers" loading="lazy" />
          <div className={styles.card}>
            <p>Более 3200 дизайнов, созданных нашими арт-директорами для блогеров, стримеров и брендов.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;