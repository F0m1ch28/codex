document.addEventListener("DOMContentLoaded", () => {
  const banner = document.getElementById("cookie-banner");
  const consentButtons = document.querySelectorAll("[data-cookie-consent]");
  const consentKey = "luxefestive-cookie-consent";

  function setBannerVisibility() {
    const consent = localStorage.getItem(consentKey);
    if (!consent) {
      banner?.classList.add("active");
    } else {
      banner?.classList.remove("active");
    }
  }

  consentButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const action = button.getAttribute("data-cookie-consent");
      localStorage.setItem(consentKey, action);
      banner?.classList.remove("active");
    });
  });

  setBannerVisibility();

  const filterButtons = document.querySelectorAll(".filter-btn");
  const productCards = document.querySelectorAll(".product-card");

  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const filter = button.getAttribute("data-filter");
      filterButtons.forEach((btn) => btn.classList.remove("active"));
      button.classList.add("active");

      productCards.forEach((card) => {
        const categories = card.getAttribute("data-category");
        if (filter === "all" || categories.includes(filter)) {
          card.style.display = "flex";
        } else {
          card.style.display = "none";
        }
      });
    });
  });

  const builderForm = document.getElementById("builder-form");
  if (builderForm) {
    const themeSelect = document.getElementById("box-theme");
    const summaryTheme = document.getElementById("summary-theme");
    const summaryTreats = document.getElementById("summary-treats");
    const summaryDate = document.getElementById("summary-date");
    const summaryMessage = document.getElementById("summary-message");
    const totalDisplay = document.getElementById("builder-total");
    const giftMessage = document.getElementById("gift-message");
    const saveButton = document.getElementById("save-build");

    function calculateTotal() {
      let total = 0;
      const themeOption = themeSelect.options[themeSelect.selectedIndex];
      total += Number(themeOption.dataset.price || 0);

      const selectedTreats = builderForm.querySelectorAll("input[name='treats']:checked");
      const selectedAccents = builderForm.querySelectorAll("input[name='accents']:checked");
      const selectedCard = builderForm.querySelector("input[name='card']:checked");

      const selectedItems = [];

      summaryTreats.innerHTML = "";

      selectedTreats.forEach((item) => {
        total += Number(item.dataset.price || 0);
        selectedItems.push(item.value);
        const listItem = document.createElement("li");
        listItem.textContent = item.parentElement.querySelector("span").textContent;
        summaryTreats.appendChild(listItem);
      });

      selectedAccents.forEach((item) => {
        total += Number(item.dataset.price || 0);
        selectedItems.push(item.value);
        const listItem = document.createElement("li");
        listItem.textContent = item.parentElement.querySelector("span").textContent;
        summaryTreats.appendChild(listItem);
      });

      if (selectedCard) {
        total += Number(selectedCard.dataset.price || 0);
        const listItem = document.createElement("li");
        listItem.textContent = selectedCard.parentElement.querySelector("span").textContent;
        summaryTreats.appendChild(listItem);
      }

      if (!summaryTreats.hasChildNodes()) {
        const placeholder = document.createElement("li");
        placeholder.textContent = "Foil Holiday Card";
        summaryTreats.appendChild(placeholder);
      }

      summaryTheme.textContent = themeOption.textContent.split("—")[0].trim();
      totalDisplay.textContent = `$${total}`;

      const deliveryDate = document.getElementById("delivery-date").value;
      summaryDate.textContent = deliveryDate ? new Date(deliveryDate).toLocaleDateString() : "Select a date";

      if (giftMessage && giftMessage.value.trim().length > 0) {
        summaryMessage.textContent = `Message will read: “${giftMessage.value.trim()}”`;
      } else {
        summaryMessage.textContent = "Share your message to include a handwritten note in the box.";
      }
    }

    builderForm.addEventListener("change", calculateTotal);
    giftMessage?.addEventListener("input", calculateTotal);

    saveButton?.addEventListener("click", () => {
      calculateTotal();
      saveButton.textContent = "Added!";
      saveButton.disabled = true;
      setTimeout(() => {
        saveButton.textContent = "Add to Wishlist";
        saveButton.disabled = false;
      }, 1800);
    });

    calculateTotal();
  }
});