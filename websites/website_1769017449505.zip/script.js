document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', function () {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      siteNav.classList.toggle('is-open');
      document.body.classList.toggle('nav-open', !isExpanded);
    });

    siteNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navToggle.setAttribute('aria-expanded', 'false');
        siteNav.classList.remove('is-open');
        document.body.classList.remove('nav-open');
      });
    });
  }

  const banner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  const consentKey = 'gbs_cookie_consent';

  if (banner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      banner.classList.add('is-visible');
    } else {
      banner.classList.add('is-hidden');
    }

    const handleConsent = function (value) {
      localStorage.setItem(consentKey, value);
      banner.classList.remove('is-visible');
      banner.classList.add('is-hidden');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        handleConsent('accepted');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        handleConsent('declined');
      });
    }
  }
});