document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".primary-nav");
    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navMenu.classList.toggle("is-open");
        });
        navMenu.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                navToggle.setAttribute("aria-expanded", "false");
                navMenu.classList.remove("is-open");
            });
        });
    }

    const currentPath = window.location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".primary-nav .nav-link").forEach(function (link) {
        const linkPath = link.getAttribute("href");
        if (linkPath === currentPath) {
            link.classList.add("is-current");
        }
    });

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-btn[data-preference]");
    const cookiePreference = localStorage.getItem("wdg_cookie_preference");

    if (cookieBanner && cookiePreference) {
        cookieBanner.classList.add("hidden");
    }

    cookieButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            const preference = button.getAttribute("data-preference");
            if (preference) {
                localStorage.setItem("wdg_cookie_preference", preference);
            }
        });
    });

    const levelFilter = document.getElementById("levelFilter");
    const topicFilter = document.getElementById("topicFilter");
    const courseCards = document.querySelectorAll(".course-card");

    function applyCourseFilters() {
        const levelValue = levelFilter ? levelFilter.value : "all";
        const topicValue = topicFilter ? topicFilter.value : "all";
        courseCards.forEach(function (card) {
            const cardLevel = card.getAttribute("data-level");
            const cardTopic = card.getAttribute("data-topic");
            const matchesLevel = levelValue === "all" || cardLevel === levelValue;
            const matchesTopic = topicValue === "all" || cardTopic === topicValue;
            card.style.display = matchesLevel && matchesTopic ? "" : "none";
        });
    }

    if (levelFilter && topicFilter) {
        levelFilter.addEventListener("change", applyCourseFilters);
        topicFilter.addEventListener("change", applyCourseFilters);
    }
});