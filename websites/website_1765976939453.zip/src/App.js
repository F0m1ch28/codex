import React, { useEffect } from 'react';
import { Routes, Route, Link, useParams } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';

const blogPosts = [
  {
    slug: 'consejos-para-manana-productiva',
    title: 'Consejos para una mañana productiva y tranquila',
    description:
      'Descubre cómo diseñar una rutina matutina suave que active tu energía sin estrés y marque el tono del día.',
    image: 'https://picsum.photos/seed/rutina/1200/800',
    readTime: '5 minutos',
    content: [
      'Abrir el día con intención es la llave para sostener la calma a lo largo de la jornada. Empieza por un despertar consciente: evita revisar el teléfono en los primeros quince minutos y regálate una pausa para respirar profundo mientras estiras el cuerpo.',
      'Continúa con un ritual breve —puede ser escribir tres intenciones, tomar agua tibia con limón o escuchar una pieza de música suave— que te recuerde que tú marcas el ritmo. Cuando por fin te sientes a planificar, trabaja con bloques de enfoque: identifica tres prioridades esenciales y asigna espacios generosos para cada una.',
      'Cierra la mañana con una revisión agradecida de lo que sí avanzó. Este gesto mantiene alta la motivación y protege tus niveles de energía para la tarde. Recuerda: productividad serena significa avanzar sin forzar el cuerpo ni la mente.'
    ]
  },
  {
    slug: 'tecnicas-desconexion-digital',
    title: 'Técnicas de desconexión digital para cuidar tu mente',
    description:
      'Implementa límites amables con la tecnología y recupera horas de descanso profundo para tu creatividad.',
    image: 'https://picsum.photos/seed/digital/1200/800',
    readTime: '6 minutos',
    content: [
      'La sobreexposición a pantallas es uno de los mayores detonantes de ansiedad y desorden mental. En Coralindo Mariso sugerimos comenzar por un inventario honesto de los momentos en los que utilizas dispositivos sin una intención clara.',
      'Diseña rituales de cierre digital: define un horario fijo para el último correo del día y crea un espacio físico donde guardar el teléfono durante tus cenas o conversaciones íntimas. Complementa con notificaciones inteligentes; apaga todo aquello que no requiera respuesta inmediata.',
      'Finalmente, incorpora micro pausas sin pantallas: salir a caminar, observar el cielo o simplemente cerrar los ojos y escuchar sonidos naturales. Estas anclas sensoriales regeneran tu atención y te devuelven al presente con más serenidad y claridad.'
    ]
  },
  {
    slug: 'rituales-para-cerrar-el-dia',
    title: 'Rituales para cerrar el día y dormir en paz',
    description:
      'Pequeños hábitos vespertinos que separan tu vida laboral de la personal y preparan un descanso reparador.',
    image: 'https://picsum.photos/seed/noche/1200/800',
    readTime: '4 minutos',
    content: [
      'El cierre del día es tan importante como el arranque. Empieza por una revisión amable: registra qué lograste, qué quedó pendiente y cómo te sentiste. Permite que el agradecimiento tome protagonismo.',
      'Después, haz un “reset” visual del espacio. Ordena tu escritorio, apaga luces intensas y enciende una lámpara cálida. Este cambio de ambiente le indica a tu cerebro que la fase activa culminó.',
      'Crea un ritual de transición: puede ser un té relajante, una lectura ligera o una breve meditación. Al acostarte, practica respiraciones profundas contando hasta cuatro y prolongando la exhalación. Tu mente sabrá que es momento de soltar y tu descanso se volverá más profundo.'
    ]
  }
];

const updateMetaDescription = (description) => {
  const metaDescription = document.querySelector('meta[name="description"]');
  if (metaDescription) {
    metaDescription.setAttribute('content', description);
  }
};

const GuidePage = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Cómo trabajamos juntos';
    updateMetaDescription(
      'Explora el proceso de colaboración con Coralindo Mariso y descubre cómo te acompañamos paso a paso hacia una vida organizada y sin estrés.'
    );
  }, []);

  return (
    <div className="page guide-page">
      <section className="section intro">
        <div className="container">
          <p className="eyebrow">Guía de acompañamiento</p>
          <h1 className="section-title">Cómo trabajamos contigo</h1>
          <p className="section-description">
            Nuestra metodología está diseñada para acompañarte con suavidad y claridad desde el día uno. Construimos un espacio seguro para
            explorar tus retos y diseñar soluciones a medida que respeten tu ritmo.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container guide-steps">
          <div className="step-card">
            <span className="step-number">1</span>
            <h2>Exploración consciente</h2>
            <p>
              Comenzamos con una sesión de diagnóstico donde escuchamos tu historia, tus retos y tus aspiraciones. Reunimos información sobre
              hábitos, herramientas y dinámicas actuales para entender el panorama completo.
            </p>
          </div>
          <div className="step-card">
            <span className="step-number">2</span>
            <h2>Diseño colaborativo</h2>
            <p>
              Construimos un plan personalizado que equilibra tus objetivos profesionales y personales. Cada propuesta incluye micro acciones
              sostenibles y herramientas fáciles de integrar en tu día a día.
            </p>
          </div>
          <div className="step-card">
            <span className="step-number">3</span>
            <h2>Acompañamiento activo</h2>
            <p>
              Caminamos a tu lado durante la implementación con sesiones de seguimiento, ajustes semanales y recordatorios afectivos para que
              no te sientas sola o solo en el proceso.
            </p>
          </div>
          <div className="step-card">
            <span className="step-number">4</span>
            <h2>Cierre y sostenibilidad</h2>
            <p>
              Celebramos lo logrado, documentamos aprendizajes y te entregamos un plan de mantenimiento. Nuestro objetivo es que sigas
              avanzando con autonomía y confianza.
            </p>
          </div>
        </div>
      </section>

      <section className="section bg-soft">
        <div className="container guide-cta">
          <h2>Tu bienestar merece un plan a la altura</h2>
          <p>
            Agenda una conversación gratuita de 20 minutos para identificar qué programa se ajusta mejor a tu momento. Estamos aquí para
            cuidarte mientras construyes la vida organizada y serena que imaginas.
          </p>
          <div className="cta-actions">
            <Link to="/contact" className="btn primary">
              Reservar conversación
            </Link>
            <Link to="/programs" className="btn ghost">
              Ver programas completos
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

const ToolsPage = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Herramientas que nos inspiran';
    updateMetaDescription(
      'Explora herramientas, recursos y buenas prácticas seleccionadas por Coralindo Mariso para organizar tu vida y trabajo con serenidad.'
    );
  }, []);

  return (
    <div className="page tools-page">
      <section className="section">
        <div className="container">
          <p className="eyebrow">Recursos esenciales</p>
          <h1 className="section-title">Herramientas para una vida organizada</h1>
          <p className="section-description">
            Seleccionamos recursos confiables y amigables que complementan nuestros programas. Cada herramienta se integra con facilidad a tu
            rutina y te ayuda a sostener los cambios a largo plazo.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container tools-grid">
          <article className="tool-card">
            <h2>Plantilla balance semanal</h2>
            <p>
              Un diseño propio que combina prioridades, autocuidado y bloques de descanso. Ideal para visualizar cada área de tu vida en un
              solo lugar.
            </p>
            <a
              className="btn-link"
              href="https://docs.google.com/spreadsheets/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Descargar plantilla
            </a>
          </article>
          <article className="tool-card">
            <h2>Tablero de enfoque profundo</h2>
            <p>
              Configuración en Trello para gestionar proyectos con foco en resultados sostenibles. Incluye etiquetas calmadas y checklist de
              autocuidado.
            </p>
            <a className="btn-link" href="https://trello.com/" target="_blank" rel="noopener noreferrer">
              Ver tablero guía
            </a>
          </article>
          <article className="tool-card">
            <h2>Guía de pausas conscientes</h2>
            <p>
              Un manual breve con respiraciones, estiramientos y meditaciones de menos de cinco minutos para reactivar tu energía durante el
              día laboral.
            </p>
            <a className="btn-link" href="https://www.calm.com/" target="_blank" rel="noopener noreferrer">
              Inspiración sonora
            </a>
          </article>
          <article className="tool-card">
            <h2>Biblioteca de hábitos suaves</h2>
            <p>
              Lista curada de artículos, podcasts y ejercicios que refuerzan la importancia de establecer límites y rituales de descanso.
            </p>
            <a
              className="btn-link"
              href="https://www.notion.so/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Explorar biblioteca
            </a>
          </article>
        </div>
      </section>

      <section className="section bg-soft">
        <div className="container">
          <h2>Más recursos en tu bandeja</h2>
          <p>
            Suscríbete a nuestro boletín mensual con ideas prácticas, plantillas exclusivas y recordatorios para vivir con menos prisa y más
            intención.
          </p>
          <Link to="/contact" className="btn primary">
            Solicitar boletín
          </Link>
        </div>
      </section>
    </div>
  );
};

const BlogPage = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Blog de calma productiva';
    updateMetaDescription(
      'Lecturas frescas y humanas sobre organización consciente, bienestar laboral y hábitos sostenibles para profesionales en México.'
    );
  }, []);

  return (
    <div className="page blog-page">
      <section className="section">
        <div className="container">
          <p className="eyebrow">Ideas que inspiran calma</p>
          <h1 className="section-title">Blog Coralindo</h1>
          <p className="section-description">
            Artículos breves y cercanos para ayudarte a construir sistemas que honren tu energía y tus metas. Lee, comparte y aplica a tu
            ritmo.
          </p>
        </div>
      </section>
      <section className="section light">
        <div className="container blog-list">
          {blogPosts.map((post) => (
            <article key={post.slug} className="blog-card">
              <img src={post.image} alt={post.title} loading="lazy" />
              <div className="blog-content">
                <h2>{post.title}</h2>
                <p className="blog-meta">{post.readTime} de lectura</p>
                <p>{post.description}</p>
                <Link to={`/blog/${post.slug}`} className="btn-link">
                  Leer artículo completo
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

const BlogArticle = () => {
  const { slug } = useParams();
  const post = blogPosts.find((item) => item.slug === slug);

  useEffect(() => {
    if (post) {
      document.title = `Coralindo Mariso | ${post.title}`;
      updateMetaDescription(post.description);
    } else {
      document.title = 'Coralindo Mariso | Artículo no encontrado';
    }
  }, [post]);

  if (!post) {
    return (
      <div className="page blog-article">
        <section className="section">
          <div className="container">
            <h1 className="section-title">Artículo no encontrado</h1>
            <p>
              No pudimos encontrar la publicación que buscas. Te invitamos a regresar al blog y explorar otras ideas llenas de calma.
            </p>
            <Link to="/blog" className="btn primary">
              Volver al blog
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="page blog-article">
      <section className="section article-hero">
        <div className="container narrow">
          <p className="eyebrow">Lecturas Coralindo</p>
          <h1 className="section-title">{post.title}</h1>
          <p className="blog-meta">{post.readTime} de lectura • Coralindo Mariso</p>
        </div>
      </section>
      <section className="section">
        <div className="container narrow">
          <img className="article-cover" src={post.image} alt={post.title} loading="lazy" />
          {post.content.map((paragraph, index) => (
            <p key={index} className="article-paragraph">
              {paragraph}
            </p>
          ))}
          <div className="article-footer">
            <p>
              ¿Te gustaría profundizar en este tema con acompañamiento personalizado? Nuestro equipo está listo para escuchar tu historia.
            </p>
            <div className="cta-actions">
              <Link to="/contact" className="btn primary">
                Solicitar acompañamiento
              </Link>
              <Link to="/blog" className="btn ghost">
                Más artículos
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

const CookiePolicyPage = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Política de cookies';
    updateMetaDescription(
      'Conoce cómo Coralindo Mariso utiliza cookies para ofrecerte una experiencia agradable y proteger tu privacidad en línea.'
    );
  }, []);

  return (
    <div className="page legal-page">
      <section className="section">
        <div className="container">
          <h1 className="section-title">Política de uso de cookies</h1>
          <p>
            En Coralindo Mariso usamos cookies esenciales y analíticas para mejorar tu experiencia de navegación. Las cookies nos permiten
            recordar tus preferencias y entender qué contenidos son más valiosos para nuestra comunidad.
          </p>
          <h2>¿Qué tipos de cookies utilizamos?</h2>
          <ul>
            <li>
              <strong>Cookies necesarias:</strong> habilitan funciones básicas como la navegación y el acceso a áreas seguras del sitio.
            </li>
            <li>
              <strong>Cookies de rendimiento:</strong> recopilan información anónima sobre el uso del sitio para mejorar nuestros servicios.
            </li>
            <li>
              <strong>Cookies de funcionalidad:</strong> recuerdan tus preferencias para ofrecerte una experiencia más personalizada.
            </li>
          </ul>
          <h2>Gestión de cookies</h2>
          <p>
            Puedes aceptar o rechazar cookies directamente en nuestro banner emergente. Además, puedes modificar la configuración de tu
            navegador para eliminarlas o impedir su instalación futura. Ten en cuenta que desactivar ciertas cookies puede afectar el
            funcionamiento del sitio.
          </p>
          <h2>Contacto</h2>
          <p>
            Si tienes dudas sobre cómo usamos las cookies, escribe a{' '}
            <a href="mailto:hola@coralindomariso.site">hola@coralindomariso.site</a>. Nos encantará apoyarte.
          </p>
        </div>
      </section>
    </div>
  );
};

const NotFoundPage = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Página no encontrada';
    updateMetaDescription(
      'La página que buscas no está disponible. Descubre Coralindo Mariso y las soluciones que tenemos para ti en México.'
    );
  }, []);

  return (
    <div className="page not-found">
      <section className="section">
        <div className="container">
          <h1 className="section-title">Ups, no encontramos lo que buscas</h1>
          <p>
            Puede que el enlace haya cambiado o que la página ya no exista. Te invitamos a regresar al inicio o explorar nuestros programas
            y artículos más recientes.
          </p>
          <div className="cta-actions">
            <Link to="/" className="btn primary">
              Ir a inicio
            </Link>
            <Link to="/programs" className="btn ghost">
              Conocer programas
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

const App = () => {
  return (
    <div className="app-shell">
      <Header />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/guide" element={<GuidePage />} />
          <Route path="/programs" element={<Services />} />
          <Route path="/tools" element={<ToolsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:slug" element={<BlogArticle />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<TermsOfService />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;