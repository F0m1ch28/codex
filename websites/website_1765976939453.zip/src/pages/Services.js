import React, { useEffect } from 'react';

const updateMetaDescription = (description) => {
  const tag = document.querySelector('meta[name="description"]');
  if (tag) {
    tag.setAttribute('content', description);
  }
};

const Services = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Programas de organización sin estrés';
    updateMetaDescription(
      'Explora los programas de Coralindo Mariso para vivir y trabajar con serenidad: acompañamiento personal, equipos conscientes y hogares en armonía.'
    );
  }, []);

  return (
    <div className="page programs-page">
      <section className="section">
        <div className="container">
          <p className="eyebrow">Programas Coralindo</p>
          <h1 className="section-title">Acompañamientos diseñados para tu ritmo</h1>
          <p>
            Cada programa combina estrategia, herramientas visuales y prácticas de autocuidado. Nos enfocamos en crear cambios tangibles y
            sostenibles que respeten tu energía.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container programs-grid">
          <article className="program-detail-card">
            <h2>Pulsos de calma semanal</h2>
            <p>
              Programa de ocho semanas dirigido a profesionales independientes. Mientras reorganizamos tu agenda, trabajamos en rituales de
              enfoque, límites sanos y celebraciones semanales. Incluye sesiones uno a uno, tableros personalizados y acompañamiento por chat.
            </p>
            <ul>
              <li>Diagnóstico de carga mental y metas prioritarias.</li>
              <li>Diseño de bloques de trabajo y descanso regenerativo.</li>
              <li>Seguimiento cercano para ajustar estrategias en vivo.</li>
            </ul>
          </article>
          <article className="program-detail-card">
            <h2>Equipos sin burnout</h2>
            <p>
              Acompañamiento para líderes y equipos en crecimiento. Facilitamos talleres interactivos, rediseñamos procesos colaborativos y
              creamos acuerdos culturales que previenen el agotamiento y fortalecen la confianza.
            </p>
            <ul>
              <li>Sesiones grupales de diagnóstico y escucha.</li>
              <li>Implementación de metodologías ágiles con enfoque humano.</li>
              <li>Plan de bienestar integral con indicadores saludables.</li>
            </ul>
          </article>
          <article className="program-detail-card">
            <h2>Casa en orden integral</h2>
            <p>
              Experiencia holística para familias que buscan armonía en su hogar. Integramos organización de espacios, administración del
              tiempo y hábitos emocionales que nutren la convivencia.
            </p>
            <ul>
              <li>Mapeo de ambientes clave y dinámicas familiares.</li>
              <li>Sesiones presenciales o virtuales con recomendaciones prácticas.</li>
              <li>Guía ilustrada para mantener el orden con facilidad.</li>
            </ul>
          </article>
          <article className="program-detail-card">
            <h2>Mentoría de liderazgo sereno</h2>
            <p>
              Dispositivo de acompañamiento ejecutivo de cuatro meses. Trabajamos en toma de decisiones consciente, gestión de prioridades,
              comunicación empática y descanso estratégico.
            </p>
            <ul>
              <li>Sesiones quincenales con herramientas de reflexión profunda.</li>
              <li>Planes trimestrales con métricas de bienestar.</li>
              <li>Prácticas de presencia plena aplicadas al liderazgo.</li>
            </ul>
          </article>
        </div>
      </section>

      <section className="section">
        <div className="container methodology">
          <h2>Nuestra metodología</h2>
          <div className="method-grid">
            <div className="method-card">
              <h3>Escucha profunda</h3>
              <p>Nos sumergimos en tu contexto y validamos cada emoción. Ninguna solución se impone, todo se construye contigo.</p>
            </div>
            <div className="method-card">
              <h3>Diseño visual</h3>
              <p>
                Co-creamos tableros y plantillas estéticamente cuidadas que invitan a usarse. La belleza es parte de la sostenibilidad.
              </p>
            </div>
            <div className="method-card">
              <h3>Acción iterativa</h3>
              <p>
                Probamos, medimos y ajustamos. Pequeños experimentos que generan grandes transformaciones sin abrumarte.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-soft">
        <div className="container">
          <h2>¿Cuál programa es ideal para ti?</h2>
          <p>
            Agenda una conversación exploratoria y recibes una guía comparativa con recomendaciones personalizadas. Será un espacio seguro
            para aclarar dudas y definir el siguiente paso.
          </p>
          <div className="cta-actions">
            <a className="btn primary" href="mailto:hola@coralindomariso.site">
              Escribir al equipo
            </a>
            <a className="btn ghost" href="tel:+525512345678">
              Llamar ahora
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;