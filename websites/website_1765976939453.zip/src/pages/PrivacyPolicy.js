import React, { useEffect } from 'react';

const updateMetaDescription = (description) => {
  const tag = document.querySelector('meta[name="description"]');
  if (tag) {
    tag.setAttribute('content', description);
  }
};

const PrivacyPolicy = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Aviso de privacidad';
    updateMetaDescription(
      'Descubre cómo Coralindo Mariso protege y gestiona tus datos personales con responsabilidad y transparencia.'
    );
  }, []);

  return (
    <div className="page legal-page">
      <section className="section">
        <div className="container">
          <h1 className="section-title">Aviso de privacidad</h1>
          <p>
            En Coralindo Mariso respetamos tu privacidad y protegemos tus datos personales conforme a la legislación mexicana aplicable. Esta
            política describe qué información recopilamos y cómo la utilizamos.
          </p>

          <h2>1. Datos que recopilamos</h2>
          <p>
            Recolectamos información de identificación personal (nombre, correo electrónico, teléfono) cuando completas formularios o te
            comunicas con nosotros. También podemos registrar datos de navegación mediante cookies para mejorar tu experiencia.
          </p>

          <h2>2. Finalidad del tratamiento</h2>
          <p>
            Utilizamos tus datos para responder solicitudes, gestionar servicios, enviar comunicaciones relevantes y mejorar nuestros
            programas. Nunca venderemos ni compartiremos tu información con terceros sin tu consentimiento expreso.
          </p>

          <h2>3. Conservación y seguridad</h2>
          <p>
            Implementamos medidas técnicas y administrativas para resguardar tu información. Conservamos tus datos únicamente durante el tiempo
            necesario para cumplir con las finalidades descritas.
          </p>

          <h2>4. Derechos ARCO</h2>
          <p>
            Puedes solicitar el acceso, rectificación, cancelación u oposición al tratamiento de tus datos en cualquier momento. Escríbenos a{' '}
            <a href="mailto:hola@coralindomariso.site">hola@coralindomariso.site</a> y atenderemos tu requerimiento.
          </p>

          <h2>5. Transferencias</h2>
          <p>
            No transferimos datos personales a terceros ajenos a Coralindo Mariso, salvo obligación legal o que sea indispensable para prestar
            un servicio que hayas solicitado.
          </p>

          <h2>6. Actualizaciones</h2>
          <p>
            Este aviso puede actualizarse sin previo aviso. La versión vigente siempre estará disponible en nuestro sitio web.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicy;