import React, { useEffect } from 'react';

const updateMetaDescription = (description) => {
  const tag = document.querySelector('meta[name="description"]');
  if (tag) {
    tag.setAttribute('content', description);
  }
};

const About = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Nuestra historia y esencia';
    updateMetaDescription(
      'Conoce la misión, visión y equipo de Coralindo Mariso, especialistas en organización y bienestar sin estrés en México.'
    );
  }, []);

  return (
    <div className="page about-page">
      <section className="section">
        <div className="container">
          <p className="eyebrow">Sobre Coralindo Mariso</p>
          <h1 className="section-title">Un hogar para la calma estratégica</h1>
          <p>
            Coralindo Mariso nació en 2016 con la convicción de que la organización puede ser un acto de cuidado propio. En plena Ciudad de
            México, decidimos crear un estudio boutique para acompañar a quienes lidian con agendas saturadas, procesos confusos y niveles de
            estrés que afectan su bienestar.
          </p>
        </div>
      </section>

      <section className="section light">
        <div className="container split">
          <div>
            <h2>Misión</h2>
            <p>
              Facilitar experiencias de organización y bienestar que respeten la humanidad de cada persona. Diseñamos estrategias adaptativas,
              visuales y suaves que incrementan la productividad y el disfrute de la vida.
            </p>
          </div>
          <div>
            <h2>Visión</h2>
            <p>
              Ser el referente latinoamericano en creación de sistemas integrales que integran trabajo, hogar y autocuidado con una mirada
              sensible y profesional.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Nuestro equipo</h2>
          <div className="team-grid">
            <article className="team-card">
              <img src="https://picsum.photos/seed/directora/320/320" alt="Retrato de Sofía Marín" loading="lazy" />
              <h3>Sofía Marín</h3>
              <p>Directora & estratega de bienestar</p>
              <p className="team-bio">
                Psicóloga organizacional y especialista en gestión del tiempo. Cree firmemente en la escucha activa como motor del cambio.
              </p>
            </article>
            <article className="team-card">
              <img src="https://picsum.photos/seed/consultor/320/320" alt="Retrato de Daniel Ruiz" loading="lazy" />
              <h3>Daniel Ruiz</h3>
              <p>Consultor de procesos visuales</p>
              <p className="team-bio">
                Diseñador de experiencias con enfoque en metodologías ágiles. Convierte ideas complejas en tableros claros y accionables.
              </p>
            </article>
            <article className="team-card">
              <img src="https://picsum.photos/seed/coach/320/320" alt="Retrato de Ilse Herrera" loading="lazy" />
              <h3>Ilse Herrera</h3>
              <p>Coach de hábitos y energía</p>
              <p className="team-bio">
                Formada en mindfulness y yoga terapéutico. Guía sesiones enfocadas en reconectar con el cuerpo y sostener nuevos hábitos.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section bg-soft">
        <div className="container">
          <h2>Nuestro compromiso social</h2>
          <p>
            El 5% de nuestras horas de consultoría se destinan a organizaciones que acompañan a mujeres emprendedoras en contextos vulnerables.
            Creemos que la calma y la organización son derechos que deben compartirse.
          </p>
        </div>
      </section>
    </div>
  );
};

export default About;