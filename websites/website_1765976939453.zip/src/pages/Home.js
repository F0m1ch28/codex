import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

const updateMetaDescription = (description) => {
  const metaDescription = document.querySelector('meta[name="description"]');
  if (metaDescription) {
    metaDescription.setAttribute('content', description);
  }
};

const Home = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Serenidad para tu vida y trabajo';
    updateMetaDescription(
      'Coralindo Mariso crea sistemas de organización y bienestar para líderes y equipos en México que desean vivir sin estrés.'
    );
  }, []);

  return (
    <div className="page home-page">
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-content">
            <p className="eyebrow">Organización con propósito</p>
            <h1>
              Diseñamos rutinas serenas para que vivas y trabajes con{' '}
              <span className="highlight">calma profunda</span>
            </h1>
            <p>
              Coralindo Mariso combina estrategia, organización y bienestar para transformar la forma en que gestionas tu tiempo, tus
              proyectos y tu energía. Crea sistemas que respiran contigo.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn primary">
                Agenda una sesión
              </Link>
              <Link to="/programs" className="btn ghost">
                Ver programas
              </Link>
            </div>
          </div>
          <div className="hero-visual">
            <img
              src="https://picsum.photos/seed/coralindo/720/540"
              alt="Espacio de trabajo minimalista y armonioso"
              loading="lazy"
            />
            <span className="hero-badge">Equilibrio real, sin prisas</span>
          </div>
        </div>
      </section>

      <section className="section bg-soft">
        <div className="container split">
          <div>
            <h2 className="section-title">Quiénes somos</h2>
            <p>
              Somos un equipo interdisciplinario con base en Ciudad de México. Acompañamos a personas y organizaciones a crear hábitos
              ligeros, procesos eficientes y espacios interiores en calma. Creemos en el poder de los pequeños ajustes sostenibles.
            </p>
            <Link to="/about" className="btn-link">
              Conoce nuestra historia
            </Link>
          </div>
          <div className="stat-group">
            <div className="stat-card">
              <span className="stat-number">+180</span>
              <p>Personas que viven con mayor claridad y serenidad</p>
            </div>
            <div className="stat-card">
              <span className="stat-number">92%</span>
              <p>Reportan menos estrés después de 8 semanas de acompañamiento</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Nuestros valores</h2>
          <div className="values-grid">
            <article className="value-card">
              <h3>Humanidad</h3>
              <p>Escuchamos tus ritmos, respetamos tus límites y celebramos la autenticidad en cada proceso.</p>
            </article>
            <article className="value-card">
              <h3>Claridad</h3>
              <p>Convertimos lo complejo en pasos sencillos, medibles y amables con tu energía.</p>
            </article>
            <article className="value-card">
              <h3>Co-creación</h3>
              <p>Tu voz guía cada decisión. Diseñamos juntas soluciones versátiles que evolucionan contigo.</p>
            </article>
            <article className="value-card">
              <h3>Sostenibilidad</h3>
              <p>Preferimos hábitos pequeños y constantes que puedas mantener toda la vida sin sacrificios extremos.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container split">
          <div>
            <h2 className="section-title">¿Por qué importa una vida organizada?</h2>
            <p>
              La organización consciente reduce el agotamiento y libera recursos mentales para la creatividad. Cuando tus sistemas funcionan,
              tienes más espacio para lo que realmente importa: tu bienestar, tus relaciones y tus ideas.
            </p>
          </div>
          <ul className="benefits-list">
            <li>Reduce el estrés y la ansiedad derivados de la carga mental.</li>
            <li>Potencia el foco y la productividad sin sacrificar descanso.</li>
            <li>Genera alineación entre tus metas personales y profesionales.</li>
            <li>Te permite disfrutar el proceso y celebrar cada avance.</li>
          </ul>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Principios Coralindo</h2>
          <div className="principles-grid">
            <article className="principle-card">
              <h3>Respirar antes de actuar</h3>
              <p>Cada recomendación nace desde la escucha y la pausa estratégica. No corremos, acompañamos.</p>
            </article>
            <article className="principle-card">
              <h3>Diseño visual claro</h3>
              <p>Utilizamos herramientas sencillas y visualmente armoniosas para que tus procesos sean ligeros.</p>
            </article>
            <article className="principle-card">
              <h3>Feedback constante</h3>
              <p>Las sesiones están llenas de retroalimentación cálida que te ayuda a ajustar el rumbo sin juicios.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="section light">
        <div className="container">
          <h2 className="section-title">Programas destacados</h2>
          <div className="program-preview-grid">
            <article className="program-card">
              <h3>Pulsos de calma semanal</h3>
              <p>
                Rituales de planificación y descanso que se integran de forma natural en tu agenda actual. Ideal para personas que desean
                recuperar control y propósito.
              </p>
              <Link to="/programs" className="btn-link">
                Descubrir programa
              </Link>
            </article>
            <article className="program-card">
              <h3>Equipos sin burnout</h3>
              <p>
                Acompañamiento grupal para líderes que buscan implementar metodologías ágiles con bienestar emocional y cultural.
              </p>
              <Link to="/programs" className="btn-link">
                Ver metodología
              </Link>
            </article>
            <article className="program-card">
              <h3>Casa en orden integral</h3>
              <p>
                Intervención holística que conecta la organización de espacios físicos con la gestión del tiempo y la energía personal.
              </p>
              <Link to="/programs" className="btn-link">
                Más detalles
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="section-title">Personas que confían en Coralindo</h2>
          <div className="testimonials-grid">
            <figure className="testimonial-card">
              <img src="https://picsum.photos/seed/cliente1/140/140" alt="Retrato de Elisa" loading="lazy" />
              <blockquote>
                “Por primera vez siento que mi agenda respira conmigo. Los recordatorios de autocuidado hicieron toda la diferencia en mi
                energía.”
              </blockquote>
              <figcaption>Elisa Martínez · Directora de marketing</figcaption>
            </figure>
            <figure className="testimonial-card">
              <img src="https://picsum.photos/seed/cliente2/140/140" alt="Retrato de Gustavo" loading="lazy" />
              <blockquote>
                “El programa para equipos nos ayudó a evitar el burnout. Hoy trabajamos con claridad y tiempos reales.”
              </blockquote>
              <figcaption>Gustavo Torres · Fundador de startup tecnológica</figcaption>
            </figure>
            <figure className="testimonial-card">
              <img src="https://picsum.photos/seed/cliente3/140/140" alt="Retrato de Mariana" loading="lazy" />
              <blockquote>
                “Mi casa y mi mente están más ordenadas. Aprendí a priorizar sin culpa y a delegar con confianza.”
              </blockquote>
              <figcaption>Mariana Álvarez · Emprendedora creativa</figcaption>
            </figure>
          </div>
        </div>
      </section>

      <section className="section bg-soft">
        <div className="container callout">
          <h2>¿Lista para una vida sin prisas innecesarias?</h2>
          <p>
            Da el primer paso y agenda una sesión de descubrimiento. En menos de media hora te mostraremos cómo construir un sistema de
            organización sereno y práctico.
          </p>
          <div className="cta-actions">
            <Link to="/contact" className="btn primary">
              ¡Conversemos!
            </Link>
            <Link to="/guide" className="btn ghost">
              Conocer proceso
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;