import React, { useEffect } from 'react';

const updateMetaDescription = (description) => {
  const tag = document.querySelector('meta[name="description"]');
  if (tag) {
    tag.setAttribute('content', description);
  }
};

const TermsOfService = () => {
  useEffect(() => {
    document.title = 'Coralindo Mariso | Términos de uso';
    updateMetaDescription(
      'Consulta los términos y condiciones de uso del sitio web y los servicios ofrecidos por Coralindo Mariso en México.'
    );
  }, []);

  return (
    <div className="page legal-page">
      <section className="section">
        <div className="container">
          <h1 className="section-title">Términos y condiciones de uso</h1>
          <p>
            Bienvenido a Coralindo Mariso. Al acceder a nuestro sitio web y utilizar nuestros servicios, aceptas los siguientes términos y
            condiciones. Te invitamos a leerlos atentamente.
          </p>

          <h2>1. Uso del sitio</h2>
          <p>
            Este sitio está destinado a brindar información sobre nuestros programas y recursos. Queda prohibido utilizarlo para fines
            ilegales, distribuir contenido malicioso o vulnerar la seguridad de la plataforma.
          </p>

          <h2>2. Servicios</h2>
          <p>
            Los programas y acompañamientos descritos pueden actualizarse sin previo aviso para garantizar su calidad. Nos reservamos el
            derecho de aceptar o rechazar nuevas colaboraciones según disponibilidad y alineación con nuestros valores.
          </p>

          <h2>3. Propiedad intelectual</h2>
          <p>
            Todo el contenido (textos, gráficos, plantillas, fotografías y materiales descargables) es propiedad de Coralindo Mariso, salvo
            que se indique lo contrario. No está permitido reproducir, distribuir o crear trabajos derivados sin autorización escrita.
          </p>

          <h2>4. Limitación de responsabilidad</h2>
          <p>
            Trabajamos con altos estándares de profesionalismo; sin embargo, cada resultado depende del compromiso personal de quien participa.
            No garantizamos resultados específicos. No somos responsables de decisiones tomadas con base exclusiva en la información del sitio.
          </p>

          <h2>5. Enlaces externos</h2>
          <p>
            Algunas secciones incluyen vínculos a herramientas o recursos de terceros. Coralindo Mariso no se hace responsable del contenido
            o políticas de privacidad de dichos sitios.
          </p>

          <h2>6. Modificaciones</h2>
          <p>
            Podemos actualizar estos términos en cualquier momento. Los cambios entrarán en vigor al publicarse en este sitio. Te sugerimos
            revisarlos periódicamente.
          </p>

          <h2>7. Contacto</h2>
          <p>
            Si tienes preguntas sobre estos términos, escríbenos a{' '}
            <a href="mailto:hola@coralindomariso.site">hola@coralindomariso.site</a>. Será un placer apoyarte.
          </p>
        </div>
      </section>
    </div>
  );
};

export default TermsOfService;