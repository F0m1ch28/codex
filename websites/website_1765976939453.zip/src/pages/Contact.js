import React, { useEffect, useState } from 'react';

const updateMetaDescription = (description) => {
  const tag = document.querySelector('meta[name="description"]');
  if (tag) {
    tag.setAttribute('content', description);
  }
};

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    document.title = 'Coralindo Mariso | Contacto y acompañamiento';
    updateMetaDescription(
      'Ponte en contacto con Coralindo Mariso para diseñar un plan de organización y bienestar sin estrés a tu medida.'
    );
  }, []);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Por favor escribe tu nombre.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Necesitamos tu correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'El correo no tiene un formato válido.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Cuéntanos brevemente qué necesitas.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
    }
  };

  return (
    <div className="page contact-page">
      <section className="section">
        <div className="container contact-grid">
          <div>
            <p className="eyebrow">Hablemos con calma</p>
            <h1 className="section-title">Conecta con Coralindo Mariso</h1>
            <p>
              Cuéntanos qué te gustaría reorganizar y te responderemos en menos de 24 horas hábiles con ideas iniciales y próximos pasos. Nos
              encanta escuchar y acompañar procesos con presencia genuina.
            </p>
            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">Nombre completo</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Escribe tu nombre"
                value={formData.name}
                onChange={(event) => setFormData({ ...formData, name: event.target.value })}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className="error-message" role="alert">
                  {errors.name}
                </span>
              )}

              <label htmlFor="email">Correo electrónico</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="tu@correo.com"
                value={formData.email}
                onChange={(event) => setFormData({ ...formData, email: event.target.value })}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className="error-message" role="alert">
                  {errors.email}
                </span>
              )}

              <label htmlFor="message">Mensaje</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Comparte tus retos o preguntas..."
                value={formData.message}
                onChange={(event) => setFormData({ ...formData, message: event.target.value })}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className="error-message" role="alert">
                  {errors.message}
                </span>
              )}

              <button type="submit" className="btn primary">
                ¡Contáctanos!
              </button>
              {submitted && (
                <p className="success-message" role="status">
                  Gracias por tu mensaje. Nos pondremos en contacto muy pronto.
                </p>
              )}
            </form>
          </div>
          <aside className="contact-info" aria-label="Datos de contacto de Coralindo Mariso">
            <div className="info-card">
              <h2>Visítanos</h2>
              <p>Av. Principal 123, Col. Centro</p>
              <p>Ciudad de México, CDMX, México</p>
            </div>
            <div className="info-card">
              <h2>Escríbenos</h2>
              <a href="mailto:hola@coralindomariso.site">hola@coralindomariso.site</a>
            </div>
            <div className="info-card">
              <h2>Llámamos</h2>
              <a href="tel:+525512345678">+52 55 1234 5678</a>
            </div>
            <div className="info-card">
              <h2>Horario</h2>
              <p>Lunes a viernes · 9:00 a 18:00 h (GMT-6)</p>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
};

export default Contact;