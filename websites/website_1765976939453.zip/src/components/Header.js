import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';

const navLinks = [
  { to: '/', label: 'Inicio' },
  { to: '/guide', label: 'Guía' },
  { to: '/programs', label: 'Programas' },
  { to: '/tools', label: 'Herramientas' },
  { to: '/blog', label: 'Blog' },
  { to: '/about', label: 'Sobre nosotros' },
  { to: '/contact', label: 'Contacto' }
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 960) {
        setIsMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className="site-header" role="banner">
      <div className="container header-container">
        <Link to="/" className="brand" aria-label="Coralindo Mariso inicio">
          <span className="brand-icon" aria-hidden="true">
            ●
          </span>
          <span className="brand-text">Coralindo Mariso</span>
        </Link>
        <button
          type="button"
          className="menu-toggle"
          onClick={() => setIsMenuOpen((prev) => !prev)}
          aria-expanded={isMenuOpen}
          aria-controls="primary-navigation"
          aria-label="Alternar menú principal"
        >
          <span />
          <span />
          <span />
        </button>
        <nav id="primary-navigation` className={`nav-links ${isMenuOpen ? 'open' : ''}`} aria-label=`Navegación principal">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;