import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('coralindoCookieConsent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('coralindoCookieConsent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>
        Utilizamos cookies para mejorar tu experiencia y ofrecerte contenido relevante. Al continuar, aceptas nuestro uso de cookies. Consulta
        la <Link to="/cookie-policy">política de cookies</Link>.
      </p>
      <button type="button" className="btn primary" onClick={handleAccept}>
        Aceptar
      </button>
    </div>
  );
};

export default CookieBanner;