import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => (
  <footer className="site-footer" role="contentinfo">
    <div className="container footer-grid">
      <div className="footer-column">
        <h3>Coralindo Mariso</h3>
        <p>
          Soluciones modernas para vivir y trabajar con serenidad. Acompañamos a profesionales y equipos en México a diseñar sistemas
          humanos, sostenibles y llenos de calma.
        </p>
      </div>
      <div className="footer-column">
        <h4>Explora</h4>
        <ul>
          <li>
            <Link to="/guide">Cómo trabajamos</Link>
          </li>
          <li>
            <Link to="/programs">Programas</Link>
          </li>
          <li>
            <Link to="/tools">Herramientas</Link>
          </li>
          <li>
            <Link to="/blog">Blog</Link>
          </li>
        </ul>
      </div>
      <div className="footer-column">
        <h4>Contacto</h4>
        <ul>
          <li>Av. Principal 123, Col. Centro</li>
          <li>Ciudad de México, CDMX, México</li>
          <li>
            <a href="tel:+525512345678">+52 55 1234 5678</a>
          </li>
          <li>
            <a href="mailto:hola@coralindomariso.site">hola@coralindomariso.site</a>
          </li>
        </ul>
      </div>
      <div className="footer-column">
        <h4>Legal & redes</h4>
        <ul>
          <li>
            <Link to="/terms">Términos de uso</Link>
          </li>
          <li>
            <Link to="/privacy">Aviso de privacidad</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookies</Link>
          </li>
        </ul>
        <div className="social-links">
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn Coralindo Mariso">
            <span aria-hidden="true">in</span>
          </a>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram Coralindo Mariso">
            <span aria-hidden="true">ig</span>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube Coralindo Mariso">
            <span aria-hidden="true">yt</span>
          </a>
        </div>
      </div>
    </div>
    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} Coralindo Mariso. Todos los derechos reservados.</p>
    </div>
  </footer>
);

export default Footer;