(function () {
  document.addEventListener("DOMContentLoaded", function () {
    const body = document.body;
    const header = document.querySelector("[data-header]");
    const nav = document.querySelector(".site-nav");
    const toggle = document.querySelector(".menu-toggle");
    const pageId = body.dataset.page;
    const navLinks = document.querySelectorAll(".site-nav a[data-page]");
    const cookieBanner = document.querySelector("[data-cookie-banner]");
    const contactForm = document.querySelector("[data-contact-form]");
    const formStatus = document.querySelector("[data-form-status]");
    const carCards = document.querySelectorAll("[data-car-card]");
    const carStatus = document.querySelector("[data-car-status]");
    const trackCards = document.querySelectorAll("[data-track-card]");
    const trackStatus = document.querySelector("[data-track-status]");
    const countables = document.querySelectorAll("[data-countup]");

    function highlightActiveNav() {
      if (!pageId) return;
      navLinks.forEach(function (link) {
        if (link.dataset.page === pageId) {
          link.classList.add("is-active");
        }
      });
    }

    function handleHeaderScroll() {
      if (!header) return;
      const scrollHandler = function () {
        if (window.scrollY > 12) {
          header.classList.add("is-scrolled");
        } else {
          header.classList.remove("is-scrolled");
        }
      };
      scrollHandler();
      window.addEventListener("scroll", scrollHandler, { passive: true });
    }

    function setupMenuToggle() {
      if (!toggle || !nav) return;
      toggle.addEventListener("click", function () {
        const isOpen = nav.classList.toggle("is-open");
        toggle.setAttribute("aria-expanded", String(isOpen));
      });

      navLinks.forEach(function (link) {
        link.addEventListener("click", function () {
          if (nav.classList.contains("is-open")) {
            nav.classList.remove("is-open");
            toggle.setAttribute("aria-expanded", "false");
          }
        });
      });
    }

    function handleCookieBanner() {
      if (!cookieBanner) return;
      const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
      const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
      const preference = localStorage.getItem("cookiePreference");

      function hideBanner(choice) {
        cookieBanner.setAttribute("hidden", "");
        cookieBanner.setAttribute("data-choice", choice);
      }

      if (!preference) {
        cookieBanner.removeAttribute("hidden");
      } else {
        hideBanner(preference);
      }

      if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
          localStorage.setItem("cookiePreference", "accepted");
          hideBanner("accepted");
        });
      }

      if (declineBtn) {
        declineBtn.addEventListener("click", function () {
          localStorage.setItem("cookiePreference", "declined");
          hideBanner("declined");
        });
      }
    }

    function parseStoredJSON(key) {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) return null;
        return JSON.parse(raw);
      } catch (error) {
        console.warn("Ошибка чтения", key, error);
        return null;
      }
    }

    function handleCarSelection() {
      if (!carCards.length) return;
      let stored = parseStoredJSON("selectedCar");

      function updateSelectionUI(selectedCard) {
        carCards.forEach(function (card) {
          if (card === selectedCard) {
            card.classList.add("is-selected");
          } else {
            card.classList.remove("is-selected");
          }
        });
      }

      function updateStatus(carData) {
        if (!carStatus) return;
        if (carData) {
          carStatus.innerHTML = "Выбран автомобиль: <span>" + carData.name + "</span>, макс. скорость: <span>" + carData.maxSpeed + " м/с</span>";
        } else {
          carStatus.textContent = "Выберите автомобиль, чтобы использовать его в игре.";
        }
      }

      if (stored) {
        const initialCard = Array.from(carCards).find(function (card) {
          return card.dataset.carId === stored.id;
        });
        if (initialCard) {
          updateSelectionUI(initialCard);
        }
        updateStatus(stored);
      } else {
        updateStatus(null);
      }

      carCards.forEach(function (card) {
        const button = card.querySelector("[data-car-select]");
        if (!button) return;

        button.addEventListener("click", function () {
          const carData = {
            id: card.dataset.carId,
            name: card.dataset.carName,
            color: card.dataset.carColor,
            maxSpeed: Number(card.dataset.carSpeed),
            acceleration: Number(card.dataset.carAccel)
          };
          localStorage.setItem("selectedCar", JSON.stringify(carData));
          updateSelectionUI(card);
          updateStatus(carData);
        });
      });
    }

    function handleTrackSelection() {
      if (!trackCards.length) return;
      let stored = parseStoredJSON("selectedTrack");

      function updateSelectionUI(selectedCard) {
        trackCards.forEach(function (card) {
          if (card === selectedCard) {
            card.classList.add("is-selected");
          } else {
            card.classList.remove("is-selected");
          }
        });
      }

      function updateStatus(info) {
        if (!trackStatus) return;
        if (info) {
          trackStatus.innerHTML = "Активная трасса: <span>" + info.name + "</span> — покрытие: <span>" + info.surface + "</span>";
        } else {
          trackStatus.textContent = "Выберите трассу, чтобы применить её в игре.";
        }
      }

      if (stored) {
        const initialCard = Array.from(trackCards).find(function (card) {
          return card.dataset.trackId === stored.id;
        });
        if (initialCard) {
          updateSelectionUI(initialCard);
        }
        updateStatus(stored);
      } else {
        updateStatus(null);
      }

      trackCards.forEach(function (card) {
        const button = card.querySelector("[data-track-select]");
        if (!button) return;

        button.addEventListener("click", function () {
          const trackData = {
            id: card.dataset.trackId,
            name: card.dataset.trackName,
            surface: card.dataset.trackSurface,
            theme: card.dataset.trackTheme
          };
          localStorage.setItem("selectedTrack", JSON.stringify(trackData));
          updateSelectionUI(card);
          updateStatus(trackData);
        });
      });
    }

    function handleContactForm() {
      if (!contactForm) return;
      contactForm.addEventListener("submit", function (event) {
        event.preventDefault();
        if (formStatus) {
          formStatus.textContent = "Спасибо! Ваше сообщение отправлено, команда поддержки ответит в течение 24 часов.";
        }
        contactForm.reset();
      });
    }

    function animateCounters() {
      if (!countables.length) return;

      const observer = new IntersectionObserver(function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            const el = entry.target;
            const target = Number(el.dataset.countup) || 0;
            const duration = Number(el.dataset.countupDuration) || 1200;
            const startTime = performance.now();

            function update(now) {
              const progress = Math.min((now - startTime) / duration, 1);
              const value = Math.floor(progress * target);
              el.textContent = value.toLocaleString("ru-RU");
              if (progress < 1) {
                requestAnimationFrame(update);
              } else {
                el.textContent = target.toLocaleString("ru-RU");
              }
            }

            requestAnimationFrame(update);
            obs.unobserve(el);
          }
        });
      }, { threshold: 0.35 });

      countables.forEach(function (el) {
        observer.observe(el);
      });
    }

    highlightActiveNav();
    handleHeaderScroll();
    setupMenuToggle();
    handleCookieBanner();
    handleCarSelection();
    handleTrackSelection();
    handleContactForm();
    animateCounters();
  });
})();