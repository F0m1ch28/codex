(function () {
  if (!document.body || document.body.dataset.page !== "game") {
    return;
  }

  const THREE_EXISTS = typeof THREE !== "undefined";
  if (!THREE_EXISTS) {
    console.error("Three.js не загружен");
    return;
  }

  const container = document.getElementById("game-stage");
  const hudSpeed = document.querySelector("[data-hud-speed]");
  const hudLap = document.querySelector("[data-hud-lap]");
  const hudTimer = document.querySelector("[data-hud-timer]");
  const hudBest = document.querySelector("[data-hud-best]");
  const hudScore = document.querySelector("[data-hud-score]");
  const hudTrack = document.querySelector("[data-hud-track]");
  const hudCar = document.querySelector("[data-hud-car]");
  const restartBtn = document.querySelector("[data-game-restart]");
  const mobileControls = document.querySelectorAll("[data-control]");

  let renderer, scene, camera;
  let resizeObserver;
  let car, carBody, carFrame;
  let trackMesh, barrierGroup;
  let checkpoints = [];
  let obstacles = [];
  let checkpointBoxes = [];
  let obstacleBoxes = [];
  let trackThemeConfig;
  let animationId;
  const clock = new THREE.Clock();

  const storedCar = loadStoredJSON("selectedCar") || {
    id: "default",
    name: "Apex Ghost",
    color: "#ff1245",
    maxSpeed: 58,
    acceleration: 38
  };

  const storedTrack = loadStoredJSON("selectedTrack") || {
    id: "neon-ring",
    name: "Неоновый ринг",
    surface: "карбон",
    theme: "neon"
  };

  const trackThemes = {
    neon: {
      floorColor: 0x0b101c,
      lineColor: 0x39ff14,
      barrierColor: 0xff1245,
      fogColor: 0x05070b,
      ambient: 0x334155,
      background: 0x020306
    },
    desert: {
      floorColor: 0x3b2b20,
      lineColor: 0xffc857,
      barrierColor: 0xff8f2f,
      fogColor: 0x25180d,
      ambient: 0x705439,
      background: 0x160f08
    },
    frost: {
      floorColor: 0x152332,
      lineColor: 0x6bdcff,
      barrierColor: 0x1e90ff,
      fogColor: 0x0b141d,
      ambient: 0x9ecbff,
      background: 0x03070c
    }
  };

  trackThemeConfig = trackThemes[storedTrack.theme] || trackThemes.neon;

  const state = {
    speed: 0,
    maxSpeed: storedCar.maxSpeed,
    acceleration: storedCar.acceleration,
    reverseLimit: 18,
    steering: 0,
    lap: 1,
    totalLaps: 3,
    nextCheckpoint: 0,
    score: 0,
    bestLap: null,
    lapStart: performance.now(),
    elapsed: 0,
    completed: false
  };

  const inputState = {
    forward: false,
    backward: false,
    left: false,
    right: false,
    brake: false
  };

  function loadStoredJSON(key) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      console.warn("Не удалось прочитать", key, error);
      return null;
    }
  }

  function initThree() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(trackThemeConfig.background);
    scene.fog = new THREE.Fog(trackThemeConfig.fogColor, 120, 350);

    camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 800);
    camera.position.set(0, 45, 70);
    camera.lookAt(0, 0, 0);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    container.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(trackThemeConfig.ambient, 0.6);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(60, 120, 60);
    dirLight.castShadow = true;
    scene.add(dirLight);

    const spotLight = new THREE.SpotLight(0xffffff, 1.25, 280, Math.PI / 6, 0.45, 1);
    spotLight.position.set(-40, 90, -40);
    spotLight.target.position.set(0, 0, 0);
    scene.add(spotLight);
    scene.add(spotLight.target);
  }

  function createTrack() {
    const trackGroup = new THREE.Group();

    const floorGeometry = new THREE.PlaneGeometry(260, 140, 32, 32);
    const floorMaterial = new THREE.MeshStandardMaterial({
      color: trackThemeConfig.floorColor,
      metalness: 0.1,
      roughness: 0.8
    });

    trackMesh = new THREE.Mesh(floorGeometry, floorMaterial);
    trackMesh.rotation.x = -Math.PI / 2;
    trackMesh.receiveShadow = true;
    trackGroup.add(trackMesh);

    const innerTrackGeometry = new THREE.RingGeometry(35, 45, 64);
    const innerTrackMaterial = new THREE.MeshBasicMaterial({
      color: trackThemeConfig.lineColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.35
    });
    const innerRing = new THREE.Mesh(innerTrackGeometry, innerTrackMaterial);
    innerRing.rotation.x = -Math.PI / 2;
    innerRing.position.set(0, 0.02, 0);
    trackGroup.add(innerRing);

    const outerTrackGeometry = new THREE.RingGeometry(65, 75, 80);
    const outerTrackMaterial = new THREE.MeshBasicMaterial({
      color: trackThemeConfig.lineColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.25
    });
    const outerRing = new THREE.Mesh(outerTrackGeometry, outerTrackMaterial);
    outerRing.rotation.x = -Math.PI / 2;
    outerRing.position.set(0, 0.02, 0);
    trackGroup.add(outerRing);

    barrierGroup = new THREE.Group();
    const barrierMaterial = new THREE.MeshStandardMaterial({
      color: trackThemeConfig.barrierColor,
      metalness: 0.25,
      emissive: trackThemeConfig.barrierColor,
      emissiveIntensity: 0.2
    });

    const barrierPositions = [
      { x: 0, z: -60, scaleX: 80 },
      { x: 0, z: 60, scaleX: 80 },
      { x: -120, z: 0, scaleZ: 120 },
      { x: 120, z: 0, scaleZ: 120 }
    ];

    barrierPositions.forEach(function (pos) {
      const geometry = new THREE.BoxGeometry(pos.scaleX || 18, 8, pos.scaleZ || 18);
      const barrier = new THREE.Mesh(geometry, barrierMaterial);
      barrier.position.set(pos.x, 4, pos.z);
      barrier.castShadow = true;
      barrier.receiveShadow = true;
      barrierGroup.add(barrier);
    });

    trackGroup.add(barrierGroup);

    scene.add(trackGroup);
  }

  function createCheckpoints() {
    const positions = [
      new THREE.Vector3(0, 4, -40),
      new THREE.Vector3(40, 4, 0),
      new THREE.Vector3(0, 4, 40),
      new THREE.Vector3(-40, 4, 0)
    ];

    const gateGeometry = new THREE.BoxGeometry(12, 10, 4);
    const gateMaterial = new THREE.MeshStandardMaterial({
      color: trackThemeConfig.lineColor,
      transparent: true,
      opacity: 0.18,
      emissive: trackThemeConfig.lineColor,
      emissiveIntensity: 0.3
    });

    checkpoints = positions.map(function (pos) {
      const gate = new THREE.Mesh(gateGeometry, gateMaterial);
      gate.position.copy(pos);
      gate.rotation.y = Math.atan2(pos.x, pos.z);
      scene.add(gate);
      return gate;
    });

    checkpointBoxes = checkpoints.map(function (gate) {
      const box = new THREE.Box3().setFromObject(gate);
      return box;
    });
  }

  function createObstacles() {
    obstacles = [];
    obstacleBoxes = [];
    const obstacleGeometry = new THREE.CylinderGeometry(0, 3, 10, 6, 1);
    const obstacleMaterial = new THREE.MeshStandardMaterial({
      color: 0x202637,
      metalness: 0.45,
      roughness: 0.35
    });

    const positions = [
      new THREE.Vector3(-25, 5, -15),
      new THREE.Vector3(30, 5, 10),
      new THREE.Vector3(10, 5, 30),
      new THREE.Vector3(-35, 5, 20)
    ];

    positions.forEach(function (pos) {
      const obstacle = new THREE.Mesh(obstacleGeometry, obstacleMaterial);
      obstacle.position.copy(pos);
      obstacle.castShadow = true;
      obstacle.receiveShadow = true;
      obstacle.rotation.y = Math.random() * Math.PI;
      scene.add(obstacle);
      obstacles.push(obstacle);
      obstacleBoxes.push(new THREE.Box3().setFromObject(obstacle));
    });
  }

  function createCar() {
    const carGroup = new THREE.Group();

    const bodyGeometry = new THREE.BoxGeometry(6, 1.6, 10);
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(storedCar.color),
      metalness: 0.55,
      roughness: 0.25
    });
    carBody = new THREE.Mesh(bodyGeometry, bodyMaterial);
    carBody.position.y = 1.2;
    carBody.castShadow = true;
    carBody.receiveShadow = true;
    carGroup.add(carBody);

    const frameGeometry = new THREE.BoxGeometry(6.5, 0.2, 10.8);
    const frameMaterial = new THREE.MeshStandardMaterial({
      color: 0x1b1f2e,
      metalness: 0.3,
      roughness: 0.8
    });
    carFrame = new THREE.Mesh(frameGeometry, frameMaterial);
    carFrame.position.y = 0.5;
    carFrame.castShadow = true;
    carFrame.receiveShadow = true;
    carGroup.add(carFrame);

    const cabinGeometry = new THREE.BoxGeometry(3.5, 1.1, 3.6);
    const cabinMaterial = new THREE.MeshStandardMaterial({
      color: 0x10131f,
      metalness: 0.15,
      roughness: 0.4,
      emissive: 0x111122,
      emissiveIntensity: 0.3
    });
    const cabin = new THREE.Mesh(cabinGeometry, cabinMaterial);
    cabin.position.set(0, 1.9, -1.2);
    carGroup.add(cabin);

    const wheelGeometry = new THREE.CylinderGeometry(1.1, 1.1, 2.2, 16);
    const wheelMaterial = new THREE.MeshStandardMaterial({
      color: 0x0f1118,
      metalness: 0.2,
      roughness: 0.6
    });

    const wheelPositions = [
      [-2.2, 0.7, -3.4],
      [2.2, 0.7, -3.4],
      [-2.2, 0.7, 3.4],
      [2.2, 0.7, 3.4]
    ];

    wheelPositions.forEach(function (pos) {
      const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(pos[0], pos[1], pos[2]);
      wheel.castShadow = true;
      wheel.receiveShadow = true;
      carGroup.add(wheel);
    });

    carGroup.position.set(0, 0, 45);
    carGroup.rotation.y = Math.PI;
    scene.add(carGroup);
    car = carGroup;
  }

  function setupResizeHandler() {
    resizeObserver = new ResizeObserver(function () {
      if (!renderer || !camera) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      renderer.setSize(width, height);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    });
    resizeObserver.observe(container);
  }

  function setupControls() {
    function setKeyState(code, value) {
      switch (code) {
        case "ArrowUp":
        case "KeyW":
          inputState.forward = value;
          break;
        case "ArrowDown":
        case "KeyS":
          inputState.backward = value;
          break;
        case "ArrowLeft":
        case "KeyA":
          inputState.left = value;
          break;
        case "ArrowRight":
        case "KeyD":
          inputState.right = value;
          break;
        case "Space":
          inputState.brake = value;
          break;
        default:
          break;
      }
    }

    window.addEventListener("keydown", function (event) {
      setKeyState(event.code, true);
      if (event.code === "KeyR") {
        resetRace(true);
      }
    });

    window.addEventListener("keyup", function (event) {
      setKeyState(event.code, false);
    });

    mobileControls.forEach(function (btn) {
      const dir = btn.dataset.control;
      function setMobile(value) {
        switch (dir) {
          case "forward":
            inputState.forward = value;
            break;
          case "backward":
            inputState.backward = value;
            break;
          case "left":
            inputState.left = value;
            break;
          case "right":
            inputState.right = value;
            break;
          case "brake":
            inputState.brake = value;
            break;
          default:
            break;
        }
      }
      btn.addEventListener("pointerdown", function (event) {
        event.preventDefault();
        setMobile(true);
        btn.classList.add("is-active");
      });
      btn.addEventListener("pointerup", function (event) {
        event.preventDefault();
        setMobile(false);
        btn.classList.remove("is-active");
      });
      btn.addEventListener("pointerleave", function () {
        setMobile(false);
        btn.classList.remove("is-active");
      });
    });

    if (restartBtn) {
      restartBtn.addEventListener("click", function () {
        resetRace(true);
      });
    }
  }

  function resetRace(fullReset) {
    state.speed = 0;
    state.steering = 0;
    state.lap = 1;
    state.nextCheckpoint = 0;
    state.score = 0;
    state.elapsed = 0;
    state.completed = false;
    state.lapStart = performance.now();
    if (fullReset && state.totalLaps) {
      state.bestLap = null;
    }
    car.position.set(0, 0, 45);
    car.rotation.y = Math.PI;
    updateHUD();
  }

  function updateHUD() {
    if (hudSpeed) {
      const speedKmh = Math.abs(state.speed) * 2.8;
      hudSpeed.textContent = speedKmh.toFixed(0) + " км/ч";
    }
    if (hudLap) {
      hudLap.textContent = state.lap + " / " + state.totalLaps;
    }
    if (hudTimer) {
      const elapsedSeconds = state.elapsed / 1000;
      hudTimer.textContent = elapsedSeconds.toFixed(2) + " c";
    }
    if (hudBest) {
      if (state.bestLap) {
        hudBest.textContent = (state.bestLap / 1000).toFixed(2) + " c";
      } else {
        hudBest.textContent = "—";
      }
    }
    if (hudScore) {
      hudScore.textContent = state.score.toLocaleString("ru-RU");
    }
    if (hudTrack) {
      hudTrack.textContent = storedTrack.name + " · " + storedTrack.surface;
    }
    if (hudCar) {
      hudCar.textContent = storedCar.name;
    }
  }

  function computeControls(delta) {
    const accelerationPower = inputState.forward ? state.acceleration : inputState.backward ? -state.acceleration * 0.7 : 0;
    const brakeFactor = inputState.brake ? 1.8 : 1;
    const friction = inputState.forward || inputState.backward ? 12 : 18 * brakeFactor;
    const maxSpeed = state.maxSpeed;
    const reverseLimit = state.reverseLimit;

    state.speed += accelerationPower * delta;
    state.speed -= Math.sign(state.speed) * friction * delta;
    state.speed = THREE.MathUtils.clamp(state.speed, -reverseLimit, maxSpeed);

    if (Math.abs(state.speed) < 0.05) {
      state.speed = 0;
    }

    let steeringInput = 0;
    if (inputState.left) steeringInput -= 1;
    if (inputState.right) steeringInput += 1;

    const effectiveTurn = steeringInput * 2.1 * delta * (Math.abs(state.speed) / maxSpeed + 0.2);
    car.rotation.y -= effectiveTurn;
  }

  function updatePosition(delta) {
    const forwardVector = new THREE.Vector3(0, 0, -1).applyQuaternion(car.quaternion);
    car.position.addScaledVector(forwardVector, state.speed * delta);

    car.position.x = THREE.MathUtils.clamp(car.position.x, -110, 110);
    car.position.z = THREE.MathUtils.clamp(car.position.z, -60, 60);

    camera.position.lerp(new THREE.Vector3(car.position.x, car.position.y + 35, car.position.z + 55), 0.05);
    camera.lookAt(car.position.x, car.position.y + 4, car.position.z);
  }

  function checkCollisions() {
    const carBox = new THREE.Box3().setFromObject(car);

    obstacles.forEach(function (obstacle, index) {
      const obstacleBox = obstacleBoxes[index];
      obstacleBox.copy(new THREE.Box3().setFromObject(obstacle));
      if (carBox.intersectsBox(obstacleBox)) {
        state.speed *= -0.35;
        state.score = Math.max(0, state.score - 35);
      }
    });

    const outerLimit = 80;
    if (Math.abs(car.position.x) > outerLimit || Math.abs(car.position.z) > outerLimit) {
      state.speed *= 0.65;
    }
  }

  function checkCheckpoints() {
    const carBox = new THREE.Box3().setFromObject(carBody);
    checkpointBoxes.forEach(function (box, index) {
      box.copy(new THREE.Box3().setFromObject(checkpoints[index]));
    });

    const targetIndex = state.nextCheckpoint % checkpoints.length;
    const targetBox = checkpointBoxes[targetIndex];

    if (targetBox && carBox.intersectsBox(targetBox)) {
      state.nextCheckpoint += 1;
      state.score += 120;

      if (state.nextCheckpoint % checkpoints.length === 0) {
        const now = performance.now();
        const lapTime = now - state.lapStart;
        state.lapStart = now;
        state.elapsed = 0;
        if (!state.bestLap || lapTime < state.bestLap) {
          state.bestLap = lapTime;
        }
        state.lap += 1;
        if (state.lap > state.totalLaps) {
          state.completed = true;
          state.speed = 0;
        }
      }
    }
  }

  function updateTimer() {
    if (!state.completed) {
      state.elapsed = performance.now() - state.lapStart;
    }
  }

  function renderLoop() {
    const delta = clock.getDelta();
    computeControls(delta);
    updatePosition(delta);
    checkCollisions();
    checkCheckpoints();
    updateTimer();
    updateHUD();

    renderer.render(scene, camera);
    animationId = requestAnimationFrame(renderLoop);
  }

  function start() {
    initThree();
    createTrack();
    createCheckpoints();
    createObstacles();
    createCar();
    setupResizeHandler();
    setupControls();
    resetRace(false);
    updateHUD();
    renderLoop();
  }

  start();

  window.addEventListener("beforeunload", function () {
    if (resizeObserver) {
      resizeObserver.disconnect();
    }
    if (animationId) {
      cancelAnimationFrame(animationId);
    }
    if (renderer) {
      renderer.dispose();
    }
  });
})();