# LumenFlow Studio Website

A multi-page marketing website for the fictional LumenFlow Studio, showcasing digital product design and engineering services.

## Features
- Responsive layout with semantic HTML and reusable CSS utility classes.
- Adaptive images served via `<picture>` with real Pexels photography (unique IDs per image).
- Persistent navigation, CTA, and consistent branding across Home, About, Services, Contact, Policy, Terms, and FAQ pages.
- Accessible components including keyboard-navigable menus, descriptive alt text, and focus states.
- Cookie consent banner with “Accept”, “Reject”, and “Customize” options backed by `localStorage`.
- Privacy Policy, Terms of Service, and FAQ pages to support compliance and transparency.
- Supplemental files for deployability: sitemap, robots, manifest, favicon placeholder, JSON data, SVG asset, and .gitignore.

## Structure
- `index.html` plus supporting pages in project root.
- `styles.css` contains global styles, layout utilities, and cookies banner modifiers.
- `script.js` manages navigation toggling and cookie preference storage.
- `assets/hero-shape.svg` decorative background element.
- `assets/data/testimonials.json` stores testimonial content for reference or future integration.
- `assets/icon-192.png` and `assets/icon-512.png` placeholders for PWA icons (replace in production).

## Usage
1. Replace favicon and manifest icons with production-ready assets.
2. Update company details (emails, addresses, phone numbers) as needed.
3. Serve files through any static hosting provider. Ensure HTTPS for best UX.
4. Integrate analytics or marketing scripts conditionally based on stored cookie preferences.

## Development Notes
- No build tooling required; vanilla HTML, CSS, and JS stack.
- Customize brand colors or typography via CSS variables in `styles.css`.
- Extend components or add new sections by leveraging existing layout classes.

## License
This project is provided as-is for demonstration purposes. Replace placeholder content before use in production.