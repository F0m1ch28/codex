const menuToggle = document.querySelector('[data-js="menu-toggle"]');
const primaryNav = document.querySelector('[data-js="primary-nav"]');
const cookiesBanner = document.querySelector('[data-js="cookies-banner"]');
const cookiesModal = document.querySelector('[data-js="cookies-modal"]');
const acceptCookiesBtn = document.querySelector('[data-js="accept-cookies"]');
const rejectCookiesBtn = document.querySelector('[data-js="reject-cookies"]');
const customizeCookiesBtn = document.querySelector('[data-js="customize-cookies"]');
const closeCustomizeButtons = document.querySelectorAll('[data-js="close-customize"]');
const savePreferencesBtn = document.querySelector('[data-js="save-preferences"]');
const preferenceInputs = document.querySelectorAll('[data-js="preference-input"]');
const cookiesForm = document.querySelector('[data-js="cookies-form"]');

if (menuToggle && primaryNav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = primaryNav.classList.toggle('is-open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });

  primaryNav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      if (window.innerWidth <= 820 && primaryNav.classList.contains('is-open')) {
        primaryNav.classList.remove('is-open');
        menuToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 820 && primaryNav.classList.contains('is-open')) {
      primaryNav.classList.remove('is-open');
      menuToggle.setAttribute('aria-expanded', 'false');
    }
  });
}

function getStoredPreferences() {
  const stored = localStorage.getItem('cookiePreferences');
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch (error) {
    console.error('Failed to parse cookie preferences', error);
    return null;
  }
}

function setPreferences(preferences) {
  localStorage.setItem('cookiePreferences', JSON.stringify(preferences));
}

function applyPreferencesToUI(preferences) {
  if (!preferences) {
    preferenceInputs.forEach((input) => {
      input.checked = false;
    });
    return;
  }
  preferenceInputs.forEach((input) => {
    input.checked = Boolean(preferences[input.value]);
  });
}

function showBanner() {
  if (cookiesBanner) {
    cookiesBanner.classList.add('is-visible');
  }
}

function hideBanner() {
  if (cookiesBanner) {
    cookiesBanner.classList.remove('is-visible');
  }
}

function openModal() {
  if (!cookiesModal) return;
  applyPreferencesToUI(getStoredPreferences());
  cookiesModal.classList.add('is-open');
  cookiesModal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');
}

function closeModal() {
  if (!cookiesModal) return;
  cookiesModal.classList.remove('is-open');
  cookiesModal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-open');
}

if (cookiesBanner) {
  const storedPreferences = getStoredPreferences();
  if (!storedPreferences) {
    showBanner();
  } else {
    applyPreferencesToUI(storedPreferences);
    hideBanner();
  }

  acceptCookiesBtn?.addEventListener('click', () => {
    setPreferences({ essential: true, analytics: true, marketing: true });
    hideBanner();
    closeModal();
  });

  rejectCookiesBtn?.addEventListener('click', () => {
    setPreferences({ essential: true, analytics: false, marketing: false });
    hideBanner();
    closeModal();
  });

  customizeCookiesBtn?.addEventListener('click', () => {
    openModal();
  });

  closeCustomizeButtons.forEach((button) => {
    button.addEventListener('click', () => {
      closeModal();
      if (!getStoredPreferences()) {
        showBanner();
      }
    });
  });

  savePreferencesBtn?.addEventListener('click', () => {
    const preferences = { essential: true };
    preferenceInputs.forEach((input) => {
      preferences[input.value] = input.checked;
    });
    setPreferences(preferences);
    hideBanner();
    closeModal();
  });

  cookiesModal?.addEventListener('click', (event) => {
    if (event.target === cookiesModal) {
      closeModal();
      if (!getStoredPreferences()) {
        showBanner();
      }
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && cookiesModal?.classList.contains('is-open')) {
      closeModal();
      if (!getStoredPreferences()) {
        showBanner();
      }
    }
  });
}