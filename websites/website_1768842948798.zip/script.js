(function () {
  document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.getElementById('primary-nav');

    if (navToggle && siteNav) {
      navToggle.addEventListener('click', function () {
        const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!isExpanded));
        navToggle.classList.toggle('is-open');
        siteNav.classList.toggle('is-open');
      });

      siteNav.querySelectorAll('a').forEach(function (link) {
        link.addEventListener('click', function () {
          navToggle.setAttribute('aria-expanded', 'false');
          navToggle.classList.remove('is-open');
          siteNav.classList.remove('is-open');
        });
      });
    }

    const banner = document.getElementById('cookie-banner');
    if (banner) {
      const stored = localStorage.getItem('eliteTattooCookieConsent');
      if (stored) {
        banner.classList.add('hide');
      }
      banner.querySelectorAll('button[data-action]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          localStorage.setItem('eliteTattooCookieConsent', btn.dataset.action);
          banner.classList.add('hide');
        });
      });
    }
  });
})();