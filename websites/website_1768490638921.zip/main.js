document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    const declineCookies = document.getElementById('declineCookies');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
            });
        });
    }

    if (cookieBanner && acceptCookies && declineCookies) {
        const cookiePreference = localStorage.getItem('genusCookiePreference');
        if (!cookiePreference) {
            cookieBanner.classList.add('active');
        }

        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('genusCookiePreference', 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineCookies.addEventListener('click', () => {
            localStorage.setItem('genusCookiePreference', 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});