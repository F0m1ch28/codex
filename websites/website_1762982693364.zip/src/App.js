import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

const App = () => {
  return (
    <>
      <Helmet>
        <title>Пиццерия в Киеве | Настоящая итальянская пицца в сердце города</title>
        <meta
          name="description"
          content="Печь на дровах, доставка по Киеву и любимые итальянские рецепты. Пиццерия в Киеве ждет вас на Крещатике, 25."
        />
        <meta name="keywords" content="пицца, доставка пиццы Киев, итальянская кухня, ресторан, еда на вынос" />
      </Helmet>
      <a className="skip-link" href="#main-content">
        Перейти к основному содержанию
      </a>
      <div className="app">
        <Header />
        <main id="main-content" tabIndex="-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services view="services" />} />
            <Route path="/menu" element={<Services view="menu" />} />
            <Route path="/delivery" element={<Services view="delivery" />} />
            <Route path="/contacts" element={<Contact />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/terms" element={<Terms variant="terms" />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookie-policy" element={<Terms variant="cookie" />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTopButton />
      </div>
    </>
  );
};

export default App;