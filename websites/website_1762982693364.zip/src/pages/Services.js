import React, { useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = ({ view: viewProp }) => {
  const location = useLocation();
  const currentView = viewProp || (location.pathname === '/menu' ? 'menu' : location.pathname === '/delivery' ? 'delivery' : 'services');

  const tabs = [
    { key: 'services', label: 'Послуги' },
    { key: 'menu', label: 'Меню' },
    { key: 'delivery', label: 'Доставка' },
  ];

  const menuCategories = ['Класичні', 'Авторські', 'Вегетаріанські', 'Фокус сезону'];
  const menuItems = useMemo(
    () => [
      {
        category: 'Класичні',
        title: 'Маринара Подільська',
        description:
          'Соус на помідорах Сан Марцано, запашний часник і сушений орегано — класика у виконанні нашого піцайоло.',
        image: 'https://picsum.photos/seed/services-menu1/640/480',
      },
      {
        category: 'Авторські',
        title: 'Чотири острови',
        description:
          'Поєднання копченого вугра, вершкового соусу, листя шисо та кунжуту. Натхнення — Київ та японські гастрономічні історії.',
        image: 'https://picsum.photos/seed/services-menu2/640/480',
      },
      {
        category: 'Вегетаріанські',
        title: 'Сад на Софійській',
        description:
          'Фета, томати конфі, м’ята і карамелізовані горіхи. Легка, але поживна піца для обіду.',
        image: 'https://picsum.photos/seed/services-menu3/640/480',
      },
      {
        category: 'Фокус сезону',
        title: 'Весняна асиметрія',
        description:
          'Топінг з асиметричним викладенням — половина з молодою капустою, половина з печеним буряком та діжонською гірчицею.',
        image: 'https://picsum.photos/seed/services-menu4/640/480',
      },
    ],
    []
  );

  const deliverySteps = [
    {
      title: 'Замовлення',
      description: 'Приймаємо заявки на сайті, телефоном або у Telegram. Оператор уточнює деталі та бажані топінги.',
    },
    {
      title: 'Підготовка',
      description:
        'Кухня одразу запускає тісто. Кожна піца проходить контроль температури перед пакуванням у вентиляційні коробки.',
    },
    {
      title: 'Доставка',
      description:
        'Кур’єри працюють у дві зміни, мають термосумки з контролем вологості. У мобільному додатку бачите маршрут у реальному часі.',
    },
    {
      title: 'Післясмак',
      description:
        'Ми пишемо повідомлення з рекомендаціями, як розігріти залишки та що спробувати наступного разу.',
    },
  ];

  const cateringOptions = [
    {
      title: 'Кейтеринг із печі на колесах',
      description:
        'Привозимо мобільну піч, фермерські інгредієнти та команду. Готуємо піцу наживо на подіях до 200 гостей.',
      icon: '🚚',
    },
    {
      title: 'Піца-бар для офісу',
      description:
        'Створюємо тематичні станції, де гості самі обирають топінги. Є варіанти для ранкових зустрічей та afterparty.',
      icon: '🏢',
    },
    {
      title: 'Майстер-класи та тімбілдінг',
      description:
        'Проводимо інтерактивні заняття під керівництвом шефа. Кожен гість готує власну піцу та отримує сертифікат.',
      icon: '🎉',
    },
  ];

  const [activeMenuCategory, setActiveMenuCategory] = useState('Класичні');

  return (
    <>
      <Helmet>
        <title>
          {currentView === 'menu'
            ? 'Меню пиццерии | Піч на Крещатику'
            : currentView === 'delivery'
            ? 'Доставка піци у Києві | Умови та сервіс'
            : 'Послуги пиццерии | Меню, доставка, кейтеринг'}
        </title>
        <meta
          name="description"
          content="Меню, доставка та кейтеринг від Пиццерии в Киеве: мобільна піч, авторські піци, сервіс 24/7."
        />
      </Helmet>
      <div className={styles.page}>
        <header className={styles.hero}>
          <div className={styles.heroContent}>
            <span className={styles.heroBadge}>Піч, що подорожує з вами</span>
            <h1>
              {currentView === 'menu'
                ? 'Меню, що відображає настрій Києва'
                : currentView === 'delivery'
                ? 'Доставка, яка дбає про температуру та час'
                : 'Послуги пиццерии в Киеве'}
            </h1>
            <p>
              Ми працюємо з однією метою — щоб піца приїхала до вас такою, ніби ви щойно вийшли з нашої тераси. Тому
              продумали і меню, і сервіс, і мобільну піч для заходів.
            </p>
          </div>
          <div className={styles.heroImage}>
            <img
              src={
                currentView === 'delivery'
                  ? 'https://picsum.photos/800/600?random=303'
                  : 'https://picsum.photos/800/600?random=302'
              }
              alt="Процес приготування піци у пиццерии"
              loading="lazy"
            />
          </div>
        </header>

        <nav className={styles.tabs} aria-label="Навігація по послугам">
          {tabs.map((tab) => (
            <a
              key={tab.key}
              href={tab.key === 'services' ? '/services' : `/${tab.key}`}
              className={`${styles.tab} ${currentView === tab.key ? styles.tabActive : ''}`}
            >
              {tab.label}
            </a>
          ))}
        </nav>

        {(currentView === 'services' || currentView === 'menu') && (
          <section className={styles.menuPreview} aria-labelledby="menu-heading">
            <div className={styles.menuHeader}>
              <h2 id="menu-heading">Короткий гід по меню</h2>
              <p>
                Піци поділили на чотири групи, щоб ви могли легко знайти улюблений смак. У кожній категорії — сезонні
                оновлення та авторські соуси.
              </p>
            </div>
            <div className={styles.menuCategories} role="tablist" aria-label="Категорії піци">
              {menuCategories.map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`${styles.menuCategory} ${
                    activeMenuCategory === category ? styles.menuCategoryActive : ''
                  }`}
                  onClick={() => setActiveMenuCategory(category)}
                  aria-pressed={activeMenuCategory === category}
                >
                  {category}
                </button>
              ))}
            </div>
            <div className={styles.menuGrid}>
              {menuItems
                .filter((item) => item.category === activeMenuCategory)
                .map((item) => (
                  <article key={item.title} className={styles.menuCard}>
                    <img src={item.image} alt={item.title} loading="lazy" />
                    <div>
                      <h3>{item.title}</h3>
                      <p>{item.description}</p>
                    </div>
                  </article>
                ))}
            </div>
          </section>
        )}

        {(currentView === 'services' || currentView === 'delivery') && (
          <section className={styles.delivery} aria-labelledby="delivery-heading">
            <div className={styles.deliveryIntro}>
              <h2 id="delivery-heading">Як працює наша доставка</h2>
              <p>
                Ми контролюємо температуру на всьому шляху: від печі до вашої двері. Кожна коробка має вентиляційний
                малюнок, що дозволяє коржу залишатися хрустким.
              </p>
              <ul>
                <li>Центр, Поділ, Печерськ і Липки — зона до 45 хвилин.</li>
                <li>Передмістя: погоджуємо час індивідуально.</li>
                <li>Безконтактна оплата та передплата доступні 24/7.</li>
              </ul>
            </div>
            <div className={styles.deliverySteps}>
              {deliverySteps.map((step) => (
                <article key={step.title}>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </article>
              ))}
            </div>
          </section>
        )}

        {currentView === 'services' && (
          <section className={styles.catering} aria-labelledby="catering-heading">
            <h2 id="catering-heading">Кейтеринг і події</h2>
            <div className={styles.cateringGrid}>
              {cateringOptions.map((option) => (
                <article key={option.title}>
                  <span aria-hidden="true">{option.icon}</span>
                  <h3>{option.title}</h3>
                  <p>{option.description}</p>
                </article>
              ))}
            </div>
            <div className={styles.cateringNotice}>
              <p>
                Плануєте івент? Напишіть нам на <a href="mailto:info@pizzeria-kiev.ua">info@pizzeria-kiev.ua</a> або
                зателефонуйте <a href="tel:+380441234567">+380 (44) 123-45-67</a> — підберемо сет та декор під вашу подію.
              </p>
            </div>
          </section>
        )}

        <section className={styles.faq} aria-labelledby="faq-heading">
          <h2 id="faq-heading">Популярні запитання</h2>
          <div className={styles.faqGrid}>
            <article>
              <h3>Чи можна замовити піцу наперед?</h3>
              <p>Так, ми приймаємо передзамовлення за 24 години. Особливо зручно для великих компаній та офісів.</p>
            </article>
            <article>
              <h3>Які методи оплати?</h3>
              <p>Готівка, банківські картки, Apple Pay, Google Pay, безготівковий рахунок для компаній.</p>
            </article>
            <article>
              <h3>Чи є ланч-пропозиції?</h3>
              <p>З понеділка по п’ятницю до 15:00 діє ланч-комбо з супом дня та напоєм. Без черг при самовивозі.</p>
            </article>
          </div>
        </section>
      </div>
    </>
  );
};

export default Services;