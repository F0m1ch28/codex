import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => {
  const milestones = [
    {
      year: '2014',
      title: 'Відновили історичну піч',
      description:
        'На місці старого кавового будиночка знайшли димохід XVIII століття. Відновили його з керамічниками з Подолу.',
    },
    {
      year: '2017',
      title: 'Запустили перші майстер-класи',
      description:
        'Навчили понад тисячу киян готувати піцу вдома. Досі проводимо уроки для дітей та сімей.',
    },
    {
      year: '2020',
      title: 'Доставка з live-трансляцією',
      description:
        'Під час локдауну зробили прямі включення з кухні, щоб гості бачили, як народжується їхня піца.',
    },
    {
      year: '2023',
      title: 'Перемога у Kyiv Food Awards',
      description:
        'Стали найкращою пиццерією міста за версією Kyiv Food Awards. Взяли нагороду за «Сервіс року».',
    },
  ];

  const values = [
    {
      title: 'Локальні продукти',
      description:
        'Ми співпрацюємо з 12 фермерськими господарствами Київщини. Сир, борошно, овочі — з перевірених родинних ферм.',
    },
    {
      title: 'Сталий підхід',
      description:
        'Використовуємо компостовані коробки та повторно застосовуємо тепло печі для приготування домашніх заквасок.',
    },
    {
      title: 'Сімейний сервіс',
      description:
        'Кожного гостя зустрічаємо на ім’я. Пам’ятаємо улюблені смаки постійних відвідувачів і даруємо додаткові топінги на свята.',
    },
  ];

  const people = [
    {
      name: 'Дарина Мельник',
      role: 'Шеф-кухарка',
      bio: 'Стежить за кожною партією тіста, збирає колекцію оливкових олій і створює сезонні ліміти.',
      image: 'https://picsum.photos/seed/about1/480/480',
    },
    {
      name: 'Марко Сидоренко',
      role: 'Головний піцайоло',
      bio: 'Керує нічною ферментацією та готує спеціальні бортики, наповнені сиром, для дітей.',
      image: 'https://picsum.photos/seed/about2/480/480',
    },
    {
      name: 'Оля Романюк',
      role: 'Менеджер сервісу',
      bio: 'Організовує команду залу, тренує на empathy-марафонах і відповідає за теплі листи гостям.',
      image: 'https://picsum.photos/seed/about3/480/480',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Про пиццерию | Історія, команда, філософія</title>
        <meta
          name="description"
          content="Дізнайтесь історію Пиццерии в Киеве: від відновлення старої печі до щоденної роботи з локальними фермерськими продуктами."
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.intro}>
          <div className={styles.introText}>
            <h1>Київська історія, яку печемо кожного дня</h1>
            <p>
              Пиццерия в Киеве народилася з бажання поєднати контрасти: дерев’яні балки старої будівлі, сучасну кухню,
              ритм Хрещатика та спокій Подолу. Ми відтворили атмосферу домівки, куди заходиш за теплом і залишається
              довше, ніж планував.
            </p>
            <p>
              Кожен наш ранок починається з кави на терасі і зустрічі фермерів. Ми знаємо по імені людей, які виростили
              наші томати чи привезли козячий сир. Це дозволяє слідкувати за якістю — і дарувати вам довіру в кожному
              шматочку піци.
            </p>
          </div>
          <div className={styles.introImage}>
            <img src="https://picsum.photos/800/600?random=202" alt="Команда пиццерии біля печі" loading="lazy" />
          </div>
        </section>

        <section className={styles.values} aria-labelledby="values-heading">
          <h2 id="values-heading">Наші цінності</h2>
          <div className={styles.valueGrid}>
            {values.map((value) => (
              <article key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.milestones} aria-labelledby="milestones-heading">
          <h2 id="milestones-heading">З чого ми починали і куди рухаємось</h2>
          <div className={styles.timeline}>
            {milestones.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <span>{item.year}</span>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className={styles.team} aria-labelledby="team-heading">
          <h2 id="team-heading">Познайомтесь ближче</h2>
          <div className={styles.teamGrid}>
            {people.map((person) => (
              <article key={person.name} className={styles.teamCard}>
                <img src={person.image} alt={`${person.name}, ${person.role}`} loading="lazy" />
                <div className={styles.teamBody}>
                  <h3>{person.name}</h3>
                  <span>{person.role}</span>
                  <p>{person.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.story} aria-labelledby="story-heading">
          <div>
            <h2 id="story-heading">Чому гості повертаються</h2>
            <p>
              Ми зберігаємо ритуали. Кожного четверга влаштовуємо «вечори відкритої кухні»: відвідувачі можуть спробувати
              самостійно розкрутити тісто, поставити запитання шефу, створити власну комбінацію. У неділю влаштовуємо
              маленький фермерський ринок з постачальниками.
            </p>
            <p>
              Для нас важливо, щоб кожна людина відчувала себе частиною нашої історії — чи то гості з дітьми, чи компанії
              підприємців після роботи. Саме тому ми придумали «лист із печі»: після відвідування ви отримуєте маленьке
              повідомлення з подякою і рекомендаціями наступних смаків.
            </p>
          </div>
          <div className={styles.storyImage}>
            <img src="https://picsum.photos/800/600?random=207" alt="Інтер’єр пиццерии в Києві" loading="lazy" />
          </div>
        </section>

        <section id="blog" className={styles.blog} aria-labelledby="blog-heading">
          <h2 id="blog-heading">Що зараз відбувається у печі</h2>
          <div className={styles.blogGrid}>
            <article>
              <h3>Весняний сет «Зелена хвиля»</h3>
              <p>
                Запустили зелений сет із сиром страчателла, молодим горошком і лимонною мікрозелінню. Доступний лише у квітні.
              </p>
            </article>
            <article>
              <h3>Майстер-клас для дітей до Великодня</h3>
              <p>
                Разом з дитячим простором на Подолі створюємо особливі коробки — діти самі обирають начинку і забирають додому.
              </p>
            </article>
            <article>
              <h3>Вечір з натуральним вином</h3>
              <p>
                Ілля Бабенко підібрав три українські вина, які підкреслюють вершкові соуси та копчені інгредієнти.
              </p>
            </article>
          </div>
        </section>
      </div>
    </>
  );
};

export default About;