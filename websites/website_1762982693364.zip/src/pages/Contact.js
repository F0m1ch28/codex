import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });
  const [formStatus, setFormStatus] = useState({ status: 'idle', message: '' });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((state) => ({ ...state, [name]: value }));
  };

  const validate = () => {
    if (!formData.name.trim()) {
      return 'Напишіть, будь ласка, ваше ім’я.';
    }
    if (!/^\+?[0-9\s()-]{7,}$/u.test(formData.phone)) {
      return 'Вкажіть телефон, щоб ми могли зв’язатися.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/u.test(formData.email)) {
      return 'Перевірте email — здається, є помилка.';
    }
    if (!formData.message.trim()) {
      return 'Опишіть, будь ласка, запит чи бажання.';
    }
    return null;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const error = validate();
    if (error) {
      setFormStatus({ status: 'error', message: error });
      return;
    }
    setFormStatus({ status: 'success', message: 'Дякуємо! Ми зв’яжемося з вами протягом 15 хвилин.' });
    setFormData({ name: '', phone: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Контакти пиццерии | Замовлення, бронювання, доставка</title>
        <meta
          name="description"
          content="Пиццерия в Киеве: контакти для замовлень та бронювання. Телефон, email, карта, форма зворотного звʼязку."
        />
      </Helmet>
      <div className={styles.page}>
        <section className={styles.info} aria-labelledby="contact-info-heading">
          <h1 id="contact-info-heading">Контакти пиццерии</h1>
          <p>
            Ми завжди на зв’язку, щоб обговорити меню, організувати доставку чи підготувати приватну вечерю. Зателефонуйте
            або напишіть — відповімо швидко.
          </p>
          <ul className={styles.contactList}>
            <li>
              <strong>Адреса:</strong> г. Киев, ул. Крещатик, 25
            </li>
            <li>
              <strong>Телефон:</strong>{' '}
              <a href="tel:+380441234567" className={styles.link}>
                +380 (44) 123-45-67
              </a>
            </li>
            <li>
              <strong>Email:</strong>{' '}
              <a href="mailto:info@pizzeria-kiev.ua" className={styles.link}>
                info@pizzeria-kiev.ua
              </a>
            </li>
            <li>
              <strong>Графік:</strong> Пн-Вс 10:00-23:00
            </li>
          </ul>
          <div className={styles.messengers}>
            <a href="https://t.me" target="_blank" rel="noreferrer">
              Telegram
            </a>
            <a href="https://wa.me/380441234567" target="_blank" rel="noreferrer">
              WhatsApp
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer">
              Instagram
            </a>
          </div>
        </section>

        <section className={styles.formSection} aria-labelledby="form-heading">
          <h2 id="form-heading">Напишіть нам</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="name">Ім’я</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Ваше ім’я"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="phone">Телефон</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                placeholder="+380..."
                value={formData.phone}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="example@gmail.com"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className={`${styles.formGroup} ${styles.formGroupFull}`}>
              <label htmlFor="message">Повідомлення</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Розкажіть, що саме вас цікавить..."
                value={formData.message}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.formFooter}>
              <button type="submit" className="btnPrimary">
                Надіслати
              </button>
              <p className={styles.formStatus} aria-live="polite">
                {formStatus.message}
              </p>
            </div>
          </form>
        </section>

        <section className={styles.mapSection} aria-labelledby="map-heading">
          <h2 id="map-heading">Як нас знайти</h2>
          <div className={styles.mapWrapper}>
            <iframe
              title="Пиццерия в Киеве на Крещатике"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2539.662779989018!2d30.52340077694901!3d50.44942137159474!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4ce5d1b210d5f%3A0xccd797f63018e8b5!2z0LLRg9C70LjRhtGPINCc0YPQu9C40YbRiywgMjUsINCa0LjRgNCw0Y8g0JrQsNC70YzQvdC40LosIDAxMDAw!5e0!3m2!1sru!2sua!4v1711815000000!5m2!1sru!2sua"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </section>
      </div>
    </>
  );
};

export default Contact;