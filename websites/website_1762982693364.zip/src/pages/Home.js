import React, { useMemo, useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const useInView = () => {
  const [isIntersecting, setIntersecting] = useState(false);
  const ref = React.useRef(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIntersecting(true);
          observer.disconnect();
        }
      },
      { threshold: 0.28 }
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return [ref, isIntersecting];
};

const ProgressiveImage = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className={`${styles.imageWrapper} ${loaded ? styles.imageLoaded : ''}`}>
      {!loaded && <div className={styles.imageSkeleton} aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        className={`${styles.image} ${className || ''}`}
        onLoad={() => setLoaded(true)}
        loading="lazy"
      />
    </div>
  );
};

const Home = () => {
  const [statsRef, statsVisible] = useInView();
  const [menuRef, menuVisible] = useInView();
  const [projectsRef, projectsVisible] = useInView();
  const [faqRef, faqVisible] = useInView();
  const [ctaRef, ctaVisible] = useInView();

  const statsData = useMemo(
    () => [
      { label: 'Рецептів в печі', value: 48 },
      { label: 'Щасливих гостей на день', value: 320 },
      { label: 'Подій, які ми обслуговуємо щорічно', value: 55 },
      { label: 'Хвилин середній час доставки', value: 45 },
    ],
    []
  );
  const [statValues, setStatValues] = useState(statsData.map(() => 0));

  useEffect(() => {
    if (!statsVisible) return;
    let animationFrame;
    const duration = 1400;
    const start = performance.now();

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      setStatValues(statsData.map((item) => Math.floor(item.value * progress)));
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };
    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [statsVisible, statsData]);

  const menuItems = useMemo(
    () => [
      {
        id: 1,
        title: 'Маргарита ді Нова',
        category: 'Класичні',
        description:
          'Тісто на заквасці, томати Сан Марцано, ніжна бурата і крапля базилікової олії для завершення.',
        image: 'https://picsum.photos/seed/pizza1/640/480',
        tags: ['вегетаріанська', 'неаполітанська', 'на дровах'],
      },
      {
        id: 2,
        title: 'Карбонара Римська',
        category: 'Преміум',
        description:
          'Хрусткий край, кремова соус-основа з яйцем, гваяль і сир пекоріно романо — передаємо дух Риму.',
        image: 'https://picsum.photos/seed/pizza2/640/480',
        tags: ['сигнатурна', 'сирна', 'подача зі сковороди'],
      },
      {
        id: 3,
        title: 'Фунгі Форестера',
        category: 'Вегетаріанські',
        description:
          'Поєднання трьох сортів грибів, трюфельне масло та трави з власного городика на терасі.',
        image: 'https://picsum.photos/seed/pizza3/640/480',
        tags: ['ароматна', 'хіт сезону', 'slow food'],
      },
      {
        id: 4,
        title: 'Пікантна Сапорі',
        category: 'Авторські',
        description:
          'Домашня nduja, сир качокавалло, карамелізована цибуля та апельсинова цедра для яскравого aftertaste.',
        image: 'https://picsum.photos/seed/pizza4/640/480',
        tags: ['гостра', 'крафтова', 'запашна'],
      },
      {
        id: 5,
        title: 'Чотири сезони Подолу',
        category: 'Класичні',
        description:
          'Кожен квадрант — окрема історія: артишоки, прошуто, чорні оливки та гриби шампіньйон.',
        image: 'https://picsum.photos/seed/pizza5/640/480',
        tags: ['сімейна', 'топ продажів', 'традиційна'],
      },
      {
        id: 6,
        title: 'Лимонна Полента',
        category: 'Авторські',
        description:
          'Ніжний маскарпоне, лимонна цедра та базилік, посипані карамелізованою кукурудзяною крупою.',
        image: 'https://picsum.photos/seed/pizza6/640/480',
        tags: ['солодко-солона', 'експеримент', 'летнє меню'],
      },
    ],
    []
  );
  const [activeCategory, setActiveCategory] = useState('Усі');
  const categories = ['Усі', 'Класичні', 'Преміум', 'Вегетаріанські', 'Авторські'];
  const filteredMenu = useMemo(() => {
    if (activeCategory === 'Усі') {
      return menuItems;
    }
    return menuItems.filter((item) => item.category === activeCategory);
  }, [activeCategory, menuItems]);

  const testimonials = [
    {
      name: 'Марія Коваль',
      quote:
        'Замовляли піцу для родинного обіду — тісто ніжне, начинки багато, доставка приїхала раніше, ніж ми накрили на стіл.',
      occupation: 'Флорист',
      image: 'https://picsum.photos/seed/testimonial1/160/160',
    },
    {
      name: 'Олексій Гончар',
      quote:
        'Завжди беру з собою до офісу. Люблю, що можна налаштувати гостроту, а кур’єри ввічливі та з термосумками.',
      occupation: 'Product manager',
      image: 'https://picsum.photos/seed/testimonial2/160/160',
    },
    {
      name: 'Ірина Литвин',
      quote:
        'Провели корпоратив на терасі пиццерії — команда продумала все до дрібниць, навіть пледи для вечірнього вітру.',
      occupation: 'HR-директор',
      image: 'https://picsum.photos/seed/testimonial3/160/160',
    },
  ];
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const processSteps = [
    {
      title: 'Замішуємо тісто',
      description:
        'Використовуємо закваску, мелену в Києві муку та воду, настояну на травах. Тісто відпочиває 48 годин.',
      icon: '🥖',
    },
    {
      title: 'Добираємо начинки',
      description:
        'Сир з невеликих сироварень, овочі від фермерів Київщини та власні соуси на томатах Сан Марцано.',
      icon: '🧀',
    },
    {
      title: 'Випікаємо у печі',
      description:
        'Піч на дровах розігріта до 450°C, щоб піца мала підпечений край та пухку серединку.',
      icon: '🔥',
    },
    {
      title: 'Доставляємо теплою',
      description:
        'Піцу пакуємо в коробки з вентиляційним малюнком, щоб вона приїхала до вас хрусткою.',
      icon: '🚲',
    },
  ];

  const projects = [
    {
      id: 'proj1',
      category: 'Кейтеринг',
      title: 'Арт-вечір у PinchukArtCentre',
      description:
        'Облаштували pop-up піч і створили сет авторських піц з локальними травами і печеним гарбузом.',
      image: 'https://picsum.photos/seed/project1/960/640',
    },
    {
      id: 'proj2',
      category: 'Фестивалі',
      title: 'Kyiv Food Market Weekend',
      description:
        'Гості могли зібрати власну піцу — від соусів до фінальних топінгів, черга не закінчувалась.',
      image: 'https://picsum.photos/seed/project2/960/640',
    },
    {
      id: 'proj3',
      category: 'Кейтеринг',
      title: 'Весілля на Подолі',
      description:
        'Зробили нічний піца-бар із живим виступом шефа та інтерактивною станцією для гостей.',
      image: 'https://picsum.photos/seed/project3/960/640',
    },
    {
      id: 'proj4',
      category: 'Колаборації',
      title: 'Chef’s Table з баром Parovoz',
      description:
        'Поєднали наші печені артишоки з коктейльною картою — кожна пара піца+коктейль мала власну історію.',
      image: 'https://picsum.photos/seed/project4/960/640',
    },
  ];
  const [projectFilter, setProjectFilter] = useState('Усе');
  const filteredProjects = useMemo(() => {
    if (projectFilter === 'Усе') return projects;
    return projects.filter((item) => item.category === projectFilter);
  }, [projectFilter, projects]);

  const faqItems = [
    {
      question: 'Чи можна замовити піцу наполовину з різними смаками?',
      answer:
        'Так, ми пропонуємо мікси для діаметра 32 см. Повідомте оператору або додайте примітку під час онлайн-замовлення.',
    },
    {
      question: 'Які райони Києва обслуговує доставка?',
      answer:
        'Крім центру, доставляємо на Печерськ, Поділ, Липки, а також частину Оболоні. Зони розширюємо щоквартально.',
    },
    {
      question: 'Чи є безглютенове тісто?',
      answer:
        'Маємо безглютенову основу на кукурудзяній муці. Замовлення на таке тісто приймаємо за 2 години до випічки.',
    },
    {
      question: 'Скільки часу займає самовивіз?',
      answer:
        'Піца буде готова за 15 хвилин. Ми сповістимо вас у месенджері, щоб забрати в найтепліший момент.',
    },
  ];

  const blogPosts = [
    {
      id: 'blog1',
      title: 'Як ми відновили піч XVIII століття для сучасної кухні',
      excerpt: 'Історія димоходу з Подолу, яку ми перетворили на серце нашої пиццерії.',
      date: '05.03.2024',
      category: 'Історії Києва',
      image: 'https://picsum.photos/seed/blog1/800/520',
    },
    {
      id: 'blog2',
      title: 'Гід по винам до піци: поради сомельє',
      excerpt: 'Підібрали українські та італійські вина, що найкраще розкривають наші смаки.',
      date: '17.03.2024',
      category: 'Напої',
      image: 'https://picsum.photos/seed/blog2/800/520',
    },
    {
      id: 'blog3',
      title: 'Чому холодна ферментація — секрет нашого тіста',
      excerpt: 'Розповідаємо, як час і температура змінюють текстуру та смак.',
      date: '29.03.2024',
      category: 'Кухня',
      image: 'https://picsum.photos/seed/blog3/800/520',
    },
  ];

  const [subscribeEmail, setSubscribeEmail] = useState('');
  const [subscribeState, setSubscribeState] = useState({ status: 'idle', message: '' });

  const handleSubscribe = (event) => {
    event.preventDefault();
    if (!subscribeEmail) {
      setSubscribeState({ status: 'error', message: 'Будь ласка, введіть email.' });
      return;
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/u;
    if (!emailPattern.test(subscribeEmail)) {
      setSubscribeState({ status: 'error', message: 'Перевірте формат email — ми не можемо відправити лист.' });
      return;
    }
    setSubscribeState({ status: 'success', message: 'Дякуємо! Ми вже готуємо лист із новинами та акціями.' });
    setSubscribeEmail('');
  };

  const [activeFaq, setActiveFaq] = useState(null);

  return (
    <>
      <Helmet>
        <meta
          name="description"
          content="Меню, доставка, команда та історії Пиццерии в Киеве. Сучасна середземноморська атмосфера та дров’яна піч."
        />
      </Helmet>

      <div className={styles.page}>
        <section
          className={styles.hero}
          style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=101)' }}
        >
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>Справжня неаполітанська піч</span>
              <h1 className={styles.heroTitle}>
                Піцерія на Крещатику,
                <br />
                де кожна випічка — маленьке свято Києва
              </h1>
              <p className={styles.heroSubtitle}>
                Ми поєднуємо традиції італійських маестро та настрій старого міста, щоб ви відчули тепло дровяної печі
                навіть вдома.
              </p>
              <div className={styles.heroActions}>
                <NavLink to="/menu" className="btnPrimary">
                  Переглянути меню
                </NavLink>
                <a className="btnGhost" href="#contact">
                  Забронювати столик
                </a>
              </div>
              <ul className={styles.heroHighlights}>
                <li>Замішуємо тісто 48 годин</li>
                <li>Доставка по Києву за 45 хвилин</li>
                <li>Меню змінюється з сезоном</li>
              </ul>
            </div>
            <div className={styles.heroCard}>
              <div className={styles.heroCardInner}>
                <span className={styles.cardLabel}>Спецпропозиція тижня</span>
                <h3>Піца «Весняна Контральто»</h3>
                <p>
                  Топінг з молодого шпинату, сортування сирів та соусу з печеного буряка. Лише до 7 квітня.
                </p>
                <NavLink to="/menu" className={styles.cardLink}>
                  Деталі меню →
                </NavLink>
              </div>
            </div>
          </div>
        </section>

        <section ref={statsRef} className={`${styles.statsSection} ${statsVisible ? styles.inView : ''}`}>
          <h2 className={styles.sectionTitle}>Про що говорить статистика нашої печі</h2>
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <div className={styles.statValue}>{statValues[index]}</div>
                <p className={styles.statLabel}>{stat.label}</p>
              </article>
            ))}
          </div>
        </section>

        <section
          ref={menuRef}
          id="menu"
          className={`${styles.menuSection} ${menuVisible ? styles.inView : ''}`}
          aria-labelledby="menu-heading"
        >
          <div className={styles.zigzagWrapper}>
            <div className={styles.zigzagContent}>
              <h2 id="menu-heading" className={styles.sectionTitle}>
                Наше меню — улюблені смаки Києва
              </h2>
              <p className={styles.sectionText}>
                У нас немає промислових заготовок: тісто ферментується холодним способом, сир тремо щоранку, а сезонні
                овочі збираємо з фермерських двориків. Скуштуйте добірку, яку кияни рекомендують друзям.
              </p>
              <div className={styles.filters} role="tablist" aria-label="Категорії меню">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    className={`${styles.filterButton} ${activeCategory === cat ? styles.filterActive : ''}`}
                    onClick={() => setActiveCategory(cat)}
                    role="tab"
                    aria-selected={activeCategory === cat}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <NavLink to="/menu" className="btnSecondary">
                Відкрити повне меню
              </NavLink>
            </div>

            <div className={styles.menuGrid}>
              {filteredMenu.map((item) => (
                <article key={item.id} className={styles.menuCard}>
                  <ProgressiveImage src={item.image} alt={`Піца ${item.title}`} />
                  <div className={styles.menuCardBody}>
                    <div className={styles.menuMeta}>
                      <span>{item.category}</span>
                    </div>
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                    <ul className={styles.menuTags}>
                      {item.tags.map((tag) => (
                        <li key={tag}>#{tag}</li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.processSection} aria-labelledby="process-heading">
          <div className={styles.zigzagWrapper}>
            <div className={styles.processIntro}>
              <h2 id="process-heading" className={styles.sectionTitle}>
                Процес, у який ми закохані
              </h2>
              <p className={styles.sectionText}>
                Кухня відкривається за годину до відвідувань, аби підготувати тісто, розпалити піч та добрати трави.
                Кожен етап — наша маленька ритуальна церемонія.
              </p>
              <a href="/delivery" className="btnPrimary">
                Дізнатися про доставку
              </a>
            </div>
            <div className={styles.processTimeline}>
              {processSteps.map((step) => (
                <div key={step.title} className={styles.processStep}>
                  <span className={styles.processIcon} aria-hidden="true">
                    {step.icon}
                  </span>
                  <div>
                    <h3>{step.title}</h3>
                    <p>{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.testimonialSection} aria-labelledby="testimonials-heading">
          <div className={styles.testimonialHeader}>
            <h2 id="testimonials-heading" className={styles.sectionTitle}>
              Відгуки, які надихають готувати ще краще
            </h2>
            <p className={styles.sectionText}>
              Нам важливо підтримувати діалог із гостями. Кожен коментар — це рецепт, який ми допрацьовуємо разом із вами.
            </p>
          </div>
          <div className={styles.testimonialCarousel} aria-live="polite">
            {testimonials.map((item, index) => (
              <article
                key={item.name}
                className={`${styles.testimonialCard} ${
                  testimonialIndex === index ? styles.testimonialActive : ''
                }`}
              >
                <ProgressiveImage src={item.image} alt={`Гість ${item.name}`} className={styles.testimonialAvatar} />
                <blockquote>“{item.quote}”</blockquote>
                <div className={styles.testimonialMeta}>
                  <span>{item.name}</span>
                  <span>{item.occupation}</span>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.testimonialControls}>
            <button
              type="button"
              aria-label="Попередній відгук"
              onClick={() =>
                setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
              }
            >
              ←
            </button>
            <button
              type="button"
              aria-label="Наступний відгук"
              onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonials.length)}
            >
              →
            </button>
          </div>
        </section>

        <section className={styles.teamSection} aria-labelledby="team-heading">
          <div className={styles.zigzagWrapper}>
            <div className={styles.teamIntro}>
              <h2 id="team-heading" className={styles.sectionTitle}>
                Команда печі та залу
              </h2>
              <p className={styles.sectionText}>
                Ми віримо в силу ручної праці. Кожен член команди проходить наш «теплий стаж» — два тижні у пекарні,
                аби відчути енергетику продукту.
              </p>
              <NavLink to="/about" className="btnGhost">
                Познайомитись ближче
              </NavLink>
            </div>
            <div className={styles.teamGrid}>
              {[
                {
                  name: 'Дарина Мельник',
                  role: 'Шеф-кухарка',
                  story: 'Навчалась у Неаполі, створює сезонні колекції піци та соусів.',
                  image: 'https://picsum.photos/seed/team1/480/480',
                },
                {
                  name: 'Марко Сидоренко',
                  role: 'Піцайоло',
                  story: 'Вітряк, який розкручує тісто у повітрі за 2 секунди. Обожнює ферментацію.',
                  image: 'https://picsum.photos/seed/team2/480/480',
                },
                {
                  name: 'Оля Романюк',
                  role: 'Керівниця сервісу',
                  story: 'Вчить команду говорити «дякую» на десяти мовах і пам’ятати постійних гостей.',
                  image: 'https://picsum.photos/seed/team3/480/480',
                },
                {
                  name: 'Ілля Бабенко',
                  role: 'Бариста-сомельє',
                  story: 'Поєднує піцу з кавою та натуральними винами, складає пари на смак гостей.',
                  image: 'https://picsum.photos/seed/team4/480/480',
                },
              ].map((member) => (
                <article key={member.name} className={styles.teamCard}>
                  <ProgressiveImage src={member.image} alt={`${member.name} — ${member.role}`} />
                  <div className={styles.teamOverlay}>
                    <h3>{member.name}</h3>
                    <span>{member.role}</span>
                    <p>{member.story}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section
          ref={projectsRef}
          className={`${styles.projectsSection} ${projectsVisible ? styles.inView : ''}`}
          aria-labelledby="projects-heading"
        >
          <div className={styles.sectionHeader}>
            <h2 id="projects-heading" className={styles.sectionTitle}>
              Проєкти та події, які ми запалюємо
            </h2>
            <div className={styles.projectFilters} role="tablist">
              {['Усе', 'Кейтеринг', 'Фестивалі', 'Колаборації'].map((filter) => (
                <button
                  key={filter}
                  type={filter === projectFilter ? 'button' : 'button'}
                  onClick={() => setProjectFilter(filter)}
                  className={`${styles.projectFilterButton} ${
                    projectFilter === filter ? styles.projectFilterActive : ''
                  }`}
                  role="tab"
                  aria-selected={projectFilter === filter}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <ProgressiveImage src={project.image} alt={project.title} />
                <div className={styles.projectBody}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <a href="/services" className={styles.projectLink}>
                    Дізнатись як ми працюємо →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section
          ref={faqRef}
          className={`${styles.faqSection} ${faqVisible ? styles.inView : ''}`}
          aria-labelledby="faq-heading"
        >
          <div className={styles.zigzagWrapper}>
            <div className={styles.faqIntro}>
              <h2 id="faq-heading" className={styles.sectionTitle}>
                Часті питання: хто, що, коли?
              </h2>
              <p className={styles.sectionText}>
                Зібрали відповіді, щоб ви могли швидко зорієнтуватися. Якщо чогось не вистачає — напишіть нам у чат.
              </p>
              <a className="btnSecondary" href="tel:+380441234567">
                Зателефонувати зараз
              </a>
            </div>
            <div className={styles.accordion} role="list">
              {faqItems.map((item, index) => (
                <div key={item.question} className={styles.accordionItem}>
                  <button
                    type="button"
                    className={styles.accordionButton}
                    aria-expanded={activeFaq === index}
                    onClick={() => setActiveFaq((prev) => (prev === index ? null : index))}
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true">{activeFaq === index ? '−' : '+'}</span>
                  </button>
                  <div
                    className={`${styles.accordionPanel} ${activeFaq === index ? styles.accordionOpen : ''}`}
                    role="region"
                    aria-hidden={activeFaq !== index}
                  >
                    <p>{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.blogSection} aria-labelledby="blog-heading">
          <div className={styles.sectionHeader}>
            <h2 id="blog-heading" className={styles.sectionTitle}>
              Блог пічної команди
            </h2>
            <a className="btnGhost" href="/about#blog">
              Читати всі матеріали
            </a>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <ProgressiveImage src={post.image} alt={post.title} />
                <div className={styles.blogBody}>
                  <span className={styles.blogMeta}>
                    {post.category} • {post.date}
                  </span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href="/about#blog" className={styles.blogLink}>
                    Далі →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section
          ref={ctaRef}
          className={`${styles.ctaSection} ${ctaVisible ? styles.inView : ''}`}
          aria-labelledby="cta-heading"
        >
          <div className={styles.ctaContent}>
            <h2 id="cta-heading">Готові до вечора зі справжньою піцою?</h2>
            <p>
              Залиште заявку — ми зателефонуємо, допоможемо підібрати смаки та забронюємо столик із видом на Хрещатик.
            </p>
            <div className={styles.ctaActions}>
              <a className="btnPrimary" href="/contacts">
                Залишити заявку
              </a>
              <a className="btnSecondary" href="https://t.me">
                Написати у Telegram
              </a>
            </div>
          </div>
        </section>

        <section className={styles.subscribeSection} aria-labelledby="subscribe-heading">
          <div className={styles.subscribeContent}>
            <h2 id="subscribe-heading">Новини від печі</h2>
            <p>
              Раз на тиждень надсилаємо рецепти, ідеї для вечерь та закриті пропозиції для друзів пиццерії.
            </p>
            <form className={styles.subscribeForm} onSubmit={handleSubscribe}>
              <label htmlFor="subscribe-email" className="visually-hidden">
                Email для підписки
              </label>
              <input
                id="subscribe-email"
                type="email"
                name="email"
                placeholder="Ваш email"
                value={subscribeEmail}
                onChange={(event) => setSubscribeEmail(event.target.value)}
                required
              />
              <button type="submit" className="btnPrimary">
                Підписатись
              </button>
            </form>
            <p className={styles.subscribeNote} aria-live="polite">
              {subscribeState.message}
            </p>
          </div>
        </section>

        <section id="contact" className={styles.contactSection} aria-labelledby="contact-heading">
          <div className={styles.contactContent}>
            <div className={styles.contactInfo}>
              <h2 id="contact-heading" className={styles.sectionTitle}>
                Контакти та карта
              </h2>
              <p className={styles.sectionText}>
                Ми чекаємо на вас щодня з 10:00 до 23:00. Дзвоніть, пишіть у месенджери або приходьте на ароматну каву.
              </p>
              <ul className={styles.contactList}>
                <li>
                  <strong>Адреса:</strong> г. Киев, ул. Крещатик, 25
                </li>
                <li>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+380441234567" aria-label="Позвонить в пиццерию">
                    +380 (44) 123-45-67
                  </a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@pizzeria-kiev.ua">info@pizzeria-kiev.ua</a>
                </li>
                <li>
                  <strong>Графік:</strong> Пн-Вс 10:00-23:00
                </li>
              </ul>
              <div className={styles.contactActions}>
                <a className="btnPrimary" href="tel:+380441234567">
                  Зателефонувати
                </a>
                <a className="btnGhost" href="mailto:info@pizzeria-kiev.ua">
                  Написати лист
                </a>
              </div>
            </div>
            <div className={styles.mapWrapper}>
              <iframe
                title="Пиццерия в Киеве на карте"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2539.662779989018!2d30.52340077694901!3d50.44942137159474!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d4ce5d1b210d5f%3A0xccd797f63018e8b5!2z0LLRg9C70LjRhtGPINCc0YPQu9C40YbRiywgMjUsINCa0LjRgNCw0Y8g0JrQsNC70YzQvdC40LosIDAxMDAw!5e0!3m2!1sru!2sua!4v1711815000000!5m2!1sru!2sua"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;