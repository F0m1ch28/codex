document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isActive = navToggle.classList.toggle("is-active");
      primaryNav.classList.toggle("nav-open", isActive);
      document.body.classList.toggle("nav-open", isActive);
      navToggle.setAttribute("aria-expanded", isActive ? "true" : "false");
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        primaryNav.classList.remove("nav-open");
        navToggle.classList.remove("is-active");
        document.body.classList.remove("nav-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const banner = document.querySelector(".cookie-banner");
  if (banner) {
    const consent = localStorage.getItem("abhCookieConsent");
    if (consent) {
      banner.classList.add("is-hidden");
    }
    const acceptButton = banner.querySelector('[data-cookie="accept"]');
    const declineButton = banner.querySelector('[data-cookie="decline"]');

    if (acceptButton) {
      acceptButton.addEventListener("click", () => {
        localStorage.setItem("abhCookieConsent", "accepted");
        banner.classList.add("is-hidden");
      });
    }

    if (declineButton) {
      declineButton.addEventListener("click", () => {
        localStorage.setItem("abhCookieConsent", "declined");
        banner.classList.add("is-hidden");
      });
    }
  }

  if (document.body.classList.contains("thank-you-page")) {
    window.addEventListener("load", () => {
      alert("Thank you for your enquiry");
    });
  }
});