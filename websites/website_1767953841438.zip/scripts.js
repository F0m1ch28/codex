document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.primary-nav');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('smellukldc_cookie_preference');
        if (storedPreference) {
            cookieBanner.classList.add('is-hidden');
        }

        const cookieButtons = cookieBanner.querySelectorAll('[data-cookie-action]');
        cookieButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const action = button.dataset.cookieAction || 'dismissed';
                localStorage.setItem('smellukldc_cookie_preference', action);
                cookieBanner.classList.add('is-hidden');
                const redirectTarget = button.dataset.redirect;
                if (redirectTarget) {
                    setTimeout(() => {
                        window.location.href = redirectTarget;
                    }, 300);
                }
            });
        });
    }
});