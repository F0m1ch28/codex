document.addEventListener("DOMContentLoaded", () => {
    const body = document.body;

    /* Current Year */
    const yearElement = document.querySelectorAll("[data-current-year]");
    const currentYear = new Date().getFullYear();
    yearElement.forEach((el) => {
        el.textContent = currentYear;
    });

    /* Mobile Navigation */
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");
    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = primaryNav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
            navToggle.classList.toggle("is-active", isOpen);
            body.classList.toggle("nav-open", isOpen);
        });
    }

    /* Cookie Banner */
    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll("[data-cookie-choice]");
    const cookieStatus = localStorage.getItem("cornmqgh-cookie-choice");
    if (!cookieStatus && cookieBanner) {
        cookieBanner.classList.add("active");
    }
    cookieButtons.forEach((btn) => {
        btn.addEventListener("click", (event) => {
            event.preventDefault();
            const choice = btn.getAttribute("data-cookie-choice");
            localStorage.setItem("cornmqgh-cookie-choice", choice);
            if (cookieBanner) {
                cookieBanner.classList.remove("active");
            }
        });
    });

    /* Form Redirects */
    const forms = document.querySelectorAll("form[data-redirect]");
    forms.forEach((form) => {
        form.addEventListener("submit", (event) => {
            event.preventDefault();
            const redirectUrl = form.getAttribute("data-redirect") || "thanks.html";
            form.classList.add("is-submitting");
            setTimeout(() => {
                window.location.href = redirectUrl;
            }, 400);
        });
    });

    /* Posts Filtering */
    const filterChips = document.querySelectorAll(".filter-chip[data-filter]");
    const searchInput = document.querySelector(".search-field input");
    const articles = document.querySelectorAll("[data-category]");
    const pagination = document.querySelector(".pagination");

    function updateArticles() {
        const activeFilter = document.querySelector(".filter-chip.active")?.dataset.filter || "all";
        const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
        let visibleCount = 0;

        articles.forEach((article) => {
            const category = article.dataset.category;
            const text = article.textContent.toLowerCase();
            const matchesFilter = activeFilter === "all" || category === activeFilter;
            const matchesSearch = query.length === 0 || text.includes(query);
            if (matchesFilter && matchesSearch) {
                article.style.display = "";
                visibleCount++;
            } else {
                article.style.display = "none";
            }
        });

        if (pagination) {
            pagination.style.display = visibleCount > 0 ? "flex" : "none";
        }
    }

    filterChips.forEach((chip) => {
        chip.addEventListener("click", () => {
            filterChips.forEach((item) => item.classList.remove("active"));
            chip.classList.add("active");
            updateArticles();
        });
    });

    if (searchInput) {
        searchInput.addEventListener("input", () => {
            updateArticles();
        });
    }

    if (articles.length > 0) {
        updateArticles();
    }
});