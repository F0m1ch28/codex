import React, { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  course: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setStatus('');
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus('Please fill out the required fields to send your message.');
      return;
    }
    setStatus('Thank you! Our team will be in touch shortly.');
    setFormData(initialFormState);
  };

  return (
    <div className="container">
      <PageHelmet
        title="Contact Language Loft"
        description="Connect with Language Loft to craft your personalised language program or request information about our services."
        canonical="https://www.example.com/contact"
      />
      <header className={styles.header}>
        <span>Contact</span>
        <h1>Let’s design your Language Loft journey.</h1>
        <p>
          Share your goals and availability with us. Our Amsterdam-based team will respond within one business day to map next steps.
        </p>
      </header>

      <section className={styles.grid}>
        <form className={styles.form} onSubmit={handleSubmit} aria-label="Contact Language Loft form">
          <label htmlFor="name">
            Name<span aria-hidden="true">*</span>
          </label>
          <input id="name" type="text" name="name" value={formData.name} onChange={handleChange} required placeholder="Full name" />

          <label htmlFor="email">
            Email<span aria-hidden="true">*</span>
          </label>
          <input id="email" type="email" name="email" value={formData.email} onChange={handleChange} required placeholder="you@example.com" />

          <label htmlFor="course">Course Interest</label>
          <select id="course" name="course" value={formData.course} onChange={handleChange}>
            <option value="">Select an interest</option>
            <option value="Dutch Professional">Dutch for Professionals</option>
            <option value="English Leadership">English Leadership</option>
            <option value="Spanish Immersion">Spanish Immersion</option>
            <option value="Mandarin Strategic">Mandarin Strategic</option>
            <option value="Corporate Custom">Corporate Custom Pathway</option>
            <option value="Not sure yet">I’m exploring options</option>
          </select>

          <label htmlFor="message">
            Message<span aria-hidden="true">*</span>
          </label>
          <textarea id="message" name="message" rows="5" value={formData.message} onChange={handleChange} required placeholder="Tell us about your goals, context, and timeline." />

          <button type="submit">Send Message</button>
          {status && <p className={styles.statusMessage}>{status}</p>}
        </form>

        <aside className={styles.details}>
          <h2>Contact details</h2>
          <div className={styles.detailBlock}>
            <h3>Address</h3>
            <p>[Адрес будет добавлен позже]</p>
          </div>
          <div className={styles.detailBlock}>
            <h3>Phone</h3>
            <p>[Телефон будет добавлен позже]</p>
          </div>
          <div className={styles.detailBlock}>
            <h3>Email</h3>
            <p>[Email будет добавлен позже]</p>
          </div>
          <div className={styles.detailBlock}>
            <h3>Visit the loft</h3>
            <p>Join us for a discovery session at our Amsterdam studio or connect virtually from anywhere in the world.</p>
          </div>
        </aside>
      </section>
    </div>
  );
};

export default Contact;