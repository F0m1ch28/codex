import React from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import styles from './Blog.module.css';

const blogEntries = [
  {
    slug: 'tips-for-beginners',
    title: 'Tips for Beginners: Building Momentum in a New Language',
    image: 'https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=1200&q=80',
    summary:
      'Start with anchors that make sense to you, layer listening routines, and transform mistakes into progress markers.',
    readTime: '6 min read',
    category: 'Strategy',
    content: [
      {
        heading: 'Build your micro-habit framework',
        body:
          'Rather than committing to hour-long study blocks, anchor a five-minute habit to moments already in your schedule. For example, pair your morning coffee with a Dutch audio snippet or your commute with vocabulary reviews. Consistency primes the brain to expect language moments and reduces the friction of getting started.',
      },
      {
        heading: 'Design your environment for exposure',
        body:
          'Switch device settings to your target language, replace small talk with simple practice phrases, and curate a playlist of native speakers discussing topics you love. Your environment should remind you of your learning objective throughout the day.',
      },
      {
        heading: 'Celebrate micro-milestones',
        body:
          'Track the first time you understand a full sentence, order a meal, or contribute to a meeting. Reflecting on micro-milestones helps maintain momentum during the inevitable plateaus.',
      },
    ],
  },
  {
    slug: 'cultural-notes-spain',
    title: 'Cultural Notes: Navigating Everyday Spain',
    image: 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=1200&q=80',
    summary:
      'From greetings to mealtime etiquette, understanding Spanish cultural rhythms enhances every conversation.',
    readTime: '5 min read',
    category: 'Culture',
    content: [
      {
        heading: 'Context matters more than directness',
        body:
          'Spanish communication style values warmth and context. Expect greetings to include inquiries about family or wellbeing before diving into business. Matching this rhythm builds rapport quickly.',
      },
      {
        heading: 'Embrace the sobremesa',
        body:
          'The leisurely conversation that follows a meal—the sobremesa—is where relationships deepen. Use this time to practise storytelling and active listening.',
      },
      {
        heading: 'Adapt to regional nuances',
        body:
          'Spain is wonderfully diverse. Recognise the linguistic differences between Castilian, Catalan, and other regional languages to show respect and curiosity.',
      },
    ],
  },
  {
    slug: 'dutch-language-hacks',
    title: 'Dutch Language Hacks for Busy Professionals',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
    summary:
      'Integrate Dutch naturally into your workday with smart shortcuts, reflective loops, and community immersion.',
    readTime: '7 min read',
    category: 'Productivity',
    content: [
      {
        heading: 'Leverage your meeting calendar',
        body:
          'Tag agenda items with key Dutch vocabulary and practise summaries before and after meetings. This primes you for real-time application without extra study blocks.',
      },
      {
        heading: 'Use Dutch voice notes',
        body:
          'Send voice notes to teammates or yourself in Dutch to reinforce pronunciation and spontaneity. Review them weekly to notice improvements.',
      },
      {
        heading: 'Join community meetups',
        body:
          'The Netherlands hosts countless language cafés and professional meetups. Choose one per month to stretch beyond the classroom while building local networks.',
      },
    ],
  },
];

const Blog = () => {
  return (
    <div className="container">
      <PageHelmet
        title="Language Loft Blog"
        description="Read Language Loft blog insights on language strategy, cultural intelligence, and learner stories from across the Netherlands."
        canonical="https://www.example.com/blog"
      />
      <header className={styles.header}>
        <span>Blog & insights</span>
        <h1>Stories, strategies, and cultural notes from Language Loft.</h1>
        <p>
          Dive into reflections from our coaches, learners, and partners across the Netherlands as they use language to unlock new possibilities.
        </p>
      </header>
      <section className={styles.grid}>
        {blogEntries.map((post) => (
          <article key={post.slug}>
            <img src={post.image} alt={post.title} loading="lazy" />
            <div className={styles.body}>
              <span>{post.category}</span>
              <h2>{post.title}</h2>
              <p>{post.summary}</p>
              <div className={styles.meta}>{post.readTime}</div>
              <Link to={`/blog/${post.slug}`}>Read article</Link>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

const renderArticle = (post) => (
  <div className={`container ${styles.article}`}>
    <PageHelmet
      title={`${post.title} | Language Loft Blog`}
      description={post.summary}
      canonical={`https://www.example.com/blog/${post.slug}`}
    />
    <header>
      <span>{post.category}</span>
      <h1>{post.title}</h1>
      <p>{post.summary}</p>
      <div>{post.readTime}</div>
    </header>
    <img src={post.image} alt={post.title} loading="lazy" />
    {post.content.map((section) => (
      <article key={section.heading}>
        <h2>{section.heading}</h2>
        <p>{section.body}</p>
      </article>
    ))}
    <div className={styles.backLink}>
      <Link to="/blog">← Back to all posts</Link>
    </div>
  </div>
);

export const BlogTipsForBeginners = () => renderArticle(blogEntries[0]);
export const BlogCulturalNotesSpain = () => renderArticle(blogEntries[1]);
export const BlogDutchLanguageHacks = () => renderArticle(blogEntries[2]);

export default Blog;