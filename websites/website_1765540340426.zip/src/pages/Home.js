import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Learners coached', value: 3200 },
  { label: 'Languages delivered', value: 12 },
  { label: 'Corporate partners', value: 85 },
  { label: 'Average satisfaction score', value: 4.9, suffix: '/5' },
];

const programHighlights = [
  {
    title: 'Dutch for Professionals',
    description: 'Accelerated Dutch coaching designed for expats navigating the Dutch workplace with confidence.',
    image: 'https://images.unsplash.com/photo-1529070538774-1843cb3265df?auto=format&fit=crop&w=1200&q=80',
    link: '/programs',
    tag: 'Popular',
  },
  {
    title: 'EU Mobility Language Sprint',
    description: 'Intensive, hybrid program for teams operating across European markets and time zones.',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80',
    link: '/programs',
    tag: 'Team',
  },
  {
    title: 'Cultural Fluency Path',
    description: 'Immersive experiences in Amsterdam and beyond to connect language with living culture.',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
    link: '/programs',
    tag: 'Immersive',
  },
];

const projectExperiences = [
  {
    title: 'Rotterdam Port Negotiation Lab',
    category: 'Corporate',
    description: 'Simulated multi-lingual negotiation experience with logistics stakeholders across Europe.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80',
  },
  {
    title: 'Amsterdam Creative Residency',
    category: 'Creative',
    description: 'Storytelling residency pairing learners with filmmakers and writers for narrative mastery.',
    image: 'https://images.unsplash.com/photo-1460518451285-97b6aa326961?auto=format&fit=crop&w=1200&q=80',
  },
  {
    title: 'Utrecht Academic Symposium',
    category: 'Academic',
    description: 'Scholarly debates and peer feedback in academic English and German for research fellows.',
    image: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=1200&q=80',
  },
];

const testimonials = [
  {
    quote:
      'Language Loft helped our multinational team maintain nuance and rapport across Dutch, Spanish, and English. The coaching is adaptive and deeply human.',
    name: 'Elena Martín',
    role: 'EMEA Talent Lead, GreenWave Energy',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
  },
  {
    quote:
      'From day one, my coach mapped my goals and made the Netherlands feel like home. The cultural immersion projects are a game changer.',
    name: 'Thomas Becker',
    role: 'Strategy Consultant, Berlin',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=400&q=80',
  },
  {
    quote:
      'Our medical fellows cite Language Loft as their most valuable professional development module. Communication in critical care is sharper than ever.',
    name: 'Dr. Floor van Dijk',
    role: 'Program Director, Utrecht Medical Center',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e0?auto=format&fit=crop&w=400&q=80',
  },
];

const faqItems = [
  {
    question: 'How are Language Loft programs tailored to individual goals?',
    answer:
      'Each learner begins with a discovery session led by our academic team. We map professional, personal, and cultural aims, then design a modular plan that evolves after every milestone review.',
  },
  {
    question: 'Do you support hybrid or remote participation?',
    answer:
      'Yes. We blend live sessions from our Amsterdam loft with virtual cohorts so traveling professionals remain connected without compromising progress.',
  },
  {
    question: 'Which languages can I study with Language Loft?',
    answer:
      'Our core languages include Dutch, English, German, French, Spanish, Italian, and Mandarin, with rotating electives for emerging global hubs.',
  },
];

const blogPreviews = [
  {
    title: 'Tips for Beginners: Building Momentum in a New Language',
    link: '/blog/tips-for-beginners',
    image: 'https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=800&q=80',
    tag: 'Strategy',
  },
  {
    title: 'Cultural Notes: Navigating Everyday Spain',
    link: '/blog/cultural-notes-spain',
    image: 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=800&q=80',
    tag: 'Culture',
  },
  {
    title: 'Dutch Language Hacks for Busy Professionals',
    link: '/blog/dutch-language-hacks',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=800&q=80',
    tag: 'Productivity',
  },
];

const Home = () => {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeProjectFilter, setActiveProjectFilter] = useState('All');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((value, index) => {
          const target = statsData[index].value;
          if (value >= target) return target;
          const increment = Math.ceil(target / 60);
          return Math.min(value + increment, target);
        })
      );
    }, 60);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(rotation);
  }, []);

  const testimonial = testimonials[testimonialIndex];

  const projectFilters = useMemo(() => ['All', ...new Set(projectExperiences.map((item) => item.category))], []);
  const filteredProjects =
    activeProjectFilter === 'All'
      ? projectExperiences
      : projectExperiences.filter((project) => project.category === activeProjectFilter);

  return (
    <>
      <PageHelmet
        title="Language Loft | Tailored Language Mastery in the Netherlands"
        description="Discover Language Loft, the Netherlands-based language studio delivering bespoke programs, cultural immersion, and coaching for global professionals."
        canonical="https://www.example.com/"
      />
      <section className={styles.hero}>
        <div className={styles.heroMedia} role="presentation" />
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <span className={styles.heroTag}>Amsterdam · Tailored Language Journeys</span>
            <h1>Unlock the language that powers your next chapter.</h1>
            <p>
              Language Loft designs adaptive, learner-first programs that weave language, culture, and confidence together. From executive Dutch to multi-market communication, every path is crafted for your ambitions.
            </p>
            <div className={styles.heroActions}>
              <Link to="/guide" className={styles.primaryBtn}>
                Explore the course guide
              </Link>
              <Link to="/contact" className={styles.secondaryBtn}>
                Talk to an advisor
              </Link>
            </div>
            <div className={styles.heroCredits}>
              <img
                src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=160&q=80"
                alt="Learners collaborating"
              />
              <p>
                Trusted by innovators across Amsterdam, Rotterdam, and the wider EU to elevate everyday communication and strategic fluency.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats}>
        <div className="container">
          <div className={styles.sectionIntro}>
            <h2>Impact grounded in the Netherlands, reaching worldwide.</h2>
            <p>Our studio blends Dutch pragmatism with global insights to unlock measurable growth for every learner.</p>
          </div>
          <div className={styles.statGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <h3 aria-live="polite">
                  {counters[index]}
                  {stat.suffix || ''}
                </h3>
                <p>{stat.label}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.programs}>
        <div className="container">
          <div className={styles.sectionIntro}>
            <span className={styles.kicker}>Signature programs</span>
            <h2>Dial in the program that fits your voice, pace, and industry.</h2>
            <p>
              Every Language Loft journey begins with a bespoke blueprint. Our coaches map your strengths, schedule, and professional context to design sessions that resonate.
            </p>
          </div>
          <div className={styles.programGrid}>
            {programHighlights.map((program) => (
              <article key={program.title} className={styles.programCard}>
                <div className={styles.cardMedia}>
                  <img src={program.image} alt={program.title} loading="lazy" />
                  <span className={styles.cardTag}>{program.tag}</span>
                </div>
                <div className={styles.cardBody}>
                  <h3>{program.title}</h3>
                  <p>{program.description}</p>
                  <Link to={program.link} className={styles.cardLink}>
                    Discover more
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.journey}>
        <div className="container">
          <div className={styles.sectionIntro}>
            <span className={styles.kicker}>Your language journey</span>
            <h2>Four phases, endless personalization.</h2>
            <p>
              Our methodology combines instructional design, cultural immersion, and reflective coaching to keep progress transparent and energising.
            </p>
          </div>
          <div className={styles.journeyGrid}>
            <article>
              <div className={styles.stepNumber}>01</div>
              <h3>Discovery & diagnostics</h3>
              <p>We capture linguistic goals, map your schedule, and run a diagnostic to understand how you naturally communicate.</p>
            </article>
            <article>
              <div className={styles.stepNumber}>02</div>
              <h3>Designing the blueprint</h3>
              <p>Our academic team curates modules, resources, and coaches who mirror your industry and communication style.</p>
            </article>
            <article>
              <div className={styles.stepNumber}>03</div>
              <h3>Immersive execution</h3>
              <p>Live coaching, digital labs, and cultural fieldwork blend seamlessly. Weekly retrospectives ensure momentum stays high.</p>
            </article>
            <article>
              <div className={styles.stepNumber}>04</div>
              <h3>Performance review & growth</h3>
              <p>We measure outcomes, celebrate milestones, and evolve the roadmap so your fluency keeps pace with your ambitions.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.sectionIntro}>
            <span className={styles.kicker}>Immersive projects</span>
            <h2>Apply language in living laboratories across Europe.</h2>
            <p>
              From Rotterdam shipping terminals to creative studios in Madrid, our projects test your fluency in dynamic, real-world environments.
            </p>
          </div>
          <div className={styles.filterBar} role="toolbar" aria-label="Project filters">
            {projectFilters.map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveProjectFilter(filter)}
                className={activeProjectFilter === filter ? styles.filterActive : ''}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectBody}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.sectionIntro}>
            <span className={styles.kicker}>Meet the mentors</span>
            <h2>Guides who bridge language, culture, and strategy.</h2>
            <p>
              Our Amsterdam-based team unites linguists, former diplomats, and industry specialists who understand what fluency demands today.
            </p>
          </div>
          <div className={styles.teamGrid}>
            <article>
              <img src="https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=400&q=80" alt="Portrait of Mila de Vries, Lead Coach" loading="lazy" />
              <h3>Mila de Vries</h3>
              <p>Lead Coach · Dutch & German</p>
              <span>Former EU policy translator advising leadership teams on cross-border messaging.</span>
            </article>
            <article>
              <img src="https://images.unsplash.com/photo-1524504388940-b1c1722653c4?auto=format&fit=crop&w=400&q=80" alt="Portrait of Gabriel Fernández, Cultural Strategist" loading="lazy" />
              <h3>Gabriel Fernández</h3>
              <p>Cultural Strategist · Spanish & English</p>
              <span>Designs immersive residencies and storytelling labs that anchor language in lived experience.</span>
            </article>
            <article>
              <img src="https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=400&q=80" alt="Portrait of Liling Chen, Corporate Partner Lead" loading="lazy" />
              <h3>Liling Chen</h3>
              <p>Corporate Partner Lead · Mandarin & English</p>
              <span>Architect of multilingual onboarding for technology scale-ups across the Netherlands.</span>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.community}>
        <div className="container">
          <div className={styles.communityGrid}>
            <div className={styles.testimonials} aria-live="polite">
              <span className={styles.kicker}>Voices from the loft</span>
              <h2>Learning that leaves a mark.</h2>
              <article className={styles.testimonialCard}>
                <img src={testimonial.image} alt={testimonial.name} />
                <blockquote>&ldquo;{testimonial.quote}&rdquo;</blockquote>
                <p className={styles.testimonialName}>{testimonial.name}</p>
                <span>{testimonial.role}</span>
              </article>
              <div className={styles.testimonialDots} role="tablist" aria-label="Testimonial selector">
                {testimonials.map((item, index) => (
                  <button
                    key={item.name}
                    type="button"
                    onClick={() => setTestimonialIndex(index)}
                    className={testimonialIndex === index ? styles.dotActive : ''}
                    aria-label={`Show testimonial from ${item.name}`}
                    aria-selected={testimonialIndex === index}
                  />
                ))}
              </div>
            </div>
            <div className={styles.faq}>
              <span className={styles.kicker}>Questions answered</span>
              <h2>Frequently asked exploration.</h2>
              <div className={styles.accordion}>
                {faqItems.map((item, index) => {
                  const isOpen = openFaq === index;
                  return (
                    <div key={item.question} className={`${styles.accordionItem} ${isOpen ? styles.accordionOpen : ''}`}>
                      <button
                        type="button"
                        onClick={() => setOpenFaq(isOpen ? -1 : index)}
                        aria-expanded={isOpen}
                      >
                        {item.question}
                        <span>{isOpen ? '−' : '+'}</span>
                      </button>
                      <div className={styles.accordionContent}>
                        <p>{item.answer}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.blogCta}>
        <div className="container">
          <div className={styles.sectionIntro}>
            <span className={styles.kicker}>Insights & updates</span>
            <h2>Stay inspired between sessions.</h2>
            <p>
              The Language Loft blog explores practical frameworks, cultural nuance, and reflections from our learners across Europe.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPreviews.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogBody}>
                  <span>{post.tag}</span>
                  <h3>{post.title}</h3>
                  <Link to={post.link}>Read article</Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.ctaPanel}>
            <div>
              <h3>Ready to elevate your language practice?</h3>
              <p>Book a discovery session and craft a roadmap that matches your schedule, sector, and aspirations.</p>
            </div>
            <Link to="/contact" className={styles.primaryBtn}>
              Start a conversation
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;