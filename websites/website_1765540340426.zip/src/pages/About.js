import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './About.module.css';

const timeline = [
  {
    year: '2015',
    title: 'Language Loft opens in Amsterdam',
    description: 'Founded by linguists and creatives who believed language learning should feel bespoke, experiential, and joyful.',
  },
  {
    year: '2017',
    title: 'First corporate partnerships',
    description: 'Partnered with Dutch scale-ups expanding across Europe, creating tailored programs for multilingual teams.',
  },
  {
    year: '2020',
    title: 'Virtual loft launch',
    description: 'Built a fully interactive virtual studio to support learners working remotely across time zones.',
  },
  {
    year: '2023',
    title: 'Immersion residencies expand',
    description: 'Introduced cultural residencies in Spain, Germany, and the Nordics to complement our Amsterdam experiences.',
  },
];

const accolades = [
  'Recognised by Amsterdam Education Board for innovative adult learning design (2022)',
  'Winner of the European Language Label for blended learning excellence (2021)',
  'Featured in Dutch Design Week for immersive language residencies (2020)',
];

const About = () => {
  return (
    <div className={`container ${styles.wrapper}`}>
      <PageHelmet
        title="About Language Loft"
        description="Discover Language Loft’s story, mission, and team. Based in the Netherlands, we craft personalised language journeys for global professionals."
        canonical="https://www.example.com/about"
      />
      <header className={styles.header}>
        <h1>Born in Amsterdam. Inspired by global storytellers.</h1>
        <p>
          Language Loft began as a studio for creatives and entrepreneurs who needed language programs tailored to real life. Today we guide professionals, researchers, and teams across the Netherlands and beyond.
        </p>
      </header>

      <section className={styles.mission}>
        <article>
          <h2>Mission</h2>
          <p>
            To design language journeys that empower people to communicate boldly, authentically, and empathetically across cultures.
          </p>
        </article>
        <article>
          <h2>Vision</h2>
          <p>
            A world where language is a catalyst for collaboration, innovation, and belonging—no matter where you call home.
          </p>
        </article>
        <article>
          <h2>Values</h2>
          <ul>
            <li><strong>Personalisation:</strong> Every learner deserves a roadmap crafted around their ambitions.</li>
            <li><strong>Curiosity:</strong> Cultural intelligence is a practice, not a checkbox.</li>
            <li><strong>Craft:</strong> We blend pedagogy, design, and storytelling in every session.</li>
            <li><strong>Community:</strong> Learning accelerates when shared with others.</li>
          </ul>
        </article>
      </section>

      <section className={styles.timeline}>
        <h2>Our journey</h2>
        <div className={styles.timelineGrid}>
          {timeline.map((item) => (
            <article key={item.year}>
              <span>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.accolades}>
        <h2>Accolades</h2>
        <ul>
          {accolades.map((award) => (
            <li key={award}>{award}</li>
          ))}
        </ul>
      </section>

      <section className={styles.callout}>
        <div>
          <h2>Meet us at the loft.</h2>
          <p>
            Visit our canal-side studio in Amsterdam or connect virtually from anywhere in the world. We can’t wait to hear your language story.
          </p>
        </div>
      </section>
    </div>
  );
};

export default About;