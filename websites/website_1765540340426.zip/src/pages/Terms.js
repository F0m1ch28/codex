import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Terms.module.css';

const Terms = () => {
  return (
    <div className={`container ${styles.wrapper}`}>
      <PageHelmet
        title="Language Loft Terms of Service"
        description="Review the Language Loft Terms of Service covering usage, responsibilities, and legal details."
        canonical="https://www.example.com/terms"
      />
      <h1>Terms of Service</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>

      <section>
        <h2>1. Overview</h2>
        <p>
          Language Loft provides language coaching, cultural immersion, and educational resources. By enrolling in our programs or using our services, you agree to the terms outlined below.
        </p>
      </section>

      <section>
        <h2>2. Learner responsibilities</h2>
        <ul>
          <li>Provide accurate information when requesting services.</li>
          <li>Participate actively and respect our coaches and fellow learners.</li>
          <li>Use provided materials for personal learning purposes only.</li>
        </ul>
      </section>

      <section>
        <h2>3. Intellectual property</h2>
        <p>
          All course materials, resources, and website content are owned by Language Loft. You may not reproduce or distribute them without written permission.
        </p>
      </section>

      <section>
        <h2>4. Service adjustments</h2>
        <p>
          We may update program schedules or formats to improve the learner experience. We will communicate any significant changes in advance.
        </p>
      </section>

      <section>
        <h2>5. Contact</h2>
        <p>
          For questions about these terms, please reach out through the contact details listed on our Contact page.
        </p>
      </section>
    </div>
  );
};

export default Terms;