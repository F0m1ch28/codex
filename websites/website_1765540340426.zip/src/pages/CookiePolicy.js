import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => {
  return (
    <div className={`container ${styles.wrapper}`}>
      <PageHelmet
        title="Language Loft Cookie Policy"
        description="Learn how Language Loft uses cookies and similar technologies."
        canonical="https://www.example.com/cookie-policy"
      />
      <h1>Cookie Policy</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>

      <section>
        <h2>1. What are cookies?</h2>
        <p>
          Cookies are small text files placed on your device to help websites function and improve user experience.
        </p>
      </section>

      <section>
        <h2>2. How Language Loft uses cookies</h2>
        <ul>
          <li><strong>Essential cookies:</strong> Keep the site secure and functional.</li>
          <li><strong>Performance cookies:</strong> Help us understand how the site is used so we can improve it.</li>
        </ul>
      </section>

      <section>
        <h2>3. Managing cookies</h2>
        <p>
          You can manage or disable cookies through your browser settings. Note that disabling essential cookies may impact site functionality.
        </p>
      </section>

      <section>
        <h2>4. Updates</h2>
        <p>
          We may update this policy periodically. Changes will be reflected on this page.
        </p>
      </section>
    </div>
  );
};

export default CookiePolicy;