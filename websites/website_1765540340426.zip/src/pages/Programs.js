import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Programs.module.css';

const courses = [
  {
    language: 'Dutch',
    level: 'Beginner · A1-A2',
    format: 'Hybrid cohorts · 12 weeks',
    description: 'Build a confident foundation with practical scenarios, micro-immersion labs, and weekly pronunciation clinics.',
    focus: ['Survival Dutch', 'Workplace basics', 'Cultural etiquette'],
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80',
  },
  {
    language: 'Dutch',
    level: 'Professional · B2-C1',
    format: 'One-to-one · 8+ weeks',
    description: 'Advanced coaching for presentations, negotiations, and stakeholder management in Dutch-speaking environments.',
    focus: ['Executive presence', 'Negotiation role-play', 'Industry vocabulary'],
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=800&q=80',
  },
  {
    language: 'English',
    level: 'Leadership · C1-C2',
    format: 'Small group · 10 weeks',
    description: 'Sharpen executive communication across English-speaking markets with storytelling frameworks and feedback.',
    focus: ['Storytelling', 'Investor communication', 'Cross-cultural nuance'],
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80',
  },
  {
    language: 'German',
    level: 'Professional · B1-B2',
    format: 'Hybrid · 12 weeks',
    description: 'Designed for professionals expanding into German-speaking markets, blending technical terminology with cultural insights.',
    focus: ['Industry terminology', 'Client meetings', 'Cultural intelligence'],
    image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=800&q=80',
  },
  {
    language: 'Spanish',
    level: 'Immersion · Multi-level',
    format: 'Residency · 2 weeks',
    description: 'Live the language across Barcelona and Madrid with curated experiences, partner organisations, and guided reflection.',
    focus: ['Cultural immersion', 'Service design labs', 'Collaborative storytelling'],
    image: 'https://images.unsplash.com/photo-1524169358666-79f22534bc6e?auto=format&fit=crop&w=800&q=80',
  },
  {
    language: 'Mandarin',
    level: 'Strategic · Intermediate',
    format: 'One-to-one · 14 weeks',
    description: 'Navigate Mandarin-speaking markets with modules focused on corporate language, etiquette, and remote collaboration.',
    focus: ['Cross-border meetings', 'Written communication', 'Cultural briefings'],
    image: 'https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&w=800&q=80',
  },
];

const Programs = () => {
  return (
    <div className="container">
      <PageHelmet
        title="Language Loft Programs"
        description="Explore Language Loft language programs across Dutch, English, Spanish, Mandarin, and more—crafted for learners across the Netherlands and Europe."
        canonical="https://www.example.com/programs"
      />
      <header className={styles.header}>
        <span>Programs</span>
        <h1>Choose the language path that grows with you.</h1>
        <p>
          Each Language Loft program blends individual coaching, community labs, and measurable milestones so you can apply language immediately in your world.
        </p>
      </header>

      <section className={styles.grid}>
        {courses.map((course) => (
          <article key={`${course.language}-${course.level}`} className={styles.card}>
            <div className={styles.media}>
              <img src={course.image} alt={`${course.language} program`} loading="lazy" />
              <span>{course.level}</span>
            </div>
            <div className={styles.body}>
              <h2>{course.language}</h2>
              <p className={styles.format}>{course.format}</p>
              <p>{course.description}</p>
              <ul>
                {course.focus.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </section>

      <section className={styles.note}>
        <h2>Need a custom pathway?</h2>
        <p>
          Our academic team designs bespoke programs for organisations, relocating families, and research institutes. Share your context and we will architect the next steps.
        </p>
      </section>
    </div>
  );
};

export default Programs;