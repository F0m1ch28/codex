import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Tools.module.css';

const resources = [
  {
    title: 'Loft Listening Lab',
    description: 'Audio journeys featuring Dutch, English, and German professionals tackling real scenarios with transcripts.',
    type: 'Podcast playlists',
    link: 'https://spotify.com',
  },
  {
    title: 'Conversation Canvas',
    description: 'Printable prompt sheets to practise spontaneous conversations with colleagues and friends.',
    type: 'PDF templates',
    link: 'https://drive.google.com',
  },
  {
    title: 'Vocabulary Builder',
    description: 'Segmented flashcards powered by spaced repetition, curated for business, travel, and academic contexts.',
    type: 'Notion database',
    link: 'https://notion.so',
  },
  {
    title: 'Accent Studio',
    description: 'Guided pronunciation drills with phonetic tips and voice notes from our coaching team.',
    type: 'Audio toolkit',
    link: 'https://soundcloud.com',
  },
  {
    title: 'Cultural Briefings',
    description: 'Quick-read cultural insights spotlighting festivals, etiquette, and communication styles across Europe.',
    type: 'Article series',
    link: '/blog',
  },
  {
    title: 'Daily Reflection Log',
    description: 'Micro-reflection prompts to capture wins, blockers, and new vocabulary every day.',
    type: 'Worksheet',
    link: 'https://drive.google.com',
  },
];

const Tools = () => {
  return (
    <div className="container">
      <PageHelmet
        title="Language Loft Tools"
        description="Access Language Loft’s free resources, templates, and listening labs to accelerate your language learning journey."
        canonical="https://www.example.com/tools"
      />
      <header className={styles.header}>
        <span>Resource hub</span>
        <h1>Tools to extend your momentum between sessions.</h1>
        <p>
          Explore our curated collection of downloads, playlists, and templates designed to reinforce learning wherever you are.
        </p>
      </header>
      <section className={styles.grid}>
        {resources.map((resource) => (
          <article key={resource.title}>
            <div className={styles.badge}>{resource.type}</div>
            <h2>{resource.title}</h2>
            <p>{resource.description}</p>
            <a href={resource.link} target="_blank" rel="noreferrer">
              Access resource
            </a>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Tools;