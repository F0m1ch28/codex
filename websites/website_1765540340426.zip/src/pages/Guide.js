import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Guide.module.css';

const Guide = () => {
  return (
    <div className="container">
      <PageHelmet
        title="Language Loft Course Guide"
        description="Dive into the Language Loft course guide to understand formats, coaching approach, and how to join a cohort tailored to your goals."
        canonical="https://www.example.com/guide"
      />
      <header className={styles.header}>
        <span>Course Guide</span>
        <h1>Your map to Language Loft learning.</h1>
        <p>
          We pair rigorous pedagogy with flexible design, ensuring every learner from the Netherlands and beyond can reach their ambitions without compromising schedule or style.
        </p>
      </header>

      <section className={styles.grid}>
        <article>
          <h2>Program architecture</h2>
          <ul>
            <li>
              <strong>Foundation Labs</strong> — small cohorts (4–6 learners) for rapid skill building, featuring thematic sprints and live labs twice per week.
            </li>
            <li>
              <strong>Coach Sessions</strong> — one-to-one coaching with a lead mentor focused on personalised goals, pronunciation drills, and feedback loops.
            </li>
            <li>
              <strong>Immersion Modules</strong> — curated experiences in Dutch cities and online simulations where learners practice in real contexts.
            </li>
            <li>
              <strong>Reflection Studios</strong> — monthly progress reviews to measure outcomes, adjust pace, and celebrate milestones.
            </li>
          </ul>
        </article>

        <article>
          <h2>Coaching philosophy</h2>
          <p>
            Language Loft coaches blend linguistic expertise with industry insight. We believe fluency is inseparable from context, so each session connects grammar and vocabulary to scenarios you encounter daily.
          </p>
          <p>
            You will receive:
          </p>
          <ol>
            <li>Personalised learning plans updated after each milestone.</li>
            <li>High-touch feedback with annotated recordings and pronunciation notes.</li>
            <li>Access to our Amsterdam loft or virtual studio for collaboration time.</li>
            <li>Optional peer mentoring to keep momentum between sessions.</li>
          </ol>
        </article>

        <article>
          <h2>How to enrol</h2>
          <div className={styles.timeline}>
            <div>
              <span>Step 1</span>
              <h3>Discovery call</h3>
              <p>Book a 30-minute discovery call with our academic team to align on goals, schedule, and language needs.</p>
            </div>
            <div>
              <span>Step 2</span>
              <h3>Diagnostic & design</h3>
              <p>Complete a short diagnostic assessment. We craft a tailored blueprint and recommend start dates.</p>
            </div>
            <div>
              <span>Step 3</span>
              <h3>Onboarding</h3>
              <p>Meet your coach, access resources, and set milestones. Onboarding can be completed in-person or remotely.</p>
            </div>
            <div>
              <span>Step 4</span>
              <h3>Immersion begins</h3>
              <p>Start sessions, receive weekly reflections, and join community events that enrich your practice.</p>
            </div>
          </div>
        </article>
      </section>
    </div>
  );
};

export default Guide;