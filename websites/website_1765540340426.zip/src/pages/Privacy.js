import React from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Privacy.module.css';

const Privacy = () => {
  return (
    <div className={`container ${styles.wrapper}`}>
      <PageHelmet
        title="Language Loft Privacy Policy"
        description="Understand how Language Loft collects, uses, and protects your information."
        canonical="https://www.example.com/privacy"
      />
      <h1>Privacy Policy</h1>
      <p>Last updated: {new Date().toLocaleDateString()}</p>

      <section>
        <h2>1. Data we collect</h2>
        <p>
          We collect information you provide directly, such as your name, contact details, and learning objectives. We also collect limited usage data to improve our services.
        </p>
      </section>

      <section>
        <h2>2. How we use data</h2>
        <ul>
          <li>Deliver and tailor language programs and resources.</li>
          <li>Communicate about sessions, updates, and events.</li>
          <li>Ensure the security and performance of our platforms.</li>
        </ul>
      </section>

      <section>
        <h2>3. Data sharing</h2>
        <p>
          We do not sell your data. We may share information with trusted partners who support our services, always under confidentiality agreements.
        </p>
      </section>

      <section>
        <h2>4. Your rights</h2>
        <p>
          You may request access, correction, or deletion of your personal data. Contact us to exercise these rights.
        </p>
      </section>

      <section>
        <h2>5. Contact</h2>
        <p>
          Questions about this policy? Reach out via the contact information listed on our Contact page.
        </p>
      </section>
    </div>
  );
};

export default Privacy;