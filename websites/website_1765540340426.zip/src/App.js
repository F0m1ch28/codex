import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton, { ScrollRestoration } from './components/ScrollToTop';
import Home from './pages/Home';
import Guide from './pages/Guide';
import Programs from './pages/Programs';
import Tools from './pages/Tools';
import Blog, {
  BlogTipsForBeginners,
  BlogCulturalNotesSpain,
  BlogDutchLanguageHacks,
} from './pages/Blog';
import About from './pages/About';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  return (
    <div className="App">
      <ScrollRestoration />
      <Header />
      <main role="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/guide" element={<Guide />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/tools" element={<Tools />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/tips-for-beginners" element={<BlogTipsForBeginners />} />
          <Route path="/blog/cultural-notes-spain" element={<BlogCulturalNotesSpain />} />
          <Route path="/blog/dutch-language-hacks" element={<BlogDutchLanguageHacks />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </div>
  );
}

export default App;