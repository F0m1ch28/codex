import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'languageLoftCookieConsent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive" aria-label="Cookie consent banner">
      <div className={styles.text}>
        <h4>Cookies for a smoother journey</h4>
        <p>
          We use essential cookies to understand how learners engage with Language Loft and to keep the experience secure.
        </p>
      </div>
      <button type="button" onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;