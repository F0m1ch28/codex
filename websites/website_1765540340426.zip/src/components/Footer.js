import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.grid}`}>
        <div className={styles.brand}>
          <h3>Language Loft</h3>
          <p>
            Crafted in the Netherlands, Language Loft connects ambitious learners with expert coaches and real-world language experiences.
          </p>
          <div className={styles.socials} aria-label="Social media links">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              in
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
              ig
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
              yt
            </a>
          </div>
        </div>
        <div>
          <h4>Explore</h4>
          <nav className={styles.links} aria-label="Footer navigation">
            <NavLink to="/guide">Course Guide</NavLink>
            <NavLink to="/programs">Programs</NavLink>
            <NavLink to="/tools">Learning Tools</NavLink>
            <NavLink to="/blog">Blog</NavLink>
          </nav>
        </div>
        <div>
          <h4>About</h4>
          <nav className={styles.links} aria-label="About navigation">
            <NavLink to="/about">Our Story</NavLink>
            <NavLink to="/contact">Contact</NavLink>
            <NavLink to="/terms">Terms of Service</NavLink>
            <NavLink to="/privacy">Privacy Policy</NavLink>
            <NavLink to="/cookie-policy">Cookie Policy</NavLink>
          </nav>
        </div>
        <div>
          <h4>Newsletter</h4>
          <p>Receive monthly language insights, cultural spotlights, and learning resources curated by our team.</p>
          <form className={styles.newsletter} onSubmit={(event) => event.preventDefault()}>
            <label htmlFor="footer-email" className="visuallyHidden">
              Email address
            </label>
            <input id="footer-email" type="email" placeholder="you@example.com" required />
            <button type="submit">Subscribe</button>
          </form>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Language Loft. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;