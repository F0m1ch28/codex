document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = siteNav.classList.toggle("open");
      navToggle.classList.toggle("active", isOpen);
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        siteNav.classList.remove("open");
        navToggle.classList.remove("active");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  const observedElements = document.querySelectorAll(".observed");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.18 }
    );
    observedElements.forEach((el) => observer.observe(el));
  } else {
    observedElements.forEach((el) => el.classList.add("visible"));
  }

  const COOKIE_KEY = "bf_cookie_choice";
  const banner = document.querySelector(".cookie-banner");
  if (banner) {
    const storedChoice = localStorage.getItem(COOKIE_KEY);
    if (!storedChoice) {
      banner.classList.add("show");
      banner.setAttribute("aria-hidden", "false");
    } else {
      banner.setAttribute("aria-hidden", "true");
    }
    banner.querySelectorAll("button[data-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        const choice = button.getAttribute("data-choice");
        localStorage.setItem(COOKIE_KEY, choice);
        banner.classList.remove("show");
        banner.setAttribute("aria-hidden", "true");
      });
    });
  }

  const toast = document.getElementById("global-toast");
  const forms = document.querySelectorAll("form[data-redirect]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const redirectUrl = form.getAttribute("data-redirect") || "thank-you.html";
      if (toast) {
        toast.textContent = "Your message has been received.";
        toast.classList.add("show");
        toast.setAttribute("aria-hidden", "false");
        setTimeout(() => {
          toast.classList.remove("show");
          toast.setAttribute("aria-hidden", "true");
        }, 3200);
      }
      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 1600);
    });
  });

  const yearSpan = document.getElementById("current-year");
  if (yearSpan) {
    yearSpan.textContent = String(new Date().getFullYear());
  }
});