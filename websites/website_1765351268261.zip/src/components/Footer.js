import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <div className={styles.logo}>DigitalCovers</div>
            <p>
              Цифровой маркетплейс премиальной графики. Создаем визуальную идентичность для креаторов, брендов и
              студий по всему миру.
            </p>
            <p className={styles.email}>
              <a href="mailto:support@digitalcovers.com">support@digitalcovers.com</a>
            </p>
          </div>
          <div>
            <h4>Навигация</h4>
            <ul>
              <li>
                <Link to="/catalog">Каталог</Link>
              </li>
              <li>
                <Link to="/about">О нас</Link>
              </li>
              <li>
                <Link to="/services">Сервисы</Link>
              </li>
              <li>
                <Link to="/contact">Контакты</Link>
              </li>
              <li>
                <Link to="/faq">FAQ</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>Юридическая информация</h4>
            <ul>
              <li>
                <Link to="/terms">Условия использования</Link>
              </li>
              <li>
                <Link to="/privacy">Политика конфиденциальности</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Политика cookie</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>Оставайтесь на связи</h4>
            <p>Подпишитесь на обновления, чтобы получать свежие релизы и идеи для вашего контента.</p>
            <form className={styles.newsletter} onSubmit={(e) => e.preventDefault()}>
              <input type="email" name="newsletter-email" placeholder="Ваш email" aria-label="Email для подписки" />
              <button type="submit">Подписаться</button>
            </form>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} DigitalCovers. Все права защищены.</p>
          <p>Создаем визуальные истории для глобальной аудитории.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;