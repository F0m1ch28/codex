import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => setMenuOpen((prev) => !prev);
  const handleClose = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className="container">
        <div className={styles.wrapper}>
          <Link to="/" className={styles.logo} onClick={handleClose}>
            <span aria-hidden="true">🎨</span>
            <span className={styles.logoText}>DigitalCovers</span>
          </Link>
          <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Главная навигация">
            <NavLink
              to="/"
              className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
              onClick={handleClose}
            >
              Главная
            </NavLink>
            <NavLink
              to="/catalog"
              className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
              onClick={handleClose}
            >
              Каталог
            </NavLink>
            <NavLink
              to="/about"
              className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
              onClick={handleClose}
            >
              О нас
            </NavLink>
            <NavLink
              to="/contact"
              className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
              onClick={handleClose}
            >
              Контакты
            </NavLink>
            <NavLink
              to="/faq"
              className={({ isActive }) => (isActive ? `${styles.navLink} ${styles.active}` : styles.navLink)}
              onClick={handleClose}
            >
              FAQ
            </NavLink>
          </nav>
          <div className={styles.actions}>
            <button className={styles.cartButton} type="button" aria-label="Избранное">
              <span aria-hidden="true">★</span>
            </button>
            <button
              className={`${styles.menuToggle} ${menuOpen ? styles.menuOpen : ''}`}
              type="button"
              onClick={handleToggle}
              aria-expanded={menuOpen}
              aria-controls="primary-navigation"
            >
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;