import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'digitalcovers_cookie_choice';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedChoice = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (!storedChoice) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem(STORAGE_KEY, choice);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Мы используем файлы cookie для улучшения работы сайта.{' '}
          <Link to="/cookie-policy">Узнать больше</Link>
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleChoice('declined')} className={styles.decline}>
            Отклонить
          </button>
          <button type="button" onClick={() => handleChoice('accepted')} className={styles.accept}>
            Принять
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;