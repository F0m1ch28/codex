const products = [
  {
    id: 'custom-youtube-thumbnail',
    name: 'Авторская миниатюра YouTube',
    price: '19',
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/5720566/pexels-photo-5720566.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1',
      'https://images.pexels.com/photos/6686456/pexels-photo-6686456.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1',
      'https://images.pexels.com/photos/4348403/pexels-photo-4348403.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1'
    ],
    description:
      'Создайте вау-эффект для вашего видео с полностью адаптируемой миниатюрой. Слои в PSD, проработанная типографика и яркая композиция.',
    features: [
      'Формат PSD + JPG в высоком разрешении',
      'Руководство по настройке текста и цветовых акцентов',
      'Подходит для роликов любого жанра: обзоры, стримы, интервью'
    ],
    tags: ['Миниатюры YouTube', 'Видео', 'PSD'],
    category: 'Миниатюры YouTube'
  },
  {
    id: 'stream-overlay-pack',
    name: 'Пакет графики для стрима',
    price: '29',
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/3394327/pexels-photo-3394327.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1',
      'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1'
    ],
    description:
      'Комплект оверлеев, экранов паузы, алертов и панелей для Twitch и YouTube Gaming. Современная неоновая эстетика и адаптация под мобильные стримы.',
    features: [
      '12 готовых сцен для OBS и Streamlabs',
      'Векторные файлы для кастомизации',
      'Шрифтовой пакет в комплекте'
    ],
    tags: ['Стрим', 'Оверлей', 'Неон'],
    category: 'Баннеры для стримов'
  },
  {
    id: 'avatar-pack-pro',
    name: 'Набор аватарок Creator Pro',
    price: '15',
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/6953872/pexels-photo-6953872.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1',
      'https://images.pexels.com/photos/8140574/pexels-photo-8140574.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1'
    ],
    description:
      '10 стильных аватарок в трендовом градиентном стиле. Оптимизированы под Twitch, Discord, Telegram и другие платформы.',
    features: [
      'Форматы PNG и SVG',
      'Цветовые схемы в 3 вариантах',
      'Готово к публикации без доработок'
    ],
    tags: ['Аватарки', 'Соцсети', 'PNG'],
    category: 'Аватарки'
  },
  {
    id: 'social-media-kit',
    name: 'Social Media Starter Kit',
    price: '24',
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/3184634/pexels-photo-3184634.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1',
      'https://images.pexels.com/photos/4050347/pexels-photo-4050347.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1'
    ],
    description:
      'Универсальный пак шаблонов для Instagram, TikTok и VK. Включает сторис, посты, обложки для хайлайтов и баннеры.',
    features: [
      '30 дизайнерских макетов в Figma',
      'Текстовые стили и сетки для адаптивного дизайна',
      'Руководство по брендингу и запуску'
    ],
    tags: ['Соцсети', 'Шаблоны', 'Figma'],
    category: 'Для социальных сетей'
  },
  {
    id: 'podcast-cover-series',
    name: 'Серия обложек для подкаста',
    price: '18',
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/6476588/pexels-photo-6476588.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1',
      'https://images.pexels.com/photos/5908227/pexels-photo-5908227.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1'
    ],
    description:
      'Серия обложек для эпизодов подкаста в стиле «нейроджаз». Деликатная типографика и абстрактные формы для Apple Podcasts и Spotify.',
    features: [
      'PSD + PNG + JPEG',
      'Готовые цветовые палитры под разные темы',
      'Подходит для цикличных выпусков'
    ],
    tags: ['Подкаст', 'Обложки', 'Музыка'],
    category: 'Обложки для видео'
  },
  {
    id: 'youtube-banner-ultimate',
    name: 'YouTube Banner Ultimate',
    price: '17',
    currency: 'USD',
    images: [
      'https://images.pexels.com/photos/7567430/pexels-photo-7567430.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1',
      'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1'
    ],
    description:
      'Готовый баннер для YouTube-канала с адаптивными зонами для мобильных и телевизионных экранов. Современный тех-стиль с динамическими формами.',
    features: [
      'Слои для логотипа и CTA',
      'Тёмная и светлая версия',
      'Руководство по публикации'
    ],
    tags: ['YouTube', 'Баннер', 'Канал'],
    category: 'Обложки для видео'
  }
];

export default products;