import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Contact.module.css';

const Contact = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const nextErrors = {};
    if (!formState.name.trim()) {
      nextErrors.name = 'Пожалуйста, укажите имя.';
    }
    if (!formState.email.trim()) {
      nextErrors.email = 'Введите актуальный email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email)) {
      nextErrors.email = 'Похоже, в email ошибка.';
    }
    if (formState.message.trim().length < 10) {
      nextErrors.message = 'Расскажите подробнее о запросе (минимум 10 символов).';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    setSubmitted(true);
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Seo
        title="Контакты — DigitalCovers"
        description="Свяжитесь с командой DigitalCovers: помощь, кастомные проекты, партнерство. Заполните форму и получите ответ в течение 24 часов."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Свяжитесь с нами</h1>
          <p>
            Нужна кастомная графика, подписка или партнерство? Напишите нам — мы ответим в течение 24 часов.
          </p>
          <p className={styles.email}>
            Email поддержки: <a href="mailto:support@digitalcovers.com">support@digitalcovers.com</a>
          </p>
        </div>
      </section>

      <section className={styles.contactSection}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Чем мы можем помочь</h2>
              <ul>
                <li>Подбор готовых шаблонов под вашу тематику.</li>
                <li>Расчет стоимости кастомного проекта.</li>
                <li>Вопросы по лицензиям, платежам и подписке.</li>
                <li>Партнерские программы и коллаборации.</li>
              </ul>
              <p>
                Мы работаем с клиентами по всему миру. Напишите нам на английском или русском — команда ответит в
                удобное вам время.
              </p>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label htmlFor="name">
                Имя
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formState.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </label>
              <label htmlFor="email">
                Email
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formState.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </label>
              <label htmlFor="message">
                Сообщение
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formState.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </label>
              <button type="submit" className={styles.submitButton}>
                Отправить сообщение
              </button>
              {submitted && (
                <p className={styles.success}>
                  Спасибо! Ваш запрос отправлен. Мы свяжемся с вами по email support@digitalcovers.com.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;