import React from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './Services.module.css';

const Services = () => {
  const services = [
    {
      title: 'Premium Custom Design',
      description:
        'Разработка уникальной визуальной коммуникации: от логотипов до рекламных сетов с учетом вашей воронки и KPI.',
      image: 'https://picsum.photos/800/600?random=61'
    },
    {
      title: 'Контент-студия по подписке',
      description:
        'Команда DigitalCovers создает миниатюры, баннеры и сторис на ежемесячной основе. Вы выбираете пакет — мы берем дизайн на себя.',
      image: 'https://picsum.photos/800/600?random=62'
    },
    {
      title: 'Аудит и оптимизация',
      description:
        'Анализируем CTR, вовлеченность и ретеншн, тестируем визуальные гипотезы и создаем чек-листы для вашего контента.',
      image: 'https://picsum.photos/800/600?random=63'
    }
  ];

  const process = [
    'Диагностика: изучаем нишу, аудиторию и визуальное окружение.',
    'Концепция: формируем moodboard, палитры, типографику.',
    'Продакшн: создаем графику, адаптируем под ключевые платформы.',
    'Внедрение: сопровождаем запуск и проверяем метрики.'
  ];

  return (
    <>
      <Seo
        title="Сервисы DigitalCovers"
        description="Индивидуальный дизайн, подписка на визуальный контент и аналитика. Узнайте больше о профессиональных сервисах DigitalCovers."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Сервисы DigitalCovers</h1>
          <p>
            Нужны уникальные решения? Мы разрабатываем визуальные системы, сопровождаем запуск и помогаем управлять
            контентом в долгую.
          </p>
          <Link to="/contact" className={styles.ctaButton}>
            Запросить коммерческое предложение
          </Link>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <img src={service.image} alt={service.title} />
                <div className={styles.cardContent}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <h2>Как мы работаем</h2>
          <ol>
            {process.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>
        </div>
      </section>
    </>
  );
};

export default Services;