import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';
import Seo from '../components/Seo';
import products from '../data/products';

const Home = () => {
  const featuredProducts = products.slice(0, 4);

  const categories = [
    {
      name: 'Обложки для видео',
      description: 'Яркие превью для YouTube, подкастов и курсов.',
      icon: '🎬',
      link: '/catalog?category=Обложки для видео'
    },
    {
      name: 'Аватарки',
      description: 'Сочные аватары для стримингов и соцсетей.',
      icon: '🧑‍💻',
      link: '/catalog?category=Аватарки'
    },
    {
      name: 'Баннеры для стримов',
      description: 'Оверлеи, алерты и панели для трансляций.',
      icon: '📡',
      link: '/catalog?category=Баннеры для стримов'
    },
    {
      name: 'Миниатюры YouTube',
      description: 'Кликабельные PSD-макеты в трендах платформы.',
      icon: '🔥',
      link: '/catalog?category=Миниатюры YouTube'
    },
    {
      name: 'Для социальных сетей',
      description: 'Посты, сторис и карусели под любой формат.',
      icon: '🌐',
      link: '/catalog?category=Для социальных сетей'
    }
  ];

  const stats = [
    { value: '12K+', label: 'готовых дизайнов' },
    { value: '78', label: 'категорий контента' },
    { value: '5M+', label: 'просмотров с нашими обложками' },
    { value: '98%', label: 'довольных клиентов' }
  ];

  const steps = [
    {
      title: 'Выберите дизайн',
      text: 'Изучите каталог и подберите стиль под ваш контент.'
    },
    {
      title: 'Персонализируйте',
      text: 'Корректируйте цвета, текст и элементы под бренд.'
    },
    {
      title: 'Скачайте файлы',
      text: 'Получите готовые к публикации форматы без водяных знаков.'
    }
  ];

  const benefits = [
    {
      title: 'Высокое качество',
      text: 'Каждый шаблон собирается дизайнерами с опытом в digital-продвижении и тестируется на разных устройствах.'
    },
    {
      title: 'Быстрая загрузка',
      text: 'Сразу после оплаты вы получаете доступ к ZIP-архиву, а также инструкции по адаптации.'
    },
    {
      title: 'Живая поддержка',
      text: 'Команда помощи ответит на вопросы по адаптации и использованию в течение 24 часов.'
    },
    {
      title: 'Новые релизы каждую неделю',
      text: 'Мы отслеживаем тренды YouTube, Twitch, Instagram и регулярно обновляем коллекции.'
    }
  ];

  const testimonials = [
    {
      name: 'Алексей Ветров',
      role: 'YouTube-продюсер',
      quote:
        'DigitalCovers значительно ускорил подготовку выпуска. Миниатюры в их стиле дают заметный рост CTR и удержание зрителей.',
      photo: 'https://picsum.photos/200/200?random=21'
    },
    {
      name: 'NOVA Stream',
      role: 'Стриминговая студия',
      quote:
        'Оверлеи легко адаптировались под бренд-цвета и язык трансляций. Отличное соотношение цены и качества.',
      photo: 'https://picsum.photos/200/200?random=22'
    },
    {
      name: 'Мария Грацио',
      role: 'Маркетолог',
      quote:
        'Наборы для соцсетей продуманы под реальные сценарии промо. Нам остается только вставить текст и выгружать.',
      photo: 'https://picsum.photos/200/200?random=23'
    }
  ];

  const team = [
    {
      name: 'Ева Руденко',
      role: 'Creative Director',
      bio: '10 лет в motion & branding, ex-YouTube Originals.',
      photo: 'https://picsum.photos/400/400?random=24'
    },
    {
      name: 'Даниил Беккер',
      role: 'Lead Designer',
      bio: 'Специалист по стриминговой графике, работал с ESL и Riot.',
      photo: 'https://picsum.photos/400/400?random=25'
    },
    {
      name: 'София Йонс',
      role: 'Head of Community',
      bio: 'Запускает кампании с инфлюенсерами и поддерживает авторов.',
      photo: 'https://picsum.photos/400/400?random=26'
    }
  ];

  const projects = [
    {
      title: 'GameWave Streams',
      description: 'Полный пакет оверлеев и экранов для киберспортивной студии.',
      image: 'https://picsum.photos/1200/800?random=27'
    },
    {
      title: 'DocuTalk Podcast',
      description: 'Серия обложек и шаблонов сторис для документального подкаста.',
      image: 'https://picsum.photos/1200/800?random=28'
    },
    {
      title: 'Creators Hub',
      description: 'Корпоративный набор для обучения создателей контента.',
      image: 'https://picsum.photos/1200/800?random=29'
    }
  ];

  const blogPosts = [
    {
      title: '7 трендов YouTube-миниатюр на 2024',
      excerpt: 'Как сочетать жирную типографику и кинематографичные кадры, чтобы выделиться среди рекомендаций.',
      image: 'https://picsum.photos/800/600?random=31'
    },
    {
      title: 'Гайд: визуальный стиль стрима за 30 минут',
      excerpt: 'Пошаговый план создания брендового набора графики для Twitch и YouTube Live.',
      image: 'https://picsum.photos/800/600?random=32'
    },
  {
      title: 'Соцсети без дизайнеров: как шablony помогают расти',
      excerpt: 'Сценарии использования готовых шаблонов для запуска промо-кампаний в Instagram и VK.',
      image: 'https://picsum.photos/800/600?random=33'
    }
  ];

  const faqPreview = [
    {
      question: 'Можно ли редактировать файлы?',
      answer:
        'Да, большинство шаблонов поставляются в форматах PSD, Figma или AI. Мы прикладываем инструкцию по настройке.'
    },
    {
      question: 'Какая лицензия?',
      answer:
        'Вы получаете коммерческую лицензию на использование в рамках вашего проекта без права перепродажи исходников.'
    },
    {
      question: 'Что если нужен кастомный дизайн?',
      answer:
        'Заполните бриф в разделе «Контакты», и мы предложим персональный пакет услуг и сроки.'
    }
  ];

  return (
    <>
      <Seo
        title="DigitalCovers — премиум графика для вашего контента"
        description="Выбирайте и скачивайте готовые обложки, аватарки, баннеры и шаблоны для YouTube, стримов и социальных сетей. DigitalCovers — профессиональный маркетплейс цифровой графики."
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.badge}>Маркетплейс №1 для креаторов</p>
            <h1>Премиум графика для вашего контента</h1>
            <p className={styles.subtitle}>
              Готовые шаблоны, кастомные пакеты и дизайны, созданные профессионалами с опытом работы в YouTube,
              Twitch и международных агентствах.
            </p>
            <div className={styles.heroActions}>
              <Link to="/catalog" className={styles.primaryButton}>
                Смотреть каталог
              </Link>
              <Link to="/services" className={styles.secondaryButton}>
                Узнать о сервисах
              </Link>
            </div>
          </div>
          <div className={styles.heroVisual} aria-hidden="true">
            <img
              src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1200&h=900&dpr=1"
              alt="Дизайнер работает над цифровой обложкой"
            />
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {stats.map((item) => (
              <div key={item.label} className={styles.statCard}>
                <span>{item.value}</span>
                <p>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Категории каталога</h2>
            <p>Подберите формат под ваш контент: от стримов до лонгридов в соцсетях.</p>
          </header>
          <div className={styles.categoriesGrid}>
            {categories.map((category) => (
              <Link to={category.link} key={category.name} className={styles.categoryCard}>
                <span className={styles.categoryIcon} aria-hidden="true">
                  {category.icon}
                </span>
                <h3>{category.name}</h3>
                <p>{category.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.featuredSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Популярные релизы недели</h2>
            <p>Релизы, которые вдохновляют тысячи креаторов по всему миру.</p>
          </header>
          <div className={styles.featuredGrid}>
            {featuredProducts.map((product) => (
              <article key={product.id} className={styles.productCard}>
                <div className={styles.productImage}>
                  <img src={product.images[0]} alt={product.name} />
                </div>
                <div className={styles.productContent}>
                  <span className={styles.categoryTag}>{product.category}</span>
                  <h3>{product.name}</h3>
                  <p>{product.description}</p>
                  <div className={styles.cardFooter}>
                    <span className={styles.price}>
                      {product.price} {product.currency}
                    </span>
                    <Link to={`/product/${product.id}`} className={styles.moreLink}>
                      Подробнее →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.howItWorksSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Как это работает</h2>
            <p>Три шага, чтобы получить безупречный визуал.</p>
          </header>
          <div className={styles.stepsGrid}>
            {steps.map((step, index) => (
              <div key={step.title} className={styles.stepCard}>
                <span className={styles.stepNumber}>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.benefitsSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Почему DigitalCovers?</h2>
            <p>Мы усиливаем ваш бренд визуально и стратегически.</p>
          </header>
          <div className={styles.benefitsGrid}>
            {benefits.map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <h3>{benefit.title}</h3>
                <p>{benefit.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.servicesSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Сервисы и кастомизация</h2>
            <p>Поддержка бренда на каждом этапе — от идеи до измеримого результата.</p>
          </header>
          <div className={styles.servicesGrid}>
            <article className={styles.serviceCard}>
              <img
                src="https://picsum.photos/600/400?random=41"
                alt="Команда разрабатывает брендбук"
              />
              <div className={styles.serviceContent}>
                <h3>Индивидуальный брендинг</h3>
                <p>
                  Дизайн обложек, сетов для стримов и соцсетей, полностью адаптированных под голос и стратегию вашего
                  бренда.
                </p>
                <Link to="/services" className={styles.moreLink}>
                  Узнать больше
                </Link>
              </div>
            </article>
            <article className={styles.serviceCard}>
              <img
                src="https://picsum.photos/600/400?random=42"
                alt="Рабочее место для создания контента"
              />
              <div className={styles.serviceContent}>
                <h3>Контент на подписке</h3>
                <p>
                  Подготовка пакетов визуала на месяц вперед: миниатюры, сторис, рекламные баннеры. Выбор тарифов под
                  объем команды.
                </p>
                <Link to="/contact" className={styles.moreLink}>
                  Связаться с нами
                </Link>
              </div>
            </article>
            <article className={styles.serviceCard}>
              <img
                src="https://picsum.photos/600/400?random=43"
                alt="Аналитика эффективности контента"
              />
              <div className={styles.serviceContent}>
                <h3>Аналитика и оптимизация</h3>
                <p>
                  Аудит визуальной коммуникации, тестирование миниатюр и рекомендации по повышению CTR и удержанию.
                </p>
                <Link to="/services" className={styles.moreLink}>
                  Посмотреть кейсы
                </Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Отзывы клиентов</h2>
            <p>Мы работаем с креаторами, агентствами и корпоративными командами по всему миру.</p>
          </header>
          <div className={styles.testimonialsGrid}>
            {testimonials.map((testimonial) => (
              <article key={testimonial.name} className={styles.testimonialCard}>
                <img src={testimonial.photo} alt={`Отзыв от ${testimonial.name}`} />
                <p className={styles.quote}>“{testimonial.quote}”</p>
                <div className={styles.author}>
                  <span>{testimonial.name}</span>
                  <span>{testimonial.role}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Команда</h2>
            <p>Команда DigitalCovers — это дизайнеры, продюсеры и аналитики с опытом в крупнейших медиа.</p>
          </header>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.photo} alt={member.name} />
                <div>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Недавние проекты</h2>
            <p>Коллаборации, которые помогли брендам усилить визуальное присутствие онлайн.</p>
          </header>
          <div className={styles.projectsGrid}>
            {projects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} />
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>Популярные вопросы</h2>
            <p>Краткие ответы на основные вопросы о покупке и использовании файлов.</p>
          </header>
          <div className={styles.faqGrid}>
            {faqPreview.map((item) => (
              <div key={item.question} className={styles.faqCard}>
                <h3>{item.question}</h3>
                <p>{item.answer}</p>
              </div>
            ))}
          </div>
          <div className={styles.faqCta}>
            <Link to="/faq" className={styles.primaryButton}>
              Открыть полный FAQ
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <h2>DigitalCovers Insights</h2>
            <p>Гайды и аналитика для развития вашего визуального бренда.</p>
          </header>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/catalog" className={styles.moreLink}>
                    Читать →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Готовы к следующему релизу?</h2>
            <p>
              Соберите комплект обложек и баннеров за несколько минут или закажите кастомный визуал у нашей команды.
            </p>
            <div className={styles.ctaActions}>
              <Link to="/catalog" className={styles.primaryButtonAlt}>
                Перейти в каталог
              </Link>
              <Link to="/contact" className={styles.secondaryButtonLight}>
                Связаться с дизайнером
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;