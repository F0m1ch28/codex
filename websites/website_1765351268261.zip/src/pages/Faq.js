import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './Faq.module.css';

const questions = [
  {
    question: 'Какая лицензия предоставляется?',
    answer:
      'Вы получаете коммерческую лицензию на использование графики в рамках вашего проекта или бренда. Запрещено перепродавать файлы или распространять их в открытом доступе.'
  },
  {
    question: 'Можно ли вернуть покупку?',
    answer:
      'Поскольку продукт цифровой и моментально скачивается, возвраты не предусмотрены. Если возникла техническая проблема, свяжитесь с поддержкой — мы поможем.'
  },
  {
    question: 'Как я получу файлы?',
    answer:
      'После оплаты на email придёт ссылка на скачивание архива. Также файл доступен в личном кабинете по заказу.'
  },
  {
    question: 'Подходит ли графика для мобильных устройств?',
    answer:
      'Да, мы тестируем каждый шаблон на разных разрешениях, включая мобильные и телевизионные версии YouTube, Twitch и соцсетей.'
  },
  {
    question: 'Что делать, если нужно изменить текст или цвета?',
    answer:
      'В комплекте лежит инструкция по редактированию. Вы можете менять слои в Photoshop, Figma или Illustrator в зависимости от формата.'
  },
  {
    question: 'Можно заказать эксклюзив под ключ?',
    answer:
      'Да, заполните форму на странице «Контакты». Мы соберем бриф, предложим концепции и подготовим смету.'
  },
  {
    question: 'Есть ли подписка?',
    answer:
      'Да, у нас есть месячные и квартальные подписки на создание миниатюр, баннеров и соцсетей. Напишите нам для деталей.'
  },
  {
    question: 'Какие способы оплаты доступны?',
    answer:
      'Мы принимаем банковские карты, PayPal и корпоративные счёта через выставление инвойса.'
  }
];

const Faq = () => {
  const [openedIndex, setOpenedIndex] = useState(0);

  return (
    <>
      <Seo
        title="FAQ — DigitalCovers"
        description="Ответы на вопросы о покупке цифровых шаблонов, лицензии, подписках и кастомных заказах в DigitalCovers."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Часто задаваемые вопросы</h1>
          <p>Собрали ключевые ответы по покупке, лицензиям и работе с нашей командой.</p>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.accordion}>
            {questions.map((item, index) => (
              <div key={item.question} className={styles.item}>
                <button
                  type="button"
                  onClick={() => setOpenedIndex(openedIndex === index ? -1 : index)}
                  className={styles.trigger}
                  aria-expanded={openedIndex === index}
                >
                  <span>{item.question}</span>
                  <span aria-hidden="true">{openedIndex === index ? '−' : '+'}</span>
                </button>
                {openedIndex === index && <p className={styles.answer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Faq;