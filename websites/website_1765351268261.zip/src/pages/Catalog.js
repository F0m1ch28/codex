import React, { useMemo, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Seo from '../components/Seo';
import products from '../data/products';
import styles from './Catalog.module.css';

const Catalog = () => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const initialFilter = params.get('category') || 'Все';
  const [activeFilter, setActiveFilter] = useState(initialFilter);

  const categories = useMemo(() => {
    const unique = new Set(products.map((product) => product.category));
    return ['Все', ...Array.from(unique)];
  }, []);

  const filteredProducts = useMemo(() => {
    if (activeFilter === 'Все') {
      return products;
    }
    return products.filter((product) => product.category === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <Seo
        title="Каталог цифровых дизайнов — DigitalCovers"
        description="Просматривайте каталог готовых обложек, миниатюр и графических пакетов. Удобные фильтры по категориям и форматам."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Каталог DigitalCovers</h1>
          <p>
            Выберите категорию и найдите графику, которая усилит контент — от миниатюр YouTube до комплексных пакетов
            для социальных сетей.
          </p>
        </div>
      </section>

      <section className={styles.filtersSection}>
        <div className="container">
          <div className={styles.filters}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${activeFilter === category ? styles.active : ''}`}
                onClick={() => setActiveFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.productsSection}>
        <div className="container">
          <div className={styles.grid}>
            {filteredProducts.map((product) => (
              <article key={product.id} className={styles.card}>
                <img src={product.images[0]} alt={product.name} />
                <div className={styles.cardContent}>
                  <span className={styles.category}>{product.category}</span>
                  <h2>{product.name}</h2>
                  <p>{product.description}</p>
                  <div className={styles.cardFooter}>
                    <span className={styles.price}>
                      {product.price} {product.currency}
                    </span>
                    <Link to={`/product/${product.id}`} className={styles.link}>
                      Подробнее
                    </Link>
                  </div>
                  <div className={styles.tags}>
                    {product.tags.map((tag) => (
                      <span key={tag}>#{tag}</span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
          {filteredProducts.length === 0 && (
            <p className={styles.empty}>По выбранному фильтру пока нет материалов. Попробуйте другую категорию.</p>
          )}
        </div>
      </section>
    </>
  );
};

export default Catalog;