import React from 'react';
import Seo from '../components/Seo';
import styles from './About.module.css';

const About = () => {
  return (
    <>
      <Seo
        title="О компании DigitalCovers"
        description="DigitalCovers — команда дизайнеров и стратегов, создающих премиальные шаблоны и кастомные решения для креаторов и брендов."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>О нас</h1>
          <p>
            DigitalCovers — это команда дизайнеров, продюсеров и аналитиков, которые объединяют опыт телевизионного
            продакшена, гейм-индустрии и цифрового маркетинга. Мы создаем визуальные решения, которые помогают контенту
            расти.
          </p>
        </div>
      </section>

      <section className={styles.mission}>
        <div className="container">
          <div className={styles.missionGrid}>
            <article>
              <h2>Миссия</h2>
              <p>
                Мы хотим, чтобы каждый автор чувствовал уверенность в своем визуале. Независимо от бюджета и команды,
                у вас должны быть инструменты, которые выделяют ваш контент.
              </p>
            </article>
            <article>
              <h2>История</h2>
              <p>
                DigitalCovers родился на пересечении творческой студии и продюсерского центра. Мы начали с кастомных
                проектов для YouTube-шоу и стриминговых площадок, а затем упаковали лучшие практики в готовые наборы.
              </p>
            </article>
            <article>
              <h2>Ценности</h2>
              <p>
                Прозрачность, уважение к авторскому праву и ориентация на результат. Мы не просто продаем файлы, а
                сопровождаем клиентов до достижения KPI.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.timeline}>
        <div className="container">
          <h2>Как мы росли</h2>
          <div className={styles.timelineList}>
            <div>
              <span>2018</span>
              <p>Запуск студии и первые проекты для образовательных YouTube-каналов.</p>
            </div>
            <div>
              <span>2019</span>
              <p>Выход на стриминговый рынок: оформление турниров и шоу-матчей.</p>
            </div>
            <div>
              <span>2021</span>
              <p>Открытие маркетплейса цифровой графики для глобальной аудитории.</p>
            </div>
            <div>
              <span>2023</span>
              <p>Запуск подписки на визуальный контент и аналитики для брендов.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.valuesGrid}>
            <article>
              <h3>Глобальный подход</h3>
              <p>Наши шаблоны учитывают особенности платформ и культур разных регионов.</p>
            </article>
            <article>
              <h3>Техническая точность</h3>
              <p>Следим за требованиями к размерам файлов, безопасным зонам и читаемости текста.</p>
            </article>
            <article>
              <h3>Комьюнити</h3>
              <p>Создаем закрытые встречи и воркшопы для авторов, делимся аналитикой трендов.</p>
            </article>
            <article>
              <h3>Экологичный дизайн</h3>
              <p>Оптимизируем графику так, чтобы она быстро загружалась и не перегружала устройства.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.imageSection}>
        <div className="container">
          <div className={styles.imageWrapper}>
            <img
              src="https://picsum.photos/1600/900?random=51"
              alt="Команда DigitalCovers на мозговом штурме"
            />
          </div>
          <div className={styles.caption}>
            DigitalCovers объединяет креатив и аналитический подход, чтобы ваш контент входил в рекомендации и оставался
            узнаваемым.
          </div>
        </div>
      </section>
    </>
  );
};

export default About;