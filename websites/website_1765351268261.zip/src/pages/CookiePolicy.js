import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Seo
      title="Политика использования файлов cookie — DigitalCovers"
      description="Подробности о том, какие cookie-файлы использует DigitalCovers и как управлять вашими настройками."
    />
    <section className={styles.page}>
      <div className="container">
        <h1>Политика использования файлов cookie</h1>
        <p className={styles.updated}>Обновлено: 15 апреля 2024</p>

        <article>
          <h2>1. Что такое cookie</h2>
          <p>
            Cookie — небольшие текстовые файлы, которые сохраняются на вашем устройстве при посещении сайта. Они помогают
            нам анализировать поведение, запоминать настройки и улучшать сервис.
          </p>
        </article>

        <article>
          <h2>2. Какие cookie мы используем</h2>
          <ul>
            <li>Строго необходимые cookie — обеспечивают авторизацию и работу корзины.</li>
            <li>Аналитические cookie — позволяют понимать, как пользователи взаимодействуют с контентом.</li>
            <li>Функциональные cookie — запоминают ваши предпочтения и язык интерфейса.</li>
          </ul>
        </article>

        <article>
          <h2>3. Управление cookie</h2>
          <p>
            Вы можете изменить настройки через баннер на сайте или в настройках браузера. Обратите внимание, что отключение
            необходимых cookie может ограничить функциональность платформы.
          </p>
        </article>

        <article>
          <h2>4. Обновления</h2>
          <p>
            Мы периодически пересматриваем список cookie. Новые категории будут добавлены в эту политику.
          </p>
        </article>

        <p>
          Если у вас есть вопросы о cookie, свяжитесь с нами по адресу{' '}
          <a href="mailto:support@digitalcovers.com">support@digitalcovers.com</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;