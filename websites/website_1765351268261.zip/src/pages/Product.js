import React, { useMemo, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Seo from '../components/Seo';
import products from '../data/products';
import styles from './Product.module.css';

const Product = () => {
  const { id } = useParams();
  const product = useMemo(() => products.find((item) => item.id === id), [id]);
  const [selectedImage, setSelectedImage] = useState(product ? product.images[0] : '');
  const [inCart, setInCart] = useState(false);

  if (!product) {
    return (
      <section className={styles.notFound}>
        <div className="container">
          <h1>К сожалению, товар не найден</h1>
          <p>Возможно, ссылка устарела или товар был снят с продажи.</p>
          <Link to="/catalog" className={styles.backLink}>
            Вернуться в каталог
          </Link>
        </div>
      </section>
    );
  }

  const handleAddToCart = () => {
    setInCart(true);
    setTimeout(() => setInCart(false), 2500);
  };

  return (
    <>
      <Seo
        title={`${product.name} — DigitalCovers`}
        description={`Купить ${product.name} для ${product.category}. Готовые файлы: ${product.tags.join(', ')}`}
      />
      <section className={styles.hero}>
        <div className="container">
          <nav aria-label="Хлебные крошки" className={styles.breadcrumbs}>
            <Link to="/">Главная</Link>
            <span>/</span>
            <Link to="/catalog">Каталог</Link>
            <span>/</span>
            <span>{product.name}</span>
          </nav>
          <div className={styles.layout}>
            <div className={styles.gallery}>
              <div className={styles.mainImage}>
                <img src={selectedImage} alt={product.name} />
              </div>
              <div className={styles.thumbnails}>
                {product.images.map((image) => (
                  <button
                    type="button"
                    key={image}
                    className={`${styles.thumbnailButton} ${selectedImage === image ? styles.active : ''}`}
                    onClick={() => setSelectedImage(image)}
                  >
                    <img src={image} alt={`${product.name} — превью`} />
                  </button>
                ))}
              </div>
            </div>
            <div className={styles.details}>
              <span className={styles.category}>{product.category}</span>
              <h1>{product.name}</h1>
              <p className={styles.description}>{product.description}</p>
              <div className={styles.priceBlock}>
                <span className={styles.price}>
                  {product.price} {product.currency}
                </span>
                <button type="button" onClick={handleAddToCart} className={styles.primaryButton}>
                  {inCart ? 'Добавлено!' : 'Добавить в корзину'}
                </button>
              </div>
              <div className={styles.featureList}>
                <h2>Что внутри</h2>
                <ul>
                  {product.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
              </div>
              <div className={styles.tags}>
                {product.tags.map((tag) => (
                  <span key={tag}>#{tag}</span>
                ))}
              </div>
              <div className={styles.notice}>
                <h3>Важно знать</h3>
                <p>
                  После покупки вы получите мгновенный доступ к файлам, подробную инструкцию по редактированию и нашу
                  поддержку. Пожалуйста, ознакомьтесь с условиями использования перед публикацией.
                </p>
                <Link to="/terms">Открыть условия использования</Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Product;