document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            siteNav.classList.toggle('open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const cookiePreference = localStorage.getItem('funapmwi_cookie_choice');

    if (cookieBanner && acceptBtn && declineBtn) {
        if (cookiePreference) {
            cookieBanner.style.display = 'none';
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem('funapmwi_cookie_choice', 'accepted');
            cookieBanner.style.display = 'none';
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem('funapmwi_cookie_choice', 'declined');
            cookieBanner.style.display = 'none';
        });
    }
});