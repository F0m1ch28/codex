const DEFAULT_LANG = "fr";
const STORAGE_LANG_KEY = "site_lang";
const COOKIE_STORAGE_KEY = "cookie_consent";

const I18N = {
  fr: {
    meta: {
      homeTitle: "danswholesaleplants · Orientation spatiale et signalétique numérique en Belgique",
      homeDescription: "Analyses, méthodologies et retours d’expérience sur la navigation intérieure, la cartographie des espaces et le design informationnel pour les bâtiments publics en Belgique.",
      servicesTitle: "Expertises en orientation spatiale · danswholesaleplants",
      servicesDescription: "Panorama détaillé des expertises de danswholesaleplants autour de la signalétique numérique, de la mobilité piétonne et de la modélisation des parcours utilisateurs.",
      aboutTitle: "À propos de danswholesaleplants · Recherche en orientation spatiale",
      aboutDescription: "Comprendre la mission, l’équipe et le cadre méthodologique de danswholesaleplants autour de l’UX spatiale et de l’accessibilité.",
      blogTitle: "Publications · Recherches sur le guidage visuel et la cartographie des espaces",
      blogDescription: "Analyses approfondies sur l’orientation spatiale, la lisibilité des environnements complexes et les systèmes de guidage numériques.",
      post1Title: "Interpréter les données d’orientation dans les pôles multimodaux · danswholesaleplants",
      post1Description: "Étude approfondie des indicateurs, des protocoles et des modèles analytiques pour la navigation dans les pôles multimodaux belges.",
      post2Title: "Accessibilité inclusive des parcours intérieurs · danswholesaleplants",
      post2Description: "Cadres méthodologiques pour aligner accessibilité, UX spatiale et continuité de parcours dans les bâtiments publics.",
      post3Title: "Cartographie narrative pour environnements complexes · danswholesaleplants",
      post3Description: "Réflexions sur la narration cartographique, les métadonnées contextuelles et la synthèse des flux de circulation.",
      post4Title: "Signalétique numérique et expérience piétonne · danswholesaleplants",
      post4Description: "Analyse de la convergence entre signalétique numérique, ergonomie d’usage et mobilité piétonne dans les espaces urbains.",
      post5Title: "Mesurer l’efficacité d’un schéma directionnel intérieur · danswholesaleplants",
      post5Description: "Méthodes d’évaluation, indicateurs composites et suivi longitudinal des dispositifs directionnels.",
      contactTitle: "Coordonnées et carte · danswholesaleplants",
      contactDescription: "Informations pratiques, carte interactive et formulaire pour coordonner vos projets d’orientation spatiale.",
      faqTitle: "FAQ sur l’orientation spatiale et la signalétique numérique",
      faqDescription: "Réponses détaillées aux questions fréquentes concernant la cartographie des espaces, la mobilité piétonne et l’accessibilité.",
      termsTitle: "Conditions d’utilisation · danswholesaleplants",
      termsDescription: "Conditions d’utilisation des contenus, responsabilités et cadre juridique du site danswholesaleplants.",
      privacyTitle: "Politique de confidentialité · danswholesaleplants",
      privacyDescription: "Collecte, utilisation et conservation des données personnelles dans le cadre de danswholesaleplants.",
      cookiesTitle: "Politique relative aux cookies · danswholesaleplants",
      cookiesDescription: "Description des cookies utilisés, finalités, durées de conservation et modalités de gestion.",
      refundTitle: "Politique de rétractation · danswholesaleplants",
      refundDescription: "Procédures de rétractation, délais et modalités d’ajustement pour les échanges d’informations.",
      disclaimerTitle: "Avertissement · danswholesaleplants",
      disclaimerDescription: "Limites d’utilisation, absence de garanties et périmètre des informations publiées.",
      thankYouTitle: "Merci pour votre message · danswholesaleplants",
      thankYouDescription: "Confirmation d’envoi du formulaire et prochaines étapes de réponse.",
      notFoundTitle: "Page introuvable · danswholesaleplants",
      notFoundDescription: "La page demandée est introuvable. Explorez les ressources d’orientation spatiale disponibles."
    },
    common: {
      skipLink: "Aller au contenu principal",
      languageLabel: "Langue",
      brandTagline: "Ingénierie de l’orientation spatiale",
      manageCookies: "Préférences cookies",
      currentYearPrefix: "©",
      readMore: "Découvrir",
      backHome: "Retourner à l’accueil",
      exploreResources: "Explorer les ressources"
    },
    nav: {
      home: "Accueil",
      services: "Expertises",
      about: "À propos",
      blog: "Publications",
      faq: "Questions",
      contact: "Contact"
    },
    footer: {
      title: "danswholesaleplants",
      subtitle: "Analyse et conception de dispositifs d’orientation spatiale",
      phone: "Téléphone : +32 2 123 45 67",
      email: "Courriel : contact@danswholesaleplants.com",
      address: "Adresse : Rue de la Loi 200, 1040 Bruxelles, Belgique",
      rights: "Tous droits réservés.",
      terms: "Conditions d’utilisation",
      privacy: "Confidentialité",
      cookies: "Cookies",
      refund: "Politique de rétractation",
      disclaimer: "Avertissement"
    },
    home: {
      heroTitle: "Coordonner l’orientation spatiale dans les environnements complexes",
      heroSubtitle: "danswholesaleplants structure la compréhension des parcours intérieurs, de la signalétique numérique et des plans interactifs afin de fluidifier la mobilité piétonne et la lisibilité des infrastructures belges.",
      heroCtaPrimary: "Cartographier les trajectoires utilisateurs",
      heroCtaSecondary: "Consulter les cadres méthodologiques",
      heroStat1Label: "Espaces analysés",
      heroStat1Value: "48 sites publics",
      heroStat2Label: "Données directionnelles",
      heroStat2Value: "125 modèles UX",
      heroStat3Label: "Itérations évaluées",
      heroStat3Value: "312 parcours testés",
      featuredTitle: "Cartographie raisonnée des flux de circulation",
      featuredIntro: "Chaque intervention s’appuie sur une lecture croisée des données spatiales, des signaux visuels et des usages piétons pour clarifier les enchaînements décisionnels.",
      featureCard1Title: "Audit des points d’orientation",
      featureCard1Text: "Identification des zones de transition, compréhension de la densité décisionnelle et hiérarchisation des repères actifs au sein des séquences de déplacement.",
      featureCard2Title: "Matrices signalétiques comparées",
      featureCard2Text: "Analyse synchrone des supports analogiques et numériques, pondération selon la distance de lecture et le niveau d’effort cognitif requis.",
      featureCard3Title: "Modélisation des scénarios d’usage",
      featureCard3Text: "Construction de scénarios multi-profils, simulation des bifurcations successives et mesure de l’impact UX sur la continuité des parcours.",
      featureCard4Title: "Cartes relationnelles interactives",
      featureCard4Text: "Structuration des points d’intérêt, ancrage des zones sensibles et visualisation des interconnexions pour renforcer la lisibilité des environnements bâtis.",
      methodTitle: "Cadre opératoire pour la navigation intérieure",
      methodIntro: "Un triptyque méthodologique articule observation, expérimentation et synthèse pour orchestrer les dispositifs de guidage dans toute leur complexité.",
      methodStep1Title: "Observation multi-échelle",
      methodStep1Text: "Relevés de terrain, mesures photographiques et inventaires directionnels sont combinés à des entretiens qualitatifs ciblés.",
      methodStep2Title: "Itération et prototypage",
      methodStep2Text: "Combinaisons de parcours, storyboards et tests in situ permettent de confronter les hypothèses aux réalités d’usage.",
      methodStep3Title: "Analyse et gouvernance",
      methodStep3Text: "Restitutions graphiques, matrices de décision et recommandations opérationnelles assurent la pérennité des choix directionnels.",
      recommendationsTitle: "Recommandations de structuration",
      recommendationsIntro: "Les préconisations s’attachent à articuler l’architecture, la donnée et l’usage dans des cadres de gouvernance sobres et durables.",
      recommendation1Title: "Stabiliser les référentiels",
      recommendation1Text: "Consolider une base documentaire commune, préciser les logiques de signalétique et formaliser les circuits de validation.",
      recommendation2Title: "Séquencer les repères",
      recommendation2Text: "Fractionner les informations, rythmer les rappels visuels et garantir la cohérence multi-supports sur l’ensemble des continuités.",
      recommendation3Title: "Piloter la maintenance",
      recommendation3Text: "Structurer des indicateurs de vieillissement, planifier les mises à jour numériques et documenter les décisions morphologiques.",
      recommendation4Title: "Aligner les données",
      recommendation4Text: "Assurer l’interopérabilité entre maquettes BIM, inventaires patrimoniaux et cartographies d’usage pour un suivi transversal.",
      testimonialsTitle: "Témoignages sur les environnements transformés",
      testimonialsIntro: "Institutions et structures publiques partagent leurs retours sur la mise en cohérence des parcours d’orientation.",
      testimonial1Quote: "L’approche de danswholesaleplants a permis d’harmoniser les repères directionnels et d’éclairer les points d’hésitation critiques dans notre campus hospitalier.",
      testimonial1Author: "Direction technique · Réseau hospitalier métropolitain",
      testimonial2Quote: "Les scénarios piétons et les métriques de lisibilité élaborés ont alimenté nos arbitrages d’aménagement tout en respectant les contraintes patrimoniales.",
      testimonial2Author: "Cellule urbanisme · Ville de Liège",
      testimonial3Quote: "Le travail sur la cartographie narrative a rendu intelligible un bâtiment tertiaire très fragmenté et facilité l’accueil des nouveaux arrivants.",
      testimonial3Author: "Coordination immobilière · Administration fédérale",
      resourcesTitle: "Ressources et approfondissements",
      resourcesIntro: "Études, protocoles et outils méthodologiques pour prolonger l’analyse des dispositifs d’orientation.",
      resourcesItem1Title: "Guide de lecture des données directionnelles",
      resourcesItem1Text: "Un cadre pour interpréter les signaux faibles et croiser perception et performance.",
      resourcesItem2Title: "Référentiel d’accessibilité spatiale",
      resourcesItem2Text: "Checklist opérationnelle pour intégrer les besoins multi-profils dans les parcours.",
      resourcesItem3Title: "Gabarits de cartographies narratives",
      resourcesItem3Text: "Structures visuelles et métadonnées type pour des plans interactifs évolutifs."
    },
    services: {
      heroTitle: "Panorama des expertises mobilisées",
      heroSubtitle: "Chaque service décrit les angles d’analyse et les livrables méthodologiques qui structurent la compréhension des parcours et des plans de guidage.",
      heroBadge: "Approche modulaire",
      introTitle: "Cinq axes pour orchestrer l’orientation",
      introText: "Les expertises couvrent la totalité des cycles d’analyse : observation, design informationnel, modélisation, accessibilité et évaluation UX.",
      service1Title: "Analyse des défis d’orientation",
      service1Description: "Inventaires des signaux, cartographie des zones d’incertitude, lectures croisées des contraintes architecturales et des flux piétons.",
      service1Item1: "Cartographie des points de friction et des zones d’attente prolongée.",
      service1Item2: "Observation in situ et captations vidéo pour qualifier les comportements.",
      service1Item3: "Matrices effort/décision pour chaque séquence de déplacement.",
      service1Item4: "Analyse des correspondances intramodales et intermodales.",
      service2Title: "Design de signalétique numérique",
      service2Description: "Déclinaison des principes graphiques, gestion des contenus dynamiques et articulation avec les supports physiques existants.",
      service2Item1: "Définition des niveaux d’information par distance de lecture.",
      service2Item2: "Grilles de contenus et scénarios de mise à jour en temps réel.",
      service2Item3: "Prototypage d’interfaces tactiles et audit d’ergonomie.",
      service2Item4: "Alignement with architecture et scénographie existantes.",
      service3Title: "Modélisation des parcours utilisateurs",
      service3Description: "Construction d’hypothèses de déplacement, simulation des têtes de flux et validation terrain par tests dirigés.",
      service3Item1: "Cartes de chaleur des flux piétons et segmentation par profil.",
      service3Item2: "Storyboards des décisions critiques et des repères visuels.",
      service3Item3: "Tests de compréhension et suivi des temps de parcours.",
      service3Item4: "Recommandations sur la hiérarchisation des axes de circulation.",
      service4Title: "Accessibilité et inclusion spatiale",
      service4Description: "Vérification des normes, analyses sensorielles et intégration des usages spécifiques dans la chaîne de déplacement.",
      service4Item1: "Parcours commentés avec utilisateurs aux besoins spécifiques.",
      service4Item2: "Grilles tactiles et alternatives sonores pour les repères clés.",
      service4Item3: "Evaluations contrastées des contrastes visuels et reliefs.",
      service4Item4: "Protocoles d’entretien et formation aux acteurs de terrain.",
      service5Title: "Recherche sur la lisibilité des infrastructures",
      service5Description: "Dispositifs de mesure, tableaux de bord dédiés et suivi longitudinal de la performance des systèmes de guidage.",
      service5Item1: "Indicateurs de lisibilité pondérés par espace et typologie d’usager.",
      service5Item2: "Audits comparatifs avant / après déploiement de signalétique.",
      service5Item3: "Synthèses graphiques pour arbitrer les phases de maintenance.",
      service5Item4: "Observatoires d’usage et retours qualitatifs documentés.",
      methodologyTitle: "Méthodologie d’intervention",
      methodologyText: "Une démarche incrémentale où les phases se chevauchent pour garantir la robustesse des décisions.",
      methodologyItem1Title: "Cadre stratégique",
      methodologyItem1Text: "Clarification des objectifs, identification des parties prenantes et cadrage des livrables cartographiques.",
      methodologyItem2Title: "Itérations et prototypage",
      methodologyItem2Text: "Allers-retours visuels, ateliers de scénarisation et évaluations rapides pour éviter les angles morts.",
      methodologyItem3Title: "Gouvernance de la donnée",
      methodologyItem3Text: "Mise en place de référentiels, documentation et scripts de mise à jour pour inscrire la signalétique dans le temps."
    },
    about: {
      heroTitle: "Une structure dédiée à l’orientation spatiale",
      heroSubtitle: "danswholesaleplants fédère expertise en architecture, design informationnel et sciences de la mobilité pour comprendre la circulation humaine dans les environnements complexes.",
      missionTitle: "Mission",
      missionText: "Relier les dimensions physiques, numériques et humaines de l’orientation pour sécuriser une expérience cohérente au sein des infrastructures publiques.",
      visionTitle: "Vision",
      visionText: "Concevoir des systèmes de guidage transparents qui valorisent l’architecture, fluidifient les flux et renforcent l’accessibilité de chaque espace.",
      valuesTitle: "Principes de travail",
      valuesItem1Title: "Transversalité",
      valuesItem1Text: "Croiser les regards entre architectes, urbanistes, designers et responsables opérationnels.",
      valuesItem2Title: "Sobriété",
      valuesItem2Text: "Privilégier des dispositifs lisibles, documentés et maîtrisables sur la durée.",
      valuesItem3Title: "Mesure",
      valuesItem3Text: "S’appuyer sur des indicateurs tangibles pour piloter les ajustements.",
      valuesItem4Title: "Accessibilité",
      valuesItem4Text: "Intégrer les usages spécifiques dès l’amorce des analyses.",
      timelineTitle: "Repères chronologiques",
      timelineItem1Title: "2014 · Origine",
      timelineItem1Text: "Premières missions de diagnostic signalétique dans les bâtiments administratifs bruxellois.",
      timelineItem2Title: "2017 · Modèles de parcours",
      timelineItem2Text: "Formalisation des matrices de décision et des cartographies narratives interactives.",
      timelineItem3Title: "2019 · Dimension inclusive",
      timelineItem3Text: "Intégration systématique des audits d’accessibilité et constitution d’un panel utilisateurs.",
      timelineItem4Title: "2022 · Gouvernance des données",
      timelineItem4Text: "Déploiement d’ateliers dédiés aux référentiels signalétiques et au suivi des plans numériques.",
      competenciesTitle: "Compétences clés",
      competenciesItem1: "Analyse spatiale multi-échelles et relevés géolocalisés.",
      competenciesItem2: "Design informationnel et construction de grilles graphiques.",
      competenciesItem3: "Facilitation d’ateliers pluridisciplinaires.",
      competenciesItem4: "Cadrage de projets numériques cartographiques.",
      competenciesItem5: "Évaluation qualitative et quantitative des parcours.",
      approachTitle: "Approche en trois mouvements",
      approachStep1Title: "Immersion",
      approachStep1Text: "Compréhension des usages existants par observation et entretiens ciblés.",
      approachStep2Title: "Composition",
      approachStep2Text: "Structuration des parcours, création de prototypes et tests rapides.",
      approachStep3Title: "Transmission",
      approachStep3Text: "Documentation, formation et handover méthodologique pour les équipes internes."
    },
    blog: {
      heroTitle: "Publications et carnets de recherche",
      heroSubtitle: "Un regard analytique sur la navigation intérieure, les plans interactifs et la lisibilité des environnements urbains.",
      heroBadge: "Veille continue",
      introTitle: "Derniers articles",
      introText: "Synthèses, études de cas et retours d’expérience issus des missions belges et européennes.",
      card1Title: "Interpréter les données d’orientation dans les pôles multimodaux",
      card1Excerpt: "Quels indicateurs privilégier pour décrypter les prises de décision d’orientation dans les pôles mêlant trains, tramways et réseaux piétons ?",
      card2Title: "Accessibilité inclusive des parcours intérieurs",
      card2Excerpt: "Comment aligner chaîne de déplacement, repères sensoriels et lisibilité pour tous les profils d’usagers ?",
      card3Title: "Cartographie narrative pour environnements complexes",
      card3Excerpt: "Structurer l’information pour traduire la complexité architecturale en séquences compréhensibles.",
      card4Title: "Signalétique numérique et expérience piétonne",
      card4Excerpt: "Converger design d’interfaces et ergonomie des supports physiques pour une continuité fluide.",
      card5Title: "Mesurer l’efficacité d’un schéma directionnel intérieur",
      card5Excerpt: "Quels indicateurs et quelles fréquences d’observation pour piloter la performance des dispositifs ?",
      readPost: "Lire l’article"
    },
    contact: {
      heroTitle: "Coordonnées et interactions",
      heroSubtitle: "Cartographions ensemble les besoins d’orientation et les cadres opérationnels adaptés à vos environnements.",
      infoTitle: "Informations pratiques",
      phoneLabel: "Téléphone",
      emailLabel: "Courriel",
      addressLabel: "Adresse",
      hoursLabel: "Disponibilités",
      hoursText: "Du lundi au vendredi · 09h00 — 18h00 (CET)",
      mapTitle: "Implantation à Bruxelles",
      formTitle: "Formulaire de mise en relation",
      formIntro: "Décrivez votre environnement et vos objectifs afin d’activer un diagnostic circonstancié.",
      fieldNameLabel: "Nom et prénom",
      fieldNamePlaceholder: "Votre identité",
      fieldEmailLabel: "Adresse électronique",
      fieldEmailPlaceholder: "nom@organisation.be",
      fieldOrganisationLabel: "Organisation",
      fieldOrganisationPlaceholder: "Structure ou institution",
      fieldPurposeLabel: "Objet principal",
      fieldPurposeOption1: "Diagnostic d’orientation",
      fieldPurposeOption2: "Modélisation des parcours",
      fieldPurposeOption3: "Accessibilité et inclusion",
      fieldPurposeOption4: "Documentation et gouvernance",
      fieldMessageLabel: "Message",
      fieldMessagePlaceholder: "Décrivez l’environnement, les enjeux et les échéances clés.",
      submitButton: "Envoyer vers la page de confirmation",
      mapCaption: "Vue OpenStreetMap centrée sur Rue de la Loi 200, Bruxelles."
    },
    faq: {
      heroTitle: "Questions récurrentes",
      heroSubtitle: "Des réponses détaillées pour clarifier la méthodologie et les usages de l’orientation spatiale.",
      item1Question: "Comment débute un diagnostic d’orientation spatiale ?",
      item1Answer: "Un travail préparatoire collecte plans, documents signalétiques et données de fréquentation. Des visites immersives confirment les observations et définissent les zones prioritaires.",
      item2Question: "Quels outils mobiliser pour analyser les flux piétons ?",
      item2Answer: "Cartographies manuelles, capteurs anonymisés et observations chronométrées sont croisés pour comprendre séquences d’arrêt, bifurcations et temps d’attente.",
      item3Question: "Comment intégrer l’accessibilité dès la conception ?",
      item3Answer: "Les besoins multi-profils sont formalisés dans un référentiel d’accessibilité qui guide les tests utilisateurs, la hiérarchisation des supports et les alternatives sensorielles.",
      item4Question: "Quelle place pour la signalétique numérique ?",
      item4Answer: "Elle s’inscrit en complémentarité, notamment dans les lieux à fréquence d’événements. Son efficacité dépend d’une gouvernance claire des contenus et d’un design cross-canal.",
      item5Question: "Comment mesurer la performance d’un dispositif ?",
      item5Answer: "Des indicateurs de lisibilité, de temps de parcours et de satisfaction qualifiée sont suivis avant et après chaque itération afin d’ajuster les décisions.",
      item6Question: "Quelle durée pour formaliser un référentiel signalétique ?",
      item6Answer: "Selon la taille du site, il faut compter entre six et douze semaines, incluant ateliers collaboratifs, prototypage et documentation technique."
    },
    terms: {
      intro: "Les présentes conditions encadrent l’utilisation du site danswholesaleplants.com. La consultation implique l’acceptation intégrale des clauses suivantes.",
      section1Title: "1. Objet",
      section1Text: "Définir les modalités d’accès aux contenus relatifs à l’orientation spatiale et à la signalétique numérique diffusés par danswholesaleplants.",
      section2Title: "2. Acceptation",
      section2Text: "L’accès au site implique l’adhésion aux présentes conditions sans réserve. Toute utilisation contraire aux présentes est prohibée.",
      section3Title: "3. Accès aux contenus",
      section3Text: "Les ressources sont mises à disposition à titre informatif. danswholesaleplants se réserve le droit de modifier, suspendre ou retirer tout contenu sans préavis.",
      section4Title: "4. Propriété intellectuelle",
      section4Text: "Les textes, visuels et structures informationnelles sont protégés. Toute reproduction ou diffusion requiert l’autorisation écrite préalable de danswholesaleplants.",
      section5Title: "5. Usage des informations",
      section5Text: "Les contenus ne constituent ni prescription ni engagement opérationnel. L’utilisateur conserve la responsabilité de ses décisions.",
      section6Title: "6. Contributions externes",
      section6Text: "Les témoignages et retours d’expérience publiés sont validés avant mise en ligne. danswholesaleplants peut refuser ou retirer toute contribution non alignée.",
      section7Title: "7. Liens hypertexte",
      section7Text: "La création de liens vers le site est autorisée sous réserve de ne pas porter atteinte à la réputation de danswholesaleplants ni induire en erreur sur la nature des contenus.",
      section8Title: "8. Responsabilités",
      section8Text: "danswholesaleplants ne saurait être tenu responsable des dommages résultant d’une utilisation inappropriée ou d’une interprétation erronée des informations.",
      section9Title: "9. Disponibilité",
      section9Text: "Le site est accessible 24h/24 et 7j/7 sauf maintenance ou cas de force majeure. Aucun engagement de disponibilité continue n’est formulé.",
      section10Title: "10. Protection des données",
      section10Text: "Les données collectées par le formulaire sont traitées conformément à la politique de confidentialité accessible sur le site.",
      section11Title: "11. Cookies",
      section11Text: "Le fonctionnement du site implique l’utilisation de cookies détaillés dans la politique dédiée. L’utilisateur peut ajuster ses préférences à tout moment.",
      section12Title: "12. Évolution des conditions",
      section12Text: "danswholesaleplants peut modifier les présentes conditions pour refléter les évolutions juridiques ou techniques. La date de mise à jour figure en en-tête de page.",
      section13Title: "13. Droit applicable",
      section13Text: "Les présentes conditions sont soumises au droit belge. En cas de litige, les tribunaux de Bruxelles sont compétents.",
      section14Title: "14. Contact",
      section14Text: "Toute question relative aux conditions d’utilisation peut être adressée via contact@danswholesaleplants.com ou la page dédiée."
    },
    privacy: {
      intro: "Cette politique précise les modalités de traitement des données personnelles collectées dans le cadre du site danswholesaleplants.com.",
      section1Title: "1. Responsable de traitement",
      section1Text: "Le responsable est danswholesaleplants, Rue de la Loi 200, 1040 Bruxelles. Courriel de contact : contact@danswholesaleplants.com.",
      section2Title: "2. Données collectées",
      section2Text: "Les données transmises via le formulaire (identité, courriel, organisation, message) et les préférences cookies sont enregistrées.",
      section3Title: "3. Finalités",
      section3Text: "Les données servent à répondre aux sollicitations, organiser les échanges et documenter les besoins d’orientation spatiale.",
      section4Title: "4. Base juridique",
      section4Text: "Le traitement repose sur l’intérêt légitime de danswholesaleplants à gérer les échanges professionnels et informer ses interlocuteurs.",
      section5Title: "5. Durées de conservation",
      section5Text: "Les données de contact sont conservées 24 mois après le dernier échange. Les préférences cookies sont conservées 12 mois.",
      section6Title: "6. Destinataires",
      section6Text: "Les informations sont réservées aux équipes internes habilitées et ne font l’objet d’aucune transmission non autorisée.",
      section7Title: "7. Droits des personnes",
      section7Text: "Toute personne dispose de droits d’accès, rectification, opposition, limitation et effacement. Les demandes s’effectuent par courriel.",
      section8Title: "8. Sécurité",
      section8Text: "Des mesures organisationnelles et techniques sont déployées pour protéger les données contre tout accès non autorisé.",
      section9Title: "9. Cookies",
      section9Text: "Les cookies utilisés sont détaillés dans la politique dédiée. L’utilisateur peut modifier ses préférences à tout moment.",
      section10Title: "10. Contact et recours",
      section10Text: "Pour exercer ses droits, écrire à contact@danswholesaleplants.com. Un recours est possible auprès de l’Autorité de protection des données (Belgique)."
    },
    cookies: {
      intro: "Cette page décrit les cookies utilisés sur danswholesaleplants.com ainsi que les moyens de gestion mis à votre disposition.",
      section1Title: "1. Définition",
      section1Text: "Un cookie est un fichier déposé sur votre terminal afin d’enregistrer des informations relatives à votre navigation.",
      section2Title: "2. Gestion des préférences",
      section2Text: "Le bandeau dédié permet d’accepter, refuser ou personnaliser les cookies. Votre choix est conservé pendant 12 mois.",
      tableTitle: "Tableau récapitulatif",
      tableHeadName: "Nom",
      tableHeadProvider: "Fournisseur",
      tableHeadType: "Type",
      tableHeadPurpose: "Finalité",
      tableHeadDuration: "Durée",
      tableRow1Name: "cookie_consent",
      tableRow1Provider: "danswholesaleplants",
      tableRow1Type: "Nécessaire",
      tableRow1Purpose: "Stocker les préférences de consentement.",
      tableRow1Duration: "12 mois",
      tableRow2Name: "session_layout",
      tableRow2Provider: "danswholesaleplants",
      tableRow2Type: "Préférences",
      tableRow2Purpose: "Mémoriser les réglages d’affichage du site.",
      tableRow2Duration: "6 mois",
      tableRow3Name: "analytics_flow",
      tableRow3Provider: "danswholesaleplants",
      tableRow3Type: "Analytics",
      tableRow3Purpose: "Mesurer la navigation agrégée entre les sections.",
      tableRow3Duration: "13 mois",
      section3Title: "3. Désactivation",
      section3Text: "Vous pouvez également paramétrer votre navigateur pour bloquer tout ou partie des cookies. Certains services pourraient alors être limités.",
      section4Title: "4. Mise à jour",
      section4Text: "La présente politique est revue régulièrement pour refléter l’évolution des usages et de la réglementation."
    },
    refund: {
      intro: "Cette politique précise les modalités de rétractation applicables aux échanges d’informations et de documents.",
      section1Title: "1. Champ d’application",
      section1Text: "Elle couvre les contributions documentaires échangées via le site ou par courriel suite à un formulaire.",
      section2Title: "2. Droit de rétractation",
      section2Text: "Toute demande de retrait d’un document partagé peut être formulée dans un délai de 14 jours suivant son envoi.",
      section3Title: "3. Procédure",
      section3Text: "Adressez votre demande à contact@danswholesaleplants.com en précisant l’objet concerné et la date d’échange.",
      section4Title: "4. Traitement",
      section4Text: "Une confirmation de prise en compte est transmise sous 5 jours ouvrés, avec les actions correctives associées.",
      section5Title: "5. Limites",
      section5Text: "Les ressources publiques ou déjà intégrées à des référentiels ne peuvent être supprimées qu’après examen de leur impact.",
      section6Title: "6. Archivage",
      section6Text: "Les versions retirées sont conservées à des fins de traçabilité interne pendant une durée maximale de 12 mois.",
      section7Title: "7. Ajustements",
      section7Text: "Lorsque la suppression n’est pas possible, une version amendée peut être proposée pour refléter les attentes exprimées.",
      section8Title: "8. Collaboration",
      section8Text: "La coopération avec les équipes demandeuses est encouragée afin de documenter précisément les besoins.",
      section9Title: "9. Évolutions",
      section9Text: "Cette politique peut évoluer pour tenir compte des nouvelles pratiques documentaires.",
      section10Title: "10. Contact",
      section10Text: "Toute question relative à la rétractation peut être adressée via la page contact ou à l’adresse courriel indiquée."
    },
    disclaimer: {
      intro: "Les informations fournies sur danswholesaleplants.com sont diffusées à des fins informatives.",
      section1Title: "1. Absence de garantie",
      section1Text: "danswholesaleplants ne garantit ni l’exhaustivité ni l’actualisation permanente des contenus publiés.",
      section2Title: "2. Responsabilité",
      section2Text: "L’utilisateur demeure responsable de l’interprétation et de l’usage des informations mises à disposition.",
      section3Title: "3. Pas de conseil",
      section3Text: "Les contenus ne constituent pas un conseil opérationnel ou juridique personnalisé.",
      section4Title: "4. Liens externes",
      section4Text: "Le site peut contenir des liens vers d’autres ressources. danswholesaleplants n’endosse aucune responsabilité sur leur contenu.",
      section5Title: "5. Modifications",
      section5Text: "Les informations sont susceptibles d’être modifiées à tout moment sans préavis.",
      section6Title: "6. Contact",
      section6Text: "Pour toute précision, merci d’utiliser le formulaire ou l’adresse contact@danswholesaleplants.com."
    },
    thankYou: {
      heroTitle: "Merci pour votre message",
      heroSubtitle: "Votre demande a bien été transmise. Une analyse attentive sera effectuée avant toute prise de contact.",
      nextStepsTitle: "Prochaines étapes",
      nextStepsText: "Nous reviendrons vers vous sous 5 jours ouvrés afin de clarifier les attendus et planifier les éventuels ateliers exploratoires.",
      backButton: "Revenir aux publications"
    },
    notFound: {
      heroTitle: "La page demandée est introuvable",
      heroSubtitle: "Le chemin suivi ne correspond plus à un contenu disponible. Naviguez vers les ressources principales pour poursuivre votre exploration.",
      buttonText: "Retour à l’accueil"
    },
    notifications: {
      formSubmitted: "Formulaire envoyé vers la page de confirmation.",
      formInvalid: "Veuillez compléter les champs requis avant l’envoi.",
      cookieSaved: "Préférences cookies enregistrées.",
      cookieDeclined: "Cookies optionnels désactivés.",
      cookieAccepted: "Cookies optionnels activés."
    },
    cookieBanner: {
      title: "Gestion des cookies",
      description: "Nous utilisons des cookies pour assurer le bon fonctionnement du site et analyser de manière anonyme la navigation.",
      necessary: "Nécessaires",
      necessaryDescription: "Indispensables au fonctionnement du site. Toujours actifs.",
      preferences: "Préférences",
      preferencesDescription: "Enregistre vos réglages d’affichage et d’interface.",
      analytics: "Analytics",
      analyticsDescription: "Mesure agrégée des parcours visiteurs.",
      marketing: "Marketing",
      marketingDescription: "Non utilisés actuellement.",
      acceptAll: "Tout accepter",
      declineAll: "Tout refuser",
      save: "Enregistrer",
      manage: "Personnaliser",
      openButton: "Ouvrir les préférences cookies",
      close: "Fermer"
    },
    blogPosts: {
      post1: {
        h1: "Interpréter les données d’orientation dans les pôles multimodaux",
        h2: "Contextualiser les indicateurs directionnels",
        h3: "Vers une lecture systémique des parcours croisés",
        paragraphs: [
          "Les pôles multimodaux belges combinent lignes ferroviaires, réseaux de métro, tramways et cheminements piétons souterrains ou aériens. Comprendre l’orientation des usagers suppose d’abord de dresser une cartographie précise des interactions entre ces couches de mobilité. Les données brutes — comptages, relevés photographiques, journaux d’incident — ne prennent sens qu’une fois alignées sur les séquences décisionnelles réellement observées.",
          "Une première étape consiste à classer les noeuds directionnels par intensité. On distingue les points d’inflexion majeurs, où plusieurs choix sont possibles, des points d’ajustement, où l’utilisateur confirme ou corrige sa trajectoire. Cette hiérarchisation permet de pondérer les indicateurs collectés : un volume de questions d’information n’a pas la même signification selon qu’il intervient avant ou après une bifurcation complexe.",
          "La granularité temporelle joue également un rôle décisif. Les cycles d’arrivée des trains, la synchronisation des bus ou les pics touristiques modifient la densité piétonne et la charge cognitive perçue. Les données doivent donc être segmentées par tranches horaires et couplées à des observations qualitatives afin de ne pas lisser des situations critiques.",
          "L’étape suivante vise à rapprocher données quantitatives et parcours témoins. Les méthodes d’itinéraires accompagnés, où un observateur note chaque micro-décision, offrent un matériau précieux pour interpréter des anomalies statistiques. Pourquoi un flux se détourne-t-il d’un escalier pourtant signalé ? Une signalisation redondante est-elle ignorée par surplus d’information ? Ces questions ne trouvent réponse qu’en croisant chiffres et récit d’usage.",
          "La mise en relation des supports numériques et analogiques constitue un autre pivot analytique. Un écran dynamique peut diffuser l’information exacte mais devenir invisible dans un contexte lumineux ou en raison d’un placement latéral trop bas. Les données doivent intégrer cette dimension sensorielle. On associe alors la performance mesurée (temps de parcours, volume d’erreurs) à l’expérience perçue, recueillie via des entretiens brefs ou des questionnaires situés.",
          "La synthèse se matérialise sous forme de cartes narratives. Chaque segment de parcours est décrit par une fiche combinant indicateurs clés, photographies et recommandations. Cette documentation facilite le dialogue entre architectes, responsables opérations et autorités de transport, car elle traduit l’abstraction des données en éléments visuels partagés. Les investissements prioritaires émergent naturellement : repositionnement de repères, harmonisation graphique, ajout d’un jalon tactile ou d’une annonce sonore.",
          "Enfin, l’analyse ne peut être considérée comme figée. Les pôles multimodaux évoluent à mesure que les lignes changent ou que les flux se recomposent. Instaurer une boucle de révision périodique — trimestrielle pour les données, annuelle pour les parcours accompagnés — garantit que la lecture systémique conserve sa pertinence et reste alignée sur les usages réels."
        ]
      },
      post2: {
        h1: "Accessibilité inclusive des parcours intérieurs",
        h2: "Comprendre la diversité des profils utilisateurs",
        h3: "Intégrer les retours d’expérience dans la gouvernance spatiale",
        paragraphs: [
          "L’accessibilité ne se réduit pas au respect d’une norme. Dans un bâtiment public belge, elle se manifeste par la capacité de chaque personne à s’orienter, circuler, se repérer et atteindre son objectif sans rupture. Pour cela, il est indispensable de reconnaître la diversité des profils. Personnes en situation de handicap visuel, visiteurs peu familiers des lieux, usagers temporaires ou réguliers ne développent ni les mêmes réflexes, ni les mêmes attentes.",
          "Une démarche inclusive commence par la constitution d’un panel représentatif. Chaque membre est invité à parcourir les espaces avec son propre rythme. Les observateurs notent les repères utilisés, les hésitations et les interactions nécessaires. Les commentaires sont ensuite structurés en cartographies d’expérience, révélant les zones à forte charge cognitive ou les éléments de signalétique insuffisamment contrastés.",
          "Les retours sensoriels occupent une place centrale. Les contrastes visuels sont mesurés, les textures de sols analysées, les intensités lumineuses relevées. Pour certains profils, la gêne ne provient pas d’un manque d’information mais d’une surcharge : trop de panneaux, des typographies éclatées, des consignes qui se chevauchent. Une politique d’accessibilité inclusive nécessite donc un juste équilibre entre précision et sobriété.",
          "Les alternatives doivent être pensées conjointement. Une balise tactile ne suffit pas si elle n’est pas connectée à une description audio cohérente. De même, une carte simplifiée devient pertinente lorsqu’elle renvoie à un plan numérique accessible via lecteur d’écran. Chaque support forme une brique d’un écosystème plus large qui doit rester cohérent malgré la diversité des formats.",
          "La documentation est un autre levier critique. Les équipes techniques et les agents d’accueil ont besoin d’un référentiel clair expliquant l’intention de chaque repère. Sans cette base, les initiatives ponctuelles risquent d’altérer la cohérence globale. Il convient d’instaurer une gouvernance où chaque ajout est évalué au prisme de l’accessibilité.",
          "Les audits périodiques viennent consolider l’ensemble. Ils associent mesures quantifiables — temps de parcours, nombre de demandes d’assistance — et retours qualitatifs actualisés. Les écarts repérés alimentent ensuite un plan d’action incluant formation, ajustement des supports et tests complémentaires. L’inclusion devient ainsi un processus vivant, soutenu par des indicateurs partagés.",
          "Adopter cette posture inclusive transforme la perception du bâtiment. Loin d’être un ensemble d’obligations, l’accessibilité devient un fil conducteur de l’expérience, capable de renforcer la fluidité pour tous les publics et de valoriser le patrimoine existant."
        ]
      },
      post3: {
        h1: "Cartographie narrative pour environnements complexes",
        h2: "Composer une narration spatiale claire",
        h3: "Du récit visuel à la maintenance de long terme",
        paragraphs: [
          "Dans un bâtiment labyrinthique, la cartographie se doit d’être plus qu’un simple plan. Elle devient un récit capable d’expliquer l’espace, de hiérarchiser les priorités et d’anticiper les bifurcations. Cette narration se construit en couches successives, chacune apportant une précision sans noyer l’utilisateur sous des détails inutiles.",
          "Le point de départ consiste à définir un vocabulaire visuel partagée. Les zones fonctionnelles reçoivent des codes couleurs cohérents, les cheminements structurants sont figurés par des tracés continus, tandis que les zones secondaires utilisent des textures légères. L’objectif est de permettre une lecture intuitive, même lors d’une consultation rapide sur un plan mural ou une interface tactile.",
          "Les métadonnées jouent un rôle stratégique. Chaque repère cartographique est lié à des informations complémentaires : services disponibles, horaires, accessibilité, temps estimé. Cette base alimente ensuite les supports numériques, garantissant une diffusion homogène quel que soit le canal. Lorsqu’un service change d’emplacement, l’actualisation est centralisée et répliquée automatiquement sur les différents supports.",
          "La dimension narrative s’exprime aussi par l’ordre de présentation. Un plan qui détaille immédiatement tous les niveaux peut dérouter. Il est souvent préférable de guider l’utilisateur : d’abord l’ensemble, puis l’étage concerné, enfin les détails du dernier tronçon. Ce zoom progressif soutient la prise de décision et limite la surcharge cognitive.",
          "Les dispositifs interactifs offrent un potentiel supplémentaire. En couplant la cartographie à des scénarios d’usage, on peut proposer des itinéraires pré-calculés, intégrer des filtres thématiques ou afficher des alertes contextuelles. Toutefois, la richesse fonctionnelle doit rester maîtrisée : la navigation principale doit demeurer accessible en quelques gestes.",
          "La maintenance de la cartographie narrative se pense en amont. Des gabarits vectoriels, des bibliothèques d’icônes et des règles typographiques facilitent les mises à jour. Un comité de gouvernance, réunissant architectes, gestionnaires et responsables de communication, arbitre les évolutions majeures afin de préserver la cohérence globale.",
          "Enfin, l’évaluation par les usagers permet de vérifier l’efficacité du récit. Des ateliers de lecture de plan, des tests A/B et des observations discrètes aident à mesurer l’impact des ajustements. À terme, la cartographie narrative devient une composante vivante de la stratégie d’accueil, capable d’accompagner les transformations du lieu sans perdre en lisibilité."
        ]
      },
      post4: {
        h1: "Signalétique numérique et expérience piétonne",
        h2: "Concilier interfaces digitales et repères physiques",
        h3: "Maintenir une cohérence dans le temps",
        paragraphs: [
          "Les écrans et applications de guidage se multiplient dans les espaces publics. Leur apport est indéniable pour diffuser des informations dynamiques, mais ils doivent s’intégrer à une expérience piétonne déjà structurée par une signalétique physique. Le défi consiste à orchestrer ces dispositifs pour qu’ils se renforcent mutuellement.",
          "La première étape consiste à cartographier les supports existants. Panneaux directionnels, plans muraux, marquages au sol : tous doivent être inventoriés et évalués selon leur utilité. Les écrans ne doivent pas dupliquer sans discernement ces informations, mais plutôt les prolonger. Par exemple, un plan interactif peut proposer des itinéraires adaptés aux contraintes temporaires, tandis qu’un panneau fixe assure les repères de base.",
          "L’ergonomie d’usage est un autre facteur déterminant. Les interfaces doivent rester lisibles dans des conditions lumineuses variées et accessibles aux personnes de petite taille comme aux utilisateurs de fauteuils roulants. Des tests rapides, menés en conditions réelles, permettent d’ajuster la taille des caractères, le contraste ou la logique de navigation.",
          "Côté contenu, l’actualisation doit être maîtrisée. Un écran affichant des informations obsolètes décrédibilise l’ensemble du dispositif. Une gouvernance claire identifie les responsables de chaque rubrique, définit la fréquence de mise à jour et prévoit des alertes en cas d’anomalie. De cette manière, le numérique conserve sa valeur ajoutée sans générer une charge supplémentaire pour les équipes.",
          "La cohérence visuelle demeure essentielle. Les codes graphiques, les icônes et la terminologie doivent être harmonisés entre supports. Les utilisateurs ne devraient jamais avoir à traduire une étiquette numérique en un équivalent physique. Cette continuité facilite le passage d’un média à l’autre et réduit les efforts de compréhension.",
          "Dans la durée, la surveillance des usages complète le dispositif. Des capteurs anonymisés ou des observations discrètes déterminent si les écrans sont consultés, combien de temps et dans quelles conditions. Ces données orientent les évolutions futures : repositionnement d’un support, ajout d’une fonctionnalité ou simplification d’un menu.",
          "En définitive, la signalétique numérique ne remplace pas la signalétique physique. Elle la prolonge en ajoutant une couche d’information adaptable. Lorsque les deux dimensions sont orchestrées avec soin, l’expérience piétonne gagne en fluidité, en réactivité et en confort de navigation."
        ]
      },
      post5: {
        h1: "Mesurer l’efficacité d’un schéma directionnel intérieur",
        h2: "Définir des indicateurs actionnables",
        h3: "Boucles d’amélioration continue",
        paragraphs: [
          "Un schéma directionnel, aussi bien conçu soit-il, nécessite une évaluation régulière. Mesurer son efficacité revient à vérifier que l’information parvient aux usagers, qu’elle est comprise et qu’elle suscite les comportements attendus. La construction d’indicateurs pertinents constitue donc un préalable incontournable.",
          "Les indicateurs quantitatifs mesurent la performance observable. Temps moyen de parcours, nombre d’erreurs de direction, volume de demandes d’assistance : ces données fournissent une base tangible. Elles doivent toutefois être contextualisées par zone afin de distinguer les situations exceptionnelles des tendances durables.",
          "Les observations qualitatives complètent ce dispositif. Interroger les usagers à chaud, analyser leurs trajectoires sur plan ou recueillir leurs commentaires permet de saisir des nuances invisibles dans les chiffres. Une signalisation peut sembler performante, mais générer un sentiment d’inconfort ou d’incompréhension.",
          "La fréquence de mesure dépend de la dynamique du lieu. Dans un bâtiment administratif stable, un audit annuel suffit souvent. Dans un équipement culturel accueillant des expositions temporaires, une revue trimestrielle est préférable. Ces rendez-vous réguliers instaurent une culture de l’ajustement continu.",
          "Pour interpréter les résultats, il est recommandé de construire un tableau de bord partagé. Chaque indicateur y figure avec sa méthode de calcul, sa source, sa fréquence et un seuil d’alerte. Les équipes opérationnelles peuvent ainsi prioriser les interventions : repositionnement d’un panneau, ajout d’un rappel, clarification d’une terminologie.",
          "Les retours doivent ensuite être traduits en actions concrètes. Lorsqu’un point de friction est identifié, un protocole de test est déclenché : création d’une alternative, expérimentation sur site, récolte de retours. Les enseignements sont documentés pour capitaliser sur les réussites et éviter la réapparition des mêmes problèmes.",
          "Enfin, la transparence avec les usagers renforce l’efficacité globale. Communiquer sur les évolutions, expliquer les raisons d’une modification et solliciter des retours réguliers permet de bâtir une relation de confiance. Le schéma directionnel devient ainsi un système vivant, co-construit et piloté par des données robustes."
        ]
      }
    }
  },
  en: {
    meta: {
      homeTitle: "danswholesaleplants · Spatial orientation and digital wayfinding in Belgium",
      homeDescription: "Analyses, methodologies, and field insights on indoor navigation, space mapping, and informational design for Belgian public buildings.",
      servicesTitle: "Wayfinding expertise · danswholesaleplants",
      servicesDescription: "Comprehensive overview of danswholesaleplants expertise in digital signage, pedestrian mobility, and user journey modelling.",
      aboutTitle: "About danswholesaleplants · Spatial orientation research",
      aboutDescription: "Discover the mission, team, and methodological framework behind danswholesaleplants and its spatial UX and accessibility focus.",
      blogTitle: "Publications · Research on visual guidance and space mapping",
      blogDescription: "In-depth analyses on spatial orientation, readability of complex environments, and digital guidance systems.",
      post1Title: "Interpreting wayfinding data in multimodal hubs · danswholesaleplants",
      post1Description: "Detailed study of indicators, protocols, and analytical models for navigation in Belgian multimodal hubs.",
      post2Title: "Inclusive accessibility across indoor journeys · danswholesaleplants",
      post2Description: "Methodological frameworks aligning accessibility, spatial UX, and journey continuity in public buildings.",
      post3Title: "Narrative mapping for complex environments · danswholesaleplants",
      post3Description: "Reflections on cartographic storytelling, contextual metadata, and circulation flow synthesis.",
      post4Title: "Digital signage and pedestrian experience · danswholesaleplants",
      post4Description: "Analysis of the convergence between digital signage, usability, and pedestrian mobility in urban spaces.",
      post5Title: "Measuring the effectiveness of indoor directional schemes · danswholesaleplants",
      post5Description: "Assessment methods, composite indicators, and longitudinal monitoring of directional systems.",
      contactTitle: "Contact and map · danswholesaleplants",
      contactDescription: "Practical information, interactive map, and form to coordinate spatial orientation initiatives.",
      faqTitle: "FAQ on spatial orientation and digital signage",
      faqDescription: "Detailed answers to frequent questions about space mapping, pedestrian mobility, and accessibility.",
      termsTitle: "Terms of use · danswholesaleplants",
      termsDescription: "Usage conditions, responsibilities, and legal framework for the danswholesaleplants website.",
      privacyTitle: "Privacy policy · danswholesaleplants",
      privacyDescription: "Collection, use, and retention of personal data for danswholesaleplants activities.",
      cookiesTitle: "Cookie policy · danswholesaleplants",
      cookiesDescription: "Description of cookies in use, their purposes, retention periods, and management options.",
      refundTitle: "Withdrawal policy · danswholesaleplants",
      refundDescription: "Procedures, timelines, and adjustments applicable to information exchanges.",
      disclaimerTitle: "Disclaimer · danswholesaleplants",
      disclaimerDescription: "Usage limits, absence of guarantees, and scope of published information.",
      thankYouTitle: "Thank you for your message · danswholesaleplants",
      thankYouDescription: "Form submission confirmation and next steps.",
      notFoundTitle: "Page not found · danswholesaleplants",
      notFoundDescription: "The requested page could not be found. Explore the available wayfinding resources."
    },
    common: {
      skipLink: "Skip to main content",
      languageLabel: "Language",
      brandTagline: "Spatial orientation engineering",
      manageCookies: "Cookie preferences",
      currentYearPrefix: "©",
      readMore: "Discover",
      backHome: "Return home",
      exploreResources: "Explore resources"
    },
    nav: {
      home: "Home",
      services: "Expertise",
      about: "About",
      blog: "Publications",
      faq: "Questions",
      contact: "Contact"
    },
    footer: {
      title: "danswholesaleplants",
      subtitle: "Analysis and design of spatial orientation systems",
      phone: "Phone: +32 2 123 45 67",
      email: "Email: contact@danswholesaleplants.com",
      address: "Address: Rue de la Loi 200, 1040 Brussels, Belgium",
      rights: "All rights reserved.",
      terms: "Terms of use",
      privacy: "Privacy",
      cookies: "Cookies",
      refund: "Withdrawal policy",
      disclaimer: "Disclaimer"
    },
    home: {
      heroTitle: "Coordinating spatial orientation in complex environments",
      heroSubtitle: "danswholesaleplants structures the understanding of indoor journeys, digital signage, and interactive plans to streamline pedestrian mobility and infrastructure legibility across Belgium.",
      heroCtaPrimary: "Map user trajectories",
      heroCtaSecondary: "Consult methodological frameworks",
      heroStat1Label: "Spaces analysed",
      heroStat1Value: "48 public sites",
      heroStat2Label: "Wayfinding datasets",
      heroStat2Value: "125 UX models",
      heroStat3Label: "Iterations reviewed",
      heroStat3Value: "312 tested routes",
      featuredTitle: "Reasoned mapping of circulation flows",
      featuredIntro: "Each intervention relies on a combined reading of spatial data, visual signals, and pedestrian practices to clarify decision sequences.",
      featureCard1Title: "Orientation checkpoint audits",
      featureCard1Text: "Identify transition zones, understand decision density, and rank active wayfinding cues within movement sequences.",
      featureCard2Title: "Comparative signage matrices",
      featureCard2Text: "Synchronise analogue and digital supports, weighting them by viewing distance and required cognitive effort.",
      featureCard3Title: "User scenario modelling",
      featureCard3Text: "Build multi-profile scenarios, simulate successive bifurcations, and measure UX impact on journey continuity.",
      featureCard4Title: "Interactive relational maps",
      featureCard4Text: "Structure points of interest, anchor sensitive areas, and visualise interconnections to reinforce built environment readability.",
      methodTitle: "Operational framework for indoor navigation",
      methodIntro: "A three-part methodology blends observation, experimentation, and synthesis to orchestrate guidance systems in all their complexity.",
      methodStep1Title: "Multi-scale observation",
      methodStep1Text: "Field surveys, photographic measurements, and signage inventories combine with targeted qualitative interviews.",
      methodStep2Title: "Iteration and prototyping",
      methodStep2Text: "Route combinations, storyboards, and on-site tests confront hypotheses with real usage patterns.",
      methodStep3Title: "Analysis and governance",
      methodStep3Text: "Graphic outputs, decision matrices, and actionable recommendations sustain long-term wayfinding choices.",
      recommendationsTitle: "Structuring recommendations",
      recommendationsIntro: "Guidelines focus on aligning architecture, data, and usage within balanced governance frameworks.",
      recommendation1Title: "Stabilise reference frames",
      recommendation1Text: "Consolidate a shared documentation base, clarify signage logic, and formalise validation circuits.",
      recommendation2Title: "Sequence wayfinding cues",
      recommendation2Text: "Break down information, pace visual reminders, and preserve multi-channel coherence along entire journeys.",
      recommendation3Title: "Steer maintenance cycles",
      recommendation3Text: "Build ageing indicators, schedule digital updates, and document morphologic decisions.",
      recommendation4Title: "Align data streams",
      recommendation4Text: "Ensure interoperability across BIM models, heritage inventories, and usage maps for transversal monitoring.",
      testimonialsTitle: "Voices from transformed environments",
      testimonialsIntro: "Public institutions share feedback on harmonised journeys and clarified direction schemes.",
      testimonial1Quote: "danswholesaleplants helped harmonise directional cues and reveal critical hesitation points across our hospital campus.",
      testimonial1Author: "Technical direction · Metropolitan hospital network",
      testimonial2Quote: "The pedestrian scenarios and readability metrics informed our planning decisions while respecting heritage constraints.",
      testimonial2Author: "Urban planning unit · City of Liège",
      testimonial3Quote: "Narrative mapping brought clarity to a fragmented office building and eased the onboarding of new occupants.",
      testimonial3Author: "Real estate coordination · Federal administration",
      resourcesTitle: "Resources and further reading",
      resourcesIntro: "Studies, protocols, and methodological tools to deepen wayfinding analysis.",
      resourcesItem1Title: "Wayfinding data interpretation guide",
      resourcesItem1Text: "A framework to decode weak signals and combine perception with performance.",
      resourcesItem2Title: "Spatial accessibility reference",
      resourcesItem2Text: "Operational checklist embedding multi-profile needs within journeys.",
      resourcesItem3Title: "Narrative mapping templates",
      resourcesItem3Text: "Visual structures and metadata patterns for evolving interactive plans."
    },
    services: {
      heroTitle: "Scope of deployed expertise",
      heroSubtitle: "Each strand outlines the analytical angles and methodological deliverables used to understand journeys and guidance plans.",
      heroBadge: "Modular approach",
      introTitle: "Five axes orchestrating orientation",
      introText: "Expertise spans the full analytical cycle: observation, informational design, modelling, accessibility, and UX assessment.",
      service1Title: "Analysing spatial orientation challenges",
      service1Description: "Inventory wayfinding cues, map uncertainty zones, and cross architectural constraints with pedestrian flows.",
      service1Item1: "Map friction points and prolonged waiting areas.",
      service1Item2: "Run on-site observations and video captures to qualify behaviours.",
      service1Item3: "Build effort/decision matrices for every travel sequence.",
      service1Item4: "Analyse intra- and inter-modal correspondences.",
      service2Title: "Designing digital signage systems",
      service2Description: "Deploy graphic principles, curate dynamic content, and align with existing physical supports.",
      service2Item1: "Define information levels by reading distance.",
      service2Item2: "Prepare content grids and real-time update scenarios.",
      service2Item3: "Prototype touch interfaces and run usability audits.",
      service2Item4: "Ensure alignment with architecture and scenography.",
      service3Title: "Modelling user pathways",
      service3Description: "Build travel hypotheses, simulate flow heads, and validate through directed testing.",
      service3Item1: "Produce pedestrian heatmaps segmented by profile.",
      service3Item2: "Draft critical decision storyboards and visual cues.",
      service3Item3: "Measure comprehension and journey time evolution.",
      service3Item4: "Recommend circulation axis hierarchies.",
      service4Title: "Spatial accessibility integration",
      service4Description: "Check standards, analyse sensory cues, and embed specific usage requirements within travel chains.",
      service4Item1: "Conduct accompanied journeys with specific-needs users.",
      service4Item2: "Design tactile trails and sonic alternatives for key cues.",
      service4Item3: "Assess visual contrasts and relief readability.",
      service4Item4: "Provide interview protocols and field team training.",
      service5Title: "Research on infrastructure readability",
      service5Description: "Deploy measurement schemes, dedicated dashboards, and longitudinal follow-up of guidance performance.",
      service5Item1: "Readability indicators weighted by space and user typology.",
      service5Item2: "Comparative audits before and after signage deployment.",
      service5Item3: "Graphic syntheses steering maintenance phases.",
      service5Item4: "Usage observatories and documented qualitative feedback.",
      methodologyTitle: "Intervention methodology",
      methodologyText: "An incremental journey where phases overlap to secure robust decisions.",
      methodologyItem1Title: "Strategic framing",
      methodologyItem1Text: "Clarify objectives, map stakeholders, and frame cartographic outputs.",
      methodologyItem2Title: "Iteration and prototyping",
      methodologyItem2Text: "Visual back-and-forth, scenario workshops, and quick testing prevent blind spots.",
      methodologyItem3Title: "Data governance",
      methodologyItem3Text: "Set up references, documentation, and update scripts to anchor signage in time."
    },
    about: {
      heroTitle: "A structure dedicated to spatial orientation",
      heroSubtitle: "danswholesaleplants blends architecture, informational design, and mobility sciences to grasp human circulation in complex environments.",
      missionTitle: "Mission",
      missionText: "Connect physical, digital, and human dimensions of wayfinding to deliver coherent experiences within public infrastructures.",
      visionTitle: "Vision",
      visionText: "Design transparent guidance systems that highlight architecture, streamline flows, and enhance accessibility everywhere.",
      valuesTitle: "Working principles",
      valuesItem1Title: "Transversality",
      valuesItem1Text: "Bridge architects, urban planners, designers, and operational leaders.",
      valuesItem2Title: "Sobriety",
      valuesItem2Text: "Favour readable, well-documented, and sustainable solutions.",
      valuesItem3Title: "Measurement",
      valuesItem3Text: "Rely on tangible indicators to steer adjustments.",
      valuesItem4Title: "Accessibility",
      valuesItem4Text: "Embed specific usage needs from the outset.",
      timelineTitle: "Milestones",
      timelineItem1Title: "2014 · Foundations",
      timelineItem1Text: "First signage diagnostics within Brussels administrative buildings.",
      timelineItem2Title: "2017 · Journey modelling",
      timelineItem2Text: "Formalisation of decision matrices and interactive narrative maps.",
      timelineItem3Title: "2019 · Inclusive dimension",
      timelineItem3Text: "Systematic integration of accessibility audits and dedicated user panels.",
      timelineItem4Title: "2022 · Data governance",
      timelineItem4Text: "Workshops on signage references and digital plan maintenance.",
      competenciesTitle: "Core competencies",
      competenciesItem1: "Multi-scale spatial analysis and geolocated surveys.",
      competenciesItem2: "Informational design and graphic grid creation.",
      competenciesItem3: "Facilitation of cross-disciplinary workshops.",
      competenciesItem4: "Framing of digital cartographic projects.",
      competenciesItem5: "Qualitative and quantitative journey assessment.",
      approachTitle: "Three-movement approach",
      approachStep1Title: "Immersion",
      approachStep1Text: "Understand existing uses through observation and targeted interviews.",
      approachStep2Title: "Composition",
      approachStep2Text: "Structure journeys, build prototypes, and test swiftly.",
      approachStep3Title: "Transmission",
      approachStep3Text: "Document, train, and hand over methodologies to internal teams."
    },
    blog: {
      heroTitle: "Publications and research notes",
      heroSubtitle: "Analytical perspectives on indoor navigation, interactive plans, and urban legibility.",
      heroBadge: "Ongoing insights",
      introTitle: "Latest articles",
      introText: "Summaries, case studies, and feedback from Belgian and European missions.",
      card1Title: "Interpreting wayfinding data in multimodal hubs",
      card1Excerpt: "Which indicators help decode decisions in hubs combining trains, tramways, and pedestrian corridors?",
      card2Title: "Inclusive accessibility across indoor journeys",
      card2Excerpt: "How to align travel chains, sensory cues, and clarity for every user profile?",
      card3Title: "Narrative mapping for complex environments",
      card3Excerpt: "Structure information to translate architectural complexity into understandable sequences.",
      card4Title: "Digital signage and pedestrian experience",
      card4Excerpt: "Merge interfaces and physical supports to secure continuity.",
      card5Title: "Measuring the effectiveness of indoor directional schemes",
      card5Excerpt: "What indicators and monitoring frequency steer performance?",
      readPost: "Read article"
    },
    contact: {
      heroTitle: "Contact and collaboration channels",
      heroSubtitle: "Let’s align spatial orientation objectives with tailored operational frameworks for your environments.",
      infoTitle: "Practical information",
      phoneLabel: "Phone",
      emailLabel: "Email",
      addressLabel: "Address",
      hoursLabel: "Availability",
      hoursText: "Monday to Friday · 09:00 — 18:00 (CET)",
      mapTitle: "Location in Brussels",
      formTitle: "Coordination request form",
      formIntro: "Describe your environment and objectives to activate a contextual diagnosis.",
      fieldNameLabel: "Full name",
      fieldNamePlaceholder: "Your identity",
      fieldEmailLabel: "Email address",
      fieldEmailPlaceholder: "name@organisation.be",
      fieldOrganisationLabel: "Organisation",
      fieldOrganisationPlaceholder: "Structure or institution",
      fieldPurposeLabel: "Main purpose",
      fieldPurposeOption1: "Wayfinding diagnostic",
      fieldPurposeOption2: "Journey modelling",
      fieldPurposeOption3: "Accessibility and inclusion",
      fieldPurposeOption4: "Documentation and governance",
      fieldMessageLabel: "Message",
      fieldMessagePlaceholder: "Describe the environment, challenges, and key milestones.",
      submitButton: "Send to confirmation page",
      mapCaption: "OpenStreetMap view centred on Rue de la Loi 200, Brussels."
    },
    faq: {
      heroTitle: "Frequently asked questions",
      heroSubtitle: "Detailed answers describing methodology and use cases for spatial orientation.",
      item1Question: "How does a spatial wayfinding audit start?",
      item1Answer: "Preparatory work gathers plans, signage documents, and footfall data. Immersive visits confirm observations and reveal priority zones.",
      item2Question: "Which tools help analyse pedestrian flows?",
      item2Answer: "Manual mapping, anonymised sensors, and timed observations are combined to decode stops, bifurcations, and waiting times.",
      item3Question: "How to embed accessibility from the outset?",
      item3Answer: "Multi-profile needs are captured in an accessibility reference guiding user tests, support hierarchy, and sensory alternatives.",
      item4Question: "What role does digital signage play?",
      item4Answer: "It complements static media, notably during frequent events. Effectiveness depends on clear content governance and cross-channel design.",
      item5Question: "How to measure a guidance system’s performance?",
      item5Answer: "Readability, journey time, and qualified satisfaction indicators are tracked before and after each iteration to steer decisions.",
      item6Question: "How long to formalise a signage reference?",
      item6Answer: "Depending on site scale, allocate six to twelve weeks including workshops, prototyping, and technical documentation."
    },
    terms: {
      intro: "These terms govern the use of danswholesaleplants.com. Accessing the site implies full acceptance of the following clauses.",
      section1Title: "1. Purpose",
      section1Text: "Define the conditions for accessing spatial orientation and digital signage content published by danswholesaleplants.",
      section2Title: "2. Acceptance",
      section2Text: "Using the site means unreserved agreement with these terms. Any contrary usage is prohibited.",
      section3Title: "3. Content access",
      section3Text: "Resources are provided for information only. danswholesaleplants may modify, suspend, or withdraw any content without notice.",
      section4Title: "4. Intellectual property",
      section4Text: "Texts, visuals, and informational structures are protected. Reproduction or distribution requires prior written authorisation.",
      section5Title: "5. Use of information",
      section5Text: "Content does not constitute binding advice. Users remain responsible for their interpretations and decisions.",
      section6Title: "6. External contributions",
      section6Text: "Testimonials and feedback are reviewed before publication. Non-compliant submissions may be refused or removed.",
      section7Title: "7. Hyperlinks",
      section7Text: "Links to the site are permitted provided they do not harm danswholesaleplants’ reputation or mislead about content nature.",
      section8Title: "8. Liability",
      section8Text: "danswholesaleplants cannot be held liable for damages resulting from improper use or misinterpretation of information.",
      section9Title: "9. Availability",
      section9Text: "The site operates 24/7 except for maintenance or force majeure. Continuous availability is not guaranteed.",
      section10Title: "10. Data protection",
      section10Text: "Data collected via forms is processed according to the privacy policy available on the site.",
      section11Title: "11. Cookies",
      section11Text: "Site operations rely on cookies described in the dedicated policy. Users may adjust preferences at any time.",
      section12Title: "12. Changes to terms",
      section12Text: "danswholesaleplants may amend these terms to reflect legal or technical evolutions. Update date appears on the page header.",
      section13Title: "13. Applicable law",
      section13Text: "Belgian law applies. Courts of Brussels have jurisdiction in case of dispute.",
      section14Title: "14. Contact",
      section14Text: "Questions about these terms can be sent to contact@danswholesaleplants.com or via the contact page."
    },
    privacy: {
      intro: "This policy outlines how personal data is processed within danswholesaleplants.com.",
      section1Title: "1. Controller",
      section1Text: "The controller is danswholesaleplants, Rue de la Loi 200, 1040 Brussels. Contact email: contact@danswholesaleplants.com.",
      section2Title: "2. Data collected",
      section2Text: "Form submissions (identity, email, organisation, message) and cookie preferences are recorded.",
      section3Title: "3. Purposes",
      section3Text: "Data supports responses, meeting coordination, and documentation of wayfinding needs.",
      section4Title: "4. Legal basis",
      section4Text: "Processing relies on danswholesaleplants’ legitimate interest to manage professional exchanges and share information.",
      section5Title: "5. Retention periods",
      section5Text: "Contact data is stored for 24 months after the last exchange. Cookie preferences are stored for 12 months.",
      section6Title: "6. Recipients",
      section6Text: "Information is limited to authorised internal teams and is not shared without approval.",
      section7Title: "7. Data subject rights",
      section7Text: "Individuals may access, rectify, oppose, limit, or erase data. Requests are handled via email.",
      section8Title: "8. Security",
      section8Text: "Organisational and technical measures protect data against unauthorised access.",
      section9Title: "9. Cookies",
      section9Text: "Cookie usage is detailed in the dedicated policy. Users can change preferences at any time.",
      section10Title: "10. Contact and recourse",
      section10Text: "To exercise rights, email contact@danswholesaleplants.com. Appeals can be made to the Belgian Data Protection Authority."
    },
    cookies: {
      intro: "This page explains the cookies used on danswholesaleplants.com and how you can manage them.",
      section1Title: "1. Definition",
      section1Text: "A cookie is a file saved on your device to store navigation details.",
      section2Title: "2. Managing preferences",
      section2Text: "The dedicated banner lets you accept, refuse, or customise cookies. Your choice is stored for 12 months.",
      tableTitle: "Summary table",
      tableHeadName: "Name",
      tableHeadProvider: "Provider",
      tableHeadType: "Type",
      tableHeadPurpose: "Purpose",
      tableHeadDuration: "Duration",
      tableRow1Name: "cookie_consent",
      tableRow1Provider: "danswholesaleplants",
      tableRow1Type: "Necessary",
      tableRow1Purpose: "Store consent preferences.",
      tableRow1Duration: "12 months",
      tableRow2Name: "session_layout",
      tableRow2Provider: "danswholesaleplants",
      tableRow2Type: "Preferences",
      tableRow2Purpose: "Remember layout and interface settings.",
      tableRow2Duration: "6 months",
      tableRow3Name: "analytics_flow",
      tableRow3Provider: "danswholesaleplants",
      tableRow3Type: "Analytics",
      tableRow3Purpose: "Measure aggregated navigation between sections.",
      tableRow3Duration: "13 months",
      section3Title: "3. Disabling cookies",
      section3Text: "You may configure your browser to block cookies entirely. Some services may then be limited.",
      section4Title: "4. Updates",
      section4Text: "This policy is reviewed regularly to reflect evolving usage and regulation."
    },
    refund: {
      intro: "This policy describes withdrawal modalities applicable to information and document exchanges.",
      section1Title: "1. Scope",
      section1Text: "It applies to documents shared through the site or via email following a form submission.",
      section2Title: "2. Withdrawal right",
      section2Text: "Any request to withdraw a shared document can be made within 14 days after transmission.",
      section3Title: "3. Procedure",
      section3Text: "Send your request to contact@danswholesaleplants.com specifying the document and exchange date.",
      section4Title: "4. Handling",
      section4Text: "Acknowledgement is provided within five working days along with corrective actions.",
      section5Title: "5. Limitations",
      section5Text: "Public resources or items already embedded in references can be removed only after impact review.",
      section6Title: "6. Archiving",
      section6Text: "Removed versions are kept for internal traceability for up to 12 months.",
      section7Title: "7. Adjustments",
      section7Text: "When deletion is not possible, an amended version may be proposed to reflect the expectations received.",
      section8Title: "8. Collaboration",
      section8Text: "Collaboration with requesting teams is encouraged to document needs precisely.",
      section9Title: "9. Changes",
      section9Text: "This policy may evolve to match emerging documentation practices.",
      section10Title: "10. Contact",
      section10Text: "Questions about withdrawal can be sent via the contact page or the listed email address."
    },
    disclaimer: {
      intro: "Information on danswholesaleplants.com is provided for informational purposes only.",
      section1Title: "1. No guarantee",
      section1Text: "danswholesaleplants does not guarantee content exhaustiveness or permanent updates.",
      section2Title: "2. Liability",
      section2Text: "Users remain responsible for interpreting and using the information.",
      section3Title: "3. No advice",
      section3Text: "Content shall not be considered personalised operational or legal advice.",
      section4Title: "4. External links",
      section4Text: "Links to third-party resources do not imply responsibility for their content.",
      section5Title: "5. Changes",
      section5Text: "Information may change at any time without notice.",
      section6Title: "6. Contact",
      section6Text: "For clarifications, use the form or contact@danswholesaleplants.com."
    },
    thankYou: {
      heroTitle: "Thank you for your message",
      heroSubtitle: "Your request has been sent successfully. We will review its details before getting back to you.",
      nextStepsTitle: "Next steps",
      nextStepsText: "Expect a response within five working days to clarify requirements and schedule exploratory sessions if needed.",
      backButton: "Return to publications"
    },
    notFound: {
      heroTitle: "The requested page cannot be found",
      heroSubtitle: "The followed path no longer matches available content. Navigate to key resources to continue exploring.",
      buttonText: "Back to home"
    },
    notifications: {
      formSubmitted: "Form sent to confirmation page.",
      formInvalid: "Please complete the required fields before sending.",
      cookieSaved: "Cookie preferences saved.",
      cookieDeclined: "Optional cookies disabled.",
      cookieAccepted: "Optional cookies enabled."
    },
    cookieBanner: {
      title: "Cookie management",
      description: "We use cookies to ensure site operations and anonymously analyse navigation.",
      necessary: "Necessary",
      necessaryDescription: "Required for the site to function. Always active.",
      preferences: "Preferences",
      preferencesDescription: "Store your layout and interface settings.",
      analytics: "Analytics",
      analyticsDescription: "Measure aggregated journeys through sections.",
      marketing: "Marketing",
      marketingDescription: "Not used at the moment.",
      acceptAll: "Accept all",
      declineAll: "Decline all",
      save: "Save",
      manage: "Customise",
      openButton: "Open cookie preferences",
      close: "Close"
    },
    blogPosts: {
      post1: {
        h1: "Interpreting wayfinding data in multimodal hubs",
        h2: "Contextualising directional indicators",
        h3: "Towards a systemic reading of intersecting journeys",
        paragraphs: [
          "Belgian multimodal hubs combine rail lines, metro networks, tramways, and elevated or underground pedestrian corridors. Understanding wayfinding starts with accurately mapping interactions between mobility layers. Raw data—counts, photographic surveys, incident logs—only make sense once aligned with the actual decision sequences observed on site.",
          "The first step ranks directional nodes by intensity. We distinguish major inflection points, where multiple choices emerge, from adjustment points, where users confirm or correct their trajectory. This hierarchy helps weigh collected indicators: a high volume of information requests has a different meaning before or after a complex bifurcation.",
          "Temporal granularity is equally decisive. Train arrival cycles, bus synchronisation, or tourist peaks reshape pedestrian density and perceived cognitive load. Data must therefore be segmented by time ranges and paired with qualitative observations to avoid smoothing out critical situations.",
          "The next phase pairs quantitative outputs with guided journeys. Accompanied routes, where observers note every micro-decision, provide invaluable context for understanding statistical anomalies. Why does a flow bypass a staircase despite its signage? Is an overabundance of cues ignored due to information overload? These questions require combining numbers with stories.",
          "Relating digital and analogue supports is another analytical pivot. A dynamic screen may display accurate information yet remain unnoticed because of glare or low positioning. Data interpretation must integrate sensory dimensions. Measured performance (travel time, error volume) is therefore linked to perceived experience, captured through short interviews or location-based surveys.",
          "Synthesis often takes the form of narrative maps. Each journey segment receives a sheet combining key indicators, photographs, and recommendations. This documentation enables architects, operations managers, and transit authorities to share a common understanding. Priority actions emerge clearly: reposition cues, harmonise graphic codes, add tactile markers, or broadcast audio prompts.",
          "Finally, the analysis cannot freeze in time. Multimodal hubs evolve as lines change or flows reorganise. Establishing a continuous review loop—quarterly for data, yearly for accompanied journeys—keeps the systemic reading relevant and aligned with real usage."
        ]
      },
      post2: {
        h1: "Inclusive accessibility across indoor journeys",
        h2: "Understanding user diversity",
        h3: "Embedding feedback within spatial governance",
        paragraphs: [
          "Accessibility is not just about compliance. In a Belgian public building it manifests as the ability for every person to orient, circulate, locate, and achieve goals without disruption. Recognising user diversity is therefore essential. People with visual impairments, visitors unfamiliar with the site, temporary or regular users all adopt different strategies and expectations.",
          "An inclusive approach starts with a representative panel. Each member explores the space at their own pace. Observers note relied-upon cues, hesitation points, and required interactions. Comments are structured into experience maps revealing areas of high cognitive load or insufficient contrast.",
          "Sensory feedback plays a central role. Visual contrasts are measured, floor textures reviewed, and light levels recorded. For certain profiles, discomfort stems from overload rather than lack of cues: too many panels, conflicting typography, overlapping instructions. Inclusive accessibility therefore seeks balance between precision and sobriety.",
          "Alternatives must be designed together. A tactile marker alone is insufficient if unsupported by coherent audio descriptions. Likewise, a simplified map gains value when linked to a screen-reader-friendly digital plan. Each support forms part of a broader ecosystem that must remain consistent across formats.",
          "Documentation provides further leverage. Technical teams and front-of-house staff need clear references explaining each cue’s intent. Without such foundation, ad-hoc initiatives risk weakening overall coherence. Governance ensures every addition is evaluated against accessibility requirements.",
          "Periodic audits consolidate the system. They mix quantitative measures—journey times, assistance requests—with refreshed qualitative feedback. Identified gaps feed an action plan including training, support adjustments, and supplementary testing. Inclusion becomes a living process supported by shared indicators.",
          "Adopting this inclusive stance shifts the building’s perception. Accessibility evolves from obligation to guiding principle, improving overall fluidity and highlighting existing assets for every visitor."
        ]
      },
      post3: {
        h1: "Narrative mapping for complex environments",
        h2: "Crafting a clear spatial storyline",
        h3: "From visual narrative to long-term maintenance",
        paragraphs: [
          "In labyrinthine buildings, maps must evolve beyond static layouts. They need to tell a story, clarifying space, ranking priorities, and anticipating bifurcations. This narrative emerges through successive layers, each adding clarity without overwhelming users with unnecessary detail.",
          "The starting point is a shared visual vocabulary. Functional zones receive consistent colour codes, structural paths use bold continuous lines, while secondary areas adopt subtle textures. The goal is intuitive reading, even during brief consultations on wall-mounted plans or touch interfaces.",
          "Metadata carries strategic weight. Every cartographic cue links to complementary information: available services, opening hours, accessibility, estimated time. This dataset feeds digital supports, ensuring consistent outputs across channels. When a service moves, a central update automatically cascades to all media.",
          "Narrative sequencing also matters. Showing every floor at once can confuse. Progressive zoom is often preferred: overall layout, targeted level, then the final stretch. This graduated approach supports decision-making and limits cognitive load.",
          "Interactive devices add further potential. Combining maps with user scenarios allows pre-calculated routes, thematic filters, or contextual alerts. Yet functionality must remain restrained: primary navigation should stay accessible in a few gestures.",
          "Maintenance is planned from day one. Vector templates, icon libraries, and typographic rules streamline updates. A governance committee—architects, managers, communication leads—arbitrates major changes to preserve coherence.",
          "Lastly, user evaluation verifies the narrative’s value. Map-reading workshops, A/B tests, and discrete observations assess adjustments. Over time, narrative mapping becomes a lived component of the welcome strategy, supporting site transformations while maintaining clarity."
        ]
      },
      post4: {
        h1: "Digital signage and pedestrian experience",
        h2: "Aligning digital interfaces with physical cues",
        h3: "Maintaining coherence over time",
        paragraphs: [
          "Screens and guidance apps are multiplying across public venues. They excel at broadcasting dynamic information, yet must integrate with physical signage already structuring pedestrian experience. The challenge lies in orchestrating these elements so they reinforce one another.",
          "Begin by mapping existing supports. Directional panels, wall maps, floor markings—all require inventory and functional assessment. Screens should not indiscriminately duplicate information but extend it. For instance, an interactive plan can adapt to temporary constraints while fixed panels provide foundational cues.",
          "Usability is another cornerstone. Interfaces must remain readable under varied lighting and accessible to visitors of different stature or wheelchair users. Quick on-site testing helps fine-tune typography size, contrast, and navigation logic.",
          "Content updates must be controlled. A screen showing outdated information undermines trust in the entire system. Clear governance assigns ownership, sets refresh schedules, and triggers alerts when anomalies arise. Digital signage then retains value without burdening teams.",
          "Visual coherence remains essential. Graphic codes, icons, and terminology should align across media. Users should never translate a digital label to a physical equivalent. Consistency eases media transitions and reduces cognitive effort.",
          "Ongoing monitoring completes the loop. Anonymous sensors or discreet observations reveal whether screens are consulted, for how long, and under which conditions. These findings inform future changes: relocating supports, adding functions, or simplifying menus.",
          "Ultimately, digital signage does not replace physical cues. It enriches them with adaptable information. When both dimensions are orchestrated carefully, pedestrian experience gains fluidity, responsiveness, and navigational comfort."
        ]
      },
      post5: {
        h1: "Measuring the effectiveness of indoor directional schemes",
        h2: "Defining actionable indicators",
        h3: "Continuous improvement loops",
        paragraphs: [
          "Even a well-crafted directional scheme requires regular evaluation. Measuring effectiveness verifies that information reaches users, is understood, and drives expected behaviour. Constructing relevant indicators is therefore essential.",
          "Quantitative indicators monitor observable performance. Average journey time, number of wrong turns, and volume of assistance requests provide a factual basis. Yet they must be contextualised per zone to distinguish exceptions from persistent trends.",
          "Qualitative observations complement the picture. Interviewing users, analysing traced routes, or gathering comments uncovers nuances hidden in figures. A signage system may appear efficient yet trigger discomfort or confusion.",
          "Measurement frequency depends on site dynamics. Stable administrative buildings may require annual audits, while cultural venues with rotating events benefit from quarterly reviews. These regular checkpoints build a culture of steady refinement.",
          "Interpretation relies on a shared dashboard. Each indicator includes its definition, source, frequency, and alert threshold. Operational teams can then prioritise interventions: repositioning panels, adding reminders, or clarifying terminology.",
          "Insights must translate into tangible actions. When friction emerges, a testing protocol is activated: produce an alternative, trial it on site, and collect feedback. Learnings are documented to consolidate successes and prevent recurring issues.",
          "Transparency strengthens the process. Communicating updates, explaining changes, and inviting ongoing feedback cultivate trust. The directional scheme becomes a living system, co-built and steered by robust evidence."
        ]
      }
    }
  }
};

function getTranslation(dict, key) {
  return key.split('.').reduce((acc, part) => (acc && acc[part] !== undefined ? acc[part] : null), dict);
}

function applyTranslations(lang) {
  const dictionary = I18N[lang] || I18N[DEFAULT_LANG];
  document.documentElement.setAttribute('lang', lang);

  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18n);
    if (translation !== null) {
      el.textContent = translation;
    }
  });

  document.querySelectorAll('[data-i18n-html]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18nHtml);
    if (translation !== null) {
      el.innerHTML = translation;
    }
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18nPlaceholder);
    if (translation !== null) {
      el.setAttribute('placeholder', translation);
    }
  });

  document.querySelectorAll('[data-i18n-alt]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18nAlt);
    if (translation !== null) {
      el.setAttribute('alt', translation);
    }
  });

  document.querySelectorAll('[data-i18n-title]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18nTitle);
    if (translation !== null) {
      el.textContent = translation;
      if (el.tagName.toLowerCase() === 'title') {
        document.title = translation;
      }
    }
  });

  document.querySelectorAll('[data-i18n-meta]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18nMeta);
    if (translation !== null) {
      el.setAttribute('content', translation);
    }
  });

  document.querySelectorAll('[data-i18n-aria]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18nAria);
    if (translation !== null) {
      el.setAttribute('aria-label', translation);
    }
  });

  document.querySelectorAll('[data-i18n-value]').forEach((el) => {
    const translation = getTranslation(dictionary, el.dataset.i18nValue);
    if (translation !== null) {
      el.setAttribute('value', translation);
    }
  });
}

function setActiveLanguageButton(lang) {
  document.querySelectorAll('[data-lang]').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
    btn.setAttribute('aria-pressed', btn.dataset.lang === lang ? 'true' : 'false');
  });
}

function initLanguage() {
  const stored = localStorage.getItem(STORAGE_LANG_KEY);
  const lang = stored && I18N[stored] ? stored : DEFAULT_LANG;
  applyTranslations(lang);
  setActiveLanguageButton(lang);
}

function changeLanguage(lang) {
  if (!I18N[lang]) return;
  localStorage.setItem(STORAGE_LANG_KEY, lang);
  applyTranslations(lang);
  setActiveLanguageButton(lang);
}

function initLanguageToggle() {
  document.querySelectorAll('[data-lang]').forEach((btn) => {
    btn.addEventListener('click', () => {
      changeLanguage(btn.dataset.lang);
    });
  });
}

function initNavigation() {
  const toggle = document.querySelector('[data-nav-toggle]');
  const navList = document.querySelector('[data-nav]');
  if (!toggle || !navList) return;

  toggle.addEventListener('click', () => {
    const expanded = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
    if (expanded) {
      navList.classList.remove('open');
    } else {
      navList.classList.add('open');
    }
  });

  navList.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      navList.classList.remove('open');
    });
  });
}

function initAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );

  document.querySelectorAll('[data-animate]').forEach((el) => observer.observe(el));
}

function showToast(messageKey) {
  const container = document.querySelector('[data-toast-container]');
  if (!container) return;
  const lang = localStorage.getItem(STORAGE_LANG_KEY) || DEFAULT_LANG;
  const translation = getTranslation(I18N[lang], `notifications.${messageKey}`);
  if (!translation) return;

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <div class="toast-icon">•</div>
    <div>${translation}</div>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 400);
  }, 4200);
}

function getCookieState() {
  const stored = localStorage.getItem(COOKIE_STORAGE_KEY);
  if (!stored) {
    return {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      updatedAt: null
    };
  }
  try {
    return JSON.parse(stored);
  } catch (error) {
    return {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      updatedAt: null
    };
  }
}

function saveCookieState(state) {
  localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify(state));
}

function updateCookieBannerState() {
  const banner = document.querySelector('[data-cookie-banner]');
  const manageButton = document.querySelector('[data-cookie-open]');
  if (!banner) return;
  const state = getCookieState();
  const hasDecision = state.updatedAt !== null;
  if (hasDecision) {
    banner.classList.remove('visible');
    if (manageButton) {
      manageButton.classList.add('visible');
    }
  } else {
    banner.classList.add('visible');
    if (manageButton) {
      manageButton.classList.remove('visible');
    }
  }
  const lang = localStorage.getItem(STORAGE_LANG_KEY) || DEFAULT_LANG;
  const prefToggle = document.querySelector('[data-cookie-toggle="preferences"]');
  const analyticsToggle = document.querySelector('[data-cookie-toggle="analytics"]');
  const marketingToggle = document.querySelector('[data-cookie-toggle="marketing"]');
  if (prefToggle) prefToggle.checked = !!state.preferences;
  if (analyticsToggle) analyticsToggle.checked = !!state.analytics;
  if (marketingToggle) marketingToggle.checked = !!state.marketing;

  // Update descriptions to ensure translations applied when reopening
  applyTranslations(lang);
}

function initCookieBanner() {
  const banner = document.querySelector('[data-cookie-banner]');
  if (!banner) return;

  const acceptAllBtn = banner.querySelector('[data-cookie-action="accept"]');
  const declineAllBtn = banner.querySelector('[data-cookie-action="decline"]');
  const saveBtn = banner.querySelector('[data-cookie-action="save"]');
  const manageBtn = banner.querySelector('[data-cookie-action="manage"]');
  const closeBtn = banner.querySelector('[data-cookie-action="close"]');
  const manageShortcut = document.querySelector('[data-cookie-open]');

  const preferenceToggle = banner.querySelector('[data-cookie-toggle="preferences"]');
  const analyticsToggle = banner.querySelector('[data-cookie-toggle="analytics"]');
  const marketingToggle = banner.querySelector('[data-cookie-toggle="marketing"]');

  function persistAndFeedback(state, feedbackKey) {
    state.updatedAt = new Date().toISOString();
    saveCookieState(state);
    updateCookieBannerState();
    showToast(feedbackKey);
  }

  if (acceptAllBtn) {
    acceptAllBtn.addEventListener('click', () => {
      const state = getCookieState();
      state.preferences = true;
      state.analytics = true;
      state.marketing = true;
      persistAndFeedback(state, 'cookieAccepted');
    });
  }

  if (declineAllBtn) {
    declineAllBtn.addEventListener('click', () => {
      const state = getCookieState();
      state.preferences = false;
      state.analytics = false;
      state.marketing = false;
      persistAndFeedback(state, 'cookieDeclined');
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const state = getCookieState();
      state.preferences = preferenceToggle ? preferenceToggle.checked : false;
      state.analytics = analyticsToggle ? analyticsToggle.checked : false;
      state.marketing = marketingToggle ? marketingToggle.checked : false;
      persistAndFeedback(state, 'cookieSaved');
    });
  }

  function openBanner() {
    if (banner) banner.classList.add('visible');
    if (manageShortcut) manageShortcut.classList.remove('visible');
  }

  if (manageBtn) manageBtn.addEventListener('click', openBanner);
  if (manageShortcut) manageShortcut.addEventListener('click', openBanner);

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      banner.classList.remove('visible');
    });
  }

  [preferenceToggle, analyticsToggle, marketingToggle].forEach((toggle) => {
    if (!toggle) return;
    toggle.addEventListener('change', () => {
      const state = getCookieState();
      state.preferences = preferenceToggle ? preferenceToggle.checked : false;
      state.analytics = analyticsToggle ? analyticsToggle.checked : false;
      state.marketing = marketingToggle ? marketingToggle.checked : false;
      saveCookieState(state);
    });
  });

  updateCookieBannerState();
}

function initContactForm() {
  const form = document.querySelector('[data-contact-form]');
  if (!form) return;

  form.addEventListener('submit', (event) => {
    if (!form.checkValidity()) {
      event.preventDefault();
      showToast('formInvalid');
      return;
    }
    event.preventDefault();
    showToast('formSubmitted');
    setTimeout(() => {
      form.submit();
    }, 650);
  });
}

function setCurrentYear() {
  const yearEl = document.querySelector('[data-year]');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initLanguage();
  initLanguageToggle();
  initNavigation();
  initAnimations();
  initCookieBanner();
  initContactForm();
  setCurrentYear();
});