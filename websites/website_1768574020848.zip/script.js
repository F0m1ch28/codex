document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            navToggle.classList.toggle('active');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                navToggle.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookies = document.querySelector('.cookie-accept');
    const declineCookies = document.querySelector('.cookie-decline');
    const cookieChoice = localStorage.getItem('stoopeqohlCookieChoice');

    if (cookieBanner) {
        if (cookieChoice) {
            cookieBanner.classList.add('hidden');
        }

        const handleChoice = (choice) => {
            localStorage.setItem('stoopeqohlCookieChoice', choice);
            cookieBanner.classList.add('hidden');
        };

        if (acceptCookies) {
            acceptCookies.addEventListener('click', () => handleChoice('accepted'));
        }

        if (declineCookies) {
            declineCookies.addEventListener('click', () => handleChoice('declined'));
        }
    }
});