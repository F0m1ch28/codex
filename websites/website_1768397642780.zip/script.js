document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('#primary-navigation');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const consentKey = 'familynohlCookieConsent';

    if (cookieBanner) {
        const existingConsent = localStorage.getItem(consentKey);
        if (existingConsent) {
            cookieBanner.classList.add('cookie-banner-hidden');
        }

        cookieBanner.querySelectorAll('.cookie-btn').forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                const choice = btn.classList.contains('accept') ? 'accepted' : 'declined';
                localStorage.setItem(consentKey, choice);
                cookieBanner.classList.add('cookie-banner-hidden');
            });
        });
    }
});