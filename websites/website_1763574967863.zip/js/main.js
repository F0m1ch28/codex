document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const currentPage = body.dataset.page;
  const navMenu = document.querySelector('.nav-menu');
  const navToggle = document.querySelector('.nav-toggle');

  if (currentPage && navMenu) {
    navMenu.querySelectorAll('a').forEach(link => {
      if (link.dataset.page === currentPage) {
        link.classList.add('active');
      }
    });
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
      body.classList.toggle('nav-open');
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (navMenu.classList.contains('open')) {
          navMenu.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
          body.classList.remove('nav-open');
        }
      });
    });
  }

  document.querySelectorAll('a[href^="#"]:not([href="#"])').forEach(anchor => {
    anchor.addEventListener('click', event => {
      const targetId = anchor.getAttribute('href').substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const cookieDecline = document.getElementById('cookie-decline');
  const storedPreference = localStorage.getItem('cookiePreference');

  if (cookieBanner) {
    if (!storedPreference) {
      requestAnimationFrame(() => cookieBanner.classList.add('show'));
    }

    const setPreference = value => {
      localStorage.setItem('cookiePreference', value);
      cookieBanner.classList.remove('show');
    };

    cookieAccept?.addEventListener('click', () => setPreference('accepted'));
    cookieDecline?.addEventListener('click', () => setPreference('declined'));
  }

  const form = document.querySelector('.contact-form');
  if (form) {
    form.addEventListener('submit', event => {
      const nameField = form.querySelector('#name');
      const emailField = form.querySelector('#email');
      const messageField = form.querySelector('#message');
      const errorBox = form.querySelector('.form-error');
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      let isValid = true;

      [nameField, emailField, messageField].forEach(field => field.classList.remove('invalid'));
      if (errorBox) errorBox.textContent = '';

      if (!nameField.value.trim()) {
        nameField.classList.add('invalid');
        isValid = false;
      }

      if (!emailPattern.test(emailField.value.trim())) {
        emailField.classList.add('invalid');
        isValid = false;
      }

      if (!messageField.value.trim() || messageField.value.trim().length < 10) {
        messageField.classList.add('invalid');
        isValid = false;
      }

      if (!isValid) {
        event.preventDefault();
        if (errorBox) {
          errorBox.textContent = 'Please complete all required fields before submitting.';
        }
      }
    });
  }

  const yearSpan = document.getElementById('current-year');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
});