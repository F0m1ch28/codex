'use strict';
document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  const toast = document.getElementById('global-toast');
  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const cookieDecline = document.getElementById('cookie-decline');
  const yearSpan = document.getElementById('current-year');
  const animateItems = document.querySelectorAll('[data-animate]');
  const storedPreference = localStorage.getItem('cw-cookie-choice');

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('open');
      body.classList.toggle('disable-scroll');
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        body.classList.remove('disable-scroll');
      });
    });
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  animateItems.forEach(item => observer.observe(item));

  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('toast-show');
    setTimeout(() => {
      toast.classList.remove('toast-show');
    }, 2000);
  };

  const forms = document.querySelectorAll('form[data-redirect]');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const message = 'Mesaj trimis. Vă mulțumim!';
      showToast(message);
      const redirectUrl = form.getAttribute('data-redirect') || form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 1600);
    });
  });

  const hideBanner = choice => {
    if (!cookieBanner) return;
    cookieBanner.classList.remove('show');
    cookieBanner.setAttribute('aria-hidden', 'true');
    if (choice) {
      localStorage.setItem('cw-cookie-choice', choice);
    }
  };

  if (cookieBanner) {
    if (!storedPreference) {
      cookieBanner.classList.add('show');
      cookieBanner.setAttribute('aria-hidden', 'false');
    } else {
      cookieBanner.classList.remove('show');
      cookieBanner.setAttribute('aria-hidden', 'true');
    }
  }

  if (cookieAccept) {
    cookieAccept.addEventListener('click', () => {
      hideBanner('accepted');
      showToast('Preferințe cookie salvate.');
    });
  }

  if (cookieDecline) {
    cookieDecline.addEventListener('click', () => {
      hideBanner('declined');
      showToast('Preferințe cookie actualizate.');
    });
  }
});