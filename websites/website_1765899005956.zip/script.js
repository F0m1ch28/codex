document.addEventListener("DOMContentLoaded", function () {
  var banner = document.getElementById("cookie-banner");
  var acceptBtn = document.getElementById("cookie-accept");
  var declineBtn = document.getElementById("cookie-decline");

  if (!banner || !acceptBtn || !declineBtn) {
    return;
  }

  var consent = localStorage.getItem("gdh_cookie_consent");

  if (!consent) {
    banner.classList.add("active");
  }

  acceptBtn.addEventListener("click", function () {
    localStorage.setItem("gdh_cookie_consent", "accepted");
    banner.classList.remove("active");
  });

  declineBtn.addEventListener("click", function () {
    localStorage.setItem("gdh_cookie_consent", "declined");
    banner.classList.remove("active");
  });
});