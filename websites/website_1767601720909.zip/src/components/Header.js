import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.bar}>
        <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="На головну сторінку">
          <span className={styles.logoLeaf}>🌿</span>
          <span>Квіткова&nbsp;Оптом</span>
        </Link>
        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={isMenuOpen}
          aria-label="Меню навігації"
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={"${styles.nav} ${isMenuOpen ? styles.navOpen : ''}"} aria-label="Головна навігація">
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"}>
            Головна
          </NavLink>
          <NavLink to="/about" onClick={closeMenu} className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"}>
            Про нас
          </NavLink>
          <NavLink to="/assortment" onClick={closeMenu} className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"}>
            Асортимент
          </NavLink>
          <NavLink to="/cooperation" onClick={closeMenu} className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"}>
            Співпраця
          </NavLink>
          <NavLink to="/contacts" onClick={closeMenu} className={({ isActive }) => "${styles.navLink} ${isActive ? styles.active : ''}"}>
            Контакти
          </NavLink>
          <div className={styles.docsGroup}>
            <NavLink to="/privacy" onClick={closeMenu} className={({ isActive }) => "${styles.navSubLink} ${isActive ? styles.active : ''}"}>
              Політика конфіденційності
            </NavLink>
            <NavLink to="/terms" onClick={closeMenu} className={({ isActive }) => "${styles.navSubLink} ${isActive ? styles.active : ''}"}>
              Умови використання
            </NavLink>
          </div>
          <Link to="/contacts" className={styles.ctaButton} onClick={closeMenu}>
            Зв&apos;язатися
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;