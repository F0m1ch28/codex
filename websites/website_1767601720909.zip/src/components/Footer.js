import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Футер сайту">
    <div className={styles.container}>
      <div>
        <h4 className={styles.title}>Квіткова Оптом</h4>
        <p className={styles.text}>
          Постачаємо свіжі квіти для флористичних студій, івент-агенцій та корпоративних клієнтів по всій Україні.
          Натхненно створюємо ринки, де кожна квітка зберігає свою красу.
        </p>
      </div>
      <div>
        <h5 className={styles.subtitle}>Навігація</h5>
        <ul className={styles.list}>
          <li><Link to="/" className={styles.link}>Головна</Link></li>
          <li><Link to="/about" className={styles.link}>Про нас</Link></li>
          <li><Link to="/assortment" className={styles.link}>Асортимент</Link></li>
          <li><Link to="/cooperation" className={styles.link}>Співпраця</Link></li>
        </ul>
      </div>
      <div>
        <h5 className={styles.subtitle}>Документи</h5>
        <ul className={styles.list}>
          <li><Link to="/terms" className={styles.link}>Умови використання</Link></li>
          <li><Link to="/privacy" className={styles.link}>Політика конфіденційності</Link></li>
          <li><Link to="/cookie-policy" className={styles.link}>Політика щодо cookie</Link></li>
        </ul>
      </div>
      <div>
        <h5 className={styles.subtitle}>Контакти</h5>
        <address className={styles.address}>
          <span>м. Київ, вул. Садова, 10</span>
          <Link to="/contacts" className={styles.contactLink}>+380 (44) 123-45-67</Link>
          <Link to="/contacts" className={styles.contactLink}>info@kvitkova-optom.ua</Link>
        </address>
        <div className={styles.socials}>
          <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
            <span>IG</span>
          </a>
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
            <span>FB</span>
          </a>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
            <span>IN</span>
          </a>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} Квіткова Оптом. Україна.</span>
    </div>
  </footer>
);

export default Footer;