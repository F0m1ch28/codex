import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = localStorage.getItem('kvitkovaCookieConsent');
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('kvitkovaCookieConsent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Повідомлення про використання cookie">
      <p>
        Ми використовуємо cookie, щоб покращити ваш досвід співпраці. Продовжуючи роботу з сайтом, ви погоджуєтесь з нашою
        <Link to="/cookie-policy" className={styles.link}> політикою щодо cookie</Link>.
      </p>
      <button type="button" onClick={acceptCookies} className={styles.button}>
        Погодитися
      </button>
    </div>
  );
};

export default CookieBanner;