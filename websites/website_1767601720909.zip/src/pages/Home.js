import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const HeroImage = ({ src, alt }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={styles.heroImageWrapper}>
      {!loaded && <div className={styles.imageSkeleton} aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        onLoad={() => setLoaded(true)}
        className={"${styles.heroImage} ${loaded ? styles.imageVisible : ''}"}
      />
    </div>
  );
};

const CategoryCard = ({ title, description, image }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <Link to="/assortment" className={styles.categoryCard}>
      <div className={styles.categoryImageWrapper}>
        {!loaded && <div className={styles.imageSkeleton} aria-hidden="true" />}
        <img
          src={image}
          alt={title}
          onLoad={() => setLoaded(true)}
          className={"${styles.cardImage} ${loaded ? styles.imageVisible : ''}"}
        />
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
      <span className={styles.categoryAction}>Переглянути деталі</span>
    </Link>
  );
};

const HomePage = () => {
  const advantages = [
    {
      title: 'Безкомпромісна свіжість',
      text: 'Контролюємо холодовий ланцюг на всіх етапах та доставляємо рослини одразу після зрізу.',
      icon: '🌱',
    },
    {
      title: 'Широкий вибір позицій',
      text: 'Понад 150 найменувань квітів та зелені: від класичних троянд до авторських селекцій.',
      icon: '💐',
    },
    {
      title: 'Надійна логістика',
      text: 'Плануємо поставки з урахуванням сезонів, графіків клієнтів та форс-мажорів.',
      icon: '🚚',
    },
    {
      title: 'Індивідуальний супровід',
      text: 'Персональний менеджер та гнучкі рішення під ваш бізнес-проєкт.',
      icon: '🤝',
    },
  ];

  const categories = [
    {
      title: 'Троянди преміум',
      description: 'Різнокольорові сорти з Еквадору, Колумбії та Кенії.',
      image: 'https://images.unsplash.com/photo-1528825871115-3581a5387919?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Екзотичні рослини',
      description: 'Протеї, антуріуми, стіцинтії та інші рідкісні квіти.',
      image: 'https://images.unsplash.com/photo-1514894780887-121968d00567?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Сезонні тепличні',
      description: 'Півонії, тюльпани, хризантеми від локальних фермерів.',
      image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Зелень та наповнення',
      description: 'Евкаліпт, рускус, аспарагус, декоративні гілки.',
      image: 'https://images.unsplash.com/photo-1483794344563-d27a8d18014e?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Авторські мікси',
      description: 'Спеціальні підборки для святкових колекцій та проєктів.',
      image: 'https://images.unsplash.com/photo-1492496913980-501348b61469?auto=format&fit=crop&w=800&q=80',
    },
    {
      title: 'Квіти для мереж',
      description: 'Стабільні постачання для готелів, ресторанів та ритейлерів.',
      image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80',
    },
  ];

  const workflow = [
    {
      step: 'Запит та аналітика потреб',
      details: 'Вивчаємо ваш формат, обсяги, сезонність та очікуваний бюджет закупівель.',
    },
    {
      step: 'Формування пропозиції',
      details: 'Добираємо сорти, погоджуємо графік поставок, готуємо супровідні документи.',
    },
    {
      step: 'Логістика та контроль якості',
      details: 'Організовуємо доставку в оптимальному температурному режимі з фото-звітами.',
    },
    {
      step: 'Післяпродажний супровід',
      details: 'Моніторимо якість, реагуємо на зміну потреб, пропонуємо свіжі рішення.',
    },
  ];

  const testimonials = [
    {
      name: 'Анастасія Романюк',
      company: 'Fleur Event Studio',
      quote:
        'Співпраця з Квітковою Оптом — це впевненість у якості та точності поставок. Команда завжди пропонує нестандартні сорти, що підсилює наші проєкти.',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    },
    {
      name: 'Марко Кравченко',
      company: 'Готель «Skyline»',
      quote:
        'Важливо, що постачальник розуміє потреби готельного бізнесу. Працюємо рік — жодного зриву графіку, квіти тримають форму довше звичайного.',
      avatar: 'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=200&q=80',
    },
    {
      name: 'Олена Федорова',
      company: 'Мережа бутиків «Bloom&Co»',
      quote:
        'Персональний менеджер допомагає планувати сезонні колекції, а глибина асортименту дозволяє створювати унікальні компіляції.',
      avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Квіткова Оптом — Оптові поставки квітів для бізнесу</title>
        <meta
          name="description"
          content="Квіткова Оптом забезпечує бізнес стабільними поставками свіжих квітів, індивідуальним сервісом та професійним підходом."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Свіжі квіти оптом для вашого бізнесу</h1>
          <p>
            Ми створюємо оптові поставки квітів з ідеальною логістикою, ретельним відбором та індивідуальним сервісом. Доступно для
            флористичних студій, івент-агенцій, готелів та корпоративних клієнтів.
          </p>
          <div className={styles.heroActions}>
            <Link to="/contacts" className={styles.primaryButton}>
              Зв&apos;язатися
            </Link>
            <Link to="/cooperation" className={styles.secondaryButton}>
              Дізнатися про співпрацю
            </Link>
          </div>
          <div className={styles.heroHighlights}>
            <div>
              <span>10+</span>
              <p>років у галузі оптових поставок</p>
            </div>
            <div>
              <span>150+</span>
              <p>позицій у постійному асортименті</p>
            </div>
            <div>
              <span>24/7</span>
              <p>підтримка менеджерів</p>
            </div>
          </div>
        </div>
        <HeroImage
          src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1200&q=80"
          alt="Професійний флорист розкладає свіжі квіти для оптової поставки"
        />
      </section>

      <section className={styles.about}>
        <div>
          <h2>Квіткова Оптом — партнер, якому довіряють</h2>
          <p>
            Наша команда поєднує ботанічну експертизу, сучасні технології зберігання та глибоке розуміння потреб B2B-клієнтів. Ми
            працюємо з надійними виробниками з Нідерландів, Еквадору, Кенії та України, аби кожен стебель був досконалим.
          </p>
          <p>
            Основний принцип — прозорість та плановість. Разом ми будуємо системні річні контракти, сезонні колекції та спеціальні
            поставки під ваш бренд.
          </p>
        </div>
        <div className={styles.aboutCard}>
          <h3>Чому з нами комфортно</h3>
          <ul>
            <li>Власний температурний склад у Києві та оперативна доставка по Україні.</li>
            <li>Аналітика продажів та рекомендації під ваш формат.</li>
            <li>Оновлення асортименту щотижня та спеціальні добірки під події.</li>
          </ul>
        </div>
      </section>

      <section className={styles.advantages}>
        <h2>Наші переваги</h2>
        <div className={styles.advantagesGrid}>
          {advantages.map((adv) => (
            <article key={adv.title} className={styles.advantageCard}>
              <span className={styles.advIcon} aria-hidden="true">
                {adv.icon}
              </span>
              <h3>{adv.title}</h3>
              <p>{adv.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.categories}>
        <div className={styles.sectionHeader}>
          <h2>Категорії асортименту</h2>
          <p>
            Відбираємо найкращі сорти та формуємо стабільні партії, щоб ваші букети, інсталяції чи регулярні композиції завжди
            виглядали бездоганно.
          </p>
        </div>
        <div className={styles.categoriesGrid}>
          {categories.map((category) => (
            <CategoryCard
              key={category.title}
              title={category.title}
              description={category.description}
              image={category.image}
            />
          ))}
        </div>
      </section>

      <section className={styles.workflow}>
        <h2>Як ми працюємо</h2>
        <div className={styles.workflowGrid}>
          {workflow.map((item, index) => (
            <div key={item.step} className={styles.workflowStep}>
              <span className={styles.workflowNumber}>{index + 1}</span>
              <h3>{item.step}</h3>
              <p>{item.details}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials}>
        <h2>Відгуки наших партнерів</h2>
        <div className={styles.testimonialsGrid}>
          {testimonials.map((testimonial) => (
            <figure key={testimonial.name} className={styles.testimonialCard}>
              <img src={testimonial.avatar} alt={"Портрет ${testimonial.name}"} className={styles.avatar} />
              <blockquote>{testimonial.quote}</blockquote>
              <figcaption>
                <strong>{testimonial.name}</strong>
                <span>{testimonial.company}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Готові до нових квіткових сезонів?</h2>
          <p>
            Залиште запит — і ми підготуємо індивідуальну пропозицію з урахуванням ваших обсягів, графіку та стилістики.
            Разом розквітнемо новий розділ вашого бізнесу.
          </p>
        </div>
        <div className={styles.ctaDetails}>
          <span>м. Київ, вул. Садова, 10</span>
          <a href="tel:+380441234567">+380 (44) 123-45-67</a>
          <a href="mailto:info@kvitkova-optom.ua">info@kvitkova-optom.ua</a>
          <Link to="/contacts" className={styles.primaryButton}>
            Запланувати дзвінок
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;