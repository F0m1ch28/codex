import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  message: '',
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Будь ласка, вкажіть ваше ім’я.';
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = 'Вкажіть, будь ласка, email.';
    } else if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Переконайтесь, що email введено коректно.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Опишіть ваш запит, щоб ми могли підготувати пропозицію.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    navigate('/thank-you');
  };

  return (
    <>
      <Helmet>
        <title>Контакти Квіткової Оптом — запит на співпрацю</title>
        <meta
          name="description"
          content="Зв’яжіться з командою Квіткової Оптом для організації оптових поставок квітів. Ми відповімо у зручний для вас час."
        />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <h1>Зв’яжіться з нами</h1>
          <p>
            Розкажіть про ваш проєкт або регулярні потреби в квітах — ми підготуємо пропозицію, що точно відповідає цілям вашого
            бізнесу.
          </p>
          <div className={styles.contactInfo}>
            <span><strong>Адреса:</strong> м. Київ, вул. Садова, 10</span>
            <span><strong>Телефон:</strong> +380 (44) 123-45-67</span>
            <span><strong>Email:</strong> info@kvitkova-optom.ua</span>
          </div>
        </div>
        <div className={styles.contactCard}>
          <h2>Форма для запиту</h2>
          <form onSubmit={handleSubmit} className={styles.form} noValidate>
            <label htmlFor="name">
              Ім’я та компанія
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.name ? 'true' : 'false'}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}
            </label>

            <label htmlFor="email">
              Бізнес email
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.email ? 'true' : 'false'}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}
            </label>

            <label htmlFor="message">
              Опишіть ваш запит
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-required="true"
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}
            </label>

            <button type="submit" className={styles.submitButton}>
              Надіслати запит
            </button>
          </form>
        </div>
      </section>

      <section className={styles.details}>
        <div>
          <h2>Що варто зазначити у запиті</h2>
          <ul>
            <li>Сфери, де будуть використовуватись квіти (івенти, мережа, офіс тощо).</li>
            <li>Бажані обсяги та частота поставок.</li>
            <li>Сезони або конкретні дати, що потребують особливої уваги.</li>
          </ul>
        </div>
        <div>
          <h2>Коли ми відповімо</h2>
          <p>
            Менеджер зв’яжеться з вами протягом робочого дня, щоб уточнити деталі та узгодити наступні кроки. Працюємо по всій Україні
            та охоче організовуємо персональні зустрічі у нашому шоурумі.
          </p>
        </div>
      </section>
    </>
  );
};

export default ContactPage;