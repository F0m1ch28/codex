import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const AboutPage = () => {
  const milestones = [
    {
      year: '2014',
      text: 'Створення Квіткової Оптом та перші поставки імпортних квітів для флористів Києва.',
    },
    {
      year: '2016',
      text: 'Відкриття власного холодильного складу та розширення географії поставок по Україні.',
    },
    {
      year: '2019',
      text: 'Запуск освітніх програм і воркшопів для партнерів з догляду та зберігання квітів.',
    },
    {
      year: '2022',
      text: 'Створення команди експертів з аналітики продажів і впровадження цифрового моніторингу поставок.',
    },
  ];

  const team = [
    {
      name: 'Юлія Сафонова',
      role: 'Засновниця та директорка',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=500&q=80',
    },
    {
      name: 'Іван Черненко',
      role: 'Керівник логістики',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=500&q=80&sat=-100',
    },
    {
      name: 'Марина Левченко',
      role: 'Керівниця роботи з партнерами',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=500&q=80',
    },
    {
      name: 'Олексій Гринь',
      role: 'Експерт із селекції та закупівель',
      image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=500&q=80&sat=-50',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Про компанію Квіткова Оптом — наша історія та команда</title>
        <meta
          name="description"
          content="Дізнайтеся історію Квіткової Оптом, познайомтеся з командою та принципами роботи, які забезпечують преміальні поставки квітів."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroText}>
          <h1>Про Квіткову Оптом</h1>
          <p>
            Ми допомагаємо підприємствам реалізувати найсміливіші квіткові концепції, забезпечуючи стабільний доступ до унікальних
            сортів і досконалий сервіс. Наші партнери — це флористичні студії, івент-агенції, готелі та мережеві компанії, які цінують
            точність та красу.
          </p>
        </div>
        <img
          src="https://images.unsplash.com/photo-1526379879527-8559ecfcaec0?auto=format&fit=crop&w=1000&q=80"
          alt="Команда флористів працює над створенням композицій з квітів"
          className={styles.heroImage}
        />
      </section>

      <section className={styles.mission}>
        <div>
          <h2>Місія та цінності</h2>
          <p>
            Наша місія — забезпечити клієнтів квітами, які зберігають емоцію першого погляду. Ми віримо у відповідальне виробництво,
            довірчі партнерські стосунки та силу деталей. Тому ретельно відбираємо партнерів-постачальників та інвестуємо у власні
            стандарти якості.
          </p>
        </div>
        <div className={styles.valuesCard}>
          <h3>Наші принципи</h3>
          <ul>
            <li><strong>Прозорість</strong> — відкриті умови співпраці та чесні комунікації.</li>
            <li><strong>Повага</strong> — турбота про кожного клієнта, рослину та співробітника.</li>
            <li><strong>Інноваційність</strong> — моніторимо тенденції та впроваджуємо сучасні рішення.</li>
          </ul>
        </div>
      </section>

      <section className={styles.milestones}>
        <h2>Ключові етапи розвитку</h2>
        <div className={styles.milestoneGrid}>
          {milestones.map((item) => (
            <div key={item.year} className={styles.milestoneCard}>
              <span>{item.year}</span>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <h2>Команда експертів</h2>
        <p className={styles.teamIntro}>
          Кожен з нас закоханий у світ флористики та має профільну освіту або багаторічний досвід в галузі. Ми говоримо мовою
          бізнесу, але мислимо як митці, щоб ваші проєкти виглядали неповторно.
        </p>
        <div className={styles.teamGrid}>
          {team.map((member) => (
            <figure key={member.name} className={styles.teamCard}>
              <img src={member.image} alt={"${member.name} — ${member.role}"} />
              <figcaption>
                <strong>{member.name}</strong>
                <span>{member.role}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.sustainability}>
        <h2>Відповідальний підхід</h2>
        <div className={styles.sustainabilityContent}>
          <p>
            Ми підтримуємо локальних фермерів, використовуємо повторно упаковку та обираємо логістичні рішення з меншим вуглецевим
            слідом. Постійно інвестуємо у навчання команди щодо дбайливого ставлення до рослин та довкілля.
          </p>
          <p>
            Співпрацюючи з нами, ви долучаєтесь до екосистеми, де краса поєднується з відповідальністю та турботою про майбутні
            квіткові сезони України.
          </p>
        </div>
      </section>
    </>
  );
};

export default AboutPage;