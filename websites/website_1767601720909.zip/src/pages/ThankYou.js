import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const ThankYouPage = () => (
  <>
    <Helmet>
      <title>Дякуємо за звернення — Квіткова Оптом</title>
      <meta
        name="description"
        content="Дякуємо за ваш запит. Команда Квіткової Оптом зв’яжеться з вами найближчим часом для обговорення деталей."
      />
    </Helmet>

    <section className={styles.wrapper}>
      <div className={styles.card}>
        <h1>Дякуємо за звернення!</h1>
        <p>
          Ваш запит прийнято. Ми вже аналізуємо інформацію та підготуємо персональну пропозицію. Менеджер зв’яжеться з вами дуже
          скоро.
        </p>
        <Link to="/" className={styles.button}>
          Повернутися на головну
        </Link>
      </div>
    </section>
  </>
);

export default ThankYouPage;