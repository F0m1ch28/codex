import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/Home';
import AboutPage from './pages/About';
import AssortmentPage, { CooperationPage } from './pages/Services';
import ContactPage from './pages/Contact';
import ThankYouPage from './pages/ThankYou';
import TermsOfService, { CookiePolicyPage } from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import styles from './App.module.css';

function App() {
  return (
    <Router>
      <div className={styles.appWrapper}>
        <ScrollToTop />
        <Header />
        <main className={styles.mainContent}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/assortment" element={<AssortmentPage />} />
            <Route path="/cooperation" element={<CooperationPage />} />
            <Route path="/contacts" element={<ContactPage />} />
            <Route path="/terms" element={<TermsOfService />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
            <Route path="/thank-you" element={<ThankYouPage />} />
            <Route path="*" element={<HomePage />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </Router>
  );
}

export default App;