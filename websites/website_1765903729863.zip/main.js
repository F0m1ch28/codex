(function () {
  function initCookieBanner() {
    const banner = document.querySelector('.cookie-banner');
    if (!banner) return;
    const acceptBtn = banner.querySelector('#cookieAccept');
    const declineBtn = banner.querySelector('#cookieDecline');
    const consent = localStorage.getItem('gft_cookie_consent');
    if (!consent) {
      banner.classList.remove('is-hidden');
    }
    if (consent === 'accepted' || consent === 'declined') {
      banner.classList.add('is-hidden');
    }
    function setConsent(value) {
      localStorage.setItem('gft_cookie_consent', value);
      banner.classList.add('is-hidden');
    }
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        setConsent('accepted');
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        setConsent('declined');
      });
    }
  }

  function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;
    const statusEl = document.getElementById('formStatus');
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const name = form.elements['name'];
      const email = form.elements['email'];
      const organization = form.elements['organization'];
      const topic = form.elements['topic'];
      const message = form.elements['message'];

      let valid = true;
      [name, email, topic, message].forEach(function (field) {
        field.classList.remove('input-error');
      });
      statusEl.textContent = '';

      if (!name.value.trim()) {
        name.classList.add('input-error');
        valid = false;
      }
      if (!email.value.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        email.classList.add('input-error');
        valid = false;
      }
      if (!topic.value.trim()) {
        topic.classList.add('input-error');
        valid = false;
      }
      if (!message.value.trim()) {
        message.classList.add('input-error');
        valid = false;
      }

      if (!valid) {
        statusEl.textContent = 'Please complete the required fields highlighted above.';
        statusEl.focus();
        return;
      }

      const payload = {
        name: name.value.trim(),
        email: email.value.trim(),
        organization: organization.value.trim(),
        topic: topic.value.trim(),
        message: message.value.trim()
      };
      console.log('Contact submission payload:', payload);
      window.location.href = 'thanks.html';
    });

    form.addEventListener('input', function (event) {
      if (event.target.classList.contains('input-error') && event.target.value.trim()) {
        event.target.classList.remove('input-error');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initCookieBanner();
    initContactForm();
  });
})();