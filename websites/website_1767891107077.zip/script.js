document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const mainNav = document.querySelector('.main-nav');

    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', () => {
            mainNav.classList.toggle('open');
        });

        mainNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mainNav.classList.remove('open');
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                mainNav.classList.remove('open');
            }
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storageKey = 'rivetevpcj_cookie_pref';
        let storageAvailable = true;

        try {
            const testKey = '__test';
            localStorage.setItem(testKey, testKey);
            localStorage.removeItem(testKey);
        } catch (err) {
            storageAvailable = false;
        }

        const preference = storageAvailable ? localStorage.getItem(storageKey) : null;
        if (!preference) {
            cookieBanner.classList.add('visible');
        }

        const cookieButtons = cookieBanner.querySelectorAll('[data-cookie-action]');
        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                if (storageAvailable) {
                    localStorage.setItem(storageKey, button.dataset.cookieAction);
                }
                cookieBanner.classList.remove('visible');
            });
        });
    }
});