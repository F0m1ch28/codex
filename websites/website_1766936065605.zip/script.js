document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.getElementById('navToggle');
  const primaryNav = document.getElementById('primaryNav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('is-open');
    });

    primaryNav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        primaryNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const storedPreference = localStorage.getItem('luminaCookieChoice');
    if (!storedPreference) {
      cookieBanner.classList.remove('hidden');
    }

    cookieBanner.addEventListener('click', function (event) {
      const target = event.target;
      if (!(target instanceof HTMLElement)) {
        return;
      }
      const action = target.dataset.action;
      if (action === 'accept-cookies') {
        localStorage.setItem('luminaCookieChoice', 'accepted');
        cookieBanner.classList.add('hidden');
      } else if (action === 'decline-cookies') {
        localStorage.setItem('luminaCookieChoice', 'declined');
        cookieBanner.classList.add('hidden');
      }
    });
  }

  const contactForm = document.getElementById('contactForm');
  const contactMessage = document.getElementById('contactFormMessage');

  if (contactForm && contactMessage) {
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
      contactMessage.textContent = '';
      contactMessage.classList.remove('error-message', 'success-message');

      const fullName = contactForm.fullName.value.trim();
      const email = contactForm.email.value.trim();
      const subject = contactForm.subject.value.trim();
      const message = contactForm.message.value.trim();

      const errors = [];

      if (!fullName || fullName.length < 2) {
        errors.push('Please provide your full name.');
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        errors.push('Please enter a valid email address.');
      }

      if (!subject) {
        errors.push('Please select how we can assist.');
      }

      if (!message || message.length < 10) {
        errors.push('Please share a bit more detail in your message.');
      }

      if (errors.length) {
        contactMessage.textContent = errors.join(' ');
        contactMessage.classList.add('error-message');
        return;
      }

      contactMessage.textContent = 'Thank you! Our concierge team will respond within four business hours.';
      contactMessage.classList.add('success-message');
      contactForm.reset();
    });
  }

  const customForm = document.getElementById('customForm');
  if (customForm) {
    const totalPriceEl = document.getElementById('totalPrice');
    const summaryOccasion = document.getElementById('summaryOccasion');
    const summaryPalette = document.getElementById('summaryPalette');
    const summaryAddons = document.getElementById('summaryAddons');
    const feedback = document.getElementById('customizationFeedback');

    const basePrices = {
      petite: 75,
      classic: 115,
      grand: 165
    };

    function formatCurrency(value) {
      return `$${value.toFixed(2)}`;
    }

    function updateSummary() {
      const selectedSize = customForm.elements['boxSize'].value || 'classic';
      let total = basePrices[selectedSize] || 115;

      const occasionValue = customForm.elements['occasion'].value;
      const paletteValue = customForm.elements['palette'].value;

      summaryOccasion.textContent = occasionValue;
      summaryPalette.textContent = paletteValue;

      const addons = Array.from(customForm.querySelectorAll('input[name="addons"]:checked'));
      if (addons.length) {
        const addonNames = addons.map(function (addon) {
          const addonPrice = Number(addon.dataset.price) || 0;
          total += addonPrice;
          return `${addon.value} (+$${addonPrice})`;
        });
        summaryAddons.textContent = addonNames.join(', ');
      } else {
        summaryAddons.textContent = 'None selected yet';
      }

      const expedite = customForm.querySelector('input[name="expedite"]');
      if (expedite && expedite.checked) {
        total += Number(expedite.dataset.price) || 0;
      }

      totalPriceEl.textContent = formatCurrency(total);
    }

    updateSummary();

    customForm.addEventListener('input', function () {
      updateSummary();
      if (feedback) {
        feedback.textContent = '';
        feedback.classList.remove('success-message', 'error-message');
      }
    });

    customForm.addEventListener('submit', function (event) {
      event.preventDefault();
      updateSummary();
      if (feedback) {
        feedback.textContent = 'Your festive blueprint is reserved! Our concierge will reach out shortly with a moodboard confirmation.';
        feedback.classList.remove('error-message');
        feedback.classList.add('success-message');
      }
    });
  }
});