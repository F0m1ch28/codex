document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".primary-nav");
    const scrollBtn = document.getElementById("scrollTopBtn");
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");
    const yearSpan = document.getElementById("currentYear");
    const forms = document.querySelectorAll(".contact-form");
    const navLinks = document.querySelectorAll('a[data-scroll-top="true"]');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const isOpen = nav.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", isOpen);
        });
    }

    if (navLinks) {
        navLinks.forEach(link => {
            link.addEventListener("click", () => {
                window.scrollTo({ top: 0, behavior: "instant" });
            });
        });
    }

    window.addEventListener("scroll", () => {
        if (window.scrollY > 300) {
            scrollBtn.classList.add("show");
        } else {
            scrollBtn.classList.remove("show");
        }
    });

    if (scrollBtn) {
        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    const cookiesAccepted = localStorage.getItem("almaCookiesAccepted");
    if (!cookiesAccepted && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener("click", () => {
            localStorage.setItem("almaCookiesAccepted", "true");
            cookieBanner.classList.remove("active");
        });
    }

    forms.forEach(form => {
        const feedback = form.querySelector(".form-feedback");
        form.addEventListener("submit", event => {
            event.preventDefault();
            const inputs = form.querySelectorAll("input[required], textarea[required]");
            let isValid = true;

            inputs.forEach(input => {
                if (!input.value.trim() || (input.type === "email" && !/^\S+@\S+\.\S+$/.test(input.value))) {
                    isValid = false;
                    input.setAttribute("aria-invalid", "true");
                    input.classList.add("input-error");
                } else {
                    input.setAttribute("aria-invalid", "false");
                    input.classList.remove("input-error");
                }
            });

            if (isValid) {
                if (feedback) {
                    feedback.textContent = "Хабарламаңыз қабылданды. Біз жақын арада хабарласамыз!";
                    feedback.style.color = "var(--primary)";
                }
                form.reset();
            } else {
                if (feedback) {
                    feedback.textContent = "Барлық міндетті жолдарды тексеріңіз.";
                    feedback.style.color = "crimson";
                }
            }
        });
    });
});