document.addEventListener('DOMContentLoaded', () => {
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navList = document.querySelector('.nav-list');
  if (mobileToggle && navList) {
    mobileToggle.addEventListener('click', () => {
      const isOpen = navList.classList.toggle('is-open');
      mobileToggle.classList.toggle('is-active', isOpen);
      mobileToggle.setAttribute('aria-expanded', String(isOpen));
    });
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.18 });

  document.querySelectorAll('[data-animate]').forEach((el) => observer.observe(el));

  const toastRegion = document.querySelector('.toast-region');
  function showToast(message, warning = false) {
    if (!toastRegion) return;
    const toast = document.createElement('div');
    toast.className = warning ? 'toast toast-warning' : 'toast';
    toast.textContent = message;
    toastRegion.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(30px)';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  document.querySelectorAll('form[data-redirect]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Mulțumim pentru mesaj. Redirecționăm acum.');
      const target = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = target;
      }, 1400);
    });
  });

  const banner = document.querySelector('.cookie-banner');
  const cookieKey = 'voltaCookieChoice';
  if (banner) {
    const savedChoice = localStorage.getItem(cookieKey);
    if (!savedChoice) {
      banner.classList.remove('hidden');
    }
    banner.querySelectorAll('[data-cookie-action]').forEach((button) => {
      button.addEventListener('click', () => {
        const action = button.getAttribute('data-cookie-action');
        localStorage.setItem(cookieKey, action);
        banner.classList.add('hidden');
        showToast(action === 'accept' ? 'Preferințele privind cookie-urile au fost salvate.' : 'Ați refuzat cookie-urile opționale.', action !== 'accept');
      });
    });
  }
});