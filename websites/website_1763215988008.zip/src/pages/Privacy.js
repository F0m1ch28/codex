```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './PolicyPage.module.css';

const Privacy = () => {
  return (
    <div className={styles.policy}>
      <Helmet>
        <title>Privacy Policy | TechSolutions</title>
        <meta
          name="description"
          content="Read the TechSolutions Privacy Policy to understand how we collect, use, and protect your personal information."
        />
      </Helmet>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p className={styles.lastUpdated}>Last updated: January 3, 2024</p>

        <section>
          <h2>1. Overview</h2>
          <p>
            TechSolutions (“we”, “us”, or “our”) respects your privacy and is
            committed to protecting the personal information that you share with
            us. This Privacy Policy explains how we collect, use, disclose, and
            safeguard your information when you visit our website or interact
            with our services.
          </p>
        </section>

        <section>
          <h2>2. Information we collect</h2>
          <p>
            We collect information that helps us understand your needs and offer
            tailored services. This includes:
          </p>
          <ul>
            <li>
              <strong>Information you provide.</strong> When you complete forms
              on our site, subscribe to updates, or contact us directly, we may
              collect your name, email address, company details, and any
              information you choose to share.
            </li>
            <li>
              <strong>Usage data.</strong> We automatically collect certain
              information about your device and usage patterns, such as IP
              address, browser type, pages viewed, and time spent on the site.
            </li>
            <li>
              <strong>Cookies and similar technologies.</strong> We use cookies
              to enhance your experience, remember preferences, and understand
              how visitors use our site.
            </li>
          </ul>
        </section>

        <section>
          <h2>3. How we use your information</h2>
          <p>We may use the information we collect for purposes including:</p>
          <ul>
            <li>Responding to inquiries and providing requested services.</li>
            <li>
              Improving website functionality, content, and user experience.
            </li>
            <li>
              Sending updates, insights, or invitations that may interest you,
              when permitted by law.
            </li>
            <li>
              Maintaining the security, integrity, and performance of our
              systems.
            </li>
            <li>
              Complying with legal obligations and enforcing our agreements.
            </li>
          </ul>
        </section>

        <section>
          <h2>4. Sharing of information</h2>
          <p>
            We do not sell your personal information. We may share information
            with trusted parties who help us deliver our services, such as
            technology vendors or professional advisors. These parties are
            required to respect your privacy and protect your information. We
            may also share information to comply with legal requirements or to
            protect our rights.
          </p>
        </section>

        <section>
          <h2>5. Data retention</h2>
          <p>
            We retain personal information only as long as necessary to fulfill
            the purposes described in this policy unless a longer retention
            period is required by law. When information is no longer needed, we
            take reasonable steps to securely delete or anonymize it.
          </p>
        </section>

        <section>
          <h2>6. Your choices</h2>
          <p>
            You may request access to your personal information, ask for
            corrections, or request deletion where applicable. You may also opt
            out of marketing communications by using the unsubscribe link in our
            emails or contacting us directly.
          </p>
        </section>

        <section>
          <h2>7. Security</h2>
          <p>
            We implement appropriate technical and organizational safeguards to
            protect your personal information. While no method of transmission
            or storage is completely secure, we strive to protect your data with
            reasonable measures.
          </p>
        </section>

        <section>
          <h2>8. International transfers</h2>
          <p>
            If you access our site from outside the United States, please note
            that your information may be processed in countries where data
            protection laws differ from your jurisdiction. We handle all
            information in accordance with this policy.
          </p>
        </section>

        <section>
          <h2>9. Children’s privacy</h2>
          <p>
            Our website and services are not directed to children under the age
            of 16, and we do not knowingly collect personal information from
            children. If you believe a child has provided us with information,
            please contact us so we can take appropriate action.
          </p>
        </section>

        <section>
          <h2>10. Changes to this policy</h2>
          <p>
            We may update this Privacy Policy from time to time to reflect
            changes in our practices or legal requirements. We encourage you to
            review this page periodically for the latest information.
          </p>
        </section>

        <section>
          <h2>11. Contact us</h2>
          <p>
            If you have questions about this Privacy Policy or our privacy
            practices, please contact us at:
          </p>
          <address>
            TechSolutions
            <br />
            123 Tech Avenue, Innovation District
            <br />
            San Francisco, CA 94105
            <br />
            Phone: +1 (555) 123-4567
            <br />
            Email: <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
          </address>
        </section>
      </div>
    </div>
  );
};

export default Privacy;
```