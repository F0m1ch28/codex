```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={`${styles.inner} container`}>
        <div className={styles.brand}>
          <h3>TechSolutions</h3>
          <p>
            A trusted partner for cloud-first strategies and thoughtful digital
            transformation journeys.
          </p>
        </div>
        <div className={styles.links}>
          <h4>Explore</h4>
          <ul>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Use</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Cookie Policy</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div className={styles.contact}>
          <h4>Contact</h4>
          <address>
            123 Tech Avenue, Innovation District,
            <br />
            San Francisco, CA 94105
          </address>
          <a href="tel:+15551234567">+1 (555) 123-4567</a>
          <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {currentYear} TechSolutions. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
```