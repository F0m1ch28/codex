document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.querySelector(".nav-menu");

  if (navToggle && navMenu) {
    const toggleMenu = () => {
      const isVisible = navMenu.getAttribute("data-visible") === "true";
      navMenu.setAttribute("data-visible", String(!isVisible));
      navToggle.setAttribute("aria-expanded", String(!isVisible));
    };

    navToggle.addEventListener("click", toggleMenu);
    navToggle.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        toggleMenu();
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptButton = document.getElementById("cookie-accept");
  const declineButton = document.getElementById("cookie-decline");

  const setCookie = (name, value, days) => {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    document.cookie = `${name}=${value};expires=${date.toUTCString()};path=/;SameSite=Lax`;
  };

  const getCookie = (name) => {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) {
      return parts.pop().split(";").shift();
    }
    return null;
  };

  if (cookieBanner && !getCookie("gtc_cookie_consent")) {
    cookieBanner.classList.add("is-visible");
  }

  if (acceptButton) {
    acceptButton.addEventListener("click", () => {
      setCookie("gtc_cookie_consent", "accepted", 180);
      cookieBanner.classList.remove("is-visible");
      acceptButton.blur();
    });
  }

  if (declineButton) {
    declineButton.addEventListener("click", () => {
      setCookie("gtc_cookie_consent", "declined", 30);
      cookieBanner.classList.remove("is-visible");
      declineButton.blur();
    });
  }
});