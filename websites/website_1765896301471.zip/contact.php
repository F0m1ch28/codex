<?php
$prefillNombre = "";
$prefillCorreo = "";
$prefillTipo = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["nombre"])) {
        $prefillNombre = htmlspecialchars(trim($_POST["nombre"]), ENT_QUOTES, "UTF-8");
    }
    if (isset($_POST["correo"])) {
        $prefillCorreo = htmlspecialchars(trim($_POST["correo"]), ENT_QUOTES, "UTF-8");
    }
    if (isset($_POST["tipo_proyecto"])) {
        $prefillTipo = htmlspecialchars(trim($_POST["tipo_proyecto"]), ENT_QUOTES, "UTF-8");
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contacto | Geo Thermal Control España</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Formulario de contacto de Geo Thermal Control España. Solicita una evaluación geotérmica o agenda una demostración.">
    <meta name="keywords" content="contacto geotermia, evaluación geotérmica, torre picasso, monitorización geotérmica">
    <meta property="og:title" content="Contacto | Geo Thermal Control España">
    <meta property="og:description" content="Comunícate con Geo Thermal Control España para coordinar una evaluación geotérmica especializada.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.geothermalcontrol.es/contact.php">
    <meta property="og:image" content="https://picsum.photos/1200/630?random=31">
    <meta property="og:locale" content="es_ES">
    <meta property="og:site_name" content="Geo Thermal Control España">
    <link rel="canonical" href="https://www.geothermalcontrol.es/contact.php">
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>
<body>
    <a class="skip-link" href="#contenido-principal">Saltar al contenido principal</a>
    <header class="site-header" role="banner">
        <div class="container">
            <div class="branding">
                <div class="logo-mark" aria-hidden="true">GT</div>
                <div class="site-title">
                    Geo Thermal Control España
                    <span>Sistemas de monitorización geotérmica</span>
                </div>
            </div>
            <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="principal-menu">
                <span>Menú</span>
            </button>
            <nav aria-label="Menú principal">
                <ul class="nav-menu" id="principal-menu" data-visible="false">
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="about.html">Nosotros</a></li>
                    <li><a href="solutions.html">Soluciones</a></li>
                    <li><a href="technology.html">Tecnología</a></li>
                    <li><a href="performance.html">Rendimiento</a></li>
                    <li><a href="projects.html">Proyectos</a></li>
                    <li><a href="contact.php" aria-current="page">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main id="contenido-principal">
        <section class="page-hero" role="region" aria-label="Formulario de contacto">
            <div class="container hero-container">
                <div class="hero-content">
                    <span class="badge">Contáctanos</span>
                    <h1>Solicitar evaluación geotérmica</h1>
                    <p>
                        Cuéntanos las características de tu planta geotérmica o proyecto y nuestro equipo preparará una propuesta de monitorización y control acorde a tus objetivos operativos.
                    </p>
                    <div class="hero-cta">
                        <a class="button secondary" href="tel:+34915678432">Llamar al +34 915 678 432</a>
                        <a class="button tertiary" href="mailto:contacto@geothermalcontrol.es">Escribir correo</a>
                    </div>
                </div>
            </div>
        </section>

        <section class="section" aria-labelledby="titulo-formulario">
            <div class="container">
                <div class="contact-grid">
                    <form class="hero-form" id="form-contacto" action="thanks.php" method="post" novalidate>
                        <h2 id="titulo-formulario">Datos de contacto</h2>
                        <p>Los campos marcados con * son obligatorios.</p>
                        <div class="form-group">
                            <label for="form-nombre">Nombre completo *</label>
                            <input class="input-control" type="text" id="form-nombre" name="nombre" value="<?php echo $prefillNombre; ?>" required aria-required="true">
                        </div>
                        <div class="form-group">
                            <label for="form-correo">Correo profesional *</label>
                            <input class="input-control" type="email" id="form-correo" name="correo" value="<?php echo $prefillCorreo; ?>" required aria-required="true">
                        </div>
                        <div class="form-group">
                            <label for="form-telefono">Teléfono</label>
                            <input class="input-control" type="tel" id="form-telefono" name="telefono" placeholder="+34 600 000 000" autocomplete="tel">
                        </div>
                        <div class="form-group">
                            <label for="form-empresa">Empresa u organización</label>
                            <input class="input-control" type="text" id="form-empresa" name="empresa" placeholder="Nombre de la entidad">
                        </div>
                        <div class="form-group">
                            <label for="form-tipo">Tipo de proyecto *</label>
                            <select id="form-tipo" name="tipo_proyecto" required aria-required="true">
                                <option value="">Selecciona una opción</option>
                                <option value="district_heating" <?php echo $prefillTipo === "district_heating" ? "selected" : ""; ?>>Red de calor geotérmica</option>
                                <option value="generacion_electrica" <?php echo $prefillTipo === "generacion_electrica" ? "selected" : ""; ?>>Generación eléctrica geotérmica</option>
                                <option value="industrial" <?php echo $prefillTipo === "industrial" ? "selected" : ""; ?>>Proceso industrial geotérmico</option>
                                <option value="hibrida" <?php echo $prefillTipo === "hibrida" ? "selected" : ""; ?>>Planta híbrida geotérmica</option>
                                <option value="otro">Otro proyecto geotérmico</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="form-mensaje">Describe tus necesidades *</label>
                            <textarea id="form-mensaje" name="mensaje" placeholder="Cuéntanos sobre tu planta, objetivos y retos actuales." required aria-required="true"></textarea>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="acepta_privacidad" value="1" required aria-required="true">
                                He leído y acepto la <a href="privacy.html">política de privacidad</a>.
                            </label>
                        </div>
                        <div class="form-group">
                            <button class="button" type="submit">Enviar solicitud</button>
                        </div>
                    </form>
                    <aside class="contact-card" aria-label="Información de contacto">
                        <h2>Geo Thermal Control España</h2>
                        <address>
                            Torre Picasso<br>
                            Plaza Pablo Ruiz Picasso 1<br>
                            28020 Madrid, España
                        </address>
                        <p>Teléfono: <a href="tel:+34915678432">+34 915 678 432</a></p>
                        <p>Correo: <a href="mailto:contacto@geothermalcontrol.es">contacto@geothermalcontrol.es</a></p>
                        <div class="alert-info">
                            Respondemos en menos de 24 horas laborales con un plan de acción adaptado.
                        </div>
                        <iframe class="map-embed" title="Mapa de la sede de Geo Thermal Control España" src="https://www.google.com/maps?q=Torre+Picasso,+Madrid&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        <div class="hero-cta">
                            <a class="button secondary" href="solutions.html">Ver soluciones digitales</a>
                        </div>
                    </aside>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer" role="contentinfo">
        <div class="container footer-grid">
            <div>
                <div class="logo-mark" aria-hidden="true">GT</div>
                <p>
                    Geo Thermal Control España desarrolla plataformas de control inteligente para maximizar el rendimiento de plantas geotérmicas en todo el territorio nacional.
                </p>
                <address>
                    Torre Picasso<br>
                    Plaza Pablo Ruiz Picasso 1<br>
                    28020 Madrid, España<br>
                    Tel: <a href="tel:+34915678432">+34 915 678 432</a><br>
                    Email: <a href="mailto:contacto@geothermalcontrol.es">contacto@geothermalcontrol.es</a>
                </address>
            </div>
            <nav aria-label="Enlaces principales">
                <h3>Explorar</h3>
                <ul>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="about.html">Nosotros</a></li>
                    <li><a href="solutions.html">Soluciones</a></li>
                    <li><a href="technology.html">Tecnología</a></li>
                    <li><a href="performance.html">Rendimiento</a></li>
                    <li><a href="projects.html">Proyectos</a></li>
                </ul>
            </nav>
            <nav aria-label="Documentos legales">
                <h3>Documentación</h3>
                <ul>
                    <li><a href="contact.php">Contacto</a></li>
                    <li><a href="privacy.html">Política de privacidad</a></li>
                    <li><a href="cookies.html">Política de cookies</a></li>
                    <li><a href="terms.html">Términos legales</a></li>
                    <li><a href="sitemap.xml">Mapa del sitio</a></li>
                </ul>
            </nav>
        </div>
        <div class="container footer-bottom">
            <span>© 2024 Geo Thermal Control España. Todos los derechos reservados.</span>
            <span>Operamos en toda España con sede en Madrid.</span>
        </div>
    </footer>

    <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
        <p>
            Utilizamos cookies técnicas para garantizar el funcionamiento seguro del sitio y analíticas anónimas para mejorar la experiencia. Puedes gestionar tu preferencia en nuestra <a href="cookies.html">política de cookies</a>.
        </p>
        <div class="cookie-actions">
            <button class="button ghost" id="cookie-decline" type="button">Rechazar</button>
            <button class="button" id="cookie-accept" type="button">Aceptar</button>
        </div>
    </div>
</body>
</html>