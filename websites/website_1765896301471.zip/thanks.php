<?php
$nombre = isset($_POST["nombre"]) && trim($_POST["nombre"]) !== "" ? htmlspecialchars(trim($_POST["nombre"]), ENT_QUOTES, "UTF-8") : "equipo técnico";
$correo = isset($_POST["correo"]) ? htmlspecialchars(trim($_POST["correo"]), ENT_QUOTES, "UTF-8") : "";
$telefono = isset($_POST["telefono"]) ? htmlspecialchars(trim($_POST["telefono"]), ENT_QUOTES, "UTF-8") : "";
$tipo = isset($_POST["tipo_proyecto"]) ? htmlspecialchars(trim($_POST["tipo_proyecto"]), ENT_QUOTES, "UTF-8") : "";
$mensaje = isset($_POST["mensaje"]) ? htmlspecialchars(trim($_POST["mensaje"]), ENT_QUOTES, "UTF-8") : "";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gracias por contactar | Geo Thermal Control España</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="description" content="Confirmación de solicitud a Geo Thermal Control España.">
    <meta property="og:title" content="Gracias por contactar | Geo Thermal Control España">
    <meta property="og:description" content="Hemos recibido tu solicitud y te contactaremos en breve.">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://picsum.photos/1200/630?random=37">
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>
<body>
    <a class="skip-link" href="#contenido-principal">Saltar al contenido principal</a>
    <header class="site-header" role="banner">
        <div class="container">
            <div class="branding">
                <div class="logo-mark" aria-hidden="true">GT</div>
                <div class="site-title">
                    Geo Thermal Control España
                    <span>Sistemas de monitorización geotérmica</span>
                </div>
            </div>
            <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="principal-menu">
                <span>Menú</span>
            </button>
            <nav aria-label="Menú principal">
                <ul class="nav-menu" id="principal-menu" data-visible="false">
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="about.html">Nosotros</a></li>
                    <li><a href="solutions.html">Soluciones</a></li>
                    <li><a href="technology.html">Tecnología</a></li>
                    <li><a href="performance.html">Rendimiento</a></li>
                    <li><a href="projects.html">Proyectos</a></li>
                    <li><a href="contact.php">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main id="contenido-principal">
        <section class="page-hero" role="region" aria-label="Confirmación de envío">
            <div class="container hero-container">
                <div class="hero-content">
                    <span class="badge">Solicitud recibida</span>
                    <h1>Gracias, <?php echo $nombre; ?>.</h1>
                    <p>
                        Hemos recibido tu mensaje y nos pondremos en contacto a la mayor brevedad para coordinar los siguientes pasos.
                    </p>
                    <div class="hero-cta">
                        <a class="button" href="index.html">Volver al inicio</a>
                        <a class="button secondary" href="solutions.html">Explorar soluciones</a>
                    </div>
                </div>
            </div>
        </section>

        <section class="section" aria-labelledby="titulo-resumen">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title" id="titulo-resumen">Resumen de tu solicitud</h2>
                    <p class="section-subtitle">Esta información nos ayuda a preparar la respuesta más adecuada.</p>
                </div>
                <div class="contact-card">
                    <p><strong>Correo facilitado:</strong> <?php echo $correo !== "" ? $correo : "No indicado"; ?></p>
                    <p><strong>Teléfono:</strong> <?php echo $telefono !== "" ? $telefono : "No indicado"; ?></p>
                    <p><strong>Tipo de proyecto:</strong> <?php echo $tipo !== "" ? $tipo : "No indicado"; ?></p>
                    <p><strong>Descripción recibida:</strong> <?php echo $mensaje !== "" ? $mensaje : "Sin detalles adicionales"; ?></p>
                </div>
                <div class="alert-info">
                    Si deseas añadir información complementaria o adjuntar documentación técnica, escríbenos a <a href="mailto:contacto@geothermalcontrol.es">contacto@geothermalcontrol.es</a>.
                </div>
            </div>
        </section>
    </main>

    <footer class="footer" role="contentinfo">
        <div class="container footer-grid">
            <div>
                <div class="logo-mark" aria-hidden="true">GT</div>
                <p>
                    Geo Thermal Control España desarrolla plataformas de control inteligente para maximizar el rendimiento de plantas geotérmicas en todo el territorio nacional.
                </p>
                <address>
                    Torre Picasso<br>
                    Plaza Pablo Ruiz Picasso 1<br>
                    28020 Madrid, España<br>
                    Tel: <a href="tel:+34915678432">+34 915 678 432</a><br>
                    Email: <a href="mailto:contacto@geothermalcontrol.es">contacto@geothermalcontrol.es</a>
                </address>
            </div>
            <nav aria-label="Enlaces principales">
                <h3>Explorar</h3>
                <ul>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="about.html">Nosotros</a></li>
                    <li><a href="solutions.html">Soluciones</a></li>
                    <li><a href="technology.html">Tecnología</a></li>
                    <li><a href="performance.html">Rendimiento</a></li>
                    <li><a href="projects.html">Proyectos</a></li>
                </ul>
            </nav>
            <nav aria-label="Documentos legales">
                <h3>Documentación</h3>
                <ul>
                    <li><a href="contact.php">Contacto</a></li>
                    <li><a href="privacy.html">Política de privacidad</a></li>
                    <li><a href="cookies.html">Política de cookies</a></li>
                    <li><a href="terms.html">Términos legales</a></li>
                    <li><a href="sitemap.xml">Mapa del sitio</a></li>
                </ul>
            </nav>
        </div>
        <div class="container footer-bottom">
            <span>© 2024 Geo Thermal Control España. Todos los derechos reservados.</span>
            <span>Operamos en toda España con sede en Madrid.</span>
        </div>
    </footer>

    <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies">
        <p>
            Utilizamos cookies técnicas para garantizar el funcionamiento seguro del sitio y analíticas anónimas para mejorar la experiencia. Puedes gestionar tu preferencia en nuestra <a href="cookies.html">política de cookies</a>.
        </p>
        <div class="cookie-actions">
            <button class="button ghost" id="cookie-decline" type="button">Rechazar</button>
            <button class="button" id="cookie-accept" type="button">Aceptar</button>
        </div>
    </div>
</body>
</html>