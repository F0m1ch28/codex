document.addEventListener("DOMContentLoaded", () => {
  const yearElement = document.getElementById("current-year");
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.2
    }
  );

  document.querySelectorAll(".animate-on-scroll").forEach(section => {
    observer.observe(section);
  });

  const navToggle = document.querySelector(".menu-toggle");
  const primaryNav = document.getElementById("primary-navigation");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("is-open");
    });

    primaryNav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        primaryNav.classList.remove("is-open");
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const cookieStorageKey = "essaouiraconference_cookie_choice";

  if (cookieBanner) {
    const choice = localStorage.getItem(cookieStorageKey);
    if (!choice) {
      cookieBanner.classList.add("is-visible");
    }

    cookieBanner.querySelectorAll("[data-cookie-action]").forEach(button => {
      button.addEventListener("click", () => {
        const action = button.getAttribute("data-cookie-action");
        localStorage.setItem(cookieStorageKey, action);
        cookieBanner.classList.remove("is-visible");
        showToast(`Cookie preference saved: ${action}`);
      });
    });
  }

  function showToast(message) {
    const toast = document.getElementById("global-toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-active");
    setTimeout(() => {
      toast.classList.remove("is-active");
    }, 3200);
  }

  document.querySelectorAll("form[data-redirect]").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const redirectUrl = form.getAttribute("data-redirect") || form.getAttribute("action");
      showToast("Submission received. Redirecting...");
      setTimeout(() => {
        window.location.href = redirectUrl || "thank-you.html";
      }, 1500);
    });
  });
});