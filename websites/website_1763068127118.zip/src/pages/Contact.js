import React from 'react';
import { Helmet } from 'react-helmet';
import ContactStyles from './Contact.module.css';

const Contact = () => (
  <>
    <Helmet>
      <html lang="de" />
      <title>Kontakt | ArtVision Studio Berlin</title>
      <meta
        name="description"
        content="Kontaktieren Sie ArtVision Studio. Wir freuen uns auf Ihr Design-Projekt. Friedrichstraße 123, 10117 Berlin."
      />
      <link rel="canonical" href="https://www.artvision-studio.de/contact" />
    </Helmet>
    <section className={ContactStyles.hero}>
      <div className="container">
        <h1>Kontakt aufnehmen</h1>
        <p>
          Erzählen Sie uns von Ihrem Projekt, Ihrem Produkt oder Ihrer Vision. Wir melden uns schnellstmöglich mit den nächsten Schritten.
        </p>
      </div>
    </section>

    <section className={ContactStyles.grid}>
      <div className="container">
        <div className={ContactStyles.content}>
          <div className={ContactStyles.formWrap}>
            <h2>Projektanfrage</h2>
            <form
              className={ContactStyles.form}
              onSubmit={(event) => {
                event.preventDefault();
                event.currentTarget.reset();
                alert('Danke für Ihre Nachricht! Wir melden uns zeitnah.');
              }}
            >
              <label htmlFor="contact-name">Name*</label>
              <input id="contact-name" name="name" type="text" required placeholder="Vor- und Nachname" />
              <label htmlFor="contact-email">E-Mail*</label>
              <input id="contact-email" name="email" type="email" required placeholder="Ihre E-Mail-Adresse" />
              <label htmlFor="contact-company">Unternehmen</label>
              <input id="contact-company" name="company" type="text" placeholder="Unternehmensname" />
              <label htmlFor="contact-project">Projektziel*</label>
              <textarea id="contact-project" name="project" rows="5" required placeholder="Beschreiben Sie kurz Ihr Vorhaben" />
              <label className={ContactStyles.checkboxLabel}>
                <input type="checkbox" required name="privacy" />
                <span>Ich stimme der Verarbeitung meiner Daten gemäß Datenschutz zu.</span>
              </label>
              <button type="submit" className="button button--primary">
                Nachricht senden
              </button>
            </form>
          </div>
          <aside className={ContactStyles.info}>
            <div className={ContactStyles.box}>
              <h3>Studio</h3>
              <p>
                ArtVision Studio<br />
                Friedrichstraße 123<br />
                10117 Berlin, Germany
              </p>
            </div>
            <div className={ContactStyles.box}>
              <h3>Kontakt</h3>
              <p>
                Telefon:&nbsp;<a href="tel:+493012345678">+49 30 12345678</a><br />
                E-Mail:&nbsp;<a href="mailto:hello@artvision-studio.de">hello@artvision-studio.de</a>
              </p>
            </div>
            <div className={ContactStyles.mapWrapper}>
              <iframe
                title="ArtVision Studio Standort"
                src="https://maps.google.com/maps?q=Friedrichstrasse%20123%2C%2010117%20Berlin&t=&z=13&ie=UTF8&iwloc=&output=embed"
                loading="lazy"
              />
            </div>
          </aside>
        </div>
      </div>
    </section>
  </>
);

export default Contact;