import React from 'react';
import { Helmet } from 'react-helmet';
import CookiePolicyStyles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <html lang="de" />
      <title>Cookie-Richtlinie | ArtVision Studio</title>
      <meta
        name="description"
        content="Cookie-Richtlinie von ArtVision Studio. Erfahren Sie, welche Cookies wir setzen und wie Sie diese verwalten können."
      />
      <link rel="canonical" href="https://www.artvision-studio.de/cookie-policy" />
    </Helmet>
    <section className={CookiePolicyStyles.wrapper}>
      <div className="container">
        <h1>Cookie-Richtlinie</h1>
        <p>Stand: Januar 2024</p>

        <h2>1. Was sind Cookies?</h2>
        <p>
          Cookies sind kleine Textdateien, die auf Ihrem Endgerät gespeichert werden. Sie ermöglichen eine effiziente Nutzung unserer Website und helfen uns, das Nutzererlebnis zu verbessern.
        </p>

        <h2>2. Arten von Cookies</h2>
        <ul>
          <li>
            <strong>Essenzielle Cookies:</strong> notwendig für grundlegende Funktionen wie Formularverarbeitung.
          </li>
          <li>
            <strong>Analyse-Cookies:</strong> werden nur nach Ihrer Einwilligung eingesetzt, um das Nutzerverhalten zu verstehen.
          </li>
        </ul>

        <h2>3. Verwaltung</h2>
        <p>
          Sie können Cookies über die Einstellungen Ihres Browsers verwalten oder löschen. Darüber hinaus können Sie Ihre Einwilligung jederzeit über unser Cookie-Banner widerrufen.
        </p>

        <h2>4. Kontakt</h2>
        <p>
          Bei Fragen zur Cookie-Nutzung kontaktieren Sie uns unter hello@artvision-studio.de.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicy;