import React from 'react';
import { Helmet } from 'react-helmet';
import AboutStyles from './About.module.css';

const teamMembers = [
  {
    name: 'Mara Schulz',
    role: 'Creative Director & Co-Founder',
    image: 'https://picsum.photos/seed/mara/400/420',
  },
  {
    name: 'Emil Wagner',
    role: 'Head of UX',
    image: 'https://picsum.photos/seed/emil/400/420',
  },
  {
    name: 'Yara Hoffmann',
    role: 'Brand Strategist',
    image: 'https://picsum.photos/seed/yara/400/420',
  },
  {
    name: 'Noah Becker',
    role: 'Lead Visual Designer',
    image: 'https://picsum.photos/seed/noah/400/420',
  },
];

const About = () => (
  <>
    <Helmet>
      <html lang="de" />
      <title>Über ArtVision Studio | Unser Team und unsere Geschichte</title>
      <meta
        name="description"
        content="Lernen Sie das Team hinter ArtVision Studio kennen. Wir entwickeln visionäre Designlösungen aus Berlin mit internationalem Mindset."
      />
      <link rel="canonical" href="https://www.artvision-studio.de/about" />
    </Helmet>
    <section className={AboutStyles.hero}>
      <div className="container">
        <h1>Design mit Haltung und Herz</h1>
        <p>
          Seit 2014 gestaltet ArtVision Studio Marken und digitale Erlebnisse, die den Nerv der Zeit treffen – und darüber hinaus Bestand haben. Unsere Wurzeln liegen in Berlin, unsere Projekte reichen quer durch Europa.
        </p>
      </div>
    </section>

    <section className={AboutStyles.story}>
      <div className="container">
        <div className={AboutStyles.storyGrid}>
          <div>
            <h2>Von der Idee zum Studio</h2>
            <p>
              ArtVision Studio entstand aus der gemeinsamen Vision von Designerinnen, Strategen und Entwicklerinnen, die Design als Transformationskraft verstehen. Was als kleines Kollektiv begann, ist heute ein eingespieltes Team aus zwölf Expert:innen – vom UX Research bis Motion Design.
            </p>
            <p>
              Unser Ansatz: Wir hören genau hin, hinterfragen Annahmen und entwickeln Lösungen, die Markenidentität, Nutzererlebnis und Business-Ziele verbinden. Wir arbeiten prozess-orientiert, daten-informiert und mit einem starken Fokus auf Zugänglichkeit.
            </p>
          </div>
          <div>
            <h2>Wir leben Kollaboration</h2>
            <p>
              Jede Marke hat ihre eigene DNA. Darum entwickeln wir Workshops, Co-Creation-Sessions und Design-Sprints, die Teams aktiv einbinden. So entstehen Ergebnisse, die intern verankert sind und extern differenzieren.
            </p>
            <p>
              Unsere Kund:innen kommen aus Technologie, Kultur, Nachhaltigkeit und Lifestyle. Was sie verbindet, ist der Anspruch, ihre Marke neu zu denken. Wir begleiten sie als Sparringspartner – strategisch, kreativ und zuverlässig.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={AboutStyles.values}>
      <div className="container">
        <h2>Unsere Werte</h2>
        <div className={AboutStyles.valuesGrid}>
          <article>
            <h3>Neugier</h3>
            <p>
              Wir hinterfragen, experimentieren und suchen nach Lösungen jenseits des Offensichtlichen.
            </p>
          </article>
          <article>
            <h3>Transparenz</h3>
            <p>
              Offene Kommunikation und klare Prozesse sorgen für Vertrauen und Effizienz.
            </p>
          </article>
          <article>
            <h3>Inklusion</h3>
            <p>
              Barrierefreie Designs und diverse Perspektiven führen zu besseren Produkten für alle.
            </p>
          </article>
          <article>
            <h3>Impact</h3>
            <p>
              Unsere Arbeit soll messbare Veränderungen bewirken – für Marken und deren Nutzer:innen.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={AboutStyles.team}>
      <div className="container">
        <h2>Team ArtVision</h2>
        <p className={AboutStyles.teamIntro}>
          Ein multidisziplinäres Team mit einem gemeinsamen Ziel: Erfahrungen zu gestalten, die Menschen begeistern.
        </p>
        <div className={AboutStyles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={AboutStyles.member}>
              <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
              <h3>{member.name}</h3>
              <p>{member.role}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default About;