import React from 'react';
import { Helmet } from 'react-helmet';
import TermsStyles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <html lang="de" />
      <title>Nutzungsbedingungen | ArtVision Studio</title>
      <meta
        name="description"
        content="Nutzungsbedingungen für die Website von ArtVision Studio."
      />
      <link rel="canonical" href="https://www.artvision-studio.de/terms" />
    </Helmet>
    <section className={TermsStyles.wrapper}>
      <div className="container">
        <h1>Nutzungsbedingungen</h1>
        <p>Stand: Januar 2024</p>

        <h2>1. Geltungsbereich</h2>
        <p>
          Diese Nutzungsbedingungen gelten für die Nutzung der Website von ArtVision Studio. Mit dem Zugriff auf unsere Website erkennen Sie die folgenden Bestimmungen an.
        </p>

        <h2>2. Inhalte</h2>
        <p>
          Alle Inhalte unserer Website wurden mit größter Sorgfalt erstellt. Dennoch übernehmen wir keine Gewähr für Richtigkeit, Vollständigkeit und Aktualität. Inhalte können jederzeit ohne Vorankündigung geändert werden.
        </p>

        <h2>3. Urheberrecht</h2>
        <p>
          Die auf dieser Website veröffentlichten Inhalte und Werke unterliegen dem deutschen Urheberrecht. Jede Verwertung bedarf der vorherigen schriftlichen Zustimmung von ArtVision Studio oder der jeweiligen Urheber:innen.
        </p>

        <h2>4. Haftung</h2>
        <p>
          Wir haften nicht für Schäden, die durch die Nutzung oder Nichtnutzung der bereitgestellten Informationen entstehen, sofern kein nachweislich vorsätzliches oder grob fahrlässiges Verschulden vorliegt.
        </p>

        <h2>5. Verlinkungen</h2>
        <p>
          Unsere Website kann Links zu externen Websites enthalten. Auf deren Inhalte haben wir keinen Einfluss. Für die Inhalte verlinkter Seiten ist der jeweilige Anbieter verantwortlich.
        </p>

        <h2>6. Datenschutz</h2>
        <p>
          Informationen zum Datenschutz finden Sie in unserer Datenschutzerklärung.
        </p>

        <h2>7. Änderungen</h2>
        <p>
          Wir behalten uns vor, diese Nutzungsbedingungen bei Bedarf anzupassen. Es gilt die jeweils aktuelle Fassung.
        </p>
      </div>
    </section>
  </>
);

export default Terms;