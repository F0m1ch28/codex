import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import PortfolioStyles from './Portfolio.module.css';

const projects = [
  {
    title: 'Aurora E-Commerce Plattform',
    sector: 'Tech & Retail',
    category: 'Webdesign',
    image: 'https://picsum.photos/seed/aurora-full/900/620',
    summary: 'Headless Commerce mit personalisierten User Journeys und dynamischen Produktvisualisierungen.',
  },
  {
    title: 'Lumen Capital Identity',
    sector: 'Finance',
    category: 'Branding',
    image: 'https://picsum.photos/seed/lumen-full/900/620',
    summary: 'Vertrauensaufbau durch ein prägnantes Branding für einen europäischen Klimafonds.',
  },
  {
    title: 'FlowRide Mobility App',
    sector: 'Mobility',
    category: 'UI/UX',
    image: 'https://picsum.photos/seed/flowride-full/900/620',
    summary: 'Benutzerfreundliche App mit Echtzeitdaten, Onboarding und Accessibility für alle Nutzer:innen.',
  },
  {
    title: 'Atelier Bloom Kampagne',
    sector: 'Lifestyle',
    category: 'Grafikdesign',
    image: 'https://picsum.photos/seed/bloom-full/900/620',
    summary: 'Illustrative Visuals und Storytelling für eine nachhaltige Lifestyle-Marke.',
  },
  {
    title: 'Pulse Health Dashboard',
    sector: 'Healthcare',
    category: 'UI/UX',
    image: 'https://picsum.photos/seed/pulse-full/900/620',
    summary: 'Data Visualizations und modulare Komponenten für medizinische Entscheidungsprozesse.',
  },
  {
    title: 'Nordlicht Scale-up Branding',
    sector: 'SaaS',
    category: 'Branding',
    image: 'https://picsum.photos/seed/nordlicht-full/900/620',
    summary: 'Flexible Brand Assets inklusive Motion-Kit für internationale Roll-outs.',
  },
];

const categories = ['Alle', 'Webdesign', 'Branding', 'UI/UX', 'Grafikdesign'];

const Portfolio = () => {
  const [filter, setFilter] = useState('Alle');
  const filtered =
    filter === 'Alle' ? projects : projects.filter((project) => project.category === filter);

  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Portfolio | ArtVision Studio Projekte</title>
        <meta
          name="description"
          content="Entdecken Sie Projekte von ArtVision Studio: Webdesign, Branding, UI/UX und Grafikdesign für Unternehmen in Europa."
        />
        <link rel="canonical" href="https://www.artvision-studio.de/portfolio" />
      </Helmet>
      <section className={PortfolioStyles.hero}>
        <div className="container">
          <h1>Projekte, die Marken erlebbar machen</h1>
          <p>
            Jede Zusammenarbeit ist einzigartig. Unser Portfolio zeigt die Bandbreite an Branchen, Design-Disziplinen und Herausforderungen, die wir erfolgreich gestalten durften.
          </p>
        </div>
      </section>

      <section className={PortfolioStyles.gallery}>
        <div className="container">
          <div className={PortfolioStyles.filterRow}>
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                className={`${PortfolioStyles.filterBtn} ${filter === cat ? PortfolioStyles.active : ''}`}
                onClick={() => setFilter(cat)}
                aria-pressed={filter === cat}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className={PortfolioStyles.grid}>
            {filtered.map((project) => (
              <article key={project.title} className={PortfolioStyles.card}>
                <div className={PortfolioStyles.media}>
                  <img src={project.image} alt={`Case Study: ${project.title}`} loading="lazy" />
                  <span>{project.category}</span>
                </div>
                <div className={PortfolioStyles.content}>
                  <h2>{project.title}</h2>
                  <p>{project.summary}</p>
                  <div className={PortfolioStyles.meta}>
                    <span>Branche: {project.sector}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Portfolio;