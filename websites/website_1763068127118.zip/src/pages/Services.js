import React from 'react';
import { Helmet } from 'react-helmet';
import ServicesStyles from './Services.module.css';

const serviceSections = [
  {
    title: 'Markenstrategie & Positionierung',
    description:
      'Wir entwickeln Brand Platforms, die Ihr Profil schärfen. Dazu gehören Markenworkshops, Wettbewerbsanalyse und klare Messaging-Strukturen, die intern wie extern funktionieren.',
    bullets: ['Markenworkshops & Stakeholder-Interviews', 'Purpose, Vision & Tonalität', 'Brand Architecture & Messaging'],
  },
  {
    title: 'Digital Product Design',
    description:
      'Von Discovery bis zum High-Fidelity Prototyping – wir entwickeln Interfaces, die Menschen intuitiv nutzen können. Unser Fokus liegt auf Accessibility und Performance.',
    bullets: ['UX Research & Personas', 'Informationsarchitektur & User Flows', 'Design Systeme & UI Kits'],
  },
  {
    title: 'Webdesign & Entwicklung',
    description:
      'Wir gestalten Websites mit nahtloser Nutzerführung, SEO-Optimierung und Headless CMS-Setups, die Ihr Team eigenständig pflegen kann.',
    bullets: ['Responsive UI & Interaction Design', 'CMS-Implementierung (Headless, Webflow, WordPress)', 'SEO & Performance Optimierung'],
  },
  {
    title: 'Kampagnen & Visual Storytelling',
    description:
      'Wir erzählen Geschichten in starken Visuals – von Motion Graphics bis Editorial Design. Jedes Element passt nahtlos in Ihre Markenwelt.',
    bullets: ['Key Visuals & Kampagnenkonzepte', 'Illustration & Icon Design', 'Storyboards & Motion Design'],
  },
];

const Services = () => (
  <>
    <Helmet>
      <html lang="de" />
      <title>Leistungen | ArtVision Studio</title>
      <meta
        name="description"
        content="Entdecken Sie die Leistungen von ArtVision Studio: Branding, Webdesign, UI/UX und visuelles Storytelling für ambitionierte Marken."
      />
      <link rel="canonical" href="https://www.artvision-studio.de/services" />
    </Helmet>
    <section className={ServicesStyles.hero}>
      <div className="container">
        <h1>Designlösungen entlang des gesamten Markenerlebnisses</h1>
        <p>
          Wir begleiten Ihr Projekt von der Strategie bis zum Launch – und darüber hinaus. Unser multidisziplinäres Team arbeitet mit klaren Prozessen, exzellenter Gestaltung und einem feinen Gespür für Details.
        </p>
      </div>
    </section>

    <section className={ServicesStyles.services}>
      <div className="container">
        <div className={ServicesStyles.grid}>
          {serviceSections.map((section) => (
            <article key={section.title} className={ServicesStyles.card}>
              <h2>{section.title}</h2>
              <p>{section.description}</p>
              <ul>
                {section.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={ServicesStyles.cta}>
      <div className="container">
        <div className={ServicesStyles.ctaBox}>
          <h2>Gemeinsam das nächste Kapitel schreiben?</h2>
          <p>
            Lassen Sie uns in einem unverbindlichen Gespräch herausfinden, wie wir Ihre Marke stärken können.
          </p>
          <a className="button button--light" href="/contact">
            Gespräch vereinbaren
          </a>
        </div>
      </div>
    </section>
  </>
);

export default Services;