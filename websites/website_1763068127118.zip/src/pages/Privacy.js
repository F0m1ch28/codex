import React from 'react';
import { Helmet } from 'react-helmet';
import PrivacyStyles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <html lang="de" />
      <title>Datenschutzerklärung | ArtVision Studio</title>
      <meta
        name="description"
        content="Datenschutzinformationen von ArtVision Studio in Übereinstimmung mit der DSGVO."
      />
      <link rel="canonical" href="https://www.artvision-studio.de/privacy" />
    </Helmet>
    <section className={PrivacyStyles.wrapper}>
      <div className="container">
        <h1>Datenschutzerklärung</h1>
        <p>Stand: Januar 2024</p>

        <h2>1. Verantwortliche Stelle</h2>
        <p>
          ArtVision Studio<br />
          Friedrichstraße 123, 10117 Berlin, Germany<br />
          Telefon: +49 30 12345678<br />
          E-Mail: hello@artvision-studio.de
        </p>

        <h2>2. Verarbeitung personenbezogener Daten</h2>
        <p>
          Wir verarbeiten personenbezogene Daten ausschließlich im Rahmen der gesetzlichen Bestimmungen. Dazu zählen insbesondere Kontaktdaten, Projektdetails und Kommunikationsinhalte, die Sie uns über unsere Formulare oder per E-Mail übermitteln.
        </p>

        <h2>3. Zweck und Rechtsgrundlagen</h2>
        <ul>
          <li>Bearbeitung von Anfragen (Art. 6 Abs. 1 lit. b DSGVO)</li>
          <li>Vertragserfüllung und Projektabwicklung (Art. 6 Abs. 1 lit. b DSGVO)</li>
          <li>Analyse und Optimierung unserer Website (Art. 6 Abs. 1 lit. f DSGVO)</li>
        </ul>

        <h2>4. Cookies & Tracking</h2>
        <p>
          Unsere Website setzt essentielle Cookies ein, um grundlegende Funktionen bereitzustellen. Analyse-Tools kommen nur nach Ihrer Einwilligung zum Einsatz. Details hierzu finden Sie in unserer Cookie-Richtlinie.
        </p>

        <h2>5. Datenübermittlung</h2>
        <p>
          Eine Weitergabe Ihrer Daten findet nur statt, wenn dies für die Vertragserfüllung erforderlich ist oder eine gesetzliche Verpflichtung besteht.
        </p>

        <h2>6. Speicherdauer</h2>
        <p>
          Wir speichern personenbezogene Daten nur so lange, wie es für die genannten Zwecke erforderlich ist oder eine gesetzliche Aufbewahrungspflicht besteht.
        </p>

        <h2>7. Ihre Rechte</h2>
        <p>
          Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung und Datenübertragbarkeit. Wenden Sie sich dazu an hello@artvision-studio.de. Außerdem steht Ihnen ein Beschwerderecht bei der zuständigen Aufsichtsbehörde zu.
        </p>

        <h2>8. Kontakt</h2>
        <p>
          Bei Fragen zum Datenschutz kontaktieren Sie uns unter hello@artvision-studio.de oder telefonisch unter +49 30 12345678.
        </p>
      </div>
    </section>
  </>
);

export default Privacy;