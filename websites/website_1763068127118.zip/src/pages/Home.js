import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import ReviewCarousel from '../components/ReviewCarousel';
import HomeStyles from './Home.module.css';

const portfolioItems = [
  {
    id: 1,
    title: 'Aurora E-Commerce Plattform',
    category: 'Webdesign',
    image: 'https://picsum.photos/seed/aurora/700/500',
    description: 'Skalierbares Headless-Shop-Erlebnis mit immersiver Produktvisualisierung.',
  },
  {
    id: 2,
    title: 'Lumen Identity System',
    category: 'Branding',
    image: 'https://picsum.photos/seed/lumen/700/500',
    description: 'Neue Markenidentität für einen europäischen Klimafonds.',
  },
  {
    id: 3,
    title: 'FlowRide App UI',
    category: 'UI/UX',
    image: 'https://picsum.photos/seed/flowride/700/500',
    description: 'Mobilitäts-App mit Fokus auf Echtzeitdaten und barrierefreie Nutzung.',
  },
  {
    id: 4,
    title: 'Atelier Bloom Kampagne',
    category: 'Grafikdesign',
    image: 'https://picsum.photos/seed/bloom/700/500',
    description: 'Illustrative Kampagne mit handgezeichneten Elementen und Typografie.',
  },
  {
    id: 5,
    title: 'Pulse Health Dashboard',
    category: 'UI/UX',
    image: 'https://picsum.photos/seed/pulse/700/500',
    description: 'Data-Driven Dashboard für eine digitale Gesundheitsplattform.',
  },
  {
    id: 6,
    title: 'Nordlicht Brand Guidelines',
    category: 'Branding',
    image: 'https://picsum.photos/seed/nordlicht/700/500',
    description: 'Ganzheitliches Corporate Design für ein Tech-Scale-up aus Berlin.',
  },
];

const services = [
  {
    title: 'Digitales Webdesign',
    description:
      'User-zentrierte Websites mit modularen Designsystemen, optimiert für Performance und SEO.',
    icon: '🌐',
  },
  {
    title: 'Strategisches Branding',
    description:
      'Markenidentitäten, die Werte sichtbar machen – von Naming bis Brand Guidelines.',
    icon: '✨',
  },
  {
    title: 'UI/UX Design Thinking',
    description:
      'Research, Prototyping und Testing, um digitale Produkte intuitiv und inklusiv zu gestalten.',
    icon: '🧠',
  },
  {
    title: 'Grafik & Illustration',
    description:
      'Editorial Design, Kampagnenvisuals und individuelle Illustrationen mit starker Wirkung.',
    icon: '🎨',
  },
];

const processSteps = [
  {
    title: 'Discover',
    description: 'Wir analysieren Vision, Zielgruppen und KPIs, um Fokus und Scope präzise zu definieren.',
  },
  {
    title: 'Design',
    description: 'Konzept, Moodboards, Prototypen: wir übersetzen Insights in visuelle Konzepte.',
  },
  {
    title: 'Develop',
    description: 'Design-Systeme, Interaktionen, Guidelines – bereit für Roll-out und Skalierung.',
  },
  {
    title: 'Deliver & Iterate',
    description: 'Launch, Monitoring und kontinuierliche Optimierung entlang definierter Ziele.',
  },
];

const Home = () => {
  const [filter, setFilter] = useState('Alle');
  const filteredItems =
    filter === 'Alle'
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === filter);

  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>ArtVision Studio | Visionäre Designs für starke Marken</title>
        <meta
          name="description"
          content="ArtVision Studio aus Berlin kreiert strategisches Webdesign, Branding und UI/UX Lösungen, die Ihre Marke sichtbar machen."
        />
        <link rel="canonical" href="https://www.artvision-studio.de/" />
      </Helmet>
      <section className={HomeStyles.hero}>
        <div className="container">
          <div className={HomeStyles.heroInner}>
            <motion.div
              className={HomeStyles.heroContent}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <span className={HomeStyles.badge}>Kreatives Design aus Berlin</span>
              <h1 className={HomeStyles.title}>
                Wir gestalten digitale Erlebnisse, die <span>Marken spürbar machen.</span>
              </h1>
              <p className={HomeStyles.subtitle}>
                ArtVision Studio vereint Strategie, Design und Technologie. Unser Team entwickelt Markenwelten, Websites und Interfaces, die Menschen berühren und Ziele erreichen.
              </p>
              <div className={HomeStyles.heroActions}>
                <Link to="/portfolio" className="button button--primary">
                  Portfolio entdecken
                </Link>
                <Link to="/contact" className="button button--ghost">
                  Projekt anfragen
                </Link>
              </div>
              <div className={HomeStyles.heroStats} aria-label="Ausgewählte Kennzahlen">
                <div>
                  <strong>120+</strong>
                  <span>Projekte europaweit</span>
                </div>
                <div>
                  <strong>18</strong>
                  <span>Design Awards</span>
                </div>
                <div>
                  <strong>12</strong>
                  <span>Teammitglieder</span>
                </div>
              </div>
            </motion.div>
            <motion.div
              className={HomeStyles.heroMedia}
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <img
                src="https://picsum.photos/seed/artvisionstudio/720/640"
                alt="Design-Team von ArtVision Studio bei der Konzeptentwicklung"
                loading="lazy"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className={HomeStyles.about}>
        <div className="container">
          <div className={HomeStyles.zigzag}>
            <div className={HomeStyles.text}>
              <h2>Strategischer Fokus mit Sinn für Ästhetik</h2>
              <p>
                Wir glauben, dass jedes starke Produkt auf einer klaren Markenstory basiert. Deshalb verbinden wir qualitative Recherche mit kreativer Exzellenz. Unser Studio in Berlin arbeitet interdisziplinär – von UX Research über Motion bis Typografie. So entstehen Erlebnisse, die Konsistenz und Emotion vereinen.
              </p>
              <p>
                Nachhaltige Partnerschaften sind uns wichtig: Wir begleiten Start-ups beim Scale-up, etablierte Unternehmen bei Transformationen und Kulturinstitutionen bei ihrer digitalen Präsenz.
              </p>
              <Link to="/about" className="link-underline">
                Mehr über unsere Vision
              </Link>
            </div>
            <div className={HomeStyles.imageWrap}>
              <img
                src="https://picsum.photos/seed/atelier/720/520"
                alt="Kollaboration von Designerinnen am Moodboard"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={HomeStyles.services} id="services">
        <div className="container">
          <div className={HomeStyles.sectionHead}>
            <h2>Unsere Kernkompetenzen</h2>
            <p>
              Wir designen entlang des gesamten Markenerlebnisses – von der digitalen Touchpoint-Strategie bis zum finalen Roll-out.
            </p>
          </div>
          <div className={HomeStyles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={HomeStyles.serviceCard}>
                <span className={HomeStyles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className="link-underline">
                  Mehr erfahren
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={HomeStyles.portfolio}>
        <div className="container">
          <div className={HomeStyles.sectionHead}>
            <h2>Ausgewählte Projekte</h2>
            <p>
              Vom Minimum Viable Product bis zur globalen Markenwelt – jedes Projekt basiert auf messbaren Zielen und klarer Designstrategie.
            </p>
          </div>
          <div className={HomeStyles.filters} role="tablist" aria-label="Portfolio Filter">
            {['Alle', 'Webdesign', 'Branding', 'UI/UX', 'Grafikdesign'].map((item) => (
              <button
                type="button"
                key={item}
                className={`${HomeStyles.filterButton} ${filter === item ? HomeStyles.filterActive : ''}`}
                aria-pressed={filter === item}
                onClick={() => setFilter(item)}
              >
                {item}
              </button>
            ))}
          </div>
          <div className={HomeStyles.portfolioGrid}>
            {filteredItems.map((project) => (
              <article key={project.id} className={HomeStyles.projectCard}>
                <div className={HomeStyles.projectImage}>
                  <img src={project.image} alt={`Projekt ${project.title}`} loading="lazy" />
                  <span>{project.category}</span>
                </div>
                <div className={HomeStyles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/portfolio" className="link-underline">
                    Projekt ansehen
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={HomeStyles.process}>
        <div className="container">
          <div className={HomeStyles.sectionHead}>
            <h2>Unser Prozess</h2>
            <p>
              Transparent, kollaborativ und zielorientiert – wir führen Ihr Team durch jeden Schritt des Design-Prozesses.
            </p>
          </div>
          <div className={HomeStyles.processGrid}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={HomeStyles.processCard}>
                <span className={HomeStyles.processIndex}>{String(index + 1).padStart(2, '0')}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={HomeStyles.testimonials}>
        <div className="container">
          <div className={HomeStyles.sectionHead}>
            <h2>Stimmen unserer Partner</h2>
            <p>
              Langfristige Zusammenarbeit und messbare Ergebnisse sprechen für sich.
            </p>
          </div>
          <ReviewCarousel />
        </div>
      </section>

      <section className={HomeStyles.contact}>
        <div className="container">
          <div className={HomeStyles.contactGrid}>
            <div className={HomeStyles.contactInfo}>
              <h2>Bereit für das nächste Kapitel Ihrer Marke?</h2>
              <p>
                Erzählen Sie uns von Ihren Herausforderungen. Wir melden uns innerhalb von 24 Stunden mit einem klaren Vorschlag für das nächste gemeinsame Vorgehen.
              </p>
              <div className={HomeStyles.contactDetails}>
                <div>
                  <span>Adresse</span>
                  <p>
                    ArtVision Studio<br />
                    Friedrichstraße 123<br />
                    10117 Berlin, Germany
                  </p>
                </div>
                <div>
                  <span>Kontakt</span>
                  <p>
                    Telefon: <a href="tel:+493012345678">+49 30 12345678</a><br />
                    E-Mail: <a href="mailto:hello@artvision-studio.de">hello@artvision-studio.de</a>
                  </p>
                </div>
              </div>
            </div>
            <div className={HomeStyles.contactFormWrapper}>
              <h3>Projektbriefing</h3>
              <form
                className={HomeStyles.contactForm}
                onSubmit={(event) => {
                  event.preventDefault();
                  event.currentTarget.reset();
                  alert('Vielen Dank! Wir melden uns in Kürze bei Ihnen.');
                }}
              >
                <label htmlFor="home-name">Name</label>
                <input id="home-name" name="name" type="text" placeholder="Ihr Name" required />
                <label htmlFor="home-email">E-Mail</label>
                <input id="home-email" name="email" type="email" placeholder="Ihre E-Mail-Adresse" required />
                <label htmlFor="home-company">Unternehmen</label>
                <input id="home-company" name="company" type="text" placeholder="Unternehmensname (optional)" />
                <label htmlFor="home-message">Projektbeschreibung</label>
                <textarea id="home-message" name="message" rows="4" placeholder="Beschreiben Sie Ihr Vorhaben" required />
                <button type="submit" className="button button--primary">
                  Nachricht senden
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;