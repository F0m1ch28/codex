import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import classNames from 'classnames';
import HeaderStyles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={classNames(HeaderStyles.header, {
        [HeaderStyles.headerScrolled]: scrolled,
      })}
    >
      <div className="container">
        <div className={HeaderStyles.inner}>
          <NavLink to="/" className={HeaderStyles.logo} aria-label="ArtVision Studio Startseite">
            ArtVision<span>Studio</span>
          </NavLink>
          <button
            type="button"
            className={HeaderStyles.menuToggle}
            aria-label="Navigation umschalten"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span />
            <span />
            <span />
          </button>
          <nav
            className={classNames(HeaderStyles.nav, {
              [HeaderStyles.navOpen]: menuOpen,
            })}
            aria-label="Hauptnavigation"
          >
            <NavLink to="/about" className={({ isActive }) => classNames(HeaderStyles.link, { [HeaderStyles.active]: isActive })}>
              Über uns
            </NavLink>
            <NavLink to="/services" className={({ isActive }) => classNames(HeaderStyles.link, { [HeaderStyles.active]: isActive })}>
              Leistungen
            </NavLink>
            <NavLink to="/portfolio" className={({ isActive }) => classNames(HeaderStyles.link, { [HeaderStyles.active]: isActive })}>
              Portfolio
            </NavLink>
            <NavLink to="/contact" className={({ isActive }) => classNames(HeaderStyles.link, { [HeaderStyles.active]: isActive })}>
              Kontakt
            </NavLink>
            <NavLink to="/contact" className={HeaderStyles.ctaButton}>
              Jetzt anfragen
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;