import React from 'react';
import { Link } from 'react-router-dom';
import FooterStyles from './Footer.module.css';

const Footer = () => (
  <footer className={FooterStyles.footer}>
    <div className="container">
      <div className={FooterStyles.grid}>
        <div>
          <h3 className={FooterStyles.title}>ArtVision Studio</h3>
          <p className={FooterStyles.text}>
            Friedrichstraße 123<br />
            10117 Berlin, Deutschland
          </p>
          <p className={FooterStyles.text}>
            Telefon: <a href="tel:+493012345678">+49 30 12345678</a><br />
            E-Mail: <a href="mailto:hello@artvision-studio.de">hello@artvision-studio.de</a>
          </p>
        </div>
        <div>
          <h4 className={FooterStyles.subtitle}>Navigation</h4>
          <ul className={FooterStyles.list}>
            <li><Link to="/about">Über uns</Link></li>
            <li><Link to="/services">Leistungen</Link></li>
            <li><Link to="/portfolio">Portfolio</Link></li>
            <li><Link to="/contact">Kontakt</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={FooterStyles.subtitle}>Rechtliches</h4>
          <ul className={FooterStyles.list}>
            <li><Link to="/privacy">Datenschutz</Link></li>
            <li><Link to="/terms">Nutzungsbedingungen</Link></li>
            <li><Link to="/cookie-policy">Cookie-Richtlinie</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={FooterStyles.subtitle}>Folgen Sie uns</h4>
          <ul className={FooterStyles.socials}>
            <li><a href="https://www.behance.net" target="_blank" rel="noreferrer">Behance</a></li>
            <li><a href="https://dribbble.com" target="_blank" rel="noreferrer">Dribbble</a></li>
            <li><a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a></li>
          </ul>
        </div>
      </div>
      <div className={FooterStyles.bottom}>
        <p>© {new Date().getFullYear()} ArtVision Studio. Alle Rechte vorbehalten.</p>
      </div>
    </div>
  </footer>
);

export default Footer;