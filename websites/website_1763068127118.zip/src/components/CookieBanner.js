import React, { useState, useEffect } from 'react';
import CookieStyles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('av-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('av-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={CookieStyles.banner} role="dialog" aria-live="polite" aria-label="Cookie Hinweis">
      <div className={CookieStyles.content}>
        <p>
          Wir verwenden Cookies, um Ihr Erlebnis zu optimieren und unseren Service zu verbessern. Durch Ihre Zustimmung helfen Sie uns, ArtVision Studio noch besser zu machen.
        </p>
        <div className={CookieStyles.actions}>
          <a href="/cookie-policy" className={CookieStyles.link}>
            Mehr erfahren
          </a>
          <button type="button" onClick={acceptCookies} className={CookieStyles.button}>
            Akzeptieren
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;