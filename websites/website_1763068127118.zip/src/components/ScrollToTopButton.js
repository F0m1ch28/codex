import React, { useState, useEffect } from 'react';
import { FiArrowUp } from 'react-icons/fi';
import ScrollStyles from './ScrollToTopButton.module.css';

const ScrollToTopButton = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setVisible(window.scrollY > 320);
    };
    window.addEventListener('scroll', toggleVisibility);
    toggleVisibility();
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!visible) return null;

  return (
    <button
      type='button'
      className={ScrollStyles.button}
      onClick={scrollToTop}
      aria-label="Nach oben scrollen"
    >
      <FiArrowUp />
    </button>
  );
};

export default ScrollToTopButton;