import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ReviewStyles from './ReviewCarousel.module.css';

const testimonials = [
  {
    name: 'Leonie Krauss',
    role: 'Marketing Lead, Nordlicht Tech',
    quote:
      'ArtVision Studio hat unsere Marke komplett neu positioniert. Die Kombination aus Strategie, Ästhetik und Nutzerfokus ist beeindruckend.',
  },
  {
    name: 'Jakob Meier',
    role: 'Produktmanager, Urban Mobility GmbH',
    quote:
      'Das Team liefert präzise Arbeit, tiefes Verständnis für UX und eine enge Zusammenarbeit. Unsere Conversion-Rates sind deutlich gestiegen.',
  },
  {
    name: 'Clara Hofmann',
    role: 'Gründerin, Bloom & Co.',
    quote:
      'Von Moodboards bis Launch war alles professionell orchestriert. Besonders die Illustrationen spiegeln unsere Vision perfekt wider.',
  },
];

const ReviewCarousel = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setCurrent((prev) => (prev + 1) % testimonials.length),
      6000
    );
    return () => clearInterval(timer);
  }, []);

  return (
    <div className={ReviewStyles.wrapper} aria-live="polite">
      <AnimatePresence mode="wait">
        <motion.blockquote
          key={current}
          className={ReviewStyles.card}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.5 }}
        >
          <p className={ReviewStyles.quote}>“{testimonials[current].quote}”</p>
          <footer className={ReviewStyles.footer}>
            <span className={ReviewStyles.name}>{testimonials[current].name}</span>
            <span className={ReviewStyles.role}>{testimonials[current].role}</span>
          </footer>
        </motion.blockquote>
      </AnimatePresence>
      <div className={ReviewStyles.dots} role="tablist" aria-label="Kundenstimmen Navigationspunkte">
        {testimonials.map((item, index) => (
          <button
            key={item.name}
            type="button"
            className={`${ReviewStyles.dot} ${index === current ? ReviewStyles.dotActive : ''}`}
            aria-label={`Bewertung von ${item.name} anzeigen`}
            aria-selected={index === current}
            onClick={() => setCurrent(index)}
          />
        ))}
      </div>
    </div>
  );
};

export default ReviewCarousel;