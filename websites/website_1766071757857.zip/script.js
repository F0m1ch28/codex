(function () {
  document.addEventListener("DOMContentLoaded", function () {
    var navToggle = document.querySelector(".nav-toggle");
    var navList = document.querySelector(".site-nav-list");
    if (navToggle && navList) {
      navToggle.addEventListener("click", function () {
        navList.classList.toggle("is-open");
        var expanded = navToggle.getAttribute("aria-expanded") === "true";
        navToggle.setAttribute("aria-expanded", (!expanded).toString());
      });
    }

    var cookieBanner = document.getElementById("cookieBanner");
    var acceptBtn = document.getElementById("acceptCookies");
    var declineBtn = document.getElementById("declineCookies");
    var storedConsent = localStorage.getItem("cookieConsent");
    if (cookieBanner) {
      if (!storedConsent) {
        requestAnimationFrame(function () {
          cookieBanner.classList.add("is-visible");
        });
      }
      if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
          localStorage.setItem("cookieConsent", "accepted");
          cookieBanner.classList.remove("is-visible");
        });
      }
      if (declineBtn) {
        declineBtn.addEventListener("click", function () {
          localStorage.setItem("cookieConsent", "declined");
          cookieBanner.classList.remove("is-visible");
        });
      }
    }

    var disclaimerOverlay = document.getElementById("disclaimerOverlay");
    var acknowledgeBtn = document.getElementById("acknowledgeDisclaimer");
    var disclaimerStatus = localStorage.getItem("disclaimerAcknowledged");
    if (disclaimerOverlay) {
      if (disclaimerStatus === "true") {
        disclaimerOverlay.classList.remove("is-visible");
      } else {
        disclaimerOverlay.classList.add("is-visible");
      }
      if (acknowledgeBtn) {
        acknowledgeBtn.addEventListener("click", function () {
          localStorage.setItem("disclaimerAcknowledged", "true");
          disclaimerOverlay.classList.remove("is-visible");
        });
      }
    }
  });
})();