document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("is-open");
        });

        siteNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                siteNav.classList.remove("is-open");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('[data-action="accept-cookies"]');
        const declineBtn = cookieBanner.querySelector('[data-action="decline-cookies"]');
        const storedConsent = localStorage.getItem("cookieConsent");

        if (storedConsent === "accepted" || storedConsent === "declined") {
            cookieBanner.classList.add("is-hidden");
        }

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem("cookieConsent", "accepted");
                cookieBanner.classList.add("is-hidden");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem("cookieConsent", "declined");
                cookieBanner.classList.add("is-hidden");
            });
        }
    }

    const contactForm = document.querySelector("#contact-form");
    if (contactForm) {
        const messageBox = contactForm.querySelector("[data-form-message]");
        const inputs = contactForm.querySelectorAll("input, textarea, select");

        inputs.forEach((field) => {
            field.addEventListener("input", () => {
                field.classList.remove("is-invalid");
                if (messageBox) {
                    messageBox.textContent = "";
                    messageBox.removeAttribute("data-type");
                }
            });
        });

        contactForm.addEventListener("submit", (event) => {
            let isValid = true;
            const nameInput = contactForm.querySelector('[name="name"]');
            const emailInput = contactForm.querySelector('[name="email"]');
            const phoneInput = contactForm.querySelector('[name="phone"]');
            const serviceSelect = contactForm.querySelector('[name="service"]');
            const messageInput = contactForm.querySelector('[name="message"]');

            if (nameInput && !nameInput.value.trim()) {
                nameInput.classList.add("is-invalid");
                isValid = false;
            }

            if (emailInput) {
                const emailValue = emailInput.value.trim();
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailValue || !emailPattern.test(emailValue)) {
                    emailInput.classList.add("is-invalid");
                    isValid = false;
                }
            }

            if (phoneInput && phoneInput.value.trim().length < 7) {
                phoneInput.classList.add("is-invalid");
                isValid = false;
            }

            if (serviceSelect && !serviceSelect.value) {
                serviceSelect.classList.add("is-invalid");
                isValid = false;
            }

            if (messageInput && messageInput.value.trim().length < 15) {
                messageInput.classList.add("is-invalid");
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault();
                if (messageBox) {
                    messageBox.textContent = "Пожалуйста, проверьте корректность введённых данных.";
                    messageBox.setAttribute("data-type", "error");
                }
            } else if (messageBox) {
                messageBox.textContent = "Спасибо! Ваше сообщение отправлено.";
                messageBox.setAttribute("data-type", "success");
            }
        });
    }
});