window.__imgFallbackSvg = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800"><rect width="100%" height="100%" fill="#0b1220"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#ffffff" font-size="28" font-family="Arial">image unavailable</text></svg>');

const DEFAULT_LANG = "fr";
let currentLang = DEFAULT_LANG;

const I18N = {
  fr: {
    "header.logo": "danswholesaleplants",
    "nav.home": "Accueil",
    "nav.services": "Services",
    "nav.about": "À propos",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "nav.toggle": "Menu",
    "nav.toggleAria": "Basculer la navigation principale",
    "nav.ariaLabel": "Navigation principale",
    "lang.label": "Sélection de langue",
    "lang.ariaLabel": "Changer de langue",
    "lang.fr": "Français",
    "lang.en": "English",
    "footer.brand": "danswholesaleplants",
    "footer.tagline": "Systèmes d’orientation spatiale et signalétique numérique pour des environnements publics lisibles et inclusifs.",
    "footer.contactTitle": "Coordonnées",
    "footer.phone": "Téléphone : +32 2 318 45 72",
    "footer.email": "Courriel : info@danswholesaleplants.com",
    "footer.address": "Boulevard Anspach 65, 1000 Bruxelles, Belgique",
    "footer.legalTitle": "Cadre éditorial",
    "footer.terms": "Conditions d’utilisation",
    "footer.privacy": "Politique de confidentialité",
    "footer.cookies": "Politique relative aux cookies",
    "footer.refund": "Politique de révision",
    "footer.disclaimer": "Clause de non-responsabilité",
    "footer.cookieManage": "Gérer les cookies",
    "footer.copy": "© {{year}} danswholesaleplants. Tous droits réservés.",
    "toast.form.sent": "Message envoyé. Nous reviendrons vers vous prochainement.",
    "toast.cookie.accepted": "Préférences mises à jour : tous les cookies sont activés.",
    "toast.cookie.declined": "Préférences mises à jour : cookies optionnels désactivés.",
    "toast.cookie.saved": "Préférences de cookies enregistrées.",
    "cookies.banner.title": "Gestion des cookies",
    "cookies.banner.body": "Nous utilisons des cookies pour améliorer la lisibilité de nos contenus et mesurer l’engagement des parcours. Vous pouvez personnaliser chaque catégorie.",
    "cookies.banner.link": "Consulter la politique relative aux cookies",
    "cookies.banner.accept": "Tout accepter",
    "cookies.banner.decline": "Tout refuser",
    "cookies.banner.save": "Enregistrer les préférences",
    "cookies.preferences.necessary.title": "Essentiels",
    "cookies.preferences.necessary.desc": "Garantissent la sécurité, la gestion de session et le fonctionnement de la langue. Toujours actifs.",
    "cookies.preferences.preferences.title": "Préférences",
    "cookies.preferences.preferences.desc": "Sauvegardent vos choix d’affichage comme les cartes interactives et les sections épinglées.",
    "cookies.preferences.analytics.title": "Analyse",
    "cookies.preferences.analytics.desc": "Mesurent la compréhension des plans et la navigation pour améliorer l’UX spatiale.",
    "cookies.preferences.marketing.title": "Diffusion",
    "cookies.preferences.marketing.desc": "Contrôlent la mise en avant de contenus pertinents dans nos bulletins d’information.",
    "meta.index.title": "danswholesaleplants — Orientation spatiale et signalétique numérique",
    "meta.index.description": "Explorations et analyses dédiées à l’orientation spatiale, la signalétique numérique et la navigation intérieure dans les environnements publics complexes.",
    "home.hero.eyebrow": "ORIENTATION SPATIALE",
    "home.hero.title": "Concevoir des repères digitaux pour des espaces publics intelligibles",
    "home.hero.subtitle": "Nous articulons signalétique numérique, plans interactifs et guidage visuel afin de structurer des parcours utilisateurs dans des bâtiments et infrastructures publiques à fortes contraintes.",
    "home.hero.ctaPrimary": "Explorer les axes de travail",
    "home.hero.ctaSecondary": "Prendre contact",
    "home.hero.imageAlt": "Collaborateurs analysant un plan interactif d’orientation",
    "home.featured.heading": "Synthèses spatiales prioritaires",
    "home.featured.intro": "Trois champs d’observation nourrissent nos missions : analyse des flux, narration cartographique et gouvernance des données spatiales.",
    "home.featured.card1.title": "Cartographie sensible des usages",
    "home.featured.card1.text": "Combiner mesures quantitatives et récits d’usagers pour repérer les zones qui requièrent une signalétique hybride ou des compléments d’information contextuelle.",
    "home.featured.card1.alt": "Plans et annotations autour d’un espace public",
    "home.featured.card2.title": "Design informationnel modulaire",
    "home.featured.card2.text": "Construire des composants de guidage adaptables aux saisons, travaux ou reprogrammations, tout en assurant la lisibilité des transitions entre intérieur et extérieur.",
    "home.featured.card2.alt": "Signalétique numérique affichant des directions modulaires",
    "home.featured.card3.title": "Gouvernance continue des parcours",
    "home.featured.card3.text": "Mettre en place des rituels de pilotage pour monitorer les performances de l’UX spatiale, actualiser les plans interactifs et partager les données entre équipes.",
    "home.featured.card3.alt": "Équipe travaillant sur un tableau de bord de circulation",
    "home.pillars.heading": "Piliers méthodologiques",
    "home.pillars.intro": "Chaque intervention s’ancre dans trois dimensions complémentaires afin d’anticiper les mutations d’un environnement bâti complexe.",
    "home.pillars.card1.title": "Lecture des flux",
    "home.pillars.card1.text": "Observer la mobilité piétonne, comprendre les vitesses d’avancement et déceler les barrières cognitives qui freinent la navigation.",
    "home.pillars.card1.point1": "Traces multi-sources analysées en continu",
    "home.pillars.card1.point2": "Scénarios de fréquentation par typologie d’usagers",
    "home.pillars.card2.title": "Structures narratives",
    "home.pillars.card2.text": "Construire des histoires spatiales cohérentes, du macro plan directeur aux repères situés sur site ou sur écran.",
    "home.pillars.card2.point1": "Itinéraires thématiques et cartographies tactiles",
    "home.pillars.card2.point2": "Scripteurs éditoriaux dédiés aux parcours",
    "home.pillars.card3.title": "Organisations apprenantes",
    "home.pillars.card3.text": "Installer une gouvernance partagée entre services techniques, médiation et accueil pour maintenir les dispositifs.",
    "home.pillars.card3.point1": "Tableaux de bord sur mesure",
    "home.pillars.card3.point2": "Guides opérationnels pour mises à jour rapides",
    "home.recommendations.heading": "Recommandations clés",
    "home.recommendations.intro": "Nos études aboutissent à des recommandations opérationnelles adaptées aux phases de transformation d’un site.",
    "home.recommendations.item1": "Prioriser les points d’inflexion où se croisent flux de circulation, attentes pédagogiques et contraintes de sécurité.",
    "home.recommendations.item2": "Associer expériences numériques et repères architecturaux existants pour ne pas fragmenter la mémoire du lieu.",
    "home.recommendations.item3": "Documenter chaque évolution de plan pour constituer un patrimoine cartographique transmissible.",
    "home.recommendations.item4": "Tester l’accessibilité avec différents profils et itérer tant que la compréhension n’est pas spontanée.",
    "home.testimonials.heading": "Témoignages",
    "home.testimonials.intro": "Institutions publiques et consortiums urbains partagent leur retour sur les collaborations de recherche-action.",
    "home.testimonials.quote1": "« Les ateliers de cartographie narrative ont transformé notre compréhension des déplacements piétons. Les plans interactifs restent pertinents malgré le chantier en cours. »",
    "home.testimonials.name1": "Sophie Maréchal",
    "home.testimonials.role1": "Coordinatrice mobilité, pôle muséal métropolitain",
    "home.testimonials.quote2": "« La gouvernance éditoriale proposée simplifie la mise à jour des contenus signalétiques sur trois langues sans surcharge pour nos équipes. »",
    "home.testimonials.name2": "Laurent De Wilde",
    "home.testimonials.role2": "Responsable information voyageurs, réseau de transport régional",
    "home.testimonials.quote3": "« Les simulations de flux nocturnes ont permis d’intégrer des repères lumineux précis tout en respectant les contraintes architecturales patrimoniales. »",
    "home.testimonials.name3": "Nabila Cherfi",
    "home.testimonials.role3": "Directrice technique, campus pédagogique urbain",
    "home.blog.heading": "Explorations récentes",
    "home.blog.intro": "Nos articles détaillent des méthodes appliquées à des environnements complexes, illustrées par des études de cas et jeux de données.",
    "home.blog.readMore": "Lire l’analyse",
    "home.blog.allPosts": "Voir tous les articles",
    "services.hero.eyebrow": "SERVICES",
    "services.hero.title": "Cinq volets pour structurer vos stratégies d’orientation",
    "services.hero.subtitle": "Nous accompagnons les acteurs publics dans l’analyse, la conception et l’évaluation de systèmes d’orientation spatiale adaptés aux environnements multi-usages.",
    "services.hero.imageAlt": "Réunion de travail autour d’un plan numérique",
    "services.list.heading": "Volets d’intervention",
    "services.list.intro": "Chaque service se déploie selon un protocole documenté, articulant diagnostic qualitatif, modélisation quantitative et accompagnement opérationnel.",
    "services.service1.title": "Audit d’orientation spatiale",
    "services.service1.text": "Diagnostic complet des conditions d’accès, de lisibilité et d’appropriation des lieux publics à partir d’observations et de données partagées.",
    "services.service1.point1": "Cartographie des points de friction et opportunités",
    "services.service1.point2": "Recommandations priorisées et scénarios temporels",
    "services.service2.title": "Design de signalétique numérique",
    "services.service2.text": "Déploiement de supports digitaux, plans interactifs et contenus contextuels pour guider les publics à chaque étape du parcours.",
    "services.service2.point1": "Guides éditoriaux multilingues",
    "services.service2.point2": "Matrices de contenus adaptables aux événements",
    "services.service3.title": "Plans interactifs et modélisation",
    "services.service3.text": "Production de plans dynamiques intégrant données temps réel, contraintes d’accessibilité et variations de flux.",
    "services.service3.point1": "Intégration d’hyperliens contextualisés",
    "services.service3.point2": "Interfaces accessibles sur kiosques et mobile",
    "services.service4.title": "Parcours utilisateurs et UX spatiale",
    "services.service4.text": "Analyse des usages, co-design des parcours et tests d’expérience à partir de prototypes fonctionnels.",
    "services.service4.point1": "Cartes d’émotions et métriques de compréhension",
    "services.service4.point2": "Boucles d’amélioration continue documentées",
    "services.service5.title": "Gouvernance et accompagnement",
    "services.service5.text": "Structuration d’une gouvernance pérenne pour assurer la maintenance, la cohérence et l’évolution des systèmes de guidage.",
    "services.service5.point1": "Rituels de coordination interservices",
    "services.service5.point2": "Tableaux de bord et indicateurs partagés",
    "services.method.heading": "Méthodologie type",
    "services.method.intro": "Nos missions suivent un fil conducteur modulable en fonction de la maturité du site et de la disponibilité des données.",
    "services.method.step1": "1. Immersion sur site : observations, entretiens et récolte de documents existants.",
    "services.method.step2": "2. Synthèse cartographique : segmentation des espaces, formalisation des flux et détection des conflits d’usage.",
    "services.method.step3": "3. Prototypage : scénarios graphiques, prototypes numériques et tests utilisateurs ciblés.",
    "services.method.step4": "4. Déploiement : guide opérationnel, gouvernance, transfert de compétences et indicateurs de suivi.",
    "services.deliverables.heading": "Livrables",
    "services.deliverables.intro": "Les livrables s’adaptent aux calendriers et aux ressources des équipes internes.",
    "services.deliverables.point1": "Dossiers cartographiques annotés et versionnés",
    "services.deliverables.point2": "Bibliothèques de composants de signalétique",
    "services.deliverables.point3": "Scripts de gouvernance et matrices de décision",
    "services.deliverables.point4": "Sessions de transfert et documentation opérationnelle",
    "about.hero.eyebrow": "APPROCHE",
    "about.hero.title": "Une équipe dédiée aux environnements publics complexes",
    "about.hero.subtitle": "Nous combinons urbanisme, design informationnel et ingénierie de données pour accompagner les transformations spatiales.",
    "about.hero.imageAlt": "Vue d’un atelier collaboratif de cartographie",
    "about.mission.heading": "Mission",
    "about.mission.intro": "Partager des méthodes robustes pour rendre lisibles des lieux soumis à de fortes contraintes, en plaçant l’accessibilité au centre.",
    "about.mission.point1": "Ancrer les dispositifs dans la réalité opérationnelle des sites",
    "about.mission.point2": "Faciliter les coopérations entre métiers techniques et publics",
    "about.mission.point3": "Documenter chaque étape pour garantir la réplicabilité",
    "about.values.heading": "Valeurs",
    "about.values.intro": "Nos interventions reposent sur des principes qui garantissent consistence et transparence.",
    "about.values.card1.title": "Clarté",
    "about.values.card1.text": "Rendre compréhensibles données et décisions afin que chaque acteur puisse s’approprier les trajectoires spatiales.",
    "about.values.card2.title": "Écoute",
    "about.values.card2.text": "Multiplier les formats d’échange pour capter les perceptions des usagers et transformer ces récits en indicateurs actionnables.",
    "about.values.card3.title": "Pérennité",
    "about.values.card3.text": "Concevoir des outils maintenables, alignés sur les ressources internes et capables d’évoluer sans rupture.",
    "about.timeline.heading": "Repères",
    "about.timeline.intro": "Quelques jalons illustrent notre progression et les expérimentations menées.",
    "about.timeline.step1": "2016 — Lancement du laboratoire d’orientation spatiale et premières cartographies sensibles dans des bibliothèques urbaines.",
    "about.timeline.step2": "2018 — Création d’un référentiel de signalétique numérique pour des campus multi-sites.",
    "about.timeline.step3": "2020 — Déploiement d’une suite d’outils de navigation intérieure pour un réseau culturel intercommunal.",
    "about.timeline.step4": "2023 — Publication de guides de gouvernance et d’indicateurs partagés pour des consortiums publics.",
    "about.team.heading": "Équipe",
    "about.team.intro": "Une équipe pluridisciplinaire réunissant design stratégique, cartographie et sciences sociales.",
    "about.team.member1.name": "Diane Smet",
    "about.team.member1.role": "Directrice de recherche",
    "about.team.member1.bio": "Urbaniste de formation, elle coordonne les immersions terrain et veille à l’alignement des scénarios de mobilité avec les objectifs politiques.",
    "about.team.member1.alt": "Portrait de Diane Smet",
    "about.team.member2.name": "Jonas Dervaux",
    "about.team.member2.role": "Designer informationnel",
    "about.team.member2.bio": "Spécialiste des plans interactifs, il construit les bibliothèques graphiques et supervise les tests de lisibilité multi-supports.",
    "about.team.member2.alt": "Portrait de Jonas Dervaux",
    "about.team.member3.name": "Leïla Rahmani",
    "about.team.member3.role": "Analyste UX spatiale",
    "about.team.member3.bio": "Elle pilote les protocoles d’enquête, structure les jeux de données et conçoit les tableaux de bord de suivi pour les équipes internes.",
    "about.team.member3.alt": "Portrait de Leïla Rahmani",
    "blog.hero.eyebrow": "BLOG",
    "blog.hero.title": "Analyses approfondies de l’UX spatiale",
    "blog.hero.subtitle": "Études de cas, retours d’expérience et protocoles reproductibles autour de la signalétique numérique et de la navigation intérieure.",
    "blog.list.intro": "Retrouvez ci-dessous nos publications les plus récentes. Chaque article propose des ressources actionnables et des indicateurs mesurables.",
    "blog.backLink": "Revenir aux articles",
    "post1.meta": "22 avril 2024 · 11 min de lecture",
    "post1.excerpt": "Comment structurer une narration spatiale multi-couches pour un campus urbain, en reliant cartographie sensible, signalétique numérique et gouvernance continue des contenus.",
    "post1.title": "Construire une narration spatiale stratifiée pour un campus urbain",
    "post1.heroAlt": "Visiteur consultant une interface de navigation sur un campus urbain",
    "post1.intro": "Les campus urbains mêlent institutions culturelles, intersections de transport, laboratoires et places publiques. Chaque strate attire des publics aux attentes distinctes, tous dépendants d’une orientation spatiale claire malgré les mutations permanentes. Notre approche de la signalétique numérique considère le campus comme un jeu de données vivant où qualités architecturales, rythmes temporels et perceptions piétonnes sont synchronisés. Plutôt que produire des panneaux statiques, nous orchestrons la navigation intérieure sur plusieurs médias pour que visiteurs, équipes et partenaires saisissent en temps réel la chorégraphie du lieu.",
    "post1.section1.heading": "Cartographier les conditions opérationnelles",
    "post1.section1.p1": "Nous commençons par élaborer une cartographie des espaces multi-échelles mêlant relevés, journaux de maintenance et observations. Les traces issues de capteurs révèlent les flux de circulation en périodes d’affluence ou de creux, tandis que les entretiens dévoilent les cartes mentales des résidents. Ces apports nourrissent des storyboards géolocalisés décrivant lumière, acoustique et seuils d’accessibilité. Le jeu de données obtenu indique où la signalétique numérique doit s’adapter, où les repères analogiques suffisent, et où des dispositifs hybrides facilitent la transition intérieur-extérieur.",
    "post1.section1.p2": "Nous étiquetons ensuite chaque nœud spatial selon son rôle expérientiel : ancre, portail, connecteur, pause, exploration. Pour chaque rôle nous évaluons la lisibilité via contrastes, temps de séjour et angles de visibilité. Les contraintes architecturales et d’infrastructure publique sont documentées en parallèle des ressentis d’usagers recueillis par carnets de bord. Cette triangulation évite les angles morts qui apparaissent lorsqu’on s’appuie uniquement sur les plans techniques. Ainsi, la phase de cartographie formule des hypothèses d’amélioration de l’UX spatiale avant tout prototype.",
    "post1.section1.p3": "La même cartographie met en lumière des dépendances fonctionnelles telles que corridors techniques, issues d’urgence ou périmètres de travaux. Ces superpositions garantissent que les engagements en matière d’accessibilité restent respectés lorsque le site évolue. Nous observons comment la mobilité piétonne cohabite avec les micromobilités et les véhicules de service pour dessiner des zones tampons. Chaque diagramme s’accompagne de notes de gouvernance afin que les équipes futures ajustent les hypothèses sans repartir de zéro, limitant les désalignements lors des sprints de conception.",
    "post1.section2.heading": "Piloter des expérimentations numériques",
    "post1.section2.p1": "Une fois la base validée, nous déployons des pilotes numériques qui rejouent des parcours réels. Plans interactifs, kiosques, signalétique lumineuse et projections dynamiques sont synchronisés. Chaque pilote cible un scénario prioritaire : accueillir des chercheurs invités, guider des classes en visite ou orienter les équipes de maintenance la nuit. Nous observons plusieurs contextes météorologiques pour tester la lisibilité sous soleil, pluie ou obscurité hivernale. Les interactions tactiles et trajectoires captées affinent icônes et sémantiques.",
    "post1.section2.p2": "Parce que les environnements complexes refusent les solutions uniformes, nous concevons des modules combinables : parcours colorés, repères lumineux et notifications contextuelles s’assemblent selon la typologie des bâtiments. Les pilotes permettent aux parties prenantes d’éprouver le design informationnel lorsque le bruit augmente ou que la densité se resserre. Les boucles de retour incluent micro-enquêtes, vidéos commentées et ateliers de co-design. L’effort se concentre sur la traduction des parcours utilisateurs en ajustements tangibles plutôt que sur la livraison d’un artefact final.",
    "post1.section2.p3": "Durant ces pilotes, nous maintenons un journal de modifications qui consigne chaque réglage. Ce registre retrace l’évolution de la cartographie des espaces lorsque les priorités changent, qu’il s’agisse d’expositions temporaires ou d’ajustements réglementaires. En reliant chaque évolution à un résultat mesurable — détour réduit, attente fluidifiée, meilleures compréhensions multilingues — nous renforçons la confiance dans l’itération. Cette transparence incite les services à partager leurs flux de données, enrichissant les plans interactifs.",
    "post1.section3.heading": "Instaurer une gouvernance continue",
    "post1.section3.p1": "Une stratégie d’UX spatiale n’est efficace que si la gouvernance tient dans la durée. Nous aidons les institutions à produire des chartes de stewardship qui précisent qui surveille le guidage visuel, qui édite les contenus et comment les mises à jour circulent. Des modules de formation permettent aux équipes d’ajuster les plans interactifs sans assistance externe. Des tableaux de bord signalent les anomalies, par exemple lorsqu’un écran perd la synchronisation avec les informations opérationnelles.",
    "post1.section3.p2": "Nous définissons aussi des protocoles d’escalade mêlant observation qualitative et analyses de capteurs. Si un corridor provoque régulièrement des hésitations, une alerte est adressée pour vérifier éclairage, acoustique et messages. Les comités accessibilité examinent ces signaux afin de maintenir les engagements inclusifs. Lorsqu’un nouveau bâtiment émerge, le guide de gouvernance impose que les standards d’orientation spatiale soient intégrés au cahier des charges, prolongeant la narration existante.",
    "post1.section3.p3": "Enfin, nous planifions des cycles d’évaluation calés sur le calendrier académique et la programmation culturelle. Les saisons animées déploient des messages spécifiques, tandis que les périodes calmes testent des repères augmentés. Ces rendez-vous ravivent l’appropriation collective et réduisent les fractures entre couches physiques et numériques. Avec une gouvernance ancrée, le campus évolue harmonieusement et les publics continuent d’expérimenter une cartographie cohérente.",
    "post1.conclusion": "Les campus urbains prospèrent grâce à la curiosité, la collaboration et l’adaptation. Considérer la signalétique numérique comme un cadre vivant garantit que chaque évolution renforce la confiance spatiale. Notre méthodologie associe données, récit et design pour maintenir une orientation claire, même lorsque l’environnement gagne en complexité. Le résultat est un écosystème de navigation résilient qui garde les espaces publics hospitaliers sur le long terme.",
    "post2.meta": "8 mai 2024 · 10 min de lecture",
    "post2.excerpt": "Déployer une signalétique numérique séquencée dans une plateforme de transport multimodale en coordonnant flux piétons, jalonnement urbain et interfaces de mobilité partagée.",
    "post2.title": "Orchestrer la signalétique numérique d’un pôle de transport multimodal",
    "post2.heroAlt": "Hall de transport avec signalétique numérique synchronisée",
    "post2.intro": "Les pôles multimodaux réunissent trains, tramways, lignes de bus, vélo-partage et services urbains. La densité de connexions exige une signalétique numérique capable de guider des publics variés sans surcharge cognitive. Notre approche s’attache à clarifier les séquences de déplacement, à révéler les dépendances logistiques et à harmoniser l’expérience entre l’espace public extérieur et l’espace intérieur. L’objectif : offrir une orientation spatiale cohérente, quel que soit le point d’entrée ou le mode utilisé.",
    "post2.section1.heading": "Analyser les séquences de déplacement",
    "post2.section1.p1": "Nous démarrons par une observation détaillée des flux de circulation sur plusieurs cycles quotidiens et hebdomadaires. Les trajectoires piétonnes, les transferts intermodaux et les zones d’attente sont cartographiés. Nous identifions les ruptures de rythme, les zones d’accumulation et les moments où l’information est recherchée. Cette lecture fine met en évidence les segments nécessitant une signalétique numérique renforcée et ceux où un marquage discret suffit.",
    "post2.section1.p2": "À partir de ces observations, nous construisons un atlas des parcours utilisateurs. Chaque parcours est décliné selon différents profils : voyageur occasionnel, usager quotidien, personne accompagnant un groupe, visiteur touristique. Nous notons les émotions, les points de stress, les besoins d’accessibilité. Ces données alimentent des scripts qui déterminent la hiérarchie de l’information, l’ordre des messages et les points de bascule entre canaux analogiques et numériques.",
    "post2.section1.p3": "Nous associons ensuite les équipes d’exploitation afin de comprendre les contraintes opérationnelles : gestion des incidents, maintenance nocturne, régulation des flux en période d’événements. Les informations collectées permettent de définir des scénarios de surcharge et des plans de contingence. Ainsi, la signalétique numérique peut basculer vers des messages de régulation, des annonces d’itinéraires alternatifs ou des consignes de sécurité avec un langage homogène.",
    "post2.section2.heading": "Structurer des supports synchronisés",
    "post2.section2.p1": "La conception des supports numériques se fait par couches. Des totems d’accueil proposent une vision globale du site, des écrans contextuels jalonnent les transferts, et des repères lumineux assistent la navigation de nuit. Cette hiérarchie est couplée à des déclencheurs basés sur les flux détectés. Les contenus se réorganisent pour orienter les voyageurs vers les accès les moins saturés, ou pour accompagner les personnes à mobilité réduite vers des ascenseurs disponibles.",
    "post2.section2.p2": "Nous accordons une attention particulière à la lisibilité multilingue. Une charte graphique précise les codes couleur, les typographies et les pictogrammes utilisés sur chaque support. Les plans interactifs proposent des filtres selon le mode de transport, la durée de correspondance ou le niveau sonore souhaité. Les contenus audio sont synchronisés avec les visuels afin de maintenir une cohérence sensorielle.",
    "post2.section2.p3": "Pour garantir la résilience du dispositif, nous mettons en place des interfaces d’administration modulaires. Les équipes internes peuvent ajuster les messages, programmer des campagnes thématiques ou désactiver temporairement des éléments. Des scripts de vérification vérifient l’alignement entre les données temps réel et l’affichage. En cas de décalage, une alerte est déclenchée pour prévenir les opérateurs.",
    "post2.section3.heading": "Ancrer la gouvernance dans le territoire",
    "post2.section3.p1": "Une signalétique multimodale n’est efficace que si elle s’inscrit dans le territoire qui l’entoure. Nous travaillons avec les services urbains pour aligner les informations diffusées dans la gare et celles présentes dans l’espace public. Les plans de quartier, les itinéraires piétons vers des équipements, les cartes des mobilités douces sont intégrés de manière cohérente. Cette continuité encourage les usagers à prolonger leurs trajets hors du hub sans perdre leurs repères.",
    "post2.section3.p2": "Nous instaurons des points de coordination réguliers entre exploitants de transport, services municipaux et acteurs économiques. Ces rencontres permettent d’anticiper les grands événements, les travaux, les changements d’offre et les variations saisonnières. La signalétique numérique devient alors un canal de dialogue qui reflète la dynamique du territoire plutôt qu’un simple affichage centralisé.",
    "post2.section3.p3": "Enfin, nous évaluons l’efficacité du dispositif à travers des indicateurs partagés : temps de correspondance, taux de satisfaction, niveaux de saturation. Les résultats sont comparés à des scénarios de référence pour identifier les pistes d’amélioration. Les enseignements sont ensuite capitalisés pour d’autres sites, permettant une montée en compétence collective.",
    "post2.conclusion": "En orchestrant la signalétique numérique d’un pôle multimodal autour de séquences claires, de supports synchronisés et d’une gouvernance territoriale, nous construisons une expérience fluide pour chaque usager. L’orientation spatiale devient un service public à part entière, capable d’évoluer en fonction des besoins et des événements.",
    "post3.meta": "21 mai 2024 · 10 min de lecture",
    "post3.excerpt": "Mesurer la performance d’un guidage visuel dans un quartier culturel dense, en combinant observations in situ, indicateurs sensoriels et gouvernance partagée.",
    "post3.title": "Mesurer l’impact d’un guidage visuel dans un quartier culturel",
    "post3.heroAlt": "Passerelle piétonne avec repères lumineux et signalétique culturelle",
    "post3.intro": "Les quartiers culturels concentrent musées, salles de spectacle, bibliothèques et espaces publics. Leur attractivité repose sur la capacité à accueillir des publics hétérogènes tout en préservant la fluidité des déplacements. Déployer un guidage visuel dans un tel contexte demande de conjuguer exigences patrimoniales, contraintes opérationnelles et diversité des usages. Voici comment nous mesurons et consolidons une stratégie de signalétique adaptée.",
    "post3.section1.heading": "Définir les métriques de lecture",
    "post3.section1.p1": "Nous commençons par établir une grille de lecture mêlant indicateurs quantitatifs et qualitatifs. Le temps nécessaire pour trouver une entrée, l’aisance à franchir un carrefour, la compréhension des contenus éditoriaux sont évalués. Nous analysons les traces de déplacement et les plans mentaux collectés lors d’entretiens. Ces éléments révèlent les zones qui génèrent des hésitations.",
    "post3.section1.p2": "Nous cartographions ensuite les stimuli sensoriels : intensité lumineuse, ambiance sonore, densité de foule. Ces paramètres influencent la lisibilité du guidage. Un repère lumineux efficace de jour peut devenir agressif de nuit ; une palette couleur harmonieuse peut se dissoudre dans un environnement très contrasté. Nos relevés permettent d’ajuster les dispositifs pour chaque période.",
    "post3.section1.p3": "Enfin, nous évaluons les interactions entre dispositifs analogiques et numériques. Les bâtiments patrimoniaux imposent des contraintes d’intégration. Nous travaillons avec les architectes pour imaginer des supports réversibles, capables de dialoguer avec le bâti sans le dénaturer. Chaque adaptation est documentée pour faciliter les futures évolutions.",
    "post3.section2.heading": "Organiser la médiation territoriale",
    "post3.section2.p1": "Le quartier culturel est un écosystème multi-acteurs. Nous installons des ateliers de médiation qui réunissent institutions, commerçants, riverains, artistes. Ensemble, nous définissons les priorités, les messages essentiels, les langues d’usage. Les retours nourrissent une base de connaissances partagée.",
    "post3.section2.p2": "Nous bâtissons un calendrier éditorial synchronisé avec la programmation culturelle. Les messages diffusés sur la signalétique numérique s’adaptent aux événements, aux festivals, aux nocturnes. Les contenus éditoriaux mettent en avant des récits de quartier pour renforcer l’appropriation. La signalétique devient un média qui prolonge l’expérience culturelle.",
    "post3.section2.p3": "Pour assurer la cohérence, nous développons des outils de gouvernance : tableaux de bord, check-lists de maintenance, procédures d’urgence. Chaque acteur sait comment mettre à jour un contenu, signaler un dysfonctionnement ou demander une adaptation. Cette clarté renforce la résilience collective.",
    "post3.section3.heading": "Capitaliser et transmettre",
    "post3.section3.p1": "L’évaluation ne s’arrête pas aux indicateurs chiffrés. Nous réalisons des carnets de parcours qui racontent l’expérience sur plusieurs saisons. Ces récits illustrent les évolutions du quartier, les adaptations réalisées, les nouveaux publics accueillis.",
    "post3.section3.p2": "Nous produisons également des guides de transfert pour accompagner les équipes internes. Ils décrivent les structures de données, les workflows éditoriaux, les attentes en matière d’accessibilité. Les nouveaux collaborateurs disposent d’une feuille de route claire.",
    "post3.section3.p3": "Enfin, nous partageons les enseignements avec d’autres territoires culturels. Ateliers, publications et conférences permettent de diffuser des pratiques éprouvées et de bénéficier de retours croisés. Le guidage visuel devient un bien commun en constante évolution.",
    "post3.conclusion": "Mesurer l’impact d’un guidage visuel dans un quartier culturel, c’est conjuguer rigueur méthodologique, écoute des usagers et gouvernance partagée. Grâce à cette approche, les publics trouvent leur chemin, les institutions coordonnent leurs actions et le territoire gagne en lisibilité.",
    "post4.meta": "4 juin 2024 · 9 min de lecture",
    "post4.excerpt": "Concevoir un guidage vocal et visuel pour un réseau de bibliothèques, en s’appuyant sur des interfaces accessibles, des repères physiques et une gouvernance documentaire.",
    "post4.title": "Guidage vocal augmenté pour un réseau de bibliothèques publiques",
    "post4.heroAlt": "Utilisateur consultant une borne vocale dans une bibliothèque",
    "post4.intro": "Les bibliothèques publiques combinent collections physiques, espaces d’étude, services numériques et événements. Les usagers ont des besoins variés : trouver rapidement un rayon, s’orienter vers une salle de travail, repérer une exposition. Nous avons conçu un dispositif de guidage vocal augmenté qui articule signalétique numérique, repères physiques et accompagnement humain.",
    "post4.section1.heading": "Écouter les usages et modéliser les besoins",
    "post4.section1.p1": "Nous avons mené des entretiens avec lecteurs, équipes documentaires, médiateurs. Les attentes diffèrent selon l’expérience : un habitué cherche l’efficacité, un nouvel usager souhaite explorer. Nous avons cartographié les flux par typologie de visite, analysé les zones de confusion et les moments de forte affluence.",
    "post4.section1.p2": "Un audit acoustique a identifié les espaces où un guidage vocal était pertinent sans perturber la quiétude du lieu. Certaines zones nécessitent des messages informatifs, d’autres se prêtent mieux à des signaux lumineux. Nous avons également évalué la compatibilité avec les outils existants : catalogues, applications, dispositifs d’accessibilité.",
    "post4.section1.p3": "Enfin, nous avons défini un lexique partagé, simple et précis. Les annonces vocales utilisent des phrases courtes, des repères spatiaux explicites et des indications d’orientation claires. Cette base linguistique garantit la cohérence entre supports.",
    "post4.section2.heading": "Prototyper des parcours augmentés",
    "post4.section2.p1": "Nous avons développé des bornes vocales connectées à des plans interactifs. L’usager choisit son parcours : consulter une salle, rejoindre un service, découvrir un contenu. La borne fournit des instructions vocales et visuelles synchronisées, qui s’adaptent à la progression du lecteur grâce à des balises discrètes.",
    "post4.section2.p2": "Les repères physiques ont été renforcés : totems lumineux, pictogrammes tactiles, repères colorés. Chaque élément répond à une logique narrative. Les contenus numériques renvoient vers des ressources complémentaires pour prolonger la visite. Les prototypages ont été testés lors de sessions réunissant différents profils d’usagers.",
    "post4.section2.p3": "Nous avons intégré des modules d’accessibilité : réglages du volume, sous-titrage dynamique, traduction en langue des signes via avatars, contraste élevé. Les retours ont permis d’améliorer la qualité de la voix de synthèse et la fluidité des dialogues.",
    "post4.section3.heading": "Structurer la gouvernance documentaire",
    "post4.section3.p1": "Le guidage vocal nécessite une gouvernance rigoureuse. Nous avons créé un comité éditorial qui gère les contenus, définit les mises à jour et valide les scripts audio. Des procédures décrivent comment ajouter un nouveau service, modifier un parcours, intégrer un événement temporaire.",
    "post4.section3.p2": "Des tableaux de bord suivent l’utilisation des bornes et la satisfaction des usagers. Les données alimentent des boucles d’amélioration continue : ajustement des messages, optimisation des repères lumineux, enrichissement des contenus.",
    "post4.section3.p3": "Enfin, nous avons formé les équipes internes pour qu’elles se sentent à l’aise avec le dispositif. Des ateliers pratiques et des guides illustrés facilitent la prise en main. Le guidage vocal devient ainsi un service pérenne, en phase avec l’évolution des bibliothèques.",
    "post4.conclusion": "Un guidage vocal augmenté, conçu avec soin, renforce l’accessibilité et l’attractivité des bibliothèques publiques. En associant écoute, prototypage et gouvernance, le dispositif s’adapte aux usages et devient un vecteur de médiation.",
    "post5.meta": "18 juin 2024 · 9 min de lecture",
    "post5.excerpt": "Maintenir une base d’UX spatiale dans un quartier patrimonial en conciliant conservation, flux touristiques et besoins quotidiens des habitants.",
    "post5.title": "Maintenir une UX spatiale durable dans un district patrimonial",
    "post5.heroAlt": "Rue patrimoniale avec balisage discret et affichage numérique",
    "post5.intro": "Les quartiers patrimoniaux attirent visiteurs et riverains. Ils doivent protéger leur identité tout en restant accessibles. Maintenir une UX spatiale durable oblige à concilier conservation, flux touristiques, logistique locale et besoins des habitants. Nous partageons ici notre démarche.",
    "post5.section1.heading": "Identifier les tensions d’usage",
    "post5.section1.p1": "Nous procédons à des observations saisonnières pour comprendre les variations de fréquentation. Les itinéraires touristiques, les trajets quotidiens des habitants, les livraisons sont cartographiés. Les zones de saturation, les goulots d’étranglement et les espaces de repli sont identifiés.",
    "post5.section1.p2": "Nous évaluons également l’impact des contenus numériques déjà présents. Certains écrans peuvent altérer l’ambiance patrimoniale. Nous recherchons des solutions discrètes : projections temporaires, dispositifs rétractables, signalétique tactile. L’objectif est de préserver la cohérence du lieu.",
    "post5.section1.p3": "Les entretiens avec artisans, commerçants, guides, habitants complètent l’analyse. Chaque acteur exprime ses attentes, ses contraintes, ses idées. Ces récits nourrissent une matrice de tensions qui oriente les choix de guidage.",
    "post5.section2.heading": "Concevoir des repères réversibles",
    "post5.section2.p1": "Les interventions sont conçues pour être réversibles. Des balises lumineuses à intensité variable, des supports amovibles, des plans pliables permettent d’adapter le guidage selon les périodes. Les matériaux et les finitions s’inspirent du patrimoine.",
    "post5.section2.p2": "Nous développons des contenus numériques accessibles via QR codes discrets ou applications dédiées. Les informations sont contextualisées : histoire des lieux, horaires, services de proximité. Les contenus audio peuvent être téléchargés pour une visite autonome.",
    "post5.section2.p3": "Des tests utilisateurs sont réalisés en collaboration avec des visiteurs occasionnels et des habitants. Les retours permettent d’ajuster la densité de l’information, le ton des messages, l’emplacement des repères. Le processus favorise l’appropriation collective.",
    "post5.section3.heading": "Ancrer la maintenance dans la durée",
    "post5.section3.p1": "Nous mettons en place une gouvernance partagée qui réunit services patrimoine, tourisme, voirie, associations locales. Un calendrier de revue des dispositifs est établi selon les saisons. Les décisions sont documentées et diffusées.",
    "post5.section3.p2": "Des indicateurs suivis régulièrement — satisfaction, flux, retours qualitatifs — permettent d’ajuster les dispositifs. Les enseignements sont capitalisés pour d’autres sites patrimoniaux.",
    "post5.section3.p3": "Enfin, nous formons les équipes locales à la maintenance. Des guides techniques et des ateliers pratiques assurent la continuité. L’UX spatiale devient un patrimoine immatériel partagé.",
    "post5.conclusion": "Maintenir une UX spatiale durable dans un district patrimonial implique une écoute fine et des dispositifs réversibles. En installant une gouvernance partagée, le quartier reste vivant, lisible et accueillant.",
    "contact.hero.eyebrow": "CONTACT",
    "contact.hero.title": "Coordonner vos projets d’orientation spatiale",
    "contact.hero.subtitle": "Expliquez-nous votre contexte : nous analysons vos besoins et partageons un premier cadrage méthodologique sans délai.",
    "contact.hero.imageAlt": "Plan de Bruxelles avec repères d’orientation",
    "contact.details.title": "Coordonnées directes",
    "contact.details.intro": "Nous travaillons depuis Bruxelles, en réseau avec des partenaires européens. Privilégiez un message détaillé pour faciliter la préparation de notre échange.",
    "contact.details.phoneLabel": "Téléphone",
    "contact.details.phoneValue": "+32 2 318 45 72",
    "contact.details.emailLabel": "Courriel",
    "contact.details.emailValue": "info@danswholesaleplants.com",
    "contact.details.addressLabel": "Adresse",
    "contact.details.addressValue": "Boulevard Anspach 65, 1000 Bruxelles, Belgique",
    "contact.details.hoursLabel": "Plages de réponse",
    "contact.details.hoursValue": "Du lundi au vendredi, 09:00 - 17:30 (heure d’Europe centrale)",
    "contact.map.title": "Cartographie du bureau",
    "contact.map.caption": "Le bureau est situé à proximité de la Bourse, accessible par tram, métro et lignes cyclables.",
    "contact.map.iframeTitle": "Carte OpenStreetMap localisant danswholesaleplants à Bruxelles",
    "contact.form.title": "Décrivez votre situation",
    "contact.form.intro": "Plus votre message est précis, plus nous pouvons préparer des pistes utiles avant la première réunion.",
    "contact.form.nameLabel": "Nom et prénom",
    "contact.form.namePlaceholder": "Votre nom complet",
    "contact.form.emailLabel": "Adresse électronique",
    "contact.form.emailPlaceholder": "nom@organisation.be",
    "contact.form.orgLabel": "Organisation",
    "contact.form.orgPlaceholder": "Institution ou service concerné",
    "contact.form.messageLabel": "Message",
    "contact.form.messagePlaceholder": "Objectifs, périmètre, échéances, état des lieux…",
    "contact.form.submit": "Envoyer",
    "contact.form.privacy": "Les informations partagées servent uniquement à préparer notre réponse. Consultez notre politique de confidentialité pour en savoir plus.",
    "faq.hero.eyebrow": "FAQ",
    "faq.hero.title": "Questions fréquentes",
    "faq.hero.subtitle": "Précisions sur notre approche, nos formats d’interventions et nos modalités de collaboration avec les acteurs publics.",
    "faq.list.intro": "Ces réponses restent génériques. Écrivez-nous pour des éléments spécifiques à votre territoire.",
    "faq.q1.question": "Intervenez-vous uniquement en Belgique ?",
    "faq.q1.answer": "Notre base est bruxelloise mais nous opérons régulièrement dans d’autres pays européens. Nous privilégions les missions où un accès régulier au site est possible.",
    "faq.q2.question": "Quelles données sont nécessaires pour démarrer ?",
    "faq.q2.answer": "Nous pouvons travailler avec des documents de base : plans, photos, rapports terrain. Si les données manquent, nous organisons rapidement un diagnostic immersif.",
    "faq.q3.question": "Comment associez-vous les équipes internes ?",
    "faq.q3.answer": "Nous constituons un comité de pilotage transversale qui suit chaque étape, partage les arbitrages et assure la continuité après notre intervention.",
    "faq.q4.question": "Quelle est la durée type d’une mission ?",
    "faq.q4.answer": "Selon la complexité du site, une mission s’étend de six semaines pour un audit ciblé à neuf mois pour un dispositif complet, gouvernance incluse.",
    "faq.q5.question": "Pouvez-vous produire des supports physiques ?",
    "faq.q5.answer": "Nous concevons des prototypes détaillés, travaillons les chartes et spécifications techniques. La production peut être confiée à des partenaires que nous coordonnons.",
    "faq.q6.question": "Quels indicateurs suivez-vous ?",
    "faq.q6.answer": "Nous monitorons la compréhension, les temps de parcours, la satisfaction qualitative et la résilience des dispositifs via des tableaux de bord.",
    "faq.q7.question": "Comment gérez-vous le multilinguisme ?",
    "faq.q7.answer": "Nous élaborons des matrices éditoriales multilingues, testées avec des publics variés pour garantir la lisibilité et la pertinence des contenus.",
    "faq.q8.question": "Proposez-vous des formations ?",
    "faq.q8.answer": "Oui, nous animons des ateliers de transfert et des formations ciblées sur la gouvernance, l’édition de contenus et l’analyse des données de parcours.",
    "terms.hero.eyebrow": "CONDITIONS",
    "terms.hero.title": "Conditions d’utilisation",
    "terms.hero.subtitle": "Ces conditions encadrent la consultation et l’usage des contenus publiés sur danswholesaleplants.com.",
    "terms.section1.title": "1. Objet",
    "terms.section1.body": "Les présentes conditions définissent les modalités selon lesquelles les utilisateurs accèdent aux contenus informatifs du site et les utilisent dans le respect de la législation belge.",
    "terms.section2.title": "2. Acceptation",
    "terms.section2.body": "En consultant le site, l’utilisateur reconnaît avoir pris connaissance des conditions et s’engage à les respecter. En cas de désaccord, la navigation doit être interrompue.",
    "terms.section3.title": "3. Évolution",
    "terms.section3.body": "Nous pouvons modifier ces conditions à tout moment. Les utilisateurs sont invités à les consulter régulièrement pour rester informés des mises à jour.",
    "terms.section4.title": "4. Accès au site",
    "terms.section4.body": "Le site est accessible 24h/24 sauf interruption pour maintenance, cas de force majeure ou décision liée à la sécurité des systèmes.",
    "terms.section5.title": "5. Propriété intellectuelle",
    "terms.section5.body": "Les contenus, graphismes et documents sont protégés par le droit d’auteur. Toute reproduction est possible sous réserve de citer la source et de respecter l’intégrité des textes.",
    "terms.section6.title": "6. Usage autorisé",
    "terms.section6.body": "Les informations peuvent être utilisées à des fins d’étude, de veille ou de documentation. Tout usage trompeur ou détourné est interdit.",
    "terms.section7.title": "7. Contributions",
    "terms.section7.body": "Lorsque des commentaires ou retours nous sont adressés, l’utilisateur garantit la véracité des informations et s’abstient de tout contenu illicite ou diffamatoire.",
    "terms.section8.title": "8. Données personnelles",
    "terms.section8.body": "Les données collectées via le formulaire de contact sont traitées selon notre politique de confidentialité, exclusivement pour répondre aux demandes reçues.",
    "terms.section9.title": "9. Liens externes",
    "terms.section9.body": "Le site peut contenir des liens vers d’autres ressources. Nous ne sommes pas responsables du contenu externe ni de ses mises à jour.",
    "terms.section10.title": "10. Responsabilité",
    "terms.section10.body": "Nous mettons tous les moyens pour offrir une information fiable, sans garantir l’absence totale d’erreurs. L’utilisateur reste responsable de l’usage qu’il en fait.",
    "terms.section11.title": "11. Sécurité",
    "terms.section11.body": "L’utilisateur s’engage à ne pas perturber le bon fonctionnement du site et à signaler toute faille potentielle en écrivant à l’adresse de contact.",
    "terms.section12.title": "12. Droit applicable",
    "terms.section12.body": "Les conditions sont régies par le droit belge. Tout litige relève de la compétence des tribunaux de Bruxelles.",
    "terms.section13.title": "13. Contact",
    "terms.section13.body": "Pour toute question relative aux conditions, une demande peut être adressée via le formulaire de contact ou à info@danswholesaleplants.com.",
    "terms.section14.title": "14. Entrée en vigueur",
    "terms.section14.body": "La présente version est en vigueur depuis le 1er mars 2024 et remplace les versions antérieures.",
    "privacy.hero.eyebrow": "CONFIDENTIALITÉ",
    "privacy.hero.title": "Politique de confidentialité",
    "privacy.hero.subtitle": "Nous détaillons ici la manière dont nous traitons les informations personnelles transmises par les utilisateurs.",
    "privacy.section1.title": "1. Responsable du traitement",
    "privacy.section1.body": "Le site est édité par danswholesaleplants, basé Boulevard Anspach 65, 1000 Bruxelles. Nous sommes responsables du traitement des données collectées via le formulaire de contact.",
    "privacy.section2.title": "2. Données collectées",
    "privacy.section2.body": "Nous recueillons les informations fournies volontairement (nom, courriel, organisation, message). Aucune donnée sensible n’est sollicitée.",
    "privacy.section3.title": "3. Finalités",
    "privacy.section3.body": "Les données servent exclusivement à analyser les demandes, préparer les échanges et assurer un suivi. Elles ne sont pas utilisées pour de la prospection automatisée.",
    "privacy.section4.title": "4. Base légale",
    "privacy.section4.body": "Le traitement est fondé sur l’intérêt légitime à répondre aux sollicitations et sur le consentement explicite de l’utilisateur.",
    "privacy.section5.title": "5. Conservation",
    "privacy.section5.body": "Les données sont conservées pendant douze mois après le dernier contact, puis effacées ou anonymisées.",
    "privacy.section6.title": "6. Destinataires",
    "privacy.section6.body": "Les informations sont destinées aux membres habilités de danswholesaleplants. Aucun transfert externe n’est réalisé sans accord préalable.",
    "privacy.section7.title": "7. Hébergement",
    "privacy.section7.body": "Le site est hébergé sur des serveurs localisés dans l’Union européenne respectant des standards de sécurité reconnus.",
    "privacy.section8.title": "8. Droits des personnes",
    "privacy.section8.body": "Vous disposez d’un droit d’accès, de rectification, d’effacement, de limitation et d’opposition. Pour exercer ces droits, contactez info@danswholesaleplants.com.",
    "privacy.section9.title": "9. Sécurité",
    "privacy.section9.body": "Nous mettons en place des mesures techniques et organisationnelles pour protéger les données contre toute perte, usage abusif ou accès non autorisé.",
    "privacy.section10.title": "10. Modifications",
    "privacy.section10.body": "Nous pouvons adapter cette politique à tout moment. Les utilisateurs seront informés via le site des mises à jour significatives.",
    "cookies.hero.eyebrow": "COOKIES",
    "cookies.hero.title": "Politique relative aux cookies",
    "cookies.hero.subtitle": "Comprendre comment nous utilisons les cookies et comment ajuster vos préférences.",
    "cookies.intro.text": "Les cookies sont de petits fichiers déposés sur votre appareil. Ils facilitent votre expérience et nous aident à améliorer la navigation. Vous pouvez accepter, refuser ou personnaliser leur usage.",
    "cookies.table.name": "Nom",
    "cookies.table.provider": "Fournisseur",
    "cookies.table.type": "Type",
    "cookies.table.purpose": "Finalité",
    "cookies.table.duration": "Durée",
    "cookies.table.row1.name": "site_lang",
    "cookies.table.row1.provider": "danswholesaleplants",
    "cookies.table.row1.type": "Essentiel",
    "cookies.table.row1.purpose": "Mémoriser la langue d’affichage choisie.",
    "cookies.table.row1.duration": "12 mois",
    "cookies.table.row2.name": "cookie_consent",
    "cookies.table.row2.provider": "danswholesaleplants",
    "cookies.table.row2.type": "Essentiel",
    "cookies.table.row2.purpose": "Sauvegarder vos préférences de cookies.",
    "cookies.table.row2.duration": "12 mois",
    "cookies.table.row3.name": "ux_preferences",
    "cookies.table.row3.provider": "danswholesaleplants",
    "cookies.table.row3.type": "Préférences",
    "cookies.table.row3.purpose": "Retenir vos sections favorites ou cartes consultées.",
    "cookies.table.row3.duration": "6 mois",
    "cookies.table.row4.name": "wayfinding_insights",
    "cookies.table.row4.provider": "danswholesaleplants",
    "cookies.table.row4.type": "Analyse",
    "cookies.table.row4.purpose": "Mesurer la consultation des ressources d’orientation.",
    "cookies.table.row4.duration": "6 mois",
    "cookies.section1.title": "Cookies essentiels",
    "cookies.section1.body": "Indispensables au fonctionnement du site, ils garantissent la gestion de session, la sécurité et la mémorisation de la langue. Ils ne peuvent pas être désactivés.",
    "cookies.section2.title": "Cookies de préférences",
    "cookies.section2.body": "Ils conservent vos choix d’affichage, par exemple les articles épinglés ou les cartes ouvertes récemment.",
    "cookies.section3.title": "Cookies d’analyse",
    "cookies.section3.body": "Ils nous aident à comprendre comment les visiteurs naviguent dans nos contenus afin d’améliorer l’UX spatiale. Ils peuvent être désactivés.",
    "cookies.section4.title": "Cookies de diffusion",
    "cookies.section4.body": "Ils servent à mesurer l’intérêt pour nos publications partagées sur nos canaux d’information. Nous ne diffusons aucun contenu commercial.",
    "cookies.manage.instructions": "Vous pouvez modifier vos préférences à tout moment via le bouton « Gérer les cookies » présent dans le pied de page.",
    "refund.hero.eyebrow": "POLITIQUE",
    "refund.hero.title": "Politique de révision",
    "refund.hero.subtitle": "Nos contenus sont informatifs. Cette politique précise comment nous traitons les demandes de correction ou de retrait.",
    "refund.section1.title": "1. Champ d’application",
    "refund.section1.body": "La politique couvre les articles, synthèses et ressources téléchargeables publiées sur le site.",
    "refund.section2.title": "2. Publication",
    "refund.section2.body": "Chaque contenu est vérifié avant publication. Nous favorisons des références croisées et citons les sources utilisées.",
    "refund.section3.title": "3. Signalement",
    "refund.section3.body": "Toute demande de correction peut être envoyée via le formulaire de contact en précisant l’URL et la nature de l’erreur constatée.",
    "refund.section4.title": "4. Analyse",
    "refund.section4.body": "Nous analysons chaque signalement sous quinze jours et revenons vers l’expéditeur pour confirmer la prise en compte.",
    "refund.section5.title": "5. Révision",
    "refund.section5.body": "Lorsque l’erreur est confirmée, nous mettons à jour le contenu en mentionnant la date de modification.",
    "refund.section6.title": "6. Retrait",
    "refund.section6.body": "Si une information ne peut être fiabilisée, nous pouvons retirer le contenu concerné. Une mention de retrait est alors affichée.",
    "refund.section7.title": "7. Conservation",
    "refund.section7.body": "Les versions précédentes sont archivées pour assurer la traçabilité des corrections importantes.",
    "refund.section8.title": "8. Responsabilités",
    "refund.section8.body": "Les contributeurs internes restent responsables de leurs textes. Les citations externes sont signalées pour respect des droits.",
    "refund.section9.title": "9. Périodicité",
    "refund.section9.body": "Un audit éditorial est réalisé annuellement pour vérifier la pertinence des publications.",
    "refund.section10.title": "10. Contact",
    "refund.section10.body": "Pour toute question relative à cette politique, contactez info@danswholesaleplants.com.",
    "disclaimer.hero.eyebrow": "AVERTISSEMENT",
    "disclaimer.hero.title": "Clause de non-responsabilité",
    "disclaimer.hero.subtitle": "Cadre d’utilisation des informations présentes sur le site.",
    "disclaimer.section1.title": "Informations générales",
    "disclaimer.section1.body": "Le site propose des analyses et retours d’expérience. Ils ne constituent pas un avis juridique, financier ou technique exhaustif.",
    "disclaimer.section2.title": "Exactitude",
    "disclaimer.section2.body": "Nous veillons à la qualité des informations sans garantir leur complétude. Il appartient aux utilisateurs de vérifier leur adéquation à leur contexte.",
    "disclaimer.section3.title": "Responsabilité",
    "disclaimer.section3.body": "Nous ne saurions être tenus responsables des décisions prises sur la base de nos contenus. Les utilisateurs conservent l’entière maîtrise de leurs choix.",
    "disclaimer.section4.title": "Liens externes",
    "disclaimer.section4.body": "Les liens vers des sites tiers sont fournis à titre informatif. Nous n’exerçons aucun contrôle sur leur contenu.",
    "disclaimer.section5.title": "Évolutions",
    "disclaimer.section5.body": "Nous pouvons modifier nos contenus sans préavis afin de refléter l’évolution des projets ou des connaissances.",
    "disclaimer.section6.title": "Contact",
    "disclaimer.section6.body": "Pour toute question relative à cette clause, merci d’utiliser le formulaire de contact.",
    "thank.hero.eyebrow": "MERCI",
    "thank.hero.title": "Votre message a bien été envoyé",
    "thank.hero.subtitle": "Nous examinerons votre demande et reviendrons vers vous pour proposer une première séance de cadrage.",
    "thank.hero.button": "Retour à l’accueil",
    "meta.services.title": "Services d’orientation spatiale — danswholesaleplants",
    "meta.services.description": "Cinq volets pour analyser, concevoir et gouverner la signalétique numérique, la cartographie des espaces et l’UX spatiale.",
    "meta.about.title": "À propos — danswholesaleplants",
    "meta.about.description": "Découvrez notre mission, nos valeurs et notre équipe dédiée à l’orientation spatiale dans les environnements complexes.",
    "meta.blog.title": "Blog — danswholesaleplants",
    "meta.blog.description": "Analyses approfondies sur la signalétique numérique, la navigation intérieure et la cartographie des espaces publics.",
    "meta.contact.title": "Contact — danswholesaleplants",
    "meta.contact.description": "Coordonnées, carte et formulaire pour présenter votre contexte d’orientation spatiale.",
    "meta.faq.title": "FAQ — danswholesaleplants",
    "meta.faq.description": "Questions fréquentes concernant nos méthodes, périmètres d’intervention et collaborations avec les acteurs publics.",
    "meta.terms.title": "Conditions d’utilisation — danswholesaleplants",
    "meta.terms.description": "Conditions d’utilisation du site danswholesaleplants.com et cadre juridique applicable.",
    "meta.privacy.title": "Politique de confidentialité — danswholesaleplants",
    "meta.privacy.description": "Traitement des données personnelles collectées via danswholesaleplants.com.",
    "meta.cookies.title": "Politique cookies — danswholesaleplants",
    "meta.cookies.description": "Informations sur les cookies et réglages disponibles sur danswholesaleplants.com.",
    "meta.refund.title": "Politique de révision — danswholesaleplants",
    "meta.refund.description": "Procédure de correction et de retrait des contenus éditoriaux publiés.",
    "meta.disclaimer.title": "Clause de non-responsabilité — danswholesaleplants",
    "meta.disclaimer.description": "Cadre d’utilisation des informations et limites de responsabilité.",
    "meta.thankyou.title": "Merci — danswholesaleplants",
    "meta.thankyou.description": "Confirmation de réception de votre message adressé à danswholesaleplants.",
    "meta.post1.title": "Narration spatiale d’un campus urbain — danswholesaleplants",
    "meta.post1.description": "Méthodologie pour articuler cartographie, signalétique numérique et gouvernance dans un campus urbain.",
    "meta.post2.title": "Signalétique multimodale orchestrée — danswholesaleplants",
    "meta.post2.description": "Séquençage d’une signalétique numérique dans un pôle de transport multimodal.",
    "meta.post3.title": "Guidage culturel mesuré — danswholesaleplants",
    "meta.post3.description": "Évaluer un guidage visuel dans un quartier culturel dense.",
    "meta.post4.title": "Guidage vocal pour bibliothèques — danswholesaleplants",
    "meta.post4.description": "Conception d’un dispositif vocal augmenté dans un réseau de bibliothèques publiques.",
    "meta.post5.title": "UX spatiale patrimoniale durable — danswholesaleplants",
    "meta.post5.description": "Maintenir une UX spatiale dans un district patrimonial.",
    "home.blog.moreLink": "Découvrir le blog"
  },
  en: {
    "header.logo": "danswholesaleplants",
    "nav.home": "Home",
    "nav.services": "Services",
    "nav.about": "About",
    "nav.blog": "Blog",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "nav.toggle": "Menu",
    "nav.toggleAria": "Toggle primary navigation",
    "nav.ariaLabel": "Primary navigation",
    "lang.label": "Language selection",
    "lang.ariaLabel": "Change language",
    "lang.fr": "Français",
    "lang.en": "English",
    "footer.brand": "danswholesaleplants",
    "footer.tagline": "Spatial orientation systems and digital wayfinding for public environments that remain legible and inclusive.",
    "footer.contactTitle": "Contact details",
    "footer.phone": "Phone: +32 2 318 45 72",
    "footer.email": "Email: info@danswholesaleplants.com",
    "footer.address": "Boulevard Anspach 65, 1000 Brussels, Belgium",
    "footer.legalTitle": "Editorial framework",
    "footer.terms": "Terms of use",
    "footer.privacy": "Privacy policy",
    "footer.cookies": "Cookie policy",
    "footer.refund": "Revision policy",
    "footer.disclaimer": "Disclaimer",
    "footer.cookieManage": "Manage cookies",
    "footer.copy": "© {{year}} danswholesaleplants. All rights reserved.",
    "toast.form.sent": "Message sent. We will get back to you shortly.",
    "toast.cookie.accepted": "Preferences updated: all cookies enabled.",
    "toast.cookie.declined": "Preferences updated: optional cookies disabled.",
    "toast.cookie.saved": "Cookie preferences saved.",
    "cookies.banner.title": "Cookie settings",
    "cookies.banner.body": "We use cookies to improve comprehension of our content and to measure engagement with spatial journeys. You can adapt every category.",
    "cookies.banner.link": "Read the cookie policy",
    "cookies.banner.accept": "Accept all",
    "cookies.banner.decline": "Decline all",
    "cookies.banner.save": "Save preferences",
    "cookies.preferences.necessary.title": "Necessary",
    "cookies.preferences.necessary.desc": "Guarantee security, session handling, and language storage. Always active.",
    "cookies.preferences.preferences.title": "Preferences",
    "cookies.preferences.preferences.desc": "Remember your display choices such as interactive maps and pinned sections.",
    "cookies.preferences.analytics.title": "Analytics",
    "cookies.preferences.analytics.desc": "Measure how plans are understood and how navigation flows evolve to refine spatial UX.",
    "cookies.preferences.marketing.title": "Outreach",
    "cookies.preferences.marketing.desc": "Control the exposure of relevant publications within our information bulletins.",
    "meta.index.title": "danswholesaleplants — Spatial orientation and digital wayfinding",
    "meta.index.description": "Insights dedicated to spatial orientation, digital signage, and indoor navigation across complex public environments.",
    "home.hero.eyebrow": "SPATIAL ORIENTATION",
    "home.hero.title": "Designing digital cues for intelligible public spaces",
    "home.hero.subtitle": "We choreograph digital signage, interactive plans, and visual guidance to structure user journeys inside public buildings and infrastructures with demanding constraints.",
    "home.hero.ctaPrimary": "Explore focus areas",
    "home.hero.ctaSecondary": "Get in touch",
    "home.hero.imageAlt": "Colleagues reviewing an interactive wayfinding plan",
    "home.featured.heading": "Priority spatial insights",
    "home.featured.intro": "Three observation fields sustain our work: flow analytics, cartographic storytelling, and spatial data governance.",
    "home.featured.card1.title": "Sensitive mapping of uses",
    "home.featured.card1.text": "Combine quantitative measures with user narratives to detect zones requiring hybrid signage or contextual information layers.",
    "home.featured.card1.alt": "Maps and annotations around a public environment",
    "home.featured.card2.title": "Modular information design",
    "home.featured.card2.text": "Build guidance components that adapt to seasons, works, or reprogramming while preserving the clarity of indoor-outdoor transitions.",
    "home.featured.card2.alt": "Digital signage with modular directions",
    "home.featured.card3.title": "Continuous journey governance",
    "home.featured.card3.text": "Install steering rituals that monitor spatial UX performance, update interactive plans, and share data across teams.",
    "home.featured.card3.alt": "Team collaborating on a circulation dashboard",
    "home.pillars.heading": "Methodological pillars",
    "home.pillars.intro": "Every intervention rests on three complementary dimensions to anticipate the evolution of complex built environments.",
    "home.pillars.card1.title": "Reading flows",
    "home.pillars.card1.text": "Observe pedestrian mobility, comprehend pace variations, and detect cognitive barriers that slow navigation.",
    "home.pillars.card1.point1": "Multi-source traces analysed continuously",
    "home.pillars.card1.point2": "Visitor scenarios crafted by user typology",
    "home.pillars.card2.title": "Narrative structures",
    "home.pillars.card2.text": "Compose coherent spatial stories, from the master plan to on-site or on-screen cues.",
    "home.pillars.card2.point1": "Thematic routes and tactile cartography",
    "home.pillars.card2.point2": "Editorial scripting dedicated to journeys",
    "home.pillars.card3.title": "Learning organisations",
    "home.pillars.card3.text": "Set up shared governance between technical, mediation, and hospitality teams to maintain systems over time.",
    "home.pillars.card3.point1": "Custom monitoring dashboards",
    "home.pillars.card3.point2": "Operational guides for fast updates",
    "home.recommendations.heading": "Key recommendations",
    "home.recommendations.intro": "Our studies conclude with actionable recommendations tailored to your transformation phases.",
    "home.recommendations.item1": "Prioritise pivot points where circulation, educational expectations, and safety constraints intersect.",
    "home.recommendations.item2": "Blend digital experiences with existing architectural cues to protect collective memory of the site.",
    "home.recommendations.item3": "Document every plan evolution to build a transmissible cartographic heritage.",
    "home.recommendations.item4": "Test accessibility with diverse profiles and iterate until comprehension becomes effortless.",
    "home.testimonials.heading": "Testimonials",
    "home.testimonials.intro": "Public institutions and urban consortiums share feedback on our research-action collaborations.",
    "home.testimonials.quote1": "“The narrative mapping workshops transformed how we understand pedestrian flows. Interactive plans remain relevant despite ongoing works.”",
    "home.testimonials.name1": "Sophie Maréchal",
    "home.testimonials.role1": "Mobility coordinator, metropolitan museum hub",
    "home.testimonials.quote2": "“The editorial governance we co-created simplifies multilingual signage updates without overloading teams.”",
    "home.testimonials.name2": "Laurent De Wilde",
    "home.testimonials.role2": "Passenger information manager, regional transport network",
    "home.testimonials.quote3": "“Night-time flow simulations allowed us to integrate precise light markers while respecting heritage constraints.”",
    "home.testimonials.name3": "Nabila Cherfi",
    "home.testimonials.role3": "Technical director, urban learning campus",
    "home.blog.heading": "Latest explorations",
    "home.blog.intro": "Our articles detail applied methods for complex environments, illustrated with datasets and field insights.",
    "home.blog.readMore": "Read the analysis",
    "home.blog.allPosts": "View all articles",
    "services.hero.eyebrow": "SERVICES",
    "services.hero.title": "Five strands to structure your orientation strategy",
    "services.hero.subtitle": "We support public actors in analysing, designing, and evaluating spatial orientation systems suited to multi-use environments.",
    "services.hero.imageAlt": "Workshop reviewing a digital plan",
    "services.list.heading": "Intervention strands",
    "services.list.intro": "Each service unfolds through a documented workflow combining qualitative diagnosis, quantitative modelling, and operational guidance.",
    "services.service1.title": "Spatial orientation audit",
    "services.service1.text": "Comprehensive appraisal of access conditions, readability, and appropriation across public venues using observations and shared data.",
    "services.service1.point1": "Mapping frictions and opportunities",
    "services.service1.point2": "Prioritised recommendations with temporal scenarios",
    "services.service2.title": "Digital signage design",
    "services.service2.text": "Deployment of digital supports, interactive plans, and contextual content guiding audiences at every stage of their journey.",
    "services.service2.point1": "Multilingual editorial guidelines",
    "services.service2.point2": "Content matrices adaptable to events",
    "services.service3.title": "Interactive plan modelling",
    "services.service3.text": "Production of dynamic plans integrating real-time feeds, accessibility constraints, and flow variations.",
    "services.service3.point1": "Contextual hyperlinks woven into maps",
    "services.service3.point2": "Interfaces available on kiosks and mobile",
    "services.service4.title": "User journeys and spatial UX",
    "services.service4.text": "Journey analysis, co-design sessions, and experience testing through functional prototypes.",
    "services.service4.point1": "Emotion maps and comprehension metrics",
    "services.service4.point2": "Documented continuous improvement loops",
    "services.service5.title": "Governance and coaching",
    "services.service5.text": "Structuring lasting governance to maintain, align, and evolve guidance systems with internal capacities.",
    "services.service5.point1": "Cross-department coordination rituals",
    "services.service5.point2": "Shared dashboards and indicators",
    "services.method.heading": "Typical methodology",
    "services.method.intro": "Our missions follow a flexible spine based on site maturity and data availability.",
    "services.method.step1": "1. On-site immersion: observations, interviews, and audit of existing documents.",
    "services.method.step2": "2. Cartographic synthesis: zoning, flow modelling, and detection of user conflicts.",
    "services.method.step3": "3. Prototyping: graphic scenarios, digital prototypes, and targeted user tests.",
    "services.method.step4": "4. Deployment: operational handbook, governance, skills transfer, and monitoring indicators.",
    "services.deliverables.heading": "Deliverables",
    "services.deliverables.intro": "Outputs adapt to your timelines and internal resources.",
    "services.deliverables.point1": "Annotated, versioned cartographic dossiers",
    "services.deliverables.point2": "Signage component libraries",
    "services.deliverables.point3": "Governance scripts and decision matrices",
    "services.deliverables.point4": "Transfer sessions with operational documentation",
    "about.hero.eyebrow": "APPROACH",
    "about.hero.title": "A team dedicated to complex public environments",
    "about.hero.subtitle": "We combine urbanism, information design, and data engineering to accompany spatial transformations.",
    "about.hero.imageAlt": "Collaborative mapping workshop in progress",
    "about.mission.heading": "Mission",
    "about.mission.intro": "Share robust methods to make demanding places legible while putting accessibility first.",
    "about.mission.point1": "Anchor systems in the operational reality of each site",
    "about.mission.point2": "Bridge technical teams and audiences for shared decisions",
    "about.mission.point3": "Document every step to guarantee replication",
    "about.values.heading": "Values",
    "about.values.intro": "Our interventions rely on principles that secure consistency and transparency.",
    "about.values.card1.title": "Clarity",
    "about.values.card1.text": "Make data and decisions understandable so every actor can own spatial journeys.",
    "about.values.card2.title": "Listening",
    "about.values.card2.text": "Multiply exchange formats to capture user perceptions and turn them into actionable indicators.",
    "about.values.card3.title": "Continuity",
    "about.values.card3.text": "Design maintainable tools aligned with internal resources and capable of evolving smoothly.",
    "about.timeline.heading": "Milestones",
    "about.timeline.intro": "A few highlights illustrate our progress and experiments.",
    "about.timeline.step1": "2016 — Launch of the spatial orientation lab and first sensitive mappings in urban libraries.",
    "about.timeline.step2": "2018 — Creation of a digital signage reference framework for multi-site campuses.",
    "about.timeline.step3": "2020 — Roll-out of indoor navigation tools for a cultural intermunicipal network.",
    "about.timeline.step4": "2023 — Publication of governance guides and shared indicators for public consortiums.",
    "about.team.heading": "Team",
    "about.team.intro": "A multidisciplinary team blending strategic design, cartography, and social sciences.",
    "about.team.member1.name": "Diane Smet",
    "about.team.member1.role": "Research director",
    "about.team.member1.bio": "Urban planner coordinating field immersions and aligning mobility scenarios with policy objectives.",
    "about.team.member1.alt": "Portrait of Diane Smet",
    "about.team.member2.name": "Jonas Dervaux",
    "about.team.member2.role": "Information designer",
    "about.team.member2.bio": "Specialist of interactive plans, he crafts graphic libraries and supervises multi-device readability tests.",
    "about.team.member2.alt": "Portrait of Jonas Dervaux",
    "about.team.member3.name": "Leïla Rahmani",
    "about.team.member3.role": "Spatial UX analyst",
    "about.team.member3.bio": "She pilots research protocols, structures datasets, and builds monitoring dashboards for internal teams.",
    "about.team.member3.alt": "Portrait of Leïla Rahmani",
    "blog.hero.eyebrow": "BLOG",
    "blog.hero.title": "In-depth spatial UX analyses",
    "blog.hero.subtitle": "Case studies, field feedback, and reproducible protocols around digital signage and indoor navigation.",
    "blog.list.intro": "Browse our latest publications. Each article shares actionable resources and measurable indicators.",
    "blog.backLink": "Back to articles",
    "post1.meta": "22 April 2024 · 11 min read",
    "post1.excerpt": "How to structure layered spatial narratives for an urban campus by connecting sensitive mapping, digital signage, and continuous governance.",
    "post1.title": "Designing layered spatial narratives for an urban campus",
    "post1.heroAlt": "Visitor using a navigation interface on an urban campus",
    "post1.intro": "Urban campuses mix cultural institutions, transport interchanges, research labs, and public squares. Each layer attracts audiences with distinct expectations, yet they all rely on clear spatial orientation amid constant change. Our digital signage practice treats the campus as a living dataset where architectural qualities, temporal rhythms, and pedestrian perceptions are synchronised. Rather than producing static boards, we choreograph indoor navigation across multiple media so visitors, staff, and partners understand the site’s choreography in real time.",
    "post1.section1.heading": "Mapping operational conditions",
    "post1.section1.p1": "We begin with multiscale mapping that blends surveys, maintenance logs, and field observations. Sensor traces reveal circulation peaks and troughs, while interviews expose mental maps residents rely on. These inputs feed geolocated storyboards describing light, acoustics, and accessibility thresholds. The dataset indicates where digital signage must adapt, where analogue cues still deliver, and where hybrid interventions clarify indoor-outdoor transitions.",
    "post1.section1.p2": "Each spatial node is tagged by experiential role: anchor, gateway, connector, pause, exploration. For every role we evaluate readability metrics such as contrast, dwell time, and intersecting sightlines. Architectural and infrastructure constraints sit alongside user impressions collected through diary studies. Triangulating these viewpoints prevents blind spots often created when only technical drawings are reviewed. Mapping therefore generates spatial UX hypotheses before any prototype is drafted.",
    "post1.section1.p3": "The mapping also highlights dependencies like service corridors, emergency exits, and construction envelopes. These overlays preserve accessibility commitments even when the campus shifts. We examine how pedestrian mobility interacts with micro-mobility fleets and service vehicles, designing buffers where required. Every diagram includes stewardship notes so future teams can update assumptions without starting over, reducing misalignment during later design sprints.",
    "post1.section2.heading": "Running iterative digital pilots",
    "post1.section2.p1": "Once the baseline is validated, we deliver digital pilots that mirror real journeys. Interactive plans, kiosks, light cues, and projections are synchronised. Each pilot focuses on a priority scenario: welcoming visiting researchers, guiding school groups, or routing maintenance teams at night. Observation windows cover varied weather to test readability under glare, rain, or winter darkness. Touch interactions and positional data refine iconography and semantics.",
    "post1.section2.p2": "Because complex environments resist uniform answers, we deploy modular guidance blocks. Colour-coded trails, ambient lighting, and context-aware notifications combine according to building typologies. Pilots let stakeholders experience information design when noise spikes or crowd density rises. Feedback loops include micro-surveys, recorded walkthroughs, and co-design workshops. The emphasis stays on translating user journeys into tangible adjustments rather than delivering a final artefact.",
    "post1.section2.p3": "Throughout pilots we keep a change log capturing every calibration. The log tracks how spatial mapping evolves when operational needs shift, such as temporary exhibitions or policy updates. Linking each change to measurable outcomes—shorter detours, smoother elevator waits, stronger comprehension of multilingual messages—builds trust in iteration. Transparency encourages departments to share data streams that enrich interactive maps.",
    "post1.section3.heading": "Embedding continuous governance",
    "post1.section3.p1": "Spatial UX strategy succeeds only with governance in place. We help institutions craft stewardship charters defining who monitors visual guidance, who curates content, and how updates flow through digital channels. Training modules equip staff to recalibrate interactive plans without external help. Dashboards flag anomalies, for instance when guidance screens desynchronise from operational systems.",
    "post1.section3.p2": "We also design escalation protocols blending qualitative observations with sensor analytics. If a corridor repeatedly triggers hesitation, maintenance teams receive alerts to examine lighting, acoustics, or signage. Accessibility committees review these signals to keep inclusive commitments active. When new architecture is commissioned, the governance guide requires spatial orientation standards in briefs so future projects extend the existing narrative.",
    "post1.section3.p3": "Finally, we schedule evaluation cycles aligned with academic calendars and public programming. Busy seasons align messaging with cultural events, while calmer periods test experimental augmented cues. Reviews renew shared ownership across departments, reducing splits between physical and digital layers. With governance embedded, the campus evolves gracefully and visitors continue to experience a coherent cartography.",
    "post1.conclusion": "Urban campuses thrive on curiosity, collaboration, and adaptation. Treating digital signage as a living framework ensures every update strengthens spatial confidence. Our layered methodology unites data, narrative, and design craft so orientation stays clear even as environments grow intricate. The result is a resilient navigational ecosystem keeping public spaces welcoming over decades.",
    "post2.meta": "8 May 2024 · 10 min read",
    "post2.excerpt": "Deploying sequenced digital signage inside a multimodal transport hub by coordinating pedestrian flows, urban cues, and shared mobility interfaces.",
    "post2.title": "Sequencing digital wayfinding inside a multimodal transit hub",
    "post2.heroAlt": "Transport hall with synchronised digital signage",
    "post2.intro": "Multimodal hubs assemble trains, trams, buses, shared bikes, and urban services. Their density demands digital signage that guides diverse audiences without cognitive overload. Our approach clarifies travel sequences, surfaces operational dependencies, and harmonises transitions between outdoor public space and indoor networks. The goal: deliver coherent spatial orientation no matter the entry point or mode.",
    "post2.section1.heading": "Analysing journey sequences",
    "post2.section1.p1": "We start by observing circulation across daily and weekly cycles. Pedestrian trajectories, intermodal transfers, and waiting zones are mapped. We pinpoint changes in pace, build-up zones, and moments when information is sought. This scrutiny reveals segments needing reinforced digital signage versus those where discreet markers suffice.",
    "post2.section1.p2": "We then build journey atlases for multiple profiles: occasional visitor, daily commuter, group escort, tourist. Emotions, stress points, and accessibility needs are noted. Scripts generated from these findings define information hierarchy, messaging order, and handover moments between analogue and digital channels.",
    "post2.section1.p3": "Operations teams join the process so we understand constraints such as incident management, overnight maintenance, or crowd control during events. We define overload scenarios and contingency plans. Digital signage can thus pivot to crowd regulation, alternative routing, or safety instructions using consistent language.",
    "post2.section2.heading": "Structuring synchronised supports",
    "post2.section2.p1": "We design layered supports. Welcome totems provide global orientation, contextual screens punctuate transfers, and light cues assist night navigation. Hierarchy is linked to triggers based on flow detection. Content rearranges to guide travellers toward less saturated access points or to support people with reduced mobility.",
    "post2.section2.p2": "Multilingual readability receives special care. A graphic charter specifies colour codes, typography, and pictograms per medium. Interactive plans include filters by transport mode, transfer time, or desired sound level. Audio content is synchronised with visuals to maintain sensory coherence.",
    "post2.section2.p3": "To ensure resilience we supply modular admin interfaces. Internal teams adjust messages, schedule thematic campaigns, or temporarily disable elements. Validation scripts check alignment between real-time data and display content; discrepancies trigger alerts for operators.",
    "post2.section3.heading": "Anchoring governance in the territory",
    "post2.section3.p1": "Effective multimodal signage must align with the surrounding territory. We collaborate with urban services to synchronise station information with public realm cues. District maps, pedestrian routes to amenities, and active mobility plans integrate seamlessly. This continuity encourages travellers to extend their journeys outside without losing orientation.",
    "post2.section3.p2": "We set up regular coordination between transport operators, municipal services, and local actors. Meetings anticipate major events, works, service changes, and seasonal variations. Digital signage becomes a dialogue channel reflecting territorial dynamics rather than a centralised broadcast.",
    "post2.section3.p3": "Finally, we assess effectiveness using shared indicators: transfer times, satisfaction, saturation levels. Results are benchmarked against reference scenarios to highlight improvements. Lessons are capitalised for other sites, building collective expertise.",
    "post2.conclusion": "Sequencing digital wayfinding around clear journeys, synchronised supports, and territorial governance transforms a multimodal hub into a fluent experience. Spatial orientation becomes a public service able to adapt to evolving needs and events.",
    "post3.meta": "21 May 2024 · 10 min read",
    "post3.excerpt": "Evaluating visual guidance inside a dense cultural district by combining field observation, sensory indicators, and shared governance.",
    "post3.title": "Evaluating visual guidance inside a cultural quarter",
    "post3.heroAlt": "Pedestrian bridge with light cues and cultural signage",
    "post3.intro": "Cultural quarters host museums, venues, libraries, and public spaces. Their appeal depends on welcoming diverse audiences while keeping flows fluid. Deploying visual guidance here means balancing heritage requirements, operational constraints, and varied uses. This is how we measure and reinforce a suitable signage strategy.",
    "post3.section1.heading": "Defining readability metrics",
    "post3.section1.p1": "We establish a grid mixing quantitative and qualitative indicators. Time needed to locate an entrance, ease crossing a junction, and comprehension of editorial content are assessed. We analyse movement traces and mental maps collected through interviews to reveal hesitation zones.",
    "post3.section1.p2": "Sensory stimuli are mapped: light intensity, soundscape, crowd density. These parameters influence guidance readability. A light cue effective by day may overwhelm at night; a colour palette can dissolve in highly contrasted surroundings. Measurements allow us to tune interventions by period.",
    "post3.section1.p3": "We also evaluate interactions between analogue and digital supports. Heritage buildings impose integration constraints. We co-create reversible supports with architects so devices converse with the fabric without altering it. Every adaptation is documented for future updates.",
    "post3.section2.heading": "Organising territorial mediation",
    "post3.section2.p1": "The cultural quarter is a multi-actor ecosystem. Mediation workshops gather institutions, retailers, residents, and artists. Together we set priorities, key messages, and working languages. Feedback feeds a shared knowledge base.",
    "post3.section2.p2": "We craft an editorial calendar synchronised with cultural programming. Digital signage content adapts to events, festivals, late openings. Editorial pieces highlight district narratives to strengthen appropriation. Signage becomes a medium extending cultural experiences.",
    "post3.section2.p3": "Governance tools sustain coherence: dashboards, maintenance checklists, emergency procedures. Every actor knows how to update content, report issues, or request changes. Clarity reinforces collective resilience.",
    "post3.section3.heading": "Capitalising and sharing",
    "post3.section3.p1": "Evaluation continues beyond metrics. We compile journey diaries describing experiences across seasons. These narratives illustrate district evolution, adjustments made, and new audiences welcomed.",
    "post3.section3.p2": "Transfer guides support internal teams. They describe data structures, editorial workflows, and accessibility expectations. New team members gain a clear roadmap.",
    "post3.section3.p3": "Lessons are shared with other cultural territories through workshops, publications, and talks. Visual guidance becomes a shared asset that keeps evolving.",
    "post3.conclusion": "Measuring visual guidance impact in a cultural quarter blends methodology, user listening, and shared governance. With this approach, visitors find their way, institutions coordinate, and the territory gains readability.",
    "post4.meta": "4 June 2024 · 9 min read",
    "post4.excerpt": "Designing a voice-augmented guidance system for a library network using accessible interfaces, physical cues, and documentary governance.",
    "post4.title": "Voice-augmented wayfinding for a public library network",
    "post4.heroAlt": "Library user interacting with a vocal kiosk",
    "post4.intro": "Public libraries combine collections, study rooms, digital services, and events. Users need to locate shelves quickly, access workspaces, or find temporary exhibitions. We designed a voice-augmented guidance system linking digital signage, physical cues, and human support.",
    "post4.section1.heading": "Listening to uses and modelling requirements",
    "post4.section1.p1": "Interviews with readers, staff, and mediators revealed distinct expectations. Regulars seek efficiency, newcomers want exploration. We mapped flows by visit type, analysed confusion zones, and recorded peak periods.",
    "post4.section1.p2": "Acoustic audits identified areas where voice guidance would support without disturbing quietness. Some zones need informative prompts, others suit light cues. We assessed compatibility with existing catalogues, apps, and accessibility tools.",
    "post4.section1.p3": "A shared lexicon was crafted, concise and precise. Vocal messages use short sentences, explicit spatial references, and clear orientation instructions. This linguistic foundation keeps content consistent across supports.",
    "post4.section2.heading": "Prototyping augmented journeys",
    "post4.section2.p1": "We built vocal kiosks synced with interactive plans. Users select a journey: find a room, reach a service, discover content. Kiosks deliver synchronised voice and visual instructions, adapting to progress thanks to discreet beacons.",
    "post4.section2.p2": "Physical cues were reinforced: light totems, tactile pictograms, colour-coded markers. Each element obeys a narrative logic. Digital content links to extra resources extending the visit. Prototypes were tested with diverse user profiles.",
    "post4.section2.p3": "Accessibility modules were integrated: volume controls, live captions, sign-language avatars, high-contrast modes. Feedback improved synthetic voice quality and dialogue flow.",
    "post4.section3.heading": "Structuring documentary governance",
    "post4.section3.p1": "Voice guidance needs rigorous governance. We founded an editorial committee in charge of content, updates, and audio scripts. Procedures explain how to add services, modify journeys, or integrate temporary programmes.",
    "post4.section3.p2": "Dashboards track kiosk usage and satisfaction. Data feeds continuous improvement: fine-tuning messages, optimising light cues, enriching content.",
    "post4.section3.p3": "Training sessions prepared internal teams for operations. Practical workshops and illustrated guides eased adoption. Voice guidance thus becomes a lasting service aligned with library evolution.",
    "post4.conclusion": "Well-crafted voice-augmented guidance strengthens accessibility and attractiveness in public libraries. Combined listening, prototyping, and governance keep the system aligned with users and make it a mediation vector.",
    "post5.meta": "18 June 2024 · 9 min read",
    "post5.excerpt": "Maintaining a spatial UX baseline inside a heritage district by balancing conservation, tourism flows, and resident needs.",
    "post5.title": "Maintaining resilient spatial UX in a heritage district",
    "post5.heroAlt": "Heritage street with discreet markers and digital display",
    "post5.intro": "Heritage districts attract visitors and residents. They must protect identity while staying accessible. Maintaining resilient spatial UX requires balancing conservation, tourist flows, local logistics, and daily needs. Here is our approach.",
    "post5.section1.heading": "Identifying use tensions",
    "post5.section1.p1": "Seasonal observations reveal attendance variations. Tourist circuits, resident routines, and deliveries are mapped. Saturation points, bottlenecks, and respite areas emerge.",
    "post5.section1.p2": "We assess existing digital content. Some screens disrupt the heritage ambiance. We pursue discreet solutions: temporary projections, retractable supports, tactile signage. The goal is preserving coherence.",
    "post5.section1.p3": "Interviews with artisans, shopkeepers, guides, and residents enrich the matrix. Each actor shares expectations, constraints, and ideas. These narratives feed a tension matrix guiding decisions.",
    "post5.section2.heading": "Designing reversible cues",
    "post5.section2.p1": "Interventions are reversible by design. Adjustable light beacons, removable supports, and foldable maps adapt guidance to seasons. Materials and finishes echo heritage elements.",
    "post5.section2.p2": "Digital content is available via discreet QR codes or dedicated apps. Information is contextual: site history, opening times, local services. Audio content can be downloaded for self-guided tours.",
    "post5.section2.p3": "User tests with visitors and residents adjust information density, tone, and marker placement. Participation fosters shared ownership.",
    "post5.section3.heading": "Embedding long-term maintenance",
    "post5.section3.p1": "Shared governance unites heritage, tourism, public works, and local associations. Review calendars follow seasons. Decisions are documented and circulated.",
    "post5.section3.p2": "Indicators—satisfaction, flow metrics, qualitative feedback—drive adjustments. Lessons transfer to other heritage sites.",
    "post5.section3.p3": "Training ensures local teams handle maintenance. Technical guides and hands-on workshops sustain continuity. Spatial UX becomes shared intangible heritage.",
    "post5.conclusion": "Maintaining resilient spatial UX in a heritage district demands careful listening and reversible tools. With shared governance the district stays vibrant, legible, and welcoming.",
    "contact.hero.eyebrow": "CONTACT",
    "contact.hero.title": "Coordinate your spatial orientation projects",
    "contact.hero.subtitle": "Describe your context: we analyse your needs and prepare initial methodological pointers without delay.",
    "contact.hero.imageAlt": "Brussels map with orientation markers",
    "contact.details.title": "Direct details",
    "contact.details.intro": "We operate from Brussels alongside European partners. Please share a detailed message to help us prepare our exchange.",
    "contact.details.phoneLabel": "Phone",
    "contact.details.phoneValue": "+32 2 318 45 72",
    "contact.details.emailLabel": "Email",
    "contact.details.emailValue": "info@danswholesaleplants.com",
    "contact.details.addressLabel": "Address",
    "contact.details.addressValue": "Boulevard Anspach 65, 1000 Brussels, Belgium",
    "contact.details.hoursLabel": "Response window",
    "contact.details.hoursValue": "Monday to Friday, 09:00 - 17:30 (Central European Time)",
    "contact.map.title": "Office map",
    "contact.map.caption": "The office sits near the Bourse, reachable by tram, metro, and cycling lanes.",
    "contact.map.iframeTitle": "OpenStreetMap locating danswholesaleplants in Brussels",
    "contact.form.title": "Describe your situation",
    "contact.form.intro": "The more context you provide, the better we can prepare actionable insights before our first meeting.",
    "contact.form.nameLabel": "Full name",
    "contact.form.namePlaceholder": "Your full name",
    "contact.form.emailLabel": "Email address",
    "contact.form.emailPlaceholder": "name@organisation.be",
    "contact.form.orgLabel": "Organisation",
    "contact.form.orgPlaceholder": "Institution or department",
    "contact.form.messageLabel": "Message",
    "contact.form.messagePlaceholder": "Objectives, scope, timeline, current status…",
    "contact.form.submit": "Send",
    "contact.form.privacy": "Information shared is used solely to prepare our response. See our privacy policy for details.",
    "faq.hero.eyebrow": "FAQ",
    "faq.hero.title": "Frequently asked questions",
    "faq.hero.subtitle": "Clarifications about our approach, intervention formats, and cooperation with public actors.",
    "faq.list.intro": "Answers remain generic. Contact us for guidance tailored to your territory.",
    "faq.q1.question": "Do you only work in Belgium?",
    "faq.q1.answer": "We are based in Brussels yet operate across Europe. We favour missions where regular site access is feasible.",
    "faq.q2.question": "Which data is required to start?",
    "faq.q2.answer": "We can begin with basic material—plans, photos, field notes. When data is missing we organise a rapid immersive audit.",
    "faq.q3.question": "How do you involve internal teams?",
    "faq.q3.answer": "We set up a cross-functional steering committee following each step, sharing decisions, and ensuring continuity after our mission.",
    "faq.q4.question": "What is the typical project duration?",
    "faq.q4.answer": "Depending on complexity, missions run from six weeks for focused audits to nine months for full systems including governance.",
    "faq.q5.question": "Do you deliver physical supports?",
    "faq.q5.answer": "We design detailed prototypes and specifications. Fabrication can be handled by partners we coordinate with.",
    "faq.q6.question": "Which indicators do you track?",
    "faq.q6.answer": "We monitor comprehension, journey times, qualitative satisfaction, and system resilience through dashboards.",
    "faq.q7.question": "How do you manage multilingual content?",
    "faq.q7.answer": "We craft multilingual editorial matrices tested with varied audiences to guarantee readability and relevance.",
    "faq.q8.question": "Do you provide training?",
    "faq.q8.answer": "Yes, we deliver transfer workshops and focused training on governance, content editing, and journey analytics.",
    "terms.hero.eyebrow": "TERMS",
    "terms.hero.title": "Terms of use",
    "terms.hero.subtitle": "These terms govern access to and use of content published on danswholesaleplants.com.",
    "terms.section1.title": "1. Purpose",
    "terms.section1.body": "These terms define how users access the site’s informative content and use it in accordance with Belgian law.",
    "terms.section2.title": "2. Acceptance",
    "terms.section2.body": "By browsing the site, users acknowledge reading the terms and agree to comply. Otherwise they should discontinue browsing.",
    "terms.section3.title": "3. Changes",
    "terms.section3.body": "We may amend these terms at any time. Users should review them regularly to stay informed.",
    "terms.section4.title": "4. Site availability",
    "terms.section4.body": "The site is available 24/7 except during maintenance, force majeure, or security decisions.",
    "terms.section5.title": "5. Intellectual property",
    "terms.section5.body": "Content, graphics, and documents are protected. Reuse is allowed if sourced properly and text integrity is preserved.",
    "terms.section6.title": "6. Authorised use",
    "terms.section6.body": "Information may be used for study, monitoring, or documentation. Misleading or diverted use is forbidden.",
    "terms.section7.title": "7. Contributions",
    "terms.section7.body": "When comments or feedback are shared, users guarantee accuracy and avoid unlawful or defamatory content.",
    "terms.section8.title": "8. Personal data",
    "terms.section8.body": "Data collected via the contact form is processed per our privacy policy solely to answer requests.",
    "terms.section9.title": "9. External links",
    "terms.section9.body": "The site may link to other resources. We bear no responsibility for external content or updates.",
    "terms.section10.title": "10. Liability",
    "terms.section10.body": "We strive to supply reliable information without guaranteeing complete accuracy. Users remain responsible for their interpretations.",
    "terms.section11.title": "11. Security",
    "terms.section11.body": "Users agree not to disrupt the site and to report any potential vulnerability via the contact address.",
    "terms.section12.title": "12. Governing law",
    "terms.section12.body": "These terms are governed by Belgian law. Courts in Brussels have jurisdiction over disputes.",
    "terms.section13.title": "13. Contact",
    "terms.section13.body": "Questions about the terms can be addressed through the contact form or info@danswholesaleplants.com.",
    "terms.section14.title": "14. Effective date",
    "terms.section14.body": "This version has been effective since 1 March 2024 and replaces previous editions.",
    "privacy.hero.eyebrow": "PRIVACY",
    "privacy.hero.title": "Privacy policy",
    "privacy.hero.subtitle": "We detail how personal information shared by users is processed.",
    "privacy.section1.title": "1. Data controller",
    "privacy.section1.body": "The site is operated by danswholesaleplants, Boulevard Anspach 65, 1000 Brussels. We control data collected through the contact form.",
    "privacy.section2.title": "2. Data collected",
    "privacy.section2.body": "We collect voluntarily provided information (name, email, organisation, message). No sensitive data is requested.",
    "privacy.section3.title": "3. Purpose",
    "privacy.section3.body": "Data is used exclusively to analyse requests, prepare exchanges, and follow up. It is not used for automated outreach.",
    "privacy.section4.title": "4. Legal basis",
    "privacy.section4.body": "Processing relies on legitimate interest to answer requests and on the user’s explicit consent.",
    "privacy.section5.title": "5. Retention",
    "privacy.section5.body": "Data is retained for twelve months after the last contact, then deleted or anonymised.",
    "privacy.section6.title": "6. Recipients",
    "privacy.section6.body": "Information is shared only with authorised members of danswholesaleplants. No external transfer occurs without prior agreement.",
    "privacy.section7.title": "7. Hosting",
    "privacy.section7.body": "The site is hosted on EU-based servers adhering to recognised security standards.",
    "privacy.section8.title": "8. Rights",
    "privacy.section8.body": "You may access, rectify, erase, restrict, or oppose processing. Contact info@danswholesaleplants.com to exercise your rights.",
    "privacy.section9.title": "9. Security",
    "privacy.section9.body": "We implement technical and organisational safeguards against loss, misuse, or unauthorised access.",
    "privacy.section10.title": "10. Updates",
    "privacy.section10.body": "We may update this policy. Significant changes will be announced on the site.",
    "cookies.hero.eyebrow": "COOKIES",
    "cookies.hero.title": "Cookie policy",
    "cookies.hero.subtitle": "Understand how we use cookies and how to adjust preferences.",
    "cookies.intro.text": "Cookies are small files stored on your device. They help us remember your settings and improve navigation. You can accept, refuse, or customise their use.",
    "cookies.table.name": "Name",
    "cookies.table.provider": "Provider",
    "cookies.table.type": "Type",
    "cookies.table.purpose": "Purpose",
    "cookies.table.duration": "Duration",
    "cookies.table.row1.name": "site_lang",
    "cookies.table.row1.provider": "danswholesaleplants",
    "cookies.table.row1.type": "Necessary",
    "cookies.table.row1.purpose": "Stores your chosen display language.",
    "cookies.table.row1.duration": "12 months",
    "cookies.table.row2.name": "cookie_consent",
    "cookies.table.row2.provider": "danswholesaleplants",
    "cookies.table.row2.type": "Necessary",
    "cookies.table.row2.purpose": "Records your cookie preferences.",
    "cookies.table.row2.duration": "12 months",
    "cookies.table.row3.name": "ux_preferences",
    "cookies.table.row3.provider": "danswholesaleplants",
    "cookies.table.row3.type": "Preferences",
    "cookies.table.row3.purpose": "Keeps your preferred sections or maps.",
    "cookies.table.row3.duration": "6 months",
    "cookies.table.row4.name": "wayfinding_insights",
    "cookies.table.row4.provider": "danswholesaleplants",
    "cookies.table.row4.type": "Analytics",
    "cookies.table.row4.purpose": "Measures consultation of wayfinding resources.",
    "cookies.table.row4.duration": "6 months",
    "cookies.section1.title": "Necessary cookies",
    "cookies.section1.body": "Essential for operation, they handle sessions, security, and language memory. They cannot be disabled.",
    "cookies.section2.title": "Preference cookies",
    "cookies.section2.body": "They keep your display choices, such as pinned articles or recently opened maps.",
    "cookies.section3.title": "Analytics cookies",
    "cookies.section3.body": "They help us understand how visitors browse our content to improve spatial UX. They can be disabled.",
    "cookies.section4.title": "Outreach cookies",
    "cookies.section4.body": "They measure interest in publications shared through our information channels. No commercial material is distributed.",
    "cookies.manage.instructions": "You can change preferences anytime using the “Manage cookies” button in the footer.",
    "refund.hero.eyebrow": "POLICY",
    "refund.hero.title": "Revision policy",
    "refund.hero.subtitle": "Our content is informational. This policy outlines how we process correction or removal requests.",
    "refund.section1.title": "1. Scope",
    "refund.section1.body": "The policy covers articles, summaries, and downloadable resources published on the site.",
    "refund.section2.title": "2. Publication",
    "refund.section2.body": "All content is checked before publication. We favour cross-references and cite sources.",
    "refund.section3.title": "3. Notifications",
    "refund.section3.body": "Correction requests can be submitted through the contact form including URL and the identified issue.",
    "refund.section4.title": "4. Review",
    "refund.section4.body": "Each notification is reviewed within fifteen days and acknowledged to the sender.",
    "refund.section5.title": "5. Update",
    "refund.section5.body": "Confirmed inaccuracies trigger updates with a published modification date.",
    "refund.section6.title": "6. Withdrawal",
    "refund.section6.body": "If information cannot be verified, content may be withdrawn. A withdrawal notice is displayed.",
    "refund.section7.title": "7. Archiving",
    "refund.section7.body": "Previous versions are archived to ensure traceability of significant corrections.",
    "refund.section8.title": "8. Responsibilities",
    "refund.section8.body": "Internal contributors remain responsible for their texts. External quotations are credited accordingly.",
    "refund.section9.title": "9. Periodicity",
    "refund.section9.body": "An annual editorial review checks the relevance of publications.",
    "refund.section10.title": "10. Contact",
    "refund.section10.body": "Questions about this policy can be addressed to info@danswholesaleplants.com.",
    "disclaimer.hero.eyebrow": "NOTICE",
    "disclaimer.hero.title": "Disclaimer",
    "disclaimer.hero.subtitle": "Framework governing the use of information provided on the site.",
    "disclaimer.section1.title": "General information",
    "disclaimer.section1.body": "The site offers analyses and field feedback. They do not constitute exhaustive legal, financial, or technical advice.",
    "disclaimer.section2.title": "Accuracy",
    "disclaimer.section2.body": "We ensure quality without guaranteeing completeness. Users must verify suitability for their context.",
    "disclaimer.section3.title": "Responsibility",
    "disclaimer.section3.body": "We are not liable for decisions made using our content. Users remain in control of their choices.",
    "disclaimer.section4.title": "External links",
    "disclaimer.section4.body": "Links to third-party sites are for reference. We do not control external content.",
    "disclaimer.section5.title": "Updates",
    "disclaimer.section5.body": "Content may change without notice to reflect evolving projects or knowledge.",
    "disclaimer.section6.title": "Contact",
    "disclaimer.section6.body": "Use the contact form for any questions regarding this disclaimer.",
    "thank.hero.eyebrow": "THANK YOU",
    "thank.hero.title": "Your message has been sent",
    "thank.hero.subtitle": "We will review your request and propose an initial scoping session.",
    "thank.hero.button": "Back to home",
    "meta.services.title": "Spatial orientation services — danswholesaleplants",
    "meta.services.description": "Five strands to analyse, design, and govern digital signage, spatial mapping, and UX guidance systems.",
    "meta.about.title": "About — danswholesaleplants",
    "meta.about.description": "Discover our mission, values, and team focused on spatial orientation inside complex environments.",
    "meta.blog.title": "Blog — danswholesaleplants",
    "meta.blog.description": "In-depth analyses on digital signage, indoor navigation, and public space cartography.",
    "meta.contact.title": "Contact — danswholesaleplants",
    "meta.contact.description": "Contact details, map, and form to present your spatial orientation context.",
    "meta.faq.title": "FAQ — danswholesaleplants",
    "meta.faq.description": "Frequently asked questions about our methods, scopes, and collaborations with public stakeholders.",
    "meta.terms.title": "Terms of use — danswholesaleplants",
    "meta.terms.description": "Terms governing access to and use of danswholesaleplants.com.",
    "meta.privacy.title": "Privacy policy — danswholesaleplants",
    "meta.privacy.description": "How personal data collected through danswholesaleplants.com is processed.",
    "meta.cookies.title": "Cookie policy — danswholesaleplants",
    "meta.cookies.description": "Information about cookies used on danswholesaleplants.com and available settings.",
    "meta.refund.title": "Revision policy — danswholesaleplants",
    "meta.refund.description": "Procedure for correcting or withdrawing editorial content.",
    "meta.disclaimer.title": "Disclaimer — danswholesaleplants",
    "meta.disclaimer.description": "Use framework and responsibility limits for site information.",
    "meta.thankyou.title": "Thank you — danswholesaleplants",
    "meta.thankyou.description": "Confirmation of your message sent to danswholesaleplants.",
    "meta.post1.title": "Layered campus narratives — danswholesaleplants",
    "meta.post1.description": "Methodology connecting mapping, digital signage, and governance within an urban campus.",
    "meta.post2.title": "Multimodal signage orchestration — danswholesaleplants",
    "meta.post2.description": "Sequencing digital wayfinding inside a multimodal transport hub.",
    "meta.post3.title": "Cultural visual guidance metrics — danswholesaleplants",
    "meta.post3.description": "Measuring visual guidance performance in a dense cultural district.",
    "meta.post4.title": "Voice-augmented libraries — danswholesaleplants",
    "meta.post4.description": "Designing a voice-augmented wayfinding system for public libraries.",
    "meta.post5.title": "Resilient heritage UX — danswholesaleplants",
    "meta.post5.description": "Maintaining spatial UX within a heritage district.",
    "home.blog.moreLink": "Discover the blog"
  }
};

function getTranslation(key, lang) {
  const dict = I18N[lang] || I18N[DEFAULT_LANG];
  if (dict && Object.prototype.hasOwnProperty.call(dict, key)) {
    return dict[key];
  }
  const fallback = I18N[DEFAULT_LANG];
  if (fallback && Object.prototype.hasOwnProperty.call(fallback, key)) {
    return fallback[key];
  }
  return "";
}

function applyLanguage(lang) {
  const html = document.documentElement;
  html.setAttribute("lang", lang);
  const dictionary = I18N[lang] || I18N[DEFAULT_LANG];

  const titleEl = document.querySelector("title[data-i18n-title]");
  if (titleEl) {
    const titleKey = titleEl.getAttribute("data-i18n-title");
    const titleText = getTranslation(titleKey, lang);
    if (titleText) {
      document.title = titleText;
    }
  }

  document.querySelectorAll("meta[data-i18n-meta]").forEach((meta) => {
    const key = meta.getAttribute("data-i18n-meta");
    const text = getTranslation(key, lang);
    if (text) {
      meta.setAttribute("content", text);
    }
  });

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const text = getTranslation(key, lang);
    if (text) {
      if (text.includes("{{year}}")) {
        el.textContent = text.replace("{{year}}", new Date().getFullYear());
      } else {
        el.textContent = text;
      }
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const text = getTranslation(key, lang);
    if (text) {
      el.setAttribute("placeholder", text);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const text = getTranslation(key, lang);
    if (text) {
      el.setAttribute("alt", text);
    }
  });

  document.querySelectorAll("[data-i18n-title-attr]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title-attr");
    const text = getTranslation(key, lang);
    if (text) {
      el.setAttribute("title", text);
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria-label");
    const text = getTranslation(key, lang);
    if (text) {
      el.setAttribute("aria-label", text);
    }
  });

  document.querySelectorAll("option[data-i18n]").forEach((option) => {
    const key = option.getAttribute("data-i18n");
    const text = getTranslation(key, lang);
    if (text) {
      option.textContent = text;
    }
  });
}

function showToast(messageKey) {
  const toastContainer = document.getElementById("toast-container");
  if (!toastContainer) return;
  const message = getTranslation(messageKey, currentLang);
  if (!message) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  toastContainer.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.add("show");
  });
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 4200);
}

function setupLanguageToggle() {
  const toggle = document.getElementById("language-toggle");
  if (!toggle) return;
  toggle.value = currentLang;
  toggle.addEventListener("change", (event) => {
    const lang = event.target.value;
    currentLang = lang;
    localStorage.setItem("site_lang", lang);
    applyLanguage(lang);
  });
}

function setupNavigationToggle() {
  const navToggle = document.getElementById("nav-toggle");
  const body = document.body;
  if (!navToggle) return;
  navToggle.addEventListener("click", () => {
    const expanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", (!expanded).toString());
    body.classList.toggle("nav-open", !expanded);
  });
  document.querySelectorAll(".primary-nav a").forEach((link) => {
    link.addEventListener("click", () => {
      document.body.classList.remove("nav-open");
      if (navToggle) {
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  });
}

function setupAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  document.querySelectorAll("[data-animate]").forEach((el) => observer.observe(el));
}

function getStoredConsent() {
  try {
    const stored = localStorage.getItem("cookie_consent");
    if (!stored) return null;
    return JSON.parse(stored);
  } catch (error) {
    return null;
  }
}

function storeConsent(consent) {
  localStorage.setItem("cookie_consent", JSON.stringify(consent));
}

function applyConsentToUI(consent) {
  const preferences = document.getElementById("cookie-preferences");
  const analytics = document.getElementById("cookie-analytics");
  const marketing = document.getElementById("cookie-marketing");
  if (preferences) preferences.checked = !!consent?.preferences;
  if (analytics) analytics.checked = !!consent?.analytics;
  if (marketing) marketing.checked = !!consent?.marketing;
}

function hideCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (banner) {
    banner.classList.add("hidden");
  }
}

function showCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (banner) {
    banner.classList.remove("hidden");
  }
}

function setupCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  if (!banner) return;

  const acceptBtn = banner.querySelector("[data-action='accept']");
  const declineBtn = banner.querySelector("[data-action='decline']");
  const saveBtn = banner.querySelector("[data-action='save']");
  const openBtn = document.getElementById("open-cookie-settings");

  const consent = getStoredConsent();
  if (consent) {
    applyConsentToUI(consent);
    hideCookieBanner();
  } else {
    showCookieBanner();
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      const newConsent = {
        necessary: true,
        preferences: true,
        analytics: true,
        marketing: true,
        decidedAt: new Date().toISOString()
      };
      storeConsent(newConsent);
      applyConsentToUI(newConsent);
      hideCookieBanner();
      showToast("toast.cookie.accepted");
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      const newConsent = {
        necessary: true,
        preferences: false,
        analytics: false,
        marketing: false,
        decidedAt: new Date().toISOString()
      };
      storeConsent(newConsent);
      applyConsentToUI(newConsent);
      hideCookieBanner();
      showToast("toast.cookie.declined");
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      const preferences = document.getElementById("cookie-preferences");
      const analytics = document.getElementById("cookie-analytics");
      const marketing = document.getElementById("cookie-marketing");
      const newConsent = {
        necessary: true,
        preferences: !!preferences?.checked,
        analytics: !!analytics?.checked,
        marketing: !!marketing?.checked,
        decidedAt: new Date().toISOString()
      };
      storeConsent(newConsent);
      applyConsentToUI(newConsent);
      hideCookieBanner();
      showToast("toast.cookie.saved");
    });
  }

  if (openBtn) {
    openBtn.addEventListener("click", () => {
      const consentState = getStoredConsent();
      if (consentState) {
        applyConsentToUI(consentState);
      }
      showCookieBanner();
    });
  }
}

function setupContactFormToast() {
  const form = document.querySelector("form[data-form='contact']");
  if (form) {
    form.addEventListener("submit", () => {
      sessionStorage.setItem("pendingToast", "toast.form.sent");
    });
  }
  const pending = sessionStorage.getItem("pendingToast");
  if (pending) {
    sessionStorage.removeItem("pendingToast");
    showToast(pending);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const storedLang = localStorage.getItem("site_lang");
  currentLang = storedLang && I18N[storedLang] ? storedLang : DEFAULT_LANG;
  applyLanguage(currentLang);
  setupLanguageToggle();
  setupNavigationToggle();
  setupAnimations();
  setupCookieBanner();
  setupContactFormToast();
});