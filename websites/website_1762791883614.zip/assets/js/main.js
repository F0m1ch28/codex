document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.mobile-nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  const scrollTopBtn = document.getElementById('scrollTop');
  const cookieBanner = document.getElementById('cookieBanner');
  const cookieAccept = document.getElementById('cookieAccept');
  const currentYearEl = document.getElementById('currentYear');

  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', !expanded);
      navLinks.parentElement.classList.toggle('open');
      navLinks.classList.toggle('open');
    });

    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        navLinks.parentElement.classList.remove('open');
        navLinks.classList.remove('open');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
  }

  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 300) {
        scrollTopBtn.classList.add('show');
      } else {
        scrollTopBtn.classList.remove('show');
      }
    });

    scrollTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (cookieBanner && cookieAccept) {
    const consent = localStorage.getItem('smd_cookie_consent');
    if (consent === 'accepted') {
      cookieBanner.classList.remove('show');
    } else {
      cookieBanner.classList.add('show');
    }

    cookieAccept.addEventListener('click', () => {
      localStorage.setItem('smd_cookie_consent', 'accepted');
      cookieBanner.classList.remove('show');
    });
  }
});