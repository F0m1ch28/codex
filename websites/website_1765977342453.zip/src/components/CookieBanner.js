import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('valentor_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('valentor_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <strong>Мы используем файлы cookie.</strong>
        <p>
          Они помогают нам улучшать сайт, анализируя его использование. Подробнее читайте в{' '}
          <Link to="/politika-fajlov-cookie">политике файлов cookie</Link>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
}

export default CookieBanner;