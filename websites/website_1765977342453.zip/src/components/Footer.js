import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.inner}>
        <div className={styles.brand}>
          <h3>Valentor Amicado</h3>
          <p>
            Персональный консалтинг, стратегия и сопровождение для тех, кто стремится к устойчивому
            росту и точным решениям.
          </p>
        </div>
        <div className={styles.links}>
          <h4>Навигация</h4>
          <ul>
            <li>
              <Link to="/">Главная</Link>
            </li>
            <li>
              <Link to="/uslugi">Услуги</Link>
            </li>
            <li>
              <Link to="/obo-mne">Обо мне</Link>
            </li>
            <li>
              <Link to="/kontakty">Контакты</Link>
            </li>
          </ul>
        </div>
        <div className={styles.legal}>
          <h4>Документы</h4>
          <ul>
            <li>
              <Link to="/usloviya-ispolzovaniya">Условия использования</Link>
            </li>
            <li>
              <Link to="/politika-konfidencialnosti">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/politika-fajlov-cookie">Политика файлов cookie</Link>
            </li>
          </ul>
        </div>
        <div className={styles.contacts}>
          <h4>Контакты</h4>
          <address>
            <span>г. Москва, ул. Тверская, д. 10, офис 45</span>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:contact@valentoramicado.site">contact@valentoramicado.site</a>
          </address>
          <div className={styles.socials} aria-label="Социальные сети">
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              in
            </a>
            <a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Telegram">
              t
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
              yt
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottomLine}>
        <p>© {new Date().getFullYear()} Valentor Amicado. Все права защищены.</p>
      </div>
    </footer>
  );
}

export default Footer;