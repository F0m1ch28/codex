import React, { useEffect, useState } from 'react';
import styles from './ScrollToTop.module.css';

function ScrollToTopButton() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    function toggleVisibility() {
      setIsVisible(window.scrollY > 320);
    }
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const handleScroll = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <button
      type="button"
      className={`${styles.scrollButton} ${isVisible ? styles.visible : ''}`}
      onClick={handleScroll}
      aria-label="Вернуться наверх"
    >
      ↑
    </button>
  );
}

export default ScrollToTopButton;