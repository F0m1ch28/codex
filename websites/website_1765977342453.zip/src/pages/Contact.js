import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Пожалуйста, укажите ваше имя.';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Укажите электронную почту для связи.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Похоже, что адрес почты указан некорректно.';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Опишите ваш запрос или вопрос.';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Пожалуйста, расскажите чуть подробнее (минимум 10 символов).';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setStatus('Ваш запрос отправлен. Я свяжусь с вами в ближайшее время.');
      setFormData({ name: '', email: '', message: '' });
    } else {
      setStatus(null);
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты — Valentor Amicado</title>
        <meta
          name="description"
          content="Свяжитесь с Valentor Amicado: Москва, ул. Тверская, д. 10, офис 45. Телефон +7 (495) 123-45-67, почта contact@valentoramicado.site."
        />
        <meta
          name="keywords"
          content="контакты, Valentor Amicado, консультация, запись, Москва"
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Давайте обсудим вашу задачу</h1>
        <p>
          Расскажите, что происходит в вашем проекте или команде. Найдём решение, которое поможет
          двигаться дальше уверенно и системно.
        </p>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.details}>
          <h2>Контактные данные</h2>
          <ul>
            <li>
              <strong>Адрес:</strong> г. Москва, ул. Тверская, д. 10, офис 45
            </li>
            <li>
              <strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            </li>
            <li>
              <strong>Email:</strong>{' '}
              <a href="mailto:contact@valentoramicado.site">contact@valentoramicado.site</a>
            </li>
          </ul>
          <p>
            Встречи проходят в гибридном формате: онлайн и офлайн. Перед личной встречей мы
            согласуем удобное время и уточним детали.
          </p>
        </div>

        <div className={styles.formWrapper}>
          <h2>Написать сообщение</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="name">Имя</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                placeholder="Как к вам обращаться?"
                aria-describedby={errors.name ? 'name-error' : undefined}
              />
              {errors.name && (
                <span id="name-error" className={styles.error}>
                  {errors.name}
                </span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="email">Электронная почта</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="your@email.com"
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && (
                <span id="email-error" className={styles.error}>
                  {errors.email}
                </span>
              )}
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="message">Сообщение</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                placeholder="Опишите свой запрос или вопрос"
                aria-describedby={errors.message ? 'message-error' : undefined}
              />
              {errors.message && (
                <span id="message-error" className={styles.error}>
                  {errors.message}
                </span>
              )}
            </div>

            <button type="submit" className={styles.submitButton}>
              Отправить
            </button>
            {status && <p className={styles.status}>{status}</p>}
          </form>
        </div>
      </section>
    </div>
  );
}

export default Contact;