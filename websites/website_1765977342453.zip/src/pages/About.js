import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Обо мне — Valentor Amicado</title>
        <meta
          name="description"
          content="История создания Valentor Amicado: опыт, ценности и подход к консалтингу и персональному сопровождению."
        />
        <meta
          name="keywords"
          content="Valentor Amicado, консалтинг, персональное развитие, стратегия, эффективность"
        />
      </Helmet>

      <section className={styles.intro}>
        <div className={styles.text}>
          <h1>Валентор Аммекадо — о пути и философии работы</h1>
          <p>
            Valentor Amicado — авторский консалтинговый проект, созданный для руководителей и
            экспертов, которым нужны гибкие и глубокие решения. Я объединяю стратегическое мышление,
            системный взгляд и человеческую эмпатию, чтобы поддерживать вас в моменты изменений.
          </p>
        </div>
        <div className={styles.photoGrid}>
          <div className={styles.photo} aria-hidden="true">
            <img
              src="https://picsum.photos/seed/valentor1/420/560"
              alt="Портрет консультанта Valentor Amicado"
            />
          </div>
          <div className={styles.photo} aria-hidden="true">
            <img
              src="https://picsum.photos/seed/valentor2/420/560"
              alt="Рабочий процесс: анализ и заметки"
            />
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <h2>Ценности, которые ведут вперёд</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Чистота намерений</h3>
            <p>
              В работе важна честность: я не обещаю волшебных решений, но всегда предлагаю то, что
              считаю лучшим именно для вас и вашей команды.
            </p>
          </article>
          <article>
            <h3>Комбинация глубины и простоты</h3>
            <p>
              Я умею переводить сложные аналитические модели на понятный язык, чтобы решения
              становились доступными и воспроизводимыми.
            </p>
          </article>
          <article>
            <h3>Ответственность за результат</h3>
            <p>
              Вкладываюсь в каждую задачу так, будто она моя собственная. Личная вовлечённость
              позволяет идти рядом и держать фокус.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.timeline}>
        <h2>Опорные точки пути</h2>
        <ul>
          <li>
            <span className={styles.year}>2008</span>
            <p>Первые проекты в корпоративном консалтинге и запуск отделов в крупных компаниях.</p>
          </li>
          <li>
            <span className={styles.year}>2014</span>
            <p>Работа с распространением стратегий в международных командах и наставничество для руководителей.</p>
          </li>
          <li>
            <span className={styles.year}>2018</span>
            <p>Создание авторских методик сопровождения и фасилитации управленческих решений.</p>
          </li>
          <li>
            <span className={styles.year}>2021</span>
            <p>Запуск проекта Valentor Amicado для индивидуальной работы с клиентами в России и за её пределами.</p>
          </li>
        </ul>
      </section>

      <section className={styles.philosophy}>
        <div className={styles.philosophyContent}>
          <h2>Философия взаимодействия</h2>
          <p>
            Я верю, что сильные решения рождаются в диалоге. Поэтому консультирование выстраивается
            на уважении, прозрачности и точном понимании вашей реальности. Вместе мы создаём
            пространство, где можно честно взглянуть на ситуацию, проверить гипотезы и выбрать
            оптимальную стратегию.
          </p>
          <p>
            Валентор — это не просто советник, а партнёр по росту. Я остаюсь рядом, пока новые
            подходы закрепляются и начинают приносить результат.
          </p>
        </div>
      </section>
    </div>
  );
}

export default About;