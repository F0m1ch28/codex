import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

function Home() {
  const services = [
    {
      title: 'Стратегический консалтинг',
      description:
        'Разрабатываю стратегии, которые учитывают контекст вашего бизнеса и обеспечивают измеримый прогресс.',
    },
    {
      title: 'Персональное сопровождение',
      description:
        'Помогаю руководителям выстроить устойчивые привычки, повысить эффективность и принимать уверенные решения.',
    },
    {
      title: 'Сложные переговоры',
      description:
        'Готовлю к переговорам, структурирую позицию и сопровождаю, чтобы вы достигали договорённостей без потерь.',
    },
  ];

  const benefits = [
    {
      title: 'Фокус на сути',
      description:
        'Чётко определяю ключевые вопросы, чтобы не распыляться и двигаться к результату короткими итерациями.',
    },
    {
      title: 'Методы, основанные на опыте',
      description:
        'Использую проверенные подходы консалтинга, дополняя их индивидуальными форматами работы.',
    },
    {
      title: 'Экологичные решения',
      description:
        'Учитываю ценности и ограничения клиента, чтобы решения оставались устойчивыми и реалистичными.',
    },
  ];

  const testimonials = [
    {
      name: 'Анна С., основатель образовательного проекта',
      feedback:
        '«Благодаря совместной работе я смогла усовершенствовать бизнес-модель и подготовиться к масштабированию без хаоса. Валентор помогает оставаться собранной и видеть картину целиком.»',
    },
    {
      name: 'Дмитрий П., операционный директор',
      feedback:
        '«Сессии помогают мгновенно структурировать мысли, находить выход из тупиковых ситуаций и сохранять спокойствие даже в пиковые периоды.»',
    },
    {
      name: 'Екатерина Л., руководитель агентства',
      feedback:
        '«Получила ясность в вопросах команды, перераспределила зону ответственности и наконец-то вернула себе время на стратегию.»',
    },
  ];

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Valentor Amicado — консалтинг и персональные решения</title>
        <meta
          name="description"
          content="Valentor Amicado помогает руководителям и экспертам находить стратегию, повышать эффективность и устойчиво расти."
        />
        <meta
          name="keywords"
          content="консалтинг, персональный рост, решение проблем, стратегия, эффективность"
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>Консалтинг нового уровня</p>
          <h1>
            Стратегия и персональное сопровождение для тех, кто привык доводить дела до совершенства
          </h1>
          <p className={styles.subtitle}>
            Valentor Amicado помогает русскоязычным руководителям и экспертам выстраивать устойчивую
            стратегию, повышать эффективность и действовать уверенно в сложных ситуациях.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.heroCta}>
              Записаться на консультацию
            </Link>
            <Link to="/uslugi" className={styles.heroSecondary}>
              Узнать больше
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.servicesPreview}>
        <div className={styles.sectionHeader}>
          <h2>Чем я могу помочь</h2>
          <p>
            Работаю точечно с запросами, где требуется аналитика, стратегия и персональная поддержка.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          {services.map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/uslugi" className={styles.cardLink}>
                Подробнее →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.aboutTeaser}>
        <div className={styles.aboutImage} role="presentation" />
        <div className={styles.aboutContent}>
          <h2>Немного обо мне</h2>
          <p>
            Я работаю на пересечении стратегии, управленческого консалтинга и персонального
            наставничества. Моя задача — помочь вам увидеть новую траекторию роста и уверенно пройти
            по ней, сохраняя баланс.
          </p>
          <ul>
            <li>15+ лет управления проектами и командами</li>
            <li>Практика индивидуальной и командной фасилитации</li>
            <li>Работа с клиентами из России, Европы и Азии</li>
          </ul>
          <Link to="/obo-mne" className={styles.aboutLink}>
            Узнать историю Valentor Amicado
          </Link>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className={styles.sectionHeader}>
          <h2>Подход, на который можно опереться</h2>
          <p>
            Сочетаю аналитичность, человеческое участие и точные инструменты, чтобы вы получали
            результат без лишнего стресса.
          </p>
        </div>
        <div className={styles.benefitsGrid}>
          {benefits.map((item) => (
            <div key={item.title} className={styles.benefitCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.timeline}>
        <div className={styles.sectionHeader}>
          <h2>Как строится работа</h2>
          <p>Прозрачный процесс помогает сохранять контроль и движение вперёд.</p>
        </div>
        <ol className={styles.timelineList}>
          <li>
            <span className={styles.stage}>1</span>
            <div>
              <h3>Диагностика запроса</h3>
              <p>
                Погружаемся в контекст, формулируем ключевой вопрос и определяем критерии успеха.
              </p>
            </div>
          </li>
          <li>
            <span className={styles.stage}>2</span>
            <div>
              <h3>Стратегическая сессия</h3>
              <p>
                Создаём карту решений, выделяем приоритеты, планируем шаги на ближайший период.
              </p>
            </div>
          </li>
          <li>
            <span className={styles.stage}>3</span>
            <div>
              <h3>Сопровождение и поддержка</h3>
              <p>
                Отслеживаем прогресс, корректируем стратегию и укрепляем новые управленческие
                навыки.
              </p>
            </div>
          </li>
        </ol>
      </section>

      <section className={styles.testimonials}>
        <div className={styles.sectionHeader}>
          <h2>Истории успеха клиентов</h2>
          <p>Тёплые отзывы людей, которые доверили мне сложные задачи и нашли решение.</p>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((item) => (
            <blockquote key={item.name} className={styles.testimonialCard}>
              <img
                src="https://picsum.photos/seed/amicado/96"
                alt=""
                loading="lazy"
                aria-hidden="true"
              />
              <p className={styles.quote}>{item.feedback}</p>
              <cite>{item.name}</cite>
            </blockquote>
          ))}
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className={styles.finalContent}>
          <h2>Готовы двигаться вперёд?</h2>
          <p>
            Давайте обсудим вашу задачу и найдём решение, которое даст устойчивый результат без
            перегрузки команды и вас лично.
          </p>
          <Link to="/kontakty" className={styles.finalButton}>
            Связаться и обсудить запрос
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Home;