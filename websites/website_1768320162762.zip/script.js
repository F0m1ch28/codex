document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 768) {
                navToggle.classList.remove('active');
                navMenu.classList.remove('active');
            }
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const cookieButtons = cookieBanner.querySelectorAll('.cookie-choice');
        const savedChoice = localStorage.getItem('friaryCookieChoice');
        if (savedChoice) {
            cookieBanner.classList.add('hidden');
        }
        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const choice = button.dataset.choice;
                localStorage.setItem('friaryCookieChoice', choice);
                cookieBanner.classList.add('hidden');
            });
        });
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            window.location.href = 'thanks.html';
        });
    }

    const subscribeForm = document.getElementById('subscribe-form');
    if (subscribeForm) {
        subscribeForm.addEventListener('submit', event => {
            event.preventDefault();
            window.location.href = 'thanks.html';
        });
    }

    const postsGrid = document.querySelector('.posts-grid');
    if (postsGrid) {
        const postCards = Array.from(postsGrid.querySelectorAll('.post-card'));
        const searchInput = document.querySelector('input[type="search"]');
        const filterButtons = document.querySelectorAll('.filter-buttons button');
        const paginationContainer = document.getElementById('pagination');
        const itemsPerPage = 6;
        let currentPage = 1;
        let activeCategory = 'all';
        let searchTerm = '';

        const applyFilters = () => {
            return postCards.filter(card => {
                const matchesCategory = activeCategory === 'all' || card.dataset.category === activeCategory;
                const title = card.querySelector('.article-title')?.textContent.toLowerCase() || '';
                const summary = card.querySelector('.article-excerpt')?.textContent.toLowerCase() || '';
                const matchesSearch = title.includes(searchTerm) || summary.includes(searchTerm);
                return matchesCategory && matchesSearch;
            });
        };

        const renderPagination = totalItems => {
            if (!paginationContainer) return;
            paginationContainer.innerHTML = '';
            const totalPages = Math.max(1, Math.ceil(totalItems / itemsPerPage));
            if (currentPage > totalPages) currentPage = totalPages;

            for (let i = 1; i <= totalPages; i++) {
                const button = document.createElement('button');
                button.textContent = i;
                if (i === currentPage) {
                    button.classList.add('active');
                }
                button.addEventListener('click', () => {
                    currentPage = i;
                    renderPosts();
                });
                paginationContainer.appendChild(button);
            }
        };

        const renderPosts = () => {
            const filtered = applyFilters();
            postCards.forEach(card => {
                card.style.display = 'none';
            });
            const start = (currentPage - 1) * itemsPerPage;
            const end = start + itemsPerPage;
            filtered.slice(start, end).forEach(card => {
                card.style.display = 'grid';
            });
            renderPagination(filtered.length);
        };

        if (searchInput) {
            searchInput.addEventListener('input', event => {
                searchTerm = event.target.value.trim().toLowerCase();
                currentPage = 1;
                renderPosts();
            });
        }

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                activeCategory = button.dataset.category;
                currentPage = 1;
                renderPosts();
            });
        });

        renderPosts();
    }
});