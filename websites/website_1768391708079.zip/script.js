document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNavigation = document.querySelector('.site-navigation');
    const navLinks = document.querySelectorAll('.site-navigation a');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAccept = document.getElementById('cookie-accept');
    const cookieDecline = document.getElementById('cookie-decline');
    const COOKIE_STORAGE_KEY = 'sdc-cookie-consent';

    if (navToggle && siteNavigation) {
        navToggle.addEventListener('click', () => {
            const isOpen = siteNavigation.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen);
            navToggle.classList.toggle('is-active', isOpen);
            document.body.style.overflow = isOpen ? 'hidden' : '';
        });

        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768 && siteNavigation.classList.contains('is-open')) {
                    siteNavigation.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                    navToggle.classList.remove('is-active');
                    document.body.style.overflow = '';
                }
            });
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth >= 768) {
                siteNavigation.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
                navToggle.classList.remove('is-active');
                document.body.style.overflow = '';
            }
        });
    }

    if (cookieBanner && cookieAccept && cookieDecline) {
        const consent = localStorage.getItem(COOKIE_STORAGE_KEY);
        if (!consent) {
            cookieBanner.classList.add('visible');
        }

        const setConsent = (value) => {
            localStorage.setItem(COOKIE_STORAGE_KEY, value);
            cookieBanner.classList.remove('visible');
        };

        cookieAccept.addEventListener('click', () => setConsent('accepted'));
        cookieDecline.addEventListener('click', () => setConsent('declined'));
    }
});