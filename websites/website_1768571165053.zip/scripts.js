document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-links a');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navToggle.classList.toggle('active');
            siteNav.classList.toggle('open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('open')) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    navToggle.classList.remove('active');
                    siteNav.classList.remove('open');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const customizeBtn = document.querySelector('.cookie-customize');
    const storageKey = 'aromatsngj-cookie-choice';

    if (cookieBanner) {
        const storedChoice = localStorage.getItem(storageKey);
        if (!storedChoice) {
            requestAnimationFrame(() => cookieBanner.classList.add('show'));
        }

        const setChoice = (choice) => {
            localStorage.setItem(storageKey, choice);
            cookieBanner.classList.remove('show');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => setChoice('accepted'));
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => setChoice('declined'));
        }

        if (customizeBtn) {
            customizeBtn.addEventListener('click', () => {
                setChoice('customize');
                window.location.href = 'cookies.html#management';
            });
        }
    }
});