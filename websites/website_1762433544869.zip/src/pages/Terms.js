import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Termini e Condizioni | AECD</title>
      <meta
        name="description"
        content="Termini e condizioni di utilizzo del sito e dei servizi formativi dell’Accademia Europea di Comunicazione Digitale."
      />
    </Helmet>
    <section className={styles.container}>
      <h1>Termini e Condizioni</h1>
      <p>
        Il presente documento disciplina l&apos;utilizzo del sito e dei servizi offerti da Accademia Europea di
        Comunicazione Digitale (AECD). L&apos;accesso al sito implica l&apos;accettazione integrale dei termini qui
        riportati.
      </p>
      <h2>1. Servizi offerti</h2>
      <p>
        AECD propone percorsi di formazione professionale online dedicati a branding, content strategy, analisi dei dati
        e comunicazione digitale. I contenuti sono destinati a professionisti e organizzazioni che desiderano sviluppare
        competenze avanzate.
      </p>
      <h2>2. Diritti di proprietà intellettuale</h2>
      <p>
        Tutti i materiali formativi, inclusi testi, immagini, video, esercitazioni e strumenti, sono protetti dalla
        normativa sul diritto d&apos;autore. È vietata la riproduzione senza autorizzazione scritta dell&apos;Accademia.
      </p>
      <h2>3. Utilizzo del sito</h2>
      <p>
        L&apos;utente si impegna a utilizzare il sito in modo conforme alla legge e a non porre in essere attività che
        possano compromettere il funzionamento della piattaforma o la sicurezza dei dati.
      </p>
      <h2>4. Responsabilità</h2>
      <p>
        AECD adotta sistemi di controllo per garantire l’accuratezza dei contenuti. Eventuali errori saranno corretti con
        tempestività. L&apos;Accademia non è responsabile per disservizi causati da fattori esterni o da uso improprio dei
        materiali da parte dell&apos;utente.
      </p>
      <h2>5. Modifiche</h2>
      <p>
        AECD si riserva la facoltà di aggiornare i presenti termini. Le modifiche saranno comunicate sul sito e avranno
        effetto dalla data di pubblicazione.
      </p>
    </section>
  </>
);

export default Terms;