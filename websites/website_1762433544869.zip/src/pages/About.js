import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>Chi Siamo | Accademia Europea di Comunicazione Digitale</title>
      <meta
        name="description"
        content="Conosci la missione di AECD, la nostra visione sulla formazione digitale, l’approccio didattico e il team multidisciplinare di mentor."
      />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <p className={styles.kicker}>Chi Siamo</p>
        <h1>Innovazione, metodo e cultura data-driven</h1>
        <p>
          L&apos;Accademia Europea di Comunicazione Digitale nasce a Milano con l&apos;obiettivo di unire business intelligence,
          marketing e content strategy. Offriamo percorsi di crescita pensati per professionisti che desiderano portare
          nelle loro organizzazioni una cultura decisionale guidata dai dati e dalla creatività.
        </p>
      </div>
      <img src="https://picsum.photos/800/600?random=31" alt="Team collaborativo in un laboratorio digitale" loading="lazy" />
    </section>

    <section className={styles.values}>
      <div>
        <h2>La nostra visione</h2>
        <p>
          Crediamo che i dati abbiano senso solo se trasformati in storie rilevanti. Per questo connettiamo competenze analitiche e narrative, abilitando i partecipanti a progettare ecosistemi digitali coerenti, misurabili e scalabili.
        </p>
      </div>
      <div className={styles.grid}>
        <article>
          <h3>Ricerca continua</h3>
          <p>
            Monitoriamo trend europei su customer intelligence, tecnologie marketing e content performance per aggiornare
            costantemente i moduli formativi.
          </p>
        </article>
        <article>
          <h3>Mentorship personalizzata</h3>
          <p>
            Ogni partecipante riceve coaching dedicato: sessioni di feedback, revisione progetti e supporto per trasferire
            il metodo all’interno dell’azienda.
          </p>
        </article>
        <article>
          <h3>Comunità professionale</h3>
          <p>
            Una rete di alumni e partner con cui confrontarsi, condividere strumenti, co-creare progetti e aprire nuove
            collaborazioni internazionali.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.team}>
      <h2>Team Direttivo</h2>
      <div className={styles.teamGrid}>
        <article>
          <img src="https://picsum.photos/400/400?random=51" alt="Direttrice accademica durante una presentazione" loading="lazy" />
          <h3>Sara De Angelis</h3>
          <p>Direttrice Accademica</p>
          <span>Esperta in business intelligence, ha coordinato progetti di trasformazione digitale per gruppi internazionali.</span>
        </article>
        <article>
          <img src="https://picsum.photos/400/400?random=52" alt="Responsabile della strategia digitale" loading="lazy" />
          <h3>Andrea Morelli</h3>
          <p>Responsabile Strategia Digitale</p>
          <span>Connette analisi dati e branding multicanale, guidando la progettazione dei laboratori esperienziali.</span>
        </article>
        <article>
          <img src="https://picsum.photos/400/400?random=53" alt="Coordinatrice di progetto digitale" loading="lazy" />
          <h3>Elisa Conti</h3>
          <p>Program Manager</p>
          <span>Coordina mentor e partner, curando l’integrazione di moduli su coding, marketing e content operations.</span>
        </article>
      </div>
    </section>
  </>
);

export default About;