import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Corsi | Branding Online e Content Strategy</title>
      <meta
        name="description"
        content="Panoramica dei corsi avanzati AECD: pubblicità targetizzata, coding e data automation, social media marketing evoluto e laboratori di business intelligence."
      />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <p className={styles.kicker}>Corsi avanzati</p>
        <h1>Percorsi integrati di formazione digitale</h1>
        <p>
          Ogni corso combina analisi dei dati, pratica laboratoriale e mentoring professionale. L’obiettivo è trasformare
          insight e storytelling in leve concrete per crescita e posizionamento.
        </p>
      </div>
    </section>

    <section className={styles.modules}>
      <article>
        <h2>Branding Data-Driven</h2>
        <p>
          Analisi di audience, creazione di brand framework e storytelling con metriche misurabili. Introduzione all’uso
          di algoritmi di clustering e analisi semantica per definire messaggi omnicanale.
        </p>
      </article>
      <article>
        <h2>Content Strategy & Automation</h2>
        <p>
          Workflow avanzati di content design, progettazione di calendar editoriali con strumenti collaborativi e
          automazioni per mantenere i dati aggiornati e consistenti.
        </p>
      </article>
      <article>
        <h2>Social Media Marketing Evoluto</h2>
        <p>
          Analisi di piattaforme, social listening, definizione di KPI e ottimizzazione delle community con modelli di
          engagement e sperimentazione di nuovi formati.
        </p>
      </article>
      <article>
        <h2>Ads Intelligence</h2>
        <p>
          Pianificazione e analisi di campagne Meta, Google e LinkedIn con dashboard che uniscono performance, sentiment e
          indicatori di brand lift.
        </p>
      </article>
    </section>

    <section className={styles.focus}>
      <div>
        <h2>Strumenti e piattaforme</h2>
        <ul>
          <li>Suite BI e Data Visualization (Looker Studio, Power BI, Tableau)</li>
          <li>Marketing automation e CRM</li>
          <li>Librerie per analisi dati (Python, JavaScript, SQL)</li>
          <li>Strumenti SEO e di social listening</li>
        </ul>
      </div>
      <div>
        <h2>Competenze trasversali</h2>
        <ul>
          <li>Decision-making basato sui dati</li>
          <li>Collaborazione cross-funzionale</li>
          <li>Storytelling e copywriting strategico</li>
          <li>Project management agile</li>
        </ul>
      </div>
    </section>
  </>
);

export default Services;