import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | AECD</title>
      <meta
        name="description"
        content="Informazioni sui cookie utilizzati dal sito dell’Accademia Europea di Comunicazione Digitale e istruzioni per la loro gestione."
      />
    </Helmet>
    <section className={styles.container}>
      <h1>Cookie Policy</h1>
      <p>
        Il sito di Accademia Europea di Comunicazione Digitale utilizza cookie tecnici e, previa autorizzazione, cookie di
        analisi per monitorare il traffico e ottimizzare l&apos;esperienza d&apos;uso.
      </p>
      <h2>1. Cosa sono i cookie</h2>
      <p>
        I cookie sono piccoli file di testo che il sito invia al dispositivo dell&apos;utente per migliorare l&apos;uso
        della piattaforma e personalizzare i contenuti.
      </p>
      <h2>2. Cookie utilizzati</h2>
      <p>
        Utilizziamo cookie tecnici essenziali e strumenti analitici anonimizzati per studiare le interazioni con le
        pagine, migliorando le funzionalità e la qualità dei contenuti formativi.
      </p>
      <h2>3. Gestione dei cookie</h2>
      <p>
        È possibile configurare il browser per bloccare o eliminare i cookie. In caso di disattivazione, alcune
        funzionalità del sito potrebbero risultare limitate.
      </p>
    </section>
  </>
);

export default CookiePolicy;