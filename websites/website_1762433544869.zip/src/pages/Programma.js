import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programma.module.css';

const modules = [
  {
    title: 'Modulo 1 • Insight & Audience Intelligence',
    items: [
      'Metodologie di ricerca e design dei dati',
      'Segmentazione avanzata e profilazione comportamentale',
      'Mappe di empatia basate su insight quantitativi e qualitativi'
    ]
  },
  {
    title: 'Modulo 2 • Data Visualization & Dashboard',
    items: [
      'Principi di visual storytelling',
      'Creazione di dashboard interattive',
      'Monitoraggio KPI per branding, engagement e advocacy'
    ]
  },
  {
    title: 'Modulo 3 • Content Strategy & Governance',
    items: [
      'Framework per piani editoriali multicanale',
      'Content operations e workflow automation',
      'Misurazione dell’impatto e governance dei contenuti'
    ]
  },
  {
    title: 'Modulo 4 • Paid Media & Performance',
    items: [
      'Strategie omnicanale per campagne',
      'Test A/B, modelli di attribuzione, marketing mix',
      'Ottimizzazione continua con analisi predittiva'
    ]
  }
];

const Programma = () => (
  <>
    <Helmet>
      <title>Programma del Corso | AECD</title>
      <meta
        name="description"
        content="Scopri il programma completo del Corso Avanzato AECD: moduli su insight, data visualization, content strategy e paid media con approccio pratico."
      />
    </Helmet>
    <section className={styles.hero}>
      <div>
        <p className={styles.kicker}>Programma completo</p>
        <h1>Un percorso progettato per integrare dati, contenuti e tecnologia</h1>
        <p>
          Il programma è pensato per offrire competenze immediatamente applicabili. Ogni modulo combina teoria
          operativa, esercitazioni in team e project work su briefing reali.
        </p>
      </div>
    </section>

    <section className={styles.timeline}>
      {modules.map((module) => (
        <article key={module.title}>
          <div className={styles.dot} aria-hidden="true" />
          <h2>{module.title}</h2>
          <ul>
            {module.items.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </article>
      ))}
    </section>

    <section className={styles.outcome}>
      <div>
        <h2>Output finale</h2>
        <p>
          I partecipanti costruiscono un piano strategico completo, corredato da dashboard di monitoraggio, linee guida
          editoriali e roadmap di automazione. Il progetto viene discusso con la faculty per individuare passaggi di
          miglioramento e integrarlo nel contesto aziendale.
        </p>
      </div>
      <img src="https://picsum.photos/800/600?random=32" alt="Dashboard e documenti strategici su un tavolo di lavoro" loading="lazy" />
    </section>
  </>
);

export default Programma;