import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Informativa Privacy | AECD</title>
      <meta
        name="description"
        content="Informativa sul trattamento dei dati personali per i servizi formativi erogati dall’Accademia Europea di Comunicazione Digitale."
      />
    </Helmet>
    <section className={styles.container}>
      <h1>Informativa Privacy</h1>
      <p>
        Accademia Europea di Comunicazione Digitale (AECD) tutela i dati personali nel rispetto del Regolamento (UE)
        2016/679. La presente informativa illustra le modalità di raccolta, utilizzo e conservazione dei dati forniti
        dagli utenti.
      </p>
      <h2>1. Titolare del trattamento</h2>
      <p>
        AECD, con sede in Via Milano, 22, 20121 Milano MI. Per informazioni è possibile contattare il nostro ufficio
        privacy tramite il form alla pagina contatti.
      </p>
      <h2>2. Tipologie di dati trattati</h2>
      <p>
        Trattiamo dati identificativi e professionali forniti dagli utenti tramite moduli online, iscrizioni e interazioni
        con i servizi digitali dell&apos;Accademia.
      </p>
      <h2>3. Finalità del trattamento</h2>
      <p>
        I dati sono utilizzati per rispondere a richieste informative, gestire l&apos;accesso ai percorsi formativi,
        inviare comunicazioni operative e aggiornamenti sugli argomenti trattati.
      </p>
      <h2>4. Conservazione dei dati</h2>
      <p>
        I dati vengono conservati per il tempo strettamente necessario alle finalità per le quali sono stati raccolti e
        comunque nel rispetto degli obblighi di legge.
      </p>
      <h2>5. Diritti dell’interessato</h2>
      <p>
        Gli utenti possono esercitare i diritti di accesso, rettifica, cancellazione, limitazione e opposizione scrivendo
        ad AECD tramite il form contatti, indicando la richiesta.
      </p>
    </section>
  </>
);

export default Privacy;