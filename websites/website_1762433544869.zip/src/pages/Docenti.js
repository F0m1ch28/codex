import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Docenti.module.css';

const faculty = [
  {
    name: 'Giulia Bernardi',
    role: 'Data Strategist',
    desc: 'Specialista in business intelligence per il settore retail e fintech. Supporta i partecipanti nella definizione di dashboard e nella lettura degli insight.',
    image: 'https://picsum.photos/400/400?random=61'
  },
  {
    name: 'Marco Rossi',
    role: 'Lead Developer & Automation Expert',
    desc: 'Coordina i laboratori di coding, API marketing e data automation. Aiuta a creare workflow scalabili e integrazioni personalizzate.',
    image: 'https://picsum.photos/400/400?random=62'
  },
  {
    name: 'Chiara Fabbri',
    role: 'Content Strategy Consultant',
    desc: 'Consulente per brand internazionali, guida i moduli su storytelling, governance dei contenuti e misurazione delle performance.',
    image: 'https://picsum.photos/400/400?random=63'
  },
  {
    name: 'Davide Palmieri',
    role: 'Paid Media Specialist',
    desc: 'Esperto in pianificazione omnicanale, modelli di attribuzione e ottimizzazione dei media mix, con focus sulla misurazione del brand lift.',
    image: 'https://picsum.photos/400/400?random=64'
  }
];

const Docenti = () => (
  <>
    <Helmet>
      <title>Docenti e Mentor | AECD</title>
      <meta
        name="description"
        content="Conosci i docenti del Corso Avanzato AECD: professionisti attivi su analisi dati, coding, content strategy e social media marketing."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Docenti e Mentor</h1>
      <p>
        Un team multidisciplinare che unisce competenze tecniche e strategiche per accompagnare i partecipanti in ogni
        fase del percorso.
      </p>
    </section>
    <section className={styles.grid}>
      {faculty.map((member) => (
        <article key={member.name}>
          <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
          <h3>{member.name}</h3>
          <p className={styles.role}>{member.role}</p>
          <p>{member.desc}</p>
        </article>
      ))}
    </section>
  </>
);

export default Docenti;