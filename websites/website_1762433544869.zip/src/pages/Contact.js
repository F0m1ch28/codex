import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', company: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Inserisci il tuo nome.';
    if (!formData.email.trim()) {
      newErrors.email = 'Inserisci la tua email.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email non valida.';
    }
    if (!formData.message.trim()) newErrors.message = 'Scrivi un messaggio.';
    return newErrors;
  };

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => ({ ...prev, [e.target.name]: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
  };

  return (
    <>
      <Helmet>
        <title>Contatti | Accademia Europea di Comunicazione Digitale</title>
        <meta
          name="description"
          content="Contatta AECD per informazioni sul Corso Avanzato di Branding Online e Content Strategy. Via Milano, 22, Milano. Telefono +39 02 9456 8113."
        />
      </Helmet>
      <section className={styles.hero}>
        <div>
          <p className={styles.kicker}>Contatti</p>
          <h1>Costruiamo insieme il tuo percorso</h1>
          <p>
            Siamo pronti a supportarti nella definizione di obiettivi e competenze digitali per il tuo team o per la tua
            carriera. Compila il form e ti ricontatteremo al più presto.
          </p>
          <div className={styles.info}>
            <span>Via Milano, 22, 20121 Milano MI</span>
            <a href="tel:+390294568113">+39 02 9456 8113</a>
          </div>
        </div>
        <iframe
          title="Mappa della sede AECD a Milano"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2797.585271916204!2d9.186389476674173!3d45.47287563297873!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4786c6a4f8f2a61d%3A0x8e1a38f9d271e96a!2sVia%20Milano%2C%2022%2C%2020121%20Milano%20MI!5e0!3m2!1sit!2sit!4v1700000000000"
          loading="lazy"
          allowFullScreen=""
          aria-label="Mappa interattiva della sede"
        />
      </section>

      <section className={styles.formSection}>
        <form onSubmit={handleSubmit} noValidate>
          <div className={styles.field}>
            <label htmlFor="name">Nome e cognome</label>
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email professionale</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="company">Azienda / Organizzazione</label>
            <input
              id="company"
              name="company"
              type="text"
              value={formData.company}
              onChange={handleChange}
            />
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Messaggio</label>
            <textarea
              id="message"
              name="message"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit">Invia richiesta</button>
          {submitted && <p className={styles.success}>Grazie! Ti risponderemo entro due giorni lavorativi.</p>}
        </form>
      </section>
    </>
  );
};

export default Contact;