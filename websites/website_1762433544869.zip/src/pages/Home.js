import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Professionisti formati', target: 2400 },
  { label: 'Ore live e on-demand', target: 360 },
  { label: 'Case study internazionali', target: 58 },
  { label: 'Strumenti analizzati', target: 24 }
];

const processSteps = [
  {
    title: 'Assessment Strategico',
    description:
      'Analizziamo gli obiettivi del team e definiamo indicatori chiave legati a branding, lead qualification e reputazione digitale.'
  },
  {
    title: 'Laboratori Data-Driven',
    description:
      'Workshop interattivi su analisi dei dati, marketing automation e storytelling visivo con dashboard BI reali.'
  },
  {
    title: 'Content Intelligence',
    description:
      'Sviluppo di calendari editoriali ottimizzati con insight provenienti da social listening, SEO semantica e analisi predittiva.'
  },
  {
    title: 'Ottimizzazione Continua',
    description:
      'Misurazione delle performance con iterazioni guidate da metriche e feedback, sostenendo una cultura di miglioramento costante.'
  }
];

const courses = [
  {
    title: 'Pubblicità Targetizzata',
    description:
      'Campagne omnicanale con segmentazione avanzata, modelli di attribuzione e test A/B su ecosistemi Meta, Google e LinkedIn.',
    icon: '🎯'
  },
  {
    title: 'Coding & Data Automation',
    description:
      'Sviluppo di micro-servizi, tagging personalizzato e tracciamenti con JavaScript, Python e API di marketing intelligence.',
    icon: '💻'
  },
  {
    title: 'Social Media Marketing Evoluto',
    description:
      'Strategie narrative basate su insight, KPI di engagement e community management misurabile con strumenti di listening.',
    icon: '📊'
  }
];

const testimonials = [
  {
    quote:
      'Il laboratorio su business intelligence e contenuti mi ha permesso di consolidare un framework dati-narrativa applicabile subito nei progetti europei.',
    name: 'Francesca L. — Digital Strategist'
  },
  {
    quote:
      'La combinazione tra coding, marketing analitico e storytelling ha trasformato il modo in cui il nostro team interpreta i dati di comportamento.',
    name: 'Luca M. — Marketing Manager'
  },
  {
    quote:
      'Approccio estremamente pratico: dashboard BI, casi di studio e mentoring dedicato ci hanno guidati verso una content strategy allineata agli obiettivi.',
    name: 'Paola R. — Head of Communication'
  }
];

const projects = [
  { id: 1, title: 'Fintech Insight Map', category: 'Analisi Dati', image: 'https://picsum.photos/1200/800?random=41' },
  { id: 2, title: 'Retail Analytics Journey', category: 'Business Intelligence', image: 'https://picsum.photos/1200/800?random=42' },
  { id: 3, title: 'Editorial Intelligence Hub', category: 'Content Strategy', image: 'https://picsum.photos/1200/800?random=43' },
  { id: 4, title: 'Performance Branding Dashboard', category: 'Analisi Dati', image: 'https://picsum.photos/1200/800?random=44' }
];

const faqItems = [
  {
    question: 'Quali competenze digitali vengono sviluppate durante il corso?',
    answer:
      'Alleniamo competenze trasversali: analisi dei dati, business intelligence, content design, automazione di workflow, SEO e strategie per social media.'
  },
  {
    question: 'Il percorso prevede project work pratici?',
    answer:
      'Ogni modulo integra progetti applicativi basati su scenari reali, con feedback dei mentor per consolidare processi e deliverable.'
  },
  {
    question: 'Come viene supportata la trasformazione interna delle aziende?',
    answer:
      'Forniamo toolkit, canvas decisionali e sessioni dedicate al team per tradurre i dati in azioni strategiche condivise.'
  }
];

const blogPosts = [
  {
    title: 'Dashboard Human-Centric per i team marketing europei',
    excerpt:
      'Dalle metriche alla narrazione: come costruire una dashboard BI che guidi decisioni sulle campagne di branding digitale.',
    link: '/programma'
  },
  {
    title: 'Content Strategy e analisi predittiva: un nuovo equilibrio',
    excerpt:
      'Integrare forecasting, sentiment analysis e creatività per orchestrare esperienze coerenti lungo il journey del cliente.',
    link: '/corsi'
  },
  {
    title: 'Coding data-driven per rafforzare le strategie editoriali',
    excerpt:
      'Script, automazioni e controllo qualità per pianificare contenuti con dati sempre aggiornati e insight rapidi.',
    link: '/chi-siamo'
  }
];

const Home = () => {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [filter, setFilter] = useState('Tutti');
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const intervals = statsData.map((item, index) =>
      setInterval(() => {
        setStats((prev) => {
          const updated = [...prev];
          if (updated[index] < item.target) {
            const increment = Math.ceil(item.target / 80);
            updated[index] = Math.min(updated[index] + increment, item.target);
          }
          return updated;
        });
      }, 40)
    );
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects = useMemo(() => {
    if (filter === 'Tutti') return projects;
    return projects.filter((project) => project.category === filter);
  }, [filter]);

  const toggleFaq = (index) => {
    setExpandedFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <Helmet>
        <title>AECD | Corso Avanzato Branding Online e Content Strategy</title>
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>Corso Avanzato • Branding Online & Content Strategy</p>
          <h1>Trasforma la Tua Carriera Digitale</h1>
          <p>
            Un percorso europeo per connettere analisi dei dati, creatività e tecnologie emergenti. Guidiamo professionisti e aziende a progettare esperienze digitali misurabili e storytelling data-driven.
          </p>
          <div className={styles.heroActions}>
            <Link to="/corsi" className={styles.primaryBtn}>
              Scopri il percorso
            </Link>
            <Link to="/programma" className={styles.secondaryBtn}>
              Esplora il programma
            </Link>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=11"
            alt="Team di professionisti che analizzano dashboard digitali"
            loading="lazy"
          />
        </div>
      </section>

      <section className={styles.intro}>
        <div className={styles.introText}>
          <h2>Accademia Europea di Comunicazione Digitale</h2>
          <p>
            Lavoriamo con manager, consulenti e creativi per costruire una cultura digitale orientata ai dati. Il nostro Corso Avanzato di Branding Online e Content Strategy combina business intelligence, coding e storytelling per definire strategie realmente orientate al cliente.
          </p>
          <p>
            Ogni modulo integra analisi quantitativa, insight qualitativi e framework di decision-making. I partecipanti sperimentano strumenti all’avanguardia e metodologie collaborative per prototipare contenuti, monitorare performance e guidare trasformazioni interne.
          </p>
        </div>
        <div className={styles.introHighlights}>
          <div>
            <h3>Missione</h3>
            <p>Potenziare le competenze digitali europee attraverso apprendimento continuo, sperimentazione e mentorship personalizzata.</p>
          </div>
          <div>
            <h3>Approccio</h3>
            <p>Moduli sincroni e asincroni, casi studio internazionali, community professionale e supporto one-to-one per attivare l’innovazione.</p>
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Statistiche del corso">
        {statsData.map((item, index) => (
          <div key={item.label} className={styles.statCard}>
            <span>{stats[index]}</span>
            <p>{item.label}</p>
          </div>
        ))}
      </section>

      <section className={styles.courses} id="corsi" aria-label="Corsi principali">
        <div className={styles.sectionHeader}>
          <h2>Corsi e Percorsi Specialistici</h2>
          <p>Strutture modulari per coordinare marketing, contenuti e technology enablement con indicatori concreti.</p>
        </div>
        <div className={styles.courseGrid}>
          {courses.map((course) => (
            <article key={course.title} className={styles.courseCard}>
              <span className={styles.icon} aria-hidden="true">
                {course.icon}
              </span>
              <h3>{course.title}</h3>
              <p>{course.description}</p>
              <Link to="/programma" aria-label={`Approfondisci ${course.title}`}>
                Dettagli modulo →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-label="Come funziona il percorso">
        <div className={styles.sectionHeader}>
          <h2>Come Funziona il Percorso</h2>
          <p>Dalla diagnosi strategica alla costruzione di esperienze digitali misurabili, con supporto continuo dei mentor.</p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step, index) => (
            <div key={step.title} className={styles.processCard}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.why} aria-label="Perché scegliere l'accademia">
        <div className={styles.sectionHeader}>
          <h2>Perché Sceglierci</h2>
          <p>Mettiamo al centro l’apprendimento esperienziale e la sperimentazione con i dati per decisioni condivise.</p>
        </div>
        <div className={styles.whyGrid}>
          <div>
            <h3>Mentor con esperienza internazionale</h3>
            <p>Professionisti attivi in aziende europee, con focus su analisi dati, strategic design e content operations.</p>
          </div>
          <div>
            <h3>Toolkit operativi pronti all’uso</h3>
            <p>Canvas di strategia, checklist per social media marketing, script di automazione e librerie per dashboard.</p>
          </div>
          <div>
            <h3>Community professionale</h3>
            <p>Sessioni di confronto, roundtable tematiche e mentorship tra pari per alimentare la crescita continua.</p>
          </div>
          <div>
            <h3>Allineamento con obiettivi aziendali</h3>
            <p>Ogni progetto viene collegato ai KPI di branding, generazione lead e customer experience con metriche trasparenti.</p>
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Testimonianze">
        <div className={styles.sectionHeader}>
          <h2>Testimonianze dei Partecipanti</h2>
          <p>Esperienze di professionisti che hanno trasformato il proprio approccio alla comunicazione digitale.</p>
        </div>
        <div className={styles.testimonialCard}>
          <p>&ldquo;{testimonials[testimonialIndex].quote}&rdquo;</p>
          <span>{testimonials[testimonialIndex].name}</span>
          <div className={styles.dots}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={index === testimonialIndex ? styles.activeDot : ''}
                aria-label={`Mostra testimonianza ${index + 1}`}
                onClick={() => setTestimonialIndex(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-label="Progetti e case study">
        <div className={styles.sectionHeader}>
          <h2>Case Study e Progetti</h2>
          <p>Applichiamo framework data-driven su scenari reali per generare impatti concreti.</p>
        </div>
        <div className={styles.filterBar}>
          {['Tutti', 'Analisi Dati', 'Business Intelligence', 'Content Strategy'].map((category) => (
            <button
              key={category}
              className={filter === category ? styles.activeFilter : ''}
              onClick={() => setFilter(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article key={project.id} className={styles.projectCard}>
              <div className={styles.projectImage}>
                <img src={project.image} alt={`Case study ${project.title}`} loading="lazy" />
              </div>
              <div className={styles.projectContent}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <Link to="/programma">Esplora il caso studio →</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-label="Domande frequenti">
        <div className={styles.sectionHeader}>
          <h2>Domande Frequenti</h2>
          <p>Informazioni utili per orientarsi nel percorso avanzato.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div key={item.question} className={styles.faqItem}>
              <button onClick={() => toggleFaq(index)} aria-expanded={expandedFaq === index}>
                <span>{item.question}</span>
                <span>{expandedFaq === index ? '−' : '+'}</span>
              </button>
              {expandedFaq === index && <p>{item.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className={styles.blog} aria-label="Ultimi approfondimenti">
        <div className={styles.sectionHeader}>
          <h2>Insight dal nostro laboratorio</h2>
          <p>Ricerca, analisi e sperimentazione sugli ecosistemi digitali europei.</p>
        </div>
        <div className={styles.blogGrid}>
          {blogPosts.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src="https://picsum.photos/800/600?random=21" alt="Analisi digitale su schermo professionale" loading="lazy" />
              <div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link}>Leggi l’approfondimento →</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta} aria-label="Call to action">
        <div className={styles.ctaContent}>
          <h2>Inizia Oggi</h2>
          <p>
            Unisciti alla community di professionisti che uniscono dati, tecnologia e storytelling per guidare la trasformazione digitale delle aziende europee.
          </p>
          <Link to="/contatti" className={styles.primaryBtn}>
            Richiedi una sessione di orientamento
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;