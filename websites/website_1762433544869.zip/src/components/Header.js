import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsOpen((prev) => !prev);
  const closeMenu = () => setIsOpen(false);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Intestazione principale">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Accademia Europea di Comunicazione Digitale">
          <span className={styles.logoAccent}>AE</span>CD
        </NavLink>
        <nav className={`${styles.nav} ${isOpen ? styles.open : ''}`} aria-label="Navigazione principale">
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Home
          </NavLink>
          <NavLink to="/chi-siamo" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Chi Siamo
          </NavLink>
          <NavLink to="/corsi" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Corsi
          </NavLink>
          <NavLink to="/programma" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Programma
          </NavLink>
          <NavLink to="/docenti" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Docenti
          </NavLink>
          <NavLink to="/contatti" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Contatti
          </NavLink>
        </nav>
        <button
          className={`${styles.burger} ${isOpen ? styles.burgerOpen : ''}`}
          onClick={toggleMenu}
          aria-label="Apri menu di navigazione"
          aria-expanded={isOpen}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;