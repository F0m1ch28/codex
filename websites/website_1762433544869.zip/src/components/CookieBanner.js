import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Informativa sui cookie">
      <p>
        Utilizziamo cookie essenziali per ottimizzare l&apos;esperienza, analizzare le performance e perfezionare i
        contenuti formativi. Per sapere di più consulta la nostra{' '}
        <a href="/cookie-policy">Cookie Policy</a>.
      </p>
      <button onClick={handleAccept}>Accetto</button>
    </div>
  );
};

export default CookieBanner;