import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Piè di pagina">
    <div className={styles.wrapper}>
      <div className={styles.brand}>
        <h3>Accademia Europea di Comunicazione Digitale</h3>
        <p>
          Centro di formazione online con focus su business intelligence, branding digitale e strategie basate sui dati
          per professionisti e team aziendali.
        </p>
        <div className={styles.contactInfo}>
          <span>Via Milano, 22, 20121 Milano MI</span>
          <a href="tel:+390294568113">+39 02 9456 8113</a>
        </div>
      </div>
      <div className={styles.links}>
        <h4>Esplora</h4>
        <NavLink to="/chi-siamo">Chi Siamo</NavLink>
        <NavLink to="/corsi">Corsi</NavLink>
        <NavLink to="/programma">Programma</NavLink>
        <NavLink to="/docenti">Docenti</NavLink>
        <NavLink to="/contatti">Contatti</NavLink>
      </div>
      <div className={styles.legal}>
        <h4>Informazioni</h4>
        <NavLink to="/termini">Termini</NavLink>
        <NavLink to="/privacy">Privacy</NavLink>
        <NavLink to="/cookie-policy">Cookie Policy</NavLink>
        <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
          LinkedIn
        </a>
      </div>
      <div className={styles.newsletter}>
        <h4>Aggiornamenti</h4>
        <p>Ricevi idee e ricerche su data-driven marketing e content intelligence.</p>
        <form className={styles.form} aria-label="Iscrizione newsletter">
          <label htmlFor="newsletter-email" className="sr-only">
            Email
          </label>
          <input id="newsletter-email" type="email" placeholder="La tua email" aria-required="true" />
          <button type="submit">Iscriviti</button>
        </form>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>&copy; {new Date().getFullYear()} Accademia Europea di Comunicazione Digitale. Tutti i diritti riservati.</p>
    </div>
  </footer>
);

export default Footer;