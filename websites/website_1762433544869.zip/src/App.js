import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Programma from './pages/Programma';
import Docenti from './pages/Docenti';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const App = () => {
  const location = useLocation();

  return (
    <>
      <Helmet>
        <html lang="it" />
        <title>Accademia Europea di Comunicazione Digitale | Branding Online e Content Strategy</title>
        <meta
          name="description"
          content="Corso avanzato di branding online e content strategy a Milano. Formazione digitale su analisi dei dati, business intelligence e social media marketing per professionisti e aziende."
        />
        <meta
          name="keywords"
          content="corsi online Italia, pubblicità targetizzata, corso coding Milano, social media marketing, formazione digitale, corsi SMM, SEO, imparare programmazione, Facebook Ads, Instagram marketing, sviluppo web"
        />
        <meta property="og:title" content="Accademia Europea di Comunicazione Digitale" />
        <meta
          property="og:description"
          content="Accademia professionale italiana specializzata in branding online, content strategy e business intelligence."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`https://www.aecd.it${location.pathname}`} />
      </Helmet>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/chi-siamo" element={<About />} />
          <Route path="/corsi" element={<Services />} />
          <Route path="/programma" element={<Programma />} />
          <Route path="/docenti" element={<Docenti />} />
          <Route path="/contatti" element={<Contact />} />
          <Route path="/termini" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTopButton />
    </>
  );
};

export default App;