const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const I18N = {
  fr: {
    // Common
    brand_name: "danswholesaleplants",
    nav_home: "Accueil",
    nav_services: "Analyses",
    nav_about: "À propos",
    nav_blog: "Blog",
    nav_faq: "FAQ",
    nav_contact: "Contact",
    lang_fr: "FR",
    lang_en: "EN",
    aria_nav_toggle: "Ouvrir ou fermer la navigation",
    footer_tagline: "Observatoire analytique pour l'orientation spatiale et la signalétique numérique.",
    footer_phone: "Téléphone : +32 2 808 34 55",
    footer_email: "Courriel : contact@danswholesaleplants.com",
    footer_address: "Rue de la Loi 200, 1040 Bruxelles, Belgique",
    legal_terms: "Conditions",
    legal_privacy: "Confidentialité",
    legal_cookies: "Cookies",
    legal_refund: "Politique de remboursement",
    legal_disclaimer: "Avertissement",
    footer_year: "© {year} danswholesaleplants. Analyses spatiales depuis Bruxelles.",
    cookie_message: "Nous utilisons un suivi analytique minimal pour comprendre la navigation sur ces ressources.",
    cookie_more: "Préférences cookies",
    cookie_accept: "Accepter",
    toast_form_success: "Données du formulaire prêtes. Redirection vers la confirmation.",
    toast_close: "Fermer",
    // Meta
    meta_home_title: "danswholesaleplants | Observatoire de l’orientation spatiale",
    meta_home_desc: "Plateforme bilingue dédiée à l’analyse de la signalétique numérique, de la mobilité piétonne et de la cartographie des espaces publics en Belgique.",
    meta_services_title: "Capacités analytiques · danswholesaleplants",
    meta_services_desc: "Présentation des axes de recherche consacrés à l’orientation spatiale, à la signalétique numérique et à l’accessibilité dans les infrastructures belges.",
    meta_about_title: "Origines et méthode · danswholesaleplants",
    meta_about_desc: "Comprendre l’histoire, les piliers et la méthodologie de l’équipe danswholesaleplants pour étudier la navigation intérieure.",
    meta_blog_title: "Journal d’orientation spatiale · danswholesaleplants",
    meta_blog_desc: "Articles de fond sur la signalétique numérique, la cartographie des espaces complexes et l’expérience piétonne.",
    meta_post1_title: "Strates de synthèse pour la navigation multimodale | danswholesaleplants",
    meta_post1_desc: "Analyse détaillée de la coordination sensorielle et des interfaces numériques dans les bâtiments publics belges.",
    meta_post2_title: "Audits de cycle de vie pour la signalétique numérique | danswholesaleplants",
    meta_post2_desc: "Étude sur la maintenance, la gouvernance et l’accessibilité des réseaux d’affichage dans les pôles de transport.",
    meta_post3_title: "Orientation inclusive pour les campus civiques | danswholesaleplants",
    meta_post3_desc: "Exploration des approches participatives pour guider des communautés variées sur des sites étendus.",
    meta_contact_title: "Contact · danswholesaleplants",
    meta_contact_desc: "Coordonnées et formulaire pour échanger autour des recherches en orientation spatiale en Belgique.",
    meta_faq_title: "Questions fréquentes · danswholesaleplants",
    meta_faq_desc: "Réponses aux questions relatives aux observations, aux méthodologies et au partage des informations.",
    meta_terms_title: "Conditions d’utilisation · danswholesaleplants",
    meta_terms_desc: "Cadre juridique encadrant l’utilisation des contenus publiés sur danswholesaleplants.",
    meta_privacy_title: "Politique de confidentialité · danswholesaleplants",
    meta_privacy_desc: "Description des traitements de données réalisés dans le cadre des activités éditoriales et de recherche.",
    meta_cookies_title: "Gestion des cookies · danswholesaleplants",
    meta_cookies_desc: "Informations sur les cookies et technologies similaires utilisés par la plateforme.",
    meta_refund_title: "Politique de remboursement · danswholesaleplants",
    meta_refund_desc: "Procédures relatives aux demandes de corrections ou d’ajustements de livrables non commerciaux.",
    meta_disclaimer_title: "Avertissement · danswholesaleplants",
    meta_disclaimer_desc: "Limites de responsabilité et nature purement informative des contenus publiés.",
    meta_thank_title: "Merci · danswholesaleplants",
    meta_thank_desc: "Confirmation d’envoi pour les messages adressés à l’équipe danswholesaleplants.",
    // Home
    home_hero_label: "Carnet d’observation",
    home_hero_title: "Interpréter la signalétique numérique pour des environnements belges complexes",
    home_hero_description: "Nous documentons la manière dont signalétique, architecture et flux piétons s’entrelacent dans les bâtiments publics. Les analyses croisent observations de terrain, entretiens avec les équipes et mesures lumineuses ou sonores.",
    home_hero_caption: "Salle de supervision d’un pôle multimodal à Bruxelles.",
    home_stat1_content: "<strong>48 couloirs cartographiés</strong><span>Expérimentations d’interfaces documentées depuis 2021</span>",
    home_stat2_content: "<strong>12 visites par trimestre</strong><span>Cycles itératifs dans des campus civiques</span>",
    home_stat3_content: "<strong>6 lentilles d’analyse</strong><span>Accessibilité, flux, ergonomie, données, média, gouvernance</span>",
    home_hero_img_alt: "Mur de signalétique numérique dans un nœud de transport belge",
    home_features_label: "Cadres",
    home_features_title: "Lire l’orientation spatiale par couches pluridisciplinaires",
    home_features_desc: "Chaque synthèse distille les comportements observés, l’ergonomie des interfaces et les contraintes d’infrastructure relevées dans les institutions belges.",
    home_feature1_content: "<h3>Diagnostics de mobilité piétonne</h3><p>Nous relevons discrètement les trajectoires, cartographions les boucles de circulation et catégorisons les points de décision révélant l’interprétation des signaux dans des bâtiments denses.</p>",
    home_feature2_content: "<h3>Lisibilité de la signalétique numérique</h3><p>Contrastes, iconographie et règles de séquençage sont évalués et mis en regard des standards d’accessibilité adaptés à l’usage multilingue.</p>",
    home_feature3_content: "<h3>Revue cartographique adaptative</h3><p>Plans en strates et représentations tactiles sont comparés à l’usage réel afin de vérifier la synchronisation entre supports physiques et médias interactifs.</p>",
    home_feature4_content: "<h3>Gouvernance UX spatiale</h3><p>La documentation souligne les protocoles de maintenance et les rôles partagés qui maintiennent un guidage cohérent entre agences et partenaires.</p>",
    home_cartography_title: "Une cartographie interface vivante",
    home_cartography_desc: "Les artefacts cartographiques dans les institutions belges dépassent l’affiche statique : ils s’animent, se traduisent et s’ajustent aux parcours saisonniers.",
    home_cartography_point1: "Étiquetage multilingue testé avec les parties prenantes locales.",
    home_cartography_point2: "Surcouches dynamiques répondant aux fermetures temporaires ou aux densités de foule.",
    home_cartography_point3: "Boucles de retour reliant kiosques numériques et gestionnaires de site.",
    home_cartography_img_alt: "Chercheur comparant une carte interactive à l’environnement physique d’un bâtiment civique",
    home_cartography_caption: "Session itérative dans un complexe culturel à Gand.",
    home_recommendations_title: "Recommandations issues des dernières marches exploratoires",
    home_recommendations_desc: "Ces pistes structurées accompagnent les équipes de conception et d’exploitation sans prescrire de livrables commerciaux.",
    home_recommendation1_content: "<h3>Synchroniser canaux analogiques et numériques</h3><p>Vérifier si panneaux muraux, graphismes au sol et écrans se renforcent aux carrefours clés afin de réduire les signaux contradictoires.</p>",
    home_recommendation2_content: "<h3>Modéliser les flux lors des fermetures</h3><p>Simuler le détour des usagers quand un ascenseur ou un couloir est indisponible et s’assurer que la signalétique temporaire reflète des itinéraires accessibles.</p>",
    home_recommendation3_content: "<h3>Structurer la formation à la stewardship</h3><p>Outiller les équipes techniques avec des bibliothèques de motifs et des scénarios d’escalade pour ajuster rapidement les messages durant les événements.</p>",
    home_testimonials_title: "Témoignages des équipes partenaires",
    home_testimonials_desc: "Retours recueillis après des ateliers de co-conception dans des campus belges.",
    home_testimonial1_content: "<blockquote>« Les matrices de navigation ont aidé notre personnel à comprendre la manière dont les familles multilingues traversent l’atrium, révélant des frictions ignorées lors des précédentes rénovations. »</blockquote><figcaption>Anne-Lise Dupont · Coordinatrice mobilité, Bruxelles Environnement</figcaption>",
    home_testimonial2_content: "<blockquote>« Relier les données de signalétique aux journaux de maintenance a clarifié l’obsolescence ressentie de certains kiosques. Nous actualisons désormais les libellés en parallèle des interventions techniques. »</blockquote><figcaption>Joris Van de Walle · Stratège facility, Campus civique de Louvain</figcaption>",
    home_testimonial3_content: "<blockquote>« Leur documentation ne prescrit pas de fournisseurs ; elle suit les comportements, ce qui nous permet de défendre des améliorations progressives fondées sur des preuves. »</blockquote><figcaption>Sarah Bianchi · Responsable de programme, Réseau culturel liégeois</figcaption>",
    home_latest_title: "Mises à jour du blog",
    home_latest_desc: "Les articles approfondissent les écosystèmes de signalétique, l’éthique des données et la modélisation des flux.",
    home_latest_post1_meta: "Étude de terrain · 12 juin 2024",
    home_latest_post2_meta: "Audit de systèmes · 28 mai 2024",
    home_latest_post3_meta: "Perspective accessibilité · 16 avril 2024",
    home_latest_post1_excerpt: "Analyse des interactions sensorielles qui transforment des indications disparates en décisions piétonnes cohérentes.",
    home_latest_post2_excerpt: "Cartographie des cycles de maintenance et de gouvernance pour garder les écrans alignés sur les réalités opérationnelles.",
    home_latest_post3_excerpt: "Approche participative visant à rendre des campus étendus lisibles pour des communautés diverses.",
    home_latest_readmore: "Lire l’analyse complète",
    home_latest_img1_alt: "Analyste observant un tableau de bord de signalétique dans une zone de transport",
    home_latest_img2_alt: "Technicien vérifiant un écran d’information dans un hall de gare belge",
    home_latest_img3_alt: "Groupe en atelier cartographiant un campus civique sur une table lumineuse",
    // Services
    services_intro_label: "Capacités",
    services_intro_title: "Analyser les écosystèmes d’orientation au sein des infrastructures belges",
    services_intro_desc: "Nous examinons la signalétique numérique, les parcours piétons et la cartographie des espaces pour fournir un socle commun aux équipes techniques et expertes.",
    services_card1_content: "<h3>Inventaires des défis spatiaux</h3><p>Compilation de preuves décrivant les hésitations des visiteurs, l’interprétation des pictogrammes et les facteurs architecturaux perturbant la continuité.</p>",
    services_card2_content: "<h3>Recherche sur la signalétique numérique</h3><p>Benchmark des réseaux d’affichage concernant le temps d’attention, la hiérarchie des messages et la lisibilité multilingue.</p>",
    services_card3_content: "<h3>Discussions sur les parcours usagers</h3><p>Sessions de travail avec les équipes de terrain pour recueillir les récits de pointe, les itinéraires accessibles et les responsabilités partagées.</p>",
    services_card4_content: "<h3>Exploration du design informationnel</h3><p>Comparaison de schémas cartographiques, de pictogrammes et de typographies pour comprendre la médiation de l’attention.</p>",
    services_card5_content: "<h3>Revue technologique et accessibilité</h3><p>Évaluation des kiosques, couches QR et outils mobiles quant à leur réactivité, leurs affordances tactiles et leur conformité aux standards européens.</p>",
    services_process_title: "Approche",
    services_process_desc: "Chaque collaboration suit un cycle transparent reliant observation, synthèse et partage de connaissances contextualisées.",
    services_process_points: "<ol><li><strong>Immersion initiale</strong> — Parcours sur site pour relever frictions positionnelles, tonalité de signalétique et stimuli concurrents.</li><li><strong>Synthèse collaborative</strong> — Confrontation des constats aux données opérationnelles, aux plannings de maintenance et aux politiques linguistiques.</li><li><strong>Restitution contextualisée</strong> — Tableaux de bord, plans annotés et photographies servent de base à la discussion stratégique.</li></ol>",
    services_image_alt: "Chercheur testant un annuaire interactif dans un hub de transport belge",
    services_image_caption: "Évaluation d’un répertoire multilingue dans un terminal bruxellois.",
    services_outcome_title: "Livrables",
    services_outcome_desc: "La documentation vise l’amélioration continue plutôt que la prescription commerciale.",
    services_outcome_point1: "Plans annotés signalant zones de convergence et angles morts.",
    services_outcome_point2: "Check-lists d’accessibilité alignées sur la réglementation belge et les retours d’expérience.",
    services_outcome_point3: "Guides de maintenance reliant exploitation de la signalétique et évolutions architecturales.",
    // About
    about_intro_label: "Origines",
    about_intro_title: "Suivre l’évolution de danswholesaleplants",
    about_intro_desc: "Collectif de recherche basé à Bruxelles, danswholesaleplants observe la manière dont les environnements bâtis guident ou désorientent.",
    about_story_content: "<h2>Une histoire d’observation continue</h2><p>Crée en 2019, le collectif a d’abord documenté la signalétique des marchés couverts avant d’étendre ses études aux transports, aux bibliothèques et aux campus culturels. Les premiers rapports ont mis l’accent sur la lisibilité bilingue. Aujourd’hui, les explorations intègrent acoustique, éclairage et comportements sensoriels.</p><p>Le groupe s’appuie sur des carnets de terrain, des entretiens et des ateliers ouverts pour nourrir une mémoire partagée entre institutions partenaires.</p>",
    about_image_alt: "Équipe observant les flux piétons à l’intérieur d’un hall civique belge",
    about_image_caption: "Observation partagée avec des agents municipaux à Bruxelles.",
    about_pillars_title: "Piliers directeurs",
    about_pillars_desc: "Trois principes structurent la lecture des parcours et la restitution des analyses.",
    about_pillar1_content: "<h3>Preuve avant hypothèse</h3><p>Chaque insight découle de notes de terrain, de relevés et de transcriptions décrivant les mouvements et les hésitations.</p>",
    about_pillar2_content: "<h3>Co-création avec les steward·e·s</h3><p>Les constats sont traduits en lexiques partagés pour que agents de mobilité, architectes et accueils les interprètent ensemble.</p>",
    about_pillar3_content: "<h3>Attention au temps</h3><p>La signalétique évolue selon les saisons, les événements et les travaux. Nos analyses suivent ces mutations pour anticiper les ruptures.</p>",
    about_methods_title: "Méthodes en pratique",
    about_methods_desc: "Un mélange d’outils analogiques et numériques permet de capter les nuances des parcours.",
    about_methods_list: "<ul><li>Cartes sensibles dessinées à partir d’observations in situ.</li><li>Journalisation photographique alignée sur les horaires de pointe.</li><li>Analyses croisées entre données opérationnelles et témoignages d’usagers.</li><li>Prototypage d’expériences de guidage au sein d’ateliers participatifs.</li></ul>",
    about_team_title: "Structure d’équipe",
    about_team_desc: "Chercheur·euse·s, designer·euse·s de services et spécialistes accessibilité collaborent entre Bruxelles, Gand et Liège.",
    // Blog
    blog_intro_label: "Journal",
    blog_intro_title: "Journal d’orientation spatiale",
    blog_intro_desc: "Les contributions rassemblent études longitudinales, retours de terrain et cadres méthodologiques.",
    blog_post1_title: "Strates de synthèse pour la navigation intérieure multimodale",
    blog_post2_title: "Audits de cycle de vie pour la signalétique numérique en transport",
    blog_post3_title: "Concevoir une orientation inclusive pour des campus civiques étendus",
    blog_post1_meta: "Étude de terrain · 12 juin 2024",
    blog_post2_meta: "Audit de systèmes · 28 mai 2024",
    blog_post3_meta: "Perspective accessibilité · 16 avril 2024",
    blog_post1_excerpt: "La coordination des signaux visuels, sonores et tactiles influence directement la prise de décision des usagers dans des bâtiments interconnectés.",
    blog_post2_excerpt: "Un audit de cycle de vie révèle comment maintenance, gouvernance éditoriale et accessibilité assurent la cohérence des écrans.",
    blog_post3_excerpt: "Des démarches participatives transforment des campus éclatés en communs navigables pour des publics variés.",
    // Post 1
    post1_intro_label: "Analyse longue",
    post1_intro_summary: "Ce rapport détaille la manière dont les couches sensorielles et numériques se synchronisent pour orienter les usagers.",
    post1_image_alt: "Passagers examinant une grande carte interactive dans un hall couvert",
    post1_caption: "Relevé nœud par nœud dans un échangeur bruxellois.",
    post1_content: `<h1>Strates de synthèse pour la navigation intérieure multimodale</h1><p>Les bâtiments publics belges ne fonctionnent presque jamais comme des espaces mono-sensoriels. Les pôles de transport, les complexes culturels et les campus administratifs mêlent sons, lumières et mouvements tout en tentant de rester lisibles pour les résident·e·s, les navetteurs et les visiteur·euse·s. Notre dernier cycle d’observation explore la manière dont surfaces numériques, panneaux statiques et signaux environnementaux composent des expériences de guidage. Le rapport rassemble de nombreuses visites à Bruxelles, Gand et Liège, où annonces multilingues, acoustique architecturale et murs médiatiques se superposent. Nous suivons la façon dont chacun assemble du sens à partir de ces sollicitations simultanées et nous examinons les seuils où l’orientation réussit ou s’effrite. En ajoutant l’attention portée aux odeurs, aux niveaux lumineux et aux indices tactiles à des audits visuels, nous comprenons mieux le moment où une personne poursuit son chemin, s’arrête pour vérifier ou rebrousse route.</p><h2>Cartographier les apports sensoriels et les décisions spatiales</h2><p>Pendant les parcours, nous relevons non seulement la position des dispositifs d’orientation mais aussi leurs relations. Un kiosque fournissant les mises à jour du tram jouxte un café aux arômes marqués ; une bande podotactile dirige les passants à proximité d’une zone de maintenance bruyante ; des rubans lumineux codés par couleur varient selon les données d’occupation. Chaque élément influence la perception des autres. Nos grilles de cartographie croisent donc registres sensoriels et points décisionnels. Nous observons si une personne remarque une bannière plafonnière tout en manœuvrant un chariot, ou si une annonce multilingue l’incite à se tourner vers un couloir moins visible. Ces observations alimentent une compréhension stratifiée de la manière dont la perception se transforme en gestes concrets, au bénéfice des équipes qui gèrent architecture et systèmes d’information.</p><h3>Repères de synchronisation des données</h3><p>Synchroniser les contenus des surfaces numériques devient complexe lorsque plusieurs opérateurs partagent un même lieu. Nous avons documenté des kiosques actualisés toutes les quinze minutes, tandis que des panneaux LED voisins affichaient des flux en temps réel. Les visiteurs questionnaient des icônes identiques annonçant des numéros de quai différents. Notre référentiel compare donc horodatages, provenance des données et cadence d’affichage. En consignant les moments où les flux divergent, nous apportons des preuves pour harmoniser API, procédures éditoriales et interventions manuelles. Le référentiel n’est pas une liste de conformité ; il raconte comment un voyageur perçoit la fragmentation lorsqu’il respire des effluves de diesel, guette un rappel de quai et lit des flèches contradictoires. Aligner ces couches sensorielles s’avère aussi décisif qu’installer un nouvel équipement.</p><p>Nous mettons également en parallèle les informations tactiles et les index numériques. Par exemple, un pictogramme en relief peut toujours orienter une personne malvoyante vers un escalator récemment devenu bidirectionnel. Sans routines de synchronisation claires, ces personnes s’en remettent à du personnel qui n’a pas reçu la dernière mise à jour. Notre étude propose des calendriers partagés reliant transformations d’infrastructure, annonces sonores et surimpressions en Braille. Ce travail anticipatif évite que la désorientation ne se propage dans le bâtiment, même lorsque les calendriers de rénovation évoluent soudainement.</p><h2>Comportements des interfaces dans les bâtiments denses</h2><p>Les bâtiments denses canalisent souvent de multiples flux dans des vestibules restreints. Écrans, projections et marquages au sol rivalisent pour capter l’attention en quelques secondes. Nous avons observé des familles avec poussettes passer sous des écrans déroulant des textes trop longs, tandis que des flèches temporaires en vinyle tentaient de les rediriger vers un bloc d’ascenseurs plus calme. Le rapport entre espace physique et comportement des interfaces devient déterminant : lorsqu’un écran s’anime trop vivement, les personnes hésitent ; lorsque l’éclairage est atténué, l’information s’efface. Notre étude mesure ces effets par des diagrammes d’ombres, des relevés de luminance et des instantanés acoustiques montrant comment la réverbération dissimule des annonces cruciales.</p><h3>Rythme adaptatif des messages</h3><p>Le rythme des messages décrit la fréquence des rappels, la façon de reconnaître un retard et la manière d’orienter vers une étape suivante. Dans les gares belges, les annonces alternent en français, néerlandais, anglais et parfois allemand. Nous chronométrons la durée d’un cycle complet et la comparons au degré de patience d’une personne peu familière du bâtiment. La signalétique numérique devrait combler cette attente ; pourtant, nous avons vu des murs diffuser du contenu promotionnel tandis que les voyageurs s’inquiétaient. Nous recommandons de programmer des boucles adaptatives déclenchées par les capteurs de foule et les alertes de maintenance. Plutôt que des playlists figées, les interfaces devraient insérer des rappels d’orientation concis dès qu’un obstacle apparaît. Le rythme doit sembler soutenant et non intrusif, en complément des agents présents sur place.</p><ul><li>Associer des pictogrammes concis à un texte réduit pour maintenir des rotations multilingues rapides sans perdre de clarté.</li><li>Réserver un pourcentage du temps d’écran aux messages de déviation dynamique, afin que les mises à jour urgentes supplantent les narrations ambiantes.</li><li>Utiliser des signaux lumineux d’ambiance pour indiquer le prochain point de confirmation, comme la validation de titres ou l’accueil d’information.</li></ul><h2>Maintenir la fiabilité sur le terrain</h2><p>La fiabilité repose sur des rituels d’entretien continus. Nous avons suivi la collaboration—ou son absence—entre équipes de nettoyage, sécurité et information autour des systèmes de signalétique. Dans plusieurs bâtiments, des remplacements d’ampoules se produisaient sans prévenir l’équipe en charge du contenu numérique, créant des couloirs très éclairés à côté d’écrans ternes. Ailleurs, des autocollants couvraient des icônes obsolètes mais se décollaient au bout d’une semaine, révélant des directions contradictoires. Nous insistons pour que la fiabilité soit gérée comme un patrimoine commun. Des chartes de gouvernance doivent préciser qui valide les traductions, qui audite les éléments tactiles et qui intervient quand les réaménagements redessinent les parcours de référence.</p><h3>Patrons de documentation</h3><p>La documentation prend du poids lorsqu’elle reflète l’expérience vécue. Nos rapports assemblent captures vidéo annotées, courbes de décibels, notes olfactives et retranscriptions d’entretiens spontanés. Chaque élément devient un chapitre d’un atlas vivant. Nous évitons d’isoler les tableaux de bord numériques de la réalité mouvante des déplacements lors de grèves, festivals ou intempéries. Au contraire, nous encourageons les équipes à revisiter la documentation avant d’engager de nouvelles interventions. Lorsqu’un bâtiment envisage de nouveaux kiosques, il devrait consulter les schémas montrant où les files se forment, comment la ventilation influence l’intelligibilité vocale et quelles associations d’accessibilité ont signalé des obstacles ignorés. La documentation évolue ainsi d’archives figées en mémoire opérationnelle partagée entre services.</p><p>Finalement, la synthèse multimodale invite à l’humilité. Aucune interface isolée ne résout l’orientation dans une structure complexe. L’objectif consiste à chorégraphier lumière, son, texture et langue pour que les visiteur·euse·s construisent une carte mentale fiable. Les institutions belges qui expérimentent cette chorégraphie montrent que l’observation rigoureuse, le partage transparent des données et la maintenance collaborative transforment l’errance en mouvement confiant. Notre recherche continue de suivre ces expérimentations, offrant les preuves contextuelles nécessaires pour garder alignés canaux numériques et supports physiques.</p>`,
    // Post 2
    post2_intro_label: "Étude méthodologique",
    post2_intro_summary: "Un audit de cycle de vie révèle les dépendances qui maintiennent la signalétique numérique cohérente.",
    post2_image_alt: "Technicien inspectant un panneau d’information dans une gare belge",
    post2_caption: "Suivi nocturne de maintenance à Anvers.",
    post2_content: `<h1>Audits de cycle de vie pour la signalétique numérique en intérieurs de transport</h1><p>Les intérieurs de transport en Belgique fonctionnent par cycles d’usure, de rénovation et de renouvellement technologique, mais les réseaux de signalétique évoluent souvent par fragments. Cet article examine comment les audits de cycle de vie révèlent les dépendances cachées qui assurent la cohérence du guidage. Pendant douze semaines, nous avons accompagné des équipes de maintenance à Bruxelles, Anvers et Charleroi, en suivant l’installation, la réparation ou la mise hors service des écrans. En corrélant registres d’actifs et observations de terrain, nous avons établi une chronologie des écrans, haut-parleurs, projecteurs et alimentations. L’audit montre quand l’infrastructure numérique soutient réellement la compréhension des passagers et quand elle s’écarte silencieusement des transformations architecturales.</p><h2>Suivre les étapes de vie du matériel</h2><p>L’audit commence par l’identification de l’âge et de l’état de chaque composant ancrant le réseau de signalétique. De nombreuses gares héritent d’appareils provenant d’anciens opérateurs, créant un mélange de générations sur un même circuit. Nous avons catalogué caissons, platines, cheminements de câbles et dégagements de ventilation. L’imagerie thermique a révélé des points chauds autour d’écrans installés sans circulation d’air suffisante, causant un affaiblissement progressif de la luminosité. Ces diagnostics physiques éclairent les décisions de déplacement, de refroidissement ou de remplacement. L’audit examine aussi les hauteurs de fixation et les angles de vision, en les comparant aux évolutions démographiques des usagers, y compris les personnes en fauteuil et les voyageurs de grande taille.</p><h3>Indicateurs de fatigue des matériaux</h3><p>La fatigue matérielle se manifeste subtilement : vis desserrées par les vibrations, cadres qui se déforment sous le soleil, filtres antireflets jaunis par les produits de nettoyage. Nous avons élaboré un système de notation capturant ces signaux avant la panne. Le personnel de nettoyage a fourni des observations précieuses, signalant des surfaces nécessitant des frottements répétés après les événements du week-end. Leurs remarques indiquent la dégradation des revêtements protecteurs. Combiner ces notes qualitatives avec des mesures de luminance offre un profil exploitable. Plutôt que de réagir aux ruptures, les opérateurs peuvent programmer une maintenance tournante qui maintient l’homogénéité visuelle du réseau.</p><p>Un autre indicateur concerne l’infrastructure sonore accompagnant la signalétique visuelle. Les haut-parleurs encastrés au plafond accumulent souvent de la poussière qui étouffe la clarté de la parole. Notre audit consigne niveaux de décibels et réponses fréquentielles pour vérifier l’intelligibilité lorsque les quais se densifient. Le matériel incapable de maintenir une clarté de base dans les tolérances convenues est signalé pour remplacement ou repositionnement. Préserver ces indicateurs évite la frustration de passagers qui comptent sur les écrans pour confirmer les annonces vocales.</p><h2>Gouvernance des contenus dans les pôles partagés</h2><p>Les pôles de transport accueillent plusieurs acteurs : exploitants, équipes de sécurité, offices touristiques et commerçants. Chacun peut solliciter un temps d’écran. Sans perspective de cycle de vie, le calendrier éditorial devient un rapport de force. Nous avons étudié des instances de gouvernance qui coordonnent les messages via des revues trimestrielles, des points quotidiens et des protocoles d’urgence. Les instances efficaces maintiennent des inventaires de contenus obligatoires—consignes de sécurité, alertes multilingues, rappels d’accessibilité—avant d’autoriser des récits d’ambiance. L’audit évalue la capacité de ces structures à réagir lorsque des événements imprévus surviennent, comme un avis météo soudain ou une action sociale.</p><h3>Modèles de coordination multi-acteurs</h3><p>Les modèles de coordination varient. Certains pôles s’appuient sur un éditeur central qui agrège les mises à jour. D’autres pratiquent la rédaction distribuée où chaque entité charge ses gabarits. Nous avons évalué les temps de réponse en simulant des perturbations : escalators bloqués, bus déviés ou avis de disparition. Les modèles les plus résilients s’appuyaient sur des taxonomies partagées et des blocs de messages modulaires. Des gabarits conservés dans une bibliothèque versionnée garantissaient cohérence des tailles de police, des langues et des pictogrammes. Quand les entités s’en écartaient, la lisibilité chutait et le personnel devait fournir des explications improvisées. Les audits de cycle de vie recommandent donc des accords de gouvernance reliant mises à niveau matérielles et flux éditoriaux, afin d’éviter le décalage entre écrans neufs et gabarits obsolètes.</p><p>Nous avons également cartographié les boucles décisionnelles durant les fenêtres nocturnes de maintenance. Les équipes techniques profitent souvent de ces heures pour mettre à jour des micrologiciels ou recalibrer des capteurs. Si la chaîne de communication se rompt, les usagers du matin découvrent des écrans éteints. Documenter qui autorise l’arrêt, qui valide la remise en service et qui surveille les diagnostics à distance est essentiel pour préserver l’orientation. Ces boucles doivent être réexaminées à chaque arrivée d’un nouveau prestataire.</p><h2>Pérenniser l’accessibilité au fil des mises à jour</h2><p>L’accessibilité est un engagement de cycle de vie. Une mise à niveau matérielle peut involontairement réduire le contraste tactile ou déplacer des légendes. Nous avons comparé des configurations héritées avec de nouvelles installations pour garantir la conformité aux normes belges et aux attentes des voyageurs réguliers. Une attention particulière a été portée aux sous-titres, inserts en langue des signes et descriptions audio diffusés sur des écrans partagés. Lorsque des éditeurs raccourcissent les boucles, les superpositions d’accessibilité sont parfois écourtées en premier. Notre audit plaide pour des plages réservées qui ne peuvent être supprimées sans escalade.</p><h3>Instruments de mesure</h3><p>Pour pérenniser l’accessibilité, les instruments de mesure doivent s’intégrer aux opérations courantes. Nous avons introduit des listes de contrôle mêlant métriques objectives et retours subjectifs. Les métriques objectives incluent ratios de contraste, hauteur des symboles et latence de rafraîchissement. Les retours subjectifs proviennent d’un compagnonnage avec des passagers aux profils de mobilité, sensoriels et cognitifs variés. Leurs récits dévoilent des micro-barrières : reflets qui masquent des flèches au coucher du soleil, messages vocaux qui se superposent aux annonces publiques. Intégrer ces instruments aux audits de cycle de vie garantit que les améliorations n’effacent pas des acquis d’accessibilité.</p><ul><li>Documenter chaque intervention avec photos datées et relevés de capteurs afin d’assurer la traçabilité.</li><li>Organiser des retours d’expérience transdisciplinaires après une perturbation pour analyser les défaillances de communication ou de matériel.</li><li>Aligner les cycles d’acquisition avec la formation afin que le personnel maîtrise l’exploitation et la maintenance des nouveaux dispositifs.</li></ul><p>Penser cycle de vie transforme la signalétique numérique d’un ensemble d’écrans dispersés en un compagnon de navigation fiable. Lorsque diagnostics matériels, modèles de gouvernance et instruments d’accessibilité s’entrelacent, les intérieurs de transport belges demeurent lisibles malgré leur évolution. L’audit nourrit aussi l’empathie pour celles et ceux qui pérennisent ces systèmes : technicien·ne·s remplaçant des alimentations à l’aube, concepteurs raffinent des pictogrammes après les ateliers citoyens, annonceurs calibrent leur tonalité lors des ajustements de service. En soutenant leur collaboration, les passagers trouvent un guidage soigné plutôt qu’improvisé.</p>`,
    // Post 3
    post3_intro_label: "Perspective inclusive",
    post3_intro_summary: "Des campus étendus deviennent lisibles grâce à la co-conception et aux protocoles de soin.",
    post3_image_alt: "Groupe marchant sur un campus civique avec supports de signalétique",
    post3_caption: "Itinéraire partagé avec des associations à Namur.",
    post3_content: `<h1>Concevoir une orientation inclusive pour des campus civiques étendus</h1><p>Les campus civiques belges couvrent souvent plusieurs îlots en mêlant bâtiments administratifs, lieux culturels et espaces ouverts. L’orientation dans ces environnements doit répondre à des communautés variées : habitant·e·s accédant aux services publics, étudiant·e·s suivant des cours du soir, touristes découvrant des expositions, agent·e·s publics passant d’une réunion à l’autre. Cet article synthétise des études longitudinales menées sur des campus à Bruxelles, Namur et Ostende. En combinant analyses spatiales, ateliers de récit et prototypes itératifs, nous explorons la manière dont un guidage inclusif émerge lorsque l’autorité est partagée entre institutions aux mandats distincts.</p><h2>Cartographier les identités du campus</h2><p>Un campus étendu s’exprime rarement d’une seule voix. Chaque bâtiment porte sa signalétique, sa palette de couleurs et son ton. Les visiteur·euse·s peuvent interpréter ces différences comme des frontières, incertain·e·s d’avoir le droit de traverser une cour ou d’entrer dans un atrium. Nous menons des cartographies d’identité pour révéler chevauchements et manques. Cela implique de photographier les accès à différents moments de la journée, en documentant comment lumière, végétation et vie de rue modifient la perception. Nous comparons les récits transmis par les plaques, bannières et annuaires numériques. L’objectif est de détecter où des identités contradictoires bloquent l’orientation et où des motifs cohérents existent déjà.</p><h3>Co-recherche avec les communautés</h3><p>La cartographie d’identité se complète par une co-recherche communautaire. Nous invitons personnel, voisinage et usagers à annoter des plans imprimés avec souvenirs et frustrations. Lors des ateliers, les participant·e·s expliquent les rituels qui structurent leurs visites : déposer des enfants à des cours de langue, patienter pour des documents administratifs, assister à un spectacle après le travail. Ces récits dévoilent des raccourcis informels, des zones perçues comme sûres et des espaces évités après la tombée de la nuit. La co-recherche ancre la conception dans l’expérience vécue, garantissant que les interventions respectent les accords sociaux établis plutôt que d’imposer une logique extérieure.</p><h2>Segmenter les typologies de piétons</h2><p>Les typologies de piétons décrivent le rythme, les attentes et les contraintes des différent·e·s usagers du campus. Nous évitons les stéréotypes en fondant ces typologies sur l’observation et les entretiens. Certain·e·s se déplacent avec urgence, comme les personnels de livraison soumis à des horaires serrés. D’autres privilégient la déambulation, tel·le·s des retraité·e·s participant à des programmes culturels. Cette segmentation oriente l’adaptation de la hiérarchie signalétique et des indices spatiaux. Les typologies rapides profitent de balises à fort contraste et d’un langage direct. Les typologies contemplatives apprécient des plaques narratives, des guides audio ou des superpositions en réalité augmentée offrant un contexte historique.</p><h3>Protocoles de soin et de maintenance</h3><p>Une orientation inclusive se dégrade sans soin. Les protocoles de maintenance doivent définir qui surveille la végétation masquant des panneaux, qui rafraîchit les cheminements tactiles et qui recalibre l’éclairage extérieur. Sur un campus, des jardiniers bénévoles taillaient les haies mais dissimulaient involontairement des poteaux directionnels. Nous avons aidé l’administration à collaborer avec eux pour établir des listes de contrôle partagées. Un autre campus faisait face à des totems vandalisés. Plutôt que de les remplacer simplement, le protocole a instauré des ambassadeurs communautaires signalant les incidents via un canal de messagerie. Les protocoles alignent ainsi la vigilance humaine sur les conditions environnementales, renforçant l’inclusion par une maintenance fiable.</p><h2>Canaux de communication inclusifs</h2><p>L’orientation dépasse les panneaux physiques. Une communication inclusive mobilise plusieurs canaux : notifications mobiles, supports imprimés, guides humains, signaux d’ambiance. Nous évaluons la portée de chaque canal auprès de publics multilingues, de personnes avec handicaps sensoriels et de nouveaux arrivants sans repères institutionnels. Les notifications mobiles ne doivent pas supposer une connexion permanente. Les supports imprimés doivent utiliser des typographies lisibles pour les lecteurs dyslexiques. Les guides humains, bénévoles ou salarié·e·s, ont besoin de scripts reflétant les politiques de langage inclusif. Les signaux d’ambiance—séquences lumineuses, fontaines, carillons—peuvent indiquer des seuils sans recourir au texte.</p><h3>Boucles d’évaluation</h3><p>Les boucles d’évaluation transforment l’inclusion en pratique continue. Nous mettons en place des boucles mêlant audits saisonniers, formulaires numériques et séances d’observation. Les audits saisonniers examinent l’impact de la météo sur la marchabilité ; neige ou forte pluie peuvent rendre les repères tactiles glissants. Les formulaires numériques recueillent les récits de celles et ceux qui ne peuvent participer aux ateliers. Les séances d’observation suivent des personnes découvrant un nouvel aménagement, en captant gestes, questions et temps d’arrêt. Ces boucles alimentent des tableaux de suivi où les équipes du campus repèrent les points de friction persistants et planifient une action adaptée.</p><ul><li>Concevoir des centres d’accueil comme des biens communs de la connaissance, proposant guides imprimés, cartes tactiles et liens vers des mises à jour en temps réel.</li><li>Coordonner les glossaires signalétiques afin que le vocabulaire reste cohérent entre services et lieux loués.</li><li>Publier des journaux de maintenance transparents indiquant la date des inspections, nettoyages ou mises à jour.</li></ul><p>L’orientation inclusive ne se résume pas à ajouter des rampes ou à traduire des textes. Elle consiste à cultiver des relations qui maintiennent l’information digne de confiance. Lorsque acteurs architecturaux, culturels et administratifs collaborent, les campus deviennent poreux et accueillants. Les exemples belges montrent que même des sites historiques peuvent adopter une gouvernance participative pour soutenir l’inclusion. Le défi permanent est de préserver l’élan : re-tester les hypothèses après des rénovations, inviter de nouvelles voix à co-concevoir les supports, valoriser le travail de soin souvent invisible. Grâce à ces pratiques, les campus étendus évoluent en communs navigables au service de toutes et tous.</p>`,
    // FAQ
    faq_intro_title: "Questions fréquentes",
    faq_intro_desc: "Précisions sur notre manière de documenter, de partager et de mettre à jour les analyses d’orientation spatiale.",
    faq_item1_content: "<h3>Comment sélectionnez-vous les sites d’observation ?</h3><p>Nous privilégions les lieux publics confrontés à des enjeux de navigation ou de multilinguisme. Les visites sont réalisées en partenariat avec les opérateurs et les usagers concernés.</p>",
    faq_item2_content: "<h3>Quels livrables produisez-vous ?</h3><p>Des plans annotés, des carnets photographiques, des transcriptions d’entretiens et des tableaux de synthèse. Ils servent de base à la discussion entre équipes techniques et responsables de site.</p>",
    faq_item3_content: "<h3>À quelle fréquence publiez-vous des analyses ?</h3><p>Les études majeures paraissent trimestriellement, complétées par des notes plus courtes après des événements ou chantiers spécifiques.</p>",
    faq_item4_content: "<h3>Comment intégrez-vous les retours d’usagers ?</h3><p>Via des ateliers, des marches accompagnées et des formulaires ouverts. Les retours sont anonymisés et intégrés aux synthèses.</p>",
    faq_item5_content: "<h3>Pouvez-vous intervenir en dehors de la Belgique ?</h3><p>Nos ressources se concentrent sur les institutions belges. Nous partageons toutefois nos méthodes afin que d’autres territoires puissent les adapter.</p>",
    faq_item6_content: "<h3>Comment citer vos analyses ?</h3><p>Merci de mentionner danswholesaleplants, le titre de l’étude et sa date de publication. Les documents incluent toujours un identifiant de version.</p>",
    // Contact
    contact_intro_label: "Prendre contact",
    contact_intro_title: "Collaborer autour de l’orientation spatiale",
    contact_intro_desc: "Utilisez ce canal pour proposer une observation conjointe, partager un retour de terrain ou demander des précisions méthodologiques.",
    contact_details_title: "Coordonnées",
    contact_phone_label: "Téléphone",
    contact_phone_value: "+32 2 808 34 55",
    contact_email_label: "Courriel",
    contact_email_value: "contact@danswholesaleplants.com",
    contact_hours_label: "Disponibilité",
    contact_hours_value: "Du lundi au vendredi, 09h00–18h00 CET",
    contact_support_note: "Nous répondons habituellement sous deux jours ouvrables.",
    contact_form_title: "Envoyer un message",
    contact_form_desc: "Décrivez le contexte, les bâtiments concernés et vos questions sur la navigation.",
    contact_form_name_label: "Nom",
    contact_form_name_placeholder: "Votre nom complet",
    contact_form_email_label: "Courriel",
    contact_form_email_placeholder: "Votre adresse professionnelle",
    contact_form_org_label: "Organisation",
    contact_form_org_placeholder: "Institution ou équipe",
    contact_form_message_label: "Message",
    contact_form_message_placeholder: "Décrivez l’environnement et les sujets à investiguer.",
    contact_form_submit: "Passer à la confirmation",
    contact_map_caption: "Localisation près des institutions européennes à Bruxelles.",
    contact_map_title: "Carte indiquant la Rue de la Loi 200 à Bruxelles",
    // Legal
    legal_intro_label: "Cadre légal",
    terms_intro_title: "Conditions d’utilisation",
    terms_intro_desc: "Ces conditions encadrent l’accès aux contenus publiés par danswholesaleplants.",
    terms_content: `<h1>Conditions d’utilisation</h1><p>Les présentes conditions s’appliquent à l’ensemble des contenus publiés sur le domaine danswholesaleplants.com. En consultant le site, vous acceptez ces règles qui peuvent être mises à jour à tout moment.</p><h2>1. Objet</h2><p>Le site diffuse des analyses et des ressources concernant l’orientation spatiale et la signalétique numérique. Il n’a aucune vocation commerciale et ne constitue pas une offre de prestation.</p><h2>2. Définitions</h2><p>“Plateforme” désigne le site danswholesaleplants.com. “Utilisateur” désigne toute personne accédant au contenu. “Contenus” regroupe textes, images, schémas et ressources téléchargeables.</p><h2>3. Langues</h2><p>Les contenus sont publiés en français et en anglais. En cas de divergence d’interprétation, la version française prévaut.</p><h2>4. Utilisation des contenus</h2><p>Les contenus sont fournis à titre informatif. Toute réutilisation doit mentionner clairement la source et respecter l’intégrité des analyses.</p><h2>5. Propriété intellectuelle</h2><p>Sauf mention contraire, les contenus appartiennent à danswholesaleplants. Ils ne peuvent être reproduits ou exploités sans autorisation écrite.</p><h2>6. Accès à la plateforme</h2><p>L’accès est gratuit et peut être suspendu ou modifié pour maintenance, amélioration ou raisons de sécurité.</p><h2>7. Références externes</h2><p>Le site peut contenir des liens vers des ressources externes. Danswholesaleplants n’est pas responsable de leur disponibilité ni de leur contenu.</p><h2>8. Matériels de recherche</h2><p>Les documents méthodologiques et jeux de données partagés le sont dans un but de transparence. Leur réutilisation doit respecter les licences indiquées.</p><h2>9. Contributions des utilisateurs</h2><p>Les retours transmis via formulaires ou courriels peuvent être cités de manière anonymisée. Les utilisateurs garantissent la véracité des informations fournies.</p><h2>10. Référence à la protection des données</h2><p>Le traitement des données personnelles est décrit dans la politique de confidentialité. Toute question peut être adressée à l’adresse de contact.</p><h2>11. Limitation de responsabilité</h2><p>Danswholesaleplants ne garantit pas l’exhaustivité des contenus et ne saurait être tenu responsable des décisions prises sur la base des analyses publiées.</p><h2>12. Modification des conditions</h2><p>Les conditions peuvent être révisées à tout moment. La date de mise à jour est indiquée au début de la page.</p><h2>13. Droit applicable</h2><p>Les présentes conditions sont régies par le droit belge. Tout litige relève de la compétence des tribunaux de Bruxelles.</p><h2>14. Contact</h2><p>Pour toute question, écrivez à contact@danswholesaleplants.com ou utilisez le formulaire disponible sur la page Contact.</p>`,
    privacy_intro_title: "Politique de confidentialité",
    privacy_intro_desc: "Cette politique explique comment danswholesaleplants traite les données personnelles dans le cadre de ses activités éditoriales.",
    privacy_content: `<h1>Politique de confidentialité</h1><p>Nous accordons une attention particulière à la protection des données personnelles recueillies lors de l’utilisation du site.</p><h2>1. Responsable du traitement</h2><p>Le responsable du traitement est danswholesaleplants, Rue de la Loi 200, 1040 Bruxelles, Belgique.</p><h2>2. Données collectées</h2><p>Nous collectons les données fournies via le formulaire de contact (nom, courriel, organisation, message) ainsi que des informations techniques minimales pour les statistiques de fréquentation.</p><h2>3. Méthodes de collecte</h2><p>Les données proviennent directement des utilisateurs ou de cookies analytiques strictement nécessaires à la compréhension du trafic.</p><h2>4. Finalités</h2><p>Les données servent à répondre aux messages, organiser des échanges de recherche et améliorer le contenu éditorial.</p><h2>5. Bases juridiques</h2><p>Le traitement repose sur l’intérêt légitime de répondre aux sollicitations et de suivre l’audience du site.</p><h2>6. Conservation</h2><p>Les données de contact sont conservées le temps d’assurer le suivi des échanges, sans excéder deux ans d’inactivité. Les statistiques sont agrégées et anonymisées.</p><h2>7. Partage</h2><p>Les données ne sont pas revendues. Elles peuvent être partagées avec des prestataires techniques hébergeant le site ou assurant la sécurité, soumis à un engagement de confidentialité.</p><h2>8. Transferts internationaux</h2><p>Nous privilégions l’hébergement au sein de l’Espace économique européen. Tout transfert éventuel fera l’objet de garanties adéquates.</p><h2>9. Droits des personnes</h2><p>Vous pouvez demander l’accès, la rectification, l’effacement ou la limitation du traitement de vos données en contactant contact@danswholesaleplants.com.</p><h2>10. Sécurité</h2><p>Des mesures techniques et organisationnelles protègent les données contre la perte, l’accès non autorisé ou la divulgation.</p><h2>11. Mise à jour</h2><p>La présente politique peut être ajustée pour refléter l’évolution de nos pratiques. La date de révision est indiquée en tête de page.</p>`,
    cookies_intro_title: "Gestion des cookies",
    cookies_intro_desc: "Nous limitons l’usage des cookies au strict nécessaire pour la langue et les mesures d’audience.",
    cookies_content: `<h1>Cookies et technologies similaires</h1><p>Ce site emploie un nombre réduit de cookies pour assurer son fonctionnement bilingue et mesurer l’audience.</p><table><thead><tr><th>Nom</th><th>Fournisseur</th><th>Type</th><th>Finalité</th><th>Durée</th></tr></thead><tbody><tr><td>site_lang</td><td>danswholesaleplants</td><td>Fonctionnel</td><td>Mémoriser la langue choisie par l’utilisateur.</td><td>12 mois</td></tr><tr><td>cookie_consent</td><td>danswholesaleplants</td><td>Fonctionnel</td><td>Enregistrer le consentement relatif aux cookies.</td><td>12 mois</td></tr><tr><td>analytics_session</td><td>danswholesaleplants</td><td>Statistique</td><td>Mesurer de manière agrégée la fréquentation des pages.</td><td>24 heures</td></tr></tbody></table><p>Vous pouvez ajuster vos préférences en supprimant les cookies depuis votre navigateur ou en nous contactant.</p>`,
    refund_intro_title: "Politique de remboursement",
    refund_intro_desc: "Bien que le site ne propose aucune vente, cette politique détaille la manière dont nous traitons les demandes de correction ou de retrait de contenus.",
    refund_content: `<h1>Politique de remboursement</h1><p>Danswholesaleplants ne commercialise aucun produit ou service. La présente politique explique comment nous gérons les requêtes d’ajustement concernant nos publications.</p><h2>1. Objet</h2><p>Clarifier les procédures d’ajustement de contenus lorsqu’une information doit être précisée ou retirée.</p><h2>2. Champ d’application</h2><p>La politique couvre les articles, rapports et supports partagés publiquement sur le site.</p><h2>3. Absence de transactions financières</h2><p>Aucune somme d’argent n’est échangée. Les demandes portent exclusivement sur la qualité des informations.</p><h2>4. Demandes liées aux événements</h2><p>Si une session ou un atelier est reporté, les participants inscrits reçoivent une nouvelle date ou un compte rendu détaillé.</p><h2>5. Corrections documentaires</h2><p>Les personnes citées peuvent solliciter une correction. Nous vérifions la demande et publions une version révisée datée.</p><h2>6. Délai de traitement</h2><p>Nous accusons réception sous cinq jours ouvrables et tentons de traiter la demande dans les trente jours.</p><h2>7. Canal de communication</h2><p>Les demandes sont adressées via le formulaire de contact ou par courriel à contact@danswholesaleplants.com.</p><h2>8. Exceptions</h2><p>Une demande peut être refusée si elle compromet l’intégrité des analyses ou repose sur des informations manifestement erronées.</p><h2>9. Archivage</h2><p>Les versions modifiées sont archivées afin de conserver l’historique des changements.</p><h2>10. Mise à jour de la politique</h2><p>Cette politique est révisée régulièrement et la date de mise à jour est affichée sur la page.</p>`,
    disclaimer_intro_title: "Avertissement",
    disclaimer_intro_desc: "Les contenus publiés ont une finalité d’information et de recherche.",
    disclaimer_content: `<h1>Avertissement</h1><p>Les analyses fournies sur danswholesaleplants reflètent un état des observations et ne constituent pas un avis professionnel personnalisé.</p><h2>Absence de garantie</h2><p>Nous nous efforçons d’assurer l’exactitude des informations mais ne garantissons ni exhaustivité ni actualisation permanente.</p><h2>Responsabilité limitée</h2><p>Danswholesaleplants n’est pas responsable des décisions prises sur la base des contenus publiés. Les utilisateurs conservent la responsabilité de leurs choix.</p><h2>Ressources externes</h2><p>Les liens externes sont fournis à titre indicatif. Nous ne maîtrisons pas leur contenu.</p><h2>Évolution des contenus</h2><p>Les publications peuvent être mises à jour ou supprimées sans préavis pour refléter l’avancée des recherches.</p>`,
    // Thank you
    thank_intro_title: "Merci pour votre message",
    thank_intro_desc: "Nous avons bien reçu votre envoi et reviendrons vers vous sous deux jours ouvrables.",
    thank_return_link: "Retour à l’accueil"
  },
  en: {
    // Common
    brand_name: "danswholesaleplants",
    nav_home: "Home",
    nav_services: "Analyses",
    nav_about: "About",
    nav_blog: "Blog",
    nav_faq: "FAQ",
    nav_contact: "Contact",
    lang_fr: "FR",
    lang_en: "EN",
    aria_nav_toggle: "Toggle navigation",
    footer_tagline: "Analytical observatory for spatial orientation and digital signage.",
    footer_phone: "Phone: +32 2 808 34 55",
    footer_email: "Email: contact@danswholesaleplants.com",
    footer_address: "Rue de la Loi 200, 1040 Brussels, Belgium",
    legal_terms: "Terms",
    legal_privacy: "Privacy",
    legal_cookies: "Cookies",
    legal_refund: "Refund Policy",
    legal_disclaimer: "Disclaimer",
    footer_year: "© {year} danswholesaleplants. Spatial research insights from Brussels.",
    cookie_message: "We use minimal analytics to understand how visitors navigate these resources.",
    cookie_more: "Cookie preferences",
    cookie_accept: "Accept",
    toast_form_success: "Form data prepared. Redirecting to confirmation.",
    toast_close: "Close",
    // Meta
    meta_home_title: "danswholesaleplants | Spatial Orientation Research Observatory",
    meta_home_desc: "Bilingual platform examining digital wayfinding, pedestrian mobility, and signage systems across Belgian public infrastructure.",
    meta_services_title: "Analytical Capabilities · danswholesaleplants",
    meta_services_desc: "Overview of research capabilities supporting spatial orientation studies for Belgian public environments.",
    meta_about_title: "Origins and Method · danswholesaleplants",
    meta_about_desc: "Learn about the history, pillars, and methodology guiding danswholesaleplants in studying indoor navigation.",
    meta_blog_title: "Spatial Orientation Journal · danswholesaleplants",
    meta_blog_desc: "Long-form articles exploring digital signage, complex spaces, and pedestrian experience.",
    meta_post1_title: "Synthesis Layers for Multimodal Indoor Navigation | danswholesaleplants",
    meta_post1_desc: "In-depth analysis of sensory coordination and digital interfaces within Belgian public buildings.",
    meta_post2_title: "Lifecycle Audits for Digital Signage in Transit Interiors | danswholesaleplants",
    meta_post2_desc: "Study of maintenance, governance, and accessibility across transport display networks.",
    meta_post3_title: "Designing Inclusive Wayfinding for Expansive Civic Campuses | danswholesaleplants",
    meta_post3_desc: "Exploration of participatory approaches that keep large campuses legible for diverse communities.",
    meta_contact_title: "Contact · danswholesaleplants",
    meta_contact_desc: "Contact details and form to discuss spatial orientation research in Belgium.",
    meta_faq_title: "Frequently Asked Questions · danswholesaleplants",
    meta_faq_desc: "Responses about observation methods, data handling, and collaboration practices.",
    meta_terms_title: "Terms of Use · danswholesaleplants",
    meta_terms_desc: "Legal framework governing access to content published by danswholesaleplants.",
    meta_privacy_title: "Privacy Policy · danswholesaleplants",
    meta_privacy_desc: "Description of data practices related to editorial and research activities.",
    meta_cookies_title: "Cookie Management · danswholesaleplants",
    meta_cookies_desc: "Information about cookies and related technologies used on the platform.",
    meta_refund_title: "Refund Policy · danswholesaleplants",
    meta_refund_desc: "Procedures for addressing correction requests relating to non-commercial outputs.",
    meta_disclaimer_title: "Disclaimer · danswholesaleplants",
    meta_disclaimer_desc: "Limitations of responsibility and informational nature of published materials.",
    meta_thank_title: "Thank You · danswholesaleplants",
    meta_thank_desc: "Confirmation page for messages sent to the danswholesaleplants team.",
    // Home
    home_hero_label: "Observatory Notes",
    home_hero_title: "Interpreting Digital Wayfinding for Complex Belgian Environments",
    home_hero_description: "We document how signage, architecture, and pedestrian flows intertwine inside public buildings. Field observations, team interviews, and light or sound measurements inform every synthesis.",
    home_hero_caption: "Central control room at a multimodal hub in Brussels.",
    home_stat1_content: "<strong>48 mapped corridors</strong><span>Interface experiments documented since 2021</span>",
    home_stat2_content: "<strong>12 field visits each quarter</strong><span>Iterative observation cycles across civic campuses</span>",
    home_stat3_content: "<strong>6 analytical lenses</strong><span>Accessibility, flow, ergonomics, data, media, stewardship</span>",
    home_hero_img_alt: "Digital signage wall inside a Belgian transport interchange",
    home_features_label: "Frameworks",
    home_features_title: "Reading spatial orientation through multidisciplinary layers",
    home_features_desc: "Each briefing distils observed behaviours, interface ergonomics, and infrastructural constraints encountered in Belgian institutions.",
    home_feature1_content: "<h3>Pedestrian mobility diagnostics</h3><p>Walking trajectories are recorded through unobtrusive observations, mapping circulation loops and categorising decision points that reveal cue interpretation inside dense buildings.</p>",
    home_feature2_content: "<h3>Digital signage legibility</h3><p>We evaluate contrast ratios, iconography, and sequencing rules governing displays and kiosks, aligning them with contemporary accessibility standards for multilingual use.</p>",
    home_feature3_content: "<h3>Adaptive cartography reviews</h3><p>Layered floor plans are compared with live usage to verify whether media walls, tactile diagrams, and mobile extracts remain synchronised with building alterations.</p>",
    home_feature4_content: "<h3>Spatial UX governance</h3><p>Our documentation highlights maintenance protocols, roles, and collaborative loops that sustain coherent navigation across agencies and service partners.</p>",
    home_cartography_title: "Cartography as a living interface",
    home_cartography_desc: "Cartographic artefacts within Belgian institutions expand beyond static posters; they animate, translate, and adjust to seasonal journeys.",
    home_cartography_point1: "Cross-lingual labelling tested with community stakeholders.",
    home_cartography_point2: "Dynamic overlays responding to temporary closures or crowding.",
    home_cartography_point3: "Feedback channels linking digital kiosks to facility managers.",
    home_cartography_img_alt: "Researcher comparing an interactive map with the physical environment of a civic building",
    home_cartography_caption: "Iterative session at a cultural complex in Ghent.",
    home_recommendations_title: "Recommendations emerging from recent walkthroughs",
    home_recommendations_desc: "Structured insights support design and operations teams without prescribing commercial deliverables.",
    home_recommendation1_content: "<h3>Synchronise analogue and digital channels</h3><p>Audit whether wall panels, floor graphics, and screens reinforce one another at pivotal junctions to reduce contradictory cues.</p>",
    home_recommendation2_content: "<h3>Model flows during maintenance scenarios</h3><p>Simulate how passengers reroute when lifts or corridors close, ensuring temporary signposting reflects accessible alternatives.</p>",
    home_recommendation3_content: "<h3>Develop stewardship training</h3><p>Equip facility teams with pattern libraries and escalation paths so they can adjust messages quickly during events or seasonal shifts.</p>",
    home_testimonials_title: "Testimonials from collaborating stewards",
    home_testimonials_desc: "Perspectives collected after co-design workshops within Belgian campuses.",
    home_testimonial1_content: "<blockquote>“The navigation matrices helped our staff understand how multilingual families move through the atrium, revealing friction we had missed during previous refurbishments.”</blockquote><figcaption>Anne-Lise Dupont · Mobility Coordinator, Bruxelles Environnement</figcaption>",
    home_testimonial2_content: "<blockquote>“Connecting signage data with maintenance logs clarified why certain kiosks felt outdated. We now update labels alongside technical interventions.”</blockquote><figcaption>Joris Van de Walle · Facility Strategist, Leuven Civic Campus</figcaption>",
    home_testimonial3_content: "<blockquote>“Their documentation does not prescribe vendors; it tracks behaviour, letting us argue for incremental improvements backed by evidence.”</blockquote><figcaption>Sarah Bianchi · Programme Lead, Liège Cultural Network</figcaption>",
    home_latest_title: "Blog updates",
    home_latest_desc: "Long-form analyses examine signage ecosystems, data ethics, and flow modelling.",
    home_latest_post1_meta: "Field study · 12 June 2024",
    home_latest_post2_meta: "Systems audit · 28 May 2024",
    home_latest_post3_meta: "Accessibility lens · 16 April 2024",
    home_latest_post1_excerpt: "Analysis of sensory interactions that turn disparate signals into coherent pedestrian decisions.",
    home_latest_post2_excerpt: "Mapping maintenance and governance cycles that keep screens aligned with operational realities.",
    home_latest_post3_excerpt: "Participatory approach turning expansive campuses into legible commons for diverse communities.",
    home_latest_readmore: "Read the full briefing",
    home_latest_img1_alt: "Analyst reviewing signage dashboards inside a transport corridor",
    home_latest_img2_alt: "Technician inspecting an information display in a Belgian station hall",
    home_latest_img3_alt: "Workshop group mapping a civic campus on a light table",
    // Services
    services_intro_label: "Capabilities",
    services_intro_title: "Analysing orientation ecosystems within Belgian infrastructures",
    services_intro_desc: "We examine digital signage, pedestrian journeys, and spatial cartography to provide a shared baseline for technical and expert teams.",
    services_card1_content: "<h3>Spatial challenge inventories</h3><p>Evidence packs describe where visitors hesitate, how they interpret pictograms, and which architectural factors disrupt continuity.</p>",
    services_card2_content: "<h3>Digital signage research</h3><p>Display networks are benchmarked for dwell time, message hierarchy, and multilingual readability requirements.</p>",
    services_card3_content: "<h3>User journey discussions</h3><p>Work sessions with front-line teams capture narratives about peak-hour stressors, accessible routes, and shared responsibilities.</p>",
    services_card4_content: "<h3>Information design exploration</h3><p>We compare map schematics, pictograms, and typography to understand how each medium mediates attention.</p>",
    services_card5_content: "<h3>Technology and accessibility review</h3><p>Kiosks, QR layers, and mobile guidance tools are assessed for responsiveness, tactile affordances, and alignment with European standards.</p>",
    services_process_title: "Approach",
    services_process_desc: "Each collaboration follows a transparent cycle linking observation, synthesis, and contextualised knowledge sharing.",
    services_process_points: "<ol><li><strong>Baseline immersion</strong> — On-site walkthroughs record positional friction, signage tone, and competing stimuli.</li><li><strong>Collaborative synthesis</strong> — Findings are compared with operational data, maintenance schedules, and language policies.</li><li><strong>Contextual reporting</strong> — Dashboards, annotated plans, and photographic evidence anchor strategic discussions.</li></ol>",
    services_image_alt: "Researcher testing an interactive directory at a Belgian transport hub",
    services_image_caption: "Evaluating a multilingual directory during a Brussels terminal audit.",
    services_outcome_title: "Deliverables",
    services_outcome_desc: "Documentation emphasises continuous improvement rather than prescribing commercial outputs.",
    services_outcome_point1: "Annotated floor plans highlighting convergence zones and blind spots.",
    services_outcome_point2: "Accessibility checklists aligned with Belgian regulations and lived experience feedback.",
    services_outcome_point3: "Maintenance-oriented playbooks connecting signage operations with architectural updates.",
    // About
    about_intro_label: "Background",
    about_intro_title: "Tracing the evolution of danswholesaleplants",
    about_intro_desc: "Based in Brussels, the collective observes how built environments guide or disorient those who traverse them.",
    about_story_content: "<h2>A story of continuous observation</h2><p>Founded in 2019, the collective first documented signage in covered markets before expanding to transport nodes, libraries, and cultural campuses. Initial reports focused on bilingual legibility. Today the explorations integrate acoustics, lighting, and sensory behaviour.</p><p>The group relies on field notebooks, interviews, and open workshops to build shared memory among partner institutions.</p>",
    about_image_alt: "Team observing pedestrian flows inside a Belgian civic hall",
    about_image_caption: "Field observation with municipal staff in Brussels.",
    about_pillars_title: "Guiding pillars",
    about_pillars_desc: "Three principles frame how we read journeys and share analysis.",
    about_pillar1_content: "<h3>Evidence before assumption</h3><p>Every insight stems from field notes, measurements, and transcripts describing movement and hesitation.</p>",
    about_pillar2_content: "<h3>Co-creation with stewards</h3><p>Findings are translated into shared vocabularies so mobility agents, architects, and front desks interpret them together.</p>",
    about_pillar3_content: "<h3>Temporal awareness</h3><p>Signage evolves with seasons, events, and works. Our studies follow these shifts to anticipate breaks.</p>",
    about_methods_title: "Methods in practice",
    about_methods_desc: "A blend of analogue and digital tools captures nuances across journeys.",
    about_methods_list: "<ul><li>Sensory maps drawn from in-situ observation.</li><li>Photographic journaling aligned with peak schedules.</li><li>Cross-analysis between operational data and user testimonies.</li><li>Prototype sessions within participatory workshops.</li></ul>",
    about_team_title: "Team structure",
    about_team_desc: "Researchers, service designers, and accessibility specialists collaborate between Brussels, Ghent, and Liège.",
    // Blog
    blog_intro_label: "Insights",
    blog_intro_title: "Spatial orientation journal",
    blog_intro_desc: "Contributions gather longitudinal studies, field notes, and methodological frameworks.",
    blog_post1_title: "Synthesis Layers for Multimodal Indoor Navigation",
    blog_post2_title: "Lifecycle Audits for Digital Signage in Transit Interiors",
    blog_post3_title: "Designing Inclusive Wayfinding for Expansive Civic Campuses",
    blog_post1_meta: "Field study · 12 June 2024",
    blog_post2_meta: "Systems audit · 28 May 2024",
    blog_post3_meta: "Accessibility lens · 16 April 2024",
    blog_post1_excerpt: "Coordinating visual, sonic, and tactile signals directly shapes decision making within interconnected buildings.",
    blog_post2_excerpt: "Lifecycle auditing reveals how maintenance, editorial governance, and accessibility keep displays coherent.",
    blog_post3_excerpt: "Participatory practices transform dispersed campuses into navigable commons for varied publics.",
    // Post 1
    post1_intro_label: "Long-form analysis",
    post1_intro_summary: "This briefing dissects how sensory layers and digital systems synchronise to guide visitors.",
    post1_image_alt: "Passengers reading a large interactive map inside an indoor concourse",
    post1_caption: "Node-by-node recording in a Brussels interchange.",
    post1_content: `<h1>Synthesis Layers for Multimodal Indoor Navigation</h1><p>Belgian public buildings rarely operate as single-sensory spaces. Transport interchanges, cultural complexes, and administrative campuses all blend sound, light, and movement while attempting to remain legible to residents, commuters, and visitors. Our latest observation cycle explores how digital surfaces, static signs, and environmental cues combine into navigation experiences. The briefing documents numerous visits between Brussels, Ghent, and Liège, where multilingual announcements mix with architectural acoustics and media walls. We track how individuals assemble meaning from these simultaneous prompts, and we examine the thresholds where guidance succeeds or collapses. By layering attention to smell, light levels, and tactile clues into otherwise visual audits, we begin to understand how a person decides to continue forward, pause for reassurance, or retrace a route.</p><h2>Mapping Sensory Inputs to Spatial Decisions</h2><p>During walkthroughs, we record not only the position of wayfinding assets but their relationships. A kiosk delivering tram updates sits beside a café releasing strong aromas; a tactile floor strip directs people past a loud maintenance bay; colour-coded light bands fluctuate with occupancy data. Each element influences how the others are perceived. Our mapping grids therefore cross-reference sensory registers with spatial decision points. We observe whether a visitor notices a ceiling banner while juggling a luggage cart, or whether a multilingual announcement compels someone to turn towards a less visible corridor. These observations foster a layered understanding of how perception converges into tangible steps, aiding teams that manage both architecture and information systems.</p><h3>Data Synchronisation Benchmarks</h3><p>Synchronising content across digital surfaces becomes complex when multiple agencies share the same venue. We documented kiosks that refresh in fifteen-minute cycles, while adjacent LED panels pull real-time feeds. Visitors questioned why identical icons announced mismatched platform numbers. Our benchmark therefore compares timestamps, data provenance, and display cadence. By logging when feeds diverge, we provide evidence for harmonising APIs, content management workflows, and manual overrides. The benchmark is not a compliance checklist; it is a narrative showing how a commuter perceives fragmentation when inhaling diesel residue, listening for platform recalls, and reading conflicting arrows. Aligning these sensory layers proves as critical as installing new hardware.</p><p>We also plot tactile information against digital indexes. For example, a raised pictogram may still direct a blind traveller towards an escalator that recently became bidirectional. Without clear synchronisation routines, such travellers rely on staff who may not have received the latest updates. Our study proposes shared calendars linking infrastructure changes, audio announcements, and Braille overlays. This anticipatory work prevents disorientation from rippling through a building, even when renovation schedules shift unexpectedly.</p><h2>Interface Behaviours in Dense Buildings</h2><p>Dense buildings often funnel multiple flows through constrained vestibules. Screens, projections, and floor graphics all compete for attention within seconds. We watched families travelling with strollers navigate under hanging displays that scrolled lengthy text, while temporary vinyl arrows attempted to redirect them towards a quieter elevator block. The interplay between physical space and interface behaviour becomes decisive: when a screen animates too aggressively, people hesitate; when lighting is subdued, information fades into the background. Our study measures these effects through shadow diagrams, luminance readings, and acoustic snapshots that capture how reverberation buries crucial announcements.</p><h3>Adaptive Messaging Rhythm</h3><p>Messaging rhythm describes how often guidance repeats, how it acknowledges delays, and how it directs follow-up actions. In Belgian stations, announcements alternate between French, Dutch, English, and sometimes German. We chart the time it takes for a full cycle to complete and compare it with the patience of someone unfamiliar with the building. Digital signage should bridge the waiting period; yet we saw walls looping promotional content while passengers grew uneasy. We recommend programming adaptive loops triggered by crowd sensors and maintenance alerts. Instead of static playlists, interfaces should insert concise orientation reminders whenever obstacles appear. The rhythm must feel supportive rather than disruptive, complementing human stewards positioned nearby.</p><ul><li>Blend concise icons with minimal text so multilingual rotations remain rapid without sacrificing clarity.</li><li>Reserve a percentage of screen time for dynamic rerouting messages, ensuring emergency updates override ambient storytelling.</li><li>Use ambient lighting cues to point towards the next confirmation node, such as ticket validation or information desks.</li></ul><h2>Maintaining Field Reliability</h2><p>Reliability depends on continuous maintenance rituals. We tracked how cleaning crews, security teams, and information officers collaborate—or fail to collaborate—around signage systems. In several buildings, bulb replacements occurred without notifying the digital content team, leaving bright hallways that contradicted dim displays. Elsewhere, sticker overlays covered outdated icons but peeled after a week, exposing contradictory directions. We stress that field reliability should be treated as a shared asset. Governance charters should establish who validates translations, who audits tactile elements, and who responds when refurbishments alter canonical routes.</p><h3>Documentation Patterns</h3><p>Documentation becomes meaningful when it mirrors lived experience. Our reports integrate annotated video stills, decibel charts, olfactory notes, and transcripts from spontaneous interviews. Each element forms a chapter within a living atlas. We avoid isolating digital dashboards from the messy reality of people moving during strikes, festivals, or weather disruptions. Instead, we encourage teams to revisit documentation before launching interventions. When a building plans new kiosks, they should consult past diagrams indicating where queues naturally form, how ventilation affects speech intelligibility, and which accessibility advocates flagged overlooked obstacles. Documentation therefore evolves from static PDF archives into an operational memory shared across departments.</p><p>Ultimately, multimodal synthesis invites humility. No single interface solves orientation in a complex structure. The goal is to choreograph light, sound, texture, and language so visitors assemble a reliable map in their minds. Belgian institutions experimenting with this choreography demonstrate that rigorous observation, transparent data sharing, and collaborative maintenance can transform wandering into confident movement. Our research continues to track these experiments, providing the contextual evidence needed to keep digital and physical channels aligned.</p>`,
    // Post 2
    post2_intro_label: "Methodological study",
    post2_intro_summary: "A lifecycle audit uncovers the dependencies that keep digital signage coherent.",
    post2_image_alt: "Technician inspecting an information panel in a Belgian station",
    post2_caption: "Overnight maintenance follow-up in Antwerp.",
    post2_content: `<h1>Lifecycle Audits for Digital Signage in Transit Interiors</h1><p>Transit interiors in Belgium operate through cycles of wear, refurbishment, and technological refresh, yet signage networks often evolve piecemeal. This article examines how lifecycle audits expose the hidden dependencies that keep guidance coherent. Over twelve weeks we shadowed maintenance teams in Brussels, Antwerp, and Charleroi, tracing how displays are installed, patched, or retired. By correlating asset registers with on-site observations, we formed a chronological map of screens, speakers, projectors, and power supplies. The audit uncovers when digital infrastructure genuinely supports passenger comprehension and when it silently drifts out of alignment with architectural change.</p><h2>Tracing Hardware Life Stages</h2><p>Lifecycle auditing begins with establishing the age and condition of every component anchoring a signage network. Many stations inherit devices from previous operators, resulting in mixed vintages sharing the same circuit. We catalogued enclosures, backplates, cabling routes, and ventilation clearances. Thermal imaging revealed hotspots around screens installed without sufficient airflow, leading to progressive dimming. Such physical diagnostics inform decisions about relocation, cooling, or replacement. The audit also inspects mounting heights and viewing angles, comparing them with the evolving demographics of commuters, including wheelchair users and taller international travellers.</p><h3>Material Fatigue Indicators</h3><p>Material fatigue manifests in subtle ways: screws loosen from vibration, bezels warp under sunlight, anti-glare films yellow with cleaning products. We developed a scoring system capturing these indicators before failure occurs. Cleaning staff provided invaluable insights, noting surfaces that require repeated scrubbing after weekend events. Their observations signal when protective coatings are degrading. Combining these qualitative notes with quantitative lux readings produces an actionable profile. Rather than reacting to breakdowns, operators can schedule rotational maintenance that keeps the network visually consistent.</p><p>Another indicator involves the auditory infrastructure that accompanies visual signage. Speakers embedded in ceilings often face dust accumulation that muffles speech clarity. Our audit logs decibel levels and frequency responses, testing whether announcements remain intelligible when platforms crowd. Hardware that cannot maintain baseline clarity within agreed tolerances is flagged for replacement or repositioning. Maintaining these indicators prevents the frustration of passengers who otherwise rely on digital displays to confirm spoken updates.</p><h2>Content Governance in Shared Hubs</h2><p>Transit hubs host multiple agencies: transport operators, security teams, tourism offices, and commercial tenants. Each stakeholder may request screen time. Without a lifecycle perspective, the content calendar becomes a tug-of-war. We studied governance boards that coordinate messages through quarterly reviews, daily check-ins, and emergency protocols. Successful boards maintain inventories of mandatory content—safety notices, multilingual alerts, accessibility reminders—before approving ambient storytelling. The audit evaluates how governance structures adapt when unexpected events occur, such as sudden weather warnings or labour actions.</p><h3>Multi-Agency Coordination Models</h3><p>Coordination models vary. Some hubs rely on a central editor who aggregates updates. Others operate distributed authoring, where each agency uploads templates. We assessed response times by simulating disruptions: blocked escalators, re-routed buses, or lost-child alerts. The most resilient models featured shared taxonomies and modular message blocks. Templates stored in a version-controlled library ensured that font sizes, languages, and pictograms remained consistent. When agencies deviated from the library, readability dropped and staff delivered ad-hoc clarifications. Lifecycle audits therefore recommend governance agreements that tie hardware upgrades to content workflows, preventing mismatches between new screens and outdated templates.</p><p>We also mapped decision loops during overnight maintenance windows. Facilities teams often seize these hours to update firmware or recalibrate sensors. If communication chains fail, morning commuters encounter blank displays. Documented loops—who authorises downtime, who verifies restart success, who monitors remote diagnostics—are essential to keep orientation intact. These loops should be revisited whenever a new contractor joins the ecosystem.</p><h2>Sustaining Accessibility Across Updates</h2><p>Accessibility is a lifecycle commitment. Hardware upgrades may unintentionally reduce tactile contrast or reposition captions. We compared legacy configurations with new installations to ensure compliance with Belgian standards and the lived expectations of regular passengers. Particular attention was given to how subtitles, sign language inserts, and audio descriptions manifest on shared displays. When content editors shorten loops, accessibility overlays are sometimes trimmed first. Our audit advocates reserving fixed slots that cannot be overridden without escalation.</p><h3>Measurement Instruments</h3><p>To sustain accessibility, measurement instruments must be embedded in routine operations. We introduced checklists that blend objective metrics and subjective feedback. Objective metrics include contrast ratios, symbol heights, and refresh latency. Subjective feedback emerges from shadowing passengers with varied mobility, sensory, and cognitive profiles. Their narratives highlight micro-barriers: reflections that obscure arrows at sunset, or voice prompts that overlap with public address announcements. Embedding these instruments into lifecycle audits ensures that upgrades do not erase earlier accessibility gains.</p><ul><li>Document every intervention with date-stamped photos and sensor readings to maintain traceability.</li><li>Create cross-disciplinary retrospectives after disruptions to analyse where communication or hardware failed.</li><li>Align procurement cycles with training so staff understand how to operate and maintain new signage assets.</li></ul><p>Lifecycle thinking transforms digital signage from a scattered collection of screens into a dependable navigation companion. When hardware diagnostics, governance models, and accessibility instruments intertwine, Belgian transit interiors remain intelligible even as they evolve. The audit perspective also fosters empathy for those who keep these systems running: technicians swapping power supplies at dawn, designers refining pictograms after community workshops, and announcers calibrating tone during service changes. By sustaining their collaboration, passengers encounter guidance that feels cared for rather than improvised.</p>`,
    // Post 3
    post3_intro_label: "Inclusive perspective",
    post3_intro_summary: "Expansive campuses become legible through co-creation and care protocols.",
    post3_image_alt: "Group walking through a civic campus with wayfinding supports",
    post3_caption: "Shared route with associations in Namur.",
    post3_content: `<h1>Designing Inclusive Wayfinding for Expansive Civic Campuses</h1><p>Belgian civic campuses often span multiple blocks, blending administrative buildings, cultural venues, and open landscapes. Wayfinding in these environments must respond to diverse communities: residents accessing public services, students attending evening classes, tourists exploring exhibitions, and civil servants moving between meetings. This article distils findings from longitudinal studies at campuses in Brussels, Namur, and Ostend. By combining spatial analysis, storytelling workshops, and iterative prototypes, we explore how inclusive guidance emerges when authority is shared across institutions with distinct mandates.</p><h2>Mapping Campus Identities</h2><p>An expansive campus rarely speaks with a single voice. Each building bears its own signage, colour palette, and tone. Visitors may interpret these differences as boundaries, unsure whether they are permitted to cross a courtyard or enter an atrium. We conduct identity mapping to reveal overlaps and gaps. This involves photographing entrances at different times of day, documenting how light, vegetation, and street life alter perception. We compare the narratives communicated through plaques, banners, and digital directories. The aim is to detect where conflicting identities obstruct orientation and where cohesive motifs already exist.</p><h3>Community Co-Research</h3><p>Identity mapping is complemented by community co-research. We invite staff, neighbours, and service users to annotate printed maps with memories and frustrations. During workshops, participants explain the rituals that structure their visits: dropping off children at language classes, queuing for administrative documents, or attending performances after work. These narratives unveil informal shortcuts, perceived safe zones, and areas to avoid after dusk. Co-research grounds the design process in lived experience, ensuring proposed interventions respect established social agreements rather than imposing external logic.</p><h2>Segmenting Pedestrian Typologies</h2><p>Pedestrian typologies describe the tempo, expectations, and constraints of different campus users. We avoid stereotypes by basing typologies on observed behaviour and interviews. Some pedestrians move with urgency, such as delivery staff navigating tight schedules. Others prefer contemplative strolls, like retirees attending cultural programmes. The segmentation informs how signage hierarchy and spatial cues should adapt. Quick-moving typologies benefit from high-contrast beacons and direct language. Reflective typologies appreciate storytelling plaques, audio guides, or augmented reality overlays offering historical context.</p><h3>Care and Maintenance Protocols</h3><p>Inclusive wayfinding deteriorates without care. Maintenance protocols must define who monitors plant growth obscuring signs, who refreshes tactile paths, and who recalibrates outdoor lighting. At one campus, volunteer gardeners pruned hedges but inadvertently hid directional posts. We helped faculty administration collaborate with gardeners to establish shared checklists. Another campus faced vandalised orientation pillars. Instead of simply replacing them, the maintenance protocol introduced community ambassadors who report issues via a messaging channel. Protocols align human stewardship with environmental conditions, reinforcing inclusion through reliable upkeep.</p><h2>Inclusive Communication Channels</h2><p>Wayfinding extends beyond physical signs. Inclusive communication draws on multiple channels: mobile notifications, print materials, human guides, and ambient cues. We evaluate how each channel reaches multilingual audiences, people with sensory impairments, and newcomers lacking institutional context. Mobile notifications must avoid assuming constant connectivity. Print materials should employ typefaces legible to dyslexic readers. Human guides, whether volunteers or staff, need scripts that reflect inclusive language policies. Ambient cues—lighting sequences, water features, wind chimes—can signal thresholds without relying on text.</p><h3>Evaluation Loops</h3><p>Evaluation loops transform inclusion from a one-time project into an ongoing practice. We establish loops that combine seasonal audits, digital feedback forms, and shadowing sessions. Seasonal audits examine how weather alters walkability; snow or heavy rain may render tactile markers slippery. Digital forms capture stories from those unable to attend workshops. Shadowing sessions follow individuals as they navigate new layouts, capturing gestures, questions, and pauses. The loops feed into dashboards where campus teams can detect persistent friction points and schedule responsive action.</p><ul><li>Design campus welcome centres as knowledge commons, offering printed guides, tactile maps, and links to real-time updates.</li><li>Coordinate signage glossaries so vocabulary remains consistent across departments and rented venues.</li><li>Publish transparent maintenance logs showing when routes were inspected, cleaned, or updated.</li></ul><p>Inclusive wayfinding is not merely about adding ramps or translating text. It involves cultivating relationships that keep information trustworthy. When architectural, cultural, and administrative actors collaborate, campuses feel porous and welcoming. Belgian examples demonstrate that even historical sites can adopt participatory governance to sustain inclusion. The ongoing challenge is to maintain momentum: retesting assumptions after renovations, inviting new voices to co-create materials, and celebrating care work that often remains invisible. Through these practices, expansive campuses evolve into navigable commons serving everyone.</p>`,
    // FAQ
    faq_intro_title: "Frequently asked questions",
    faq_intro_desc: "Clarifying how we document, share, and update spatial orientation insights.",
    faq_item1_content: "<h3>How are observation sites selected?</h3><p>We collaborate with public agencies facing navigation or multilingual challenges. Visits are conducted with the consent of operators and communities.</p>",
    faq_item2_content: "<h3>What deliverables are produced?</h3><p>Annotated plans, photographic notebooks, interview transcripts, and synthesis tables that support discussions between technical teams and site leaders.</p>",
    faq_item3_content: "<h3>How often do you publish analyses?</h3><p>Major studies appear quarterly, complemented by shorter notes after specific events or maintenance phases.</p>",
    faq_item4_content: "<h3>How do you include user feedback?</h3><p>Through workshops, accompanied walks, and open forms. Feedback is anonymised before integration.</p>",
    faq_item5_content: "<h3>Do you operate outside Belgium?</h3><p>Our resources focus on Belgian institutions. We share methods so other territories can adapt them locally.</p>",
    faq_item6_content: "<h3>How should your analyses be cited?</h3><p>Please reference danswholesaleplants, the study title, and publication date. Documents always include a version identifier.</p>",
    // Contact
    contact_intro_label: "Reach out",
    contact_intro_title: "Collaborate on spatial orientation research",
    contact_intro_desc: "Use this channel to propose joint observation, share field feedback, or request methodological detail.",
    contact_details_title: "Coordination details",
    contact_phone_label: "Telephone",
    contact_phone_value: "+32 2 808 34 55",
    contact_email_label: "Email",
    contact_email_value: "contact@danswholesaleplants.com",
    contact_hours_label: "Availability",
    contact_hours_value: "Monday to Friday, 09:00–18:00 CET",
    contact_support_note: "We usually respond within two working days.",
    contact_form_title: "Send a message",
    contact_form_desc: "Describe the context, buildings involved, and your navigation questions.",
    contact_form_name_label: "Name",
    contact_form_name_placeholder: "Your full name",
    contact_form_email_label: "Email",
    contact_form_email_placeholder: "Your professional email",
    contact_form_org_label: "Organisation",
    contact_form_org_placeholder: "Institution or team",
    contact_form_message_label: "Message",
    contact_form_message_placeholder: "Describe the environment and navigation topics to explore.",
    contact_form_submit: "Proceed to confirmation",
    contact_map_caption: "Location near European institutions in Brussels.",
    contact_map_title: "Map showing Rue de la Loi 200 in Brussels",
    // Legal
    legal_intro_label: "Legal framework",
    terms_intro_title: "Terms of use",
    terms_intro_desc: "These terms govern access to materials published by danswholesaleplants.",
    terms_content: `<h1>Terms of Use</h1><p>These terms apply to all content published on danswholesaleplants.com. By browsing the site you accept the rules, which may be updated at any time.</p><h2>1. Scope</h2><p>The site shares analysis and resources related to spatial orientation and digital signage. It is non-commercial and does not constitute a service offer.</p><h2>2. Definitions</h2><p>“Platform” refers to danswholesaleplants.com. “User” means any person accessing the content. “Content” includes text, images, diagrams, and downloadable material.</p><h2>3. Language</h2><p>Content is available in French and English. If interpretations differ, the French version prevails.</p><h2>4. Use of content</h2><p>Content is provided for information purposes. Any reuse must clearly credit the source and respect the integrity of the analysis.</p><h2>5. Intellectual property</h2><p>Unless otherwise stated, content belongs to danswholesaleplants. It may not be reproduced or exploited without written permission.</p><h2>6. Platform access</h2><p>Access is free and may be suspended or modified for maintenance, improvement, or security reasons.</p><h2>7. External references</h2><p>The site may link to external resources. danswholesaleplants is not responsible for their availability or content.</p><h2>8. Research materials</h2><p>Methodological documents and datasets are shared for transparency. Any reuse must respect the stated licences.</p><h2>9. User contributions</h2><p>Feedback submitted via forms or email may be cited anonymously. Users guarantee the accuracy of the information provided.</p><h2>10. Privacy reference</h2><p>Data processing is described in the privacy policy. Questions may be sent to the contact address.</p><h2>11. Liability limits</h2><p>danswholesaleplants does not guarantee completeness and cannot be held liable for decisions made using published analyses.</p><h2>12. Changes to terms</h2><p>Terms may be revised at any time. The update date appears at the top of the page.</p><h2>13. Governing law</h2><p>These terms are governed by Belgian law. Disputes fall under the jurisdiction of the courts of Brussels.</p><h2>14. Contact</h2><p>For questions, email contact@danswholesaleplants.com or use the form on the Contact page.</p>`,
    privacy_intro_title: "Privacy policy",
    privacy_intro_desc: "This policy explains how danswholesaleplants processes personal data within its editorial activities.",
    privacy_content: `<h1>Privacy Policy</h1><p>We take care to protect personal data collected during use of the site.</p><h2>1. Controller</h2><p>The controller is danswholesaleplants, Rue de la Loi 200, 1040 Brussels, Belgium.</p><h2>2. Data collected</h2><p>We collect data provided through the contact form (name, email, organisation, message) and minimal technical information for audience statistics.</p><h2>3. Collection methods</h2><p>Data is obtained directly from users or through analytical cookies strictly necessary to understand traffic.</p><h2>4. Purpose</h2><p>Data is used to respond to messages, arrange research exchanges, and improve editorial content.</p><h2>5. Lawful basis</h2><p>Processing relies on our legitimate interest in responding to requests and monitoring site usage.</p><h2>6. Retention</h2><p>Contact data is stored as long as needed to follow up exchanges, for no longer than two years of inactivity. Statistics are aggregated and anonymised.</p><h2>7. Sharing</h2><p>Data is not sold. It may be shared with technical providers hosting the site or ensuring security, bound by confidentiality obligations.</p><h2>8. International transfers</h2><p>We favour hosting within the European Economic Area. Any transfer will include appropriate safeguards.</p><h2>9. Rights</h2><p>You may request access, rectification, erasure, or restriction by contacting contact@danswholesaleplants.com.</p><h2>10. Security</h2><p>Technical and organisational measures protect data against loss, unauthorised access, or disclosure.</p><h2>11. Updates</h2><p>This policy may change to reflect practice evolution. The revision date appears at the top of the page.</p>`,
    cookies_intro_title: "Cookie management",
    cookies_intro_desc: "We limit cookies to what is necessary for language preference and audience measurement.",
    cookies_content: `<h1>Cookies and similar technologies</h1><p>This site uses a small number of cookies to maintain bilingual functionality and measure audience.</p><table><thead><tr><th>Name</th><th>Provider</th><th>Type</th><th>Purpose</th><th>Duration</th></tr></thead><tbody><tr><td>site_lang</td><td>danswholesaleplants</td><td>Functional</td><td>Remember the language selected by the user.</td><td>12 months</td></tr><tr><td>cookie_consent</td><td>danswholesaleplants</td><td>Functional</td><td>Store the cookie consent choice.</td><td>12 months</td></tr><tr><td>analytics_session</td><td>danswholesaleplants</td><td>Analytics</td><td>Measure page visits in aggregate form.</td><td>24 hours</td></tr></tbody></table><p>You can adjust your preferences by clearing cookies in your browser or contacting us.</p>`,
    refund_intro_title: "Refund policy",
    refund_intro_desc: "Although the site conducts no sales, this policy explains how we handle correction or withdrawal requests regarding our publications.",
    refund_content: `<h1>Refund Policy</h1><p>danswholesaleplants does not sell products or services. This policy outlines how we address adjustment requests concerning our publications.</p><h2>1. Purpose</h2><p>Clarify procedures for adjusting content when information must be refined or withdrawn.</p><h2>2. Scope</h2><p>The policy covers articles, reports, and shared resources published on the site.</p><h2>3. No financial transactions</h2><p>No money is exchanged. Requests focus solely on information quality.</p><h2>4. Event-related requests</h2><p>If a session or workshop is rescheduled, registered participants receive a new date or a detailed summary.</p><h2>5. Documentary corrections</h2><p>Individuals referenced may request corrections. We verify the request and release a revised, dated version.</p><h2>6. Processing time</h2><p>We acknowledge receipt within five working days and aim to address the request within thirty days.</p><h2>7. Communication channel</h2><p>Requests should be sent via the contact form or by email to contact@danswholesaleplants.com.</p><h2>8. Exceptions</h2><p>A request may be declined if it undermines analytical integrity or relies on clearly inaccurate information.</p><h2>9. Archiving</h2><p>Revised versions are archived to preserve change history.</p><h2>10. Policy review</h2><p>This policy is reviewed regularly and the update date appears on the page.</p>`,
    disclaimer_intro_title: "Disclaimer",
    disclaimer_intro_desc: "Published content serves informational and research purposes.",
    disclaimer_content: `<h1>Disclaimer</h1><p>Analyses published on danswholesaleplants reflect observation findings and do not constitute tailored professional advice.</p><h2>No guarantee</h2><p>We strive for accuracy but cannot guarantee completeness or permanent updates.</p><h2>Limited responsibility</h2><p>danswholesaleplants is not liable for decisions made using the published materials. Users remain responsible for their choices.</p><h2>External resources</h2><p>External links are provided for convenience. We do not control their content.</p><h2>Content evolution</h2><p>Publications may be updated or removed without notice to reflect research progress.</p>`,
    // Thank you
    thank_intro_title: "Thank you for your message",
    thank_intro_desc: "We have received your submission and will reply within two working days.",
    thank_return_link: "Return to the homepage"
  }
};
let currentLang = DEFAULT_LANG;
let toastTimer = null;

document.addEventListener("DOMContentLoaded", function () {
  const storedLang = localStorage.getItem(LANG_KEY);
  const initialLang = storedLang && I18N[storedLang] ? storedLang : DEFAULT_LANG;
  applyLanguage(initialLang);
  setupLangButtons();
  setupNavToggle();
  initScrollAnimations();
  initCookieBanner();
  initFormHandlers();
  highlightActiveNav();
  const toast = document.getElementById("global-toast");
  if (toast) {
    const closeBtn = toast.querySelector(".toast-close");
    if (closeBtn) {
      closeBtn.addEventListener("click", hideToast);
    }
  }
});

function substitutePlaceholders(text) {
  if (typeof text !== "string") {
    return text;
  }
  return text.replace("{year}", new Date().getFullYear());
}

function applyLanguage(lang) {
  if (!I18N[lang]) {
    return;
  }
  currentLang = lang;
  localStorage.setItem(LANG_KEY, lang);
  document.documentElement.setAttribute("lang", lang);
  const langData = I18N[lang];

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (langData[key] !== undefined) {
      el.textContent = substitutePlaceholders(langData[key]);
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach((el) => {
    const key = el.getAttribute("data-i18n-html");
    if (langData[key] !== undefined) {
      el.innerHTML = substitutePlaceholders(langData[key]);
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (langData[key] !== undefined) {
      el.setAttribute("placeholder", substitutePlaceholders(langData[key]));
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    if (langData[key] !== undefined) {
      el.setAttribute("alt", substitutePlaceholders(langData[key]));
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title");
    if (langData[key] !== undefined) {
      const value = substitutePlaceholders(langData[key]);
      if (el.tagName.toLowerCase() === "title") {
        el.textContent = value;
      } else {
        el.setAttribute("title", value);
      }
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.getAttribute("data-i18n-meta");
    if (langData[key] !== undefined) {
      el.setAttribute("content", substitutePlaceholders(langData[key]));
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria-label");
    if (langData[key] !== undefined) {
      el.setAttribute("aria-label", substitutePlaceholders(langData[key]));
    }
  });

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    const isActive = btn.getAttribute("data-lang") === lang;
    btn.classList.toggle("is-active", isActive);
    btn.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function setupLangButtons() {
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.getAttribute("data-lang");
      if (lang && lang !== currentLang) {
        applyLanguage(lang);
      }
    });
  });
}

function setupNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  if (!toggle) {
    return;
  }
  toggle.addEventListener("click", () => {
    const isOpen = !document.body.classList.contains("nav-open");
    document.body.classList.toggle("nav-open", isOpen);
    toggle.setAttribute("aria-expanded", String(isOpen));
  });
  document.querySelectorAll(".main-nav a").forEach((link) => {
    link.addEventListener("click", () => {
      if (document.body.classList.contains("nav-open")) {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  });
  window.addEventListener("resize", () => {
    if (window.innerWidth >= 768 && document.body.classList.contains("nav-open")) {
      document.body.classList.remove("nav-open");
      toggle.setAttribute("aria-expanded", "false");
    }
  });
}

function highlightActiveNav() {
  const page = document.body.getAttribute("data-page") || "";
  const target = page.startsWith("post") ? "blog" : page;
  document.querySelectorAll(".main-nav a[data-page-target]").forEach((link) => {
    const matches = link.getAttribute("data-page-target") === target;
    link.classList.toggle("active", matches);
    if (matches) {
      link.setAttribute("aria-current", "page");
    } else {
      link.removeAttribute("aria-current");
    }
  });
}

function initScrollAnimations() {
  const animated = document.querySelectorAll("[data-animate]");
  if (!("IntersectionObserver" in window)) {
    animated.forEach((el) => el.classList.add("in-view"));
    return;
  }
  const observer = new IntersectionObserver(
    (entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          obs.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  animated.forEach((el) => observer.observe(el));
}

function initCookieBanner() {
  const banner = document.getElementById("cookie-banner");
  const accept = document.getElementById("cookie-accept");
  if (!banner || !accept) {
    return;
  }
  const consent = localStorage.getItem("cookie_consent");
  if (!consent) {
    requestAnimationFrame(() => {
      banner.classList.add("active");
    });
  }
  accept.addEventListener("click", () => {
    localStorage.setItem("cookie_consent", "accepted");
    banner.classList.remove("active");
  });
}

function initFormHandlers() {
  document.querySelectorAll("form[data-toast]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const message = I18N[currentLang]?.toast_form_success || "";
      if (message) {
        showToast(message);
      }
      setTimeout(() => {
        form.submit();
      }, 600);
    });
  });
}

function showToast(message) {
  const toast = document.getElementById("global-toast");
  if (!toast) {
    return;
  }
  const messageEl = toast.querySelector(".toast-message");
  if (messageEl) {
    messageEl.textContent = message;
  }
  toast.classList.add("show");
  if (toastTimer) {
    clearTimeout(toastTimer);
  }
  toastTimer = setTimeout(() => {
    hideToast();
  }, 4000);
}

function hideToast() {
  const toast = document.getElementById("global-toast");
  if (!toast) {
    return;
  }
  toast.classList.remove("show");
  if (toastTimer) {
    clearTimeout(toastTimer);
    toastTimer = null;
  }
}