document.addEventListener('DOMContentLoaded', function () {
    const banner = document.getElementById('cookieBanner');
    if (!banner) {
        return;
    }
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');
    const preference = localStorage.getItem('mirabirjnaCookieChoice');

    if (!preference) {
        banner.classList.add('active');
    }

    acceptBtn.addEventListener('click', function () {
        localStorage.setItem('mirabirjnaCookieChoice', 'accepted');
        banner.classList.remove('active');
    });

    declineBtn.addEventListener('click', function () {
        localStorage.setItem('mirabirjnaCookieChoice', 'declined');
        banner.classList.remove('active');
    });
});