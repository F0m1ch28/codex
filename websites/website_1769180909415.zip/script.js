document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    const navLinks = siteNav.querySelectorAll("a");
    const toggleNav = () => {
      const isOpen = siteNav.classList.toggle("nav-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    };
    navToggle.addEventListener("click", toggleNav);
    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("nav-open")) {
          siteNav.classList.remove("nav-open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const yearHolders = document.querySelectorAll(".current-year");
  const currentYear = new Date().getFullYear();
  yearHolders.forEach((el) => {
    el.textContent = currentYear;
  });

  const animatedItems = document.querySelectorAll("[data-animate]");
  if (animatedItems.length > 0 && "IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    animatedItems.forEach((item) => observer.observe(item));
  } else {
    animatedItems.forEach((item) => item.classList.add("is-visible"));
  }

  const cookieBanner = document.getElementById("cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("#cookie-accept");
    const declineBtn = cookieBanner.querySelector("#cookie-decline");
    const storedChoice = localStorage.getItem("shsCookieChoice");
    if (!storedChoice) {
      setTimeout(() => {
        cookieBanner.classList.add("visible");
      }, 600);
    } else {
      cookieBanner.remove();
    }
    const handleChoice = (choice) => {
      localStorage.setItem("shsCookieChoice", choice);
      cookieBanner.classList.remove("visible");
      setTimeout(() => {
        cookieBanner.remove();
      }, 400);
    };
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => handleChoice("accept"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => handleChoice("decline"));
    }
  }

  const forms = document.querySelectorAll("form[data-redirect]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const target = form.getAttribute("action") || "thank-you.html";
      const toast = document.getElementById("form-toast");
      const message = form.dataset.toastMessage || "Mesaj transmis.";
      if (toast) {
        toast.textContent = message;
        toast.classList.add("show");
        setTimeout(() => {
          toast.classList.remove("show");
          window.location.href = target;
        }, 1600);
      } else {
        window.location.href = target;
      }
    });
  });
});