import React from 'react';

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container">
          <span className="badge">Privacy</span>
          <h1>Privacy Policy</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>
      <section className="legal-content">
        <div className="container">
          <h2>1. Overview</h2>
          <p>
            [Company Name] is committed to protecting your privacy. This policy outlines how we collect,
            use, store, and safeguard your personal information when you interact with our Services.
          </p>

          <h2>2. Information we collect</h2>
          <p>We collect information that you provide directly to us, including:</p>
          <ul>
            <li>Contact details when you fill out forms or subscribe to communications;</li>
            <li>Professional information when exploring partnerships or career opportunities;</li>
            <li>Usage data collected automatically via cookies and analytics tools.</li>
          </ul>

          <h2>3. How we use your information</h2>
          <p>We use your information to:</p>
          <ul>
            <li>Provide, maintain, and improve our Services;</li>
            <li>Communicate with you about opportunities, updates, and events;</li>
            <li>Ensure security, detect fraud, and comply with legal obligations.</li>
          </ul>

          <h2>4. Data sharing</h2>
          <p>
            We do not sell your personal information. We may share data with trusted service providers who
            assist us in operating the Services, subject to confidentiality obligations.
          </p>

          <h2>5. Your rights</h2>
          <p>
            Depending on your location, you may have rights to access, correct, or delete your personal data.
            To exercise these rights, contact privacy@company.com.
          </p>

          <h2>6. Data security</h2>
          <p>
            We implement reasonable safeguards to protect personal information. However, no system is
            completely secure, and we cannot guarantee absolute security.
          </p>

          <h2>7. Updates</h2>
          <p>
            We may update this policy periodically. We encourage you to review it regularly to stay informed
            about how we protect your information.
          </p>

          <h2>8. Contact</h2>
          <p>
            For privacy-related inquiries, email us at{' '}
            <a href="mailto:privacy@company.com">privacy@company.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;