import React from 'react';

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container">
          <span className="badge">Legal</span>
          <h1>Terms of Use</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>
      <section className="legal-content">
        <div className="container">
          <h2>1. Acceptance of the Terms</h2>
          <p>
            By accessing or using the [Company Name] website, platforms, or services (collectively, the
            “Services”), you agree to be bound by these Terms of Use and our Privacy Policy. If you do
            not agree, please discontinue use immediately.
          </p>

          <h2>2. Use of Services</h2>
          <p>
            You may use the Services solely for lawful purposes. You are responsible for all content you
            submit and must ensure it does not violate any applicable laws or infringe upon the rights
            of others.
          </p>

          <h2>3. Intellectual Property</h2>
          <p>
            All content, trademarks, logos, and service marks displayed on the Services are owned by or
            licensed to [Company Name]. You may not reproduce, distribute, or create derivative works
            without our express written permission.
          </p>

          <h2>4. Disclaimers</h2>
          <p>
            The Services are provided “as is” without warranties of any kind. We do not guarantee that
            the Services will be uninterrupted, secure, or error-free.
          </p>

          <h2>5. Limitation of Liability</h2>
          <p>
            To the maximum extent permitted by law, [Company Name] shall not be liable for any indirect,
            incidental, special, consequential, or punitive damages resulting from your use of the Services.
          </p>

          <h2>6. Modifications</h2>
          <p>
            We may update these Terms from time to time. Continued use of the Services after changes
            constitutes acceptance of the updated Terms.
          </p>

          <h2>7. Contact</h2>
          <p>
            For questions about these Terms, please contact us at{' '}
            <a href="mailto:legal@company.com">legal@company.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;