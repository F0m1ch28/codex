import React from 'react';

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container">
          <span className="badge">About us</span>
          <h1>We exist to architect growth for visionary organizations.</h1>
          <p>
            [Company Name] was founded on the belief that bold ideas deserve equally bold execution.
            We blend strategists, designers, engineers, and change experts who thrive on tackling
            complexity and unlocking new value for global enterprises.
          </p>
        </div>
      </section>

      <section className="about-story">
        <div className="container two-column">
          <div>
            <h2>Guided by purpose, driven by outcomes</h2>
            <p>
              Across industries and continents, our teams mobilize around shared goals: improve
              customer experiences, accelerate digital capabilities, and deliver measurable results.
              We embed ourselves within your organization to create momentum that endures beyond launch.
            </p>
            <p>
              With hubs in New York, London, and Singapore, we partner with clients around the world.
              Our diverse perspective ensures we design inclusive, resilient solutions anchored in human truth.
            </p>
          </div>
          <div className="about-image">
            <img
              src="https://picsum.photos/800/600?random=202"
              alt="Team members collaborating during a strategy workshop"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="about-values">
        <div className="container section-header">
          <h2>Values that shape every partnership</h2>
          <p>We aspire to be the most trusted partner for digital transformation.</p>
        </div>
        <div className="container values-grid">
          <article>
            <h3>Human-centered impact</h3>
            <p>
              We focus relentlessly on end users, ensuring every solution drives meaningful experiences
              for people and scalable returns for businesses.
            </p>
          </article>
          <article>
            <h3>Craft with integrity</h3>
            <p>
              Quality is non-negotiable. We operate with transparency, humility, and curiosity to deliver
              resilient outcomes built on trust.
            </p>
          </article>
          <article>
            <h3>Momentum through collaboration</h3>
            <p>
              Co-creation fuels our work. By connecting multidisciplinary teams, we move from vision to execution
              faster and smarter together.
            </p>
          </article>
          <article>
            <h3>Always be evolving</h3>
            <p>
              We embrace continuous learning. Emerging technologies, shifting markets, and new expectations
              demand relentless innovation.
            </p>
          </article>
        </div>
      </section>

      <section className="about-timeline">
        <div className="container section-header">
          <h2>Milestones on our journey</h2>
          <p>From boutique consultancy to global partner, we are just getting started.</p>
        </div>
        <div className="container timeline">
          <div className="timeline-item">
            <span>2014</span>
            <div>
              <h3>Founded in New York City</h3>
              <p>
                Launched with a mission to blend strategy and design for companies navigating digital transformation.
              </p>
            </div>
          </div>
          <div className="timeline-item">
            <span>2017</span>
            <div>
              <h3>Global delivery model</h3>
              <p>
                Expanded to London and Singapore, building a 24/7 delivery model to support enterprise clients.
              </p>
            </div>
          </div>
          <div className="timeline-item">
            <span>2020</span>
            <div>
              <h3>AI & automation practice</h3>
              <p>
                Introduced advanced analytics and automation services to accelerate intelligent decision-making.
              </p>
            </div>
          </div>
          <div className="timeline-item">
            <span>2023</span>
            <div>
              <h3>100th transformation program delivered</h3>
              <p>
                Celebrated our 100th enterprise engagement with measurable impact across customers, operations, and teams.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="page-cta">
        <div className="container cta-inline">
          <div>
            <h2>Let&apos;s design the future together</h2>
            <p>
              Partner with our team to shape what&apos;s next for your organization. We&apos;ll meet you where you are
              and accelerate progress with confidence.
            </p>
          </div>
          <a href="/contact" className="btn-primary">
            Connect with us
          </a>
        </div>
      </section>
    </div>
  );
};

export default About;