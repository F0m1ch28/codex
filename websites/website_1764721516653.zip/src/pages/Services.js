import React, { useState } from 'react';

const serviceDetails = [
  {
    title: 'Strategy & Transformation',
    intro:
      'Unlock future-ready business models and build alignment across leadership, technology, and operations.',
    bullets: [
      'Customer journey mapping & experience blueprinting',
      'Operating model design & change management',
      'Innovation labs and venture incubation',
      'Digital maturity assessments and executive coaching',
    ],
  },
  {
    title: 'Product & Experience Design',
    intro:
      'Shape digital products and services with human-centered research, experimentation, and best-in-class craft.',
    bullets: [
      'UX/UI design systems and prototyping',
      'Service design and omnichannel experiences',
      'Inclusive design and accessibility compliance',
      'Design ops and workflow enablement',
    ],
  },
  {
    title: 'Engineering & Platform Modernization',
    intro:
      'Design and deliver modern architectures that scale with security, resilience, and operational excellence.',
    bullets: [
      'Cloud-native development and DevOps automation',
      'Legacy modernization and microservices',
      'API ecosystems and integration frameworks',
      'Cybersecurity and compliance governance',
    ],
  },
  {
    title: 'Data, AI & Automation',
    intro:
      'Activate data intelligence with advanced analytics, machine learning, and automation at scale.',
    bullets: [
      'Enterprise data strategy and governance',
      'AI use case design and model validation',
      'Intelligent automation and process optimization',
      'Responsible AI, ethics, and regulatory compliance',
    ],
  },
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container">
          <span className="badge">How we can help</span>
          <h1>Integrated capabilities engineered for measurable change.</h1>
          <p>
            We combine strategy, design, engineering, and data to deliver experiences that resonate
            with customers and transform operations. Explore our core capabilities.
          </p>
        </div>
      </section>

      <section className="services-tabs">
        <div className="container tab-layout">
          <aside className="tab-list" role="tablist" aria-orientation="vertical">
            {serviceDetails.map((service, index) => (
              <button
                key={service.title}
                type="button"
                role="tab"
                className={index === activeIndex ? 'active' : ''}
                aria-selected={index === activeIndex}
                onClick={() => setActiveIndex(index)}
              >
                <span>{service.title}</span>
                <small>{service.intro}</small>
              </button>
            ))}
          </aside>
          <div className="tab-panel">
            <h2>{serviceDetails[activeIndex].title}</h2>
            <p>{serviceDetails[activeIndex].intro}</p>
            <ul>
              {serviceDetails[activeIndex].bullets.map((bullet) => (
                <li key={bullet}>{bullet}</li>
              ))}
            </ul>
            <a href="/contact" className="btn-primary">
              Discuss this service
            </a>
          </div>
        </div>
      </section>

      <section className="services-proof">
        <div className="container section-header">
          <h2>Proof of impact</h2>
          <p>Results that demonstrate our commitment to performance and excellence.</p>
        </div>
        <div className="container metrics-grid">
          <article>
            <h3>42%</h3>
            <p>Revenue growth for a global retailer after deploying a unified commerce platform.</p>
          </article>
          <article>
            <h3>16 weeks</h3>
            <p>From ideation to MVP launch for a disruptive digital banking product.</p>
          </article>
          <article>
            <h3>3x</h3>
            <p>Increase in digital self-service adoption for an energy provider within 6 months.</p>
          </article>
          <article>
            <h3>99.98%</h3>
            <p>Platform availability achieved for a mission-critical healthcare system.</p>
          </article>
        </div>
      </section>

      <section className="page-cta">
        <div className="container cta-inline">
          <div>
            <h2>Need a custom engagement?</h2>
            <p>
              We tailor teams, processes, and success metrics around your objectives. Let&apos;s co-create
              a solution built for your customers and teams.
            </p>
          </div>
          <a href="/contact" className="btn-secondary">
            Start the conversation
          </a>
        </div>
      </section>
    </div>
  );
};

export default Services;