import React, { useState } from 'react';

const initialState = {
  name: '',
  email: '',
  company: '',
  budget: '',
  message: '',
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email.';
    }
    if (!formData.company.trim()) newErrors.company = 'Please enter your company name.';
    if (!formData.budget.trim()) newErrors.budget = 'Please select a budget range.';
    if (!formData.message.trim()) newErrors.message = 'Please tell us about your project.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container">
          <span className="badge">Let&apos;s collaborate</span>
          <h1>Tell us about the future you want to build.</h1>
          <p>
            We partner closely with executive teams, product leaders, and innovators to deliver bold,
            measurable outcomes. Share a few details and we&apos;ll connect within one business day.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <h2>Project inquiry</h2>
            <p>We&apos;re excited to learn about your opportunity and goals.</p>

            <label htmlFor="name">Full name</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Jane Doe"
              value={formData.name}
              onChange={handleChange}
            />
            {errors.name && <span className="error">{errors.name}</span>}

            <label htmlFor="email">Work email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@company.com"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <span className="error">{errors.email}</span>}

            <label htmlFor="company">Company</label>
            <input
              id="company"
              name="company"
              type="text"
              placeholder="Company name"
              value={formData.company}
              onChange={handleChange}
            />
            {errors.company && <span className="error">{errors.company}</span>}

            <label htmlFor="budget">Estimated budget</label>
            <select
              id="budget"
              name="budget"
              value={formData.budget}
              onChange={handleChange}
            >
              <option value="">Select a range</option>
              <option value="Under $50K">Under $50K</option>
              <option value="$50K - $150K">$50K - $150K</option>
              <option value="$150K - $500K">$150K - $500K</option>
              <option value="$500K+">$500K+</option>
            </select>
            {errors.budget && <span className="error">{errors.budget}</span>}

            <label htmlFor="message">Project details</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Share your goals, timeline, and current challenges."
              value={formData.message}
              onChange={handleChange}
            />
            {errors.message && <span className="error">{errors.message}</span>}

            <button type="submit" className="btn-primary">
              Submit inquiry
            </button>
            <small>
              By submitting this form you agree to our <a href="/privacy">Privacy Policy</a>.
            </small>
            {submitted && (
              <div className="success">
                Thank you! We&apos;ll be in touch shortly to schedule a discovery call.
              </div>
            )}
          </form>

          <aside className="contact-info">
            <div className="contact-card">
              <h3>Global headquarters</h3>
              <p>
                220 Madison Avenue<br />
                New York, NY 10016<br />
                United States
              </p>
              <a href="tel:+1234567890">+1 (234) 567-890</a>
              <a href="mailto:hello@company.com">hello@company.com</a>
            </div>
            <div className="contact-card">
              <h3>Regional hubs</h3>
              <ul>
                <li>London, United Kingdom</li>
                <li>Singapore, Asia Pacific</li>
                <li>Toronto, Canada</li>
              </ul>
            </div>
            <div className="contact-card">
              <h3>Join the team</h3>
              <p>
                We&apos;re always looking for strategists, designers, engineers, and product leaders to shape what&apos;s next.
              </p>
              <a className="btn-secondary" href="#careers">
                View open roles
              </a>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
};

export default Contact;