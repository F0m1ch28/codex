import React, { useState, useEffect, useRef } from 'react';

const statsData = [
  { label: 'Client Impact', value: 120, suffix: '+', description: 'global transformation programs delivered' },
  { label: 'Team Experts', value: 85, suffix: '+', description: 'strategists, designers, and engineers' },
  { label: 'Satisfaction', value: 98, suffix: '%', description: 'client retention over the past 5 years' },
  { label: 'Markets', value: 14, suffix: '', description: 'countries where we drive digital growth' },
];

const servicesData = [
  {
    title: 'Experience Strategy',
    description: 'Define bold visions with measurable roadmaps that align leadership, teams, and technology.',
    icon: '🌐',
  },
  {
    title: 'Product Innovation',
    description: 'Prototype and launch digital products that delight customers and fuel new revenue streams.',
    icon: '🚀',
  },
  {
    title: 'Enterprise Platforms',
    description: 'Deploy scalable platforms that modernize legacy systems and power resilient operations.',
    icon: '🏢',
  },
  {
    title: 'Data Intelligence',
    description: 'Activate data ecosystems with real-time analytics, automation, and AI enablement.',
    icon: '📊',
  },
];

const processSteps = [
  {
    title: 'Discover & Align',
    description: 'We deep dive into your business model, customers, and technology capabilities to uncover opportunities.',
  },
  {
    title: 'Design & Prototype',
    description: 'Our multidisciplinary team shapes the solution with rapid prototyping and iterative testing.',
  },
  {
    title: 'Build & Integrate',
    description: 'We engineer scalable architectures and integrate seamlessly with your core platforms.',
  },
  {
    title: 'Launch & Evolve',
    description: 'Continuous optimization ensures sustained performance and ongoing innovation at scale.',
  },
];

const testimonials = [
  {
    quote:
      '“[Company Name] reimagined our digital ecosystem, resulting in a 42% revenue increase within the first quarter post-launch.”',
    author: 'Amelia Foster',
    role: 'Chief Digital Officer, NovaTech',
  },
  {
    quote:
      '“Their collaborative DNA and technical rigor made them an indispensable partner in our transformation journey.”',
    author: 'Leo Martin',
    role: 'VP of Product, Vista Group',
  },
  {
    quote:
      '“From strategy to delivery, the team exceeded expectations and empowered our teams with new capabilities.”',
    author: 'Priya Desai',
    role: 'Head of Innovation, Orbit Finance',
  },
];

const teamMembers = [
  {
    name: 'Jordan Clarke',
    role: 'Managing Partner',
    image: 'https://picsum.photos/400/400?random=31',
  },
  {
    name: 'Sofia Ramirez',
    role: 'Head of Experience Design',
    image: 'https://picsum.photos/400/400?random=32',
  },
  {
    name: 'Miles Chen',
    role: 'Lead Solutions Architect',
    image: 'https://picsum.photos/400/400?random=33',
  },
  {
    name: 'Harper Lee',
    role: 'Director of Data Science',
    image: 'https://picsum.photos/400/400?random=34',
  },
];

const projectsData = [
  {
    title: 'NovaTech Commerce Platform',
    category: 'Technology',
    image: 'https://picsum.photos/1200/800?random=41',
  },
  {
    title: 'Orbit Finance Customer App',
    category: 'Financial Services',
    image: 'https://picsum.photos/1200/800?random=42',
  },
  {
    title: 'Vista Group Employee Experience',
    category: 'Enterprise',
    image: 'https://picsum.photos/1200/800?random=43',
  },
  {
    title: 'Atlas Health Digital Portal',
    category: 'Healthcare',
    image: 'https://picsum.photos/1200/800?random=44',
  },
  {
    title: 'Lumen Energy Control Center',
    category: 'Energy',
    image: 'https://picsum.photos/1200/800?random=45',
  },
  {
    title: 'Verve Mobility Fleet Intelligence',
    category: 'Transportation',
    image: 'https://picsum.photos/1200/800?random=46',
  },
];

const categories = ['All', 'Technology', 'Financial Services', 'Enterprise', 'Healthcare', 'Energy', 'Transportation'];

const faqData = [
  {
    question: 'How do you structure engagements for large-scale transformation projects?',
    answer:
      'We co-create a multi-phase roadmap that aligns executive priorities, success metrics, and delivery milestones. Engagements include cross-functional squads, governance, and dedicated change management support.',
  },
  {
    question: 'Do you work with internal teams or fully manage delivery?',
    answer:
      'Every engagement is bespoke. We can serve as your dedicated delivery partner or embed within your teams to upskill talent and accelerate impact together.',
  },
  {
    question: 'What industries do you specialize in?',
    answer:
      'We have deep expertise across financial services, healthcare, energy, retail, and technology. Our blind is to solve complex challenges for progressive organizations ready for growth.',
  },
  {
    question: 'How quickly can you launch a new digital product?',
    answer:
      'Our innovation sprints help clients prototype and validate new product concepts in as little as 4 weeks, with market-ready launches typically following within 12-16 weeks depending on scope.',
  },
];

const blogPosts = [
  {
    title: 'Designing Platforms That Scale with Your Customers',
    image: 'https://picsum.photos/800/600?random=51',
    date: 'May 28, 2024',
    excerpt:
      'Explore our framework for building experience-driven platforms that adapt and evolve with customer expectations.',
  },
  {
    title: 'Five Signals That Your Enterprise is Ready for AI',
    image: 'https://picsum.photos/800/600?random=52',
    date: 'May 12, 2024',
    excerpt:
      'AI maturity requires intentional planning. Learn the operational and cultural indicators that your teams are prepared.',
  },
  {
    title: 'Modernizing Legacy Systems Without Disruption',
    image: 'https://picsum.photos/800/600?random=53',
    date: 'April 30, 2024',
    excerpt:
      'A playbook for leaders navigating mission-critical transformations while protecting day-to-day operations.',
  },
];

const Home = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [faqOpen, setFaqOpen] = useState(null);
  const [statsAnimated, setStatsAnimated] = useState(false);
  const statsRef = useRef(null);
  const animationFrameId = useRef();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsAnimated) {
            setStatsAnimated(true);
          }
        });
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, [statsAnimated]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!statsAnimated) return;

    const startTime = performance.now();
    const durations = statsData.map(() => 1800);

    const step = (now) => {
      const elapsed = now - startTime;
      const updatedValues = statsData.map((stat, index) => {
        const progress = Math.min(elapsed / durations[index], 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        return Math.floor(stat.value * eased);
      });

      statsData.forEach((stat, index) => {
        const element = document.querySelector(`#stat-${index}`);
        if (element) {
          element.textContent = `${updatedValues[index]}${stat.suffix}`;
        }
      });

      if (elapsed < Math.max(...durations)) {
        animationFrameId.current = requestAnimationFrame(step);
      }
    };

    animationFrameId.current = requestAnimationFrame(step);

    return () => cancelAnimationFrame(animationFrameId.current);
  }, [statsAnimated]);

  const filteredProjects =
    activeCategory === 'All'
      ? projectsData
      : projectsData.filter((project) => project.category === activeCategory);

  const toggleFaq = (index) => {
    setFaqOpen((prev) => (prev === index ? null : index));
  };

  return (
    <div className="home-page">
      <section className="hero" id="hero">
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="badge">Award-winning digital transformation partner</span>
            <h1>
              Accelerate what&apos;s next with design-led strategy, modern engineering, and measurable impact.
            </h1>
            <p>
              We craft breakthrough experiences and resilient platforms that help organizations move faster,
              smarter, and with greater confidence. From vision to execution, we align teams around
              customer-centric innovation.
            </p>
            <div className="hero-actions">
              <a className="btn-primary" href="#contact">
                Book a strategy call
              </a>
              <a className="btn-link" href="#projects">
                Explore our work
              </a>
            </div>
            <div className="hero-stats">
              <div>
                <strong>Enterprise trusted</strong>
                <p>Partnering with Fortune 500 and high-growth disruptors.</p>
              </div>
              <div>
                <strong>End-to-end delivery</strong>
                <p>Strategy, design, engineering, and change enablement.</p>
              </div>
            </div>
          </div>
          <div className="hero-media">
            <div className="hero-image-wrapper">
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Team collaborating in a modern workspace"
                loading="lazy"
              />
              <div className="media-overlay">
                <div>
                  <span>In partnership with</span>
                  <strong>Future-forward enterprises</strong>
                </div>
                <p>We activate technology investments with human-centered experiences.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <div className="stat-value" id={`stat-${index}`}>
                {statsAnimated ? `${stat.value}${stat.suffix}` : `0${stat.suffix}`}
              </div>
              <h3>{stat.label}</h3>
              <p>{stat.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="services" id="services">
        <div className="container section-header">
          <h2>Capabilities designed for transformation</h2>
          <p>
            From strategic advisory to integrated delivery, we help organizations unlock new
            value. Our multidisciplinary team brings vision, craft, and measurable momentum.
          </p>
        </div>
        <div className="container services-grid">
          {servicesData.map((service) => (
            <article className="service-card" key={service.title}>
              <span className="service-icon" aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <button type="button" className="btn-ghost">
                Discover more
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className="process" id="process">
        <div className="container section-header">
          <h2>Our collaborative approach</h2>
          <p>
            Every engagement is grounded in partnership, transparency, and momentum. We work in
            co-creation with your teams to deliver outcomes that endure.
          </p>
        </div>
        <div className="container process-steps">
          {processSteps.map((step, index) => (
            <div className="process-step" key={step.title}>
              <div className="step-number">0{index + 1}</div>
              <div className="step-content">
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="testimonials">
        <div className="container section-header">
          <h2>Leaders trust us to deliver meaningful change</h2>
          <p>Read what our clients are saying about cross-functional impact at scale.</p>
        </div>
        <div className="container testimonials-slider">
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.author}
              className={`testimonial-card ${index === activeTestimonial ? 'is-active' : ''}`}
            >
              <p>{testimonial.quote}</p>
              <div className="testimonial-author">
                <span>{testimonial.author}</span>
                <small>{testimonial.role}</small>
              </div>
            </article>
          ))}
          <div className="testimonial-controls">
            {testimonials.map((_, index) => (
              <button
                key={`dot-${index}`}
                type="button"
                className={index === activeTestimonial ? 'active' : ''}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Show testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="team" id="team">
        <div className="container section-header">
          <h2>Meet the leadership behind every engagement</h2>
          <p>Seasoned experts dedicated to aligning vision, quality, and delivery excellence.</p>
        </div>
        <div className="container team-grid">
          {teamMembers.map((member) => (
            <article className="team-card" key={member.name}>
              <div className="team-image">
                <img src={member.image} alt={`Portrait of ${member.name}`} loading="lazy" />
              </div>
              <div className="team-info">
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <button type="button" className="btn-link">
                  Connect on LinkedIn
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container section-header">
          <h2>Selected work shaping industries</h2>
          <p>
            We deliver measurable outcomes across sectors. Filter by industry to explore how we
            activate vision into results.
          </p>
        </div>
        <div className="container projects-filters">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={category === activeCategory ? 'active' : ''}
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        <div className="container projects-grid">
          {filteredProjects.map((project) => (
            <article className="project-card" key={project.title}>
              <div className="project-image">
                <img src={project.image} alt={`${project.title} case study visual`} loading="lazy" />
              </div>
              <div className="project-content">
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <a href="#contact" className="btn-link">
                  View case study
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="insight" id="insight">
        <div className="container section-header">
          <h2>Insights to stay ahead</h2>
          <p>Thought leadership designed to keep your teams informed and inspired.</p>
        </div>
        <div className="container blog-grid">
          {blogPosts.map((post) => (
            <article className="blog-card" key={post.title}>
              <div className="blog-image">
                <img src={post.image} alt={post.title} loading="lazy" />
              </div>
              <div className="blog-content">
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href="#contact" className="btn-link">
                  Read the article
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container section-header">
          <h2>Frequently asked questions</h2>
          <p>Transparent partnerships begin with clear answers. Explore our most common discussions.</p>
        </div>
        <div className="container faq-accordion">
          {faqData.map((item, index) => (
            <div
              className={`faq-item ${faqOpen === index ? 'is-open' : ''}`}
              key={item.question}
            >
              <button
                type="button"
                onClick={() => toggleFaq(index)}
                className="faq-question"
                aria-expanded={faqOpen === index}
              >
                {item.question}
                <span>{faqOpen === index ? '−' : '+'}</span>
              </button>
              <div className="faq-answer">
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="cta-section" id="contact">
        <div className="container cta-grid">
          <div className="cta-content">
            <h2>Ready to orchestrate what&apos;s next?</h2>
            <p>
              Let&apos;s align on your most pressing priorities and build a roadmap to achieve them.
              We&apos;ll bring the strategy, design, and technology to deliver outcomes at speed.
            </p>
            <ul>
              <li>Complimentary transformation consultation</li>
              <li>Tailored roadmap with measurable milestones</li>
              <li>Access to specialist advisors and solution leads</li>
            </ul>
          </div>
          <form className="cta-form">
            <label htmlFor="cta-name">Name</label>
            <input id="cta-name" type="text" placeholder="Your name" required />
            <label htmlFor="cta-email">Work Email</label>
            <input id="cta-email" type="email" placeholder="name@company.com" required />
            <label htmlFor="cta-company">Company</label>
            <input id="cta-company" type="text" placeholder="Company name" required />
            <label htmlFor="cta-message">Message</label>
            <textarea
              id="cta-message"
              placeholder="Share your challenges or goals..."
              rows="4"
              required
            />
            <button type="submit" className="btn-primary">
              Schedule consultation
            </button>
            <small>
              By submitting, you agree to our{' '}
              <a href="/privacy">Privacy Policy</a> and <a href="/terms">Terms of Use</a>.
            </small>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Home;