import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="brand-mark">[C]</div>
          <p>
            We partner with ambitious teams to build products, brands, and experiences
            that redefine what&apos;s possible in the digital era.
          </p>
          <div className="footer-contact">
            <a href="tel:+1234567890">+1 (234) 567-890</a>
            <a href="mailto:hello@company.com">hello@company.com</a>
          </div>
        </div>
        <div className="footer-column">
          <h4>Company</h4>
          <ul>
            <li><NavLink to="/about">About</NavLink></li>
            <li><NavLink to="/services">Services</NavLink></li>
            <li><NavLink to="/terms">Terms</NavLink></li>
            <li><NavLink to="/privacy">Privacy</NavLink></li>
          </ul>
        </div>
        <div className="footer-column">
          <h4>Solutions</h4>
          <ul>
            <li><a href="#services">Digital Strategy</a></li>
            <li><a href="#projects">Product Design</a></li>
            <li><a href="#process">Enterprise Platforms</a></li>
            <li><a href="#faq">Innovation Labs</a></li>
          </ul>
        </div>
        <div className="footer-column">
          <h4>Stay Updated</h4>
          <p>Sign up to receive strategic insights and invitations to exclusive events.</p>
          <form className="footer-form">
            <label htmlFor="footer-email" className="sr-only">
              Email address
            </label>
            <input id="footer-email" type="email" placeholder="Your email" required />
            <button type="submit">Subscribe</button>
          </form>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
              X (Twitter)
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer">
              Instagram
            </a>
          </div>
        </div>
      </div>
      <div className="container footer-bottom">
        <p>© {new Date().getFullYear()} [Company Name]. All rights reserved.</p>
        <div className="footer-bottom-links">
          <NavLink to="/privacy">Privacy Policy</NavLink>
          <NavLink to="/terms">Terms of Use</NavLink>
        </div>
      </div>
    </footer>
  );
};

export default Footer;