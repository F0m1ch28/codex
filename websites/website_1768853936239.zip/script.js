document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  const body = document.body;

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      siteNav.classList.toggle("is-visible");
      body.classList.toggle("nav-open");
    });

    siteNav.querySelectorAll(".nav-link").forEach(function (link) {
      link.addEventListener("click", function () {
        if (siteNav.classList.contains("is-visible")) {
          siteNav.classList.remove("is-visible");
          navToggle.setAttribute("aria-expanded", "false");
          body.classList.remove("nav-open");
        }
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const consent = localStorage.getItem("pmi-cookie-consent");
    if (consent) {
      cookieBanner.classList.add("is-hidden");
    }

    const acceptButton = cookieBanner.querySelector("[data-cookie-accept]");
    const declineButton = cookieBanner.querySelector("[data-cookie-decline]");

    const setConsent = function (value) {
      localStorage.setItem("pmi-cookie-consent", value);
      cookieBanner.classList.add("is-hidden");
    };

    if (acceptButton) {
      acceptButton.addEventListener("click", function () {
        setConsent("accepted");
      });
    }

    if (declineButton) {
      declineButton.addEventListener("click", function () {
        setConsent("declined");
      });
    }
  }
});