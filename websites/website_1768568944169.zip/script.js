document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.nav-menu a');
    const body = document.body;
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            siteNav.classList.toggle('is-active');
            body.classList.toggle('nav-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('is-active')) {
                    siteNav.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                    body.classList.remove('nav-open');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedDecision = localStorage.getItem('knittekkkmCookieDecision');
        if (storedDecision) {
            cookieBanner.classList.add('is-hidden');
        } else {
            setTimeout(() => {
                cookieBanner.classList.add('is-visible');
            }, 800);
        }

        const buttons = cookieBanner.querySelectorAll('[data-cookie-decision]');
        buttons.forEach(button => {
            button.addEventListener('click', () => {
                const decision = button.dataset.cookieDecision;
                localStorage.setItem('knittekkkmCookieDecision', decision);
                cookieBanner.classList.remove('is-visible');
                cookieBanner.classList.add('is-hidden');
                setTimeout(() => {
                    window.open('cookies.html', '_blank');
                }, 240);
            });
        });
    }
});