import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Policy.module.css';

function Terms() {
  return (
    <>
      <Helmet>
        <title>Terms of Use | TechSolutions</title>
        <meta
          name="description"
          content="Read TechSolutions terms of use governing access to our website, services, intellectual property, and user responsibilities."
        />
      </Helmet>
      <section className={styles.policy}>
        <div className="layout">
          <h1>Terms of Use</h1>
          <p className={styles.updated}>Effective date: January 1, 2024</p>

          <h2>Acceptance of terms</h2>
          <p>
            By accessing or using the TechSolutions website, you agree to comply with these Terms of Use and our Privacy Policy. If you do not agree, please discontinue use.
          </p>

          <h2>Use of content</h2>
          <p>
            All materials on this site, including text, graphics, logos, and imagery, are property of TechSolutions or our licensors. You may not reproduce or exploit any content without prior written consent.
          </p>

          <h2>User responsibilities</h2>
          <p>
            You agree not to misuse our website, attempt unauthorized access, or engage in any activity that disrupts our services. You are responsible for the information you submit and must ensure it is accurate and lawful.
          </p>

          <h2>Disclaimers</h2>
          <p>
            This site is provided “as is” without warranties of any kind. We disclaim liability for errors, inaccuracies, or interruptions and do not guarantee specific outcomes from consulting services described.
          </p>

          <h2>Limitation of liability</h2>
          <p>
            To the fullest extent permitted by law, TechSolutions will not be liable for any indirect, incidental, or consequential damages arising from your use of the website or reliance on its content.
          </p>

          <h2>Third-party links</h2>
          <p>
            Our website may reference third-party sites or resources. We are not responsible for their content, security, or practices. Accessing third-party links is at your own risk.
          </p>

          <h2>Modifications</h2>
          <p>
            We reserve the right to update these Terms at any time. Changes will be effective upon posting. Continued use of the website constitutes acceptance of the revised terms.
          </p>

          <h2>Governing law</h2>
          <p>
            These Terms are governed by the laws of the State of California, without regard to conflict of law principles. Any disputes shall be resolved in the state or federal courts located in San Francisco County, California.
          </p>

          <h2>Contact</h2>
          <p>
            For questions regarding these Terms, contact TechSolutions at <a href="mailto:info@techsolutions.com">info@techsolutions.com</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default Terms;