import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>About | studdfxg.world</title>
      <meta
        name="description"
        content="Learn about studdfxg.world, our mission, and the Irish educators helping learners grow their IT careers."
      />
    </Helmet>
    <section className={`${styles.hero} sectionSpacing`}>
      <div className="container">
        <h1>Our mission</h1>
        <p>
          studdfxg.world exists to make tech education accessible, practical, and locally relevant for people across
          Ireland. We believe everyone deserves the chance to learn in-demand skills without leaving their county,
          community, or current job.
        </p>
      </div>
    </section>

    <section className={`${styles.values} sectionSpacing`}>
      <div className="container">
        <div className={styles.grid}>
          <article>
            <h2>Practical-first learning</h2>
            <p>
              We focus on real projects, tangible feedback, and tools that Irish employers rely on. Theory is important,
              but you will always apply it in a realistic context.
            </p>
          </article>
          <article>
            <h2>Inclusive community</h2>
            <p>
              Our cohorts welcome career changers, parents returning to work, graduates, and professionals from every
              corner of Ireland. Diversity strengthens the learning experience for all.
            </p>
          </article>
          <article>
            <h2>Local insight</h2>
            <p>
              From guest speakers to hiring partners, we partner with organisations across Ireland to keep our content
              current and our learners connected.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={`${styles.story} sectionSpacing`}>
      <div className="container">
        <div className={styles.storyCard}>
          <img
            src="https://picsum.photos/800/600?random=204"
            alt="Learners collaborating in a modern workspace"
            loading="lazy"
          />
          <div>
            <h2>How it started</h2>
            <p>
              We began by supporting a small group of career changers in Dublin who needed flexible training during the
              pandemic. Word of mouth spread quickly, and soon we were welcoming learners from every province. Today we
              deliver courses across web development, data, cybersecurity, and more—always with an Irish lens.
            </p>
            <p>
              Our team includes instructors, mentors, career coaches, and learner success specialists. Together, we build
              a supportive environment where you can take on challenges, ask questions, and succeed.
            </p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default About;