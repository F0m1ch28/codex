import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ForIreland.module.css';

const ForIreland = () => (
  <>
    <Helmet>
      <title>For Ireland | studdfxg.world</title>
      <meta
        name="description"
        content="Discover how studdfxg.world tailors IT courses to Ireland with local mentors, Irish tech case studies, and flexible schedules."
      />
    </Helmet>
    <section className={`${styles.hero} sectionSpacing`}>
      <div className="container">
        <h1>Supporting learners across Ireland</h1>
        <p>
          From timing and content to mentors and community, every part of studdfxg.world is designed for people living in
          Ireland. We understand the local tech landscape and reflect it throughout the learning experience.
        </p>
      </div>
    </section>

    <section className={`${styles.content} sectionSpacing`}>
      <div className="container">
        <div className={styles.grid}>
          <article>
            <h2>Irish mentors &amp; guest speakers</h2>
            <p>
              Learn from engineers, designers, data specialists, and cybersecurity experts who work in Irish companies
              today. Hear their stories, ask questions, and build a network that lives where you do.
            </p>
          </article>
          <article>
            <h2>Local case studies</h2>
            <p>
              We incorporate case studies based on Irish SMEs, public-sector organisations, and scale-ups. You will
              understand regulatory requirements, workplace culture, and collaboration styles expected here.
            </p>
          </article>
          <article>
            <h2>Flexible time-zone friendly sessions</h2>
            <p>
              Live classes run in the evenings or at lunch-time to fit Irish schedules. If you miss anything, watch
              recorded sessions with time-stamped notes, then join weekly office hours to catch up.
            </p>
          </article>
          <article>
            <h2>Funding guidance</h2>
            <p>
              We keep track of Irish training grants, Skillnet opportunities, and employer sponsorship options. Our team
              guides you through applications so nothing slows down your learning journey.
            </p>
          </article>
        </div>
      </div>
    </section>

    <section className={`${styles.mapSection} sectionSpacing`}>
      <div className="container">
        <div className={styles.mapCard}>
          <h2>Nationwide community</h2>
          <p>
            Join learners from Dublin, Cork, Galway, Limerick, Waterford, and beyond. Our online community makes it easy
            to collaborate, share wins, and celebrate progress no matter where you are.
          </p>
          <img
            src="https://picsum.photos/800/600?random=202"
            alt="Illustration of Ireland highlighting connected learners"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  </>
);

export default ForIreland;