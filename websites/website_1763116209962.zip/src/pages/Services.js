import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <>
    <Helmet>
      <title>Services | studdfxg.world</title>
      <meta
        name="description"
        content="Discover studdfxg.world services for individuals and Irish organisations, including career accelerators, team upskilling, and mentored projects."
      />
    </Helmet>
    <section className={`${styles.hero} sectionSpacing`}>
      <div className="container">
        <h1>Services that move you forward</h1>
        <p>
          Whether you are learning for yourself or supporting a team, studdfxg.world offers structured services to help
          you build skills and translate them into real results in Ireland.
        </p>
      </div>
    </section>

    <section className={`${styles.services} sectionSpacing`}>
      <div className="container">
        <article className={styles.card} id="career">
          <h2>Career Accelerator Programmes</h2>
          <p>
            Cohort-based learning experiences with weekly mentorship, project milestones, and career preparation. Ideal
            for people who are changing careers or stepping into new responsibilities.
          </p>
          <ul>
            <li>Personalised learning roadmap</li>
            <li>Portfolio building with Irish case studies</li>
            <li>Interview preparation and employer introductions</li>
          </ul>
        </article>

        <article className={styles.card} id="teams">
          <h2>Team Upskilling Packages</h2>
          <p>
            Tailored programmes for Irish organisations that need to upskill their teams. We work with managers to align
            learning outcomes with business objectives and compliance requirements.
          </p>
          <ul>
            <li>Bespoke curriculum and scheduling</li>
            <li>Live workshops and recorded modules</li>
            <li>Progress dashboards for managers</li>
          </ul>
        </article>

        <article className={styles.card} id="mentored-projects">
          <h2>Mentored Project Labs</h2>
          <p>
            Solve real-world problems with support from senior Irish practitioners. Best for intermediate learners who
            want to polish their skills and gain confidence presenting to stakeholders.
          </p>
          <ul>
            <li>Weekly mentor check-ins</li>
            <li>Presentation practice and feedback</li>
            <li>Showcase events with Irish employers</li>
          </ul>
        </article>
      </div>
    </section>
  </>
);

export default Services;