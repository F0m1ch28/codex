import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Courses.module.css';

const courses = [
  {
    id: 'web-development',
    title: 'Intro to Web Development',
    level: 'Beginner',
    duration: '8 weeks • 5 hours/week',
    format: 'Live + on-demand',
    description:
      'Master the fundamentals of HTML, CSS, and JavaScript. Create responsive websites and build your first portfolio project, guided by Irish mentors who ship production code every day.',
    outcomes: [
      'Build responsive layouts and reusable UI patterns',
      'Understand version control with Git and GitHub',
      'Launch a personal site to showcase your work'
    ]
  },
  {
    id: 'python',
    title: 'Python for Beginners',
    level: 'Beginner',
    duration: '6 weeks • 4 hours/week',
    format: 'Flexible schedule',
    description:
      'Learn Python by solving practical challenges relevant to Irish organisations. Automate tasks, process data, and write clean code with support from experienced developers.',
    outcomes: [
      'Write and debug Python scripts confidently',
      'Apply automation techniques to real-world tasks',
      'Collaborate using cloud notebooks and Git'
    ]
  },
  {
    id: 'data-analysis',
    title: 'Data Analysis Foundations',
    level: 'Intermediate',
    duration: '10 weeks • 6 hours/week',
    format: 'Mentor-led projects',
    description:
      'Dig into data storytelling, SQL, and visual dashboards. Study Irish datasets, present insights to stakeholders, and build analytics projects that stand out in local job interviews.',
    outcomes: [
      'Work with SQL databases and clean messy data',
      'Create dashboards in Power BI and Tableau',
      'Communicate insights that drive business decisions'
    ]
  },
  {
    id: 'cybersecurity',
    title: 'Cybersecurity Basics',
    level: 'Beginner',
    duration: '7 weeks • 4 hours/week',
    format: 'Guided labs & workshops',
    description:
      'Gain a strong foundation in security principles, including risk assessments, compliance, and incident response. Designed around the needs of Irish SMEs and public-sector teams.',
    outcomes: [
      'Recognise and mitigate common security threats',
      'Map security practices to Irish/EU compliance',
      'Create a security improvement plan for SMEs'
    ]
  },
  {
    id: 'cloud',
    title: 'Cloud Fundamentals',
    level: 'Intermediate',
    duration: '9 weeks • 5 hours/week',
    format: 'Live labs',
    description:
      'Get hands-on with AWS and Azure. Learn how Irish companies structure modern cloud environments, and practice deploying scalable applications safely.',
    outcomes: [
      'Navigate AWS and Azure core services',
      'Deploy and monitor basic cloud infrastructure',
      'Understand cost, governance, and security essentials'
    ]
  },
  {
    id: 'ux',
    title: 'UX & Product Discovery',
    level: 'Intermediate',
    duration: '8 weeks • 5 hours/week',
    format: 'Project-based',
    description:
      'Explore user research, journey mapping, and prototyping with a focus on inclusive design. Collaborate on a discovery project for a local Irish organisation.',
    outcomes: [
      'Plan and conduct user research interviews',
      'Build interactive prototypes in Figma',
      'Share insight-driven recommendations with stakeholders'
    ]
  }
];

const Courses = () => (
  <>
    <Helmet>
      <title>Courses | studdfxg.world</title>
      <meta
        name="description"
        content="Explore our beginner to intermediate IT courses designed for Irish learners. Learn web development, Python, data analysis, cybersecurity, cloud, and UX online."
      />
    </Helmet>
    <section className={`${styles.hero} sectionSpacing`}>
      <div className="container">
        <span className={styles.breadcrumb}>Home / Courses</span>
        <h1>Practical IT courses designed for Ireland</h1>
        <p>
          Each programme combines structured lessons, hands-on projects, and supportive mentorship. Choose the pathway
          that matches your goals and availability.
        </p>
      </div>
    </section>

    <section className={`${styles.coursesList} sectionSpacing`}>
      <div className="container">
        <div className={styles.grid}>
          {courses.map((course) => (
            <article key={course.id} className={styles.courseCard} id={course.id}>
              <div className={styles.courseHeader}>
                <div>
                  <span className={styles.level}>{course.level}</span>
                  <h2>{course.title}</h2>
                </div>
                <div className={styles.meta}>
                  <span>{course.duration}</span>
                  <span>{course.format}</span>
                </div>
              </div>
              <p className={styles.description}>{course.description}</p>
              <ul className={styles.outcomes}>
                {course.outcomes.map((outcome) => (
                  <li key={outcome}>{outcome}</li>
                ))}
              </ul>
              <button type="button" className={styles.applyButton}>
                Request syllabus
              </button>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Courses;