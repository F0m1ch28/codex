import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Learners enrolled', value: 2450, suffix: '+' },
  { label: 'Career transitions', value: 640, suffix: '' },
  { label: 'Expert mentors', value: 40, suffix: '+' },
  { label: 'Learner satisfaction', value: 96, suffix: '%' }
];

const coursesData = [
  {
    title: 'Intro to Web Development',
    description: 'Go from zero to building responsive websites using HTML, CSS, and JavaScript.',
    level: 'Beginner',
    duration: '8 weeks • Online',
    link: '/courses#web-development'
  },
  {
    title: 'Python for Beginners',
    description: 'Learn practical Python programming and automation through hands-on projects.',
    level: 'Beginner',
    duration: '6 weeks • Online',
    link: '/courses#python'
  },
  {
    title: 'Data Analysis Foundations',
    description: 'Build confidence with spreadsheets, SQL, and visual dashboards in real-world Irish scenarios.',
    level: 'Intermediate',
    duration: '10 weeks • Online',
    link: '/courses#data-analysis'
  },
  {
    title: 'Cybersecurity Basics',
    description: 'Understand core security threats, compliance, and best practices for Irish SMEs.',
    level: 'Beginner',
    duration: '7 weeks • Online',
    link: '/courses#cybersecurity'
  },
  {
    title: 'Cloud Fundamentals',
    description: 'Get to grips with AWS and Azure essentials for modern Irish teams.',
    level: 'Intermediate',
    duration: '9 weeks • Online',
    link: '/courses#cloud'
  },
  {
    title: 'UX & Product Discovery',
    description: 'Design user-centered digital experiences with proven research frameworks.',
    level: 'Intermediate',
    duration: '8 weeks • Online',
    link: '/courses#ux'
  }
];

const howItWorksSteps = [
  {
    title: 'Choose your IT course',
    description: 'Start with a programme that matches your goals, whether you are upskilling or changing careers.'
  },
  {
    title: 'Learn online with practical tasks',
    description: 'Attend live sessions or catch up on-demand, then apply what you learn with guided projects.'
  },
  {
    title: 'Get feedback and support',
    description: 'Access Irish-based mentors, weekly office hours, and peer community feedback.'
  },
  {
    title: "Use your new skills in Ireland's job market",
    description: 'Build a strong portfolio and plan your next steps with employability advice tailored to Ireland.'
  }
];

const irelandHighlights = [
  {
    title: 'Suitable for Irish time zone',
    description: 'Live classes and mentor sessions scheduled around Irish business hours.'
  },
  {
    title: 'Relevant to EU/Irish tech market',
    description: 'Case studies and compliance topics aligned with Irish and EU regulations.'
  },
  {
    title: 'Online from anywhere in Ireland',
    description: 'From Dublin to Donegal, learn remotely with only a laptop and stable internet.'
  }
];

const testimonials = [
  {
    name: 'Aoife, Dublin',
    role: 'Career changer',
    quote:
      'The web development course gave me confidence to join a local startup. The mentors understood the Irish market and helped me prep for interviews.'
  },
  {
    name: 'Sean, Galway',
    role: 'IT support specialist',
    quote:
      'I upskilled with the cybersecurity track while working full-time. Flexible sessions meant zero stress and measurable progress every week.'
  },
  {
    name: 'Niamh, Cork',
    role: 'Final-year student',
    quote:
      'Loved the project-based approach. I got feedback fast and built a portfolio that landed me a paid internship in Cork.'
  }
];

const projectPortfolio = [
  {
    title: 'Irish Retail Dashboard',
    category: 'Data',
    description: 'Interactive Power BI dashboard for a Galway retailer tracking weekly performance.',
    image: 'https://picsum.photos/1200/800?random=401'
  },
  {
    title: 'Community Health Web App',
    category: 'Web',
    description: 'Responsive app prototype supporting local clinics across Leinster.',
    image: 'https://picsum.photos/1200/800?random=402'
  },
  {
    title: 'SME Security Audit Toolkit',
    category: 'Cybersecurity',
    description: 'Reusable policy templates for SMEs mapped to Irish regulations.',
    image: 'https://picsum.photos/1200/800?random=403'
  },
  {
    title: 'SaaS Onboarding UX',
    category: 'UX',
    description: 'End-to-end UX research and redesign for a Dublin SaaS product.',
    image: 'https://picsum.photos/1200/800?random=404'
  }
];

const teamMembers = [
  {
    name: 'Emma O’Donnell',
    role: 'Programme Director',
    bio: 'Former edtech leader focusing on learner success and inclusive curriculum design.',
    image: 'https://picsum.photos/400/400?random=301'
  },
  {
    name: 'Patrick Byrne',
    role: 'Lead Instructor, Web',
    bio: 'Full-stack engineer with experience at Irish startups and multinationals.',
    image: 'https://picsum.photos/400/400?random=302'
  },
  {
    name: 'Ciara Walsh',
    role: 'Career Coach',
    bio: 'Helps learners translate new skills into interviews, portfolios, and job offers.',
    image: 'https://picsum.photos/400/400?random=303'
  }
];

const blogPosts = [
  {
    title: 'How to plan your IT upskilling journey in Ireland',
    excerpt: 'Practical steps for balancing study, work, and life when switching into tech roles across Ireland.',
    date: 'March 2025',
    image: 'https://picsum.photos/800/600?random=501',
    link: '/blog/upskilling-ireland'
  },
  {
    title: 'Cybersecurity basics for Irish SMEs',
    excerpt: 'Understand the essential security safeguards Irish businesses expect from new hires.',
    date: 'February 2025',
    image: 'https://picsum.photos/800/600?random=502',
    link: '/blog/cyber-basics'
  },
  {
    title: 'From Galway to global: Remote tech careers',
    excerpt: 'Success stories from learners who now work remotely for teams across Europe while staying in Ireland.',
    date: 'January 2025',
    image: 'https://picsum.photos/800/600?random=503',
    link: '/blog/remote-tech'
  }
];

const faqItems = [
  {
    question: 'Do I need previous IT experience?',
    answer:
      'No prior experience is required for our beginner courses. We provide onboarding resources, foundational lessons, and beginner-friendly support to help you feel comfortable from week one.'
  },
  {
    question: 'Are the courses fully online?',
    answer:
      'Yes. You can join live sessions or watch on-demand recordings. Practical assignments, mentor feedback, and community events are all delivered online.'
  },
  {
    question: 'How much time per week do I need?',
    answer:
      'Plan for 4–6 hours per week for beginner tracks and 6–8 hours for intermediate programmes. Each course includes suggested schedules for both part-time and accelerated study.'
  },
  {
    question: 'Are the courses suitable for people working full-time?',
    answer:
      'Absolutely. We design each curriculum with flexible pacing, evening live sessions, quick catch-up recordings, and realistic projects suited to working professionals.'
  },
  {
    question: 'Will I receive a certificate?',
    answer:
      'Yes. Successfully completing the course project and assessments earns you a digital certificate recognised by employers across Ireland.'
  },
  {
    question: 'Can I speak with someone before enrolling?',
    answer:
      'Definitely—book a free call with our learner advisor to discuss goals, timelines, and funding options tailored to your situation.'
  }
];

const Home = () => {
  const [statsValues, setStatsValues] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const statsRef = useRef(null);

  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [activeCategory, setActiveCategory] = useState('All');
  const [faqOpenIndex, setFaqOpenIndex] = useState(0);

  const [formValues, setFormValues] = useState({ name: '', email: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [formStatus, setFormStatus] = useState('');

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (!statsAnimated && entries[0].isIntersecting) {
          setStatsAnimated(true);
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, [statsAnimated]);

  useEffect(() => {
    if (!statsAnimated) return;

    const duration = 1400;

    statsData.forEach((stat, index) => {
      let start = null;

      const step = (timestamp) => {
        if (!start) start = timestamp;
        const progress = Math.min((timestamp - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        const value = Math.floor(eased * stat.value);

        setStatsValues((prev) => {
          const next = [...prev];
          next[index] = value;
          return next;
        });

        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          setStatsValues((prev) => {
            const next = [...prev];
            next[index] = stat.value;
            return next;
          });
        }
      };

      requestAnimationFrame(step);
    });
  }, [statsAnimated]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    activeCategory === 'All'
      ? projectPortfolio
      : projectPortfolio.filter((project) => project.category === activeCategory);

  const handleFaqToggle = (index) => {
    setFaqOpenIndex((prev) => (prev === index ? -1 : index));
  };

  const handleInputChange = (event) => {
    setFormValues((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    if (formErrors[event.target.name]) {
      setFormErrors((prev) => {
        const next = { ...prev };
        delete next[event.target.name];
        return next;
      });
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!formValues.name.trim()) errors.name = 'Please introduce yourself.';
    if (!formValues.email.trim()) {
      errors.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      errors.email = 'Use a valid email address.';
    }
    if (!formValues.message.trim()) errors.message = 'Tell us what you would like to learn.';
    return errors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const errors = validateForm();
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      setFormStatus('Thanks! A member of our team will reach out within one working day.');
      setFormValues({ name: '', email: '', message: '' });
    } else {
      setFormStatus('');
    }
  };

  return (
    <>
      <Helmet>
        <title>studdfxg.world | IT Courses for Learners in Ireland</title>
        <meta
          name="description"
          content="Discover flexible IT courses tailored to learners in Ireland. Gain practical skills online with mentorship, projects, and career support."
        />
      </Helmet>

      <div className={styles.home}>
        <section className={`${styles.hero} sectionSpacing`}>
          <div className={`container ${styles.heroContentWrapper}`}>
            <div className={styles.heroText}>
              <span className={styles.badge}>Irish-focused online learning</span>
              <h1>IT Courses for Learners in Ireland</h1>
              <p>
                Master practical IT skills with flexible, project-based courses designed around Irish business needs.
                Learn online, meet local mentors, and open new opportunities without leaving home.
              </p>
              <div className={styles.heroButtons}>
                <Link className={`${styles.primaryButton} ${styles.ctaPulse}`} to="/courses">
                  Browse Courses
                </Link>
                <Link className={styles.secondaryButton} to="/contact">
                  Talk to an Advisor
                </Link>
              </div>
              <ul className={styles.heroHighlights}>
                <li>Beginner-friendly pathways</li>
                <li>Irish time-zone sessions</li>
                <li>Mentor support every week</li>
              </ul>
            </div>
            <div className={styles.heroVisual}>
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Learners collaborating online using laptops"
                loading="lazy"
              />
              <div className={styles.heroCard}>
                <strong>Flexible &amp; supportive</strong>
                <p>Join live or study on-demand with access to Irish mentors and peer community.</p>
              </div>
            </div>
          </div>
        </section>

        <section className={`sectionSpacing ${styles.benefitsSection}`}>
          <div className="container">
            <h2>Why learn with studdfxg.world?</h2>
            <p className={styles.sectionIntro}>
              We blend practical IT training with local context, so every lesson feels relevant to life and work in
              Ireland.
            </p>
            <div className={styles.benefitGrid}>
              <article>
                <h3>Ireland-focused support</h3>
                <p>Learn with instructors who understand Irish workplaces, regulations, and employer expectations.</p>
              </article>
              <article>
                <h3>Beginner-friendly IT courses</h3>
                <p>Start from scratch with structured foundations and dedicated mentor feedback every week.</p>
              </article>
              <article>
                <h3>Online &amp; flexible schedule</h3>
                <p>Balance learning with work and family thanks to evening live sessions and on-demand recordings.</p>
              </article>
              <article>
                <h3>Career-oriented skills</h3>
                <p>Build projects, portfolios, and confidence that translate directly into Ireland’s tech job market.</p>
              </article>
            </div>
          </div>
        </section>

        <section className={`${styles.statsSection} sectionSpacing`} ref={statsRef}>
          <div className="container">
            <div className={styles.statsBackground}>
              <h2>Trusted by learners across Ireland</h2>
              <div className={styles.statsGrid}>
                {statsData.map((stat, index) => (
                  <div key={stat.label} className={styles.statCard}>
                    <span className={styles.statValue}>
                      {statsValues[index]}
                      {stat.suffix}
                    </span>
                    <span className={styles.statLabel}>{stat.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.coursesSection} sectionSpacing`}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <div>
                <h2>Popular IT Courses</h2>
                <p>Pick a course aligned to your current experience and goals.</p>
              </div>
              <Link to="/courses" className={styles.viewAllLink}>
                View all courses →
              </Link>
            </div>
            <div className={styles.coursesGrid}>
              {coursesData.map((course) => (
                <article key={course.title} className={styles.courseCard}>
                  <div className={styles.courseBadge}>{course.level}</div>
                  <h3>{course.title}</h3>
                  <p>{course.description}</p>
                  <span className={styles.courseDuration}>{course.duration}</span>
                  <Link to={course.link} className={styles.courseLink}>
                    View Details
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.processSection} sectionSpacing`}>
          <div className="container">
            <h2>How It Works</h2>
            <div className={styles.timeline}>
              {howItWorksSteps.map((step, index) => (
                <div key={step.title} className={styles.timelineStep}>
                  <div className={styles.timelineNumber}>{index + 1}</div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.irelandSection} sectionSpacing`}>
          <div className="container">
            <div className={styles.irelandContent}>
              <div>
                <span className={styles.badge}>For Ireland</span>
                <h2>Built for learners in Ireland</h2>
                <p>
                  Our learning experience is designed around real Irish tech teams. You will work on projects that mirror
                  the tools, regulations, and collaboration styles used in local organisations.
                </p>
                <Link to="/for-ireland" className={styles.secondaryButton}>
                  Explore our Irish focus
                </Link>
              </div>
              <div className={styles.irelandGrid}>
                {irelandHighlights.map((item) => (
                  <article key={item.title}>
                    <h3>{item.title}</h3>
                    <p>{item.description}</p>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className={`${styles.testimonialsSection} sectionSpacing`}>
          <div className="container">
            <h2>What our learners say</h2>
            <div className={styles.testimonialWrapper}>
              <button
                type="button"
                className={styles.carouselControl}
                onClick={() =>
                  setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
                }
                aria-label="Previous testimonial"
              >
                ←
              </button>
              <div className={styles.testimonialCard} key={testimonialIndex}>
                <blockquote>“{testimonials[testimonialIndex].quote}”</blockquote>
                <footer>
                  <strong>{testimonials[testimonialIndex].name}</strong>
                  <span>{testimonials[testimonialIndex].role}</span>
                </footer>
              </div>
              <button
                type="button"
                className={styles.carouselControl}
                onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonials.length)}
                aria-label="Next testimonial"
              >
                →
              </button>
            </div>
            <div className={styles.carouselDots} role="tablist" aria-label="Testimonial slides">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  type="button"
                  className={`${styles.dot} ${index === testimonialIndex ? styles.dotActive : ''}`}
                  onClick={() => setTestimonialIndex(index)}
                  aria-label={`Go to testimonial ${index + 1}`}
                  aria-pressed={index === testimonialIndex}
                />
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.servicesSection} sectionSpacing`}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2>Services &amp; learning pathways</h2>
              <p>
                From one-off workshops to complete career transitions, we support every stage of your learning journey in
                Ireland.
              </p>
            </div>
            <div className={styles.servicesGrid}>
              <article>
                <h3>Career Accelerator</h3>
                <p>
                  Cohort-based programmes with portfolio projects, Irish mentor feedback, and interview preparation to
                  help you land a role in tech.
                </p>
                <Link to="/services#career" className={styles.learnMore}>
                  Learn more →
                </Link>
              </article>
              <article>
                <h3>Team Upskilling</h3>
                <p>
                  Custom training for Irish organisations needing to upskill staff in cloud, cyber, data, and digital
                  collaboration tools.
                </p>
                <Link to="/services#teams" className={styles.learnMore}>
                  Learn more →
                </Link>
              </article>
              <article>
                <h3>Mentored Projects</h3>
                <p>
                  Hands-on projects guided by senior Irish technologists. Build credible work samples with structured
                  mentor reviews.
                </p>
                <Link to="/services#mentored-projects" className={styles.learnMore}>
                  Learn more →
                </Link>
              </article>
            </div>
          </div>
        </section>

        <section className={`${styles.projectsSection} sectionSpacing`}>
          <div className="container">
            <h2>Featured learner projects</h2>
            <div className={styles.filterBar}>
              {['All', 'Web', 'Data', 'Cybersecurity', 'UX'].map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`${styles.filterButton} ${activeCategory === category ? styles.filterActive : ''}`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
            <div className={styles.projectsGrid}>
              {filteredProjects.map((project) => (
                <article key={project.title} className={styles.projectCard}>
                  <img src={project.image} alt={`${project.title} project preview`} loading="lazy" />
                  <div>
                    <span className={styles.projectCategory}>{project.category}</span>
                    <h3>{project.title}</h3>
                    <p>{project.description}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.teamSection} sectionSpacing`}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2>Meet the team guiding your progress</h2>
              <p>Our educators and coaches are based across Ireland with deep experience in the tech sector.</p>
            </div>
            <div className={styles.teamGrid}>
              {teamMembers.map((member) => (
                <article key={member.name} className={styles.teamCard}>
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                  <div className={styles.teamInfo}>
                    <h3>{member.name}</h3>
                    <span>{member.role}</span>
                    <p>{member.bio}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.faqSection} sectionSpacing`}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2>FAQ</h2>
              <p>Answers to the questions we hear most often from learners across Ireland.</p>
            </div>
            <div className={styles.faqAccordion}>
              {faqItems.map((item, index) => (
                <article key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    onClick={() => handleFaqToggle(index)}
                    aria-expanded={faqOpenIndex === index}
                    className={styles.faqButton}
                  >
                    <span>{item.question}</span>
                    <span className={styles.faqIcon}>{faqOpenIndex === index ? '−' : '+'}</span>
                  </button>
                  {faqOpenIndex === index && <p className={styles.faqAnswer}>{item.answer}</p>}
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.blogSection} sectionSpacing`}>
          <div className="container">
            <div className={styles.sectionHeader}>
              <h2>Latest insights</h2>
              <p>Stay informed with updates on the Irish tech landscape and practical learning tips.</p>
            </div>
            <div className={styles.blogGrid}>
              {blogPosts.map((post) => (
                <article key={post.title} className={styles.blogCard}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                  <div className={styles.blogContent}>
                    <span className={styles.blogDate}>{post.date}</span>
                    <h3>{post.title}</h3>
                    <p>{post.excerpt}</p>
                    <button type="button" className={styles.learnMore}>
                      Read article →
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={`${styles.contactSection} sectionSpacing`}>
          <div className="container">
            <div className={styles.contactWrapper}>
              <div className={styles.contactIntro}>
                <h2>Ready to take the next step?</h2>
                <p>
                  Tell us what you would like to learn and we will recommend the best course, funding options, and
                  schedule to match your goals in Ireland.
                </p>
                <ul className={styles.contactHighlights}>
                  <li>Personalised learning roadmap</li>
                  <li>Support with Irish training grants</li>
                  <li>Guidance from real mentors</li>
                </ul>
              </div>
              <form className={styles.contactForm} onSubmit={handleSubmit} noValidate>
                <div className={styles.formGroup}>
                  <label htmlFor="home-name">Name</label>
                  <input
                    id="home-name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    value={formValues.name}
                    onChange={handleInputChange}
                    aria-invalid={Boolean(formErrors.name)}
                  />
                  {formErrors.name && <span className={styles.formError}>{formErrors.name}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="home-email">Email</label>
                  <input
                    id="home-email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={formValues.email}
                    onChange={handleInputChange}
                    aria-invalid={Boolean(formErrors.email)}
                  />
                  {formErrors.email && <span className={styles.formError}>{formErrors.email}</span>}
                </div>
                <div className={styles.formGroup}>
                  <label htmlFor="home-message">What would you like to learn?</label>
                  <textarea
                    id="home-message"
                    name="message"
                    rows="4"
                    value={formValues.message}
                    onChange={handleInputChange}
                    aria-invalid={Boolean(formErrors.message)}
                  />
                  {formErrors.message && <span className={styles.formError}>{formErrors.message}</span>}
                </div>
                <button type="submit" className={styles.primaryButton}>
                  Send Message
                </button>
                {formStatus && (
                  <p className={styles.formSuccess} role="status">
                    {formStatus}
                  </p>
                )}
              </form>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;