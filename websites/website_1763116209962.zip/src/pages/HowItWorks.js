import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './HowItWorks.module.css';

const steps = [
  {
    title: 'Start with a strategy call',
    description:
      'Book a short call with our learner advisor. We will review your goals, availability, and any Irish funding options you may be eligible for.'
  },
  {
    title: 'Enroll and prepare',
    description:
      'Get access to your welcome kit, pre-course exercises, and community space. Meet your mentor and set your learning targets.'
  },
  {
    title: 'Attend learning sprints',
    description:
      'Work through weekly learning sprints with live workshops, recorded lessons, and guided projects. Attend Q&A sessions tailored to Irish case studies.'
  },
  {
    title: 'Build & showcase projects',
    description:
      'Create portfolio-ready work with feedback from mentors and peers. Learn how to present your project in a way that resonates with Irish employers.'
  },
  {
    title: 'Plan your next steps',
    description:
      'Wrap up with a personalised roadmap. Get career coaching, CV and LinkedIn reviews, and interview practice focused on roles in Ireland.'
  }
];

const HowItWorks = () => (
  <>
    <Helmet>
      <title>How It Works | studdfxg.world</title>
      <meta
        name="description"
        content="See how studdfxg.world guides you through Irish-focused IT courses, from strategy call to final project showcase and career support."
      />
    </Helmet>
    <section className={`${styles.hero} sectionSpacing`}>
      <div className="container">
        <h1>Learning that fits around life in Ireland</h1>
        <p>
          Our step-by-step approach keeps you supported from the moment you enquire until you are confidently applying
          your skills in the Irish workplace.
        </p>
      </div>
    </section>

    <section className={`${styles.steps} sectionSpacing`}>
      <div className="container">
        <div className={styles.timeline}>
          {steps.map((step, index) => (
            <article key={step.title} className={styles.card}>
              <span className={styles.number}>{index + 1}</span>
              <div>
                <h2>{step.title}</h2>
                <p>{step.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.support} sectionSpacing`}>
      <div className="container">
        <div className={styles.supportGrid}>
          <div>
            <h2>Support you can rely on</h2>
            <p>
              Every course includes dedicated success managers, Irish-based mentors, and a welcoming community. You will
              never be stuck on your own.
            </p>
            <ul>
              <li>Weekly office hours with mentors</li>
              <li>Peer accountability groups</li>
              <li>Irish guest speakers and industry nights</li>
              <li>Career and funding guidance</li>
            </ul>
          </div>
          <div className={styles.supportCard}>
            <h3>Always-on help desk</h3>
            <p>
              Ask questions anytime in our moderated community. Get replies from instructors or peers within 24 hours,
              often much faster.
            </p>
            <span className={styles.availability}>Available 7 days/week</span>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default HowItWorks;