import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [values, setValues] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    setValues((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    if (errors[event.target.name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[event.target.name];
        return next;
      });
    }
  };

  const validate = () => {
    const validation = {};
    if (!values.name.trim()) validation.name = 'Name is required.';
    if (!values.email.trim()) {
      validation.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
      validation.email = 'Enter a valid email.';
    }
    if (!values.subject.trim()) validation.subject = 'Let us know your topic.';
    if (!values.message.trim()) validation.message = 'Tell us more about your enquiry.';
    return validation;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setStatus('Thank you! We will reply within one working day.');
      setValues({ name: '', email: '', subject: '', message: '' });
    } else {
      setStatus('');
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact | studdfxg.world</title>
        <meta
          name="description"
          content="Get in touch with studdfxg.world. Ask about IT courses, services for Irish teams, or enrolment support."
        />
      </Helmet>

      <section className={`${styles.hero} sectionSpacing`}>
        <div className="container">
          <h1>Contact our team</h1>
          <p>
            Ask about course content, funding, or anything else on your mind. We are happy to guide you through the best
            next steps.
          </p>
        </div>
      </section>

      <section className={`${styles.content} sectionSpacing`}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <div className={styles.infoCard}>
                <h2>Contact details</h2>
                <ul>
                  <li>
                    <strong>Email:</strong> Pending confirmation
                  </li>
                  <li>
                    <strong>Phone:</strong> Pending confirmation
                  </li>
                  <li>
                    <strong>Address:</strong> Pending confirmation, Ireland
                  </li>
                </ul>
                <p>
                  While we finalise our Galway HQ, all services remain fully remote-first with Irish-based support teams.
                </p>
              </div>
              <div className={styles.infoCard}>
                <h3>Office hours</h3>
                <p>Monday to Friday, 9:00 – 17:30 (Irish time)</p>
                <p>Weekend support for urgent learner queries.</p>
              </div>
            </div>

            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="contact-name">Name</label>
                <input
                  id="contact-name"
                  name="name"
                  type="text"
                  value={values.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  value={values.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-subject">Subject</label>
                <input
                  id="contact-subject"
                  name="subject"
                  type="text"
                  value={values.subject}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.subject)}
                />
                {errors.subject && <span className={styles.error}>{errors.subject}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="contact-message">Message</label>
                <textarea
                  id="contact-message"
                  name="message"
                  rows="5"
                  value={values.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit">Send message</button>
              {status && (
                <p className={styles.success} role="status">
                  {status}
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;