import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={`container ${styles.content}`}>
      <div>
        <h3 className={styles.logo}>studdfxg.world</h3>
        <p className={styles.tagline}>
          IT courses crafted for people living and working in Ireland. Learn online, build practical skills, and grow
          your tech career at your own pace.
        </p>
      </div>

      <div>
        <h4 className={styles.heading}>Quick links</h4>
        <ul className={styles.list}>
          <li>
            <Link to="/courses">Courses</Link>
          </li>
          <li>
            <Link to="/how-it-works">How It Works</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>
            <Link to="/services">Services</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </div>

      <div>
        <h4 className={styles.heading}>Legal</h4>
        <ul className={styles.list}>
          <li>
            <Link to="/terms">Terms &amp; Conditions</Link>
          </li>
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookie-policy">Cookie Policy</Link>
          </li>
        </ul>
      </div>

      <div>
        <h4 className={styles.heading}>Contact</h4>
        <ul className={styles.list}>
          <li>Email: <span>Pending confirmation</span></li>
          <li>Phone: <span>Pending confirmation</span></li>
          <li>Address: <span>Pending confirmation, Ireland</span></li>
        </ul>
      </div>
    </div>
    <div className={styles.bottomBar}>
      <p>© {new Date().getFullYear()} studdfxg.world. All rights reserved.</p>
    </div>
  </footer>
);

export default Footer;