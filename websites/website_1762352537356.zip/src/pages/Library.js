import React from "react";
import { Helmet } from "react-helmet";

const resources = [
  {
    title: "Protocol Playbooks",
    items: [
      "Negotiating API versioning with multi-jurisdiction teams",
      "Checklist for migrating event-driven protocols",
      "Guide to documenting handshake states in customer channels"
    ]
  },
  {
    title: "Infrastructure Readers",
    items: [
      "Zero trust reference architectures in the Canadian context",
      "Service mesh adoption stories from public-sector labs",
      "Observability maturity ladders for platform teams"
    ]
  },
  {
    title: "Culture Companions",
    items: [
      "Running psychological safety sessions for SRE teams",
      "Facilitating asynchronous design reviews",
      "Onboarding narratives that reinforce protocol agreements"
    ]
  }
];

const Library = () => {
  return (
    <>
      <Helmet>
        <title>Library | Protocol Canvas</title>
        <meta
          name="description"
          content="Access curated Protocol Canvas library resources covering protocol playbooks, infrastructure readers, and culture companions."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="uppercase text-xs tracking-[0.3em] text-blue-500">Library</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              Curated resources for protocol practitioners
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Our library aggregates the guides, readers, and culture companions referenced throughout Protocol Canvas. Each collection is regularly updated based on field research.
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {resources.map((section) => (
              <div
                key={section.title}
                className="bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-200 hover:shadow-lg transition"
              >
                <h2 className="font-satoshi text-2xl font-semibold text-slate-900">
                  {section.title}
                </h2>
                <ul className="mt-4 space-y-3 list-disc list-inside text-sm text-slate-600">
                  {section.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <p className="mt-6 text-xs text-slate-400">
                  Access coming soon. Join the newsletter for release updates.
                </p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Library;