import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 32 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.3 },
  transition: { duration: 0.6, delay }
});

const Home = () => {
  const stats = [
    { label: "Protocols profiled", value: 128, suffix: "+" },
    { label: "Case studies published", value: 62, suffix: "" },
    { label: "Contributors across Canada", value: 24, suffix: "" },
    { label: "Newsletter readership", value: 11400, suffix: "+" }
  ];

  const featuredEssays = [
    {
      title: "Trading Handshakes: Negotiation Layers Inside TLS 1.3",
      description:
        "How modern handshake patterns reduce unpredictability while keeping ciphers negotiable.",
      link: "/blog/the-cost-of-fragmented-standards"
    },
    {
      title: "Resilience by Design: Replay Protection in Messaging Protocols",
      description:
        "What telemetry from Canadian civic tech teams reveals about replay-resistant design.",
      link: "/blog/why-consensus-algorithms-matter"
    },
    {
      title: "Observability Common Ground for Layered Platforms",
      description:
        "Cross-team agreements that keep shared platforms transparent and debuggable.",
      link: "/blog/cloud-native-protocols"
    }
  ];

  const deepDives = [
    {
      title: "GRPC in Regulated Deployments",
      summary:
        "Evaluating schema change cadences, channel management, and runtime governance in provincially regulated workloads."
    },
    {
      title: "Kafka Across Mobility Fleets",
      summary:
        "Partition strategies that help transit datasets stay orderly while enabling near real-time planning."
    },
    {
      title: "SPIFFE for Hybrid Clouds",
      summary:
        "Identity primitives that outlive the clusters they secure and how Canadian research labs apply them."
    }
  ];

  const toolingIndex = [
    {
      name: "Envoy Gateway Blueprints",
      detail: "Custom filters, retry budgets, and verification hooks for security-conscious mesh borders."
    },
    {
      name: "Backstage Canada Fork",
      detail: "Templates aligning with PSPC compliance for onboarding reusable components."
    },
    {
      name: "Cluster Cadence Dashboard",
      detail: "An index of release engineering cadences for provincial digital service teams."
    }
  ];

  const codeHistory = [
    {
      era: "1990s",
      highlight: "The first inter-provincial data interchange specs for transport scheduling."
    },
    {
      era: "2000s",
      highlight: "XML schemas for environmental reporting that introduced deterministic pipelines."
    },
    {
      era: "2010s",
      highlight: "Rise of container orchestration and the cultural shift towards platform stewardship."
    },
    {
      era: "2020s",
      highlight: "Federated services and zero-trust protocols shaping collaborative research."
    }
  ];

  const editorialHighlights = [
    {
      title: "Platform SRE in the Public Sector",
      excerpt:
        "Frontline engineers in Ontario describe balancing high availability with fiscal oversight."
    },
    {
      title: "Field Notes from Cloud Landing Zones",
      excerpt:
        "A cross-team diary on translating security controls into Terraform modules that humans can audit."
    },
    {
      title: "Protocol Storytelling",
      excerpt:
        "Why we treat protocol documentation as a cultural artifact, not just reference material."
    }
  ];

  const standardsDirectory = [
    { name: "CIO Strategy Council CAN/Digital-008", focus: "Digital identity assurance" },
    { name: "NIST SP 800-207 Companion", focus: "Zero Trust architecture implementation notes" },
    { name: "IETF RFC 8896", focus: "QUIC transport parameter tuning for data centers" },
    { name: "OpenProfile CAN-1", focus: "Interoperability guidelines for civic data feeds" }
  ];

  const latestPosts = [
    {
      title: "Interchange Formats for Cross-Border Research",
      date: "Nov 4, 2023",
      link: "/blog/the-cost-of-fragmented-standards"
    },
    {
      title: "Consensus Lessons from Disaster Recovery Drills",
      date: "Oct 19, 2023",
      link: "/blog/why-consensus-algorithms-matter"
    },
    {
      title: "Regional Mesh Gateways at Scale",
      date: "Sep 28, 2023",
      link: "/blog/cloud-native-protocols"
    }
  ];

  const servicesShowcase = [
    {
      title: "Protocol Field Guides",
      description: "Commissioned briefings tailored to teams stewarding cross-organization platforms.",
      tags: ["Analysis", "Diagrams", "Stakeholder alignment"]
    },
    {
      title: "Infrastructure Narratives",
      description: "Long-form storytelling capturing how cloud teams operationalize technical standards.",
      tags: ["Interviews", "Documentation", "Research"]
    },
    {
      title: "Culture Diagnostics",
      description: "Facilitated sessions that surface shared vocabulary for platform-centered collaboration.",
      tags: ["Workshops", "Frameworks", "Playbooks"]
    }
  ];

  const processSteps = [
    {
      step: "01",
      title: "Discovery",
      description: "Map the protocol or platform challenge with product owners and engineers."
    },
    {
      step: "02",
      title: "Documentation Audit",
      description: "Review existing diagrams, runbooks, and adoption barriers."
    },
    {
      step: "03",
      title: "Field Interviews",
      description: "Capture narratives from implementers to reveal tacit knowledge."
    },
    {
      step: "04",
      title: "Editorial Synthesis",
      description: "Craft aligned outputs across briefs, diagrams, and culture notes."
    }
  ];

  const testimonials = [
    {
      quote:
        "Protocol Canvas transformed a dense service mesh project into a coherent story. Our teams across Ottawa and Vancouver finally shared the same mental model.",
      name: "Avery Chen",
      role: "Director of Platform Strategy, Federal Digital Service"
    },
    {
      quote:
        "Their editors brought precision and empathy to a complex identity federation rollout. Stakeholders rallied behind the roadmap after reading the briefing.",
      name: "Lea Martin",
      role: "Lead Architect, Atlantic Digital Innovation Hub"
    },
    {
      quote:
        "We rely on Protocol Canvas when protocol change meets organizational change. Their coverage keeps our leadership informed and our engineers energized.",
      name: "Sahil Desai",
      role: "Head of Engineering Enablement, Prairie Systems Co-op"
    }
  ];

  const teamMembers = [
    {
      name: "Maya Sinclair",
      role: "Editor-in-Chief",
      specialty: "Distributed systems storytelling",
      img: "https://picsum.photos/400/400?random=301",
      bio: "Former platform engineer with a decade leading editorial teams focused on infrastructure literacy."
    },
    {
      name: "Owen Patel",
      role: "Research Director",
      specialty: "Protocol analysis and field studies",
      img: "https://picsum.photos/400/400?random=302",
      bio: "Specializes in networking standards and policy. Coordinates research sprints across Canadian institutions."
    },
    {
      name: "Zoe Tremblay",
      role: "Culture Editor",
      specialty: "Team rituals & collaboration frameworks",
      img: "https://picsum.photos/400/400?random=303",
      bio: "Facilitates interviews that translate platform folklore into reliable onboarding material."
    }
  ];

  const projectFilters = ["All", "Protocol", "Infrastructure", "Culture"];
  const projectGallery = [
    {
      title: "Trust Boundaries Playbook",
      type: "Protocol",
      description: "Visual walkthrough of trust zone negotiations for inter-agency APIs.",
      image: "https://picsum.photos/1200/800?random=401"
    },
    {
      title: "Cloud Landing Zone Narrative",
      type: "Infrastructure",
      description: "Story-driven primer on the managed guardrails for provincial cloud pilots.",
      image: "https://picsum.photos/1200/800?random=402"
    },
    {
      title: "Incident Retrospective Patterns",
      type: "Culture",
      description: "Frameworks for retros that balance engineering depth with organizational clarity.",
      image: "https://picsum.photos/1200/800?random=403"
    },
    {
      title: "Data Interchange Charter",
      type: "Protocol",
      description: "Collaborative charter aligning data exchange semantics between research agencies.",
      image: "https://picsum.photos/1200/800?random=404"
    }
  ];

  const faqItems = [
    {
      question: "Which topics does Protocol Canvas prioritize?",
      answer:
        "We prioritize protocols, cloud infrastructure, tooling ecosystems, and the cultural practices that sustain them. Each article is grounded in interviews, field research, and reproducible documentation."
    },
    {
      question: "How can teams collaborate with the editors?",
      answer:
        "Use the contact form to outline the protocol or infrastructure story you want to surface. We schedule a discovery call, align on scope, and co-design deliverables."
    },
    {
      question: "Do you publish reader submissions?",
      answer:
        "We review pitches that align with our editorial pillars. Submit a concise abstract, context for Canadian teams, and any technical references."
    },
    {
      question: "Can I reference your materials in training?",
      answer:
        "Yes. Cite Protocol Canvas as the source, keep excerpts intact, and share how the material is being used so we can support your cohort."
    }
  ];

  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("All");

  const filteredProjects = useMemo(() => {
    if (projectFilter === "All") return projectGallery;
    return projectGallery.filter((project) => project.type === projectFilter);
  }, [projectFilter, projectGallery]);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  return (
    <>
      <Helmet>
        <title>Protocol Canvas | Decoding the Language of Systems</title>
        <meta
          name="description"
          content="Protocol Canvas is a Canadian editorial platform decoding software protocols, cloud-native infrastructure, and engineering culture."
        />
        <meta property="og:title" content="Protocol Canvas | Decoding the Language of Systems" />
        <meta
          property="og:description"
          content="Featured essays, protocol deep dives, tooling indexes, and cultural narratives for systems builders."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.protocolcanvas.ca/" />
        <meta property="og:image" content="https://picsum.photos/1600/900?random=1" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "Protocol Canvas",
            url: "https://www.protocolcanvas.ca",
            logo: "https://picsum.photos/1600/900?random=1",
            description:
              "Canadian editorial platform decoding software protocols, cloud infrastructure, and engineering culture.",
            address: {
              "@type": "PostalAddress",
              streetAddress: "401 Bay St",
              addressLocality: "Toronto",
              addressRegion: "ON",
              postalCode: "M5H 2Y4",
              addressCountry: "Canada"
            },
            contactPoint: {
              "@type": "ContactPoint",
              telephone: "+1 (437) 802-1184",
              contactType: "editorial inquiries",
              areaServed: "CA"
            }
          })}
        </script>
      </Helmet>
      <div className="pt-20 sm:pt-24">
        <section className="relative overflow-hidden">
          <div className="absolute inset-0">
            <img
              src="https://picsum.photos/1600/900?random=11"
              alt="Abstract infrastructural systems"
              className="w-full h-full object-cover opacity-20"
              loading="lazy"
            />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl"
            >
              <p className="uppercase tracking-[0.2em] text-sm text-blue-300 mb-6">
                Protocol Canvas · Canada
              </p>
              <h1 className="font-satoshi text-4xl sm:text-5xl lg:text-6xl font-semibold text-slate-900 leading-tight">
                Decoding the Language of Systems
              </h1>
              <p className="mt-6 text-lg sm:text-xl text-slate-700 leading-relaxed">
                We surface the architecture decisions, protocol negotiations, and cultural patterns powering resilient platforms. Each story is reported from the vantage point of Canadian teams stewarding the next generation of infrastructure.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Link
                  to="/blog"
                  className="inline-flex items-center justify-center rounded-full px-6 py-3 text-base font-semibold text-white bg-blue-500 hover:bg-blue-400 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
                >
                  Read the latest essays
                </Link>
                <a
                  href="#core-topics"
                  className="inline-flex items-center justify-center rounded-full px-6 py-3 text-base font-semibold text-blue-500 bg-white border border-blue-200 hover:border-blue-300 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
                >
                  Explore our topics
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-12 sm:py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  className="bg-slate-900 text-white rounded-2xl p-6 shadow-lg"
                  whileHover={{ y: -4 }}
                  transition={{ duration: 0.3 }}
                >
                  <p className="text-sm uppercase tracking-wide text-slate-300">{stat.label}</p>
                  <p className="mt-4 text-3xl font-satoshi font-semibold">
                    {stat.value}
                    <span className="text-blue-400">{stat.suffix}</span>
                  </p>
                  <div className="mt-3 h-1 w-16 bg-blue-500 rounded-full" />
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-50" id="core-topics">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <motion.h2 {...fadeUp()} className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
                What we publish
              </motion.h2>
              <motion.p {...fadeUp(0.1)} className="mt-4 text-lg text-slate-600">
                Protocol Canvas documents the systems that connect teams, data, and infrastructure. We combine primary research with editorial craft to illuminate both technical and human considerations.
              </motion.p>
            </div>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {["Protocols", "Cloud technologies", "Tooling ecosystems", "Engineering culture"].map(
                (topic) => (
                  <div
                    key={topic}
                    className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-blue-200 hover:shadow-lg transition"
                  >
                    <h3 className="font-satoshi text-xl font-semibold text-slate-900">{topic}</h3>
                    <p className="mt-3 text-sm text-slate-600 leading-relaxed">
                      Deep research, clear visualizations, and practitioner interviews shape how we cover {topic.toLowerCase()}.
                    </p>
                  </div>
                )
              )}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-10 lg:grid-cols-[1fr,1.2fr] items-center">
            <motion.div {...fadeUp()}>
              <p className="uppercase text-xs tracking-[0.3em] text-blue-500">
                Featured essays
              </p>
              <h2 className="mt-4 font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
                Editorial features that decode complex systems
              </h2>
              <p className="mt-4 text-base text-slate-600 leading-relaxed">
                Each feature pulls together protocol specifications, infrastructure diagrams, and team-level practices. We write for engineers, product leaders, and public-sector stakeholders seeking clarity over hype.
              </p>
              <Link
                to="/blog"
                className="inline-flex items-center justify-center mt-6 rounded-full px-5 py-2.5 text-sm font-semibold text-blue-500 border border-blue-200 hover:border-blue-300 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
              >
                View all essays
              </Link>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="grid gap-6">
              {featuredEssays.map((essay) => (
                <Link
                  to={essay.link}
                  key={essay.title}
                  className="group block bg-slate-50 border border-slate-200 rounded-2xl p-6 hover:border-blue-200 hover:shadow-xl transition"
                >
                  <p className="text-sm uppercase tracking-wide text-blue-500">Essay</p>
                  <h3 className="mt-3 font-satoshi text-xl font-semibold text-slate-900 group-hover:text-blue-600">
                    {essay.title}
                  </h3>
                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">{essay.description}</p>
                </Link>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()}>
              <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold">Protocol Deep Dives</h2>
              <p className="mt-4 text-base text-slate-300 max-w-3xl">
                We unpack real-world protocol adoption stories—from initial experiments to production guardrails. Our deep dives combine packets, process, and people.
              </p>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 lg:grid-cols-3">
              {deepDives.map((item) => (
                <div
                  key={item.title}
                  className="bg-slate-800/60 border border-slate-700 rounded-2xl p-6 h-full flex flex-col justify-between hover:border-blue-400 transition"
                >
                  <h3 className="font-satoshi text-xl font-semibold text-white">{item.title}</h3>
                  <p className="mt-4 text-sm text-slate-300 leading-relaxed">{item.summary}</p>
                  <span className="mt-6 inline-flex items-center text-sm font-semibold text-blue-300">
                    Full brief coming soon →
                  </span>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()} className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
              <div className="max-w-3xl">
                <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
                  Tooling Index
                </h2>
                <p className="mt-3 text-base text-slate-600">
                  We catalogue the tooling patterns Canadian teams rely on—from service meshes to observability stacks—highlighting governance insights along the way.
                </p>
              </div>
              <Link
                to="/tooling"
                className="inline-flex items-center justify-center rounded-full px-5 py-2.5 text-sm font-semibold text-blue-500 border border-blue-200 hover:border-blue-300 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
              >
                Explore tooling
              </Link>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="mt-8 grid gap-6 md:grid-cols-3">
              {toolingIndex.map((tool) => (
                <div
                  key={tool.name}
                  className="bg-slate-50 border border-slate-200 rounded-2xl p-6 hover:border-blue-200 transition"
                >
                  <h3 className="font-satoshi text-lg font-semibold text-slate-900">{tool.name}</h3>
                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">{tool.detail}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2 {...fadeUp()} className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
              Code History
            </motion.h2>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {codeHistory.map((item) => (
                <div
                  key={item.era}
                  className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-blue-200 transition"
                >
                  <p className="text-sm uppercase tracking-wide text-blue-500">{item.era}</p>
                  <h3 className="mt-3 font-satoshi text-lg font-semibold text-slate-900">
                    Evolution
                  </h3>
                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">{item.highlight}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2 {...fadeUp()} className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
              Editorial Highlights
            </motion.h2>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 md:grid-cols-3">
              {editorialHighlights.map((item) => (
                <div
                  key={item.title}
                  className="bg-slate-50 border border-slate-200 rounded-2xl p-6 hover:border-blue-200 transition"
                >
                  <h3 className="font-satoshi text-xl font-semibold text-slate-900">{item.title}</h3>
                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">{item.excerpt}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()} className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
              <div>
                <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold">
                  Standards Directory
                </h2>
                <p className="mt-4 text-base text-slate-300 max-w-2xl">
                  From IETF to Canadian standards bodies, we maintain a directory of references that influence technical planning.
                </p>
              </div>
              <Link
                to="/sources"
                className="inline-flex items-center justify-center rounded-full px-5 py-2.5 text-sm font-semibold text-white border border-blue-200/40 hover:border-blue-200 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-200"
              >
                View source directory
              </Link>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 md:grid-cols-2">
              {standardsDirectory.map((standard) => (
                <div
                  key={standard.name}
                  className="bg-slate-800/70 border border-slate-700 rounded-2xl p-6 hover:border-blue-400 transition"
                >
                  <p className="text-sm uppercase tracking-wide text-blue-300">
                    {standard.focus}
                  </p>
                  <h3 className="mt-3 font-satoshi text-lg font-semibold text-white">{standard.name}</h3>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2 {...fadeUp()} className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
              Latest Posts
            </motion.h2>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 md:grid-cols-3">
              {latestPosts.map((post) => (
                <Link
                  to={post.link}
                  key={post.title}
                  className="group bg-slate-50 border border-slate-200 rounded-2xl p-6 hover:border-blue-200 hover:shadow-lg transition"
                >
                  <p className="text-xs uppercase tracking-wide text-blue-500">{post.date}</p>
                  <h3 className="mt-3 font-satoshi text-xl font-semibold text-slate-900 group-hover:text-blue-600">
                    {post.title}
                  </h3>
                  <span className="mt-4 inline-flex items-center text-sm font-semibold text-blue-500">
                    Continue reading →
                  </span>
                </Link>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()} className="max-w-3xl">
              <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
                Services
              </h2>
              <p className="mt-4 text-base text-slate-600">
                Beyond publishing, Protocol Canvas collaborates with teams to craft accessible protocol documentation, run culture diagnostics, and translate infrastructure into narratives decision makers understand.
              </p>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 md:grid-cols-3">
              {servicesShowcase.map((service) => (
                <div
                  key={service.title}
                  className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-blue-200 hover:shadow-lg transition"
                >
                  <h3 className="font-satoshi text-xl font-semibold text-slate-900">
                    {service.title}
                  </h3>
                  <p className="mt-4 text-sm text-slate-600 leading-relaxed">{service.description}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {service.tags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-flex items-center px-3 py-1 text-xs font-medium bg-blue-50 text-blue-600 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-8 lg:grid-cols-[1.1fr,0.9fr] items-center">
            <motion.div {...fadeUp()}>
              <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
                How we work with teams
              </h2>
              <p className="mt-4 text-base text-slate-600">
                Our editorial process blends technical interviews, documentation audits, and cultural research. We stay close to practitioners to ensure pragmatic insights.
              </p>
              <div className="mt-8 space-y-4">
                {processSteps.map((step) => (
                  <div
                    key={step.step}
                    className="flex gap-4 items-start bg-slate-50 border border-slate-200 rounded-2xl p-5"
                  >
                    <span className="font-satoshi text-lg font-semibold text-blue-500">
                      {step.step}
                    </span>
                    <div>
                      <h3 className="font-satoshi text-lg font-semibold text-slate-900">
                        {step.title}
                      </h3>
                      <p className="text-sm text-slate-600 mt-2">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="relative">
              <img
                src="https://picsum.photos/800/600?random=21"
                alt="Editors reviewing technical diagrams"
                className="rounded-3xl shadow-2xl border border-slate-200"
                loading="lazy"
              />
              <div className="absolute -bottom-6 -left-6 bg-slate-900 text-white rounded-2xl p-6 shadow-xl max-w-xs">
                <p className="text-sm">
                  “We translate protocol choices into stories that leadership, engineers, and policy makers can all act on.”
                </p>
                <p className="mt-3 text-xs text-slate-300">Protocol Canvas editorial team</p>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()} className="text-center max-w-3xl mx-auto">
              <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold">
                Voices from our collaborators
              </h2>
              <p className="mt-4 text-base text-slate-300">
                Protocol Canvas works alongside provincial labs, public agencies, and platform teams. Here is what they say.
              </p>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="mt-10 relative">
              <div className="overflow-hidden">
                <motion.div
                  key={activeTestimonial}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.5 }}
                  className="bg-slate-800/70 border border-slate-700 rounded-3xl p-8 md:p-10 max-w-4xl mx-auto"
                >
                  <p className="text-lg text-slate-200 leading-relaxed">
                    “{testimonials[activeTestimonial].quote}”
                  </p>
                  <div className="mt-6">
                    <p className="font-satoshi text-lg font-semibold text-white">
                      {testimonials[activeTestimonial].name}
                    </p>
                    <p className="text-sm text-slate-400">
                      {testimonials[activeTestimonial].role}
                    </p>
                  </div>
                </motion.div>
              </div>
              <div className="flex items-center justify-center gap-2 mt-6">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveTestimonial(index)}
                    className={`h-2 w-8 rounded-full transition ${
                      activeTestimonial === index ? "bg-blue-400" : "bg-slate-700"
                    }`}
                    aria-label={`Show testimonial ${index + 1}`}
                  />
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2 {...fadeUp()} className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
              Meet the editorial team
            </motion.h2>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-8 md:grid-cols-3">
              {teamMembers.map((member) => (
                <div
                  key={member.name}
                  className="bg-slate-50 border border-slate-200 rounded-3xl p-6 hover:border-blue-200 hover:shadow-lg transition"
                >
                  <div className="relative">
                    <img
                      src={member.img}
                      alt={`${member.name}, ${member.role}`}
                      className="rounded-2xl w-full h-64 object-cover"
                      loading="lazy"
                    />
                    <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur rounded-full px-4 py-1 text-xs font-semibold text-slate-700">
                      {member.specialty}
                    </div>
                  </div>
                  <h3 className="mt-5 font-satoshi text-xl font-semibold text-slate-900">
                    {member.name}
                  </h3>
                  <p className="text-sm text-blue-500 font-medium">{member.role}</p>
                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">{member.bio}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()} className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div>
                <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
                  Recent projects
                </h2>
                <p className="mt-3 text-base text-slate-600">
                  A sample of the editorial and research projects we stewarded with Canadian teams.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                {projectFilters.map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setProjectFilter(filter)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                      projectFilter === filter
                        ? "bg-blue-500 text-white shadow"
                        : "bg-white text-slate-700 border border-slate-200 hover:border-blue-200"
                    }`}
                    aria-pressed={projectFilter === filter}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="mt-8 grid gap-6 lg:grid-cols-2">
              {filteredProjects.map((project) => (
                <div
                  key={project.title}
                  className="bg-white border border-slate-200 rounded-3xl overflow-hidden hover:border-blue-200 hover:shadow-xl transition"
                >
                  <img
                    src={project.image}
                    alt={`${project.title} case study visual`}
                    className="w-full h-56 object-cover"
                    loading="lazy"
                  />
                  <div className="p-6">
                    <span className="text-xs uppercase tracking-wide text-blue-500">
                      {project.type}
                    </span>
                    <h3 className="mt-3 font-satoshi text-xl font-semibold text-slate-900">
                      {project.title}
                    </h3>
                    <p className="mt-3 text-sm text-slate-600 leading-relaxed">{project.description}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2 {...fadeUp()} className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
              FAQ
            </motion.h2>
            <motion.div {...fadeUp(0.2)} className="mt-8 space-y-4">
              {faqItems.map((item, index) => (
                <details
                  key={item.question}
                  className="group bg-slate-50 border border-slate-200 rounded-2xl p-5 hover:border-blue-200 transition"
                >
                  <summary className="flex items-center justify-between cursor-pointer font-satoshi text-lg font-semibold text-slate-900 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300">
                    {item.question}
                  </summary>
                  <p className="mt-3 text-sm text-slate-600 leading-relaxed">{item.answer}</p>
                </details>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-16 sm:py-20 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeUp()} className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
              <div className="max-w-3xl">
                <p className="uppercase text-xs tracking-[0.3em] text-blue-300">Insights</p>
                <h2 className="font-satoshi text-3xl sm:text-4xl font-semibold mt-3">
                  Blog Preview
                </h2>
                <p className="mt-4 text-base text-slate-300">
                  We publish weekly notes on system interoperability, observability, and the rituals that keep platform teams aligned.
                </p>
              </div>
              <Link
                to="/blog"
                className="inline-flex items-center justify-center rounded-full px-5 py-2.5 text-sm font-semibold text-white border border-blue-200/40 hover:border-blue-200 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-200"
              >
                Browse blog
              </Link>
            </motion.div>
            <motion.div {...fadeUp(0.2)} className="mt-10 grid gap-6 md:grid-cols-3">
              {latestPosts.map((post) => (
                <Link
                  to={post.link}
                  key={post.title}
                  className="group bg-slate-800/70 border border-slate-700 rounded-2xl p-6 hover:border-blue-300 transition"
                >
                  <p className="text-xs uppercase tracking-wide text-blue-300">{post.date}</p>
                  <h3 className="mt-3 font-satoshi text-xl font-semibold text-white group-hover:text-blue-300">
                    {post.title}
                  </h3>
                  <span className="mt-4 inline-flex items-center text-sm font-semibold text-blue-300">
                    Read insight →
                  </span>
                </Link>
              ))}
            </motion.div>
          </div>
        </section>

        <section id="newsletter" className="py-16 sm:py-20 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.h2 {...fadeUp()} className="font-satoshi text-3xl sm:text-4xl font-semibold text-slate-900">
              Subscribe to the Protocol Canvas briefing
            </motion.h2>
            <motion.p {...fadeUp(0.1)} className="mt-4 text-base text-slate-600">
              Receive editor notes, new deep dives, and research calls. Our newsletter keeps you current on protocols shaping Canadian infrastructure.
            </motion.p>
            <motion.form {...fadeUp(0.2)} className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                required
                placeholder="you@example.com"
                className="w-full sm:w-72 rounded-full border border-slate-200 px-5 py-3 text-sm text-slate-700 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center px-6 py-3 rounded-full text-sm font-semibold text-white bg-blue-500 hover:bg-blue-400 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
              >
                Join briefing
              </button>
            </motion.form>
            <p className="mt-3 text-xs text-slate-500">
              By subscribing, you consent to receive editorial updates. You may unsubscribe anytime.
            </p>
          </div>
        </section>

        <section className="py-12 bg-slate-900 text-slate-100">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p className="text-sm">
              Disclaimer: for educational and research use only. Protocol Canvas does not provide legal or financial advice. Always consult relevant policies and standards before implementing new protocols.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;