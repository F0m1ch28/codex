import React from "react";
import { Helmet } from "react-helmet";

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | Protocol Canvas</title>
        <meta
          name="description"
          content="Read the Protocol Canvas terms of service outlining usage guidelines for the website and published content."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white border border-slate-200 rounded-3xl p-10 shadow-lg">
          <h1 className="font-satoshi text-3xl font-semibold text-slate-900">Terms of Service</h1>
          <p className="mt-4 text-sm text-slate-500">Effective: September 15, 2023</p>
          <div className="mt-8 space-y-6 text-sm text-slate-600 leading-relaxed">
            <p>
              These Terms of Service govern your access and use of the Protocol Canvas website. By accessing the site, you agree to comply with these terms and applicable laws.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Use of content</h2>
            <p>
              Protocol Canvas publishes editorial content for educational and research purposes. You may reference or share excerpts with attribution. Republishing full articles requires written permission.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">User submissions</h2>
            <p>
              When submitting content or feedback, ensure that you have authorization to share that material. Protocol Canvas may edit submissions for clarity before publication.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Intellectual property</h2>
            <p>
              All trademarks, logos, and editorial content remain the property of Protocol Canvas. Unauthorized use is prohibited.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Limitation of liability</h2>
            <p>
              Protocol Canvas provides information “as is” for educational use. We are not responsible for decisions made based on our content. Always consult appropriate experts for implementation guidance.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Governing law</h2>
            <p>
              These terms are governed by the laws of Ontario, Canada. Disputes will be resolved in Ontario courts.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Contact</h2>
            <p>
              Questions about these terms can be sent through our contact form or mailed to 401 Bay St, Toronto, ON M5H 2Y4, Canada.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default Terms;