import React from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";

const posts = [
  {
    title: "Cloud-Native Protocols: Balancing Velocity and Reliability",
    excerpt:
      "We dissect the trade-offs teams face when modernizing their protocol stack while keeping public services reliable.",
    link: "/blog/cloud-native-protocols",
    date: "September 28, 2023",
    author: "Maya Sinclair"
  },
  {
    title: "The Cost of Fragmented Standards",
    excerpt:
      "When agencies follow divergent standards, integrations slow. We explore coordination remedies across Canadian jurisdictions.",
    link: "/blog/the-cost-of-fragmented-standards",
    date: "November 4, 2023",
    author: "Owen Patel"
  },
  {
    title: "Why Consensus Algorithms Matter",
    excerpt:
      "Beyond blockchain headlines, consensus ensures trust in distributed services. We unpack design lessons for civic platforms.",
    link: "/blog/why-consensus-algorithms-matter",
    date: "October 19, 2023",
    author: "Zoe Tremblay"
  }
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Blog | Protocol Canvas Editorial Insights</title>
        <meta
          name="description"
          content="Browse Protocol Canvas blog posts covering protocols, cloud infrastructure, and engineering culture across Canada."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="uppercase text-xs tracking-[0.3em] text-blue-500">Blog</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              Latest editorial insights
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Field notes, research synthesis, and interviews with the builders pushing Canadian systems forward.
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-2">
            {posts.map((post) => (
              <Link
                to={post.link}
                key={post.title}
                className="bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-200 hover:shadow-lg transition"
              >
                <p className="text-xs uppercase tracking-wide text-blue-500">{post.date}</p>
                <h2 className="mt-3 font-satoshi text-2xl font-semibold text-slate-900">
                  {post.title}
                </h2>
                <p className="mt-4 text-sm text-slate-600 leading-relaxed">{post.excerpt}</p>
                <p className="mt-6 text-xs text-slate-400">By {post.author}</p>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Blog;