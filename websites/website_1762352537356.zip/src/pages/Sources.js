import React from "react";
import { Helmet } from "react-helmet";

const sources = [
  {
    name: "IETF Datatracker",
    type: "Standards",
    link: "https://datatracker.ietf.org/",
    description: "Primary repository for internet standards drafts and RFCs referenced in our coverage."
  },
  {
    name: "CIO Strategy Council",
    type: "Canadian Standards",
    link: "https://ciostrategycouncil.com/",
    description: "Develops digital and data standards relevant to Canadian public-sector teams."
  },
  {
    name: "NIST Cybersecurity Publications",
    type: "Guidance",
    link: "https://csrc.nist.gov/publications",
    description: "Includes SP series documents such as zero trust and supply chain security guidance."
  },
  {
    name: "CANARIE Research Platform Updates",
    type: "Infrastructure",
    link: "https://www.canarie.ca/",
    description: "Tracks research network developments and interoperability efforts across Canada."
  }
];

const Sources = () => {
  return (
    <>
      <Helmet>
        <title>Sources & References | Protocol Canvas</title>
        <meta
          name="description"
          content="Protocol Canvas maintains a directory of standards bodies and references guiding our editorial work."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="uppercase text-xs tracking-[0.3em] text-blue-500">Sources</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              Standards and references powering our reporting
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Our editorial work cites authoritative standards and research bodies. Explore the sources that inform our stories and guides.
            </p>
          </div>
          <div className="mt-12 space-y-6">
            {sources.map((source) => (
              <a
                key={source.name}
                href={source.link}
                target="_blank"
                rel="noopener noreferrer"
                className="block bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-200 hover:shadow-lg transition"
              >
                <p className="text-xs uppercase tracking-wide text-blue-500">{source.type}</p>
                <h2 className="mt-3 font-satoshi text-2xl font-semibold text-slate-900">
                  {source.name}
                </h2>
                <p className="mt-4 text-sm text-slate-600 leading-relaxed">{source.description}</p>
                <span className="mt-4 inline-flex items-center text-sm font-semibold text-blue-500">
                  Visit source →
                </span>
              </a>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Sources;