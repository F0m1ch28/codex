import React from "react";
import { Helmet } from "react-helmet";

const rituals = [
  {
    title: "Protocol retrospectives",
    summary:
      "Teams host retros after significant protocol changes, focusing on communication, documentation, and stakeholder alignment."
  },
  {
    title: "Shadow reviews",
    summary:
      "New engineers shadow protocol working groups to understand decisions before contributing."
  },
  {
    title: "Incident storytelling",
    summary:
      "Post-incident reports read like narratives, blending data with human decision points to enhance learning."
  }
];

const Culture = () => {
  return (
    <>
      <Helmet>
        <title>Engineering Culture | Protocol Canvas</title>
        <meta
          name="description"
          content="Protocol Canvas explores rituals, practices, and cultural patterns that empower Canadian engineering teams."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="uppercase text-xs tracking-[0.3em] text-blue-500">Culture</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              Rituals that sustain resilient engineering teams
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Culture is the invisible protocol binding system builders. We study how teams learn together, share context, and care for systems in moments of pressure.
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {rituals.map((item) => (
              <div
                key={item.title}
                className="bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-200 hover:shadow-lg transition"
              >
                <h2 className="font-satoshi text-2xl font-semibold text-slate-900">{item.title}</h2>
                <p className="mt-4 text-sm text-slate-600 leading-relaxed">{item.summary}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 bg-slate-900 text-white rounded-3xl p-8">
            <h2 className="font-satoshi text-3xl font-semibold">
              Culture Diaries series
            </h2>
            <p className="mt-4 text-sm text-slate-300 leading-relaxed">
              We interview engineers, product leaders, and policy partners to surface the hidden work that keeps protocols thriving. The series maps rituals to measurable system reliability, bridging qualitative insights and technical outcomes.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default Culture;