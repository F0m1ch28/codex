import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { useNavigate } from "react-router-dom";

const initialState = {
  name: "",
  email: "",
  organization: "",
  message: "",
  consent: false
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please provide your name.";
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/))
      newErrors.email = "Enter a valid email address.";
    if (!formData.message.trim()) newErrors.message = "Tell us a bit about your request.";
    if (!formData.consent) newErrors.consent = "Consent is required to process your information.";
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    if (Object.keys(validation).length) {
      setErrors(validation);
      return;
    }
    setErrors({});
    setFormData(initialState);
    navigate("/contact/thanks", { state: { name: formData.name } });
  };

  return (
    <>
      <Helmet>
        <title>Contact Protocol Canvas | Editorial Inquiries</title>
        <meta
          name="description"
          content="Reach Protocol Canvas for editorial collaborations, protocol research, and partnership opportunities. Located in Toronto, serving Canada."
        />
        <meta property="og:title" content="Contact Protocol Canvas" />
        <meta
          property="og:description"
          content="Connect with the Protocol Canvas editorial team based in Toronto for protocol and infrastructure storytelling."
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://www.protocolcanvas.ca/contact" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=71" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ContactPage",
            name: "Contact Protocol Canvas",
            url: "https://www.protocolcanvas.ca/contact",
            mainEntity: {
              "@type": "Organization",
              name: "Protocol Canvas",
              address: {
                "@type": "PostalAddress",
                streetAddress: "401 Bay St",
                addressLocality: "Toronto",
                addressRegion: "ON",
                postalCode: "M5H 2Y4",
                addressCountry: "Canada"
              },
              telephone: "+1 (437) 802-1184"
            }
          })}
        </script>
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-[0.85fr,1.15fr]">
            <div className="bg-slate-900 text-white rounded-3xl p-8 shadow-xl">
              <p className="uppercase text-xs tracking-[0.3em] text-blue-300">
                Contact
              </p>
              <h1 className="font-satoshi text-3xl sm:text-4xl font-semibold mt-4">
                We respond within two business days
              </h1>
              <p className="mt-4 text-sm text-slate-300 leading-relaxed">
                Share your protocol, infrastructure, or culture story. Include timelines, stakeholders, and the desired impact. Confidentiality is respected by default.
              </p>
              <div className="mt-8 space-y-4 text-sm text-slate-100">
                <p>
                  Headquarters: 401 Bay St, Toronto, ON M5H 2Y4, Canada
                </p>
                <p>Telephone: +1 (437) 802-1184</p>
                <p>Email: Add your address in the form so we can reach you every step of the way.</p>
              </div>
              <div className="mt-8 border border-blue-400/40 rounded-2xl p-4 text-sm text-slate-300">
                <p>
                  Note: Protocol Canvas processes your information solely to coordinate editorial conversations. Review our privacy policy for details.
                </p>
              </div>
            </div>
            <form
              className="bg-white border border-slate-200 rounded-3xl p-8 shadow-lg"
              onSubmit={handleSubmit}
              noValidate
            >
              <div className="grid gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-slate-900">
                    Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    className={`mt-2 w-full rounded-2xl border px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-100 ${
                      errors.name ? "border-red-400" : "border-slate-200 focus:border-blue-400"
                    }`}
                    placeholder="Your full name"
                  />
                  {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name}</p>}
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-slate-900">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`mt-2 w-full rounded-2xl border px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-100 ${
                      errors.email ? "border-red-400" : "border-slate-200 focus:border-blue-400"
                    }`}
                    placeholder="you@organization.ca"
                  />
                  {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
                </div>
                <div>
                  <label
                    htmlFor="organization"
                    className="block text-sm font-semibold text-slate-900"
                  >
                    Organization
                  </label>
                  <input
                    id="organization"
                    name="organization"
                    type="text"
                    value={formData.organization}
                    onChange={handleChange}
                    className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
                    placeholder="Team or agency name"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-slate-900">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={5}
                    value={formData.message}
                    onChange={handleChange}
                    className={`mt-2 w-full rounded-2xl border px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-100 ${
                      errors.message ? "border-red-400" : "border-slate-200 focus:border-blue-400"
                    }`}
                    placeholder="Share context, timelines, and what success looks like"
                  />
                  {errors.message && (
                    <p className="mt-1 text-xs text-red-500">{errors.message}</p>
                  )}
                </div>
                <div className="flex items-start gap-3">
                  <input
                    id="consent"
                    name="consent"
                    type="checkbox"
                    checked={formData.consent}
                    onChange={handleChange}
                    className="mt-1 h-4 w-4 rounded border-slate-300 text-blue-500 focus:ring-blue-400"
                  />
                  <label htmlFor="consent" className="text-xs text-slate-600">
                    I consent to Protocol Canvas using the submitted information to respond to my inquiry. I have reviewed the privacy policy.
                  </label>
                </div>
                {errors.consent && <p className="text-xs text-red-500">{errors.consent}</p>}
                <button
                  type="submit"
                  className="inline-flex items-center justify-center rounded-full px-6 py-3 text-sm font-semibold text-white bg-blue-500 hover:bg-blue-400 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
                >
                  Send message
                </button>
              </div>
            </form>
          </div>
        </section>
      </div>
    </>
  );
};

export default Contact;