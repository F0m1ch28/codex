import React from "react";
import { Helmet } from "react-helmet";
import { useLocation, Link } from "react-router-dom";

const ContactThanks = () => {
  const location = useLocation();
  const name = location.state?.name;

  return (
    <>
      <Helmet>
        <title>Thank You | Protocol Canvas</title>
        <meta
          name="description"
          content="Thank you for contacting Protocol Canvas. Our editorial team will review your message shortly."
        />
      </Helmet>
      <div className="bg-slate-50 min-h-screen pt-32 pb-20">
        <div className="max-w-xl mx-auto bg-white border border-slate-200 rounded-3xl p-10 text-center shadow-lg">
          <div className="h-16 w-16 mx-auto rounded-full bg-blue-500 text-white flex items-center justify-center text-2xl font-semibold">
            ✓
          </div>
          <h1 className="mt-6 font-satoshi text-3xl font-semibold text-slate-900">
            Thank you{ name ? `, ${name}` : "" }!
          </h1>
          <p className="mt-4 text-base text-slate-600">
            Your message is in our editorial queue. We respond within two business days with next steps or follow-up questions.
          </p>
          <Link
            to="/"
            className="inline-flex items-center justify-center mt-6 rounded-full px-6 py-3 text-sm font-semibold text-blue-500 border border-blue-200 hover:border-blue-300 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
          >
            Return to homepage
          </Link>
        </div>
      </div>
    </>
  );
};

export default ContactThanks;