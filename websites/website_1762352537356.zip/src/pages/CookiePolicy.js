import React from "react";
import { Helmet } from "react-helmet";

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Protocol Canvas</title>
        <meta
          name="description"
          content="Understand how Protocol Canvas uses cookies and similar technologies to enhance your experience."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white border border-slate-200 rounded-3xl p-10 shadow-lg">
          <h1 className="font-satoshi text-3xl font-semibold text-slate-900">Cookie Policy</h1>
          <p className="mt-4 text-sm text-slate-500">Updated: September 15, 2023</p>
          <div className="mt-8 space-y-6 text-sm text-slate-600 leading-relaxed">
            <p>
              Protocol Canvas uses cookies to deliver a secure and consistent experience. This policy explains the categories of cookies we use and how you can adjust preferences.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Types of cookies</h2>
            <ul className="list-disc list-inside space-y-2">
              <li>
                Functional cookies: Required to maintain session state and remember preferences.
              </li>
              <li>
                Analytics cookies: Aggregate metrics on page visits and content performance. We do not conduct individual tracking.
              </li>
            </ul>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Managing cookies</h2>
            <p>
              You can accept or decline cookies through the banner on our site. You may also adjust settings in your browser to delete or block cookies.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Third-party services</h2>
            <p>
              We partner with analytics providers aligned with Canadian privacy expectations. Data is processed in aggregate form and never sold to advertisers.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Updates</h2>
            <p>
              Changes to this policy will be posted on this page with an updated effective date.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default CookiePolicy;