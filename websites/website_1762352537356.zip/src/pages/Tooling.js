import React from "react";
import { Helmet } from "react-helmet";

const tools = [
  {
    name: "Service Mesh Atlas",
    category: "Platform",
    description:
      "A living index of Envoy filters, retries, and circuit breakers tuned for Canadian public-sector workloads.",
    maturity: "Production",
    steward: "Protocol Canvas tooling desk"
  },
  {
    name: "Observability Quilt",
    category: "Monitoring",
    description:
      "Composable dashboards for tracing cross-cluster activity. Pairs metrics with narrative runbooks.",
    maturity: "Pilot",
    steward: "Prairie Systems Co-op"
  },
  {
    name: "Release Cadence Map",
    category: "Collaboration",
    description:
      "Aggregates release schedules from partner teams to prevent integration collisions.",
    maturity: "Production",
    steward: "Atlantic Digital Innovation Hub"
  },
  {
    name: "Policy Alignment Checker",
    category: "Compliance",
    description:
      "Static analysis scripts verifying code against PSC public service standards before deployments.",
    maturity: "Beta",
    steward: "Ontario Digital Service"
  }
];

const Tooling = () => {
  return (
    <>
      <Helmet>
        <title>Tooling Index | Protocol Canvas</title>
        <meta
          name="description"
          content="Explore the Protocol Canvas tooling index cataloguing Canadian platform tooling patterns and their stewards."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="uppercase text-xs tracking-[0.3em] text-blue-500">Tooling</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              Platform tooling index
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Protocol Canvas curates tooling stories that illustrate how teams operationalize standards. Each entry highlights context, maturity, and stewarding teams.
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-2">
            {tools.map((tool) => (
              <div
                key={tool.name}
                className="bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-200 hover:shadow-lg transition"
              >
                <p className="text-xs uppercase tracking-wide text-blue-500">{tool.category}</p>
                <h2 className="mt-3 font-satoshi text-2xl font-semibold text-slate-900">{tool.name}</h2>
                <p className="mt-4 text-sm text-slate-600 leading-relaxed">{tool.description}</p>
                <div className="mt-6 flex flex-wrap gap-4 text-xs text-slate-500">
                  <span className="inline-flex px-3 py-1 rounded-full bg-slate-100 text-slate-700">
                    Maturity: {tool.maturity}
                  </span>
                  <span className="inline-flex px-3 py-1 rounded-full bg-slate-100 text-slate-700">
                    Steward: {tool.steward}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Tooling;