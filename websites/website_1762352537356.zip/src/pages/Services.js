import React from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";

const engagements = [
  {
    title: "Protocol Field Guides",
    description:
      "Custom research packages that decode protocol negotiations, integration roadmaps, and decision logs.",
    outcomes: [
      "Annotated protocol diagrams",
      "Stakeholder-aligned briefs",
      "Adoption readiness checklist"
    ]
  },
  {
    title: "Infrastructure Reporting",
    description:
      "Immersive storytelling for platform launches, modernization efforts, and post-incident knowledge sharing.",
    outcomes: [
      "Narrative reports with visuals",
      "Executive summaries for non-technical readers",
      "Community Q&A synthesis"
    ]
  },
  {
    title: "Culture Diagnostics",
    description:
      "Facilitated sessions that help teams capture rituals, vocabulary, and onboarding practices.",
    outcomes: [
      "Collaboration playbooks",
      "Workshop facilitation kits",
      "Culture-informed documentation"
    ]
  },
  {
    title: "Tooling Index Partnerships",
    description:
      "Co-develop entries for the Protocol Canvas tooling index, ensuring reusable knowledge persists.",
    outcomes: [
      "Tooling baselines",
      "Update cadences",
      "Communication templates"
    ]
  }
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Services | Protocol Canvas Collaborations</title>
        <meta
          name="description"
          content="Protocol Canvas collaborates with teams to produce protocol field guides, infrastructure reporting, culture diagnostics, and tooling indexes."
        />
        <meta property="og:title" content="Protocol Canvas Services" />
        <meta
          property="og:description"
          content="Explore collaboration models for protocol research, infrastructure reporting, and engineering culture diagnostics."
        />
        <meta property="og:type" content="service" />
        <meta property="og:url" content="https://www.protocolcanvas.ca/services" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=61" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            name: "Protocol Canvas Editorial Collaborations",
            provider: {
              "@type": "Organization",
              name: "Protocol Canvas"
            },
            areaServed: "Canada",
            serviceType: [
              "Protocol Research",
              "Infrastructure Reporting",
              "Engineering Culture Diagnostics"
            ]
          })}
        </script>
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <p className="uppercase text-xs tracking-[0.3em] text-blue-500">Services</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              Editorial collaborations for protocol-driven teams
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Our engagements deliver rigorous research, clear storytelling, and reusable playbooks. We partner with teams stewarding complex systems, ensuring each deliverable strengthens internal alignment and external understanding.
            </p>
          </motion.div>
        </section>

        <section className="mt-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-8 md:grid-cols-2">
            {engagements.map((engagement) => (
              <motion.div
                key={engagement.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.6 }}
                className="bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-200 hover:shadow-xl transition"
              >
                <h2 className="font-satoshi text-2xl font-semibold text-slate-900">
                  {engagement.title}
                </h2>
                <p className="mt-4 text-base text-slate-600 leading-relaxed">
                  {engagement.description}
                </p>
                <div className="mt-6">
                  <p className="text-sm font-semibold text-slate-900">Deliverables include:</p>
                  <ul className="mt-3 space-y-2">
                    {engagement.outcomes.map((item) => (
                      <li key={item} className="text-sm text-slate-600 flex items-start gap-2">
                        <span aria-hidden="true" className="text-blue-500 mt-1">
                          •
                        </span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="mt-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 bg-slate-900 text-white rounded-3xl p-10">
            <h2 className="font-satoshi text-3xl font-semibold">
              Collaboration cadence
            </h2>
            <p className="mt-4 text-base text-slate-300 leading-relaxed">
              We co-design engagements around your release cycles. Typical collaborations span four to eight weeks, combining research sprints, editorial drafts, and review checkpoints. Each engagement concludes with a retrospective to capture lessons learned and future updates.
            </p>
            <a
              href="/contact"
              className="inline-flex items-center justify-center mt-6 rounded-full px-6 py-3 text-sm font-semibold text-slate-900 bg-white hover:bg-blue-50 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-200"
            >
              Start a conversation
            </a>
          </div>
        </section>
      </div>
    </>
  );
};

export default Services;