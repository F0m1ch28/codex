import React from "react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";

const About = () => {
  const values = [
    {
      title: "Evidence-led reporting",
      description: "Every article is anchored in interviews, documentation reviews, and reproducible experiments."
    },
    {
      title: "Inclusive engineering culture",
      description: "We highlight rituals and communication patterns that help distributed teams collaborate."
    },
    {
      title: "Clarity over jargon",
      description: "We translate complex protocol concepts into narratives leaders and practitioners can share."
    }
  ];

  const timeline = [
    {
      year: "2019",
      detail: "Protocol Canvas launches in Toronto, partnering with regional digital service teams."
    },
    {
      year: "2020",
      detail: "Expanded coverage into cloud-native operations, publishing the first Tooling Index."
    },
    {
      year: "2021",
      detail: "Introduced Culture Diaries to document the people behind protocol decisions."
    },
    {
      year: "2023",
      detail: "Launched the Standards Directory supporting cross-provincial interoperability planning."
    }
  ];

  return (
    <>
      <Helmet>
        <title>About Protocol Canvas | Editorial Mission & Team</title>
        <meta
          name="description"
          content="Learn about the Protocol Canvas editorial mission, research methodology, and the team decoding protocols and infrastructure across Canada."
        />
        <meta property="og:title" content="About Protocol Canvas" />
        <meta
          property="og:description"
          content="Protocol Canvas documents software protocols, cloud infrastructure, and engineering culture with evidence-led reporting."
        />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://www.protocolcanvas.ca/about" />
        <meta property="og:image" content="https://picsum.photos/1200/630?random=51" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "AboutPage",
            name: "About Protocol Canvas",
            description:
              "Protocol Canvas is a Canadian editorial platform focused on software protocols, infrastructure, and engineering culture.",
            url: "https://www.protocolcanvas.ca/about"
          })}
        </script>
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <p className="uppercase tracking-[0.3em] text-xs text-blue-500">About us</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              An editorial studio for protocol-first thinking
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Protocol Canvas was founded by editors and engineers who believe that infrastructure stories deserve thoughtful reporting. From early-stage experiments to production-grade ecosystems, we capture how teams negotiate standards, orchestrate tooling, and cultivate culture.
            </p>
          </motion.div>
        </section>

        <section className="mt-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-10 lg:grid-cols-[1.1fr,0.9fr] items-center">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <img
                src="https://picsum.photos/1000/700?random=52"
                alt="Protocol Canvas editors reviewing systems diagrams"
                className="rounded-3xl border border-slate-200 shadow-xl"
                loading="lazy"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white border border-slate-200 rounded-3xl p-8 shadow-lg"
            >
              <h2 className="font-satoshi text-2xl font-semibold text-slate-900">
                Our editorial model
              </h2>
              <p className="mt-4 text-base text-slate-600 leading-relaxed">
                We embrace a research-to-story pipeline. Field interviews capture practitioner voices. Documentation audits provide rigor. Narrative frameworks align with how teams share knowledge internally. This model keeps our coverage accurate and accessible.
              </p>
              <p className="mt-4 text-base text-slate-600 leading-relaxed">
                Based in Toronto, our editorial network extends across Canada. We publish in English, stay responsive to regional policy contexts, and champion transparent infrastructure practices.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="mt-16 bg-white py-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="font-satoshi text-3xl font-semibold text-slate-900">
              Core values
            </h2>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {values.map((value) => (
                <div
                  key={value.title}
                  className="bg-slate-50 border border-slate-200 rounded-3xl p-6 hover:border-blue-200 transition"
                >
                  <h3 className="font-satoshi text-xl font-semibold text-slate-900">
                    {value.title}
                  </h3>
                  <p className="mt-4 text-sm text-slate-600 leading-relaxed">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mt-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="font-satoshi text-3xl font-semibold text-slate-900">
              Milestones
            </h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              {timeline.map((item) => (
                <div
                  key={item.year}
                  className="bg-white border border-slate-200 rounded-3xl p-6 hover:border-blue-200 transition"
                >
                  <p className="text-sm uppercase tracking-wide text-blue-500">{item.year}</p>
                  <p className="mt-3 text-base text-slate-600 leading-relaxed">{item.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mt-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 bg-slate-900 text-white rounded-3xl p-10">
            <h2 className="font-satoshi text-3xl font-semibold">
              Editorial footprint across Canada
            </h2>
            <p className="mt-4 text-base text-slate-300 leading-relaxed">
              Our contributors report from British Columbia, Alberta, Ontario, Quebec, and Atlantic Canada. This distributed perspective helps us track how different jurisdictions interpret shared standards. We collaborate closely with public agencies, civic tech collectives, and private sector teams advancing interoperable systems.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default About;