import React from "react";
import { Helmet } from "react-helmet";

const patterns = [
  {
    name: "Dual-write transition pattern",
    description:
      "When migrating protocols, run dual writes with structured validation windows to ensure new message formats behave as expected.",
    context: "Used during payment gateway modernization across provincial agencies."
  },
  {
    name: "Consent-driven rollout",
    description:
      "Secure stakeholder approval for each rollout stage, making policy compliance visible through shared dashboards and checklists.",
    context: "Applied to identity federation upgrades requiring privacy reviews."
  },
  {
    name: "Culture-first incident reviews",
    description:
      "Structure post-incident analyses around empathy, framing protocol gaps as improvement opportunities rather than blame.",
    context: "Keeps cross-functional teams aligned during high-pressure recovery."
  }
];

const Patterns = () => {
  return (
    <>
      <Helmet>
        <title>Patterns | Protocol Canvas</title>
        <meta
          name="description"
          content="Discover Protocol Canvas patterns covering protocol migrations, rollout governance, and culture-first incident reviews."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="uppercase text-xs tracking-[0.3em] text-blue-500">Patterns</p>
            <h1 className="font-satoshi text-4xl sm:text-5xl font-semibold text-slate-900 mt-4">
              Patterns distilled from field research
            </h1>
            <p className="mt-6 text-lg text-slate-600 leading-relaxed">
              Protocol Canvas collects reusable patterns that teams can adapt to their contexts. Each pattern is grounded in interviews and validated through real-world deployments.
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {patterns.map((pattern) => (
              <div
                key={pattern.name}
                className="bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-200 transition"
              >
                <h2 className="font-satoshi text-2xl font-semibold text-slate-900">
                  {pattern.name}
                </h2>
                <p className="mt-4 text-sm text-slate-600 leading-relaxed">{pattern.description}</p>
                <p className="mt-4 text-xs text-blue-500 uppercase tracking-wide">
                  Field context
                </p>
                <p className="mt-2 text-sm text-slate-500">{pattern.context}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default Patterns;