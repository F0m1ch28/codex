import React from "react";
import { Helmet } from "react-helmet";

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Protocol Canvas</title>
        <meta
          name="description"
          content="Review the Protocol Canvas privacy policy outlining how we collect, use, and protect personal information."
        />
      </Helmet>
      <div className="bg-slate-50 pt-24 pb-20">
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white border border-slate-200 rounded-3xl p-10 shadow-lg">
          <h1 className="font-satoshi text-3xl font-semibold text-slate-900">Privacy Policy</h1>
          <p className="mt-4 text-sm text-slate-500">Updated: September 15, 2023</p>
          <div className="mt-8 space-y-6 text-sm text-slate-600 leading-relaxed">
            <p>
              Protocol Canvas protects your privacy in alignment with Canadian privacy legislation. We collect personal information only when you submit a contact form, subscribe to our newsletter, or participate in research engagements.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Information we collect</h2>
            <ul className="list-disc list-inside space-y-2">
              <li>Contact details (name, email, organization) provided via forms.</li>
              <li>Contextual information included in messages or research briefs.</li>
              <li>Aggregated analytics data to understand readership patterns.</li>
            </ul>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">How we use information</h2>
            <p>
              We use submitted information to respond to inquiries, coordinate editorial work, and deliver newsletters. We do not sell or share personal information with advertisers.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Data storage</h2>
            <p>
              Information is stored securely on Canadian or trusted international infrastructure with contractual safeguards. Access is limited to core team members who require the information to perform editorial work.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Cookies and analytics</h2>
            <p>
              Protocol Canvas uses functional cookies. Analytics are collected in aggregate form to improve content planning. You can adjust cookie preferences using the cookie banner or by contacting us.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Your rights</h2>
            <p>
              You may request access, corrections, or deletion of your personal information by contacting our team. We respond to privacy requests within 30 days.
            </p>
            <h2 className="font-satoshi text-xl text-slate-900 mt-6">Contact</h2>
            <p>
              Questions about this policy can be directed through our contact form or by mail at 401 Bay St, Toronto, ON M5H 2Y4, Canada.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default Privacy;