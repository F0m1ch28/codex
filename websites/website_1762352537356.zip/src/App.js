import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import ContactThanks from "./pages/ContactThanks";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import CookiePolicy from "./pages/CookiePolicy";
import Blog from "./pages/Blog";
import ArticleCloudNative from "./pages/ArticleCloudNative";
import ArticleFragmentedStandards from "./pages/ArticleFragmentedStandards";
import ArticleConsensusAlgorithms from "./pages/ArticleConsensusAlgorithms";
import Tooling from "./pages/Tooling";
import Culture from "./pages/Culture";
import Sources from "./pages/Sources";
import Library from "./pages/Library";
import Patterns from "./pages/Patterns";

const PageTransition = ({ children }) => (
  <motion.main
    className="min-h-screen bg-slate-50"
    initial={{ opacity: 0, y: 24 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -24 }}
    transition={{ duration: 0.35, ease: "easeOut" }}
  >
    {children}
  </motion.main>
);

const AnimatedRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait" initial={false}>
      <Routes location={location} key={location.pathname}>
        <Route
          path="/"
          element={
            <PageTransition>
              <Home />
            </PageTransition>
          }
        />
        <Route
          path="/about"
          element={
            <PageTransition>
              <About />
            </PageTransition>
          }
        />
        <Route
          path="/services"
          element={
            <PageTransition>
              <Services />
            </PageTransition>
          }
        />
        <Route
          path="/tooling"
          element={
            <PageTransition>
              <Tooling />
            </PageTransition>
          }
        />
        <Route
          path="/culture"
          element={
            <PageTransition>
              <Culture />
            </PageTransition>
          }
        />
        <Route
          path="/library"
          element={
            <PageTransition>
              <Library />
            </PageTransition>
          }
        />
        <Route
          path="/patterns"
          element={
            <PageTransition>
              <Patterns />
            </PageTransition>
          }
        />
        <Route
          path="/sources"
          element={
            <PageTransition>
              <Sources />
            </PageTransition>
          }
        />
        <Route
          path="/blog"
          element={
            <PageTransition>
              <Blog />
            </PageTransition>
          }
        />
        <Route
          path="/blog/cloud-native-protocols"
          element={
            <PageTransition>
              <ArticleCloudNative />
            </PageTransition>
          }
        />
        <Route
          path="/blog/the-cost-of-fragmented-standards"
          element={
            <PageTransition>
              <ArticleFragmentedStandards />
            </PageTransition>
          }
        />
        <Route
          path="/blog/why-consensus-algorithms-matter"
          element={
            <PageTransition>
              <ArticleConsensusAlgorithms />
            </PageTransition>
          }
        />
        <Route
          path="/contact"
          element={
            <PageTransition>
              <Contact />
            </PageTransition>
          }
        />
        <Route
          path="/contact/thanks"
          element={
            <PageTransition>
              <ContactThanks />
            </PageTransition>
          }
        />
        <Route
          path="/privacy"
          element={
            <PageTransition>
              <Privacy />
            </PageTransition>
          }
        />
        <Route
          path="/terms"
          element={
            <PageTransition>
              <Terms />
            </PageTransition>
          }
        />
        <Route
          path="/cookie-policy"
          element={
            <PageTransition>
              <CookiePolicy />
            </PageTransition>
          }
        />
      </Routes>
    </AnimatePresence>
  );
};

const App = () => {
  return (
    <div className="bg-slate-50 text-slate-900 font-inter">
      <Header />
      <ScrollToTop />
      <AnimatedRoutes />
      <Footer />
      <CookieBanner />
    </div>
  );
};

export default App;