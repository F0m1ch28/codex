import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid gap-12 lg:grid-cols-4">
        <div>
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">
              PC
            </div>
            <div>
              <p className="font-satoshi text-xl font-semibold">Protocol Canvas</p>
              <p className="text-sm text-slate-400 mt-1">
                Canadian editorial platform for protocol-centric engineering.
              </p>
            </div>
          </div>
          <p className="text-sm text-slate-400 mt-6 leading-relaxed">
            Protocol Canvas examines distributed systems, cloud-native infrastructure, and the people who steward them. Our editors document the architectures, trade-offs, and cultural shifts guiding resilient platforms.
          </p>
        </div>
        <div>
          <h4 className="font-semibold text-lg font-satoshi mb-4">Explore</h4>
          <nav className="space-y-3">
            <NavLink to="/tooling" className="block text-sm text-slate-300 hover:text-white transition">
              Tooling Index
            </NavLink>
            <NavLink to="/culture" className="block text-sm text-slate-300 hover:text-white transition">
              Culture Essays
            </NavLink>
            <NavLink to="/library" className="block text-sm text-slate-300 hover:text-white transition">
              Library
            </NavLink>
            <NavLink to="/patterns" className="block text-sm text-slate-300 hover:text-white transition">
              Patterns
            </NavLink>
            <NavLink to="/sources" className="block text-sm text-slate-300 hover:text-white transition">
              Sources
            </NavLink>
          </nav>
        </div>
        <div>
          <h4 className="font-semibold text-lg font-satoshi mb-4">Editorial</h4>
          <nav className="space-y-3">
            <NavLink to="/blog" className="block text-sm text-slate-300 hover:text-white transition">
              Blog
            </NavLink>
            <NavLink to="/about" className="block text-sm text-slate-300 hover:text-white transition">
              About Protocol Canvas
            </NavLink>
            <NavLink to="/services" className="block text-sm text-slate-300 hover:text-white transition">
              Services
            </NavLink>
            <NavLink to="/privacy" className="block text-sm text-slate-300 hover:text-white transition">
              Privacy
            </NavLink>
            <NavLink to="/terms" className="block text-sm text-slate-300 hover:text-white transition">
              Terms
            </NavLink>
            <NavLink to="/cookie-policy" className="block text-sm text-slate-300 hover:text-white transition">
              Cookie Policy
            </NavLink>
          </nav>
        </div>
        <div>
          <h4 className="font-semibold text-lg font-satoshi mb-4">Contact</h4>
          <ul className="text-sm text-slate-300 space-y-3">
            <li>401 Bay St, Toronto, ON M5H 2Y4, Canada</li>
            <li>Phone: +1 (437) 802-1184</li>
            <li>Email inquiries are gathered through the contact form.</li>
          </ul>
          <p className="text-xs text-slate-500 mt-6">
            Office hours follow Eastern Time. For urgent newsroom coordination, note your timezone and response window in the contact message.
          </p>
        </div>
      </div>
      <div className="border-t border-slate-800 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} Protocol Canvas. All rights reserved.</p>
          <p>Designed in Toronto, published for Canada and beyond.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;