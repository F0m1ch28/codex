import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedPreference = localStorage.getItem("protocol-canvas-cookie-consent");
    if (!storedPreference) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("protocol-canvas-cookie-consent", "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem("protocol-canvas-cookie-consent", "declined");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-x-4 bottom-4 z-50 bg-white border border-slate-200 rounded-2xl shadow-xl max-w-3xl mx-auto p-5 sm:flex sm:items-center sm:justify-between gap-4"
          initial={{ opacity: 0, y: 48 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 32 }}
          role="dialog"
          aria-live="polite"
        >
          <div>
            <h2 className="font-satoshi font-semibold text-slate-900 text-lg">
              Cookies & telemetry
            </h2>
            <p className="text-sm text-slate-600 mt-2">
              Protocol Canvas uses functional cookies and privacy-respecting analytics to understand readership patterns. You can opt out at any time via our cookie policy.
            </p>
          </div>
          <div className="flex items-center gap-3 mt-4 sm:mt-0">
            <button
              onClick={handleDecline}
              className="w-full sm:w-auto px-4 py-2 rounded-full text-sm font-medium text-slate-700 bg-slate-200 hover:bg-slate-300 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            >
              Decline
            </button>
            <button
              onClick={handleAccept}
              className="w-full sm:w-auto px-4 py-2 rounded-full text-sm font-semibold text-white bg-blue-500 hover:bg-blue-400 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
            >
              Accept
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieBanner;