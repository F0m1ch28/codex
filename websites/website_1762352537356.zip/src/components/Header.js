import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { path: "/", label: "Home" },
  { path: "/about", label: "About" },
  { path: "/services", label: "Services" },
  { path: "/tooling", label: "Tooling" },
  { path: "/culture", label: "Culture" },
  { path: "/library", label: "Library" },
  { path: "/patterns", label: "Patterns" },
  { path: "/blog", label: "Blog" },
  { path: "/sources", label: "Sources" },
  { path: "/contact", label: "Contact" }
];

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 12);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
  }, [menuOpen]);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all ${
        isScrolled
          ? "bg-slate-900/90 backdrop-blur shadow-lg shadow-slate-900/10"
          : "bg-slate-900/70 backdrop-blur-sm"
      }`}
      aria-label="Primary navigation"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <NavLink
            to="/"
            className="flex items-center space-x-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded"
          >
            <div className="h-10 w-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">
              PC
            </div>
            <div>
              <span className="text-white font-satoshi text-lg font-semibold leading-tight">
                Protocol Canvas
              </span>
              <p className="text-xs text-slate-300">
                Decoding the language of systems
              </p>
            </div>
          </NavLink>
          <nav className="hidden lg:flex items-center space-x-6">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `text-sm font-medium transition hover:text-blue-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded ${
                    isActive ? "text-blue-300" : "text-slate-200"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <a
              href="#newsletter"
              className="inline-flex items-center justify-center rounded-full px-4 py-2 text-sm font-semibold text-white bg-blue-500 hover:bg-blue-400 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
            >
              Join Updates
            </a>
          </nav>
          <button
            className="lg:hidden inline-flex items-center justify-center p-2 rounded-md text-slate-200 hover:bg-slate-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label="Toggle navigation menu"
          >
            <span className="sr-only">Toggle navigation</span>
            <div className="space-y-1">
              <span
                className={`block h-0.5 w-6 bg-white transition ${
                  menuOpen ? "rotate-45 translate-y-1.5" : ""
                }`}
              />
              <span
                className={`block h-0.5 w-6 bg-white transition ${
                  menuOpen ? "opacity-0" : ""
                }`}
              />
              <span
                className={`block h-0.5 w-6 bg-white transition ${
                  menuOpen ? "-rotate-45 -translate-y-1.5" : ""
                }`}
              />
            </div>
          </button>
        </div>
      </div>
      <AnimatePresence>
        {menuOpen && (
          <motion.nav
            id="mobile-menu"
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="lg:hidden bg-slate-900/95 backdrop-blur"
          >
            <div className="px-4 py-6 space-y-4">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setMenuOpen(false)}
                  className={({ isActive }) =>
                    `block text-base font-medium py-2 rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 transition ${
                      isActive ? "text-blue-300" : "text-slate-200"
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <a
                href="#newsletter"
                onClick={() => setMenuOpen(false)}
                className="inline-flex items-center justify-center w-full rounded-full px-4 py-3 text-sm font-semibold text-white bg-blue-500 hover:bg-blue-400 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-300"
              >
                Join Updates
              </a>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;