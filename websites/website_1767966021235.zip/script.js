document.addEventListener("DOMContentLoaded", function () {
    const yearSpan = document.getElementById("currentYear");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".primary-nav");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navMenu.classList.toggle("open");
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
        });

        navMenu.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    const filterButtons = document.querySelectorAll(".filter-button");
    const postCards = document.querySelectorAll("[data-category]");
    const searchInput = document.getElementById("postSearch");

    function applyFilters() {
        const activeButton = document.querySelector(".filter-button.active");
        const filterValue = activeButton ? activeButton.dataset.filter : "all";
        const searchTerm = searchInput ? searchInput.value.trim().toLowerCase() : "";

        postCards.forEach((card) => {
            const matchesFilter = filterValue === "all" || card.dataset.category === filterValue;
            const matchesSearch =
                searchTerm.length === 0 ||
                card.dataset.title.includes(searchTerm) ||
                card.dataset.summary.includes(searchTerm);
            if (matchesFilter && matchesSearch) {
                card.classList.remove("hidden");
            } else {
                card.classList.add("hidden");
            }
        });
    }

    if (filterButtons.length > 0) {
        filterButtons.forEach((button) => {
            button.addEventListener("click", () => {
                filterButtons.forEach((btn) => btn.classList.remove("active"));
                button.classList.add("active");
                applyFilters();
            });
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", applyFilters);
    }

    document.querySelectorAll("form[data-redirect]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            event.preventDefault();
            const redirectTarget = form.dataset.redirect || "thanks.html";
            window.location.href = redirectTarget;
        });
    });

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieActions = document.querySelectorAll(".cookie-banner .cookie-action");
    if (cookieBanner) {
        const storedConsent = localStorage.getItem("ncpCookieConsent");
        if (storedConsent) {
            cookieBanner.classList.add("hidden");
        }

        cookieActions.forEach((action) => {
            action.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = action.dataset.choice || "acknowledged";
                localStorage.setItem("ncpCookieConsent", choice);
                cookieBanner.classList.add("hidden");
                const target = action.getAttribute("href");
                if (target) {
                    window.open(target, "_blank");
                }
            });
        });
    }
});