document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (siteNav.classList.contains('is-open')) {
          siteNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  // Intersection observer for reveal animations
  const revealElements = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealElements.length) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    revealElements.forEach(el => observer.observe(el));
  } else {
    revealElements.forEach(el => el.classList.add('in-view'));
  }

  // Contact form handling
  const contactForms = document.querySelectorAll('[data-form="contact"]');
  contactForms.forEach(form => {
    const status = form.querySelector('.form-status');
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!status) return;

      const name = form.querySelector('[name="name"]');
      const email = form.querySelector('[name="email"]');
      const message = form.querySelector('[name="message"]');

      const errors = [];

      if (!name.value.trim()) {
        errors.push('Please enter your name.');
      }

      if (!email.value.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        errors.push('Enter a valid email address.');
      }

      if (!message.value.trim()) {
        errors.push('Share a brief overview of your project.');
      }

      if (errors.length) {
        status.textContent = errors.join(' ');
        status.classList.remove('success');
        status.classList.add('error');
        return;
      }

      status.textContent = 'Sending…';
      status.classList.remove('error');
      status.classList.remove('success');

      setTimeout(() => {
        status.textContent = 'Thank you! Our team will reach out shortly.';
        status.classList.add('success');
        form.reset();
      }, 800);
    });
  });

  // Newsletter subscription forms
  const subscribeForms = document.querySelectorAll('[data-form="subscribe"]');
  subscribeForms.forEach(form => {
    const status = form.querySelector('.form-status');
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!status) return;

      const emailInput = form.querySelector('input[type="email"]');
      const emailValue = emailInput.value.trim();

      if (!emailValue || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) {
        status.textContent = 'Please provide a valid email.';
        status.classList.remove('success');
        status.classList.add('error');
        return;
      }

      status.textContent = 'Subscribing…';
      status.classList.remove('success');
      status.classList.remove('error');

      setTimeout(() => {
        status.textContent = 'Thanks for subscribing! Check your inbox for confirmation.';
        status.classList.add('success');
        emailInput.value = '';
      }, 600);
    });
  });

  // FAQ accordion toggle
  const faqButtons = document.querySelectorAll('[data-faq-toggle]');
  faqButtons.forEach(button => {
    const answer = button.nextElementSibling;
    if (!answer) return;

    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';

      button.setAttribute('aria-expanded', String(!expanded));

      if (!expanded) {
        answer.hidden = false;
        answer.classList.add('is-open');
        answer.style.maxHeight = `${answer.scrollHeight}px`;
      } else {
        answer.style.maxHeight = `${answer.scrollHeight}px`;
        requestAnimationFrame(() => {
          answer.style.maxHeight = '0px';
        });
        answer.addEventListener('transitionend', () => {
          answer.hidden = true;
          answer.classList.remove('is-open');
          answer.style.maxHeight = '';
        }, { once: true });
      }
    });
  });

  // Cookie consent banner
  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('.cookie-accept');
    const declineButton = cookieBanner.querySelector('.cookie-decline');
    const consentKey = 'apex_cookie_consent';

    const hideBanner = () => {
      cookieBanner.classList.remove('is-visible');
      cookieBanner.classList.add('is-hidden');
    };

    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      setTimeout(() => {
        cookieBanner.classList.add('is-visible');
      }, 800);
    } else {
      hideBanner();
    }

    acceptButton?.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      hideBanner();
    });

    declineButton?.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'declined');
      hideBanner();
    });
  }

  // Update footer year
  const yearSpans = document.querySelectorAll('#current-year');
  const currentYear = new Date().getFullYear();
  yearSpans.forEach(span => {
    span.textContent = currentYear;
  });
});