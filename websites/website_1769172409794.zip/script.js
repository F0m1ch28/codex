document.documentElement.classList.add('js-enabled');

document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.mobile-toggle');
  const navList = document.querySelector('.nav-list');

  if (navToggle && header && navList) {
    navToggle.addEventListener('click', () => {
      const isOpen = header.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    navList.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (header.classList.contains('nav-open')) {
          header.classList.remove('nav-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const yearEl = document.getElementById('currentYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('.animate-on-scroll').forEach(element => {
    observer.observe(element);
  });

  const cookieBanner = document.getElementById('cookieBanner');
  const acceptBtn = cookieBanner ? cookieBanner.querySelector('.cookie-accept') : null;
  const declineBtn = cookieBanner ? cookieBanner.querySelector('.cookie-decline') : null;
  const consentKey = 'uws_cookie_consent';

  const showCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.classList.add('is-visible');
    }
  };

  const hideCookieBanner = value => {
    if (cookieBanner) {
      cookieBanner.classList.remove('is-visible');
      localStorage.setItem(consentKey, value);
    }
  };

  if (!localStorage.getItem(consentKey)) {
    setTimeout(showCookieBanner, 600);
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => hideCookieBanner('accepted'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => hideCookieBanner('declined'));
  }

  const toast = document.getElementById('globalToast');
  let toastTimeout;

  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.setAttribute('aria-hidden', 'false');
    toast.classList.add('is-visible');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toast.classList.remove('is-visible');
      toast.setAttribute('aria-hidden', 'true');
    }, 2200);
  };

  document.querySelectorAll('form.needs-toast').forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const action = form.getAttribute('action') || 'thank-you.html';
      showToast('Solicitarea ta este transmisă către UrbanWash Station.');
      setTimeout(() => {
        window.location.href = action;
      }, 1100);
    });
  });
});