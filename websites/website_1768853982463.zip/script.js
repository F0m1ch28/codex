document.addEventListener("DOMContentLoaded", () => {
  const banner = document.getElementById("cookie-banner");
  if (banner) {
    const storedPreference = localStorage.getItem("saMarketInsightsCookiePref");
    if (storedPreference) {
      banner.classList.add("is-hidden");
    }
    const acceptButton = banner.querySelector(".accept");
    const declineButton = banner.querySelector(".decline");

    const hideBanner = (preference) => {
      localStorage.setItem("saMarketInsightsCookiePref", preference);
      banner.classList.add("is-hidden");
    };

    if (acceptButton) {
      acceptButton.addEventListener("click", () => hideBanner("accepted"));
    }
    if (declineButton) {
      declineButton.addEventListener("click", () => hideBanner("declined"));
    }
  }

  const navToggle = document.querySelector(".nav-toggle");
  const navMenu = document.getElementById("primary-navigation");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      const isOpen = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isOpen));
      navMenu.classList.toggle("is-open");
    });

    navMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        navMenu.classList.remove("is-open");
      });
    });
  }
});