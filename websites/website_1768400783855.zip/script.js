document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('[data-cookie-action]');
    const consentKey = 'audiortreg-cookie-consent';

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            siteNav.classList.toggle('is-open');
        });

        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 992 && siteNav.classList.contains('is-open')) {
                    navToggle.setAttribute('aria-expanded', 'false');
                    siteNav.classList.remove('is-open');
                }
            });
        });
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            requestAnimationFrame(() => {
                cookieBanner.classList.add('is-visible');
            });
        }

        cookieButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-cookie-action');
                localStorage.setItem(consentKey, action);
                cookieBanner.classList.remove('is-visible');
            });
        });
    }
});