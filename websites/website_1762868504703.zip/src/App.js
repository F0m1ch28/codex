import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Jobs from './pages/Jobs';
import Services from './pages/Services';
import Lernen from './pages/Lernen';
import Community from './pages/Community';
import Plans from './pages/Plans';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

function RouteChangeHandler() {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return null;
}

function App() {
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Vexoralia',
    url: 'https://www.vexoralia.de',
    description:
      'Vexoralia ist eine deutsche Plattform für Remote-Arbeit, kuratierte Jobs, digitale Tools und Lernpfade.',
    logo: 'https://www.vexoralia.de/logo.png',
    sameAs: [
      'https://www.linkedin.com/company/vexoralia',
      'https://twitter.com/vexoralia'
    ]
  };

  return (
    <>
      <Helmet>
        <title>Vexoralia – Remote-Arbeit Plattform für flexible Teams</title>
        <meta
          name="description"
          content="Vexoralia vernetzt Fachkräfte und Unternehmen für ortsunabhängige Zusammenarbeit, bietet kuratierte Remote-Jobs, Tools, Lernpfade und eine aktive Community in ganz Deutschland."
        />
        <meta name="robots" content="index,follow" />
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      </Helmet>
      <RouteChangeHandler />
      <div className="app-shell">
        <Header />
        <main className="main-content" aria-live="polite">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/über-uns" element={<About />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/funktionen" element={<Services />} />
            <Route path="/lernen" element={<Lernen />} />
            <Route path="/community" element={<Community />} />
            <Route path="/pläne" element={<Plans />} />
            <Route path="/kontakt" element={<Contact />} />
            <Route path="/nutzungsbedingungen" element={<Terms />} />
            <Route path="/datenschutz" element={<Privacy />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <ScrollToTop />
      </div>
    </>
  );
}

export default App;