import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brand}>
            <div className={styles.logo}>Vexoralia</div>
            <p>
              Vexoralia verbindet ambitionierte Fachkräfte mit Unternehmen, die flexible Arbeit
              leben. Wir gestalten Remote-Workflows, die Menschen zusammenbringen.
            </p>
          </div>
          <div>
            <h3>Navigation</h3>
            <ul>
              <li>
                <NavLink to="/über-uns">Über uns</NavLink>
              </li>
              <li>
                <NavLink to="/jobs">Jobs</NavLink>
              </li>
              <li>
                <NavLink to="/funktionen">Funktionen</NavLink>
              </li>
              <li>
                <NavLink to="/lernen">Lernen</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3>Mehr entdecken</h3>
            <ul>
              <li>
                <NavLink to="/community">Community</NavLink>
              </li>
              <li>
                <NavLink to="/pläne">Pläne</NavLink>
              </li>
              <li>
                <NavLink to="/nutzungsbedingungen">Nutzungsbedingungen</NavLink>
              </li>
              <li>
                <NavLink to="/datenschutz">Datenschutz</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3>Kontakt</h3>
            <ul>
              <li>
                <a href="mailto:hello@vexoralia.de" aria-label="E-Mail an Vexoralia">
                  hello@vexoralia.de
                </a>
              </li>
              <li>Telefon: —</li>
              <li>Adresse: —</li>
            </ul>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} Vexoralia. Alle Rechte vorbehalten.</p>
          <div className={styles.socials} aria-label="Soziale Medien">
            <a href="https://www.linkedin.com/company/vexoralia" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="https://twitter.com/vexoralia" aria-label="Twitter">
              Twitter
            </a>
            <a href="https://www.instagram.com/vexoralia" aria-label="Instagram">
              Instagram
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;