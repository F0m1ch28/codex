import React from 'react';
import { NavLink } from 'react-router-dom';
import { ReactComponent as MenuIcon } from '../icons/menu.svg';
import { ReactComponent as CloseIcon } from '../icons/close.svg';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Start' },
  { path: '/über-uns', label: 'Über uns' },
  { path: '/jobs', label: 'Jobs' },
  { path: '/funktionen', label: 'Funktionen' },
  { path: '/lernen', label: 'Lernen' },
  { path: '/community', label: 'Community' },
  { path: '/pläne', label: 'Pläne' },
  { path: '/kontakt', label: 'Kontakt' }
];

function Header() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  React.useEffect(() => {
    if (isMenuOpen) {
      document.body.classList.add('menu-open');
    } else {
      document.body.classList.remove('menu-open');
    }
  }, [isMenuOpen]);

  return (
    <header className={styles.header}>
      <div className="container">
        <div className={styles.wrapper}>
          <NavLink
            to="/"
            className={styles.logo}
            aria-label="Vexoralia Startseite"
            onClick={closeMenu}
          >
            <span className={styles.logoMark} aria-hidden="true">
              VX
            </span>
            <span className={styles.logoText}>Vexoralia</span>
          </NavLink>
          <nav
            className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}
            aria-label="Hauptnavigation"
          >
            <ul className={styles.navList}>
              {navItems.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    className={({ isActive }) =>
                      isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
                    }
                    onClick={closeMenu}
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
          <div className={styles.actions}>
            <NavLink to="/funktionen" className={styles.outlineButton}>
              App ausprobieren
            </NavLink>
            <button
              type="button"
              className={styles.menuButton}
              aria-label={isMenuOpen ? 'Navigation schließen' : 'Navigation öffnen'}
              aria-expanded={isMenuOpen}
              onClick={toggleMenu}
            >
              {isMenuOpen ? <CloseIcon aria-hidden="true" /> : <MenuIcon aria-hidden="true" />}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;