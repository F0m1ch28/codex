import React from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'vexoralia_cookie_consent';

function CookieBanner() {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="assertive">
      <div className={styles.text}>
        <h2>Cookies & Monitoring</h2>
        <p>
          Wir verwenden funktionale Cookies, um Ihr Erlebnis zu verbessern. Sie können Ihre
          Einstellungen jederzeit in den Browsereinstellungen anpassen.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Einverstanden
      </button>
    </div>
  );
}

export default CookieBanner;