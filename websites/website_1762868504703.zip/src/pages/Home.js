import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { label: 'Partner-Unternehmen', target: 320 },
  { label: 'Remote-Fachkräfte', target: 12800 },
  { label: 'Verfügbare Tools', target: 46 },
  { label: 'Lernpfade', target: 58 }
];

const servicesData = [
  {
    title: 'Kuratiertes Job-Matching',
    description:
      'Erhalten Sie Jobs, die zu Ihren Fähigkeiten, Sprachen und Zeitzonen passen. Unser Matching berücksichtigt Branchen und Teamkultur.',
    icon: '🧭',
    link: '/jobs'
  },
  {
    title: 'Workflow Tool-Kit',
    description:
      'Verbinden Sie Ihre bevorzugten Projektboards, Videotools und Dokumentationen. Alles in einem anpassbaren Dashboard.',
    icon: '🛠️',
    link: '/funktionen'
  },
  {
    title: 'Lernpfade & Micro-Labs',
    description:
      'Vertiefen Sie Fähigkeiten mit modularen Einheiten rund um Remote-Kommunikation, Leadership, Produktivität und Resilienz.',
    icon: '🎓',
    link: '/lernen'
  },
  {
    title: 'Community & Mentoring',
    description:
      'Vernetzen Sie sich mit anderen Remote-Professionals, tauschen Sie Best Practices aus und finden Sie Mentorinnen und Mentoren.',
    icon: '🤝',
    link: '/community'
  }
];

const processSteps = [
  {
    step: '1',
    title: 'Anmelden',
    description:
      'Profil anlegen, Kompetenzen hervorheben und bevorzugte Arbeitsmodelle festlegen.'
  },
  {
    step: '2',
    title: 'Profil verfeinern',
    description:
      'Portfolio, Projekterfolge und Verfügbarkeiten ergänzen. Unsere KI unterstützt bei der Profiloptimierung.'
  },
  {
    step: '3',
    title: 'Remote-Jobs & Tools',
    description:
      'Persönliche Jobvorschläge erhalten, empfohlene Tool-Stacks testen und Workflows aufsetzen.'
  },
  {
    step: '4',
    title: 'Workflow gestalten',
    description:
      'Mit Teams zusammenarbeiten, Prozesse synchronisieren und Fortschritt in Echtzeit verfolgen.'
  }
];

const testimonials = [
  {
    quote:
      'Durch Vexoralia haben wir Teams in drei Ländern aufgebaut, ohne die Unternehmenskultur zu verlieren.',
    name: 'Lea Hoffmann',
    role: 'Operations Lead, Novalabs'
  },
  {
    quote:
      'Die Lernpfade und Check-ins helfen uns, neue Entwicklerinnen schnell remote einzuarbeiten.',
    name: 'Samuel Krüger',
    role: 'CTO, Datarise'
  },
  {
    quote:
      'Als UX-Designer arbeite ich jetzt projektübergreifend mit europäischen Kundinnen. Die Community inspiriert täglich.',
    name: 'Mina Klee',
    role: 'Freelance Experience Designer'
  }
];

const teamPreview = [
  {
    name: 'Larissa Dietz',
    role: 'Head of Platform',
    focus: 'Digitale Infrastruktur & Produkt',
    img: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Noah Zimmer',
    role: 'Lead Remote Operations',
    focus: 'Prozesse & Automatisierung',
    img: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Eva Marin',
    role: 'Community Strategin',
    focus: 'Mentoring & Events',
    img: 'https://picsum.photos/400/400?random=33'
  }
];

const projectsData = [
  {
    title: 'Remote Customer Hub',
    category: 'Collaboration',
    img: 'https://picsum.photos/1200/800?random=41',
    description: 'Zentrales Dashboard für Support-Teams mit Fokus auf Transparenz.'
  },
  {
    title: 'Async Product Sprint',
    category: 'Produktentwicklung',
    img: 'https://picsum.photos/1200/800?random=42',
    description: 'Remote Sprints mit strukturierten Ritualen und messbaren Ergebnissen.'
  },
  {
    title: 'Hybrid Leadership Toolkit',
    category: 'Leadership',
    img: 'https://picsum.photos/1200/800?random=43',
    description: 'Guides und Checklisten zur Führung internationaler Teams.'
  },
  {
    title: 'Community Pulse Analytics',
    category: 'Collaboration',
    img: 'https://picsum.photos/1200/800?random=44',
    description: 'Datengestützte Insights zu Engagement, Feedback und Lernfortschritt.'
  }
];

const faqItems = [
  {
    question: 'Wie unterstützt Vexoralia beim Onboarding neuer Remote-Kolleginnen?',
    answer:
      'Wir kombinieren geführte Lernpfade mit Checklisten, Videoanleitungen und Peer-Sessions. Teams erhalten eine Onboarding-Map, die individuelle Rollen berücksichtigt.'
  },
  {
    question: 'Welche Integrationen stehen zur Verfügung?',
    answer:
      'Zu den beliebtesten Integrationen zählen Task-Boards, Dokumentationsplattformen, Meeting-Tools und Automatisierungslösungen. Das Tool-Kit lässt sich modular erweitern.'
  },
  {
    question: 'Wie werden Remote-Jobs kuratiert?',
    answer:
      'Unser Talent-Team prüft jede Ausschreibung anhand klarer Qualitätskriterien, abgestimmter Zeitmodelle und transparenter Kommunikation mit den Partner-Unternehmen.'
  },
  {
    question: 'Gibt es Support für rechtliche Rahmenbedingungen?',
    answer:
      'Ja. Wir stellen Leitfäden zur Zusammenarbeit über Grenzen hinweg bereit, inklusive Hinweisen zu Arbeitsrecht, Datenschutz und Kollaborationsvereinbarungen.'
  }
];

const blogPosts = [
  {
    title: 'Remote Rituale: Wie hybride Teams Fokus halten',
    summary:
      'Ein Blick in praxisnahe Rituale, die Teams helfen, Klarheit und Zusammenhalt in verteilten Settings zu stärken.',
    date: '12. März 2024'
  },
  {
    title: 'Tool-Stacks vergleichen: Drei Setups für skalierende Teams',
    summary:
      'Analyse verschiedener Toolkombinationen für Vertrieb, Produktentwicklung und Customer Success.',
    date: '27. Februar 2024'
  },
  {
    title: 'Mentoring remote gestalten: Lernerfahrungen aus der Community',
    summary:
      'Community-Mitglieder teilen, wie sie gezielte Mentoring-Programme aufgesetzt und evaluiert haben.',
    date: '9. Februar 2024'
  }
];

function Home() {
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [activeProjectFilter, setActiveProjectFilter] = React.useState('Alle');
  const [animatedStats, setAnimatedStats] = React.useState(
    statsData.map(() => 0)
  );
  const [statsTriggered, setStatsTriggered] = React.useState(false);
  const statsRef = React.useRef(null);

  React.useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsTriggered) {
            setStatsTriggered(true);
          }
        });
      },
      { threshold: 0.45 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, [statsTriggered]);

  React.useEffect(() => {
    if (!statsTriggered) return;

    const intervals = statsData.map((stat, index) => {
      const increment = Math.ceil(stat.target / 60);
      return setInterval(() => {
        setAnimatedStats((prev) => {
          const next = [...prev];
          next[index] = Math.min(next[index] + increment, stat.target);
          return next;
        });
      }, 18);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsTriggered]);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);

    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    activeProjectFilter === 'Alle'
      ? projectsData
      : projectsData.filter((project) => project.category === activeProjectFilter);

  const projectFilters = ['Alle', 'Collaboration', 'Produktentwicklung', 'Leadership'];

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-label="Hero Bereich">
        <div className="container">
          <div className={styles.heroGrid}>
            <div className={styles.heroContent}>
              <h1>Arbeite von überall – gestalte deinen Arbeitsalltag flexibel</h1>
              <p>
                Vexoralia bündelt Remote-Jobs, Tools und Lernpfade in einer Plattform. Wir helfen
                Teams, Arbeitsabläufe zu strukturieren, Zusammenarbeit zu stärken und Projekte
                ortsunabhängig voranzutreiben.
              </p>
              <div className={styles.heroActions}>
                <NavLink to="/jobs" className={styles.primaryButton}>
                  Remote-Jobs entdecken
                </NavLink>
                <NavLink to="/funktionen" className={styles.secondaryButton}>
                  Mehr erfahren
                </NavLink>
              </div>
              <ul className={styles.heroHighlights}>
                <li>Transparente Matching-Profile</li>
                <li>Integrierte Workflows und Dashboards</li>
                <li>Aktive Community und Mentoring</li>
              </ul>
            </div>
            <div className={styles.heroImageWrapper}>
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Professionals arbeiten remote in verschiedenen Umgebungen"
                className={styles.heroImage}
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.intro} aria-label="Einführung">
        <div className="container">
          <div className={styles.introCard}>
            <h2>Wer wir sind</h2>
            <p>
              Vexoralia ist eine in Deutschland entwickelte Plattform, die Remote-Teams aufbaut,
              unterstützt und weiterentwickelt. Wir kombinieren menschliche Expertise mit präziser
              Technologie, um Arbeitsprozesse intuitiv zu gestalten. Von der ersten Jobvermittlung
              bis zum laufenden Projektbetrieb halten wir alle Fäden zusammen.
            </p>
            <div className={styles.introActions}>
              <NavLink to="/über-uns" className={styles.linkButton}>
                Geschichte von Vexoralia
              </NavLink>
              <NavLink to="/community" className={styles.linkButton}>
                Community kennenlernen
              </NavLink>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Kennzahlen" ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <article key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{animatedStats[index]}</span>
                <span className={styles.statLabel}>{stat.label}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.services} aria-label="Funktionen">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Alles an einem Ort</h2>
            <p>
              Unsere Plattform verbindet Recruiting, Projektsteuerung, Kollaboration und
              Weiterentwicklung. Interaktive Module lassen sich flexibel kombinieren.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <NavLink to={service.link} className={styles.cardLink}>
                  Mehr erfahren
                </NavLink>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process} aria-label="So funktioniert es">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>In vier Schritten zum produktiven Remote-Workflow</h2>
            <p>
              Unser Framework bietet einen klaren Ablauf, der Teams und Einzelpersonen hilft,
              Remote-Arbeit kontrolliert aufzubauen.
            </p>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <article key={step.step} className={styles.processCard}>
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.why} aria-label="Warum Vexoralia">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Warum Vexoralia</h2>
            <p>
              Wir denken Remote-Arbeit ganzheitlich – von der sicheren Infrastruktur bis zur
              menschlichen Ebene der Zusammenarbeit.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <article>
              <h3>Transparente Prozesse</h3>
              <p>
                Alle Workflows werden auditierbar dokumentiert. Das schafft Vertrauen, reduziert
                Rückfragen und ermöglicht klare Zuständigkeiten.
              </p>
            </article>
            <article>
              <h3>Stabilität & Sicherheit</h3>
              <p>
                Hosting in Deutschland, DSGVO-konforme Datenräume und rollenbasierte Zugriffe halten
                sensible Informationen geschützt.
              </p>
            </article>
            <article>
              <h3>Begleitende Beratung</h3>
              <p>
                Unser Team unterstützt beim Teambuilding, bei Retrospektiven und bei der Einführung
                neuer Technologien – immer mit Blick auf Ihren Kontext.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Erfahrungsberichte">
        <div className="container">
          <div className={styles.testimonialHeader}>
            <h2>Stories aus der Praxis</h2>
            <div className={styles.testimonialControls}>
              <button
                type="button"
                onClick={() =>
                  setActiveTestimonial(
                    (prev) => (prev - 1 + testimonials.length) % testimonials.length
                  )
                }
                aria-label="Vorherige Story"
              >
                Zurück
              </button>
              <button
                type="button"
                onClick={() => setActiveTestimonial((prev) => (prev + 1) % testimonials.length)}
                aria-label="Nächste Story"
              >
                Weiter
              </button>
            </div>
          </div>
          <div className={styles.testimonialContent}>
            {testimonials.map((testimonial, index) => (
              <blockquote
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.active : ''
                }`}
              >
                <p>„{testimonial.quote}“</p>
                <footer>
                  <span>{testimonial.name}</span>
                  <span>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} aria-label="Team Vorschau">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Menschen hinter der Plattform</h2>
            <p>
              Ein interdisziplinäres Team mit Erfahrung in Produktentwicklung, HR, Kommunikation und
              Organisationsberatung.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamPreview.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.img} alt={`Teammitglied ${member.name}`} loading="lazy" />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <p>{member.role}</p>
                  <span>{member.focus}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-label="Projekte">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Workflows, die nachhaltigen Impact schaffen</h2>
            <p>
              Eine Auswahl an Projekten, bei denen Vexoralia Struktur, Messbarkeit und kollaborative
              Energie geliefert hat.
            </p>
          </div>
          <div className={styles.projectFilters} role="tablist" aria-label="Projektfilter">
            {projectFilters.map((filter) => (
              <button
                key={filter}
                type="button"
                className={
                  filter === activeProjectFilter
                    ? `${styles.filterButton} ${styles.filterActive}`
                    : styles.filterButton
                }
                onClick={() => setActiveProjectFilter(filter)}
                role="tab"
                aria-selected={filter === activeProjectFilter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.img} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq} aria-label="Häufige Fragen">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>FAQ: Remote-Arbeit klar beantwortet</h2>
            <p>
              Wir sammeln Fragen aus der Community und geben Einblicke aus unserer täglichen Arbeit
              mit Remote-Teams.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>
                  <span>{item.question}</span>
                  <span aria-hidden="true">+</span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog} aria-label="Blog Vorschau">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Insights aus der Remote-Praxis</h2>
            <p>
              Aktuelle Beiträge mit Checklisten, Interviews und Analysen rund um moderne
              Zusammenarbeit.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <span>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.summary}</p>
                <NavLink to="/community" className={styles.cardLink}>
                  Beitrag lesen
                </NavLink>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta} aria-label="Call to Action">
        <div className="container">
          <div className={styles.ctaCard}>
            <div>
              <h2>Bereit für die nächste Remote-Etappe?</h2>
              <p>
                Starten Sie mit Ihrem Team oder individuell. Gemeinsam definieren wir Ziele, richten
                Workflows ein und sorgen für messbare Fortschritte.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <NavLink to="/kontakt" className={styles.primaryButton}>
                Jetzt starten
              </NavLink>
              <NavLink to="/jobs" className={styles.secondaryButton}>
                Remote-Jobs entdecken
              </NavLink>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;