import React from 'react';
import styles from './Jobs.module.css';

const jobData = [
  {
    title: 'Product Manager Remote Collaboration',
    company: 'Synccraft GmbH',
    location: 'Berlin / Remote',
    type: 'Vollzeit',
    category: 'Produkt',
    description:
      'Entwickeln von Feature-Roadmaps, Durchführung von Nutzerinterviews und Steuerung cross-funktionaler Teams.'
  },
  {
    title: 'Senior Backend Engineer',
    company: 'Nexonetics',
    location: 'Hamburg / Remote',
    type: 'Vollzeit',
    category: 'Entwicklung',
    description:
      'Microservices in Node.js, Integration von Observability-Tools und Performanceoptimierung in einem hybriden Setup.'
  },
  {
    title: 'UX Researcher Remote',
    company: 'Collective Insight',
    location: 'München / Remote',
    type: 'Teilzeit',
    category: 'Design',
    description:
      'Durchführung internationaler Remote-Studien, Moderation von Interviews und Synthese in Research-Repositories.'
  },
  {
    title: 'People Operations Partner',
    company: 'Orbit Scale',
    location: 'Köln / Remote',
    type: 'Teilzeit',
    category: 'Operations',
    description:
      'Aufbau globaler HR-Prozesse, Remote-Onboarding und Gestaltung nachhaltiger Feedback-Mechanismen.'
  },
  {
    title: 'Frontend Engineer Accessibility',
    company: 'Brightwave Studios',
    location: 'Remote (EU)',
    type: 'Vollzeit',
    category: 'Entwicklung',
    description:
      'Implementierung barrierefreier Interfaces mit React, Zusammenarbeit mit Design und QA, kontinuierliche Verbesserungen.'
  }
];

const categories = ['Alle', 'Produkt', 'Entwicklung', 'Design', 'Operations'];
const types = ['Alle', 'Vollzeit', 'Teilzeit'];

function Jobs() {
  const [categoryFilter, setCategoryFilter] = React.useState('Alle');
  const [typeFilter, setTypeFilter] = React.useState('Alle');
  const [keywords, setKeywords] = React.useState('');

  const filteredJobs = jobData.filter((job) => {
    const matchesCategory = categoryFilter === 'Alle' || job.category === categoryFilter;
    const matchesType = typeFilter === 'Alle' || job.type === typeFilter;
    const matchesKeywords =
      keywords.length === 0 ||
      job.title.toLowerCase().includes(keywords.toLowerCase()) ||
      job.company.toLowerCase().includes(keywords.toLowerCase());
    return matchesCategory && matchesType && matchesKeywords;
  });

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-label="Jobs Hero">
        <div className="container">
          <h1>Kuratiertes Remote-Jobboard</h1>
          <p>
            Entdecken Sie sorgfältig geprüfte Rollen aus ganz Europa. Jede Ausschreibung wurde auf
            Remote-Tauglichkeit, klare Verantwortlichkeiten und kommunikative Linien geprüft.
          </p>
        </div>
      </section>

      <section className={styles.filters} aria-label="Filter">
        <div className="container">
          <div className={styles.filterGrid}>
            <div className={styles.inputGroup}>
              <label htmlFor="keywords">Suche nach Titel oder Unternehmen</label>
              <input
                id="keywords"
                type="text"
                placeholder="z. B. Engineer, Strategin"
                value={keywords}
                onChange={(event) => setKeywords(event.target.value)}
              />
            </div>
            <div className={styles.inputGroup}>
              <label htmlFor="category">Kategorie</label>
              <select
                id="category"
                value={categoryFilter}
                onChange={(event) => setCategoryFilter(event.target.value)}
              >
                {categories.map((category) => (
                  <option key={category}>{category}</option>
                ))}
              </select>
            </div>
            <div className={styles.inputGroup}>
              <label htmlFor="type">Arbeitszeitmodell</label>
              <select
                id="type"
                value={typeFilter}
                onChange={(event) => setTypeFilter(event.target.value)}
              >
                {types.map((type) => (
                  <option key={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.listing} aria-label="Jobliste">
        <div className="container">
          {filteredJobs.length === 0 ? (
            <p>Leider keine Treffer. Bitte Filter anpassen.</p>
          ) : (
            filteredJobs.map((job) => (
              <article key={job.title} className={styles.jobCard}>
                <div>
                  <h2>{job.title}</h2>
                  <div className={styles.jobMeta}>
                    <span>{job.company}</span>
                    <span>{job.location}</span>
                    <span>{job.type}</span>
                  </div>
                  <p>{job.description}</p>
                </div>
                <button type="button" className={styles.jobButton}>
                  Jetzt starten
                </button>
              </article>
            ))
          )}
        </div>
      </section>
    </div>
  );
}

export default Jobs;