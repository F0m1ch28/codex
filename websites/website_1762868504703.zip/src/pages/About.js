import React from 'react';
import styles from './About.module.css';

const milestones = [
  {
    year: '2018',
    title: 'Erste Remote-Teams in Berlin',
    description:
      'Aus einer Beratungsinitiative für digitale Transformation entstand die Idee einer Plattform, die verteilte Teams dauerhaft unterstützt.'
  },
  {
    year: '2020',
    title: 'Vexoralia Plattform Launch',
    description:
      'Wir brachten kuratiertes Job-Matching, Onboarding-Module und Tool-Integrationen in einer Beta-Version zusammen.'
  },
  {
    year: '2022',
    title: 'Community & Lernpfade',
    description:
      'Mit Mentor:innen, Micro-Labs und Peer-Gruppen erweiterten wir die Plattform um kontinuierliche Wissensangebote.'
  },
  {
    year: '2023',
    title: 'Compliance & Analytics Layer',
    description:
      'Einführung von DSGVO-konformen Datenräumen, Governance-Richtlinien und Echtzeit-Analysen für Remote-Teams.'
  }
];

const leadership = [
  {
    name: 'Felix Roland',
    role: 'Co-Founder & CEO',
    bio: 'Verbindet Strategieberatung mit Leidenschaft für grenzenlose Zusammenarbeit. Verantwortlich für Produktstrategie und Partnernetzwerk.',
    img: 'https://picsum.photos/400/400?random=51'
  },
  {
    name: 'Dana Wilke',
    role: 'Co-Founder & Chief Experience Officer',
    bio: 'Fokus auf People Experience, Lernökosysteme und inklusive Kollaboration. Entwickelt Formate für Community und Weiterentwicklung.',
    img: 'https://picsum.photos/400/400?random=52'
  },
  {
    name: 'Hendrik Soyka',
    role: 'Chief Technology Officer',
    bio: 'Erfahrener Architekt für skalierbare Plattformen. Sorgt dafür, dass Integrationen sicher und zukunftsfähig sind.',
    img: 'https://picsum.photos/400/400?random=53'
  }
];

const values = [
  {
    title: 'Vernetzung mit Verantwortung',
    description:
      'Wir schaffen Räume, in denen Vertrauen entsteht. Offen, respektvoll und auf Augenhöhe – egal, wie weit wir voneinander entfernt sind.'
  },
  {
    title: 'Lernen als Dauerzustand',
    description:
      'Remote-Arbeit entwickelt sich weiter. Deshalb betrachten wir Feedback, Reflexion und Wissensaustausch als festen Bestandteil jeder Zusammenarbeit.'
  },
  {
    title: 'Technologie als Enabler',
    description:
      'Tools sollen Prozesse vereinfachen, nicht dominieren. Wir setzen auf Lösungen, die Menschen unterstützen und Transparenz fördern.'
  }
];

function About() {
  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-label="Über uns">
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <h1>Wir gestalten Remote-Arbeit aus Überzeugung</h1>
              <p>
                Vexoralia entstand aus der Beobachtung, dass verteilte Teams nicht nur Technologie,
                sondern auch Kontext und Begleitung benötigen. Heute arbeiten wir mit
                Organisationen, die flexible Strukturen nachhaltig verankern möchten.
              </p>
            </div>
            <img
              src="https://picsum.photos/800/600?random=21"
              alt="Team arbeitet gemeinsam an Laptops in einem modernen Arbeitsraum"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.mission} aria-label="Mission">
        <div className="container">
          <div className={styles.missionGrid}>
            <div>
              <h2>Unsere Mission</h2>
              <p>
                Wir befähigen Menschen und Unternehmen, ortsunabhängig zusammenzuarbeiten, ohne an
                Qualität, Klarheit oder Verbundenheit einzubüßen. Struktur, Transparenz und
                kontinuierliches Feedback sind dafür die Basis.
              </p>
            </div>
            <div>
              <h2>Unsere Vision</h2>
              <p>
                Remote-Arbeit wird zur selbstverständlichen Option in der Arbeitswelt. Vexoralia
                liefert das Ökosystem, das Teams sicher, produktiv und inspiriert arbeiten lässt –
                unabhängig von Zeitzonen oder Hintergründen.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.milestones} aria-label="Meilensteine">
        <div className="container">
          <h2>Meilensteine</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <article key={milestone.year}>
                <span>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.leadership} aria-label="Leitungsteam">
        <div className="container">
          <h2>Leadership-Team</h2>
          <div className={styles.leadershipGrid}>
            {leadership.map((member) => (
              <article key={member.name} className={styles.leadCard}>
                <div className={styles.leadImage}>
                  <img src={member.img} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </div>
                <div className={styles.leadInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.values} aria-label="Werte">
        <div className="container">
          <h2>Werte, die uns leiten</h2>
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title}>
                <h3>{value.title}</h3>
                <p>{value.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;