import React from 'react';
import styles from './Plans.module.css';

const planData = [
  {
    name: 'Team Collaboration',
    focus: 'Für wachsende Teams mit Fokus auf strukturierte Workflows und klare Kommunikation.',
    includes: [
      'Remote-Workspace mit rollenbasiertem Zugriff',
      'Integrationen zu Projekt- und Kommunikationstools',
      'Begleitete Retrospektiven und Health-Checks'
    ]
  },
  {
    name: 'Scale & Enablement',
    focus: 'Für Organisationen, die mehrere Teams synchronisieren und Lernpfade kombinieren möchten.',
    includes: [
      'Individuelle Onboarding-Programme',
      'Analytics Layer für Engagement und Projektdaten',
      'Mentoring-Programme und Community-Gruppen'
    ]
  },
  {
    name: 'Enterprise Alignment',
    focus: 'Für verteilte Organisationen mit regulatorischen Anforderungen und komplexen Governance-Strukturen.',
    includes: [
      'Dedizierte Beratung und technische Betreuung',
      'DSGVO-konformes Data Management mit Audit-Trails',
      'Erweiterte Sicherheits- und Freigabeprozesse'
    ]
  }
];

function Plans() {
  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Pläne für jede Remote-Reise</h1>
          <p>
            Wählen Sie einen Rahmen, der zu Ihrer Organisationsgröße und Ihren Ambitionen passt.
            Unsere Pläne lassen sich modular erweitern.
          </p>
        </div>
      </section>

      <section className={styles.plans} aria-label="Pläne">
        <div className="container">
          <div className={styles.planGrid}>
            {planData.map((plan) => (
              <article key={plan.name} className={styles.planCard}>
                <h2>{plan.name}</h2>
                <p>{plan.focus}</p>
                <ul>
                  {plan.includes.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <button type="button" className={styles.planButton}>
                  App ausprobieren
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Plans;