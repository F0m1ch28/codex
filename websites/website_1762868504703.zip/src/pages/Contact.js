import React from 'react';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  topic: '',
  message: ''
};

function Contact() {
  const [formData, setFormData] = React.useState(initialFormState);
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte Namen eintragen.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte E-Mail eintragen.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Bitte eine gültige E-Mail-Adresse verwenden.';
    }
    if (!formData.topic.trim()) newErrors.topic = 'Bitte Thema auswählen.';
    if (!formData.message.trim()) newErrors.message = 'Bitte Nachricht eintragen.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData(initialFormState);
    }
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Kontakt aufnehmen</h1>
          <p>
            Wir freuen uns auf Ihr Anliegen. Ob Remote-Strategie, Tool-Integration oder Community:
            Unser Team meldet sich zeitnah.
          </p>
        </div>
      </section>

      <section className={styles.mapSection} aria-label="Standort">
        <div className="container">
          <div className={styles.mapCard}>
            <img
              src="https://picsum.photos/1200/600?random=61"
              alt="Illustration einer Deutschlandkarte mit Remote-Standorten"
              loading="lazy"
            />
            <div className={styles.mapInfo}>
              <h2>Deutschlandweit vernetzt</h2>
              <p>
                Unsere Community arbeitet aus mehr als 40 Städten. Beratung und Support finden
                digital statt, ergänzt durch regionale Meetups.
              </p>
              <ul>
                <li>E-Mail: hello@vexoralia.de</li>
                <li>Telefon: —</li>
                <li>Adresse: —</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.formSection} aria-label="Kontaktformular">
        <div className="container">
          <div className={styles.formCard}>
            <h2>Ihre Nachricht</h2>
            {submitted && (
              <div className={styles.success} role="status">
                Vielen Dank für Ihre Nachricht. Wir melden uns bald.
              </div>
            )}
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.formGroup}>
                <label htmlFor="name">Name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={errors.name ? 'true' : 'false'}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="email">E-Mail</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={errors.email ? 'true' : 'false'}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="topic">Thema</label>
                <select
                  id="topic"
                  name="topic"
                  value={formData.topic}
                  onChange={handleChange}
                  aria-invalid={errors.topic ? 'true' : 'false'}
                >
                  <option value="">Bitte wählen</option>
                  <option value="Remote-Strategie">Remote-Strategie</option>
                  <option value="Tool-Integration">Tool-Integration</option>
                  <option value="Community & Mentoring">Community & Mentoring</option>
                  <option value="Presse & Medien">Presse & Medien</option>
                  <option value="Sonstiges">Sonstiges</option>
                </select>
                {errors.topic && <span className={styles.error}>{errors.topic}</span>}
              </div>
              <div className={styles.formGroup}>
                <label htmlFor="message">Nachricht</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={errors.message ? 'true' : 'false'}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submitButton}>
                Abschicken
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;