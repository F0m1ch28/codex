import React from 'react';
import styles from './Community.module.css';

const events = [
  {
    title: 'Remote Focus Forum',
    date: '18. April 2024',
    format: 'Virtuelles Barcamp',
    description:
      'Sessions von Community-Mitgliedern rund um Teamrituale, Onboarding und async Kommunikation.'
  },
  {
    title: 'Mentor:innen Matching Day',
    date: '2. Mai 2024',
    format: 'Speed Mentoring',
    description:
      'Kurze Fokus-Sessions mit erfahrenen Remote-Leads. Ziel: Konkrete Fragestellungen bearbeiten.'
  },
  {
    title: 'Tool Stack Roundtable',
    date: '16. Mai 2024',
    format: 'Moderiertes Panel',
    description:
      'Produktteams teilen Best Practices, wie sie Tool-Landschaften für verschiedene Funktionsbereiche strukturieren.'
  }
];

const communities = [
  {
    name: 'Product & Delivery',
    members: '4.100 Mitglieder',
    highlights: 'Roadmap-Shares, async Sprint Clinics, Peer-Feedback'
  },
  {
    name: 'People & Culture',
    members: '2.800 Mitglieder',
    highlights: 'Policy-Patterns, Remote-Wellbeing, Feedback-Systeme'
  },
  {
    name: 'Engineering Collective',
    members: '5.300 Mitglieder',
    highlights: 'Code-Reviews, Architektur-Diskussionen, Pairing'
  }
];

function Community() {
  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Community für Austausch und Mentoring</h1>
          <p>
            Unsere Community ist ein Raum für Reflexion, Inspiration und kollaboratives Lernen.
            Events, Foren und Mentoring werden moderiert, damit jede Stimme gehört wird.
          </p>
        </div>
      </section>

      <section className={styles.events} aria-label="Veranstaltungen">
        <div className="container">
          <h2>Bevorstehende Formate</h2>
          <div className={styles.eventGrid}>
            {events.map((event) => (
              <article key={event.title}>
                <h3>{event.title}</h3>
                <div className={styles.eventMeta}>
                  <span>{event.date}</span>
                  <span>{event.format}</span>
                </div>
                <p>{event.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.groups} aria-label="Community Bereiche">
        <div className="container">
          <h2>Schwerpunkte</h2>
          <div className={styles.groupGrid}>
            {communities.map((group) => (
              <article key={group.name}>
                <h3>{group.name}</h3>
                <span>{group.members}</span>
                <p>{group.highlights}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Community;