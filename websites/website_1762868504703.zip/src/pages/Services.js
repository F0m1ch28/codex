import React from 'react';
import styles from './Services.module.css';

const modules = [
  {
    title: 'Job-Matching Engine',
    description:
      'Analysiert Fähigkeiten, Zeitzonen und Teamdynamiken. Vorschläge werden kontinuierlich aktualisiert und priorisiert.',
    highlights: ['Skill-Graph', 'Zeitzonenausgleich', 'Teamfit-Check']
  },
  {
    title: 'Bewerbungs-Tracker',
    description:
      'Verwalten Sie Bewerbungsprozesse mit klaren Statusmeldungen, Feedbackschleifen und Reminder-Funktionen.',
    highlights: ['Status-Automation', 'Feedbacktemplates', 'Reminder-Board']
  },
  {
    title: 'Tool-Integrationen',
    description:
      'Nahtlose Verbindungen zu Task-Boards, Statement-of-Work-Templates und Videokonferenzen.',
    highlights: ['API-Konnektoren', 'Konfigurierbare Workflows', 'Sicherheitslayer']
  }
];

const toolkits = [
  {
    name: 'Team Alignment Canvas',
    description:
      'Strukturierte Session-Vorlagen, um Erwartungen, Rituale und Verantwortlichkeiten remote auszurichten.'
  },
  {
    name: 'Async Collaboration Hub',
    description:
      'Zentraler Ort für Entscheidungslogs, Projektstände und Wissensartikel mit granularen Zugriffsrechten.'
  },
  {
    name: 'Pulse Analytics',
    description:
      'Echtzeit-Einblicke in Engagement, Geschwindigkeit und Feedback – visuell aufbereitet für Team-Reviews.'
  }
];

function Services() {
  const [activeModule, setActiveModule] = React.useState(modules[0].title);

  return (
    <div className={styles.page}>
      <section className={styles.hero} aria-label="Funktionen">
        <div className="container">
          <h1>Werkzeuge, die Remote-Teams verbinden</h1>
          <p>
            Vexoralia kombiniert Matching, Workflow-Steuerung und kontinuierliche Entwicklung in
            einer modularen Architektur. Wählen Sie die Bausteine, die zu Ihrer Organisation passen.
          </p>
        </div>
      </section>

      <section className={styles.modules} aria-label="Module">
        <div className="container">
          <div className={styles.moduleSelector} role="tablist" aria-label="Funktionsmodule">
            {modules.map((module) => (
              <button
                key={module.title}
                type="button"
                className={
                  module.title === activeModule
                    ? `${styles.moduleButton} ${styles.moduleActive}`
                    : styles.moduleButton
                }
                onClick={() => setActiveModule(module.title)}
                role="tab"
                aria-selected={module.title === activeModule}
              >
                {module.title}
              </button>
            ))}
          </div>
          <div className={styles.moduleContent}>
            {modules.map(
              (module) =>
                module.title === activeModule && (
                  <article key={module.title} className={styles.moduleCard}>
                    <div>
                      <h2>{module.title}</h2>
                      <p>{module.description}</p>
                    </div>
                    <ul>
                      {module.highlights.map((highlight) => (
                        <li key={highlight}>{highlight}</li>
                      ))}
                    </ul>
                  </article>
                )
            )}
          </div>
        </div>
      </section>

      <section className={styles.toolkits} aria-label="Toolkits">
        <div className="container">
          <h2>Tool-Kit Highlights</h2>
          <div className={styles.toolkitGrid}>
            {toolkits.map((tool) => (
              <article key={tool.name}>
                <h3>{tool.name}</h3>
                <p>{tool.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Services;