import React from 'react';
import styles from './Lernen.module.css';

const learningTracks = [
  {
    name: 'Remote Leadership Essentials',
    duration: '6 Wochen',
    focus: 'Führung, Feedback, Entscheidungsprozesse',
    description:
      'Von Onboarding bis Retrospektive: Strukturiertes Framework für Leader, die hybride Teams navigieren.'
  },
  {
    name: 'Async Collaboration Mastery',
    duration: '4 Wochen',
    focus: 'Dokumentation, Meetingreduktion, Alignment',
    description:
      'Praktische Methoden, um Asynchronität effektiv zu nutzen und Kommunikation klar zu dokumentieren.'
  },
  {
    name: 'Cross-Cultural Collaboration',
    duration: '5 Wochen',
    focus: 'Interkulturelle Kommunikation, Empathie, Sprache',
    description:
      'Werkzeuge und Reflexionen, um globale Teams inklusiv, respektvoll und produktiv zu führen.'
  }
];

const microSessions = [
  {
    title: 'Deep Work im Remote-Alltag',
    format: 'Live-Session 60 Minuten',
    description: 'Impulse, Übungen und Q&A rund um Fokus und Energiehaushalt.'
  },
  {
    title: 'Visuelles Storytelling für Remote-Updates',
    format: 'On-Demand Toolkit',
    description: 'Templates und Beispiele für prägnante Statusmeldungen.'
  },
  {
    title: 'Mentoring mit klaren Zielen',
    format: 'Workshop-Serie',
    description: 'Strukturierte Mentoring-Rahmen für individuelle Entwicklung.'
  }
];

function Lernen() {
  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className="container">
          <h1>Lernen mit Fokus auf Remote-Kompetenzen</h1>
          <p>
            Vexoralia Lernpfade verbinden Theorie, Praxis und Peer-Feedback. Teams wählen Module, die
            zu ihren aktuellen Herausforderungen passen.
          </p>
        </div>
      </section>

      <section className={styles.tracks} aria-label="Lernpfade">
        <div className="container">
          <h2>Lernpfade</h2>
          <div className={styles.trackGrid}>
            {learningTracks.map((track) => (
              <article key={track.name} className={styles.trackCard}>
                <h3>{track.name}</h3>
                <p>{track.description}</p>
                <div className={styles.trackMeta}>
                  <span>Dauer: {track.duration}</span>
                  <span>Schwerpunkt: {track.focus}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sessions} aria-label="Micro Sessions">
        <div className="container">
          <h2>Micro Sessions & Labs</h2>
          <div className={styles.sessionGrid}>
            {microSessions.map((session) => (
              <article key={session.title}>
                <h3>{session.title}</h3>
                <span>{session.format}</span>
                <p>{session.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default Lernen;