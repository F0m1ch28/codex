import React from 'react';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Datenschutz</h1>
        <p>
          Der Schutz Ihrer Daten hat für Vexoralia höchste Priorität. Diese Erklärung erläutert, wie
          wir personenbezogene Daten verarbeiten.
        </p>

        <h2>1. Verantwortliche Stelle</h2>
        <p>Vexoralia – Kontakt: hello@vexoralia.de</p>

        <h2>2. Verarbeitete Daten</h2>
        <p>
          Wir verarbeiten Kontaktdaten, Profildaten, Inhalte in Workspaces und Nutzungsdaten. Die
          Verarbeitung erfolgt zur Bereitstellung unserer Dienste sowie zur Kommunikation mit Ihnen.
        </p>

        <h2>3. Rechtsgrundlagen</h2>
        <p>
          Die Verarbeitung basiert auf Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung) sowie Art. 6
          Abs. 1 lit. f DSGVO (berechtigtes Interesse). Für Marketingaktivitäten holen wir
          gegebenenfalls eine Einwilligung ein.
        </p>

        <h2>4. Auftragsverarbeitung & Dritte</h2>
        <p>
          Wir arbeiten mit Dienstleistern zusammen, die vertraglich zur Vertraulichkeit verpflichtet
          sind. Eine Übermittlung in Drittstaaten erfolgt nur bei geeigneten Garantien.
        </p>

        <h2>5. Speicherdauer</h2>
        <p>
          Daten werden gelöscht, wenn der Zweck entfällt oder gesetzliche Aufbewahrungspflichten
          erfüllt sind. Workspace-Daten können auf Wunsch exportiert oder entfernt werden.
        </p>

        <h2>6. Ihre Rechte</h2>
        <p>
          Sie haben das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung,
          Datenübertragbarkeit und Widerspruch. Kontaktieren Sie uns unter hello@vexoralia.de.
        </p>

        <h2>7. Sicherheit</h2>
        <p>
          Wir setzen technische und organisatorische Maßnahmen ein, um Daten vor Verlust, Veränderung
          oder unbefugtem Zugriff zu schützen.
        </p>
      </div>
    </div>
  );
}

export default Privacy;