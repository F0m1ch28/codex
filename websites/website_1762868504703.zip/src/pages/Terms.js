import React from 'react';
import styles from './Terms.module.css';

function Terms() {
  return (
    <div className={styles.page}>
      <div className="container">
        <h1>Nutzungsbedingungen</h1>
        <p>
          Diese Nutzungsbedingungen regeln die Verwendung der Plattform Vexoralia. Mit dem Zugriff
          auf unsere Dienste erklären Sie sich mit den nachstehenden Bedingungen einverstanden.
        </p>

        <h2>1. Geltungsbereich</h2>
        <p>
          Die Plattform richtet sich an Unternehmen und Fachkräfte, die Remote-Arbeit organisieren.
          Abweichende Bedingungen gelten nur, wenn sie schriftlich bestätigt wurden.
        </p>

        <h2>2. Kontoerstellung</h2>
        <p>
          Für die Nutzung ist ein persönliches Konto erforderlich. Alle Angaben müssen korrekt,
          aktuell und vollständig sein. Zugänge dürfen nicht an Dritte weitergegeben werden.
        </p>

        <h2>3. Nutzung der Plattform</h2>
        <p>
          Sie verpflichten sich, alle Inhalte verantwortungsvoll zu nutzen. Verboten sind
          Veröffentlichungen, die geltendes Recht oder Rechte Dritter verletzen. Wir behalten uns vor,
          Inhalte zu sperren, die gegen Richtlinien verstoßen.
        </p>

        <h2>4. Geistiges Eigentum</h2>
        <p>
          Sämtliche Inhalte der Plattform sind urheberrechtlich geschützt. Eine Verwendung über den
          eigenen Organisationszweck hinaus erfordert unsere Zustimmung.
        </p>

        <h2>5. Haftung</h2>
        <p>
          Wir stellen die Plattform mit größtmöglicher Sorgfalt bereit, übernehmen jedoch keine
          Verantwortung für Inhalte oder Handlungen von Nutzerinnen und Nutzern. Wir haften nur für
          Vorsatz und grobe Fahrlässigkeit.
        </p>

        <h2>6. Änderungen</h2>
        <p>
          Wir können diese Bedingungen anpassen, um rechtliche Anforderungen oder Funktionsänderungen
          abzubilden. Über relevante Anpassungen informieren wir Sie rechtzeitig.
        </p>

        <h2>7. Schlussbestimmungen</h2>
        <p>
          Sollten einzelne Bestimmungen unwirksam sein, bleibt die Wirksamkeit der übrigen Klauseln
          unberührt. Es gilt deutsches Recht.
        </p>
      </div>
    </div>
  );
}

export default Terms;