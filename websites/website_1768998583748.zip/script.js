document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            siteNav.classList.toggle('open');
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
        });
        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('open')) {
                    siteNav.classList.remove('open');
                    navToggle.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
        const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
        const decision = localStorage.getItem('maplenetxCookieConsent');
        if (!decision) {
            cookieBanner.classList.add('active');
        }
        const handleDecision = (value) => {
            localStorage.setItem('maplenetxCookieConsent', value);
            cookieBanner.classList.remove('active');
        };
        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleDecision('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleDecision('declined'));
        }
    }

    const path = window.location.pathname.replace(/^\//, '').toLowerCase();
    const redirects = {
        'history': 'atlas.html',
        'history.html': 'atlas.html',
        'network-history': 'atlas.html',
        'ix': 'exchange-points.html',
        'ix.html': 'exchange-points.html'
    };
    if (redirects[path]) {
        window.location.replace(redirects[path]);
    }
});