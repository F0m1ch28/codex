document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navigation = document.querySelector('.main-navigation');
    const navLinks = document.querySelectorAll('.nav-links a');
    const scrollBtn = document.querySelector('.scroll-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAcceptBtn = document.getElementById('cookieAccept');
    const currentYearSpan = document.querySelector('.current-year');

    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
    window.scrollTo(0, 0);

    if (menuToggle && navigation) {
        menuToggle.addEventListener('click', () => {
            const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', String(!isExpanded));
            navigation.classList.toggle('open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (navigation.classList.contains('open')) {
                    navigation.classList.remove('open');
                    menuToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollBtn.classList.add('visible');
            } else {
                scrollBtn.classList.remove('visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAcceptBtn) {
        const storageKey = 'tnCookieAccepted';
        if (localStorage.getItem(storageKey) === 'true') {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.add('active');
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem(storageKey, 'true');
            cookieBanner.classList.add('hidden');
        });
    }

    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }
});