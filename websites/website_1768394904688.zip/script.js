document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.getElementById("site-navigation");
    const navLinks = siteNav ? siteNav.querySelectorAll(".nav-link") : [];

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = siteNav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", String(isOpen));
            document.body.classList.toggle("nav-open", isOpen);
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("is-open")) {
                    siteNav.classList.remove("is-open");
                    document.body.classList.remove("nav-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-action");
    const storedConsent = localStorage.getItem("spkCookieConsent");

    if (cookieBanner && !storedConsent) {
        setTimeout(() => {
            cookieBanner.classList.add("is-visible");
        }, 500);
    }

    if (cookieBanner && cookieButtons.length) {
        cookieButtons.forEach((button) => {
            button.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = button.dataset.choice || "dismissed";
                localStorage.setItem("spkCookieConsent", choice);
                cookieBanner.classList.remove("is-visible");
                const target = button.getAttribute("href");
                if (target) {
                    window.location.href = target;
                }
            });
        });
    }
});