document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');
  const navLinks = document.querySelectorAll('.main-nav a');
  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      mainNav.classList.toggle('is-open');
    });
    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 1024) {
          mainNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.18 }
  );
  document.querySelectorAll('.animate-on-scroll').forEach((el) => {
    observer.observe(el);
  });

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = banner ? banner.querySelector('[data-cookie-accept]') : null;
  const declineBtn = banner ? banner.querySelector('[data-cookie-decline]') : null;
  const consentKey = 'livnotigCookieConsent';
  const storedConsent = localStorage.getItem(consentKey);

  const hideBanner = () => {
    if (banner) {
      banner.classList.remove('is-visible');
      setTimeout(() => {
        banner.style.display = 'none';
      }, 300);
    }
  };

  if (!storedConsent && banner) {
    banner.style.display = 'block';
    requestAnimationFrame(() => banner.classList.add('is-visible'));
  }

  const storeConsent = (value) => {
    localStorage.setItem(consentKey, value);
    hideBanner();
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => storeConsent('accepted'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => storeConsent('declined'));
  }

  const forms = document.querySelectorAll('form[data-form="redirect"]');
  const showToast = (message) => {
    let toast = document.querySelector('.form-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'form-toast';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'polite');
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 2250);
  };

  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Your message has been noted. Redirecting...');
      const redirectTarget = form.getAttribute('action') || 'thank-you.html';
      setTimeout(() => {
        window.location.href = redirectTarget;
      }, 1600);
    });
  });

  const currentYearSpan = document.querySelectorAll('#currentYear');
  const year = new Date().getFullYear();
  currentYearSpan.forEach((span) => {
    if (span.textContent !== String(year)) {
      span.textContent = String(year);
    }
  });
});