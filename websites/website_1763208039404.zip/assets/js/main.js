document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  const scrollTopBtn = document.getElementById("scrollTop");
  const contactForm = document.getElementById("contactForm");
  const formMessage = document.getElementById("formMessage");
  const cookieBanner = document.getElementById("cookieBanner");
  const acceptCookiesBtn = document.getElementById("acceptCookies");
  const currentYearEl = document.getElementById("currentYear");

  // Set current year
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  // Mobile navigation toggle
  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("is-open");
      document.body.classList.toggle("nav-open");
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (primaryNav.classList.contains("is-open")) {
          navToggle.setAttribute("aria-expanded", "false");
          primaryNav.classList.remove("is-open");
          document.body.classList.remove("nav-open");
        }
      });
    });
  }

  // Smooth scroll for on-page links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (event) {
      const targetId = this.getAttribute("href");
      if (targetId && targetId.length > 1) {
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
          event.preventDefault();
          targetElement.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }
    });
  });

  // Scroll to top button
  const toggleScrollTop = () => {
    if (window.scrollY > 300) {
      scrollTopBtn?.classList.add("show");
    } else {
      scrollTopBtn?.classList.remove("show");
    }
  };

  window.addEventListener("scroll", toggleScrollTop);
  toggleScrollTop();

  scrollTopBtn?.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  // Contact form handling
  if (contactForm && formMessage) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const fullName = formData.get("fullName")?.toString().trim();
      const email = formData.get("email")?.toString().trim();
      const message = formData.get("message")?.toString().trim();

      if (!fullName || !email || !message) {
        formMessage.textContent = "Please complete the required fields before submitting.";
        formMessage.style.color = "#B00020";
        return;
      }

      // Simulate submission success
      formMessage.textContent = "Thank you. Our advisory team will reach out shortly.";
      formMessage.style.color = "#1F4E79";
      contactForm.reset();
    });
  }

  // Cookie banner handling
  const cookieStorageKey = "ntaCookieConsent";

  const showCookieBanner = () => {
    cookieBanner?.classList.add("show");
  };

  const hideCookieBanner = () => {
    cookieBanner?.classList.remove("show");
  };

  if (!localStorage.getItem(cookieStorageKey)) {
    showCookieBanner();
  }

  acceptCookiesBtn?.addEventListener("click", () => {
    localStorage.setItem(cookieStorageKey, "accepted");
    hideCookieBanner();
  });
});