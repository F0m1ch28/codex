document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('primary-navigation');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navToggle.classList.toggle('is-active');
            navMenu.classList.toggle('is-open');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    navMenu.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const storedConsent = localStorage.getItem('trailbxixkCookieConsent');

    if (cookieBanner && !storedConsent) {
        requestAnimationFrame(() => {
            cookieBanner.classList.add('show');
        });
    }

    const cookieButtons = document.querySelectorAll('[data-cookie-action]');
    if (cookieButtons.length) {
        cookieButtons.forEach(button => {
            button.addEventListener('click', () => {
                const action = button.getAttribute('data-cookie-action') || 'dismissed';
                localStorage.setItem('trailbxixkCookieConsent', action);
            });
        });
    }
});