document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            document.body.classList.toggle('nav-open');
        });
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 880 && document.body.classList.contains('nav-open')) {
                    document.body.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('restriszvt_cookie_consent');
        if (storedConsent) {
            cookieBanner.classList.add('is-hidden');
        } else {
            cookieBanner.classList.add('is-visible');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-actions a');
        cookieButtons.forEach(button => {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const choice = this.dataset.choice || 'viewed';
                localStorage.setItem('restriszvt_cookie_consent', choice);
                cookieBanner.classList.remove('is-visible');
                cookieBanner.classList.add('is-hidden');
                const target = this.getAttribute('href');
                if (target) {
                    window.location.href = target;
                }
            });
        });
    }
});