import React from "react";

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container">
          <h1>Terms &amp; Conditions</h1>
          <p>Updated January 1, 2024</p>
        </div>
      </section>
      <section className="page-section legal-content">
        <div className="container">
          <h2>1. Agreement</h2>
          <p>
            By accessing or using ForwardEdge Consulting’s services, you agree to be bound by these Terms &amp; Conditions.
            If you do not agree, please discontinue use of our services immediately.
          </p>
          <h2>2. Services</h2>
          <p>
            ForwardEdge Consulting provides strategic advisory, design, and engineering services.
            All engagements are governed by the statements of work and master service agreements executed with clients.
          </p>
          <h2>3. Intellectual Property</h2>
          <p>
            Unless otherwise stated, ForwardEdge Consulting retains ownership of methodologies, frameworks,
            and intellectual property developed prior to or outside of the engagement. Client-owned assets remain the property of the client.
          </p>
          <h2>4. Confidentiality</h2>
          <p>
            Both parties agree to maintain confidentiality of non-public information shared during the engagement,
            except when required by law or authorized in writing.
          </p>
          <h2>5. Liability</h2>
          <p>
            ForwardEdge Consulting is not liable for indirect, incidental, or consequential damages
            arising from the use of our services. Our total liability is limited to fees paid in the twelve months preceding the claim.
          </p>
          <h2>6. Governing Law</h2>
          <p>
            These Terms are governed by the laws of the State of New York, without regard to conflict of law principles.
          </p>
          <h2>7. Updates</h2>
          <p>
            We may update these Terms from time to time. Continued use of our services constitutes acceptance of the revised Terms.
          </p>
          <p>
            For questions, contact <a href="mailto:legal@forwardedge.com">legal@forwardedge.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;