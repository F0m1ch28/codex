import React from "react";

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container">
          <h1>We unite strategy, design, and technology to drive enduring growth.</h1>
          <p>
            ForwardEdge Consulting was founded to help visionary organizations turn ambitious ideas
            into transformative realities faster than ever before.
          </p>
        </div>
      </section>

      <section className="page-section">
        <div className="container about-grid">
          <div>
            <h2>Our Purpose</h2>
            <p>
              We believe every customer interaction is a chance to earn trust. Our purpose is to help brands craft
              these moments with precision, empathy, and measurable impact. From market discovery through scale,
              we deliver holistic programs that create momentum and resilience.
            </p>
            <p>
              By embedding directly with your teams, we transfer knowledge, modernize capabilities, and ensure that our
              partnership leaves a lasting legacy of innovation.
            </p>
          </div>
          <div className="about-visual">
            <img
              src="https://picsum.photos/800/600?random=202"
              alt="ForwardEdge consultants collaborating around strategy boards"
            />
          </div>
        </div>
      </section>

      <section className="page-section values">
        <div className="container">
          <h2>Values that lead every decision</h2>
          <div className="values-grid">
            <div className="value-card">
              <h3>Outcome Obsession</h3>
              <p>
                Everything we build is tied to a measurable business objective—because results matter more than outputs.
              </p>
            </div>
            <div className="value-card">
              <h3>Radical Clarity</h3>
              <p>
                We foster transparency, shared context, and decisiveness, enabling teams to move confidently together.
              </p>
            </div>
            <div className="value-card">
              <h3>Inclusive Innovation</h3>
              <p>
                Diverse viewpoints unlock breakthrough ideas. We ensure voices are heard and converted into action.
              </p>
            </div>
            <div className="value-card">
              <h3>Relentless Improvement</h3>
              <p>
                Continuous learning and iteration keep our clients at the forefront of market shifts and customer needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section timeline">
        <div className="container">
          <h2>Milestones along our journey</h2>
          <div className="timeline-list">
            <div className="timeline-item">
              <span className="timeline-year">2016</span>
              <p>ForwardEdge is founded with the mission to modernize enterprise customer experiences.</p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2018</span>
              <p>Launches Accelerator Lab, a rapid prototyping program for emerging ventures.</p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2020</span>
              <p>Expands globally, partnering with clients across North America, Europe, and APAC.</p>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2023</span>
              <p>Recognized as a top consultancy for digital transformation by StratEdge Research.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section">
        <div className="container">
          <div className="cta-inline">
            <div>
              <h2>Join forces with a team built for impact.</h2>
              <p>
                Whether you need a strategic sparring partner or a full-scale delivery team, ForwardEdge brings
                the focus and expertise to make your next milestone inevitable.
              </p>
            </div>
            <a className="btn btn--primary" href="/contact">
              Partner with us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;