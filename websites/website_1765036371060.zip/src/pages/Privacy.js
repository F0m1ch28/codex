import React from "react";

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Updated January 1, 2024</p>
        </div>
      </section>
      <section className="page-section legal-content">
        <div className="container">
          <h2>Overview</h2>
          <p>
            ForwardEdge Consulting values your privacy. This policy explains what information we collect,
            how we use it, and the choices you have about that information.
          </p>
          <h2>Information We Collect</h2>
          <p>
            We collect information you provide directly, such as name, email, phone number, and company details
            when you contact us or subscribe to communications. We may also collect analytics data about site usage.
          </p>
          <h2>How We Use Information</h2>
          <ul>
            <li>To respond to inquiries and deliver requested services</li>
            <li>To improve our website, offerings, and communication</li>
            <li>To comply with legal obligations and enforce agreements</li>
          </ul>
          <h2>Cookies</h2>
          <p>
            We use cookies to enhance site performance and analyze traffic. You can control cookies through your browser settings.
          </p>
          <h2>Data Sharing</h2>
          <p>
            We do not sell or rent personal information. We may share data with trusted providers who assist in delivering our services,
            subject to confidentiality and security obligations.
          </p>
          <h2>Your Rights</h2>
          <p>
            You may request access, correction, or deletion of your personal data by contacting{" "}
            <a href="mailto:privacy@forwardedge.com">privacy@forwardedge.com</a>.
          </p>
          <h2>Security</h2>
          <p>
            We implement safeguards to protect personal information, but no system is completely secure.
            We encourage you to take appropriate precautions to protect your data.
          </p>
          <h2>Contact</h2>
          <p>
            Questions about this policy can be directed to{" "}
            <a href="mailto:privacy@forwardedge.com">privacy@forwardedge.com</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;