import React, { useState } from "react";

const Contact = () => {
  const initialState = { name: "", email: "", company: "", message: "" };
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your full name.";
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email address.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!formData.company.trim()) newErrors.company = "Company name is required.";
    if (!formData.message.trim()) newErrors.message = "Tell us about your project or question.";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    setFormData(initialState);
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container">
          <h1>Let’s accelerate your next big leap.</h1>
          <p>
            Share your goals and we’ll tailor a partnership that meets you where you are—then takes you where you want to go.
          </p>
        </div>
      </section>

      <section className="page-section contact-grid">
        <div className="container">
          <div className="contact-details">
            <h2>Talk with us</h2>
            <p>
              Email{" "}
              <a href="mailto:hello@forwardedge.com">
                hello@forwardedge.com
              </a>{" "}
              or call{" "}
              <a href="tel:+1234567890">
                +1 (234) 567-890
              </a>. We’ll respond within one business day.
            </p>
            <div className="contact-card">
              <h3>Visit our studio</h3>
              <p>
                ForwardEdge Consulting<br />
                745 Innovation Drive<br />
                New York, NY 10001
              </p>
              <p>By appointment only.</p>
            </div>
            <div className="contact-card">
              <h3>Connect online</h3>
              <p>
                Follow along for insights and updates on LinkedIn, Twitter, and Dribbble.
              </p>
            </div>
          </div>
          <div className="contact-form-wrapper">
            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label htmlFor="name">Full name</label>
                <input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter your full name"
                />
                {errors.name && <span className="error">{errors.name}</span>}
              </div>
              <div className="form-group">
                <label htmlFor="email">Work email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="name@company.com"
                />
                {errors.email && <span className="error">{errors.email}</span>}
              </div>
              <div className="form-group">
                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Company or organization"
                />
                {errors.company && <span className="error">{errors.company}</span>}
              </div>
              <div className="form-group">
                <label htmlFor="message">How can we help?</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Share your priorities, timeline, and success metrics."
                />
                {errors.message && <span className="error">{errors.message}</span>}
              </div>
              <button className="btn btn--primary btn--large" type="submit">
                Submit Inquiry
              </button>
              {submitted && (
                <div className="success-message">
                  Thank you! Your inquiry has been received. Our team will be in touch shortly.
                </div>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;