import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

const statsConfig = [
  { label: "Projects Delivered", value: 168 },
  { label: "Client Satisfaction", value: 98, suffix: "%" },
  { label: "Growth Unlocked", value: 23, suffix: "x" },
  { label: "Countries Served", value: 12 },
];

const servicesData = [
  {
    title: "Digital Strategy",
    description: "Actionable roadmaps aligned with measurable business outcomes.",
    icon: "🧭",
  },
  {
    title: "Product Innovation",
    description: "Human-centered solutions from ideation through launch and scaling.",
    icon: "💡",
  },
  {
    title: "Experience Design",
    description: "Immersive experiences that delight users and strengthen loyalty.",
    icon: "🎨",
  },
  {
    title: "Engineering Enablement",
    description: "Robust architectures and agile delivery to future-proof platforms.",
    icon: "🛠️",
  },
];

const processSteps = [
  { title: "Discover", copy: "Collaborative workshops uncover opportunities and align vision." },
  { title: "Design", copy: "Intuitive prototypes validated by insights and rapid iteration." },
  { title: "Build", copy: "Modern engineering practices deliver reliable, scalable products." },
  { title: "Launch", copy: "Orchestrated rollouts and training ensure confident adoption." },
  { title: "Optimize", copy: "Continuous measurement and experimentation maximize ROI." },
];

const testimonials = [
  {
    quote:
      "ForwardEdge transformed the way we bring products to market. Their team became an extension of ours overnight.",
    name: "Samantha Lee",
    role: "Chief Product Officer, Horizon Labs",
  },
  {
    quote:
      "They helped us define a bold roadmap and execute flawlessly. We hit our KPIs two quarters ahead of schedule.",
    name: "Jordan Patel",
    role: "VP of Growth, Altitude Ventures",
  },
  {
    quote:
      "From strategy through delivery, ForwardEdge delivered excellence. Our customer NPS climbed by 34 points.",
    name: "Michael Torres",
    role: "CEO, Vertex Retail Group",
  },
];

const team = [
  {
    name: "Avery Hopkins",
    role: "Managing Partner",
    image: "https://picsum.photos/400/400?random=301",
    bio: "Strategist with two decades of experience scaling digital ecosystems for Fortune 500 companies.",
  },
  {
    name: "Noah Harrington",
    role: "Head of Product",
    image: "https://picsum.photos/400/400?random=302",
    bio: "Product leader focused on human-centered innovation and evidence-based decision making.",
  },
  {
    name: "Emilia Jennings",
    role: "Director of Experience",
    image: "https://picsum.photos/400/400?random=303",
    bio: "Design visionary crafting memorable customer journeys across channels and markets.",
  },
  {
    name: "Kai Bennett",
    role: "Engineering Principal",
    image: "https://picsum.photos/400/400?random=304",
    bio: "Architect of resilient platforms with deep expertise in cloud-native and data-driven solutions.",
  },
];

const allProjects = [
  {
    title: "Intelligent Commerce Platform",
    category: "Development",
    image: "https://picsum.photos/1200/800?random=401",
  },
  {
    title: "Immersive Brand Experience",
    category: "Design",
    image: "https://picsum.photos/1200/800?random=402",
  },
  {
    title: "Global Expansion Blueprint",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=403",
  },
  {
    title: "AI-Powered Insights Hub",
    category: "Development",
    image: "https://picsum.photos/1200/800?random=404",
  },
  {
    title: "Omnichannel CX Redesign",
    category: "Design",
    image: "https://picsum.photos/1200/800?random=405",
  },
  {
    title: "Innovation Operating Model",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=406",
  },
];

const faqItems = [
  {
    question: "How quickly can you begin a new engagement?",
    answer:
      "We typically kick off new engagements within two weeks. A rapid discovery sprint aligns stakeholders and defines milestones before execution.",
  },
  {
    question: "Do you work with in-house teams?",
    answer:
      "Absolutely. We partner with internal teams to accelerate delivery, upskill talent, and implement sustainable ways of working.",
  },
  {
    question: "Can you help with scaling after launch?",
    answer:
      "Yes. Our growth programs include performance monitoring, experimentation frameworks, and continuous optimization.",
  },
  {
    question: "What industries do you specialize in?",
    answer:
      "We work across technology, retail, healthcare, finance, and emerging industries, tailoring strategies to each sector’s dynamics.",
  },
];

const blogPosts = [
  {
    title: "Designing Adaptive Experiences for the Hybrid Customer",
    date: "January 8, 2024",
    excerpt:
      "We explore a framework for harmonizing physical and digital touchpoints while keeping empathy at the core.",
  },
  {
    title: "Beyond Dashboards: Building an Insight Culture",
    date: "December 20, 2023",
    excerpt:
      "Leaders are moving from passive reporting to proactive decision intelligence—here’s how to make the shift.",
  },
  {
    title: "Unlocking Innovation with Product Ops",
    date: "November 29, 2023",
    excerpt:
      "Learn how product operations creates clarity, alignment, and momentum in fast-paced organizations.",
  },
];

const StatsSection = () => {
  const [counts, setCounts] = useState(statsConfig.map(() => 0));
  const sectionRef = useRef(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const node = sectionRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          const duration = 1800;
          const start = performance.now();

          const tick = (now) => {
            const progress = Math.min((now - start) / duration, 1);
            const newCounts = statsConfig.map((stat) =>
              Math.round(stat.value * progress)
            );
            setCounts(newCounts);
            if (progress < 1) {
              requestAnimationFrame(tick);
            }
          };

          requestAnimationFrame(tick);
        }
      },
      { threshold: 0.5 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <section className="stats" ref={sectionRef}>
      <div className="container stats-grid">
        {statsConfig.map((stat, index) => (
          <div key={stat.label} className="stat-card">
            <span className="stat-value">
              {counts[index]}
              {stat.suffix || ""}
            </span>
            <span className="stat-label">{stat.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
};

const TestimonialsSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const testimonial = testimonials[currentIndex];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="testimonials" aria-live="polite">
      <div className="container testimonials-grid">
        <div className="testimonial-card">
          <p className="testimonial-quote">“{testimonial.quote}”</p>
          <div className="testimonial-meta">
            <p className="testimonial-name">{testimonial.name}</p>
            <span className="testimonial-role">{testimonial.role}</span>
          </div>
        </div>
        <div className="testimonial-controls">
          {testimonials.map((item, idx) => (
            <button
              key={item.name}
              className={`testimonial-dot ${idx === currentIndex ? "active" : ""}`}
              onClick={() => setCurrentIndex(idx)}
              aria-label={`Show testimonial from ${item.name}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

const ProjectsSection = () => {
  const [filter, setFilter] = useState("All");
  const filters = useMemo(
    () => ["All", "Strategy", "Design", "Development"],
    []
  );

  const filteredProjects =
    filter === "All"
      ? allProjects
      : allProjects.filter((project) => project.category === filter);

  return (
    <section className="projects" id="projects">
      <div className="container projects-container">
        <div className="section-heading">
          <h2>Selected Projects</h2>
          <p>
            A snapshot of the partnerships where strategy, creativity, and technology intersect.
          </p>
        </div>
        <div className="projects-filters" role="tablist">
          {filters.map((option) => (
            <button
              key={option}
              className={`filter-chip ${filter === option ? "active" : ""}`}
              onClick={() => setFilter(option)}
              role="tab"
              aria-selected={filter === option}
            >
              {option}
            </button>
          ))}
        </div>
        <div className="projects-grid">
          {filteredProjects.map((project) => (
            <article className="project-card" key={project.title}>
              <div className="project-image">
                <img
                  src={project.image}
                  alt={`${project.title} case study visual`}
                  loading="lazy"
                />
              </div>
              <div className="project-content">
                <span className="project-category">{project.category}</span>
                <h3>{project.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

const Home = () => {
  const [expandedFaq, setExpandedFaq] = useState(null);

  return (
    <div className="home">
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="hero-kicker">Strategy · Design · Engineering</span>
            <h1>
              Build the future
              <span className="gradient-text"> your customers deserve.</span>
            </h1>
            <p>
              ForwardEdge Consulting helps ambitious teams accelerate growth,
              modernize operations, and deliver experiences that earn loyalty with every touchpoint.
            </p>
            <div className="hero-actions">
              <Link className="btn btn--primary" to="/contact">
                Start a Project
              </Link>
              <Link className="btn btn--ghost" to="/services">
                View Services
              </Link>
            </div>
            <div className="hero-meta">
              <span className="meta-item">Trusted by leaders in 12 countries</span>
              <span className="meta-item">Proven frameworks for sustainable growth</span>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-image-wrapper">
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Business team strategizing with digital dashboards"
              />
            </div>
            <div className="hero-badge">
              <span className="badge-title">Top 1% Consultancy</span>
              <span className="badge-text">Awarded 2023</span>
            </div>
          </div>
        </div>
      </section>

      <StatsSection />

      <section className="services" id="services">
        <div className="container services-container">
          <div className="section-heading">
            <h2>Services engineered to outperform expectations</h2>
            <p>
              We combine strategic clarity, design excellence, and technical rigor to help you build what’s next.
            </p>
          </div>
          <div className="services-grid">
            {servicesData.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="service-icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className="service-link">
                  Learn more <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process" id="process">
        <div className="container process-container">
          <div className="section-heading">
            <h2>A transparent journey from insight to impact</h2>
            <p>
              Our proven delivery framework keeps teams aligned and outcomes on track at every milestone.
            </p>
          </div>
          <div className="process-steps">
            {processSteps.map((step, index) => (
              <div className="process-step" key={step.title}>
                <span className="step-index">{index + 1}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.copy}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <TestimonialsSection />

      <section className="team" id="team">
        <div className="container">
          <div className="section-heading">
            <h2>Meet the leaders guiding every engagement</h2>
            <p>
              Our multidisciplinary team brings deep expertise, fearless curiosity, and a passion for delivering measurable value.
            </p>
          </div>
          <div className="team-grid">
            {team.map((member) => (
              <article className="team-card" key={member.name}>
                <div className="team-image">
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <ProjectsSection />

      <section className="insight-banner">
        <div className="container insight-content">
          <div>
            <h2>Insights for leaders shaping tomorrow</h2>
            <p>
              Download our 2024 State of Digital Transformation playbook to discover the trends defining next-generation experiences.
            </p>
          </div>
          <a className="btn btn--ghost" href="#blog">
            Get the Playbook
          </a>
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container">
          <div className="section-heading">
            <h2>Frequently Asked Questions</h2>
            <p>
              Answers to the questions we hear most from transformation leaders across industries.
            </p>
          </div>
          <div className="faq-accordion">
            {faqItems.map((item, idx) => {
              const isOpen = expandedFaq === idx;
              return (
                <div className={`faq-item ${isOpen ? "open" : ""}`} key={item.question}>
                  <button
                    className="faq-question"
                    onClick={() => setExpandedFaq(isOpen ? null : idx)}
                    aria-expanded={isOpen}
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true">{isOpen ? "−" : "+"}</span>
                  </button>
                  <div className="faq-answer">
                    <p>{item.answer}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="blog" id="blog">
        <div className="container">
          <div className="section-heading">
            <h2>Latest Insights</h2>
            <p>
              Fresh thinking on transformation, customer experience, and the future of work from our strategy team.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <div className="blog-date">{post.date}</div>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to="/about" className="blog-link">
                  Read story <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container cta-grid">
          <div>
            <h2>Let’s make your next bold move happen.</h2>
            <p>
              Schedule a conversation with our leadership team to explore how ForwardEdge can accelerate your roadmap this quarter.
            </p>
          </div>
          <Link className="btn btn--primary btn--large" to="/contact">
            Book a Strategy Session
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;