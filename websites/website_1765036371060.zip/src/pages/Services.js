import React, { useState } from "react";

const capabilities = [
  {
    category: "Strategy",
    services: [
      "Growth and commercialization roadmaps",
      "Operating model and governance design",
      "Customer journey mapping and opportunity sizing",
      "KPI frameworks and experimentation programs",
    ],
  },
  {
    category: "Design",
    services: [
      "Product and service design sprints",
      "Experience mapping and prototyping",
      "Content and brand systems",
      "Research and customer validation",
    ],
  },
  {
    category: "Technology",
    services: [
      "Modern application development",
      "Platform and systems integration",
      "Cloud and data engineering",
      "Quality automation and DevOps enablement",
    ],
  },
];

const serviceHighlights = [
  {
    title: "Transformation Blueprint",
    description:
      "A six-week program delivering a prioritized portfolio, tactical roadmap, and change strategy.",
    impact: "Accelerate alignment across leadership and execution teams.",
  },
  {
    title: "Product Delivery Pods",
    description:
      "Cross-functional squads embedded with your organization to design, build, and ship faster.",
    impact: "Scale delivery capacity while elevating your internal capabilities.",
  },
  {
    title: "Experience Refresh",
    description:
      "Rapid redesign focused on critical journeys, guided by insights and measurable outcomes.",
    impact: "Increase customer conversion and retention through cohesive experiences.",
  },
];

const Services = () => {
  const [activeCategory, setActiveCategory] = useState(capabilities[0].category);

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container">
          <h1>Navigate change with services designed to outperform.</h1>
          <p>
            From the C-suite to delivery teams, we equip leaders with clarity, speed, and the capabilities to unlock growth.
          </p>
        </div>
      </section>

      <section className="page-section services-tabs">
        <div className="container">
          <div className="tabs-nav" role="tablist">
            {capabilities.map((capability) => (
              <button
                key={capability.category}
                className={`tab ${capability.category === activeCategory ? "active" : ""}`}
                onClick={() => setActiveCategory(capability.category)}
                role="tab"
                aria-selected={capability.category === activeCategory}
              >
                {capability.category}
              </button>
            ))}
          </div>
          <div className="tabs-content">
            {capabilities.map(
              (capability) =>
                capability.category === activeCategory && (
                  <div className="tab-panel" key={capability.category} role="tabpanel">
                    <ul className="capability-list">
                      {capability.services.map((service) => (
                        <li key={service}>{service}</li>
                      ))}
                    </ul>
                  </div>
                )
            )}
          </div>
        </div>
      </section>

      <section className="page-section service-highlights">
        <div className="container">
          <h2>Signature programs for fast-moving teams</h2>
          <div className="highlight-grid">
            {serviceHighlights.map((item) => (
              <article className="highlight-card" key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <span className="highlight-impact">{item.impact}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="page-section service-proof">
        <div className="container proof-grid">
          <div>
            <h2>Why teams choose ForwardEdge</h2>
            <p>
              We blend the rigor of top-tier consultancy with the imagination of a design studio and the precision of a modern engineering organization. Each engagement is anchored in measurable outcomes and accelerated through collaborative delivery.
            </p>
            <p>
              Our clients see an average 34% increase in customer satisfaction and 2.3x faster time-to-market after partnering with us for a single quarter.
            </p>
          </div>
          <div className="proof-points">
            <div className="proof-card">
              <span className="proof-metric">+68%</span>
              <p>Average lift in digital revenue across transformation programs.</p>
            </div>
            <div className="proof-card">
              <span className="proof-metric">4.9/5</span>
              <p>Engagement satisfaction score from executive sponsors.</p>
            </div>
            <div className="proof-card">
              <span className="proof-metric">12 weeks</span>
              <p>Average time to deliver a validated product MVP ready for scaling.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section">
        <div className="container">
          <div className="cta-inline">
            <div>
              <h2>Build your roadmap with us.</h2>
              <p>We’ll assemble the right blend of strategy, design, and engineering talent to move your priorities forward.</p>
            </div>
            <a className="btn btn--primary" href="/contact">
              Schedule a consultation
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;