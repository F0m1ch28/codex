import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const accepted = window.localStorage.getItem("forwardedge-cookie-consent");
    if (!accepted) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("forwardedge-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="region" aria-label="Cookie consent">
      <div className="cookie-text">
        We use cookies to personalize content and analyze our traffic. By clicking
        “Accept”, you consent to our cookies in accordance with our{" "}
        <a href="/privacy">Privacy Policy</a>.
      </div>
      <button className="btn btn--primary" onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;