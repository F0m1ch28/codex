import React, { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
      <div className="container header-container">
        <NavLink to="/" className="header-logo" aria-label="ForwardEdge Consulting">
          <span className="logo-icon">⧉</span>
          <span className="logo-text">
            ForwardEdge <span>Consulting</span>
          </span>
        </NavLink>
        <nav className={`nav ${menuOpen ? "nav--open" : ""}`}>
          <NavLink end to="/" className="nav-link">
            Home
          </NavLink>
          <NavLink to="/about" className="nav-link">
            About
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact
          </NavLink>
          <NavLink to="/terms" className="nav-link">
            Terms
          </NavLink>
          <NavLink to="/privacy" className="nav-link">
            Privacy
          </NavLink>
        </nav>
        <button
          className={`menu-toggle ${menuOpen ? "menu-toggle--active" : ""}`}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;