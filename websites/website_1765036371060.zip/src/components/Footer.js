import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="footer-logo">
            <span className="logo-icon">⧉</span>
            ForwardEdge Consulting
          </div>
          <p>
            We partner with ambitious leaders to design, build, and launch solutions
            that accelerate growth and deliver measurable impact.
          </p>
        </div>
        <div className="footer-column">
          <h4>Explore</h4>
          <ul>
            <li>
              <NavLink to="/">Home</NavLink>
            </li>
            <li>
              <NavLink to="/about">About</NavLink>
            </li>
            <li>
              <NavLink to="/services">Services</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Contact</NavLink>
            </li>
          </ul>
        </div>
        <div className="footer-column">
          <h4>Resources</h4>
          <ul>
            <li>
              <NavLink to="/terms">Terms &amp; Conditions</NavLink>
            </li>
            <li>
              <NavLink to="/privacy">Privacy Policy</NavLink>
            </li>
            <li>
              <a href="#faq">FAQ</a>
            </li>
            <li>
              <a href="#blog">Insights</a>
            </li>
          </ul>
        </div>
        <div className="footer-column">
          <h4>Contact</h4>
          <ul>
            <li><a href="mailto:hello@forwardedge.com">hello@forwardedge.com</a></li>
            <li><a href="tel:+1234567890">+1 (234) 567-890</a></li>
            <li>745 Innovation Drive<br />New York, NY 10001</li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} ForwardEdge Consulting. All rights reserved.</p>
        <div className="footer-social">
          <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
          <a href="https://www.twitter.com" target="_blank" rel="noreferrer">Twitter</a>
          <a href="https://www.dribbble.com" target="_blank" rel="noreferrer">Dribbble</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;