document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            siteNav.classList.toggle("is-open");
            document.body.classList.toggle("nav-open");
        });

        siteNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 768) {
                    navToggle.setAttribute("aria-expanded", "false");
                    siteNav.classList.remove("is-open");
                    document.body.classList.remove("nav-open");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector("#cookie-accept");
    const declineBtn = document.querySelector("#cookie-decline");
    const cookieKey = "solidnizmkCookieChoice";

    if (cookieBanner) {
        const storedChoice = localStorage.getItem(cookieKey);
        if (!storedChoice) {
            cookieBanner.classList.remove("is-hidden");
        }

        const handleChoice = (choice) => {
            localStorage.setItem(cookieKey, choice);
            cookieBanner.classList.add("is-hidden");
        };

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => handleChoice("accepted"));
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => handleChoice("declined"));
        }
    }
});