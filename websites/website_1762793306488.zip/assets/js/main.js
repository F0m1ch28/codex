document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.site-nav');
  const navLinks = document.querySelectorAll('.nav-links a');
  const scrollTopBtn = document.querySelector('.scroll-top');
  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieAccept = document.querySelector('.cookie-accept');
  const cookieDecline = document.querySelector('.cookie-decline');
  const forms = document.querySelectorAll('.rl-form');
  const yearSpan = document.getElementById('year');

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navMenu.classList.toggle('open');
    });
  }

  if (navLinks) {
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (navMenu.classList.contains('open')) {
          navMenu.classList.remove('open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
        window.scrollTo({ top: 0, behavior: 'instant' });
      });
    });
  }

  if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
  }
  window.addEventListener('pageshow', () => window.scrollTo(0, 0));

  const toggleScrollTop = () => {
    if (!scrollTopBtn) return;
    if (window.scrollY > 320) {
      scrollTopBtn.classList.add('show');
    } else {
      scrollTopBtn.classList.remove('show');
    }
  };

  if (scrollTopBtn) {
    scrollTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  window.addEventListener('scroll', toggleScrollTop);
  toggleScrollTop();

  if (cookieBanner) {
    const consent = localStorage.getItem('rl_cookie_consent');
    if (consent) {
      cookieBanner.classList.add('hidden');
    }

    const setConsent = value => {
      localStorage.setItem('rl_cookie_consent', value);
      cookieBanner.classList.add('hidden');
    };

    if (cookieAccept) {
      cookieAccept.addEventListener('click', () => setConsent('accepted'));
    }
    if (cookieDecline) {
      cookieDecline.addEventListener('click', () => setConsent('declined'));
    }
  }

  if (forms) {
    forms.forEach(form => {
      const responseEl = form.querySelector('.form-response');
      form.addEventListener('submit', event => {
        event.preventDefault();
        if (responseEl) {
          responseEl.textContent = 'Thank you. Our advisors will reach out shortly.';
        }
        form.reset();
      });
    });
  }
});