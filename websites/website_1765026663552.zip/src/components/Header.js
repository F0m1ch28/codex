import React, { useEffect, useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    const handleResize = () => {
      if (window.innerWidth > 1024) {
        setIsMenuOpen(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', handleResize);
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const navLinkClass = ({ isActive }) =>
    isActive ? 'nav-link active' : 'nav-link';

  return (
    <header className={`site-header ${isScrolled ? 'scrolled' : ''}`}>
      <div className="container header-container">
        <Link to="/" className="logo" aria-label="Apex Dynamics Consulting home">
          <span className="logo-mark">A</span>
          <span className="logo-type">
            Apex Dynamics
            <span className="logo-subtitle">Consulting</span>
          </span>
        </Link>

        <div className="header-right">
          <nav className={`site-nav ${isMenuOpen ? 'open' : ''}`} aria-label="Primary">
            <NavLink to="/" end className={navLinkClass} onClick={closeMenu}>
              Home
            </NavLink>
            <NavLink to="/about" className={navLinkClass} onClick={closeMenu}>
              About
            </NavLink>
            <NavLink to="/services" className={navLinkClass} onClick={closeMenu}>
              Services
            </NavLink>
            <NavLink to="/contact" className={navLinkClass} onClick={closeMenu}>
              Contact
            </NavLink>
            <NavLink to="/privacy" className={navLinkClass} onClick={closeMenu}>
              Privacy
            </NavLink>
            <NavLink to="/terms" className={navLinkClass} onClick={closeMenu}>
              Terms
            </NavLink>
            <Link to="/contact" className="btn btn-nav" onClick={closeMenu}>
              Book a Consultation
            </Link>
          </nav>

          <button
            type="button"
            className={`nav-toggle ${isMenuOpen ? 'open' : ''}`}
            onClick={toggleMenu}
            aria-expanded={isMenuOpen}
            aria-label="Toggle navigation"
          >
            <span className="nav-toggle-bar" />
            <span className="nav-toggle-bar" />
            <span className="nav-toggle-bar" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;