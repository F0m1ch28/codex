import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="container footer-container">
        <div className="footer-column">
          <h3 className="footer-title">Apex Dynamics Consulting</h3>
          <p>
            Strategic growth partners delivering measurable outcomes through
            research-driven strategy, design excellence, and scalable technology.
          </p>
          <div className="footer-contact">
            <a href="tel:+18005551234">+1 (800) 555-1234</a>
            <a href="mailto:hello@apexdynamicsconsulting.com">
              hello@apexdynamicsconsulting.com
            </a>
          </div>
        </div>

        <div className="footer-column">
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/terms">Terms &amp; Conditions</Link>
            </li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Resources</h4>
          <ul>
            <li>
              <Link to="/">Case Studies</Link>
            </li>
            <li>
              <Link to="/services">Digital Transformation</Link>
            </li>
            <li>
              <Link to="/about">Leadership</Link>
            </li>
            <li>
              <Link to="/contact">Support</Link>
            </li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Newsletter</h4>
          <p>Stay ahead with monthly insights on strategy, design, and technology.</p>
          <form
            className="footer-newsletter"
            onSubmit={(event) => {
              event.preventDefault();
            }}
          >
            <label htmlFor="footer-email" className="sr-only">
              Email address
            </label>
            <input
              type="email"
              id="footer-email"
              name="email"
              placeholder="Email address"
              required
            />
            <button type="submit" className="btn btn-secondary">
              Subscribe
            </button>
          </form>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer">
              Twitter
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
              YouTube
            </a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>&copy; {currentYear} Apex Dynamics Consulting. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;