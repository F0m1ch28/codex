import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('apex-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('apex-cookie-consent', 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          We use cookies to personalize content, enhance your browsing experience, and analyze our traffic.
          Read our <Link to="/privacy">Privacy Policy</Link> for more information.
        </p>
        <button type="button" className="btn btn-primary" onClick={acceptCookies}>
          Accept &amp; Continue
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;