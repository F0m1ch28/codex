import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const contactHighlights = [
  {
    title: 'Global presence',
    detail: 'Strategists and delivery leads across North America and Europe for follow-the-sun support.',
  },
  {
    title: 'Senior team',
    detail: 'Every engagement is led by seasoned practitioners with enterprise transformation experience.',
  },
  {
    title: 'Tailored engagements',
    detail: 'From rapid discovery to multi-year transformations, we adapt to your operating model.',
  },
];

const contactMethods = [
  { label: 'Call us', value: '+1 (800) 555-1234', href: 'tel:+18005551234' },
  { label: 'Email', value: 'hello@apexdynamicsconsulting.com', href: 'mailto:hello@apexdynamicsconsulting.com' },
  { label: 'Visit', value: '245 5th Avenue, 18th Floor, New York, NY 10016', href: 'https://maps.google.com' },
];

const ImageWithLoader = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`image-loader ${loaded ? 'loaded' : ''} ${className || ''}`}>
      <img src={src} alt={alt} loading="lazy" onLoad={() => setLoaded(true)} />
    </div>
  );
};

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    const elements = document.querySelectorAll('.reveal');
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: '',
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your full name.';
    }
    if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Tell us a little about your initiative.';
    }
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);

    if (Object.keys(validation).length === 0) {
      setStatus('success');
      setFormData({
        name: '',
        email: '',
        company: '',
        message: '',
      });
    } else {
      setStatus('');
    }
  };

  return (
    <div className="contact-page">
      <section className="page-section reveal">
        <div className="container contact-grid">
          <div className="contact-intro">
            <h1>Let’s plan your next strategic move.</h1>
            <p>
              Share a few details about your initiative and our senior team will reach out within one business day.
            </p>
            <div className="contact-highlights">
              {contactHighlights.map((highlight) => (
                <div className="contact-highlight" key={highlight.title}>
                  <h3>{highlight.title}</h3>
                  <p>{highlight.detail}</p>
                </div>
              ))}
            </div>
            <div className="contact-methods">
              {contactMethods.map((method) => (
                <a key={method.label} href={method.href} className="contact-method">
                  <span className="contact-method-label">{method.label}</span>
                  <span className="contact-method-value">{method.value}</span>
                </a>
              ))}
            </div>
          </div>

          <div className="contact-form-wrapper">
            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label htmlFor="name">Full name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter your name"
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'name-error' : undefined}
                  required
                />
                {errors.name && (
                  <span id="name-error" className="error-text">
                    {errors.name}
                  </span>
                )}
              </div>

              <div className="form-group">
                <label htmlFor="email">Work email *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="name@company.com"
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  required
                />
                {errors.email && (
                  <span id="email-error" className="error-text">
                    {errors.email}
                  </span>
                )}
              </div>

              <div className="form-group">
                <label htmlFor="company">Company</label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Organization or team"
                />
              </div>

              <div className="form-group">
                <label htmlFor="message">How can we help? *</label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Describe your initiative, timeline, and goals."
                  rows="5"
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  required
                />
                {errors.message && (
                  <span id="message-error" className="error-text">
                    {errors.message}
                  </span>
                )}
              </div>

              <button type="submit" className="btn btn-primary">
                Submit inquiry
              </button>
              <p className="form-footnote">
                By submitting this form, you agree to our <Link to="/privacy">Privacy Policy</Link> and{' '}
                <Link to="/terms">Terms &amp; Conditions</Link>.
              </p>
              <div className="form-status" aria-live="polite">
                {status === 'success' && (
                  <span className="success-text">
                    Thank you! A member of our leadership team will connect with you shortly.
                  </span>
                )}
              </div>
            </form>
          </div>
        </div>
      </section>

      <section className="page-section reveal contact-insights">
        <div className="container insights-grid">
          <div className="insights-content">
            <h2>Prefer a collaborative working session?</h2>
            <p>
              We host strategy workshops tailored to your challenge—whether you’re exploring new markets, aligning teams,
              or shaping the next release. Let’s co-create a path forward.
            </p>
            <Link to="/services" className="btn btn-secondary">
              View workshop formats
            </Link>
          </div>
          <ImageWithLoader
            src="https://picsum.photos/900/650?random=701"
            alt="Collaborative strategy session around a conference table"
            className="contact-image"
          />
        </div>
      </section>

      <section className="page-section reveal contact-map">
        <div className="container">
          <h2>Our headquarters</h2>
          <p>
            245 5th Avenue, 18th Floor, New York, NY 10016 <br />
            We also have delivery teams in Toronto, Austin, London, and Berlin.
          </p>
          <ImageWithLoader
            src="https://picsum.photos/1200/500?random=702"
            alt="Map view of Apex Dynamics Consulting headquarters in New York"
            className="map-image"
          />
        </div>
      </section>
    </div>
  );
};

export default Contact;