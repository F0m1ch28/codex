import React from 'react';
import { Link } from 'react-router-dom';

const Terms = () => {
  return (
    <section className="page-section legal-section">
      <div className="container narrow">
        <h1>Terms &amp; Conditions</h1>
        <p className="lead">Last updated: October 1, 2024</p>

        <article className="legal-text">
          <h2>1. Agreement Overview</h2>
          <p>
            These Terms &amp; Conditions (&quot;Terms&quot;) govern your access to and use of the Apex Dynamics Consulting
            website and any related services (collectively, the &quot;Services&quot;). By accessing or using the Services
            you agree to be bound by these Terms and all applicable laws and regulations.
          </p>

          <h2>2. Use of Services</h2>
          <p>
            You may use the Services solely for lawful purposes and in accordance with these Terms. You agree not to:
          </p>
          <ul className="legal-list">
            <li>Misrepresent your identity or affiliation with any person or organization.</li>
            <li>Attempt to gain unauthorized access to any portion of the Services or related systems.</li>
            <li>
              Use the Services in any manner that could disable, overburden, or impair the proper working of the platform.
            </li>
          </ul>

          <h2>3. Intellectual Property</h2>
          <p>
            All content, trademarks, logos, and intellectual property appearing on the Services are the property of Apex
            Dynamics Consulting or its licensors. You may not use, reproduce, or distribute any content without our prior
            written consent.
          </p>

          <h2>4. Confidential Information</h2>
          <p>
            Any confidential information shared between you and Apex Dynamics Consulting during an engagement is subject
            to the confidentiality obligations outlined in the applicable statement of work or master services agreement.
          </p>

          <h2>5. Disclaimers &amp; Limitation of Liability</h2>
          <p>
            The Services are provided on an &quot;as-is&quot; and &quot;as-available&quot; basis. Apex Dynamics Consulting
            disclaims all warranties, express or implied, and shall not be liable for any indirect, incidental, or consequential
            damages arising out of or related to your use of the Services.
          </p>

          <h2>6. Governing Law</h2>
          <p>
            These Terms are governed by the laws of the State of New York, without regard to conflict of law provisions.
            Any disputes shall be resolved in the state or federal courts located in New York County, New York.
          </p>

          <h2>7. Changes to Terms</h2>
          <p>
            We may update these Terms from time to time. Changes will be posted on this page with an updated &quot;Last updated&quot;
            date. Your continued use of the Services constitutes acceptance of the revised Terms.
          </p>

          <h2>8. Contact</h2>
          <p>
            Questions about these Terms? <Link to="/contact">Contact our team</Link> or email{' '}
            <a href="mailto:legal@apexdynamicsconsulting.com">legal@apexdynamicsconsulting.com</a>.
          </p>
        </article>
      </div>
    </section>
  );
};

export default Terms;