import React from 'react';
import { Link } from 'react-router-dom';

const Privacy = () => {
  return (
    <section className="page-section legal-section">
      <div className="container narrow">
        <h1>Privacy Policy</h1>
        <p className="lead">Last updated: October 1, 2024</p>

        <article className="legal-text">
          <h2>1. Summary</h2>
          <p>
            Apex Dynamics Consulting (&quot;we&quot;, &quot;us&quot;, or &quot;our&quot;) is committed to protecting your privacy.
            This Privacy Policy describes how we collect, use, and protect information when you interact with our website or Services.
          </p>

          <h2>2. Information We Collect</h2>
          <ul className="legal-list">
            <li>
              <strong>Contact information:</strong> such as your name, email address, phone number, and company details submitted
              through forms or direct communication.
            </li>
            <li>
              <strong>Usage data:</strong> including analytics about how you interact with the website, captured via cookies and similar technologies.
            </li>
            <li>
              <strong>Engagement records:</strong> project documentation and correspondence associated with client engagements.
            </li>
          </ul>

          <h2>3. How We Use Information</h2>
          <p>We use collected information to:</p>
          <ul className="legal-list">
            <li>Respond to inquiries and provide requested services.</li>
            <li>Improve site functionality, user experience, and security.</li>
            <li>Communicate updates, insights, and marketing materials (with your consent).</li>
            <li>Fulfil contractual obligations and comply with legal requirements.</li>
          </ul>

          <h2>4. How We Share Information</h2>
          <p>
            We do not sell personal information. We may share information with trusted partners and service providers who support
            our operations, subject to confidentiality obligations. We may also disclose information when required by law.
          </p>

          <h2>5. Data Retention &amp; Security</h2>
          <p>
            Information is retained only as long as necessary to fulfill the purposes described in this Policy or as required by law.
            We implement administrative, technical, and physical safeguards to protect information from unauthorized access.
          </p>

          <h2>6. Your Rights</h2>
          <p>
            Depending on your jurisdiction, you may have rights to access, correct, or delete your personal data. To submit a request,
            please email <a href="mailto:privacy@apexdynamicsconsulting.com">privacy@apexdynamicsconsulting.com</a>. We will respond within
            applicable legal timeframes.
          </p>

          <h2>7. Cookies</h2>
          <p>
            We use cookies and similar technologies to enhance site performance and understand user behavior. You may adjust your browser
            settings to disable cookies; however, this may limit certain functionality.
          </p>

          <h2>8. International Transfers</h2>
          <p>
            If you access our Services from outside the United States, your information may be transferred to and processed in the United States.
            We apply appropriate safeguards to protect personal data in accordance with applicable laws.
          </p>

          <h2>9. Updates to this Policy</h2>
          <p>
            We may revise this Privacy Policy periodically. Updates will be posted on this page with the revised &quot;Last updated&quot; date.
            Your continued use of the Services signifies acceptance of any updates.
          </p>

          <h2>10. Contact</h2>
          <p>
            If you have questions about this Policy or our privacy practices, <Link to="/contact">contact us</Link> or email{' '}
            <a href="mailto:privacy@apexdynamicsconsulting.com">privacy@apexdynamicsconsulting.com</a>.
          </p>
        </article>
      </div>
    </section>
  );
};

export default Privacy;