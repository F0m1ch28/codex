import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const serviceDetails = [
  {
    title: 'Strategy & Advisory',
    summary:
      'Set a clear direction anchored in customer insight, market dynamics, and measurable outcomes.',
    outcomes: [
      'North-star experience vision aligned across leadership.',
      'Prioritized roadmap with quantified investment cases.',
      'Governance model enabling fast, evidence-based decisions.',
    ],
  },
  {
    title: 'Experience & Product Design',
    summary:
      'Translate strategy into intuitive service journeys and product experiences that delight customers.',
    outcomes: [
      'Service blueprints connecting front-stage and back-stage operations.',
      'Validated prototypes with ongoing customer feedback loops.',
      'Design systems and playbooks to scale consistent delivery.',
    ],
  },
  {
    title: 'Technology & Delivery',
    summary:
      'Build and scale resilient ecosystems with modern engineering practices and change enablement.',
    outcomes: [
      'Cloud-native architecture and integration strategies.',
      'Delivery squads aligned to value streams with transparent metrics.',
      'Capability uplift across product, engineering, and operations teams.',
    ],
  },
];

const capabilityGroups = [
  {
    heading: 'Research & Insights',
    items: [
      'Ethnographic research & diary studies',
      'Quantitative market sizing & segmentation',
      'Journey analytics & sentiment mining',
    ],
  },
  {
    heading: 'Design & Experience',
    items: [
      'Service blueprinting & journey orchestration',
      'Design systems & accessibility audits',
      'Rapid prototyping & experiment design',
    ],
  },
  {
    heading: 'Technology & Delivery',
    items: [
      'Platform modernization & microservices',
      'DevOps automation & observability',
      'Change management & capability enablement',
    ],
  },
];

const engagementModels = [
  {
    title: 'Transformation Squads',
    description:
      'Cross-functional teams embedded within your organization, co-leading strategic initiatives from discovery to scale.',
  },
  {
    title: 'Advisory Retainers',
    description:
      'Dedicated strategists, design leads, and technology advisors who guide your teams with on-demand expertise.',
  },
  {
    title: 'Capability Building',
    description:
      'Customized academies, playbooks, and embedded coaching to strengthen internal practices and governance.',
  },
];

const proofPoints = [
  { metric: '12-week', label: 'average time to pilot launch' },
  { metric: '3.4x', label: 'average ROI across programs' },
  { metric: '94%', label: 'executive confidence scores' },
];

const toolkitItems = [
  'Journey mapping & service blueprints',
  'Design ops & product governance frameworks',
  'Analytics instrumentation & dashboards',
  'Innovation portfolio management',
  'Change enablement & communications',
  'Platform modernization accelerators',
];

const ImageWithLoader = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`image-loader ${loaded ? 'loaded' : ''} ${className || ''}`}>
      <img src={src} alt={alt} loading="lazy" onLoad={() => setLoaded(true)} />
    </div>
  );
};

const Services = () => {
  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    const elements = document.querySelectorAll('.reveal');
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="services-page">
      <section
        className="page-hero services-hero"
        style={{ backgroundImage: 'url(https://picsum.photos/1600/700?random=604)' }}
      >
        <div className="page-hero-overlay" />
        <div className="container">
          <div className="page-hero-content">
            <h1>Integrated services that turn ambition into evidence-backed results.</h1>
            <p>
              Whether you are reimagining an experience, scaling a product, or building new capabilities,
              our multidisciplinary team moves with you from idea to impact.
            </p>
            <Link to="/contact" className="btn btn-primary">
              Craft your engagement
            </Link>
          </div>
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container service-grid">
          {serviceDetails.map((service) => (
            <div className="service-detail-card" key={service.title}>
              <h2>{service.title}</h2>
              <p>{service.summary}</p>
              <ul>
                {service.outcomes.map((outcome) => (
                  <li key={outcome}>{outcome}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container capability-grid">
          {capabilityGroups.map((group) => (
            <div className="capability-card" key={group.heading}>
              <h3>{group.heading}</h3>
              <ul>
                {group.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="page-section reveal services-insight">
        <div className="container insights-grid">
          <ImageWithLoader
            src="https://picsum.photos/900/650?random=605"
            alt="Service designers mapping customer journeys with clients"
            className="services-image"
          />
          <div className="insights-content">
            <h2>Co-create the roadmap with measurable value at every milestone.</h2>
            <p>
              We build joint delivery plans that integrate research, design, and technology. Each workstream
              is connected to defined success metrics with clear owners and rituals that keep teams aligned.
            </p>
            <ul className="insights-list">
              <li>Quarterly OKRs and dashboards tied to experience KPIs.</li>
              <li>Experiment libraries and decision logs for transparent governance.</li>
              <li>Capability uplift plans to embed new ways of working.</li>
            </ul>
            <Link to="/about" className="btn btn-secondary">
              Learn about our approach
            </Link>
          </div>
        </div>
      </section>

      <section className="page-section reveal engagement-section">
        <div className="container engagement-grid">
          {engagementModels.map((model) => (
            <div className="engagement-card" key={model.title}>
              <h3>{model.title}</h3>
              <p>{model.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="page-section reveal proof-section">
        <div className="container proof-grid">
          {proofPoints.map((item) => (
            <div className="proof-card" key={item.label}>
              <span className="proof-metric">{item.metric}</span>
              <span className="proof-label">{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="page-section reveal toolkit-section">
        <div className="container toolkit-grid">
          <div className="toolkit-content">
            <h2>Your initiative, powered by our playbooks</h2>
            <p>
              Our toolkit combines proven frameworks with custom accelerators tailored to your context.
              Use them to align stakeholders, de-risk investment, and create repeatable success.
            </p>
            <Link to="/contact" className="btn btn-outline">
              Request a working session
            </Link>
          </div>
          <ImageWithLoader
            src="https://picsum.photos/900/650?random=606"
            alt="Cross-functional team reviewing digital transformation playbooks"
            className="services-image"
          />
        </div>
        <div className="container toolkit-list">
          <ul>
            {toolkitItems.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="page-section reveal services-cta">
        <div className="container">
          <h2>Let’s design the engagement that fits your ambition.</h2>
          <p>
            Share your goals and we’ll assemble the right mix of strategists, designers, and technologists to make them real.
          </p>
          <Link to="/contact" className="btn btn-primary">
            Start the conversation
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;