import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const statsData = [
  { label: 'Projects Delivered', value: 320, suffix: '+' },
  { label: 'Client Satisfaction', value: 96, suffix: '%' },
  { label: 'Countries Served', value: 18 },
  { label: 'Average ROI Achieved', value: 12, suffix: 'x' },
];

const servicesData = [
  {
    title: 'Growth Strategy',
    description:
      'Data-backed roadmaps that align your teams, accelerate revenue, and remove uncertainty from decision-making.',
    icon: '📈',
  },
  {
    title: 'Service Design',
    description:
      'End-to-end service orchestration that unlocks differentiated customer experiences across digital and physical touchpoints.',
    icon: '🧭',
  },
  {
    title: 'Product Acceleration',
    description:
      'Launch high-impact products faster with cross-functional squads, rapid experimentation, and measurable outcomes.',
    icon: '🚀',
  },
  {
    title: 'Customer Research',
    description:
      'Qualitative and quantitative insights uncover unmet needs, powering confident investments in innovation.',
    icon: '🔍',
  },
  {
    title: 'Digital Transformation',
    description:
      'Modernize platforms, workflows, and teams with cloud-native architectures and future-proof operating models.',
    icon: '💡',
  },
  {
    title: 'Analytics Enablement',
    description:
      'Build actionable intelligence with unified data, dashboards, and advanced analytics capabilities.',
    icon: '📊',
  },
];

const processSteps = [
  {
    title: 'Discover & Align',
    description:
      'Immersive workshops, stakeholder interviews, and baseline analysis to define ambitions and constraints.',
  },
  {
    title: 'Design & Prototype',
    description:
      'Collaborative design sprints, rapid prototyping, and user validation to test the experience early.',
  },
  {
    title: 'Build & Launch',
    description:
      'Integrated delivery combining modern engineering practices with rigorous change management.',
  },
  {
    title: 'Scale & Optimize',
    description:
      'Ongoing performance measurement, experimentation, and capability enablement to sustain momentum.',
  },
];

const testimonialsData = [
  {
    quote:
      'Apex Dynamics delivered a unified commerce strategy that transformed our omnichannel experience. We saw double-digit growth within the first quarter.',
    name: 'Priya Raman',
    role: 'Chief Digital Officer, Horizon Retail Group',
  },
  {
    quote:
      'Their product acceleration team helped us launch a new B2B offering in record time. The depth of research and executional discipline is unmatched.',
    name: 'Daniel Lee',
    role: 'VP of Product, Velocity Logistics',
  },
  {
    quote:
      'From discovery through scale, the Apex team kept us aligned and focused on customer value. They are true partners invested in our success.',
    name: 'Amelia Chen',
    role: 'Head of Experience, Stellar Financial',
  },
];

const teamMembersData = [
  {
    name: 'Maya Johnson',
    role: 'Founder & Lead Strategist',
    image: 'https://picsum.photos/400/400?random=303',
    bio: 'Former Fortune 500 transformation leader with 15 years guiding enterprise innovation and large-scale change.',
    linkedin: 'https://www.linkedin.com',
  },
  {
    name: 'Luis Martinez',
    role: 'Director of Experience Design',
    image: 'https://picsum.photos/400/400?random=304',
    bio: 'Design leader specializing in human-centered service design, usability testing, and digital ecosystems.',
    linkedin: 'https://www.linkedin.com',
  },
  {
    name: 'Sofia Anders',
    role: 'Head of Delivery',
    image: 'https://picsum.photos/400/400?random=305',
    bio: 'Program strategist ensuring complex initiatives land with measurable impact, on time and on budget.',
    linkedin: 'https://www.linkedin.com',
  },
];

const projectsData = [
  {
    title: 'Digital Commerce Redesign',
    category: 'Strategy',
    description: 'Unified CX vision and roadmap for a global retailer with 12 markets.',
    image: 'https://picsum.photos/1200/800?random=401',
    result: 'Increased conversion by 42% within 90 days of launch.',
  },
  {
    title: 'Smart Operations Platform',
    category: 'Development',
    description: 'IoT-enabled platform connecting field teams with real-time insights.',
    image: 'https://picsum.photos/1200/800?random=402',
    result: 'Reduced operational overhead by $2.3M annually.',
  },
  {
    title: 'Next-Gen Banking App',
    category: 'Design',
    description: 'Mobile-first experience for a digital bank expansion in APAC.',
    image: 'https://picsum.photos/1200/800?random=403',
    result: 'Achieved 68% adoption within the first six weeks.',
  },
  {
    title: 'Customer Research Lead Program',
    category: 'Research',
    description: 'Global ethnographic study informing a new loyalty proposition.',
    image: 'https://picsum.photos/1200/800?random=404',
    result: 'Unlocked a $180M growth opportunity across regions.',
  },
  {
    title: 'SaaS Onboarding Revamp',
    category: 'Design',
    description: 'Reimagined onboarding experience for enterprise software clients.',
    image: 'https://picsum.photos/1200/800?random=405',
    result: 'Cut churn by 28% and boosted NPS by 18 points.',
  },
  {
    title: 'Analytics Center of Excellence',
    category: 'Strategy',
    description: 'Future-state blueprint for data governance and dashboards.',
    image: 'https://picsum.photos/1200/800?random=406',
    result: 'Enabled unified KPI insights across 14 business units.',
  },
];

const faqData = [
  {
    question: 'How do you align stakeholders across complex organizations?',
    answer:
      'We use collaborative ways of working—including vision sprints, journey mapping, and value stream alignment—to build a shared understanding of customer needs, success metrics, and governance from day one.',
  },
  {
    question: 'What industries do you specialize in?',
    answer:
      'Our team has deep experience across retail, financial services, logistics, SaaS, healthcare, and mobility. We combine cross-industry best practices with domain expertise to tailor engagements.',
  },
  {
    question: 'How quickly can we launch a new initiative?',
    answer:
      'Discovery typically takes 3-4 weeks, with alpha launches between 10-16 weeks depending on scope and integration complexity. We build flexible delivery squads to meet critical timelines.',
  },
  {
    question: 'Can you work alongside our internal teams?',
    answer:
      'Absolutely. We integrate with internal product, technology, and operations teams to co-create solutions, transfer knowledge, and build lasting capabilities within your organization.',
  },
];

const blogPostsData = [
  {
    title: 'Designing Seamless End-to-End Service Journeys',
    excerpt:
      'Learn how to map operational complexity into a simple customer experience, from research to service blueprints.',
    date: 'September 18, 2024',
    image: 'https://picsum.photos/800/600?random=501',
    link: 'https://www.apexdynamicsconsulting.com/blog/seamless-service-journeys',
  },
  {
    title: 'Building an Analytics Culture People Actually Use',
    excerpt:
      'Adoption issues are rarely about the tool. Discover the rituals, governance, and enablement that drive real value.',
    date: 'August 30, 2024',
    image: 'https://picsum.photos/800/600?random=502',
    link: 'https://www.apexdynamicsconsulting.com/blog/analytics-culture',
  },
  {
    title: 'Rapid Experimentation for Enterprise Innovation',
    excerpt:
      'Deploy experiment-driven operating models that de-risk bold moves and align stakeholders around evidence.',
    date: 'August 2, 2024',
    image: 'https://picsum.photos/800/600?random=503',
    link: 'https://www.apexdynamicsconsulting.com/blog/rapid-experimentation',
  },
];

const ImageWithLoader = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`image-loader ${loaded ? 'loaded' : ''} ${className || ''}`}>
      <img src={src} alt={alt} loading="lazy" onLoad={() => setLoaded(true)} />
    </div>
  );
};

const Home = () => {
  const [animatedStats, setAnimatedStats] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeFaq, setActiveFaq] = useState(null);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }

    let frameId;
    const duration = 1600;
    const start = performance.now();

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const values = statsData.map((item) => Math.round(item.value * progress));
      setAnimatedStats(values);

      if (progress < 1) {
        frameId = requestAnimationFrame(animate);
      }
    };

    frameId = requestAnimationFrame(animate);

    return () => {
      if (frameId) {
        cancelAnimationFrame(frameId);
      }
    };
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    const elements = document.querySelectorAll('.reveal');
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);

    return () => clearInterval(timer);
  }, []);

  const heroBackground = 'https://picsum.photos/1600/900?random=101';
  const insightsImage = 'https://picsum.photos/800/600?random=202';
  const innovationImage = 'https://picsum.photos/800/600?random=203';

  const categories = ['All', ...new Set(projectsData.map((project) => project.category))];

  const filteredProjects =
    activeCategory === 'All'
      ? projectsData
      : projectsData.filter((project) => project.category === activeCategory);

  const toggleFaq = (index) => {
    setActiveFaq((prev) => (prev === index ? null : index));
  };

  const currentTestimonialData = testimonialsData[currentTestimonial];

  return (
    <div className="home-page">
      <section
        className="hero"
        style={{ backgroundImage: `url(${heroBackground})` }}
      >
        <div className="hero-overlay" />
        <div className="container hero-container">
          <div className="hero-content reveal">
            <div className="hero-eyebrow">Strategic Growth Partners</div>
            <h1>
              Accelerate transformation with bold strategy, inspired design, and
              resilient delivery.
            </h1>
            <p>
              Apex Dynamics Consulting unites research, strategy, design, and
              technology to help ambitious teams invent the future, launch with
              confidence, and scale what works.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn btn-primary btn-hero">
                Start Your Initiative
              </Link>
              <Link to="/services" className="btn btn-outline">
                Explore Services
              </Link>
            </div>
            <div className="hero-trust">
              <span className="hero-trust-label">Trusted by teams at</span>
              <div className="hero-trust-logos">
                <span>NovaBank</span>
                <span>Guidewave</span>
                <span>Axis Mobility</span>
                <span>GreenField</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stats-section reveal">
        <div className="container">
          <div className="section-header">
            <h2>Outcomes that move the needle</h2>
            <p>
              We focus on measurable value, rallying teams around shared impact
              metrics from inception through scale.
            </p>
          </div>
          <div className="stats-grid">
            {statsData.map((item, index) => (
              <div className="stat-card" key={item.label}>
                <div className="stat-value">
                  {animatedStats[index].toLocaleString()}
                  {item.suffix && (
                    <span className="stat-suffix">{item.suffix}</span>
                  )}
                </div>
                <div className="stat-label">{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="services-section reveal">
        <div className="container">
          <div className="section-header">
            <h2>Integrated services for every stage of growth</h2>
            <p>
              Build clarity, launch new value propositions, and scale winning
              experiences with a multidisciplinary team aligned to your goals.
            </p>
          </div>
          <div className="services-grid">
            {servicesData.map((service) => (
              <div className="service-card" key={service.title}>
                <div className="service-icon" aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className="service-link">
                  Learn more
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="insights-section reveal">
        <div className="container insights-grid">
          <div className="insights-content">
            <h2>Insight-driven strategies anchored in customer truth</h2>
            <p>
              We blend qualitative research, market intelligence, and advanced
              analytics to uncover human motivations. The result is a strategy
              grounded in evidence, with clear prioritization and a compelling
              value proposition for customers and stakeholders alike.
            </p>
            <ul className="insights-list">
              <li>Enterprise research operations integrated across silos.</li>
              <li>Customer journey governance that keeps teams aligned.</li>
              <li>Strategic narratives and artifacts that enable action.</li>
            </ul>
            <Link to="/about" className="btn btn-secondary">
              Discover our method
            </Link>
          </div>
          <ImageWithLoader
            src={insightsImage}
            alt="Team collaborating on strategic roadmap with data visualizations"
            className="insights-image"
          />
        </div>
      </section>

      <section className="process-section reveal">
        <div className="container">
          <div className="section-header">
            <h2>A proven process tailored to your velocity</h2>
            <p>
              From the first whiteboard sketch to market launch, we operate as
              an extension of your team—aligning stakeholders, de-risking
              investment, and building momentum.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step, index) => (
              <div className="process-card" key={step.title}>
                <div className="process-number">{index + 1}</div>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="innovation-section reveal">
        <div className="container innovation-grid">
          <ImageWithLoader
            src={innovationImage}
            alt="Innovative workspace with collaborative digital tools"
            className="innovation-image"
          />
          <div className="innovation-content">
            <h2>Build resilient systems that scale with confidence</h2>
            <p>
              Our delivery teams pair modern engineering practices with change
              management to ensure enterprise readiness. We embed with your
              teams, streamline governance, and enable long-term ownership.
            </p>
            <div className="innovation-points">
              <div>
                <span className="innovation-count">10x</span>
                Faster experiment cycles powered by automated tooling.
              </div>
              <div>
                <span className="innovation-count">30%</span>
                Reduction in total cost of ownership post-launch.
              </div>
              <div>
                <span className="innovation-count">100%</span>
                Knowledge transfer completion for internal teams.
              </div>
            </div>
            <Link to="/contact" className="btn btn-outline">
              Talk with an expert
            </Link>
          </div>
        </div>
      </section>

      <section className="testimonials-section reveal">
        <div className="container">
          <div className="testimonials-wrapper">
            <div className="testimonial-quote">
              “{currentTestimonialData.quote}”
            </div>
            <div className="testimonial-meta">
              <span className="testimonial-name">{currentTestimonialData.name}</span>
              <span className="testimonial-role">{currentTestimonialData.role}</span>
            </div>
            <div className="testimonial-controls" role="tablist" aria-label="Client testimonials">
              {testimonialsData.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  type="button"
                  className={`testimonial-dot ${currentTestimonial === index ? 'active' : ''}`}
                  onClick={() => setCurrentTestimonial(index)}
                  aria-label={`View testimonial from ${testimonial.name}`}
                  aria-selected={currentTestimonial === index}
                  role="tab"
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team-section reveal">
        <div className="container">
          <div className="section-header">
            <h2>Senior leadership on every engagement</h2>
            <p>
              Your initiative is guided by seasoned strategists, designers, and
              technologists who bring cross-industry expertise and hands-on
              experience shipping high-impact work.
            </p>
          </div>
          <div className="team-grid">
            {teamMembersData.map((member) => (
              <div className="team-card" key={member.name}>
                <div className="team-media">
                  <ImageWithLoader
                    src={member.image}
                    alt={`${member.name}, ${member.role}`}
                    className="team-photo"
                  />
                  <div className="team-overlay">
                    <p>{member.bio}</p>
                    <a href={member.linkedin} target="_blank" rel="noreferrer">
                      Connect on LinkedIn
                    </a>
                  </div>
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="projects-section reveal">
        <div className="container">
          <div className="section-header">
            <h2>Selected projects</h2>
            <p>
              Every engagement is tailored to your business model and maturity.
              Explore a few transformations we have delivered recently.
            </p>
          </div>
          <div className="filter-group" role="tablist" aria-label="Project categories">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`filter-button ${activeCategory === category ? 'active' : ''}`}
                onClick={() => setActiveCategory(category)}
                role="tab"
                aria-selected={activeCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="project-grid">
            {filteredProjects.map((project) => (
              <div className="project-card" key={project.title}>
                <ImageWithLoader
                  src={project.image}
                  alt={`${project.title} project visual`}
                  className="project-image"
                />
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className="project-result">{project.result}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section reveal">
        <div className="container">
          <div className="section-header">
            <h2>Frequently asked questions</h2>
            <p>
              We meet you where you are. Here are the answers to some of the
              questions we hear most often from growth-minded teams.
            </p>
          </div>
          <div className="faq-list">
            {faqData.map((item, index) => (
              <div
                className={`faq-item ${activeFaq === index ? 'open' : ''}`}
                key={item.question}
              >
                <button
                  type="button"
                  className="faq-question"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={activeFaq === index}
                >
                  {item.question}
                  <span className="faq-icon" aria-hidden="true" />
                </button>
                <div className="faq-answer">
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog-section reveal">
        <div className="container">
          <div className="section-header">
            <h2>Latest insights &amp; updates</h2>
            <p>
              Explore perspectives from our practitioners on the future of
              digital experience, operating models, and customer value.
            </p>
          </div>
          <div className="blog-grid">
            {blogPostsData.map((post) => (
              <article className="blog-card" key={post.title}>
                <ImageWithLoader
                  src={post.image}
                  alt={post.title}
                  className="blog-image"
                />
                <div className="blog-content">
                  <span className="blog-date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <a href={post.link} className="blog-link">
                    Read the article
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section reveal">
        <div className="container cta-container">
          <div>
            <h2>Let’s architect what’s next.</h2>
            <p>
              Share where you’re headed and we’ll assemble the right mix of
              experts to get you there—fast, focused, and ready to scale.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn-primary">
              Schedule a conversation
            </Link>
            <Link to="/services" className="btn btn-outline">
              Download capabilities overview
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;