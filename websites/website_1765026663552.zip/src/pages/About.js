import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const valuesData = [
  {
    title: 'Empathy & Evidence',
    description:
      'We listen first, pairing qualitative insights with data to understand what truly matters to customers and stakeholders.',
  },
  {
    title: 'Velocity with Rigor',
    description:
      'Speed is valuable when paired with confidence. We design smart guardrails so your teams can move with purpose.',
  },
  {
    title: 'Co-creation',
    description:
      'We build with you, not for you—elevating the capabilities of your teams so progress continues after our engagement.',
  },
  {
    title: 'Measurable Impact',
    description:
      'Every initiative is tied to a clear value hypothesis, success metrics, and transparent reporting.',
  },
];

const timelineData = [
  {
    year: '2016',
    title: 'Origins',
    description:
      'Apex Dynamics launches with a mission to connect insight, design, and technology for ambitious organizations.',
  },
  {
    year: '2018',
    title: 'Global Expansion',
    description:
      'We establish delivery hubs across North America and Europe, enabling follow-the-sun collaboration.',
  },
  {
    year: '2020',
    title: 'Scale with Resilience',
    description:
      'Clients leverage our remote-first frameworks to accelerate digital programs during rapid change.',
  },
  {
    year: '2023',
    title: 'Capability Network',
    description:
      'We formalize our practitioner guilds, offering clients embedded expertise across strategy, CX, and engineering.',
  },
];

const impactStats = [
  { value: '180+', label: 'Transformation programs delivered' },
  { value: '94%', label: 'Executive confidence scores' },
  { value: '12', label: 'Average years senior lead experience' },
];

const principlesData = [
  {
    title: 'Guided by customers',
    description:
      'We ensure every decision is anchored in customer needs, validated through continuous discovery.',
  },
  {
    title: 'Adaptive partnerships',
    description:
      'Our team flexes to match your operating rhythms, from product pods to enterprise transformation offices.',
  },
  {
    title: 'Sustainable outcomes',
    description:
      'We design playbooks, rituals, and enablement to ensure the impact lasts well beyond launch.',
  },
];

const ImageWithLoader = ({ src, alt, className }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={`image-loader ${loaded ? 'loaded' : ''} ${className || ''}`}>
      <img src={src} alt={alt} loading="lazy" onLoad={() => setLoaded(true)} />
    </div>
  );
};

const About = () => {
  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    const elements = document.querySelectorAll('.reveal');
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="about-page">
      <section
        className="page-hero"
        style={{ backgroundImage: 'url(https://picsum.photos/1600/700?random=601)' }}
      >
        <div className="page-hero-overlay" />
        <div className="container">
          <div className="page-hero-content">
            <h1>We architect bold transformations with purpose and precision.</h1>
            <p>
              Apex Dynamics Consulting was founded to bridge the gap between strategy and execution.
              We believe meaningful progress happens when vision, customer insight, and delivery excellence work together.
            </p>
            <Link to="/contact" className="btn btn-primary">
              Partner with our team
            </Link>
          </div>
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container about-grid">
          <div className="about-story">
            <h2>From insight to impact</h2>
            <p>
              Our founders spent their careers leading large-scale transformations inside global enterprises.
              The breakthrough? Change sticks when teams are empowered, insights are transparent, and delivery is sustainable.
            </p>
            <p>
              Today we assemble multidisciplinary teams—strategists, researchers, designers, engineers, and change leaders—
              tuned to your goals. We operate as one team with shared rituals, clear cadences, and accountability for outcomes.
            </p>
            <ul className="about-list">
              <li>Proven playbooks shaped by over 180 programs worldwide.</li>
              <li>Client satisfaction scores consistently above 94%.</li>
              <li>Embedded enablement so your teams carry the momentum forward.</li>
            </ul>
          </div>
          <ImageWithLoader
            src="https://picsum.photos/900/650?random=602"
            alt="Apex Dynamics leadership team collaborating in workshop"
            className="about-image"
          />
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container values-grid">
          {valuesData.map((value) => (
            <div className="value-card" key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container timeline">
          <h2>Milestones on our journey</h2>
          <div className="timeline-items">
            {timelineData.map((item) => (
              <div className="timeline-item" key={item.year}>
                <div className="timeline-year">{item.year}</div>
                <div className="timeline-content">
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container impact-grid">
          {impactStats.map((stat) => (
            <div className="impact-card" key={stat.label}>
              <span className="impact-value">{stat.value}</span>
              <span className="impact-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container principles-grid">
          <div className="principles-text">
            <h2>Operating principles</h2>
            <p>
              These principles keep our teams and yours aligned. They ensure every initiative is grounded in purpose and executed with clarity.
            </p>
            <Link to="/services" className="btn btn-secondary">
              Explore our services
            </Link>
          </div>
          <div className="principles-list">
            {principlesData.map((principle) => (
              <div className="principle-card" key={principle.title}>
                <h3>{principle.title}</h3>
                <p>{principle.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="page-section reveal">
        <div className="container about-grid">
          <ImageWithLoader
            src="https://picsum.photos/900/650?random=603"
            alt="Team facilitating strategy workshop with client stakeholders"
            className="about-image"
          />
          <div className="about-story">
            <h2>Global reach, local understanding</h2>
            <p>
              From New York to London, Toronto to Berlin, our strategists and delivery specialists bring localized market knowledge with global best practices.
            </p>
            <p>
              We adapt engagement models to your team structure—whether you need a transformation office, product pods, or embedded enablement.
            </p>
            <div className="about-badges">
              <span>Follow-the-sun collaboration</span>
              <span>Hybrid & remote-first delivery</span>
              <span>Certified change practitioners</span>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section reveal about-cta">
        <div className="container">
          <h2>Ready to make your next chapter your best chapter?</h2>
          <p>
            Let’s build a roadmap that aligns leadership, energizes teams, and delivers measurable value.
          </p>
          <Link to="/contact" className="btn btn-primary">
            Schedule a discovery session
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;