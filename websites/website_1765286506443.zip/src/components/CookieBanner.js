import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'hsfr_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem(COOKIE_KEY);
    if (!storedConsent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.message}>
        Historic Streets of France Review utilise des cookies techniques pour assurer le bon
        fonctionnement du site. En poursuivant votre navigation, vous acceptez cette utilisation.
        <a className={styles.link} href="/politique-des-cookies">Consulter la politique des cookies</a>
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        J’accepte
      </button>
    </div>
  );
};

export default CookieBanner;