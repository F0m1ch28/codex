import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.column}>
        <h2 className={styles.title}>Historic Streets of France Review</h2>
        <p className={styles.text}>
          Publication indépendante consacrée à l’étude des rues historiques françaises,
          de leur évolution architecturale et des dynamiques sociales qui les traversent.
        </p>
      </div>
      <div className={styles.column}>
        <h3 className={styles.subtitle}>Navigation</h3>
        <ul className={styles.list}>
          <li><Link to="/a-propos">À propos</Link></li>
          <li><Link to="/methodologie">Méthodologie</Link></li>
          <li><Link to="/archives">Archives</Link></li>
          <li><Link to="/contact">Contact</Link></li>
        </ul>
      </div>
      <div className={styles.column}>
        <h3 className={styles.subtitle}>Références</h3>
        <ul className={styles.list}>
          <li><Link to="/conditions-utilisation">Conditions d’utilisation</Link></li>
          <li><Link to="/politique-de-confidentialite">Politique de confidentialité</Link></li>
          <li><Link to="/politique-des-cookies">Politique des cookies</Link></li>
        </ul>
        <p className={styles.contact}>
          Pour toute demande&nbsp;: <a href="mailto:redaction@historicstreets-fr-review.fr">redaction@historicstreets-fr-review.fr</a>
        </p>
      </div>
    </div>
    <div className={styles.bottom}>
      <p className={styles.bottomText}>
        © {new Date().getFullYear()} Historic Streets of France Review. Tous droits réservés.
      </p>
    </div>
  </footer>
);

export default Footer;