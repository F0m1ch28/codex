import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { to: '/', label: 'Accueil' },
    { to: '/a-propos', label: 'À propos' },
    { to: '/methodologie', label: 'Méthodologie' },
    { to: '/archives', label: 'Archives' },
    { to: '/contact', label: 'Contact' },
    { to: '/conditions-utilisation', label: 'Conditions d’utilisation' },
    { to: '/politique-de-confidentialite', label: 'Politique de confidentialité' },
    { to: '/politique-des-cookies', label: 'Politique des cookies' }
  ];

  const toggleMenu = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          Historic Streets of France Review
        </NavLink>
        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="navigation-principale"
        >
          <span className={styles.srOnly}>Ouvrir le menu principal</span>
          <span className={styles.menuIcon} aria-hidden="true" />
        </button>
        <nav
          id="navigation-principale"
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
          aria-label="Navigation principale"
        >
          <ul className={styles.navList}>
            {navItems.map((item) => (
              <li key={item.to} className={styles.navItem}>
                <NavLink
                  to={item.to}
                  onClick={closeMenu}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.active : ''}`
                  }
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;