import React, { useState } from 'react';
import Seo from '../components/Seo';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    topic: '',
    message: ''
  });
  const [feedback, setFeedback] = useState('');

  const handleChange = (event) => {
    setFormData((prev) => ({
      ...prev,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const { fullName, email, message } = formData;
    if (!fullName.trim() || !email.trim() || !message.trim()) {
      setFeedback('Merci de compléter les champs essentiels pour que nous puissions répondre.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/u;
    if (!emailRegex.test(email)) {
      setFeedback('Le format de l’adresse électronique ne semble pas correct.');
      return;
    }
    setFeedback('Votre message a bien été transmis à la rédaction. Merci pour votre contribution.');
    setFormData({
      fullName: '',
      email: '',
      topic: '',
      message: ''
    });
  };

  return (
    <>
      <Seo
        title="Contact | Historic Streets of France Review"
        description="Formulaire de contact de la rédaction de Historic Streets of France Review."
      />
      <article className={styles.page}>
        <header className={styles.header}>
          <h1>Contact</h1>
          <p>
            Pour proposer une étude, signaler une ressource ou solliciter un échange, adressez votre
            message à la rédaction via le formulaire ci-dessous. Nous répondons aux demandes
            éditoriales et scientifiques dans les meilleurs délais.
          </p>
        </header>

        <section className={styles.section}>
          <h2>Formulaire</h2>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <div className={styles.formGroup}>
              <label htmlFor="fullName">Nom complet</label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                value={formData.fullName}
                onChange={handleChange}
                required
                placeholder="Votre nom"
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="email">Adresse électronique</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="nom@example.org"
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="topic">Objet (facultatif)</label>
              <input
                id="topic"
                name="topic"
                type="text"
                value={formData.topic}
                onChange={handleChange}
                placeholder="Sujet de votre message"
              />
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                required
                placeholder="Votre message"
              />
            </div>
            <button type="submit" className={styles.submit}>
              Envoyer
            </button>
            {feedback && (
              <p className={styles.feedback} aria-live="polite">
                {feedback}
              </p>
            )}
          </form>
        </section>

        <section className={styles.section}>
          <h2>Coordonnées de référence</h2>
          <p>
            Rédaction : <a href="mailto:redaction@historicstreets-fr-review.fr">redaction@historicstreets-fr-review.fr</a>
          </p>
          <p>
            Pour toute demande d’accès aux sources primaires ou pour proposer une collaboration
            scientifique, merci de préciser les références des rues étudiées et le cadre de votre
            projet.
          </p>
        </section>
      </article>
    </>
  );
};

export default ContactPage;