import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import styles from './HomePage.module.css';

const latestStudies = [
  {
    id: 'etude-lyon',
    title: 'L’évolution du tracé de la Rue du Vieux Marché à Lyon, 1600-1900',
    excerpt:
      'Analyse diachronique des plans urbains conservés aux archives municipales et croisement avec les registres de métiers des XVIIIe et XIXe siècles.',
    date: '12 juin 2024'
  },
  {
    id: 'etude-paris',
    title: 'Le Boulevard Haussmann : symbole et réalités de la modernisation parisienne',
    excerpt:
      'Lecture critique des transformations du boulevard au prisme des politiques d’assainissement, des archives photographiques et des témoignages contemporains.',
    date: '29 mai 2024'
  },
  {
    id: 'etude-bordeaux',
    title: 'La Rue Sainte-Catherine à Bordeaux, longue durée d’une artère commerçante',
    excerpt:
      'Cartographie évolutive de la rue la plus fréquentée de Bordeaux, du plan Louis XVI aux réaménagements contemporains orientés vers la marche.',
    date: '15 mai 2024'
  },
  {
    id: 'etude-strasbourg',
    title: 'Les alignements médiévaux de la Grand’Rue de Strasbourg',
    excerpt:
      'Étude morphologique associant relevés laser, sources cadastrales et entretiens avec les ateliers de conservation du patrimoine alsacien.',
    date: '24 avril 2024'
  }
];

const focusCities = [
  {
    city: 'Paris',
    description:
      'Transformation haussmannienne, contrastes entre boulevards planifiés et impasses pré-révolutionnaires, réinterprétation des axes historiques.'
  },
  {
    city: 'Lyon',
    description:
      'Superposition des trames médiévales, renaissance italienne à Saint-Jean et percées industrielles du XIXe siècle sur les pentes de la Croix-Rousse.'
  },
  {
    city: 'Marseille',
    description:
      'Confrontation entre ruelles du Panier, grands quais commerciaux et extensions modernes vers le littoral oriental.'
  },
  {
    city: 'Bordeaux',
    description:
      'Patrimoine portuaire, arcades du XVIIIe siècle, réhabilitation des cours historiques et piétonnisation progressive.'
  },
  {
    city: 'Strasbourg',
    description:
      'Héritages germaniques et français, tissus médiévaux denses, planification impériale et recompositions contemporaines.'
  }
];

const HomePage = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');

  const handleSubscription = (event) => {
    event.preventDefault();
    if (!email.trim()) {
      setStatus('Merci d’indiquer une adresse électronique valide.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/u;
    if (!emailRegex.test(email)) {
      setStatus('Le format de l’adresse électronique ne semble pas correct.');
      return;
    }
    setStatus('Votre adresse a été ajoutée à notre liste de diffusion éditoriale.');
    setEmail('');
  };

  return (
    <>
      <Seo
        title="Historic Streets of France Review"
        description="Revue dédiée à l’analyse des rues historiques françaises, de leurs transformations architecturales et de leur rôle social."
      />
      <div className={styles.page}>
        <section className={styles.hero}>
          <div className={styles.heroOverlay} />
          <div className={styles.heroContent}>
            <h1 className={styles.heroTitle}>Historic Streets of France Review</h1>
            <p className={styles.heroSubtitle}>
              Un espace d’analyse pour comprendre comment les rues historiques françaises se
              transforment, s’inscrivent dans la mémoire urbaine et dessinent les usages du
              quotidien.
            </p>
          </div>
        </section>

        <section className={styles.introduction}>
          <div className={styles.sectionInner}>
            <h2 className={styles.sectionTitle}>Une revue pour documenter les espaces publics</h2>
            <p>
              Historic Streets of France Review rassemble des recherches croisées en histoire
              urbaine, géographie sociale et études architecturales. Chaque dossier mobilise des
              archives, des sources cartographiques, des relevés de terrain et des entretiens afin
              de restituer la profondeur historique des rues françaises.
            </p>
            <p>
              L’approche reste volontairement neutre et contextualisée : il s’agit d’examiner les
              espaces publics comme des fabriques de la vie collective, sensibles aux politiques
              urbaines, aux usages quotidiens et aux mémoires locales.
            </p>
          </div>
        </section>

        <section className={styles.latest}>
          <div className={styles.sectionInner}>
            <h2 className={styles.sectionTitle}>Études récentes</h2>
            <div className={styles.cardGrid}>
              {latestStudies.map((study) => (
                <article key={study.id} className={styles.card} id={study.id}>
                  <header className={styles.cardHeader}>
                    <h3>{study.title}</h3>
                    <time dateTime={study.date}>{study.date}</time>
                  </header>
                  <p className={styles.cardExcerpt}>{study.excerpt}</p>
                  <a className={styles.cardLink} href={`/archives#${study.id}`}>
                    Lire l’étude
                  </a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.cities}>
          <div className={styles.sectionInner}>
            <h2 className={styles.sectionTitle}>Cinq villes en observation continue</h2>
            <div className={styles.cityGrid}>
              {focusCities.map((entry) => (
                <article key={entry.city} className={styles.cityCard}>
                  <h3>{entry.city}</h3>
                  <p>{entry.description}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.methodologyPreview}>
          <div className={styles.sectionInner}>
            <h2 className={styles.sectionTitle}>Méthodologie en bref</h2>
            <p>
              Les enquêtes s’appuient sur la confrontation des plans anciens, des archives
              municipales, des données de mobilité, des inventaires patrimoniaux et des entretiens
              avec historiens de l’art, urbanistes et acteurs associatifs. Ce protocole est détaillé
              dans notre présentation méthodologique.
            </p>
            <Link className={styles.methodologyLink} to="/methodologie">
              Découvrir la méthodologie complète
            </Link>
          </div>
        </section>

        <section className={styles.quoteSection}>
          <div className={styles.sectionInner}>
            <blockquote className={styles.quote}>
              « Étudier une rue ne se limite pas à relever sa forme. C’est retracer les rythmes qui
              l’ont traversée, les métiers qui l’ont animée, les ambiances qui l’ont façonnée. »
            </blockquote>
            <p className={styles.quoteAuthor}>— Dr Élodie Marchand, historienne des villes</p>
          </div>
        </section>

        <section className={styles.subscription}>
          <div className={styles.sectionInner}>
            <h2 className={styles.sectionTitle}>Suivez nos publications</h2>
            <p>
              Recevez nos synthèses éditoriales et les annonces d’archives mises à jour directement
              dans votre boîte de réception.
            </p>
            <form className={styles.form} onSubmit={handleSubscription} noValidate>
              <label className={styles.label} htmlFor="newsletter-email">
                Adresse électronique
              </label>
              <div className={styles.formRow}>
                <input
                  id="newsletter-email"
                  name="email"
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="nom@example.org"
                  required
                  className={styles.input}
                />
                <button type="submit" className={styles.submitButton}>
                  Envoyer
                </button>
              </div>
              {status && (
                <p className={styles.statusMessage} aria-live="polite">
                  {status}
                </p>
              )}
            </form>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;