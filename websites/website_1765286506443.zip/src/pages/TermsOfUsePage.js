import React from 'react';
import Seo from '../components/Seo';
import styles from './TermsOfUsePage.module.css';

const TermsOfUsePage = () => (
  <>
    <Seo
      title="Conditions d’utilisation | Historic Streets of France Review"
      description="Conditions générales d’utilisation du site Historic Streets of France Review."
    />
    <article className={styles.page}>
      <header className={styles.header}>
        <h1>Conditions d’utilisation</h1>
        <p>
          Les présentes conditions encadrent l’accès et la consultation du site Historic Streets of
          France Review. En naviguant sur ce site, vous acceptez les règles décrites ci-dessous.
        </p>
      </header>

      <section className={styles.section}>
        <h2>1. Objet</h2>
        <p>
          Le site diffuse des contenus à vocation d’étude et d’information autour des rues
          historiques françaises. Les articles, cartes et illustrations sont publiés pour un usage
          documentaire et ne constituent pas de conseils opérationnels.
        </p>
      </section>

      <section className={styles.section}>
        <h2>2. Propriété intellectuelle</h2>
        <p>
          Les contenus originaux publiés sur le site (textes, analyses, photographies, graphiques)
          appartiennent à Historic Streets of France Review ou aux auteurs identifiés. Toute
          reproduction ou diffusion nécessite l’accord préalable de la rédaction.
        </p>
      </section>

      <section className={styles.section}>
        <h2>3. Responsabilité</h2>
        <p>
          La rédaction veille à la fiabilité des informations. Toutefois, les documents historiques
          peuvent comporter des limites ou lacunes. Les lecteurs sont invités à vérifier les données
          auprès des sources citées. Le site ne saurait être tenu responsable d’éventuels usages
          détournés des contenus.
        </p>
      </section>

      <section className={styles.section}>
        <h2>4. Liens externes</h2>
        <p>
          Certains articles renvoient vers des sites tiers pour compléter la documentation. Ces
          liens sont fournis pour information. Historic Streets of France Review n’exerce aucun
          contrôle sur leur contenu et décline toute responsabilité quant à leur mise à jour.
        </p>
      </section>

      <section className={styles.section}>
        <h2>5. Modifications</h2>
        <p>
          La rédaction peut mettre à jour ces conditions afin de refléter l’évolution du site ou des
          obligations légales. Les utilisateurs sont invités à consulter régulièrement cette page.
        </p>
      </section>
    </article>
  </>
);

export default TermsOfUsePage;