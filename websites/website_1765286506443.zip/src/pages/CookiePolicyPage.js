import React from 'react';
import Seo from '../components/Seo';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <>
    <Seo
      title="Politique des cookies | Historic Streets of France Review"
      description="Informations sur l’utilisation des cookies par Historic Streets of France Review."
    />
    <article className={styles.page}>
      <header className={styles.header}>
        <h1>Politique des cookies</h1>
        <p>
          Historic Streets of France Review utilise des cookies essentiels pour assurer la
          disponibilité du site et mesurer son bon fonctionnement.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Cookies indispensables</h2>
        <p>
          Ces cookies garantissent la navigation, l’accès aux pages et la sécurité des contenus. Ils
          ne collectent aucune information personnelle exploitable à des fins marketing.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Mesure d’audience</h2>
        <p>
          Le site utilise des indicateurs de fréquentation anonymisés afin d’évaluer la consultation
          des pages et d’améliorer l’organisation des contenus. Aucune donnée nominative n’est
          stockée.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Gestion de vos préférences</h2>
        <p>
          Vous pouvez choisir d’accepter ou de refuser les cookies non essentiels via le bandeau
          affiché lors de votre première visite. Votre choix est conservé dans un cookie technique
          pendant une durée limitée.
        </p>
      </section>
    </article>
  </>
);

export default CookiePolicyPage;