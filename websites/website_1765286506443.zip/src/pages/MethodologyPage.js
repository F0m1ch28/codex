import React from 'react';
import Seo from '../components/Seo';
import styles from './MethodologyPage.module.css';

const steps = [
  {
    title: 'Analyse documentaire',
    description:
      'Collecte des plans anciens, des cadastres successifs, des arrêtés municipaux et des photographies d’archives pour établir une ligne de temps précise.'
  },
  {
    title: 'Observation de terrain',
    description:
      'Relevés photographiques et métriques, carnet de bord des usages observés, cartographie des ambiances sonores et lumineuses.'
  },
  {
    title: 'Entretiens qualitatifs',
    description:
      'Rencontres avec historiens locaux, urbanistes, responsables de conservation, commerçants et habitants afin de croiser les regards sur les transformations.'
  },
  {
    title: 'Synthèse et visualisations',
    description:
      'Production de dossiers thématiques, cartes diachroniques, frises chronologiques et tableaux comparatifs, validés par le comité scientifique.'
  }
];

const MethodologyPage = () => (
  <>
    <Seo
      title="Méthodologie | Historic Streets of France Review"
      description="Description détaillée de la méthodologie employée pour documenter les rues historiques françaises."
    />
    <article className={styles.page}>
      <header className={styles.header}>
        <h1>Méthodologie</h1>
        <p>
          Chaque étude publiée dans Historic Streets of France Review suit un protocole rigoureux :
          vérification des sources, triangulation des données, transparence sur les limites
          méthodologiques. Ce cadre garantit la reproductibilité des analyses.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Sources mobilisées</h2>
        <div className={styles.sourcesGrid}>
          <div className={styles.sourceCard}>
            <h3>Archives publiques</h3>
            <p>
              Plans d’alignement, dossiers de travaux, fonds photographiques municipaux, cadastres
              napoléonien et rénové, registres de délibérations.
            </p>
          </div>
          <div className={styles.sourceCard}>
            <h3>Corpus iconographiques</h3>
            <p>
              Cartes postales anciennes, lithographies, atlas, peintures urbaines, films amateurs
              documentant les usages des rues.
            </p>
          </div>
          <div className={styles.sourceCard}>
            <h3>Données contemporaines</h3>
            <p>
              Relevés topographiques, données ouvertes sur les mobilités, mesures climatiques
              urbaines, inventaires patrimoniaux et études de flux piétons.
            </p>
          </div>
          <div className={styles.sourceCard}>
            <h3>Témoignages</h3>
            <p>
              Entretiens semi-directifs, récits de mémoire, contributions associatives dédiées à la
              conservation des quartiers historiques.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <h2>Étapes clés</h2>
        <ol className={styles.steps}>
          {steps.map((step) => (
            <li key={step.title} className={styles.step}>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className={styles.section}>
        <h2>Vérification et relecture</h2>
        <p>
          Les dossiers sont relus par le comité éditorial et, lorsque cela est pertinent, par des
          correspondants locaux. Chaque article indique les archives consultées et précise les
          limites des corpus disponibles. En cas de correction ou d’ajout ultérieur, la notice
          d’erratum est publiée dans la section Archives.
        </p>
      </section>
    </article>
  </>
);

export default MethodologyPage;