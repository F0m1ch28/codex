import React from 'react';
import Seo from '../components/Seo';
import styles from './AboutPage.module.css';

const teamMembers = [
  {
    name: 'Claire Montagnac',
    role: 'Rédactrice en chef',
    description:
      'Historienne de l’architecture, spécialiste des transformations urbaines du XIXe siècle et des politiques de conservation du patrimoine.'
  },
  {
    name: 'Julien Pichon',
    role: 'Coordinateur éditorial',
    description:
      'Géographe urbain, il assure la liaison avec les équipes de terrain et la cohérence des protocoles d’observation.'
  },
  {
    name: 'Mina Benali',
    role: 'Responsable des archives et iconographie',
    description:
      'Archiviste-paléographe, chargée de la sélection des sources, de l’iconographie et des corpus cartographiques.'
  },
  {
    name: 'Antoine Serrat',
    role: 'Chargé des enquêtes locales',
    description:
      'Urbaniste, il coordonne les entretiens, collecte les récits d’usagers et documente les pratiques quotidiennes des rues étudiées.'
  }
];

const AboutPage = () => (
  <>
    <Seo
      title="À propos | Historic Streets of France Review"
      description="Présentation de la rédaction, des objectifs éditoriaux et des principes scientifiques de Historic Streets of France Review."
    />
    <article className={styles.page}>
      <header className={styles.header}>
        <h1>À propos</h1>
        <p>
          Historic Streets of France Review est une revue de recherche indépendante dédiée à la
          compréhension des rues historiques françaises et de leurs enjeux contemporains. Notre
          ambition : croiser les savoirs académiques et les pratiques professionnelles pour documenter
          les mutations des espaces publics.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Orientation éditoriale</h2>
        <p>
          La revue privilégie une analyse située, fondée sur des sources vérifiables. Chaque dossier
          s’articule autour d’un axe thématique : évolution architecturale, mémoire collective,
          usages sociaux, ou encore politiques de réhabilitation. Les contributions externes sont
          relues par le comité de rédaction afin de garantir précision et contextualisation.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Principes directeurs</h2>
        <ul className={styles.list}>
          <li>
            <strong>Neutralité analytique&nbsp;:</strong> restituer les faits urbains sans jugement
            prescriptif, en s’appuyant sur la variété des sources.
          </li>
          <li>
            <strong>Contextualisation historique&nbsp;:</strong> replacer chaque rue dans le temps long,
            depuis sa genèse jusqu’aux requalifications récentes.
          </li>
          <li>
            <strong>Pluridisciplinarité&nbsp;:</strong> mobiliser l’histoire, l’urbanisme, la sociologie,
            l’architecture, la géographie et l’anthropologie urbaine.
          </li>
          <li>
            <strong>Accessibilité des savoirs&nbsp;:</strong> rendre lisibles les résultats de recherche à un public
            large, curieux des transformations urbaines.
          </li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2>Équipe éditoriale</h2>
        <div className={styles.grid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.card}>
              <h3>{member.name}</h3>
              <p className={styles.role}>{member.role}</p>
              <p>{member.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2>Partenariats scientifiques</h2>
        <p>
          La revue entretient des collaborations méthodologiques avec des laboratoires universitaires,
          des services d’archives, des écoles d’architecture et des maisons de l’urbanisme. Ces
          partenariats permettent de valider les corpus, d’ouvrir l’accès aux fonds patrimoniaux et de
          confronter les résultats avec des acteurs de terrain.
        </p>
      </section>
    </article>
  </>
);

export default AboutPage;