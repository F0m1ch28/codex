import React from 'react';
import Seo from '../components/Seo';
import styles from './PrivacyPolicyPage.module.css';

const PrivacyPolicyPage = () => (
  <>
    <Seo
      title="Politique de confidentialité | Historic Streets of France Review"
      description="Politique de confidentialité et traitement des données personnelles de Historic Streets of France Review."
    />
    <article className={styles.page}>
      <header className={styles.header}>
        <h1>Politique de confidentialité</h1>
        <p>
          Cette politique précise la manière dont Historic Streets of France Review traite les
          données personnelles collectées sur le site.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Données collectées</h2>
        <p>
          Les formulaires de contact et de suivi des publications recueillent les informations
          suivantes&nbsp;: nom, adresse électronique, sujet du message. Ces données ne sont utilisées
          que pour répondre aux demandes ou envoyer des informations éditoriales.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Base légale et durée</h2>
        <p>
          Les données sont traitées sur la base du consentement de la personne concernée. Elles sont
          conservées pendant la durée nécessaire au traitement de la demande ou jusqu’au retrait du
          consentement pour les communications éditoriales.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Partage des données</h2>
        <p>
          Les informations transmises ne sont pas cédées à des tiers. Elles peuvent être traitées
          par des prestataires techniques strictement nécessaires au fonctionnement du site, tenus à
          la confidentialité.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Droits des personnes</h2>
        <p>
          Conformément à la législation en vigueur, vous pouvez exercer vos droits d’accès, de
          rectification, d’effacement ou de limitation en écrivant à
          <a href="mailto:redaction@historicstreets-fr-review.fr"> redaction@historicstreets-fr-review.fr</a>.
          Un justificatif d’identité peut être demandé afin de sécuriser le traitement.
        </p>
      </section>
    </article>
  </>
);

export default PrivacyPolicyPage;