import React from 'react';
import Seo from '../components/Seo';
import styles from './ArchivesPage.module.css';

const articles = [
  {
    id: 'rue-vieux-marche',
    title: 'Rue du Vieux Marché à Lyon : entre artisanat et restructurations industrielles',
    city: 'Lyon',
    period: '1600-2023',
    summary:
      'Étude diachronique des mutations fonctionnelles de la rue à partir des registres professionnels, des plans scénographiques lyonnais et des enquêtes orales récentes.',
    keywords: ['Lyon', 'quartiers médiévaux', 'archives municipales', 'artisanat'],
    published: '12 juin 2024'
  },
  {
    id: 'boulevard-haussmann',
    title: 'Boulevard Haussmann : infrastructures et façades sous surveillance patrimoniale',
    city: 'Paris',
    period: '1853-2024',
    summary:
      'Analyse des alignements haussmanniens, des règlements de copropriété et des interventions contemporaines liées à la végétalisation des grands boulevards.',
    keywords: ['Paris', 'tracés haussmanniens', 'patrimoine bâti', 'séquences commerciales'],
    published: '29 mai 2024'
  },
  {
    id: 'rue-sainte-catherine',
    title: 'Rue Sainte-Catherine à Bordeaux : longueurs piétonnes et mutations des commerces',
    city: 'Bordeaux',
    period: '1730-2024',
    summary:
      'Croisement des séries cadastrales, des enquêtes de terrain et des données de fréquentation pour cartographier les usages d’une rue majeure.',
    keywords: ['Bordeaux', 'piétonnisation', 'commerces historiques', 'mobilités'],
    published: '15 mai 2024'
  },
  {
    id: 'grand-rue-strasbourg',
    title: 'Grand’Rue de Strasbourg : alignements médiévaux et régulations contemporaines',
    city: 'Strasbourg',
    period: 'XIIIe siècle-2024',
    summary:
      'Étude morphologique complétée par des relevés laser et des entretiens avec les services de la ville sur les stratégies de conservation.',
    keywords: ['Strasbourg', 'patrimoine urbain', 'conservation', 'ruelles'],
    published: '24 avril 2024'
  },
  {
    id: 'canebiere-marseille',
    title: 'La Canebière : représentations publiques d’une avenue marseillaise',
    city: 'Marseille',
    period: '1666-2023',
    summary:
      'Examen des sources iconographiques et des comptes rendus municipaux pour retracer les débats autour de l’image de la Canebière.',
    keywords: ['Marseille', 'avenues', 'représentations', 'tourisme culturel'],
    published: '10 avril 2024'
  },
  {
    id: 'place-bellecour',
    title: 'Place Bellecour : espace central et recompositions des circulations',
    city: 'Lyon',
    period: 'XVIIe siècle-2024',
    summary:
      'Analyse des plans de circulation, des archives de police et des dispositifs actuels de partage de l’espace sur la plus grande place de Lyon.',
    keywords: ['Lyon', 'places', 'mobilités', 'vie quotidienne'],
    published: '20 mars 2024'
  }
];

const ArchivesPage = () => (
  <>
    <Seo
      title="Archives | Historic Streets of France Review"
      description="Catalogue des études publiées sur les rues emblématiques de France et leurs transformations urbaines."
    />
    <article className={styles.page}>
      <header className={styles.header}>
        <h1>Archives des articles</h1>
        <p>
          Les dossiers sont organisés par ville et par période d’étude. Chaque fiche renvoie aux
          sources principales mobilisées ainsi qu’aux mots-clés permettant d’explorer les thèmes liés
          aux rues historiques françaises.
        </p>
      </header>

      <section className={styles.section} aria-label="Liste des articles archivés">
        <div className={styles.list}>
          {articles.map((article) => (
            <article key={article.id} className={styles.card} id={article.id}>
              <header className={styles.cardHeader}>
                <h2>{article.title}</h2>
                <p className={styles.meta}>
                  <span>{article.city}</span>
                  <span>{article.period}</span>
                  <time dateTime={article.published}>{article.published}</time>
                </p>
              </header>
              <p className={styles.summary}>{article.summary}</p>
              <div className={styles.keywords}>
                {article.keywords.map((keyword) => (
                  <span key={keyword} className={styles.keyword}>
                    {keyword}
                  </span>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>
    </article>
  </>
);

export default ArchivesPage;