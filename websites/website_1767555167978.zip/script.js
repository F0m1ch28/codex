document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const nav = document.getElementById("primary-navigation");
  const menuToggle = document.querySelector(".menu-toggle");

  if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
      const expanded = menuToggle.getAttribute("aria-expanded") === "true";
      menuToggle.setAttribute("aria-expanded", (!expanded).toString());
      menuToggle.classList.toggle("is-active");
      nav.classList.toggle("nav-open");
      body.classList.toggle("has-open-nav");
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        menuToggle.classList.remove("is-active");
        nav.classList.remove("nav-open");
        menuToggle.setAttribute("aria-expanded", "false");
        body.classList.remove("has-open-nav");
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
    const consent = localStorage.getItem("cookieConsent");

    if (consent === "accepted" || consent === "declined") {
      cookieBanner.classList.add("is-hidden");
    }

    const handleConsent = (value) => {
      localStorage.setItem("cookieConsent", value);
      cookieBanner.classList.add("is-hidden");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => handleConsent("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => handleConsent("declined"));
    }
  }

  const filterButtons = document.querySelectorAll(".btn-filter");
  const tourCards = document.querySelectorAll(".tour-card");

  if (filterButtons.length && tourCards.length) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const filterValue = button.dataset.filter;
        filterButtons.forEach((btn) => btn.classList.remove("is-active"));
        button.classList.add("is-active");

        tourCards.forEach((card) => {
          const category = card.dataset.category || "";
          if (filterValue === "all") {
            card.classList.remove("is-hidden");
            return;
          }
          const categories = category.split(",").map((item) => item.trim());
          card.classList.toggle("is-hidden", !categories.includes(filterValue));
        });
      });
    });
  }

  const contactForm = document.querySelector(".contact-form");
  if (contactForm) {
    const messageBox = contactForm.querySelector(".form-message");

    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const nameInput = contactForm.querySelector('input[name="name"]');
      const emailInput = contactForm.querySelector('input[name="email"]');
      const phoneInput = contactForm.querySelector('input[name="phone"]');
      const serviceSelect = contactForm.querySelector('select[name="service"]');
      const messageInput = contactForm.querySelector('textarea[name="message"]');

      const errors = [];

      const resetField = (field) => {
        if (field) {
          field.classList.remove("field-error");
        }
      };

      [nameInput, emailInput, phoneInput, serviceSelect, messageInput].forEach(resetField);

      if (!nameInput || nameInput.value.trim().length < 2) {
        errors.push("Пожалуйста, укажите ваше имя (не менее 2 символов).");
        if (nameInput) nameInput.classList.add("field-error");
      }

      const emailValue = emailInput ? emailInput.value.trim() : "";
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(emailValue)) {
        errors.push("Введите корректный адрес электронной почты.");
        if (emailInput) emailInput.classList.add("field-error");
      }

      if (serviceSelect && serviceSelect.value === "") {
        errors.push("Пожалуйста, выберите интересующий формат путешествия.");
        serviceSelect.classList.add("field-error");
      }

      if (!messageInput || messageInput.value.trim().length < 20) {
        errors.push("Расскажите подробнее о запросе (минимум 20 символов).");
        if (messageInput) messageInput.classList.add("field-error");
      }

      if (!messageBox) {
        return;
      }

      if (errors.length) {
        messageBox.textContent = errors.join(" ");
        messageBox.classList.add("is-visible", "error");
        messageBox.classList.remove("success");
        return;
      }

      messageBox.textContent = "Спасибо! Ваш запрос отправлен. Менеджер свяжется с вами в течение часа.";
      messageBox.classList.add("is-visible", "success");
      messageBox.classList.remove("error");
      contactForm.reset();
    });
  }
});