document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");
    const scrollBtn = document.getElementById("scrollTop");
    const form = document.getElementById("contact-form");
    const formFeedback = document.getElementById("form-feedback");
    const cookieBanner = document.getElementById("cookie-banner");
    const cookieAccept = document.getElementById("cookie-accept");
    const consentKey = "zf_cookie_consent";

    if (navToggle && mainNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = mainNav.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", String(isOpen));
        });

        mainNav.querySelectorAll("a[href^='#']").forEach(link => {
            link.addEventListener("click", event => {
                event.preventDefault();
                const target = document.querySelector(link.getAttribute("href"));
                if (target) {
                    target.scrollIntoView({ behavior: "smooth" });
                }
                mainNav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    window.addEventListener("scroll", () => {
        if (window.scrollY > 280) {
            scrollBtn.classList.add("show");
        } else {
            scrollBtn.classList.remove("show");
        }
    });

    scrollBtn.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    if (form && formFeedback) {
        form.addEventListener("submit", event => {
            event.preventDefault();
            formFeedback.textContent = "Vielen Dank! Ihre Nachricht wurde übermittelt.";
            form.reset();
        });
    }

    const acceptCookies = () => {
        cookieBanner.classList.remove("active");
        localStorage.setItem(consentKey, "accepted");
    };

    if (cookieBanner) {
        const consent = localStorage.getItem(consentKey);
        if (consent !== "accepted") {
            cookieBanner.classList.add("active");
        }

        if (cookieAccept) {
            cookieAccept.addEventListener("click", () => {
                acceptCookies();
            });
        }
    }
});