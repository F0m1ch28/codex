const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.getElementById('primary-menu');
const scrollToTopBtn = document.getElementById('scrollToTop');
const cookieBanner = document.querySelector('.cookie-banner');
const acceptCookiesBtn = document.getElementById('acceptCookies');
const form = document.querySelector('.contact-form');
const formMessage = document.querySelector('.form-message');

const COOKIE_CONSENT_KEY = 'maple_cookie_consent';

if (menuToggle) {
  menuToggle.addEventListener('click', () => {
    const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', !expanded);
    navMenu.classList.toggle('open');
  });
}

document.querySelectorAll('.nav-link').forEach((link) => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
});

window.addEventListener('scroll', () => {
  if (window.scrollY > 300) {
    scrollToTopBtn.style.display = 'inline-flex';
  } else {
    scrollToTopBtn.style.display = 'none';
  }
});

if (scrollToTopBtn) {
  scrollToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

function showCookieBanner() {
  if (!localStorage.getItem(COOKIE_CONSENT_KEY)) {
    cookieBanner.style.display = 'flex';
  }
}

if (acceptCookiesBtn) {
  acceptCookiesBtn.addEventListener('click', () => {
    localStorage.setItem(COOKIE_CONSENT_KEY, 'accepted');
    cookieBanner.style.display = 'none';
  });
}

showCookieBanner();

const yearSpan = document.getElementById('current-year');
if (yearSpan) {
  yearSpan.textContent = new Date().getFullYear();
}

if (form && formMessage) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    formMessage.textContent = 'Thank you for reaching out. Our team will respond shortly.';
    form.reset();
  });
}