import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
  Navigate,
  Link
} from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import TermsOfService from "./pages/TermsOfService";
import PrivacyPolicy from "./pages/PrivacyPolicy";

const CookiePolicy = () => {
  React.useEffect(() => {
    document.title = "Cookie Policy | Green Resilience Lab";
  }, []);
  return (
    <div className="page-section container narrow">
      <header className="page-header">
        <h1>Cookie Policy</h1>
        <p>
          This policy explains how Green Resilience Lab uses cookies and
          comparable technologies to enhance the digital experience on
          GreenResilienceLab.com.
        </p>
      </header>
      <section className="content-card">
        <h2>How We Use Cookies</h2>
        <p>
          We employ strictly necessary cookies to maintain site security and
          preserve your session preferences. Analytics cookies help us
          understand how visitors engage with our resources so we can adjust the
          content architecture responsibly.
        </p>
        <p>
          Cookies do not contain personal identifiers. Analytics data is
          aggregated and stored securely in accordance with Canadian privacy
          legislation. You can disable cookies through your browser settings;
          some features may operate with limited functionality as a result.
        </p>
        <h2>Managing Preferences</h2>
        <p>
          You can manage consent via this page or through the cookie banner on
          your first visit. If you clear cookies, the banner will reappear to
          confirm your preferences.
        </p>
      </section>
      <section className="content-card">
        <h2>Contact</h2>
        <p>
          For questions about this policy, email{" "}
          <a href="mailto:info@greenresiliencelab.com">
            info@greenresiliencelab.com
          </a>{" "}
          or call +1 604 343 9186.
        </p>
      </section>
    </div>
  );
};

const ThankYouPage = () => {
  React.useEffect(() => {
    document.title = "Thank You | Green Resilience Lab";
  }, []);
  return (
    <div className="page-section container narrow">
      <header className="page-header center">
        <h1>Your request has been received</h1>
        <p>
          Our team will review your message and connect with you within one
          business day. We appreciate your commitment to resilient renewable
          infrastructure.
        </p>
        <Link className="button primary" to="/">
          Return to Home
        </Link>
      </header>
    </div>
  );
};

const RouteChangeHandler = () => {
  const location = useLocation();
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname]);
  return null;
};

const AppContent = () => (
  <>
    <Header />
    <RouteChangeHandler />
    <main className="main-content" id="main-content">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/company" element={<About />} />
        <Route path="/about" element={<Navigate to="/company" replace />} />
        <Route path="/services" element={<Services />} />
        <Route path="/risk-assessment" element={<Services activeTab="risk" />} />
        <Route
          path="/resilience-analysis"
          element={<Services activeTab="resilience" />}
        />
        <Route
          path="/environmental-exposure"
          element={<Services activeTab="exposure" />}
        />
        <Route
          path="/applications"
          element={<Services activeTab="applications" />}
        />
        <Route path="/contact" element={<Contact />} />
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<TermsOfService />} />
        <Route path="/cookies" element={<CookiePolicy />} />
        <Route path="/thanks" element={<ThankYouPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </>
);

const App = () => (
  <Router>
    <AppContent />
  </Router>
);

export default App;