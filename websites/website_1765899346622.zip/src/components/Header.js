import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header" role="banner">
      <div className="container header-inner">
        <Link to="/" className="brand" onClick={closeMenu}>
          <span className="brand-mark" aria-hidden="true">
            GRL
          </span>
          <div className="brand-text">
            <span className="brand-name">Green Resilience Lab</span>
            <span className="brand-tagline">
              Renewable Infrastructure Intelligence
            </span>
          </div>
        </Link>
        <button
          className="menu-toggle"
          aria-controls="primary-navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span className="sr-only">Toggle navigation</span>
          <span className="menu-line" />
          <span className="menu-line" />
          <span className="menu-line" />
        </button>
        <nav
          id="primary-navigation"
          className={`nav ${menuOpen ? "is-open" : ""}`}
          aria-label="Main Navigation"
        >
          <NavLink to="/" onClick={closeMenu} className="nav-link">
            Home
          </NavLink>
          <NavLink to="/company" onClick={closeMenu} className="nav-link">
            Company
          </NavLink>
          <NavLink to="/services" onClick={closeMenu} className="nav-link">
            Services
          </NavLink>
          <NavLink to="/applications" onClick={closeMenu} className="nav-link">
            Applications
          </NavLink>
          <NavLink to="/contact" onClick={closeMenu} className="nav-link">
            Contact
          </NavLink>
          <Link
            to="/contact"
            className="button header-cta"
            onClick={closeMenu}
          >
            Request Assessment
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;