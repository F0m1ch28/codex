import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer" role="contentinfo">
      <div className="container footer-grid">
        <div>
          <h3 className="footer-heading">Green Resilience Lab</h3>
          <p>
            Evidence-led diagnostics that keep Canadian renewable infrastructure
            ready for a changing climate.
          </p>
          <div className="footer-contact">
            <p>The Stack – Vancouver, 1133 Melville Street, Floor 18</p>
            <p>Vancouver, British Columbia, Canada</p>
            <p>
              <a href="tel:+16043439186">+1 604 343 9186</a>
            </p>
            <p>
              <a href="mailto:info@greenresiliencelab.com">
                info@greenresiliencelab.com
              </a>
            </p>
          </div>
        </div>
        <div>
          <h4 className="footer-subheading">Explore</h4>
          <ul className="footer-list">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/company">Company</Link>
            </li>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/applications">Applications</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="footer-subheading">Governance</h4>
          <ul className="footer-list">
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/cookies">Cookie Policy</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Service</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="footer-subheading">Connect</h4>
          <div className="footer-social">
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
            >
              <span aria-hidden="true">in</span>
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noreferrer"
              aria-label="Twitter"
            >
              <span aria-hidden="true">t</span>
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noreferrer"
              aria-label="YouTube"
            >
              <span aria-hidden="true">yt</span>
            </a>
          </div>
          <p className="footer-note">
            © {new Date().getFullYear()} Green Resilience Lab. All rights
            reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;