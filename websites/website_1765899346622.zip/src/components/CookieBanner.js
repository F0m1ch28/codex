import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const COOKIE_KEY = "grl-cookie-consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(COOKIE_KEY, "accepted");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-text">
        <p>
          We use essential and analytics cookies to enhance research insights
          and improve your experience. Review how we manage data in our{" "}
          <Link to="/cookies">Cookie Policy</Link>.
        </p>
      </div>
      <button className="button primary" onClick={handleAccept}>
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;