import React, { useEffect } from "react";

const PrivacyPolicy = () => {
  useEffect(() => {
    document.title = "Privacy Policy | Green Resilience Lab";
  }, []);

  return (
    <div className="page-section container narrow">
      <header className="page-header">
        <h1>Privacy Policy</h1>
        <p>Aligned with Canadian privacy legislation (PIPEDA).</p>
      </header>
      <section className="content-card">
        <h2>Information We Collect</h2>
        <p>
          When you submit a form, we collect your name, email address, company,
          and message content. We also gather aggregated analytics information
          such as page visits and engagement patterns.
        </p>
        <h2>How We Use Information</h2>
        <ul className="styled-list">
          <li>Responding to inquiries about services and partnerships.</li>
          <li>
            Improving website usability, accessibility, and educational content.
          </li>
          <li>Maintaining security and preventing unauthorized access.</li>
        </ul>
        <h2>Consent</h2>
        <p>
          By providing personal information, you consent to its use for the
          purposes described. You may withdraw consent at any time by contacting
          us.
        </p>
        <h2>Storage &amp; Safeguards</h2>
        <p>
          Data is stored on secure servers located in Canada. We implement
          technical and organizational measures to protect data from loss or
          unauthorized disclosure.
        </p>
        <h2>Access &amp; Correction</h2>
        <p>
          You may request access to, or corrections of, your personal
          information by emailing{" "}
          <a href="mailto:info@greenresiliencelab.com">
            info@greenresiliencelab.com
          </a>
          . Identification may be required to verify requests.
        </p>
        <h2>Third Parties</h2>
        <p>
          We do not sell personal information. Limited data may be shared with
          service providers who support our operations, subject to strict
          confidentiality obligations.
        </p>
        <h2>Retention</h2>
        <p>
          Personal information is retained only as long as necessary to fulfill
          the purpose for which it was collected or as required by law.
        </p>
        <h2>International Transfers</h2>
        <p>
          We primarily store data in Canada. If data is processed in other
          jurisdictions, we ensure comparable protection measures are in place.
        </p>
        <h2>Updates</h2>
        <p>
          We may revise this policy to reflect new practices or regulatory
          requirements. Changes will be posted on this page with an updated
          effective date.
        </p>
        <h2>Contact</h2>
        <p>
          Privacy inquiries can be sent to{" "}
          <a href="mailto:info@greenresiliencelab.com">
            info@greenresiliencelab.com
          </a>{" "}
          or via telephone at +1 604 343 9186.
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicy;