import React, { useEffect } from "react";

const TermsOfService = () => {
  useEffect(() => {
    document.title = "Terms of Service | Green Resilience Lab";
  }, []);

  return (
    <div className="page-section container narrow">
      <header className="page-header">
        <h1>Terms of Service</h1>
        <p>Effective date: January 2024</p>
      </header>
      <section className="content-card">
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing GreenResilienceLab.com you agree to these Terms of
          Service and all applicable laws and regulations. If you do not agree,
          please discontinue use of the site.
        </p>
        <h2>2. Use of Content</h2>
        <p>
          Content is provided for informational purposes. You may reference the
          material for internal planning, provided attribution to Green
          Resilience Lab is maintained. Redistribution without permission is
          prohibited.
        </p>
        <h2>3. Professional Services</h2>
        <p>
          Any advisory or engineering services are governed by separate written
          agreements outlining scope, deliverables, and responsibilities.
        </p>
        <h2>4. Privacy &amp; Data Protection</h2>
        <p>
          We handle personal data according to our{" "}
          <a href="/privacy">Privacy Policy</a>. By submitting forms you consent
          to the described data practices.
        </p>
        <h2>5. Disclaimers</h2>
        <p>
          Information on this website is provided “as is.” Green Resilience Lab
          makes no warranties regarding completeness, reliability, or
          suitability for specific projects.
        </p>
        <h2>6. Limitation of Liability</h2>
        <p>
          Green Resilience Lab is not liable for direct, indirect, incidental, or
          consequential damages arising from use of this site or reliance on its
          content.
        </p>
        <h2>7. Governing Law</h2>
        <p>
          These terms are governed by the laws of British Columbia and Canada.
          Disputes will be resolved in the courts of British Columbia.
        </p>
        <h2>8. Updates</h2>
        <p>
          We may update these terms from time to time. Continued use of the site
          following changes indicates acceptance of the revised terms.
        </p>
        <h2>9. Contact</h2>
        <p>
          Questions may be directed to{" "}
          <a href="mailto:info@greenresiliencelab.com">
            info@greenresiliencelab.com
          </a>{" "}
          or +1 604 343 9186.
        </p>
      </section>
    </div>
  );
};

export default TermsOfService;