import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const ImageCard = ({ src, alt }) => {
  const [loaded, setLoaded] = useState(false);
  return (
    <div className={`image-frame ${loaded ? "is-loaded" : "is-loading"}`}>
      <img src={src} alt={alt} onLoad={() => setLoaded(true)} />
    </div>
  );
};

const Home = () => {
  const navigate = useNavigate();
  const [ctaEmail, setCtaEmail] = useState("");

  useEffect(() => {
    document.title =
      "Green Resilience Lab | Assessing Risk & Resilience for Renewable Infrastructure";
  }, []);

  const handleCtaSubmit = (event) => {
    event.preventDefault();
    navigate("/contact", { state: { email: ctaEmail } });
  };

  return (
    <div>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-text">
            <p className="eyebrow">Renewable Infrastructure Diagnostics</p>
            <h1>Assessing Risk &amp; Resilience for Renewable Infrastructure</h1>
            <p>
              Green Resilience Lab equips Canadian clean energy operators with
              climate-aware analytics, engineering insight, and resilience
              scoring that anticipate environmental volatility.
            </p>
            <div className="hero-actions">
              <Link to="/services" className="button primary">
                Explore Services
              </Link>
              <Link to="/contact" className="button secondary">
                Speak with Specialists
              </Link>
            </div>
          </div>
          <div className="hero-visual" role="presentation">
            <div className="hero-overlay-card">
              <span className="hero-label">Live Resilience Indices</span>
              <ul>
                <li>
                  Coastal Wind Farms <span>Adaptive Ready 91%</span>
                </li>
                <li>
                  Prairie Solar Arrays <span>Grid Secure 87%</span>
                </li>
                <li>
                  Northern Microgrids <span>Stress Alert Moderate</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section container">
        <header className="section-heading">
          <h2>Why Resilience Matters for Clean Energy Assets</h2>
          <p>
            Canadian operators contend with rapid freeze-thaw cycles, coastal
            storms, and shifting wildfire patterns. Purpose-built resilience
            diagnostics highlight where systems bend and how to keep them online.
          </p>
        </header>
        <div className="grid three-up">
          <article className="info-card">
            <h3>Grid Continuity</h3>
            <p>
              Maintain power supply commitments through scenario-based
              redundancy modelling and cross-season response planning.
            </p>
          </article>
          <article className="info-card">
            <h3>Asset Longevity</h3>
            <p>
              Align maintenance windows with environmental exposure profiles to
              extend component life and reduce unplanned outages.
            </p>
          </article>
          <article className="info-card">
            <h3>Stakeholder Assurance</h3>
            <p>
              Demonstrate structured risk governance to communities, utilities,
              and regulators with transparent resilience metrics.
            </p>
          </article>
        </div>
      </section>

      <section className="page-section background-light">
        <div className="container">
          <header className="section-heading">
            <h2>Environmental Risk Factors in Canada</h2>
            <p>
              Every province brings unique stressors. Our geospatial libraries
              pair atmospheric, hydrological, and geotechnical datasets with
              operational telemetry.
            </p>
          </header>
          <div className="grid two-up">
            <div className="content-card">
              <h3>Weather Extremes</h3>
              <ul className="styled-list">
                <li>Atlantic cyclone frequency shifts impacting offshore wind.</li>
                <li>Arctic outflows triggering rapid ice accretion on turbines.</li>
                <li>Heat dome scenarios driving inverter derating in BC.</li>
              </ul>
            </div>
            <div className="content-card">
              <h3>Topographic Exposure</h3>
              <ul className="styled-list">
                <li>Permafrost stability and foundation movement assessments.</li>
                <li>Rockfall and debris flow susceptibility for mountain assets.</li>
                <li>Coastal saline spray mapping for corrosion monitoring.</li>
              </ul>
            </div>
          </div>
          <div className="image-row">
            <ImageCard
              src="https://picsum.photos/seed/wind/520/320"
              alt="Canadian wind turbines under dramatic sky"
            />
            <ImageCard
              src="https://picsum.photos/seed/solarcanada/520/320"
              alt="Solar field with snow coverage in Canada"
            />
            <ImageCard
              src="https://picsum.photos/seed/gridnorth/520/320"
              alt="Microgrid installation in remote northern landscape"
            />
          </div>
        </div>
      </section>

      <section className="page-section container">
        <header className="section-heading">
          <h2>Operational Vulnerability Analysis</h2>
          <p>
            Our models interrogate mechanical, electrical, and digital systems
            to locate critical dependencies before they fail.
          </p>
        </header>
        <div className="grid three-up">
          <article className="info-card">
            <h3>Component Stress Profiling</h3>
            <p>
              Evaluate gearbox loads, blade dynamics, and power electronics
              under simulated gust fronts and extreme temperature swings.
            </p>
          </article>
          <article className="info-card">
            <h3>Control System Resilience</h3>
            <p>
              Map SCADA telemetry gaps, alarm handling, and failover pathways to
              ensure graceful degradation in unstable conditions.
            </p>
          </article>
          <article className="info-card">
            <h3>Supply Chain Sensitivity</h3>
            <p>
              Identify lead-time vulnerabilities for specialized parts and align
              contingency inventories with seasonal risk windows.
            </p>
          </article>
        </div>
      </section>

      <section className="page-section background-dark">
        <div className="container">
          <header className="section-heading light">
            <h2>Resilience Scoring &amp; Reliability Metrics</h2>
            <p>
              Translating complex environmental data into actionable indices
              helps teams track improvements and prioritize investments.
            </p>
          </header>
          <div className="metrics-grid">
            <div className="metric-card">
              <span className="metric-value">0.89</span>
              <p>Adaptive Readiness Index</p>
            </div>
            <div className="metric-card">
              <span className="metric-value">42%</span>
              <p>Projected downtime avoided via pre-emptive controls</p>
            </div>
            <div className="metric-card">
              <span className="metric-value">18</span>
              <p>Scenario pathways aligned with grid operator criteria</p>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section container">
        <header className="section-heading">
          <h2>Engineering Insights for Risk Mitigation</h2>
          <p>
            Recommendations balance practicality with future-ready design to
            secure renewable output under evolving climate stressors.
          </p>
        </header>
        <div className="grid two-up stack-on-mobile">
          <div className="content-card">
            <h3>Actionable Strategies</h3>
            <ul className="styled-list">
              <li>Blade retrofit guidance to manage icing and vibration modes.</li>
              <li>Microgrid islanding protocols for northern community assets.</li>
              <li>Thermal management playbooks for rapid temperature change.</li>
            </ul>
          </div>
          <div className="content-card">
            <h3>Collaborative Implementation</h3>
            <p>
              Cross-disciplinary experts partner with operators, utilities, and
              Indigenous communities to co-develop resilient energy blueprints.
            </p>
            <Link className="inline-link" to="/services">
              Review our methodology
            </Link>
          </div>
        </div>
      </section>

      <section className="page-section background-light">
        <div className="container">
          <header className="section-heading">
            <h2>Resilience Services at a Glance</h2>
            <p>
              Our integrated services combine field data, simulation, and
              scenario planning to bolster clean power reliability.
            </p>
          </header>
          <div className="grid four-up service-cards">
            <article className="service-card">
              <h3>Scenario Playbooks</h3>
              <p>
                Tailored response kits covering severe weather, grid disturbance,
                and remote access constraints.
              </p>
            </article>
            <article className="service-card">
              <h3>Reliability Dashboards</h3>
              <p>
                Real-time resilience KPIs integrating SCADA data and climate
                projections.
              </p>
            </article>
            <article className="service-card">
              <h3>Climate Stress Modelling</h3>
              <p>
                Coupled atmospheric and structural models tuned to site-specific
                exposure across Canada.
              </p>
            </article>
            <article className="service-card">
              <h3>Field Validation</h3>
              <p>
                On-site inspections, instrumentation audits, and commissioning
                support for critical upgrades.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="page-section container">
        <header className="section-heading">
          <h2>Voices from the Renewable Community</h2>
        </header>
        <div className="grid three-up testimonials">
          <figure className="testimonial-card">
            <ImageCard
              src="https://picsum.photos/seed/persona1/120/120"
              alt="Portrait of clean energy director"
            />
            <blockquote>
              “Green Resilience Lab transformed incident logs into proactive
              monitoring. Their clarity keeps our coastal wind fleet prepared.”
            </blockquote>
            <figcaption>Director of Wind Operations, Atlantic Canada</figcaption>
          </figure>
          <figure className="testimonial-card">
            <ImageCard
              src="https://picsum.photos/seed/persona2/120/120"
              alt="Portrait of microgrid manager"
            />
            <blockquote>
              “Their hybrid microgrid assessments blend engineering rigour with
              northern community insight. Implementation has been seamless.”
            </blockquote>
            <figcaption>Energy Program Manager, Northwest Territories</figcaption>
          </figure>
          <figure className="testimonial-card">
            <ImageCard
              src="https://picsum.photos/seed/persona3/120/120"
              alt="Portrait of solar asset manager"
            />
            <blockquote>
              “We rely on their analytics to prioritize upgrades and align with
              regulator expectations on climate resilience.”
            </blockquote>
            <figcaption>Asset Integrity Lead, Prairie Solar Portfolio</figcaption>
          </figure>
        </div>
      </section>

      <section className="page-section background-dark">
        <div className="container">
          <header className="section-heading light">
            <h2>Field Specialists Across Canada</h2>
          </header>
          <div className="grid three-up team-grid">
            <article className="team-card">
              <ImageCard
                src="https://picsum.photos/seed/team1/300/260"
                alt="Engineering specialist in field"
              />
              <h3>Amelia Cho, P.Eng.</h3>
              <p>Lead Structural Engineer, Extreme Weather Adaptation</p>
            </article>
            <article className="team-card">
              <ImageCard
                src="https://picsum.photos/seed/team2/300/260"
                alt="Data scientist in control room"
              />
              <h3>Malik Thompson</h3>
              <p>Data Scientist, Climate Scenario Modelling</p>
            </article>
            <article className="team-card">
              <ImageCard
                src="https://picsum.photos/seed/team3/300/260"
                alt="Field technician in winter"
              />
              <h3>Élodie Gervais</h3>
              <p>Field Resilience Specialist, Northern Microgrids</p>
            </article>
          </div>
        </div>
      </section>

      <section className="page-section container narrow">
        <header className="section-heading">
          <h2>Stay Informed About Renewable Resilience</h2>
          <p>
            Share your work email and we will follow up with curated insights
            relevant to your infrastructure portfolio.
          </p>
        </header>
        <form className="cta-form" onSubmit={handleCtaSubmit}>
          <label htmlFor="cta-email" className="sr-only">
            Work email
          </label>
          <input
            id="cta-email"
            type="email"
            placeholder="you@organization.ca"
            value={ctaEmail}
            onChange={(event) => setCtaEmail(event.target.value)}
            required
          />
          <button type="submit" className="button primary">
            Continue to Contact
          </button>
        </form>
      </section>
    </div>
  );
};

export default Home;