import React, { useEffect } from "react";

const About = () => {
  useEffect(() => {
    document.title = "Company | Green Resilience Lab";
  }, []);

  return (
    <div>
      <section className="page-hero">
        <div className="container narrow">
          <p className="eyebrow">Company</p>
          <h1>Engineering Resilience for Canada&apos;s Clean Energy Future</h1>
          <p>
            Green Resilience Lab unites engineers, geoscientists, and data
            analysts dedicated to safeguarding renewable infrastructure across
            Canada&apos;s diverse climates.
          </p>
        </div>
      </section>

      <section className="page-section container">
        <header className="section-heading">
          <h2>Company Overview</h2>
        </header>
        <div className="content-card">
          <p>
            Founded in Vancouver, Green Resilience Lab operates nationwide,
            partnering with utilities, developers, municipalities, and community
            energy leaders. Our work integrates satellite analytics, field
            instrumentation, and scenario planning to keep power systems ready
            for the unexpected.
          </p>
          <p>
            We curate interdisciplinary teams for each engagement, combining
            field knowledge with advanced modelling to create solutions that are
            both technically rigorous and practical to implement.
          </p>
        </div>
      </section>

      <section className="page-section background-light">
        <div className="container">
          <header className="section-heading">
            <h2>Analytical Methodology</h2>
          </header>
          <div className="grid two-up">
            <div className="content-card">
              <h3>Evidence-Based Workflow</h3>
              <ul className="styled-list">
                <li>Data ingestion from SCADA, satellite, and on-site sensors.</li>
                <li>Probabilistic modelling of environmental stress events.</li>
                <li>Failure mode analysis with prioritization scoring.</li>
                <li>Iterative validation with operator teams.</li>
              </ul>
            </div>
            <div className="content-card">
              <h3>Continuous Improvement</h3>
              <p>
                Each engagement closes with a resilience roadmap and monitoring
                cadence. We support periodic updates to ensure scenarios reflect
                emerging climate signals and operational changes.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section container">
        <header className="section-heading">
          <h2>Engineering Expertise</h2>
        </header>
        <div className="grid three-up">
          <article className="info-card">
            <h3>Structural Dynamics</h3>
            <p>
              Specialists evaluate foundations, blades, racking, and supporting
              civil works under cross-seasonal loads and fatigue cycles.
            </p>
          </article>
          <article className="info-card">
            <h3>Electrical Systems</h3>
            <p>
              Power engineers map fault tolerances, protection coordination, and
              grid harmonics to strengthen ride-through capability.
            </p>
          </article>
          <article className="info-card">
            <h3>Data Science</h3>
            <p>
              Our analysts develop machine learning models that detect anomaly
              patterns, predict stress accumulation, and optimize maintenance.
            </p>
          </article>
        </div>
      </section>

      <section className="page-section background-light">
        <div className="container">
          <header className="section-heading">
            <h2>Focus on the Canadian Climate</h2>
            <p>
              From Atlantic storms to Arctic cold snaps, our team understands
              the intricacies of Canada&apos;s climate diversity.
            </p>
        </header>
          <div className="content-card">
            <ul className="styled-list">
              <li>
                Regional climate libraries developed with Environment and Climate
                Change Canada datasets.
              </li>
              <li>
                Collaboration with Indigenous guardians monitoring environmental
                shifts in remote communities.
              </li>
              <li>
                Integration of wildfire, permafrost, and hydrological modelling
                to inform energy resilience strategies.
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className="page-section container">
        <header className="section-heading">
          <h2>Compliance &amp; Standards Alignment</h2>
        </header>
        <div className="content-card">
          <p>
            Projects map directly to federal and provincial regulatory
            requirements, including CSA, IEEE, and NERC standards. Each report
            documents methodology, datasets, and recommended controls to
            streamline internal review and oversight processes.
          </p>
        </div>
      </section>

      <section className="page-section background-dark">
        <div className="container">
          <header className="section-heading light">
            <h2>Commitment to Sustainable Development</h2>
          </header>
          <div className="content-card light">
            <p>
              Sustainability is embedded in our operations—from low-carbon field
              logistics to knowledge-sharing programs that empower communities.
              Green Resilience Lab contributes expertise to collaborative
              research initiatives advancing resilient net-zero pathways across
              Canada.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;