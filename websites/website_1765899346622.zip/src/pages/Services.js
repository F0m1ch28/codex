import React, { useEffect } from "react";
import { Link } from "react-router-dom";

const Services = ({ activeTab }) => {
  useEffect(() => {
    document.title = "Services | Green Resilience Lab";
  }, []);

  return (
    <div>
      <section className="page-hero services-hero">
        <div className="container">
          <p className="eyebrow">Services</p>
          <h1>Holistic Risk Assessment and Resilience Analysis</h1>
          <p>
            Integrated diagnostics, modelling, and mitigation strategies that
            keep renewable assets stable and adaptive in dynamic Canadian
            climates.
          </p>
          <div className="hero-actions">
            <Link to="/contact" className="button primary">
              Request Renewable Risk Assessment
            </Link>
            <Link to="/company" className="button secondary">
              Meet the Team
            </Link>
          </div>
        </div>
      </section>

      <section
        id="risk"
        className={`page-section container ${
          activeTab === "risk" ? "highlighted-section" : ""
        }`}
      >
        <header className="section-heading">
          <h2>Renewable Infrastructure Risk Assessment</h2>
          <p>
            Identify component-level and systemic vulnerabilities to build
            targeted mitigation programs for solar, wind, and hybrid assets.
          </p>
        </header>
        <div className="grid two-up">
          <div className="content-card">
            <h3>Risk Identification</h3>
            <p>
              Detailed audits of design assumptions, maintenance records, and
              operational history uncover hidden failure modes across turbines,
              PV modules, storage systems, and supporting civil structures.
            </p>
          </div>
          <div className="content-card">
            <h3>Component Vulnerability Analysis</h3>
            <p>
              Finite element models and thermal profiling reveal fatigue,
              corrosion, and electrical stress thresholds, guiding focused
              intervention.
            </p>
          </div>
        </div>
        <div className="grid two-up">
          <div className="content-card">
            <h3>Hybrid System Profiles</h3>
            <p>
              Evaluate the interactions of generation, storage, and microgrid
              controllers to ensure balance-of-system integrity under load
              transitions.
            </p>
          </div>
          <div className="content-card">
            <h3>Failure Probability Mapping</h3>
            <p>
              Geospatial analytics combine soil data, wind regimes, and
              hydrological patterns to map likelihood of outages across service
              territories.
            </p>
          </div>
        </div>
      </section>

      <section
        id="resilience"
        className={`page-section background-light ${
          activeTab === "resilience" ? "highlighted-section" : ""
        }`}
      >
        <div className="container">
          <header className="section-heading">
            <h2>Resilience Analysis &amp; Climate Modelling</h2>
            <p>
              Stress testing for the full life-cycle of renewable assets ensures
              systems respond gracefully to both acute events and chronic trends.
            </p>
          </header>
          <div className="grid two-up">
            <div className="content-card">
              <h3>Climate Resilience Modelling</h3>
              <p>
                Downscaled climate projections feed mechanical and electrical
                simulations to forecast performance under future weather
                scenarios.
              </p>
            </div>
            <div className="content-card">
              <h3>Stress Response Evaluation</h3>
              <p>
                Evaluate islanding capability, black-start readiness, and control
                system failover routines through scenario exercises with asset
                operators.
              </p>
            </div>
          </div>
          <div className="grid two-up">
            <div className="content-card">
              <h3>Redundancy Assessment</h3>
              <p>
                Determine optimal redundancy strategies across generation,
                storage, and communication channels to maintain power delivery.
              </p>
            </div>
            <div className="content-card">
              <h3>Adaptive Capacity Metrics</h3>
              <p>
                Quantify adaptability through indices covering response time,
                spare capacity, and recovery trajectories to inform investment
                priorities.
              </p>
            </div>
          </div>
          <div className="content-card">
            <h3>Long-Term Stability Indicators</h3>
            <p>
              We track leading indicators of degradation, including oscillation
              patterns, grounding integrity, and software patch cadence, forming
              a forward-looking resilience dashboard.
            </p>
          </div>
        </div>
      </section>

      <section
        id="exposure"
        className={`page-section container ${
          activeTab === "exposure" ? "highlighted-section" : ""
        }`}
      >
        <header className="section-heading">
          <h2>Environmental Exposure Intelligence</h2>
          <p>
            Understand the environmental fingerprint of each site to align
            infrastructure hardening and maintenance programs.
          </p>
        </header>
        <div className="grid two-up">
          <div className="content-card">
            <h3>Multi-Vector Load Analysis</h3>
            <p>
              Evaluate wind shear, temperature swings, icing, albedo, and solar
              irradiance variation tailored to each province and territory.
            </p>
          </div>
          <div className="content-card">
            <h3>Site-Specific Profiles</h3>
            <p>
              Rapid exposure reports draw on lidar, remote sensing, and existing
              survey data to establish operational guardrails for crews.
            </p>
          </div>
        </div>
        <div className="content-card">
          <h3>Regional Climate Patterns</h3>
          <p>
            National datasets and Indigenous knowledge inform regionally
            calibrated forecasts, accounting for ocean oscillations, jet stream
            shifts, and wildfire smoke dynamics.
          </p>
        </div>
        <div className="content-card">
          <h3>Impact Forecasting</h3>
          <p>
            Seasonal outlooks incorporate ENSO phases, polar vortex behaviour,
            and hydrological projections, delivering foresight for maintenance
            scheduling and procurement.
          </p>
        </div>
      </section>

      <section
        id="applications"
        className={`page-section background-light ${
          activeTab === "applications" ? "highlighted-section" : ""
        }`}
      >
        <div className="container">
          <header className="section-heading">
            <h2>Applications Across Canada</h2>
            <p>
              Tailored engagements for utility-scale installations, industrial
              campuses, remote communities, and hybrid energy systems.
            </p>
          </header>
          <div className="grid two-up stack-on-mobile">
            <div className="content-card">
              <h3>Utility-Scale Renewable Assets</h3>
              <p>
                Integrated resilience roadmaps for large wind and solar farms,
                aligning with ISO and provincial grid requirements.
              </p>
            </div>
            <div className="content-card">
              <h3>Industrial Clean Energy Sites</h3>
              <p>
                Support for industrial decarbonization projects with combined
                heat and power, hydrogen-ready systems, and storage components.
              </p>
            </div>
          </div>
          <div className="grid two-up stack-on-mobile">
            <div className="content-card">
              <h3>Remote &amp; Northern Installations</h3>
              <p>
                Microgrid design reviews, logistics planning, and resilience
                exercises for remote communities and resource operations.
              </p>
            </div>
            <div className="content-card">
              <h3>Hybrid Systems</h3>
              <p>
                Multi-source integrations combining wind, solar, hydro, and
                storage to ensure stable operation during rapid load changes.
              </p>
            </div>
          </div>
          <div className="content-card">
            <h3>Regional Case Spotlights</h3>
            <ul className="styled-list">
              <li>Offshore wind resilience strategies for Atlantic Canada.</li>
              <li>Wildfire smoke readiness plans for BC solar arrays.</li>
              <li>Cold climate battery systems for Prairie storage projects.</li>
              <li>Permafrost foundation monitoring for Arctic microgrids.</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;