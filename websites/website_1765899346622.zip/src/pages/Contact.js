import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const Contact = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: ""
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle");

  useEffect(() => {
    document.title = "Contact | Green Resilience Lab";
  }, []);

  useEffect(() => {
    if (location.state && location.state.email) {
      setFormData((prev) => ({ ...prev, email: location.state.email }));
    }
  }, [location.state]);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Please provide your name.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Please provide your email address.";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email.trim())
    ) {
      newErrors.email = "Enter a valid email address.";
    }
    if (!formData.company.trim()) {
      newErrors.company = "Please provide your organization.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Share a brief description of your objectives.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      return;
    }
    setStatus("loading");
    setTimeout(() => {
      setStatus("success");
      navigate("/thanks");
    }, 900);
  };

  return (
    <div>
      <section className="page-hero contact-hero">
        <div className="container narrow">
          <p className="eyebrow">Contact</p>
          <h1>Request Renewable Risk Assessment</h1>
          <p>
            Share your objectives and our specialists will coordinate a session
            tailored to your infrastructure portfolio.
          </p>
        </div>
      </section>

      <section className="page-section container contact-section">
        <div className="contact-grid">
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Name*</label>
              <input
                id="name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? "name-error" : undefined}
              />
              {errors.name && (
                <span className="field-error" id="name-error">
                  {errors.name}
                </span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="email">Email*</label>
              <input
                id="email"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? "email-error" : undefined}
              />
              {errors.email && (
                <span className="field-error" id="email-error">
                  {errors.email}
                </span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="company">Company*</label>
              <input
                id="company"
                type="text"
                name="company"
                value={formData.company}
                onChange={handleChange}
                aria-invalid={Boolean(errors.company)}
                aria-describedby={errors.company ? "company-error" : undefined}
              />
              {errors.company && (
                <span className="field-error" id="company-error">
                  {errors.company}
                </span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="message">Message*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? "message-error" : undefined}
              />
              {errors.message && (
                <span className="field-error" id="message-error">
                  {errors.message}
                </span>
              )}
            </div>
            <button
              type="submit"
              className="button primary full-width"
              disabled={status === "loading"}
            >
              {status === "loading" ? "Sending..." : "Submit Request"}
            </button>
          </form>
          <div className="contact-details">
            <div className="content-card">
              <h2>Direct Contact</h2>
              <p>
                The Stack – Vancouver, 1133 Melville Street, Floor 18, Vancouver,
                British Columbia, Canada
              </p>
              <p>
                Phone: <a href="tel:+16043439186">+1 604 343 9186</a>
              </p>
              <p>
                Email:{" "}
                <a href="mailto:info@greenresiliencelab.com">
                  info@greenresiliencelab.com
                </a>
              </p>
            </div>
            <div className="content-card">
              <h2>Visit Us</h2>
              <div className="map-wrapper">
                <iframe
                  title="Green Resilience Lab Vancouver Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2605.228037375322!2d-123.12310562337487!3d49.28752237139262!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54867180e1a1cf8f%3A0xe5c476f51f2e3925!2s1133%20Melville%20St%20%2318%2C%20Vancouver%2C%20BC%20V6E%206E4%2C%20Canada!5e0!3m2!1sen!2sca!4v1699999999999!5m2!1sen!2sca"
                  width="100%"
                  height="260"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;