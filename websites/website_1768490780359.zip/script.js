document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            const isOpen = navLinks.classList.toggle('is-open');
            navToggle.classList.toggle('is-active', isOpen);
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('abbeyuuvnCookieChoice');
        if (storedChoice) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const choice = button.getAttribute('data-cookie-choice');
                localStorage.setItem('abbeyuuvnCookieChoice', choice);
                cookieBanner.classList.add('is-hidden');
                const policyLink = button.getAttribute('data-link');
                if (policyLink) {
                    window.open(policyLink, '_blank', 'noopener');
                }
            });
        });
    }

    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    if (animatedElements.length) {
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        animatedElements.forEach(function (element) {
            observer.observe(element);
        });
    }

    document.querySelectorAll('.faq-item button').forEach(function (button) {
        button.addEventListener('click', function () {
            const parent = button.closest('.faq-item');
            parent.classList.toggle('open');
        });
    });
});