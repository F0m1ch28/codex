document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const nav = document.getElementById('primary-navigation');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAcceptBtn = document.getElementById('cookieAccept');
    const currentYearEl = document.getElementById('currentYear');

    if (navToggle && nav) {
        navToggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                scrollBtn.classList.add('show');
            } else {
                scrollBtn.classList.remove('show');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAcceptBtn) {
        const consent = localStorage.getItem('ddaCookiesAccepted');
        if (consent === 'true') {
            cookieBanner.style.display = 'none';
        }

        cookieAcceptBtn.addEventListener('click', () => {
            localStorage.setItem('ddaCookiesAccepted', 'true');
            cookieBanner.style.display = 'none';
        });
    }

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }
});