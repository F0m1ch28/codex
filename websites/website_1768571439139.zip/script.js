document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navMenu.classList.toggle('is-open');
        });

        navMenu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                navMenu.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const storageKey = 'trainiwcjc-cookie-consent';

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(storageKey);
        if (!storedConsent) {
            cookieBanner.classList.add('is-visible');
        }

        const handleConsent = function (value) {
            localStorage.setItem(storageKey, value);
            cookieBanner.classList.remove('is-visible');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                handleConsent('accepted');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', function () {
                handleConsent('declined');
            });
        }
    }
});