import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialFormState = {
  name: '',
  email: '',
  company: '',
  message: '',
};

function Contact() {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please provide your full name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide a valid email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Email format is invalid.';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Please include a brief description of your needs.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors((prev) => {
        const updated = { ...prev };
        delete updated[name];
        return updated;
      });
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setIsSubmitted(true);
    setFormData(initialFormState);
  };

  return (
    <>
      <Helmet>
        <title>Contact TechSolutions | Start Your Cloud Transformation</title>
        <meta
          name="description"
          content="Contact TechSolutions to discuss cloud strategy, modernization, or digital transformation initiatives. We respond within one business day."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="layout">
          <div className={styles.heroContent}>
            <h1>We’re ready to guide your next transformation.</h1>
            <p>
              Share your goals and challenges, and our consultants will follow up within one business day to explore how we can help.
            </p>
            <div className={styles.contactDetails}>
              <p><strong>Phone:</strong> <a href="tel:+15551234567">+1 (555) 123-4567</a></p>
              <p><strong>Email:</strong> <a href="mailto:info@techsolutions.com">info@techsolutions.com</a></p>
              <p><strong>Address:</strong> 123 Innovation Street, Tech Park, San Francisco, CA 94105</p>
            </div>
          </div>
          <div className={styles.formCard}>
            <h2>Send us a message</h2>
            {isSubmitted && (
              <div className={styles.success} role="status">
                Thank you for reaching out. Our team will respond shortly.
              </div>
            )}
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label>
                Full name *
                <input
                  type="text"
                  name="name"
                  placeholder="Jane Doe"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={!!errors.name}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </label>
              <label>
                Work email *
                <input
                  type="email"
                  name="email"
                  placeholder="jane.doe@company.com"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </label>
              <label>
                Company
                <input
                  type="text"
                  name="company"
                  placeholder="Company name"
                  value={formData.company}
                  onChange={handleChange}
                />
              </label>
              <label>
                How can we help? *
                <textarea
                  name="message"
                  rows="5"
                  placeholder="Tell us about your current initiatives, timelines, and success criteria."
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={!!errors.message}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </label>
              <button type="submit">Submit inquiry</button>
            </form>
          </div>
        </div>
      </section>

      <section className={styles.mapSection}>
        <div className="layout">
          <h2>Visit our headquarters</h2>
          <div className={styles.mapContainer}>
            <iframe
              title="TechSolutions San Francisco Office Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.180490662046!2d-122.39630812330266!3d37.789742912042406!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064a5b5c9e5%3A0x9edd0d99f0ff2ed3!2s123%20Innovation%20St%2C%20San%20Francisco%2C%20CA%2094105!5e0!3m2!1sen!2sus!4v1700000000000!5m2!1sen!2sus"
              width="600"
              height="450"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;