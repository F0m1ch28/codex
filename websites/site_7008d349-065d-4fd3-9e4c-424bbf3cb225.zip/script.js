const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const CONSENT_KEY = "cookie_consent";

const I18N = {
  fr: {
    meta: {
      index: {
        title: "danswholesaleplants — Orientation spatiale et signalétique numérique",
        description: "Études, cartographie et recommandations pour la navigation intérieure, la signalétique numérique et la mobilité piétonne au sein d’environnements publics complexes."
      },
      services: {
        title: "Services analytiques — danswholesaleplants",
        description: "Cadres méthodologiques pour analyser l’orientation spatiale, concevoir des systèmes de signalétique numérique et cartographier les parcours utilisateurs dans les bâtiments publics."
      },
      about: {
        title: "À propos de danswholesaleplants",
        description: "Mission, valeurs et feuille de route de danswholesaleplants : une équipe dédiée à l’analyse des flux, à la lisibilité des environnements bâtis et au design informationnel."
      },
      blog: {
        title: "Carnet d’études — danswholesaleplants",
        description: "Articles techniques sur l’orientation spatiale, la signalétique numérique, la navigation intérieure et la cartographie des espaces complexes en Belgique."
      },
      post1: {
        title: "Évaluer les écosystèmes de signalétique numérique multimodale",
        description: "Cadres méthodologiques pour diagnostiquer les hubs multimodaux, corréler supports analogiques et numériques et orchestrer la chorégraphie des correspondances."
      },
      post2: {
        title: "Concevoir des récits d’orientation inclusifs pour les bâtiments civiques",
        description: "Méthodes pour cartographier intentions des parties prenantes, créer un lexique partagé et orchestrer médias analogiques et numériques dans les équipements civiques."
      },
      post3: {
        title: "Harmoniser les données spatiales pour les cartes de campus interactives",
        description: "Audits taxonomiques, gouvernance des métadonnées et design adaptatif pour cartographier les campus et soutenir la navigation multi-profils."
      },
      post4: {
        title: "Guidage visuel adaptatif dans les districts urbains complexes",
        description: "Observation des micro-géographies urbaines, scripts temporels et systèmes lumineux réactifs pour maintenir la lisibilité des espaces denses."
      },
      post5: {
        title: "Mesurer la réaction des flux piétons à la signalétique dynamique",
        description: "Cadre de mesure combinant analytics, observation ethnographique et modélisation pour évaluer l’impact des contenus dynamiques."
      },
      contact: {
        title: "Coordonnées et carte — danswholesaleplants",
        description: "Contacter danswholesaleplants, planifier un échange et découvrir l’adresse Rue de la Loi 200 à Bruxelles sur carte interactive."
      },
      faq: {
        title: "Questions fréquentes — danswholesaleplants",
        description: "Réponses sur l’analyse de signalétique, la cartographie des parcours et la gouvernance des données spatiales."
      },
      terms: {
        title: "Conditions d’utilisation — danswholesaleplants",
        description: "Cadre juridique encadrant l’utilisation des contenus, des recherches et des publications diffusées par danswholesaleplants."
      },
      privacy: {
        title: "Politique de confidentialité — danswholesaleplants",
        description: "Collecte de données, bases légales, conservation et droits des personnes concernant les analyses de danswholesaleplants."
      },
      cookies: {
        title: "Politique relative aux cookies — danswholesaleplants",
        description: "Description des cookies nécessaires et facultatifs utilisés sur danswholesaleplants.com et modalités de gestion des préférences."
      },
      refund: {
        title: "Politique de révision — danswholesaleplants",
        description: "Processus de révision des engagements analytiques, critères d’éligibilité et canaux d’escalade pour les collaborations."
      },
      disclaimer: {
        title: "Avis de non-responsabilité — danswholesaleplants",
        description: "Limites de responsabilité, absence de garantie et usage informatif des analyses publiées par danswholesaleplants."
      },
      thankYou: {
        title: "Merci pour votre message — danswholesaleplants",
        description: "Confirmation de réception et prochaines étapes après l’envoi du formulaire de contact."
      },
      notFound: {
        title: "Page introuvable — danswholesaleplants",
        description: "La ressource demandée est indisponible. Naviguez vers une autre section du site."
      }
    },
    brand: {
      name: "danswholesaleplants",
      tagline: "Orientation spatiale et signalétique numérique"
    },
    nav: {
      home: "Accueil",
      services: "Services",
      about: "À propos",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    },
    header: {
      menuLabel: "Menu",
      menuToggle: "Basculer la navigation"
    },
    buttons: {
      explore: "Explorer les cadres d’orientation",
      methodology: "Consulter l’approche méthodologique",
      viewServices: "Voir la synthèse des services",
      contact: "Accéder aux coordonnées",
      readArticle: "Lire l’article",
      backToBlog: "Retour au blog",
      home: "Retour à l’accueil"
    },
    footer: {
      description: "danswholesaleplants recueille, structure et partage des connaissances opérationnelles pour les environnements bâtis complexes.",
      addressLabel: "Adresse",
      address: "Rue de la Loi 200, 1040 Bruxelles, Belgique",
      phoneLabel: "Téléphone",
      phoneNumber: "+32 2 123 45 67",
      emailLabel: "Courriel",
      emailAddress: "contact@danswholesaleplants.com",
      rights: "© {{year}} danswholesaleplants. Tous droits réservés.",
      legal: {
        terms: "Conditions d’utilisation",
        privacy: "Confidentialité",
        cookies: "Cookies",
        refund: "Politique de révision",
        disclaimer: "Avis de non-responsabilité"
      }
    },
    index: {
      hero: {
        title: "Intelligence d’orientation spatiale pour environnements publics",
        subtitle: "Nous cartographions la manière dont les usagers décodent les bâtiments et districts complexes, afin de synchroniser signalétique, médias numériques et architecture. Chaque recommandation naît d’observations in situ, de modélisations de flux et de protocoles de test itératifs.",
        button: "Explorer les cadres d’orientation",
        secondary: "Consulter l’approche méthodologique",
        note: "Des cycles d’observation continus alimentent chaque scénario de guidage.",
        imageAlt: "Visualisation numérique d’un hub multimodal avec signalétique lumineuse",
        stats: {
          s1: {
            value: "38",
            label: "audits spatiaux menés dans des hubs civiques belges"
          },
          s2: {
            value: "24",
            label: "protocoles d’évaluation itérative maintenus"
          },
          s3: {
            value: "12",
            label: "laboratoires urbains suivis chaque année"
          }
        }
      },
      featured: {
        heading: "Analyse systémique des bâtiments complexes",
        intro: "Les environnements publics superposent dispositifs physiques et numériques. Notre travail consiste à comprendre leur complémentarité pour réaliser des recommandations fondées sur l’usage réel.",
        cards: {
          c1: {
            title: "Strates diagnostiques",
            text: "Cartographier les expériences vécues pour identifier les concordances et contradictions entre repères physiques et écrans.",
            list: "<li>Inventaires multisensoriels le long des parcours</li><li>Détection des conflits analogiques / numériques</li><li>Matrice de priorisation des zones critiques</li>"
          },
          c2: {
            title: "Modélisation des interactions",
            text: "Simuler les décisions clés afin de mesurer la charge cognitive imposée aux usagers dans des contextes changeants.",
            list: "<li>Cartes de décision et points de friction</li><li>Scripts temporels par périodes d’affluence</li><li>Couplage des flux piétons et des supports médias</li>"
          },
          c3: {
            title: "Orchestration de l’accessibilité",
            text: "Intégrer diversité linguistique et besoins spécifiques pour garantir une lisibilité partagée de l’espace.",
            list: "<li>Tests multilingues et niveaux de lecture</li><li>Guidage haptique, lumineux et sonore coordonné</li><li>Plans de maintenance orientés usager</li>"
          }
        }
      },
      method: {
        heading: "Architecture méthodologique",
        intro: "Chaque mission suit une séquence reproductible qui articule observation, modélisation et gouvernance.",
        steps: {
          step1: {
            title: "Observation immersive",
            text: "Parcours guidés, vidéos et capteurs pour comprendre les comportements et perceptions in situ."
          },
          step2: {
            title: "Synthèse des cartes mentales",
            text: "Traduction des observations en matrices décisionnelles et récits d’orientation partagés."
          },
          step3: {
            title: "Prototypage de scénarios",
            text: "Expérimentations numériques et analogiques synchronisées avec les équipes opérationnelles."
          },
          step4: {
            title: "Boucles d’évidence",
            text: "Tableaux de bord, revues trimestrielles et ajustements continus basés sur des indicateurs vérifiables."
          }
        }
      },
      recommendations: {
        heading: "Recommandations pour la gouvernance de l’orientation",
        intro: "Nos recommandations condensent des pratiques éprouvées pour entretenir la lisibilité des espaces.",
        cards: {
          r1: {
            title: "Documenter un système vivant",
            text: "Centraliser plans, métadonnées et retours usagers afin que toute évolution soit traçable et expliquée."
          },
          r2: {
            title: "Garantir la parité multilingue",
            text: "Synchroniser textes, pictogrammes et annonces audio pour éviter la hiérarchisation involontaire des publics."
          },
          r3: {
            title: "Programmer les répétitions",
            text: "Planifier des revues régulières de scénarios pour tester les plans d’urgence, les saisons et les événements."
          }
        }
      },
      testimonials: {
        heading: "Témoignages de terrain",
        intro: "Partenaires et institutions décrivent l’impact des démarches coordonnées.",
        cards: {
          t1: {
            quote: "« La cartographie croisée des flux et des contenus numériques a mis en lumière des contradictions invisibles. Les recommandations étaient immédiatement actionnables par nos équipes techniques. »",
            author: "Élise Lambert",
            role: "Responsable mobilité urbaine, Ville de Namur"
          },
          t2: {
            quote: "« Les ateliers multilingues ont permis de clarifier notre lexique tout en conservant les obligations réglementaires. Les visiteurs se sentent désormais orientés plus rapidement. »",
            author: "Koen Van Hove",
            role: "Coordinateur accueil, Maison administrative de Gand"
          },
          t3: {
            quote: "« Les scripts temporels co-construits servent aujourd’hui de référence pour chaque évènement majeur. Les équipes sécurité et culture parlent enfin le même langage. »",
            author: "Samira Chakar",
            role: "Programmation culturelle, Quartier des Arts"
          }
        }
      },
      insights: {
        heading: "Veille active",
        intro: "Constats récents qui guident nos analyses.",
        points: {
          p1: "La lisibilité spatiale progresse lorsque les verbes d’action sont cohérents entre supports analogiques et numériques.",
          p2: "Les plans interactifs gagnent en confiance lorsqu’ils affichent la fraîcheur des données et invitent aux retours d’expérience.",
          p3: "Les tests sensoriels nocturnes révèlent plus d’écarts de perception que les audits en horaires diurnes chargés."
        }
      },
      closing: {
        heading: "Aligner stratégies d’orientation et opérations",
        text: "Nous facilitons la mise en cohérence des équipes architecture, exploitation et communication autour d’indicateurs partagés.",
        button: "Voir la synthèse des services"
      }
    },
    services: {
      hero: {
        title: "Services analytiques pour l’orientation spatiale",
        subtitle: "Nous investiguons les espaces publics, bâtiments institutionnels et infrastructures urbaines pour proposer des cadres décisionnels robustes. Les livrables servent à coordonner signalétique physique, interfaces numériques et flux opérationnels.",
        button: "Accéder aux coordonnées",
        imageAlt: "Plan numérique interactif affiché sur une table tactile"
      },
      intro: {
        heading: "Périmètre d’intervention",
        text: "Nos services couvrent l’audit des environnements bâtis, la conception de parcours, la gouvernance des données spatiales et la préparation de scénarios d’urgence. Chaque mission combine analyse qualitative et mesures instrumentées."
      },
      list: {
        heading: "Volets d’étude",
        analysis: {
          title: "Analyse des défis d’orientation",
          text: "Identification des zones de confusion, cartographie des conflits de signaux et recommandations de priorisation.",
          list: "<li>Inventaires détaillés des supports et contenus</li><li>Métriques de lisibilité et charge cognitive</li><li>Cartes synthétiques des points de friction</li>"
        },
        wayfinding: {
          title: "Conception de signalétique numérique",
          text: "Définition de principes éditoriaux et scénographies digitales adaptées aux comportements observés.",
          list: "<li>Scripts temporels et playlists modulaires</li><li>Architecture d’information multilingue</li><li>Prototypage d’interfaces et tests utilisateurs</li>"
        },
        journeys: {
          title: "Cartographie des parcours utilisateurs",
          text: "Formalisation des séquences de déplacements et des décisions clés pour chaque profil d’usager.",
          list: "<li>Personae et récits d’orientation</li><li>Matrice des besoins contextuels</li><li>Tableaux de bord de suivi longitudinal</li>"
        },
        information: {
          title: "Design informationnel",
          text: "Structuration des contenus et harmonisation des messages entre supports analogiques et numériques.",
          list: "<li>Lexiques partagés et guides rédactionnels</li><li>Grammaire visuelle et iconographique</li><li>Plans de gouvernance éditoriale</li>"
        },
        mobility: {
          title: "Recherche sur la mobilité piétonne",
          text: "Mesure des flux, scénarios de dispersion et modélisation des réponses à la signalétique dynamique.",
          list: "<li>Protocoles de comptage multi-capteurs</li><li>Analyses de résilience et capacités</li><li>Recommandations d’exploitation et scénarios</li>"
        }
      },
      approach: {
        heading: "Principes d’approche",
        text: "Chaque démarche privilégie la transparence méthodologique et une documentation exploitable par toutes les parties prenantes.",
        items: {
          i1: "Co-analyse avec les équipes d’exploitation et de terrain",
          i2: "Validation régulière grâce à des prototypes et tests ciblés",
          i3: "Traçabilité des décisions et mesures d’impact"
        }
      },
      outcomes: {
        heading: "Composants livrés",
        cards: {
          c1: {
            title: "Dossiers d’intelligence spatiale",
            text: "Synthèses visuelles, matrices décisionnelles et cartographies annotées des espaces étudiés."
          },
          c2: {
            title: "Prototypes interactifs",
            text: "Maquettes fonctionnelles de signalétique numérique, scénarios d’écrans et guides d’implémentation."
          },
          c3: {
            title: "Playbooks de gouvernance",
            text: "Procédures, indicateurs et calendriers de revue pour maintenir la performance des dispositifs."
          }
        }
      },
      callout: {
        heading: "Coordonner un diagnostic partagé",
        text: "Nous organisons des sessions de cadrage pour aligner objectifs, contraintes et métriques de réussite avant tout déploiement.",
        button: "Accéder aux coordonnées"
      }
    },
    about: {
      hero: {
        title: "Une fabrique de lisibilité spatiale",
        subtitle: "danswholesaleplants associe analyse de données, observation de terrain et design informationnel pour rendre les environnements bâtis intelligibles.",
        imageAlt: "Équipe analysant des plans et données cartographiques"
      },
      mission: {
        heading: "Mission",
        text: "Permettre aux institutions publiques et organisations urbaines de comprendre la manière dont leurs espaces sont vécus, afin de concevoir des parcours clairs, inclusifs et adaptables."
      },
      values: {
        heading: "Valeurs structurantes",
        intro: "Nos engagements guident chaque collaboration et garantissent la fiabilité des recommandations.",
        cards: {
          c1: {
            title: "Preuve avant intuition",
            text: "Les décisions reposent sur des observations étayées, des métriques comparables et des retours d’expérience."
          },
          c2: {
            title: "Inclure tous les publics",
            text: "Chaque scénario d’orientation est testé auprès de profils variés pour refléter la diversité des usages."
          },
          c3: {
            title: "Empathie opérationnelle",
            text: "Les recommandations tiennent compte des ressources disponibles et des réalités de maintenance."
          }
        }
      },
      timeline: {
        heading: "Feuille de route",
        intro: "Quelques jalons illustrant la maturation de nos approches.",
        steps: {
          s1: {
            year: "2016",
            title: "Observatoires de signalétique",
            text: "Premières immersions dans les gares et musées pour comprendre la perception des repères existants."
          },
          s2: {
            year: "2018",
            title: "Laboratoires urbains",
            text: "Mise en place de programmes pilotes avec des communes belges pour mesurer l’impact de contenus dynamiques."
          },
          s3: {
            year: "2020",
            title: "Plateforme de métadonnées",
            text: "Développement d’outils de gouvernance documentaire pour maintenir des plans interactifs fiables."
          },
          s4: {
            year: "2023",
            title: "Cadres de gouvernance",
            text: "Publication de playbooks partagés par les infrastructures culturelles et de transport partenaires."
          }
        }
      },
      capabilities: {
        heading: "Capacités principales",
        text: "Nous opérons à la croisée de la recherche spatiale, de l’UX et de l’ingénierie opérationnelle.",
        list: "<li>Analyse des flux et modélisation de scénarios</li><li>Design d’information multicanal et prototypage</li><li>Gouvernance des données et accompagnement au changement</li>"
      },
      network: {
        heading: "Réseau et partenariats",
        text: "Collaboration avec des urbanistes, designers de services, sociologues, spécialistes de l’accessibilité et experts en infrastructures numériques pour proposer des réponses complètes."
      },
      callout: {
        heading: "Partager vos enjeux",
        text: "Nous sommes disponibles pour explorer vos défis d’orientation et définir un cadre d’étude adapté.",
        button: "Accéder aux coordonnées"
      }
    },
    blog: {
      hero: {
        title: "Carnet d’études et de veille",
        subtitle: "Analyses approfondies des systèmes d’orientation, du design informationnel et de la mobilité piétonne.",
        imageAlt: "Notebook avec croquis de signalétique et ordinateur portable"
      },
      intro: {
        heading: "Notes techniques",
        text: "Chaque article documente nos méthodes, observations et hypothèses pour éclairer les décideurs sur la transformation des espaces complexes."
      },
      cards: {
        post1: {
          title: "Évaluer les écosystèmes de signalétique numérique multimodale",
          excerpt: "Cadre méthodologique pour analyser les hubs multimodaux, corréler supports analogiques et numériques et orchestrer les correspondances.",
          date: "14 mars 2024"
        },
        post2: {
          title: "Récits d’orientation inclusifs pour bâtiments civiques",
          excerpt: "Comment construire un lexique partagé, orchestrer les médias et instaurer une gouvernance durable dans les équipements civiques.",
          date: "26 février 2024"
        },
        post3: {
          title: "Harmoniser les données spatiales des campus interactifs",
          excerpt: "Audit taxonomique, stewardship des métadonnées et design adaptatif pour fiabiliser les cartes numériques de campus.",
          date: "29 janvier 2024"
        },
        post4: {
          title: "Guidage visuel adaptatif dans les districts urbains",
          excerpt: "Observation des micro-géographies, scénarios temporels et éclairage réactif pour maintenir la lisibilité urbaine.",
          date: "11 décembre 2023"
        },
        post5: {
          title: "Mesurer les réactions aux contenus de signalétique dynamique",
          excerpt: "Méthodes de mesure, fusion de capteurs et interprétation pour piloter les dispositifs dynamiques.",
          date: "23 novembre 2023"
        },
        readMore: "Lire l’article"
      }
    },
    posts: {
      general: {
        back: "Retour au blog",
        readingTime: "Temps de lecture estimé : 9 minutes"
      },
      post1: {
        title: "Évaluer les écosystèmes de signalétique numérique dans les pôles de transport multimodaux",
        meta: "Publié le 14 mars 2024 • 9 minutes de lecture",
        imageAlt: "Vue intérieure d’un hub multimodal avec signalétique numérique",
        lead: "Les pôles de transport multimodaux superposent des couches de signalétique, des bornes numériques, des affichages d’occupation en temps réel et des indices architecturaux. Évaluer la manière dont ces couches interagissent dépasse le simple comptage d’écrans ; il s’agit d’adopter un regard systémique sur la cognition spatiale, la chorégraphie de service et les contraintes environnementales. Chez danswholesaleplants, l’observation longitudinale et la cartographie participative montrent que les usagers interprètent les empilements d’information différemment selon leur mode d’arrivée. Cette étude vise à formaliser des routines d’évaluation respectant ces divergences tout en alignant les équipes opérationnelles sur des preuves mesurables.",
        section1: {
          heading: "Cadre méthodologique pour hubs complexes",
          body: "<p>La structuration méthodologique pour un hub complexe commence par un inventaire des récits spatiaux. Nous segmentons le site en épisodes de navigation, du seuil d’arrivée aux zones d’embarquement, et documentons chaque artefact numérique qui conduit la transition. Chaque artefact est noté selon la clarté, la redondance, la charge sensorielle et le moment de relais. La matrice obtenue met en évidence les zones où les voyageurs rencontrent des signaux concurrents ainsi que les séquences insuffisamment rassurantes. Croiser la matrice avec les analytics de temps de stationnement offre une base objectivée avant toute hypothèse de refonte.</p><p>Les inventaires quantitatifs restent incomplets sans profondeur qualitative. Nos équipes organisent des parcours guidés avec des profils variés : navetteurs familiers des raccourcis, visiteurs confrontés aux barrières linguistiques et équipes de maintenance poussant du matériel. Les récits recueillis sont encodés par balisage sémantique et renvoyés vers la matrice d’inventaire. Ce croisement révèle les points de friction causés par le jargon, l’ambiguïté des pictogrammes ou des messages sonores mal synchronisés. Il identifie aussi les segments où l’architecture guide déjà efficacement l’orientation, évitant des ajouts numériques superflus.</p>",
          subheading: "Matrices de corrélation des éléments de guidage",
          subbody: "<p>Les matrices de corrélation comparent le comportement de la signalétique numérique aux supports analogiques et mesurent quelles combinaisons réduisent le temps d’hésitation. Une carte dynamique accessible par QR code atteint par exemple son efficacité maximale lorsqu’elle est associée à des flèches au sol qui incitent au scan. Sans amorce analogique, l’usage s’effondre malgré une résolution d’écran élevée. Capturer ces dépendances permet aux exploitants de planifier des interventions coordonnées plutôt que de remplacer des actifs isolément.</p><p>Nous intégrons ensuite les journaux de maintenance et les rapports d’incidents. Les éléments nécessitant des réinitialisations fréquentes reçoivent un coefficient de résilience afin que l’évaluation intègre la charge opérationnelle. En corrélant la résilience aux scores de rassurance recueillis auprès des usagers, les planificateurs peuvent justifier le maintien de supports simples et peu coûteux à exploiter dans les carrefours critiques. La matrice devient ainsi un espace de négociation entre ambition numérique et pragmatisme infrastructurel.</p>"
        },
        section2: {
          heading: "Couches de communication contextuelles",
          body: "<p>Les couches contextuelles considèrent la fluctuation des besoins d’information au fil de la journée. Les pointes matinales privilégient la vitesse de transfert tandis que les soirées tardives réclament de la rassurance et des rappels de sécurité personnelle. Nous projetons ces priorités sur une horloge de communication sur 24 heures qui décrit la séquence des contenus diffusés sur les panneaux numériques. L’horloge régit également la rotation multilingue afin d’adapter les messages au groupe linguistique dominant sans saturer les écrans.</p><p>Les variables environnementales telles que la lumière naturelle, la réverbération acoustique et la densité de foule nourrissent la même couche. Un couloir inondé de lumière peut rendre certaines palettes inefficaces, tandis qu’un quai bruyant annihile les annonces audio. Nous annotons chaque point critique avec des seuils sensoriels pour que les concepteurs de contenus sachent quand privilégier des visuels à fort contraste, des signaux lumineux dynamiques ou des indicateurs tactiles intégrés aux mains courantes.</p>",
          subheading: "Chorégraphie des correspondances",
          subbody: "<p>La chorégraphie des correspondances désigne le chemin orchestré entre les modes. Nous analysons les rayons de braquage et les points de décision, puis les alignons sur des déclencheurs de contenu. Si les passagers doivent choisir entre escaliers et ascenseurs en trois secondes, le message numérique précédent doit préparer ce choix en annonçant la disponibilité des ascenseurs plus tôt dans l’approche. La chorégraphie garantit ainsi que les points de contact numériques ne soient pas décoratifs mais anticipatifs.</p><p>Lors des pilotes, nous suivons les micro-interactions via des capteurs discrets qui consignent les changements de direction et les ancrages de regard. Ces données révèlent si les voyageurs enregistrent réellement le guidage ou s’ils reviennent à un comportement de troupeau. Lorsque les signaux de foule dominent, nous enrichissons la chorégraphie par des projections au sol ou un éclairage cinétique qui prolonge le message numérique dans la vision périphérique.</p>"
        },
        section3: {
          heading: "Mesurer l’impact et itérer",
          body: "<p>L’évaluation de l’impact dépasse le simple comptage des requêtes d’orientation réussies. Nous suivons la variance des temps de correspondance, les niveaux de stress perçus lors d’entretiens in situ et le nombre d’interventions du personnel. La combinaison de ces indicateurs produit un indice composite de qualité de navigation. Son évolution durable confirme si l’écosystème numérique réduit la charge cognitive ou s’il ajoute seulement de la nouveauté.</p><p>Les cycles d’itération sont programmés trimestriellement en synchronisation avec les fenêtres de maintenance. Chaque cycle comporte un carnet d’hypothèses issu des récits utilisateurs, des anomalies analytiques et des observations saisonnières. Nous prototypons les séquences dans un environnement de simulation reproduisant la géométrie du hub. Les opérateurs peuvent répéter des scénarios de perturbation, tester des extensions multilingues et anticiper la prise en main des messages d’urgence.</p>",
          subheading: "Axes de recherche à prolonger",
          subbody: "<p>Les prolongements de recherche explorent l’intégration de capteurs adaptatifs capables de moduler luminosité et densité de contenu en temps réel. Nous étudions également comment les applications de mobilité personnelle pourraient échanger des signaux anonymisés avec la signalétique de station afin que les playlists s’adaptent aux flux dominants tout en respectant les lignes directrices sur la vie privée.</p><p>Un autre axe concerne la gouvernance collaborative. En considérant l’écosystème comme un service partagé entre autorités de transport, commerçants et acteurs urbains, la planification des ressources devient collective plutôt que cloisonnée. Les protocoles d’évaluation doivent dès lors rester transparents, explicables et fondés sur des preuves que les parties prenantes de l’urbanisme, des opérations et de l’accessibilité peuvent examiner. C’est à cette condition que les hubs multimodaux pourront évoluer sans désorienter les publics qu’ils servent.</p>"
        }
      },
      post2: {
        title: "Concevoir des récits d’orientation inclusifs pour les bâtiments civiques",
        meta: "Publié le 26 février 2024 • 9 minutes de lecture",
        imageAlt: "Signalétique numérique dans un bâtiment civique",
        lead: "Les bâtiments civiques réunissent guichets administratifs, programmations culturelles et événements communautaires sous un même toit. Les visiteurs n’y poursuivent pas les mêmes objectifs, et leurs cartes mentales varient selon leur familiarité avec le vocabulaire institutionnel. Les plans traditionnels peinent à répondre à ces divergences, surtout lorsque des couches numériques sont ajoutées sans fil narratif. Notre exploration se concentre sur des récits de navigation inclusifs, capables d’orienter les usagers occasionnels sans les exclure tout en offrant la profondeur nécessaire aux spécialistes utilisant les circulations techniques.",
        section1: {
          heading: "Cartographier les intentions des parties prenantes",
          body: "<p>Un récit inclusif commence par la définition des intentions de l’ensemble des parties prenantes présentes dans le bâtiment. Nous organisons des ateliers transversaux réunissant archivistes, agents d’accueil, équipes de sécurité et partenaires externes. Chaque groupe identifie les destinations prioritaires, les zones sensibles et les débits souhaités. Nous traduisons ensuite ces intentions en storyboards représentant l’expérience de visiteurs archétypaux, du résident en quête d’un document communal à l’artiste montant une exposition temporaire. Les storyboards révèlent des écarts sémantiques qui n’apparaîtraient qu’après le déploiement.</p><p>Une fois les intentions alignées, nous superposons les contraintes de gouvernance telles que les protocoles de sûreté et les calendriers de maintenance. Ces paramètres déterminent quelles trajectoires peuvent être publiées et à quel moment. En les intégrant tôt dans le récit, nous évitons de diffuser des indications ensuite contredites par l’exploitation. Le plan directeur qui en découle apporte une clarté partagée aux équipes de conception et de gestion technique.</p>",
          subheading: "Cadres lexicaux pour la clarté",
          subbody: "<p>Le choix du lexique constitue une étape décisive. Nous élaborons un inventaire qui concilie les dénominations légales avec des intitulés intuitifs. Ainsi, un « bureau de l’état civil » peut devenir « guichet documents des résidents » sur les canaux grand public tout en conservant son appellation officielle dans les répertoires internes. Ce cadre lexical alimente la rédaction sur la signalétique statique, les annonces vocales et les notifications mobiles, garantissant une cohérence linguistique quel que soit le support.</p><p>Le cadre lexical régit aussi l’iconographie. Chaque pictogramme est testé avec des groupes multilingues afin de vérifier la compréhension, notamment auprès de publics peu familiers avec les symboles administratifs. Les tests incluent la simulation de conditions de basse vision pour valider les contrastes et la redondance grâce aux textures ou aux animations.</p>"
        },
        section2: {
          heading: "Orchestrer médias analogiques et numériques",
          body: "<p>La signalétique analogique fournit des repères d’orientation tandis que les couches numériques délivrent des mises à jour contextuelles. Nous orchestrons les deux en définissant les rôles médiatiques : l’analogique pour la structuration spatiale, le numérique pour l’information temporelle. Les playlists d’écrans sont synchronisées sur les calendriers civiques, affichant les temps d’attente durant les périodes de renouvellement puis mettant en avant les programmes culturels en soirée. Cette orchestration prévient la surcharge cognitive et maintient le récit inclusif.</p><p>Nous tenons également compte de l’équité d’accès aux dispositifs. Tous les visiteurs ne disposent pas d’un smartphone capable de scanner des codes QR ou d’exécuter des applications natives. Toute extension mobile est donc pensée comme un support facultatif. Lorsqu’elle est proposée, elle reprend la grammaire de guidage des supports physiques afin d’éviter la fragmentation qui fragilise la confiance.</p>",
          subheading: "Techniques de narration spatiale",
          subbody: "<p>La narration spatiale repose sur la séquence des points de vue révélant progressivement la logique du bâtiment. Nous déployons des balisages lumineux en plafond pour souligner les axes et intégrons des inserts tactiles au sol pour confirmer les transitions entre zones publiques. Aux carrefours clés, un mapping vidéo affiche des invites contextuelles, par exemple pour indiquer les guichets accessibles uniquement sur rendez-vous.</p><p>Ces techniques sont évaluées lors de scénarios répétés. Des citoyens volontaires rejouent des parcours typiques tandis que des observateurs documentent les hésitations et réactions émotionnelles. Les enseignements alimentent le récit, ajustant le rythme des révélations et l’intensité sensorielle des signaux.</p>"
        },
        section3: {
          heading: "Gouvernance et amélioration continue",
          body: "<p>Un récit de navigation durable repose sur la gouvernance. Nous préconisons la création d’un conseil de signalétique réunissant chaque trimestre des représentants de tous les services. Le conseil examine des tableaux de bord synthétisant temps de stationnement, motifs des demandes au point information et engagement avec les contenus numériques. Cette gouvernance garantit la mise à jour du langage inclusif et des indices spatiaux au rythme de l’évolution des services.</p><p>L’amélioration continue demande également une discipline d’archivage. Chaque modification de signalétique, de contenu ou d’aménagement est consignée avec sa justification et sa date de révision. Ce registre constitue la mémoire de l’institution, permettant aux successeurs de comprendre les décisions et évitant le retour à des ajouts ponctuels non maîtrisés.</p>",
          subheading: "Prochaines itérations",
          subbody: "<p>Pour les prochaines itérations, nous testons des outils d’auteur participatifs permettant aux usagers de signaler les difficultés d’orientation via des bornes. Les contributions sont anonymisées et catégorisées, offrant un baromètre des expériences vécues sans compromettre la vie privée.</p><p>Parallèlement, nous explorons des collaborations avec des médiateurs culturels afin d’intégrer des couches interprétatives au guidage. Plutôt que de dissocier orientation et récit, la prochaine étape imagine des couloirs qui transmettent à la fois la direction et l’identité civique, pour que les visiteurs se sentent orientés spatialement et socialement.</p>"
        }
      },
      post3: {
        title: "Harmoniser les données spatiales pour les cartes de campus interactives",
        meta: "Publié le 29 janvier 2024 • 9 minutes de lecture",
        imageAlt: "Interface de carte interactive de campus",
        lead: "Les grands campus englobent des zones académiques, résidentielles, logistiques et ouvertes au public. Chaque direction entretient sa propre cartographie avec des standards de projection, des conventions de nommage et des rythmes de mise à jour différents. Lorsque des cartes interactives tentent de superposer ces sources, les décalages apparaissent sous forme de trajets contradictoires ou de destinations manquantes. Notre programme d’harmonisation étudie la conciliation des jeux de données pour offrir des cartes numériques exactes à plusieurs échelles et sensibles aux événements temporaires sans saturer les usagers de métadonnées.",
        section1: {
          heading: "Consolider des jeux de données hétérogènes",
          body: "<p>La première étape consiste en un audit taxonomique. Nous inventorions les entités représentées dans les jeux de données : bâtiments, points d’accès, zones paysagères et structures temporaires. Pour chaque entité, nous attribuons un identifiant canonique et répertorions les alias hérités. Ce dictionnaire constitue l’ossature des jointures et évite la duplication lorsque les services publient des révisions. Sans lui, un auditorium unique peut apparaître sous trois noms, fragmentant le récit de navigation.</p><p>Nous évaluons également la précision spatiale. Certaines couches s’appuient sur des plans DAO au centimètre près, d’autres proviennent de PDF dessinés à la main et géoréférencés approximativement. L’harmonisation suppose de négocier des tolérances acceptables selon les usages. L’évacuation d’urgence exige des entrées exactes, tandis que la promotion d’événements tolère des contours approximatifs. En hiérarchisant les besoins de précision, nous concentrons les ressources là où elles sont cruciales.</p>",
          subheading: "Stewardship des métadonnées",
          subbody: "<p>Les métadonnées résident souvent dans des colonnes de commentaires. Nous les restructurons en champs explicites décrivant les caractéristiques d’accessibilité, les horaires, les propriétaires administratifs et la fréquence de révision. Des protocoles de stewardship attribuent la responsabilité de chaque champ afin que la carte interactive puisse signaler son niveau de confiance. Une destination dont la métadonnée est obsolète est marquée visuellement et invite au retour d’information.</p><p>Pour maintenir l’élan, nous instituons une guilde des métadonnées se réunissant chaque mois. Les représentants de la cartographie, de la maintenance, des bibliothèques et des affaires étudiantes examinent les journaux de changements, résolvent les conflits et planifient des publications synchronisées. Ce modèle évite que l’effort d’harmonisation ne retombe dans des routines silotées.</p>"
        },
        section2: {
          heading: "Concevoir des interfaces de cartes adaptatives",
          body: "<p>Une fois les fondations consolidées, le design d’interface les traduit en expériences lisibles. Nous concevons des couches adaptatives qui réagissent au contexte : un mode orientation pour les visiteurs découvreurs simplifie les repères et anime les trajets, tandis qu’un mode exploitation expose les circulations techniques et les quais de livraison. Les usagers peuvent basculer entre modes sans perdre leur position, respectant la diversité des modèles mentaux.</p><p>Le design adaptatif couvre aussi les capacités des appareils. Les vues sur ordinateur incluent des tableaux comparatifs pour la planification, tandis que les bornes privilégient de larges zones tactiles et des transitions dynamiques pour compenser l’éblouissement. Les vues mobiles préchargent des tuiles hors ligne pour les secteurs à connectivité limitée, renforçant la confiance sur le terrain.</p>",
          subheading: "Interactions inclusives",
          subbody: "<p>Les cartes interactives doivent aller au-delà des listes de conformité en matière d’accessibilité. Nous implémentons une navigation clavier prioritaire, des palettes à fort contraste et un grossissement ajustable. Pour les personnes neurodiverses, la carte propose des storyboards linéaires découpant les itinéraires en panneaux successifs plutôt que de s’appuyer uniquement sur l’abstraction spatiale.</p><p>La diversité linguistique est tout aussi essentielle. L’interface prend en charge des libellés bilingues juxtaposés et permet de moduler l’accent typographique lorsque l’une des langues utilise des descriptions plus longues. Des transcriptions phonétiques peuvent être ajoutées pour les termes à prononciation complexe, facilitant l’accompagnement par les équipes d’accueil.</p>"
        },
        section3: {
          heading: "Opérationnaliser les boucles de retour",
          body: "<p>L’harmonisation ne perdure que si les usagers peuvent signaler facilement les écarts. Nous intégrons un module de retour d’information capturant coordonnées géospatiales, capture d’écran et rôle déclaratif. Les rapports sont triés automatiquement selon la gravité : les enjeux de sécurité déclenchent une alerte immédiate, tandis que les ajustements esthétiques entrent dans la file hebdomadaire.</p><p>Les analytics observent la manière dont les usagers parcourent la carte, révélant des impasses dues à des filtres contradictoires ou à la superposition excessive de couches. Nous convertissons ces constats en éléments de backlog pour la guilde des métadonnées et les designers d’interface. Le tableau de bord partagé maintient la transparence des responsabilités.</p>",
          subheading: "Gouvernance à long terme",
          subbody: "<p>La gouvernance à long terme associe politique et outils. Nous documentons les engagements de service sur les fréquences de mise à jour, définissons les processus d’intégration pour les nouveaux services et entretenons un bac à sable de test reflétant la production. Des scripts d’automatisation vérifient l’intégrité des géométries, signalant les auto-intersections ou les nœuds orphelins avant publication.</p><p>Enfin, nous investissons dans la transmission de connaissances. Ateliers et documentations expliquent comment les données harmonisées soutiennent la navigation, la planification d’événements et la gestion des actifs. Lorsque les parties prenantes comprennent la valeur collective, elles respectent davantage les conventions de nommage et fournissent des mises à jour ponctuelles, assurant la fiabilité de la carte interactive du campus.</p>"
        }
      },
      post4: {
        title: "Guidage visuel adaptatif dans les districts urbains complexes",
        meta: "Publié le 11 décembre 2023 • 9 minutes de lecture",
        imageAlt: "Éclairage urbain adaptatif guidant les piétons",
        lead: "Les districts urbains complexes mêlent nœuds de transport, commerces, logements et fonctions civiques. Les visiteurs n’y vivent pas une trajectoire unique ; ils composent avec des places, des passages couverts et des traversées souterraines selon des objectifs changeants. Un guidage visuel adaptatif reconnaît cette variabilité en ajustant continuellement les signaux au contexte. Nos terrains menés dans des projets de renouvellement urbain en Belgique montrent comment une mise en scène visuelle soignée maintient la lisibilité sans recourir à une surveillance intrusive ni à des paysages sonores oppressants.",
        section1: {
          heading: "Observer les micro-géographies urbaines",
          body: "<p>L’observation commence par les micro-géographies, ces tronçons de rue qui se comportent différemment selon les usages adjacents. Nous cartographions la manière dont lumière, végétation, reflets de vitrines et œuvres publiques influencent les lignes de vue. Les enregistrements nocturnes sont comparés aux séquences diurnes pour détecter les angles morts ou les façades trop lumineuses qui écrasent la signalétique. Ces observations alimentent une classification des zones d’intervention.</p><p>Des marches communautaires complètent les captations. Les résidents annotent leurs ressentis, signalant les lieux où ils se sentent désorientés ou pressés. Leurs retours pointent souvent des déclencheurs immatériels tels que des ruptures de revêtement ou des alignements spontanés de vendeurs. Documenter ces perceptions nous évite de nous fier uniquement aux luxmètres ou aux comptages de flux.</p>",
          subheading: "Superposition temporelle des signaux",
          subbody: "<p>La superposition temporelle reconnaît que le rythme d’un district varie chaque heure. Les flux matinaux exigent des signaux rapides et contrastés, tandis que les promenades du week-end profitent d’invitations plus lentes et exploratoires. Nous rédigeons donc une timeline précisant quels actifs visuels s’activent sur chaque plage horaire. Les façades numériques peuvent s’atténuer pour révéler des flèches projetées à l’aube puis basculer sur des récits culturels après la tombée de la nuit.</p><p>Les scripts temporels intègrent aussi les scénarios exceptionnels. Lors de travaux, par exemple, des superpositions temporaires guident les piétons autour des barrières. Elles disparaissent dès la fin du chantier, évitant l’accumulation de signes obsolètes. Le script garantit que le district ne se charge pas de résidus confus.</p>"
        },
        section2: {
          heading: "Concevoir des systèmes visuels adaptatifs",
          body: "<p>Les systèmes adaptatifs reposent sur des éléments modulaires reprogrammables. Nous déployons des ailettes LED, des rubans lumineux au sol et des panneaux e-paper dont la messagerie se met à jour à distance. Les modules sont agencés de manière à offrir à chaque point de décision au moins deux signaux complémentaires, l’un directionnel, l’autre confirmatif. Cette redondance soutient des profils perceptifs variés.</p><p>Le choix des matériaux est déterminant. Des polycarbonates diffus protègent l’électronique tout en maintenant une luminance homogène. Des revêtements antireflet empêchent les éblouissements sous la pluie. Les installations sont testées avec des groupes de piétons utilisant des aides à la mobilité afin de s’assurer qu’elles n’obstruent ni n’engendrent de risques de chute.</p>",
          subheading: "Stratégies d’éclairage réactif",
          subbody: "<p>L’éclairage réactif s’appuie sur des capteurs mesurant densité de foule et luminosité ambiante. Lorsque le trafic augmente, le système élargit le chemin lumineux pour diluer les flux. Aux heures calmes, l’intensité diminue pour économiser l’énergie tout en signalant des itinéraires sûrs. Les algorithmes sont calibrés pour éviter des variations brusques susceptibles d’effrayer les passants.</p><p>Nous associons l’éclairage réactif à des marqueurs analogiques comme des carreaux réfléchissants et des garde-corps texturés. En cas de défaillance des capteurs, la couche analogique continue de transmettre la direction. Des exercices réguliers avec les équipes de maintenance répètent les procédures de secours pour remplacer des modules ou activer des préréglages statiques.</p>"
        },
        section3: {
          heading: "Évaluer l’adaptation sur le long terme",
          body: "<p>L’évaluation dépasse la simple disponibilité technique. Nous menons des audits saisonniers en enregistrant les trajectoires piétonnes via des caméras anonymisées et les comparons aux études de référence. Des enquêtes menées avec les conseils de quartier recueillent les impressions sur le confort, l’orientation et l’ambiance. La combinaison des métriques évite de dépendre d’un indicateur unique.</p><p>Les résultats alimentent des sessions de recalibrage annuelles durant lesquelles nous ajustons les scripts, remplaçons les contenus et réglons les seuils des capteurs. Ces sessions sont planifiées avant les grands événements afin de préparer le district à des flux atypiques.</p>",
          subheading: "Stewardship collaboratif",
          subbody: "<p>Le guidage adaptatif prospère lorsque la responsabilité est partagée. Nous facilitons des accords entre services d’éclairage municipaux, programmateurs culturels, commerçants et associations d’habitants. Chaque partie parrraine certains modules, finance la maintenance et propose des idées de programmation. Cette propriété partagée décourage le vandalisme et accélère les interventions.</p><p>Une documentation transparente soutient le partenariat. Chaque modification est consignée dans un atlas numérique décrivant la justification, la durée de vie attendue et les contacts. L’atlas sert aussi d’outil de formation pour les nouvelles équipes, assurant la continuité malgré les renouvellements de personnel.</p>"
        }
      },
      post5: {
        title: "Mesurer la réaction des flux piétons à la signalétique dynamique",
        meta: "Publié le 23 novembre 2023 • 9 minutes de lecture",
        imageAlt: "Capteurs analysant un flux piéton",
        lead: "La signalétique dynamique promet de moduler les flux piétons aux heures de pointe, mais chaque affirmation doit s’appuyer sur des preuves. Notre cadre de mesure combine analytics spatiales, observation ethnographique et modélisation statistique pour évaluer la réaction des piétons lorsque les contenus changent en temps réel. L’objectif est d’identifier la causalité et de distinguer les véritables évolutions comportementales des fluctuations fortuites provoquées par la météo ou des retards de transport.",
        section1: {
          heading: "Établir des modèles de flux de référence",
          body: "<p>Nous commençons par établir des modèles de référence à partir d’observations sur des périodes fixes avant l’introduction de contenus dynamiques. Des capteurs positionnés aux goulets d’étranglement collectent les comptages directionnels, les distributions de vitesse et les durées d’arrêt. Ces relevés sont synchronisés avec des annotations manuelles portant sur la taille des groupes et la présence de bagages, variables qui influencent souvent le rythme.</p><p>Les références sont contextualisées par des métadonnées environnementales. Nous consignons les horaires de service concomitants, les promotions commerciales à proximité et les cadences de transport. Ce contexte évite d’interpréter une foule liée à un festival spontané comme un effet de la signalétique. Le modèle de référence est mis à jour chaque semaine jusqu’à stabilisation de la variance dans les seuils convenus.</p>",
          subheading: "Segmenter les cohortes d’usagers",
          subbody: "<p>La réaction à la signalétique varie selon les cohortes. Nous classons les piétons en navetteurs, visiteurs et personnel logistique à partir de sondages et de comptages anonymisés de présences d’appareils. Chaque cohorte dispose de ses propres métriques de référence afin que les moyennes ne masquent pas les comportements atypiques. Les navetteurs adaptent par exemple rapidement leur trajet alors que les visiteurs ont besoin de répétitions.</p><p>Les profils de segment incluent également les considérations d’accessibilité. Les personnes en fauteuil roulant, les parents avec poussettes et les individus sensibles aux stimuli sont suivis via des programmes balises volontaires et des observations ciblées. Leurs retours orientent le calibrage des tailles de police, de la vitesse d’animation et des compléments audio.</p>"
        },
        section2: {
          heading: "Déployer des expériences de contenu dynamique",
          body: "<p>Les expériences dynamiques suivent un schéma A/B/A pour isoler les effets. La phase A conserve la signalétique statique, la phase B introduit les contenus dynamiques et la dernière phase A revient aux repères initiaux. Chaque phase couvre des créneaux identiques sur plusieurs jours. Les variations comprennent des flèches directionnelles qui grossissent en cas de congestion, des compteurs de capacité d’escalator et des invitations contextuelles vers des couloirs alternatifs.</p><p>À chaque phase, nous collectons des métriques de flux mais aussi des retours qualitatifs lors d’entretiens éclair. Les questions sondent la clarté perçue, le niveau de stress et la confiance accordée à l’information. Les enseignements qualitatifs nous alertent lorsque des progrès statistiques masquent un ressenti négatif.</p>",
          subheading: "Méthodes de fusion de capteurs",
          subbody: "<p>Pour accroître la fiabilité, nous fusionnons les données de caméras thermiques, de capteurs LiDAR et de dalles de pression. Les caméras thermiques fournissent des comptages précis sans biométrie, le LiDAR capture les vecteurs de trajectoire et les tapis de pression confirment l’occupation des passages couverts. Les algorithmes de fusion pondèrent chaque source selon sa précision contextuelle.</p><p>Nous calibrons les capteurs quotidiennement grâce à des marches de référence. Des techniciens parcourent des trajets balisés en portant des marqueurs de calibration, permettant au système d’ajuster les dérives. Des alertes automatiques se déclenchent lorsque les écarts dépassent les bandes de tolérance, garantissant la fiabilité des données expérimentales.</p>"
        },
        section3: {
          heading: "Interpréter les résultats",
          body: "<p>L’interprétation combine les écarts quantitatifs et les récits qualitatifs. Nous analysons la variation des coefficients de charge des couloirs entre les phases et si les goulets se résorbent ou se déplacent. Les cartes de chaleur révèlent les impacts secondaires, comme l’augmentation de l’usage d’escaliers jusque-là sous-utilisés. Ces visuels sont partagés avec les parties prenantes en parallèle des extraits d’entretiens pour des décisions équilibrées.</p><p>Nous examinons également la résilience. Si la signalétique dynamique réduit la congestion mais requiert un pilotage permanent, le bénéfice peut ne pas être pérenne. Les journaux de maintenance et les besoins en personnel font donc partie de l’évaluation.</p>",
          subheading: "Inscrire les enseignements dans les politiques",
          subbody: "<p>Les enseignements se traduisent en recommandations politiques précisant quand la signalétique dynamique doit s’activer, qui autorise les nouveaux contenus et comment la performance est auditée. Les politiques définissent des seuils déclencheurs, tels que la densité de passagers ou les rapports d’incident, qui basculent automatiquement les playlists.</p><p>Enfin, nous partageons les résultats avec les districts voisins pour encourager des pratiques interopérables. Lorsque les espaces adjacents adoptent des déclencheurs et grammaires visuelles compatibles, les piétons bénéficient d’un guidage fluide plutôt que d’instructions contradictoires. L’apprentissage partagé accélère l’amélioration et renforce la confiance du public dans la signalétique dynamique comme outil de stewardship légitime.</p>"
        }
      }
    },
    contact: {
      hero: {
        title: "Coordonnées et carte",
        subtitle: "Prenons le temps d’explorer vos besoins en orientation spatiale. Présentez votre contexte, vos contraintes et vos ambitions afin de construire un cadre d’étude précis.",
        imageAlt: "Carte détaillée de Bruxelles avec repère sur Rue de la Loi"
      },
      info: {
        heading: "Point de contact",
        text: "Disponibles pour échanges exploratoires, ateliers de cadrage et accompagnement des équipes opérationnelles.",
        phoneLabel: "Téléphone",
        emailLabel: "Courriel",
        addressLabel: "Adresse",
        schedule: "Plages d’échange : du lundi au jeudi • 09:00 — 17:30",
        phoneNumber: "+32 2 123 45 67",
        emailAddress: "contact@danswholesaleplants.com"
      },
      map: {
        heading: "Localisation",
        description: "Visualisez l’emplacement de notre espace de travail au cœur de Bruxelles."
      },
      form: {
        heading: "Formulaire de contact",
        description: "Partagez les informations essentielles sur votre environnement. Nous répondrons avec des pistes de cadrage.",
        nameLabel: "Nom et prénom",
        namePlaceholder: "Votre nom complet",
        emailLabel: "Adresse e-mail",
        emailPlaceholder: "nom@organisation.be",
        organisationLabel: "Organisation",
        organisationPlaceholder: "Nom de la structure",
        phoneLabel: "Téléphone",
        phonePlaceholder: "+32 ...",
        messageLabel: "Description de votre environnement et de vos questions",
        messagePlaceholder: "Expliquez les enjeux rencontrés, vos priorités et le calendrier souhaité.",
        submit: "Envoyer et documenter",
        notice: "Les informations fournies sont utilisées pour préparer un échange personnalisé. Consultez la politique de confidentialité pour plus de détails."
      },
      support: {
        heading: "Préparer votre message",
        text: "Pour accélérer la compréhension, précisez les publics concernés, les supports existants et les limites actuelles.",
        list: "<li>Cartes ou plans disponibles et date de mise à jour</li><li>Nombre de langues utilisées dans vos communications</li><li>Metrics ou observations déjà collectées sur site</li>"
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        subtitle: "Clarifications sur nos méthodes, livrables et modes de collaboration.",
        imageAlt: "Documents analytiques et plans annotés"
      },
      intro: {
        text: "Vous trouverez ici des précisions sur la manière dont nous abordons les environnements complexes et sur la collaboration proposée."
      },
      questions: {
        q1: {
          question: "Quelles méthodes d’observation privilégiez-vous ?",
          answer: "Nous combinons parcours guidés, captations vidéo, compteurs de flux anonymisés et ateliers participatifs. L’objectif est de croiser perception qualitative et mesures quantitatives."
        },
        q2: {
          question: "Comment assurez-vous la parité linguistique ?",
          answer: "Les contenus sont audités en français, néerlandais et anglais selon les besoins. Nous vérifions longueur des libellés, prononciation, iconographie et redondance tactile ou sonore."
        },
        q3: {
          question: "Quelles livraisons produisez-vous régulièrement ?",
          answer: "Cartes d’expérience annotées, matrices de décision, lexiques bilingues, scripts temporels, prototypes interactifs et playbooks de gouvernance."
        },
        q4: {
          question: "Intervenez-vous sur l’implémentation ?",
          answer: "Nous accompagnons la phase d’implémentation aux côtés des équipes internes et fournisseurs, en assurant la cohérence avec les scénarios validés."
        },
        q5: {
          question: "Comment mesurez-vous l’impact ?",
          answer: "Par des indicateurs de temps de parcours, de stress perçu, de demandes d’assistance, ainsi que par des audits sensoriels saisonniers."
        },
        q6: {
          question: "Travaillez-vous uniquement en Belgique ?",
          answer: "Nos recherches sont ancrées en Belgique, mais les cadres méthodologiques peuvent s’adapter à d’autres contextes européens en tenant compte des spécificités locales."
        }
      }
    },
    terms: {
      hero: {
        title: "Conditions d’utilisation",
        subtitle: "Cadre juridique encadrant la consultation et l’utilisation des contenus publiés.",
        imageAlt: "Documents juridiques sur un bureau"
      },
      sections: {
        s1: {
          title: "1. Objet",
          text: "Les présentes conditions régissent l’accès au site danswholesaleplants.com et l’usage des contenus analytiques, publications, outils et documents mis à disposition."
        },
        s2: {
          title: "2. Définitions",
          text: "Le terme « Site » désigne la plateforme danswholesaleplants.com. « Utilisateur » désigne toute personne consultant les contenus. « Contenus » regroupe textes, graphiques, vidéos et documents téléchargeables."
        },
        s3: {
          title: "3. Acceptation",
          text: "En accédant au Site, l’Utilisateur accepte sans réserve les présentes conditions. Tout usage contraire à ces dispositions pourra entraîner la restriction d’accès."
        },
        s4: {
          title: "4. Propriété intellectuelle",
          text: "Les contenus publiés sont la propriété de danswholesaleplants ou de ses partenaires. Toute reproduction ou diffusion sans autorisation écrite est interdite."
        },
        s5: {
          title: "5. Usage des contenus",
          text: "Les contenus sont fournis à des fins d’information et de recherche. Ils ne peuvent être utilisés pour constituer un service concurrent ni revendiqués comme des conseils opérationnels définitifs."
        },
        s6: {
          title: "6. Contributions externes",
          text: "Lorsque des partenaires contribuent à des contenus, leurs droits restent préservés. Leur citation est obligatoire selon les conditions convenues."
        },
        s7: {
          title: "7. Exactitude des informations",
          text: "Nous veillons à la fiabilité des informations, sans garantir l’absence d’erreurs. Les contenus peuvent être mis à jour sans préavis."
        },
        s8: {
          title: "8. Responsabilité de l’utilisateur",
          text: "L’Utilisateur garantit l’usage licite du Site et s’engage à ne pas porter atteinte à l’intégrité des systèmes techniques ni à collecter des données de manière automatisée."
        },
        s9: {
          title: "9. Accessibilité",
          text: "Le Site est conçu pour être accessible au plus grand nombre. Des améliorations continues sont apportées en fonction des retours utilisateurs."
        },
        s10: {
          title: "10. Liens externes",
          text: "Des liens vers d’autres sites peuvent être proposés. danswholesaleplants ne peut être tenue responsable du contenu de ces plateformes tierces."
        },
        s11: {
          title: "11. Sécurité",
          text: "Des mesures techniques protègent les flux d’information. Toutefois, l’Utilisateur reconnaît que la transmission de données sur Internet comporte un risque résiduel."
        },
        s12: {
          title: "12. Modifications",
          text: "Les conditions peuvent évoluer. La date de dernière mise à jour est indiquée, et la consultation régulière est recommandée."
        },
        s13: {
          title: "13. Droit applicable",
          text: "Les présentes sont régies par le droit belge. Tout litige sera porté devant les tribunaux compétents de Bruxelles."
        },
        s14: {
          title: "14. Contact",
          text: "Pour toute question relative aux conditions, contactez contact@danswholesaleplants.com ou écrivez à Rue de la Loi 200, 1040 Bruxelles."
        }
      }
    },
    privacy: {
      hero: {
        title: "Politique de confidentialité",
        subtitle: "Transparence sur la collecte et l’utilisation des données personnelles.",
        imageAlt: "Icônes de sécurité et données"
      },
      sections: {
        s1: {
          title: "1. Introduction",
          text: "Cette politique décrit la manière dont danswholesaleplants traite les données personnelles collectées via le Site et lors des échanges professionnels."
        },
        s2: {
          title: "2. Données collectées",
          text: "Nous collectons les informations fournies via le formulaire de contact (nom, e-mail, organisation, message) ainsi que des données techniques anonymisées (logs serveur, statistiques de fréquentation)."
        },
        s3: {
          title: "3. Finalités",
          text: "Les données servent à répondre aux demandes, planifier des échanges, améliorer le Site et assurer la sécurité technique."
        },
        s4: {
          title: "4. Bases légales",
          text: "Le traitement s’appuie sur l’intérêt légitime à répondre aux sollicitations et sur le consentement lorsque celui-ci est requis (gestion des cookies optionnels)."
        },
        s5: {
          title: "5. Conservation",
          text: "Les données de contact sont conservées le temps nécessaire au suivi de la demande puis archivées pendant une durée maximale de 24 mois. Les logs techniques sont conservés 12 mois."
        },
        s6: {
          title: "6. Partage",
          text: "Les données ne sont pas vendues. Elles peuvent être partagées avec des prestataires techniques assurant l’hébergement ou la maintenance, soumis à des clauses de confidentialité."
        },
        s7: {
          title: "7. Transferts internationaux",
          text: "Les données sont hébergées dans l’Union européenne. Aucun transfert hors UE n’est opéré sans garanties adéquates."
        },
        s8: {
          title: "8. Droits des personnes",
          text: "Vous disposez de droits d’accès, de rectification, de suppression, de limitation et d’opposition. Pour les exercer, contactez contact@danswholesaleplants.com."
        },
        s9: {
          title: "9. Sécurité",
          text: "Des mesures techniques (chiffrement TLS, contrôles d’accès) et organisationnelles protègent les données contre l’accès non autorisé."
        },
        s10: {
          title: "10. Mise à jour",
          text: "Cette politique peut évoluer. La date de révision figure en en-tête. Nous encourageons une consultation régulière."
        }
      }
    },
    cookies: {
      hero: {
        title: "Politique relative aux cookies",
        subtitle: "Gestion des traceurs utilisés sur danswholesaleplants.com.",
        imageAlt: "Illustration de préférences de cookies"
      },
      intro: "Les cookies sont des fichiers déposés sur votre terminal pour assurer le bon fonctionnement du Site, mesurer l’audience et mémoriser vos préférences. Vous pouvez gérer vos choix à tout moment.",
      essentials: "Les cookies nécessaires garantissent la sécurité et la mémorisation de votre choix de langue. Ils sont activés par défaut.",
      optional: "Les cookies de préférences, d’analytics et de marketing sont désactivés tant que vous n’avez pas donné votre consentement.",
      tableHeading: "Liste des cookies utilisés",
      table: {
        name: "Nom",
        provider: "Fournisseur",
        type: "Type",
        purpose: "Finalité",
        duration: "Durée",
        rows: {
          row1: {
            name: "site_session",
            provider: "danswholesaleplants",
            type: "Nécessaire",
            purpose: "Maintient une session sécurisée entre les pages.",
            duration: "24 heures"
          },
          row2: {
            name: "lang_pref",
            provider: "danswholesaleplants",
            type: "Préférences",
            purpose: "Mémorise la langue choisie via le sélecteur.",
            duration: "12 mois"
          },
          row3: {
            name: "consent_state",
            provider: "danswholesaleplants",
            type: "Nécessaire",
            purpose: "Enregistre votre configuration de consentement.",
            duration: "12 mois"
          },
          row4: {
            name: "traffic_sample",
            provider: "danswholesaleplants",
            type: "Analytics",
            purpose: "Mesure anonymisée des flux de navigation.",
            duration: "6 mois"
          }
        }
      },
      management: "Vous pouvez modifier vos préférences à tout moment via le bandeau ou en supprimant les cookies de votre navigateur.",
      contact: "Pour toute question relative aux cookies, contactez contact@danswholesaleplants.com."
    },
    refund: {
      hero: {
        title: "Politique de révision",
        subtitle: "Procédure en cas de demande de réévaluation d’un livrable analytique.",
        imageAlt: "Discussion autour d’un rapport d’audit"
      },
      sections: {
        s1: {
          title: "1. Objet",
          text: "Cette politique décrit la façon dont danswholesaleplants traite les demandes de révision lorsque des livrables analytiques nécessitent des ajustements."
        },
        s2: {
          title: "2. Champ d’application",
          text: "Elle concerne les études, diagnostics et prototypes remis dans le cadre de collaborations de recherche ou de conseil."
        },
        s3: {
          title: "3. Éligibilité",
          text: "Une demande est recevable lorsqu’un écart significatif entre livrables et cadrage initial est démontré par écrit sous 30 jours après livraison."
        },
        s4: {
          title: "4. Procédure",
          text: "La demande est adressée à contact@danswholesaleplants.com, détaillant le livrable concerné, la date et la nature de l’écart observé."
        },
        s5: {
          title: "5. Analyse conjointe",
          text: "Un entretien est organisé pour examiner les éléments. Des compléments d’information peuvent être requis."
        },
        s6: {
          title: "6. Scénarios de réponse",
          text: "Selon l’analyse, danswholesaleplants peut proposer un ajustement, une nouvelle itération ciblée ou valider que le livrable respecte le cadrage."
        },
        s7: {
          title: "7. Délai de traitement",
          text: "Les réponses sont apportées dans un délai de 15 jours ouvrés suivant la réception des informations nécessaires."
        },
        s8: {
          title: "8. Limites",
          text: "Les demandes liées à un changement d’objectif ou à l’ajout de périmètres non prévus font l’objet d’une nouvelle proposition distincte."
        },
        s9: {
          title: "9. Escalade",
          text: "En cas de désaccord persistant, un médiateur externe peut être sollicité d’un commun accord."
        },
        s10: {
          title: "10. Contact",
          text: "Pour toute question relative à cette politique, adressez un message à contact@danswholesaleplants.com."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Avis de non-responsabilité",
        subtitle: "Limites d’usage des contenus publiés.",
        imageAlt: "Panneau informatif avec avertissement"
      },
      sections: {
        s1: {
          title: "1. Informations générales",
          text: "Les contenus du Site sont fournis à titre informatif et ne constituent pas un engagement contractuel."
        },
        s2: {
          title: "2. Absence de garantie",
          text: "danswholesaleplants ne garantit pas l’exhaustivité ni l’actualité permanente des informations diffusées."
        },
        s3: {
          title: "3. Décisions opérationnelles",
          text: "Les décisions prises à partir des contenus relèvent de la seule responsabilité de l’Utilisateur."
        },
        s4: {
          title: "4. Références externes",
          text: "Lorsque des liens vers des ressources tierces sont proposés, leur contenu demeure sous la responsabilité de leurs éditeurs."
        },
        s5: {
          title: "5. Limitation de responsabilité",
          text: "danswholesaleplants ne pourra être tenue responsable des dommages directs ou indirects résultant de l’usage du Site."
        },
        s6: {
          title: "6. Contact",
          text: "Toute question relative au présent avis peut être adressée à contact@danswholesaleplants.com."
        }
      }
    },
    thankYou: {
      hero: {
        title: "Merci pour votre message",
        subtitle: "Nous revenons vers vous rapidement avec une proposition de cadrage.",
        imageAlt: "Personne consultant un message de confirmation"
      },
      body: "Votre message a bien été transmis. Nous analysons les informations partagées et programmons un retour sous deux jours ouvrés.",
      nextSteps: {
        heading: "Suite du processus",
        text: "Vous pouvez d’ores et déjà rassembler plans, métriques et documents utiles à la préparation de notre échange.",
        list: "<li>Réviser vos objectifs prioritaires</li><li>Identifier les parties prenantes à impliquer</li><li>Préparer les contraintes de calendrier</li>"
      },
      button: "Retour à l’accueil"
    },
    notFound: {
      hero: {
        title: "Page introuvable",
        subtitle: "Le contenu recherché n’est plus disponible ou a changé d’adresse.",
        imageAlt: "Signalétique indiquant une déviation"
      },
      description: "Utilisez le menu principal pour poursuivre votre navigation ou revenez à l’accueil.",
      button: "Retour à l’accueil"
    },
    cookieBanner: {
      title: "Préférences de cookies",
      description: "Nous utilisons des cookies pour sécuriser le site, mémoriser votre langue et analyser l’usage (optionnel). Ajustez vos préférences.",
      toggles: {
        necessary: "Nécessaires",
        preferences: "Préférences",
        analytics: "Analytics",
        marketing: "Marketing"
      },
      buttons: {
        acceptAll: "Tout accepter",
        declineAll: "Tout refuser",
        save: "Enregistrer",
        manage: "Gérer les préférences"
      },
      necessaryText: "Toujours actifs pour garantir la sécurité et le fonctionnement du Site."
    },
    toast: {
      contactSuccess: "Merci ! Votre message a été transmis.",
      formError: "Merci de compléter les champs requis avant envoi.",
      cookieSaved: "Vos préférences cookies sont enregistrées.",
      cookieDeclined: "Cookies optionnels désactivés."
    },
    form: {
      validation: "Certains champs obligatoires sont manquants."
    }
  },
  en: {
    meta: {
      index: {
        title: "danswholesaleplants — Spatial orientation and digital wayfinding",
        description: "Research, mapping, and recommendations for indoor navigation, digital signage, and pedestrian mobility across complex public environments."
      },
      services: {
        title: "Analytical services — danswholesaleplants",
        description: "Methodological frameworks to analyse spatial orientation, design digital wayfinding systems, and map user journeys within public buildings."
      },
      about: {
        title: "About danswholesaleplants",
        description: "Mission, values, and roadmap of danswholesaleplants: a team focused on flow analysis, built environment legibility, and information design."
      },
      blog: {
        title: "Research log — danswholesaleplants",
        description: "Technical articles on spatial orientation, digital signage, indoor navigation, and complex space mapping in Belgium."
      },
      post1: {
        title: "Evaluating digital wayfinding ecosystems in multimodal hubs",
        description: "Methodological frameworks to diagnose multimodal hubs, correlate analog and digital supports, and orchestrate interchange choreography."
      },
      post2: {
        title: "Designing inclusive navigation narratives for civic buildings",
        description: "Mapping stakeholder intentions, building shared lexicons, and choreographing media for complex civic facilities."
      },
      post3: {
        title: "Spatial data harmonisation for interactive campus maps",
        description: "Taxonomy audits, metadata stewardship, and adaptive design to deliver reliable campus mapping experiences."
      },
      post4: {
        title: "Adaptive visual guidance in complex urban districts",
        description: "Observing urban micro-geographies, scripting temporal cues, and deploying responsive lighting systems."
      },
      post5: {
        title: "Measuring pedestrian flow response to dynamic signage",
        description: "Measurement frameworks combining analytics, ethnography, and modelling to evaluate dynamic signage."
      },
      contact: {
        title: "Contact and map — danswholesaleplants",
        description: "Reach danswholesaleplants, schedule an exchange, and explore the Rue de la Loi 200 Brussels location."
      },
      faq: {
        title: "Frequently asked questions — danswholesaleplants",
        description: "Answers about signage analysis, journey mapping, and spatial data governance."
      },
      terms: {
        title: "Terms of use — danswholesaleplants",
        description: "Legal framework governing the use of research content and publications shared by danswholesaleplants."
      },
      privacy: {
        title: "Privacy policy — danswholesaleplants",
        description: "Data collection, usage, retention, and user rights related to danswholesaleplants analyses."
      },
      cookies: {
        title: "Cookie policy — danswholesaleplants",
        description: "Overview of necessary and optional cookies on danswholesaleplants.com and preference management."
      },
      refund: {
        title: "Revision policy — danswholesaleplants",
        description: "Procedure for analytical deliverable reviews, eligibility criteria, and escalation channels."
      },
      disclaimer: {
        title: "Disclaimer — danswholesaleplants",
        description: "Liability limitations and informational purpose of danswholesaleplants publications."
      },
      thankYou: {
        title: "Thank you for your message — danswholesaleplants",
        description: "Confirmation of receipt and next steps after submitting the contact form."
      },
      notFound: {
        title: "Page not found — danswholesaleplants",
        description: "The requested resource is unavailable. Navigate to another section of the site."
      }
    },
    brand: {
      name: "danswholesaleplants",
      tagline: "Spatial orientation and digital wayfinding"
    },
    nav: {
      home: "Home",
      services: "Services",
      about: "About",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    },
    header: {
      menuLabel: "Menu",
      menuToggle: "Toggle navigation"
    },
    buttons: {
      explore: "Explore orientation frameworks",
      methodology: "Review methodology overview",
      viewServices: "View services overview",
      contact: "Access contact coordinates",
      readArticle: "Read article",
      backToBlog: "Back to blog",
      home: "Return home"
    },
    footer: {
      description: "danswholesaleplants gathers, structures, and shares operational knowledge for complex built environments.",
      addressLabel: "Address",
      address: "Rue de la Loi 200, 1040 Brussels, Belgium",
      phoneLabel: "Phone",
      phoneNumber: "+32 2 123 45 67",
      emailLabel: "Email",
      emailAddress: "contact@danswholesaleplants.com",
      rights: "© {{year}} danswholesaleplants. All rights reserved.",
      legal: {
        terms: "Terms of use",
        privacy: "Privacy",
        cookies: "Cookies",
        refund: "Revision policy",
        disclaimer: "Disclaimer"
      }
    },
    index: {
      hero: {
        title: "Spatial orientation intelligence for public environments",
        subtitle: "We map how people decode complex buildings and districts to synchronise signage, digital media, and architecture. Each recommendation emerges from on-site observation, flow modelling, and iterative testing protocols.",
        button: "Explore orientation frameworks",
        secondary: "Review methodology overview",
        note: "Continuous observation cycles inform every guidance scenario.",
        imageAlt: "Digital wayfinding interface inside a multimodal hub",
        stats: {
          s1: {
            value: "38",
            label: "spatial audits conducted across Belgian civic hubs"
          },
          s2: {
            value: "24",
            label: "iterative evaluation protocols maintained"
          },
          s3: {
            value: "12",
            label: "urban laboratories monitored annually"
          }
        }
      },
      featured: {
        heading: "Systems analysis for complex buildings",
        intro: "Public environments stack physical and digital cues. Our role is to understand their interplay and deliver recommendations grounded in real use.",
        cards: {
          c1: {
            title: "Diagnostic layering",
            text: "Cross-analyse lived experiences to identify alignments and contradictions between physical landmarks and digital media.",
            list: "<li>Multi-sensory inventories along journeys</li><li>Conflict detection between analog and digital cues</li><li>Prioritisation matrix for critical zones</li>"
          },
          c2: {
            title: "Interaction modelling",
            text: "Simulate decision points to quantify cognitive load under shifting contexts.",
            list: "<li>Decision maps and friction points</li><li>Temporal scripts across demand peaks</li><li>Coupling pedestrian flows with media supports</li>"
          },
          c3: {
            title: "Accessibility orchestration",
            text: "Integrate linguistic diversity and specific needs to ensure shared space legibility.",
            list: "<li>Multilingual testing and reading levels</li><li>Coordinated haptic, luminous, and audio cues</li><li>User-oriented maintenance planning</li>"
          }
        }
      },
      method: {
        heading: "Method architecture",
        intro: "Every engagement follows a reproducible sequence aligning observation, modelling, and governance.",
        steps: {
          step1: {
            title: "Immersive observation",
            text: "Guided walks, video capture, and sensors to understand behaviours and perceptions on site."
          },
          step2: {
            title: "Cognitive mapping synthesis",
            text: "Translate observations into decision matrices and shared orientation narratives."
          },
          step3: {
            title: "Scenario prototyping",
            text: "Coordinate analog and digital experiments with operational teams."
          },
          step4: {
            title: "Evidence loops",
            text: "Dashboards, quarterly reviews, and continuous adjustments based on verifiable indicators."
          }
        }
      },
      recommendations: {
        heading: "Recommendations for orientation governance",
        intro: "Our guidance distils proven practices to keep spaces legible over time.",
        cards: {
          r1: {
            title: "Maintain living documentation",
            text: "Centralise plans, metadata, and feedback so every change remains traceable and explained."
          },
          r2: {
            title: "Design for multilingual parity",
            text: "Align copy, pictograms, and audio prompts to avoid unintentionally prioritising audiences."
          },
          r3: {
            title: "Plan iterative rehearsals",
            text: "Schedule scenario reviews to test emergency plans, seasons, and major events."
          }
        }
      },
      testimonials: {
        heading: "Testimonials from field partners",
        intro: "Independent voices describe how coordinated approaches improved their operations.",
        cards: {
          t1: {
            quote: "“Cross-layer mapping of flows and digital content surfaced hidden contradictions. Recommendations were immediately actionable for our technical teams.”",
            author: "Élise Lambert",
            role: "Urban mobility manager, City of Namur"
          },
          t2: {
            quote: "“Multilingual workshops clarified our lexicon while keeping regulatory obligations. Visitors now orient themselves much faster.”",
            author: "Koen Van Hove",
            role: "Reception coordinator, Ghent administrative house"
          },
          t3: {
            quote: "“The co-authored temporal scripts are now the reference for every major event. Safety and culture teams finally share the same language.”",
            author: "Samira Chakar",
            role: "Cultural programming, Arts District"
          }
        }
      },
      insights: {
        heading: "Current insights",
        intro: "Key observations currently steering our analyses.",
        points: {
          p1: "Spatial legibility improves when analog and digital cues reuse the same verbs.",
          p2: "Interactive maps gain trust when they display data freshness and invite feedback.",
          p3: "Night-time sensory testing reveals more perception gaps than crowded daytime audits."
        }
      },
      closing: {
        heading: "Align orientation strategies with operations",
        text: "We help architecture, operations, and communication teams converge around shared indicators.",
        button: "View services overview"
      }
    },
    services: {
      hero: {
        title: "Analytical services for spatial orientation",
        subtitle: "We investigate public environments, institutional buildings, and urban infrastructures to deliver robust decision frameworks. Deliverables support the coordination of physical signage, digital interfaces, and operational flows.",
        button: "Access contact coordinates",
        imageAlt: "Interactive floor plan displayed on a touch table"
      },
      intro: {
        heading: "Scope of work",
        text: "Our services span built-environment audits, journey design, spatial data governance, and emergency rehearsal preparation. Each engagement blends qualitative insights with instrumented measurements."
      },
      list: {
        heading: "Research streams",
        analysis: {
          title: "Spatial orientation analysis",
          text: "Identify confusion zones, map signal conflicts, and define prioritised recommendations.",
          list: "<li>Detailed inventories of supports and content</li><li>Legibility and cognitive load metrics</li><li>Synthesised maps highlighting friction zones</li>"
        },
        wayfinding: {
          title: "Digital wayfinding design",
          text: "Define editorial principles and digital scenography aligned with observed behaviours.",
          list: "<li>Temporal scripts and modular playlists</li><li>Multilingual information architecture</li><li>Prototype interfaces and user testing</li>"
        },
        journeys: {
          title: "User journey mapping",
          text: "Formalise travel sequences and decision points for each user profile.",
          list: "<li>Personas and orientation narratives</li><li>Contextual need matrices</li><li>Longitudinal monitoring dashboards</li>"
        },
        information: {
          title: "Information design consulting",
          text: "Structure content and harmonise messaging across analog and digital supports.",
          list: "<li>Shared lexicons and editorial guides</li><li>Visual and iconographic grammar</li><li>Editorial governance plans</li>"
        },
        mobility: {
          title: "Pedestrian mobility research",
          text: "Measure flows, model dispersion, and assess responses to dynamic signage.",
          list: "<li>Multi-sensor counting protocols</li><li>Resilience and capacity analyses</li><li>Operational recommendations and scenarios</li>"
        }
      },
      approach: {
        heading: "Approach principles",
        text: "Our methodology emphasises transparency and documentation every stakeholder can reuse.",
        items: {
          i1: "Co-analysis with on-site and operations teams",
          i2: "Regular validation through prototypes and targeted testing",
          i3: "Decision traceability and impact measurement"
        }
      },
      outcomes: {
        heading: "Deliverable components",
        cards: {
          c1: {
            title: "Spatial intelligence dossiers",
            text: "Visual syntheses, decision matrices, and annotated maps of the studied space."
          },
          c2: {
            title: "Interactive prototypes",
            text: "Functional digital signage mock-ups, playlist scenarios, and implementation guidelines."
          },
          c3: {
            title: "Governance playbooks",
            text: "Procedures, indicators, and review calendars sustaining system performance."
          }
        }
      },
      callout: {
        heading: "Coordinate a shared diagnostic",
        text: "We facilitate framing sessions aligning objectives, constraints, and success metrics before any deployment.",
        button: "Access contact coordinates"
      }
    },
    about: {
      hero: {
        title: "A craft of spatial legibility",
        subtitle: "danswholesaleplants combines data analysis, field observation, and information design to make complex environments intelligible.",
        imageAlt: "Team analysing plans and cartographic data"
      },
      mission: {
        heading: "Mission",
        text: "Enable public institutions and urban organisations to understand how their spaces are experienced, so they can design clear, inclusive, and adaptable journeys."
      },
      values: {
        heading: "Guiding values",
        intro: "Our commitments drive every collaboration and secure trustworthy recommendations.",
        cards: {
          c1: {
            title: "Evidence before intuition",
            text: "Decisions rely on documented observations, comparable metrics, and grounded feedback."
          },
          c2: {
            title: "Include every audience",
            text: "Orientation scenarios are tested with diverse profiles to reflect real usage."
          },
          c3: {
            title: "Operational empathy",
            text: "Recommendations consider available resources and maintenance realities."
          }
        }
      },
      timeline: {
        heading: "Timeline",
        intro: "Key milestones highlighting the maturation of our frameworks.",
        steps: {
          s1: {
            year: "2016",
            title: "Signage observatories",
            text: "First immersions in stations and museums to understand how existing cues are perceived."
          },
          s2: {
            year: "2018",
            title: "Urban laboratories",
            text: "Pilot programmes with Belgian municipalities measuring dynamic content impact."
          },
          s3: {
            year: "2020",
            title: "Metadata platform",
            text: "Development of governance tools keeping interactive maps reliable."
          },
          s4: {
            year: "2023",
            title: "Governance playbooks",
            text: "Publication of shared frameworks adopted by cultural and transport infrastructures."
          }
        }
      },
      capabilities: {
        heading: "Core capabilities",
        text: "We operate at the intersection of spatial research, UX, and operational engineering.",
        list: "<li>Flow analysis and scenario modelling</li><li>Multichannel information design and prototyping</li><li>Data governance and change enablement</li>"
      },
      network: {
        heading: "Network and partnerships",
        text: "Collaboration with urban planners, service designers, sociologists, accessibility specialists, and digital infrastructure experts delivers holistic responses."
      },
      callout: {
        heading: "Share your challenges",
        text: "We are available to unpack your orientation issues and set up an adapted research frame.",
        button: "Access contact coordinates"
      }
    },
    blog: {
      hero: {
        title: "Research log and insights",
        subtitle: "In-depth analyses on orientation systems, information design, and pedestrian mobility.",
        imageAlt: "Notebook with signage sketches and laptop"
      },
      intro: {
        heading: "Technical notes",
        text: "Each article documents methods, observations, and hypotheses to guide decision-makers transforming complex spaces."
      },
      cards: {
        post1: {
          title: "Evaluating digital wayfinding ecosystems in multimodal hubs",
          excerpt: "Methodological framework to analyse multimodal hubs, correlate analog and digital supports, and stage interchange choreography.",
          date: "14 March 2024"
        },
        post2: {
          title: "Inclusive navigation narratives for civic buildings",
          excerpt: "Craft shared lexicons, orchestrate media, and build durable governance across civic facilities.",
          date: "26 February 2024"
        },
        post3: {
          title: "Harmonising spatial data for interactive campus maps",
          excerpt: "Taxonomy audits, metadata stewardship, and adaptive design for reliable campus maps.",
          date: "29 January 2024"
        },
        post4: {
          title: "Adaptive visual guidance in urban districts",
          excerpt: "Micro-geography observation, temporal scripting, and responsive lighting to keep districts legible.",
          date: "11 December 2023"
        },
        post5: {
          title: "Measuring reactions to dynamic signage content",
          excerpt: "Measurement methods, sensor fusion, and interpretation to steer dynamic signage programmes.",
          date: "23 November 2023"
        },
        readMore: "Read article"
      }
    },
    posts: {
      general: {
        back: "Back to blog",
        readingTime: "Estimated reading time: 9 minutes"
      },
      post1: {
        title: "Evaluating digital wayfinding ecosystems in multimodal transport hubs",
        meta: "Published on 14 March 2024 • 9-minute read",
        imageAlt: "Interior view of a multimodal hub with digital signage",
        lead: "Multimodal transport hubs accumulate layers of signage, digital kiosks, live occupancy displays, and architectural cues. Evaluating how these layers interact requires more than counting screens; it demands a systemic view of spatial cognition, service choreography, and environmental constraints. At danswholesaleplants, longitudinal observation and participatory mapping have revealed that riders interpret information stacks differently depending on their modal origin. The goal of this study is to formalise evaluation routines that respect these divergences while keeping operational teams aligned around measurable evidence.",
        section1: {
          heading: "Methodological framing for complex hubs",
          body: "<p>Methodological framing for complex hubs begins with an inventory of spatial narratives. We segment the hub into navigational episodes, from arrival thresholds to departure lounges, and document every digital artefact that mediates the transition. Each artefact is rated against clarity, redundancy, sensory load, and handoff timing. The resulting matrix exposes zones where passengers encounter competing cues, as well as stretches with insufficient reassurance. Pairing the matrix with dwell-time analytics provides a grounded baseline before any redesign hypothesis is drafted.</p><p>Quantitative inventories alone remain incomplete without qualitative depth. Our teams facilitate guided walks with diverse user profiles: commuters familiar with shortcuts, tourists navigating linguistic barriers, and maintenance crews moving equipment. Narratives gathered during these walks are encoded using semantic tagging that maps back to the inventory matrix. This crosswalk highlights friction points caused by jargon, icon ambiguity, or misaligned audio prompts. It also captures segments where physical architecture already guides orientation effectively, preventing unnecessary digital additions.</p>",
          subheading: "Correlation matrices for navigational elements",
          subbody: "<p>The correlation matrices compare the behaviour of digital signage with analog supports, tracking which combination reduces hesitation time. A dynamic QR-driven map, for instance, may only reach peak utility when paired with floor-mounted arrows that cue scanning behaviour. Without the analog primer, usage collapses despite a high-resolution display. Capturing such dependencies allows operators to stage interventions in coordinated waves rather than replacing assets in isolation.</p><p>We then loop in maintenance logs and service disruption reports. Elements that frequently require manual resets are flagged with resilience coefficients, ensuring the evaluation accounts for operational burden. By correlating resilience with user reassurance scores, planners can justify keeping simpler, low-maintenance supports in critical junctions. The matrix therefore evolves into a negotiation platform where digital ambition and infrastructural pragmatism meet.</p>"
        },
        section2: {
          heading: "Context-aware communication layers",
          body: "<p>Context layers consider how information needs fluctuate throughout the day. Morning peaks emphasise transfer speed, while late evenings require reassurance and personal safety prompts. We map fluctuating priorities onto a 24-hour communication clock that instructs content sequencing on digital panels. The clock also governs how multilingual messaging is rotated to match the dominant language group across time bands without overwhelming displays.</p><p>Environmental variables such as daylight penetration, acoustic reverberation, and crowd density feed into the same layer. A corridor flooded with natural light may render certain colour palettes ineffective, whereas platform noise can drown out audio announcements. We annotate each hotspot with sensory thresholds so that content designers know when to favour high-contrast visuals, kinetic motion cues, or tactile indicators embedded in handrails.</p>",
          subheading: "Interchange choreography",
          subbody: "<p>Interchange choreography refers to the orchestrated path between modes. We analyse turning radii and decision points, then align them with content triggers. If passengers must choose between stairs and elevators within three seconds, the preceding digital message must prime that decision by advertising elevator availability earlier in the approach. Choreography mapping ensures that digital touchpoints are not merely decorative but anticipatory.</p><p>During pilot implementations, we track micro-interactions using unobtrusive sensors that log direction changes and gaze anchors. This data reveals whether travellers actually register the guidance or if they revert to crowd-following behaviour. When crowd cues dominate, we enrich the choreography with floor projections or kinetic lighting that extends the digital message into peripheral vision.</p>"
        },
        section3: {
          heading: "Measuring impact and iterating",
          body: "<p>Impact measurement spans beyond counting successful wayfinding queries. We monitor variance in transfer completion times, perceived stress levels gathered through intercept interviews, and the number of staff interventions required. Combining these indicators produces a composite navigation quality index. A sustained shift in the index validates whether the digital ecosystem is easing cognitive load or merely adding novelty.</p><p>Iteration cycles are planned quarterly, aligning with infrastructure maintenance windows. Each cycle includes a hypothesis backlog derived from user narratives, analytics anomalies, and seasonal observations. We prototype sequences in a simulation environment that mirrors hub geometry. Operators can rehearse disruptions, test multi-language expansions, and preview how emergency messaging overrides standard playlists.</p>",
          subheading: "Research avenues to extend",
          subbody: "<p>Future research will explore the integration of adaptive sensors capable of modulating brightness and content density in real time. We are also examining how personal mobility apps could exchange anonymised signals with station signage so that playlists adapt to dominant flows while respecting privacy guidelines.</p><p>Another avenue is collaborative governance. By framing the ecosystem as a shared service between transport agencies, tenants, and civic authorities, resource planning becomes collective rather than siloed. Evaluation protocols must therefore remain transparent, explainable, and grounded in evidence that stakeholders from urban planning, operations, and accessibility advocacy can scrutinise. Only then can multimodal hubs evolve without disorienting the people they serve.</p>"
        }
      },
      post2: {
        title: "Designing inclusive navigation narratives for civic buildings",
        meta: "Published on 26 February 2024 • 9-minute read",
        imageAlt: "Digital signage within a civic building",
        lead: "Civic buildings host administrative counters, cultural programmes, and community events under one roof. Visitors rarely share the same goals, and their cognitive maps differ according to familiarity with institutional vocabulary. Traditional floor plans fail to address these discrepancies, especially when digital signage layers are added without a narrative thread. Our exploration focuses on building navigation narratives that remain inclusive, allowing occasional visitors to orient themselves without feeling excluded while still providing the depth required by specialists using backstage corridors.",
        section1: {
          heading: "Mapping stakeholder intentions",
          body: "<p>An inclusive narrative begins by defining the intentions of all stakeholders occupying the building. We convene cross-functional workshops with archivists, citizen service officers, security teams, and external partners. Each group identifies priority destinations, sensitive zones, and desired flow rates. We then translate intentions into storyboards representing the experience of archetypal visitors, ranging from residents seeking municipal documents to artists installing temporary exhibitions. The storyboards expose semantic gaps that might otherwise surface only after deployment.</p><p>Once intentions are aligned, we layer governance constraints such as security protocols and maintenance schedules. These parameters influence which routes can be publicised and when. By embedding them early in the narrative, we avoid publishing guidance that later conflicts with operational realities. The resulting blueprint delivers clarity for both design and facility management teams.</p>",
          subheading: "Lexical frameworks for clarity",
          subbody: "<p>Selecting terminology is a decisive step. We assemble a lexical inventory that reconciles legal designations with intuitive labels. For example, a “citizen registry office” might be renamed “resident documentation desk” on user-facing channels while retaining the official title in back-office directories. The lexical framework informs copywriting across static signage, voice announcements, and mobile notifications, ensuring linguistic coherence regardless of medium.</p><p>The framework also dictates iconography. Each icon is tested with multilingual focus groups to verify comprehension, especially among populations less familiar with bureaucratic symbols. The testing phase includes simulation of low-vision conditions to validate contrast ratios and redundancy through textures or motion cues.</p>"
        },
        section2: {
          heading: "Orchestrating analog and digital media",
          body: "<p>Analog signage provides orientation anchors, while digital layers deliver situational updates. We choreograph both by defining media roles: analog for structural navigation, digital for temporal information. Display playlists are synchronised with civic calendars, surfacing queue statuses during peak renewal periods and shifting to cultural programming updates during evenings. This orchestration prevents cognitive overload and maintains the inclusive narrative.</p><p>We also consider device equity. Not every visitor carries a smartphone capable of scanning QR codes or running native applications. Therefore, any mobile augmentation is treated as supportive rather than mandatory. When mobile content is offered, it mirrors the wayfinding grammar found on physical signage, avoiding the fragmentation that often undermines trust.</p>",
          subheading: "Spatial storytelling techniques",
          subbody: "<p>Spatial storytelling relies on sequencing viewpoints that reveal the building’s logic progressively. We deploy ceiling-mounted lighting cues to highlight axial corridors and embed tactile floor inserts to confirm transitions between public zones. At key junctions, projection mapping introduces context-specific prompts, such as indicating which counters operate with prior appointments.</p><p>These techniques are evaluated through rehearsal scenarios. Volunteer citizens enact typical journeys while observers document hesitation points and emotional responses. Insights gathered feed back into the narrative, adjusting both the pacing of revelations and the sensory intensity of prompts.</p>"
        },
        section3: {
          heading: "Governance and continuous improvement",
          body: "<p>A sustainable navigation narrative depends on governance. We recommend forming a wayfinding council that convenes quarterly with representatives from each department. The council reviews performance dashboards summarising dwell times, inquiry topics at information desks, and digital content engagement. Governance ensures that inclusive language and spatial cues remain current as services evolve.</p><p>Continuous improvement also requires archival discipline. Every update to signage, content, or physical interventions is logged with rationale and review dates. This log acts as institutional memory, enabling successors to understand why decisions were taken and preventing regression to ad-hoc signage additions.</p>",
          subheading: "Future iterations",
          subbody: "<p>Looking ahead, we are prototyping participatory authoring tools allowing community members to flag navigation pain points via kiosks. Submissions are anonymised and categorised, providing a steady pulse on lived experiences without compromising privacy.</p><p>In parallel, we are exploring partnerships with cultural mediators to integrate interpretive layers into navigation. Rather than separating orientation from storytelling, the next iteration envisions corridors that communicate both direction and civic identity, helping visitors feel oriented not only spatially but also socially.</p>"
        }
      },
      post3: {
        title: "Spatial data harmonisation for interactive campus maps",
        meta: "Published on 29 January 2024 • 9-minute read",
        imageAlt: "Interactive campus map interface",
        lead: "Large campuses encompass academic, residential, logistical, and public zones. Each directorate curates its own map, with varying projection standards, naming conventions, and update cadences. When interactive maps attempt to overlay these sources, misalignments appear as contradictory paths or missing destinations. Our harmonisation programme studies how to reconcile datasets so that digital maps remain accurate at multiple scales and responsive to time-bound events without overwhelming users with metadata clutter.",
        section1: {
          heading: "Consolidating heterogeneous datasets",
          body: "<p>The first milestone is a taxonomy audit. We inventory the entities represented across datasets—buildings, access points, landscape zones, and temporary structures. For each entity we assign canonical identifiers and document legacy aliases. This dictionary acts as the backbone for data joins, preventing duplication whenever departments upload revisions. Without it, a single auditorium may appear under three names, fracturing the navigational narrative.</p><p>We also evaluate spatial precision. Some layers rely on CAD drawings with centimetric accuracy, while others originate from hand-drawn PDFs georeferenced by estimation. Harmonisation involves negotiating acceptable tolerances for each usage scenario. Emergency routing demands exact entrances, whereas event promotion tolerates approximate footprints. By tiering accuracy requirements, we can prioritise resources where precision matters most.</p>",
          subheading: "Metadata stewardship",
          subbody: "<p>Metadata often hides in comment columns. We restructure it into explicit fields describing accessibility features, opening hours, administrative ownership, and update frequency. Stewardship protocols assign accountability for each field so that the interactive map can signal confidence levels to users. A destination with outdated metadata is flagged visually, inviting feedback rather than silently propagating misinformation.</p><p>To maintain momentum, we establish a metadata guild that meets monthly. Representatives from GIS, facilities, library services, and student affairs review change logs, reconcile conflicts, and plan synchronised releases. The guild model prevents the harmonisation effort from reverting to siloed maintenance routines.</p>"
        },
        section2: {
          heading: "Designing adaptive map interfaces",
          body: "<p>Once data foundations are reliable, interface design translates them into legible experiences. We build adaptive layers that respond to context: orientation mode for first-time visitors uses simplified landmarks and animated routing, whereas operations mode exposes service corridors and loading docks. Users can transition between modes without losing location, ensuring the map respects varying mental models.</p><p>Adaptive design also covers device capabilities. Desktop views include comparative tables for scheduling, while kiosk deployments focus on large touch targets and kinetic transitions to compensate for ambient glare. Mobile views preload offline tiles for areas with limited connectivity, reinforcing trust during field use.</p>",
          subheading: "Inclusive interaction patterns",
          subbody: "<p>Interactive maps must address accessibility beyond compliance checklists. We implement keyboard-first navigation, high-contrast palettes, and adjustable text magnification. For neurodiverse users, the map offers linear storyboards that break down routes into step-by-step panels rather than relying solely on spatial abstraction.</p><p>Language diversity is equivalent in importance. The interface supports side-by-side bilingual labels and allows users to toggle typographic emphasis when one language employs longer descriptions. Phonetic transcripts can be added for terms with complex pronunciation, assisting visitor support teams.</p>"
        },
        section3: {
          heading: "Operationalising feedback loops",
          body: "<p>Harmonisation survives only if users can report discrepancies easily. We integrate a feedback widget that attaches geospatial coordinates, screenshot context, and role metadata to each submission. Reports are triaged automatically based on severity: safety-related issues generate immediate alerts, while cosmetic adjustments enter the weekly queue.</p><p>Analytics monitor how users traverse the map, revealing dead ends where filters conflict or where too many layers overlap. We translate these findings into backlog items for the metadata guild and interface designers. The shared dashboard keeps accountability transparent.</p>",
          subheading: "Long-term governance",
          subbody: "<p>Long-term governance intertwines policy and tooling. We document service-level expectations for update frequencies, define onboarding procedures for new departments, and maintain a testing sandbox mirroring production. Automation scripts validate geometry integrity, flagging self-intersections or orphaned nodes before publication.</p><p>Finally, we invest in knowledge transfer. Workshops and documentation explain how harmonised data supports navigation, event planning, and asset management. When stakeholders understand the collective value, they are more likely to respect naming conventions and contribute timely updates, ensuring the interactive campus map remains a trustworthy companion.</p>"
        }
      },
      post4: {
        title: "Adaptive visual guidance in complex urban districts",
        meta: "Published on 11 December 2023 • 9-minute read",
        imageAlt: "Adaptive urban lighting guiding pedestrians",
        lead: "Complex urban districts blend transit nodes, retail, housing, and civic functions. Visitors seldom experience the district as a single journey; instead, they weave across plazas, underpasses, and arcade passages with shifting objectives. Adaptive visual guidance acknowledges this variability by continuously tuning cues to context. Our fieldwork in Belgian urban renewal projects demonstrates how carefully staged visuals can maintain legibility without resorting to intrusive policing or intrusive soundscapes.",
        section1: {
          heading: "Observing urban micro-geographies",
          body: "<p>Observation begins with micro-geographies—street segments that behave differently depending on adjacent uses. We map how light, vegetation, storefront reflections, and public art influence sightlines. Night-time footage is compared with daytime sequences to detect blind corners or overly luminous facades that overpower signage. These observations inform zoning categories for guidance interventions.</p><p>Community walks supplement recordings. Residents annotate emotional responses to spaces, noting where they feel disoriented or hurried. Their insights often point to intangible triggers such as abrupt paving changes or informal vendor clusters. Documenting these perceptions prevents us from relying solely on technical lux readings or circulation counts.</p>",
          subheading: "Temporal layering of cues",
          subbody: "<p>Temporal layering recognises that a district’s pulse changes hourly. Morning commuter streams demand fast, high-contrast cues, while weekend promenades benefit from slower, exploratory prompts. We therefore script a timeline stating which visual assets activate during each time band. Digital facades can dim to reveal projected arrows at dawn, then switch to cultural storytelling after sunset.</p><p>Temporal scripts also integrate exceptional scenarios. During construction, for example, temporary overlays are added to guide pedestrians around barriers. They fade once work is completed, avoiding the lingering of obsolete signs. The script ensures the district never accumulates confusing residues.</p>"
        },
        section2: {
          heading: "Designing adaptive visual systems",
          body: "<p>Adaptive systems rely on modular elements that can be reprogrammed. We deploy LED fins, ground-level light ribbons, and e-paper panels capable of remotely updated messaging. Modules are arranged so that each decision point offers at least two complementary cues—one directional, one confirmatory. This redundancy supports users with different perceptual strengths.</p><p>Material selection matters. Diffused polycarbonate protects electronics from weather while maintaining uniform luminance. Anti-glare coatings prevent unintended reflections on rainy nights. Installations are tested with pedestrian groups using mobility aids to confirm that the modules neither obstruct paths nor create tripping hazards.</p>",
          subheading: "Responsive lighting strategies",
          subbody: "<p>Responsive lighting draws inputs from sensors tracking crowd density and ambient light. When foot traffic intensifies, the system widens the luminous path to disperse flows. In quieter hours, intensity reduces to conserve energy while still signalling safe routes. Algorithms are calibrated to avoid abrupt changes that might startle passers-by.</p><p>We pair responsive lighting with analogue markers such as reflective tiles and textured balustrades. Should sensors fail, the analogue layer still conveys direction. Regular drills with maintenance teams rehearse fallback procedures to swap modules or trigger static presets.</p>"
        },
        section3: {
          heading: "Evaluating long-term adaptation",
          body: "<p>Evaluation extends beyond technical uptime. We run seasonal audits capturing pedestrian trajectories via anonymised cameras and compare them with baseline studies. Surveys conducted through neighbourhood councils gather qualitative impressions about comfort, orientation, and placemaking. Combining metrics prevents overreliance on any single indicator.</p><p>Findings inform annual recalibration sessions where we tweak scripts, replace content, and adjust sensor thresholds. These sessions are scheduled before major events to ensure the district is prepared for atypical flows.</p>",
          subheading: "Collaborative stewardship",
          subbody: "<p>Adaptive guidance thrives when stewardship is shared. We facilitate agreements between municipal lighting departments, cultural curators, retailers, and resident associations. Each stakeholder sponsors specific modules, funding maintenance while contributing programming ideas. Shared ownership deters vandalism and accelerates response when issues arise.</p><p>Transparent documentation backs the partnership. Every change is logged in a digital atlas describing rationale, expected lifespan, and contact points. The atlas doubles as a training tool for new staff, safeguarding continuity as teams evolve.</p>"
        }
      },
      post5: {
        title: "Measuring pedestrian flow response to dynamic signage",
        meta: "Published on 23 November 2023 • 9-minute read",
        imageAlt: "Sensors analysing pedestrian flows",
        lead: "Dynamic signage promises to modulate pedestrian flows during peak periods, but evidence must underpin each claim. Our measurement framework combines spatial analytics, ethnographic observation, and statistical modelling to evaluate how pedestrians respond when content changes in real time. The aim is to understand causality, distinguishing genuine behavioural shifts from coincidental fluctuations caused by external events such as weather or transport delays.",
        section1: {
          heading: "Establishing baseline flow models",
          body: "<p>We begin by constructing baseline models using fixed-period observations before any dynamic content is introduced. Sensors positioned at strategic choke points collect directional counts, speed distributions, and dwell durations. These readings are synchronised with manual annotations capturing group sizes and luggage presence, variables that often influence pace.</p><p>Baselines are contextualised with environmental metadata. We log concurrent service schedules, nearby retail promotions, and public transport headways. This context guards against misinterpreting a spontaneous festival crowd as a signage effect. The baseline model is updated weekly until variance stabilises within agreed thresholds.</p>",
          subheading: "Segmenting user cohorts",
          subbody: "<p>Responses to signage vary by cohort. We classify pedestrians into commuters, visitors, and logistics staff using a mix of survey data and anonymised device presence counts. Each cohort receives its own baseline metrics, preventing averages from hiding outliers. For example, commuters might adjust routes quickly, while visitors need repeated exposures.</p><p>Segment profiles also include accessibility considerations. Wheelchair users, parents with strollers, and individuals with sensory sensitivities are tracked through voluntary beacon programmes and observational sampling. Their experiences inform the calibration of font sizes, animation speed, and audio supplements.</p>"
        },
        section2: {
          heading: "Deploying dynamic content experiments",
          body: "<p>Dynamic experiments follow an A/B/A pattern to isolate effects. Phase A runs static signage, Phase B introduces dynamic content, and the final A returns to static cues. Each phase spans identical time windows across multiple days. Content variations include directional arrows that enlarge under congestion, countdown timers for escalator capacity, and contextual prompts that suggest alternate corridors.</p><p>During each phase we collect not only flow metrics but also qualitative feedback through intercept interviews. Questions probe perceived clarity, stress levels, and trust in the information. Qualitative insights warn us when statistical improvements mask negative sentiment.</p>",
          subheading: "Sensor fusion methods",
          subbody: "<p>To increase reliability, we fuse data from thermal cameras, LiDAR units, and floor pressure sensors. Thermal cameras deliver accurate counts without biometrics, LiDAR captures trajectory vectors, and pressure mats confirm occupancy in covered walkways. Sensor fusion algorithms reconcile disparities by weighting sources according to situational accuracy.</p><p>We calibrate sensors daily using reference walks. Technicians traverse mapped paths while holding calibration tags, allowing the system to adjust for drift. Automated alerts trigger when discrepancies exceed tolerance bands, ensuring experiment data remains trustworthy.</p>"
        },
        section3: {
          heading: "Interpreting outcomes",
          body: "<p>Outcome interpretation combines quantitative deltas with qualitative narratives. We analyse how corridor load factors shift between phases and whether bottlenecks dissolve or merely migrate. Heatmaps reveal secondary impacts, such as increased usage of staircases previously overlooked. These visuals are presented to stakeholders alongside interview excerpts for balanced decision-making.</p><p>We also examine resilience. If dynamic signage reduces congestion but requires constant operator intervention, the benefit may be unsustainable. Maintenance logs and staffing requirements are therefore integrated into the evaluation.</p>",
          subheading: "Embedding insights into policy",
          subbody: "<p>Insights feed into policy recommendations that specify when dynamic signage should activate, who authorises new content, and how performance is audited. Policies define trigger thresholds—such as passenger density or incident reports—that automatically switch content playlists.</p><p>Finally, we share results with neighbouring districts to encourage interoperable practices. When adjacent spaces adopt compatible triggers and visual grammars, pedestrians experience seamless guidance rather than contradictory instructions. Shared learning accelerates refinement and reinforces public confidence in dynamic signage as a legitimate stewardship tool.</p>"
        }
      }
    },
    contact: {
      hero: {
        title: "Contact and map",
        subtitle: "Let’s explore your spatial orientation needs together. Share context, constraints, and ambitions so we can craft a precise study frame.",
        imageAlt: "Detailed Brussels map highlighting Rue de la Loi"
      },
      info: {
        heading: "Primary contact",
        text: "Available for exploratory conversations, framing workshops, and operational team support.",
        phoneLabel: "Phone",
        emailLabel: "Email",
        addressLabel: "Address",
        schedule: "Availability: Monday to Thursday • 09:00 — 17:30",
        phoneNumber: "+32 2 123 45 67",
        emailAddress: "contact@danswholesaleplants.com"
      },
      map: {
        heading: "Location",
        description: "Locate our workspace in the heart of Brussels."
      },
      form: {
        heading: "Contact form",
        description: "Share key details about your environment. We will respond with framing options.",
        nameLabel: "Full name",
        namePlaceholder: "Your full name",
        emailLabel: "Email address",
        emailPlaceholder: "name@organisation.be",
        organisationLabel: "Organisation",
        organisationPlaceholder: "Organisation name",
        phoneLabel: "Phone",
        phonePlaceholder: "+32 ...",
        messageLabel: "Description of your environment and questions",
        messagePlaceholder: "Explain your challenges, priorities, and preferred timeline.",
        submit: "Submit and document",
        notice: "Information is used to prepare a tailored exchange. See the privacy policy for details."
      },
      support: {
        heading: "Prepare your message",
        text: "To accelerate our understanding, detail audiences, existing supports, and current limitations.",
        list: "<li>Available maps or plans with update dates</li><li>Number of languages used across communications</li><li>Existing metrics or observations gathered on site</li>"
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        subtitle: "Clarifications about our methods, deliverables, and collaboration modes.",
        imageAlt: "Analytical documents and annotated plans"
      },
      intro: {
        text: "Find answers about how we approach complex environments and structure engagements."
      },
      questions: {
        q1: {
          question: "Which observation methods do you favour?",
          answer: "We combine guided journeys, video capture, anonymised flow counters, and participatory workshops. The objective is to bridge qualitative perception with quantitative metrics."
        },
        q2: {
          question: "How do you secure linguistic parity?",
          answer: "Content is audited in French, Dutch, and English when required. We review label length, pronunciation, iconography, and tactile or audio redundancy."
        },
        q3: {
          question: "What deliverables do you provide?",
          answer: "Experience maps, decision matrices, bilingual lexicons, temporal scripts, interactive prototypes, and governance playbooks."
        },
        q4: {
          question: "Do you support implementation?",
          answer: "We assist during implementation alongside internal teams and suppliers, ensuring alignment with validated scenarios."
        },
        q5: {
          question: "How is impact measured?",
          answer: "By tracking travel times, perceived stress, assistance requests, and seasonal sensory audits."
        },
        q6: {
          question: "Do you work exclusively in Belgium?",
          answer: "Our research roots are in Belgium, yet the methodological frameworks can adapt to other European contexts while accounting for local specifics."
        }
      }
    },
    terms: {
      hero: {
        title: "Terms of use",
        subtitle: "Legal framework governing access to published content.",
        imageAlt: "Legal documents on a desk"
      },
      sections: {
        s1: {
          title: "1. Purpose",
          text: "These terms govern access to danswholesaleplants.com and the use of analytical content, publications, tools, and documents provided."
        },
        s2: {
          title: "2. Definitions",
          text: "“Site” refers to danswholesaleplants.com. “User” means any person consulting the content. “Content” covers texts, graphics, videos, and downloadable documents."
        },
        s3: {
          title: "3. Acceptance",
          text: "By accessing the Site, the User accepts these terms without reservation. Any misuse may lead to restricted access."
        },
        s4: {
          title: "4. Intellectual property",
          text: "Published content belongs to danswholesaleplants or its partners. Reproduction or distribution without written permission is forbidden."
        },
        s5: {
          title: "5. Content usage",
          text: "Content is provided for informational and research purposes. It may not be repackaged as a competing service nor asserted as definitive operational advice."
        },
        s6: {
          title: "6. External contributions",
          text: "When partners contribute content, their rights remain protected. Quotation must respect agreed conditions."
        },
        s7: {
          title: "7. Information accuracy",
          text: "We strive for reliable information without guaranteeing absolute accuracy. Content may be updated without notice."
        },
        s8: {
          title: "8. User responsibility",
          text: "Users guarantee lawful usage and agree not to compromise system integrity nor collect data through automated means."
        },
        s9: {
          title: "9. Accessibility",
          text: "The Site is designed for broad accessibility. Continuous improvements are introduced based on user feedback."
        },
        s10: {
          title: "10. External links",
          text: "Links to other sites may be provided. danswholesaleplants is not responsible for third-party content."
        },
        s11: {
          title: "11. Security",
          text: "Technical measures safeguard information flows. Users acknowledge residual risks inherent to internet transmission."
        },
        s12: {
          title: "12. Changes",
          text: "These terms may evolve. The revision date is displayed and Users are encouraged to review them regularly."
        },
        s13: {
          title: "13. Governing law",
          text: "These terms are governed by Belgian law. Disputes fall under the jurisdiction of Brussels courts."
        },
        s14: {
          title: "14. Contact",
          text: "Questions regarding these terms can be sent to contact@danswholesaleplants.com or Rue de la Loi 200, 1040 Brussels."
        }
      }
    },
    privacy: {
      hero: {
        title: "Privacy policy",
        subtitle: "Transparency on how personal data is collected and used.",
        imageAlt: "Security and data icons"
      },
      sections: {
        s1: {
          title: "1. Introduction",
          text: "This policy explains how danswholesaleplants processes personal data collected through the Site and during professional exchanges."
        },
        s2: {
          title: "2. Data collected",
          text: "We collect information submitted via the contact form (name, email, organisation, message) and anonymised technical data (server logs, audience metrics)."
        },
        s3: {
          title: "3. Purposes",
          text: "Data supports responses to enquiries, meeting planning, Site improvement, and technical security."
        },
        s4: {
          title: "4. Legal basis",
          text: "Processing relies on our legitimate interest in responding to requests and on consent when required (optional cookies)."
        },
        s5: {
          title: "5. Retention",
          text: "Contact data is retained for the time needed to follow up and archived for up to 24 months. Technical logs are kept 12 months."
        },
        s6: {
          title: "6. Sharing",
          text: "Data is not sold. It may be shared with technical providers delivering hosting or maintenance under confidentiality clauses."
        },
        s7: {
          title: "7. International transfers",
          text: "Data is hosted within the European Union. No transfer outside the EU occurs without adequate safeguards."
        },
        s8: {
          title: "8. Rights",
          text: "You can access, rectify, delete, restrict, or oppose processing. Contact contact@danswholesaleplants.com to exercise your rights."
        },
        s9: {
          title: "9. Security",
          text: "Technical (TLS encryption, access controls) and organisational measures protect data against unauthorised access."
        },
        s10: {
          title: "10. Updates",
          text: "This policy may change. The revision date is displayed; please review it periodically."
        }
      }
    },
    cookies: {
      hero: {
        title: "Cookie policy",
        subtitle: "Manage the trackers used on danswholesaleplants.com.",
        imageAlt: "Cookie preference illustration"
      },
      intro: "Cookies are files stored on your device to ensure the Site works properly, measure anonymous usage, and remember preferences. You can adjust your choices anytime.",
      essentials: "Necessary cookies secure the site and remember your language choice. They are always active.",
      optional: "Preference, analytics, and marketing cookies remain disabled until you consent.",
      tableHeading: "List of cookies used",
      table: {
        name: "Name",
        provider: "Provider",
        type: "Type",
        purpose: "Purpose",
        duration: "Duration",
        rows: {
          row1: {
            name: "site_session",
            provider: "danswholesaleplants",
            type: "Necessary",
            purpose: "Maintains a secure session across pages.",
            duration: "24 hours"
          },
          row2: {
            name: "lang_pref",
            provider: "danswholesaleplants",
            type: "Preferences",
            purpose: "Stores the language selected via the toggle.",
            duration: "12 months"
          },
          row3: {
            name: "consent_state",
            provider: "danswholesaleplants",
            type: "Necessary",
            purpose: "Records your consent configuration.",
            duration: "12 months"
          },
          row4: {
            name: "traffic_sample",
            provider: "danswholesaleplants",
            type: "Analytics",
            purpose: "Anonymous measurement of navigation flows.",
            duration: "6 months"
          }
        }
      },
      management: "You can adjust preferences via the banner at any time or by clearing cookies in your browser.",
      contact: "Questions about cookies? Reach contact@danswholesaleplants.com."
    },
    refund: {
      hero: {
        title: "Revision policy",
        subtitle: "Procedure when an analytical deliverable requires review.",
        imageAlt: "Discussion around an audit report"
      },
      sections: {
        s1: {
          title: "1. Purpose",
          text: "This policy explains how danswholesaleplants handles revision requests when analytical deliverables need adjustments."
        },
        s2: {
          title: "2. Scope",
          text: "It applies to studies, diagnostics, and prototypes delivered through research or advisory collaborations."
        },
        s3: {
          title: "3. Eligibility",
          text: "A request is valid when a significant gap between deliverables and the initial framing is documented within 30 days of delivery."
        },
        s4: {
          title: "4. Procedure",
          text: "Requests must be emailed to contact@danswholesaleplants.com, detailing the deliverable, date, and nature of the observed gap."
        },
        s5: {
          title: "5. Joint review",
          text: "A meeting is scheduled to examine evidence. Additional information may be requested."
        },
        s6: {
          title: "6. Response scenarios",
          text: "Depending on findings, danswholesaleplants may offer an adjustment, a targeted iteration, or confirm alignment with the agreed frame."
        },
        s7: {
          title: "7. Timeline",
          text: "Responses are issued within 15 business days after receiving the necessary information."
        },
        s8: {
          title: "8. Limits",
          text: "Requests arising from scope expansion or new objectives are treated as separate engagements."
        },
        s9: {
          title: "9. Escalation",
          text: "If disagreement persists, an external mediator can be appointed jointly."
        },
        s10: {
          title: "10. Contact",
          text: "Questions about this policy? Write to contact@danswholesaleplants.com."
        }
      }
    },
    disclaimer: {
      hero: {
        title: "Disclaimer",
        subtitle: "Usage limits of published material.",
        imageAlt: "Informational warning sign"
      },
      sections: {
        s1: {
          title: "1. General information",
          text: "Site content is provided for informational purposes and does not constitute contractual commitments."
        },
        s2: {
          title: "2. No guarantee",
          text: "danswholesaleplants does not guarantee exhaustiveness or permanent accuracy of published information."
        },
        s3: {
          title: "3. Operational decisions",
          text: "Decisions taken using the content remain the sole responsibility of the User."
        },
        s4: {
          title: "4. External references",
          text: "Third-party links are provided for convenience; their content remains under their publishers’ responsibility."
        },
        s5: {
          title: "5. Liability limitation",
          text: "danswholesaleplants cannot be held liable for direct or indirect damages resulting from Site usage."
        },
        s6: {
          title: "6. Contact",
          text: "Questions regarding this notice? Contact contact@danswholesaleplants.com."
        }
      }
    },
    thankYou: {
      hero: {
        title: "Thank you for reaching out",
        subtitle: "We will return shortly with framing proposals.",
        imageAlt: "Person reading a confirmation message"
      },
      body: "Your message has been delivered. We are analysing the details and will reply within two business days.",
      nextSteps: {
        heading: "Next steps",
        text: "Gather plans, metrics, and documents that support our upcoming conversation.",
        list: "<li>Clarify your primary objectives</li><li>Identify stakeholders to involve</li><li>Prepare timing constraints</li>"
      },
      button: "Return home"
    },
    notFound: {
      hero: {
        title: "Page not found",
        subtitle: "The resource you’re looking for is unavailable or has moved.",
        imageAlt: "Wayfinding sign indicating a detour"
      },
      description: "Use the main navigation to continue exploring or head back to the homepage.",
      button: "Return home"
    },
    cookieBanner: {
      title: "Cookie preferences",
      description: "We use cookies to secure the site, remember your language, and analyse usage (optional). Adjust your preferences below.",
      toggles: {
        necessary: "Necessary",
        preferences: "Preferences",
        analytics: "Analytics",
        marketing: "Marketing"
      },
      buttons: {
        acceptAll: "Accept all",
        declineAll: "Decline all",
        save: "Save choices",
        manage: "Manage preferences"
      },
      necessaryText: "Always active to ensure site security and core functionality."
    },
    toast: {
      contactSuccess: "Thank you! Your message has been sent.",
      formError: "Please complete required fields before submitting.",
      cookieSaved: "Your cookie preferences are saved.",
      cookieDeclined: "Optional cookies disabled."
    },
    form: {
      validation: "Some required fields are missing."
    }
  }
};

let currentLang = DEFAULT_LANG;

function getTranslation(lang, key) {
  const segments = key.split(".");
  let value = I18N[lang];
  for (const segment of segments) {
    if (value && Object.prototype.hasOwnProperty.call(value, segment)) {
      value = value[segment];
    } else {
      return undefined;
    }
  }
  return value;
}

function formatValue(value) {
  if (typeof value === "string") {
    return value.replace(/\{\{year\}\}/g, String(new Date().getFullYear()));
  }
  return value;
}

function applyTranslations(lang) {
  if (!I18N[lang]) {
    lang = DEFAULT_LANG;
  }
  currentLang = lang;
  document.documentElement.setAttribute("lang", lang);
  const textNodes = document.querySelectorAll("[data-i18n]");
  textNodes.forEach((node) => {
    const key = node.dataset.i18n;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      node.textContent = formatValue(translation);
    }
  });

  const htmlNodes = document.querySelectorAll("[data-i18n-html]");
  htmlNodes.forEach((node) => {
    const key = node.dataset.i18nHtml;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      node.innerHTML = formatValue(translation);
    }
  });

  const placeholderNodes = document.querySelectorAll("[data-i18n-placeholder]");
  placeholderNodes.forEach((node) => {
    const key = node.dataset.i18nPlaceholder;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      node.setAttribute("placeholder", formatValue(translation));
    }
  });

  const altNodes = document.querySelectorAll("[data-i18n-alt]");
  altNodes.forEach((node) => {
    const key = node.dataset.i18nAlt;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      node.setAttribute("alt", formatValue(translation));
    }
  });

  const ariaNodes = document.querySelectorAll("[data-i18n-aria-label]");
  ariaNodes.forEach((node) => {
    const key = node.dataset.i18nAriaLabel;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      node.setAttribute("aria-label", formatValue(translation));
    }
  });

  const titleNode = document.querySelector("[data-i18n-title]");
  if (titleNode) {
    const key = titleNode.dataset.i18nTitle;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      document.title = formatValue(translation);
    }
  }

  const metaNodes = document.querySelectorAll("[data-i18n-meta]");
  metaNodes.forEach((meta) => {
    const key = meta.dataset.i18nMeta;
    const translation = getTranslation(lang, key);
    if (translation !== undefined) {
      meta.setAttribute("content", formatValue(translation));
    }
  });

  const langButtons = document.querySelectorAll("[data-lang]");
  langButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.lang === lang);
    button.setAttribute("aria-pressed", button.dataset.lang === lang ? "true" : "false");
  });
}

function setLanguage(lang) {
  const targetLang = I18N[lang] ? lang : DEFAULT_LANG;
  localStorage.setItem(LANG_KEY, targetLang);
  applyTranslations(targetLang);
}

function initialiseLanguage() {
  const stored = localStorage.getItem(LANG_KEY);
  const initialLang = stored && I18N[stored] ? stored : DEFAULT_LANG;
  applyTranslations(initialLang);
}

function toggleNavigation() {
  const navLinks = document.querySelector(".nav-links");
  const navToggle = document.querySelector(".nav-toggle");
  if (!navLinks || !navToggle) return;
  const isOpen = navLinks.classList.toggle("is-open");
  navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
}

function setupNavigation() {
  const navToggle = document.querySelector(".nav-toggle");
  if (navToggle) {
    navToggle.addEventListener("click", toggleNavigation);
  }
  const navLinks = document.querySelectorAll(".nav-link");
  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      const navList = document.querySelector(".nav-links");
      const navButton = document.querySelector(".nav-toggle");
      if (navList && navButton) {
        navList.classList.remove("is-open");
        navButton.setAttribute("aria-expanded", "false");
      }
    });
  });
}

function setupLanguageButtons() {
  document.querySelectorAll("[data-lang]").forEach((button) => {
    button.addEventListener("click", () => {
      const lang = button.dataset.lang;
      setLanguage(lang);
    });
  });
}

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.1 }
);

function setupRevealAnimations() {
  document.querySelectorAll(".reveal-on-scroll").forEach((el) => observer.observe(el));
}

function showToast(key, type = "info") {
  const container = document.querySelector(".toast-container");
  if (!container) return;
  const translation = getTranslation(currentLang, `toast.${key}`) || "";
  if (!translation) return;
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = translation;
  container.appendChild(toast);
  requestAnimationFrame(() => {
    toast.classList.add("is-visible");
  });
  setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 3600);
  setTimeout(() => {
    toast.remove();
  }, 4200);
}

function getCookieConsent() {
  try {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (!stored) return null;
    return JSON.parse(stored);
  } catch (error) {
    console.warn("Cookie consent parse error", error);
    return null;
  }
}

function saveCookieConsent(consent) {
  const payload = {
    necessary: true,
    preferences: Boolean(consent.preferences),
    analytics: Boolean(consent.analytics),
    marketing: Boolean(consent.marketing),
    updatedAt: new Date().toISOString()
  };
  localStorage.setItem(CONSENT_KEY, JSON.stringify(payload));
}

function applyConsentToUI(consent) {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;
  const toggles = banner.querySelectorAll("[data-cookie-toggle]");
  toggles.forEach((toggle) => {
    const category = toggle.dataset.cookieToggle;
    if (category === "necessary") {
      toggle.checked = true;
      toggle.disabled = true;
    } else {
      toggle.checked = consent ? Boolean(consent[category]) : false;
    }
  });
}

function hideCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (banner) {
    banner.classList.add("is-hidden");
  }
}

function showCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (banner) {
    banner.classList.remove("is-hidden");
  }
}

function setupCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  if (!banner) return;

  const consent = getCookieConsent();
  if (consent) {
    applyConsentToUI(consent);
    hideCookieBanner();
  } else {
    showCookieBanner();
  }

  banner.querySelectorAll("[data-cookie-toggle]").forEach((toggle) => {
    toggle.addEventListener("change", () => {
      const stored = getCookieConsent() || { necessary: true, preferences: false, analytics: false, marketing: false };
      const category = toggle.dataset.cookieToggle;
      stored[category] = toggle.checked;
      saveCookieConsent(stored);
    });
  });

  const acceptAll = banner.querySelector("[data-cookie-action='accept']");
  if (acceptAll) {
    acceptAll.addEventListener("click", () => {
      const consentAll = { necessary: true, preferences: true, analytics: true, marketing: true };
      saveCookieConsent(consentAll);
      applyConsentToUI(consentAll);
      hideCookieBanner();
      showToast("cookieSaved", "success");
    });
  }

  const declineAll = banner.querySelector("[data-cookie-action='decline']");
  if (declineAll) {
    declineAll.addEventListener("click", () => {
      const consentNone = { necessary: true, preferences: false, analytics: false, marketing: false };
      saveCookieConsent(consentNone);
      applyConsentToUI(consentNone);
      hideCookieBanner();
      showToast("cookieDeclined", "info");
    });
  }

  const save = banner.querySelector("[data-cookie-action='save']");
  if (save) {
    save.addEventListener("click", () => {
      const toggles = banner.querySelectorAll("[data-cookie-toggle]");
      const stored = { necessary: true, preferences: false, analytics: false, marketing: false };
      toggles.forEach((toggle) => {
        const category = toggle.dataset.cookieToggle;
        if (category !== "necessary") {
          stored[category] = toggle.checked;
        }
      });
      saveCookieConsent(stored);
      hideCookieBanner();
      showToast("cookieSaved", "success");
    });
  }

  const manage = banner.querySelector("[data-cookie-action='manage']");
  if (manage) {
    manage.addEventListener("click", () => {
      banner.classList.toggle("is-expanded");
    });
  }
}

function setupContactForm() {
  const form = document.querySelector("[data-form='contact']");
  if (!form) return;
  form.addEventListener("submit", (event) => {
    if (!form.checkValidity()) {
      event.preventDefault();
      form.reportValidity();
      showToast("formError", "error");
      return;
    }
    event.preventDefault();
    showToast("contactSuccess", "success");
    setTimeout(() => {
      window.location.href = form.getAttribute("action");
    }, 800);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initialiseLanguage();
  setupNavigation();
  setupLanguageButtons();
  setupRevealAnimations();
  setupCookieBanner();
  setupContactForm();
});