document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  if (!banner) return;

  const status = localStorage.getItem('provocacia-cookie');

  const showBanner = () => {
    setTimeout(() => banner.classList.add('is-visible'), 600);
  };

  if (!status) {
    showBanner();
  }

  const acceptBtn = banner.querySelector('[data-cookie-accept]');
  const declineBtn = banner.querySelector('[data-cookie-decline]');

  const hideBanner = () => {
    banner.classList.remove('is-visible');
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      localStorage.setItem('provocacia-cookie', 'accepted');
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', () => {
      localStorage.setItem('provocacia-cookie', 'declined');
      hideBanner();
    });
  }
});