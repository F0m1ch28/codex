import React, { useEffect, useState } from "react";
import styles from "./CookieBanner.module.css";
import { NavLink } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";
import { translations } from "../i18n/translations";

const CookieBanner = () => {
  const { language } = useLanguage();
  const t = translations[language].cookie;
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("tph-cookie-consent");
      if (!stored) {
        const timer = setTimeout(() => setVisible(true), 1200);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const handleConsent = (consent) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("tph-cookie-consent", consent ? "accepted" : "declined");
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>{t.message}</p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.decline}
            onClick={() => handleConsent(false)}
          >
            {t.decline}
          </button>
          <button
            type="button"
            className={styles.accept}
            onClick={() => handleConsent(true)}
          >
            {t.accept}
          </button>
          <NavLink to="/cookies" className={styles.link}>
            {t.manage}
          </NavLink>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;