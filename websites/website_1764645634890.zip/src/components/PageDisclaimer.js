import React from "react";
import styles from "./PageDisclaimer.module.css";
import { translations } from "../i18n/translations";
import { useLanguage } from "../context/LanguageContext";

const PageDisclaimer = () => {
  const { language } = useLanguage();
  const d = translations[language].disclaimer;

  return (
    <section className={styles.wrapper} aria-live="polite">
      <div className="container">
        <div className={styles.card}>
          <strong>{d.intro}</strong>
          <p lang="en">{d.en}</p>
          <p lang="es">{d.es}</p>
          <p lang="ru">{d.ru}</p>
          <span className={styles.note}>{d.note}</span>
        </div>
      </div>
    </section>
  );
};

export default PageDisclaimer;