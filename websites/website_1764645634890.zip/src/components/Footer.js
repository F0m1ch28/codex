import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";
import { useLanguage } from "../context/LanguageContext";
import { translations } from "../i18n/translations";

const Footer = () => {
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <footer className={styles.footer}>
      <div className={`${styles.footerContainer} container`}>
        <div className={styles.brand}>
          <h2>Tu Progreso Hoy</h2>
          <p>{t.footer.headline}</p>
          <address className={styles.address}>
            <span>{t.footer.address}</span>
            <a href="tel:+541155551234">{t.footer.phone}</a>
            <a href="mailto:contact@tuprogresohoy.com">
              contact@tuprogresohoy.com
            </a>
          </address>
        </div>

        <div className={styles.links}>
          <h3>{language === "en" ? "Company" : "Compañía"}</h3>
          <NavLink to="/about">{t.nav.about}</NavLink>
          <NavLink to="/services">{t.nav.services}</NavLink>
          <NavLink to="/resources">{t.nav.resources}</NavLink>
          <NavLink to="/course">{t.nav.course}</NavLink>
        </div>

        <div className={styles.links}>
          <h3>{language === "en" ? "Policies" : "Políticas"}</h3>
          <NavLink to="/privacy">
            {language === "en" ? "Privacy Policy" : "Política de privacidad"}
          </NavLink>
          <NavLink to="/cookies">
            {language === "en"
              ? "Cookie Policy"
              : "Política de cookies"}
          </NavLink>
          <NavLink to="/terms">
            {language === "en" ? "Terms of Service" : "Términos de uso"}
          </NavLink>
        </div>

        <div className={styles.links}>
          <h3>{language === "en" ? "Stay connected" : "Conexión"}</h3>
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
          >
            LinkedIn
          </a>
          <a
            href="https://twitter.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="X"
          >
            X (Twitter)
          </a>
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
          >
            Instagram
          </a>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>{t.footer.copyrights}</span>
      </div>
    </footer>
  );
};

export default Footer;