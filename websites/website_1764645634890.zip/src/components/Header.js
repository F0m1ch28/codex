import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";
import { useLanguage } from "../context/LanguageContext";
import { translations } from "../i18n/translations";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const { language, setLanguage } = useLanguage();
  const t = translations[language];

  const toggleMenu = () => setMenuOpen((open) => !open);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          <span className={styles.logoAccent}>Tu</span> Progreso Hoy
        </NavLink>

        <nav
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ""}`}
          aria-label="Primary navigation"
        >
          <NavLink
            to="/"
            onClick={closeMenu}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.active : ""}`
            }
          >
            {t.nav.home}
          </NavLink>
          <NavLink
            to="/inflation"
            onClick={closeMenu}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.active : ""}`
            }
          >
            {t.nav.inflation}
          </NavLink>
          <NavLink
            to="/course"
            onClick={closeMenu}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.active : ""}`
            }
          >
            {t.nav.course}
          </NavLink>
          <NavLink
            to="/resources"
            onClick={closeMenu}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.active : ""}`
            }
          >
            {t.nav.resources}
          </NavLink>
          <NavLink
            to="/about"
            onClick={closeMenu}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.active : ""}`
            }
          >
            {t.nav.about}
          </NavLink>
          <NavLink
            to="/services"
            onClick={closeMenu}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.active : ""}`
            }
          >
            {t.nav.services}
          </NavLink>
          <NavLink
            to="/contact"
            onClick={closeMenu}
            className={({ isActive }) =>
              `${styles.navItem} ${isActive ? styles.active : ""}`
            }
          >
            {t.nav.contact}
          </NavLink>
        </nav>

        <div className={styles.actions}>
          <button
            type="button"
            className={styles.languageSwitch}
            onClick={() => setLanguage(language === "en" ? "es" : "en")}
            aria-label={language === "en" ? "Cambiar a español" : "Switch to English"}
          >
            {language === "en" ? "ES" : "EN"}
          </button>
          <NavLink
            to="/course"
            className={styles.cta}
            onClick={closeMenu}
            aria-label="Go to course page"
          >
            {language === "en" ? "View course" : "Ver curso"}
          </NavLink>
          <button
            className={`${styles.burger} ${menuOpen ? styles.burgerOpen : ""}`}
            type="button"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
            onClick={toggleMenu}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;