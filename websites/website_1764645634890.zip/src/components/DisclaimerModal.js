import React, { useEffect, useState } from "react";
import styles from "./DisclaimerModal.module.css";
import { useLanguage } from "../context/LanguageContext";
import { translations } from "../i18n/translations";

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);
  const { language } = useLanguage();
  const disclaimer = translations[language].disclaimer;

  useEffect(() => {
    if (typeof window !== "undefined") {
      const hasSeen = sessionStorage.getItem("tph-disclaimer");
      if (!hasSeen) {
        const timer = setTimeout(() => setOpen(true), 900);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const handleClose = () => {
    setOpen(false);
    if (typeof window !== "undefined") {
      sessionStorage.setItem("tph-disclaimer", "acknowledged");
    }
  };

  if (!open) return null;

  return (
    <div className={styles.overlay} role="alertdialog" aria-modal="true">
      <div className={styles.modal}>
        <h3>{disclaimer.intro}</h3>
        <p lang="en">{disclaimer.en}</p>
        <p lang="es">{disclaimer.es}</p>
        <p lang="ru">{disclaimer.ru}</p>
        <p className={styles.note}>{disclaimer.note}</p>
        <button type="button" onClick={handleClose} className={styles.close}>
          {language === "en" ? "Understood" : "Entendido"}
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;