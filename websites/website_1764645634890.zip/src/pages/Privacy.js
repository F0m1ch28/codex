import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Policy.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Tu Progreso Hoy</title>
    </Helmet>
    <section className={styles.policy}>
      <div className="container">
        <h1>Privacy Policy</h1>
        <p>Last updated: October 15, 2024</p>
        <h2>1. Introduction</h2>
        <p>
          Tu Progreso Hoy (“we”, “our”) operates tuprogresohoy.com to provide educational resources and data tools. This notice explains how we collect, use, and protect personal information in compliance with Argentine data protection frameworks (Ley 25.326) and international best practices.
        </p>
        <h2>2. Information we collect</h2>
        <ul>
          <li>
            <strong>Account details:</strong> name, email, organisation, language preference.
          </li>
          <li>
            <strong>Usage data:</strong> dashboard interactions, navigation patterns, device information.
          </li>
          <li>
            <strong>Communications:</strong> messages submitted through forms or email.
          </li>
        </ul>
        <h2>3. How we use information</h2>
        <p>
          We process data to deliver services, improve analytics, respond to inquiries, and send relevant updates. You may opt out of non-essential communications at any time.
        </p>
        <h2>4. Data retention</h2>
        <p>
          Personal data is retained for as long as you maintain an active relationship with Tu Progreso Hoy or as required by law. Aggregated and anonymised data may be stored indefinitely.
        </p>
        <h2>5. Sharing and transfers</h2>
        <p>
          We do not sell personal information. Trusted processors that support infrastructure or analytics operate under confidentiality agreements. International transfers follow appropriate safeguards.
        </p>
        <h2>6. Your rights</h2>
        <p>
          You can request access, correction, deletion, or portability of your personal data. Contact us at contact@tuprogresohoy.com with your request.
        </p>
        <h2>7. Security</h2>
        <p>
          We employ encryption, access controls, and regular audits to protect personal data. No method of transmission is completely secure; we encourage you to use strong passwords and enable available security features.
        </p>
        <h2>8. Contact</h2>
        <p>
          Tu Progreso Hoy · Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina · +54 11 5555-1234 · contact@tuprogresohoy.com
        </p>
      </div>
    </section>
    <PageDisclaimer />
  </>
);

export default Privacy;