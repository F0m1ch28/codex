import React from "react";
import { Helmet } from "react-helmet-async";
import { useForm } from "react-hook-form";
import styles from "./Contact.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const Contact = () => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting, isSubmitSuccessful },
  } = useForm({ mode: "onBlur" });

  const onSubmit = (data) =>
    new Promise((resolve) => {
      setTimeout(() => {
        console.log("Contact request", data);
        resolve();
      }, 1200);
    });

  return (
    <>
      <Helmet>
        <title>Contact Tu Progreso Hoy | Buenos Aires</title>
        <meta
          name="description"
          content="Connect with Tu Progreso Hoy. Visit us at Av. 9 de Julio 1000, Buenos Aires, or request a callback about inflation insights and our finance course."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Contact Tu Progreso Hoy</h1>
          <p>
            Reach our bilingual team in Buenos Aires. We respond within one business day.
          </p>
        </div>
      </section>

      <section className={styles.grid}>
        <div className="container">
          <div className={styles.info}>
            <h2>Visit or call us</h2>
            <p>
              Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
            </p>
            <p>
              Tel: <a href="tel:+541155551234">+54 11 5555-1234</a>
            </p>
            <p>
              Email:{" "}
              <a href="mailto:contact@tuprogresohoy.com">
                contact@tuprogresohoy.com
              </a>
            </p>

            <div className={styles.socials}>
              <a href="https://www.linkedin.com" aria-label="LinkedIn">
                LinkedIn
              </a>
              <a href="https://twitter.com" aria-label="Twitter">
                X
              </a>
              <a href="https://www.instagram.com" aria-label="Instagram">
                Instagram
              </a>
            </div>

            <div className={styles.mapWrapper}>
              <iframe
                title="Tu Progreso Hoy location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3284.029934646912!2d-58.383759523603386!3d-34.603734957457906!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccacf6ea091e1%3A0xcbcb9d360f1a9e4e!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          <div className={styles.formCard}>
            <h2>Request a consultation</h2>
            <form className={styles.form} onSubmit={handleSubmit(onSubmit)} noValidate>
              <label>
                Name
                <input
                  type="text"
                  {...register("name", { required: true, minLength: 3 })}
                  aria-invalid={errors.name ? "true" : "false"}
                />
                {errors.name && (
                  <small>Please enter at least 3 characters.</small>
                )}
              </label>
              <label>
                Email
                <input
                  type="email"
                  {...register("email", {
                    required: true,
                    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i,
                  })}
                  aria-invalid={errors.email ? "true" : "false"}
                />
                {errors.email && <small>Enter a valid email.</small>}
              </label>
              <label>
                Message
                <textarea
                  rows="4"
                  {...register("message", { required: true, minLength: 10 })}
                  aria-invalid={errors.message ? "true" : "false"}
                />
                {errors.message && (
                  <small>Tell us how we can help in at least 10 characters.</small>
                )}
              </label>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  {...register("consent", { required: true })}
                  aria-invalid={errors.consent ? "true" : "false"}
                />
                <span>
                  I agree to receive follow-up information about Tu Progreso Hoy.
                </span>
              </label>
              {errors.consent && <small>Consent is required.</small>}

              <button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Sending..." : "Send message"}
              </button>
              {isSubmitSuccessful && (
                <p className={styles.success}>
                  Thanks for reaching out. Please confirm the email we just sent to finalise your request.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>

      <PageDisclaimer />
    </>
  );
};

export default Contact;