import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Policy.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const Cookies = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Tu Progreso Hoy</title>
    </Helmet>
    <section className={styles.policy}>
      <div className="container">
        <h1>Cookie Policy</h1>
        <p>Last updated: October 15, 2024</p>
        <h2>1. Overview</h2>
        <p>
          Tu Progreso Hoy uses cookies and similar technologies to improve your browsing experience, analyse usage, and personalise content.
        </p>
        <h2>2. Types of cookies</h2>
        <ul>
          <li>
            <strong>Essential:</strong> Required for authentication, security, and site stability.
          </li>
          <li>
            <strong>Performance:</strong> Measure engagement with dashboards and pages.
          </li>
          <li>
            <strong>Functional:</strong> Remember language settings and display preferences.
          </li>
        </ul>
        <h2>3. Managing cookies</h2>
        <p>
          You can adjust preferences via the cookie banner or browser settings. Disabling cookies may affect functionality.
        </p>
        <h2>4. Third-party tools</h2>
        <p>
          Some analytics vendors may set cookies in line with their own policies. We vet all partners to ensure compliance and do not allow tracking for advertising purposes.
        </p>
        <h2>5. Updates</h2>
        <p>
          This policy may change as we add features. Updated versions are posted on this page.
        </p>
      </div>
    </section>
    <PageDisclaimer />
  </>
);

export default Cookies;