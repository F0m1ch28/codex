import React from "react";
import { Helmet } from "react-helmet-async";
import { useLocation, Link } from "react-router-dom";
import styles from "./ThankYou.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const ThankYou = () => {
  const location = useLocation();
  const email = location.state?.email;

  return (
    <>
      <Helmet>
        <title>Thank You | Tu Progreso Hoy</title>
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <h1>Thank you!</h1>
          <p>
            We’ve sent a confirmation email {email ? `to ${email}` : ""}. Please confirm to complete the double opt-in and unlock your access.
          </p>
          <Link to="/" className={styles.link}>
            Back to homepage
          </Link>
        </div>
      </section>
      <PageDisclaimer />
    </>
  );
};

export default ThankYou;