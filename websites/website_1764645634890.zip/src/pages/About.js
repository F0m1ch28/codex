import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./About.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const timeline = [
  {
    year: "2021",
    title: "Launched pilot dashboards",
    description:
      "Started with a group of Buenos Aires families needing real-time inflation context.",
  },
  {
    year: "2022",
    title: "Expanded to corporate teams",
    description:
      "Introduced bilingual briefings and accountability pods for HR and finance leaders.",
  },
  {
    year: "2023",
    title: "Course launch",
    description:
      "Formalised the personal finance course with modular content and mentor support.",
  },
  {
    year: "2024",
    title: "Data science integration",
    description:
      "Added predictive layers, automated alerts, and collaborative analytics requests.",
  },
];

const values = [
  {
    title: "Integrity with data",
    description:
      "Each dataset undergoes validation and context-building to keep decisions grounded.",
  },
  {
    title: "Community-first approach",
    description:
      "We listen to households, professionals, and teams to adapt learning formats.",
  },
  {
    title: "Bilingual clarity",
    description:
      "Every product is available in English and Spanish, lowering barriers to understanding.",
  },
];

const About = () => (
  <>
    <Helmet>
      <title>About Tu Progreso Hoy | Buenos Aires Team</title>
      <meta
        name="description"
        content="Learn about Tu Progreso Hoy’s mission, timeline, and values. Based in Buenos Aires, delivering data-informed financial education."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>We translate Argentine data into confident decisions</h1>
        <p>
          Tu Progreso Hoy nació en Buenos Aires para acompañar a quienes planifican entre inflación y volatilidad cambiaria. Our mission is to blend macro insights with personal finance coaching.
        </p>
      </div>
    </section>

    <section className={styles.timeline}>
      <div className="container">
        <h2>Milestones</h2>
        <div className={styles.timelineGrid}>
          {timeline.map((item) => (
            <article key={item.year} className={styles.timelineCard}>
              <span>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.values}>
      <div className="container">
        <h2>Our values</h2>
        <div className={styles.valuesGrid}>
          {values.map((value) => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <PageDisclaimer />
  </>
);

export default About;