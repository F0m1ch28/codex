import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Policy.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Service | Tu Progreso Hoy</title>
    </Helmet>
    <section className={styles.policy}>
      <div className="container">
        <h1>Terms of Service</h1>
        <p>Effective date: October 15, 2024</p>
        <h2>1. Acceptance</h2>
        <p>
          By accessing Tu Progreso Hoy, you agree to these terms. If you do not agree, please discontinue use.
        </p>
        <h2>2. Services</h2>
        <p>
          We provide educational dashboards, insights, and course materials related to Argentina’s economic context. We do not offer financial, investment, or legal services.
        </p>
        <h2>3. User responsibilities</h2>
        <ul>
          <li>Maintain accurate account information.</li>
          <li>Use content for lawful, personal, or organisational planning.</li>
          <li>Respect intellectual property rights.</li>
        </ul>
        <h2>4. Intellectual property</h2>
        <p>
          All content is owned by Tu Progreso Hoy or our licensors. You may not distribute or resell materials without permission.
        </p>
        <h2>5. Limitation of liability</h2>
        <p>
          Tu Progreso Hoy provides educational content “as is.” We are not liable for decisions you make based on our materials.
        </p>
        <h2>6. Termination</h2>
        <p>
          We may suspend access for violations. You may cancel your account anytime by contacting support.
        </p>
        <h2>7. Governing law</h2>
        <p>
          These terms are governed by the laws of Argentina. Disputes will be handled in the competent courts of Buenos Aires.
        </p>
        <h2>8. Contact</h2>
        <p>
          Tu Progreso Hoy · Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina · +54 11 5555-1234 · contact@tuprogresohoy.com
        </p>
      </div>
    </section>
    <PageDisclaimer />
  </>
);

export default Terms;