import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Inflation.module.css";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ComposedChart,
  Line,
  Bar,
} from "recharts";
import PageDisclaimer from "../components/PageDisclaimer";

const inflationData = [
  { month: "Nov 23", cpi: 8.6, food: 10.1, housing: 7.2, fx: 367 },
  { month: "Dec 23", cpi: 12.8, food: 16.5, housing: 9.8, fx: 391 },
  { month: "Jan 24", cpi: 20.6, food: 25.1, housing: 18.3, fx: 412 },
  { month: "Feb 24", cpi: 13.2, food: 15.7, housing: 12.1, fx: 420 },
  { month: "Mar 24", cpi: 11.0, food: 12.9, housing: 9.6, fx: 427 },
  { month: "Apr 24", cpi: 8.8, food: 10.2, housing: 7.4, fx: 430 },
  { month: "May 24", cpi: 7.5, food: 8.6, housing: 6.8, fx: 435 },
  { month: "Jun 24", cpi: 6.3, food: 7.4, housing: 5.6, fx: 438 },
  { month: "Jul 24", cpi: 7.2, food: 8.1, housing: 6.1, fx: 441 },
  { month: "Aug 24", cpi: 9.1, food: 11.6, housing: 7.9, fx: 445 },
  { month: "Sep 24", cpi: 8.0, food: 9.4, housing: 7.1, fx: 448 },
  { month: "Oct 24", cpi: 7.4, food: 8.7, housing: 6.4, fx: 452 },
];

const faqs = [
  {
    question: "What sources are integrated into the inflation dashboards?",
    answer:
      "We combine INDEC CPI releases with provincial statistics, market expectations (REM), and alternative FX rates. Each data set is timestamped and versioned for audit trails.",
  },
  {
    question: "How often is the ARS→USD midpoint updated?",
    answer:
      "Intraday updates occur every 10 minutes during local trading hours, while overnight we rely on historical averages until markets reopen.",
  },
  {
    question: "Can I download the datasets?",
    answer:
      "Yes. Subscribers can export CSV or connect via API to integrate CPI and FX series into their own models.",
  },
  {
    question: "¿Cómo se valida la calidad de los datos?",
    answer:
      "Contrastamos las cifras con fuentes oficiales, benchmarks independientes y paneles de especialistas. Cualquier outlier se revisa manualmente antes de publicarse.",
  },
];

const Inflation = () => {
  return (
    <>
      <Helmet>
        <title>Argentina Inflation Insights | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Explore CPI trends, ARS to USD context, and methodology notes that power Tu Progreso Hoy’s inflation dashboards."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Inflation & FX intelligence hub</h1>
          <p>
            Conocimiento financiero impulsado por tendencias. Our methodology blends official CPI releases, market expectations, and FX trajectories to deliver actionable context for Argentina-based professionals.
          </p>
        </div>
      </section>

      <section className={styles.methodology}>
        <div className="container">
          <div className={styles.methodCard}>
            <h2>Methodology at a glance</h2>
            <ul>
              <li>
                <strong>Data ingestion:</strong> Automated pipelines capture INDEC CPI, REM expectations, and MEP/official FX daily.
              </li>
              <li>
                <strong>Normalization:</strong> Each series is seasonally adjusted and aligned to a common index base (Jan 2020 = 100).
              </li>
              <li>
                <strong>Validation:</strong> Outliers are flagged with z-score thresholds and verified manually by our analysts.
              </li>
              <li>
                <strong>Context layering:</strong> Narrative briefs in English and Spanish summarise the impact on household budgets.
              </li>
            </ul>
          </div>
          <div className={styles.methodCard}>
            <h3>Scope of coverage</h3>
            <p>
              Weekly dashboards include CPI subcomponent heatmaps, FX spreads, wage negotiations, and price checkpoints in Buenos Aires neighborhoods.
            </p>
            <p>
              Everything is designed to translate macroeconomics into decisions about rent, groceries, education, and savings.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.charts}>
        <div className="container">
          <div className={styles.chartCard}>
            <h2>Monthly CPI vs. ARS→USD midpoint</h2>
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={inflationData}>
                <CartesianGrid strokeDasharray="4 4" stroke="#cbd5f5" />
                <XAxis dataKey="month" />
                <YAxis
                  yAxisId="left"
                  label={{ value: "CPI % m/m", angle: -90, position: "insideLeft" }}
                  stroke="#2563eb"
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  label={{ value: "ARS per USD", angle: 90, position: "insideRight" }}
                  stroke="#1f3a6f"
                />
                <Tooltip />
                <Bar
                  yAxisId="left"
                  dataKey="cpi"
                  fill="rgba(37, 99, 235, 0.45)"
                  radius={[8, 8, 0, 0]}
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="fx"
                  stroke="#1f3a6f"
                  strokeWidth={2.5}
                  dot={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
            <p>
              CPI acceleration in early 2024 aligned with FX adjustments, then decelerated as policy shifts tempered monthly increases.
            </p>
          </div>

          <div className={styles.chartCard}>
            <h2>CPI breakdown: food vs. housing</h2>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={inflationData}>
                <defs>
                  <linearGradient id="colorFood" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0.1} />
                  </linearGradient>
                  <linearGradient id="colorHousing" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1f3a6f" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#1f3a6f" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="4 4" stroke="#cbd5f5" />
                <XAxis dataKey="month" />
                <YAxis unit="%" />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="food"
                  stroke="#2563eb"
                  fill="url(#colorFood)"
                />
                <Area
                  type="monotone"
                  dataKey="housing"
                  stroke="#1f3a6f"
                  fill="url(#colorHousing)"
                />
              </AreaChart>
            </ResponsiveContainer>
            <p>
              Food price movements lead cumulative CPI, while housing gradually reflects regulatory adjustments and subsidy shifts.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.context}>
        <div className="container">
          <div className={styles.contextGrid}>
            <article>
              <h3>CPI narrative</h3>
              <p>
                Our analysts synthesise monthly CPI releases with remittances, wage talks, and retail discount trends. Reports highlight differences between national averages and Buenos Aires urban data, so you can align budgets precisely.
              </p>
            </article>
            <article>
              <h3>FX perspective</h3>
              <p>
                ARS→USD metrics cover official, blue, tarjeta, MEP, and blended enterprise rates. We flag stress moments when spreads widen beyond historical percentiles, letting you decide on conversions with confidence.
              </p>
            </article>
            <article>
              <h3>Household application</h3>
              <p>
                Each dataset feeds into checklists for rent negotiations, grocery planning, education expenses, and emergency funds. Guidance is bilingual and anchored in everyday decisions.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <h2>FAQ</h2>
          <div className={styles.faqList}>
            {faqs.map((faq) => (
              <details key={faq.question}>
                <summary>{faq.question}</summary>
                <p>{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <PageDisclaimer />
    </>
  );
};

export default Inflation;