import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Course.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const pillars = [
  {
    title: "Data-driven foundations",
    description:
      "Interpret CPI and FX signals with guided dashboards, ensuring every budgeting decision starts with verified numbers.",
  },
  {
    title: "Practical playbooks",
    description:
      "Templates and exercises tailored to Argentina’s context: rent negotiations, debt prioritisation, and peso-to-dollar strategies.",
  },
  {
    title: "Mentor-led accountability",
    description:
      "Weekly check-ins help you maintain routines, adjust targets, and celebrate milestones without losing momentum.",
  },
];

const syllabus = [
  {
    week: "Week 1",
    topic: "Macroeconomic essentials",
    activities: [
      "Live workshop on inflation structure",
      "Dashboard orientation (CPI + FX)",
      "Baseline budget diagnostic",
    ],
  },
  {
    week: "Week 2",
    topic: "Adaptive budgeting",
    activities: [
      "Category prioritisation clinic",
      "Scenario planning with ARS volatility",
      "Community roundtable in English and Spanish",
    ],
  },
  {
    week: "Week 3",
    topic: "Income protection",
    activities: [
      "Salary adjustment toolkit",
      "Gig income smoothing techniques",
      "Accountability partner session",
    ],
  },
  {
    week: "Week 4",
    topic: "Future-proof roadmap",
    activities: [
      "Emergency reserve calibration",
      "Quarterly review habit formation",
      "Presentation of personal finance blueprint",
    ],
  },
];

const Course = () => {
  return (
    <>
      <Helmet>
        <title>Personal Finance Course | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Bilingual personal finance course for Argentina professionals. Includes data dashboards, adaptive budgeting routines, and mentor support."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Integrate reliable data with day-to-day money decisions</h1>
          <p>
            Our personal finance course blends Argentina-specific inflation insights, ARS→USD strategies, and guided exercises. Decisiones responsables, objetivos nítidos.
          </p>
          <div className={styles.heroActions}>
            <a href="#syllabus">Explore syllabus</a>
            <a href="/#free-trial-form">Get a free lesson</a>
          </div>
        </div>
      </section>

      <section className={styles.pillars}>
        <div className="container">
          {pillars.map((pillar) => (
            <article key={pillar.title} className={styles.pillarCard}>
              <h2>{pillar.title}</h2>
              <p>{pillar.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.syllabus} id="syllabus">
        <div className="container">
          <h2>Course syllabus</h2>
          <div className={styles.syllabusGrid}>
            {syllabus.map((item) => (
              <article key={item.week} className={styles.syllabusCard}>
                <div>
                  <span>{item.week}</span>
                  <h3>{item.topic}</h3>
                </div>
                <ul>
                  {item.activities.map((activity) => (
                    <li key={activity}>{activity}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.delivery}>
        <div className="container">
          <div className={styles.deliveryCard}>
            <h2>Learning experience</h2>
            <ul>
              <li>Weekly cadence with live and on-demand sessions.</li>
              <li>Bilingual materials: English and Spanish transcripts.</li>
              <li>Peer accountability circles segmented by goals.</li>
              <li>Feedback loops using your own budget templates.</li>
            </ul>
          </div>
          <div className={styles.deliveryCard}>
            <h3>Tools included</h3>
            <p>
              Dashboard access, inflation digest newsletters, ARS→USD alerts, and templates for budgeting, conversion planning, and emergency fund tracking.
            </p>
            <p>
              No pricing is displayed here—connect with us to tailor the experience to your personal or team needs.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <h2>Anchor your financial plan to trustworthy signals.</h2>
          <p>
            Join Tu Progreso Hoy and experience a structured journey to resilient personal finance in Argentina.
          </p>
          <a href="/#free-trial-form">Request the trial lesson</a>
        </div>
      </section>

      <PageDisclaimer />
    </>
  );
};

export default Course;