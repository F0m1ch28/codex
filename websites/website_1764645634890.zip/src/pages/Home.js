import React, { useEffect, useMemo, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  AreaChart,
  Area,
} from "recharts";
import { Helmet } from "react-helmet-async";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { useInView } from "react-intersection-observer";
import styles from "./Home.module.css";
import { useLanguage } from "../context/LanguageContext";
import { translations } from "../i18n/translations";
import PageDisclaimer from "../components/PageDisclaimer";

const initialRates = [
  { timestamp: "09:00", rate: 0.0029 },
  { timestamp: "11:00", rate: 0.00295 },
  { timestamp: "13:00", rate: 0.00293 },
  { timestamp: "15:00", rate: 0.00298 },
  { timestamp: "17:00", rate: 0.00302 },
];

const inflationSeries = [
  { month: "Nov 2023", cpi: 8.6, fx: 367 },
  { month: "Dec 2023", cpi: 12.8, fx: 391 },
  { month: "Jan 2024", cpi: 20.6, fx: 412 },
  { month: "Feb 2024", cpi: 13.2, fx: 420 },
  { month: "Mar 2024", cpi: 11.0, fx: 427 },
  { month: "Apr 2024", cpi: 8.8, fx: 430 },
  { month: "May 2024", cpi: 7.5, fx: 435 },
  { month: "Jun 2024", cpi: 6.3, fx: 438 },
  { month: "Jul 2024", cpi: 7.2, fx: 441 },
  { month: "Aug 2024", cpi: 9.1, fx: 445 },
  { month: "Sep 2024", cpi: 8.0, fx: 448 },
  { month: "Oct 2024", cpi: 7.4, fx: 452 },
];

const projects = [
  {
    id: 1,
    title: "Household Inflation Pulse",
    language: "en",
    description:
      "A dashboard aligning official INDEC CPI baskets with Buenos Aires household spending behavior.",
    image: "https://picsum.photos/1200/800?random=4",
  },
  {
    id: 2,
    title: "Tablero de alertas cambiarias",
    language: "es",
    description:
      "Alertas ARS→USD según ventanas de conversión y spreads en bancos locales.",
    image: "https://picsum.photos/1200/800?random=24",
  },
];

const blogArticles = [
  {
    id: 1,
    title: "How to stress-test your peso budget against FX volatility",
    language: "en",
    summary:
      "Frameworks for adjusting living costs when ARS fluctuates against USD within a week.",
    link: "/resources#stress-test",
    date: "2024-10-12",
  },
  {
    id: 2,
    title: "Planificación bimestral con IPC y expectativas REM",
    language: "es",
    summary:
      "Integrá datos del REM con tu hoja de presupuesto para anticipar ajustes en servicios.",
    link: "/resources#bimestral",
    date: "2024-09-28",
  },
  {
    id: 3,
    title: "Contextualising salary adjustments",
    language: "en",
    summary:
      "Align labor negotiations with cumulative inflation to maintain purchasing power.",
    link: "/resources#salary",
    date: "2024-08-18",
  },
];

const testimonials = [
  {
    quote:
      "The weekly ARS→USD tracker aligned perfectly with our payroll cycles. It finally made reforecasting feel manageable.",
    name: "Malena Ruiz",
    role: "HR Partner, Palermo",
    language: "en",
  },
  {
    quote:
      "Los mapas de calor de IPC me ayudaron a renegociar alquileres sin sorpresas. La mentoría en español fue clave.",
    name: "Julián Barreto",
    role: "Diseñador independiente",
    language: "es",
  },
  {
    quote:
      "We rely on Tu Progreso Hoy to translate macro data into day-to-day budgeting decisions for our team in Buenos Aires.",
    name: "Andrew Collins",
    role: "Operations Lead, Tech Hub BA",
    language: "en",
  },
];

const mentors = [
  {
    name: "Carolina Méndez",
    role: "Lead Economist",
    image: "https://picsum.photos/400/400?random=3",
    bio: "Former INDEC analyst specialized in CPI segmentation and regional price indexes.",
  },
  {
    name: "Luciano Torres",
    role: "Personal Finance Specialist",
    image: "https://picsum.photos/400/400?random=13",
    bio: "Helps households design adaptive budgets aligned with Argentina’s macro shifts.",
  },
  {
    name: "Sofía Alvarez",
    role: "FX Monitoring Lead",
    image: "https://picsum.photos/400/400?random=23",
    bio: "Tracks ARS liquidity, alternative FX rates, and bank spreads for real-time alerts.",
  },
];

const Home = () => {
  const { language } = useLanguage();
  const t = translations[language];
  const navigate = useNavigate();
  const [rates, setRates] = useState(initialRates);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [statsValues, setStatsValues] = useState(t.stats.map(() => 0));
  const { ref: statsRef, inView: statsInView } = useInView({
    triggerOnce: true,
    threshold: 0.4,
  });

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    mode: "onBlur",
  });

  useEffect(() => {
    const rotate = setInterval(() => {
      setRates((prev) => {
        const next = [...prev];
        const last = next[next.length - 1];
        const variance = (Math.random() - 0.5) * 0.00008;
        const updated = {
          timestamp: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
          rate: Number(Math.max(0.0019, last.rate + variance).toFixed(5)),
        };
        next.shift();
        next.push(updated);
        return next;
      });
    }, 4500);
    return () => clearInterval(rotate);
  }, []);

  useEffect(() => {
    const autoplay = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(autoplay);
  }, []);

  useEffect(() => {
    if (!statsInView) return;
    const duration = 1800;
    const start = performance.now();

    const step = (timestamp) => {
      const progress = Math.min((timestamp - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 4);
      setStatsValues(
        t.stats.map((stat) => Math.round(stat.target * eased))
      );
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };

    requestAnimationFrame(step);
  }, [statsInView, t.stats]);

  const onSubmit = (data) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        navigate("/thank-you", {
          state: { email: data.email, source: "free-trial" },
        });
        resolve();
      }, 1500);
    });
  };

  const fxTrend = useMemo(
    () =>
      inflationSeries.map((item) => ({
        month: item.month,
        cpi: item.cpi,
        fx: item.fx,
      })),
    []
  );

  return (
    <>
      <Helmet>
        <title>Tu Progreso Hoy | Argentina Inflation Insights & Personal Finance Course</title>
        <meta
          name="description"
          content="Argentina-focused inflation dashboards, ARS-USD trackers, and a bilingual personal finance course rooted in trustworthy data."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <img
          src="https://picsum.photos/1600/900?random=1"
          alt="Financial analysts reviewing data dashboards"
          className={styles.heroImage}
          loading="lazy"
        />
        <div className={`${styles.heroContent} container`}>
          <p className={styles.badge}>Argentina · Buenos Aires · SaaS</p>
          <h1>{t.hero.title}</h1>
          <p className={styles.subtitle}>{t.hero.subtitle}</p>
          <div className={styles.heroActions}>
            <button
              type="button"
              className={styles.heroCta}
              onClick={() =>
                document
                  .getElementById("free-trial-form")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
            >
              {t.hero.ctaPrimary}
            </button>
            <button
              type="button"
              className={styles.secondaryCta}
              onClick={() => navigate("/inflation")}
            >
              {t.hero.ctaSecondary}
            </button>
          </div>
          <div className={styles.heroFlag} aria-hidden="true">
            <span />
            <span />
            <span />
          </div>
        </div>
      </section>

      <section className={`${styles.promises} container`}>
        {t.promises.map((promise, index) => (
          <div className={styles.promiseCard} key={promise.title}>
            <div className={styles.iconCircle}>
              {index === 0 && "📊"}
              {index === 1 && "🎓"}
              {index === 2 && "🧭"}
              {index === 3 && "🤝"}
            </div>
            <h3>{promise.title}</h3>
            <p>{promise.description}</p>
          </div>
        ))}
      </section>

      <section className={styles.fxSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>ARS→USD tracker</h2>
            <p>
              Live midpoint rate simulations with spreads from main Buenos Aires banks.
              Updated every few minutes to support intraday decisions.
            </p>
          </div>
          <div className={styles.fxGrid}>
            <div className={styles.fxCard}>
              <header>
                <span className={styles.fxLabel}>Current midpoint</span>
                <strong>
                  {(rates[rates.length - 1].rate * 1).toFixed(5)} ARS→USD
                </strong>
              </header>
              <div className={styles.fxTableWrapper}>
                <table className={styles.fxTable}>
                  <thead>
                    <tr>
                      <th scope="col">Time</th>
                      <th scope="col">Midpoint</th>
                      <th scope="col">Variation</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rates.map((entry, idx) => {
                      const prev = rates[idx - 1]?.rate ?? entry.rate;
                      const diff = entry.rate - prev;
                      const diffFormatted = diff >= 0 ? `+${diff.toFixed(5)}` : diff.toFixed(5);
                      return (
                        <tr key={entry.timestamp}>
                          <td>{entry.timestamp}</td>
                          <td>{entry.rate.toFixed(5)}</td>
                          <td className={diff >= 0 ? styles.up : styles.down}>
                            {diffFormatted}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <p className={styles.fxNote}>
                Data aggregated from Banco Nación, Banco Galicia, and leading FX platforms in Buenos Aires.
              </p>
            </div>
            <div className={styles.fxInsight}>
              <div className={styles.fxInsightCard}>
                <h3>Daily playbook</h3>
                <ul>
                  <li>
                    <strong>Spread monitor:</strong> Compare midpoint vs. blue rate differential every morning.
                  </li>
                  <li>
                    <strong>Ventana recomendada:</strong> 10:30-13:00 local time, when liquidity deepens.
                  </li>
                  <li>
                    <strong>Alertas:</strong> Receive SMS when deviation exceeds 3.5% vs. historical average.
                  </li>
                </ul>
              </div>
              <div className={styles.fxInsightCard}>
                <h3>Weekly summary</h3>
                <p>
                  Short reports connect ARS liquidity, REM expectations, and household-impact narratives so you can brief your team quickly.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.dataSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Data insights</h2>
            <p>
              Visualise the monthly path of Argentina’s CPI alongside ARS→USD midpoint to contextualise household budgets.
            </p>
          </div>
          <div className={styles.dataGrid}>
            <div className={styles.chartCard}>
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={fxTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#cbd5f5" />
                  <XAxis dataKey="month" />
                  <YAxis
                    yAxisId="left"
                    orientation="left"
                    stroke="#2563eb"
                    label={{
                      value: "CPI % m/m",
                      angle: -90,
                      position: "insideLeft",
                      style: { fill: "#2563eb" },
                    }}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    stroke="#1f3a6f"
                    label={{
                      value: "ARS per USD",
                      angle: 90,
                      position: "insideRight",
                      style: { fill: "#1f3a6f" },
                    }}
                  />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="cpi"
                    stroke="#2563eb"
                    strokeWidth={2.5}
                    dot={false}
                    yAxisId="left"
                  />
                  <Line
                    type="monotone"
                    dataKey="fx"
                    stroke="#1f3a6f"
                    strokeWidth={2.5}
                    dot={false}
                    yAxisId="right"
                  />
                </LineChart>
              </ResponsiveContainer>
              <p className={styles.chartNote}>
                CPI data sourced from INDEC, FX midpoint derived from official and financial market quotes.
              </p>
            </div>
            <div ref={statsRef} className={styles.statsList}>
              {t.stats.map((stat, index) => (
                <div key={stat.label} className={styles.statCard}>
                  <span className={styles.statNumber}>
                    {statsValues[index]}
                    {stat.suffix}
                  </span>
                  <p>{stat.label}</p>
                </div>
              ))}
              <div className={styles.dataText}>
                <strong>Method highlights:</strong>
                <ul>
                  <li>Blend of official CPI subcomponents with market pricing signals.</li>
                  <li>Outlier detection using four-year volatility bands.</li>
                  <li>Weekly commentary summarised in English and Spanish.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.courseSection} id="course-overview">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>{t.courses.heading}</h2>
            <p>{t.courses.subheading}</p>
          </div>
          <div className={styles.modulesGrid}>
            {t.courses.modules.map((module) => (
              <article className={styles.moduleCard} key={module.title}>
                <h3>{module.title}</h3>
                <p>{module.copy}</p>
              </article>
            ))}
          </div>
          <div className={styles.processGrid}>
            <div className={styles.processCard}>
              <h3>{t.courses.processTitle}</h3>
              <ol>
                {t.courses.processSteps.map((step, idx) => (
                  <li key={step}>
                    <span>{idx + 1}</span>
                    <p>{step}</p>
                  </li>
                ))}
              </ol>
            </div>
            <div className={styles.targetCard}>
              <h3>{t.courses.audienceTitle}</h3>
              <ul>
                {t.courses.audiences.map((audience) => (
                  <li key={audience}>{audience}</li>
                ))}
              </ul>
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Learners collaborating on financial plans"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.teamSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>{t.teamTitle}</h2>
            <p>
              Specialists blending macroeconomic research, personal finance coaching, and FX monitoring—based in Buenos Aires.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {mentors.map((mentor) => (
              <figure key={mentor.name} className={styles.teamCard}>
                <img src={mentor.image} alt={mentor.name} loading="lazy" />
                <figcaption>
                  <h3>{mentor.name}</h3>
                  <span>{mentor.role}</span>
                  <p>{mentor.bio}</p>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Projects & Data Stories</h2>
            <p>
              Selected prototypes and datasets that fuel actionable insights for our learners and enterprise clients.
            </p>
          </div>
          <div className={styles.projectsGrid}>
            {projects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <span className={styles.projectTag}>
                    {project.language === "en" ? "English" : "Español"}
                  </span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>{t.testimonialsTitle}</h2>
            <p>
              Participants from corporate teams and independent professionals share how Tu Progreso Hoy supports resilient decisions.
            </p>
          </div>
          <div className={styles.testimonialCard}>
            <p className={styles.quote}>
              “{testimonials[currentTestimonial].quote}”
            </p>
            <span className={styles.person}>
              {testimonials[currentTestimonial].name} ·{" "}
              {testimonials[currentTestimonial].role}
            </span>
            <div className={styles.dots}>
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  className={`${styles.dot} ${
                    idx === currentTestimonial ? styles.dotActive : ""
                  }`}
                  onClick={() => setCurrentTestimonial(idx)}
                  aria-label={`Show testimonial ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>{t.faqTitle}</h2>
            <p>
              Transparent answers about our data sources, learning model, and access policies.
            </p>
          </div>
          <div className={styles.faqGrid}>
            <details>
              <summary>
                How are ARS→USD rates calculated and validated?
              </summary>
              <p>
                We triangulate official rates, MEP, and blue market signals, filtering anomalies using VWAP. The final midpoint is timestamped and archived for audits.
              </p>
            </details>
            <details>
              <summary>
                ¿El curso ofrece asesoramiento financiero individual?
              </summary>
              <p>
                No brindamos asesoramiento financiero personalizado. Compartimos marcos educativos, ejercicios prácticos y mentoría orientada al aprendizaje.
              </p>
            </details>
            <details>
              <summary>
                What does double opt-in mean for the free trial?
              </summary>
              <p>
                After submitting the form, you receive a confirmation email. Only when you confirm we activate your dashboard preview and send the guided lesson.
              </p>
            </details>
            <details>
              <summary>
                Are materials available in both English and Spanish?
              </summary>
              <p>
                Yes. Core dashboards, video briefings, and templates are bilingual. You can switch languages anytime from your account settings.
              </p>
            </details>
          </div>
        </div>
      </section>

      <section className={styles.blogSection}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>{t.blogTitle}</h2>
            <p>
              Read concise explainers blending macroeconomic data with everyday budgeting tactics.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogArticles.map((article) => (
              <article key={article.id} className={styles.blogCard}>
                <h3>{article.title}</h3>
                <p>{article.summary}</p>
                <div className={styles.blogMeta}>
                  <span>{new Date(article.date).toLocaleDateString()}</span>
                  <span>{article.language === "en" ? "EN" : "ES"}</span>
                </div>
                <button
                  type="button"
                  onClick={() => navigate(article.link)}
                  className={styles.blogLink}
                >
                  {language === "en" ? "Read more" : "Leer más"}
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.formSection} id="free-trial-form">
        <div className="container">
          <div className={styles.formWrapper}>
            <div className={styles.formContent}>
              <h2>{t.form.heading}</h2>
              <p>{t.form.subheading}</p>
              <ul className={styles.formHighlights}>
                <li>Personalised walkthrough of the ARS→USD tracker.</li>
                <li>Sample modules from the personal finance course.</li>
                <li>Checklist for double opt-in confirmation.</li>
              </ul>
            </div>
            <form
              onSubmit={handleSubmit(onSubmit)}
              className={styles.form}
              noValidate
            >
              <label>
                <span>{t.form.name}</span>
                <input
                  type="text"
                  placeholder={language === "en" ? "Your name" : "Tu nombre"}
                  {...register("name", { required: true, minLength: 3 })}
                  aria-invalid={errors.name ? "true" : "false"}
                />
                {errors.name && (
                  <small>
                    {language === "en"
                      ? "Please enter at least 3 characters."
                      : "Ingresá al menos 3 caracteres."}
                  </small>
                )}
              </label>
              <label>
                <span>{t.form.email}</span>
                <input
                  type="email"
                  placeholder="name@example.com"
                  {...register("email", {
                    required: true,
                    pattern:
                      /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i,
                  })}
                  aria-invalid={errors.email ? "true" : "false"}
                />
                {errors.email && (
                  <small>
                    {language === "en"
                      ? "Please enter a valid email."
                      : "Ingresá un correo válido."}
                  </small>
                )}
              </label>
              <label>
                <span>{t.form.goals}</span>
                <textarea
                  rows={3}
                  placeholder={
                    language === "en"
                      ? "Tell us about the financial objective you want to strengthen."
                      : "Contanos el objetivo financiero que querés potenciar."
                  }
                  {...register("goal", { required: true, minLength: 10 })}
                  aria-invalid={errors.goal ? "true" : "false"}
                />
                {errors.goal && (
                  <small>
                    {language === "en"
                      ? "Share at least 10 characters."
                      : "Compartí al menos 10 caracteres."}
                  </small>
                )}
              </label>
              <label className={styles.checkbox}>
                <input
                  type="checkbox"
                  {...register("consent", { required: true })}
                  aria-invalid={errors.consent ? "true" : "false"}
                />
                <span>{t.form.consent}</span>
              </label>
              {errors.consent && (
                <small className={styles.error}>
                  {language === "en"
                    ? "Consent is required."
                    : "El consentimiento es obligatorio."}
                </small>
              )}
              <button type="submit" disabled={isSubmitting}>
                {isSubmitting ? t.form.submitting : t.form.submit}
              </button>
              <p className={styles.optinNote}>
                {language === "en"
                  ? "Next step: check your inbox and confirm to complete the activation."
                  : "Paso siguiente: revisá tu correo y confirmá para completar la activación."}
              </p>
            </form>
          </div>
        </div>
      </section>

      <section className={styles.finalCta}>
        <div className="container">
          <div className={styles.finalContent}>
            <h2>{t.ctaFinalTitle}</h2>
            <p>{t.ctaFinalCopy}</p>
            <div className={styles.finalActions}>
              <button
                type="button"
                onClick={() => navigate("/course")}
                className={styles.heroCta}
              >
                {language === "en" ? "Explore the course" : "Explorá el curso"}
              </button>
              <button
                type="button"
                onClick={() => navigate("/inflation")}
                className={styles.secondaryCta}
              >
                {language === "en"
                  ? "View inflation dashboards"
                  : "Ver tableros de inflación"}
              </button>
            </div>
          </div>
        </div>
      </section>

      <PageDisclaimer />
    </>
  );
};

export default Home;