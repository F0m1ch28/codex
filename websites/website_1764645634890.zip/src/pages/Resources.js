import React, { useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Resources.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const articles = [
  {
    id: "stress-test",
    title: "Stress-test your peso budget using volatility bands",
    summary:
      "Translate FX swings into monthly cash-flow buffers and adjust discretionary spending proactively.",
    language: "en",
    topic: "budgeting",
    type: "article",
    url: "#",
    date: "2024-10-12",
  },
  {
    id: "bimestral",
    title: "Planificación bimestral con IPC y proyecciones REM",
    summary:
      "Integra datos del REM al nuevo ritmo de gastos para sostener tu poder adquisitivo.",
    language: "es",
    topic: "inflation",
    type: "article",
    url: "#",
    date: "2024-09-28",
  },
  {
    id: "salary",
    title: "Salary adjustment toolkit for mid-sized teams",
    summary:
      "Map salary negotiations to cumulative CPI, industry benchmarks, and ARS liquidity signals.",
    language: "en",
    topic: "workplace",
    type: "guide",
    url: "#",
    date: "2024-08-18",
  },
  {
    id: "familia",
    title: "Checklist familiar ante subas de combustibles",
    summary:
      "Pasos concretos para reducir impacto en transporte y servicios tras ajustes regulatorios.",
    language: "es",
    topic: "household",
    type: "checklist",
    url: "#",
    date: "2024-07-02",
  },
];

const glossary = [
  {
    term: "REM",
    definition:
      "Relevamiento de Expectativas de Mercado. Survey published by the Central Bank summarising future CPI, FX, and interest rate expectations.",
  },
  {
    term: "Pass-through",
    definition:
      "The degree to which currency devaluation translates into consumer prices.",
  },
  {
    term: "Crawling peg",
    definition:
      "Monetary policy strategy where the official exchange rate moves in small increments.",
  },
  {
    term: "Subsidios energéticos",
    definition:
      "State energy subsidies that influence housing CPI components and household expenses.",
  },
];

const topics = [
  { value: "all", label: "All topics" },
  { value: "budgeting", label: "Budgeting" },
  { value: "inflation", label: "Inflation" },
  { value: "workplace", label: "Workplace" },
  { value: "household", label: "Household" },
];

const languages = [
  { value: "all", label: "EN & ES" },
  { value: "en", label: "English" },
  { value: "es", label: "Español" },
];

const Resources = () => {
  const [selectedTopic, setSelectedTopic] = useState("all");
  const [selectedLanguage, setSelectedLanguage] = useState("all");

  const filteredArticles = useMemo(() => {
    return articles.filter((article) => {
      const matchesTopic =
        selectedTopic === "all" || article.topic === selectedTopic;
      const matchesLanguage =
        selectedLanguage === "all" || article.language === selectedLanguage;
      return matchesTopic && matchesLanguage;
    });
  }, [selectedTopic, selectedLanguage]);

  return (
    <>
      <Helmet>
        <title>Resources & Insights | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Bilingual resources covering Argentina inflation, budgeting, and ARS→USD strategies with downloadable templates."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Resources & insights</h1>
          <p>
            Curated explainers, guides, and checklists to accompany your journey. Available in English and Spanish for Argentina’s unique context.
          </p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className="container">
          <label>
            Topic
            <select
              value={selectedTopic}
              onChange={(event) => setSelectedTopic(event.target.value)}
            >
              {topics.map((topic) => (
                <option key={topic.value} value={topic.value}>
                  {topic.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            Language
            <select
              value={selectedLanguage}
              onChange={(event) => setSelectedLanguage(event.target.value)}
            >
              {languages.map((language) => (
                <option key={language.value} value={language.value}>
                  {language.label}
                </option>
              ))}
            </select>
          </label>
        </div>
      </section>

      <section className={styles.articles}>
        <div className="container">
          <div className={styles.articleGrid}>
            {filteredArticles.map((article) => (
              <article key={article.id} className={styles.articleCard}>
                <div className={styles.articleMeta}>
                  <span>{article.type}</span>
                  <span>{article.language.toUpperCase()}</span>
                </div>
                <h2>{article.title}</h2>
                <p>{article.summary}</p>
                <time dateTime={article.date}>
                  {new Date(article.date).toLocaleDateString()}
                </time>
                <a href={article.url} className={styles.articleLink}>
                  {article.language === "es" ? "Leer recurso" : "View resource"}
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.glossary}>
        <div className="container">
          <h2>Glossary</h2>
          <div className={styles.glossaryGrid}>
            {glossary.map((item) => (
              <div key={item.term} className={styles.glossaryCard}>
                <h3>{item.term}</h3>
                <p>{item.definition}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <PageDisclaimer />
    </>
  );
};

export default Resources;