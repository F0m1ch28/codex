import React from "react";
import { Helmet } from "react-helmet-async";
import styles from "./Services.module.css";
import PageDisclaimer from "../components/PageDisclaimer";

const servicePackages = [
  {
    title: "Inflation intelligence",
    description:
      "Weekly CPI breakdowns, subcomponent heatmaps, and contextual briefings to support budgeting decisions.",
    features: [
      "CPI and FX dashboards",
      "Household impact notes",
      "Bilingual video recaps",
    ],
  },
  {
    title: "Personal finance cohort",
    description:
      "Bilingual course with mentor feedback to build adaptive budgeting routines in Argentina.",
    features: [
      "Modular curriculum",
      "Peer accountability",
      "Mentor office hours",
    ],
  },
  {
    title: "Enterprise enablement",
    description:
      "Tailored analytics, ARS→USD playbooks, and training for HR or finance teams in Buenos Aires.",
    features: [
      "Custom dashboards",
      "Policy and salary toolkits",
      "Team workshops",
    ],
  },
];

const workflow = [
  "Discovery call to capture objectives, language preferences, and timelines.",
  "Data access provisioning and onboarding walkthrough for your team.",
  "Implementation of dashboards, templates, and check-ins aligned with deliverables.",
  "Quarterly review to align with new macroeconomic conditions and goals.",
];

const Services = () => (
  <>
    <Helmet>
      <title>Services | Tu Progreso Hoy</title>
      <meta
        name="description"
        content="Explore Tu Progreso Hoy services: inflation intelligence, personal finance cohorts, and enterprise enablement in Buenos Aires."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Services anchored in reliable data</h1>
        <p>
          From individual learners to enterprise teams, we design bilingual experiences that convert economic signals into practical strategies.
        </p>
      </div>
    </section>

    <section className={styles.cards}>
      <div className="container">
        <div className={styles.cardGrid}>
          {servicePackages.map((service) => (
            <article key={service.title} className={styles.card}>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <a href="/contact">Discuss this service</a>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.process}>
      <div className="container">
        <h2>Process</h2>
        <ol>
          {workflow.map((step, index) => (
            <li key={step}>
              <span>{index + 1}</span>
              <p>{step}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>

    <PageDisclaimer />
  </>
);

export default Services;