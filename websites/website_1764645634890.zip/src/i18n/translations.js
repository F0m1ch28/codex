export const translations = {
  en: {
    nav: {
      home: "Home",
      inflation: "Inflation Data",
      course: "Course",
      resources: "Resources",
      about: "About",
      services: "Services",
      contact: "Contact",
    },
    hero: {
      title: "Stay ahead of Argentina’s inflation wave.",
      subtitle:
        "Datos verificados para planificar tu presupuesto. Conocimiento financiero impulsado por tendencias.",
      ctaPrimary: "Start free trial",
      ctaSecondary: "Explore inflation data",
    },
    promises: [
      {
        title: "Reliable ARS→USD data",
        description: "Live trackers and trusted sources for confident planning.",
      },
      {
        title: "Actionable personal finance lessons",
        description:
          "Decisiones responsables, objetivos nítidos. Build routines that adapt to volatility.",
      },
      {
        title: "Context that makes sense",
        description:
          "Weekly briefings connecting CPI behavior with household budgeting choices.",
      },
      {
        title: "Community learning",
        description:
          "Mentor feedback circles in English and Spanish for Buenos Aires professionals.",
      },
    ],
    courses: {
      heading: "Course overview",
      subheading:
        "A modular learning path that anchors budgeting, debt strategy, and currency awareness.",
      modules: [
        {
          title: "Module 1 · Inflation literacy",
          copy: "Map CPI components, spot seasonality, and translate percentages into real pesos.",
        },
        {
          title: "Module 2 · ARS-USD resilience",
          copy: "Design currency buffers, choose conversion windows, and track spread indicators.",
        },
        {
          title: "Module 3 · Personal budgets in motion",
          copy: "Balance essentials, commitments, and goals with rolling forecasts and cash-flow alerts.",
        },
        {
          title: "Module 4 · Decision simulation lab",
          copy: "Practice scenario planning with data sets tailored to Buenos Aires cost-of-living shifts.",
        },
      ],
      processTitle: "How the learning journey works",
      processSteps: [
        "Onboard with your financial objectives and baseline metrics.",
        "Track inflation dashboards and receive weekly digestion videos.",
        "Apply course frameworks to your budget blueprint with mentor input.",
        "Revisit targets quarterly and adjust using updated CPI and FX data.",
      ],
      audienceTitle: "Who joins Tu Progreso Hoy?",
      audiences: [
        "Professionals managing salaries in ARS with commitments in USD.",
        "Entrepreneurs seeking stable cash-flow planning amidst macro swings.",
        "Households wanting practical, bilingual guidance without jargon.",
      ],
    },
    stats: [
      {
        label: "Data points monitored per week",
        suffix: "+",
        target: 85,
      },
      {
        label: "Learners who reported clearer budgeting",
        suffix: "%",
        target: 92,
      },
      {
        label: "Hours of mentor support delivered",
        suffix: "h",
        target: 140,
      },
      {
        label: "Local sources validated monthly",
        suffix: "",
        target: 34,
      },
    ],
    testimonialsTitle: "Voices from our community",
    teamTitle: "Meet the Buenos Aires team",
    faqTitle: "Frequently asked questions",
    blogTitle: "Latest resources",
    ctaFinalTitle: "Ready to navigate Argentina’s economy with clarity?",
    ctaFinalCopy:
      "Join Tu Progreso Hoy for data, language-compatible coaching, and a structured path to resilient personal finances.",
    form: {
      heading: "Request your free lesson",
      subheading:
        "Complete the form to unlock a guided demo. We’ll email next steps—confirm to activate your double opt-in.",
      name: "Full name",
      email: "Work email",
      goals: "Key financial goal",
      consent:
        "I agree to receive curated insights and will confirm my email address to activate access.",
      submit: "Request access",
      submitting: "Sending...",
    },
    footer: {
      headline: "Decisiones responsables, objetivos nítidos.",
      address: "Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina",
      phone: "+54 11 5555-1234",
      email: "contact@tuprogresohoy.com",
      copyrights: "© 2024 Tu Progreso Hoy. All rights reserved.",
    },
    cookie: {
      message:
        "We use cookies to tailor content and measure engagement. Manage your preferences anytime.",
      accept: "Accept cookies",
      decline: "Decline",
      manage: "Cookie policy",
    },
    disclaimer: {
      intro: "Disclaimer / Aviso / Отказ от ответственности:",
      en: "We do not provide financial services or investment advice.",
      es: "No brindamos servicios financieros ni asesoramiento de inversión.",
      ru: "Мы не предоставляем финансовые услуги.",
      note: "Educational resources only. Data sources are verified regularly.",
    },
  },
  es: {
    nav: {
      home: "Inicio",
      inflation: "Inflación",
      course: "Curso",
      resources: "Recursos",
      about: "Equipo",
      services: "Servicios",
      contact: "Contacto",
    },
    hero: {
      title: "Anticipá la inflación argentina con datos claros.",
      subtitle:
        "Conocimiento financiero impulsado por tendencias. Datos verificados para planificar tu presupuesto sin sobresaltos.",
      ctaPrimary: "Comenzar prueba gratuita",
      ctaSecondary: "Ver datos de inflación",
    },
    promises: [
      {
        title: "Tablero ARS→USD confiable",
        description:
          "Seguimiento en vivo y fuentes confiables para planificar con seguridad.",
      },
      {
        title: "Curso práctico de finanzas personales",
        description:
          "Decisiones responsables, objetivos nítidos. Rutinas que se ajustan a la volatilidad.",
      },
      {
        title: "Contexto útil y accionable",
        description:
          "Briefings semanales que conectan el comportamiento del IPC con tu presupuesto.",
      },
      {
        title: "Comunidad bilingüe",
        description:
          "Mentoría en español e inglés para profesionales en Buenos Aires.",
      },
    ],
    courses: {
      heading: "Resumen del curso",
      subheading:
        "Un camino modular que integra presupuesto, estrategia de deudas y monitoreo cambiario.",
      modules: [
        {
          title: "Módulo 1 · Alfabetización inflacionaria",
          copy: "Mapeá los componentes del IPC y traducí porcentajes en pesos reales.",
        },
        {
          title: "Módulo 2 · Resiliencia ARS-USD",
          copy: "Diseñá colchones cambiarios, elegí ventanas de conversión y seguí los diferenciales.",
        },
        {
          title: "Módulo 3 · Presupuestos dinámicos",
          copy: "Equilibrá esenciales, compromisos y metas con pronósticos actualizados.",
        },
        {
          title: "Módulo 4 · Laboratorio de decisiones",
          copy: "Simulá escenarios con datasets adaptados al costo de vida porteño.",
        },
      ],
      processTitle: "Cómo se desarrolla la experiencia",
      processSteps: [
        "Iniciás con tus objetivos financieros y métricas base.",
        "Seguís tableros de inflación y recibís videos explicativos semanales.",
        "Aplicás los marcos del curso con feedback de mentoría.",
        "Revisás metas trimestralmente con los últimos datos de IPC y FX.",
      ],
      audienceTitle: "¿Quién se suma a Tu Progreso Hoy?",
      audiences: [
        "Profesionales que cobran en ARS y tienen gastos en USD.",
        "Emprendedores que buscan estabilidad en su flujo de fondos.",
        "Hogares que quieren guía práctica, bilingüe y sin promesas irreales.",
      ],
    },
    stats: [
      { label: "Puntos de datos monitoreados", suffix: "+", target: 85 },
      { label: "Aprendices con presupuestos más claros", suffix: "%", target: 92 },
      { label: "Horas de mentoría entregadas", suffix: "h", target: 140 },
      { label: "Fuentes locales validadas", suffix: "", target: 34 },
    ],
    testimonialsTitle: "Voces de nuestra comunidad",
    teamTitle: "Conocé al equipo en Buenos Aires",
    faqTitle: "Preguntas frecuentes",
    blogTitle: "Recursos recientes",
    ctaFinalTitle: "¿Listo para gestionar tu economía personal con claridad?",
    ctaFinalCopy:
      "Sumate a Tu Progreso Hoy para acceder a datos, mentoría bilingüe y un camino estructurado hacia finanzas resilientes.",
    form: {
      heading: "Solicitá tu clase gratuita",
      subheading:
        "Completá el formulario para acceder a una demo guiada. Confirmá tu correo para activar el doble opt-in.",
      name: "Nombre completo",
      email: "Correo laboral",
      goals: "Principal objetivo financiero",
      consent:
        "Acepto recibir insights y confirmaré mi correo electrónico para activar el acceso.",
      submit: "Solicitar acceso",
      submitting: "Enviando...",
    },
    footer: {
      headline: "Decisiones responsables, objetivos nítidos.",
      address: "Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina",
      phone: "+54 11 5555-1234",
      email: "contacto@tuprogresohoy.com",
      copyrights: "© 2024 Tu Progreso Hoy. Todos los derechos reservados.",
    },
    cookie: {
      message:
        "Usamos cookies para personalizar el contenido y medir la participación. Ajustá tus preferencias cuando quieras.",
      accept: "Aceptar cookies",
      decline: "Rechazar",
      manage: "Política de cookies",
    },
    disclaimer: {
      intro: "Disclaimer / Aviso / Отказ от ответственности:",
      en: "We do not provide financial services or investment advice.",
      es: "No brindamos servicios financieros ni asesoramiento de inversión.",
      ru: "Мы не предоставляем финансовые услуги.",
      note: "Recursos educativos exclusivamente. Las fuentes de datos se verifican periódicamente.",
    },
  },
};