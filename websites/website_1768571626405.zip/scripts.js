document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const mainNav = document.querySelector('.main-nav');

    if (navToggle && mainNav) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            mainNav.classList.toggle('open');
        });

        mainNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                mainNav.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    const storageKey = 'citronaCookieConsent';

    if (cookieBanner) {
        const consent = localStorage.getItem(storageKey);
        if (consent === 'accepted' || consent === 'declined') {
            cookieBanner.classList.add('hidden');
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'accepted');
                cookieBanner.classList.add('hidden');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem(storageKey, 'declined');
                cookieBanner.classList.add('hidden');
            });
        }
    }
});