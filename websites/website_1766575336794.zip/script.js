(function () {
  const navLinks = document.querySelectorAll('.nav-links a[data-nav]');
  const currentPage = document.body.dataset.page;
  if (currentPage) {
    navLinks.forEach((link) => {
      if (link.dataset.nav === currentPage) {
        link.classList.add('active');
      }
    });
  }

  const heroPlayer = document.querySelector('[data-video-player]');
  if (heroPlayer) {
    const video = heroPlayer.querySelector('video');
    const toggle = heroPlayer.querySelector('[data-video-toggle]');
    toggle.addEventListener('click', () => {
      if (video.paused) {
        video.play();
      } else {
        video.pause();
      }
    });
    video.addEventListener('play', () => {
      heroPlayer.classList.add('playing');
      toggle.setAttribute('aria-label', 'Pausar vídeo principal');
    });
    video.addEventListener('pause', () => {
      heroPlayer.classList.remove('playing');
      toggle.setAttribute('aria-label', 'Reproduzir vídeo principal');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const storageKey = 'aav-cookie-consent';

  function hideBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove('active');
    }
  }

  function showBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add('active');
    }
  }

  function setConsent(status) {
    localStorage.setItem(storageKey, status);
  }

  if (cookieBanner && acceptBtn && declineBtn) {
    const savedConsent = localStorage.getItem(storageKey);
    if (!savedConsent) {
      showBanner();
    }

    acceptBtn.addEventListener('click', () => {
      setConsent('accepted');
      hideBanner();
    });

    declineBtn.addEventListener('click', () => {
      setConsent('declined');
      hideBanner();
    });
  }
})();