document.addEventListener("DOMContentLoaded", function () {
    const currentYearEl = document.getElementById("current-year");
    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    const menuToggle = document.querySelector(".menu-toggle");
    const siteNav = document.querySelector(".site-nav");
    if (menuToggle && siteNav) {
        menuToggle.addEventListener("click", () => {
            siteNav.classList.toggle("is-open");
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        const storedChoice = localStorage.getItem("mcpCookieChoice");
        if (storedChoice) {
            cookieBanner.classList.add("is-hidden");
        } else {
            const cookieButtons = cookieBanner.querySelectorAll(".cookie-action");
            cookieButtons.forEach((button) => {
                button.addEventListener("click", (event) => {
                    event.preventDefault();
                    const choice = button.dataset.choice || "undecided";
                    localStorage.setItem("mcpCookieChoice", choice);
                    cookieBanner.classList.add("is-hidden");
                    const targetLink = button.getAttribute("href");
                    if (targetLink) {
                        window.open(targetLink, "_blank");
                    }
                });
            });
        }
    }

    const searchInput = document.querySelector("[data-post-search]");
    const postCards = document.querySelectorAll("[data-post-card]");
    const categoryButtons = document.querySelectorAll("[data-category-filter]");
    let activeCategory = "all";

    function applyFilters() {
        const query = searchInput ? searchInput.value.toLowerCase().trim() : "";
        postCards.forEach((card) => {
            const title = card.querySelector("h3")?.textContent.toLowerCase() || "";
            const summary = card.querySelector("p")?.textContent.toLowerCase() || "";
            const category = card.getAttribute("data-category");
            const matchesCategory = activeCategory === "all" || category === activeCategory;
            const matchesQuery = !query || title.includes(query) || summary.includes(query);
            if (matchesCategory && matchesQuery) {
                card.classList.remove("is-hidden");
            } else {
                card.classList.add("is-hidden");
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", applyFilters);
    }

    if (categoryButtons.length) {
        categoryButtons.forEach((button) => {
            button.addEventListener("click", () => {
                categoryButtons.forEach((btn) => btn.classList.remove("is-active"));
                button.classList.add("is-active");
                activeCategory = button.dataset.filter || "all";
                applyFilters();
            });
        });
    }
});