const navToggleButtons = document.querySelectorAll(".nav-toggle");
const navigationMenus = document.querySelectorAll(".site-nav");

navToggleButtons.forEach((toggle, index) => {
    const nav = navigationMenus[index] || navigationMenus[0];
    toggle.addEventListener("click", () => {
        const expanded = toggle.getAttribute("aria-expanded") === "true";
        toggle.setAttribute("aria-expanded", String(!expanded));
        nav.classList.toggle("is-open");
    });
});

document.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", () => {
        navToggleButtons.forEach((toggle, index) => {
            const nav = navigationMenus[index] || navigationMenus[0];
            toggle.setAttribute("aria-expanded", "false");
            nav.classList.remove("is-open");
        });
    });
});

const currentYearElement = document.querySelectorAll("#current-year");
const year = new Date().getFullYear();
currentYearElement.forEach(element => {
    element.textContent = year;
});

const cookieBanner = document.getElementById("cookie-banner");
const cookieButtons = document.querySelectorAll(".cookie-btn");
const cookieChoice = localStorage.getItem("nucleao_cookie_choice");

function hideCookieBanner() {
    if (cookieBanner) {
        cookieBanner.classList.remove("is-visible");
    }
}

if (cookieBanner && !cookieChoice) {
    setTimeout(() => {
        cookieBanner.classList.add("is-visible");
    }, 1200);
} else {
    hideCookieBanner();
}

cookieButtons.forEach(button => {
    button.addEventListener("click", () => {
        const action = button.dataset.action;
        localStorage.setItem("nucleao_cookie_choice", action);
        hideCookieBanner();
    });
});

window.addEventListener("resize", () => {
    if (window.innerWidth >= 768) {
        navigationMenus.forEach(nav => nav.classList.remove("is-open"));
        navToggleButtons.forEach(toggle => toggle.setAttribute("aria-expanded", "false"));
    }
});