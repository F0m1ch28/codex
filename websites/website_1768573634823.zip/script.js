document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptButton = document.querySelector('.cookie-accept');
    const declineButton = document.querySelector('.cookie-decline');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 1024 && navMenu.classList.contains('open')) {
                    navMenu.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner && acceptButton && declineButton) {
        const consent = localStorage.getItem('timecrywCookieConsent');
        if (!consent) {
            cookieBanner.classList.add('active');
        }

        acceptButton.addEventListener('click', () => {
            localStorage.setItem('timecrywCookieConsent', 'accepted');
            cookieBanner.classList.remove('active');
        });

        declineButton.addEventListener('click', () => {
            localStorage.setItem('timecrywCookieConsent', 'declined');
            cookieBanner.classList.remove('active');
        });
    }
});