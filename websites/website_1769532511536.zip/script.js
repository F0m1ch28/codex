const DEFAULT_LANG = "fr";
const LANG_STORAGE_KEY = "site_lang";
const COOKIE_STORAGE_KEY = "cookie_consent";

const I18N = {
  fr: {
    meta: {
      title: {
        home: "danswholesaleplants | Orientation spatiale et signalétique numérique en Belgique",
        services: "Analyses d’orientation | danswholesaleplants",
        about: "À propos de la plateforme | danswholesaleplants",
        blog: "Analyses et articles | danswholesaleplants",
        post1: "Cartographie stratifiée des nœuds intermodaux | danswholesaleplants",
        post2: "Signalétique cognitive dans les hôpitaux publics | danswholesaleplants",
        post3: "Protocoles d’évaluation UX spatiale | danswholesaleplants",
        post4: "Flux piéton dans les campus urbains | danswholesaleplants",
        post5: "Accessibilité et lisibilité numérique | danswholesaleplants",
        contact: "Contact et coordination | danswholesaleplants",
        faq: "Questions fréquentes | danswholesaleplants",
        terms: "Conditions d’utilisation | danswholesaleplants",
        privacy: "Politique de confidentialité | danswholesaleplants",
        cookies: "Politique relative aux cookies | danswholesaleplants",
        refund: "Politique de rétractation | danswholesaleplants",
        disclaimer: "Avis de non-responsabilité | danswholesaleplants",
        thankYou: "Merci pour votre message | danswholesaleplants",
        notFound: "Page introuvable | danswholesaleplants"
      },
      description: {
        home: "Explorations approfondies en orientation spatiale, signalétique numérique et navigation intérieure pour les environnements publics complexes en Belgique.",
        services: "Cinq axes d’analyse couvrant les défis d’orientation, la signalétique numérique et l’accessibilité dans les infrastructures publiques belges.",
        about: "Plateforme belge dédiée à la recherche sur la cartographie des espaces, la mobilité piétonne et la conception informationnelle.",
        blog: "Articles techniques sur la navigation intérieure, la lisibilité des espaces urbains et l’infrastructure publique.",
        post1: "Étude détaillée des stratégies de cartographie stratifiée pour les nœuds intermodaux et les réseaux multi-niveaux.",
        post2: "Analyse de la signalétique cognitive appliquée aux hôpitaux publics belges pour améliorer les parcours utilisateurs.",
        post3: "Protocoles méthodologiques pour tester l’expérience spatiale dans les environnements bâtis complexes.",
        post4: "Étude des flux piétonniers et de la synchronisation multimodale dans les campus urbains denses.",
        post5: "Guidelines pour une accessibilité inclusive et la lisibilité des plans interactifs numériques.",
        contact: "Coordonnées de danswholesaleplants, formulaire de contact et localisation à Bruxelles.",
        faq: "Réponses aux questions fréquentes sur la navigation intérieure et la signalétique numérique.",
        terms: "Conditions d’utilisation détaillant responsabilités, droits et limites de la plateforme.",
        privacy: "Politique de confidentialité décrivant la collecte, l’utilisation et les droits relatifs aux données.",
        cookies: "Description des cookies utilisés, finalités et options de gestion des préférences.",
        refund: "Procédure de rétractation et modalités de traitement des demandes liées aux contenus.",
        disclaimer: "Limites de responsabilité et absence de garanties concernant les informations publiées.",
        thankYou: "Confirmation de réception de votre message et prochaines étapes de suivi.",
        notFound: "La page demandée est introuvable. Redirection vers l’accueil proposée."
      }
    },
    nav: {
      home: "Accueil",
      services: "Analyses",
      about: "À propos",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    },
    lang: {
      fr: "FR",
      en: "EN",
      label: "Sélection de la langue"
    },
    common: {
      brandName: "danswholesaleplants",
      tagline: "Orientation spatiale et signalétique numérique",
      phoneLabel: "Téléphone",
      emailLabel: "Courriel",
      addressLabel: "Adresse",
      phoneValue: "+32 2 123 45 67",
      emailValue: "contact@danswholesaleplants.com",
      addressValue: "Rue de la Loi 200, 1000 Bruxelles, Belgique",
      legalTitle: "Pages légales",
      quickLinks: "Navigation",
      contactLinks: "Coordonnées"
    },
    buttons: {
      learnMore: "Comprendre l’approche",
      readCase: "Consulter le dossier",
      viewAllArticles: "Voir tous les articles",
      contactTeam: "Écrire à l’équipe",
      exploreServices: "Explorer les analyses",
      downloadOutline: "Télécharger la fiche",
      returnHome: "Retour à l’accueil",
      openArticles: "Accéder aux articles",
      submit: "Envoyer",
      viewFaq: "Consulter la FAQ"
    },
    home: {
      hero: {
        title: "Cartographier les parcours utilisateurs dans les environnements complexes",
        subtitle: "Nous analysons la convergence entre architecture, UX spatiale et signalétique numérique pour fluidifier la navigation intérieure au sein des bâtiments publics et des espaces urbains belges.",
        primaryAction: "Explorer les axes d’étude",
        secondaryAction: "Découvrir la méthodologie",
        imageAlt: "Visualisation abstraite d’un plan de circulation multi-niveaux"
      },
      features: {
        heading: "Champs d’investigation clés",
        intro: "Chaque environnement bâti impose des contraintes de compréhension. Nous combinons observation de terrain, modélisation des flux et conception informationnelle pour révéler les points de friction et identifier des leviers de clarté.",
        card1: {
          title: "Signalétique numérique contextuelle",
          body: "Analyse des dispositifs interactifs capables de traduire des données spatiales en repères visuels intuitifs, en tenant compte des profils de visiteurs et des variations temporelles.",
          imageAlt: "Écran de signalétique numérique dans un atrium public"
        },
        card2: {
          title: "Navigation multisensorielle",
          body: "Étude des parcours combinant éléments graphiques, signals sonores et éclairage directionnel afin d’orienter des publics divers dans les réseaux de circulation.",
          imageAlt: "Couloir avec balisage lumineux orientant les usagers"
        },
        card3: {
          title: "Cartographie adaptative",
          body: "Construction de schémas multi-niveaux hiérarchisant les informations et révélant la relation entre espaces de transit, zones fonctionnelles et services annexes.",
          imageAlt: "Plan interactif présentant plusieurs étages d’un complexe"
        }
      },
      metrics: {
        heading: "Repères de nos investigations",
        item1Value: "52",
        item1Label: "scénarios de parcours analysés",
        item2Value: "18",
        item2Label: "campagnes d’observation en Belgique",
        item3Value: "12",
        item3Label: "protocoles UX spatiale comparés"
      },
      pathway: {
        heading: "Cadre méthodologique en trois paliers",
        intro: "Nous articulons les analyses autour d’une progression allant de la lecture du terrain à la simulation digitale. Chaque étape produit des livrables cartographiques exploitables par les équipes de conception.",
        item1Title: "Immersion contextuelle",
        item1Body: "Relevés in situ, inventaire des supports existants et identification des points critiques où les usagers hésitent ou rebroussent chemin.",
        item2Title: "Modélisation systémique",
        item2Body: "Schématisation des flux et hiérarchisation des espaces pour établir des scénarios d’usage alignés sur la structure architecturale.",
        item3Title: "Itérations numériques",
        item3Body: "Prototypage de plans interactifs et de signalétiques dynamiques capables de s’ajuster aux profils et aux temporalités."
      },
      recommendations: {
        heading: "Recommandations stratégiques",
        intro: "Les recommandations regroupent des principes directement activables par les gestionnaires d’infrastructures pour renforcer la lisibilité des espaces et la synchronisation des flux.",
        card1: {
          title: "Structurer les repères primaires",
          body: "Valoriser une terminologie géographique stable et cohérente entre la signalétique physique, les plans numériques et les messages audio."
        },
        card2: {
          title: "Synchroniser les supports",
          body: "Coordonner les dispositifs fixes et interactifs pour maintenir une continuité de l’information lors des changements de niveau ou d’usage."
        },
        card3: {
          title: "Mesurer les parcours réels",
          body: "Mettre en place des boucles de feedback avec les usagers pour confronter les simulations aux trajectoires effectives et ajuster le design informationnel."
        }
      },
      testimonials: {
        heading: "Témoignages terrain",
        intro: "Les partenaires institutionnels et les équipes de gestion des bâtiments partagent leurs retours sur l’utilité des analyses produites.",
        quote1: {
          text: "Les cartographies scénarisées nous ont permis d’aligner les équipes de sécurité, d’accueil et d’exploitation sur un langage spatial commun.",
          author: "Louise Delporte",
          role: "Responsable coordination visiteurs, Maison Administrative de Namur"
        },
        quote2: {
          text: "Les itérations numériques ont été décisives pour convaincre les architectes d’intégrer des jalons lumineux au sein du réseau de passerelles.",
          author: "Gauthier Van Leeuwen",
          role: "Coordinateur technique, Pôle hospitalier de Wallonie"
        },
        quote3: {
          text: "La lecture critique des parcours a mis en évidence des points d’arrêt invisibles, ce qui a amélioré la fluidité des correspondances piétonnes.",
          author: "Sofia Martins",
          role: "Chargée de mobilité douce, Bruxelles Mobilité"
        }
      },
      blogPreview: {
        heading: "Lectures récentes",
        intro: "Chaque article approfondit un aspect spécifique de la navigation intérieure et des dispositifs d’orientation.",
        card1: {
          title: "Cartographie stratifiée des nœuds intermodaux",
          excerpt: "Comprendre comment les repères verticaux, les transitions d’altitude et les correspondances modifient la perception des voyageurs dans les hubs bruxellois.",
          link: "Lire l’article"
        },
        card2: {
          title: "Signalétique cognitive dans les hôpitaux publics",
          excerpt: "Analyse des corridors thérapeutiques, des zones sensibles et des nouveaux protocoles d’accueil dans les structures hospitalières.",
          link: "Explorer l’analyse"
        },
        card3: {
          title: "Protocoles d’évaluation UX spatiale",
          excerpt: "Méthodes mixtes pour évaluer la lisibilité et l’accessibilité de la signalétique numérique dans les bâtiments à forte densité de services.",
          link: "Consulter l’étude"
        }
      },
      callout: {
        heading: "Vous souhaitez structurer un diagnostic d’orientation spatiale ?",
        body: "La plateforme met à disposition des grilles d’observation, des matrices de priorisation et des trames de narration spatiale pour guider vos travaux.",
        action: "Entrer en relation"
      }
    },
    services: {
      hero: {
        title: "Analyses croisées pour décoder les environnements complexes",
        subtitle: "Les cinq axes d’étude s’attachent à traduire la structure bâtie en parcours compréhensibles, en conciliant exigences opérationnelles et attentes des usagers."
      },
      cards: {
        card1: {
          title: "Diagnostic d’orientation",
          body: "Inventaire des repères visuels et auditifs, mesure des ruptures de continuité informationnelle et identification des zones de confusion."
        },
        card2: {
          title: "Design de signalétique numérique",
          body: "Définition des contenus dynamiques, architecture des écrans et scénarisation des messages selon les profils visiteurs."
        },
        card3: {
          title: "Études de mobilité piétonne",
          body: "Traçage des flux, synchronisation avec les circulations verticales et modélisation des trajectoires alternatives."
        },
        card4: {
          title: "Accessibilité et inclusivité",
          body: "Évaluation des contrastes, des supports tactiles et des chemins d’évacuation pour garantir une expérience fluide à tous."
        },
        card5: {
          title: "Évaluation de guidage visuel",
          body: "Tests utilisateurs, analyse de la lisibilité des plans et recommandations sur la hiérarchie informationnelle."
        }
      },
      process: {
        heading: "Processus d’étude",
        intro: "Chaque axe se déroule selon un protocole articulant terrain, modélisation et restitution, afin de documenter les scénarios d’usage.",
        step1Title: "Observation in situ",
        step1Body: "Captation vidéo, chronométrage des parcours et collecte d’entretiens pour cerner les intentions réelles des usagers.",
        step2Title: "Modèles analytiques",
        step2Body: "Construction de cartes de chaleur, matrices de correspondance et diagrammes de visibilité pour qualifier les espaces.",
        step3Title: "Restitution stratégique",
        step3Body: "Production de dossiers illustrés, séquences narratives et recommandations hiérarchisées."
      },
      outcomes: {
        heading: "Livrables types",
        intro: "Les livrables facilitent la prise de décision des architectes, gestionnaires et designers.",
        bullet1: "Plans annotés indiquant les zones de friction et les priorités de signalétique.",
        bullet2: "Tableaux de correspondance entre vocabulaire spatial et parcours utilisateurs.",
        bullet3: "Tableaux de bord synthétisant les mesures de fluidité et de satisfaction."
      }
    },
    about: {
      hero: {
        title: "Une plateforme belge dédiée à l’UX spatiale",
        subtitle: "danswholesaleplants rassemble des analystes, cartographes et spécialistes de la signalétique pour documenter les environnements publics à grande échelle."
      },
      story: {
        heading: "Origine du projet",
        paragraph1: "Créée à Bruxelles, la plateforme est née d’un constat : la multiplication des supports numériques ne garantit pas une expérience cohérente si l’information n’est pas orchestrée selon la logique des lieux.",
        paragraph2: "Nous travaillons avec des gestionnaires d’infrastructures, des studios d’architecture et des collectivités pour rapprocher les enjeux techniques des attentes des usagers."
      },
      approach: {
        heading: "Approche interdisciplinaire",
        point1: "Analyse des flux piétonniers couplée aux contraintes structurelles.",
        point2: "Synthèse des données qualitatives et quantitatives pour nourrir la conception.",
        point3: "Narration spatiale pour communiquer les scénarios aux équipes projet."
      },
      team: {
        heading: "Équipe cœur",
        member1: {
          name: "Maëlle Vasseur",
          role: "Cartographe UX",
          bio: "Spécialisée dans la traduction des contraintes architecturales en plans interactifs compréhensibles."
        },
        member2: {
          name: "Jonas Pieters",
          role: "Analyste mobilité",
          bio: "Travaille sur la synchronisation des flux piétons et des services de transport dans les pôles urbains."
        },
        member3: {
          name: "Inès Van Dam",
          role: "Designer informationnel",
          bio: "Coordonne l’écriture graphique des signalétiques et la cohérence des supports numériques."
        }
      },
      culture: {
        heading: "Principes de travail",
        intro: "Nos principes garantissent la fiabilité des analyses et la transférabilité des enseignements.",
        bullet1: "Transparence méthodologique et documentation complète des hypothèses.",
        bullet2: "Co-construction avec les équipes terrain pour intégrer les contraintes opérationnelles.",
        bullet3: "Prototype rapide pour tester la lisibilité des parcours avant déploiement."
      }
    },
    blogPage: {
      hero: {
        title: "Blog technique",
        subtitle: "Retours d’expérience, protocoles et cadres d’analyse pour décrypter les environnements complexes."
      },
      intro: "Chaque publication s’appuie sur des études conduites dans les espaces publics belges ou sur des benchmarks internationaux.",
      cards: {
        post1: {
          excerpt: "Comment superposer niveaux de circulation, correspondances verticales et repères temporels dans les hubs intermodaux.",
          link: "Lire la suite"
        },
        post2: {
          excerpt: "Concevoir des parcours apaisants et informatifs au sein des établissements hospitaliers ouverts au public.",
          link: "Explorer"
        },
        post3: {
          excerpt: "Définir des protocoles d’évaluation combinant mesures quantitatives et récits utilisateur.",
          link: "Étudier"
        },
        post4: {
          excerpt: "Optimiser la circulation piétonne dans des campus denses tout en respectant la diversité des usages.",
          link: "Analyser"
        },
        post5: {
          excerpt: "Mettre en cohérence accessibilité, contrastes visuels et interfaces numériques adaptatives.",
          link: "Consulter"
        }
      }
    },
    posts: {
      post1: {
        title: "Cartographie stratifiée des nœuds intermodaux",
        intro: "Les pôles intermodaux concentrent des flux variés qui se croisent à différentes altitudes. L’organisation de leur signalétique requiert une lecture stratifiée intégrant la verticalité, la temporalité et les corridors de correspondance.",
        section1: {
          title: "Lire les strates verticales",
          paragraph1: "La première étape consiste à décortiquer la superposition des niveaux. Dans la majorité des hubs bruxellois, les voyageurs transitent entre quais souterrains, mezzanines et passerelles aériennes. Chaque strate possède son propre langage spatial, souvent hérité d’époques architecturales différentes. Nous dressons une cartographie précise des correspondances, en croisant plans techniques, relevés photographiques et observations in situ pour identifier les ruptures de continuité linguistique ou graphique.",
          paragraph2: "Cette cartographie met en évidence des zones d’ombre où le voyageur perd ses repères : intersections de couloirs, ascenseurs peu visibles, escaliers débouchant dans des halls saturés. Nous qualifions ces points de friction selon leur intensité et leur fréquence afin de hiérarchiser les interventions futures. L’exercice révèle la nécessité d’un langage visuel unifié, fondé sur un vocabulaire cohérent pour désigner les niveaux et les liaisons clés."
        },
        subsection1: {
          title: "Aligner les repères horizontaux et verticaux",
          paragraph1: "La confrontation des plans horizontaux et verticaux permet de détecter les écarts de perception. Les usagers lisent d’abord la continuité du sol ; la verticalité ne devient intelligible que si les transitions sont explicites. Nous recommandons de matérialiser les axes majeurs par des dispositifs lumineux ou sonores qui accompagnent physiquement le déplacement entre les niveaux.",
          paragraph2: "Un alignement réussi réduit le stress décisionnel au moment de choisir une direction. Les séquences de signalétique numérique doivent confirmer le mouvement engagé, éviter les injonctions contradictoires et rappeler les repères temporels liés aux correspondances. Une charte commune regroupe ces principes pour garantir la cohérence des futures mises à jour."
        },
        subsection2: {
          title: "Orchestrer les points de convergence",
          paragraph1: "Les hubs intermodaux fonctionnent comme des réseaux de salles de distribution. Les points de convergence doivent absorber plusieurs flux sans créer de congestion cognitive. Nous analysons la densité des supports d’information présents et leur lisibilité à distance pour éviter la saturation.",
          paragraph2: "En positionnant chaque support dans un schéma radar, nous révélons les angles morts et les espaces à clarifier. Les solutions préconisées privilégient des totems modulaires capables de réunir informations statiques et dynamiques, tout en conservant une hiérarchie claire entre directions primaires et informations de service."
        },
        section2: {
          title: "Temporalités et saisons de trafic",
          paragraph1: "La stratification cartographique doit intégrer les variations temporelles. Les flux ne sont pas homogènes : les périodes de travaux, les pics événementiels et les contraintes météo transforment les comportements. Nous déroulons donc plusieurs scénarios de trafic afin de vérifier la résilience des parcours et la stabilité des repères.",
          paragraph2: "Cette approche aboutit à une matrice saisonnière qui croise densité, profil d’usagers et exigences de service. Elle sert de base aux équipes opérationnelles pour planifier les ajustements de signalétique numérique et les interventions temporaires. Les données récoltées alimentent également une cartographie prospective, anticipant les futures évolutions du hub."
        },
        subsection3: {
          title: "Synthèse opérationnelle",
          paragraph1: "Le livrable final associe atlas illustré, modèles interactifs et recommandations priorisées. Il accompagne les décideurs dans la sélection des interventions pertinentes à court, moyen et long terme.",
          paragraph2: "Chaque intervention est reliée à un indicateur mesurable : temps de parcours moyen, taux d’erreurs de direction, capacité de résilience lors de perturbations. La cartographie stratifiée devient ainsi un outil de pilotage continu, capable d’éclairer les évolutions architecturales sans perdre de vue l’expérience voyageur."
        }
      },
      post2: {
        title: "Signalétique cognitive dans les hôpitaux publics",
        intro: "Les hôpitaux publics regroupent des services techniques, administratifs et de soin, chacun imposant des contraintes d’orientation spécifiques. Une signalétique cognitive repose sur des repères familiers, compréhensibles dans des situations émotionnelles parfois intenses.",
        section1: {
          title: "Identifier les parcours prioritaires",
          paragraph1: "Nous commençons par cartographier les itinéraires critiques : admissions urgentes, consultations programmées, visites et logistique interne. Chaque parcours possède des besoins d’information distincts. Les équipes hospitalières fournissent des retours précieux sur les questions récurrentes et les zones de confusion.",
          paragraph2: "Les observations in situ révèlent que l’anxiété modifie la capacité de lecture. Nous évaluons donc la charge cognitive de chaque message et vérifions que les informations essentielles ne sont jamais noyées dans des détails superflus. Les codes couleur sont testés auprès des usagers pour garantir leur interprétation immédiate."
        },
        subsection1: {
          title: "Langage visuel apaisant",
          paragraph1: "Un langage visuel trop technique peut renforcer le stress. Nous privilégions des pictogrammes clairs, des typographies lisibles et des contrastes doux pour faciliter la mémorisation des repères. Les couloirs critiques reçoivent des éléments répétitifs qui confirment la direction empruntée.",
          paragraph2: "Des jalons temporels rappellent le temps estimé jusqu’au service recherché. Cette indication réduit l’incertitude et aide le visiteur à se projeter. La signalétique numérique reprend les mêmes codes afin d’éviter toute dissonance entre supports."
        },
        subsection2: {
          title: "Coordination des supports physiques et numériques",
          paragraph1: "Les hôpitaux belges multiplient les écrans d’orientation. Sans harmonisation, ces dispositifs peuvent diffuser des messages contradictoires. Nous proposons un modèle de gouvernance définissant qui met à jour les contenus, selon quelles fréquences et quels scénarios d’exception.",
          paragraph2: "Les contenus sont organisés en couches : informations permanentes, alertes temporaires, notifications contextuelles. Cette hiérarchisation garantit qu’un visiteur pressé identifie immédiatement le message le plus utile."
        },
        section2: {
          title: "Inclure la diversité des publics",
          paragraph1: "Les hôpitaux accueillent des personnes aux capacités sensorielles variées. Nous évaluons les contrastes, la présence de textes alternatifs et l’accessibilité tactile. Les ascenseurs reçoivent des plans simplifiés pour détailler chaque étage avant de sortir de la cabine.",
          paragraph2: "Nous recommandons également des parcours guidés audio pour certaines sections. Les retours des associations de patients permettent de vérifier la clarté des instructions et d’ajuster le vocabulaire employé."
        },
        subsection3: {
          title: "Suivi et mise à jour",
          paragraph1: "L’efficience de la signalétique cognitive repose sur un suivi continu. Des audits trimestriels comparent les retours des usagers et les indicateurs de temps de parcours.",
          paragraph2: "Les conclusions alimentent une feuille de route garantissant la cohérence des futures extensions ou rénovations. Les équipes hospitalières disposent ainsi d’un référentiel dynamique facilitant la prise de décision."
        }
      },
      post3: {
        title: "Protocoles d’évaluation UX spatiale",
        intro: "Tester l’expérience spatiale demande de combiner mesures quantitatives et récits qualitatifs. Les protocoles proposés s’adaptent aux typologies d’espaces publics pour évaluer la compréhension des parcours et la lisibilité des supports.",
        section1: {
          title: "Préparer la campagne de tests",
          paragraph1: "La préparation commence par une segmentation des profils utilisateurs. Nous sélectionnons des participants réguliers, occasionnels et novices, afin de couvrir l’ensemble des représentations mentales. Les scénarios de test sont décrits avec précision : point de départ, objectifs, contraintes temporelles et informations disponibles.",
          paragraph2: "Nous instrumentons le parcours avec des capteurs légers, des grilles d’observation et des questionnaires de sortie. L’objectif est de capter les moments de doute, les arrêts prolongés et les changements de stratégie. Ces données nourrissent une ligne de base pour comparer les itérations futures de la signalétique."
        },
        subsection1: {
          title: "Combiner mesures et récits",
          paragraph1: "Les mesures de temps de parcours donnent une vision macroscopique, mais elles ne suffisent pas. Nous croisons ces données avec des verbatims collectés immédiatement après le trajet afin de conserver la fraîcheur des perceptions.",
          paragraph2: "Chaque participant dessine ensuite une carte mentale du parcours réalisé. Ces représentations révèlent les repères mémorables et les zones floues. Nous analysons la profondeur des champs visuels cités pour détecter les besoins de renforcement."
        },
        subsection2: {
          title: "Évaluer la signalétique numérique",
          paragraph1: "Les écrans interactifs et applications mobiles sont évalués sur leur capacité à adapter les contenus selon le contexte. Nous testons la pertinence des filtres, la clarté des informations et la cohérence avec la signalétique physique.",
          paragraph2: "Une attention particulière est portée à la transition entre le support numérique et le déplacement réel. Les tests vérifient que l’utilisateur n’abandonne pas le dispositif faute d’indications tangibles sur le terrain."
        },
        section2: {
          title: "Analyser et partager les résultats",
          paragraph1: "Les résultats sont agrégés dans une matrice croisant satisfaction, compréhension et effort perçu. Chaque point de friction reçoit une fiche détaillant la cause, les impacts et les pistes de correction.",
          paragraph2: "Nous organisons des ateliers de restitution avec les équipes métiers pour traduire les enseignements en décisions concrètes. Les protocoles deviennent ainsi des outils de pilotage continus, ajustables à chaque nouvelle transformation du site."
        },
        subsection3: {
          title: "Capitaliser pour les projets futurs",
          paragraph1: "Les observations accumulées alimentent une bibliothèque interne de principes et d’indicateurs. Elle sert de référence pour démarrer plus rapidement les évaluations sur de nouveaux sites.",
          paragraph2: "La capitalisation garantit que les connaissances acquises restent accessibles, même lorsque les équipes changent. L’UX spatiale devient un processus apprenant, capable d’anticiper les défis émergents."
        }
      },
      post4: {
        title: "Flux piétonniers dans les campus urbains",
        intro: "Les campus urbains associent bâtiments d’enseignement, espaces publics et services logistiques. Comprendre les flux piétonniers permet de synchroniser les usages et d’éviter les saturations lors des pics d’affluence.",
        section1: {
          title: "Décrypter les trajectoires quotidiennes",
          paragraph1: "Nous observons les itinéraires quotidiens à différentes heures de la journée. Les étudiants privilégient souvent les axes courts, même s’ils sont encombrés, tandis que les visiteurs recherchent les passages les mieux signalés. Les cartes de chaleur produites mettent en évidence les zones sous-utilisées et les corridors saturés.",
          paragraph2: "Les variations saisonnières influencent également les choix de trajectoire. Les conditions météorologiques et les travaux temporaires modifient la perception de la distance. Nous intégrons ces paramètres dans la modélisation pour obtenir un diagnostic robuste."
        },
        subsection1: {
          title: "Mettre en cohérence les supports directionnels",
          paragraph1: "Les campus accumulent des générations de signalétique. Nous inventaireons chaque support et évaluons sa lisibilité. Les messages contradictoires sont supprimés ou réécrits pour garantir une cohérence sémantique.",
          paragraph2: "Les cartes d’orientation sont positionnées aux points décisionnels. Elles indiquent clairement les temps de marche, les services essentiels et les zones calmes. Ces informations rassurent les visiteurs et fluidifient la circulation."
        },
        subsection2: {
          title: "Synchroniser avec les mobilités douces",
          paragraph1: "Les campus urbains sont traversés par des pistes cyclables et des voies de livraison. Nous analysons l’interaction entre ces flux et les déplacements piétons pour éviter les conflits d’usage.",
          paragraph2: "Des marquages au sol et des dispositifs lumineux matérialisent les zones de cohabitation. Les plans numériques intègrent ces informations pour guider les utilisateurs vers les passages les plus sûrs."
        },
        section2: {
          title: "Expérimenter les scénarios d’événements",
          paragraph1: "Les événements exceptionnels bouleversent la circulation. Nous simulons différents scénarios, des journées portes ouvertes aux colloques internationaux, afin de tester la résilience de la signalétique.",
          paragraph2: "Les recommandations incluent des kits temporaires faciles à déployer : bannières modulaires, notifications ciblées et balisage lumineux. Ils complètent la signalétique permanente sans créer de confusion."
        },
        subsection3: {
          title: "Vers une gouvernance partagée",
          paragraph1: "Les résultats sont intégrés dans un plan de gouvernance impliquant les services techniques, les associations étudiantes et les partenaires municipaux.",
          paragraph2: "Cette gouvernance veille à la mise à jour régulière des supports et à la circulation des informations lors des travaux ou réaménagements."
        }
      },
      post5: {
        title: "Accessibilité et lisibilité numérique",
        intro: "Les interfaces numériques complètent la signalétique physique, mais leur efficacité dépend de leur capacité à transmettre des informations accessibles, adaptatives et lisibles pour tous les publics.",
        section1: {
          title: "Concevoir des interfaces inclusives",
          paragraph1: "Nous évaluons la compatibilité des plans interactifs avec les technologies d’assistance. Les contrastes, tailles de police et descriptions audio sont vérifiés pour garantir une compréhension immédiate.",
          paragraph2: "Les parcours proposés doivent tenir compte des besoins spécifiques : ascenseurs adaptés, zones de repos, cheminements sans obstacles. Les interfaces suggèrent des trajets alternatifs en fonction des profils d’utilisateurs."
        },
        subsection1: {
          title: "Structurer l’information",
          paragraph1: "Les plans numériques sont organisés en couches : accès rapides, équipements de service, itinéraires détaillés. Cette structure limite la surcharge cognitive.",
          paragraph2: "Des systèmes de filtres permettent d’afficher uniquement les informations pertinentes. Les utilisateurs peuvent enregistrer un trajet et le retrouver facilement lors de leur visite."
        },
        subsection2: {
          title: "Assurer la cohérence multi-supports",
          paragraph1: "La lisibilité dépend de la cohérence entre interfaces mobiles, écrans sur place et supports imprimés. Nous définissons un langage visuel partagé et des règles de gouvernance pour maintenir l’alignement.",
          paragraph2: "Les mises à jour sont synchronisées via un calendrier éditorial. Chaque changement passe par une vérification linguistique et graphique pour rester accessible."
        },
        section2: {
          title: "Mesurer l’efficacité",
          paragraph1: "Des tests utilisateurs réguliers évaluent la compréhension des interfaces. Nous observons la rapidité d’appropriation, les erreurs de navigation et la satisfaction globale.",
          paragraph2: "Les indicateurs sont regroupés dans un tableau de bord accessible aux équipes opérationnelles. Il sert de base à l’amélioration continue et à la planification des évolutions fonctionnelles."
        },
        subsection3: {
          title: "Diffuser les bonnes pratiques",
          paragraph1: "Les enseignements sont compilés dans un guide partagé avec les partenaires publics belges. Il couvre les aspects techniques, graphiques et organisationnels.",
          paragraph2: "Cette diffusion favorise une culture commune de l’accessibilité numérique, essentielle pour maintenir des environnements accueillants et lisibles."
        }
      }
    },
    contact: {
      hero: {
        title: "Coordination et échanges",
        subtitle: "Prenez contact pour partager vos enjeux d’orientation spatiale ou obtenir des informations complémentaires sur les études en cours."
      },
      details: {
        heading: "Coordonnées directes",
        phoneLabel: "Téléphone de coordination",
        emailLabel: "Adresse électronique",
        addressLabel: "Localisation",
        phoneValue: "+32 2 123 45 67",
        emailValue: "contact@danswholesaleplants.com",
        addressValue: "Rue de la Loi 200, 1000 Bruxelles, Belgique",
        availability: "Disponibilité",
        availabilityValue: "Du lundi au vendredi, 9h00 - 17h30 CET"
      },
      form: {
        heading: "Formulaire de contact",
        intro: "Indiquez le contexte de votre structure et les problématiques de navigation rencontrées.",
        nameLabel: "Nom complet",
        namePlaceholder: "Votre nom",
        emailLabel: "Adresse courriel",
        emailPlaceholder: "vous@example.com",
        organizationLabel: "Organisation",
        organizationPlaceholder: "Institution ou structure",
        messageLabel: "Message",
        messagePlaceholder: "Décrivez vos besoins, contraintes ou questions",
        consentLabel: "J’accepte que mes informations soient utilisées pour organiser une prise de contact.",
        submit: "Envoyer la demande"
      },
      map: {
        heading: "Carte et accès",
        description: "Les bureaux d’analyse se situent à proximité du quartier européen, facilement accessibles en transports en commun.",
        title: "Carte de la localisation à Bruxelles"
      }
    },
    faq: {
      hero: {
        title: "Questions fréquentes",
        subtitle: "Clarifications sur la méthodologie, les livrables et les axes d’analyse de danswholesaleplants."
      },
      items: {
        q1: {
          question: "Comment démarrez-vous un diagnostic d’orientation ?",
          answer: "Nous débutons par une rencontre avec les équipes terrain, suivie d’un repérage des points critiques et d’un inventaire des supports existants."
        },
        q2: {
          question: "Quels types de données collectez-vous ?",
          answer: "Des observations de flux, des entretiens utilisateurs, des relevés photographiques et des mesures temporelles selon la configuration des lieux."
        },
        q3: {
          question: "Intervenez-vous sur des projets neufs ?",
          answer: "Oui, la plateforme accompagne aussi bien les rénovations que les projets en phase de conception pour anticiper les parcours."
        },
        q4: {
          question: "Produisez-vous des plans interactifs ?",
          answer: "Nous réalisons des prototypes fonctionnels permettant de tester la hiérarchie de l’information et la cohérence avec la signalétique physique."
        },
        q5: {
          question: "Comment intégrez-vous l’accessibilité universelle ?",
          answer: "Chaque livrable inclut des recommandations dédiées aux usagers à mobilité réduite, aux publics neurodivergents et aux visiteurs internationaux."
        },
        q6: {
          question: "Avez-vous des partenariats institutionnels ?",
          answer: "La plateforme collabore régulièrement avec des opérateurs de transport, des hôpitaux et des administrations belges."
        },
        q7: {
          question: "Comment gérez-vous la mise à jour des signalétiques ?",
          answer: "Nous proposons des protocoles de gouvernance qui définissent la fréquence, les responsabilités et les critères de validation."
        },
        q8: {
          question: "Les analyses incluent-elles des tests utilisateurs ?",
          answer: "Oui, lorsque le contexte l’exige, des tests qualitatifs et quantitatifs sont menés pour valider la lisibilité des parcours."
        }
      }
    },
    terms: {
      intro: "Ces conditions encadrent l’usage du site dans le respect de la législation belge. Toute consultation implique l’acceptation intégrale des sections suivantes.",
      section1: {
        title: "1. Objet",
        body: "Le site présente des contenus informatifs liés à l’orientation spatiale. Aucun acte commercial ni engagement contractuel n’y est proposé."
      },
      section2: {
        title: "2. Accès",
        body: "L’accès est libre et gratuit. L’utilisateur garantit disposer des moyens techniques nécessaires pour consulter les contenus."
      },
      section3: {
        title: "3. Propriété intellectuelle",
        body: "Les textes, visuels et schémas sont protégés. Toute reproduction nécessite l’accord écrit de danswholesaleplants."
      },
      section4: {
        title: "4. Contenus tiers",
        body: "Les références à des projets externes sont citées à titre informatif. Les droits associés restent la propriété de leurs auteurs."
      },
      section5: {
        title: "5. Exactitude des informations",
        body: "Les informations sont régulièrement vérifiées. Elles peuvent toutefois évoluer sans préavis pour refléter l’état des recherches."
      },
      section6: {
        title: "6. Responsabilités",
        body: "Danswholesaleplants décline toute responsabilité en cas d’interprétation erronée ou d’usage détourné des contenus consultés."
      },
      section7: {
        title: "7. Disponibilité du site",
        body: "Un soin particulier est apporté à la disponibilité. Des interruptions ponctuelles peuvent survenir pour maintenance."
      },
      section8: {
        title: "8. Liens hypertextes",
        body: "Les liens sortants sont fournis pour enrichir la lecture. Danswholesaleplants ne contrôle pas les contenus des sites tiers."
      },
      section9: {
        title: "9. Données personnelles",
        body: "Toute collecte est réalisée conformément à la politique de confidentialité publiée sur le site."
      },
      section10: {
        title: "10. Cookies",
        body: "Les cookies servent à améliorer la navigation. Le détail figure dans la politique relative aux cookies."
      },
      section11: {
        title: "11. Messagerie",
        body: "Les messages envoyés via le formulaire sont traités pour répondre aux sollicitations. Aucun fichier automatique n’est constitué sans consentement."
      },
      section12: {
        title: "12. Modifications",
        body: "Les présentes conditions peuvent être mises à jour. La date de révision est indiquée en tête de document."
      },
      section13: {
        title: "13. Droit applicable",
        body: "Les conditions sont régies par le droit belge. Tout litige relève des juridictions compétentes de Bruxelles."
      },
      section14: {
        title: "14. Contact",
        body: "Pour toute question, utilisez le formulaire de contact ou écrivez à contact@danswholesaleplants.com."
      }
    },
    privacy: {
      intro: "Cette politique décrit la manière dont danswholesaleplants traite les données personnelles collectées via le site.",
      section1: {
        title: "1. Responsable du traitement",
        body: "Le responsable est danswholesaleplants, Rue de la Loi 200, 1000 Bruxelles."
      },
      section2: {
        title: "2. Données collectées",
        body: "Les données transmises via le formulaire de contact comprennent nom, adresse électronique, organisation et message."
      },
      section3: {
        title: "3. Finalités",
        body: "Les données servent uniquement à répondre aux sollicitations et à organiser les échanges éventuels."
      },
      section4: {
        title: "4. Base légale",
        body: "La collecte repose sur le consentement exprimé lors de l’envoi du formulaire."
      },
      section5: {
        title: "5. Durée de conservation",
        body: "Les données sont conservées pendant la durée nécessaire au suivi de la demande, sans excéder douze mois sans interaction."
      },
      section6: {
        title: "6. Partage",
        body: "Les informations ne sont pas communiquées à des tiers, sauf obligation légale."
      },
      section7: {
        title: "7. Sécurité",
        body: "Des mesures techniques et organisationnelles protègent les données contre tout accès non autorisé."
      },
      section8: {
        title: "8. Droits des personnes",
        body: "Vous disposez de droits d’accès, de rectification, d’effacement, de limitation et d’opposition."
      },
      section9: {
        title: "9. Exercice des droits",
        body: "Adressez vos demandes à contact@danswholesaleplants.com en précisant l’objet de votre requête."
      },
      section10: {
        title: "10. Mise à jour",
        body: "La présente politique peut évoluer. La version en vigueur est consultable sur cette page."
      }
    },
    cookiesPage: {
      hero: {
        title: "Politique relative aux cookies",
        subtitle: "Informations sur l’usage des cookies et la gestion des préférences."
      },
      intro: "Le site utilise des cookies pour assurer son fonctionnement et améliorer la compréhension des usages. Certains cookies sont essentiels, d’autres optionnels.",
      tableTitle: "Inventaire des cookies",
      table: {
        header: {
          name: "Nom",
          provider: "Fournisseur",
          type: "Type",
          purpose: "Finalité",
          duration: "Durée"
        },
        row1: {
          name: "site_lang",
          provider: "danswholesaleplants",
          type: "Préférence",
          purpose: "Mémoriser la langue sélectionnée par l’utilisateur.",
          duration: "12 mois"
        },
        row2: {
          name: "cookie_consent",
          provider: "danswholesaleplants",
          type: "Consentement",
          purpose: "Enregistrer les choix exprimés concernant les cookies.",
          duration: "12 mois"
        },
        row3: {
          name: "session_metrics",
          provider: "danswholesaleplants",
          type: "Analytique",
          purpose: "Mesurer la fréquentation agrégée des pages pour améliorer les contenus.",
          duration: "Session"
        }
      },
      managing: {
        heading: "Gestion des préférences",
        body: "Vous pouvez ajuster vos préférences de cookies à tout moment via le bandeau disponible sur chaque page."
      },
      updates: {
        heading: "Mises à jour",
        body: "Cette politique peut être actualisée pour refléter les évolutions techniques ou réglementaires."
      },
      contact: {
        heading: "Contact",
        body: "Toute question relative aux cookies peut être adressée à contact@danswholesaleplants.com."
      }
    },
    refund: {
      hero: {
        title: "Politique de rétractation",
        subtitle: "Informations sur les modalités de retrait et de correction des contributions."
      },
      section1: {
        title: "1. Objet",
        body: "La politique de rétractation concerne les contenus fournis via le site et les échanges associés."
      },
      section2: {
        title: "2. Demandes",
        body: "Toute demande doit être transmise par courrier électronique à contact@danswholesaleplants.com."
      },
      section3: {
        title: "3. Délai de traitement",
        body: "Les demandes sont examinées dans un délai maximum de trente jours."
      },
      section4: {
        title: "4. Conditions",
        body: "La rétractation s’applique lorsque les contenus ne correspondent pas aux informations convenues lors des échanges préalables."
      },
      section5: {
        title: "5. Modalités",
        body: "Danswholesaleplants propose des corrections ou retraits des contenus concernés."
      },
      section6: {
        title: "6. Exclusions",
        body: "Les contenus déjà publiés sur des plateformes tierces ne sont pas couverts par cette politique."
      },
      section7: {
        title: "7. Échanges complémentaires",
        body: "Des échanges supplémentaires peuvent être nécessaires pour comprendre le contexte et proposer une solution adéquate."
      },
      section8: {
        title: "8. Documentation",
        body: "Les correspondances sont archivées afin de conserver une trace du traitement de la demande."
      },
      section9: {
        title: "9. Responsabilités partagées",
        body: "Le demandeur s’engage à fournir toutes informations utiles pour faciliter l’analyse."
      },
      section10: {
        title: "10. Mise à jour",
        body: "La politique peut évoluer. La version la plus récente reste accessible sur cette page."
      }
    },
    disclaimer: {
      hero: {
        title: "Avis de non-responsabilité",
        subtitle: "Limites d’utilisation des informations publiées sur danswholesaleplants."
      },
      section1: {
        title: "1. Nature des informations",
        body: "Les contenus ont un but informatif. Ils ne constituent pas un avis professionnel personnalisé."
      },
      section2: {
        title: "2. Absence de garantie",
        body: "Danswholesaleplants ne garantit pas l’exhaustivité ni l’actualité permanente des informations."
      },
      section3: {
        title: "3. Utilisation des contenus",
        body: "Toute utilisation doit être adaptée au contexte propre de l’utilisateur. Danswholesaleplants n’est pas responsable des décisions prises sur cette base."
      },
      section4: {
        title: "4. Liens externes",
        body: "Les liens vers des sites tiers sont fournis sans contrôle continu. Leur contenu peut changer sans préavis."
      },
      section5: {
        title: "5. Évolutions",
        body: "Le présent avis peut être modifié pour intégrer de nouvelles situations ou obligations légales."
      },
      section6: {
        title: "6. Contact",
        body: "Adressez vos questions à contact@danswholesaleplants.com."
      }
    },
    thankYou: {
      title: "Message transmis",
      message: "Merci pour votre prise de contact. L’équipe analysera votre demande et reviendra vers vous dans les meilleurs délais.",
      linkLabel: "Revenir à l’accueil"
    },
    notFound: {
      title: "Page introuvable",
      message: "La page que vous recherchez n’existe plus ou a changé d’adresse. Retournez vers l’accueil pour poursuivre votre exploration.",
      linkLabel: "Retour à l’accueil"
    },
    cookieBanner: {
      heading: "Gestion des cookies",
      description: "Nous utilisons des cookies pour optimiser votre navigation. Vous pouvez accepter, refuser ou personnaliser vos préférences.",
      manage: "Gérer les préférences",
      acceptAll: "Tout accepter",
      declineAll: "Tout refuser",
      save: "Enregistrer",
      close: "Fermer",
      categories: {
        necessary: {
          title: "Cookies nécessaires",
          description: "Indispensables au fonctionnement du site. Toujours actifs."
        },
        preferences: {
          title: "Cookies de préférence",
          description: "Retiennent vos choix d’affichage et de langue."
        },
        analytics: {
          title: "Cookies analytiques",
          description: "Mesurent de manière agrégée la fréquentation des pages."
        },
        marketing: {
          title: "Cookies marketing",
          description: "Non utilisés actuellement. Reste inactif par défaut."
        }
      }
    },
    toast: {
      contactSubmitting: "Votre message est en cours d’envoi…",
      contactSubmitted: "Merci, votre message a bien été transmis."
    }
  },
  en: {
    meta: {
      title: {
        home: "danswholesaleplants | Spatial orientation and digital wayfinding in Belgium",
        services: "Orientation analyses | danswholesaleplants",
        about: "About the platform | danswholesaleplants",
        blog: "Insights and articles | danswholesaleplants",
        post1: "Layered cartography for intermodal nodes | danswholesaleplants",
        post2: "Cognitive signage in public hospitals | danswholesaleplants",
        post3: "Spatial UX evaluation protocols | danswholesaleplants",
        post4: "Pedestrian flows in urban campuses | danswholesaleplants",
        post5: "Accessibility and digital legibility | danswholesaleplants",
        contact: "Contact and coordination | danswholesaleplants",
        faq: "Frequently asked questions | danswholesaleplants",
        terms: "Terms of use | danswholesaleplants",
        privacy: "Privacy policy | danswholesaleplants",
        cookies: "Cookie policy | danswholesaleplants",
        refund: "Withdrawal policy | danswholesaleplants",
        disclaimer: "Disclaimer | danswholesaleplants",
        thankYou: "Thank you for your message | danswholesaleplants",
        notFound: "Page not found | danswholesaleplants"
      },
      description: {
        home: "In-depth explorations of spatial orientation, digital signage and indoor navigation for complex public environments in Belgium.",
        services: "Five analytical pillars covering wayfinding challenges, digital signage and accessibility within Belgian public infrastructure.",
        about: "Belgian platform dedicated to research on spatial mapping, pedestrian mobility and information design.",
        blog: "Technical articles on indoor navigation, urban space legibility and public infrastructure.",
        post1: "Detailed study of layered mapping strategies for intermodal nodes and multi-level networks.",
        post2: "Analysis of cognitive signage applied to Belgian public hospitals to improve user journeys.",
        post3: "Methodological protocols for testing spatial experience within complex built environments.",
        post4: "Study of pedestrian dynamics and multimodal synchronisation in dense urban campuses.",
        post5: "Guidelines for inclusive accessibility and the legibility of digital interactive maps.",
        contact: "Contact details for danswholesaleplants, inquiry form and Brussels location.",
        faq: "Answers to common questions on indoor navigation and digital signage.",
        terms: "Terms governing responsibilities, rights and limitations of the platform.",
        privacy: "Privacy policy describing data collection, usage and user rights.",
        cookies: "Description of cookie usage, purposes and preference management options.",
        refund: "Procedure for withdrawal and handling of requests related to shared content.",
        disclaimer: "Liability limitations and absence of guarantees regarding published information.",
        thankYou: "Confirmation that your message was received and next steps.",
        notFound: "The page could not be found. A redirection to the homepage is suggested."
      }
    },
    nav: {
      home: "Home",
      services: "Analyses",
      about: "About",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact"
    },
    lang: {
      fr: "FR",
      en: "EN",
      label: "Language selection"
    },
    common: {
      brandName: "danswholesaleplants",
      tagline: "Spatial orientation and digital signage",
      phoneLabel: "Phone",
      emailLabel: "Email",
      addressLabel: "Address",
      phoneValue: "+32 2 123 45 67",
      emailValue: "contact@danswholesaleplants.com",
      addressValue: "Rue de la Loi 200, 1000 Brussels, Belgium",
      legalTitle: "Legal pages",
      quickLinks: "Navigation",
      contactLinks: "Contact details"
    },
    buttons: {
      learnMore: "Understand our approach",
      readCase: "Review the dossier",
      viewAllArticles: "View all articles",
      contactTeam: "Write to the team",
      exploreServices: "Explore the analyses",
      downloadOutline: "Download the outline",
      returnHome: "Back to homepage",
      openArticles: "Browse articles",
      submit: "Send",
      viewFaq: "Consult the FAQ"
    },
    home: {
      hero: {
        title: "Mapping user journeys across complex environments",
        subtitle: "We study the convergence of architecture, spatial UX and digital signage to ease indoor navigation within Belgian public buildings and urban spaces.",
        primaryAction: "Explore the study pillars",
        secondaryAction: "Discover the methodology",
        imageAlt: "Abstract visualization of a multi-level circulation plan"
      },
      features: {
        heading: "Key investigation fields",
        intro: "Every built environment imposes specific comprehension constraints. We combine field observation, flow modelling and information design to reveal friction points and identify clarity levers.",
        card1: {
          title: "Context-aware digital signage",
          body: "Analysis of interactive systems translating spatial data into intuitive visual cues, considering visitor profiles and temporal variations.",
          imageAlt: "Digital signage screen in a public atrium"
        },
        card2: {
          title: "Multisensory navigation",
          body: "Study of journeys combining graphic elements, sound cues and directional lighting to guide diverse audiences through circulation networks.",
          imageAlt: "Corridor with guiding light strips directing users"
        },
        card3: {
          title: "Adaptive mapping",
          body: "Development of multi-level diagrams prioritising information and revealing relationships between transit zones, functional areas and adjacent services.",
          imageAlt: "Interactive plan showing several floors of a complex"
        }
      },
      metrics: {
        heading: "Signals from our investigations",
        item1Value: "52",
        item1Label: "journey scenarios analysed",
        item2Value: "18",
        item2Label: "observation campaigns in Belgium",
        item3Value: "12",
        item3Label: "spatial UX protocols compared"
      },
      pathway: {
        heading: "Three-tier methodological framework",
        intro: "Our analyses progress from terrain reading to digital simulation. Each step yields cartographic deliverables that can be directly used by design teams.",
        item1Title: "Contextual immersion",
        item1Body: "On-site surveys, inventory of existing supports and identification of the decision points where users hesitate or turn back.",
        item2Title: "Systemic modelling",
        item2Body: "Schematic representation of flows and spatial hierarchies to build use-case scenarios aligned with architectural structure.",
        item3Title: "Digital iterations",
        item3Body: "Prototyping of interactive maps and dynamic signage that can adapt to user profiles and temporal patterns."
      },
      recommendations: {
        heading: "Strategic recommendations",
        intro: "The recommendations gather principles that infrastructure managers can activate to strengthen space legibility and flow synchronisation.",
        card1: {
          title: "Structure primary landmarks",
          body: "Promote stable geographic terminology across physical signage, digital plans and audio announcements."
        },
        card2: {
          title: "Synchronise the supports",
          body: "Coordinate static and interactive devices to maintain information continuity when levels or uses change."
        },
        card3: {
          title: "Measure actual journeys",
          body: "Implement feedback loops with users to confront simulations with effective trajectories and adjust information design."
        }
      },
      testimonials: {
        heading: "Field testimonials",
        intro: "Institutional partners and facility management teams share how the analyses support their daily operations.",
        quote1: {
          text: "The scenario-based mapping helped align security, reception and operations teams around a shared spatial language.",
          author: "Louise Delporte",
          role: "Visitor coordination manager, Maison Administrative de Namur"
        },
        quote2: {
          text: "Digital iterations were decisive to convince architects to integrate light markers within the walkway network.",
          author: "Gauthier Van Leeuwen",
          role: "Technical coordinator, Walloon Healthcare Hub"
        },
        quote3: {
          text: "The critical reading of journeys exposed invisible dead-ends, significantly improving pedestrian connections.",
          author: "Sofia Martins",
          role: "Soft mobility officer, Brussels Mobility"
        }
      },
      blogPreview: {
        heading: "Recent readings",
        intro: "Each article dives into a specific angle of indoor navigation and orientation devices.",
        card1: {
          title: "Layered cartography for intermodal nodes",
          excerpt: "Understand how vertical landmarks, altitude transitions and connections influence perception within Brussels hubs.",
          link: "Read the article"
        },
        card2: {
          title: "Cognitive signage in public hospitals",
          excerpt: "Analytics of therapeutic corridors, sensitive zones and renewed reception protocols inside healthcare facilities.",
          link: "Explore the analysis"
        },
        card3: {
          title: "Spatial UX evaluation protocols",
          excerpt: "Hybrid methods to assess the legibility and accessibility of digital signage in dense service buildings.",
          link: "Review the study"
        }
      },
      callout: {
        heading: "Need to structure a spatial orientation diagnostic?",
        body: "The platform provides observation grids, prioritisation matrices and spatial storytelling templates to guide your work.",
        action: "Get in touch"
      }
    },
    services: {
      hero: {
        title: "Cross-analyses to decode complex environments",
        subtitle: "The five study pillars translate built structure into understandable journeys, balancing operational requirements and user expectations."
      },
      cards: {
        card1: {
          title: "Orientation diagnostics",
          body: "Inventory visual and audible cues, measure information gaps and pinpoint confusion zones."
        },
        card2: {
          title: "Digital signage design",
          body: "Define dynamic content, screen architecture and messaging scenarios based on visitor profiles."
        },
        card3: {
          title: "Pedestrian mobility studies",
          body: "Trace flows, synchronise with vertical circulation and model alternative trajectories."
        },
        card4: {
          title: "Accessibility and inclusivity",
          body: "Assess contrasts, tactile supports and evacuation paths to ensure a fluid experience for all."
        },
        card5: {
          title: "Visual guidance evaluation",
          body: "Conduct user testing, analyse plan legibility and recommend information hierarchies."
        }
      },
      process: {
        heading: "Study process",
        intro: "Each pillar follows a protocol combining fieldwork, modelling and restitution to document use-case scenarios.",
        step1Title: "On-site observation",
        step1Body: "Video capture, journey timing and interviews to understand real user intent.",
        step2Title: "Analytical models",
        step2Body: "Create heatmaps, connection matrices and visibility diagrams to qualify space.",
        step3Title: "Strategic restitution",
        step3Body: "Produce illustrated dossiers, narrative sequences and prioritised recommendations."
      },
      outcomes: {
        heading: "Typical deliverables",
        intro: "Deliverables support architects, managers and designers in decision making.",
        bullet1: "Annotated plans indicating friction zones and signage priorities.",
        bullet2: "Correspondence tables aligning spatial vocabulary with user journeys.",
        bullet3: "Dashboards summarising flow fluidity and satisfaction measurements."
      }
    },
    about: {
      hero: {
        title: "A Belgian platform devoted to spatial UX",
        subtitle: "danswholesaleplants brings analysts, cartographers and signage specialists together to document large-scale public environments."
      },
      story: {
        heading: "Project origin",
        paragraph1: "Founded in Brussels, the platform emerged from a simple observation: multiplying digital supports does not guarantee coherence unless information is orchestrated according to the spatial logic.",
        paragraph2: "We collaborate with infrastructure managers, architecture studios and local authorities to bridge technical constraints with user expectations."
      },
      approach: {
        heading: "Interdisciplinary approach",
        point1: "Analyse pedestrian flows alongside structural constraints.",
        point2: "Merge qualitative and quantitative data to feed design decisions.",
        point3: "Craft spatial storytelling to communicate scenarios to project teams."
      },
      team: {
        heading: "Core team",
        member1: {
          name: "Maëlle Vasseur",
          role: "UX cartographer",
          bio: "Specialises in translating architectural constraints into understandable interactive plans."
        },
        member2: {
          name: "Jonas Pieters",
          role: "Mobility analyst",
          bio: "Works on synchronising pedestrian flows with transport services across urban hubs."
        },
        member3: {
          name: "Inès Van Dam",
          role: "Information designer",
          bio: "Coordinates the graphic narrative of signage and the coherence of digital supports."
        }
      },
      culture: {
        heading: "Working principles",
        intro: "Our principles safeguard analysis reliability and knowledge transfer.",
        bullet1: "Methodological transparency and full documentation of assumptions.",
        bullet2: "Co-construction with field teams to integrate operational reality.",
        bullet3: "Rapid prototyping to test journey legibility prior to deployment."
      }
    },
    blogPage: {
      hero: {
        title: "Technical blog",
        subtitle: "Field feedback, protocols and analytical frameworks to decipher complex environments."
      },
      intro: "Each post is grounded in research conducted within Belgian public spaces or international benchmarks.",
      cards: {
        post1: {
          excerpt: "How to superimpose circulation levels, vertical transfers and time cues in Brussels hubs.",
          link: "Read more"
        },
        post2: {
          excerpt: "Design calming and informative journeys throughout public healthcare facilities.",
          link: "Explore"
        },
        post3: {
          excerpt: "Define evaluation protocols combining quantitative metrics and user narratives.",
          link: "Study"
        },
        post4: {
          excerpt: "Optimise pedestrian circulation within dense campuses while respecting diverse uses.",
          link: "Analyse"
        },
        post5: {
          excerpt: "Align accessibility, visual contrast and adaptive digital interfaces.",
          link: "Consult"
        }
      }
    },
    posts: {
      post1: {
        title: "Layered cartography for intermodal nodes",
        intro: "Intermodal hubs gather multiple flows that intersect at different altitudes. Designing their signage requires layered reading that integrates verticality, temporality and connection corridors.",
        section1: {
          title: "Reading vertical strata",
          paragraph1: "We begin by dissecting the stack of levels. In most Brussels hubs, travellers move between underground platforms, mezzanines and aerial walkways. Each stratum carries its own spatial language, often inherited from different architectural periods. We produce detailed cartography of connections by cross-referencing technical drawings, photographic surveys and field observations to identify breaks in linguistic or graphic continuity.",
          paragraph2: "This cartography highlights shadow zones where travellers lose orientation: corridor junctions, poorly visible lifts, stairs emerging into saturated halls. We qualify these friction points by intensity and frequency to prioritise future interventions. The exercise underlines the need for a unified visual language anchored in a coherent vocabulary for levels and key links."
        },
        subsection1: {
          title: "Align horizontal and vertical cues",
          paragraph1: "Confronting horizontal and vertical plans reveals perception gaps. Users read floor continuity first; vertical orientation only becomes intelligible if transitions are explicit. We recommend materialising major axes with light or sound devices accompanying movement between levels.",
          paragraph2: "Successful alignment reduces decision stress when choosing a direction. Digital signage sequences must confirm the ongoing motion, avoid conflicting instructions and remind travellers of time-sensitive connections. A shared charter consolidates these principles to secure consistency for future updates."
        },
        subsection2: {
          title: "Orchestrating convergence points",
          paragraph1: "Intermodal nodes act as networks of distribution halls. Convergence points must absorb multiple flows without cognitive congestion. We analyse the density of information supports and their distance legibility to avoid overload.",
          paragraph2: "By mapping each support on a radar diagram, we reveal blind spots and areas needing clarity. Recommended solutions favour modular totems combining static and dynamic information while maintaining a clear hierarchy between primary directions and service messages."
        },
        section2: {
          title: "Temporalities and traffic seasons",
          paragraph1: "Layered cartography must factor in temporal variations. Fluxes are not homogeneous: works, event peaks and weather constraints reshape behaviour. We run several traffic scenarios to test journey resilience and cue stability.",
          paragraph2: "The approach yields a seasonal matrix combining density, user profiles and service requirements. It becomes a basis for operational teams to schedule digital signage adjustments and temporary interventions. Collected data also feeds forward-looking cartography anticipating future hub developments."
        },
        subsection3: {
          title: "Operational synthesis",
          paragraph1: "The final deliverable mixes an illustrated atlas, interactive models and prioritised recommendations. It supports decision makers in selecting relevant interventions on short, medium and long-term horizons.",
          paragraph2: "Each action links to measurable indicators: average journey time, direction error rate, resilience during disruptions. Layered cartography thus becomes a living management tool guiding architectural transformations without losing sight of traveller experience."
        }
      },
      post2: {
        title: "Cognitive signage in public hospitals",
        intro: "Public hospitals gather technical, administrative and care services, each with specific orientation constraints. Cognitive signage relies on familiar cues that remain understandable during emotionally intense moments.",
        section1: {
          title: "Identifying priority journeys",
          paragraph1: "We map critical pathways first: emergency admissions, scheduled consultations, visits and internal logistics. Each journey requires distinct information. Hospital teams provide valuable feedback on recurring questions and confusion zones.",
          paragraph2: "Field observations show that anxiety reshapes reading capacity. We evaluate the cognitive load of every message and ensure essential information is never buried under details. Colour codes are tested with users to guarantee immediate interpretation."
        },
        subsection1: {
          title: "Soothing visual language",
          paragraph1: "Overly technical visual language may amplify stress. We favour clear pictograms, readable typefaces and soft contrasts to support cue memorisation. Critical corridors receive repetitive elements that confirm direction.",
          paragraph2: "Time markers remind visitors of the remaining distance to the target service. This reduces uncertainty and helps them project ahead. Digital signage mirrors the same codes to avoid any discrepancy between supports."
        },
        subsection2: {
          title: "Coordinating physical and digital supports",
          paragraph1: "Belgian hospitals are adding orientation screens. Without harmonisation, these devices might display conflicting messages. We propose a governance model defining who updates content, at which frequency and under what exception scenarios.",
          paragraph2: "Content is layered: permanent information, temporary alerts, contextual notifications. This hierarchy ensures hurried visitors capture the most useful message first."
        },
        section2: {
          title: "Including diverse audiences",
          paragraph1: "Hospitals welcome people with varied sensory capabilities. We assess contrast, presence of alternative text and tactile accessibility. Lifts receive simplified plans detailing each floor before stepping out.",
          paragraph2: "Audio-guided journeys are also recommended in specific sections. Patient associations provide feedback to verify clarity and adjust vocabulary."
        },
        subsection3: {
          title: "Monitoring and updates",
          paragraph1: "Cognitive signage efficiency depends on ongoing monitoring. Quarterly audits compare visitor feedback with journey time indicators.",
          paragraph2: "Findings feed a roadmap to secure coherence during extensions or refurbishments. Hospital teams thus keep a dynamic reference to support decision making."
        }
      },
      post3: {
        title: "Spatial UX evaluation protocols",
        intro: "Testing spatial experience requires blending quantitative measurements with qualitative narratives. The proposed protocols adapt to public space typologies to assess journey comprehension and support legibility.",
        section1: {
          title: "Preparing the test campaign",
          paragraph1: "Preparation starts with user segmentation. We select regular, occasional and first-time visitors to cover the entire mental map spectrum. Test scenarios are precisely scripted: starting point, goals, time constraints and visible information.",
          paragraph2: "We instrument the journey with lightweight sensors, observation grids and exit interviews. The aim is to capture doubt moments, prolonged stops and strategy shifts. These data points build a baseline to compare future signage iterations."
        },
        subsection1: {
          title: "Blending metrics and narratives",
          paragraph1: "Journey duration provides a macro view, yet is insufficient alone. We combine it with verbatim collected immediately after the trip to preserve fresh perceptions.",
          paragraph2: "Participants then draw a mental map of the completed route. These sketches reveal memorable landmarks and blurry areas. We analyse the depth of each visual field mentioned to detect reinforcement needs."
        },
        subsection2: {
          title: "Assessing digital signage",
          paragraph1: "Interactive screens and mobile apps are evaluated on their capacity to adapt content to context. We test filter relevance, message clarity and alignment with physical signage.",
          paragraph2: "Particular attention goes to the transition between digital support and physical movement. Tests verify that users do not abandon the device due to missing on-site cues."
        },
        section2: {
          title: "Analysing and sharing results",
          paragraph1: "Results are aggregated into a matrix crossing satisfaction, understanding and perceived effort. Each friction point receives a sheet detailing cause, impacts and correction paths.",
          paragraph2: "We run co-design restitution workshops to convert insights into concrete decisions. Protocols become continuous management tools adaptable to every site transformative phase."
        },
        subsection3: {
          title: "Capitalising for future projects",
          paragraph1: "Collected observations feed an internal library of principles and indicators. It speeds up evaluations on new sites.",
          paragraph2: "Capitalisation ensures acquired knowledge remains accessible even as teams evolve. Spatial UX becomes a learning process anticipating emerging challenges."
        }
      },
      post4: {
        title: "Pedestrian flows in urban campuses",
        intro: "Urban campuses merge teaching buildings, public spaces and logistics. Understanding pedestrian flows synchronises uses and prevents saturation during peak periods.",
        section1: {
          title: "Decoding daily trajectories",
          paragraph1: "We observe daily routes at different times. Students often choose the shortest paths even when cramped, while visitors seek the best signposted passages. Heatmaps expose underused areas and congested corridors.",
          paragraph2: "Seasonal changes also affect route choice. Weather conditions and temporary works modify distance perception. We integrate these parameters into modelling to produce a robust diagnosis."
        },
        subsection1: {
          title: "Aligning directional supports",
          paragraph1: "Campuses accumulate signage from several generations. We inventory each support and assess legibility. Conflicting messages are removed or rewritten to secure semantic coherence.",
          paragraph2: "Orientation maps are placed at decision points. They clearly indicate walking times, essential services and quiet zones, reassuring visitors and smoothing circulation."
        },
        subsection2: {
          title: "Synchronising with soft mobility",
          paragraph1: "Campuses are crossed by cycle paths and delivery routes. We analyse interactions between these flows and pedestrians to avoid usage conflicts.",
          paragraph2: "Ground markings and light devices materialise shared areas. Digital maps integrate this information to guide users toward safer crossings."
        },
        section2: {
          title: "Experimenting event scenarios",
          paragraph1: "Extraordinary events disrupt circulation. We simulate scenarios from open days to international conferences to test signage resilience.",
          paragraph2: "Recommendations include easy-to-deploy temporary kits: modular banners, targeted notifications and light beacons. They complement permanent signage without creating confusion."
        },
        subsection3: {
          title: "Towards shared governance",
          paragraph1: "Results feed a governance plan involving technical services, student associations and municipal partners.",
          paragraph2: "This governance watches over regular updates and knowledge sharing during works or redesigns."
        }
      },
      post5: {
        title: "Accessibility and digital legibility",
        intro: "Digital interfaces complement physical signage, yet their efficiency relies on delivering accessible, adaptive and readable information for every audience.",
        section1: {
          title: "Designing inclusive interfaces",
          paragraph1: "We assess interactive plans against assistive technologies. Contrast, font size and audio descriptions are checked to ensure immediate comprehension.",
          paragraph2: "Suggested routes must acknowledge specific needs: suitable lifts, rest zones, obstacle-free paths. Interfaces offer alternative journeys according to user profiles."
        },
        subsection1: {
          title: "Structuring information",
          paragraph1: "Digital plans are arranged in layers: quick access, service amenities, detailed itineraries. This structure prevents cognitive overload.",
          paragraph2: "Filtering systems allow users to display only relevant information. Travellers can save a route and retrieve it easily during their visit."
        },
        subsection2: {
          title: "Securing multi-support coherence",
          paragraph1: "Legibility depends on alignment between mobile interfaces, on-site screens and printed supports. We define a shared visual language and governance rules to maintain alignment.",
          paragraph2: "Updates follow an editorial calendar. Each change undergoes linguistic and graphic verification to remain accessible."
        },
        section2: {
          title: "Measuring efficiency",
          paragraph1: "Regular user tests examine interface understanding. We observe adoption speed, navigation errors and overall satisfaction.",
          paragraph2: "Indicators are gathered in a dashboard accessible to operational teams. It supports continuous improvement and functional roadmap planning."
        },
        subsection3: {
          title: "Sharing best practices",
          paragraph1: "Findings are compiled into a guide shared with Belgian public partners. It covers technical, graphic and organisational aspects.",
          paragraph2: "This dissemination fosters a common culture of digital accessibility, essential to maintain welcoming and legible environments."
        }
      }
    },
    contact: {
      hero: {
        title: "Coordination and dialogue",
        subtitle: "Reach out to share your spatial orientation challenges or request further information about ongoing studies."
      },
      details: {
        heading: "Direct details",
        phoneLabel: "Coordination phone",
        emailLabel: "Email address",
        addressLabel: "Location",
        phoneValue: "+32 2 123 45 67",
        emailValue: "contact@danswholesaleplants.com",
        addressValue: "Rue de la Loi 200, 1000 Brussels, Belgium",
        availability: "Availability",
        availabilityValue: "Monday to Friday, 9:00 - 17:30 CET"
      },
      form: {
        heading: "Contact form",
        intro: "Describe your organisation’s context and the navigation issues encountered.",
        nameLabel: "Full name",
        namePlaceholder: "Your name",
        emailLabel: "Email address",
        emailPlaceholder: "you@example.com",
        organizationLabel: "Organisation",
        organizationPlaceholder: "Institution or structure",
        messageLabel: "Message",
        messagePlaceholder: "Share your needs, constraints or questions",
        consentLabel: "I agree that my information will be used to organise a follow-up conversation.",
        submit: "Submit request"
      },
      map: {
        heading: "Map and access",
        description: "The analysis office is located near the European district, easily reached by public transport.",
        title: "Map of the Brussels location"
      }
    },
    faq: {
      hero: {
        title: "Frequently asked questions",
        subtitle: "Clarifications on danswholesaleplants methodology, deliverables and analytical pillars."
      },
      items: {
        q1: {
          question: "How do you initiate an orientation diagnostic?",
          answer: "We start with meetings involving on-site teams, followed by a survey of critical points and an inventory of existing supports."
        },
        q2: {
          question: "What type of data do you collect?",
          answer: "Flow observations, user interviews, photographic records and timing measurements depending on site configuration."
        },
        q3: {
          question: "Do you work on new developments?",
          answer: "Yes, the platform supports refurbishments and early-stage projects to anticipate journeys."
        },
        q4: {
          question: "Do you produce interactive plans?",
          answer: "We create functional prototypes to test information hierarchy and alignment with physical signage."
        },
        q5: {
          question: "How do you integrate universal accessibility?",
          answer: "Each deliverable includes recommendations for reduced mobility users, neurodivergent audiences and international visitors."
        },
        q6: {
          question: "Do you have institutional partnerships?",
          answer: "The platform regularly collaborates with transport operators, hospitals and Belgian administrations."
        },
        q7: {
          question: "How are signage updates managed?",
          answer: "We provide governance protocols defining frequency, responsibilities and validation criteria."
        },
        q8: {
          question: "Do analyses include user testing?",
          answer: "Yes, qualitative and quantitative tests are conducted when context requires validation of journey legibility."
        }
      }
    },
    terms: {
      intro: "These terms govern site usage under Belgian law. Access implies full acceptance of the following sections.",
      section1: {
        title: "1. Purpose",
        body: "The site shares informative content about spatial orientation. No commercial act or contractual commitment is offered."
      },
      section2: {
        title: "2. Access",
        body: "Access is open and free. Users ensure they have the technical means to consult the content."
      },
      section3: {
        title: "3. Intellectual property",
        body: "Texts, visuals and diagrams are protected. Any reproduction requires written consent from danswholesaleplants."
      },
      section4: {
        title: "4. Third-party content",
        body: "References to external projects are for information only. Rights remain with their respective owners."
      },
      section5: {
        title: "5. Information accuracy",
        body: "Information is regularly reviewed. It may nonetheless change without notice to reflect research updates."
      },
      section6: {
        title: "6. Liability",
        body: "Danswholesaleplants declines responsibility for misinterpretation or improper use of the published content."
      },
      section7: {
        title: "7. Site availability",
        body: "We strive to keep the site available. Temporary interruptions may occur for maintenance."
      },
      section8: {
        title: "8. Hyperlinks",
        body: "Outbound links enrich reading. Danswholesaleplants does not control third-party site content."
      },
      section9: {
        title: "9. Personal data",
        body: "Any collection is handled according to the privacy policy available on the site."
      },
      section10: {
        title: "10. Cookies",
        body: "Cookies improve navigation. Details are described in the cookie policy."
      },
      section11: {
        title: "11. Messaging",
        body: "Messages sent via the form are processed solely to answer inquiries. No automated file is created without consent."
      },
      section12: {
        title: "12. Amendments",
        body: "These terms may be updated. The revision date is displayed at the top of the document."
      },
      section13: {
        title: "13. Governing law",
        body: "Belgian law applies. Disputes fall under the jurisdiction of Brussels courts."
      },
      section14: {
        title: "14. Contact",
        body: "For questions, use the contact form or write to contact@danswholesaleplants.com."
      }
    },
    privacy: {
      intro: "This policy explains how danswholesaleplants handles personal data collected via the site.",
      section1: {
        title: "1. Data controller",
        body: "The controller is danswholesaleplants, Rue de la Loi 200, 1000 Brussels."
      },
      section2: {
        title: "2. Collected data",
        body: "Data submitted through the contact form include name, email address, organisation and message."
      },
      section3: {
        title: "3. Purpose",
        body: "Data are used solely to answer inquiries and coordinate follow-up conversations."
      },
      section4: {
        title: "4. Legal basis",
        body: "Collection relies on the consent expressed when submitting the form."
      },
      section5: {
        title: "5. Retention",
        body: "Data are stored for the time needed to process the request, not exceeding twelve months without interaction."
      },
      section6: {
        title: "6. Sharing",
        body: "Information is not shared with third parties unless legally required."
      },
      section7: {
        title: "7. Security",
        body: "Technical and organisational measures protect data against unauthorised access."
      },
      section8: {
        title: "8. User rights",
        body: "You may access, rectify, erase, restrict or object to the processing of your data."
      },
      section9: {
        title: "9. Exercising rights",
        body: "Send requests to contact@danswholesaleplants.com specifying your demand."
      },
      section10: {
        title: "10. Updates",
        body: "This policy may evolve. The current version remains available on this page."
      }
    },
    cookiesPage: {
      hero: {
        title: "Cookie policy",
        subtitle: "Information about cookie usage and preference management."
      },
      intro: "The site uses cookies to ensure its operation and improve understanding of usage. Some cookies are essential, others optional.",
      tableTitle: "Cookie inventory",
      table: {
        header: {
          name: "Name",
          provider: "Provider",
          type: "Type",
          purpose: "Purpose",
          duration: "Duration"
        },
        row1: {
          name: "site_lang",
          provider: "danswholesaleplants",
          type: "Preference",
          purpose: "Store the language selected by the user.",
          duration: "12 months"
        },
        row2: {
          name: "cookie_consent",
          provider: "danswholesaleplants",
          type: "Consent",
          purpose: "Record the choices expressed regarding cookies.",
          duration: "12 months"
        },
        row3: {
          name: "session_metrics",
          provider: "danswholesaleplants",
          type: "Analytics",
          purpose: "Measure aggregated page visits to improve content.",
          duration: "Session"
        }
      },
      managing: {
        heading: "Managing preferences",
        body: "You can adjust your cookie preferences at any time via the banner available on each page."
      },
      updates: {
        heading: "Updates",
        body: "This policy may be updated to reflect technical or regulatory changes."
      },
      contact: {
        heading: "Contact",
        body: "Send any cookie-related question to contact@danswholesaleplants.com."
      }
    },
    refund: {
      hero: {
        title: "Withdrawal policy",
        subtitle: "Information about withdrawal terms and handling of content-related requests."
      },
      section1: {
        title: "1. Scope",
        body: "The policy covers content provided through the site and related exchanges."
      },
      section2: {
        title: "2. Requests",
        body: "Submit any request via email to contact@danswholesaleplants.com."
      },
      section3: {
        title: "3. Processing time",
        body: "Requests are reviewed within thirty days at most."
      },
      section4: {
        title: "4. Conditions",
        body: "Withdrawal applies when content does not match information agreed during prior exchanges."
      },
      section5: {
        title: "5. Options",
        body: "Danswholesaleplants provides corrections or removes the concerned content."
      },
      section6: {
        title: "6. Exclusions",
        body: "Content published on third-party platforms is not covered by this policy."
      },
      section7: {
        title: "7. Additional discussions",
        body: "Further exchanges may be required to understand the context and craft an adequate solution."
      },
      section8: {
        title: "8. Documentation",
        body: "Correspondence is archived to keep a record of the request handling."
      },
      section9: {
        title: "9. Shared responsibility",
        body: "The requester commits to providing all information needed to facilitate analysis."
      },
      section10: {
        title: "10. Updates",
        body: "The policy may evolve. The latest version remains accessible on this page."
      }
    },
    disclaimer: {
      hero: {
        title: "Disclaimer",
        subtitle: "Limitations regarding the use of information published on danswholesaleplants."
      },
      section1: {
        title: "1. Nature of information",
        body: "Content is provided for information purposes. It does not constitute personalised professional advice."
      },
      section2: {
        title: "2. No guarantee",
        body: "Danswholesaleplants does not guarantee completeness or permanent accuracy of the information."
      },
      section3: {
        title: "3. Use of content",
        body: "Users must adapt information to their own context. Danswholesaleplants is not responsible for decisions made on this basis."
      },
      section4: {
        title: "4. External links",
        body: "Links to third-party sites are provided without continuous control. Their content may change without notice."
      },
      section5: {
        title: "5. Changes",
        body: "This notice may be adjusted to include new situations or legal obligations."
      },
      section6: {
        title: "6. Contact",
        body: "Send your questions to contact@danswholesaleplants.com."
      }
    },
    thankYou: {
      title: "Message received",
      message: "Thank you for reaching out. The team will review your request and get back to you shortly.",
      linkLabel: "Return to homepage"
    },
    notFound: {
      title: "Page not found",
      message: "The page you are looking for no longer exists or has moved. Head back to the homepage to continue exploring.",
      linkLabel: "Back to homepage"
    },
    cookieBanner: {
      heading: "Cookie management",
      description: "We use cookies to optimise your navigation. You can accept, refuse or customise your preferences.",
      manage: "Manage preferences",
      acceptAll: "Accept all",
      declineAll: "Decline all",
      save: "Save",
      close: "Close",
      categories: {
        necessary: {
          title: "Necessary cookies",
          description: "Essential for the site to function. Always active."
        },
        preferences: {
          title: "Preference cookies",
          description: "Remember your display and language choices."
        },
        analytics: {
          title: "Analytics cookies",
          description: "Measure aggregated page visits to improve content."
        },
        marketing: {
          title: "Marketing cookies",
          description: "Not currently used. Remains inactive by default."
        }
      }
    },
    toast: {
      contactSubmitting: "Your message is being sent…",
      contactSubmitted: "Thank you, your message has been delivered."
    }
  }
};

let currentLang = DEFAULT_LANG;

document.addEventListener("DOMContentLoaded", () => {
  initializeLanguage();
  setupLanguageToggle();
  setupNavToggle();
  setupRevealAnimations();
  setupCookieBanner();
  setupForms();
  updateCurrentYear();
  applyPageToast();
});

function initializeLanguage() {
  const stored = localStorage.getItem(LANG_STORAGE_KEY);
  const lang = stored && I18N[stored] ? stored : DEFAULT_LANG;
  currentLang = lang;
  applyTranslations(lang);
  updateLangToggleState(lang);
}

function setupLanguageToggle() {
  document.querySelectorAll(".lang-toggle button").forEach((button) => {
    button.addEventListener("click", () => {
      const lang = button.getAttribute("data-lang");
      if (lang && I18N[lang]) {
        currentLang = lang;
        localStorage.setItem(LANG_STORAGE_KEY, lang);
        applyTranslations(lang);
        updateLangToggleState(lang);
      }
    });
  });
}

function updateLangToggleState(lang) {
  document.querySelectorAll(".lang-toggle button").forEach((btn) => {
    const isActive = btn.getAttribute("data-lang") === lang;
    btn.classList.toggle("active", isActive);
    btn.setAttribute("aria-pressed", isActive ? "true" : "false");
  });
}

function applyTranslations(lang) {
  const dict = I18N[lang] || I18N[DEFAULT_LANG];

  document.documentElement.lang = lang;

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.innerHTML = value;
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("placeholder", value);
    }
  });

  document.querySelectorAll("[data-i18n-aria]").forEach((el) => {
    const key = el.getAttribute("data-i18n-aria");
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("aria-label", value);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.getAttribute("data-i18n-alt");
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("alt", value);
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.getAttribute("data-i18n-title");
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      if (el.tagName.toLowerCase() === "title") {
        el.textContent = value;
      } else {
        el.setAttribute("title", value);
      }
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.getAttribute("data-i18n-meta");
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("content", value);
    }
  });

  document.querySelectorAll("[data-i18n-value]").forEach((el) => {
    const key = el.getAttribute("data-i18n-value");
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("value", value);
    }
  });
}

function resolveTranslation(dict, key) {
  if (!key) return null;
  const parts = key.split(".");
  let result = dict;
  for (const part of parts) {
    if (result && Object.prototype.hasOwnProperty.call(result, part)) {
      result = result[part];
    } else {
      result = null;
      break;
    }
  }
  if (typeof result === "string") {
    return result;
  }
  return result === null ? null : String(result);
}

function setupNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const isActive = nav.classList.toggle("active");
    toggle.classList.toggle("active", isActive);
    toggle.setAttribute("aria-expanded", isActive ? "true" : "false");
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("active");
      toggle.classList.remove("active");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

function setupRevealAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("reveal-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
  );

  document.querySelectorAll(".reveal").forEach((element) => {
    observer.observe(element);
  });
}

function setupCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  const manageButton = document.getElementById("cookieManageButton");
  const preferences = document.getElementById("cookiePreferences");
  const acceptAll = document.querySelector("[data-cookie-action='accept']");
  const declineAll = document.querySelector("[data-cookie-action='decline']");
  const savePreferences = document.querySelector("[data-cookie-action='save']");
  const closeBanner = document.querySelector("[data-cookie-action='close']");
  const toggles = document.querySelectorAll("[data-cookie-toggle]");

  if (!banner) return;

  const storedConsent = localStorage.getItem(COOKIE_STORAGE_KEY);
  if (storedConsent) {
    try {
      const parsed = JSON.parse(storedConsent);
      toggles.forEach((toggle) => {
        const type = toggle.getAttribute("data-cookie-toggle");
        if (type === "necessary") {
          toggle.checked = true;
        } else if (Object.prototype.hasOwnProperty.call(parsed, type)) {
          toggle.checked = Boolean(parsed[type]);
        }
      });
    } catch {
      localStorage.removeItem(COOKIE_STORAGE_KEY);
      showCookieBanner(banner);
    }
  } else {
    showCookieBanner(banner);
  }

  manageButton?.addEventListener("click", () => {
    preferences?.classList.toggle("active");
  });

  acceptAll?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: true,
      analytics: true,
      marketing: true,
      timestamp: new Date().toISOString()
    };
    persistConsent(consent);
    toggles.forEach((toggle) => {
      if (!toggle.disabled) {
        toggle.checked = true;
      }
    });
    hideCookieBanner(banner);
  });

  declineAll?.addEventListener("click", () => {
    const consent = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      timestamp: new Date().toISOString()
    };
    persistConsent(consent);
    toggles.forEach((toggle) => {
      if (!toggle.disabled) {
        toggle.checked = false;
      }
    });
    hideCookieBanner(banner);
  });

  savePreferences?.addEventListener("click", () => {
    const consent = collectToggleState(toggles);
    persistConsent(consent);
    hideCookieBanner(banner);
  });

  closeBanner?.addEventListener("click", () => {
    hideCookieBanner(banner);
  });

  toggles.forEach((toggle) => {
    toggle.addEventListener("change", () => {
      const consent = collectToggleState(toggles);
      persistConsent(consent);
    });
  });
}

function collectToggleState(toggles) {
  const state = { necessary: true, timestamp: new Date().toISOString() };
  toggles.forEach((toggle) => {
    const type = toggle.getAttribute("data-cookie-toggle");
    if (type && type !== "necessary") {
      state[type] = toggle.checked;
    }
  });
  return state;
}

function persistConsent(consent) {
  localStorage.setItem(COOKIE_STORAGE_KEY, JSON.stringify(consent));
}

function showCookieBanner(banner) {
  banner.classList.add("active");
}

function hideCookieBanner(banner) {
  banner.classList.remove("active");
}

function setupForms() {
  const forms = document.querySelectorAll("form[data-enhanced='true']");
  forms.forEach((form) => {
    form.addEventListener("submit", () => {
      showToast(resolveTranslation(I18N[currentLang], "toast.contactSubmitting"));
    });
  });
}

function showToast(message) {
  if (!message) return;
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(40px)";
    setTimeout(() => {
      toast.remove();
    }, 350);
  }, 4000);
}

function updateCurrentYear() {
  const yearElement = document.getElementById("currentYear");
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }
}

function applyPageToast() {
  const body = document.body;
  const toastKey = body.getAttribute("data-toast");
  if (toastKey) {
    const message = resolveTranslation(I18N[currentLang], toastKey);
    if (message) {
      setTimeout(() => showToast(message), 200);
    }
  }
}