document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('is-open');
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = cookieBanner?.querySelector('[data-cookie-accept]');
  const declineBtn = cookieBanner?.querySelector('[data-cookie-decline]');
  const manageButtons = document.querySelectorAll('[data-cookie-settings]');
  const storageKey = 'sce-cookie-consent';

  const setConsent = (value) => {
    localStorage.setItem(storageKey, value);
    if (cookieBanner) {
      cookieBanner.setAttribute('data-visible', 'false');
      cookieBanner.classList.add('is-dismissed');
    }
    document.documentElement.setAttribute('data-cookie-consent', value);
  };

  const showBanner = () => {
    if (cookieBanner) {
      cookieBanner.setAttribute('data-visible', 'true');
      cookieBanner.classList.remove('is-dismissed');
    }
  };

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(storageKey);
    if (!storedConsent) {
      showBanner();
    } else {
      document.documentElement.setAttribute('data-cookie-consent', storedConsent);
    }

    acceptBtn?.addEventListener('click', () => setConsent('accepted'));
    declineBtn?.addEventListener('click', () => setConsent('declined'));

    manageButtons.forEach((btn) => {
      btn.addEventListener('click', showBanner);
    });
  }
});