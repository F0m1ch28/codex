<?php
function esc($value) {
  return htmlspecialchars(trim((string)($value ?? '')), ENT_QUOTES, 'UTF-8');
}
$nombre = esc($_POST['nombre'] ?? '');
$correo = esc($_POST['correo'] ?? '');
$empresa = esc($_POST['empresa'] ?? '');
$telefono = esc($_POST['telefono'] ?? '');
$interes = esc($_POST['interes'] ?? '');
$mensaje = esc($_POST['mensaje'] ?? '');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gracias por tu mensaje | Sol Control España</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Confirmación de envío del formulario de Sol Control España.">
  <meta property="og:title" content="Gracias por contactarnos | Sol Control España">
  <meta property="og:description" content="El equipo de Sol Control España ha recibido tu mensaje.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.solcontrol-espana.com/thanks.php">
  <meta property="og:image" content="https://picsum.photos/seed/solcontrol-gracias/1200/720">
  <link rel="canonical" href="https://www.solcontrol-espana.com/thanks.php">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%232C3E50'/%3E%3Cpath d='M15 32a17 17 0 0134 0c0 9.4-7.2 17-17 17S15 41.4 15 32z' fill='%23F39C12'/%3E%3Cpath d='M32 18v14l9 9' stroke='%23ECF0F1' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <a class="skip-link" href="#contenido">Saltar al contenido</a>
  <header class="site-header">
    <div class="header-inner">
      <div class="brand">
        <span>Sol Control España</span>
        <span>Monitorización Solar Avanzada</span>
      </div>
      <button class="nav-toggle" aria-expanded="false" aria-controls="navegacion">
        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <path stroke-linecap="round" stroke-width="1.8" d="M4 6h16M4 12h16M4 18h16"/>
        </svg>
        Menú
      </button>
      <nav class="primary-nav" id="navegacion" aria-label="Navegación principal">
        <ul>
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Nosotros</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="performance.html">Rendimiento</a></li>
          <li><a href="projects.html">Proyectos</a></li>
          <li><a class="btn btn--primary" href="contact.php">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenido">
    <section class="section">
      <div class="container">
        <div class="status-banner">
          <span class="badge-inline">Mensaje enviado</span>
          <h1>¡Gracias, <?php echo $nombre ?: 'equipo'; ?>!</h1>
          <p>Hemos recibido tu consulta. Nuestro equipo de Sol Control España revisará la información y te contactará en breve.</p>
          <div class="card" style="max-width:640px; margin:0 auto;">
            <h3>Resumen de tu solicitud</h3>
            <p><strong>Correo:</strong> <?php echo $correo ?: 'No facilitado'; ?></p>
            <p><strong>Empresa:</strong> <?php echo $empresa ?: 'No facilitado'; ?></p>
            <p><strong>Teléfono:</strong> <?php echo $telefono ?: 'No facilitado'; ?></p>
            <p><strong>Interés:</strong> <?php echo $interes ?: 'No indicado'; ?></p>
            <p><strong>Mensaje:</strong><br><?php echo nl2br($mensaje) ?: 'No se ha añadido un mensaje.'; ?></p>
          </div>
          <div style="display:flex; gap:var(--space-3); justify-content:center; flex-wrap:wrap;">
            <a class="btn btn--primary" href="solutions.html">Explorar soluciones</a>
            <a class="btn btn--ghost" href="index.html">Volver a inicio</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="footer">
    <div class="footer__grid">
      <div>
        <div class="brand">
          <span>Sol Control España</span>
          <span>Monitorización Solar Avanzada</span>
        </div>
        <p style="margin-top:var(--space-3);max-width:420px;color:rgba(255,255,255,0.7);">Seguimos conectados para impulsar la eficiencia de tus plantas solares.</p>
      </div>
      <div class="footer__cols">
        <div class="footer__col">
          <h4>Empresa</h4>
          <ul class="footer__links">
            <li><a href="about.html">Nosotros</a></li>
            <li><a href="projects.html">Proyectos</a></li>
            <li><a href="technology.html">Tecnología</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <h4>Recursos</h4>
          <ul class="footer__links">
            <li><a href="solutions.html">Soluciones</a></li>
            <li><a href="performance.html">Rendimiento</a></li>
            <li><a href="privacy.html">Privacidad</a></li>
            <li><a href="cookies.html">Cookies</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <h4>Contacto</h4>
          <ul class="footer__links">
            <li>Torre Sevilla</li>
            <li>Calle Gonzalo Jiménez de Quesada 2, Planta 15</li>
            <li>41092 Sevilla, España</li>
            <li>Tel: <a href="tel:+34954682731">+34 954 682 731</a></li>
            <li><a href="contact.php">Contacto</a></li>
          </ul>
          <button class="footer__cookie-btn" type="button" data-cookie-settings>Gestionar cookies</button>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© <?php echo date('Y'); ?> Sol Control España.</span>
        <div style="display:flex; gap:var(--space-3); flex-wrap:wrap;">
          <a href="terms.html">Términos</a>
          <a href="privacy.html">Privacidad</a>
          <a href="cookies.html">Cookies</a>
          <a href="contact.php">Contacto</a>
        </div>
      </div>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies" data-visible="false">
    <h2>Preferencias de cookies</h2>
    <p>Gestiona tus preferencias cuando lo desees.</p>
    <div class="cookie-actions">
      <button class="btn btn--primary" type="button" data-cookie-accept>Aceptar</button>
      <button class="btn btn--ghost" type="button" data-cookie-decline>Rechazar</button>
    </div>
    <p class="form-footnote">Consulta la <a href="cookies.html">política de cookies</a>.</p>
  </div>

  <script src="main.js" defer></script>
</body>
</html>