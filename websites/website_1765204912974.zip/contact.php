<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto | Sol Control España</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Contacta con Sol Control España para coordinar proyectos de monitorización fotovoltaica y control inteligente solar.">
  <meta property="og:title" content="Contacto | Sol Control España">
  <meta property="og:description" content="Formulario interactivo para conectar con el equipo de Sol Control España en Sevilla.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.solcontrol-espana.com/contact.php">
  <meta property="og:image" content="https://picsum.photos/seed/solcontrol-contacto/1200/720">
  <link rel="canonical" href="https://www.solcontrol-espana.com/contact.php">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%232C3E50'/%3E%3Cpath d='M15 32a17 17 0 0134 0c0 9.4-7.2 17-17 17S15 41.4 15 32z' fill='%23F39C12'/%3E%3Cpath d='M32 18v14l9 9' stroke='%23ECF0F1' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <a class="skip-link" href="#contenido">Saltar al contenido</a>
  <header class="site-header">
    <div class="header-inner">
      <div class="brand">
        <span>Sol Control España</span>
        <span>Monitorización Solar Avanzada</span>
      </div>
      <button class="nav-toggle" aria-expanded="false" aria-controls="navegacion">
        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <path stroke-linecap="round" stroke-width="1.8" d="M4 6h16M4 12h16M4 18h16"/>
        </svg>
        Menú
      </button>
      <nav class="primary-nav" id="navegacion" aria-label="Navegación principal">
        <ul>
          <li><a href="index.html">Inicio</a></li>
          <li><a href="about.html">Nosotros</a></li>
          <li><a href="solutions.html">Soluciones</a></li>
          <li><a href="technology.html">Tecnología</a></li>
          <li><a href="performance.html">Rendimiento</a></li>
          <li><a href="projects.html">Proyectos</a></li>
          <li><a class="btn btn--primary" href="contact.php" aria-current="page">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main id="contenido">
    <section class="section">
      <div class="container">
        <span class="badge">Hablemos</span>
        <h1 class="section-title">Conecta con Sol Control España</h1>
        <p class="section-subtitle">Comparte los retos de tu planta solar y descubre cómo nuestras soluciones de control inteligente pueden reforzar tus operaciones.</p>
        <div class="contact-wrapper" style="margin-top:var(--space-6);">
          <div class="contact-panel">
            <form action="thanks.php" method="post" novalidate>
              <div class="form-grid">
                <div class="form-field">
                  <label for="nombre">Nombre y apellidos</label>
                  <input type="text" id="nombre" name="nombre" required aria-required="true" placeholder="Ej. Elena Martín">
                </div>
                <div class="form-field">
                  <label for="correo">Correo electrónico</label>
                  <input type="email" id="correo" name="correo" required aria-required="true" placeholder="nombre@empresa.com">
                </div>
                <div class="form-field">
                  <label for="empresa">Empresa</label>
                  <input type="text" id="empresa" name="empresa" placeholder="Nombre de la empresa">
                </div>
                <div class="form-field">
                  <label for="telefono">Teléfono</label>
                  <input type="tel" id="telefono" name="telefono" placeholder="+34 600 000 000">
                </div>
                <div class="form-field">
                  <label for="interes">Área de interés</label>
                  <select id="interes" name="interes">
                    <option value="monitorizacion">Monitorización fotovoltaica</option>
                    <option value="control-inteligente">Control inteligente solar</option>
                    <option value="mantenimiento-predictivo">Mantenimiento predictivo</option>
                    <option value="analitica">Analítica y dashboards</option>
                    <option value="otros">Otros</option>
                  </select>
                </div>
                <div class="form-field">
                  <label for="mensaje">Mensaje</label>
                  <textarea id="mensaje" name="mensaje" placeholder="Cuéntanos sobre tu proyecto o necesidades operativas."></textarea>
                </div>
                <div class="form-field">
                  <label>
                    <input type="checkbox" name="acepto" required aria-required="true"> Acepto la <a href="privacy.html">política de privacidad</a>.
                  </label>
                </div>
              </div>
              <button class="btn btn--primary" type="submit">Enviar consulta</button>
              <p class="form-footnote">Responderemos desde nuestro centro de control en Torre Sevilla en un plazo medio de 24 horas laborales.</p>
            </form>
          </div>
          <aside>
            <div class="card" style="background:white;">
              <h3>Visítanos</h3>
              <p>Torre Sevilla, Calle Gonzalo Jiménez de Quesada 2, Planta 15, 41092 Sevilla, España.</p>
              <p>Teléfono directo: <a href="tel:+34954682731">+34 954 682 731</a></p>
              <p>Correo: <a href="mailto:contacto@solcontrol-espana.com">contacto@solcontrol-espana.com</a></p>
            </div>
            <div style="margin-top:var(--space-4);">
              <iframe class="map-frame" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10068.844998365659!2d-6.010449942113028!3d37.39960741342586!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd126f9043c5ef49%3A0xe2b9832244c76dea!2sTorre%20Sevilla!5e0!3m2!1ses!2ses!4v1700000000000"></iframe>
            </div>
            <img src="https://picsum.photos/seed/solcontrol-contact/900/600" alt="Recepción de Sol Control España en Torre Sevilla" loading="lazy" style="margin-top:var(--space-4);">
          </aside>
        </div>
      </div>
    </section>
  </main>

  <footer class="footer">
    <div class="footer__grid">
      <div>
        <div class="brand">
          <span>Sol Control España</span>
          <span>Monitorización Solar Avanzada</span>
        </div>
        <p style="margin-top:var(--space-3);max-width:420px;color:rgba(255,255,255,0.7);">Estamos a tu disposición para impulsar la eficiencia de tus plantas solares.</p>
      </div>
      <div class="footer__cols">
        <div class="footer__col">
          <h4>Empresa</h4>
          <ul class="footer__links">
            <li><a href="about.html">Nosotros</a></li>
            <li><a href="projects.html">Proyectos</a></li>
            <li><a href="technology.html">Tecnología</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <h4>Recursos</h4>
          <ul class="footer__links">
            <li><a href="solutions.html">Soluciones</a></li>
            <li><a href="performance.html">Rendimiento</a></li>
            <li><a href="privacy.html">Privacidad</a></li>
            <li><a href="cookies.html">Cookies</a></li>
          </ul>
        </div>
        <div class="footer__col">
          <h4>Contacto</h4>
          <ul class="footer__links">
            <li>Torre Sevilla</li>
            <li>Calle Gonzalo Jiménez de Quesada 2, Planta 15</li>
            <li>41092 Sevilla, España</li>
            <li>Tel: <a href="tel:+34954682731">+34 954 682 731</a></li>
            <li><a href="contact.php">Agenda una visita</a></li>
          </ul>
          <button class="footer__cookie-btn" type="button" data-cookie-settings>Gestionar cookies</button>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© <?php echo date('Y'); ?> Sol Control España.</span>
        <div style="display:flex; gap:var(--space-3); flex-wrap:wrap;">
          <a href="terms.html">Términos</a>
          <a href="privacy.html">Privacidad</a>
          <a href="cookies.html">Cookies</a>
          <a href="contact.php">Contacto</a>
        </div>
      </div>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite" aria-label="Aviso de cookies" data-visible="false">
    <h2>Gestión de cookies</h2>
    <p>Configura tus preferencias de cookies para continuar navegando con tranquilidad.</p>
    <div class="cookie-actions">
      <button class="btn btn--primary" type="button" data-cookie-accept>Aceptar</button>
      <button class="btn btn--ghost" type="button" data-cookie-decline>Rechazar</button>
    </div>
    <p class="form-footnote">Consulta la <a href="cookies.html">política de cookies</a>.</p>
  </div>

  <script src="main.js" defer></script>
</body>
</html>