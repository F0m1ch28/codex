document.addEventListener("DOMContentLoaded", function () {
    var yearElements = document.querySelectorAll("[data-current-year]");
    var currentYear = new Date().getFullYear();
    yearElements.forEach(function (element) {
        element.textContent = currentYear;
    });

    var navToggle = document.querySelector(".mobile-nav-toggle");
    var navList = document.querySelector(".nav-list");

    if (navToggle && navList) {
        navToggle.addEventListener("click", function () {
            var isOpen = navList.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });

        navList.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (navList.classList.contains("is-open")) {
                    navList.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    var cookieBanner = document.getElementById("cookie-banner");
    if (cookieBanner) {
        var storedConsent = localStorage.getItem("frillehcxpCookieConsent");
        if (storedConsent) {
            cookieBanner.classList.add("is-hidden");
        }

        var cookieButtons = cookieBanner.querySelectorAll(".cookie-button");
        cookieButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                var action = button.dataset.action || "dismissed";
                localStorage.setItem("frillehcxpCookieConsent", action);
                cookieBanner.classList.add("is-hidden");
            });
        });
    }
});