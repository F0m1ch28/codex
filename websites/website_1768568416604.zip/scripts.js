document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const navItems = document.querySelectorAll('.nav-links a');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navLinks.classList.toggle('active');
        });

        navItems.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.accept-cookies');
    const declineBtn = document.querySelector('.decline-cookies');
    const consentStatus = localStorage.getItem('cassiaopweCookieConsent');

    if (cookieBanner && !consentStatus) {
        cookieBanner.classList.add('active');
    }

    const hideBanner = (status) => {
        if (!cookieBanner) return;
        cookieBanner.classList.remove('active');
        localStorage.setItem('cassiaopweCookieConsent', status);
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => hideBanner('accepted'));
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', () => hideBanner('declined'));
    }
});