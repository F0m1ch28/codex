import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Digital Master Academy home">
          <span className={styles.logoMark}>DMA</span>
          <span className={styles.logoText}>Digital Master Academy</span>
        </NavLink>

        <button
          className={`${styles.menuToggle} ${menuOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          aria-label="Apri o chiudi il menu di navigazione"
          aria-expanded={menuOpen}
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Navigazione principale">
          <NavLink to="/" end className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Home
          </NavLink>
          <NavLink to="/chi-siamo" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Chi Siamo
          </NavLink>
          <NavLink to="/corsi" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Corsi
          </NavLink>
          <NavLink to="/programma" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Programma
          </NavLink>
          <NavLink to="/docenti" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Docenti
          </NavLink>
          <NavLink to="/contatti" className={({ isActive }) => (isActive ? styles.activeLink : '')} onClick={closeMenu}>
            Contatti
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default Header;