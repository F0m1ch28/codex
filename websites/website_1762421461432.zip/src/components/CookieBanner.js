import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'dma_cookie_consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        <h4>Cookie e Tecnologie Simili</h4>
        <p>
          Utilizziamo cookie tecnici e strumenti analitici per migliorare l&apos;esperienza formativa, personalizzare i
          contenuti e analizzare il traffico. Consulta la nostra{' '}
          <a href="/cookie-policy">Cookie Policy</a> per maggiori informazioni.
        </p>
      </div>
      <button className="btn btnPrimary" onClick={acceptCookies} aria-label="Accetta i cookie">
        Accetto
      </button>
    </div>
  );
}

export default CookieBanner;