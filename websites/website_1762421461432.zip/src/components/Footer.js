import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Piè di pagina">
      <div className={styles.container}>
        <div className={styles.brand}>
          <span className={styles.logoMark}>DMA</span>
          <p className={styles.brandText}>
            Digital Master Academy accelera la crescita dei professionisti della formazione digitale con percorsi
            orientati alla pratica e all'innovazione.
          </p>
        </div>

        <div className={styles.links}>
          <h4>Esplora</h4>
          <NavLink to="/">Home</NavLink>
          <NavLink to="/chi-siamo">Chi Siamo</NavLink>
          <NavLink to="/corsi">Corsi</NavLink>
          <NavLink to="/programma">Programma</NavLink>
          <NavLink to="/docenti">Docenti</NavLink>
          <NavLink to="/contatti">Contatti</NavLink>
        </div>

        <div className={styles.links}>
          <h4>Supporto</h4>
          <NavLink to="/termini">Termini e Condizioni</NavLink>
          <NavLink to="/privacy">Informativa Privacy</NavLink>
          <NavLink to="/cookie-policy">Cookie Policy</NavLink>
        </div>

        <div className={styles.contact}>
          <h4>Contatti</h4>
          <p>Via Roma 125, 20121 Milano, Italia</p>
          <p>
            <a href="tel:+390212345678">+39 02 1234 5678</a>
          </p>
          <p>
            <a href="mailto:info@digitalmasteracademy.it">info@digitalmasteracademy.it</a>
          </p>
          <div className={styles.social}>
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
              Facebook
            </a>
            <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
              Instagram
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Digital Master Academy. Tutti i diritti riservati.</p>
      </div>
    </footer>
  );
}

export default Footer;