import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function CookiePolicy() {
  return (
    <section className="section">
      <Helmet>
        <title>Cookie Policy | Digital Master Academy</title>
        <meta name="robots" content="noindex" />
      </Helmet>
      <div className={styles.wrapper}>
        <h1>Cookie Policy</h1>
        <p>
          Questa Cookie Policy spiega come Digital Master Academy utilizza cookie e tecnologie simili nella propria
          piattaforma. Proseguendo la navigazione acconsenti all’impiego dei cookie descritti.
        </p>

        <h2>Cosa sono i cookie</h2>
        <p>
          I cookie sono piccoli file di testo salvati sul dispositivo dell’utente. Consentono di riconoscere il browser
          e memorizzare alcune informazioni utili all’esperienza di navigazione.
        </p>

        <h2>Tipologie utilizzate</h2>
        <ul>
          <li>
            <strong>Cookie tecnici:</strong> necessari per fornire i servizi di autenticazione e mantenere la sessione
            attiva.
          </li>
          <li>
            <strong>Cookie analitici:</strong> strumenti di misurazione aggregata per migliorare contenuti e usabilità.
          </li>
        </ul>

        <h2>Gestione dei cookie</h2>
        <p>
          Puoi modificare le impostazioni del browser per bloccare o eliminare i cookie. La disattivazione di alcuni
          cookie potrebbe influire sul funzionamento della piattaforma.
        </p>

        <h2>Contatti</h2>
        <p>
          Per ulteriori informazioni scrivi a{' '}
          <a href="mailto:privacy@digitalmasteracademy.it">privacy@digitalmasteracademy.it</a>.
        </p>
      </div>
    </section>
  );
}

export default CookiePolicy;