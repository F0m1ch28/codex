import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Courses.module.css';

const courses = [
  {
    title: 'Percorso Pubblicità Targetizzata',
    description:
      'Dalla definizione delle buyer personas alla costruzione di funnel multicanale con Facebook Ads, Instagram marketing e Google Ads. Include workshop su creatività orientata alla conversione e automazioni con strumenti italiani ed europei.',
    modules: [
      'Audience research, customer journey e segmentazione',
      'Setup avanzato Facebook Ads Manager e Business Manager',
      'Analisi dei dati con modelli di attribuzione e dashboard personalizzate',
      'Workshop su creatività dinamica e landing page orientate alla performance',
    ],
    image: 'https://picsum.photos/800/600?random=15',
  },
  {
    title: 'Percorso Coding & Sviluppo Web',
    description:
      'Impara programmazione moderna con focus su JavaScript, React e integrazione API. Laboratori pratici per creare interfacce responsive, dashboard dinamiche e microservizi.',
    modules: [
      'Fondamenti di HTML5, CSS3 e accessibilità',
      'JavaScript moderno, fetch API e gestione dello stato',
      'React, componenti funzionali e hooks',
      'Deployment su piattaforme cloud e versioning con Git',
    ],
    image: 'https://picsum.photos/800/600?random=16',
  },
  {
    title: 'Percorso Social Media Marketing',
    description:
      'Strategia e operatività per Instagram, LinkedIn, TikTok e YouTube. Calendarizzazione dei contenuti, gestione della community e misurazione dei KPI per brand italiani.',
    modules: [
      'Analisi del posizionamento e definizione dei contenuti pilastro',
      'Workflow operativo per piani editoriali e gestione community',
      'Social media analytics e reportistica con dashboard personalizzate',
      'Collaborazioni con creator e gestione campagne a pagamento integrate',
    ],
    image: 'https://picsum.photos/800/600?random=17',
  },
];

function Courses() {
  return (
    <section className="section">
      <Helmet>
        <title>Corsi | Digital Master Academy</title>
        <meta
          name="description"
          content="Scopri i corsi Digital Master Academy: pubblicità targetizzata, coding e social media marketing con approccio pratico."
        />
      </Helmet>
      <div className={styles.wrapper}>
        <div className={styles.header}>
          <p className="eyebrow">Corsi</p>
          <h1>Percorsi verticali per la tua crescita professionale</h1>
          <p>
            Ogni corso integra lezioni live, contenuti on demand, mentorship dedicata e project work per costruire un
            portfolio competitivo. Seleziona il percorso più adatto alle tue ambizioni.
          </p>
        </div>

        <div className={styles.grid}>
          {courses.map((course) => (
            <article key={course.title} className={styles.card}>
              <img src={course.image} alt={course.title} loading="lazy" />
              <div className={styles.cardContent}>
                <h2>{course.title}</h2>
                <p>{course.description}</p>
                <h3>Cosa imparerai</h3>
                <ul>
                  {course.modules.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
                <a href="/contatti" className="btn btnSecondary">
                  Richiedi orientamento
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Courses;