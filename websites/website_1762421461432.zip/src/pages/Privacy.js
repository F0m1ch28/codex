import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function Privacy() {
  return (
    <section className="section">
      <Helmet>
        <title>Informativa Privacy | Digital Master Academy</title>
        <meta name="robots" content="noindex" />
      </Helmet>
      <div className={styles.wrapper}>
        <h1>Informativa Privacy</h1>
        <p>
          Digital Master Academy tutela la riservatezza dei dati personali in conformità al Regolamento UE 2016/679
          (GDPR). Questa informativa descrive le modalità di raccolta, utilizzo e conservazione dei dati.
        </p>

        <h2>Dati trattati</h2>
        <p>
          Raccogliamo dati identificativi, contatti e informazioni professionali fornite durante la registrazione,
          l’iscrizione ai percorsi o la richiesta di orientamento. I dati vengono impiegati esclusivamente per gestire
          i rapporti con gli studenti e inviare comunicazioni legate alla formazione digitale.
        </p>

        <h2>Basi giuridiche</h2>
        <p>
          Il trattamento si basa sul consenso dell’interessato e sull’interesse legittimo dell’Academy a fornire i
          propri servizi formativi.
        </p>

        <h2>Conservazione</h2>
        <p>
          I dati vengono conservati su infrastrutture europee protette e mantenuti per il tempo necessario alla gestione
          della relazione formativa e dei progetti connessi.
        </p>

        <h2>Diritti dell’interessato</h2>
        <p>
          In qualsiasi momento è possibile richiedere accesso, rettifica, limitazione o cancellazione dei dati inviando
          una comunicazione a <a href="mailto:privacy@digitalmasteracademy.it">privacy@digitalmasteracademy.it</a>.
        </p>

        <h2>Aggiornamenti</h2>
        <p>
          Digital Master Academy potrà aggiornare la presente informativa per adeguarla a nuove normative o servizi. Le
          modifiche saranno pubblicate su questa pagina.
        </p>
      </div>
    </section>
  );
}

export default Privacy;