import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <section className="section">
      <Helmet>
        <title>Chi Siamo | Digital Master Academy</title>
        <meta
          name="description"
          content="Scopri la missione di Digital Master Academy: sviluppare talenti digitali in Italia con programmi pratici e mentor certificati."
        />
      </Helmet>
      <div className={styles.wrapper}>
        <div className={styles.intro}>
          <p className="eyebrow">Chi siamo</p>
          <h1>Digital Master Academy, l&apos;acceleratore della formazione digitale italiana</h1>
          <p>
            Siamo nati a Milano con l&apos;idea di unire docenti senior, aziende innovative e studenti ambiziosi in un
            unico ecosistema. Ogni percorso viene sviluppato con partner che operano nei settori marketing, tech e
            analytics, garantendo contenuti aderenti alle esigenze del mercato.
          </p>
        </div>

        <div className={styles.valuesGrid}>
          <article>
            <h3>Visione</h3>
            <p>
              Creare percorsi formativi che traducano la teoria in impatto reale, con progetti che i nostri studenti
              inseriscono nei portfolio professionali.
            </p>
          </article>
          <article>
            <h3>Metodo</h3>
            <p>
              Ogni modulo alterna live session, laboratori guidati e mentorship individuale per garantire una curva di
              apprendimento costante e misurabile.
            </p>
          </article>
          <article>
            <h3>Community</h3>
            <p>
              Crediamo nella forza della community italiana. Offriamo eventi mensili, hackathon e networking dedicato ai
              nostri studenti e alumni.
            </p>
          </article>
        </div>

        <div className={styles.imagePanel}>
          <img
            src="https://picsum.photos/1200/800?random=14"
            alt="Team Digital Master Academy in sessione strategica"
            loading="lazy"
          />
          <div className={styles.panelContent}>
            <h2>Connessione diretta con il mercato</h2>
            <p>
              Collaboriamo con agenzie, startup e corporate per portare in aula casi studio reali su advertising,
              sviluppo web e social media marketing. Ogni percorso è pensato per competenze spendibili con immediatezza.
            </p>
          </div>
        </div>

        <div className={styles.timeline}>
          <h2>Il nostro percorso</h2>
          <ul>
            <li>
              <span className={styles.year}>2019</span>
              <div>
                <h4>Nascita dell&apos;Academy</h4>
                <p>Avvio dei primi percorsi pilota su performance marketing e coding front-end a Milano.</p>
              </div>
            </li>
            <li>
              <span className={styles.year}>2020</span>
              <div>
                <h4>Piattaforma digitale</h4>
                <p>Lancio della piattaforma proprietaria per lezioni on demand e community interattiva.</p>
              </div>
            </li>
            <li>
              <span className={styles.year}>2022</span>
              <div>
                <h4>Espansione nazionale</h4>
                <p>Nuove partnership con aziende di Roma, Torino e Bologna per project work dedicati.</p>
              </div>
            </li>
            <li>
              <span className={styles.year}>2023</span>
              <div>
                <h4>Mentor Program</h4>
                <p>Introduzione di mentorship one-to-one e career coaching personalizzato.</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}

export default About;