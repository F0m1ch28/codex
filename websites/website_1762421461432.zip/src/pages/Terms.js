import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function Terms() {
  return (
    <section className="section">
      <Helmet>
        <title>Termini e Condizioni | Digital Master Academy</title>
        <meta name="robots" content="noindex" />
      </Helmet>
      <div className={styles.wrapper}>
        <h1>Termini e Condizioni</h1>
        <p>
          Benvenuto su Digital Master Academy. L’accesso e l’utilizzo della piattaforma implicano l’accettazione delle
          condizioni descritte in questo documento.
        </p>

        <h2>Utilizzo della piattaforma</h2>
        <p>
          I contenuti presenti nella piattaforma sono destinati a uso personale e professionale degli studenti iscritti.
          Non è consentita la redistribuzione non autorizzata del materiale formativo, incluse registrazioni video,
          slide, esercizi o qualunque risorsa condivisa dai docenti.
        </p>

        <h2>Account e sicurezza</h2>
        <p>
          Ogni utente è responsabile della riservatezza delle proprie credenziali. In caso di sospetta attività anomala
          è necessario contattare subito Digital Master Academy per attivare le misure di protezione.
        </p>

        <h2>Proprietà intellettuale</h2>
        <p>
          Marchi, loghi, testi, grafiche e contenuti multimediali sono di proprietà di Digital Master Academy o dei
          rispettivi proprietari con cui collaboriamo. È vietata ogni riproduzione senza autorizzazione scritta.
        </p>

        <h2>Modifiche</h2>
        <p>
          Ci riserviamo la facoltà di aggiornare i presenti Termini e Condizioni in qualunque momento. Eventuali
          modifiche saranno comunicate attraverso la piattaforma.
        </p>

        <h2>Contatti</h2>
        <p>
          Per domande relative ai Termini e Condizioni puoi scrivere a{' '}
          <a href="mailto:info@digitalmasteracademy.it">info@digitalmasteracademy.it</a>.
        </p>
      </div>
    </section>
  );
}

export default Terms;