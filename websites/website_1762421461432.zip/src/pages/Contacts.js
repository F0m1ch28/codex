import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contacts.module.css';

const initialState = { name: '', email: '', message: '' };

function Contacts() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Inserisci il tuo nome.';
    if (!formData.email.trim()) {
      newErrors.email = 'Inserisci la tua email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Inserisci un indirizzo email valido.';
    }
    if (!formData.message.trim()) newErrors.message = 'Scrivi un messaggio.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setFormData(initialState);
      setTimeout(() => setSubmitted(false), 5000);
    }
  };

  return (
    <section className="section">
      <Helmet>
        <title>Contatti | Digital Master Academy</title>
        <meta
          name="description"
          content="Contatta Digital Master Academy: Via Roma 125, Milano. Richiedi informazioni sui corsi di formazione digitale."
        />
      </Helmet>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <p className="eyebrow">Contatti</p>
          <h1>Parliamo del tuo percorso digitale</h1>
          <p>
            Scrivici per ricevere una sessione di orientamento, conoscere i docenti o scoprire il percorso più adatto a
            te.
          </p>
        </header>

        <div className={styles.grid}>
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            <label htmlFor="name">Nome e cognome</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Il tuo nome completo"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && (
              <span id="name-error" className={styles.error}>
                {errors.name}
              </span>
            )}

            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="nome@email.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              aria-invalid={!!errors.email}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && (
              <span id="email-error" className={styles.error}>
                {errors.email}
              </span>
            )}

            <label htmlFor="message">Messaggio</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Raccontaci le tue esigenze formative"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              aria-invalid={!!errors.message}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && (
              <span id="message-error" className={styles.error}>
                {errors.message}
              </span>
            )}

            <button type="submit" className="btn btnPrimary">
              Invia messaggio
            </button>
            {submitted && <p className={styles.success}>Messaggio inviato! Ti ricontatteremo a breve.</p>}
          </form>

          <aside className={styles.info}>
            <div>
              <h2>Informazioni di contatto</h2>
              <p>Via Roma 125, 20121 Milano, Italia</p>
              <p>
                <a href="tel:+390212345678">+39 02 1234 5678</a>
              </p>
              <p>
                <a href="mailto:info@digitalmasteracademy.it">info@digitalmasteracademy.it</a>
              </p>
            </div>
            <div>
              <h2>Orari di supporto</h2>
              <p>Lunedì - Venerdì · 9:00 - 18:00</p>
              <p>Sessioni su appuntamento anche in fascia serale.</p>
            </div>
            <div>
              <h2>Community</h2>
              <p>Accedi al forum, networking mensile e mentorship personalizzata con i nostri docenti.</p>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

export default Contacts;