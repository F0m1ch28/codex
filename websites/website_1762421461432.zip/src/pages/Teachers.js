import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Teachers.module.css';

const teachers = [
  {
    name: 'Giulia Esposito',
    role: 'Head of Performance Marketing',
    bio: 'Specialista in campagne Facebook Ads e Instagram marketing per brand fashion e retail. Ha guidato team in agenzie internazionali e segue progetti data-driven.',
    image: 'https://picsum.photos/500/500?random=18',
  },
  {
    name: 'Marco Ferri',
    role: 'Senior Front-end Engineer',
    bio: 'Oltre 10 anni di esperienza nello sviluppo web con React, Next.js e architetture component-based. Mentor per hackathon nazionali.',
    image: 'https://picsum.photos/500/500?random=19',
  },
  {
    name: 'Alessia Conti',
    role: 'Strategist Social Media',
    bio: 'Supporta aziende B2B e B2C nella gestione di piani editoriali, community management e reportistica social con focus su LinkedIn e TikTok.',
    image: 'https://picsum.photos/500/500?random=20',
  },
  {
    name: 'Luca Moretti',
    role: 'Data Analytics Lead',
    bio: 'Studia i dati per ottimizzare performance marketing, sviluppa dashboard personalizzate e modelli di attribuzione per team digital.',
    image: 'https://picsum.photos/500/500?random=21',
  },
];

function Teachers() {
  return (
    <section className="section">
      <Helmet>
        <title>Docenti | Digital Master Academy</title>
        <meta
          name="description"
          content="Conosci i docenti di Digital Master Academy: professionisti esperti di marketing digitale, sviluppo web e analytics."
        />
      </Helmet>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <p className="eyebrow">Docenti</p>
          <h1>Mentor con esperienza concreta sul campo digitale</h1>
          <p>
            I nostri docenti lavorano quotidianamente con aziende italiane e internazionali. Portano in aula casi
            pratici, strumenti aggiornati e mentorship personalizzata.
          </p>
        </header>

        <div className={styles.grid}>
          {teachers.map((teacher) => (
            <article key={teacher.name} className={styles.card}>
              <img src={teacher.image} alt={teacher.name} loading="lazy" />
              <div>
                <h2>{teacher.name}</h2>
                <h3>{teacher.role}</h3>
                <p>{teacher.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Teachers;