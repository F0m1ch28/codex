import React, { useEffect, useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsData = [
  { label: 'Professionisti formati', target: 850 },
  { label: 'Progetti digitali guidati', target: 320 },
  { label: 'Mentor certificati', target: 45 },
  { label: 'Community attiva', target: 1200 },
];

const coursesData = [
  {
    title: 'Pubblicità Targetizzata',
    description:
      'Impara ad analizzare i dati, segmentare le audience e creare campagne efficaci su Facebook Ads, Instagram e Google Ads.',
    icon: '🎯',
  },
  {
    title: 'Coding e Sviluppo Web',
    description:
      'Dalla logica di programmazione allo sviluppo front-end con React, costruisci esperienze digitali performanti.',
    icon: '💻',
  },
  {
    title: 'Social Media Marketing',
    description:
      'Progetta strategie per piattaforme social, piano editoriale e contenuti orientati alla crescita misurabile.',
    icon: '📈',
  },
];

const processSteps = [
  {
    title: 'Assessment Iniziale',
    text: 'Mappiamo competenze e obiettivi per guidare la scelta del percorso ideale.',
  },
  {
    title: 'Lezioni Live & On Demand',
    text: 'Sessioni interattive con docenti senior e materiale disponibile 24/7.',
  },
  {
    title: 'Project Work Reale',
    text: 'Applichi le competenze in progetti digitali concreti con feedback continuo.',
  },
  {
    title: 'Career Coaching',
    text: 'Supporto personalizzato per posizionarti nel mercato digitale italiano.',
  },
];

const reasons = [
  {
    title: 'Approccio data-driven',
    text: 'Ogni modulo integra strumenti di analisi per decisioni basate su insight reali.',
  },
  {
    title: 'Mentorship dedicata',
    text: 'Docenti e tutor seguono ogni studente con sessioni di mentoring mirate.',
  },
  {
    title: 'Community nazionale',
    text: 'Forum riservato con professionisti da Milano, Torino, Roma e molto altro.',
  },
  {
    title: 'Aggiornamento continuo',
    text: 'Contenuti rivisti trimestralmente per rispondere alla rapidità del settore.',
  },
];

const testimonialsData = [
  {
    quote:
      'Grazie al percorso di pubblicità targetizzata ho ridisegnato le campagne e incrementato il ROI del 35%. Mentor preparati e supporto costante.',
    name: 'Claudia Rinaldi',
    role: 'Digital Strategist | Torino',
  },
  {
    quote:
      'Il corso di coding mi ha dato basi solide e strumenti moderni. Oggi sviluppo interfacce React per un hub innovazione a Milano.',
    name: 'Federico Bernardi',
    role: 'Front-end Developer | Milano',
  },
  {
    quote:
      'Percorso pragmatico. Ho trasformato il mio piano editoriale integrando KPI e automazioni. Consigliatissimo per chi vuole fare sul serio.',
    name: 'Marta Gentili',
    role: 'Social Media Manager | Bologna',
  },
];

const projectItems = [
  { title: 'Dashboard Analytics Fashion', category: 'Analytics', image: 'https://picsum.photos/1200/800?random=4' },
  { title: 'E-commerce Growth Lab', category: 'Marketing', image: 'https://picsum.photos/1200/800?random=5' },
  { title: 'App Coding Challenge', category: 'Coding', image: 'https://picsum.photos/1200/800?random=6' },
  { title: 'Paid Media Optimization', category: 'Marketing', image: 'https://picsum.photos/1200/800?random=7' },
  { title: 'UX Research Hub', category: 'Analytics', image: 'https://picsum.photos/1200/800?random=8' },
];

const faqData = [
  {
    question: 'Quanto è pratico il percorso Academy?',
    answer:
      'Ogni modulo prevede esercitazioni guidate, project work e sessioni di revisione per consolidare le competenze in modo operativo.',
  },
  {
    question: 'Le lezioni sono disponibili on demand?',
    answer:
      'Sì, tutte le lezioni live vengono registrate e rese disponibili sulla piattaforma insieme a risorse, template e tool kit.',
  },
  {
    question: 'Serve esperienza precedente?',
    answer:
      'L’Academy propone percorsi sia per chi parte da zero sia per professionisti che desiderano specializzarsi in ambiti specifici.',
  },
  {
    question: 'Offrite supporto nella ricerca di opportunità lavorative?',
    answer:
      'Il Career Coaching include revisione del portfolio, simulazioni di colloqui e connessione con partner aziendali selezionati.',
  },
];

const blogPreview = [
  {
    title: '5 framework per pianificare campagne Facebook Ads nel 2024',
    date: '15 Febbraio 2024',
    image: 'https://picsum.photos/800/600?random=9',
  },
  {
    title: 'React Patterns: costruire interfacce scalabili per il mercato italiano',
    date: '03 Marzo 2024',
    image: 'https://picsum.photos/800/600?random=10',
  },
  {
    title: 'Analytics storytelling: tradurre i dati in azioni per i team marketing',
    date: '20 Marzo 2024',
    image: 'https://picsum.photos/800/600?random=11',
  },
];

function Home() {
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Tutti');
  const categories = useMemo(() => ['Tutti', ...new Set(projectItems.map((item) => item.category))], []);

  useEffect(() => {
    const timers = statsData.map((item, index) => {
      const increment = Math.ceil(item.target / 60);
      return setInterval(() => {
        setStats((prev) => {
          const updated = [...prev];
          if (updated[index] < item.target) {
            updated[index] = Math.min(updated[index] + increment, item.target);
          }
          return updated;
        });
      }, 40);
    });

    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    projectFilter === 'Tutti'
      ? projectItems
      : projectItems.filter((project) => project.category === projectFilter);

  return (
    <div className={styles.home}>
      <Helmet>
        <title>Home | Digital Master Academy</title>
      </Helmet>

      <section className={`${styles.hero} section`}>
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>
            Trasforma la tua carriera digitale con percorsi pratici e mentor certificati
          </h1>
          <p className={styles.heroSubtitle}>
            Digital Master Academy è la piattaforma italiana di formazione digitale che unisce pubblicità targetizzata,
            coding e social media marketing in programmi progettati per il mercato italiano.
          </p>
          <div className={styles.heroActions}>
            <a href="/corsi" className="btn btnPrimary">
              Scopri i corsi
            </a>
            <a href="/contatti" className="btn btnGhost">
              Parla con noi
            </a>
          </div>
          <div className={styles.heroBadges}>
            <span>✔️ Live & on demand</span>
            <span>✔️ Project work reali</span>
            <span>✔️ Career coaching</span>
          </div>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Studenti che collaborano davanti a computer in un laboratorio digitale"
            loading="lazy"
          />
        </div>
      </section>

      <section className="section">
        <div className={styles.introGrid}>
          <div>
            <p className="eyebrow">Chi siamo</p>
            <h2>Digital Master Academy, hub italiano per la formazione digitale avanzata</h2>
            <p>
              Colleghiamo professionisti, marketer e developer a programmi contemporanei, costruiti con aziende partner e
              docenti che operano quotidianamente su progetti digitali di livello nazionale. Il nostro obiettivo è
              accelerare le carriere con metodi pratici, strumenti aggiornati e community attiva.
            </p>
          </div>
          <div className={styles.introCard}>
            <h3>Focus principali</h3>
            <ul>
              <li>Facebook Ads, Instagram marketing e funnel di acquisizione</li>
              <li>Imparare programmazione JavaScript, React e basi back-end</li>
              <li>Gestione professionale dei social media con KPI misurabili</li>
              <li>Analytics e data storytelling per decisioni consapevoli</li>
            </ul>
          </div>
        </div>
      </section>

      <section className={`section ${styles.coursesSection}`} id="corsi">
        <div className={styles.sectionHeader}>
          <p className="eyebrow">I nostri corsi</p>
          <h2>Percorsi formativi progettati per il mercato digitale italiano</h2>
          <p>
            Dalla pubblicità targetizzata allo sviluppo web, ogni percorso combina teoria, pratica e strumenti concreti
            per ottenere risultati professionali.
          </p>
        </div>
        <div className={styles.coursesGrid}>
          {coursesData.map((course) => (
            <article key={course.title} className={styles.courseCard}>
              <span className={styles.courseIcon} aria-hidden="true">
                {course.icon}
              </span>
              <h3>{course.title}</h3>
              <p>{course.description}</p>
              <a href="/corsi" className={styles.courseLink}>
                Approfondisci →
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className={`section ${styles.statsSection}`}>
        <div className={styles.statsGrid}>
          {statsData.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue}>{stats[index]}+</span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={`section ${styles.processSection}`} id="metodo">
        <div className={styles.sectionHeader}>
          <p className="eyebrow">Come funziona</p>
          <h2>Un metodo orientato all&apos;azione e alla misurabilità</h2>
          <p>
            Strutturiamo il percorso per accompagnarti dall’assessment iniziale alla realizzazione di progetti digitali
            misurabili e spendibili sul mercato del lavoro.
          </p>
        </div>
        <div className={styles.processTimeline}>
          {processSteps.map((step, index) => (
            <div key={step.title} className={styles.processStep}>
              <span className={styles.stepNumber} aria-hidden="true">
                {index + 1}
              </span>
              <div>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={`section ${styles.reasonsSection}`}>
        <div className={styles.sectionHeader}>
          <p className="eyebrow">Perché sceglierci</p>
          <h2>Un ecosistema completo per la formazione digitale in Italia</h2>
        </div>
        <div className={styles.reasonsGrid}>
          {reasons.map((reason) => (
            <div key={reason.title} className={styles.reasonCard}>
              <h3>{reason.title}</h3>
              <p>{reason.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={`section ${styles.projectsSection}`}>
        <div className={styles.projectsHeader}>
          <div>
            <p className="eyebrow">Progetti</p>
            <h2>Portfolio dei project work realizzati con i nostri mentor</h2>
          </div>
          <div className={styles.filterGroup} role="group" aria-label="Filtro progetti">
            {categories.map((category) => (
              <button
                key={category}
                className={`${styles.filterButton} ${projectFilter === category ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        <div className={styles.projectsGrid}>
          {filteredProjects.map((project) => (
            <article key={project.title} className={styles.projectCard}>
              <img src={project.image} alt={`Progetto ${project.title}`} loading="lazy" />
              <div className={styles.projectContent}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`section ${styles.testimonialsSection}`} id="testimonianze">
        <div className={styles.sectionHeader}>
          <p className="eyebrow">Testimonianze</p>
          <h2>Cosa dicono i professionisti che hanno scelto l’Academy</h2>
        </div>
        <div className={styles.testimonialWrapper}>
          {testimonialsData.map((testimonial, index) => (
            <blockquote
              key={testimonial.name}
              className={`${styles.testimonial} ${index === testimonialIndex ? styles.testimonialActive : ''}`}
              aria-hidden={index !== testimonialIndex}
            >
              <p>“{testimonial.quote}”</p>
              <footer>
                <strong>{testimonial.name}</strong>
                <span>{testimonial.role}</span>
              </footer>
            </blockquote>
          ))}
          <div className={styles.carouselControls}>
            <button
              onClick={() =>
                setTestimonialIndex((prev) => (prev - 1 + testimonialsData.length) % testimonialsData.length)
              }
              aria-label="Testimonianza precedente"
            >
              ←
            </button>
            <button
              onClick={() => setTestimonialIndex((prev) => (prev + 1) % testimonialsData.length)}
              aria-label="Testimonianza successiva"
            >
              →
            </button>
          </div>
        </div>
      </section>

      <section className={`section ${styles.teamSection}`}>
        <div className={styles.sectionHeader}>
          <p className="eyebrow">Team</p>
          <h2>Docenti e mentor con esperienza sul campo</h2>
          <p>
            I nostri professionisti lavorano ogni giorno con aziende italiane e internazionali su progetti di advertising
            e sviluppo digitale.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {['https://picsum.photos/400/400?random=3', 'https://picsum.photos/400/400?random=12', 'https://picsum.photos/400/400?random=13'].map(
            (image, idx) => (
              <div key={image} className={styles.teamCard}>
                <img src={image} alt={`Mentor Digital Master Academy ${idx + 1}`} loading="lazy" />
                <h3>{['Giulia Esposito', 'Marco Ferri', 'Alessia Conti'][idx]}</h3>
                <p>
                  {
                    [
                      'Head of Performance Marketing con focus su Facebook Ads per brand retail.',
                      'Senior Front-end Engineer specializzato in React e architetture component-based.',
                      'Strategist Social Media con esperienza in campagne omnicanale e analytics.',
                    ][idx]
                  }
                </p>
              </div>
            )
          )}
        </div>
      </section>

      <section className={`section ${styles.faqSection}`}>
        <div className={styles.sectionHeader}>
          <p className="eyebrow">FAQ</p>
          <h2>Domande frequenti sulla formazione digitale</h2>
        </div>
        <div className={styles.faqAccordion}>
          {faqData.map((item, index) => (
            <details key={item.question} open={index === 0}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className={`section ${styles.blogSection}`}>
        <div className={styles.sectionHeader}>
          <p className="eyebrow">Insights</p>
          <h2>Ultimi articoli dal nostro hub di conoscenza</h2>
        </div>
        <div className={styles.blogGrid}>
          {blogPreview.map((post) => (
            <article key={post.title} className={styles.blogCard}>
              <img src={post.image} alt={post.title} loading="lazy" />
              <div>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <a href="/chi-siamo" className={styles.blogLink}>
                  Continua a leggere →
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={`${styles.ctaSection}`}>
        <div className={styles.ctaContent}>
          <h2>Inizia oggi il tuo percorso con Digital Master Academy</h2>
          <p>
            Prenota un orientamento personalizzato e scopri come i nostri percorsi possono accelerare la tua carriera
            nel marketing digitale o nello sviluppo web.
          </p>
          <div className={styles.ctaActions}>
            <a href="/contatti" className="btn btnPrimary">
              Prenota una call
            </a>
            <a href="/programma" className="btn btnGhost">
              Esplora il programma
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;