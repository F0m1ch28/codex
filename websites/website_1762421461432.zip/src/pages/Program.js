import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Program.module.css';

const modules = [
  {
    title: 'Modulo 1 · Fondamenta Digitali',
    description:
      'Definizione obiettivi, analisi del mercato italiano, strumenti fondamentali per progettare strategie digitali integrate.',
    outcomes: ['Digital mindset', 'Analisi competitor', 'Pianificazione strategica'],
  },
  {
    title: 'Modulo 2 · Strumenti Operativi',
    description:
      'Approfondimento su tool di marketing automation, piattaforme advertising, ambienti di sviluppo e collaboration.',
    outcomes: ['Facebook Ads Manager avanzato', 'Google Analytics 4', 'Workflow Git collaborativo'],
  },
  {
    title: 'Modulo 3 · Project Work',
    description:
      'Realizzazione di un progetto completo supervisionato dai mentor: dalla ricerca alla presentazione dei risultati.',
    outcomes: ['Case study strutturato', 'Dashboard dati custom', 'Presentazione executive'],
  },
  {
    title: 'Modulo 4 · Career Acceleration',
    description:
      'Branding professionale, portfolio, mock interview e collegamento con aziende partner per nuove opportunità.',
    outcomes: ['Pitch professionale', 'Portfolio digitale', 'Networking mirato'],
  },
];

function Program() {
  return (
    <section className="section">
      <Helmet>
        <title>Programma | Digital Master Academy</title>
        <meta
          name="description"
          content="Esplora il programma completo della Digital Master Academy: moduli progressivi, project work e career coaching."
        />
      </Helmet>
      <div className={styles.wrapper}>
        <header className={styles.header}>
          <p className="eyebrow">Programma</p>
          <h1>Un percorso progressivo in quattro moduli</h1>
          <p>
            Il programma della Digital Master Academy è strutturato per accompagnarti dall&apos;analisi iniziale alla
            presentazione di un progetto professionale, con momenti di confronto costante.
          </p>
        </header>

        <div className={styles.modules}>
          {modules.map((module) => (
            <article key={module.title} className={styles.moduleCard}>
              <div>
                <h2>{module.title}</h2>
                <p>{module.description}</p>
              </div>
              <div className={styles.outcomes}>
                <h3>Risultati attesi</h3>
                <ul>
                  {module.outcomes.map((outcome) => (
                    <li key={outcome}>{outcome}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>

        <div className={styles.bonus}>
          <h2>Bonus inclusi nel programma</h2>
          <ul>
            <li>Laboratori live con partner tecnologici italiani</li>
            <li>Accesso esclusivo alla community Slack e database risorse</li>
            <li>Sessioni di Q&amp;A settimanali con i docenti</li>
            <li>Toolkit aggiornato con template, checklist e guide operative</li>
          </ul>
        </div>
      </div>
    </section>
  );
}

export default Program;