import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Courses from './pages/Courses';
import Program from './pages/Program';
import Teachers from './pages/Teachers';
import Contacts from './pages/Contacts';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

function App() {
  return (
    <>
      <Helmet>
        <title>Digital Master Academy | Formazione Digitale Avanzata</title>
        <meta
          name="description"
          content="Digital Master Academy offre percorsi pratici di formazione digitale, corsi di pubblicità targetizzata, coding e social media marketing in Italia."
        />
        <meta property="og:title" content="Digital Master Academy" />
        <meta
          property="og:description"
          content="Trasforma la tua carriera digitale con programmi aggiornati su coding, sviluppo web e social media marketing."
        />
        <meta property="og:type" content="website" />
      </Helmet>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/chi-siamo" element={<About />} />
          <Route path="/corsi" element={<Courses />} />
          <Route path="/programma" element={<Program />} />
          <Route path="/docenti" element={<Teachers />} />
          <Route path="/contatti" element={<Contacts />} />
          <Route path="/termini" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </>
  );
}

export default App;