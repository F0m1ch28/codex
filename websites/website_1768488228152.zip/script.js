document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('is-open');
        });

        navMenu.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768 && navMenu.classList.contains('is-open')) {
                    navMenu.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', false);
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('springieCookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }

        document.querySelectorAll('.cookie-action').forEach(action => {
            action.addEventListener('click', () => {
                const preference = action.dataset.preference || 'neutral';
                localStorage.setItem('springieCookieConsent', preference);
                cookieBanner.classList.add('hidden');
            });
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const courseCards = document.querySelectorAll('.course-card');

    if (filterButtons.length && courseCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const filter = button.dataset.filter;
                filterButtons.forEach(btn => btn.classList.remove('is-active'));
                button.classList.add('is-active');

                courseCards.forEach(card => {
                    const categories = (card.dataset.category || '').split(' ');
                    if (filter === 'all' || categories.includes(filter)) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    const accordionButtons = document.querySelectorAll('.accordion-button');
    if (accordionButtons.length) {
        accordionButtons.forEach(button => {
            button.addEventListener('click', () => {
                const expanded = button.getAttribute('aria-expanded') === 'true';
                button.setAttribute('aria-expanded', (!expanded).toString());
                const content = button.nextElementSibling;

                if (!expanded) {
                    content.classList.add('open');
                    content.style.maxHeight = content.scrollHeight + 'px';
                } else {
                    content.classList.remove('open');
                    content.style.maxHeight = null;
                }
            });
        });
    }
});