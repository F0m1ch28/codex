document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const primaryNav = document.querySelector(".primary-nav");

    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            primaryNav.classList.toggle("open");
        });
    }

    const banner = document.getElementById("cookieBanner");
    const cookieButtons = document.querySelectorAll(".cookie-banner .cookie-btn");

    if (banner) {
        const consent = localStorage.getItem("haveyzpqCookieConsent");
        if (consent) {
            banner.classList.add("hidden");
        }

        cookieButtons.forEach((btn) => {
            btn.addEventListener("click", function (event) {
                event.preventDefault();
                const choice = this.dataset.choice || "undecided";
                localStorage.setItem("haveyzpqCookieConsent", choice);
                banner.classList.add("hidden");
            });
        });
    }
});