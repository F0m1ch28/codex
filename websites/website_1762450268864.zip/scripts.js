document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".site-nav");
    const scrollTopButton = document.querySelector(".scroll-top");
    const cookieBanner = document.getElementById("cookieBanner");
    const acceptCookiesBtn = document.getElementById("acceptCookies");
    const yearSpan = document.getElementById("year");

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            nav.classList.toggle("open");
        });

        nav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth < 900) {
                    navToggle.setAttribute("aria-expanded", "false");
                    nav.classList.remove("open");
                }
            });
        });
    }

    if (scrollTopButton) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 300) {
                scrollTopButton.classList.add("show");
            } else {
                scrollTopButton.classList.remove("show");
            }
        });

        scrollTopButton.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem("cdlCookiesAccepted");
        if (consent === "true") {
            cookieBanner.classList.add("hidden");
        }

        acceptCookiesBtn.addEventListener("click", () => {
            localStorage.setItem("cdlCookiesAccepted", "true");
            cookieBanner.classList.add("hidden");
        });
    }

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});