document.addEventListener('DOMContentLoaded', () => {
  const banner = document.querySelector('.cookie-banner');
  const storageKey = 'cva-cookie-consent';
  if (banner) {
    const setVisibility = (show) => {
      banner.classList.toggle('is-visible', show);
      banner.setAttribute('aria-hidden', show ? 'false' : 'true');
    };
    try {
      const preference = localStorage.getItem(storageKey);
      if (preference === 'accepted' || preference === 'declined') {
        setVisibility(false);
      } else {
        setVisibility(true);
      }
    } catch (error) {
      setVisibility(true);
    }
    const acceptBtn = banner.querySelector('[data-cookie-action="accept"]');
    const declineBtn = banner.querySelector('[data-cookie-action="decline"]');
    const handleChoice = (value) => {
      try {
        localStorage.setItem(storageKey, value);
      } catch (error) {
        /* ignore storage errors */
      }
      setVisibility(false);
    };
    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => handleChoice('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => handleChoice('declined'));
    }
  }

  const navToggle = document.getElementById('nav-toggle');
  if (navToggle) {
    const navLinks = document.querySelectorAll('.primary-nav a');
    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.checked = false;
      });
    });
  }
});