document.addEventListener("DOMContentLoaded", function () {
    const body = document.body;
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");
    const cookieBanner = document.getElementById("cookieBanner");
    const cookieAccept = document.getElementById("cookieAccept");
    const cookieDecline = document.getElementById("cookieDecline");
    const COOKIE_KEY = "ccgr_cookie_preference_v1";

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navLinks.classList.toggle("active");
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
        });
    }

    const storedConsent = localStorage.getItem(COOKIE_KEY);
    if (!storedConsent && cookieBanner) {
        cookieBanner.classList.add("active");
    }

    if (cookieAccept) {
        cookieAccept.addEventListener("click", () => {
            localStorage.setItem(COOKIE_KEY, "accepted");
            cookieBanner.classList.remove("active");
        });
    }

    if (cookieDecline) {
        cookieDecline.addEventListener("click", () => {
            localStorage.setItem(COOKIE_KEY, "declined");
            cookieBanner.classList.remove("active");
        });
    }

    const mapRegions = document.querySelectorAll(".map-region");
    const mapTitle = document.getElementById("mapRegionTitle");
    const mapDescription = document.getElementById("mapRegionDescription");
    const mapFacts = document.getElementById("mapFactsList");

    if (mapRegions && mapTitle && mapDescription && mapFacts) {
        mapRegions.forEach(region => {
            region.addEventListener("click", () => {
                const regionName = region.getAttribute("data-name");
                const regionDescription = region.getAttribute("data-description");
                const regionFacts = region.getAttribute("data-facts");
                mapRegions.forEach(item => item.classList.remove("active"));
                region.classList.add("active");
                mapTitle.textContent = regionName;
                mapDescription.textContent = regionDescription;
                renderFacts(mapFacts, regionFacts);
            });
        });
    }

    function renderFacts(container, factsString) {
        container.innerHTML = "";
        if (!factsString) return;
        const factsArray = factsString.split("|");
        factsArray.forEach((fact, index) => {
            const item = document.createElement("li");
            const badge = document.createElement("span");
            badge.className = "fact-icon";
            badge.textContent = String(index + 1).padStart(2, "0");
            item.appendChild(badge);
            item.appendChild(document.createTextNode(fact.trim()));
            container.appendChild(item);
        });
    }

    const filterButtons = document.querySelectorAll(".filter-button");
    const festivalCards = document.querySelectorAll(".festival-card");

    if (filterButtons.length && festivalCards.length) {
        filterButtons.forEach(button => {
            button.addEventListener("click", () => {
                const filter = button.getAttribute("data-filter");
                filterButtons.forEach(btn => btn.classList.remove("active"));
                button.classList.add("active");

                festivalCards.forEach(card => {
                    if (filter === "toate" || card.getAttribute("data-region") === filter) {
                        card.style.display = "";
                    } else {
                        card.style.display = "none";
                    }
                });
            });
        });
    }

    const modalOverlay = document.getElementById("modalOverlay");
    const modalClose = document.getElementById("modalClose");
    const modalContentArea = document.getElementById("modalContent");
    const chefButtons = document.querySelectorAll("[data-chef]");

    if (modalOverlay && modalClose && modalContentArea) {
        chefButtons.forEach(button => {
            button.addEventListener("click", () => {
                const chefName = button.getAttribute("data-chef");
                const chefBio = button.getAttribute("data-bio");
                const chefHighlights = button.getAttribute("data-highlights");
                const chefImage = button.getAttribute("data-image");
                openChefModal(chefName, chefBio, chefHighlights, chefImage);
            });
        });

        modalClose.addEventListener("click", closeChefModal);
        modalOverlay.addEventListener("click", (event) => {
            if (event.target === modalOverlay) {
                closeChefModal();
            }
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                closeChefModal();
            }
        });
    }

    function openChefModal(name, bio, highlights, image) {
        if (!modalOverlay || !modalContentArea) return;
        modalContentArea.innerHTML = `
            <div class="modal-hero">
                <img src="${image}" alt="Portret ${name}" style="width:100%;border-radius:12px;margin-bottom:1.2rem;">
            </div>
            <h2>${name}</h2>
            <p>${bio}</p>
            <h3>Puncte esențiale din carieră</h3>
            <ul class="fact-list">
                ${highlights.split("|").map((item, index) => `
                    <li><span class="fact-icon">${String(index + 1).padStart(2, "0")}</span>${item.trim()}</li>
                `).join("")}
            </ul>
        `;
        modalOverlay.classList.add("active");
        body.style.overflow = "hidden";
        modalClose.focus();
    }

    function closeChefModal() {
        if (!modalOverlay) return;
        modalOverlay.classList.remove("active");
        body.style.overflow = "";
    }

    const galleryItems = document.querySelectorAll(".gallery-item [data-lightbox]");
    const lightboxOverlay = document.getElementById("lightboxOverlay");
    const lightboxImage = document.getElementById("lightboxImage");
    const lightboxCaption = document.getElementById("lightboxCaption");
    const lightboxClose = document.getElementById("lightboxClose");

    if (galleryItems.length && lightboxOverlay && lightboxImage && lightboxCaption) {
        galleryItems.forEach(item => {
            item.addEventListener("click", (event) => {
                event.preventDefault();
                const source = item.getAttribute("href");
                const caption = item.getAttribute("data-caption");
                lightboxImage.src = source;
                lightboxImage.alt = caption;
                lightboxCaption.textContent = caption;
                lightboxOverlay.classList.add("active");
                body.style.overflow = "hidden";
                lightboxClose.focus();
            });
        });

        lightboxClose.addEventListener("click", closeLightbox);
        lightboxOverlay.addEventListener("click", (event) => {
            if (event.target === lightboxOverlay) {
                closeLightbox();
            }
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                closeLightbox();
            }
        });
    }

    function closeLightbox() {
        if (!lightboxOverlay) return;
        lightboxOverlay.classList.remove("active");
        lightboxImage.src = "";
        body.style.overflow = "";
    }

    const faqItems = document.querySelectorAll(".faq-item");
    if (faqItems.length) {
        faqItems.forEach(item => {
            const question = item.querySelector(".faq-question");
            question.addEventListener("click", () => {
                const isActive = item.classList.contains("active");
                faqItems.forEach(el => el.classList.remove("active"));
                if (!isActive) {
                    item.classList.add("active");
                }
            });
        });
    }

    const audioPlayers = document.querySelectorAll(".audio-card audio");
    audioPlayers.forEach(player => {
        player.addEventListener("play", () => {
            audioPlayers.forEach(other => {
                if (other !== player) {
                    other.pause();
                }
            });
        });
    });
});