```javascript
document.addEventListener('DOMContentLoaded', () => {
  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');
  const consentState = localStorage.getItem('vvedite-cookie-consent');

  if (cookieBanner && consentState) {
    cookieBanner.classList.add('is-hidden');
  }

  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('vvedite-cookie-consent', 'accepted');
    cookieBanner?.classList.add('is-hidden');
  });

  declineBtn?.addEventListener('click', () => {
    localStorage.setItem('vvedite-cookie-consent', 'declined');
    cookieBanner?.classList.add('is-hidden');
  });

  const currentPage = document.body.dataset.page;
  if (currentPage) {
    const activeLink = document.querySelector(`.nav-link[data-page="${currentPage}"]`);
    if (activeLink) {
      activeLink.classList.add('active');
      activeLink.setAttribute('aria-current', 'page');
    }
  }
});
```