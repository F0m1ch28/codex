import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.inner}>
        <div className={styles.brandBlock}>
          <h2 id="footer-heading" className={styles.title}>
            Пиццерия в Киеве
          </h2>
          <p className={styles.description}>
            Щодня розпалюємо дров’яну піч, щоб дарувати гостям справжній смак Неаполя. Доставка по Києву та теплый прием на Крещатике, 25.
          </p>
          <div className={styles.socials} aria-label="Социальные сети">
            <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram пиццерии">
              Instagram
            </a>
            <a href="https://www.facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook пиццерии">
              Facebook
            </a>
            <a href="https://t.me" target="_blank" rel="noreferrer" aria-label="Telegram пиццерии">
              Telegram
            </a>
          </div>
        </div>

        <div className={styles.columns}>
          <div className={styles.column}>
            <h3>Навигация</h3>
            <ul>
              <li>
                <NavLink to="/menu">Меню</NavLink>
              </li>
              <li>
                <NavLink to="/delivery">Доставка</NavLink>
              </li>
              <li>
                <NavLink to="/about">Про нас</NavLink>
              </li>
              <li>
                <NavLink to="/contacts">Контакти</NavLink>
              </li>
              <li>
                <NavLink to="/privacy">Політика конфіденційності</NavLink>
              </li>
              <li>
                <NavLink to="/terms">Умови використання</NavLink>
              </li>
              <li>
                <NavLink to="/cookie-policy">Cookie policy</NavLink>
              </li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3>Контакти</h3>
            <ul>
              <li>г. Киев, ул. Крещатик, 25</li>
              <li>
                <a href="tel:+380441234567">+380 (44) 123-45-67</a>
              </li>
              <li>
                <a href="mailto:info@pizzeria-kiev.ua">info@pizzeria-kiev.ua</a>
              </li>
              <li>Пн-Вс 10:00-23:00</li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3>Доставка</h3>
            <ul>
              <li>Середній час: 45 хвилин</li>
              <li>Зони: центр, Поділ, Печерськ</li>
              <li>Трекінг в реальному часі</li>
              <li>Самовивіз без черг</li>
            </ul>
          </div>
        </div>
      </div>

      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Пиццерия в Киеве. Усі права захищені.</p>
        <p>Зроблено з любов’ю до історій Києва та італійської кухні.</p>
      </div>
    </footer>
  );
};

export default Footer;