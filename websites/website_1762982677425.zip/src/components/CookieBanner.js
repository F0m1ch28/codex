import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('pizzeriaCookieConsent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = () => {
    localStorage.setItem('pizzeriaCookieConsent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          Ми використовуємо cookie, щоб зробити сервіс смачніше. Продовжуючи, ви погоджуєтесь з{' '}
          <a href="/privacy">політикою конфіденційності</a> та <a href="/cookie-policy">cookie policy</a>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className="btnPrimary" onClick={handleConsent}>
          Погоджуюсь
        </button>
        <a className="btnGhost" href="/cookie-policy">
          Детальніше
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;