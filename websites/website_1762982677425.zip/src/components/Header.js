import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const navLinks = [
    { to: '/', label: 'Головна' },
    { to: '/menu', label: 'Меню' },
    { to: '/delivery', label: 'Доставка' },
    { to: '/about', label: 'Про нас' },
    { to: '/contacts', label: 'Контакти' },
  ];

  return (
    <header className={`${styles.header} ${scrolled ? styles.headerScrolled : ''}`}>
      <div className={styles.container}>
        <div className={styles.branding}>
          <NavLink to="/" className={styles.logo} aria-label="Пиццерия в Киеве, перейти на главную">
            Пиццерия <span className={styles.logoAccent}>в Киеве</span>
          </NavLink>
          <p className={styles.tagline}>Італійський настрій на Крещатику</p>
        </div>

        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`} aria-label="Главная навигация">
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.to} className={styles.navItem}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className={styles.actions}>
          <a className="btnPrimary" href="tel:+380441234567">
            Замовити дзвінок
          </a>
          <button
            type="button"
            className={`${styles.burger} ${isMenuOpen ? styles.burgerOpen : ''}`}
            aria-label="Меню"
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((prev) => !prev)}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;