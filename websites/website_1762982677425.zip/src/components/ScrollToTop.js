import React, { useEffect, useState } from 'react';
import styles from './ScrollToTop.module.css';

const ScrollToTopButton = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const checkScroll = () => {
      setIsVisible(window.scrollY > 320);
    };
    window.addEventListener('scroll', checkScroll, { passive: true });
    return () => window.removeEventListener('scroll', checkScroll);
  }, []);

  const handleClick = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      className={`${styles.button} ${isVisible ? styles.buttonVisible : ''}`}
      onClick={handleClick}
      aria-label="Повернутися нагору"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;