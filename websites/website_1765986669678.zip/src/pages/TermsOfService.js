import React from 'react';
import Meta from '../components/Meta';
import styles from './TermsOfService.module.css';

const TermsOfService = () => {
  return (
    <div className={styles.terms}>
      <Meta
        title="Términos y Condiciones | Valentor Amicado"
        description="Consulta los términos y condiciones de uso del sitio web y servicios de Valentor Amicado."
        keywords="términos y condiciones Valentor Amicado"
        canonical="https://valentoramicado.site/terminos"
      />
      <section className={styles.section}>
        <div className="container">
          <h1>Términos y Condiciones</h1>
          <p>Fecha de última actualización: enero 2024</p>

          <h2>1. Aceptación</h2>
          <p>
            El acceso y uso del sitio web valentoramicado.site implica la aceptación plena de los presentes
            Términos y Condiciones. Si no está de acuerdo con alguna de las disposiciones, deberá abstenerse de
            utilizar el sitio.
          </p>

          <h2>2. Uso del sitio</h2>
          <p>
            Valentor Amicado ofrece información y recursos sobre educación para adultos. El usuario se compromete
            a emplear los contenidos de manera lícita y respetuosa, evitando cualquier uso indebido o fraudulento.
          </p>

          <h2>3. Propiedad intelectual</h2>
          <p>
            Todo el contenido publicado, incluyendo textos, marcas, gráficos y diseños, es propiedad de Valentor
            Amicado o cuenta con las licencias correspondientes. Queda prohibida su reproducción sin autorización
            expresa.
          </p>

          <h2>4. Privacidad y datos</h2>
          <p>
            El tratamiento de datos personales se rige por nuestra Política de Privacidad. El usuario garantiza
            que la información suministrada es veraz y se compromete a mantenerla actualizada.
          </p>

          <h2>5. Limitación de responsabilidad</h2>
          <p>
            Valentor Amicado no se hace responsable de daños derivados del uso del sitio, interrupciones del
            servicio o contenidos externos a los que se pueda enlazar. El uso del sitio es bajo responsabilidad
            del usuario.
          </p>

          <h2>6. Modificaciones</h2>
          <p>
            Nos reservamos el derecho de modificar estos Términos y Condiciones en cualquier momento. Los cambios
            serán efectivos tras su publicación en el sitio.
          </p>

          <h2>7. Legislación aplicable</h2>
          <p>
            Estos Términos se rigen por las leyes de los Estados Unidos Mexicanos. Cualquier controversia se
            someterá a los tribunales competentes de Ciudad de México.
          </p>

          <h2>8. Contacto</h2>
          <p>
            Para aclaraciones sobre estos Términos, comunícate con nosotros en{' '}
            <a href="mailto:hola@valentoramicado.site">hola@valentoramicado.site</a>.
          </p>
        </div>
      </section>
    </div>
  );
};

export default TermsOfService;