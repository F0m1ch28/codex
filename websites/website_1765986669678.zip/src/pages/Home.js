import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Meta from '../components/Meta';
import ImageWithLoader from '../components/ImageWithLoader';
import styles from './Home.module.css';

const benefits = [
  {
    title: 'Aprendizaje Personalizado',
    description:
      'Diseñamos rutas dinámicas que se adaptan en tiempo real al ritmo y estilo de cada profesional.',
    icon: '🎯'
  },
  {
    title: 'Evolución Continua',
    description:
      'Actualizamos los contenidos con insights basados en IA para garantizar habilidades vigentes.',
    icon: '📈'
  },
  {
    title: 'Mentoría Especializada',
    description:
      'Conecta con mentores certificados que combinan experiencia humana y analítica inteligente.',
    icon: '🤝'
  },
  {
    title: 'Resultados Medibles',
    description:
      'Paneles de seguimiento y analítica avanzada para tomar decisiones estratégicas de talento.',
    icon: '📊'
  }
];

const methodologySteps = [
  {
    title: 'Diagnóstico IA 360°',
    description:
      'Evaluación integral de habilidades y objetivos profesionales para mapear brechas concretas.'
  },
  {
    title: 'Ruta Personalizada',
    description:
      'Secuenciamos micro-retos, cápsulas y mentorías adaptadas al contexto laboral de cada persona.'
  },
  {
    title: 'Activación Inmersiva',
    description:
      'Experiencias blended con simulaciones, casos y feedback continuo impulsado por inteligencia artificial.'
  },
  {
    title: 'Medición y Ajustes',
    description:
      'Dashboards con métricas en tiempo real y recomendaciones proactivas de optimización.'
  }
];

const featuredPrograms = [
  {
    title: 'Liderazgo Adaptativo con IA',
    description:
      'Desarrolla líderes que combinen visión estratégica, pensamiento crítico y analítica aumentada para equipos híbridos.'
  },
  {
    title: 'Upskilling Digital para Operaciones',
    description:
      'Capacitación modular para equipos operativos con foco en automatización, datos y eficiencia inteligente.'
  },
  {
    title: 'Learning Path Ejecutivo',
    description:
      'Trayectorias concentradas para directivos con microlearning, mentoring ejecutivo y escenarios predictivos.'
  },
  {
    title: 'Cultura Data-Driven para RRHH',
    description:
      'Transforma la gestión del talento con insights accionables y procesos de aprendizaje guiados por IA.'
  }
];

const testimonials = [
  {
    name: 'Mariana Ortega',
    role: 'Directora de Capital Humano, Innovexa',
    quote:
      'La personalización con IA nos permitió acelerar el reskilling de nuestro equipo de manera tangible. Valentor Amicado integra tecnología y acompañamiento humano impecable.',
    avatar: 'https://picsum.photos/seed/valentor1/96'
  },
  {
    name: 'Ricardo Velázquez',
    role: 'Gerente de Operaciones, NorteLog',
    quote:
      'Los dashboards de progreso nos ayudan a demostrar impacto al comité directivo. La metodología es clara, adaptable y orientada a resultados.',
    avatar: 'https://picsum.photos/seed/valentor2/96'
  },
  {
    name: 'Alicia Méndez',
    role: 'Coordinadora de Formación, LatamCorp',
    quote:
      'Por primera vez nuestros colaboradores sienten que el aprendizaje se ajusta a sus necesidades reales. El soporte del equipo es extraordinario.',
    avatar: 'https://picsum.photos/seed/valentor3/96'
  }
];

const Home = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const previousTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <div className={styles.home}>
      <Meta
        title="Valentor Amicado | Educación Inteligente para Adultos en México"
        description="Transformamos el aprendizaje de adultos con rutas personalizadas basadas en IA. Descubre programas flexibles, mentoría especializada y resultados medibles."
        keywords="educación para adultos, aprendizaje con IA, capacitación profesional, desarrollo de habilidades, edtech México"
        canonical="https://valentoramicado.site/"
      />

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <p className={styles.heroTag}>Educación potenciada por IA</p>
            <h1 className={styles.heroTitle}>
              Aprendizaje profesional que evoluciona contigo y con las necesidades de tu empresa.
            </h1>
            <p className={styles.heroSubtitle}>
              En Valentor Amicado combinamos inteligencia artificial, mentoring experto y experiencias
              inmersivas para impulsar el crecimiento continuo de equipos adultos en México.
            </p>
            <div className={styles.heroActions}>
              <Link to="/programas" className={styles.primaryButton}>
                Explora Nuestros Programas
              </Link>
              <Link to="/contacto" className={styles.secondaryButton}>
                Agenda una Conversación
              </Link>
            </div>
            <div className={styles.heroHighlights} role="list">
              <div className={styles.highlightItem}>
                <span>+92%</span>
                <p>Satisfacción de participantes</p>
              </div>
              <div className={styles.highlightItem}>
                <span>4.8/5</span>
                <p>Valoración de mentorías</p>
              </div>
              <div className={styles.highlightItem}>
                <span>15k</span>
                <p>Horas de aprendizaje activadas</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.companyIntro}>
        <div className="container">
          <div className={styles.introCard}>
            <h2>Impulsamos el talento adulto con experiencias inteligentes y humanas</h2>
            <p>
              Nuestra misión es democratizar el aprendizaje profesional de alto impacto para personas
              adultas en México. Diseñamos trayectorias flexibles que combinan data, acompañamiento y
              experiencias relevantes para cada rol.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className="container">
          <h2>Beneficios clave de nuestra experiencia</h2>
          <div className={styles.benefitsGrid}>
            {benefits.map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <span className={styles.benefitIcon} aria-hidden="true">{benefit.icon}</span>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.methodology}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Así vivimos la Metodología Valentor</h2>
            <Link to="/metodologia" className={styles.linkInline}>
              Conoce el proceso completo →
            </Link>
          </div>
          <div className={styles.methodologyGrid}>
            {methodologySteps.map((step, index) => (
              <article key={step.title} className={styles.stepCard}>
                <span className={styles.stepNumber}>0{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.programs}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Programas destacados</h2>
            <p>
              Portafolio diseñado para potenciar habilidades críticas en organizaciones dinámicas y
              aceleradas.
            </p>
          </div>
          <div className={styles.programsGrid}>
            {featuredPrograms.map((program) => (
              <article key={program.title} className={styles.programCard}>
                <h3>{program.title}</h3>
                <p>{program.description}</p>
                <Link to="/programas" className={styles.programLink}>
                  Ver estructura curricular →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className={styles.sectionHead}>
            <h2>Historias de transformación</h2>
            <p>
              Empresas y profesionales que impulsan su crecimiento con estrategias de aprendizaje
              personalizadas.
            </p>
          </div>
          <div className={styles.testimonialWrapper}>
            <button
              type="button"
              onClick={previousTestimonial}
              aria-label="Testimonio anterior"
              className={styles.sliderButton}
            >
              ←
            </button>
            <article className={styles.testimonialCard}>
              <ImageWithLoader
                src={testimonials[currentTestimonial].avatar}
                alt={"Foto de ${testimonials[currentTestimonial].name}"}
                wrapperClassName={styles.avatarWrapper}
                imageClassName={styles.avatar}
              />
              <p className={styles.quote}>
                “{testimonials[currentTestimonial].quote}”
              </p>
              <div className={styles.author}>
                <strong>{testimonials[currentTestimonial].name}</strong>
                <span>{testimonials[currentTestimonial].role}</span>
              </div>
            </article>
            <button
              type="button"
              onClick={nextTestimonial}
              aria-label="Siguiente testimonio"
              className={styles.sliderButton}
            >
              →
            </button>
          </div>
          <div className={styles.dots} role="tablist" aria-label="Seleccionar testimonio">
            {testimonials.map((testimonial, index) => (
              <button
                key={testimonial.name}
                type="button"
                onClick={() => setCurrentTestimonial(index)}
                className={"${styles.dot} ${
                  currentTestimonial === index ? styles.dotActive : ''
                }"}
                aria-label={"Ver testimonio de ${testimonial.name}"}
                aria-selected={currentTestimonial === index}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Comienza hoy una ruta de aprendizaje estratégica</h2>
            <p>
              Diseñemos juntos una experiencia personalizada para tus equipos. Nuestro equipo está listo
              para acompañarte en cada paso.
            </p>
            <Link to="/contacto" className={styles.ctaButton}>
              Construyamos tu plan
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;