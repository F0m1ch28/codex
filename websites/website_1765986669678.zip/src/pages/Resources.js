import React from 'react';
import Meta from '../components/Meta';
import styles from './Resources.module.css';

const resources = [
  {
    title: 'Guía: Estrategias de Upskilling Inteligente',
    type: 'Ebook',
    description:
      'Descubre cómo implementar rutas de aprendizaje personalizadas para equipos operativos y administrativos.',
    link: '#'
  },
  {
    title: 'Checklist: Cultura de Aprendizaje Data-Driven',
    type: 'Toolkit',
    description:
      'Evalúa la madurez de tu organización y prioriza acciones para potenciar el aprendizaje basado en datos.',
    link: '#'
  },
  {
    title: 'Reporte 2024: Tendencias de Educación para Adultos en México',
    type: 'Reporte',
    description:
      'Insights clave sobre adopción tecnológica, habilidades emergentes y expectativas del talento adulto.',
    link: '#'
  },
  {
    title: 'Plantilla: OKRs de Aprendizaje Impulsados por IA',
    type: 'Plantilla',
    description:
      'Define objetivos claros y medibles para tus programas de formación profesional con IA.',
    link: '#'
  }
];

const Resources = () => {
  return (
    <div className={styles.resources}>
      <Meta
        title="Recursos | Valentor Amicado"
        description="Descarga herramientas, guías y reportes para fortalecer la educación de adultos con inteligencia artificial."
        keywords="recursos educativos, guías de aprendizaje, IA en educación, Valentor Amicado"
        canonical="https://valentoramicado.site/recursos"
      />

      <section className={styles.hero}>
        <div className="container">
          <h1>Recursos para potenciar tu estrategia de aprendizaje</h1>
          <p>
            Herramientas prácticas, investigaciones y guías diseñadas para líderes de talento, aprendizaje
            y desarrollo profesional.
          </p>
        </div>
      </section>

      <section className={styles.resourcesSection}>
        <div className="container">
          <div className={styles.grid}>
            {resources.map((resource) => (
              <article key={resource.title} className={styles.card}>
                <span className={styles.badge}>{resource.type}</span>
                <h2>{resource.title}</h2>
                <p>{resource.description}</p>
                <a href={resource.link} className={styles.downloadLink}>
                  Obtener recurso →
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Resources;