import React, { useState } from 'react';
import styles from './ImageWithLoader.module.css';

const ImageWithLoader = ({ src, alt, wrapperClassName = '', imageClassName = '' }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={"${styles.wrapper} ${wrapperClassName}"}>
      {!loaded && <div className={styles.placeholder} aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        className={"${styles.image} ${loaded ? styles.loaded : ''} ${imageClassName}"}
        onLoad={() => setLoaded(true)}
      />
    </div>
  );
};

export default ImageWithLoader;