import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={"container ${styles.grid}"}>
        <div className={styles.brandBlock}>
          <div className={styles.logo}>
            <span>VA</span>
          </div>
          <p className={styles.description}>
            Valentor Amicado potencia el aprendizaje de adultos en México con experiencias
            personalizadas y dinámicas impulsadas por inteligencia artificial.
          </p>
          <div className={styles.socials} aria-label="Redes sociales">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
              <span className={styles.socialIcon}>in</span>
            </a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
              <span className={styles.socialIcon}>▶</span>
            </a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="X">
              <span className={styles.socialIcon}>X</span>
            </a>
          </div>
        </div>

        <div className={styles.column}>
          <h3 id="footer-heading" className={styles.columnTitle}>Explora</h3>
          <ul className={styles.list}>
            <li><Link to="/nosotros">Nosotros</Link></li>
            <li><Link to="/metodologia">Metodología</Link></li>
            <li><Link to="/programas">Programas</Link></li>
            <li><Link to="/recursos">Recursos</Link></li>
            <li><Link to="/blog">Blog</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Soporte</h3>
          <ul className={styles.list}>
            <li><Link to="/contacto">Contacto</Link></li>
            <li><Link to="/terminos">Términos y Condiciones</Link></li>
            <li><Link to="/privacidad">Política de Privacidad</Link></li>
            <li><Link to="/cookies">Política de Cookies</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Contáctanos</h3>
          <address className={styles.contactInfo}>
            <p>Av. Insurgentes Sur 1234</p>
            <p>Col. Del Valle, Benito Juárez</p>
            <p>03100 Ciudad de México, CDMX, México</p>
            <p>Teléfono: <a href="tel:+525512345678">+52 55 1234 5678</a></p>
            <p>Email: <a href="mailto:hola@valentoramicado.site">hola@valentoramicado.site</a></p>
          </address>
        </div>
      </div>

      <div className={styles.bottomBar}>
        <p>© {new Date().getFullYear()} Valentor Amicado. Todos los derechos reservados.</p>
      </div>
    </footer>
  );
};

export default Footer;