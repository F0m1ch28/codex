import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navigation = [
    { path: '/', label: 'Inicio' },
    { path: '/nosotros', label: 'Nosotros' },
    { path: '/metodologia', label: 'Metodología' },
    { path: '/programas', label: 'Programas' },
    { path: '/recursos', label: 'Recursos' },
    { path: '/blog', label: 'Blog' }
  ];

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header} aria-label="Menú principal">
      <div className={"container ${styles.inner}"}>
        <Link to="/" className={styles.logo} onClick={closeMenu} aria-label="Valentor Amicado">
          <span className={styles.logoMark}>VA</span>
          <div>
            <p className={styles.logoName}>Valentor Amicado</p>
            <p className={styles.logoTagline}>AI-Powered Education</p>
          </div>
        </Link>

        <button
          className={styles.burger}
          type="button"
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Alternar menú"
        >
          <span className={styles.burgerLine} />
          <span className={styles.burgerLine} />
          <span className={styles.burgerLine} />
        </button>

        <nav
          className={"${styles.nav} ${menuOpen ? styles.navOpen : ''}"}
          id="primary-navigation"
        >
          <ul className={styles.navList}>
            {navigation.map((item) => (
              <li key={item.path} className={styles.navItem}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    isActive ? "${styles.navLink} ${styles.active}" : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <Link to="/contacto" className={styles.ctaButton} onClick={closeMenu}>
            Agenda una Demo
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;