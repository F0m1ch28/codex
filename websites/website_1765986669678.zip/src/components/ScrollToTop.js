import React, { useEffect, useState } from 'react';
import styles from './ScrollToTop.module.css';

const ScrollToTopButton = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setVisible(window.scrollY > 320);
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const handleScroll = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      onClick={handleScroll}
      className={"${styles.button} ${visible ? styles.visible : ''}"}
      aria-label="Volver al inicio"
    >
      ↑
    </button>
  );
};

export default ScrollToTopButton;