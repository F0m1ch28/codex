import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('va-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => {
        setVisible(true);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('va-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Aviso de cookies">
      <p>
        Utilizamos cookies para personalizar tu experiencia de aprendizaje. Consulta nuestra{' '}
        <Link to="/cookies">Política de Cookies</Link>.
      </p>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Aceptar
      </button>
    </div>
  );
};

export default CookieBanner;