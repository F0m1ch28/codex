```javascript
document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      navMenu.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', navMenu.classList.contains('open'));
    });

    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  if (cookieBanner) {
    const consent = localStorage.getItem('qnm_cookie_consent');
    if (!consent) {
      cookieBanner.classList.add('show');
    }

    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
    acceptBtn?.addEventListener('click', () => {
      localStorage.setItem('qnm_cookie_consent', 'accepted');
      cookieBanner.classList.remove('show');
    });
    declineBtn?.addEventListener('click', () => {
      localStorage.setItem('qnm_cookie_consent', 'declined');
      cookieBanner.classList.remove('show');
    });
  }

  const form = document.getElementById('contactForm');
  if (form) {
    const messageBox = document.getElementById('formMessage');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const name = form.querySelector('#name').value.trim();
      const email = form.querySelector('#email').value.trim();
      const message = form.querySelector('#message').value.trim();
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (name.length < 2) {
        showFormMessage('Есіміңізді толық енгізіңіз.', 'error');
        return;
      }
      if (!emailRegex.test(email)) {
        showFormMessage('Дұрыс электронды пошта форматін енгізіңіз.', 'error');
        return;
      }
      if (message.length < 10) {
        showFormMessage('Хабарлама кемінде 10 таңбадан тұруы керек.', 'error');
        return;
      }

      form.reset();
      showFormMessage('Хатыңыз сәтті жіберілді! Біз жақын арада жауап береміз.', 'success');
    });

    function showFormMessage(text, type) {
      if (!messageBox) return;
      messageBox.textContent = text;
      messageBox.classList.remove('success', 'error');
      messageBox.classList.add(type);
    }
  }

  const faqButtons = document.querySelectorAll('.faq-item button');
  faqButtons.forEach(button => {
    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';
      faqButtons.forEach(btn => {
        btn.setAttribute('aria-expanded', 'false');
        const panel = document.getElementById(btn.getAttribute('aria-controls'));
        panel?.classList.remove('open');
      });
      if (!expanded) {
        button.setAttribute('aria-expanded', 'true');
        document.getElementById(button.getAttribute('aria-controls'))?.classList.add('open');
      }
    });
  });
});
```

<!-- TEMPLATE: shared header & footer (for reference only, identical across all pages except active class) -->
```html
<header class="site-header">
  <a class="skip-link" href="#mainContent">Негізгі мазмұнға өту</a>
  <div class="container header-inner">
    <a href="index.html" class="logo" aria-label="Qazaq News Media">Qazaq News Media</a>
    <button class="nav-toggle" aria-expanded="false" aria-controls="primary-nav">
      <span class="visually-hidden">Мәзірді ашу</span>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
      </svg>
    </button>
    <nav class="nav-menu primary-nav" id="primary-nav" aria-label="Басты навигация">
      <a href="index.html">Басты</a>
      <a href="about.html">Біз туралы</a>
      <a href="blog.html">Жаңалықтар</a>
      <a href="contact.html">Байланыс</a>
    </nav>
  </div>
</header>

<footer class="site-footer">
  <div class="container footer-grid">
    <div>
      <h3>Qazaq News Media</h3>
      <p>Қазақстандағы өзекті жаңалықтар мен сенімді ақпарат көзі.</p>
      <span class="badge-status">Астана · Qazaq News Media</span>
    </div>
    <div>
      <span class="footer-heading">Байланыс</span>
      <div class="footer-contact">
        <span>+7 (7172) 45-67-89</span>
        <span>info@qazaqnews.kz</span>
        <span>Астана қ., Қабанбай батыр даңғылы, 12, Qazaq Media Tower</span>
      </div>
    </div>
    <div>
      <span class="footer-heading">Сілтемелер</span>
      <div class="footer-links">
        <a href="about.html">Біз туралы</a>
        <a href="privacy.html">Құпиялылық</a>
        <a href="faq.html">FAQ</a>
        <a href="terms.html">Пайдалану шарттары</a>
      </div>
    </div>
  </div>
  <div class="container footer-bottom">
    <span>Qazaq News Media | Қазақстандағы өзекті жаңалықтар мен сенімді ақпарат көзі</span>
    <span>© Qazaq News Media <span id="currentYear">2024</span>. Барлық құқықтар қорғалған.</span>
  </div>
</footer>

<div class="cookie-banner" id="cookieBanner" role="dialog" aria-live="polite">
  <p>Біз сіздің тәжірибеңізді жақсарту үшін cookie-файлдарын қолданамыз. Толық ақпаратты <a href="privacy.html">Құпиялылық саясатынан</a> оқыңыз.</p>
  <div class="cookie-actions">
    <button class="btn" data-cookie="accept">Қабылдаймын</button>
    <button class="btn btn-outline" data-cookie="decline">Бас тартамын</button>
  </div>
</div>
<script>document.getElementById('currentYear').textContent=new Date().getFullYear();</script>
<script src="script.js" defer></script>
```