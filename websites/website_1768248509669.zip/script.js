document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navLinks.classList.toggle('nav-open');
        });

        navLinks.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (navLinks.classList.contains('nav-open')) {
                    navLinks.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('gc-cookie-choice');
        if (storedChoice) {
            cookieBanner.classList.add('is-hidden');
        }

        cookieBanner.querySelectorAll('.cookie-button').forEach(function (button) {
            button.addEventListener('click', function () {
                const choice = button.dataset.choice || 'unspecified';
                const linkTarget = button.dataset.link || 'cookies.html';
                localStorage.setItem('gc-cookie-choice', choice);
                cookieBanner.classList.add('is-hidden');
                window.location.href = linkTarget;
            });
        });
    }
});