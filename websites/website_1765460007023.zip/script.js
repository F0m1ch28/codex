document.addEventListener('DOMContentLoaded', () => {
  const body = document.documentElement;
  const page = body.dataset.page;
  const navLinks = document.querySelectorAll('.nav-list a');
  navLinks.forEach(link => {
    if (link.getAttribute('href').includes(page)) {
      link.classList.add('is-active');
    }
  });

  const menuToggle = document.querySelector('.menu-toggle');
  const navigation = document.querySelector('.main-navigation');

  if (menuToggle && navigation) {
    menuToggle.addEventListener('click', () => {
      const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!expanded));
      navigation.classList.toggle('is-open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        menuToggle.setAttribute('aria-expanded', 'false');
        navigation.classList.remove('is-open');
      });
    });
  }

  const filterGrid = document.querySelector('[data-filter-grid]');
  const filterButtons = document.querySelectorAll('.filter-btn');
  if (filterGrid && filterButtons.length) {
    const products = filterGrid.querySelectorAll('[data-category]');
    filterButtons.forEach(button => {
      button.addEventListener('click', () => {
        const filter = button.dataset.filter;
        filterButtons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');

        products.forEach(item => {
          const category = item.dataset.category;
          const shouldShow = filter === 'all' || category === filter;
          item.style.display = shouldShow ? 'block' : 'none';
          item.style.opacity = shouldShow ? '1' : '0';
        });
      });
    });
  }

  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    const messageEl = contactForm.querySelector('.form-message');
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const name = formData.get('name');
      const email = formData.get('email');
      const topic = formData.get('topic');
      const message = formData.get('message');
      const phone = formData.get('phone');

      let errors = [];

      if (!name || name.trim().length < 2) {
        errors.push('Vul een geldige naam in.');
      }
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push('Controleer je e-mailadres.');
      }
      if (!topic) {
        errors.push('Kies een onderwerp.');
      }
      if (!message || message.trim().length < 10) {
        errors.push('Vertel ons iets meer over je vraag.');
      }
      if (phone && !/^(\+?\d{1,3})?\s?\d{6,12}$/.test(phone)) {
        errors.push('Gebruik een geldig telefoonnummer.');
      }

      if (errors.length) {
        messageEl.textContent = errors.join(' ');
        messageEl.classList.remove('is-success');
        messageEl.classList.add('is-error');
      } else {
        messageEl.textContent = 'Dank je wel voor je bericht! We antwoorden binnen één werkdag.';
        messageEl.classList.remove('is-error');
        messageEl.classList.add('is-success');
        contactForm.reset();
      }
    });
  }

  const consentKey = 'pkts-cookie-consent';
  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }

    cookieBanner.querySelectorAll('[data-cookie-action]').forEach(button => {
      button.addEventListener('click', () => {
        const action = button.dataset.cookieAction;
        localStorage.setItem(consentKey, action);
        cookieBanner.classList.remove('is-visible');
      });
    });
  }
});