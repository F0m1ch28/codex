document.addEventListener('DOMContentLoaded', function () {
  var navToggle = document.querySelector('.nav-toggle');
  var navList = document.querySelector('.nav-list');
  if (navToggle && navList) {
    navToggle.addEventListener('click', function () {
      var expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navList.classList.toggle('open');
    });
  }

  var cookieBanner = document.querySelector('[data-cookie-banner]');
  var cookieAccept = document.querySelector('[data-cookie-accept]');
  var cookieDecline = document.querySelector('[data-cookie-decline]');
  var cookieKey = 'calorimbastella_cookie_consent';
  var storedConsent = localStorage.getItem(cookieKey);

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add('cookie-banner-hidden');
    }
  }

  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove('cookie-banner-hidden');
    }
  }

  if (!storedConsent) {
    showCookieBanner();
  } else {
    hideCookieBanner();
  }

  if (cookieAccept) {
    cookieAccept.addEventListener('click', function () {
      localStorage.setItem(cookieKey, 'accepted');
      hideCookieBanner();
    });
  }

  if (cookieDecline) {
    cookieDecline.addEventListener('click', function () {
      localStorage.setItem(cookieKey, 'declined');
      hideCookieBanner();
    });
  }

  var resetButton = document.querySelector('[data-reset-cookies]');
  if (resetButton) {
    resetButton.addEventListener('click', function () {
      localStorage.removeItem(cookieKey);
      showCookieBanner();
    });
  }

  var contactForm = document.getElementById('contact-form');
  var formFeedback = document.getElementById('form-feedback');

  if (contactForm && formFeedback) {
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var nameField = contactForm.querySelector('#name');
      var emailField = contactForm.querySelector('#email');
      var queryField = contactForm.querySelector('#query');

      var errors = [];

      if (!nameField.value.trim() || nameField.value.trim().length < 3) {
        errors.push('El nombre debe tener al menos 3 caracteres.');
      }

      var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(emailField.value.trim())) {
        errors.push('Proporciona un correo electrónico válido.');
      }

      if (!queryField.value.trim() || queryField.value.trim().length < 20) {
        errors.push('Describe tu consulta con al menos 20 caracteres.');
      }

      if (errors.length > 0) {
        formFeedback.className = 'form-feedback error';
        formFeedback.textContent = errors.join(' ');
        formFeedback.style.display = 'block';
      } else {
        formFeedback.className = 'form-feedback success';
        formFeedback.textContent = 'Gracias por escribirnos. Un especialista te contactará muy pronto.';
        formFeedback.style.display = 'block';
        contactForm.reset();
      }
    });
  }

  var budgetingForm = document.getElementById('budgeting-form');
  var budgetOutput = document.getElementById('budget-output');

  if (budgetingForm && budgetOutput) {
    var canvas = document.getElementById('budget-canvas');
    var context = canvas ? canvas.getContext('2d') : null;

    budgetingForm.addEventListener('submit', function (event) {
      event.preventDefault();

      var income = Number(document.getElementById('income').value);
      var housing = Number(document.getElementById('housing').value);
      var services = Number(document.getElementById('services').value);
      var food = Number(document.getElementById('food').value);
      var wellness = Number(document.getElementById('wellness').value);
      var savings = Number(document.getElementById('savings').value);

      if (income <= 0) {
        alert('El ingreso mensual debe ser mayor que cero.');
        return;
      }

      var totalExpenses = housing + services + food + wellness + savings;
      var remaining = income - totalExpenses;
      var ratio = income > 0 ? Math.round((savings / income) * 100) : 0;

      document.getElementById('remaining-amount').textContent = '$' + remaining.toLocaleString('es-MX');
      document.getElementById('allocation-ratio').textContent = ratio + '%';

      var status;
      if (remaining >= income * 0.15) {
        status = 'Presupuesto saludable';
      } else if (remaining >= 0) {
        status = 'Controlado, revisa ajustes';
      } else {
        status = 'Gasto excedido, prioriza recortes';
      }
      document.getElementById('warning-flag').textContent = status;

      updateProgressBar('bar-housing', housing, income);
      updateProgressBar('bar-services', services, income);
      updateProgressBar('bar-food', food, income);
      updateProgressBar('bar-wellness', wellness, income);
      updateProgressBar('bar-savings', savings, income);

      if (context) {
        drawBudgetChart(context, canvas.width, canvas.height, [
          { label: 'Vivienda', value: housing, color: '#2C9CDB' },
          { label: 'Servicios', value: services, color: '#FFB347' },
          { label: 'Alimentación', value: food, color: '#006778' },
          { label: 'Bienestar', value: wellness, color: '#6EA4BF' },
          { label: 'Respaldo', value: savings, color: '#F08A5D' }
        ]);
      }

      budgetOutput.hidden = false;
    });
  }

  function updateProgressBar(id, value, income) {
    var bar = document.getElementById(id);
    if (!bar) return;
    var percentage = income > 0 ? Math.min(100, Math.round((value / income) * 100)) : 0;
    bar.style.width = percentage + '%';
  }

  function drawBudgetChart(ctx, width, height, data) {
    ctx.clearRect(0, 0, width, height);
    var margin = 50;
    var chartWidth = width - margin * 2;
    var chartHeight = height - margin * 2;

    var maxValue = data.reduce(function (max, item) {
      return item.value > max ? item.value : max;
    }, 0);

    if (maxValue === 0) {
      ctx.fillStyle = '#808080';
      ctx.font = '16px Arial';
      ctx.fillText('Agrega cantidades para visualizar la distribución.', margin, height / 2);
      return;
    }

    var barWidth = chartWidth / data.length - 20;

    ctx.font = '14px Arial';
    data.forEach(function (item, index) {
      var barHeight = (item.value / maxValue) * chartHeight;
      var x = margin + index * (barWidth + 20);
      var y = height - margin - barHeight;

      ctx.fillStyle = item.color;
      ctx.roundRect ? ctx.roundRect(x, y, barWidth, barHeight, 8) : ctx.fillRect(x, y, barWidth, barHeight);
      if (ctx.roundRect) {
        ctx.fill();
      }

      ctx.fillStyle = '#2F2F2F';
      ctx.fillText('$' + item.value.toLocaleString('es-MX'), x, y - 8);
      ctx.fillText(item.label, x, height - margin + 20);
    });
  }

  var adjustmentForm = document.getElementById('adjustment-form');
  var adjustmentOutput = document.getElementById('adjustment-output');
  var adjustmentTableBody = document.getElementById('adjustment-table-body');

  if (adjustmentForm && adjustmentOutput && adjustmentTableBody) {
    adjustmentForm.addEventListener('submit', function (event) {
      event.preventDefault();

      var current = Number(document.getElementById('current-variable').value);
      var rate = Number(document.getElementById('reduction-rate').value);

      if (current <= 0 || rate < 0 || rate > 100) {
        alert('Verifica que los valores ingresados sean válidos.');
        return;
      }

      adjustmentTableBody.innerHTML = '';
      var accumulated = 0;
      var monthAmount = current;

      for (var month = 1; month <= 4; month++) {
        var reduction = monthAmount * (rate / 100);
        monthAmount = Math.max(0, monthAmount - reduction);
        accumulated += current - monthAmount;

        var row = document.createElement('tr');
        row.innerHTML = '<td>Mes ' + month + '</td>' +
          '<td>$' + monthAmount.toLocaleString('es-MX', { minimumFractionDigits: 2 }) + '</td>' +
          '<td>$' + accumulated.toLocaleString('es-MX', { minimumFractionDigits: 2 }) + '</td>';
        adjustmentTableBody.appendChild(row);
      }

      adjustmentOutput.hidden = false;
    });
  }
});