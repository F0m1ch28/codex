document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', function () {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navList.classList.toggle('nav-list-open');
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (!cookieBanner) {
        return;
    }

    const consentKey = 'uecrConsent';
    const storedConsent = localStorage.getItem(consentKey);

    if (storedConsent) {
        cookieBanner.classList.add('cookie-banner-hidden');
        document.body.dataset.consent = storedConsent;
    } else {
        cookieBanner.classList.remove('cookie-banner-hidden');
    }

    const acceptButton = cookieBanner.querySelector('.cookie-accept');
    const declineButton = cookieBanner.querySelector('.cookie-decline');

    if (acceptButton) {
        acceptButton.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'accepted');
            cookieBanner.classList.add('cookie-banner-hidden');
            document.body.dataset.consent = 'accepted';
        });
    }

    if (declineButton) {
        declineButton.addEventListener('click', function () {
            localStorage.setItem(consentKey, 'declined');
            cookieBanner.classList.add('cookie-banner-hidden');
            document.body.dataset.consent = 'declined';
        });
    }
});