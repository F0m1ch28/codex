document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.main-navigation');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAcceptBtn = document.getElementById('cookie-accept');
    const currentYearEl = document.getElementById('current-year');

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const isOpen = navigation.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        navigation.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navigation.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    }

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollTopBtn.style.display = 'grid';
        } else {
            scrollTopBtn.style.display = 'none';
        }
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const consentKey = 'qorendiCookieConsent';
    const hasConsent = localStorage.getItem(consentKey);

    if (!hasConsent) {
        cookieBanner.classList.add('active');
    }

    cookieAcceptBtn.addEventListener('click', () => {
        localStorage.setItem(consentKey, 'accepted');
        cookieBanner.classList.remove('active');
    });
});