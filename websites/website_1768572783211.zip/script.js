document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.navbar-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
        });

        navMenu.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-actions .accept');
    const declineBtn = document.querySelector('.cookie-actions .decline');

    if (cookieBanner) {
        const consent = localStorage.getItem('preferthvl_cookie_consent');
        if (consent) {
            cookieBanner.classList.add('hidden');
        }

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem('preferthvl_cookie_consent', 'accepted');
                cookieBanner.classList.add('hidden');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem('preferthvl_cookie_consent', 'declined');
                cookieBanner.classList.add('hidden');
            });
        }
    }
});