# Tu Progreso Hoy

Tu Progreso Hoy is a bilingual educational React website focused on Argentine financial literacy, inflation insights, and a personal finance starter course. It follows WCAG AA guidelines, includes double opt-in forms, cookie management, and legal compliance pages.

## Development

Install dependencies:

```bash
npm install
```

Run locally:

```bash
npm start
```

Build for production:

```bash
npm run build
```

Deploy to Netlify using the provided `netlify.toml`.

Note: Environment calls to `https://api.exchangerate.host` are client-side.

## Tech Stack

- React 18 with functional components and hooks
- React Router DOM v6
- React Helmet for metadata
- Vanilla CSS for styling

## Structure

- `/` Home with hero, ARS→USD tracker, insights, testimonials, and double opt-in form.
- `/inflation` Methodology, charts, CPI/FX context, FAQ.
- `/course` Course syllabus, modules, target audience, CTA anchor.
- `/resources` Articles and glossary references.
- `/contact` Map, form, social links.
- `/thank-you` Confirmation page.
- `/privacy`, `/cookies`, `/terms` Legal pages.
- `/sitemap.xml`, `/robots.txt` in public.

Ensure compliance with bilingual content requirements and disclaimers.