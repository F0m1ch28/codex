import React, { useState } from "react";

const FAQAccordion = ({ items }) => {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleIndex = (index) => {
    setOpenIndex((prev) => (prev === index ? null : index));
  };

  return (
    <div className="faq" role="region" aria-label="Frequently Asked Questions">
      {items.map((item, idx) => (
        <div key={item.question} className="faq__item">
          <button
            type="button"
            aria-expanded={openIndex === idx}
            className="faq__question"
            onClick={() => toggleIndex(idx)}
          >
            {item.question}
          </button>
          {openIndex === idx && (
            <div className="faq__answer">
              <p>{item.answer}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default FAQAccordion;