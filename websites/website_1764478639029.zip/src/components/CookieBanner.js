import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const status = window.localStorage.getItem("tph-cookie-consent");
    if (!status) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem("tph-cookie-consent", value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <p>
          We use cookies to understand how you interact with Tu Progreso Hoy.
          Accepting cookies helps us improve accessibility and analytics
          tracking. Puedes cambiar tu selección en cualquier momento.
        </p>
        <div className="cookie-banner__actions">
          <button type="button" onClick={() => handleConsent("declined")}>
            Decline
          </button>
          <button type="button" onClick={() => handleConsent("accepted")}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;