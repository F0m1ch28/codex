import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { Helmet } from "react-helmet";

const Layout = ({ children }) => {
  return (
    <div className="app-shell">
      <Helmet>
        <html lang="en" />
      </Helmet>
      <Navbar />
      <main className="main-content" role="main">
        {children}
      </main>
      <Footer />
    </div>
  );
};

export default Layout;