import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const toggleMenu = () => setMobileOpen(!mobileOpen);

  const closeMenu = () => setMobileOpen(false);

  return (
    <header className="navbar" aria-label="Main navigation">
      <div className="navbar-container">
        <Link to="/" className="logo" onClick={closeMenu}>
          <span className="logo__main">Tu Progreso Hoy</span>
          <span className="logo__tagline">Insights & Learning</span>
        </Link>
        <button
          type="button"
          className="navbar__toggle"
          aria-controls="primary-navigation"
          aria-expanded={mobileOpen}
          onClick={toggleMenu}
        >
          <span className="sr-only">Toggle navigation</span>
          <div className="navbar__toggle-line" />
          <div className="navbar__toggle-line" />
          <div className="navbar__toggle-line" />
        </button>
        <nav
          id="primary-navigation"
          className={`navbar__links ${mobileOpen ? "navbar__links--open" : ""}`}
        >
          <NavLink to="/" onClick={closeMenu}>
            Home
          </NavLink>
          <NavLink to="/inflation" onClick={closeMenu}>
            Inflation Insights
          </NavLink>
          <NavLink to="/course" onClick={closeMenu}>
            Course
          </NavLink>
          <NavLink to="/resources" onClick={closeMenu}>
            Resources
          </NavLink>
          <NavLink to="/contact" onClick={closeMenu}>
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;