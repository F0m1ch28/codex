import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const DoubleOptInForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    goal: "",
    language: "English"
  });
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    const nextErrors = {};
    if (!formData.fullName.trim()) {
      nextErrors.fullName = "Please enter your full name.";
    }
    if (!formData.email.trim()) {
      nextErrors.email = "Please enter your email address.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      nextErrors.email = "Please enter a valid email.";
    }
    if (!formData.goal.trim()) {
      nextErrors.goal = "Please describe your main learning goal.";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handlePrimarySubmit = (event) => {
    event.preventDefault();
    if (validateForm()) {
      setStep(2);
    }
  };

  const handleConfirm = () => {
    console.log("Double opt-in data:", formData);
    navigate("/thank-you");
  };

  const handleCancel = () => {
    setStep(1);
  };

  return (
    <div className="double-optin">
      <form onSubmit={handlePrimarySubmit} noValidate>
        <div className="form-group">
          <label htmlFor="fullName">Full name / Nombre completo</label>
          <input
            id="fullName"
            name="fullName"
            type="text"
            value={formData.fullName}
            onChange={handleChange}
            placeholder="Carolina Fernández"
            required
          />
          {errors.fullName && (
            <p className="form-error" role="alert">
              {errors.fullName}
            </p>
          )}
        </div>
        <div className="form-group">
          <label htmlFor="email">Email / Correo electrónico</label>
          <input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="carolina@example.com"
            required
          />
          {errors.email && (
            <p className="form-error" role="alert">
              {errors.email}
            </p>
          )}
        </div>
        <div className="form-group">
          <label htmlFor="goal">
            What do you want to learn? / ¿Qué deseas aprender?
          </label>
          <textarea
            id="goal"
            name="goal"
            value={formData.goal}
            onChange={handleChange}
            placeholder="Understand inflation dynamics and budgeting tactics."
            rows={4}
            required
          />
          {errors.goal && (
            <p className="form-error" role="alert">
              {errors.goal}
            </p>
          )}
        </div>
        <div className="form-group">
          <label htmlFor="language">
            Preferred language / Idioma preferido
          </label>
          <select
            id="language"
            name="language"
            value={formData.language}
            onChange={handleChange}
          >
            <option>English</option>
            <option>Español</option>
          </select>
        </div>
        <button type="submit" className="primary-button">
          Получить бесплатный пробный урок
        </button>
        <p className="double-optin__hint">
          Información confiable que respalda elecciones responsables sobre tu
          dinero. / Reliable information supporting responsible choices about
          your money.
        </p>
      </form>
      {step === 2 && (
        <div className="double-optin__modal" role="dialog" aria-modal="true">
          <div className="double-optin__modal-content">
            <h3>Confirm your subscription</h3>
            <p>
              We just sent a confirmation email to {formData.email}. Please
              confirm your interest in the free trial lesson. Once you have
              confirmed in your inbox, click the button below to finalize.
            </p>
            <button
              type="button"
              className="primary-button"
              onClick={handleConfirm}
            >
              I confirmed my email
            </button>
            <button type="button" className="secondary-button" onClick={handleCancel}>
              Go back
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DoubleOptInForm;