import React from "react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="footer">
    <div className="footer__grid">
      <div>
        <h3 className="footer__title">Tu Progreso Hoy</h3>
        <p className="footer__text">
          Datos verificados para planificar tu presupuesto. / Verified data to
          plan your budget.
        </p>
        <p className="footer__address">
          Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina
        </p>
        <a className="footer__link" href="tel:+541155551234">
          +54 11 5555-1234
        </a>
      </div>
      <div>
        <h4 className="footer__subtitle">Explore</h4>
        <ul className="footer__list">
          <li>
            <Link to="/inflation">Inflation Insights</Link>
          </li>
          <li>
            <Link to="/course">Course</Link>
          </li>
          <li>
            <Link to="/resources">Resources</Link>
          </li>
          <li>
            <Link to="/contact">Contact</Link>
          </li>
        </ul>
      </div>
      <div>
        <h4 className="footer__subtitle">Legal</h4>
        <ul className="footer__list">
          <li>
            <Link to="/privacy">Privacy Policy</Link>
          </li>
          <li>
            <Link to="/cookies">Cookies Policy</Link>
          </li>
          <li>
            <Link to="/terms">Terms of Service</Link>
          </li>
        </ul>
      </div>
      <div>
        <h4 className="footer__subtitle">Disclaimer</h4>
        <p className="footer__text">
          Plataforma educativa con datos esenciales, sin asesoría financiera
          directa. / Educational platform with essential data, no direct
          financial advice.
        </p>
        <p className="footer__text">
          Мы не предоставляем финансовые услуги. / We do not provide financial
          services. / No brindamos servicios financieros.
        </p>
      </div>
    </div>
    <div className="footer__bottom">
      <p>© {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</p>
      <p>
        Decisiones responsables, objetivos nítidos. / Responsible decisions,
        clear objectives.
      </p>
    </div>
  </footer>
);

export default Footer;