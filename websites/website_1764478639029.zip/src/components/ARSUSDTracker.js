import React, { useEffect, useState } from "react";

const API_URL =
  "https://api.exchangerate.host/latest?base=ARS&symbols=USD";

const ARSUSDTracker = () => {
  const [rate, setRate] = useState(null);
  const [timestamp, setTimestamp] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const response = await fetch(API_URL);
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        if (data && data.rates && data.rates.USD) {
          setRate(1 / data.rates.USD);
          setTimestamp(new Date(data.date));
        } else {
          throw new Error("Invalid data");
        }
      } catch (err) {
        setError("Live rate unavailable. Using illustrative value 0.0011.");
        setRate(0.0011);
        setTimestamp(new Date());
      }
    };
    fetchRate();
  }, []);

  return (
    <div className="tracker" aria-live="polite">
      <h3>ARS → USD Tracker</h3>
      {rate ? (
        <p className="tracker__rate">
          1 ARS ≈ {rate.toFixed(4)} USD
        </p>
      ) : (
        <p>Loading current rate...</p>
      )}
      {timestamp && (
        <p className="tracker__timestamp">
          Updated: {timestamp.toLocaleDateString()}{" "}
          {timestamp.toLocaleTimeString()}
        </p>
      )}
      {error && <p className="tracker__error">{error}</p>}
      <p className="tracker__context">
        Análisis transparentes y datos de mercado para decidir con seguridad.
      </p>
    </div>
  );
};

export default ARSUSDTracker;