import React, { useEffect, useState } from "react";

const PopupDisclaimer = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const seen = window.sessionStorage.getItem("tph-disclaimer-shown");
    if (!seen) {
      setOpen(true);
    }
  }, []);

  const closePopup = () => {
    window.sessionStorage.setItem("tph-disclaimer-shown", "true");
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="popup-overlay" role="dialog" aria-modal="true">
      <div className="popup">
        <h2>Important Notice</h2>
        <p>Мы не предоставляем финансовые услуги.</p>
        <p>We do not provide financial services.</p>
        <p>No brindamos servicios financieros.</p>
        <button type="button" onClick={closePopup} className="popup__close">
          Understood
        </button>
      </div>
    </div>
  );
};

export default PopupDisclaimer;