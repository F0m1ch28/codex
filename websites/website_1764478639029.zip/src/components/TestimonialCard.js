import React from "react";

const TestimonialCard = ({ quote, name, role }) => (
  <blockquote className="testimonial-card">
    <p>{quote}</p>
    <footer>
      <span className="testimonial-card__name">{name}</span>
      <span className="testimonial-card__role">{role}</span>
    </footer>
  </blockquote>
);

export default TestimonialCard;