import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
    consent: false
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const validate = () => {
    const nextErrors = {};
    if (!formData.name.trim()) {
      nextErrors.name = "Please enter your name.";
    }
    if (!formData.email.trim()) {
      nextErrors.email = "Please enter your email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      nextErrors.email = "Please provide a valid email.";
    }
    if (!formData.message.trim()) {
      nextErrors.message = "Please include a message.";
    }
    if (!formData.consent) {
      nextErrors.consent = "Please accept the communication consent.";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      console.log("Contact message:", formData);
      setSubmitted(true);
      setFormData({
        name: "",
        email: "",
        message: "",
        consent: false
      });
    }
  };

  return (
    <div className="page contact">
      <section className="section section--hero-sm">
        <div className="section__header">
          <h1>Contact / Contacto</h1>
          <p>
            Reach out to our Buenos Aires team for partnership, learning, or
            support questions.
          </p>
        </div>
      </section>

      <section className="section section--contact-grid">
        <div className="contact-card">
          <h2>Visit us</h2>
          <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
          <p>Phone: +54 11 5555-1234</p>
          <p>Email: hola@tuprogresohoy.com</p>
          <div className="contact-social">
            <a href="https://www.linkedin.com" aria-label="LinkedIn">
              LinkedIn
            </a>
            <a href="https://www.twitter.com" aria-label="X (Twitter)">
              X
            </a>
            <a href="https://www.instagram.com" aria-label="Instagram">
              Instagram
            </a>
          </div>
        </div>

        <div className="contact-form-wrapper">
          <h2>Message us / Escríbenos</h2>
          <form onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Name / Nombre</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
              />
              {errors.name && <p className="form-error">{errors.name}</p>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Email / Correo</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>
            <div className="form-group">
              <label htmlFor="message">Message / Mensaje</label>
              <textarea
                id="message"
                name="message"
                rows={5}
                value={formData.message}
                onChange={handleChange}
                required
              />
              {errors.message && <p className="form-error">{errors.message}</p>}
            </div>
            <div className="form-group form-group--checkbox">
              <input
                id="consent"
                name="consent"
                type="checkbox"
                checked={formData.consent}
                onChange={handleChange}
              />
              <label htmlFor="consent">
                I agree to receive communications related to Tu Progreso Hoy.
              </label>
            </div>
            {errors.consent && <p className="form-error">{errors.consent}</p>}
            <button type="submit" className="primary-button">
              Send message
            </button>
            {submitted && (
              <p className="form-success">
                Thank you for contacting us. Our team will reply soon.
              </p>
            )}
          </form>
        </div>
      </section>

      <section className="section section--map">
        <div className="map-container" aria-label="Map showing Buenos Aires office">
          <iframe
            title="Tu Progreso Hoy Buenos Aires"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3285.849669137825!2d-58.381591!3d-34.603684!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95a3352b0f8e3d45%3A0x4c5b8f27c1602040!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000"
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>
    </div>
  );
};

export default Contact;