import React from "react";
import { Link } from "react-router-dom";
import ARSUSDTracker from "../components/ARSUSDTracker";
import TestimonialCard from "../components/TestimonialCard";
import DoubleOptInForm from "../components/DoubleOptInForm";

const Home = () => {
  const testimonials = [
    {
      quote:
        "Tu Progreso Hoy gave me clarity on how inflation trends impact my day-to-day purchasing decisions. The bilingual content is precise and easy to follow.",
      name: "Lucía R.",
      role: "Product Designer, Córdoba"
    },
    {
      quote:
        "Con los análisis transparentes pude entender la brecha entre el ARS y el USD, y planificar mejor mis metas a mediano plazo.",
      name: "Martín G.",
      role: "Entrepreneur, Buenos Aires"
    },
    {
      quote:
        "I appreciated the data-driven charts and the practical course modules that focused on real Argentine scenarios.",
      name: "Carlos M.",
      role: "Operations Specialist, Mendoza"
    }
  ];

  const insights = [
    {
      title: "Datos verificados para planificar tu presupuesto.",
      description:
        "Our analysts compile official CPI releases, market expectations, and currency data to keep you posted on Argentina's evolving landscape."
    },
    {
      title: "Conocimiento financiero impulsado por tendencias.",
      description:
        "We highlight how structural changes, policy shifts, and regional indicators influence personal finance choices."
    },
    {
      title: "Pasos acertados hoy, mejor futuro mañana.",
      description:
        "Use curated learning paths and scenario-based exercises to take clear steps toward resilient budgeting."
    }
  ];

  const modules = [
    {
      title: "Module 1: Inflation Foundations",
      text:
        "Discover inflation mechanics, CPI interpretation, and how Argentina's economic cycles shape purchasing power."
    },
    {
      title: "Module 2: Currency Awareness",
      text:
        "Learn ARS→USD dynamics, forward-looking indicators, and risk mitigation strategies for everyday decisions."
    },
    {
      title: "Module 3: Personal Budget Planning",
      text:
        "Translate macro data into personal action plans with templates, case studies, and bilingual guidance."
    },
    {
      title: "Module 4: Monitoring & Adjustment",
      text:
        "Build routines to revisit data, adjust budgets, and respond responsibly to market developments."
    }
  ];

  const stats = [
    { label: "CPI YoY (Nov 2023)", value: "161%" },
    { label: "Blue USD (avg Nov 2023)", value: "ARS 880" },
    { label: "Monthly basket cost delta", value: "+12%" }
  ];

  return (
    <div className="page home">
      <section className="hero">
        <div className="hero__background" aria-hidden="true" />
        <div className="hero__content">
          <p className="hero__eyebrow">
            Análisis transparentes y datos de mercado para decidir con seguridad.
          </p>
          <h1>
            Empower your financial learning with Argentina-focused insights.
          </h1>
          <p className="hero__subtitle">
            Decisiones responsables, objetivos nítidos. / Responsible decisions,
            crystal clear objectives.
          </p>
          <div className="hero__cta-group">
            <Link to="/course" className="primary-button">
              Explore the course
            </Link>
            <Link to="/inflation" className="secondary-button">
              View inflation methodology
            </Link>
          </div>
          <ARSUSDTracker />
        </div>
      </section>

      <section className="section section--insights">
        <div className="section__header">
          <h2>From information to learning / De la información al aprendizaje</h2>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero
            paso a paso.
          </p>
        </div>
        <div className="cards-grid">
          {insights.map((item) => (
            <div key={item.title} className="card">
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section section--statistics">
        <div className="section__header">
          <h2>Argentina snapshot</h2>
          <p>
            These checkpoints guide our weekly updates. Each figure is sourced
            from official bulletins and market trackers.
          </p>
        </div>
        <div className="stats-grid">
          {stats.map((stat) => (
            <div key={stat.label} className="stat-card">
              <span className="stat-card__value">{stat.value}</span>
              <span className="stat-card__label">{stat.label}</span>
            </div>
          ))}
        </div>
        <p className="section__note">
          Information confiable que respalda elecciones responsables sobre tu
          dinero.
        </p>
      </section>

      <section className="section section--overview">
        <div className="section__header">
          <h2>Course overview / Visión general del curso</h2>
          <p>
            Conocimiento financiero impulsado por tendencias. Sigue las
            tendencias, identifica oportunidades y diseña tu ruta financiera.
          </p>
        </div>
        <div className="cards-grid cards-grid--modules">
          {modules.map((module) => (
            <div key={module.title} className="module-card">
              <h3>{module.title}</h3>
              <p>{module.text}</p>
            </div>
          ))}
        </div>
        <div className="section__cta">
          <Link to="/course" className="primary-button">
            Review full syllabus
          </Link>
        </div>
      </section>

      <section className="section section--testimonials">
        <div className="section__header">
          <h2>
            Trusted by learners across Argentina / Confiado por estudiantes en
            Argentina
          </h2>
          <p>
            Plataforma educativa con datos esenciales, sin asesoría financiera
            directa.
          </p>
        </div>
        <div className="testimonials-grid">
          {testimonials.map((testimonial) => (
            <TestimonialCard key={testimonial.name} {...testimonial} />
          ))}
        </div>
      </section>

      <section className="section section--form" id="free-trial">
        <div className="section__header">
          <h2>Получить бесплатный пробный урок</h2>
          <p>
            Pasos acertados hoy, mejor futuro mañana. / Take the right steps
            today for a better tomorrow.
          </p>
        </div>
        <DoubleOptInForm />
      </section>
    </div>
  );
};

export default Home;