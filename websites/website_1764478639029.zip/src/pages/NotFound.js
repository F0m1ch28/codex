import React from "react";
import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="page not-found">
    <section className="section section--hero-sm">
      <div className="section__header">
        <h1>Page not found</h1>
        <p>
          The page you are looking for might have been moved. Return to the home page for the latest information.
        </p>
        <Link to="/" className="primary-button">
          Back to home
        </Link>
      </div>
    </section>
  </div>
);

export default NotFound;