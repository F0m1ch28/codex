import React from "react";

const Cookies = () => (
  <div className="page legal">
    <section className="section section--hero-sm">
      <div className="section__header">
        <h1>Cookies Policy</h1>
        <p>
          This Cookies Policy explains how Tu Progreso Hoy uses cookies and similar technologies.
        </p>
      </div>
    </section>
    <section className="section section--legal-text">
      <article>
        <h2>1. What Are Cookies?</h2>
        <p>
          Cookies are small text files stored on your device to support essential functionality and analytics.
        </p>

        <h2>2. Types of Cookies We Use</h2>
        <ul>
          <li>Necessary cookies for security and session management.</li>
          <li>Analytics cookies to understand page performance.</li>
          <li>Preference cookies to remember language selection.</li>
        </ul>

        <h2>3. Managing Cookies</h2>
        <p>
          You can control cookies via browser settings and our on-site cookie banner. Declining may limit some functionality.
        </p>

        <h2>4. Third-Party Services</h2>
        <p>
          We may use analytics providers that collect aggregated statistics. They do not receive contact details submitted via forms.
        </p>

        <h2>5. Updates</h2>
        <p>
          Changes to this policy will be reflected with an updated revision date.
        </p>

        <h2>6. Contact</h2>
        <p>
          For questions about cookies email privacy@tuprogresohoy.com.
        </p>
      </article>
    </section>
  </div>
);

export default Cookies;