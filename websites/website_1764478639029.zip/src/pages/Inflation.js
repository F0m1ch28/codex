import React from "react";
import FAQAccordion from "../components/FAQAccordion";

const Inflation = () => {
  const methodologyPoints = [
    {
      heading: "Data Sources",
      text:
        "We merge Instituto Nacional de Estadística y Censos (INDEC) CPI reports with high-frequency price trackers and FX observations sourced from reputable Argentine financial bulletins."
    },
    {
      heading: "Calculation Cadence",
      text:
        "Weekly updates capture consumer basket variations, while monthly summaries provide context for long-term budgeting strategies."
    },
    {
      heading: "Scenario Analysis",
      text:
        "We compare official CPI movements with blue-chip swap and blue market indicators, offering commentary on spread implications."
    },
    {
      heading: "Currency Overlay",
      text:
        "ARS→USD tracker integrates live spot data, central bank communication, and consensus forecasts to show possible paths for the peso."
    }
  ];

  const faqItems = [
    {
      question: "How often are inflation dashboards updated?",
      answer:
        "We refresh CPI-linked dashboards weekly, aligning with new data releases and market surveys. Summaries include Spanish and English highlights."
    },
    {
      question: "Do you provide investment advice?",
      answer:
        "No. Tu Progreso Hoy is an educational platform. Plataforma educativa con datos esenciales, sin asesoría financiera directa."
    },
    {
      question: "What metrics appear in the ARS→USD tracker?",
      answer:
        "The tracker visualizes the indicative spot rate, historical averages, and commentary on spreads relevant to household budgeting."
    },
    {
      question: "Is historical CPI data available for download?",
      answer:
        "Subscribers receive CSV downloads covering the last 36 months of CPI categories, curated for budgeting simulations."
    }
  ];

  return (
    <div className="page inflation">
      <section className="section section--hero-sm">
        <div className="section__header">
          <h1>Inflation methodology & dashboards</h1>
          <p>
            Datos verificados para planificar tu presupuesto. Our methodology
            brings together transparent calculations and contextual narratives.
          </p>
        </div>
      </section>

      <section className="section section--methodology">
        <div className="section__header">
          <h2>Methodology pillars / Pilares metodológicos</h2>
          <p>
            Análisis transparentes y datos de mercado para decidir con
            seguridad. Each pillar is documented in bilingual briefs.
          </p>
        </div>
        <div className="cards-grid">
          {methodologyPoints.map((item) => (
            <div key={item.heading} className="card card--method">
              <h3>{item.heading}</h3>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section section--charts">
        <div className="section__header">
          <h2>Visual dashboards / Tableros visuales</h2>
          <p>
            Use our CPI trend lines, FX comparisons, and projection charts to
            evaluate monthly and quarterly scenarios.
          </p>
        </div>
        <div className="chart-placeholder" role="img" aria-label="Inflation and FX chart preview">
          <div className="chart-placeholder__line chart-placeholder__line--cpi" />
          <div className="chart-placeholder__line chart-placeholder__line--fx" />
          <p>CPI vs ARS→USD illustrative trend 2022-2024</p>
        </div>
        <p className="section__note">
          Chart references include year-over-year CPI, monthly inflation, and
          comparative FX rates. Conocimiento financiero impulsado por
          tendencias.
        </p>
      </section>

      <section className="section section--context">
        <div className="section__header">
          <h2>CPI and FX context / Contexto IPC y FX</h2>
        </div>
        <div className="context-grid">
          <div>
            <h3>CPI breakdowns</h3>
            <p>
              Monitor food, housing, transport, and education weights. Each
              category includes commentary about significant drivers.
            </p>
          </div>
          <div>
            <h3>Currency narratives</h3>
            <p>
              Sigue las tendencias, identifica oportunidades y diseña tu ruta
              financiera. We summarize policy changes, liquidity measures, and
              sentiment without offering trading recommendations.
            </p>
          </div>
          <div>
            <h3>Responsible decisions</h3>
            <p>
              Información confiable que respalda elecciones responsables sobre
              tu dinero. Our dashboard alerts highlight emerging changes in
              expenses so you can adapt budgets responsibly.
            </p>
          </div>
        </div>
      </section>

      <section className="section section--faq">
        <div className="section__header">
          <h2>FAQ</h2>
          <p>Preguntas frecuentes sobre nuestro sistema de seguimiento.</p>
        </div>
        <FAQAccordion items={faqItems} />
      </section>
    </div>
  );
};

export default Inflation;