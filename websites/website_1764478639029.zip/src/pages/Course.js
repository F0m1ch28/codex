import React from "react";
import { Link } from "react-router-dom";

const modules = [
  {
    title: "Module 1 · Inflation Fundamentals",
    duration: "2 hours",
    topics: [
      "Understanding inflation drivers in Argentina",
      "Reading CPI bulletins in English and Spanish",
      "Laboratory: interpreting monthly data releases"
    ]
  },
  {
    title: "Module 2 · Peso to Dollar Awareness",
    duration: "2.5 hours",
    topics: [
      "Currency regimes and historical perspective",
      "ARS→USD tracker deep dive",
      "Scenario planning for household budgeting"
    ]
  },
  {
    title: "Module 3 · Budget Skills",
    duration: "3 hours",
    topics: [
      "Building a bilingual budget template",
      "Coping with price volatility",
      "Case studies from Argentina's major cities"
    ]
  },
  {
    title: "Module 4 · Monitoring & Reflection",
    duration: "1.5 hours",
    topics: [
      "Setting responsible review routines",
      "Updating personal objectives with new data",
      "Checklist for ongoing learning"
    ]
  }
];

const audience = [
  {
    title: "Professionals",
    description:
      "Managers, analysts, and freelancers seeking clarity on how macro shifts affect their purchasing power."
  },
  {
    title: "Families",
    description:
      "Caregivers designing budgets that balance essentials, savings, and education expenses."
  },
  {
    title: "Students",
    description:
      "Learners developing financial literacy with real Argentine case studies and bilingual support."
  }
];

const Course = () => (
  <div className="page course">
    <section className="section section--hero-sm">
      <div className="section__header">
        <h1>Course syllabus / Programa del curso</h1>
        <p>
          Plataforma educativa con datos esenciales, sin asesoría financiera
          directa. Pasos acertados hoy, mejor futuro mañana.
        </p>
      </div>
    </section>

    <section className="section section--modules">
      <div className="section__header">
        <h2>Modules / Módulos</h2>
        <p>
          Datos verificados para planificar tu presupuesto. Each module blends
          theory, bilingual glossaries, and practical challenges.
        </p>
      </div>
      <div className="module-list">
        {modules.map((module) => (
          <div key={module.title} className="module-list__item">
            <div className="module-list__header">
              <h3>{module.title}</h3>
              <span className="module-list__duration">{module.duration}</span>
            </div>
            <ul>
              {module.topics.map((topic) => (
                <li key={topic}>{topic}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>

    <section className="section section--audience">
      <div className="section__header">
        <h2>Who is it for? / ¿Para quién?</h2>
        <p>
          Conocimiento financiero impulsado por tendencias. Connect with peers
          navigating Argentina's dynamic economic context.
        </p>
      </div>
      <div className="cards-grid">
        {audience.map((item) => (
          <div key={item.title} className="card">
            <h3>{item.title}</h3>
            <p>{item.description}</p>
          </div>
        ))}
      </div>
    </section>

    <section className="section section--cta-anchor">
      <div className="cta-card">
        <h2>Ready to start? / ¿Listo para comenzar?</h2>
        <p>
          De la información al aprendizaje: fortalece tu criterio financiero
          paso a paso. Click below to request your free trial lesson and head to
          the form at the bottom of the home page.
        </p>
        <Link to="/#free-trial" className="primary-button">
          Request the free trial lesson
        </Link>
      </div>
    </section>
  </div>
);

export default Course;