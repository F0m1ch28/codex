import React from "react";

const Privacy = () => (
  <div className="page legal">
    <section className="section section--hero-sm">
      <div className="section__header">
        <h1>Privacy Policy</h1>
        <p>
          This Privacy Policy explains how Tu Progreso Hoy collects, uses, and
          protects personal information.
        </p>
      </div>
    </section>

    <section className="section section--legal-text">
      <article>
        <h2>1. Information We Collect</h2>
        <p>
          We collect contact details provided through website forms, analytics
          data regarding site usage, and preferences related to language and
          resource interests.
        </p>

        <h2>2. How We Use Information</h2>
        <p>
          Personal data is used to deliver educational communications, respond
          to inquiries, and improve our services. We do not sell personal data.
        </p>

        <h2>3. Data Security</h2>
        <p>
          We implement administrative and technical safeguards to protect data.
          Access is limited to authorized staff.
        </p>

        <h2>4. International Transfers</h2>
        <p>
          Data may be processed outside Argentina when working with service
          providers. We require adequate protections for such transfers.
        </p>

        <h2>5. Your Rights</h2>
        <p>
          You may request access, correction, or deletion of stored data by
          contacting privacy@tuprogresohoy.com.
        </p>

        <h2>6. Cookies</h2>
        <p>
          Cookies help us analyze website interactions. You can accept or decline via our cookie banner.
        </p>

        <h2>7. Updates</h2>
        <p>
          We may update this policy periodically and will post a revised date.
        </p>

        <h2>8. Contact</h2>
        <p>
          For privacy questions, email privacy@tuprogresohoy.com or write to our Buenos Aires office.
        </p>
      </article>
    </section>
  </div>
);

export default Privacy;