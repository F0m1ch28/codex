import React from "react";
import { Link } from "react-router-dom";

const ThankYou = () => (
  <div className="page thank-you">
    <section className="section section--hero-sm">
      <div className="section__header">
        <h1>Thank you / Gracias</h1>
        <p>
          A confirmation email is on its way. Please click the verification link
          to activate your free trial lesson request.
        </p>
        <p>
          Datos verificados para planificar tu presupuesto. Stay tuned for
          bilingual updates.
        </p>
      </div>
      <Link to="/" className="primary-button">
        Return to homepage
      </Link>
    </section>
  </div>
);

export default ThankYou;