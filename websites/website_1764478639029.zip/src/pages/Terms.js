import React from "react";

const Terms = () => (
  <div className="page legal">
    <section className="section section--hero-sm">
      <div className="section__header">
        <h1>Terms of Service</h1>
        <p>
          The Terms of Service govern your use of Tu Progreso Hoy.
        </p>
      </div>
    </section>

    <section className="section section--legal-text">
      <article>
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing our website, you agree to these Terms and all applicable laws and regulations.
        </p>

        <h2>2. Educational Purpose</h2>
        <p>
          The platform provides educational content only. Мы не предоставляем финансовые услуги.
        </p>

        <h2>3. User Responsibilities</h2>
        <p>
          You must supply accurate information, respect intellectual property, and use the site responsibly.
        </p>

        <h2>4. Intellectual Property</h2>
        <p>
          All content, graphics, and materials are owned by Tu Progreso Hoy unless otherwise stated.
        </p>

        <h2>5. Limitation of Liability</h2>
        <p>
          We are not liable for decisions made based on the information provided. Always evaluate information with care.
        </p>

        <h2>6. Modifications</h2>
        <p>
          We may update services or terms at any time. Continued use signifies acceptance of changes.
        </p>

        <h2>7. Governing Law</h2>
        <p>
          These terms are governed by the laws of Argentina.
        </p>

        <h2>8. Contact</h2>
        <p>
          For questions regarding these Terms contact legal@tuprogresohoy.com.
        </p>
      </article>
    </section>
  </div>
);

export default Terms;