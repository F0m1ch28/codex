import React from "react";

const resources = [
  {
    title: "Glossary: Argentine Inflation Terms (EN/ES)",
    description:
      "Short bilingual explanations of CPI components, wage agreements, and monetary policy concepts.",
    link: "#glossary"
  },
  {
    title: "Article: Building a responsible budget",
    description:
      "Strategies for balancing essentials and savings when inflation accelerates.",
    link: "#budget-article"
  },
  {
    title: "Article: Understanding FX spreads in Argentina",
    description:
      "Overview of official vs. market rates with practical implications for households.",
    link: "#fx-article"
  },
  {
    title: "Checklist: Monthly financial review",
    description:
      "Step-by-step tasks to monitor expenses, update forecasts, and stay informed.",
    link: "#checklist"
  }
];

const Resources = () => (
  <div className="page resources">
    <section className="section section--hero-sm">
      <div className="section__header">
        <h1>Resources / Recursos</h1>
        <p>
          Knowledge library curated in English and Spanish to strengthen your
          financial decision-making. Información confiable que respalda
          elecciones responsables sobre tu dinero.
        </p>
      </div>
    </section>

    <section className="section section--resource-list">
      <ul className="resource-list">
        {resources.map((item) => (
          <li key={item.title} className="resource-list__item" id={item.link.substring(1)}>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
            <a href={item.link} className="resource-list__link">
              Download / Descargar
            </a>
          </li>
        ))}
      </ul>
      <div className="resource-note">
        <p>
          Sigue las tendencias, identifica oportunidades y diseña tu ruta
          financiera. Resources are updated quarterly, with bilingual versions
          for clarity.
        </p>
      </div>
    </section>
  </div>
);

export default Resources;