import React from "react";
import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Inflation from "./pages/Inflation";
import Course from "./pages/Course";
import Resources from "./pages/Resources";
import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import Privacy from "./pages/Privacy";
import Cookies from "./pages/Cookies";
import Terms from "./pages/Terms";
import NotFound from "./pages/NotFound";
import CookieBanner from "./components/CookieBanner";
import PopupDisclaimer from "./components/PopupDisclaimer";

function App() {
  return (
    <>
      <PopupDisclaimer />
      <CookieBanner />
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/inflation" element={<Inflation />} />
          <Route path="/course" element={<Course />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/cookies" element={<Cookies />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
    </>
  );
}

export default App;