document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      navToggle.classList.toggle("is-active");
      siteNav.classList.toggle("is-open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute("aria-expanded", "false");
          navToggle.classList.remove("is-active");
          siteNav.classList.remove("is-open");
        }
      });
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const preferenceKey = "marketInsightCookiePreference";

  if (cookieBanner) {
    const storedPreference = localStorage.getItem(preferenceKey);
    if (!storedPreference) {
      cookieBanner.classList.add("is-visible");
    }

    cookieBanner.querySelectorAll("[data-cookie]").forEach((button) => {
      button.addEventListener("click", (event) => {
        const action = event.currentTarget.getAttribute("data-cookie");
        localStorage.setItem(preferenceKey, action);
        cookieBanner.classList.remove("is-visible");
      });
    });
  }
});