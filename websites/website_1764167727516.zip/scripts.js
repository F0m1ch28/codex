const navToggle = document.querySelector('.nav-toggle');
const siteNav = document.querySelector('.site-nav');

if (navToggle) {
    navToggle.addEventListener('click', () => {
        siteNav.classList.toggle('open');
    });
}

const cookieBanner = document.querySelector('.cookie-banner');
const cookieAccept = document.querySelector('#cookie-accept');
const cookieDecline = document.querySelector('#cookie-decline');

if (cookieBanner && cookieAccept && cookieDecline) {
    const consent = localStorage.getItem('ellivandoraConsent');
    if (!consent) {
        setTimeout(() => cookieBanner.classList.add('active'), 800);
    }

    cookieAccept.addEventListener('click', () => {
        localStorage.setItem('ellivandoraConsent', 'accepted');
        cookieBanner.classList.remove('active');
    });

    cookieDecline.addEventListener('click', () => {
        localStorage.setItem('ellivandoraConsent', 'declined');
        cookieBanner.classList.remove('active');
    });
}

document.addEventListener('click', (event) => {
    if (!siteNav.contains(event.target) && !navToggle.contains(event.target)) {
        siteNav.classList.remove('open');
    }
});