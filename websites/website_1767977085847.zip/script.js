document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            document.body.classList.toggle('nav-open');
        });
    }

    const navLinks = document.querySelectorAll('.site-nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            document.body.classList.remove('nav-open');
        });
    });

    const searchField = document.querySelector('[data-search]');
    const filterButtons = document.querySelectorAll('[data-filter]');
    const filterCards = document.querySelectorAll('[data-categories]');

    let activeFilter = 'all';

    function applyFilters() {
        const query = searchField ? searchField.value.trim().toLowerCase() : '';
        filterCards.forEach(card => {
            const categories = card.dataset.categories || '';
            const title = card.querySelector('h3') ? card.querySelector('h3').textContent.toLowerCase() : '';
            const summary = card.querySelector('p') ? card.querySelector('p').textContent.toLowerCase() : '';
            const matchesFilter = activeFilter === 'all' || categories.split(',').map(item => item.trim()).includes(activeFilter);
            const matchesSearch = !query || title.includes(query) || summary.includes(query);
            if (matchesFilter && matchesSearch) {
                card.classList.remove('hidden');
            } else {
                card.classList.add('hidden');
            }
        });
    }

    if (searchField) {
        searchField.addEventListener('input', applyFilters);
    }

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            activeFilter = button.dataset.filter || 'all';
            applyFilters();
        });
    });

    applyFilters();

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const cookiePreference = localStorage.getItem('cio_cookie_pref');
        if (!cookiePreference) {
            cookieBanner.classList.add('active');
        }

        const cookieButtons = cookieBanner.querySelectorAll('[data-consent]');
        cookieButtons.forEach(btn => {
            btn.addEventListener('click', event => {
                event.preventDefault();
                const value = btn.dataset.consent;
                localStorage.setItem('cio_cookie_pref', value);
                cookieBanner.classList.remove('active');
                const targetLink = btn.getAttribute('href');
                if (targetLink) {
                    window.location.href = targetLink;
                }
            });
        });
    }

    const yearTargets = document.querySelectorAll('[data-year]');
    const currentYear = new Date().getFullYear();
    yearTargets.forEach(el => {
        el.textContent = currentYear;
    });
});