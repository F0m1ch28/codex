document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  const navLinks = document.querySelectorAll('.site-nav a');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('open');
      siteNav.classList.toggle('open');
      document.body.classList.toggle('nav-open');
    });

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.classList.remove('open');
        siteNav.classList.remove('open');
        document.body.classList.remove('nav-open');
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  const cookieKey = 'ais-cookie-consent';

  const setCookiePreference = (value) => {
    localStorage.setItem(cookieKey, value);
    if (cookieBanner) {
      cookieBanner.classList.remove('visible');
    }
  };

  if (cookieBanner) {
    const savedPreference = localStorage.getItem(cookieKey);
    if (!savedPreference) {
      cookieBanner.classList.add('visible');
    }

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => setCookiePreference('accepted'));
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', () => setCookiePreference('declined'));
    }
  }

  const contactForm = document.getElementById('contact-form');
  const formMessage = document.getElementById('form-message');

  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      if (!contactForm.checkValidity()) {
        event.preventDefault();
        contactForm.classList.add('show-errors');
        contactForm.reportValidity();
        if (formMessage) {
          formMessage.textContent = 'Please complete all required fields before submitting.';
          formMessage.classList.remove('success');
          formMessage.classList.add('error');
        }
      } else {
        event.preventDefault();
        if (formMessage) {
          formMessage.textContent = 'Thank you. Our analytics consultants will respond within one business day.';
          formMessage.classList.remove('error');
          formMessage.classList.add('success');
          formMessage.focus?.();
        }
        contactForm.reset();
        contactForm.classList.remove('show-errors');
      }
    });
  }
});