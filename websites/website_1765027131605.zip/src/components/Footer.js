import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-column">
          <div className="logo-footer">
            <span className="logo-mark">AD</span>
            <div className="logo-text">
              <span className="logo-title">Aurora Dynamics</span>
              <span className="logo-subtitle">Digital Transformation</span>
            </div>
          </div>
          <p className="footer-description">
            We architect bold digital experiences and future-ready ecosystems that accelerate growth, resilience, and customer delight.
          </p>
          <div className="footer-social">
            <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
              LinkedIn
            </a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
              Twitter
            </a>
            <a href="https://dribbble.com" target="_blank" rel="noopener noreferrer">
              Dribbble
            </a>
          </div>
        </div>
        <div className="footer-column">
          <h4>Company</h4>
          <Link to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link to="/contact">Contact</Link>
          <a href="#projects">Projects</a>
        </div>
        <div className="footer-column">
          <h4>Resources</h4>
          <a href="#blog">Insights</a>
          <a href="#faq">Support</a>
          <a href="#process">Process</a>
          <a href="#team">Leadership</a>
        </div>
        <div className="footer-column">
          <h4>Legal</h4>
          <Link to="/privacy">Privacy Policy</Link>
          <Link to="/terms">Terms &amp; Conditions</Link>
          <a href="mailto:hello@auroradynamics.com">hello@auroradynamics.com</a>
          <p>+1 (415) 555-0134</p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {currentYear} Aurora Dynamics. All rights reserved.</p>
        <div className="footer-bottom-links">
          <Link to="/privacy">Privacy</Link>
          <Link to="/terms">Terms</Link>
          <a href="#top" className="back-to-top">
            Back to top
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;