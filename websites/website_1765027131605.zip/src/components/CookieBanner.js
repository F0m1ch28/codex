import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("aurora-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("aurora-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="region" aria-label="Cookie consent banner">
      <div>
        <h4>We value your privacy</h4>
        <p>
          We use cookies to personalize content, enhance your browsing experience, and analyze our traffic. You can review our{" "}
          <a href="/privacy">privacy policy</a> for more details.
        </p>
      </div>
      <button className="btn btn-primary" onClick={acceptCookies}>
        Accept &amp; Continue
      </button>
    </div>
  );
};

export default CookieBanner;