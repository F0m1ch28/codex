import React, { useState, useEffect } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
      <div className="container header-container">
        <Link to="/" className="logo">
          <span className="logo-mark">AD</span>
          <div className="logo-text">
            <span className="logo-title">Aurora Dynamics</span>
            <span className="logo-subtitle">Innovation. Strategy. Impact.</span>
          </div>
        </Link>
        <nav className={`main-nav ${menuOpen ? "main-nav--open" : ""}`} aria-label="Primary">
          <NavLink to="/" end className="nav-link">
            Home
          </NavLink>
          <NavLink to="/about" className="nav-link">
            About
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact
          </NavLink>
        </nav>
        <div className="header-actions">
          <Link to="/contact" className="btn btn-outline btn-small">
            Schedule a Call
          </Link>
          <button
            className={`menu-toggle ${menuOpen ? "menu-toggle--active" : ""}`}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-label="Toggle navigation"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;