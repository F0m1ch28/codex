import React from "react";

const Privacy = () => {
  return (
    <section className="inner-page legal-page">
      <div className="container narrow">
        <h1>Privacy Policy</h1>
        <p>Effective date: March 15, 2024</p>

        <h2>Information we collect</h2>
        <p>
          We collect personal information you provide (such as name, email, company, and project details) when submitting inquiries. We also gather analytical data to understand website usage.
        </p>

        <h2>How we use information</h2>
        <p>
          Information is used to respond to inquiries, deliver services, personalize experiences, and improve our offerings. We do not sell personal information to third parties.
        </p>

        <h2>Cookies</h2>
        <p>
          Cookies enhance your browsing experience and help us analyze traffic. You can manage preferences through your browser settings or via our cookie banner.
        </p>

        <h2>Data security</h2>
        <p>
          We implement administrative, technical, and physical safeguards to protect personal information. However, no method is entirely secure, and we encourage best practices from users.
        </p>

        <h2>Your rights</h2>
        <p>
          Depending on your jurisdiction, you may request access, correction, or deletion of your personal information. Contact us at <a href="mailto:privacy@auroradynamics.com">privacy@auroradynamics.com</a>.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this policy to reflect changes in practices or regulations. Review this page periodically for the latest information.
        </p>
      </div>
    </section>
  );
};

export default Privacy;