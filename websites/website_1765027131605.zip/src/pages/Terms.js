import React from "react";

const Terms = () => {
  return (
    <section className="inner-page legal-page">
      <div className="container narrow">
        <h1>Terms &amp; Conditions</h1>
        <p>Last updated: March 15, 2024</p>

        <h2>1. Acceptance of terms</h2>
        <p>
          By accessing or using the Aurora Dynamics website, you agree to these Terms &amp; Conditions and our Privacy Policy. If you do not agree, please discontinue use immediately.
        </p>

        <h2>2. Services</h2>
        <p>
          Our website provides information about our digital transformation services. Any proposals, contracts, or statements of work will define the specific terms governing client engagements.
        </p>

        <h2>3. Intellectual property</h2>
        <p>
          All content, logos, and materials on this website are owned by Aurora Dynamics or our partners. You may not reproduce or distribute any materials without written permission.
        </p>

        <h2>4. Limitation of liability</h2>
        <p>
          Aurora Dynamics is not liable for any indirect, incidental, or consequential damages arising from the use of this website or services, to the fullest extent permitted by law.
        </p>

        <h2>5. Governing law</h2>
        <p>
          These terms are governed by the laws of the State of California, without regard to its conflict of law provisions.
        </p>

        <h2>6. Updates</h2>
        <p>
          We may revise these terms periodically. The updated date will reflect at the top of this page. Continued use indicates acceptance of the revised terms.
        </p>

        <p>
          For questions, please contact us at <a href="mailto:legal@auroradynamics.com">legal@auroradynamics.com</a>.
        </p>
      </div>
    </section>
  );
};

export default Terms;