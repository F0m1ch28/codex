import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    email: "",
    message: "",
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your full name.";
    if (!formData.company.trim()) newErrors.company = "Please enter your company name.";
    if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = "Please enter a valid email address.";
    if (formData.message.trim().length < 20) newErrors.message = "Tell us a bit more (minimum 20 characters).";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    setFormData((prev) => ({ ...prev, [event.target.name]: event.target.value }));
    if (errors[event.target.name]) {
      setErrors((prev) => ({ ...prev, [event.target.name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
  };

  return (
    <section className="inner-page">
      <div className="container narrow">
        <span className="badge">Get in touch</span>
        <h1>Let’s design the next chapter of your digital journey.</h1>
        <p>
          Share your goals, challenges, and aspirations. We’ll follow up within one business day to align on next steps and tailor the right engagement for your team.
        </p>

        {submitted ? (
          <div className="form-success">
            <h2>Thank you!</h2>
            <p>
              We’ve received your message and will reach out shortly with available times for a strategy session. Looking forward to connecting.
            </p>
          </div>
        ) : (
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Full name</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Alex Morgan"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={!!errors.name}
              />
              {errors.name && <span className="error-text">{errors.name}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="company">Company</label>
              <input
                id="company"
                name="company"
                type="text"
                placeholder="Your organization"
                value={formData.company}
                onChange={handleChange}
                aria-invalid={!!errors.company}
              />
              {errors.company && <span className="error-text">{errors.company}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="email">Work email</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="name@company.com"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={!!errors.email}
              />
              {errors.email && <span className="error-text">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="message">Project details</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                placeholder="Tell us about your goals, challenges, and timeline."
                value={formData.message}
                onChange={handleChange}
                aria-invalid={!!errors.message}
              />
              {errors.message && <span className="error-text">{errors.message}</span>}
            </div>

            <button type="submit" className="btn btn-primary">
              Submit inquiry
            </button>
          </form>
        )}

        <section className="contact-meta">
          <div>
            <h3>Global headquarters</h3>
            <p>108 Market Street, Suite 900<br />San Francisco, CA 94105</p>
          </div>
          <div>
            <h3>Contact</h3>
            <p>hello@auroradynamics.com<br />+1 (415) 555-0134</p>
          </div>
          <div>
            <h3>Follow</h3>
            <p>
              <a href="https://www.linkedin.com">LinkedIn</a> · <a href="https://twitter.com">Twitter</a> ·{" "}
              <a href="https://www.instagram.com">Instagram</a>
            </p>
          </div>
        </section>
      </div>
    </section>
  );
};

export default Contact;