import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";

const statsData = [
  { label: "Projects Delivered", value: 240 },
  { label: "Client Satisfaction", value: 98, suffix: "%" },
  { label: "Average ROI", value: 320, suffix: "%" },
  { label: "Partners Worldwide", value: 42 },
];

const servicesData = [
  {
    title: "Digital Strategy & Advisory",
    description: "Translate ambitious goals into measurable digital roadmaps with data-backed strategic advisory.",
    icon: "🧭",
  },
  {
    title: "Experience Design",
    description: "Design human-centered experiences that blend intuition with measurable business outcomes.",
    icon: "🎨",
  },
  {
    title: "Cloud & Platform Engineering",
    description: "Build resilient, scalable architectures that empower teams and customers alike.",
    icon: "☁️",
  },
  {
    title: "AI-Driven Innovation",
    description: "Leverage machine intelligence to unlock predictive, personalized, and automated capabilities.",
    icon: "🤖",
  },
];

const processSteps = [
  {
    step: "01",
    title: "Discover & Align",
    description: "Deep-dive workshops to uncover opportunities, align stakeholders, and clarify intended outcomes.",
  },
  {
    step: "02",
    title: "Co-Create & Prototype",
    description: "Concept validation, prototyping, and iterative design sprints to reduce risk and accelerate value.",
  },
  {
    step: "03",
    title: "Build & Integrate",
    description: "Full-stack development, integrations, and rigorous QA to ensure performance at scale.",
  },
  {
    step: "04",
    title: "Launch & Optimize",
    description: "Continuous improvement cycles supported by analytics, experimentation, and proactive enhancements.",
  },
];

const testimonials = [
  {
    quote:
      "Aurora Dynamics delivered transformative outcomes for our digital ecosystem. Their team became an extension of ours, elevating both strategy and execution.",
    name: "Charlotte Nguyen",
    role: "Chief Digital Officer, Horizon Bank",
  },
  {
    quote:
      "The combination of vision, technical excellence, and deep empathy for our customers made Aurora the ideal innovation partner.",
    name: "Michael Patel",
    role: "VP Product, Stratos Labs",
  },
  {
    quote:
      "From discovery to launch, they infused clarity and momentum. We exceeded our KPIs within the first quarter of deployment.",
    name: "Isabel Romero",
    role: "Head of Experience, Pathway Health",
  },
];

const teamMembers = [
  {
    name: "Elena Torres",
    role: "Chief Vision Officer",
    bio: "Leads strategic innovation with two decades of experience across fintech and emerging tech ventures.",
    image: "https://picsum.photos/400/400?random=3",
  },
  {
    name: "Noah Henderson",
    role: "Director of Engineering",
    bio: "Architects scalable platforms and champions engineering excellence across global teams.",
    image: "https://picsum.photos/401/401?random=33",
  },
  {
    name: "Priya Desai",
    role: "Head of Experience Design",
    bio: "Fuses research, design, and storytelling to craft intuitive end-to-end customer journeys.",
    image: "https://picsum.photos/402/402?random=34",
  },
];

const projectData = [
  {
    id: 1,
    title: "Adaptive Commerce Platform",
    category: "Digital Platforms",
    description: "Unified marketplace infrastructure powering multi-brand experiences worldwide.",
    image: "https://picsum.photos/1200/800?random=4",
  },
  {
    id: 2,
    title: "Predictive Health Insights",
    category: "AI & Analytics",
    description: "AI-enabled diagnostics delivering personalized care pathways and insights.",
    image: "https://picsum.photos/1201/800?random=44",
  },
  {
    id: 3,
    title: "Operational Intelligence Suite",
    category: "Cloud Transformation",
    description: "Cloud-native monitoring that unlocks proactive decision-making at scale.",
    image: "https://picsum.photos/1202/800?random=45",
  },
  {
    id: 4,
    title: "Immersive Product Showroom",
    category: "Experience Design",
    description: "Interactive digital showroom redefining how customers explore products.",
    image: "https://picsum.photos/1203/800?random=46",
  },
];

const faqData = [
  {
    question: "How quickly can we kick off a project with Aurora Dynamics?",
    answer:
      "We can typically begin discovery within two weeks. Our engagement starts with alignment workshops to clarify goals, stakeholders, and resources.",
  },
  {
    question: "Do you work with existing platforms and teams?",
    answer:
      "Absolutely. We embed alongside internal teams, modernize legacy stacks, and integrate with existing systems to create unified, future-proof solutions.",
  },
  {
    question: "What industries do you specialize in?",
    answer:
      "We partner broadly across financial services, healthcare, SaaS, retail, and high-growth startups—any organization prioritizing digital excellence.",
  },
  {
    question: "How do you measure success?",
    answer:
      "We co-create a measurement framework tracking customer, operational, and business KPIs. Real-time analytics ensure we optimize continuously.",
  },
];

const blogPosts = [
  {
    id: 1,
    title: "Redefining Customer Journeys with Adaptive Experiences",
    excerpt: "Discover how dynamic experience orchestration improves satisfaction, retention, and lifetime value.",
    date: "March 12, 2024",
    author: "Elena Torres",
  },
  {
    id: 2,
    title: "Building Trustworthy AI in Regulated Industries",
    excerpt: "A practical blueprint for balancing innovation, compliance, and ethical considerations in AI programs.",
    date: "February 28, 2024",
    author: "Noah Henderson",
  },
  {
    id: 3,
    title: "Five Signals That Indicate It’s Time to Modernize Your Platform",
    excerpt: "Learn the operational, technical, and customer insights that point to an essential platform transformation.",
    date: "February 10, 2024",
    author: "Priya Desai",
  },
];

const Home = () => {
  const statsRef = useRef(null);
  const [activeCounters, setActiveCounters] = useState(statsData.map(() => 0));
  const [projectsFilter, setProjectsFilter] = useState("All");
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFAQ, setActiveFAQ] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          statsData.forEach((stat, index) => {
            const endValue = stat.value;
            const duration = 2000;
            const startTime = performance.now();
            const animate = (currentTime) => {
              const elapsed = currentTime - startTime;
              const progress = Math.min(elapsed / duration, 1);
              const currentValue = Math.floor(progress * endValue);
              setActiveCounters((prev) => {
                const updated = [...prev];
                updated[index] = currentValue;
                return updated;
              });
              if (progress < 1) {
                requestAnimationFrame(animate);
              } else {
                setActiveCounters((prev) => {
                  const updated = [...prev];
                  updated[index] = endValue;
                  return updated;
                });
              }
            };
            requestAnimationFrame(animate);
          });
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );

    if (statsRef.current) {
      observer.observe(statsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    projectsFilter === "All"
      ? projectData
      : projectData.filter((project) => project.category === projectsFilter);

  return (
    <div className="home-page">
      <section className="hero-section" id="top">
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="badge">Award-Winning Innovation Partner</span>
            <h1>
              Architecting brave digital futures that evolve with your customers.
            </h1>
            <p>
              Aurora Dynamics helps visionary teams design, build, and optimize experiences that accelerate growth, unlock efficiencies, and deepen customer loyalty.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn btn-primary btn-large">
                Start a Project
              </Link>
              <a href="#services" className="btn btn-secondary btn-large">
                Explore Capabilities
              </a>
            </div>
            <div className="hero-meta">
              <div>
                <strong>Trusted by</strong>
                <span>Global enterprises &amp; high-growth disruptors</span>
              </div>
              <div>
                <strong>Rated 5.0</strong>
                <span>Across strategic engagements</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-image-wrapper">
              <img
                src="https://picsum.photos/1600/900?random=1"
                alt="Digital transformation collaboration"
                loading="lazy"
              />
              <div className="hero-stat-card">
                <p>Launch velocity</p>
                <h3>3.2x faster</h3>
                <span>Time-to-market improvement</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stats-section" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <h3>
                {activeCounters[index]}
                {stat.suffix || "+"}
              </h3>
              <p>{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="services-section" id="services">
        <div className="container">
          <div className="section-header">
            <span className="badge">Capabilities</span>
            <h2>Strategy, design, and engineering in perfect alignment.</h2>
            <p>
              A multidisciplinary team guiding organizations from insight to execution across the full transformation lifecycle.
            </p>
          </div>
          <div className="services-grid">
            {servicesData.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="service-icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <a className="service-link" href="#contact">
                  Learn more →
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process-section" id="process">
        <div className="container">
          <div className="section-header">
            <span className="badge">Process</span>
            <h2>Integrated, transparent, and outcome-driven.</h2>
            <p>
              We orchestrate teams, technology, and insights to deliver seamless, measurable progress at every stage.
            </p>
          </div>
          <div className="process-grid">
            {processSteps.map((step) => (
              <div className="process-card" key={step.step}>
                <span className="process-step">{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials-section">
        <div className="container testimonials-container">
          <div className="testimonial-content">
            <span className="badge">Testimonials</span>
            <h2>Trusted by leaders transforming their industries.</h2>
            <p>
              Our clients describe us as partners who blend ambition with pragmatism, ensuring that every initiative generates momentum and measurable value.
            </p>
            <div className="testimonial-controls">
              {testimonials.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  className={`testimonial-dot ${activeTestimonial === index ? "active" : ""}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Show testimonial from ${testimonial.name}`}
                />
              ))}
            </div>
          </div>
          <div className="testimonial-card">
            <p className="testimonial-quote">“{testimonials[activeTestimonial].quote}”</p>
            <div className="testimonial-author">
              <strong>{testimonials[activeTestimonial].name}</strong>
              <span>{testimonials[activeTestimonial].role}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="team-section" id="team">
        <div className="container">
          <div className="section-header">
            <span className="badge">Leadership</span>
            <h2>Strategists, technologists, and experience-makers.</h2>
            <p>
              Our leadership brings a rare blend of visionary thinking and hands-on expertise across complex digital domains.
            </p>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <article className="team-card" key={member.name}>
                <div className="team-image">
                  <img src={member.image} alt={`${member.name} at Aurora Dynamics`} loading="lazy" />
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects-section" id="projects">
        <div className="container">
          <div className="section-header">
            <span className="badge">Case Studies</span>
            <h2>Recent work driving measurable business value.</h2>
            <p>
              Explore a selection of engagements where Aurora Dynamics partnered with organizations to unlock transformative outcomes.
            </p>
          </div>
          <div className="projects-filter">
            {["All", "Digital Platforms", "AI & Analytics", "Cloud Transformation", "Experience Design"].map((category) => (
              <button
                key={category}
                className={`filter-button ${projectsFilter === category ? "active" : ""}`}
                onClick={() => setProjectsFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.id}>
                <div className="project-image">
                  <img src={project.image} alt={`${project.title} digital solution`} loading="lazy" />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <a className="project-link" href="#contact">
                    View engagement →
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section" id="faq">
        <div className="container">
          <div className="section-header">
            <span className="badge">FAQs</span>
            <h2>Answers to frequently asked questions.</h2>
            <p>
              We partner with teams around the globe to solve critical challenges. Explore our most common inquiries or reach out directly.
            </p>
          </div>
          <div className="faq-accordion">
            {faqData.map((item, index) => {
              const isOpen = activeFAQ === index;
              return (
                <div className={`faq-item ${isOpen ? "open" : ""}`} key={item.question}>
                  <button className="faq-question" onClick={() => setActiveFAQ(isOpen ? null : index)}>
                    <span>{item.question}</span>
                    <span className="faq-icon">{isOpen ? "−" : "+"}</span>
                  </button>
                  <div className="faq-answer">
                    <p>{item.answer}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="blog-section" id="blog">
        <div className="container">
          <div className="section-header">
            <span className="badge">Insights</span>
            <h2>Latest thinking from Aurora Dynamics.</h2>
            <p>
              We publish actionable perspectives on digital transformation, experience design, and the future of work.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.id}>
                <span className="blog-date">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <div className="blog-footer">
                  <span>By {post.author}</span>
                  <a href="#contact">Read more →</a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section" id="contact">
        <div className="container cta-container">
          <div className="cta-content">
            <span className="badge badge-light">Let’s Collaborate</span>
            <h2>Ready to accelerate your digital transformation?</h2>
            <p>
              Schedule a strategy session with our consultants to explore your roadmap, tackle complex challenges, and craft initiatives that unlock measurable impact.
            </p>
            <Link to="/contact" className="btn btn-light">
              Book a Consultation
            </Link>
          </div>
          <div className="cta-highlight">
            <h3>What to expect</h3>
            <ul>
              <li>Aligned objectives and success benchmarks</li>
              <li>Dedicated multidisciplinary specialists</li>
              <li>Roadmap, milestones, and ongoing optimization</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;