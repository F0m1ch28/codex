import React, { useState } from "react";

const serviceSolutions = [
  {
    title: "Transformation Strategy",
    description: "Unified digital roadmaps that align vision, customer insight, and technical feasibility.",
    features: ["Opportunity mapping", "Innovation sprints", "Stakeholder alignment", "Capability frameworks"],
  },
  {
    title: "Experience & Product Design",
    description: "Human-centered design that crafts delightful, accessible, and inclusive experiences.",
    features: ["Customer research", "Service design", "UX/UI design", "Design systems"],
  },
  {
    title: "Engineering & Delivery",
    description: "Modern architectures and delivery models that scale with confidence.",
    features: ["Cloud-native platforms", "API ecosystems", "DevOps enablement", "Quality engineering"],
  },
  {
    title: "Data, AI & Analytics",
    description: "AI-driven intelligence and automation fueling smarter decisions and personalized journeys.",
    features: ["Data strategy", "Predictive analytics", "ML Ops", "Responsible AI frameworks"],
  },
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <section className="inner-page">
      <div className="container wide">
        <span className="badge">Services</span>
        <h1>Modular services tailored to your transformation journey.</h1>
        <p>
          Aurora Dynamics integrates strategy, design, engineering, and analytics to deliver measurable outcomes. We provide end-to-end delivery or augment your teams with targeted expertise.
        </p>

        <div className="services-tabs">
          <div className="tabs-list" role="tablist">
            {serviceSolutions.map((service, index) => (
              <button
                key={service.title}
                role="tab"
                aria-selected={activeIndex === index}
                className={`tab-button ${activeIndex === index ? "active" : ""}`}
                onClick={() => setActiveIndex(index)}
              >
                {service.title}
              </button>
            ))}
          </div>
          <div className="tab-panel" role="tabpanel">
            <h2>{serviceSolutions[activeIndex].title}</h2>
            <p>{serviceSolutions[activeIndex].description}</p>
            <ul className="features-list">
              {serviceSolutions[activeIndex].features.map((feature) => (
                <li key={feature}>{feature}</li>
              ))}
            </ul>
          </div>
        </div>

        <section className="engagement-models">
          <h2>Engagement models</h2>
          <div className="engagement-grid">
            <article>
              <h3>Strategic partnership</h3>
              <p>Integrated teams delivering comprehensive transformation programs aligned to organizational goals.</p>
            </article>
            <article>
              <h3>Capability squads</h3>
              <p>Dedicated experts augmenting your organization in design, engineering, AI, or product leadership.</p>
            </article>
            <article>
              <h3>Innovation labs</h3>
              <p>Rapid experimentation to explore, prototype, and validate emerging opportunities.</p>
            </article>
          </div>
        </section>
      </div>
    </section>
  );
};

export default Services;