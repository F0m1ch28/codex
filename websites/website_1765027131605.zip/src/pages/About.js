import React from "react";

const About = () => {
  return (
    <section className="inner-page">
      <div className="container narrow">
        <span className="badge">About Aurora Dynamics</span>
        <h1>We exist to create digital ecosystems that unlock collective potential.</h1>
        <p>
          Founded in 2011, Aurora Dynamics helps ambitious organizations accelerate transformation through strategy, design, engineering, and continuous optimization. We combine industry expertise with human-centered practices to ensure every initiative drives measurable impact for customers, employees, and stakeholders.
        </p>
        <p>
          Our teams operate across North America, Europe, and APAC, embedding alongside client teams to co-create bold roadmaps and deliver experiences that adapt in real time. We specialize in solving complex challenges spanning financial services, healthcare, SaaS, retail, and emerging ventures.
        </p>

        <div className="about-highlight">
          <div>
            <h3>Our mission</h3>
            <p>
              To empower organizations with resilient, intelligent, and inclusive digital ecosystems that enrich lives and accelerate growth.
            </p>
          </div>
          <div>
            <h3>Our approach</h3>
            <p>
              We align executive vision, customer insight, and technical excellence. Every engagement is anchored in research, co-creation, and measurability.
            </p>
          </div>
        </div>

        <section className="values-section">
          <h2>Guiding values</h2>
          <div className="values-grid">
            <article>
              <h3>Clarity over complexity</h3>
              <p>We pursue clarity in vision and execution, ensuring stakeholders can act with confidence and purpose.</p>
            </article>
            <article>
              <h3>Craftsmanship</h3>
              <p>From strategy to code, our teams sweat the details to create meaningful, resilient, and adaptable solutions.</p>
            </article>
            <article>
              <h3>Co-creation</h3>
              <p>We partner closely with clients, empowering their teams and embedding knowledge for sustained success.</p>
            </article>
            <article>
              <h3>Positive impact</h3>
              <p>We advocate for ethical, inclusive, and sustainable outcomes that serve communities and the planet.</p>
            </article>
          </div>
        </section>

        <section className="timeline-section">
          <h2>Milestones</h2>
          <ul className="timeline">
            <li>
              <span>2011</span>
              <p>Aurora Dynamics launches with a vision to bridge strategy and engineering for digital pioneers.</p>
            </li>
            <li>
              <span>2015</span>
              <p>Expanded to three continents, supporting clients across financial services and healthcare.</p>
            </li>
            <li>
              <span>2019</span>
              <p>Introduced Aurora Labs, our innovation accelerator delivering emerging tech prototypes.</p>
            </li>
            <li>
              <span>2023</span>
              <p>Recognized as a Top Digital Transformation Partner by the Global Innovation Council.</p>
            </li>
          </ul>
        </section>

        <section className="culture-section">
          <h2>Life at Aurora Dynamics</h2>
          <p>
            We foster a culture of curiosity, inclusion, and continuous learning. Our studios are hubs where strategists, designers, engineers, and data scientists collaborate to solve complex challenges and create lasting change.
          </p>
        </section>
      </div>
    </section>
  );
};

export default About;