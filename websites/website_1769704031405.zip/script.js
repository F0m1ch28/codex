const I18N = {
  fr: {
    titles: {
      home: "danswholesaleplants | Orientation spatiale et signalétique numérique",
      services: "Expertises | danswholesaleplants",
      about: "À propos | danswholesaleplants",
      blog: "Analyses et articles | danswholesaleplants",
      post1: "Orchestrer la signalétique multi-canal dans les pôles de transit",
      post2: "Naviguer dans les quartiers urbains à partir de repères hybrides",
      post3: "Accessibilité et navigation inclusive dans les bâtiments publics",
      post4: "Plans interactifs et métriques de circulation intérieure",
      post5: "Suivi des flux piétons et scénarios d’orientation adaptatifs",
      contact: "Contact | danswholesaleplants",
      faq: "Questions fréquentes | danswholesaleplants",
      terms: "Conditions d’utilisation | danswholesaleplants",
      privacy: "Politique de confidentialité | danswholesaleplants",
      cookies: "Gestion des cookies | danswholesaleplants",
      refund: "Politique d’annulation | danswholesaleplants",
      disclaimer: "Avertissement | danswholesaleplants",
      thank: "Merci | danswholesaleplants",
      notFound: "Page introuvable | danswholesaleplants"
    },
    meta: {
      home: "Plateforme d’analyse dédiée à l’orientation spatiale, la signalétique numérique et la navigation intérieure pour les environnements complexes en Belgique.",
      services: "Panorama des expertises de danswholesaleplants : cartographie des espaces, UX spatiale, guidage visuel et accessibilité piétonne.",
      about: "Découvrez la vision, la méthode et les engagements de danswholesaleplants pour des environnements bâtis lisibles et inclusifs.",
      blog: "Articles techniques sur l’orientation spatiale, la signalétique numérique, les plans interactifs et l’architecture de l’information.",
      post1: "Analyse approfondie de la coordination signalétique dans les pôles multimodaux et des métriques d’efficacité correspondantes.",
      post2: "Étude sur les stratégies de navigation urbaine combinant repères physiques et couches numériques dans les quartiers mixtes.",
      post3: "Synthèse des exigences d’accessibilité et de conception inclusive pour la navigation intérieure dans les bâtiments publics.",
      post4: "Exploration des plans interactifs, des maquettes 3D et des indicateurs de circulation pour optimiser les flux.",
      post5: "Évaluation du suivi des flux piétons et des scénarios d’orientation adaptatifs dans les infrastructures publiques.",
      contact: "Coordonnées et formulaire pour joindre danswholesaleplants à Bruxelles concernant l’orientation spatiale et la signalétique numérique.",
      faq: "Réponses aux questions fréquentes sur l’orientation spatiale, la cartographie et le design informationnel.",
      terms: "Conditions d’utilisation du site danswholesaleplants décrivant les règles d’accès et de consultation des contenus.",
      privacy: "Politique de confidentialité expliquant la collecte, l’utilisation et la protection des données par danswholesaleplants.",
      cookies: "Informations détaillées sur l’usage des cookies et les préférences de consentement sur danswholesaleplants.com.",
      refund: "Politique d’annulation et de rétractation relative aux activités informatives de danswholesaleplants.",
      disclaimer: "Avertissement sur les limites de responsabilité des contenus publiés par danswholesaleplants.",
      thank: "Confirmation de réception de votre message adressé à danswholesaleplants.",
      notFound: "La page demandée n’a pas été trouvée sur danswholesaleplants.com."
    },
    brand: {
      name: "danswholesaleplants"
    },
    nav: {
      home: "Accueil",
      services: "Expertises",
      about: "À propos",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact",
      toggle: "Basculer la navigation",
      skip: "Aller au contenu principal"
    },
    languages: {
      fr: "FR",
      en: "EN"
    },
    buttons: {
      readPost: "Lire l’analyse",
      returnBlog: "Retour au blog"
    },
    footer: {
      tagline: "Ressource dédiée aux systèmes d’orientation spatiale et à la signalétique numérique pour les environnements publics.",
      contactTitle: "Coordonnées",
      phoneLabel: "Téléphone :",
      phone: "+32 2 123 45 67",
      emailLabel: "Courriel :",
      email: "contact@danswholesaleplants.com",
      addressLabel: "Adresse :",
      address: "Rue de la Loi 200, 1000 Bruxelles, Belgique",
      legalTitle: "Informations légales",
      terms: "Conditions d’utilisation",
      privacy: "Confidentialité",
      cookies: "Cookies",
      refund: "Politique d’annulation",
      disclaimer: "Avertissement",
      manageCookies: "Modifier les préférences de cookies",
      copyright: "danswholesaleplants — Tous droits réservés"
    },
    home: {
      hero: {
        badge: "Cartographier les trajectoires humaines",
        title: "Concevoir des systèmes d’orientation pour les environnements complexes",
        subtitle: "danswholesaleplants documente les méthodes pour articuler signalétique numérique, plans interactifs et repères architecturaux. L’objectif : fluidifier la mobilité piétonne, clarifier les parcours utilisateurs et rendre les espaces publics lisibles.",
        ctaPrimary: "Explorer les expertises",
        ctaSecondary: "Lire les analyses récentes",
        caption: "Visualisation élaborée dans le cadre d’une étude sur les flux de circulation et la signalétique multimodale."
      },
      overview: {
        title: "Des repères fiables pour la mobilité urbaine",
        text: "Les environnements bâtis exigent des dispositifs d’orientation précis. Nous observons les interactions entre architecture, signalétique numérique et comportements utilisateurs afin de produire un corpus de références opérationnelles.",
        card1: {
          title: "Orientation spatiale",
          text: "Identification des points décisionnels, hiérarchisation des informations et création de parcours cohérents pour les usagers."
        },
        card2: {
          title: "Signalétique numérique",
          text: "Déploiement d’interfaces dynamiques synchronisées avec la signalétique physique pour garantir une lecture continue."
        },
        card3: {
          title: "Accessibilité universelle",
          text: "Inclusion des normes d’accessibilité et anticipation des contraintes sensorielles pour des déplacements fluides."
        }
      },
      featured: {
        title: "Trois axes de recherche appliquée",
        text: "Chaque axe s’appuie sur des observations de terrain, des simulations 3D et des retours d’expérience recueillis auprès d’équipes de gestion de sites publics.",
        card1: {
          tag: "Cartographie",
          title: "Plans multi-échelles et scénarios de circulation",
          text: "Analyse des jeux de plans numériques permettant d’articuler les niveaux d’un bâtiment, les liaisons intermodales et les points de rassemblement."
        },
        card2: {
          tag: "Parcours UX",
          title: "Narration des étapes critiques d’un trajet",
          text: "Modélisation des émotions et besoins d’information selon les profils utilisateurs afin de prioriser les messages visuels."
        },
        card3: {
          tag: "Infrastructure",
          title: "Écosystèmes signalétiques durables",
          text: "Évaluation des matériaux, des supports digitaux et des protocoles de maintenance pour des systèmes cohérents dans le temps."
        }
      },
      journeys: {
        title: "Cartographier les usages pour renforcer la lisibilité",
        text: "Nos observations couvrent les gares, hôpitaux, campus et espaces publics belges afin de documenter les meilleures pratiques d’orientation.",
        card1: {
          title: "Diagnostics d’approche",
          text: "Repérage des points d’entrée, analyse des franchissements et des interfaces urbaines menant aux sites étudiés."
        },
        card2: {
          title: "Cartes narratives",
          text: "Traduction des parcours critiques en séquences graphiques pour guider la conception de plans interactifs."
        },
        card3: {
          title: "Évaluation continue",
          text: "Mise en place d’indicateurs pour mesurer la compréhension des usagers et ajuster la signalétique en temps réel."
        }
      },
      recommendations: {
        title: "Recommandations clés",
        text: "Synthèse d’enseignements applicables aux bâtiments publics belges et aux infrastructures à forte densité de déplacements.",
        card1: {
          title: "Hiérarchiser les espaces de décision",
          text: "Baliser les nœuds critiques avec des repères visuels et sonores capables de gérer les flux importants sans heurter la lisibilité."
        },
        card2: {
          title: "Synchroniser physique et numérique",
          text: "Maintenir une cohérence graphique et sémantique entre panneaux, terminaux tactiles et supports mobiles consultés par les usagers."
        },
        card3: {
          title: "Mesurer et ajuster",
          text: "Installer des boucles de retour d’expérience pour observer la performance des parcours et identifier les micro-ajustements nécessaires."
        }
      },
      testimonials: {
        title: "Témoignages terrain",
        text: "Les retours d’acteurs publics confirment l’importance d’une approche systémique de la signalétique.",
        quote1: "Le cadre méthodique proposé nous a permis de recenser les irritants sur chaque étape du trajet et de prioriser les améliorations.",
        author1: "Claire Vandeputte",
        role1: "Coordinatrice mobilité, hôpital universitaire",
        quote2: "La cartographie multi-supports a fluidifié les correspondances dans notre pôle de bus et réduit les demandes d’assistance.",
        author2: "Thomas Renders",
        role2: "Responsable infrastructure, réseau de transport",
        quote3: "Les scénarios rédigés pour notre campus ont servi de base au cahier des charges des futurs dispositifs numériques.",
        author3: "Léa Dumont",
        role3: "Chargée d’accessibilité, université bruxelloise"
      },
      insights: {
        title: "Stratégie d’orientation éclairée par la donnée",
        text: "Nous combinons observations terrain, cartographies interactives et protocoles d’évaluation pour décrire des solutions reproductibles.",
        cta: "Découvrir notre approche"
      },
      callout: {
        title: "Besoin de structurer un projet de signalétique numérique ?",
        text: "Nous documentons les étapes critiques, les normes et les indicateurs nécessaires pour réussir un déploiement d’orientation.",
        link: "Accéder aux coordonnées"
      }
    },
    servicesPage: {
      hero: {
        badge: "Expertises documentées",
        title: "Une base méthodologique pour vos dispositifs d’orientation",
        subtitle: "Chaque expertise repose sur des cas d’usage, des protocoles de mesure et des grilles d’évaluation adaptés aux environnements publics."
      },
      intro: {
        title: "Domaines de compétence explorés",
        text: "Les six axes ci-dessous couvrent l’ensemble du cycle de réflexion sur l’orientation spatiale : analyse amont, conception, prototypage et suivi."
      },
      items: {
        item1: {
          title: "Analyse des défis d’orientation",
          text: "Études de terrain pour comprendre les obstacles visuels, sonores et tactiles rencontrés par les usagers au sein des infrastructures."
        },
        item2: {
          title: "Principes de signalétique numérique",
          text: "Sélection de normes graphiques et techniques pour harmoniser écrans, balises lumineuses et supports physiques."
        },
        item3: {
          title: "Modèles de parcours utilisateurs",
          text: "Construction de personas, cartographie des scénarios critiques et identification des moments d’information essentiels."
        },
        item4: {
          title: "Plans et cartes interactifs",
          text: "Conception d’interfaces cartographiques multi-niveaux intégrant couches contextuelles, alertes et options d’accessibilité."
        },
        item5: {
          title: "Lisibilité et architecture",
          text: "Évaluation des contrastes, des angles de vue et des articulations spatiales pour renforcer la compréhension immédiate des lieux."
        },
        item6: {
          title: "Accessibilité et mobilités",
          text: "Référentiels pour garantir des déplacements inclusifs, incluant les cheminements podotactiles et l’assistance vocale."
        }
      },
      methodology: {
        title: "Notre méthode de documentation",
        text: "Nous décrivons chaque projet avec des matrices de services, une gouvernance claire et des indicateurs de suivi pour faciliter la mise en œuvre.",
        point1: "Cartographie des parties prenantes dès l’amont afin d’aligner les responsabilités.",
        point2: "Synthèse des données de mobilité et des retours usagers pour orienter les choix.",
        point3: "Guides de maintenance et de mises à jour pour assurer la pérennité du système."
      }
    },
    aboutPage: {
      hero: {
        badge: "Vision & gouvernance",
        title: "Une plateforme fondée sur l’observation et la rigueur informationnelle",
        subtitle: "danswholesaleplants conjugue recherche appliquée et documentation opérationnelle pour rendre les espaces publics plus intuitifs."
      },
      section1: {
        title: "Pour une navigation intérieure sans friction",
        text: "Nous analysons les dispositifs d’orientation dans leur contexte : architecture, flux réels, objectifs des gestionnaires et perception des usagers.",
        card1: {
          title: "Approche interdisciplinaire",
          text: "Croiser design, urbanisme, psychologie environnementale et technologies pour éclairer chaque décision."
        },
        card2: {
          title: "Observation en continu",
          text: "Visites régulières, relevés photo et entretiens afin de capter les micro-situations qui influencent les déplacements."
        },
        card3: {
          title: "Capitalisation des retours",
          text: "Chaque enseignement s’intègre dans une base de connaissances structurée accessible aux partenaires publics."
        }
      },
      section2: {
        title: "Principes directeurs",
        text: "Nos travaux reposent sur des valeurs simples : clarté, inclusion, résilience et transparence des méthodes.",
        point1: "Consacrer des ressources à l’accessibilité dès la conception et non en fin de parcours.",
        point2: "Partager les informations de manière éditoriale pour garantir leur appropriation.",
        point3: "Documenter les arbitrages pour permettre leur réexamen lors des évolutions futures."
      },
      section3: {
        title: "Organisation des projets",
        text: "Nous décrivons les phases critiques et aidons à structurer les échanges entre décideurs publics, architectes, designers et exploitants.",
        card1: {
          title: "Ateliers de cadrage",
          text: "Identification des objectifs, de la terminologie et du champ d’application pour chaque site."
        },
        card2: {
          title: "Prototypage itératif",
          text: "Scénarios testés avec des maquettes physiques et numériques pour valider la lisibilité."
        },
        card3: {
          title: "Gouvernance de suivi",
          text: "Tableaux de bord pour suivre l’état de la signalétique et planifier les mises à jour."
        }
      },
      section4: {
        title: "Collaborer avec les acteurs publics",
        text: "Nous fournissons un socle d’outils pour aider les institutions belges à piloter leurs dispositifs d’orientation et de signalétique numérique.",
        cta: "Échanger avec nous"
      }
    },
    blogPage: {
      hero: {
        badge: "Lectures approfondies",
        title: "Analyses sur la navigation intérieure et la signalétique digitale",
        subtitle: "Une collection d’articles pour éclairer les décisions relatives à l’orientation spatiale."
      },
      list: {
        title: "Articles récents",
        text: "Chaque article relie des exemples concrets aux principes méthodologiques appliqués dans les bâtiments publics belges."
      },
      posts: {
        post1: {
          title: "Coordonner la signalétique multi-canal dans les pôles de transit",
          excerpt: "Comment articuler écrans, panneaux et repères architecturaux pour guider des flux multimodaux en continu ?"
        },
        post2: {
          title: "Repères hybrides pour les quartiers urbains complexes",
          excerpt: "Vers une navigation intelligible mêlant cartographies numériques, micro-signalétique et repères culturels."
        },
        post3: {
          title: "Accessibilité intégrée dans la navigation des bâtiments publics",
          excerpt: "Les clés pour conjuguer standards inclusifs, parcours tactiles et interfaces vocales."
        },
        post4: {
          title: "Plans interactifs et métriques de circulation",
          excerpt: "Pourquoi les tableaux de bord des plans numériques transforment la gestion des lieux fréquentés."
        },
        post5: {
          title: "Suivi des flux piétons et scénarios adaptatifs",
          excerpt: "Observer, modéliser et ajuster les parcours pour absorber des variations de fréquentation."
        }
      }
    },
    posts: {
      post1: {
        meta: "Publié le 12 février 2024",
        title: "Orchestrer la signalétique multi-canal dans les pôles de transit",
        subtitle: "Aligner contenus, supports et architecture pour fluidifier la navigation multimodale.",
        figure: "Perspective d’un hall multimodal intégrant panneaux numériques et signalétique suspendue.",
        heading1: "Construire une grammaire visuelle partagée",
        p1: "Les pôles de transit belges concentrent plusieurs modes de déplacement et une densité informationnelle élevée. Lorsque l’infrastructure juxtapose lignes de métro, réseaux de bus et correspondances ferroviaires, la moindre incohérence graphique fragilise la compréhension. Le point de départ consiste donc à définir une grammaire visuelle commune reliant les couleurs de lignes, la typographie des panneaux, les pictogrammes et les terminaux numériques. Cette base partagée permet d’établir des conventions de mise à jour et d’anticiper la croissance du réseau.",
        p2: "L’inventaire précis des supports sert de socle : panneaux directionnels suspendus, colonnes d’information, signalétique en façade, écrans LED, kiosques interactifs. Chaque support reçoit une fonction primaire (confirmer, préparer, réassurer) et une charte de contenu. La documentation affine la chaîne éditoriale : qui valide une nouvelle information, à quel moment migrer un message d’un écran vers un panneau statique, comment signaler une perturbation temporaire.",
        subheading1: "Aligner flux physiques et flux data en temps réel",
        p3: "La synchronisation entre signalétique physique et numérique exige une base de données centralisée alimentée par les opérateurs de transport. Les écrans et les serveurs doivent partager une API unique pour refléter les mises à jour horaires ou les incidents. Cette intégration réduit la latence entre l’événement et l’affichage. Toutefois, la dépendance aux réseaux impose des plans de continuité : scénarios hors-ligne, jeux de messages préchargés, procédures de basculement vers des repères analogiques.",
        p4: "Sur le terrain, les flux piétons ne suivent pas toujours les parcours prévus. D’où l’importance de capteurs anonymisés, d’observations vidéo ou de relevés manuels afin de confronter le plan théorique à la réalité. Les données recueillies alimentent des heatmaps qui révèlent les zones de friction. Coupler ces analyses avec des journaux d’événements (interruption d’un escalator, saturation d’un quai) permet d’ajuster la hiérarchie des messages sur les supports critiques.",
        heading2: "Mesurer l’efficacité des parcours assistés",
        p5: "Une stratégie de signalétique performante s’appuie sur des indicateurs précis : temps moyen de correspondance, nombre de demandes d’orientation, taux de rebroussement devant un panneau. Les équipes terrain peuvent coréler ces données avec des enquêtes qualitatives pour comprendre les points de confusion. Le tableau de bord issu de ces métriques doit rester lisible pour les agents opérationnels, avec des alertes simples indiquant les secteurs nécessitant une révision de contenu.",
        p6: "Lorsqu’un nouveau service est intégré (navette, vélos partagés, service d’orientation humain), il convient de tester l’impact sur la signalétique existante. Une démarche pilote peut mobiliser un échantillon d’usagers invités à suivre un scénario précis. Les retours alimentent une matrice d’améliorations classées selon l’effort requis et le gain potentiel.",
        subheading2: "Pérenniser la gouvernance signalétique",
        p7: "Pour durer, la coordination multi-canal repose sur un comité rassemblant exploitants, designers, services de maintenance et spécialistes accessibilité. Ce groupe fixe un calendrier de révision des contenus et valide les évolutions techniques. Il veille aussi à la cohérence des matériaux, à la tenue des couleurs dans le temps et à l’ergonomie des interfaces interactives.",
        p8: "Enfin, la documentation doit survivre aux changements de prestataires. C’est pourquoi un guide de gouvernance récapitule la terminologie, les processus d’escalade et les contacts. La signalétique devient alors un système vivant, capable d’absorber des modifications de ligne ou des chantiers tout en maintenant une orientation intime et claire pour chaque voyageur."
      },
      post2: {
        meta: "Publié le 26 mars 2024",
        title: "Repères hybrides pour les quartiers urbains complexes",
        subtitle: "Composer entre mémoire collective et services numériques pour guider les déplacements citadins.",
        figure: "Carte de quartier avec points de repère patrimoniaux et supports numériques.",
        heading1: "Comprendre la mosaïque d’un quartier mixte",
        p1: "Les quartiers urbains denses superposent habitats, commerces, institutions culturelles et transports. Cette diversité complique la navigation, car les repères peuvent varier d’un groupe d’usagers à l’autre. La première étape consiste à dresser une carte sensible identifiant les éléments mémoriels (places, œuvres d’art, façades singulières) et les infrastructures officielles (arrêts, parkings, centres administratifs).",
        p2: "Les entretiens qualitatifs révèlent ensuite les repères spontanément cités par les habitants. Certains évoqueront un café emblématique, d’autres un jardin partagé, d’autres encore l’entrée d’un tunnel. Ces informations orientent la conception de la signalétique, qui doit embrasser la dimension culturelle sans perdre la clarté fonctionnelle.",
        subheading1: "Tisser le lien entre supports physiques et services numériques",
        p3: "Une fois le paysage des repères établi, la signalétique doit dialoguer avec les outils numériques de navigation. Cartes web, applications mobiles ou QR codes s’alignent sur la nomenclature des panneaux physiques. Chaque point d’intérêt reçoit un identifiant unique, exploitable à la fois sur les bases de données ouvertes et sur les totems d’information sur site.",
        p4: "Les interfaces numériques intègrent également les dynamiques temporelles : horaires spécifiques, événements culturels, chantiers. L’actualisation régulière garantit la pertinence des parcours suggérés. Lorsque des flux inhabituels sont attendus (marchés, événements festifs), les supports physiques sont complétés par des signalétiques temporaires dotées des mêmes codes graphiques pour maintenir la cohérence.",
        heading2: "Favoriser une mobilité inclusive",
        p5: "L’orientation dans un quartier ne se limite pas à la marche. Les itinéraires doivent tenir compte des personnes à mobilité réduite, des cyclistes, des parents avec poussettes. Cela implique l’identification des rampes, ascenseurs urbains, toilettes accessibles et espaces de repos. Ces informations sont intégrées à la fois dans les cartes imprimables, les bornes et les services numériques.",
        p6: "Les dispositifs audio et tactiles renforcent l’inclusivité. Des balises sonores discrètes peuvent signaler un point de franchissement sécurisé. Des plans en relief, accompagnés de légendes en braille, complètent les bornes numériques. La cohérence entre ces supports assure que chaque usager peut se repérer selon ses propres sens.",
        subheading2: "Évaluer et ajuster le maillage de repères",
        p7: "La mise en place de questionnaires sur site et d’outils de cartographie participative permet de détecter les zones encore floues. Les retours peuvent indiquer qu’un passage est perçu comme peu accueillant ou qu’un signe manque de visibilité nocturne. Ces signaux guident de petites interventions ciblées, parfois aussi simples que renforcer l’éclairage ou repositionner un panneau.",
        p8: "En documentant chaque modification et son effet, la collectivité construit un référentiel exportable vers d’autres quartiers. La combinaison d’une mémoire locale valorisée et de services numériques fiables crée un sentiment de repère partagé, qui réduit la dépendance aux demandes d’information et améliore la perception de sécurité."
      },
      post3: {
        meta: "Publié le 15 mai 2024",
        title: "Accessibilité intégrée dans la navigation des bâtiments publics",
        subtitle: "Conciliations entre exigences réglementaires et expérience utilisateur inclusive.",
        figure: "Axe principal d’un bâtiment public avec signalétique accessible et contraste élevé.",
        heading1: "Auditer l’accessibilité existante",
        p1: "L’accessibilité ne se résume pas à des rampes ou ascenseurs. Elle implique une lecture aisée des espaces, des contrastes adéquats et des informations multimodales. Un audit approfondi commence par la cartographie des entrées, des sas de sécurité, des points d’attente et des plans d’évacuation.",
        p2: "La démarche inclut la vérification des hauteurs d’installation des éléments visuels, du niveau d’éclairage et du confort acoustique. Les dispositifs sonores doivent être intelligibles même en présence de réverbérations ou de bruits de foule.",
        subheading1: "Construire une information multi-sensorielle",
        p3: "Les plans tactiles, les balises audio et les pictogrammes simplifiés s’articulent avec la signalétique standard. Chaque support renvoie au même vocabulaire pour éviter les ambiguïtés. Les annonces sonores sont synchronisées avec les messages visuels des écrans et des panneaux.",
        p4: "Les supports numériques intègrent des fonctions de contraste renforcé, de lecture vocale et de navigation clavier. Les QR codes renvoient vers des contenus adaptatifs compatibles avec les lecteurs d’écran.",
        heading2: "Gouvernance et formation des équipes",
        p5: "Les équipes de gestion doivent être sensibilisées aux besoins spécifiques des publics. Cela inclut la manipulation des dispositifs audio, la vérification quotidienne des balises et l’accueil proactif des visiteurs.",
        p6: "Des scénarios d’exercice impliquant des associations spécialisées permettent de confronter les installations aux situations réelles. Les retours alimentent un registre d’amélioration continue.",
        subheading2: "Suivi et amélioration continue",
        p7: "Un tableau de bord recense les incidents remontés par les usagers : signal sonore défaillant, panneau masqué, éclairage insuffisant. Les interventions sont priorisées selon leur impact sur la sécurité et la compréhension.",
        p8: "La documentation de ces actions crée une mémoire utile pour les futures rénovations. Elle démontre que l’accessibilité est un processus vivant, soutenu par une gouvernance vigilante et une écoute constante des usagers."
      },
      post4: {
        meta: "Publié le 02 juillet 2024",
        title: "Plans interactifs et métriques de circulation intérieure",
        subtitle: "Exploiter les données pour ajuster les parcours et anticiper les congestions.",
        figure: "Interface de plan interactif affichant des flux de circulation en temps réel.",
        heading1: "Mettre en place une base cartographique robuste",
        p1: "Un plan interactif fiable repose sur une modélisation précise du bâtiment : niveaux, couloirs, espaces de service, ascenseurs. Cette base sert de référence aux simulations de flux et à l’affichage dynamique.",
        p2: "La normalisation des données garantit la compatibilité avec divers outils (bornes tactiles, web, applications internes). Chaque zone reçoit un identifiant, facilitant l’extraction de statistiques.",
        subheading1: "Collecter et interpréter les données de circulation",
        p3: "Capteurs anonymisés, badges visiteurs, observations manuelles : autant de sources permettant d’évaluer les flux. L’analyse identifie les heures de pointe, les zones d’attente imprévues et les trajets les plus empruntés.",
        p4: "Les tableaux de bord présentent ces données sous forme de cartes thermiques et de séries temporelles. Ils permettent d’anticiper les congestions et de déclencher des scénarios de délestage.",
        heading2: "Adapter la signalétique à la dynamique constatée",
        p5: "Les plans interactifs peuvent suggérer des itinéraires alternatifs en cas de forte affluence. Les écrans et panneaux physiques relayent ces recommandations lorsqu’un seuil de saturation est atteint.",
        p6: "Les notifications visuelles ou sonores guident les usagers vers des espaces moins fréquentés, améliorant le confort général.",
        subheading2: "Assurer la pérennité du système",
        p7: "Un protocole de maintenance prévoit la mise à jour des plans après chaque réaménagement. Les équipes disposent d’un workflow clair pour enregistrer les modifications.",
        p8: "L’évaluation régulière des performances garantit que le plan interactif reste un outil pertinent pour les gestionnaires et les visiteurs."
      },
      post5: {
        meta: "Publié le 18 septembre 2024",
        title: "Suivi des flux piétons et scénarios d’orientation adaptatifs",
        subtitle: "Passer de l’observation à l’ajustement dynamique des parcours en temps réel.",
        figure: "Schéma de circulation piétonne avec capteurs et scénarios d’affichage adaptatif.",
        heading1: "Comprendre les rythmes d’un site public",
        p1: "Le suivi des flux piétons demande une vision fine des rythmes quotidiens, hebdomadaires et saisonniers. Les capteurs de présence, les comptages manuels et les retours des équipes terrain permettent de dessiner un profil précis des usages.",
        p2: "Les variations de fréquentation révèlent des scénarios récurrents : arrivées groupées, désengorgement, évènements exceptionnels. Chaque scénario appelle un dispositif d’orientation spécifique.",
        subheading1: "Élaborer des scénarios adaptatifs",
        p3: "Les supports numériques (écrans, balises lumineuses, notifications mobiles) peuvent basculer d’un jeu de messages à l’autre selon les données recueillies. Le système déclenche par exemple un guidage différencié pour séparer flux entrants et sortants.",
        p4: "Les scénarios s’appuient sur des règles claires : seuils de densité, événements planifiés, incidents. La partie éditoriale prévoit les messages correspondants, testés en amont pour éviter toute ambiguïté.",
        heading2: "Mesurer l’impact des ajustements",
        p5: "Après l’activation d’un scénario adaptatif, les équipes comparent les indicateurs de mobilité : réduction des temps d’attente, moindre concentration sur les zones critiques, baisse des demandes d’assistance.",
        p6: "Des capteurs audio peuvent également suivre le niveau sonore pour détecter les zones de stress. L’objectif est de vérifier que la signalétique contribue au confort global.",
        subheading2: "Impliquer les parties prenantes",
        p7: "La réussite du système dépend de la coopération entre gestionnaires, services de sécurité et équipes de maintenance. Chacun doit connaître les scénarios, les seuils d’activation et les procédures d’escalade.",
        p8: "La capitalisation des retours d’expérience permet d’ajuster les règles dans le temps. Les scénarios deviennent plus précis et plus réactifs, garantissant une orientation adéquate même lors de pics d’affluence imprévus."
      }
    },
    contactPage: {
      hero: {
        badge: "Joindre l’équipe",
        title: "Coordonnées et formulaires de contact",
        subtitle: "Nous répondons aux questions relatives à la signalétique numérique, aux plans interactifs et aux parcours utilisateurs."
      },
      details: {
        title: "Informations pratiques",
        phoneLabel: "Téléphone",
        phoneValue: "+32 2 123 45 67",
        emailLabel: "Courriel",
        emailValue: "contact@danswholesaleplants.com",
        addressLabel: "Adresse",
        addressValue: "Rue de la Loi 200, 1000 Bruxelles, Belgique",
        hoursLabel: "Disponibilités",
        hoursValue: "Du lundi au vendredi, 09:00 – 17:00"
      },
      form: {
        title: "Formulaire de contact",
        subtitle: "Décrivez votre besoin : contexte spatial, enjeux d’orientation, attentes en matière de signalétique.",
        note: "Les champs marqués d’une étoile sont obligatoires."
      },
      map: {
        caption: "Localisation de danswholesaleplants à Bruxelles — accès aisés en transports publics."
      }
    },
    forms: {
      name: {
        label: "Nom complet *",
        placeholder: "Votre nom et prénom"
      },
      email: {
        label: "Adresse e-mail *",
        placeholder: "votre.email@example.com"
      },
      org: {
        label: "Organisation",
        placeholder: "Nom de votre structure"
      },
      subject: {
        label: "Objet *",
        placeholder: "Sujet de votre message"
      },
      message: {
        label: "Message *",
        placeholder: "Décrivez votre projet ou vos questions"
      },
      submit: "Envoyer",
      note: "En envoyant ce formulaire, vous acceptez que vos informations soient utilisées pour répondre à votre demande."
    },
    faqPage: {
      hero: {
        badge: "FAQ",
        title: "Questions fréquentes",
        subtitle: "Réponses rapides concernant nos thématiques d’orientation spatiale."
      },
      items: {
        q1: "Comment démarrez-vous un diagnostic d’orientation ?",
        a1: "Nous réalisons des visites in situ, analysons les supports existants et interrogeons les équipes pour comprendre les contraintes contextuelles.",
        q2: "Intégrez-vous les données de fréquentation ?",
        a2: "Oui, nous exploitons des relevés quantitatifs et qualitatifs pour documenter les flux et hiérarchiser les points de décision.",
        q3: "Quels types de plans interactifs privilégiez-vous ?",
        a3: "Nous recommandons des solutions modulaires capables d’agréger plusieurs niveaux et de proposer des itinéraires adaptés.",
        q4: "Comment abordez-vous l’accessibilité ?",
        a4: "Nous combinons normes réglementaires, retours d’associations spécialisées et tests utilisateurs pour garantir l’inclusivité.",
        q5: "Travaillez-vous avec des équipes internes ?",
        a5: "Nous favorisons les ateliers collaboratifs afin de transférer des méthodes et de pérenniser les actions.",
        q6: "Proposez-vous des indicateurs de performance ?",
        a6: "Chaque projet s’accompagne d’un tableau de bord recensant métriques de lisibilité, retours usagers et suivi de maintenance."
      }
    },
    termsPage: {
      title: "Conditions d’utilisation",
      subtitle: "Règles encadrant la consultation du site et l’usage des contenus.",
      section1: {
        title: "1. Objet",
        body: "Les présentes conditions définissent les modalités d’accès et d’utilisation du site danswholesaleplants.com."
      },
      section2: {
        title: "2. Acceptation",
        body: "La navigation sur le site implique l’acceptation sans réserve des présentes conditions d’utilisation."
      },
      section3: {
        title: "3. Public visé",
        body: "Le site s’adresse aux professionnels et organisations intéressés par la signalétique et la navigation intérieure."
      },
      section4: {
        title: "4. Qualité des contenus",
        body: "Les informations publiées visent à documenter des pratiques. Elles n’ont pas valeur contractuelle."
      },
      section5: {
        title: "5. Mise à jour",
        body: "Les contenus peuvent être ajustés à tout moment pour refléter l’évolution des connaissances."
      },
      section6: {
        title: "6. Propriété intellectuelle",
        body: "Les textes, images et éléments graphiques demeurent la propriété de danswholesaleplants sauf mention contraire."
      },
      section7: {
        title: "7. Réutilisation",
        body: "Toute reproduction nécessite accord préalable et citation explicite de la source."
      },
      section8: {
        title: "8. Liens externes",
        body: "Le site peut contenir des liens vers des ressources tierces sans responsabilité sur leur contenu."
      },
      section9: {
        title: "9. Disponibilité",
        body: "Nous nous efforçons d’assurer l’accessibilité du site, sans garantie d’absence d’interruption."
      },
      section10: {
        title: "10. Responsabilité",
        body: "danswholesaleplants ne saurait être tenu responsable d’un usage inapproprié des informations."
      },
      section11: {
        title: "11. Données personnelles",
        body: "Les modalités de traitement des données figurent dans la politique de confidentialité."
      },
      section12: {
        title: "12. Cookies",
        body: "La gestion des cookies est décrite dans la page dédiée et dans le bandeau de consentement."
      },
      section13: {
        title: "13. Droit applicable",
        body: "Le site est régi par le droit belge. Tout litige relève des juridictions de Bruxelles."
      },
      section14: {
        title: "14. Contact",
        body: "Pour toute question relative aux présentes conditions, écrivez à contact@danswholesaleplants.com."
      }
    },
    privacyPage: {
      title: "Politique de confidentialité",
      subtitle: "Informations sur la collecte et l’utilisation des données personnelles.",
      section1: {
        title: "1. Responsable du traitement",
        body: "danswholesaleplants est responsable des traitements effectués sur le site danswholesaleplants.com."
      },
      section2: {
        title: "2. Données collectées",
        body: "Nous recueillons les informations fournies via le formulaire de contact : nom, adresse e-mail, organisation, objet du message."
      },
      section3: {
        title: "3. Finalités",
        body: "Les données servent à répondre aux demandes et à assurer un suivi documentaire des échanges."
      },
      section4: {
        title: "4. Base légale",
        body: "Le traitement repose sur l’intérêt légitime de répondre aux sollicitations et sur le consentement exprimé lors de l’envoi."
      },
      section5: {
        title: "5. Destinataires",
        body: "Les données sont réservées à l’équipe de danswholesaleplants. Aucune transmission à des tiers n’est réalisée sans accord."
      },
      section6: {
        title: "6. Durée de conservation",
        body: "Les messages sont conservés pendant deux ans maximum, sauf obligation légale contraire."
      },
      section7: {
        title: "7. Droits des personnes",
        body: "Vous disposez de droits d’accès, de rectification, d’effacement et d’opposition. Contactez contact@danswholesaleplants.com."
      },
      section8: {
        title: "8. Sécurité",
        body: "Des mesures organisationnelles et techniques protègent les données contre toute utilisation non autorisée."
      },
      section9: {
        title: "9. Cookies",
        body: "Les cookies utilisés sont décrits dans la page dédiée. Vous pouvez gérer vos préférences à tout moment."
      },
      section10: {
        title: "10. Mise à jour",
        body: "Cette politique peut évoluer. La date de dernière révision est indiquée en bas de page."
      }
    },
    cookiesPage: {
      title: "Politique relative aux cookies",
      subtitle: "Comprendre et gérer les cookies utilisés sur le site.",
      section1: {
        title: "1. Définition",
        body: "Un cookie est un fichier texte stocké sur votre terminal lors de la consultation du site."
      },
      section2: {
        title: "2. Consentement",
        body: "Lors de votre première visite, vous pouvez accepter, refuser ou personnaliser l’utilisation des cookies."
      },
      section3: {
        title: "3. Gestion",
        body: "Vous pouvez modifier vos choix à partir du bandeau ou via le lien de gestion disponible dans le pied de page."
      },
      section4: {
        title: "4. Types de cookies",
        body: "Nous distinguons les cookies nécessaires au fonctionnement, ceux de préférence, d’analyse et marketing."
      },
      table: {
        title: "Inventaire des cookies",
        intro: "La liste ci-dessous présente les cookies susceptibles d’être déposés sur votre terminal.",
        headers: {
          name: "Nom",
          provider: "Fournisseur",
          type: "Type",
          purpose: "Finalité",
          duration: "Durée"
        },
        rows: {
          row1: {
            name: "cookie_consent",
            provider: "danswholesaleplants",
            type: "Nécessaire",
            purpose: "Sauvegarde des choix exprimés dans la bannière.",
            duration: "12 mois"
          },
          row2: {
            name: "site_lang",
            provider: "danswholesaleplants",
            type: "Préférences",
            purpose: "Mémorisation de la langue sélectionnée.",
            duration: "12 mois"
          },
          row3: {
            name: "analytics_flow",
            provider: "danswholesaleplants",
            type: "Analyse",
            purpose: "Mesure agrégée des parcours utilisateurs.",
            duration: "24 mois"
          },
          row4: {
            name: "outreach_context",
            provider: "danswholesaleplants",
            type: "Marketing",
            purpose: "Évaluation de l’intérêt pour les ressources éditoriales.",
            duration: "6 mois"
          }
        }
      },
      section5: {
        title: "5. Navigateur",
        body: "Vous pouvez configurer votre navigateur pour supprimer les cookies ou recevoir une alerte lors de leur installation."
      },
      section6: {
        title: "6. Contact",
        body: "Pour toute question relative aux cookies, écrivez à contact@danswholesaleplants.com."
      }
    },
    refundPage: {
      title: "Politique d’annulation",
      subtitle: "Modalités en cas de modification ou d’annulation des contributions.",
      section1: {
        title: "1. Champ d’application",
        body: "Cette politique s’applique aux contenus informatifs et aux échanges réalisés via le site."
      },
      section2: {
        title: "2. Nature des prestations",
        body: "Le site ne commercialise pas de services payants. Aucun paiement n’est exigé pour consulter les ressources."
      },
      section3: {
        title: "3. Demandes de retrait",
        body: "Vous pouvez demander la suppression d’un témoignage ou d’une citation en écrivant à l’adresse de contact."
      },
      section4: {
        title: "4. Rectification",
        body: "Les erreurs ou imprécisions signalées sont révisées dans les meilleurs délais."
      },
      section5: {
        title: "5. Indisponibilité",
        body: "En cas d’indisponibilité temporaire du site, aucune compensation financière n’est prévue."
      },
      section6: {
        title: "6. Contributions externes",
        body: "Les contributions invitées peuvent être retirées si elles ne correspondent plus aux objectifs éditoriaux."
      },
      section7: {
        title: "7. Préavis",
        body: "Toute modification substantielle est annoncée via une note sur le site."
      },
      section8: {
        title: "8. Gestion documentaire",
        body: "Les échanges enregistrés peuvent être archivés afin d’assurer la traçabilité des demandes."
      },
      section9: {
        title: "9. Force majeure",
        body: "Les événements extérieurs indépendants de notre volonté peuvent retarder le traitement des demandes."
      },
      section10: {
        title: "10. Contact",
        body: "Pour toute question, contactez-nous à contact@danswholesaleplants.com."
      }
    },
    disclaimerPage: {
      title: "Avertissement",
      subtitle: "Limites et responsabilités concernant les contenus publiés.",
      section1: {
        title: "1. Absence de garantie",
        body: "Les informations sont fournies à titre indicatif. Nous ne garantissons ni exhaustivité ni actualité permanente."
      },
      section2: {
        title: "2. Utilisation des contenus",
        body: "L’utilisateur reste responsable de l’interprétation et de l’usage des informations diffusées."
      },
      section3: {
        title: "3. Absence de conseil",
        body: "Les contenus ne constituent pas un avis professionnel. Ils complètent vos propres analyses."
      },
      section4: {
        title: "4. Liens externes",
        body: "Les liens sortants sont fournis pour commodité. Nous déclinons toute responsabilité concernant leur contenu."
      },
      section5: {
        title: "5. Évolutions",
        body: "Les informations peuvent être modifiées sans préavis pour intégrer de nouvelles données."
      },
      section6: {
        title: "6. Contact",
        body: "Pour signaler une erreur ou une omission, adressez un message à contact@danswholesaleplants.com."
      }
    },
    thankPage: {
      title: "Merci pour votre message",
      message: "Votre demande a bien été transmise. Nous analyserons votre besoin d’orientation spatiale et reviendrons vers vous sous peu.",
      cta: "Retour à l’accueil"
    },
    notFound: {
      title: "Page introuvable",
      message: "Le contenu recherché n’est pas disponible. Vérifiez l’URL ou explorez nos ressources sur l’orientation spatiale.",
      cta: "Revenir à l’accueil"
    },
    cookie: {
      message: "Nous utilisons des cookies pour assurer le bon fonctionnement du site et analyser la fréquentation.",
      manage: "Gérer les préférences",
      sectionIntro: "Ajustez les catégories ci-dessous selon vos besoins.",
      necessary: "Cookies nécessaires",
      necessaryDescription: "Indispensables au fonctionnement du site et à la sauvegarde de vos choix.",
      preferences: "Cookies de préférence",
      preferencesDescription: "Permettent de retenir la langue ou d’autres paramètres de confort.",
      analytics: "Cookies d’analyse",
      analyticsDescription: "Aident à comprendre la navigation globale pour améliorer nos contenus.",
      marketing: "Cookies marketing",
      marketingDescription: "Utilisés pour qualifier l’intérêt porté à nos ressources éditoriales.",
      accept: "Tout accepter",
      decline: "Tout refuser",
      save: "Enregistrer"
    },
    toast: {
      contactPending: "Merci, votre message est en préparation d’envoi.",
      contactRedirect: "Redirection vers la page de confirmation.",
      cookiesSaved: "Préférences cookies enregistrées.",
      cookiesDeclined: "Les cookies non essentiels sont désactivés.",
      languageChanged: "Langue mise à jour."
    },
    images: {
      homeHero: "Hall d’orientation numérique avec signalétique dynamique",
      blog1: "Écrans de signalétique dans un hub de transport",
      blog2: "Perspective urbaine avec repères visuels",
      blog3: "Parcours intérieur accessible",
      blog4: "Plan interactif sur table tactile",
      blog5: "Vue aérienne de flux piétons",
      post1Hero: "Interface multimodale d’un pôle de transit",
      post2Hero: "Signalétique hybride dans un quartier urbain",
      post3Hero: "Signalétique inclusive dans un bâtiment public",
      post4Hero: "Plan numérique affichant des données de circulation",
      post5Hero: "Capteurs et affichage dynamique de flux piétons"
    }
  },
  en: {
    titles: {
      home: "danswholesaleplants | Spatial orientation and digital wayfinding",
      services: "Expertise | danswholesaleplants",
      about: "About | danswholesaleplants",
      blog: "Insights and articles | danswholesaleplants",
      post1: "Orchestrating multi-channel wayfinding in transit hubs",
      post2: "Hybrid landmarks for complex urban districts",
      post3: "Inclusive navigation in public buildings",
      post4: "Interactive maps and interior circulation metrics",
      post5: "Pedestrian flow monitoring and adaptive wayfinding scenarios",
      contact: "Contact | danswholesaleplants",
      faq: "Frequently Asked Questions | danswholesaleplants",
      terms: "Terms of Use | danswholesaleplants",
      privacy: "Privacy Policy | danswholesaleplants",
      cookies: "Cookie Management | danswholesaleplants",
      refund: "Cancellation Policy | danswholesaleplants",
      disclaimer: "Disclaimer | danswholesaleplants",
      thank: "Thank You | danswholesaleplants",
      notFound: "Page Not Found | danswholesaleplants"
    },
    meta: {
      home: "Resource focused on spatial orientation, digital signage, and indoor navigation strategies for complex environments in Belgium.",
      services: "Overview of danswholesaleplants expertise: spatial mapping, spatial UX, visual guidance, and pedestrian accessibility.",
      about: "Learn about the vision, methodology, and commitments of danswholesaleplants toward legible and inclusive built environments.",
      blog: "Technical articles covering spatial orientation, digital signage, interactive plans, and information architecture.",
      post1: "In-depth analysis of wayfinding coordination within multimodal transport hubs and associated performance metrics.",
      post2: "Study of navigation strategies combining cultural landmarks and digital layers in mixed urban districts.",
      post3: "Summary of accessibility requirements and inclusive design for wayfinding inside public buildings.",
      post4: "Exploration of interactive plans, 3D mock-ups, and circulation indicators to optimise flows.",
      post5: "Assessment of pedestrian flow tracking and adaptive wayfinding scenarios across public infrastructures.",
      contact: "Contact details and form to reach danswholesaleplants in Brussels regarding spatial orientation and digital signage.",
      faq: "Answers to frequent questions about spatial orientation, mapping, and information design.",
      terms: "Terms of use describing site access rules and content usage for danswholesaleplants.",
      privacy: "Privacy policy explaining how danswholesaleplants collects, uses, and protects personal data.",
      cookies: "Detailed information about cookies and preference management on danswholesaleplants.com.",
      refund: "Cancellation policy covering the informative activities of danswholesaleplants.",
      disclaimer: "Disclaimer outlining responsibility limits for content published by danswholesaleplants.",
      thank: "Confirmation page acknowledging your message sent to danswholesaleplants.",
      notFound: "The requested page was not found on danswholesaleplants.com."
    },
    brand: {
      name: "danswholesaleplants"
    },
    nav: {
      home: "Home",
      services: "Expertise",
      about: "About",
      blog: "Blog",
      faq: "FAQ",
      contact: "Contact",
      toggle: "Toggle navigation",
      skip: "Skip to main content"
    },
    languages: {
      fr: "FR",
      en: "EN"
    },
    buttons: {
      readPost: "Read insight",
      returnBlog: "Back to blog"
    },
    footer: {
      tagline: "Resource dedicated to spatial orientation systems and digital wayfinding within public environments.",
      contactTitle: "Contact details",
      phoneLabel: "Phone:",
      phone: "+32 2 123 45 67",
      emailLabel: "Email:",
      email: "contact@danswholesaleplants.com",
      addressLabel: "Address:",
      address: "Rue de la Loi 200, 1000 Brussels, Belgium",
      legalTitle: "Legal information",
      terms: "Terms of Use",
      privacy: "Privacy",
      cookies: "Cookies",
      refund: "Cancellation policy",
      disclaimer: "Disclaimer",
      manageCookies: "Adjust cookie preferences",
      copyright: "danswholesaleplants — All rights reserved"
    },
    home: {
      hero: {
        badge: "Mapping human trajectories",
        title: "Designing orientation systems for complex environments",
        subtitle: "danswholesaleplants documents methods to align digital signage, interactive plans, and architectural cues. The goal is to ease pedestrian mobility, clarify user journeys, and make public spaces legible.",
        ctaPrimary: "Review the expertise",
        ctaSecondary: "Browse recent insights",
        caption: "Visual produced during a study on circulation flows and multimodal wayfinding."
      },
      overview: {
        title: "Reliable cues for urban mobility",
        text: "Built environments demand precise orientation devices. We observe how architecture, digital signage, and user behaviour interact to produce an operational reference bank.",
        card1: {
          title: "Spatial orientation",
          text: "Identifying decision points, prioritising information, and creating coherent journeys for visitors."
        },
        card2: {
          title: "Digital signage",
          text: "Deploying dynamic interfaces synchronised with physical signage to ensure continuous legibility."
        },
        card3: {
          title: "Universal accessibility",
          text: "Integrating accessibility standards and anticipating sensory constraints to enable seamless movement."
        }
      },
      featured: {
        title: "Three pillars of applied research",
        text: "Each pillar builds on field observations, 3D simulations, and feedback collected from public-site management teams.",
        card1: {
          tag: "Mapping",
          title: "Multi-scale plans and circulation scenarios",
          text: "Analysing digital plan sets connecting building levels, intermodal links, and congregation points."
        },
        card2: {
          tag: "UX journeys",
          title: "Narrating critical wayfinding moments",
          text: "Modelling emotions and information needs by user profile to prioritise visual messages."
        },
        card3: {
          tag: "Infrastructure",
          title: "Durable signage ecosystems",
          text: "Assessing materials, digital supports, and maintenance protocols to preserve long-term coherence."
        }
      },
      journeys: {
        title: "Mapping usage to strengthen legibility",
        text: "Our observations cover Belgian stations, hospitals, campuses, and public spaces to document proven orientation practices.",
        card1: {
          title: "Approach diagnostics",
          text: "Locating entry points, analysing crossings, and studying urban interfaces that lead to the sites."
        },
        card2: {
          title: "Narrative charts",
          text: "Translating critical journeys into graphic sequences to guide the design of interactive plans."
        },
        card3: {
          title: "Continuous evaluation",
          text: "Setting indicators to measure user understanding and to fine-tune signage in real time."
        }
      },
      recommendations: {
        title: "Key recommendations",
        text: "A synthesis of practices applicable to Belgian public buildings and high-traffic infrastructures.",
        card1: {
          title: "Prioritise decision zones",
          text: "Mark critical nodes with visual and acoustic cues able to manage heavy footfall without harming clarity."
        },
        card2: {
          title: "Synchronise analogue and digital",
          text: "Maintain graphic and semantic consistency across panels, touch terminals, and mobile supports used by visitors."
        },
        card3: {
          title: "Measure and adjust",
          text: "Set up feedback loops to monitor journey performance and identify targeted micro-adjustments."
        }
      },
      testimonials: {
        title: "Voices from the field",
        text: "Testimonials from public stakeholders underline the importance of a systemic approach to signage.",
        quote1: "The proposed methodology helped us list pain points at each trip stage and prioritise improvements.",
        author1: "Claire Vandeputte",
        role1: "Mobility coordinator, university hospital",
        quote2: "The multi-support mapping eased transfers at our bus hub and reduced orientation requests.",
        author2: "Thomas Renders",
        role2: "Infrastructure manager, transport network",
        quote3: "The scenarios drafted for our campus became the backbone of the future digital signage brief.",
        author3: "Léa Dumont",
        role3: "Accessibility officer, Brussels university"
      },
      insights: {
        title: "Data-driven wayfinding strategy",
        text: "We combine field observations, interactive mapping, and evaluation frameworks to describe replicable solutions.",
        cta: "Discover our approach"
      },
      callout: {
        title: "Structuring a digital signage initiative?",
        text: "We document critical steps, standards, and indicators required to deliver effective wayfinding systems.",
        link: "View contact details"
      }
    },
    servicesPage: {
      hero: {
        badge: "Documented expertise",
        title: "A methodological foundation for orientation systems",
        subtitle: "Each expertise area is grounded in use cases, measurement protocols, and assessment grids tailored to public environments."
      },
      intro: {
        title: "Explored competence areas",
        text: "The six pillars below cover the entire reflection cycle on spatial orientation: diagnosis, design, prototyping, and monitoring."
      },
      items: {
        item1: {
          title: "Orientation challenge analysis",
          text: "Field studies to understand visual, auditory, and tactile obstacles encountered within infrastructures."
        },
        item2: {
          title: "Digital signage principles",
          text: "Selecting graphic and technical standards to align screens, light beacons, and physical supports."
        },
        item3: {
          title: "User journey models",
          text: "Building personas, mapping critical scenarios, and identifying essential information moments."
        },
        item4: {
          title: "Interactive plans and maps",
          text: "Designing multi-level cartographic interfaces with contextual layers, alerts, and accessibility options."
        },
        item5: {
          title: "Legibility and architecture",
          text: "Reviewing contrast, sightlines, and spatial articulation to strengthen immediate comprehension."
        },
        item6: {
          title: "Accessibility and mobility",
          text: "Providing guidelines to ensure inclusive paths, including tactile paving and vocal assistance."
        }
      },
      methodology: {
        title: "Our documentation method",
        text: "We describe each project with service matrices, clear governance, and monitoring indicators to support implementation.",
        point1: "Map stakeholders early on to align responsibilities.",
        point2: "Aggregate mobility data and user feedback to inform choices.",
        point3: "Produce maintenance and update guides to ensure long-term coherence."
      }
    },
    aboutPage: {
      hero: {
        badge: "Vision & governance",
        title: "A platform built on observation and information rigor",
        subtitle: "danswholesaleplants blends applied research and operational documentation to make public spaces intuitive."
      },
      section1: {
        title: "Toward frictionless indoor navigation",
        text: "We analyse orientation devices in context: architecture, actual flows, management goals, and user perception.",
        card1: {
          title: "Interdisciplinary approach",
          text: "Combining design, urban planning, environmental psychology, and technology to inform each decision."
        },
        card2: {
          title: "Continuous observation",
          text: "Regular site visits, photographic records, and interviews to capture micro-situations shaping movement."
        },
        card3: {
          title: "Knowledge capitalisation",
          text: "Every insight is integrated into a structured knowledge base accessible to public partners."
        }
      },
      section2: {
        title: "Guiding principles",
        text: "Our work rests on clarity, inclusion, resilience, and method transparency.",
        point1: "Invest in accessibility from day one rather than at the end of the process.",
        point2: "Share information editorially to secure stakeholder buy-in.",
        point3: "Document trade-offs so they can be reassessed during future evolutions."
      },
      section3: {
        title: "Project organisation",
        text: "We describe key phases and help structure exchanges between public decision-makers, architects, designers, and operators.",
        card1: {
          title: "Framing workshops",
          text: "Defining objectives, terminology, and scope for each site."
        },
        card2: {
          title: "Iterative prototyping",
          text: "Testing scenarios with physical and digital mock-ups to validate legibility."
        },
        card3: {
          title: "Follow-up governance",
          text: "Dashboards to monitor signage condition and schedule updates."
        }
      },
      section4: {
        title: "Collaborating with public stakeholders",
        text: "We provide tools to help Belgian institutions steer their orientation and digital signage systems.",
        cta: "Get in touch"
      }
    },
    blogPage: {
      hero: {
        badge: "Deep dives",
        title: "Insights on indoor navigation and digital wayfinding",
        subtitle: "A curated collection to support spatial orientation decisions."
      },
      list: {
        title: "Latest articles",
        text: "Each piece links concrete examples with methodological principles observed in Belgian public facilities."
      },
      posts: {
        post1: {
          title: "Coordinating multi-channel wayfinding in transit hubs",
          excerpt: "How to align screens, panels, and architectural cues to guide multimodal flows continuously?"
        },
        post2: {
          title: "Hybrid landmarks for complex urban districts",
          excerpt: "Toward intelligible navigation combining digital mapping, micro-signage, and cultural cues."
        },
        post3: {
          title: "Integrating accessibility into public building navigation",
          excerpt: "Keys to combining inclusive standards, tactile routes, and vocal interfaces."
        },
        post4: {
          title: "Interactive plans and circulation metrics",
          excerpt: "Why dashboards of digital plans transform facility management."
        },
        post5: {
          title: "Monitoring pedestrian flows and adaptive scenarios",
          excerpt: "Observe, model, and adjust journeys to absorb attendance variations."
        }
      }
    },
    posts: {
      post1: {
        meta: "Published on 12 February 2024",
        title: "Orchestrating multi-channel wayfinding in transit hubs",
        subtitle: "Align content, supports, and architecture to streamline multimodal navigation.",
        figure: "Perspective of a multimodal hall mixing digital displays and suspended signage.",
        heading1: "Building a shared visual grammar",
        p1: "Belgian transit hubs aggregate multiple transport modes and a high density of information. When metro lines, bus networks, and train transfers overlap, any graphic inconsistency weakens comprehension. The starting point is to define a common visual grammar linking line colours, panel typography, pictograms, and digital terminals. This foundation establishes update conventions and anticipates network growth.",
        p2: "A thorough inventory of supports is essential: hanging direction panels, information columns, façade signage, LED displays, interactive kiosks. Each element receives a primary function—confirm, prepare, reassure—and a content charter. The documentation clarifies the editorial workflow: who validates updates, when to migrate a message from a screen to a static panel, how to highlight temporary disruptions.",
        subheading1: "Aligning physical flows with real-time data",
        p3: "Synchronising physical and digital signage requires a central database supplied by transport operators. Screens and servers should share a single API to reflect timetable updates or incidents. This integration cuts the delay between an event and its display. Because networks can fail, business continuity plans are needed: offline scenarios, preloaded message sets, and procedures for reverting to analogue cues.",
        p4: "On site, pedestrian flows do not always follow planned paths. Anonymous sensors, video observations, or manual counts confront the theoretical layout with reality. The resulting data feeds heatmaps exposing friction zones. Coupling these analyses with incident logs—escalator shutdown, platform congestion—helps adjust message hierarchy on critical supports.",
        heading2: "Measuring assisted journey efficiency",
        p5: "A robust wayfinding strategy relies on clear metrics: average transfer time, number of orientation requests, percentage of turnbacks near a panel. Field teams can correlate these figures with qualitative surveys to grasp confusion points. Dashboards must remain legible to operations staff, with simple alerts highlighting sectors needing content revision.",
        p6: "Whenever a new service is added—shuttle, bike share, human guidance—its impact on existing signage must be tested. A pilot process can engage a sample of users tasked with following a defined scenario. Feedback fuels an improvement matrix ranking actions by effort and potential gain.",
        subheading2: "Securing signage governance",
        p7: "Long-term coordination depends on a committee gathering operators, designers, maintenance teams, and accessibility experts. This group sets the review schedule and validates technical evolutions. It also ensures material consistency, colour durability, and ergonomic standards for interactive interfaces.",
        p8: "Finally, documentation must survive supplier changes. A governance guide summarises terminology, escalation processes, and contacts. Signage thus becomes a living system able to absorb line modifications or works while preserving clear, comfortable orientation for every traveller."
      },
      post2: {
        meta: "Published on 26 March 2024",
        title: "Hybrid landmarks for complex urban districts",
        subtitle: "Balancing collective memory and digital services to guide city dwellers.",
        figure: "District map displaying heritage landmarks and digital supports.",
        heading1: "Understanding the patchwork of a mixed district",
        p1: "Dense urban districts overlap housing, commerce, cultural venues, and transport nodes. This diversity complicates navigation because landmarks differ across user groups. The first step is to create a sensitive map identifying memorable elements—squares, artworks, distinctive façades—and official infrastructure such as transit stops and public facilities.",
        p2: "Qualitative interviews reveal the landmarks spontaneously used by residents. Some mention a well-known café, others a community garden, others an underpass entrance. These insights shape signage design, which should embrace cultural references without sacrificing functional clarity.",
        subheading1: "Linking physical supports with digital services",
        p3: "Once the landmark landscape is mapped, signage must dialogue with digital navigation tools. Web maps, mobile apps, or QR codes align with the nomenclature used on physical panels. Each point of interest receives a unique identifier accessible both in open datasets and on on-site information totems.",
        p4: "Digital interfaces incorporate temporal dynamics: special schedules, cultural events, construction works. Frequent updates maintain relevant suggested routes. During unusual flows—street markets, festivals—temporary signage using the same graphic codes preserves coherence.",
        heading2: "Promoting inclusive mobility",
        p5: "Orientation in a district extends beyond walking. It must consider people with reduced mobility, cyclists, and caregivers with strollers. Routes therefore highlight ramps, urban lifts, accessible toilets, and resting areas. These data appear in printable maps, kiosks, and digital services.",
        p6: "Audio and tactile devices reinforce inclusion. Subtle sound beacons can mark safe crossings. Relief plans accompanied by braille legends complement digital kiosks. Consistency across supports ensures that each visitor navigates with their preferred senses.",
        subheading2: "Evaluating and refining the landmark mesh",
        p7: "On-site surveys and participatory mapping tools detect lingering blind spots. Feedback may indicate an unwelcoming passage or inadequate night visibility. Such signals prompt targeted interventions, sometimes as simple as improved lighting or repositioned panels.",
        p8: "Documenting each modification and its effect builds a transferable reference for other districts. Combining celebrated local memory with reliable digital services creates a shared sense of orientation, reducing information requests and strengthening perceived safety."
      },
      post3: {
        meta: "Published on 15 May 2024",
        title: "Inclusive navigation in public buildings",
        subtitle: "Bringing regulatory requirements and user experience into alignment.",
        figure: "Main axis of a public building with high-contrast accessible signage.",
        heading1: "Auditing current accessibility",
        p1: "Accessibility extends beyond ramps and lifts. It involves readable spaces, adequate contrast, and multimodal information. A thorough audit maps entrances, security checkpoints, waiting points, and evacuation plans.",
        p2: "The review checks installation height, lighting level, and acoustic comfort. Audio devices must remain intelligible despite reverberation or crowd noise.",
        subheading1: "Building multisensory information",
        p3: "Tactile maps, audio beacons, and simplified pictograms align with standard signage. Each support uses the same vocabulary to avoid ambiguity. Audio announcements sync with visuals on screens and panels.",
        p4: "Digital supports include high-contrast themes, voiceover, and keyboard navigation. QR codes link to adaptive content compatible with screen readers.",
        heading2: "Governance and team training",
        p5: "Management teams must understand specific user requirements. This covers operating audio systems, checking beacon status, and anticipating visitors’ needs.",
        p6: "Drills involving specialist associations confront installations with real-life scenarios. Feedback feeds a continuous improvement register.",
        subheading2: "Monitoring and continuous improvement",
        p7: "A dashboard records incidents reported by visitors: faulty sound cues, hidden panels, insufficient light. Actions are prioritised by safety and comprehension impact.",
        p8: "Documenting these actions creates a valuable memory for future refurbishments. It shows that accessibility is a living process supported by vigilant governance and consistent user listening."
      },
      post4: {
        meta: "Published on 02 July 2024",
        title: "Interactive maps and interior circulation metrics",
        subtitle: "Leveraging data to adjust journeys and anticipate congestion.",
        figure: "Interactive map interface displaying real-time circulation flows.",
        heading1: "Building a solid cartographic base",
        p1: "A reliable interactive map starts with accurate modelling: levels, corridors, service areas, lifts. This baseline supports flow simulations and dynamic displays.",
        p2: "Data normalisation guarantees compatibility with various media—touch kiosks, web platforms, internal apps. Each zone receives an identifier, easing statistics extraction.",
        subheading1: "Collecting and interpreting circulation data",
        p3: "Anonymous sensors, visitor badges, manual observations: multiple sources evaluate flows. Analysis highlights peak hours, unexpected waiting zones, and dominant pathways.",
        p4: "Dashboards render data via heatmaps and time series, enabling congestion anticipation and load-shedding scenarios.",
        heading2: "Adjusting signage to observed dynamics",
        p5: "Interactive maps can suggest alternative routes when footfall increases. Screens and physical panels relay recommendations once a saturation threshold is reached.",
        p6: "Visual or audio notifications guide users toward quieter areas, improving overall comfort.",
        subheading2: "Ensuring long-term reliability",
        p7: "A maintenance protocol updates plans after each spatial change. Teams follow a clear workflow to register modifications.",
        p8: "Regular performance reviews keep the interactive map relevant for managers and visitors alike."
      },
      post5: {
        meta: "Published on 18 September 2024",
        title: "Pedestrian flow monitoring and adaptive wayfinding scenarios",
        subtitle: "Moving from observation to real-time journey adjustments.",
        figure: "Diagram showing pedestrian circulation, sensors, and adaptive displays.",
        heading1: "Understanding a site’s rhythms",
        p1: "Monitoring pedestrian flows requires insight into daily, weekly, and seasonal rhythms. Presence sensors, manual counts, and staff feedback outline usage profiles.",
        p2: "Attendance variations reveal recurring scenarios: group arrivals, crowd dispersal, special events. Each scenario demands specific orientation strategies.",
        subheading1: "Designing adaptive scenarios",
        p3: "Digital supports—screens, light beacons, mobile alerts—can switch between message sets based on data inputs. The system may separate inbound and outbound flows when density rises.",
        p4: "Scenarios rely on clear rules: density thresholds, scheduled events, incidents. Editorial teams prepare corresponding messages tested beforehand to avoid ambiguity.",
        heading2: "Measuring adjustment impact",
        p5: "After activating an adaptive scenario, teams compare mobility indicators: shorter wait times, lower crowd density in risk areas, fewer orientation requests.",
        p6: "Audio sensors can track noise levels, revealing stress zones. The goal is to verify that signage contributes to overall comfort.",
        subheading2: "Engaging stakeholders",
        p7: "Success depends on cooperation among managers, security teams, and maintenance staff. Each actor must know the scenarios, trigger thresholds, and escalation steps.",
        p8: "Documenting lessons learned refines rules over time. Scenarios gain precision and responsiveness, ensuring suitable orientation even during unexpected peaks."
      }
    },
    contactPage: {
      hero: {
        badge: "Get in touch",
        title: "Contact details and forms",
        subtitle: "We answer questions about digital signage, interactive plans, and user journey modelling."
      },
      details: {
        title: "Practical information",
        phoneLabel: "Phone",
        phoneValue: "+32 2 123 45 67",
        emailLabel: "Email",
        emailValue: "contact@danswholesaleplants.com",
        addressLabel: "Address",
        addressValue: "Rue de la Loi 200, 1000 Brussels, Belgium",
        hoursLabel: "Availability",
        hoursValue: "Monday to Friday, 9:00 – 17:00"
      },
      form: {
        title: "Contact form",
        subtitle: "Describe your needs: spatial context, wayfinding challenges, expectations for signage.",
        note: "Fields marked with an asterisk are mandatory."
      },
      map: {
        caption: "Location of danswholesaleplants in Brussels — easy access via public transport."
      }
    },
    forms: {
      name: {
        label: "Full name *",
        placeholder: "Your first and last name"
      },
      email: {
        label: "Email address *",
        placeholder: "your.email@example.com"
      },
      org: {
        label: "Organisation",
        placeholder: "Your organisation name"
      },
      subject: {
        label: "Subject *",
        placeholder: "Message subject"
      },
      message: {
        label: "Message *",
        placeholder: "Describe your project or questions"
      },
      submit: "Send",
      note: "By submitting this form, you agree that your information will be used to reply to your request."
    },
    faqPage: {
      hero: {
        badge: "FAQ",
        title: "Frequently asked questions",
        subtitle: "Quick answers about our spatial orientation focus."
      },
      items: {
        q1: "How do you start an orientation audit?",
        a1: "We conduct on-site visits, review existing supports, and interview teams to grasp contextual constraints.",
        q2: "Do you integrate attendance data?",
        a2: "Yes, we use quantitative and qualitative records to document flows and prioritise decision points.",
        q3: "Which interactive plans do you recommend?",
        a3: "We favour modular solutions that combine multiple levels and propose tailored routes.",
        q4: "How do you address accessibility?",
        a4: "We combine regulatory standards, specialist feedback, and user testing to guarantee inclusion.",
        q5: "Do you collaborate with internal teams?",
        a5: "We encourage collaborative workshops to transfer methods and ensure sustainability.",
        q6: "Do you provide performance indicators?",
        a6: "Each project includes a dashboard with legibility metrics, user feedback, and maintenance tracking."
      }
    },
    termsPage: {
      title: "Terms of Use",
      subtitle: "Rules governing site browsing and content usage.",
      section1: {
        title: "1. Purpose",
        body: "These terms set the conditions for accessing and using danswholesaleplants.com."
      },
      section2: {
        title: "2. Acceptance",
        body: "Browsing the site implies full acceptance of the present terms."
      },
      section3: {
        title: "3. Intended audience",
        body: "The site targets professionals and organisations interested in wayfinding and indoor navigation."
      },
      section4: {
        title: "4. Content quality",
        body: "Information is provided for documentation purposes and is not contractual."
      },
      section5: {
        title: "5. Updates",
        body: "Content may be adjusted at any time to reflect evolving knowledge."
      },
      section6: {
        title: "6. Intellectual property",
        body: "Texts, images, and graphics remain the property of danswholesaleplants unless otherwise stated."
      },
      section7: {
        title: "7. Reuse",
        body: "Any reproduction requires prior approval and explicit source attribution."
      },
      section8: {
        title: "8. External links",
        body: "The site may link to third-party resources without responsibility for their content."
      },
      section9: {
        title: "9. Availability",
        body: "We strive to keep the site accessible without guaranteeing uninterrupted service."
      },
      section10: {
        title: "10. Liability",
        body: "danswholesaleplants cannot be held liable for misuse of the information provided."
      },
      section11: {
        title: "11. Personal data",
        body: "Data processing practices are described in the privacy policy."
      },
      section12: {
        title: "12. Cookies",
        body: "Cookie usage is explained on the dedicated page and in the consent banner."
      },
      section13: {
        title: "13. Governing law",
        body: "Belgian law applies. Disputes fall under Brussels courts jurisdiction."
      },
      section14: {
        title: "14. Contact",
        body: "For questions about these terms, please write to contact@danswholesaleplants.com."
      }
    },
    privacyPage: {
      title: "Privacy Policy",
      subtitle: "Details on collecting and using personal data.",
      section1: {
        title: "1. Data controller",
        body: "danswholesaleplants oversees the processing done on danswholesaleplants.com."
      },
      section2: {
        title: "2. Data collected",
        body: "We collect details submitted through the contact form: name, email address, organisation, message subject."
      },
      section3: {
        title: "3. Purpose",
        body: "Data is used to respond to requests and keep a documented record of exchanges."
      },
      section4: {
        title: "4. Legal basis",
        body: "Processing relies on our legitimate interest in replying to inquiries and on the consent given upon submission."
      },
      section5: {
        title: "5. Recipients",
        body: "Data is restricted to the danswholesaleplants team. No transfer occurs without prior agreement."
      },
      section6: {
        title: "6. Retention",
        body: "Messages are stored for up to two years unless legal obligations require otherwise."
      },
      section7: {
        title: "7. Rights",
        body: "You may access, rectify, erase, or object to processing. Contact contact@danswholesaleplants.com."
      },
      section8: {
        title: "8. Security",
        body: "Organisational and technical measures protect data against unauthorised use."
      },
      section9: {
        title: "9. Cookies",
        body: "Cookie usage is described on the dedicated page. You may adjust preferences at any time."
      },
      section10: {
        title: "10. Updates",
        body: "This policy may change. The latest revision date appears at the bottom of the page."
      }
    },
    cookiesPage: {
      title: "Cookie Policy",
      subtitle: "Understand and manage the cookies used on this site.",
      section1: {
        title: "1. Definition",
        body: "A cookie is a text file stored on your device when visiting the site."
      },
      section2: {
        title: "2. Consent",
        body: "During your first visit, you can accept, decline, or customise cookie usage."
      },
      section3: {
        title: "3. Management",
        body: "You can revisit your choices via the banner or the management link in the footer."
      },
      section4: {
        title: "4. Cookie categories",
        body: "We distinguish necessary, preference, analytics, and marketing cookies."
      },
      table: {
        title: "Cookie inventory",
        intro: "The list below shows the cookies that may be stored on your device.",
        headers: {
          name: "Name",
          provider: "Provider",
          type: "Type",
          purpose: "Purpose",
          duration: "Duration"
        },
        rows: {
          row1: {
            name: "cookie_consent",
            provider: "danswholesaleplants",
            type: "Necessary",
            purpose: "Stores the choices made in the consent banner.",
            duration: "12 months"
          },
          row2: {
            name: "site_lang",
            provider: "danswholesaleplants",
            type: "Preferences",
            purpose: "Remembers the selected language.",
            duration: "12 months"
          },
          row3: {
            name: "analytics_flow",
            provider: "danswholesaleplants",
            type: "Analytics",
            purpose: "Aggregated measurement of user journeys.",
            duration: "24 months"
          },
          row4: {
            name: "outreach_context",
            provider: "danswholesaleplants",
            type: "Marketing",
            purpose: "Assesses interest shown in editorial resources.",
            duration: "6 months"
          }
        }
      },
      section5: {
        title: "5. Browser settings",
        body: "You can configure your browser to delete cookies or notify you before installation."
      },
      section6: {
        title: "6. Contact",
        body: "For cookie-related questions, write to contact@danswholesaleplants.com."
      }
    },
    refundPage: {
      title: "Cancellation Policy",
      subtitle: "Terms applicable when modifying or cancelling contributions.",
      section1: {
        title: "1. Scope",
        body: "This policy applies to the informative content and exchanges carried out through the site."
      },
      section2: {
        title: "2. Service nature",
        body: "The site does not sell paid services. Access to resources is free of charge."
      },
      section3: {
        title: "3. Withdrawal requests",
        body: "You may request removal of a testimonial or citation by writing to the contact address."
      },
      section4: {
        title: "4. Rectification",
        body: "Reported inaccuracies are reviewed promptly."
      },
      section5: {
        title: "5. Downtime",
        body: "No financial compensation is offered if the site is temporarily unavailable."
      },
      section6: {
        title: "6. External contributions",
        body: "Guest contributions may be removed if they no longer reflect editorial goals."
      },
      section7: {
        title: "7. Notice",
        body: "Substantial changes are announced via a notice on the site."
      },
      section8: {
        title: "8. Documentation",
        body: "Recorded exchanges may be archived to ensure traceability."
      },
      section9: {
        title: "9. Force majeure",
        body: "Events beyond our control may delay request processing."
      },
      section10: {
        title: "10. Contact",
        body: "For inquiries, email contact@danswholesaleplants.com."
      }
    },
    disclaimerPage: {
      title: "Disclaimer",
      subtitle: "Limits and responsibilities regarding published content.",
      section1: {
        title: "1. No warranty",
        body: "Information is provided for guidance only. We do not guarantee completeness or permanent accuracy."
      },
      section2: {
        title: "2. Use of content",
        body: "Users remain responsible for interpreting and applying the information shared."
      },
      section3: {
        title: "3. No professional advice",
        body: "Content does not constitute professional advice. It complements your own assessments."
      },
      section4: {
        title: "4. External links",
        body: "Outgoing links are provided for convenience. We decline responsibility for their content."
      },
      section5: {
        title: "5. Changes",
        body: "Information may be updated without notice to incorporate new findings."
      },
      section6: {
        title: "6. Contact",
        body: "To report an error or omission, email contact@danswholesaleplants.com."
      }
    },
    thankPage: {
      title: "Thank you for your message",
      message: "Your request has been received. We will review your wayfinding inquiry and respond shortly.",
      cta: "Return to homepage"
    },
    notFound: {
      title: "Page not found",
      message: "The requested content is not available. Check the URL or explore our spatial orientation resources.",
      cta: "Back to homepage"
    },
    cookie: {
      message: "We use cookies to ensure site functionality and analyse traffic.",
      manage: "Manage preferences",
      sectionIntro: "Adjust the categories below according to your needs.",
      necessary: "Necessary cookies",
      necessaryDescription: "Required for site operation and to store your choices.",
      preferences: "Preference cookies",
      preferencesDescription: "Remember language and other comfort settings.",
      analytics: "Analytics cookies",
      analyticsDescription: "Help us understand navigation patterns to improve content.",
      marketing: "Marketing cookies",
      marketingDescription: "Used to qualify interest in our editorial resources.",
      accept: "Accept all",
      decline: "Decline all",
      save: "Save"
    },
    toast: {
      contactPending: "Thanks, your message is being prepared.",
      contactRedirect: "Redirecting to the confirmation page.",
      cookiesSaved: "Cookie preferences saved.",
      cookiesDeclined: "Non-essential cookies disabled.",
      languageChanged: "Language updated."
    },
    images: {
      homeHero: "Digital wayfinding hall with dynamic signage",
      blog1: "Signage screens within a transport hub",
      blog2: "Urban perspective with visual cues",
      blog3: "Accessible interior route",
      blog4: "Interactive plan on a touch table",
      blog5: "Aerial view of pedestrian flows",
      post1Hero: "Multimodal transit interface",
      post2Hero: "Hybrid signage in an urban district",
      post3Hero: "Inclusive signage inside a public building",
      post4Hero: "Digital plan displaying circulation data",
      post5Hero: "Sensors and adaptive displays guiding pedestrians"
    }
  }
};

const DEFAULT_LANG = "fr";
const LANG_KEY = "site_lang";
const COOKIE_KEY = "cookie_consent";

function getSavedLanguage() {
  const stored = localStorage.getItem(LANG_KEY);
  if (stored && (stored === "fr" || stored === "en")) {
    return stored;
  }
  return DEFAULT_LANG;
}

function setLanguage(lang) {
  const finalLang = lang === "en" ? "en" : "fr";
  localStorage.setItem(LANG_KEY, finalLang);
  document.documentElement.lang = finalLang;
  applyTranslations(finalLang);
  updateActiveLanguageButton(finalLang);
  showToast(I18N[finalLang].toast.languageChanged);
}

function applyTranslations(lang) {
  const dict = I18N[lang];
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.dataset.i18n;
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.textContent = value;
    }
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.dataset.i18nPlaceholder;
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("placeholder", value);
    }
  });

  document.querySelectorAll("[data-i18n-alt]").forEach((el) => {
    const key = el.dataset.i18nAlt;
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("alt", value);
    }
  });

  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    const key = el.dataset.i18nTitle;
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      if (el.tagName.toLowerCase() === "title") {
        document.title = value;
      } else {
        el.setAttribute("title", value);
      }
    }
  });

  document.querySelectorAll("[data-i18n-meta]").forEach((el) => {
    const key = el.dataset.i18nMeta;
    const value = resolveTranslation(dict, key);
    if (value !== null) {
      el.setAttribute("content", value);
    }
  });
}

function resolveTranslation(dict, path) {
  const segments = path.split(".");
  let current = dict;
  for (const segment of segments) {
    if (current && Object.prototype.hasOwnProperty.call(current, segment)) {
      current = current[segment];
    } else {
      return null;
    }
  }
  return typeof current === "string" ? current : null;
}

function updateActiveLanguageButton(lang) {
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    if (btn.dataset.lang === lang) {
      btn.classList.add("active");
    } else {
      btn.classList.remove("active");
    }
  });
}

function initLanguage() {
  const initial = getSavedLanguage();
  document.documentElement.lang = initial;
  applyTranslations(initial);
  updateActiveLanguageButton(initial);
  document.querySelectorAll(".language-switcher button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const targetLang = btn.dataset.lang;
      if (targetLang) {
        setLanguage(targetLang);
      }
    });
  });
}

function initNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".primary-nav");
  if (!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", isOpen);
  });
  document.addEventListener("click", (event) => {
    if (!nav.contains(event.target) && !toggle.contains(event.target)) {
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    }
  });
}

function initAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  document.querySelectorAll(".animate-on-scroll").forEach((el) => observer.observe(el));
}

function initFooterYear() {
  const yearEl = document.getElementById("footerYear");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
}

function getCookieConsent() {
  const stored = localStorage.getItem(COOKIE_KEY);
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {
      return null;
    }
  }
  return null;
}

function saveCookieConsent(consent) {
  localStorage.setItem(COOKIE_KEY, JSON.stringify(consent));
}

function applyCookieUI(consent) {
  document.querySelectorAll("input[data-cookie-category]").forEach((input) => {
    const category = input.dataset.cookieCategory;
    if (category === "necessary") return;
    if (consent && Object.prototype.hasOwnProperty.call(consent, category)) {
      input.checked = !!consent[category];
    } else {
      input.checked = false;
    }
  });
}

function initCookieBanner() {
  const banner = document.getElementById("cookieBanner");
  const manageButton = document.querySelector("[data-cookie-manage]");
  const preferencesPanel = document.getElementById("cookiePreferences");
  const acceptButton = document.querySelector("[data-cookie-accept]");
  const declineButton = document.querySelector("[data-cookie-decline]");
  const saveButton = document.querySelector("[data-cookie-save]");
  const manageOpenButtons = document.querySelectorAll("[data-manage-open]");

  if (!banner || !manageButton || !preferencesPanel) return;

  const consent = getCookieConsent();
  if (!consent) {
    banner.classList.add("active");
  } else {
    applyCookieUI(consent);
  }

  manageButton.addEventListener("click", () => {
    preferencesPanel.classList.toggle("active");
  });

  manageOpenButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      banner.classList.add("active");
      preferencesPanel.classList.add("active");
    });
  });

  function gatherConsent(defaultValue) {
    const consentState = {
      necessary: true,
      preferences: defaultValue,
      analytics: defaultValue,
      marketing: defaultValue,
      timestamp: new Date().toISOString()
    };
    if (!defaultValue) {
      document.querySelectorAll("input[data-cookie-category]").forEach((input) => {
        if (input.dataset.cookieCategory !== "necessary") {
          input.checked = false;
        }
      });
    } else {
      document.querySelectorAll("input[data-cookie-category]").forEach((input) => {
        if (input.dataset.cookieCategory !== "necessary") {
          input.checked = true;
        }
      });
    }
    saveCookieConsent(consentState);
    return consentState;
  }

  acceptButton.addEventListener("click", () => {
    const consentState = gatherConsent(true);
    showToast(resolveTranslationForToast("cookiesSaved"));
    banner.classList.remove("active");
    applyCookieUI(consentState);
  });

  declineButton.addEventListener("click", () => {
    const consentState = gatherConsent(false);
    showToast(resolveTranslationForToast("cookiesDeclined"));
    banner.classList.remove("active");
    applyCookieUI(consentState);
  });

  saveButton.addEventListener("click", () => {
    const consentState = {
      necessary: true,
      preferences: false,
      analytics: false,
      marketing: false,
      timestamp: new Date().toISOString()
    };
    document.querySelectorAll("input[data-cookie-category]").forEach((input) => {
      const category = input.dataset.cookieCategory;
      if (category === "necessary") return;
      consentState[category] = input.checked;
    });
    saveCookieConsent(consentState);
    showToast(resolveTranslationForToast("cookiesSaved"));
    banner.classList.remove("active");
  });

  const storedConsent = getCookieConsent();
  if (storedConsent) {
    applyCookieUI(storedConsent);
  }
}

function resolveTranslationForToast(key) {
  const lang = document.documentElement.lang === "en" ? "en" : "fr";
  const toastDict = I18N[lang].toast;
  if (toastDict && Object.prototype.hasOwnProperty.call(toastDict, key)) {
    return toastDict[key];
  }
  return "";
}

function showToast(message) {
  if (!message) return;
  const container = document.querySelector(".toast-container");
  if (!container) return;
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("fade-out");
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.3s ease";
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 3500);
}

function initForms() {
  document.querySelectorAll("form[data-toast='contact']").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast(resolveTranslationForToast("contactPending"));
      setTimeout(() => {
        showToast(resolveTranslationForToast("contactRedirect"));
        window.location.href = form.getAttribute("action") || "thank-you.html";
      }, 800);
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initNavToggle();
  initAnimations();
  initFooterYear();
  initCookieBanner();
  initForms();
});