import React, { useState } from "react";

const servicesDetail = [
  {
    title: "Transformation Strategy",
    summary:
      "We align every initiative to measurable outcomes while equipping leadership with clear governance and insight.",
    bullets: [
      "Vision articulation and executive alignment",
      "Capability assessments and maturity benchmarking",
      "Portfolio prioritization and roadmap creation",
      "Operating model design and change orchestration",
    ],
  },
  {
    title: "Experience Design",
    summary:
      "Human-centered design systems and journeys that deliver intuitive, brand-defining interactions customers love.",
    bullets: [
      "Customer and employee research",
      "Journey mapping and service blueprints",
      "Experience prototyping and testing",
      "Design system creation and governance",
    ],
  },
  {
    title: "Product Engineering",
    summary:
      "Modern engineering practices to deliver high-performing platforms that scale with your ambitions.",
    bullets: [
      "Cloud-native architecture and DevOps enablement",
      "Modular platform development",
      "SRE, QA automation, and performance optimization",
      "Legacy modernization and integration",
    ],
  },
  {
    title: "Data Intelligence",
    summary:
      "Turn your data into an always-on advantage with unified platforms and intelligent insights.",
    bullets: [
      "Data strategy and governance frameworks",
      "Analytics modernization and visualization",
      "Machine learning and predictive modeling",
      "AI enablement and responsible AI practices",
    ],
  },
];

const Services = () => {
  const [activeService, setActiveService] = useState(servicesDetail[0].title);

  const currentService = servicesDetail.find(
    (service) => service.title === activeService
  );

  return (
    <div className="inner-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Our Services</span>
          <h1>Integrated capabilities for digital-first leaders.</h1>
          <p>
            NovaEdge builds tailor-made teams that combine strategic insight,
            design excellence, engineering rigor, and data intelligence to drive
            measurable business outcomes.
          </p>
        </div>
      </section>

      <section className="services-tabs">
        <div className="container">
          <div className="tabs-list" role="tablist">
            {servicesDetail.map((service) => (
              <button
                key={service.title}
                className={`tab-btn ${
                  activeService === service.title ? "is-active" : ""
                }`}
                onClick={() => setActiveService(service.title)}
                role="tab"
                aria-selected={activeService === service.title}
              >
                {service.title}
              </button>
            ))}
          </div>
          <div className="tab-panel" role="tabpanel">
            <div className="tab-panel-content">
              <h2>{currentService.title}</h2>
              <p>{currentService.summary}</p>
              <ul className="service-bullets">
                {currentService.bullets.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className="tab-panel-visual">
              <img
                src="https://picsum.photos/800/600?random=202"
                alt={`${currentService.title} consultation in progress`}
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="service-highlights">
        <div className="container">
          <h2>What sets NovaEdge apart</h2>
          <div className="highlight-grid">
            <div className="highlight-card">
              <h3>Co-creation by design</h3>
              <p>
                We embed with your teams to align vision, accelerate value, and
                ensure lasting adoption of the products and practices we build.
              </p>
            </div>
            <div className="highlight-card">
              <h3>Value-obsessed delivery</h3>
              <p>
                Every sprint is mapped to business outcomes, with real-time
                reporting and analytics that keep stakeholders aligned.
              </p>
            </div>
            <div className="highlight-card">
              <h3>Enterprise-ready craft</h3>
              <p>
                Our solutions are compliant, secure, modular, and engineered to
                integrate seamlessly into complex enterprise environments.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="partnership-cta">
        <div className="container cta-inner">
          <div className="cta-text">
            <h2>Shape your next chapter with NovaEdge.</h2>
            <p>
              Share your aspirations and we’ll assemble a tailored team to
              deliver momentum from day one.
            </p>
          </div>
          <a className="btn btn-secondary" href="/contact">
            Book a consultation
          </a>
        </div>
      </section>
    </div>
  );
};

export default Services;