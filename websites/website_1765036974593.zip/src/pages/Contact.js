import React, { useState } from "react";

const initialState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const Contact = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Please enter your name.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email address.";
    } else if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())
    ) {
      newErrors.email = "Please provide a valid email.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Let us know how we can help.";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(initialState);
  };

  return (
    <div className="inner-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Contact</span>
          <h1>Let’s build the next wave of digital excellence together.</h1>
          <p>
            Share your vision, challenges, and goals. We’ll assemble a tailored
            team to design a program that delivers impact from day one.
          </p>
        </div>
      </section>

      <section className="contact-section">
        <div className="container contact-grid">
          <div className="contact-details">
            <h2>Ways to connect</h2>
            <p>
              We collaborate across time zones and industries. Reach out to start
              a conversation about your transformation journey.
            </p>
            <div className="contact-card">
              <h3>Call</h3>
              <a href="tel:+1234567890">+1 (234) 567-890</a>
            </div>
            <div className="contact-card">
              <h3>Email</h3>
              <a href="mailto:hello@novaedgeconsulting.com">
                hello@novaedgeconsulting.com
              </a>
            </div>
            <div className="contact-card">
              <h3>Visit</h3>
              <p>121 Innovation Drive<br />Austin, TX 73301</p>
            </div>
          </div>

          <div className="contact-form-wrapper">
            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <div className="form-field">
                <label htmlFor="name">Full name*</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Your name"
                  value={formData.name}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.name)}
                />
                {errors.name && <span className="error">{errors.name}</span>}
              </div>

              <div className="form-field">
                <label htmlFor="email">Work email*</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="name@company.com"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                />
                {errors.email && <span className="error">{errors.email}</span>}
              </div>

              <div className="form-field">
                <label htmlFor="company">Company</label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  placeholder="Company name"
                  value={formData.company}
                  onChange={handleChange}
                />
              </div>

              <div className="form-field">
                <label htmlFor="message">How can we support you?*</label>
                <textarea
                  id="message"
                  name="message"
                  rows="6"
                  placeholder="Tell us about your project, goals, or challenges."
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                />
                {errors.message && (
                  <span className="error">{errors.message}</span>
                )}
              </div>

              <button type="submit" className="btn btn-primary">
                Submit inquiry
              </button>

              {submitted && (
                <p className="success-message">
                  Thank you! Our team will reach out within one business day.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;