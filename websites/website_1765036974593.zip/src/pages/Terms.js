import React from "react";

const Terms = () => {
  return (
    <div className="inner-page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Terms &amp; Conditions</span>
          <h1>NovaEdge Consulting Website Terms of Use</h1>
          <p>
            These terms outline the conditions that govern your access and use of
            the NovaEdge Consulting website and related services.
          </p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container narrow">
          <h2>1. Acceptance of terms</h2>
          <p>
            By accessing this website, you agree to comply with these terms and
            all applicable laws and regulations. If you do not agree, you are
            prohibited from using or accessing this site.
          </p>

          <h2>2. Use of content</h2>
          <p>
            All information, text, graphics, and materials are the intellectual
            property of NovaEdge Consulting and may not be reproduced or
            distributed without prior written consent.
          </p>

          <h2>3. Disclaimer</h2>
          <p>
            The materials on this site are provided “as is”. NovaEdge Consulting
            makes no warranties, expressed or implied, and disclaims all other
            warranties including, without limitation, implied warranties of
            merchantability or fitness for a particular purpose.
          </p>

          <h2>4. Limitations</h2>
          <p>
            In no event shall NovaEdge Consulting or its suppliers be liable for
            any damages arising out of the use or inability to use the materials
            on this site, even if NovaEdge or its representative has been
            notified orally or in writing of the possibility of such damage.
          </p>

          <h2>5. Governing law</h2>
          <p>
            These terms are governed by the laws of the State of Texas, United
            States, without regard to its conflict of law provisions.
          </p>

          <h2>6. Updates</h2>
          <p>
            We may revise these terms at any time without notice. By using this
            website, you agree to be bound by the current version of these terms.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;