import React from "react";

const Privacy = () => {
  return (
    <div className="inner-page legal-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">Privacy Policy</span>
          <h1>Your privacy matters to NovaEdge Consulting.</h1>
          <p>
            This policy explains how we collect, use, disclose, and safeguard the
            information you share with us through this website.
          </p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container narrow">
          <h2>1. Information we collect</h2>
          <p>
            We collect personal information you voluntarily provide, such as your
            name, email, company, and message details. We may also collect usage
            data through analytics tools to improve our services.
          </p>

          <h2>2. How we use information</h2>
          <p>
            We use collected data to respond to inquiries, deliver requested
            services, analyze performance, and enhance user experience. We may
            also send relevant updates or insights if you have opted in.
          </p>

          <h2>3. Cookies</h2>
          <p>
            We use cookies to personalize content, remember preferences, and
            analyze site usage. You can adjust your browser settings to decline
            cookies; however, some features may not function as intended.
          </p>

          <h2>4. Sharing of information</h2>
          <p>
            We do not sell your personal information. We may share data with
            trusted partners who assist in operating our website, provided they
            agree to maintain confidentiality and comply with privacy standards.
          </p>

          <h2>5. Data security</h2>
          <p>
            We implement administrative, technical, and physical safeguards to
            protect your information. While we strive for security, we cannot
            guarantee absolute protection.
          </p>

          <h2>6. Your rights</h2>
          <p>
            Depending on your jurisdiction, you may have rights to access,
            correct, or delete your personal information. Contact us at
            privacy@novaedgeconsulting.com to exercise these rights.
          </p>

          <h2>7. Updates</h2>
          <p>
            We may update this policy to reflect changes in our practices. The
            updated version will be indicated by a revised “Effective date”.
          </p>

          <p className="effective-date">Effective date: April 30, 2024</p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;