import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

const useInView = (options = {}) => {
  const ref = useRef(null);
  const [isIntersecting, setIntersecting] = useState(false);

  useEffect(() => {
    if (!ref.current) return;

    if (!("IntersectionObserver" in window)) {
      setIntersecting(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIntersecting(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.3, ...options }
    );

    observer.observe(ref.current);

    return () => observer.disconnect();
  }, [options]);

  return [ref, isIntersecting];
};

const statsData = [
  { label: "Digital programs launched", value: 120 },
  { label: "Enterprise partners", value: 58 },
  { label: "Average ROI uplift", value: 37, suffix: "%" },
  { label: "Customer experience awards", value: 24 },
];

const servicesData = [
  {
    title: "Transformation Strategy",
    description:
      "Future-proof roadmaps aligned to growth targets, built on deep market intelligence and adaptive models.",
    link: "/services",
  },
  {
    title: "Experience Design",
    description:
      "Human-centered experiences shaped through research, prototyping, and precision-crafted design systems.",
    link: "/services",
  },
  {
    title: "Product Engineering",
    description:
      "Cloud-native platforms engineered for velocity, reliability, and measurable customer outcomes.",
    link: "/services",
  },
  {
    title: "Data Intelligence",
    description:
      "Unified data ecosystems, predictive analytics, and decision science to unlock competitive advantage.",
    link: "/services",
  },
];

const processSteps = [
  {
    number: "01",
    title: "Discover & Diagnose",
    description:
      "Immersive stakeholder workshops, journey mapping, and technology audits uncover high-impact opportunities.",
  },
  {
    number: "02",
    title: "Design & Prototype",
    description:
      "Rapid concept iteration with cross-functional teams to validate experiences and model value potential.",
  },
  {
    number: "03",
    title: "Build & Integrate",
    description:
      "Iterative delivery with continuous QA and integration to existing ecosystems for zero-disruption adoption.",
  },
  {
    number: "04",
    title: "Scale & Optimize",
    description:
      "Performance analytics and governance frameworks drive lasting value and continuous innovation.",
  },
];

const testimonialsData = [
  {
    quote:
      "NovaEdge reframed our entire digital ecosystem, accelerating delivery velocity while boosting CSAT by 28%. Their team felt like an extension of ours.",
    name: "Amelia Watkins",
    role: "Chief Digital Officer, Helix Global",
  },
  {
    quote:
      "From strategy to execution, NovaEdge consistently over-delivered. We launched a new flagship experience in record time with flawless stability.",
    name: "Jordan Rivera",
    role: "VP Product, Horizon Ventures",
  },
  {
    quote:
      "Their data-driven approach transformed how we operate. We now understand our customers in real time and respond before competitors can react.",
    name: "Priya Desai",
    role: "Director of Transformation, Luminate Financial",
  },
];

const teamMembers = [
  {
    name: "Evelyn Clark",
    role: "Founder & CEO",
    image: "https://picsum.photos/400/400?random=301",
    bio: "Strategic advisor to Fortune 500 executives, translating ambition into transformational programs.",
  },
  {
    name: "Marcus Hill",
    role: "Chief Experience Officer",
    image: "https://picsum.photos/400/400?random=302",
    bio: "Leads our design practice, advocating for human-centered innovation across every touchpoint.",
  },
  {
    name: "Sophia Nguyen",
    role: "Head of Engineering",
    image: "https://picsum.photos/400/400?random=303",
    bio: "Architects resilient digital ecosystems underpinned by modern engineering excellence.",
  },
  {
    name: "Daniel Price",
    role: "Director of Data Strategy",
    image: "https://picsum.photos/400/400?random=304",
    bio: "Brings clarity to complex data landscapes, empowering smarter, faster decision-making.",
  },
];

const projectData = [
  {
    title: "Omni-Channel Retail Evolution",
    category: "Strategy",
    image: "https://picsum.photos/1200/800?random=401",
    description:
      "Unified commerce journey delivering 2.4x increase in customer lifetime value for a global retailer.",
  },
  {
    title: "Next-Gen Banking Mobile Platform",
    category: "Development",
    image: "https://picsum.photos/1200/800?random=402",
    description:
      "Modular mobile architecture enabling monthly product releases and 40% faster onboarding.",
  },
  {
    title: "AI-Powered Support Assistant",
    category: "Innovation",
    image: "https://picsum.photos/1200/800?random=403",
    description:
      "Conversational AI agent reducing handling time by 55% while elevating satisfaction scores.",
  },
  {
    title: "Experience Design System",
    category: "Design",
    image: "https://picsum.photos/1200/800?random=404",
    description:
      "Scalable design language aligning eight business units with unified visual and interaction patterns.",
  },
];

const faqData = [
  {
    question: "How quickly can we launch a transformation initiative with NovaEdge?",
    answer:
      "Discovery typically begins within two weeks. From there, we co-design a transformation roadmap with clear outcomes, milestones, and governance. Most clients see measurable improvements within the first 90 days.",
  },
  {
    question: "Do you partner with internal teams or deliver fully managed programs?",
    answer:
      "We do both. Many organizations engage us to accelerate internal capability, pairing our specialists with your teams. Others rely on NovaEdge for end-to-end delivery. We architect engagement models that align to your operating reality.",
  },
  {
    question: "Which industries do you specialize in?",
    answer:
      "We serve financial services, retail, healthcare, and B2B technology organizations. Our frameworks adapt to any industry where digital experience, data, and technology can unlock growth and loyalty.",
  },
  {
    question: "What level of data maturity is required to work with you?",
    answer:
      "We meet clients where they are. Whether you're consolidating data sources or implementing predictive analytics, we build pragmatic roadmaps to reach your vision while showing value at every stage.",
  },
];

const blogPosts = [
  {
    title: "Designing Next-Generation Customer Journeys",
    excerpt:
      "Three strategies for aligning customer insight, personalization, and operational agility to deliver breakthrough experiences.",
    image: "https://picsum.photos/800/600?random=501",
    link: "/services",
    date: "March 29, 2024",
  },
  {
    title: "Building Resilient Digital Platforms",
    excerpt:
      "How platform thinking, modular architecture, and SRE practices help enterprises move at startup speed without sacrificing control.",
    image: "https://picsum.photos/800/600?random=502",
    link: "/about",
    date: "April 12, 2024",
  },
  {
    title: "Data Culture Playbook for Leaders",
    excerpt:
      "A practical approach for establishing modern data governance and literacy while fostering innovation across teams.",
    image: "https://picsum.photos/800/600?random=503",
    link: "/contact",
    date: "April 26, 2024",
  },
];

const Home = () => {
  const [statsRef, statsVisible] = useInView();
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [activeCategory, setActiveCategory] = useState("All");
  const [openFaq, setOpenFaq] = useState(null);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const categories = useMemo(
    () => ["All", ...new Set(projectData.map((project) => project.category))],
    []
  );

  useEffect(() => {
    let animationFrame;
    if (statsVisible) {
      const duration = 1600;
      const start = performance.now();
      const animate = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        const eased = progress * (2 - progress);
        setCounts(
          statsData.map((stat) =>
            Math.round(stat.value * eased)
          )
        );
        if (progress < 1) {
          animationFrame = requestAnimationFrame(animate);
        }
      };
      animationFrame = requestAnimationFrame(animate);
    }
    return () => cancelAnimationFrame(animationFrame);
  }, [statsVisible]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial(
        (prev) => (prev + 1) % testimonialsData.length
      );
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects =
    activeCategory === "All"
      ? projectData
      : projectData.filter((project) => project.category === activeCategory);

  const handleFaqToggle = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className="home-page">
      <section className="hero">
        <div className="container hero-content">
          <div className="hero-copy">
            <span className="eyebrow">Strategic Digital Transformation</span>
            <h1>
              Build experiences that win customers and unlock enduring growth.
            </h1>
            <p>
              NovaEdge Consulting partners with modern enterprises to architect
              digital strategies, design human-centered experiences, and deliver
              resilient products that outperform expectations.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn btn-primary">
                Start a Project
              </Link>
              <Link to="/about" className="btn btn-ghost">
                Explore our approach
              </Link>
            </div>
            <div className="hero-meta">
              <div>
                <span className="meta-label">Trusted by</span>
                <span className="meta-value">Global brands &amp; scale-ups</span>
              </div>
              <div>
                <span className="meta-label">Success rate</span>
                <span className="meta-value">96% program completion</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <img
              src="https://picsum.photos/1600/900?random=101"
              alt="Business leaders collaborating on digital strategy"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <span className="stat-value">
                {counts[index]}
                {stat.suffix || ""}
                {counts[index] === stat.value ? "+" : ""}
              </span>
              <span className="stat-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="services-overview">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Capabilities</span>
            <h2>Integrated services that turn ambition into measurable value</h2>
            <p>
              From insight to implementation, we orchestrate multidisciplinary
              teams that deliver clarity, velocity, and results. Each engagement
              is tailored to your operating model and goals.
            </p>
          </div>
          <div className="services-grid">
            {servicesData.map((service) => (
              <article className="service-card" key={service.title}>
                <div className="service-card-content">
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                </div>
                <Link to={service.link} className="service-link">
                  Discover more
                  <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="process">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">How we work</span>
            <h2>Collaborative journey from discovery to continuous impact</h2>
            <p>
              Our proven framework ensures every initiative delivers rapid wins
              while laying the foundation for long-term transformation.
            </p>
          </div>
          <div className="process-timeline">
            {processSteps.map((step) => (
              <div className="process-step" key={step.number}>
                <span className="process-number">{step.number}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container testimonial-container">
          <div className="testimonial-copy">
            <span className="eyebrow">Client Stories</span>
            <h2>Leaders count on NovaEdge to accelerate transformation.</h2>
            <p>
              We align with your vision, co-create value, and deliver momentum.
              Our clients span industries, but share an ambition for bold,
              customer-centric change.
            </p>
            <Link to="/contact" className="btn btn-secondary">
              Let's build together
            </Link>
          </div>
          <div className="testimonial-slider" aria-live="polite">
            {testimonialsData.map((testimonial, index) => (
              <blockquote
                key={testimonial.name}
                className={`testimonial-card ${
                  index === currentTestimonial ? "is-active" : ""
                }`}
              >
                <p>“{testimonial.quote}”</p>
                <footer>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
            <div className="testimonial-dots">
              {testimonialsData.map((_, index) => (
                <button
                  key={index}
                  className={`dot ${
                    index === currentTestimonial ? "is-active" : ""
                  }`}
                  onClick={() => setCurrentTestimonial(index)}
                  aria-label={`View testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Leadership</span>
            <h2>The strategists, designers, and engineers shaping your future</h2>
            <p>
              Our cross-functional leadership team brings decades of experience
              guiding enterprises through pivotal transformations.
            </p>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <article className="team-card" key={member.name}>
                <img
                  src={member.image}
                  alt={`${member.name}, ${member.role}`}
                  loading="lazy"
                />
                <div className="team-card-body">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="projects">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Case studies</span>
            <h2>High-impact projects engineered for measurable outcomes</h2>
            <p>
              Explore a selection of engagements where NovaEdge transformed
              complexity into strategic advantage.
            </p>
          </div>
          <div className="project-filters">
            {categories.map((category) => (
              <button
                key={category}
                className={`filter-btn ${
                  activeCategory === category ? "is-active" : ""
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="project-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.title}>
                <div className="project-image-wrapper">
                  <img
                    src={project.image}
                    alt={`${project.title} showcase`}
                    loading="lazy"
                  />
                </div>
                <div className="project-card-body">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/contact" className="project-link">
                    Request full case study
                    <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">FAQ</span>
            <h2>Answers to common questions</h2>
            <p>
              We believe transparency aligns expectations from day one. Here are
              the essentials leaders ask before partnering with NovaEdge.
            </p>
          </div>
          <div className="faq-accordion">
            {faqData.map((item, index) => (
              <div
                className={`faq-item ${openFaq === index ? "is-open" : ""}`}
                key={item.question}
              >
                <button
                  className="faq-question"
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={openFaq === index}
                >
                  {item.question}
                  <span className="faq-icon" aria-hidden="true">
                    {openFaq === index ? "–" : "+"}
                  </span>
                </button>
                <div className="faq-answer">
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="blog">
        <div className="container">
          <div className="section-heading">
            <span className="eyebrow">Insights</span>
            <h2>Latest thinking from NovaEdge</h2>
            <p>
              Perspectives, frameworks, and playbooks designed to help leaders
              navigate digital transformation with confidence.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <div className="blog-image-wrapper">
                  <img
                    src={post.image}
                    alt={post.title}
                    loading="lazy"
                  />
                </div>
                <div className="blog-card-body">
                  <span className="blog-date">{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className="blog-link">
                    Continue reading
                    <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="container cta-inner">
          <div className="cta-text">
            <h2>Ready to accelerate your transformation?</h2>
            <p>
              Let’s co-create a roadmap that delivers rapid wins, unlocks new
              value streams, and equips your teams for sustained innovation.
            </p>
          </div>
          <Link to="/contact" className="btn btn-light">
            Schedule a strategy session
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;