import React from "react";

const About = () => {
  return (
    <div className="inner-page">
      <section className="page-hero">
        <div className="container narrow">
          <span className="eyebrow">About NovaEdge</span>
          <h1>Our team turns transformation into enduring advantage.</h1>
          <p>
            NovaEdge Consulting was founded to help visionary leaders harness
            digital opportunity with precision and confidence. With a blend of
            strategy, design, engineering, and data expertise, we build programs
            that uplift customer experiences and accelerate growth.
          </p>
        </div>
      </section>

      <section className="story">
        <div className="container split">
          <div>
            <h2>Why we exist</h2>
            <p>
              The world’s most admired brands stay ahead by embracing iteration,
              learning faster than competitors, and investing in customer
              empathy. We created NovaEdge to unlock that capacity for every
              organization, regardless of their starting point.
            </p>
            <p>
              We bring together experienced strategists, researchers, designers,
              engineers, and change leaders. Our team thrives at the intersection
              of human insight and technical execution, ensuring every solution
              is viable, desirable, and scalable.
            </p>
          </div>
          <div>
            <h3>Our values</h3>
            <ul className="values-list">
              <li>
                <strong>Elevation:</strong> We raise the bar with every
                engagement, creating outcomes that exceed expectations.
              </li>
              <li>
                <strong>Empathy:</strong> Deep understanding of people and
                context ensures our solutions are truly human-centered.
              </li>
              <li>
                <strong>Evidence:</strong> Decisions are grounded in data,
                measurable impact, and ongoing validation.
              </li>
              <li>
                <strong>Empowerment:</strong> We co-create with clients,
                building capabilities and confidence that endure.
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className="impact">
        <div className="container">
          <h2>Impact that speaks for itself</h2>
          <div className="impact-grid">
            <div className="impact-card">
              <span className="impact-number">78%</span>
              <p>Average increase in customer engagement across digital touchpoints.</p>
            </div>
            <div className="impact-card">
              <span className="impact-number">4.9/5</span>
              <p>Client satisfaction for collaboration, transparency, and quality of delivery.</p>
            </div>
            <div className="impact-card">
              <span className="impact-number">12</span>
              <p>Countries where NovaEdge teams have mobilized large-scale transformations.</p>
            </div>
            <div className="impact-card">
              <span className="impact-number">100%</span>
              <p>Projects launched with measurable success metrics and governance.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="approach">
        <div className="container split">
          <div>
            <h2>A partnership model built on trust</h2>
            <p>
              We embed with our clients to align objectives, co-develop strategy,
              and transform the way teams collaborate. Every engagement balances
              bold ambition with pragmatic execution.
            </p>
            <p>
              From day one, you receive a dedicated engagement lead, access to
              discipline experts, and transparent, data-informed reporting. We
              operate as an extension of your team and celebrate your wins as our
              own.
            </p>
          </div>
          <div>
            <div className="approach-card">
              <h3>Integrated delivery teams</h3>
              <p>
                Multi-disciplinary squads blend strategy, design, technology, and
                data to maintain momentum and reduce hand-offs.
              </p>
            </div>
            <div className="approach-card">
              <h3>Outcome-first mindset</h3>
              <p>
                We define success metrics up front and align every sprint,
                prototype, and release to those measurable outcomes.
              </p>
            </div>
            <div className="approach-card">
              <h3>Change enablement</h3>
              <p>
                Adoption frameworks, training, and playbooks ensure the solutions
                we build are embraced and sustained long after launch.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="partnership-cta">
        <div className="container cta-inner">
          <div className="cta-text">
            <h2>Let’s shape the future of your digital organization.</h2>
            <p>
              Discover how NovaEdge can partner with you to remove barriers,
              mobilize teams, and deliver experiences customers love.
            </p>
          </div>
          <a className="btn btn-primary" href="/contact">
            Talk with a strategist
          </a>
        </div>
      </section>
    </div>
  );
};

export default About;