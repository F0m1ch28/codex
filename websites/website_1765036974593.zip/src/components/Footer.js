import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-column">
          <div className="footer-logo">
            <span className="logo-mark">N</span>
            <span>NovaEdge Consulting</span>
          </div>
          <p>
            We empower ambitious organizations to design, build, and launch
            high-impact digital experiences that make measurable difference.
          </p>
          <div className="footer-contact">
            <a href="tel:+1234567890">+1 (234) 567-890</a>
            <a href="mailto:hello@novaedgeconsulting.com">
              hello@novaedgeconsulting.com
            </a>
          </div>
        </div>

        <div className="footer-column">
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">Our Story</Link>
            </li>
            <li>
              <Link to="/services">What We Do</Link>
            </li>
            <li>
              <Link to="/contact">Work With Us</Link>
            </li>
            <li>
              <Link to="/terms">Terms &amp; Conditions</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Policy</Link>
            </li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Services</h4>
          <ul>
            <li>Digital Strategy</li>
            <li>Experience Design</li>
            <li>Product Engineering</li>
            <li>Data Intelligence</li>
            <li>Advisory &amp; Enablement</li>
          </ul>
        </div>

        <div className="footer-column">
          <h4>Stay Updated</h4>
          <p>
            Subscribe to insights that keep your organization at the forefront
            of innovation.
          </p>
          <form className="footer-form">
            <label htmlFor="footer-email" className="visually-hidden">
              Email address
            </label>
            <input
              type="email"
              id="footer-email"
              name="footer-email"
              placeholder="Email address"
              required
            />
            <button type="submit" className="btn btn-secondary btn-small">
              Subscribe
            </button>
          </form>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {currentYear} NovaEdge Consulting. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;