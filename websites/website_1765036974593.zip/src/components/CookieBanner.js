import React, { useEffect, useState } from "react";

const STORAGE_KEY = "novaedge_cookie_consent";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const consent = window.localStorage.getItem(STORAGE_KEY);
      if (!consent) {
        const timeout = setTimeout(() => setIsVisible(true), 1200);
        return () => clearTimeout(timeout);
      }
    }
  }, []);

  const handleAccept = () => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, "accepted");
    }
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <p>
          We use cookies to personalize content, enhance user experience, and
          analyze traffic. By clicking “Accept”, you consent to our use of
          cookies as described in our{" "}
          <a href="/privacy" className="link-inline">
            Privacy Policy
          </a>
          .
        </p>
        <button className="btn btn-primary btn-small" onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;