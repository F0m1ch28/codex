document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            const isOpen = navToggle.classList.toggle("is-active");
            siteNav.classList.toggle("is-open", isOpen);
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });

        siteNav.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                if (window.innerWidth <= 768) {
                    siteNav.classList.remove("is-open");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });

        window.addEventListener("resize", () => {
            if (window.innerWidth > 768) {
                siteNav.classList.remove("is-open");
                navToggle.classList.remove("is-active");
                navToggle.setAttribute("aria-expanded", "false");
            }
        });
    }

    const cookieBanner = document.getElementById("cookieBanner");
    if (cookieBanner) {
        const consent = localStorage.getItem("airworprynCookieConsent");
        if (!consent) {
            cookieBanner.classList.add("is-visible");
        }

        cookieBanner.querySelectorAll("[data-cookie-choice]").forEach((button) => {
            button.addEventListener("click", () => {
                const choice = button.getAttribute("data-cookie-choice");
                localStorage.setItem("airworprynCookieConsent", choice);
                cookieBanner.classList.remove("is-visible");
            });
        });
    }
});