(function () {
  const COOKIE_KEY = 'celestial_cookie_choice';

  document.addEventListener('DOMContentLoaded', function () {
    initCookieBanner();
    initSliders();
    initCollectionFilters();
    initGiftBuilder();
    initContactForm();
  });

  function initCookieBanner() {
    const banner = document.getElementById('cookie-banner');
    if (!banner) return;

    const acceptBtn = banner.querySelector('[data-cookie-accept]');
    const declineBtn = banner.querySelector('[data-cookie-decline]');
    const storedChoice = localStorage.getItem(COOKIE_KEY);

    if (storedChoice) {
      banner.classList.add('is-hidden');
    }

    acceptBtn.addEventListener('click', function () {
      localStorage.setItem(COOKIE_KEY, 'accepted');
      banner.classList.add('is-hidden');
    });

    declineBtn.addEventListener('click', function () {
      localStorage.setItem(COOKIE_KEY, 'declined');
      banner.classList.add('is-hidden');
    });
  }

  function initSliders() {
    const sliders = document.querySelectorAll('[data-slider]');
    sliders.forEach(function (slider) {
      const track = slider.querySelector('.slider-track');
      const slides = Array.from(track.children);
      const prevBtn = slider.querySelector('[data-slider-prev]');
      const nextBtn = slider.querySelector('[data-slider-next]');
      const dotsContainer = slider.querySelector('.slider-dots');
      const autoTime = parseInt(slider.getAttribute('data-slider-auto'), 10) || 7000;
      let currentIndex = 0;
      let autoTimer;

      if (dotsContainer) {
        slides.forEach(function (_, idx) {
          const dot = document.createElement('button');
          dot.classList.add('slider-dot');
          if (idx === 0) dot.classList.add('is-active');
          dot.type = 'button';
          dot.setAttribute('aria-label', 'Jump to slide ' + (idx + 1));
          dot.addEventListener('click', function () {
            currentIndex = idx;
            updateSlider();
            resetAuto();
          });
          dotsContainer.appendChild(dot);
        });
      }

      function updateSlider() {
        const offset = -currentIndex * 100;
        track.style.transform = 'translateX(' + offset + '%)';
        if (dotsContainer) {
          dotsContainer.querySelectorAll('.slider-dot').forEach(function (dot, idx) {
            dot.classList.toggle('is-active', idx === currentIndex);
          });
        }
      }

      function goToNext() {
        currentIndex = (currentIndex + 1) % slides.length;
        updateSlider();
      }

      function goToPrev() {
        currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        updateSlider();
      }

      function resetAuto() {
        if (!autoTime) return;
        clearInterval(autoTimer);
        autoTimer = setInterval(goToNext, autoTime);
      }

      if (prevBtn) prevBtn.addEventListener('click', function () {
        goToPrev();
        resetAuto();
      });

      if (nextBtn) nextBtn.addEventListener('click', function () {
        goToNext();
        resetAuto();
      });

      if (autoTime) {
        autoTimer = setInterval(goToNext, autoTime);
        slider.addEventListener('mouseenter', function () {
          clearInterval(autoTimer);
        });
        slider.addEventListener('mouseleave', function () {
          autoTimer = setInterval(goToNext, autoTime);
        });
      }

      updateSlider();
    });
  }

  function initCollectionFilters() {
    const filters = document.querySelectorAll('[data-filter]');
    const items = document.querySelectorAll('[data-collection-item]');
    if (!filters.length || !items.length) return;

    filters.forEach(function (button) {
      button.addEventListener('click', function () {
        const value = button.getAttribute('data-filter');
        filters.forEach(function (btn) {
          btn.classList.toggle('is-active', btn === button);
        });

        items.forEach(function (item) {
          const categories = item.getAttribute('data-category') || '';
          if (value === 'all' || categories.split(' ').includes(value)) {
            item.classList.remove('is-hidden');
          } else {
            item.classList.add('is-hidden');
          }
        });
      });
    });
  }

  function initGiftBuilder() {
    const form = document.getElementById('gift-builder');
    if (!form) return;

    const summaryList = document.getElementById('gift-summary');
    const totalEl = document.getElementById('gift-total');
    const previewImage = document.getElementById('builder-preview-image');
    const previewCaption = document.getElementById('preview-caption');

    const palettePreviews = {
      'Crimson & Gold': {
        src: 'https://picsum.photos/seed/crimsongold/360/360',
        caption: 'Crimson velvet ribbon with gilded accents and winter berries.'
      },
      'Emerald & Frost': {
        src: 'https://picsum.photos/seed/emerald/360/360',
        caption: 'Emerald silk bow with frosted pinecones and icy sparkle.'
      },
      'Confetti Pastels': {
        src: 'https://picsum.photos/seed/confettipastel/360/360',
        caption: 'Pastel confetti wrap with iridescent celebration streamers.'
      }
    };

    form.addEventListener('change', updateBuilderSummary);
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      alert('Thank you! A gifting stylist will reach out with your custom quote within 24 hours.');
      form.reset();
      updateBuilderSummary();
    });

    function updateBuilderSummary() {
      const occasionSelect = form.querySelector('#occasion-select');
      const occasionOption = occasionSelect.options[occasionSelect.selectedIndex];
      const paletteRadio = form.querySelector('input[name="palette"]:checked');
      const treatCheckboxes = form.querySelectorAll('input[name="treats"]:checked');
      const messageValue = form.querySelector('#message').value.trim();

      let total = 120; // base custom box price

      total += parseFloat(occasionOption.dataset.price || 0);
      total += parseFloat(paletteRadio.dataset.price || 0);

      const treatNames = [];
      treatCheckboxes.forEach(function (checkbox) {
        treatNames.push(checkbox.value);
        total += parseFloat(checkbox.dataset.price || 0);
      });

      const summaryItems = [
        'Occasion: ' + occasionOption.textContent.replace(/\s*\(\+\$\d+\)/, ''),
        'Palette: ' + paletteRadio.value,
        'Treats: ' + (treatNames.length ? treatNames.join('; ') : 'None selected')
      ];

      if (messageValue) {
        summaryItems.push('Message: ' + messageValue);
      }

      summaryList.innerHTML = '';
      summaryItems.forEach(function (item) {
        const li = document.createElement('li');
        li.textContent = item;
        summaryList.appendChild(li);
      });

      totalEl.textContent = 'Estimated Total: $' + total.toFixed(2);

      const previewData = palettePreviews[paletteRadio.value];
      if (previewData) {
        previewImage.setAttribute('src', previewData.src);
        previewCaption.textContent = previewData.caption;
      }
    }

    updateBuilderSummary();
  }

  function initContactForm() {
    const form = document.getElementById('contact-form');
    if (!form) return;

    const feedbackEl = document.getElementById('contact-feedback');

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      const formData = new FormData(form);
      const name = formData.get('name').trim();
      const email = formData.get('email').trim();
      const message = formData.get('message').trim();

      if (!name || !email || !message) {
        feedbackEl.textContent = 'Please complete the required fields before sending.';
        feedbackEl.classList.remove('alert-success');
        feedbackEl.classList.add('alert-error');
        return;
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        feedbackEl.textContent = 'Please provide a valid email address.';
        feedbackEl.classList.remove('alert-success');
        feedbackEl.classList.add('alert-error');
        return;
      }

      feedbackEl.textContent = 'Thank you, ' + name + '! Our gifting stylists will respond within one business day.';
      feedbackEl.classList.remove('alert-error');
      feedbackEl.classList.add('alert-success');
      form.reset();
    });
  }
})();