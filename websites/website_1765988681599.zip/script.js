(function () {
  "use strict";

  const canvases = [];
  let resizeTimer = null;

  function mulberry32(a) {
    return function () {
      let t = (a += 0x6d2b79f5);
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function createRandomGenerator(seedString) {
    let seed = 0;
    for (let i = 0; i < seedString.length; i += 1) {
      seed = (seed << 5) - seed + seedString.charCodeAt(i);
      seed |= 0;
    }
    const now = Date.now() & 0xffffffff;
    const entropy = Math.floor(Math.random() * 0xffffffff);
    seed ^= now;
    seed ^= entropy;
    if (seed === 0) {
      seed = 0x6d2b79f5;
    }
    return mulberry32(seed >>> 0);
  }

  function fitCanvas(canvas) {
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(rect.width, 1);
    const height = Math.max(rect.height, 1);
    const dpr = window.devicePixelRatio || 1;
    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
    }
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx, width, height };
  }

  function drawSkyGradient(ctx, width, height, topColor, bottomColor) {
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, topColor);
    gradient.addColorStop(1, bottomColor);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
  }

  function drawGroundGradient(ctx, width, height, startY, topColor, bottomColor) {
    const gradient = ctx.createLinearGradient(0, startY, 0, height);
    gradient.addColorStop(0, topColor);
    gradient.addColorStop(1, bottomColor);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, startY, width, height - startY);
  }

  function drawSolarScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#8ec5ff", "#e2f2ff");
    const sunX = width * (0.2 + rand() * 0.2);
    const sunY = height * (0.18 + rand() * 0.1);
    const sunRadius = height * (0.1 + rand() * 0.04);
    const sunGradient = ctx.createRadialGradient(sunX, sunY, sunRadius * 0.3, sunX, sunY, sunRadius);
    sunGradient.addColorStop(0, "rgba(255, 236, 179, 1)");
    sunGradient.addColorStop(1, "rgba(255, 236, 179, 0)");
    ctx.fillStyle = sunGradient;
    ctx.beginPath();
    ctx.arc(sunX, sunY, sunRadius, 0, Math.PI * 2);
    ctx.fill();

    drawGroundGradient(ctx, width, height, height * 0.58, "#bcd4ff", "#7bb1ff");

    const rows = 4;
    const panelsPerRow = 6;
    const baseHeight = height * 0.12;

    for (let row = 0; row < rows; row += 1) {
      const rowY = height * 0.62 + row * baseHeight * 0.55;
      const rowScale = 1 - row * 0.12;
      for (let col = 0; col < panelsPerRow; col += 1) {
        const panelWidth = (width * 0.12) * rowScale;
        const panelHeight = baseHeight * rowScale;
        const spacing = (width * 0.02) * rowScale;
        const x = width * 0.18 + col * (panelWidth + spacing) + rand() * spacing * 0.2;
        const y = rowY + rand() * 4;
        const tilt = (Math.PI / 7) + rand() * 0.05;

        ctx.save();
        ctx.translate(x, y);
        ctx.transform(1, Math.tan(-tilt) * 0.2, 0, 1, 0, 0);
        const frameColor = "rgba(26, 45, 71, 0.85)";
        ctx.fillStyle = frameColor;
        ctx.fillRect(0, 0, panelWidth, panelHeight);
        const gradient = ctx.createLinearGradient(0, 0, panelWidth, panelHeight);
        gradient.addColorStop(0, "rgba(20, 36, 61, 0.92)");
        gradient.addColorStop(1, "rgba(36, 68, 103, 0.92)");
        ctx.fillStyle = gradient;
        ctx.fillRect(panelWidth * 0.04, panelHeight * 0.08, panelWidth * 0.92, panelHeight * 0.88);

        ctx.strokeStyle = "rgba(255,255,255,0.15)";
        ctx.lineWidth = 1;
        const cellCols = 6;
        const cellRows = 4;
        for (let cx = 1; cx < cellCols; cx += 1) {
          const px = panelWidth * 0.04 + (panelWidth * 0.92 / cellCols) * cx;
          ctx.beginPath();
          ctx.moveTo(px, panelHeight * 0.08);
          ctx.lineTo(px, panelHeight * 0.96);
          ctx.stroke();
        }
        for (let cy = 1; cy < cellRows; cy += 1) {
          const py = panelHeight * 0.08 + (panelHeight * 0.88 / cellRows) * cy;
          ctx.beginPath();
          ctx.moveTo(panelWidth * 0.04, py);
          ctx.lineTo(panelWidth * 0.96, py);
          ctx.stroke();
        }

        ctx.restore();

        ctx.strokeStyle = "rgba(35, 60, 88, 0.6)";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(x + panelWidth * 0.16, y + panelHeight);
        ctx.lineTo(x + panelWidth * 0.22, y + panelHeight + panelHeight * 0.8);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x + panelWidth * 0.84, y + panelHeight);
        ctx.lineTo(x + panelWidth * 0.78, y + panelHeight + panelHeight * 0.85);
        ctx.stroke();
      }
    }

    ctx.fillStyle = "rgba(22, 42, 68, 0.55)";
    ctx.beginPath();
    ctx.moveTo(width * 0.05, height);
    ctx.quadraticCurveTo(width * 0.2, height * 0.7, width * 0.45, height * 0.72);
    ctx.bezierCurveTo(width * 0.6, height * 0.74, width * 0.78, height * 0.62, width * 0.94, height * 0.68);
    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fill();
  }

  function drawWindScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#aee0ff", "#f0fbff");
    drawGroundGradient(ctx, width, height, height * 0.6, "#b4d7a8", "#6f9f62");

    ctx.fillStyle = "rgba(87, 140, 112, 0.26)";
    for (let hill = 0; hill < 3; hill += 1) {
      const baseY = height * (0.68 + hill * 0.04);
      const controlX = width * (0.2 + hill * 0.25);
      ctx.beginPath();
      ctx.moveTo(0, height);
      ctx.quadraticCurveTo(controlX, baseY, width, height);
      ctx.closePath();
      ctx.fill();
    }

    const turbines = 5;
    for (let i = 0; i < turbines; i += 1) {
      const depth = 0.6 + i * 0.08;
      const size = (1 - depth) * 0.45 + 0.5;
      const x = width * (0.15 + i * 0.17 + rand() * 0.04);
      const baseY = height * (0.62 + depth * 0.12);
      const towerHeight = height * 0.38 * size;
      const towerWidth = width * 0.015 * size;
      ctx.fillStyle = "rgba(236, 244, 250, 0.95)";
      ctx.save();
      ctx.translate(x, baseY);
      ctx.fillRect(-towerWidth / 2, -towerHeight, towerWidth, towerHeight);

      const nacelleWidth = towerWidth * 1.4;
      const nacelleHeight = towerWidth * 0.6;
      ctx.fillRect(-nacelleWidth / 2, -towerHeight - nacelleHeight, nacelleWidth, nacelleHeight);

      const hubX = 0;
      const hubY = -towerHeight - nacelleHeight / 2;
      ctx.fillStyle = "#edf6ff";
      ctx.beginPath();
      ctx.arc(hubX, hubY, towerWidth * 0.55, 0, Math.PI * 2);
      ctx.fill();

      const bladeLength = towerHeight * 0.8;
      const bladeWidth = towerWidth * 0.35;
      const bladeAngle = rand() * Math.PI * 2;
      for (let blade = 0; blade < 3; blade += 1) {
        const angle = bladeAngle + (blade * (Math.PI * 2)) / 3;
        ctx.save();
        ctx.translate(hubX, hubY);
        ctx.rotate(angle);
        const gradient = ctx.createLinearGradient(0, 0, 0, -bladeLength);
        gradient.addColorStop(0, "rgba(230, 241, 247, 0.96)");
        gradient.addColorStop(1, "rgba(255, 255, 255, 0.85)");
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(bladeWidth, -bladeLength * 0.35, bladeWidth * 0.2, -bladeLength);
        ctx.quadraticCurveTo(0, -bladeLength * 1.05, -bladeWidth * 0.2, -bladeLength);
        ctx.quadraticCurveTo(-bladeWidth, -bladeLength * 0.35, 0, 0);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
      ctx.restore();
    }

    ctx.fillStyle = "rgba(170, 220, 255, 0.25)";
    for (let cloud = 0; cloud < 4; cloud += 1) {
      const cloudX = width * (rand() * 0.8 + 0.1);
      const cloudY = height * (0.1 + rand() * 0.2);
      const cloudWidth = width * (0.16 + rand() * 0.1);
      const cloudHeight = height * (0.08 + rand() * 0.04);
      ctx.beginPath();
      ctx.ellipse(cloudX, cloudY, cloudWidth, cloudHeight, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawHybridScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#87ceeb", "#f7fbff");
    drawGroundGradient(ctx, width, height, height * 0.6, "#b3d18b", "#6f9f62");

    ctx.fillStyle = "rgba(137, 196, 244, 0.16)";
    ctx.beginPath();
    ctx.moveTo(0, height * 0.58);
    ctx.bezierCurveTo(width * 0.25, height * 0.46, width * 0.65, height * 0.7, width, height * 0.58);
    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    ctx.fill();

    const solarWidth = width * 0.22;
    const solarHeight = height * 0.14;
    for (let i = 0; i < 3; i += 1) {
      const x = width * 0.1 + i * (solarWidth * 0.95);
      const y = height * 0.68 + rand() * 6;
      ctx.save();
      ctx.translate(x, y);
      ctx.transform(1, -0.25, 0, 1, 0, 0);
      ctx.fillStyle = "rgba(21, 46, 69, 0.92)";
      ctx.fillRect(0, 0, solarWidth, solarHeight);

      const solarGradient = ctx.createLinearGradient(0, 0, solarWidth, solarHeight);
      solarGradient.addColorStop(0, "#1f2f4d");
      solarGradient.addColorStop(1, "#2c4c73");
      ctx.fillStyle = solarGradient;
      ctx.fillRect(solarWidth * 0.05, solarHeight * 0.1, solarWidth * 0.9, solarHeight * 0.85);

      ctx.strokeStyle = "rgba(255,255,255,0.1)";
      const cols = 6;
      const rows = 3;
      for (let c = 1; c < cols; c += 1) {
        const px = solarWidth * 0.05 + (solarWidth * 0.9 / cols) * c;
        ctx.beginPath();
        ctx.moveTo(px, solarHeight * 0.1);
        ctx.lineTo(px, solarHeight * 0.95);
        ctx.stroke();
      }
      for (let r = 1; r < rows; r += 1) {
        const py = solarHeight * 0.1 + (solarHeight * 0.85 / rows) * r;
        ctx.beginPath();
        ctx.moveTo(solarWidth * 0.05, py);
        ctx.lineTo(solarWidth * 0.95, py);
        ctx.stroke();
      }
      ctx.restore();

      ctx.fillStyle = "rgba(60, 80, 102, 0.8)";
      ctx.fillRect(x + solarWidth * 0.12, y + solarHeight, solarWidth * 0.08, solarHeight * 0.9);
      ctx.fillRect(x + solarWidth * 0.8, y + solarHeight, solarWidth * 0.08, solarHeight * 0.95);
    }

    const turbines = 3;
    for (let i = 0; i < turbines; i += 1) {
      const baseX = width * (0.54 + i * 0.18);
      const baseY = height * 0.66 + rand() * 8;
      const towerHeight = height * 0.34;
      const towerWidth = width * 0.012;
      ctx.save();
      ctx.translate(baseX, baseY);
      ctx.fillStyle = "rgba(240, 245, 255, 0.98)";
      ctx.fillRect(-towerWidth / 2, -towerHeight, towerWidth, towerHeight);

      const hubY = -towerHeight - towerWidth * 0.4;
      ctx.beginPath();
      ctx.arc(0, hubY, towerWidth * 0.6, 0, Math.PI * 2);
      ctx.fill();

      const bladeAngle = rand() * Math.PI * 2;
      for (let b = 0; b < 3; b += 1) {
        const angle = bladeAngle + (Math.PI * 2 * b) / 3;
        ctx.save();
        ctx.translate(0, hubY);
        ctx.rotate(angle);
        const bladeLength = towerHeight * 0.85;
        const bladeWidth = towerWidth * 0.4;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(bladeWidth * 1.2, -bladeLength * 0.38, bladeWidth * 0.2, -bladeLength);
        ctx.quadraticCurveTo(0, -bladeLength * 1.1, -bladeWidth * 0.2, -bladeLength);
        ctx.quadraticCurveTo(-bladeWidth, -bladeLength * 0.4, 0, 0);
        ctx.fill();
        ctx.restore();
      }
      ctx.restore();
    }

    const storageWidth = width * 0.14;
    const storageHeight = height * 0.16;
    ctx.save();
    ctx.translate(width * 0.34, height * 0.7);
    ctx.fillStyle = "#1d2f3e";
    ctx.fillRect(-storageWidth / 2, 0, storageWidth, storageHeight);
    ctx.fillStyle = "#24384c";
    ctx.fillRect(-storageWidth / 2 + storageWidth * 0.08, storageHeight * 0.12, storageWidth * 0.84, storageHeight * 0.28);
    ctx.fillRect(-storageWidth / 2 + storageWidth * 0.08, storageHeight * 0.52, storageWidth * 0.84, storageHeight * 0.28);
    ctx.restore();
  }

  function drawDashboardScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#111829", "#1b2537");
    ctx.fillStyle = "#0e1726";
    ctx.fillRect(0, height * 0.45, width, height * 0.55);

    const panels = 3;
    const panelGap = width * 0.04;
    const panelWidth = (width - panelGap * (panels + 1)) / panels;
    const panelHeight = height * 0.46;

    for (let i = 0; i < panels; i += 1) {
      const x = panelGap + i * (panelWidth + panelGap);
      const y = height * 0.1 + rand() * 10;
      const radius = 18;
      ctx.fillStyle = "rgba(26, 36, 54, 0.96)";
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + panelWidth - radius, y);
      ctx.quadraticCurveTo(x + panelWidth, y, x + panelWidth, y + radius);
      ctx.lineTo(x + panelWidth, y + panelHeight - radius);
      ctx.quadraticCurveTo(x + panelWidth, y + panelHeight, x + panelWidth - radius, y + panelHeight);
      ctx.lineTo(x + radius, y + panelHeight);
      ctx.quadraticCurveTo(x, y + panelHeight, x, y + panelHeight - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = "rgba(255,255,255,0.08)";
      ctx.fillRect(x + 20, y + 60, panelWidth - 40, panelHeight * 0.24);

      const chartHeight = panelHeight * 0.32;
      const chartY = y + panelHeight - chartHeight - 24;
      ctx.fillStyle = "rgba(22, 177, 160, 0.25)";
      ctx.fillRect(x + 20, chartY, panelWidth - 40, chartHeight);

      ctx.strokeStyle = "rgba(240, 245, 255, 0.25)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + 40, chartY + chartHeight - 10);
      ctx.lineTo(x + panelWidth - 42, chartY + 12);
      ctx.stroke();

      ctx.strokeStyle = "rgba(26, 108, 240, 0.65)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      let currentX = x + 30;
      let currentY = chartY + chartHeight * (0.4 + rand() * 0.2);
      ctx.moveTo(currentX, currentY);
      const points = 6;
      for (let p = 0; p < points; p += 1) {
        currentX += (panelWidth - 60) / points;
        currentY = chartY + chartHeight * (0.2 + rand() * 0.6);
        ctx.lineTo(currentX, currentY);
      }
      ctx.stroke();

      ctx.fillStyle = "rgba(255,255,255,0.4)";
      ctx.font = "14px 'Inter', sans-serif";
      ctx.fillText("Live Metrics", x + 24, y + 36);
    }

    ctx.fillStyle = "rgba(255,255,255,0.06)";
    for (let row = 0; row < 4; row += 1) {
      const textY = height * 0.62 + row * 26;
      ctx.fillRect(width * 0.08, textY, width * 0.24, 16);
      ctx.fillRect(width * 0.36, textY, width * 0.12, 16);
      ctx.fillRect(width * 0.52, textY, width * 0.18, 16);
      ctx.fillRect(width * 0.74, textY, width * 0.16, 16);
    }
  }

  function drawTeamScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#f2f6ff", "#ffffff");
    ctx.fillStyle = "rgba(26, 108, 240, 0.08)";
    ctx.fillRect(0, height * 0.6, width, height * 0.4);

    const teamCount = 4;
    const baseY = height * 0.68;
    const baseWidth = width / (teamCount + 1);
    for (let i = 0; i < teamCount; i += 1) {
      const x = (i + 1) * baseWidth;
      const skinTone = `rgba(${200 + rand() * 40}, ${150 + rand() * 60}, ${120 + rand() * 80}, 1)`;
      const shirtColor = rand() > 0.5 ? "#1a6cf0" : "#0c9a8c";
      const accentColor = rand() > 0.5 ? "#f5b400" : "#273b4a";

      const headRadius = height * 0.07;
      ctx.fillStyle = skinTone;
      ctx.beginPath();
      ctx.arc(x, baseY - headRadius * 1.4, headRadius, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = accentColor;
      ctx.beginPath();
      ctx.arc(x, baseY - headRadius * 1.8, headRadius * 0.6, Math.PI, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = shirtColor;
      const bodyHeight = headRadius * 2.4;
      const bodyWidth = headRadius * 1.8;
      ctx.beginPath();
      ctx.moveTo(x - bodyWidth, baseY);
      ctx.quadraticCurveTo(x, baseY - bodyHeight, x + bodyWidth, baseY);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = "rgba(255,255,255,0.8)";
      ctx.fillRect(x - headRadius * 0.2, baseY - bodyHeight * 0.9, headRadius * 0.4, bodyHeight * 0.6);

      ctx.strokeStyle = "rgba(32, 42, 58, 0.45)";
      ctx.lineWidth = 6;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(x - bodyWidth * 0.6, baseY - bodyHeight * 0.2);
      ctx.lineTo(x - bodyWidth * 1.1, baseY + headRadius * 0.8);
      ctx.moveTo(x + bodyWidth * 0.6, baseY - bodyHeight * 0.2);
      ctx.lineTo(x + bodyWidth * 1.2, baseY + headRadius * 0.8);
      ctx.stroke();
    }

    ctx.fillStyle = "rgba(26, 108, 240, 0.12)";
    ctx.beginPath();
    ctx.moveTo(width * 0.1, height * 0.9);
    ctx.quadraticCurveTo(width * 0.5, height * 0.82, width * 0.9, height * 0.95);
    ctx.lineTo(width * 0.9, height);
    ctx.lineTo(width * 0.1, height);
    ctx.closePath();
    ctx.fill();
  }

  function drawEnvironmentScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#9fe0ff", "#dff7ff");

    const mountainColors = ["#6aa1b7", "#4e7f94", "#355868"];
    mountainColors.forEach((color, index) => {
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.moveTo(-50, height);
      const base = height * (0.55 + index * 0.08);
      const peakX = width * (0.25 + rand() * 0.5);
      const peakY = base - height * (0.18 + rand() * 0.12);
      ctx.lineTo(peakX, peakY);
      ctx.lineTo(width + 50, height);
      ctx.closePath();
      ctx.fill();
    });

    drawGroundGradient(ctx, width, height, height * 0.6, "#8fc98b", "#4e9152");

    for (let i = 0; i < 6; i += 1) {
      const x = width * (rand() * 0.9 + 0.05);
      const treeHeight = height * (0.2 + rand() * 0.15);
      const baseY = height * 0.62 + rand() * 20;
      ctx.fillStyle = "#2f613a";
      ctx.beginPath();
      ctx.moveTo(x, baseY - treeHeight);
      ctx.lineTo(x - treeHeight * 0.25, baseY);
      ctx.lineTo(x + treeHeight * 0.25, baseY);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#2a4a2d";
      ctx.fillRect(x - treeHeight * 0.04, baseY, treeHeight * 0.08, treeHeight * 0.28);
    }

    ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
    for (let i = 0; i < 4; i += 1) {
      const cx = width * (0.2 + i * 0.2 + rand() * 0.08);
      const cy = height * (0.18 + rand() * 0.1);
      const radius = height * (0.05 + rand() * 0.02);
      ctx.beginPath();
      ctx.ellipse(cx, cy, radius * 1.8, radius, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawMapScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#0f1f2c", "#0a161f");
    ctx.fillStyle = "rgba(26, 108, 240, 0.18)";
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = "rgba(40, 120, 180, 0.4)";
    ctx.lineWidth = 1;
    const gridSpacing = width * 0.08;
    for (let x = gridSpacing * 0.5; x < width; x += gridSpacing) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = gridSpacing * 0.5; y < height; y += gridSpacing) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    ctx.fillStyle = "rgba(12, 154, 140, 0.3)";
    const regionCount = 4 + Math.floor(rand() * 3);
    for (let i = 0; i < regionCount; i += 1) {
      const polyPoints = 5 + Math.floor(rand() * 3);
      ctx.beginPath();
      for (let p = 0; p < polyPoints; p += 1) {
        const angle = (Math.PI * 2 * p) / polyPoints;
        const radius = width * (0.08 + rand() * 0.06);
        const cx = width * (0.2 + rand() * 0.6);
        const cy = height * (0.3 + rand() * 0.4);
        const px = cx + Math.cos(angle + rand() * 0.4) * radius;
        const py = cy + Math.sin(angle + rand() * 0.4) * radius;
        if (p === 0) {
          ctx.moveTo(px, py);
        } else {
          ctx.lineTo(px, py);
        }
      }
      ctx.closePath();
      ctx.fill();
    }

    const routeCount = 5;
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    for (let i = 0; i < routeCount; i += 1) {
      const startX = width * (0.1 + rand() * 0.3);
      const startY = height * (0.2 + rand() * 0.6);
      const endX = width * (0.6 + rand() * 0.3);
      const endY = height * (0.2 + rand() * 0.6);
      ctx.strokeStyle = i % 2 === 0 ? "rgba(26, 108, 240, 0.75)" : "rgba(12, 154, 140, 0.75)";
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.bezierCurveTo(
        width * (0.3 + rand() * 0.2),
        height * (0.2 + rand() * 0.6),
        width * (0.5 + rand() * 0.2),
        height * (0.2 + rand() * 0.6),
        endX,
        endY
      );
      ctx.stroke();

      ctx.fillStyle = "#f5b400";
      ctx.beginPath();
      ctx.arc(startX, startY, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(endX, endY, 6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawDefaultScene(ctx, width, height, rand) {
    drawSkyGradient(ctx, width, height, "#1a2f4a", "#0f1c31");
    const layers = 6;
    for (let i = 0; i < layers; i += 1) {
      const opacity = 0.15 + i * 0.1;
      const color = `rgba(${26 + i * 20}, ${72 + i * 18}, ${120 + i * 12}, ${opacity})`;
      ctx.fillStyle = color;
      const radius = height * (0.5 + i * 0.08);
      ctx.beginPath();
      ctx.ellipse(
        width * (0.3 + rand() * 0.4),
        height * (0.4 + rand() * 0.3),
        radius,
        radius * 0.45,
        rand() * 0.8,
        0,
        Math.PI * 2
      );
      ctx.fill();
    }

    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(255, 255, 255, 0.28)";
    ctx.beginPath();
    let startX = width * 0.1;
    let startY = height * 0.78;
    ctx.moveTo(startX, startY);
    const segments = 7;
    for (let s = 0; s < segments; s += 1) {
      startX += width * 0.12 + rand() * width * 0.05;
      startY = height * (0.3 + rand() * 0.4);
      ctx.quadraticCurveTo(startX - width * 0.08, startY - height * 0.1, startX, startY);
    }
    ctx.stroke();

    ctx.fillStyle = "rgba(12, 154, 140, 0.5)";
    for (let node = 0; node < 6; node += 1) {
      const x = width * (0.15 + rand() * 0.7);
      const y = height * (0.2 + rand() * 0.6);
      const size = 10 + rand() * 16;
      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const typeRenderers = {
    solar: drawSolarScene,
    wind: drawWindScene,
    hybrid: drawHybridScene,
    dashboard: drawDashboardScene,
    team: drawTeamScene,
    environment: drawEnvironmentScene,
    map: drawMapScene,
    default: drawDefaultScene
  };

  function renderCanvas(canvasMeta) {
    const { canvas, type, seed } = canvasMeta;
    const { ctx, width, height } = fitCanvas(canvas);
    const renderer = typeRenderers[type] || typeRenderers.default;
    const rand = createRandomGenerator(seed);
    renderer(ctx, width, height, rand);
  }

  function renderAllCanvases() {
    canvases.forEach(renderCanvas);
  }

  function collectCanvases() {
    const nodes = document.querySelectorAll(".dynamic-visual canvas");
    nodes.forEach((canvas) => {
      const type = canvas.getAttribute("data-type") || "default";
      const seed = canvas.getAttribute("data-seed") || `seed-${Math.random()}`;
      canvases.push({ canvas, type, seed });
    });
  }

  function handleResize() {
    if (resizeTimer !== null) {
      window.cancelAnimationFrame(resizeTimer);
    }
    resizeTimer = window.requestAnimationFrame(() => {
      renderAllCanvases();
    });
  }

  window.addEventListener("DOMContentLoaded", () => {
    collectCanvases();
    renderAllCanvases();
    window.addEventListener("resize", handleResize, { passive: true });
  });
})();