document.addEventListener('DOMContentLoaded', function () {
  const nav = document.querySelector('.site-nav');
  const toggle = document.querySelector('.menu-toggle');
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookies = document.getElementById('acceptCookies');
  const declineCookies = document.getElementById('declineCookies');
  const storageKey = 'aav-cookie-consent';

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });

    nav.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  if (cookieBanner && acceptCookies && declineCookies) {
    const savedConsent = localStorage.getItem(storageKey);

    if (!savedConsent) {
      setTimeout(() => cookieBanner.classList.add('show'), 800);
    }

    acceptCookies.addEventListener('click', () => {
      localStorage.setItem(storageKey, 'accepted');
      cookieBanner.classList.remove('show');
    });

    declineCookies.addEventListener('click', () => {
      localStorage.setItem(storageKey, 'declined');
      cookieBanner.classList.remove('show');
    });
  }

  const searchForms = document.querySelectorAll('.search-form');
  searchForms.forEach(form => {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      alert('Pesquisa em desenvolvimento. Em breve você poderá explorar todo o catálogo!');
    });
  });
});