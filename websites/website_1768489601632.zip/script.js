document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            navLinks.classList.toggle('is-open');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('is-active');
                navLinks.classList.remove('is-open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('gc-cookie-consent');
        if (!storedConsent) {
            cookieBanner.classList.add('is-visible');
        }

        const acceptBtn = cookieBanner.querySelector('.cookie-accept');
        const declineBtn = cookieBanner.querySelector('.cookie-decline');

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => {
                localStorage.setItem('gc-cookie-consent', 'accepted');
                cookieBanner.classList.remove('is-visible');
                cookieBanner.classList.add('hidden');
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener('click', () => {
                localStorage.setItem('gc-cookie-consent', 'declined');
                cookieBanner.classList.remove('is-visible');
                cookieBanner.classList.add('hidden');
            });
        }
    }
});