document.addEventListener("DOMContentLoaded", () => {
  const body = document.body;
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const cookieBanner = document.getElementById("cookie-banner");
  const toast = document.getElementById("form-toast");
  const yearSpan = document.getElementById("current-year");

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isExpanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!isExpanded));
      body.classList.toggle("nav-open");
      nav.classList.toggle("is-open");
    });

    nav.querySelectorAll("a").forEach(link => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        body.classList.remove("nav-open");
        nav.classList.remove("is-open");
      });
    });
  }

  const forms = document.querySelectorAll("form[data-redirect='true']");
  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 2000);
  };

  forms.forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      showToast("Mensaje enviado. Serás redirigido en breve.");
      setTimeout(() => {
        window.location.href = form.getAttribute("action");
      }, 1500);
    });
  });

  if (cookieBanner) {
    const storedChoice = localStorage.getItem("rg-cookie-choice");
    if (!storedChoice) {
      cookieBanner.classList.add("is-active");
    }

    cookieBanner.querySelectorAll("[data-cookie-choice]").forEach(button => {
      button.addEventListener("click", () => {
        const choice = button.getAttribute("data-cookie-choice");
        localStorage.setItem("rg-cookie-choice", choice);
        cookieBanner.classList.remove("is-active");
      });
    });
  }

  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!prefersReducedMotion && "IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
  } else {
    document.querySelectorAll(".reveal").forEach(el => el.classList.add("is-visible"));
  }
});