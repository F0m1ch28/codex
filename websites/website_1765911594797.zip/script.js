(function () {
  const navToggle = document.querySelector('[data-nav-toggle]');
  const nav = document.querySelector('[data-main-nav]');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      nav.classList.toggle('is-open');
    });

    nav.addEventListener('click', (event) => {
      if (event.target.tagName === 'A') {
        nav.classList.remove('is-open');
      }
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const acceptButton = document.querySelector('[data-cookie-accept]');
  const declineButton = document.querySelector('[data-cookie-decline]');
  const cookieKey = 'iky-cookie-consent';

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove('is-visible');
    }
  }

  function showCookieBanner() {
    if (cookieBanner && !localStorage.getItem(cookieKey)) {
      cookieBanner.classList.add('is-visible');
    }
  }

  if (acceptButton) {
    acceptButton.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'accepted');
      hideCookieBanner();
    });
  }

  if (declineButton) {
    declineButton.addEventListener('click', () => {
      localStorage.setItem(cookieKey, 'declined');
      hideCookieBanner();
    });
  }

  showCookieBanner();

  const leaderboardKey = 'iky-leaderboard';
  const maxLeaderboardEntries = 10;

  function readLeaderboard() {
    try {
      const data = localStorage.getItem(leaderboardKey);
      if (!data) {
        return [];
      }
      return JSON.parse(data);
    } catch (error) {
      return [];
    }
  }

  function writeLeaderboard(list) {
    localStorage.setItem(leaderboardKey, JSON.stringify(list));
  }

  function updateLeaderboardTable() {
    const tableBody = document.querySelector('#leaderboardTable tbody');
    if (!tableBody) {
      return;
    }

    const records = readLeaderboard();
    tableBody.innerHTML = '';

    if (!records.length) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 5;
      cell.textContent = 'Пока здесь пусто. Сыграйте и станьте первым!';
      row.appendChild(cell);
      tableBody.appendChild(row);
      return;
    }

    records.sort((a, b) => {
      if (b.score === a.score) {
        return b.accuracy - a.accuracy;
      }
      return b.score - a.score;
    });

    records.slice(0, maxLeaderboardEntries).forEach((record, index) => {
      const row = document.createElement('tr');

      const place = document.createElement('td');
      place.textContent = index + 1;
      row.appendChild(place);

      const name = document.createElement('td');
      name.textContent = record.name;
      row.appendChild(name);

      const score = document.createElement('td');
      score.textContent = record.score;
      row.appendChild(score);

      const accuracy = document.createElement('td');
      accuracy.textContent = `${record.accuracy}%`;
      row.appendChild(accuracy);

      const date = document.createElement('td');
      date.textContent = record.date;
      row.appendChild(date);

      tableBody.appendChild(row);
    });
  }

  const leaderboardTable = document.getElementById('leaderboardTable');
  if (leaderboardTable) {
    updateLeaderboardTable();
  }

  const gameRoot = document.getElementById('gameRoot');
  if (gameRoot) {
    const startButton = document.getElementById('startGame');
    const gameContent = document.getElementById('gameContent');
    const gameIntro = document.getElementById('gameIntro');
    const gamePrompt = document.getElementById('gamePrompt');
    const gameHint = document.getElementById('gameHint');
    const optionsList = document.getElementById('optionsList');
    const gameFeedback = document.getElementById('gameFeedback');
    const gameSummary = document.getElementById('gameSummary');
    const summaryText = document.getElementById('summaryText');
    const saveScoreForm = document.getElementById('saveScoreForm');
    const playAgainButton = document.getElementById('playAgain');
    const skipButton = document.getElementById('skipQuestion');

    const roundLabel = document.getElementById('gameRound');
    const scoreLabel = document.getElementById('gameScore');
    const streakLabel = document.getElementById('gameStreak');

    const dataset = [
      {
        prompt: 'Почему в Яндексе так много...',
        hint: 'Речь о сервисе внутри компании',
        options: [
          'рекламы в Дзене',
          'приложений на айфоне',
          'желтых такси на улицах',
          'сериалов в Кинопоиске'
        ],
        correct: 3
      },
      {
        prompt: 'Как скачать Яндекс...',
        hint: 'Подсказка: мобильное устройство',
        options: [
          'браузер на телефон',
          'навигатор на автомобиль',
          'деньги на карту',
          'такси на компьютер'
        ],
        correct: 0
      },
      {
        prompt: 'Где находится офис Яндекс...',
        hint: 'Ищем конкретный город',
        options: [
          'в Санкт-Петербурге',
          'в Москве',
          'в Ереване',
          'в Новосибирске'
        ],
        correct: 1
      },
      {
        prompt: 'Яндекс.Практикум сколько стоит...',
        hint: 'Финансовый вопрос',
        options: [
          'месяц обучения',
          'курс по UX',
          'подписка за год',
          'первый модуль'
        ],
        correct: 0
      },
      {
        prompt: 'Почему не работает Яндекс...',
        hint: 'Ситуация в дороге',
        options: [
          'карты на айфоне',
          'погода в приложении',
          'музыка на айпаде',
          'такси ночью'
        ],
        correct: 0
      },
      {
        prompt: 'Как включить голос Алисы в...',
        hint: 'Устройство умного дома',
        options: [
          'яндекс-станции',
          'телевизоре LG',
          'телефоне Xiaomi',
          'браузере'
        ],
        correct: 0
      },
      {
        prompt: 'Что лучше Яндекс или...',
        hint: 'Сравнение с конкурентом',
        options: [
          'Гугл для программистов',
          'Mail.ru для школ',
          'Вконтакте для музыки',
          'Авито для работы'
        ],
        correct: 0
      },
      {
        prompt: 'Как отключить подписку Яндекс...',
        hint: 'Популярная услуга',
        options: [
          'Музыки на айфоне',
          'Телемоста в браузере',
          'Денег на карте',
          'Такси в приложении'
        ],
        correct: 0
      },
      {
        prompt: 'Яндекс.Практикум помогает устроиться...',
        hint: 'Желаемая должность',
        options: [
          'на позицию аналитика',
          'в службу поддержки',
          'менеджером по продажам',
          'оператором call-центра'
        ],
        correct: 0
      },
      {
        prompt: 'Почему Яндекс навигатор не показывает...',
        hint: 'Инфраструктура',
        options: [
          'пробки на мосту',
          'новые дома',
          'заправки в центре',
          'полицию на трассе'
        ],
        correct: 1
      }
    ];

    let state = {
      usedQuestions: [],
      currentQuestion: null,
      score: 0,
      round: 0,
      streak: 0,
      bestAccuracy: 0,
      correctAnswers: 0,
      totalQuestions: 5,
      skipUsed: 0
    };

    function updateStatus() {
      roundLabel.textContent = `Раунд: ${state.round} / ${state.totalQuestions}`;
      scoreLabel.textContent = `Очки: ${state.score}`;
      streakLabel.textContent = `Серия: ${state.streak}`;
    }

    function pickQuestion() {
      const available = dataset.filter((_, index) => !state.usedQuestions.includes(index));
      if (!available.length) {
        state.usedQuestions = [];
      }
      const randomIndex = Math.floor(Math.random() * dataset.length);
      if (state.usedQuestions.includes(randomIndex)) {
        return pickQuestion();
      }
      state.usedQuestions.push(randomIndex);
      state.currentQuestion = dataset[randomIndex];
    }

    function renderQuestion() {
      if (!state.currentQuestion) {
        return;
      }
      gamePrompt.textContent = state.currentQuestion.prompt;
      gameHint.textContent = `Подсказка: ${state.currentQuestion.hint}`;
      optionsList.innerHTML = '';

      state.currentQuestion.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'query-option';
        button.textContent = option;
        button.dataset.index = index;
        button.addEventListener('click', handleAnswer);
        optionsList.appendChild(button);
      });
    }

    function handleAnswer(event) {
      const selectedIndex = Number(event.currentTarget.dataset.index);
      const buttons = [...optionsList.querySelectorAll('.query-option')];
      buttons.forEach((button) => {
        button.disabled = true;
      });

      const correctIndex = state.currentQuestion.correct;
      const isCorrect = selectedIndex === correctIndex;

      buttons[correctIndex].classList.add('is-correct');

      if (isCorrect) {
        state.score += 100;
        state.streak += 1;
        state.correctAnswers += 1;
        if (state.streak > 0 && state.streak % 3 === 0) {
          state.score += 25;
        }
        gameFeedback.textContent = 'Точно! Вы выбрали самый популярный вариант.';
      } else {
        state.streak = 0;
        buttons[selectedIndex].classList.add('is-wrong');
        gameFeedback.textContent = 'Упс! Этот вариант оказался менее популярным.';
      }

      gameFeedback.classList.add('is-visible');

      setTimeout(() => {
        gameFeedback.classList.remove('is-visible');
        nextRound();
      }, 1200);
    }

    function nextRound() {
      state.round += 1;
      if (state.round > state.totalQuestions) {
        finishGame();
        return;
      }
      pickQuestion();
      renderQuestion();
      updateStatus();
    }

    function finishGame() {
      const accuracy = Math.round((state.correctAnswers / state.totalQuestions) * 100);
      state.bestAccuracy = accuracy;

      gameContent.hidden = true;
      gameSummary.classList.add('is-visible');

      summaryText.textContent = `Вы набрали ${state.score} очков с точностью ${accuracy}% и максимальной серией ${state.streak} верных ответов.`;
    }

    function resetGameState() {
      state = {
        usedQuestions: [],
        currentQuestion: null,
        score: 0,
        round: 0,
        streak: 0,
        bestAccuracy: 0,
        correctAnswers: 0,
        totalQuestions: 5,
        skipUsed: 0
      };
      gameIntro.hidden = false;
      gameContent.hidden = true;
      gameSummary.classList.remove('is-visible');
      optionsList.innerHTML = '';
      updateStatus();
    }

    function startGameFlow() {
      state.round = 0;
      state.score = 0;
      state.streak = 0;
      state.correctAnswers = 0;
      state.usedQuestions = [];
      pickQuestion();
      renderQuestion();
      gameIntro.hidden = true;
      gameContent.hidden = false;
      gameSummary.classList.remove('is-visible');
      updateStatus();
    }

    function skipQuestion() {
      if (state.skipUsed >= 1) {
        gameFeedback.textContent = 'Пропуск доступен только один раз за игру.';
        gameFeedback.classList.add('is-visible');
        setTimeout(() => {
          gameFeedback.classList.remove('is-visible');
        }, 1200);
        return;
      }
      state.skipUsed += 1;
      gameFeedback.textContent = 'Запрос пропущен. Очки не изменились.';
      gameFeedback.classList.add('is-visible');
      setTimeout(() => {
        gameFeedback.classList.remove('is-visible');
        nextRound();
      }, 1000);
    }

    function saveResult(name) {
      const records = readLeaderboard();
      const accuracy = state.bestAccuracy;
      const newRecord = {
        name,
        score: state.score,
        accuracy,
        date: new Date().toLocaleDateString('ru-RU')
      };

      const existingIndex = records.findIndex((item) => item.name.toLowerCase() === name.toLowerCase());
      if (existingIndex >= 0) {
        if (records[existingIndex].score < newRecord.score) {
          records[existingIndex] = newRecord;
        }
      } else {
        records.push(newRecord);
      }

      records.sort((a, b) => {
        if (b.score === a.score) {
          return b.accuracy - a.accuracy;
        }
        return b.score - a.score;
      });

      if (records.length > maxLeaderboardEntries) {
        records.length = maxLeaderboardEntries;
      }

      writeLeaderboard(records);
      updateLeaderboardTable();
    }

    if (startButton) {
      startButton.addEventListener('click', () => {
        startGameFlow();
      });
    }

    if (playAgainButton) {
      playAgainButton.addEventListener('click', () => {
        resetGameState();
      });
    }

    if (skipButton) {
      skipButton.addEventListener('click', skipQuestion);
    }

    if (saveScoreForm) {
      saveScoreForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(saveScoreForm);
        const name = (formData.get('playerName') || '').toString().trim();
        if (!name) {
          return;
        }
        saveResult(name);
        saveScoreForm.reset();
        gameSummary.classList.remove('is-visible');
        gameIntro.hidden = false;
        alert('Результат сохранён! Посмотрите таблицу лидеров.');
      });
    }

    resetGameState();
  }
})();