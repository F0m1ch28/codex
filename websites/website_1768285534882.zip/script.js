document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNav = document.querySelector('.primary-nav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', () => {
            primaryNav.classList.toggle('open');
        });
    }

    const mapButtons = document.querySelectorAll('[data-region]');
    const mapTooltip = document.querySelector('.map-tooltip');
    const mapSvg = document.querySelector('.map-svg');

    const regionData = {
        transilvania: {
            name: 'Transilvania',
            summary: 'Păstrăvul afumat din Valea Gurghiului, varza a la Cluj și ritualul de frământare a pâinii de Rusalii sunt documentate de Centrul Cultural Mureș (2022).',
            highlight: 'linear-gradient(135deg, rgba(0,255,153,0.35), rgba(183,28,28,0.35))'
        },
        moldova: {
            name: 'Moldova',
            summary: 'Sarmalele cu foi de viță din zona Huși, borșul de pește de pe Prut și colacii de nuntă păstrați în ritualuri din Neamț sunt descrise de Etnografia României (vol. VI).',
            highlight: 'linear-gradient(135deg, rgba(183,28,28,0.35), rgba(0,255,153,0.35))'
        },
        dobrogea: {
            name: 'Dobrogea',
            summary: 'Chefalele la grătar, baclavalele dobrogene și ceremoniile tătărești din Medgidia sunt menționate de Institutul de Cercetări Eco-Muzeale Tulcea (2023).',
            highlight: 'linear-gradient(135deg, rgba(0,255,153,0.45), rgba(74,0,31,0.45))'
        },
        muntenia: {
            name: 'Muntenia',
            summary: 'Saramura de Teleorman, turta de Ignat din Giurgiu și turturile cu miere din Prahova sunt analizate de Arhivele Naționale Istorice (dosar 1848-1940).',
            highlight: 'linear-gradient(135deg, rgba(74,0,31,0.4), rgba(0,255,153,0.35))'
        },
        banat: {
            name: 'Banat',
            summary: 'Langoșii, tocănița de pui cu ardei copți și colacii cu mac din Timiș sunt incluși în Repertoriul Gastronomic Banatic (2021).',
            highlight: 'linear-gradient(135deg, rgba(183,28,28,0.4), rgba(74,0,31,0.45))'
        },
        maramures: {
            name: 'Maramureș',
            summary: 'Coșarca cu brânză de oaie, horinca folosită ceremonial și ritualul prânzurilor de șezătoare sunt descrise de Muzeul Satului din Sighet (2020).',
            highlight: 'linear-gradient(135deg, rgba(0,255,153,0.35), rgba(0,0,0,0.35))'
        },
        oltenia: {
            name: 'Oltenia',
            summary: 'Prazul dolofan, zamă de lobodă și mucenicii de 9 martie sunt cartografiați de Universitatea din Craiova în studiul din 2021.',
            highlight: 'linear-gradient(135deg, rgba(0,255,153,0.35), rgba(183,28,28,0.25))'
        }
    };

    if (mapButtons && mapTooltip && mapSvg) {
        mapButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const regionKey = btn.dataset.region;
                mapButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const regionInfo = regionData[regionKey];
                mapTooltip.innerHTML = `<strong>${regionInfo.name}</strong><p>${regionInfo.summary}</p>`;
                mapSvg.style.background = regionInfo.highlight;
            });
        });
    }

    const festivalSelect = document.querySelector('.filter-select');
    const festivalCards = document.querySelectorAll('.festival-card');
    if (festivalSelect && festivalCards) {
        festivalSelect.addEventListener('change', () => {
            const selected = festivalSelect.value;
            festivalCards.forEach(card => {
                const seasons = card.dataset.season.split(',');
                if (selected === 'toate' || seasons.includes(selected)) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }

    const modalOverlay = document.querySelector('.modal-overlay');
    const modalClose = document.querySelector('.modal-close');
    const modalContent = document.querySelector('.modal-body');
    const chefCards = document.querySelectorAll('[data-chef]');

    const chefProfiles = {
        'sara-nemeș': {
            name: 'Chef Sara Nemeș',
            intro: 'Specialistă în reinterpretarea rețetelor transilvănene cu tehnici de fermentare documentate în revista Gastronom (2023).',
            highlights: [
                'A publicat studiul „Cămară vie” cu rețete din Sălaj validate de Asociația Producătorilor Locali (2022).',
                'Promovează ierburi alpine din Apuseni și utilizează 14 tipuri de oțet artizanal certificat Slow Food.',
                'Colaborează cu Facultatea de Științe Agricole Cluj pentru proiectul „Bucătărie și biodiversitate” (2021-2024).'
            ],
            gallery: [
                'https://picsum.photos/400/400?food&random=21',
                'https://picsum.photos/400/400?food&random=22',
                'https://picsum.photos/400/400?food&random=23'
            ]
        },
        'andrei-buciuman': {
            name: 'Chef Andrei Buciuman',
            intro: 'Maestru în bucătăria urbană bucureșteană, documentează meniurile interbelice din arhivele Hotelului Lido (1930-1940).',
            highlights: [
                'A restaurat 26 de rețete din „Cartea de bucate a Mariei General Dobrescu” (1913).',
                'Organizează ateliere despre mâncarea de cartier bazate pe interviurile cu vânzătorii de pește din Obor.',
                'Dirijează proiectul „Bufetul de la Peron” cu Fundația Căi Ferate Culturale (2022).'
            ],
            gallery: [
                'https://picsum.photos/400/400?food&random=24',
                'https://picsum.photos/400/400?food&random=25',
                'https://picsum.photos/400/400?food&random=26'
            ]
        },
        'maria-atanasoaie': {
            name: 'Bucătăreasa Maria Atanăsoaie',
            intro: 'Ajunsă celebră în Bucovina prin colacii de nuntă binecuvântați, documentați de Muzeul Obiceiurilor Populare Gura Humorului (2020).',
            highlights: [
                'Coace la vatră folosind lemn de fag, tehnică descrisă de etnologul Radu Iacob (2019).',
                'Transmite 45 de rețete de post în cadrul Școlii de Mestesugari din Suceava.',
                'Participantă la proiectul „Arhiva vie a mănăstirilor culinare” condus de Arhiepiscopia Sucevei (2021).'
            ],
            gallery: [
                'https://picsum.photos/400/400?food&random=27',
                'https://picsum.photos/400/400?food&random=28',
                'https://picsum.photos/400/400?food&random=29'
            ]
        }
    };

    if (chefCards && modalOverlay && modalContent) {
        chefCards.forEach(card => {
            card.addEventListener('click', () => {
                const key = card.dataset.chef;
                const profile = chefProfiles[key];
                if (profile) {
                    modalContent.innerHTML = `
                        <h3>${profile.name}</h3>
                        <p>${profile.intro}</p>
                        <ul class="fact-list">${profile.highlights.map(item => `<li>${item}</li>`).join('')}</ul>
                        <div class="modal-gallery">
                            ${profile.gallery.map(img => `<img src="${img}" alt="${profile.name}">`).join('')}
                        </div>
                    `;
                    modalOverlay.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            });
        });
    }

    if (modalClose && modalOverlay) {
        modalClose.addEventListener('click', () => {
            modalOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });
        modalOverlay.addEventListener('click', (event) => {
            if (event.target === modalOverlay) {
                modalOverlay.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    }

    const galleryItems = document.querySelectorAll('.gallery-item');
    const lightbox = document.querySelector('.lightbox');
    const lightboxImg = document.querySelector('.lightbox img');
    if (galleryItems && lightbox && lightboxImg) {
        galleryItems.forEach(item => {
            item.addEventListener('click', () => {
                const img = item.querySelector('img');
                lightboxImg.src = img.src;
                lightboxImg.alt = img.alt;
                lightbox.classList.add('active');
                document.body.style.overflow = 'hidden';
            });
        });
        lightbox.addEventListener('click', () => {
            lightbox.classList.remove('active');
            document.body.style.overflow = '';
        });
    }

    const faqItems = document.querySelectorAll('.faq-item');
    if (faqItems) {
        faqItems.forEach(item => {
            const question = item.querySelector('.faq-question');
            question.addEventListener('click', () => {
                item.classList.toggle('active');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-actions a');

    if (cookieBanner && cookieButtons.length) {
        if (localStorage.getItem('cronicaCookieConsent')) {
            cookieBanner.style.display = 'none';
        }
        cookieButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                localStorage.setItem('cronicaCookieConsent', btn.classList.contains('decline') ? 'declined' : 'accepted');
            });
        });
    }
});