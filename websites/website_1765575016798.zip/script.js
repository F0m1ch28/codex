document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const menuToggle = document.querySelector('.menu-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  const navLinks = document.querySelectorAll('.primary-nav .nav-link');
  const currentYearEl = document.getElementById('currentYear');
  const cookieBanner = document.querySelector('.cookie-banner');
  const cookieAccept = document.querySelector('.cookie-accept');
  const cookieDecline = document.querySelector('.cookie-decline');
  const contactForm = document.querySelector('[data-form="contact"]');
  const formMessage = document.querySelector('.form-message');

  if (menuToggle && primaryNav) {
    menuToggle.addEventListener('click', () => {
      const isOpen = primaryNav.classList.toggle('is-open');
      menuToggle.setAttribute('aria-expanded', isOpen);
      body.classList.toggle('no-scroll', isOpen);
      const bars = menuToggle.querySelectorAll('span[aria-hidden="true"]');
      if (bars.length === 3) {
        bars[0].style.transform = isOpen ? 'translateY(7px) rotate(45deg)' : '';
        bars[1].style.opacity = isOpen ? '0' : '';
        bars[2].style.transform = isOpen ? 'translateY(-7px) rotate(-45deg)' : '';
      }
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        if (primaryNav.classList.contains('is-open')) {
          primaryNav.classList.remove('is-open');
          menuToggle.setAttribute('aria-expanded', 'false');
          const bars = menuToggle.querySelectorAll('span[aria-hidden="true"]');
          bars.forEach(bar => {
            bar.style.transform = '';
            bar.style.opacity = '';
          });
          body.classList.remove('no-scroll');
        }
      });
    });
  }

  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  const cookieKey = 'qazaqlearn-cookie-consent';
  if (cookieBanner) {
    const storedConsent = localStorage.getItem(cookieKey);
    if (!storedConsent) {
      cookieBanner.classList.add('visible');
    }

    const handleConsent = (value) => {
      localStorage.setItem(cookieKey, value);
      cookieBanner.classList.remove('visible');
    };

    cookieAccept?.addEventListener('click', () => handleConsent('accepted'));
    cookieDecline?.addEventListener('click', () => handleConsent('declined'));
  }

  if (contactForm && formMessage) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      formMessage.textContent = '';
      const formData = new FormData(contactForm);
      const name = formData.get('name')?.trim();
      const email = formData.get('email')?.trim();
      const message = formData.get('message')?.trim();

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!name || name.length < 2) {
        formMessage.textContent = 'Өтініш, аты-жөніңізді толық енгізіңіз.';
        return;
      }

      if (!email || !emailPattern.test(email)) {
        formMessage.textContent = 'Дұрыс электрондық поштаны енгізіңіз.';
        return;
      }

      if (!message || message.length < 10) {
        formMessage.textContent = 'Хабарлама кем дегенде 10 таңба болуы керек.';
        return;
      }

      contactForm.reset();
      formMessage.textContent = 'Рақмет! Хабарламаңыз сәтті жіберілді. Біз жақын арада байланысамыз.';
    });
  }
});