document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector("[data-nav-toggle]");
    const primaryNav = document.querySelector("[data-nav]");
    if (navToggle && primaryNav) {
        navToggle.addEventListener("click", () => {
            const currentState = primaryNav.getAttribute("data-nav-state");
            const newState = currentState === "open" ? "closed" : "open";
            primaryNav.setAttribute("data-nav-state", newState);
            navToggle.setAttribute("aria-expanded", newState === "open");
        });
    }

    document.querySelectorAll(".primary-nav a").forEach(link => {
        link.addEventListener("click", () => {
            if (primaryNav) {
                primaryNav.setAttribute("data-nav-state", "closed");
                navToggle && navToggle.setAttribute("aria-expanded", "false");
            }
        });
    });

    const cookieBanner = document.querySelector("[data-cookie-banner]");
    const cookieActions = document.querySelectorAll("[data-cookie-choice]");
    const cookieStorageKey = "friaryCookieChoice2024";

    if (cookieBanner) {
        const storedChoice = localStorage.getItem(cookieStorageKey);
        if (storedChoice) {
            cookieBanner.style.display = "none";
        }

        cookieActions.forEach(action => {
            action.addEventListener("click", (event) => {
                event.preventDefault();
                const choice = action.getAttribute("data-cookie-choice");
                localStorage.setItem(cookieStorageKey, choice);
                cookieBanner.style.display = "none";
                const targetUrl = action.getAttribute("href");
                if (targetUrl) {
                    window.open(targetUrl, "_blank", "noopener");
                }
            });
        });
    }

    const searchInput = document.querySelector("[data-search-input]");
    const filterButtons = document.querySelectorAll("[data-filter]");
    const postCards = document.querySelectorAll("[data-post]");
    const paginationControls = document.querySelectorAll("[data-page-target]");
    let activeCategory = "all";
    let activePage = "1";

    function updatePosts() {
        const searchTerm = (searchInput ? searchInput.value.trim().toLowerCase() : "");
        postCards.forEach(card => {
            const categories = card.getAttribute("data-categories").toLowerCase();
            const title = card.querySelector("h3") ? card.querySelector("h3").textContent.toLowerCase() : "";
            const excerpt = card.querySelector("p") ? card.querySelector("p").textContent.toLowerCase() : "";
            const page = card.getAttribute("data-page");

            const matchesCategory = activeCategory === "all" || categories.includes(activeCategory);
            const matchesSearch = title.includes(searchTerm) || excerpt.includes(searchTerm);
            const matchesPage = page === activePage;

            card.style.display = matchesCategory && matchesSearch && matchesPage ? "flex" : "none";
        });
    }

    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener("click", () => {
                filterButtons.forEach(btn => btn.setAttribute("data-active", "false"));
                button.setAttribute("data-active", "true");
                activeCategory = button.getAttribute("data-filter");
                activePage = "1";
                paginationControls.forEach(ctrl => ctrl.setAttribute("data-active", ctrl.getAttribute("data-page-target") === activePage ? "true" : "false"));
                updatePosts();
            });
        });
    }

    if (paginationControls.length > 0) {
        paginationControls.forEach(control => {
            control.addEventListener("click", () => {
                activePage = control.getAttribute("data-page-target");
                paginationControls.forEach(ctrl => ctrl.setAttribute("data-active", "false"));
                control.setAttribute("data-active", "true");
                updatePosts();
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", () => {
            activePage = "1";
            paginationControls.forEach(ctrl => ctrl.setAttribute("data-active", ctrl.getAttribute("data-page-target") === "1" ? "true" : "false"));
            updatePosts();
        });
    }

    updatePosts();
});