document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-links a');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('nav-open');
            navMenu.classList.toggle('nav-open');
            document.body.classList.toggle('menu-open');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('nav-open');
                navMenu.classList.remove('nav-open');
                document.body.classList.remove('menu-open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const declineCookiesBtn = document.getElementById('decline-cookies');
    const cookiePreference = localStorage.getItem('bedizeqylaCookiePreference');

    if (cookieBanner && !cookiePreference) {
        cookieBanner.style.display = 'flex';
    } else if (cookieBanner) {
        cookieBanner.style.display = 'none';
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('bedizeqylaCookiePreference', 'accepted');
            cookieBanner.style.display = 'none';
        });
    }

    if (declineCookiesBtn) {
        declineCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('bedizeqylaCookiePreference', 'declined');
            cookieBanner.style.display = 'none';
        });
    }
});