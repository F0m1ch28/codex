import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={styles.inner}>
        <div className={styles.column}>
          <h3 className={styles.logo}>КиберКотики</h3>
          <p className={styles.description}>
            Кибербезопасность может быть игривой: мы обучаем цифровым привычкам через котиков,
            юмор и тесты, чтобы правила запоминались без скуки.
          </p>
          <div className={styles.socials} aria-label="Социальные сети">
            <a
              href="https://vk.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
            >
              VK
            </a>
            <a
              href="https://t.me"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
            >
              TG
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className={styles.socialLink}
            >
              YT
            </a>
          </div>
        </div>

        <div className={styles.column}>
          <h4>Навигация</h4>
          <ul className={styles.linkList}>
            <li><Link to="/#hero">Главная</Link></li>
            <li><Link to="/#gallery">Галерея котиков</Link></li>
            <li><Link to="/#info">Советы безопасности</Link></li>
            <li><Link to="/#quiz">Тест</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Правовые документы</h4>
          <ul className={styles.linkList}>
            <li><Link to="/terms">Условия использования</Link></li>
            <li><Link to="/privacy">Политика конфиденциальности</Link></li>
            <li><Link to="/cookie-policy">Политика использования файлов cookie</Link></li>
          </ul>
        </div>

        <div className={styles.column}>
          <h4>Контакты</h4>
          <div className={styles.contactBlock}>
            <Link to="/contact" className={styles.contactLink} aria-label="Открыть страницу контактов">
              +7 (900) 123-45-67
            </Link>
            <Link to="/contact" className={styles.contactLink} aria-label="Перейти к форме обратной связи">
              hello@cyberkotiki.ru
            </Link>
            <p className={styles.contactHint}>
              Нажми, чтобы перейти к форме связи и отправить нам сообщение.
            </p>
          </div>
        </div>
      </div>
      <div className={styles.legal}>
        <p>© {year} КиберКотики. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;