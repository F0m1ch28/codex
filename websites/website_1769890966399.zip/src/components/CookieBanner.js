import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'cyber-cats-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const savedChoice = window.localStorage.getItem(STORAGE_KEY);
    if (!savedChoice) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(STORAGE_KEY, choice);
    }
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Сообщение о cookies">
      <div className={styles.content}>
        <p>
          Мы используем cookies, чтобы котики не грустили, а ваши настройки безопасности
          сохранялись. Можно поставить миску с печеньками?
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.accept} onClick={() => handleChoice('accepted')}>
            Принять
          </button>
          <button type="button" className={styles.decline} onClick={() => handleChoice('declined')}>
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;