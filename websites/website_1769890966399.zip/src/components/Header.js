import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname, location.hash]);

  const sectionLinks = [
    { label: 'Главная', to: 'hero' },
    { label: 'Галерея', to: 'gallery' },
    { label: 'Инфо', to: 'info' },
    { label: 'Тест', to: 'quiz' }
  ];

  const pageLinks = [
    { label: 'О нас', to: '/about' },
    { label: 'Услуги', to: '/services' },
    { label: 'Контакты', to: '/contact' }
  ];

  return (
    <header className={styles.header}>
      <div className={styles.topMessage} aria-live="polite">
        Ты что усроил правила безопасности в цифровой среде?
      </div>
      <div className={styles.navBar}>
        <Link to="/" className={styles.brand} aria-label="На главную страницу">
          Кибер<span>Котики</span>
        </Link>
        <button
          type="button"
          className={styles.mobileToggle}
          aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          className={"${styles.navigation} ${menuOpen ? styles.navigationOpen : ''}"}
          aria-label="Основная навигация"
        >
          {sectionLinks.map((item) => (
            <Link
              key={item.to}
              to={"/#${item.to}"}
              className={styles.navLink}
            >
              {item.label}
            </Link>
          ))}
          {pageLinks.map((item) => (
            <Link key={item.to} to={item.to} className={styles.navLink}>
              {item.label}
            </Link>
          ))}
          <Link to="/contact" className={"${styles.navLink} ${styles.contactButton}"}>
            Связаться
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;