import React, { useEffect } from 'react';
import styles from './PrivacyPolicy.module.css';

const updateMeta = (title, description, keywords) => {
  if (typeof document === 'undefined') {
    return;
  }
  document.title = title;
  const ensureMeta = (name, content) => {
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const PrivacyPolicy = () => {
  useEffect(() => {
    updateMeta(
      'КиберКотики — Политика конфиденциальности',
      'Политика обработки персональных данных на сайте КиберКотики: что собираем и как защищаем.',
      'политика конфиденциальности, персональные данные, киберкотики'
    );
  }, []);

  return (
    <div className={styles.page}>
      <h1>Политика конфиденциальности</h1>
      <section className={styles.section}>
        <h2>1. Какие данные мы собираем</h2>
        <p>
          Мы собираем только те данные, которые пользователь добровольно оставляет в форме обратной
          связи: имя, электронная почта и текст сообщения.
        </p>
      </section>
      <section className={styles.section}>
        <h2>2. Как мы используем данные</h2>
        <p>
          Данные необходимы, чтобы отвечать на запросы и отправлять полезные материалы. Мы не передаём
          информацию третьим лицам без согласия пользователя.
        </p>
      </section>
      <section className={styles.section}>
        <h2>3. Хранение и защита</h2>
        <p>
          Мы применяем организационные и технические меры, чтобы исключить несанкционированный доступ к данным.
        </p>
      </section>
      <section className={styles.section}>
        <h2>4. Права пользователей</h2>
        <p>
          Ты можешь запросить удаление или уточнение своих данных, написав нам на почту hello@cyberkotiki.ru.
        </p>
      </section>
    </div>
  );
};

export default PrivacyPolicy;