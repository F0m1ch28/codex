import React, { useEffect } from 'react';
import styles from './TermsOfService.module.css';

const updateMeta = (title, description, keywords) => {
  if (typeof document === 'undefined') {
    return;
  }
  document.title = title;
  const ensureMeta = (name, content) => {
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const TermsOfService = () => {
  useEffect(() => {
    updateMeta(
      'КиберКотики — Условия использования',
      'Правила пользования сайтом КиберКотики: доступ к материалам, ограничения и ответственность.',
      'условия использования, киберкотики, правила сайта'
    );
  }, []);

  return (
    <div className={styles.page}>
      <h1>Условия использования сайта «КиберКотики»</h1>
      <section className={styles.section}>
        <h2>1. Общие положения</h2>
        <p>
          Используя сайт «КиберКотики», ты принимаешь данные условия. Мы создаём образовательные
          материалы о цифровой безопасности и заботимся о корректном использовании контента.
        </p>
      </section>
      <section className={styles.section}>
        <h2>2. Доступ к материалам</h2>
        <ul>
          <li>Контент доступен для личного использования и обучения.</li>
          <li>Запрещено копировать материалы без указания источника.</li>
          <li>Мы можем обновлять и изменять разделы сайта без предварительного уведомления.</li>
        </ul>
      </section>
      <section className={styles.section}>
        <h2>3. Ответственность</h2>
        <p>
          Мы стараемся предоставлять актуальные советы, но пользователи самостоятельно несут
          ответственность за применение рекомендаций и соблюдение безопасности в сети.
        </p>
      </section>
      <section className={styles.section}>
        <h2>4. Обратная связь</h2>
        <p>
          Если ты нашёл неточность или хочешь предложить улучшение, напиши нам через форму обратной связи.
        </p>
      </section>
    </div>
  );
};

export const CookiePolicyPage = () => {
  useEffect(() => {
    updateMeta(
      'КиберКотики — Политика использования файлов cookie',
      'Узнай, какие файлы cookie применяются на сайте КиберКотики и как можно управлять настройками.',
      'cookie, политика cookie, киберкотики'
    );
  }, []);

  return (
    <div className={styles.page}>
      <h1>Политика использования файлов cookie</h1>
      <section className={styles.section}>
        <h2>Что такое cookie</h2>
        <p>
          Cookie — это небольшие файлы, которые сохраняются в браузере, чтобы сайт запоминал
          предпочтения и корректно работал. Наши котики используют только самые безопасные печеньки.
        </p>
      </section>
      <section className={styles.section}>
        <h2>Как мы применяем cookie</h2>
        <ul>
          <li>Сохраняем выбор по согласию на обработку данных.</li>
          <li>Запоминаем результаты прохождения теста, если пользователь дал согласие.</li>
          <li>Анализируем посещаемость, чтобы улучшать контент.</li>
        </ul>
      </section>
      <section className={styles.section}>
        <h2>Как управлять файлами cookie</h2>
        <p>
          Ты можешь в любой момент изменить настройки браузера и удалить cookie. Учти, что часть функций
          может работать иначе. Подробнее смотри в справке браузера.
        </p>
      </section>
    </div>
  );
};

export default TermsOfService;