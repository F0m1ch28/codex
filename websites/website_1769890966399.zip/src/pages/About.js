import React, { useEffect } from 'react';
import styles from './About.module.css';

const updateMeta = (title, description, keywords) => {
  if (typeof document === 'undefined') {
    return;
  }
  document.title = title;
  const ensureMeta = (name, content) => {
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const About = () => {
  useEffect(() => {
    updateMeta(
      'КиберКотики — О проекте',
      'Узнай, как команда КиберКотиков создаёт игровые сценарии по цифровой безопасности.',
      'киберкотики команда, о проекте, цифровая безопасность, обучение'
    );
  }, []);

  return (
    <div className={styles.page}>
      <section aria-labelledby="about-title">
        <h1 id="about-title">Кто прячет котиков за защитным экраном</h1>
        <p className={styles.intro}>
          КиберКотики родились из желания объяснять сложные темы простым языком. Мы дизайнеры,
          аналитики, преподаватели и, конечно, владельцы очень любопытных котов.
        </p>
      </section>

      <section className={styles.grid} aria-labelledby="team-title">
        <h2 id="team-title">Команда, которая мурлычет о безопасности</h2>
        <article className={styles.card}>
          <h3>Аня, создательница</h3>
          <p>
            Любит превращать скучные инструкции в яркие истории. В её ноутбуке больше стикеров котиков,
            чем файлов, но порядок при этом идеальный.
          </p>
        </article>
        <article className={styles.card}>
          <h3>Илья, исследователь угроз</h3>
          <p>
            Исследует новые схемы фишинга и переводит их на понятный язык. Говорит, что лучший фильтр от спама —
            внимательный пользователь.
          </p>
        </article>
        <article className={styles.card}>
          <h3>Лера, иллюстратор</h3>
          <p>
            Отвечает за настроение: все котики, которых вы видите на сайте, проходят строгий художественный отбор.
          </p>
        </article>
      </section>

      <section className={styles.highlight}>
        <h2>Почему у нас получается</h2>
        <ul>
          <li>Используем игровой подход и короткие форматы, чтобы удерживать внимание.</li>
          <li>Регулярно обновляем сценарии согласно свежим кейсам угроз.</li>
          <li>Тестируем материалы на реальных пользователях и получаем обратную связь.</li>
        </ul>
      </section>
    </div>
  );
};

export default About;