import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './ThankYou.module.css';

const updateMeta = (title, description, keywords) => {
  if (typeof document === 'undefined') {
    return;
  }
  document.title = title;
  const ensureMeta = (name, content) => {
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const ThankYou = () => {
  useEffect(() => {
    updateMeta(
      'КиберКотики — Спасибо за сообщение',
      'Благодарим за обращение к команде КиберКотиков. Мы свяжемся с тобой совсем скоро.',
      'спасибо, контакт, киберкотики'
    );
  }, []);

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <h1>Спасибо! Сообщение с мурлыканьем отправлено</h1>
        <p>
          Мы уже размораживаем цифровое молочко для ответа. Проверь почту — скоро прилетит письмо с
          дополнительными материалами.
        </p>
        <img src="https://placekitten.com/640/440" alt="Котик посылает благодарное сердечко" loading="lazy" />
        <div className={styles.actions}>
          <Link to="/#quiz">Вернуться к тесту</Link>
          <Link to="/">На главную</Link>
        </div>
      </div>
    </div>
  );
};

export default ThankYou;