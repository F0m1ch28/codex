import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './Contact.module.css';

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const updateMeta = (title, description, keywords) => {
  if (typeof document === 'undefined') {
    return;
  }
  document.title = title;
  const ensureMeta = (name, content) => {
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const Contact = () => {
  const navigate = useNavigate();
  const timeoutRef = useRef();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    updateMeta(
      'КиберКотики — Связаться с нами',
      'Напиши команде КиберКотиков: ответим, поделимся материалами и подскажем, как улучшить цифровую безопасность.',
      'контакты, киберкотики, обратная связь, цифровая безопасность'
    );
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  const validate = () => {
    const validationErrors = {};
    if (!formData.name.trim()) {
      validationErrors.name = 'Как к тебе обращаться?';
    } else if (formData.name.trim().length < 2) {
      validationErrors.name = 'Имя должно быть длиннее двух символов.';
    }

    if (!formData.email.trim()) {
      validationErrors.email = 'Укажи электронную почту.';
    } else if (!emailPattern.test(formData.email.trim())) {
      validationErrors.email = 'Кажется, адрес некорректный.';
    }

    if (!formData.message.trim()) {
      validationErrors.message = 'Расскажи, что тебя волнует.';
    } else if (formData.message.trim().length < 10) {
      validationErrors.message = 'Сообщение должно быть чуть подробнее.';
    }

    return validationErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: ''
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsSubmitting(true);
    timeoutRef.current = window.setTimeout(() => {
      setIsSubmitting(false);
      navigate('/thank-you', { replace: true });
    }, 600);
  };

  return (
    <div className={styles.page}>
      <section className={styles.contactGrid} aria-labelledby="contact-title">
        <div>
          <h1 id="contact-title">Свяжись с командой КиберКотиков</h1>
          <p className={styles.subtitle}>
            Мы с радостью поделимся дополнительными материалами, предложим интерактивные сценарии
            и подскажем, как встроить их в обучение.
          </p>

          <div className={styles.contactInfo}>
            <article className={styles.contactCard}>
              <h2>Чат поддержки</h2>
              <p className={styles.contactValue}>t.me/cyberkotiki</p>
              <p>Напиши нам в Telegram и получи быстрый совет от которедактора.</p>
            </article>
            <article className={styles.contactCard}>
              <h2>Почта</h2>
              <p className={styles.contactValue}>hello@cyberkotiki.ru</p>
              <p>Отправь запрос, если нужен комплект материалов или консультация.</p>
            </article>
            <article className={styles.contactCard}>
              <h2>Телефон</h2>
              <p className={styles.contactValue}>+7 (900) 123-45-67</p>
              <p>Позвони в будни с 10:00 до 19:00 — подскажем и поддержим.</p>
            </article>
          </div>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate aria-label="Форма обратной связи">
          <div className={styles.formGroup}>
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Кот-Эксперт"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && (
              <span id="name-error" className={styles.error}>
                {errors.name}
              </span>
            )}
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="email">Электронная почта</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && (
              <span id="email-error" className={styles.error}>
                {errors.email}
              </span>
            )}
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Расскажи, что нужно защитить, а мы предложим механику."
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && (
              <span id="message-error" className={styles.error}>
                {errors.message}
              </span>
            )}
          </div>

          <div className={styles.submitRow}>
            <button type="submit" className={styles.submitButton} disabled={isSubmitting}>
              {isSubmitting ? 'Отправляем...' : 'Отправить сообщение'}
            </button>
            <p className={styles.policyNote}>
              Отправляя форму, ты соглашаешься с нашими{' '}
              <a href="/privacy" rel="noopener noreferrer">
                правилами обработки данных
              </a>.
            </p>
          </div>
        </form>
      </section>
    </div>
  );
};

export default Contact;