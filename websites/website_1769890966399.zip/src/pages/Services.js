import React, { useEffect } from 'react';
import styles from './Services.module.css';

const updateMeta = (title, description, keywords) => {
  if (typeof document === 'undefined') {
    return;
  }
  document.title = title;
  const ensureMeta = (name, content) => {
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const Services = () => {
  useEffect(() => {
    updateMeta(
      'КиберКотики — Игровые форматы обучения',
      'Сервисы КиберКотиков: тесты, сценарии и чек-листы по цифровой безопасности в игровой форме.',
      'игровые сценарии, обучение безопасности, киберкотики услуги'
    );
  }, []);

  const services = [
    {
      title: 'Игровые марафоны',
      description: 'Серии из мини-игр с котиками. Каждый уровень раскрывает новую угрозу и даёт инструменты защиты.',
      icon: '🎯'
    },
    {
      title: 'Воркшопы для команд',
      description: 'Живые сессии в офисе или онлайн: разбираем реальные фишинговые письма и тренируем реакции.',
      icon: '🤝'
    },
    {
      title: 'Чек-листы привычек',
      description: 'Красочные карточки с упражнениями на неделю, чтобы сформировать безопасные цифровые действия.',
      icon: '✅'
    },
    {
      title: 'Менторство',
      description: 'Помогаем внедрить культуру безопасности в компании: создаём правила, FAQ и сценарии поведения.',
      icon: '🧭'
    }
  ];

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Игровые форматы, которые повышают цифровую грамотность</h1>
        <p>
          Мы верим, что обучение должно быть лёгким, эмоциональным и запоминающимся.
          Поэтому каждая наша активность — это история, в которой котики спасают аккаунты.
        </p>
      </header>

      <section className={styles.cardGrid} aria-label="Список сервисов">
        {services.map((service) => (
          <article className={styles.serviceCard} key={service.title}>
            <span className={styles.icon} aria-hidden="true">{service.icon}</span>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
          </article>
        ))}
      </section>
    </div>
  );
};

export default Services;