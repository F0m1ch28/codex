import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const galleryCats = [
  { src: 'https://placekitten.com/620/540', alt: 'Серый котёнок выглядывает из-за ноутбука' },
  { src: 'https://placekitten.com/600/520', alt: 'Кот в очках смотрит на монитор' },
  { src: 'https://placekitten.com/610/530', alt: 'Пушистый котик дремлет на клавиатуре' },
  { src: 'https://placekitten.com/640/540', alt: 'Полосатый кот играется с кабелем' },
  { src: 'https://placekitten.com/605/505', alt: 'Крошечный котик позирует рядом с смартфоном' },
  { src: 'https://placekitten.com/615/535', alt: 'Белый котёнок с широкими глазами' },
  { src: 'https://placekitten.com/625/515', alt: 'Сиамский кот смотрит прямо в камеру' },
  { src: 'https://placekitten.com/645/525', alt: 'Два котёнка обсуждают безопасность' }
];

const floatingCats = [
  { src: 'https://placekitten.com/420/420', alt: 'Кибер-котик слакит' },
  { src: 'https://placekitten.com/410/410', alt: 'Котик с лазером' },
  { src: 'https://placekitten.com/430/430', alt: 'Кот в шляпе детектива' },
  { src: 'https://placekitten.com/415/415', alt: 'Котик в наушниках' }
];

const quizQuestions = [
  {
    question: 'Письмо от "банка" просит срочно перейти по ссылке и подтвердить данные. Твои действия?',
    options: [
      'Перейти по ссылке и ввести все данные',
      'Проверить адрес отправителя и связаться с банком по официальному каналу',
      'Переслать письмо всем друзьям, чтобы они тоже знали'
    ],
    answer: 'Проверить адрес отправителя и связаться с банком по официальному каналу'
  },
  {
    question: 'Друзья предлагают бесплатную игру по подозрительной ссылке. Что делаем?',
    options: [
      'Не качаем, ищем игру в официальном магазине',
      'Скачиваем, но запускаем ночью, коты не увидят',
      'Добавляем ссылку в закладки и делимся с подписчиками'
    ],
    answer: 'Не качаем, ищем игру в официальном магазине'
  },
  {
    question: 'Пароль от соцсетей должен быть...',
    options: [
      'Простым и запоминающимся, например, "kotik123"',
      'Длинным, с символами и уникальным для каждого сервиса',
      'Таким же, как у любимого блогера'
    ],
    answer: 'Длинным, с символами и уникальным для каждого сервиса'
  },
  {
    question: 'А если сайт просит установить расширение ради "ускорения интернета"?',
    options: [
      'Ставим сразу — вдруг заработает быстрее!',
      'Проверяем отзывы в официальном каталоге и ставим только при доверии',
      'Не ставим, но просим друзей проверить'
    ],
    answer: 'Проверяем отзывы в официальном каталоге и ставим только при доверии'
  },
  {
    question: 'Как часто нужно обновлять антивирус и систему?',
    options: [
      'Как только кот муркнет — значит пора',
      'Регулярно, сразу после выхода обновлений',
      'Только если компьютер начинает шуметь'
    ],
    answer: 'Регулярно, сразу после выхода обновлений'
  }
];

const resultCats = [
  'https://placekitten.com/560/420',
  'https://placekitten.com/550/410',
  'https://placekitten.com/570/430'
];

const updateMeta = (title, description, keywords) => {
  if (typeof document === 'undefined') {
    return;
  }
  document.title = title;
  const ensureMeta = (name, content) => {
    let tag = document.querySelector("meta[name="${name}"]");
    if (!tag) {
      tag = document.createElement('meta');
      tag.setAttribute('name', name);
      document.head.appendChild(tag);
    }
    tag.setAttribute('content', content);
  };
  ensureMeta('description', description);
  ensureMeta('keywords', keywords);
};

const Home = () => {
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loadedImages, setLoadedImages] = useState({});
  const infoPoints = useMemo(
    () => [
      {
        title: 'Фишинговые ловушки',
        description: 'Непроверенные ссылки часто ведут на поддельные страницы, где у тебя украдут логины и пароли.',
        icon: '🐾'
      },
      {
        title: 'Вредоносные файлы',
        description: 'Загрузка "полезной" программы с сомнительного сайта может заразить устройство вирусом.',
        icon: '🛡️'
      },
      {
        title: 'Социальная инженерия',
        description: 'Хакеры часто притворяются знакомыми или брендами, чтобы выманить данные в переписке.',
        icon: '🎮'
      },
      {
        title: 'Потеря данных',
        description: 'Один клик по подозрительной ссылке — и ты рискуешь потерять фото, документы и доступ к аккаунтам.',
        icon: '💾'
      }
    ],
    []
  );

  const serviceCards = useMemo(
    () => [
      {
        title: 'Игровые сценарии',
        description: 'Интерактивные мини-квесты с котиками, которые помогают запомнить шаги безопасного поведения.',
        accent: 'level-up'
      },
      {
        title: 'Советы от мур-экспертов',
        description: 'Подборка простых рекомендаций, написанных живым языком и дополненных иллюстрациями котят.',
        accent: 'purrfect'
      },
      {
        title: 'Контроль привычек',
        description: 'Напоминания и чек-листы, чтобы привычка проверять адрес ссылки стала автоматической.',
        accent: 'focus'
      }
    ],
    []
  );

  const testimonials = useMemo(
    () => [
      {
        name: 'Марина и кот Мята',
        quote: 'Прошла тест вместе с котом — теперь он шипит, если я тянусь к подозрительной ссылке. Работает!',
        avatar: 'https://placekitten.com/120/120'
      },
      {
        name: 'Даня, стример',
        quote: 'Зрители оценили: пока котики пляшут по экрану, я рассказываю про безопасность и ни один фишинг не проходит.',
        avatar: 'https://placekitten.com/121/121'
      },
      {
        name: 'IT-команда Cat&Code',
        quote: 'Отправляем новичков на КиберКотиков: лучше один раз улыбнуться и запомнить, чем потом чинить хаос.',
        avatar: 'https://placekitten.com/122/122'
      }
    ],
    []
  );

  useEffect(() => {
    updateMeta(
      'КиберКотики — Проверь свою цифровую грамотность',
      'Весёлый городской портал про кибербезопасность: тесты, галерея котиков и практичные советы, чтобы не попадаться на фишинг.',
      'киберкотики, кибербезопасность, фишинг, цифровая грамотность, тест на безопасность'
    );
  }, []);

  const handleOptionChange = (questionIndex, option) => {
    setAnswers((prev) => ({
      ...prev,
      [questionIndex]: option
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (Object.keys(answers).length !== quizQuestions.length) {
      setError('Отметь ответы на все вопросы — котики внимательно следят.');
      return;
    }

    setError('');
    const { score, wrong } = quizQuestions.reduce(
      (acc, question, index) => {
        if (answers[index] === question.answer) {
          return { score: acc.score + 1, wrong: acc.wrong };
        }
        return { score: acc.score, wrong: [...acc.wrong, index] };
      },
      { score: 0, wrong: [] }
    );

    const successRate = Math.round((score / quizQuestions.length) * 100);
    let message = '';
    if (score === quizQuestions.length) {
      message = 'Вау! Ты — настоящий кот-киберниндзя. Ни одна подозрительная ссылка не проскользнёт мимо!';
    } else if (score >= quizQuestions.length - 1) {
      message = 'Почти идеально! Осторожность — твой второй хвост. Проверь пару моментов и будет безупречно.';
    } else if (score >= Math.ceil(quizQuestions.length / 2)) {
      message = 'Хороший старт! Но котики советуют ещё раз посмотреть советы, чтобы укрепить защиту.';
    } else {
      message = 'Ой! Котики в панике. Самое время повторить правила и превратить ошибки в опыт.';
    }

    const randomCat = resultCats[Math.floor(Math.random() * resultCats.length)];
    setResult({
      score,
      successRate,
      message,
      wrongQuestions: wrong,
      catImage: randomCat
    });
  };

  const handleReset = () => {
    setAnswers({});
    setResult(null);
    setError('');
  };

  const handleScrollToQuiz = () => {
    const element = document.getElementById('quiz');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleImageLoad = (src) => {
    setLoadedImages((prev) => ({ ...prev, [src]: true }));
  };

  return (
    <div className={styles.wrapper}>
      <section className={styles.hero} id="hero">
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Кибербезопасность в игровой форме с мурлыкающим сопровождением.</p>
          <h1 className={styles.heroTitle}>ПЕРЕХОДИТЬ ПО НЕПРОВЕРЕННЫМ ССЫЛКАМ НЕБЕЗОПАСНО</h1>
          <p className={styles.heroSubtitle}>
            Представь, что каждая подозрительная ссылка — это лазерная указка, ведущая в ловушку.
            Коты знают: лучше сделать вдох, проверить адрес и лишь потом кликать.
          </p>
          <div className={styles.heroActions}>
            <button type="button" className={styles.quizButton} onClick={handleScrollToQuiz}>
              ну тогда надо пройти тест снова
            </button>
            <Link to="/services" className={styles.secondaryButton}>
              Что приготовили котики
            </Link>
          </div>
        </div>
        <div className={styles.heroArt} aria-hidden="true">
          {floatingCats.map((cat, index) => (
            <img
              key={cat.src}
              src={cat.src}
              alt={cat.alt}
              className={"${styles.floatCat} ${styles["floatCat${index}"]}"}
              loading="lazy"
            />
          ))}
        </div>
      </section>

      <section className={styles.gallery} id="gallery" aria-labelledby="gallery-title">
        <div className={styles.sectionHeader}>
          <h2 id="gallery-title">Галерея котиков-наблюдателей</h2>
          <p>Каждый из них напоминает: прежде чем кликнуть — посмотри дважды.</p>
        </div>
        <div className={styles.galleryGrid}>
          {galleryCats.map((cat) => (
            <figure key={cat.src} className={styles.galleryItem}>
              <div className={styles.imageWrapper}>
                {!loadedImages[cat.src] && <div className={styles.imagePlaceholder} />}
                <img
                  src={cat.src}
                  alt={cat.alt}
                  onLoad={() => handleImageLoad(cat.src)}
                  className={loadedImages[cat.src] ? styles.imageVisible : styles.imageHidden}
                  loading="lazy"
                />
              </div>
              <figcaption>{cat.alt}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.infoSection} id="info" aria-labelledby="info-title">
        <div className={styles.sectionHeader}>
          <h2 id="info-title">Почему котики против непроверенных ссылок</h2>
          <p>Четыре причины, из-за которых даже самый любопытный кот предпочитает осторожность.</p>
        </div>
        <ul className={styles.infoList}>
          {infoPoints.map((item) => (
            <li key={item.title} className={styles.infoItem}>
              <span className={styles.infoIcon} aria-hidden="true">{item.icon}</span>
              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.servicesSection} aria-labelledby="services-title">
        <div className={styles.sectionHeader}>
          <h2 id="services-title">Что делает обучение ярким</h2>
          <p>Мы комбинируем игровые механики и реальные сценарии, чтобы знания закреплялись.</p>
        </div>
        <div className={styles.servicesGrid}>
          {serviceCards.map((card) => (
            <article key={card.title} className={styles.serviceCard}>
              <span className={styles.serviceAccent}>{card.accent}</span>
              <h3>{card.title}</h3>
              <p>{card.description}</p>
              <Link to="/services" className={styles.cardLink}>
                Подробнее
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-title">
        <div className={styles.sectionHeader}>
          <h2 id="testimonials-title">Отзывы мурлыкающих пользователей</h2>
          <p>Котики делятся впечатлениями, а люди — результатами.</p>
        </div>
        <div className={styles.testimonialList}>
          {testimonials.map((testimonial) => (
            <article key={testimonial.name} className={styles.testimonialCard}>
              <img src={testimonial.avatar} alt={testimonial.name} loading="lazy" />
              <blockquote>{testimonial.quote}</blockquote>
              <p className={styles.testimonialName}>{testimonial.name}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.aboutPreview} aria-labelledby="about-preview-title">
        <div className={styles.sectionHeader}>
          <h2 id="about-preview-title">Как рождаются КиберКотики</h2>
          <p>У нас есть команда энтузиастов и которедакторов, читающих каждый совет.</p>
        </div>
        <div className={styles.stats}>
          <article className={styles.statCard}>
            <h3>1200+</h3>
            <p>участников прошли тест за последние три месяца.</p>
          </article>
          <article className={styles.statCard}>
            <h3>87%</h3>
            <p>повысили внимательность к подозрительным ссылкам уже после первой сессии.</p>
          </article>
          <article className={styles.statCard}>
            <h3>24/7</h3>
            <p>котики патрулируют чат поддержки и делятся мемами по делу.</p>
          </article>
        </div>
        <Link to="/about" className={styles.secondaryButton}>
          Узнать нашу историю
        </Link>
      </section>

      <section className={styles.ctaSection} aria-labelledby="cta-title">
        <div className={styles.ctaContent}>
          <h2 id="cta-title">Готов проверить свои навыки ещё раз?</h2>
          <p>Если где-то закрался сомнительный ответ, котики вежливо намекают: тест доступен всегда.</p>
          <button type="button" className={styles.quizButtonAlt} onClick={handleScrollToQuiz}>
            ну тогда надо пройти тест снова
          </button>
        </div>
      </section>

      <section className={styles.quizSection} id="quiz" aria-labelledby="quiz-title">
        <div className={styles.sectionHeader}>
          <h2 id="quiz-title">Игровой тест на цифровую безопасность</h2>
          <p className={styles.quizIntro}>
            Выбери варианты, которые кажутся тебе правильными. Котики подскажут, насколько ты осознанный пользователь.
          </p>
        </div>
        <form className={styles.quizForm} onSubmit={handleSubmit} noValidate>
          {quizQuestions.map((question, index) => (
            <fieldset key={question.question} className={styles.quizFieldset}>
              <legend>{"${index + 1}. ${question.question}"}</legend>
              {question.options.map((option) => (
                <label key={option} className={styles.optionLabel}>
                  <input
                    type="radio"
                    name={"question-${index}"}
                    value={option}
                    checked={answers[index] === option}
                    onChange={() => handleOptionChange(index, option)}
                  />
                  <span>{option}</span>
                </label>
              ))}
            </fieldset>
          ))}
          {error && <p className={styles.error}>{error}</p>}
          <div className={styles.quizActions}>
            <button type="submit" className={styles.primaryButton}>Проверить результат</button>
            <button type="button" onClick={handleReset} className={styles.resetButton}>
              Сбросить ответы
            </button>
          </div>
        </form>
        {result && (
          <div className={styles.resultBox} role="status">
            <p className={styles.score}>
              Твой результат: {result.score} из {quizQuestions.length} ({result.successRate}%)
            </p>
            <p>{result.message}</p>
            {result.wrongQuestions.length > 0 && (
              <p className={styles.wrongNote}>
                Проверь вопросы: {result.wrongQuestions.map((item) => item + 1).join(', ')}.
              </p>
            )}
            <img src={result.catImage} alt="Котик поздравляет с результатом" loading="lazy" />
            <Link to="/contact" className={styles.secondaryButton}>
              Попросить персональную консультацию
            </Link>
          </div>
        )}
      </section>
    </div>
  );
};

export default Home;