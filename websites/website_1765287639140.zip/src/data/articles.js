const articles = [
  {
    id: 'evolution-rue-mouffetard-paris',
    title: 'L’évolution pluriséculaire de la rue Mouffetard à Paris',
    subtitle: 'Lecture morphologique et mémoires collectives d’un axe de la rive gauche',
    category: 'Paris',
    tag: 'Histoire Sociale',
    date: '12 avril 2024',
    readingTime: '12 min',
    image: '/images/article-rue-mouffetard.jpg',
    summary: `Au cours de plus de huit siècles, la rue Mouffetard s’est transformée sans rompre avec son profil médiéval. Ce dossier propose une lecture croisée des sources archivistiques, des relevés architecturaux et des témoignages d’habitants pour comprendre la résilience de cette artère montante. Les plans de Turgot, les registres paroissiaux et les cadastres du XIXe siècle révèlent des phases de reconfiguration successives, souvent liées à la gestion de l’eau et aux logiques de quartier. Les photographies de Charles Marville et les travaux contemporains de sociologues, notamment ceux de Chombart de Lauwe, éclairent la manière dont les structures bâties ont retenu les usages populaires. L’article examine également la manière dont les politiques patrimoniales récentes articulent conservation et densification douce, en intégrant les attentes des riverains, des historiens de la ville et des urbanistes. Ce regard analytique met en lumière la singularité parisienne tout en la confrontant à des comparaisons européennes.`,
    introduction: `Située sur l’ancien tracé du cardo de Lutèce, la rue Mouffetard dessine un ruban pavé reliant la montagne Sainte-Geneviève aux plaines de la Bièvre. Sa pente, sa largeur irrégulière et la densité de ses parcelles attenantes en font un observatoire privilégié des transformations parisiennes. Les archives consultées pour ce dossier montrent comment la rue a absorbé les arrivées successives de communautés marchandes, artisanales et étudiantes, sans perdre son rôle d’axe quotidien. À travers un corpus composé de plans, d’inventaires notariés, de monographies littéraires et de relevés architecturaux, l’étude retrace les dialogues permanents entre morphologie bâtie et usages. L’article propose une lecture diachronique qui met en regard les projets municipaux du XIXe siècle, les opérations de rénovation des années 1960 et les politiques de protection patrimoniale actuelles.`,
    sections: [
      {
        heading: 'Sources et strates documentaires',
        paragraphs: [
          `Les archives du chapitre de Sainte-Geneviève, complétées par les terriers de la fin du Moyen Âge, constituent les premiers repères sur l’organisation foncière de la rue Mouffetard. Ils révèlent un réseau de propriétés linéaires, étroites, dont la profondeur varie selon les servitudes de cour et d’atelier. L’étude de ces documents, couplée aux plans du XVIIe siècle conservés aux Archives nationales, montre que la rue se structure très tôt autour de pôles paroissiaux, en particulier la paroisse Saint-Médard. La présence de confréries marchandes y est attestée dès 1320, marquant le rôle économique de l’axe sans que celui-ci ne se transforme en boulevard spécialisé.`,
          `Au XVIIIe siècle, les sources évoluent vers des inventaires plus précis. Les registres fiscaux, les actes de vente et les enquêtes sanitaires menées après les épidémies du début du siècle renseignent sur les matériaux employés et les altérations récurrentes. Les états des lieux dressés lors des travaux du préfet Rambuteau au milieu du XIXe siècle complètent ce corpus. Ils témoignent du souci administratif de réguler les débordements d’activités sur la voie publique tout en respectant la trame ancienne. La comparaison de ces documents avec les campagnes photographiques de Charles Marville, réalisées entre 1865 et 1870, permet de mesurer la permanence des alignements et le caractère fragmentaire des interventions.`
        ]
      },
      {
        heading: 'Morphologie bâtie et alignements',
        paragraphs: [
          `Les relevés réalisés par l’École des Beaux-Arts dans les années 1880 confirment un découpage parcellaire serré, ponctué de patios et d’escaliers débouchant sur des cours intérieures. L’analyse morphologique montre que la rue conserve, malgré les réglementations d’alignement, des saillies et décrochements qui traduisent des reconstructions partielles plutôt que des démolitions totales. Les façades alternent entre maisons à pans de bois encore visibles, immeubles de pierre du XVIIIe siècle et surélévations réalisées après 1900. Cette diversité, loin d’être le fruit du hasard, résulte de compromis successifs entre les propriétaires et l’administration municipale, soucieuse de préserver l’écoulement des eaux pluviales et la ventilation des logements.`,
          `La topographie joue un rôle décisif dans la gestion de la pente. Les plans inclinés intégrés aux chaussées et la présence renouvelée de caniveaux centraux témoignent d’une adaptation concrète aux contraintes hydrologiques. Les interventions haussmanniennes, très limitées dans ce secteur, se réduisent à quelques alignements ponctuels et à l’amélioration de l’éclairage public. Au XXe siècle, l’arrivée du tout-à-l’égout et le pavage à joints serrés modifient la perception des usagers sans effacer les irrégularités originelles. Les campagnes de restauration menées depuis les années 1980 insistent sur la conservation des gabarits et sur la restitution de certains éléments disparus, tels que les enseignes en ferronnerie ou les modénatures des étages nobles.`
        ]
      },
      {
        heading: 'Sociabilités et activités de proximité',
        paragraphs: [
          `Les témoignages recueillis auprès d’habitants et de commerçants, conservés dans les archives orales de la Ville de Paris, soulignent la pluralité des sociabilités présentes sur la rue Mouffetard. Les étudiants, les artisans, les résidents âgés et les visiteurs de passage cohabitent dans un espace étroit, régulé par des temporalités spécifiques. Les marchés alimentaires du matin, les cafés de la fin d’après-midi et les manifestations estudiantines contribuent à une animation continue sans que la rue ne perde sa vocation résidentielle. Les enquêtes de l’Atelier parisien d’urbanisme montrent que la densité de rez-de-chaussée actifs renforce ce sentiment de proximité et d’interconnaissance.`,
          `Les analyses socio-économiques menées depuis les années 1960 révèlent cependant des tensions ponctuelles liées à la pression touristique et à la hausse des loyers. Les dispositifs municipaux de régulation des activités de bouche, notamment les chartes alimentaires de 2008, cherchent un équilibre entre tradition culinaire et exigences sanitaires. Les associations de riverains, très actives, jouent un rôle de médiation en documentant les transformations des vitrines, l’évolution des enseignes et la gestion des terrasses. Cette veille citoyenne contribue à maintenir des pratiques attentives au tissu urbain, évitant les ruptures brutales observées dans d’autres secteurs gentrifiés.`
        ]
      },
      {
        heading: 'Politiques patrimoniales et perspectives',
        paragraphs: [
          `La rue Mouffetard est intégrée depuis 1995 au dispositif de sauvegarde du Plan local d’urbanisme de Paris, qui impose des prescriptions spécifiques sur les matériaux, les hauteurs et les usages. Les études réalisées pour ce plan montrent que la conservation ne se limite pas à une façade souvenir, mais englobe la trame parcellaire, les alignements de toitures et les réseaux d’évacuation historiques. Les interventions récentes privilégient des techniques réversibles, telles que les consolidations par charpentes métalliques internes, afin de préserver les structures en bois ou en pierre tendre. La mairie du 5e arrondissement appuie ces orientations par des ateliers de sensibilisation destinés aux copropriétaires.`,
          `Les perspectives d’évolution se concentrent aujourd’hui sur la transition climatique et sur la gestion des flux. L’arrivée de dispositifs de logistique urbaine douce, l’expérimentation de revêtements moins bruyants et la mise en place d’itinéraires piétons connectés à la résurgence de la Bièvre constituent les axes principaux des prochains projets. Les urbanistes s’appuient sur les enseignements des siècles passés pour intégrer les besoins contemporains sans rompre l’équilibre fragile entre animation et habitabilité. La rue Mouffetard demeure ainsi un laboratoire de compatibilité entre patrimoine et usages quotidiens.`
        ]
      }
    ],
    conclusion: `La longue perspective historique rassemblée dans cette étude met en évidence l’endurance d’une rue qui a su absorber des mutations successives sans sacrifier son identité. Les sources textuelles, cartographiques et orales convergent vers l’idée d’une adaptation fine, construite par petites touches, où chaque génération réinterprète la pente, les façades et les rez-de-chaussée. Les politiques actuelles tirent parti de cette mémoire en privilégiant la concertation et la connaissance détaillée du bâti. Rue Mouffetard, la ville se lit comme une sédimentation d’initiatives dont la cohérence repose sur la reconnaissance des usages ordinaires. C’est cette alliance entre patrimoine vivant et observation minutieuse qui confère à l’artère son caractère singulier dans le paysage parisien.`
  },
  {
    id: 'traces-haussmanniennes-lyon',
    title: 'Traces haussmanniennes et réinterprétations lyonnaises de la rue de la République',
    subtitle: 'Une opération de la modernité parisienne adaptée à la presqu’île',
    category: 'Lyon',
    tag: 'Architecture',
    date: '22 mars 2024',
    readingTime: '11 min',
    image: '/images/article-lyon-republique.jpg',
    summary: `La rue de la République à Lyon incarne une synthèse singulière entre la doctrine haussmannienne et les contraintes de la presqu’île. En mobilisant des procès-verbaux d’expropriation, des plans d’alignement, des correspondances entre le préfet Vaïsse et les ingénieurs, ainsi que les archives photographiques du musée Gadagne, l’article retrace les étapes d’une transformation majeure. L’étude montre comment la régularité des gabarits, l’ouverture de passages couverts et l’intégration d’immeubles mixtes ont redéfini la centralité lyonnaise. Elle examine également les recompositions sociales provoquées par les opérations de la seconde moitié du XIXe siècle et les réinvestissements du XXe siècle, de la piétonnisation de 1974 aux mises en lumière contemporaines. Le dossier souligne enfin la manière dont les acteurs actuels conjuguent conservation patrimoniale, mobilités douces et animation quotidienne afin de préserver la vitalité d’un axe emblématique.`,
    introduction: `Au cœur de la presqu’île de Lyon, la rue de la République relie la place Bellecour à l’Hôtel de Ville par une perspective rectiligne qui contraste avec le tissu médiéval environnant. Mise en œuvre entre 1853 et 1860, l’opération refaçonne un quartier densément construit, marqué par des parcelles étroites et des maisons traversantes. Pour comprendre l’ampleur de cette transformation, la présente étude s’appuie sur les archives de la Commission d’alignement, les plans cadastraux, les séries photographiques conservées au musée Gadagne et les analyses récentes des urbanistes. L’objectif est de mesurer la portée des choix haussmanniens à Lyon, leur réception par les habitants et les héritages qui structurent encore aujourd’hui l’expérience piétonne. Les matériaux mobilisés permettent de croiser les échelles : du dessin de façade à la politique foncière, en passant par les usages quotidiens de la rue.`,
    sections: [
      {
        heading: 'Expropriations et recompositions foncières',
        paragraphs: [
          `Les procès-verbaux d’expropriation conservés aux Archives municipales de Lyon relatent avec précision les négociations menées par le préfet Vaïsse et son équipe. Ils révèlent l’importance des indemnités accordées en fonction des profondeurs de parcelles, des annexes et des caves, éléments décisifs dans un quartier dont l’économie reposait sur des immeubles industriels de petite taille. La lecture des correspondances entre l’ingénieur Descos et la municipalité montre que la priorité était d’ouvrir une artère traversante, capable d’accueillir des flux accrus tout en conservant les continuités avec les places existantes.`,
          `La question de la relocalisation des habitants et des métiers chassés par les démolitions occupe une part importante des débats. Les archives mettent en évidence la création de logements de substitution sur les pentes de la Croix-Rousse et du faubourg de Vaise. Si ces mesures ont limité la dispersion totale des familles, elles ont accentué une polarisation sociale entre la presqu’île modernisée et les quartiers périphériques. Les historiens de l’urbanisme soulignent que cet épisode inaugure une politique d’aménagement intensif qui préfigure les grandes opérations lyonnaises du XXe siècle.`
        ]
      },
      {
        heading: 'Architecture et matérialité de la nouvelle artère',
        paragraphs: [
          `Les façades érigées le long de la rue de la République empruntent à la syntaxe parisienne des corniches saillantes, des balcons filants et des arcades commerçantes, tout en intégrant des éléments lyonnais comme les décors de pierre de Couzon. Les plans d’architectes étudiés mettent en évidence une typologie d’immeubles à double orientation, destinés à capter la lumière sur les deux façades. Les étages supérieurs abritent des appartements traversants tandis que les niveaux intermédiaires accueillent des bureaux. Les rez-de-chaussée sont conçus avec des vitrines modulaires permettant une adaptation rapide des usages.`,
          `La matérialité de la rue évolue au fil du temps. Les premiers pavages sont remplacés dès 1890 par des dalles plus lisses afin de faciliter la circulation des tramways. Les relevés photographiques de Jules Sylvestre, puis les vues aériennes des années 1930, documentent l’ajout progressif d’enseignes verticales et de marquises métalliques. Dans les années 1990, les opérations de restauration privilégient des teintes minérales et la restitution des volumes d’origine, en veillant à maintenir la lisibilité des rythmes d’ouverture.`
        ]
      },
      {
        heading: 'La rue de la République comme scène urbaine',
        paragraphs: [
          `Les rapports de la Chambre de commerce et les récits de voyageurs montrent que la rue de la République devient rapidement un théâtre de sociabilités. Les grands magasins, les cafés littéraires et les cinémas du début du XXe siècle attirent une clientèle diversifiée. Les enquêtes ethnographiques menées dans les années 1960 soulignent toutefois les tensions entre circulation automobile et flânerie. Les trottoirs étroits, les embouteillages récurrents et la pollution atmosphérique nourrissent les débats sur la piétonnisation.`,
          `La décision de fermer la rue à la circulation motorisée en 1974 constitue une étape majeure. Les documents d’urbanisme de l’époque insistent sur la nécessité de redonner à la presqu’île une échelle piétonne, en lien avec la rénovation de la place des Terreaux. Les études d’impact réalisées quarante ans plus tard confirment que cette mutation a renforcé l’attractivité culturelle et commerciale de l’axe, tout en ouvrant la voie à des animations régulières, telles que les festivals de lumière et les marchés éphémères.`
        ]
      },
      {
        heading: 'Politiques contemporaines et perspectives',
        paragraphs: [
          `Depuis le début du XXIe siècle, la rue de la République fait l’objet de campagnes de requalification successives. Les revêtements ont été remplacés par des pavés de granit plus résistants, les alignements d’arbres ont été densifiés et l’éclairage public recalibré pour réduire la consommation énergétique. Les études menées par la Métropole de Lyon mettent en avant une approche fine, qui combine conservation patrimoniale et adaptation aux mobilités douces, notamment avec l’intégration de stations Vélo’v en périphérie immédiate.`,
          `Les perspectives à moyen terme incluent la gestion des flux touristiques et la valorisation des passages secondaires, tels que la galerie de l’Argue, afin de diversifier les parcours. Les urbanistes privilégient une logique de couture urbaine, articulant l’axe haussmannien aux ruelles historiques et aux berges récemment réaménagées. La rue de la République demeure ainsi un laboratoire de gouvernance partagée entre la Métropole, la Ville et les acteurs locaux, soucieux de préserver une identité lyonnaise singulière tout en maintenant la lisibilité de l’héritage haussmannien.`
        ]
      }
    ],
    conclusion: `L’analyse croisée des archives, des relevés architecturaux et des observations contemporaines montre que la rue de la République ne se réduit pas à une transposition de la modernité parisienne. Elle illustre plutôt une adaptation contextualisée, où la régularité des façades dialogue avec la complexité d’une presqu’île héritée du passé. Les politiques menées depuis cinquante ans confirment la capacité des acteurs lyonnais à renouveler l’axe sans rompre avec les choix fondateurs du XIXe siècle. En s’appuyant sur la piétonnisation, la conservation patrimoniale et l’animation culturelle, la rue de la République demeure un marqueur de l’identité urbaine lyonnaise et un champ d’observation privilégié pour comprendre la réinterprétation des modèles haussmanniens.`
  },
  {
    id: 'metamorphoses-panier-marseille',
    title: 'Métamorphoses lentes du quartier du Panier à Marseille',
    subtitle: 'Entre strates portuaires et reconstructions du quotidien',
    category: 'Marseille',
    tag: 'Quartiers Médiévaux',
    date: '28 février 2024',
    readingTime: '13 min',
    image: '/images/article-marseille-panier.jpg',
    summary: `Le quartier du Panier, cœur historique de Marseille, a vu son tissu urbain évoluer au rythme des transformations portuaires, des reconstructions d’après-guerre et des politiques patrimoniales récentes. À partir d’archives municipales, de récits de photographes et d’enquêtes sociologiques, l’article restitue la manière dont les ruelles escarpées, les escaliers et les placettes se recomposent. Sont abordés les nombreux déplacements de populations, les artisans liés à la mer, les interventions du service des Monuments historiques et les opérations de réhabilitation menées depuis les années 1980. Le dossier souligne la coexistence d’ateliers d’art, d’habitations à loyers modérés, d’équipements culturels et de lieux de mémoire liés aux migrations. Cette pluralité nourrit un patrimoine vivant qui interroge la gestion des flux touristiques, la lutte contre la vacance et la transmission des savoir-faire locaux.`,
    introduction: `Face au Vieux-Port, le quartier du Panier s’étend en pente, alignant des ruelles étroites et des placettes ombragées. Sa morphologie résulte d’un entremêlement de cycles portuaires, d’implantations monastiques et de reconstructions successives, notamment après les bombardements de 1943. Cette contribution établit un récit diachronique en mobilisant les plans anciens conservés au sein du cadastre, les dossiers de reconstruction de l’architecte Fernand Pouillon, les archives des associations de quartier et les travaux récents des géographes. L’enjeu consiste à comprendre comment un espace longtemps marginalisé devient un symbole patrimonial mis en récit par la Ville, tout en restant le lieu d’une vie quotidienne dense.`,
    sections: [
      {
        heading: 'Vestiges médiévaux et héritages portuaires',
        paragraphs: [
          `Les plans du XVIIIe siècle recensent un réseau de venelles héritées du tracé médiéval, ponctuées d’édifices religieux et d’entrepôts dédiés aux échanges méditerranéens. Les archives prouvent que la proximité du port façonnait la vie du Panier : magasins de denrées coloniales, ateliers de réparation navale et auberges recevant les équipages jalonnaient les rues. Les descriptions de voyageurs, notamment celles de l’Anglais Arthur Young, insistent sur l’animation constante et la diversité des communautés installées.`,
          `Au XIXe siècle, la transformation du port et l’ouverture de la ligne ferroviaire Marseille-Avignon provoquent une redéfinition des usages. Les maisons se densifient, les escaliers sont réaménagés, tandis que la municipalité entreprend l’assainissement des îlots les plus insalubres. Les archives sanitaires témoignent des efforts pour combattre les épidémies de choléra et de fièvre jaune. Ces interventions laissent néanmoins intacte la trame viaire, qui reste le socle du quartier contemporain.`
        ]
      },
      {
        heading: 'Reconstruction et modernisation après 1943',
        paragraphs: [
          `Les bombardements de la Seconde Guerre mondiale détruisent une partie du quartier, en particulier autour de la rue du Refuge. Les dossiers du Ministère de la Reconstruction et de l’Urbanisme, associés aux archives de l’architecte Fernand Pouillon, documentent la volonté de préserver l’échelle villageoise tout en introduisant des immeubles modernes. Les reconstructions adoptent des façades sobres, en pierre blonde, avec des percées visuelles vers le port. Les logements sont équipés d’infrastructures sanitaires inédites pour le secteur.`,
          `Cependant, ces opérations se traduisent par le déplacement de nombreux habitants vers les nouveaux ensembles périphériques. Les associations nées dans les années 1960 se mobilisent pour éviter la banalisation du quartier. Elles organisent des inventaires du bâti, des ateliers d’histoire orale et des fêtes de rue qui soulignent la singularité du Panier. Ces initiatives citoyennes influencent les politiques municipales ultérieures, orientées vers la requalification douce plutôt que vers la tabula rasa.`
        ]
      },
      {
        heading: 'Politiques patrimoniales et revitalisation sociale',
        paragraphs: [
          `À partir des années 1980, la municipalité lance plusieurs programmes de réhabilitation. Les logements vétustes sont rénovés en concertation avec les habitants, les rez-de-chaussée accueillent des ateliers d’artisanat et des structures sociales. Les archives de la Société publique locale Marseille Aménagement indiquent que l’objectif consiste à maintenir un équilibre entre ressources culturelles et vie quotidienne. Les opérations faubouriennes sont accompagnées d’un suivi socio-économique pour éviter une transformation exclusive en quartier touristique.`,
          `Les enquêtes du laboratoire TELEMMe montrent que les politiques patrimoniales ont développé un récit collectif autour de la mémoire migratoire. Les plaques évoquant l’arrivée des communautés arménienne, italienne et comorienne sont installées au détour des ruelles. Les écrivains locaux, tels que Jean-Claude Izzo, contribuent à façonner l’image du Panier en décrivant ses cafés, ses odeurs de cuisine et ses conversations polyglottes. Cette valorisation participe à la reconnaissance du quartier tout en rappelant ses racines populaires.`
        ]
      },
      {
        heading: 'Enjeux contemporains et gestion des flux',
        paragraphs: [
          `Le succès touristique du Panier oblige à réguler les flux. Les données recueillies par l’Office métropolitain de tourisme révèlent une hausse significative des visites lors des escales de croisières. Pour éviter la saturation des ruelles, la ville met en place des itinéraires balisés et encourage la découverte de secteurs moins fréquentés, comme la montée des Accoules. Parallèlement, des programmes de résorption de la vacance et d’aide à la réhabilitation soutiennent les résidents dans l’entretien des immeubles.`,
          `Les débats actuels portent sur l’équilibre entre animation culturelle et tranquillité résidentielle. Les cafés-concerts, les ateliers d’artistes et les espaces associatifs adoptent des chartes horaires afin de respecter les habitants. Les architectes urbanistes recommandent de préserver le caractère piéton et de renforcer la végétalisation des placettes pour répondre aux exigences climatiques. Le Panier continue ainsi de se transformer par petites touches, fidèle à une tradition de coexistence entre mémoire et usages présents.`
        ]
      }
    ],
    conclusion: `L’évolution du Panier démontre la capacité d’un quartier ancien à intégrer les enjeux contemporains sans renoncer à sa trame historique. Les archives et les études de terrain convergent vers l’idée d’une reconstruction patiente, fondée sur les habitants, les associations et les institutions patrimoniales. La gestion actuelle, basée sur la concertation, la reconnaissance des mémoires migratoires et la régulation des flux, témoigne d’une attention constante portée au quotidien. Ce laboratoire marseillais illustre l’importance de considérer les rues non pas comme des vestiges figés, mais comme des espaces en mouvement où se tisse une identité urbaine renouvelée.`
  },
  {
    id: 'quais-bordeaux-memoire-fluviale',
    title: 'Les quais de Bordeaux, mémoire fluviale et recompositions urbaines',
    subtitle: 'Étude longitudinale des berges de la Garonne',
    category: 'Bordeaux',
    tag: 'Patrimoine Urbain',
    date: '5 février 2024',
    readingTime: '12 min',
    image: '/images/article-bordeaux-quais.jpg',
    summary: `Les quais de Bordeaux, inscrits au patrimoine mondial, ont connu une succession de réaménagements depuis le XVIIIe siècle. Ce dossier analyse les plans de l’intendant Tourny, les archives portuaires, les relevés bathymétriques et les études contemporaines menées par l’Agence d’urbanisme Bordeaux Aquitaine. L’article retrace la construction des façades monumentales, la période industrielle marquée par les hangars et l’ère post-industrielle qui transforme les berges en promenade. Il s’intéresse aux interactions entre la Garonne, l’activité portuaire, les mobilités et la mémoire collective. L’étude met en évidence les choix paysagers, la gestion du risque d’inondation et la place accordée aux usagers dans les projets récents, notamment les Bassins à flot et le quai des Queyries.`,
    introduction: `Les berges de la Garonne constituent le socle de l’identité bordelaise. Au XVIIIe siècle, l’intendant Tourny imagine un front monumental, rythmé par des quais en pierre et des façades classiques. Les siècles suivants transforment ce décor en un espace portuaire, animé par les navires de commerce. Lorsque le port se déplace vers l’estuaire au XXe siècle, la ville se retrouve face à une infrastructure délaissée. L’étude présentée ici reconstitue les étapes de cette trajectoire à partir des archives municipales, des dossiers du Port autonome, des plans hydrauliques et des projets paysagers contemporains. Elle interroge la manière dont les quais deviennent un laboratoire de recomposition urbaine.`,
    sections: [
      {
        heading: 'Du front classique au port industriel',
        paragraphs: [
          `Les plans dressés par l’intendant Tourny entre 1730 et 1750 transforment les rives marécageuses en un front urbain majestueux. Les façades de la place de la Bourse, les alignements de quais et les paliers d’escaliers constituent un ensemble harmonieux destiné à accueillir les marchands venus de toute l’Europe. Les sources de l’époque, notamment les récits de négociants anglais et néerlandais, louent la monumentalité du décor. Les archives municipales mentionnent également la construction de magasins à vin et d’entrepôts à grain, attestant l’intensité des échanges.`,
          `Au XIXe siècle, l’arrivée du chemin de fer et l’industrialisation des quais modifient radicalement l’atmosphère. Les hangars métalliques, les grues et les voies ferrées envahissent le front de la Garonne. Les cartes postales du début du XXe siècle, conservées au musée d’Aquitaine, témoignent de ce foisonnement. La cohabitation entre activités industrielles et vie urbaine suscite des plaintes récurrentes liées aux fumées et au bruit. Pourtant, le port reste l’un des principaux employeurs de la région et maintient Bordeaux au rang de grande place maritime.`
        ]
      },
      {
        heading: 'Recul portuaire et nouvelles ambitions urbaines',
        paragraphs: [
          `À partir des années 1960, le glissement des infrastructures vers l’aval libère de vastes emprises sur les quais. Les débats s’engagent sur le devenir de ces espaces. Les archives du Port autonome montrent des hésitations entre reconversion industrielle, maintien d’activités logistiques légères et ouverture au public. Les premiers projets de promenades, portés par l’architecte Claude Ferret, peinent à convaincre faute de financements. Il faut attendre les années 1990 pour que la municipalité et la communauté urbaine s’accordent sur une stratégie de réappropriation.`,
          `Le lancement de la Mission des quais en 1996 marque un tournant. Les études paysagères, menées avec l’agence d’urbanisme, fixent des principes : ramener la nature en rive, reconnecter la ville et le fleuve, valoriser les héritages bâtis. Les anciens hangars sont transformés en espaces culturels, les quais deviennent accessibles, et les plantations accompagnent la promenade. Le succès de ces aménagements repose sur une programmation graduelle qui associe habitants, associations et acteurs économiques.` 
        ]
      },
      {
        heading: 'Gestion du risque et ingénierie fluviale',
        paragraphs: [
          `Les quais bordelais doivent composer avec les crues de la Garonne et le phénomène du mascaret. Les relevés bathymétriques et les données hydrologiques analysées par le CEREMA servent de base aux réaménagements récents. Les quais ont été rehaussés par endroits, des digues discrètes installées et des systèmes d’alerte modernisés. Les choix paysagers intègrent des matériaux perméables, des plantations adaptées aux sols humides et des dispositifs de drainage. Les promenades ne sont pas interrompues par ces équipements, intégrés dans le dessin global.`,
          `La prise en compte du changement climatique se traduit par des simulations de montée des eaux et par une réflexion sur la résilience des infrastructures. Les architectes paysagistes insistent sur la nécessité de conserver des espaces ouverts susceptibles d’accueillir temporairement l’eau. Cette approche, conjuguée à la diversification des usages (cyclistes, piétons, événements culturels), fait des quais un terrain d’expérimentation pour la gestion adaptative des rives.`
        ]
      },
      {
        heading: 'Usages contemporains et mémoire collective',
        paragraphs: [
          `Depuis leur réouverture, les quais accueillent une diversité d’usagers : promeneurs, cyclistes, joggeurs, familles et visiteurs. Les études d’observation menées par le laboratoire PASSAGES montrent que les habitants se réapproprient les berges en fonction des saisons. Les marchés de producteurs, les festivals et les installations artistiques ponctuent l’année, tout en respectant des règles strictes pour préserver le cadre patrimonial. Des dispositifs d’interprétation révèlent la mémoire portuaire : cartels, parcours sonores, expositions installées dans les anciens hangars.`,
          `Les habitants interrogés évoquent un sentiment de continuité avec l’histoire fluviale, malgré la disparition des navires de commerce. Les bateaux patrimoine, amarrés ponctuellement, entretiennent ce lien. Parallèlement, de nouvelles pratiques émergent, telles que les ateliers de dessin en plein air ou les balades guidées centrées sur l’estuaire. Les quais deviennent un lieu de transmission intergénérationnelle où le récit urbain se renouvelle.`
        ]
      }
    ],
    conclusion: `Les quais de Bordeaux illustrent la manière dont une ville peut réinventer son rapport au fleuve. La relecture de trois siècles d’aménagements révèle un mouvement pendulaire entre efficacité portuaire et mise en scène urbaine. Les projets récents, fondés sur la concertation et la connaissance fine de la Garonne, démontrent qu’il est possible de concilier patrimoine, paysage et pratiques quotidiennes. Les quais s’affirment désormais comme une interface active où se combinent mémoire fluviale, mobilités douces et attention aux risques climatiques.`
  },
  {
    id: 'grande-ile-strasbourg-hybridations',
    title: 'La Grande Île de Strasbourg : hybridations médiévales et aménagements contemporains',
    subtitle: 'Entre trame rhénane et gouvernance partagée',
    category: 'Strasbourg',
    tag: 'Centres Historiques',
    date: '18 janvier 2024',
    readingTime: '11 min',
    image: '/images/article-strasbourg-grande-ile.jpg',
    summary: `Classée au patrimoine mondial, la Grande Île de Strasbourg combine un tissu médiéval, une architecture rhénane et des interventions contemporaines. L’article s’appuie sur les plans anciens, les archives de la Ville et de l’Eurométropole, ainsi que sur les diagnostics patrimoniaux récents. Il analyse les ruelles commerciales, les alignements de maisons à colombages, les places Renaissance et les interventions du XXe siècle, notamment la restructuration de la place Kléber et la piétonnisation des abords de la cathédrale. Le dossier met en lumière les arbitrages entre conservation, accessibilité et transition écologique, en s’intéressant aux usages quotidiens des habitants et aux exigences touristiques. Il examine également la gouvernance partagée qui associe la municipalité, les associations patrimoniales et les institutions européennes basées dans la ville.`,
    introduction: `La Grande Île constitue le noyau historique de Strasbourg. Ce périmètre entouré par les bras de l’Ill abrite une mosaïque de rues médiévales, de ponts, de places et de maisons à colombages. Les influences germaniques et françaises s’y entremêlent, reflétant les changements politiques. Cette contribution propose un parcours analytique à travers les sources cartographiques du XVIe siècle, les plans reliefs du XVIIIe siècle, les dossiers de rénovation de l’après-guerre et les études contemporaines de l’Eurométropole. Elle interroge la manière dont les acteurs urbains préservent la richesse patrimoniale tout en répondant aux enjeux de mobilité, de commerce de proximité et de qualité résidentielle.`,
    sections: [
      {
        heading: 'Trame médiévale et héritage rhénan',
        paragraphs: [
          `Les cartes de Matthäus Merian et les plans conservés dans les archives municipales montrent la densité du tissu médiéval, structuré autour de la cathédrale et des axes commerciaux comme la rue des Grandes-Arcades. Les maisons à pans de bois, reconnaissables à leurs encorbellements et leurs toitures pentues, témoignent du savoir-faire rhénan. Les règlements municipaux précis sur les hauteurs, datés du XVIe siècle, visaient à éviter les incendies en imposant des couvertures en tuiles et l’utilisation de pierre pour les rez-de-chaussée.`,
          `La présence de corps de métiers organisés en guildes a laissé des traces dans la toponymie : rue des Tonneliers, rue des Orfèvres, rue des Dentelles. Les archives évoquent des marchés tenus à ciel ouvert, régulés par la ville libre de Strasbourg. L’implantation des ponts – notamment le pont Saint-Martin – répondait à des stratégies commerciales et de défense. Cette organisation médiévale demeure lisible, même si les usages ont évolué.`
        ]
      },
      {
        heading: 'Rénovations du XIXe siècle et affirmation bourgeoise',
        paragraphs: [
          `À partir de 1870, l’intégration de Strasbourg à l’Empire allemand entraîne une modernisation ambitieuse. Les plans de l’architecte Jean-Geoffroy Conrath prévoient des percées et des alignements inspirés des modèles prussiens, tout en respectant les monuments emblématiques. La place Kléber est remodelée, les quais sont consolidés, et de nouveaux bâtiments administratifs prennent place. Les archives photographiques de l’époque montrent la cohabitation de maisons médiévales et d’immeubles éclectiques dotés de façades en grès.`,
          `Ces interventions se poursuivent après le retour à la France en 1918, avec un souci de préserver l’identité locale. Les campagnes de restauration de la cathédrale et de la Maison Kammerzell renforcent l’image patrimoniale de la Grande Île. Les relevés architecturaux témoignent d’une précision accrue dans la conservation des détails sculptés, des vitraux et des charpentes.`
        ]
      },
      {
        heading: 'Piétonnisation et nouvelles pratiques urbaines',
        paragraphs: [
          `Les années 1990 marquent une évolution majeure avec la piétonnisation de plusieurs rues et l’arrivée du tramway moderne, qui contourne la Grande Île. Les documents de l’Eurométropole montrent que cette décision a été précédée d’enquêtes approfondies sur les flux. L’objectif était de réduire la circulation automobile tout en favorisant les commerces et la qualité de vie des habitants. Les pavés ont été réemployés, les réseaux souterrains modernisés et les mobiliers urbains sélectionnés pour dialoguer avec le patrimoine.`,
          `Les études post-implantation soulignent une amélioration significative de la fréquentation piétonne, de la qualité de l’air et de l’animation culturelle. Les marchés de Noël, les festivals d’art et les parcours nocturnes mis en place par l’Office du tourisme se déploient désormais sur un espace apaisé. Les guides rappellent toutefois la nécessité de réguler ces événements pour préserver la vie quotidienne des résidents permanents.`
        ]
      },
      {
        heading: 'Transition écologique et gouvernance partagée',
        paragraphs: [
          `La Grande Île fait aujourd’hui l’objet de projets intégrant la transition écologique. Les plans de gestion des îlots de fraîcheur identifient les cours intérieures et les berges comme des lieux à valoriser pour lutter contre les îlots de chaleur. Les plantations d’essences locales, la désimperméabilisation de certaines places et l’introduction de fontaines temporaires participent à l’adaptation climatique. Les données recueillies par les services municipaux sont rendues accessibles aux habitants via des ateliers participatifs.`,
          `La gouvernance repose sur un dialogue entre la Ville, les associations patrimoniales, les commerçants et les institutions européennes voisines. Les chartes d’occupation du domaine public, les dispositifs de signalétique multilingue et les mesures d’accessibilité sont co-construits. Cette démarche renforce la cohésion autour d’un patrimoine partagé, mais vivant, constamment interprété à la lumière des enjeux contemporains.`
        ]
      }
    ],
    conclusion: `La Grande Île de Strasbourg apparaît comme un palimpseste où chaque époque a laissé sa marque. Les politiques récentes, attentives aux usages et à l’environnement, confirment la volonté d’inscrire la protection patrimoniale dans un projet de ville durable. L’équilibre entre visiteurs et habitants repose sur une gouvernance coopérative et sur une connaissance fine du tissu urbain. Cette étude rappelle que la valeur d’un centre ancien se nourrit de sa capacité à accueillir les transformations tout en conservant la mémoire des gestes qui l’ont façonné.`
  }
];

export default articles;