const archives = [
  {
    id: 'plan-paris-turgot-1739',
    title: 'Plan de Paris par Turgot, feuille relative au quartier Mouffetard',
    year: 1739,
    image: '/images/archive-plan-turgot.jpg',
    description: `Plan en perspective représentant le détail parcellaire du quartier Mouffetard avec ses cours et passages. Ce document, conservé à la Bibliothèque nationale de France, permet de suivre les alignements antérieurs aux interventions du XIXe siècle.`,
    source: 'Bibliothèque nationale de France',
    link: 'https://gallica.bnf.fr'
  },
  {
    id: 'photographies-marville-1868',
    title: 'Série de photographies de Charles Marville, rues de la rive gauche',
    year: 1868,
    image: '/images/archive-marville.jpg',
    description: `Lot de tirages albuminés documentant les rues en pente de la rive gauche, dont plusieurs vues de la rue Mouffetard. Les photographies témoignent des travaux de voirie engagés par le préfet Haussmann et des transformations du pavage.`,
    source: 'Archives de Paris',
    link: 'https://archives.paris.fr'
  },
  {
    id: 'carte-lyon-commission-alignement-1853',
    title: 'Carte de la Commission d’alignement, création de la rue impériale à Lyon',
    year: 1853,
    image: '/images/archive-lyon-alignement.jpg',
    description: `Carte officielle présentant les parcelles à exproprier pour la percée de la future rue de la République. Les annotations au crayon indiquent les indemnités et les nouvelles limites parcellaires.`,
    source: 'Archives municipales de Lyon',
    link: 'https://archives-lyon.fr'
  },
  {
    id: 'rapport-mission-quais-bordeaux-1996',
    title: 'Rapport de la mission des quais de Bordeaux',
    year: 1996,
    image: '/images/archive-quais-bordeaux.jpg',
    description: `Dossier d’étude sur la requalification des quais comprenant schémas, coupes topographiques et propositions de programmation. Il marque le point de départ des grandes transformations contemporaines.`,
    source: 'Archives Bordeaux Métropole',
    link: 'https://archives.bordeaux-metropole.fr'
  },
  {
    id: 'plan-strasbourg-relief-1725',
    title: 'Plan-relief de Strasbourg, Grande Île',
    year: 1725,
    image: '/images/archive-strasbourg-planrelief.jpg',
    description: `Vue en relief réalisée pour le ministère de la Guerre français. Le document reproduit le tissu urbain avec précision, offrant une lecture des toitures, des fortifications et des ponts de la Grande Île.`,
    source: 'Musée des Plans-Reliefs',
    link: 'https://www.museedesplansreliefs.culture.fr'
  }
];

export default archives;