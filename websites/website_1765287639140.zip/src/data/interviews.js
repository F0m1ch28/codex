const interviews = [
  {
    id: 'entretien-elisabeth-caron',
    title: 'Regards croisés avec Élisabeth Caron sur la mémoire des rues parisiennes',
    role: 'Historienne du paysage urbain, Université Paris 1',
    image: '/images/interview-elisabeth-caron.jpg',
    date: '20 mars 2024',
    introduction: `Élisabeth Caron étudie les transformations des rues parisiennes depuis plus de vingt ans. Son travail met en relation archives textuelles, iconographiques et récits d’habitants. L’entretien synthétisé ici explore sa méthode, l’usage de l’histoire orale et la manière dont les politiques publiques s’emparent de ces connaissances.`,
    highlights: [
      {
        theme: 'Construire un corpus numérique des rues',
        description: `L’historienne souligne l’importance de croiser cadastres, plans d’alignement, statistiques de population et fonds photographiques. Son équipe a constitué une base de données géoréférencée qui permet de suivre la morphologie des rues sur plusieurs siècles. Cette approche met en évidence des continuités souvent invisibles, comme la permanence des réseaux d’eau et des axes de circulation secondaires.`
      },
      {
        theme: 'Recueillir la mémoire des habitants',
        description: `Élisabeth Caron insiste sur la dimension sensible des rues. Des ateliers sont organisés avec les habitants pour cartographier les usages quotidiens, les rythmes de vie et les perceptions sonores. Ces matériaux complètent les archives et permettent d’éclairer les décisions urbanistiques, notamment dans les secteurs soumis aux tensions touristiques.`
      },
      {
        theme: 'Dialoguer avec les urbanistes',
        description: `Selon la chercheuse, la collaboration avec les urbanistes se concrétise par des ateliers de restitution et des publications communes. Les cartes historiques servent de support aux scénarios de requalification. L’objectif est de faire émerger des stratégies respectant la trame ancienne tout en répondant aux besoins contemporains.`
      }
    ],
    conclusion: `Pour Élisabeth Caron, la connaissance des rues suppose un dialogue continu entre disciplines et acteurs locaux. Les archives et la mémoire des habitants agissent comme des ressources partagées, capables d’orienter les projets urbains vers une plus grande cohérence patrimoniale.`
  },
  {
    id: 'entretien-mathieu-leroy',
    title: 'Mathieu Leroy, urbaniste, sur l’adaptation climatique des centres anciens',
    role: 'Urbaniste, agence Territoires en Marche',
    image: '/images/interview-mathieu-leroy.jpg',
    date: '7 février 2024',
    introduction: `Mathieu Leroy accompagne plusieurs collectivités françaises dans la mise en œuvre d’actions climatiques au sein des centres historiques. Il analyse les interactions entre matériaux, végétalisation, gestion de l’eau et confort d’usage.`,
    highlights: [
      {
        theme: 'Diagnostic des vulnérabilités climatiques',
        description: `L’urbaniste commence par cartographier les îlots de chaleur en croisant données thermiques, orientation des rues et flux de ventilation. Les centres anciens présentent des configurations variées : ruelles étroites, cours intérieures, places ouvertes. Chaque morphologie nécessite un traitement spécifique, depuis l’introduction de revêtements perméables jusqu’à l’installation de dispositifs d’ombre réversibles.`
      },
      {
        theme: 'Associer les habitants aux transformations',
        description: `Les projets s’appuient sur des ateliers participatifs. Les habitants partagent leurs observations sur les épisodes de chaleur, les zones de stagnation de l’eau et les usages saisonniers des rues. Ces contributions orientent les priorités, comme la création de fontaines temporaires ou la plantation d’essences locales adaptées.`
      },
      {
        theme: 'Articuler patrimoine et innovation',
        description: `Mathieu Leroy souligne que la transition climatique ne s’oppose pas à la conservation patrimoniale. Des matériaux traditionnels peuvent être associés à des solutions contemporaines. L’urbaniste cite par exemple l’usage de badigeons réfléchissants sur des façades historiques, développés en concertation avec les Architectes des Bâtiments de France.`
      }
    ],
    conclusion: `Les centres anciens deviennent des laboratoires de la transition environnementale. La méthode de Mathieu Leroy met en avant la concertation, l’observation fine du bâti et l’expérimentation réversible, autant d’éléments nécessaires pour adapter les rues sans renoncer à leur héritage.`
  },
  {
    id: 'entretien-nadia-schwartz',
    title: 'Nadia Schwartz éclaire les archives cartographiques de Strasbourg',
    role: 'Conservatrice aux Archives de Strasbourg',
    image: '/images/interview-nadia-schwartz.jpg',
    date: '12 janvier 2024',
    introduction: `Conservatrice aux Archives de Strasbourg, Nadia Schwartz coordonne la numérisation des plans et vues de la ville. Cette interview présente la chaîne de traitement des documents, les enjeux de diffusion et la manière dont ces ressources nourrissent les recherches urbaines.`,
    highlights: [
      {
        theme: 'Priorités de numérisation',
        description: `La conservatrice explique que la priorité va aux documents menacés par l’usure : calques d’urbanisme, plans aquarellés, vues panoramiques. Les opérations de restauration s’effectuent avant la numérisation à très haute résolution. Les métadonnées décrivent les auteurs, les matériaux et les échelles, facilitant les recherches croisées.`
      },
      {
        theme: 'Diffusion et médiation',
        description: `Les Archives ont créé un portail en ligne permettant de consulter les plans géoréférencés. Des parcours thématiques invitent à comparer différentes périodes. Des ateliers pédagogiques sont organisés avec des écoles d’architecture pour sensibiliser aux enjeux de conservation et d’interprétation.`
      },
      {
        theme: 'Collaboration avec les chercheurs',
        description: `Nadia Schwartz insiste sur la co-construction de projets avec les universités. Les chercheurs apportent leurs analyses, qui enrichissent les notices et les expositions. Cette dynamique permet d’actualiser en permanence la connaissance du territoire et d’alimenter les politiques publiques.`
      }
    ],
    conclusion: `Pour les Archives de Strasbourg, la diffusion des cartes et plans ne constitue pas seulement une sauvegarde. Elle nourrit l’intelligence collective de la ville en mettant à disposition des sources précises et accessibles, indispensables aux débats sur l’avenir des rues et des quartiers.`
  }
];

export default interviews;