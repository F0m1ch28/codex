import { useEffect } from 'react';

const usePageMetadata = ({ title, description }) => {
  useEffect(() => {
    if (title) {
      document.title = `${title} | Historic Streets of France Review`;
    } else {
      document.title = 'Historic Streets of France Review';
    }

    if (description) {
      let descriptionTag = document.querySelector('meta[name="description"]');
      if (!descriptionTag) {
        descriptionTag = document.createElement('meta');
        descriptionTag.setAttribute('name', 'description');
        document.head.appendChild(descriptionTag);
      }
      descriptionTag.setAttribute('content', description);
    }
  }, [title, description]);
};

export default usePageMetadata;