import React, { useState } from 'react';
import styles from './ContactPage.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const ContactPage = () => {
  usePageMetadata({
    title: 'Contact',
    description:
      'Contactez la rédaction de Historic Streets of France Review pour toute demande professionnelle relative au patrimoine urbain et aux recherches publiées.'
  });

  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name.trim() || !formData.email.includes('@') || formData.message.trim().length < 10) {
      setStatus({ type: 'error', message: 'Merci de vérifier les informations fournies.' });
      return;
    }
    setStatus({ type: 'success', message: 'Votre message a été transmis à la rédaction. Une réponse suivra dans les meilleurs délais.' });
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Contact</h1>
        <p>
          Cette page est destinée aux demandes liées aux recherches urbaines, aux partenariats scientifiques et aux renseignements éditoriaux. Merci de
          préciser l’objet de votre message.
        </p>
      </header>

      <div className={styles.grid}>
        <section className={styles.info}>
          <h2>Coordonnées</h2>
          <p>Email : <a href="mailto:redaction@historicstreetsfrance.review">redaction@historicstreetsfrance.review</a></p>
          <p>Adresse : Historic Streets of France Review, BP 101, 75001 Paris, France</p>
          <p>Aucune coordination téléphonique n’est assurée. Les demandes sont traitées par courrier électronique.</p>
        </section>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <div className={styles.formGroup}>
            <label htmlFor="name">Nom et prénom</label>
            <input id="name" name="name" value={formData.name} onChange={handleChange} required />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="email">Adresse électronique professionnelle</label>
            <input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
          </div>

          <div className={styles.formGroup}>
            <label htmlFor="message">Message (détail de la demande)</label>
            <textarea id="message" name="message" rows="6" value={formData.message} onChange={handleChange} required />
          </div>

          <button type="submit">Envoyer</button>
          {status && <p className={status.type === 'error' ? styles.error : styles.success}>{status.message}</p>}
        </form>
      </div>
    </div>
  );
};

export default ContactPage;