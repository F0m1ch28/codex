import React from 'react';
import styles from './LegalPage.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const PrivacyPolicyPage = () => {
  usePageMetadata({
    title: 'Politique de confidentialité',
    description:
      'Politique de confidentialité de Historic Streets of France Review concernant la gestion des données personnelles et des formulaires de contact.'
  });

  return (
    <div className={styles.page}>
      <h1>Politique de confidentialité</h1>
      <p>
        Historic Streets of France Review attache une importance particulière à la protection des données personnelles. Les informations collectées via le
        formulaire de contact servent exclusivement à répondre aux demandes professionnelles.
      </p>
      <h2>Données collectées</h2>
      <p>
        Les données suivantes peuvent être recueillies : nom, adresse électronique et contenu du message. Aucune donnée n’est transmise à des tiers à des fins
        commerciales.
      </p>
      <h2>Utilisation</h2>
      <p>
        Les données sont utilisées pour analyser les demandes, y répondre et assurer un suivi. Elles peuvent également être exploitées pour des statistiques
        internes anonymisées.
      </p>
      <h2>Conservation</h2>
      <p>
        Les messages sont conservés pendant une durée maximale de douze mois, sauf obligation légale contraire. Au-delà, ils sont supprimés ou anonymisés.
      </p>
      <h2>Droits</h2>
      <p>
        Conformément à la réglementation européenne, toute personne dispose d’un droit d’accès, de rectification, d’opposition et de suppression des données la
        concernant. Les demandes peuvent être adressées à redaction@historicstreetsfrance.review.
      </p>
    </div>
  );
};

export default PrivacyPolicyPage;