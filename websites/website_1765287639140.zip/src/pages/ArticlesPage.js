import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './ArticlesPage.module.css';
import articles from '../data/articles';
import usePageMetadata from '../hooks/usePageMetadata';

const ArticlesPage = () => {
  usePageMetadata({
    title: 'Articles',
    description:
      'Accédez à l’ensemble des articles de Historic Streets of France Review, dédiés aux rues historiques, aux architectures et aux transformations sociales.'
  });

  const categories = useMemo(() => ['Toutes', ...new Set(articles.map((article) => article.category))], []);
  const [activeCategory, setActiveCategory] = useState('Toutes');

  const filteredArticles =
    activeCategory === 'Toutes' ? articles : articles.filter((article) => article.category === activeCategory);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Articles</h1>
        <p>
          L’ensemble des études publiées, classées par villes et par thématiques. Chaque article propose un corpus de sources, une analyse morphologique et
          une synthèse des politiques urbaines.
        </p>
      </header>

      <div className={styles.filters}>
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            className={`${styles.filterButton} ${activeCategory === category ? styles.active : ''}`}
            onClick={() => setActiveCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>

      <div className={styles.grid}>
        {filteredArticles.map((article) => (
          <article key={article.id} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={article.image} alt={article.title} />
            </div>
            <div className={styles.cardContent}>
              <span className={styles.tag}>{article.tag}</span>
              <h2>{article.title}</h2>
              <p>{article.introduction}</p>
              <div className={styles.meta}>
                <span>{article.date}</span>
                <span>{article.readingTime}</span>
              </div>
              <Link to={`/article/${article.id}`} className={styles.link}>
                Consulter l’article
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default ArticlesPage;