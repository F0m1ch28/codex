import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './HomePage.module.css';
import articles from '../data/articles';
import interviews from '../data/interviews';
import archives from '../data/archives';
import usePageMetadata from '../hooks/usePageMetadata';

const HomePage = () => {
  usePageMetadata({
    title: 'Accueil',
    description:
      'Historic Streets of France Review explore le patrimoine urbain français, l’histoire des rues et les mutations architecturales des centres anciens.'
  });

  const featuredArticle = articles[0];
  const latestArticles = articles.slice(1, 5);

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState(null);

  const statsTargets = useMemo(
    () => [
      { label: 'Années d’archives étudiées', value: 820 },
      { label: 'Rues documentées', value: 128 },
      { label: 'Cartes numérisées', value: 62 },
      { label: 'Entretiens menés', value: 37 }
    ],
    []
  );

  const [statValues, setStatValues] = useState(statsTargets.map(() => 0));

  useEffect(() => {
    const intervals = statsTargets.map((stat, index) => {
      let start = 0;
      const increment = Math.ceil(stat.value / 60);
      return setInterval(() => {
        start += increment;
        if (start >= stat.value) {
          start = stat.value;
          clearInterval(intervals[index]);
        }
        setStatValues((prev) => {
          const updated = [...prev];
          updated[index] = start;
          return updated;
        });
      }, 35);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsTargets]);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      setNewsletterStatus({ type: 'error', message: 'Veuillez saisir une adresse électronique valide.' });
      return;
    }
    setNewsletterStatus({ type: 'success', message: 'Merci. Une confirmation sera envoyée prochainement.' });
    setNewsletterEmail('');
  };

  const [activeFilter, setActiveFilter] = useState('Toutes');
  const dossiers = [
    {
      id: 'dossier-paris',
      title: 'Topographie sensible de la rue Mouffetard',
      city: 'Paris',
      image: '/images/dossier-paris.jpg',
      description: `Cartographie des pentes, inventaire des façades et recueils d’archives orales pour analyser la vie quotidienne le long de la rue Mouffetard.`
    },
    {
      id: 'dossier-lyon',
      title: 'Les arcades de la presqu’île lyonnaise',
      city: 'Lyon',
      image: '/images/dossier-lyon.jpg',
      description: `Étude comparative des passages couverts, de leur programmation et de leurs transformations depuis la percée de la rue de la République.`
    },
    {
      id: 'dossier-marseille',
      title: 'Chroniques des escaliers du Panier',
      city: 'Marseille',
      image: '/images/dossier-marseille.jpg',
      description: `Analyse des escaliers, de la gestion des pentes et des matériaux utilisés pour relier le port aux hauteurs du Panier.`
    },
    {
      id: 'dossier-bordeaux',
      title: 'Ligne de rive bordelaise',
      city: 'Bordeaux',
      image: '/images/dossier-bordeaux.jpg',
      description: `Suivi des transformations des quais, des plantations et des dispositifs hydrauliques qui accompagnent la requalification des berges.`
    },
    {
      id: 'dossier-strasbourg',
      title: 'Hybridations de la Grande Île',
      city: 'Strasbourg',
      image: '/images/dossier-strasbourg.jpg',
      description: `Inventaire des maisons à colombages, relevés de cours intérieures et étude des parcours piétons autour de la cathédrale.`
    }
  ];

  const filteredDossiers = dossiers.filter((dossier) => activeFilter === 'Toutes' || dossier.city === activeFilter);

  const faqItems = [
    {
      question: 'Comment les articles sont-ils élaborés ?',
      answer:
        'Chaque article s’appuie sur un corpus de sources constitué d’archives municipales, de plans historiques, d’enquêtes de terrain et d’entretiens. Les rédacteurs croisent systématiquement ces matériaux avant publication.'
    },
    {
      question: 'Quels territoires sont étudiés ?',
      answer:
        'La publication couvre l’ensemble des régions françaises. Les dossiers privilégient les rues et quartiers possédant un patrimoine urbain particulier, qu’il soit médiéval, haussmannien ou industriel.'
    },
    {
      question: 'Comment proposer un document d’archive ?',
      answer:
        'Les lecteurs peuvent contacter la rédaction via la page dédiée. Chaque proposition est examinée par l’équipe de documentation qui assure sa contextualisation et sa conservation numérique.'
    }
  ];

  const testimonials = [
    {
      text: 'Le recensement précis des archives municipales permet d’enrichir nos projets de restauration. Les synthèses publiées deviennent des supports de travail pour les architectes du patrimoine.',
      author: 'Rapport annuel de la Direction du Patrimoine de la Ville de Paris, 2023'
    },
    {
      text: 'Les analyses de Historic Streets of France Review facilitent la compréhension des transformations sociales et spatiales de la presqu’île lyonnaise.',
      author: 'Laboratoire LAURe, École nationale supérieure d’architecture de Lyon'
    },
    {
      text: 'La restitution cartographique du quartier du Panier constitue un outil précieux pour suivre l’évolution des usages publics.',
      author: 'Observatoire métropolitain de Marseille, note interne 2024'
    }
  ];

  const processSteps = [
    { title: 'Collecte des sources', description: 'Identification des archives textuelles, iconographiques et orales relatives aux rues étudiées.' },
    { title: 'Analyse morphologique', description: 'Études sur la trame parcellaire, les gabarits bâtis, les matériaux et les usages du sol.' },
    { title: 'Restitution cartographique', description: 'Production de cartes interactives et de schémas comparatifs pour éclairer les évolutions.' },
    { title: 'Publication et médiation', description: 'Rédaction d’articles, organisation de rencontres et diffusion des résultats auprès des acteurs locaux.' }
  ];

  const [openFaq, setOpenFaq] = useState(null);

  const toggleFaq = (index) => {
    setOpenFaq((prev) => (prev === index ? null : index));
  };

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <p className={styles.heroKicker}>Revue d’études urbaines</p>
          <h1 className={styles.heroTitle}>Historic Streets of France Review</h1>
          <p className={styles.heroSubtitle}>
            Une publication dédiée à l’exploration du patrimoine urbain et de l’évolution des rues françaises.
          </p>
          <div className={styles.heroActions}>
            <Link to="/articles" className={styles.heroButton}>
              Consulter les articles
            </Link>
            <Link to="/archives" className={styles.heroSecondary}>
              Explorer les archives
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className={styles.sectionHeader}>
          <h2>Repères chiffrés</h2>
          <p>Indicateurs issus des recherches menées depuis la création de la revue.</p>
        </div>
        <div className={styles.statsGrid}>
          {statsTargets.map((stat, index) => (
            <div key={stat.label} className={styles.statCard}>
              <span className={styles.statValue} aria-live="polite">
                {statValues[index]}
              </span>
              <span className={styles.statLabel}>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.featuredSection}>
        <div className={styles.sectionHeader}>
          <h2>Étude principale</h2>
          <p>Un dossier approfondi issu de recherches archivistiques et de relevés de terrain.</p>
        </div>
        {featuredArticle && (
          <article className={styles.featuredArticle}>
            <div className={styles.featuredImageWrapper}>
              <img src={featuredArticle.image} alt={featuredArticle.title} className={styles.featuredImage} />
            </div>
            <div className={styles.featuredContent}>
              <span className={styles.category}>{featuredArticle.tag}</span>
              <h3>{featuredArticle.title}</h3>
              <p className={styles.featuredSummary}>{featuredArticle.summary}</p>
              <div className={styles.featuredMeta}>
                <span>{featuredArticle.date}</span>
                <span>{featuredArticle.readingTime}</span>
              </div>
              <Link to={`/article/${featuredArticle.id}`} className={styles.readMore}>
                Lire l’article
              </Link>
            </div>
          </article>
        )}
      </section>

      <section className={styles.latestSection}>
        <div className={styles.sectionHeader}>
          <h2>Recherches récentes</h2>
          <p>Synthèses des dernières études publiées sur les rues et places françaises.</p>
        </div>
        <div className={styles.latestGrid}>
          {latestArticles.map((article) => (
            <article key={article.id} className={styles.latestCard}>
              <div className={styles.latestImageWrapper}>
                <img src={article.image} alt={article.title} />
              </div>
              <div className={styles.latestContent}>
                <span className={styles.tag}>{article.tag}</span>
                <h3>{article.title}</h3>
                <p>{article.introduction}</p>
                <div className={styles.latestMeta}>
                  <span>{article.date}</span>
                  <span>{article.readingTime}</span>
                </div>
                <Link to={`/article/${article.id}`} className={styles.latestLink}>
                  Lire
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.processSection}>
        <div className={styles.sectionHeader}>
          <h2>Méthodologie éditoriale</h2>
          <p>Les étapes qui jalonnent la préparation de chaque dossier.</p>
        </div>
        <div className={styles.processGrid}>
          {processSteps.map((step) => (
            <div key={step.title} className={styles.processCard}>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.expertSection}>
        <div className={styles.sectionHeader}>
          <h2>Paroles d’experts</h2>
          <p>Interviews de chercheurs, urbanistes et conservateurs impliqués dans l’étude des rues historiques.</p>
        </div>
        <div className={styles.expertContent}>
          <p>
            La rubrique interviews rassemble des synthèses d’entretiens menés avec des spécialistes du patrimoine urbain. Les discussions portent sur les
            méthodes de recherche, les politiques publiques et les observations de terrain.
          </p>
          <Link to="/interviews" className={styles.expertLink}>
            Découvrir les interviews
          </Link>
        </div>
      </section>

      <section className={styles.thematicSection}>
        <div className={styles.thematicContent}>
          <h2>Focus thématique : patrimoine haussmannien revisité</h2>
          <p>
            Les études consacrées à la rue de la République à Lyon offrent un regard situé sur les transformations haussmanniennes. Les archives
            d’expropriation, les plans d’alignement et les observations contemporaines permettent de mesurer les adaptations locales du modèle parisien.
            Retrouvez dans ce dossier l’évolution des façades, la piétonnisation et les politiques actuelles de valorisation.
          </p>
          <Link to="/article/traces-haussmanniennes-lyon" className={styles.thematicLink}>
            Lire l’analyse lyonnaise
          </Link>
        </div>
        <div className={styles.thematicImageWrapper}>
          <img src="/images/focus-haussmann.jpg" alt="Perspective de la rue de la République à Lyon" />
        </div>
      </section>

      <section className={styles.projectsSection}>
        <div className={styles.sectionHeader}>
          <h2>Dossiers thématiques</h2>
          <p>Cartographies et études de cas disponibles en consultation libre.</p>
        </div>
        <div className={styles.filterBar}>
          {['Toutes', 'Paris', 'Lyon', 'Marseille', 'Bordeaux', 'Strasbourg'].map((filter) => (
            <button
              key={filter}
              type="button"
              onClick={() => setActiveFilter(filter)}
              className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectsGrid}>
          {filteredDossiers.map((dossier) => (
            <article key={dossier.id} className={styles.projectCard}>
              <div className={styles.projectImageWrapper}>
                <img src={dossier.image} alt={dossier.title} />
              </div>
              <div className={styles.projectContent}>
                <span className={styles.projectCity}>{dossier.city}</span>
                <h3>{dossier.title}</h3>
                <p>{dossier.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.archiveSection}>
        <div className={styles.sectionHeader}>
          <h2>Depuis les archives</h2>
          <p>Documents numérisés offrant un regard direct sur les rues étudiées.</p>
        </div>
        <div className={styles.archiveHighlight}>
          <img src={archives[0].image} alt={archives[0].title} />
          <div>
            <h3>{archives[0].title}</h3>
            <p>{archives[0].description}</p>
            <Link to="/archives" className={styles.archiveLink}>
              Accéder aux archives
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.testimonialSection}>
        <div className={styles.sectionHeader}>
          <h2>Échos professionnels</h2>
          <p>Extraits de rapports et d’analyses qui mobilisent les travaux de la revue.</p>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((item, index) => (
            <blockquote key={index} className={styles.testimonialCard}>
              <p>“{item.text}”</p>
              <cite>{item.author}</cite>
            </blockquote>
          ))}
        </div>
      </section>

      <section className={styles.faqSection}>
        <div className={styles.sectionHeader}>
          <h2>Questions fréquentes</h2>
          <p>Informations pratiques concernant la consultation et la contribution aux travaux de la revue.</p>
        </div>
        <div className={styles.faqList}>
          {faqItems.map((item, index) => (
            <div key={item.question} className={`${styles.faqItem} ${openFaq === index ? styles.faqOpen : ''}`}>
              <button type="button" className={styles.faqButton} onClick={() => toggleFaq(index)} aria-expanded={openFaq === index}>
                <span>{item.question}</span>
                <span aria-hidden="true">{openFaq === index ? '−' : '+'}</span>
              </button>
              <div className={styles.faqContent}>
                <p>{item.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.newsletterSection}>
        <div className={styles.sectionHeader}>
          <h2>Restez informé</h2>
          <p>Recevez une notification pour chaque nouvelle publication ou interview.</p>
        </div>
        <form className={styles.newsletterForm} onSubmit={handleNewsletterSubmit}>
          <label htmlFor="newsletter-email" className="sr-only">
            Adresse électronique
          </label>
          <input
            id="newsletter-email"
            type="email"
            value={newsletterEmail}
            onChange={(event) => setNewsletterEmail(event.target.value)}
            placeholder="votre-adresse@email.fr"
            aria-label="Adresse électronique"
          />
          <button type="submit">S’abonner</button>
        </form>
        {newsletterStatus && (
          <p className={newsletterStatus.type === 'error' ? styles.newsletterError : styles.newsletterSuccess}>{newsletterStatus.message}</p>
        )}
        <p className={styles.newsletterNote}>
          Aucun usage commercial. Respect de la vie privée garanti. Consultez la <Link to="/politique-de-confidentialite">politique de confidentialité</Link>.
        </p>
      </section>

      <section className={styles.teamSection}>
        <div className={styles.sectionHeader}>
          <h2>Équipe éditoriale</h2>
          <p>Profils des responsables de publication et des coordinateurs de dossiers.</p>
        </div>
        <div className={styles.teamGrid}>
          <article className={styles.teamCard}>
            <img src="/images/team-anne-dupont.jpg" alt="Portrait d’Anne Dupont, rédactrice en chef" />
            <h3>Anne Dupont</h3>
            <p>Rédactrice en chef, spécialiste des archives urbaines parisiennes et coordinatrice des dossiers méthodologiques.</p>
          </article>
          <article className={styles.teamCard}>
            <img src="/images/team-rachid-benyahia.jpg" alt="Portrait de Rachid Benyahia, chargé de cartographie" />
            <h3>Rachid Benyahia</h3>
            <p>Chargé de cartographie historique, responsable des restitutions numériques et du suivi des bases de données géolocalisées.</p>
          </article>
          <article className={styles.teamCard}>
            <img src="/images/team-helene-schmidt.jpg" alt="Portrait d’Hélène Schmidt, urbaniste" />
            <h3>Hélène Schmidt</h3>
            <p>Urbaniste et experte en mobilités douces, assure la liaison entre études de terrain et analyses des politiques publiques.</p>
          </article>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Consulter la cartographie des rues étudiées</h2>
          <p>
            Accédez aux cartes interactives, aux plans historiques et aux schémas comparatifs compilés par l’équipe. Les documents sont régulièrement mis à jour.
          </p>
          <Link to="/archives" className={styles.ctaButton}>
            Accéder aux cartes
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;