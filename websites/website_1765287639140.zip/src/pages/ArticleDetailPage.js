import React from 'react';
import { useParams, Link } from 'react-router-dom';
import styles from './ArticleDetailPage.module.css';
import articles from '../data/articles';
import usePageMetadata from '../hooks/usePageMetadata';

const ArticleDetailPage = () => {
  const { articleId } = useParams();
  const article = articles.find((item) => item.id === articleId);

  usePageMetadata({
    title: article ? article.title : 'Article',
    description: article ? article.summary : 'Analyse des rues françaises par Historic Streets of France Review.'
  });

  if (!article) {
    return (
      <div className={styles.page}>
        <div className={styles.notFound}>
          <h1>Article introuvable</h1>
          <p>Le contenu recherché n’est plus disponible ou l’URL est incorrecte.</p>
          <Link to="/articles" className={styles.backLink}>
            Retour aux articles
          </Link>
        </div>
      </div>
    );
  }

  return (
    <article className={styles.page}>
      <header className={styles.header}>
        <span className={styles.tag}>{article.tag}</span>
        <h1>{article.title}</h1>
        {article.subtitle && <p className={styles.subtitle}>{article.subtitle}</p>}
        <div className={styles.meta}>
          <span>{article.category}</span>
          <span>{article.date}</span>
          <span>{article.readingTime}</span>
        </div>
        <div className={styles.heroImageWrapper}>
          <img src={article.image} alt={article.title} />
        </div>
      </header>

      <section className={styles.content}>
        <p className={styles.introduction}>{article.introduction}</p>
        {article.sections.map((section) => (
          <section key={section.heading} className={styles.sectionBlock}>
            <h2>{section.heading}</h2>
            {section.paragraphs.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </section>
        ))}
        <section className={styles.sectionBlock}>
          <h2>Conclusion</h2>
          <p>{article.conclusion}</p>
        </section>
      </section>

      <footer className={styles.footer}>
        <Link to="/articles" className={styles.backLink}>
          Retour à la liste des articles
        </Link>
      </footer>
    </article>
  );
};

export default ArticleDetailPage;