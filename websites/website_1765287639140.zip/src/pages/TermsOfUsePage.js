import React from 'react';
import styles from './LegalPage.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const TermsOfUsePage = () => {
  usePageMetadata({
    title: 'Conditions d’utilisation',
    description:
      'Conditions d’utilisation de Historic Streets of France Review, précisant les règles de consultation et de reproduction des contenus.'
  });

  return (
    <div className={styles.page}>
      <h1>Conditions d’utilisation</h1>
      <h2>Objet</h2>
      <p>
        Les présentes conditions d’utilisation régissent l’accès au site Historic Streets of France Review et l’usage des contenus publiés. Toute consultation
        implique l’acceptation de ces conditions.
      </p>
      <h2>Propriété intellectuelle</h2>
      <p>
        Les textes, images et ressources mis en ligne sont protégés par la législation sur le droit d’auteur. Toute reproduction totale ou partielle nécessite
        une autorisation écrite de la rédaction.
      </p>
      <h2>Responsabilité</h2>
      <p>
        La rédaction veille à la fiabilité des informations diffusées. Toutefois, elle ne saurait être tenue pour responsable d’une mauvaise interprétation ou
        d’un usage inapproprié des contenus.
      </p>
      <h2>Liens externes</h2>
      <p>
        Le site peut contenir des liens vers d’autres ressources. Historic Streets of France Review n’est pas responsable des informations publiées sur ces
        sites tiers.
      </p>
    </div>
  );
};

export default TermsOfUsePage;