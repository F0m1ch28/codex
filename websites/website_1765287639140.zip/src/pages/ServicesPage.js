import React from 'react';
import styles from './ServicesPage.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const ServicesPage = () => {
  usePageMetadata({
    title: 'Approches éditoriales',
    description:
      'Présentation des approches éditoriales de Historic Streets of France Review : documentation, cartographie, études de terrain et médiation.'
  });

  const approaches = [
    {
      title: 'Documentation archivistique',
      description: 'Identification, numérisation et contextualisation de documents historiques, cartes, plans et photographies relatives aux rues étudiées.'
    },
    {
      title: 'Analyses morphologiques',
      description: 'Études sur la trame parcellaire, les alignements et les matériaux pour comprendre l’évolution architecturale et urbanistique.'
    },
    {
      title: 'Enquêtes de terrain',
      description: 'Relevés photographiques, observations et recueils de témoignages afin de saisir les usages contemporains des espaces publics.'
    },
    {
      title: 'Médiation et restitution',
      description: 'Organisation de conférences, ateliers et publications numériques facilitant l’accès aux connaissances produites.'
    }
  ];

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Approches éditoriales</h1>
        <p>
          Cette page décrit les principaux axes de travail de la revue. Ils structurent la production des dossiers et garantissent une analyse complète des
          rues françaises.
        </p>
      </header>

      <div className={styles.grid}>
        {approaches.map((approach) => (
          <article key={approach.title} className={styles.card}>
            <h2>{approach.title}</h2>
            <p>{approach.description}</p>
          </article>
        ))}
      </div>
    </div>
  );
};

export default ServicesPage;