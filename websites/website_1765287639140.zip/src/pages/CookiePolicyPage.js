import React from 'react';
import styles from './LegalPage.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const CookiePolicyPage = () => {
  usePageMetadata({
    title: 'Politique de cookies',
    description:
      'Politique de cookies de Historic Streets of France Review expliquant l’usage des traceurs strictement nécessaires et les options de paramétrage.'
  });

  return (
    <div className={styles.page}>
      <h1>Politique de cookies</h1>
      <p>
        Le site utilise des cookies strictement nécessaires à son fonctionnement et des cookies de mesure d’audience anonymisés. Aucun cookie publicitaire ni
        de profilage n’est déposé.
      </p>
      <h2>Cookies nécessaires</h2>
      <p>
        Ces cookies permettent d’assurer la sécurité des sessions et la mémorisation des préférences de navigation. Leur désactivation peut empêcher certaines
        fonctionnalités.
      </p>
      <h2>Mesure d’audience</h2>
      <p>
        Des indicateurs anonymes sont produits pour évaluer la fréquentation des pages. Les données recueillies ne permettent pas d’identifier les visiteurs.
      </p>
      <h2>Paramétrage</h2>
      <p>
        Le bandeau d’information à l’arrivée sur le site permet d’accepter ou de refuser les cookies non essentiels. Les préférences peuvent être modifiées à
        tout moment en nous contactant.
      </p>
    </div>
  );
};

export default CookiePolicyPage;