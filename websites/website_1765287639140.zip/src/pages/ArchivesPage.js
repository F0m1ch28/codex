import React from 'react';
import styles from './ArchivesPage.module.css';
import archives from '../data/archives';
import usePageMetadata from '../hooks/usePageMetadata';

const ArchivesPage = () => {
  usePageMetadata({
    title: 'Archives',
    description:
      'Sélection de documents numérisés, plans, photographies et rapports techniques relatifs aux rues historiques françaises.'
  });

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Archives</h1>
        <p>
          Documents numérisés, cartes et photographies offrant des sources primaires pour l’étude des rues françaises. Chaque notice indique l’origine,
          l’année et le contexte de conservation.
        </p>
      </header>

      <section className={styles.archiveGrid}>
        {archives.map((item) => (
          <article key={item.id} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={item.image} alt={item.title} />
            </div>
            <div className={styles.content}>
              <span className={styles.year}>{item.year}</span>
              <h2>{item.title}</h2>
              <p>{item.description}</p>
              <p className={styles.source}>Source : {item.source}</p>
              <a href={item.link} className={styles.link}>
                Consulter la notice
              </a>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
};

export default ArchivesPage;