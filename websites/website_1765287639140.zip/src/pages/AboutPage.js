import React from 'react';
import styles from './AboutPage.module.css';
import usePageMetadata from '../hooks/usePageMetadata';

const AboutPage = () => {
  usePageMetadata({
    title: 'À propos',
    description:
      'Présentation de Historic Streets of France Review, de sa mission éditoriale et de son équipe dédiée au patrimoine urbain français.'
  });

  const timeline = [
    {
      year: '2016',
      title: 'Création de la revue',
      description: `Lancement du projet par un collectif de chercheurs et d’urbanistes souhaitant mutualiser les études sur les rues historiques françaises.`
    },
    {
      year: '2018',
      title: 'Ouverture des archives numériques',
      description: `Mise en ligne du premier corpus cartographique et iconographique, en partenariat avec les archives municipales de Paris et Lyon.`
    },
    {
      year: '2020',
      title: 'Déploiement des enquêtes de terrain',
      description: `Organisation de campagnes de relevés et de rencontres avec les habitants pour enrichir les dossiers monographiques.`
    },
    {
      year: '2023',
      title: 'Plateforme collaborative',
      description: `Ouverture d’un espace contributif permettant aux collectivités, chercheurs et associations de proposer des documents et analyses.`
    }
  ];

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>À propos</h1>
        <p>
          Historic Streets of France Review est une publication indépendante qui étudie les rues, places et quartiers historiques français. La revue rassemble
          des contributions scientifiques, des relevés in situ et des analyses cartographiques pour éclairer les transformations urbaines.
        </p>
      </header>

      <section className={styles.mission}>
        <h2>Mission éditoriale</h2>
        <p>
          La revue documente les paysages urbains en croisant les sources historiques, les observations de terrain et les politiques publiques. Chaque dossier
          propose une lecture attentive des évolutions morphologiques, des sociabilités et des enjeux climatiques. L’objectif est de diffuser des connaissances
          fiables et contextualisées auprès des professionnels, des étudiants et des passionnés de patrimoine.
        </p>
      </section>

      <section className={styles.timelineSection}>
        <h2>Étapes clés</h2>
        <div className={styles.timeline}>
          {timeline.map((item) => (
            <div key={item.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.commitments}>
        <h2>Engagements</h2>
        <ul>
          <li>Respecter une démarche scientifique fondée sur la pluralité des sources et leur vérification.</li>
          <li>Associer les habitants, associations et institutions locales aux enquêtes de terrain.</li>
          <li>Diffuser les connaissances sous une forme accessible, sans céder aux approches sensationnalistes.</li>
          <li>Valoriser le patrimoine urbain dans une perspective écologique et inclusive.</li>
        </ul>
      </section>
    </div>
  );
};

export default AboutPage;