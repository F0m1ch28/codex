import React from 'react';
import styles from './InterviewsPage.module.css';
import interviews from '../data/interviews';
import usePageMetadata from '../hooks/usePageMetadata';

const InterviewsPage = () => {
  usePageMetadata({
    title: 'Interviews',
    description:
      'Interviews avec des historiens, urbanistes et conservateurs portant sur l’évolution des rues françaises et la conservation du patrimoine urbain.'
  });

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <h1>Interviews</h1>
        <p>
          Synthèses d’entretiens menés avec des spécialistes du patrimoine urbain. Ils partagent leurs méthodes, leurs analyses et leurs recommandations pour
          comprendre et préserver les rues historiques.
        </p>
      </header>

      <div className={styles.grid}>
        {interviews.map((interview) => (
          <article key={interview.id} className={styles.card}>
            <div className={styles.imageWrapper}>
              <img src={interview.image} alt={interview.title} />
            </div>
            <div className={styles.content}>
              <span className={styles.date}>{interview.date}</span>
              <h2>{interview.title}</h2>
              <p className={styles.role}>{interview.role}</p>
              <p>{interview.introduction}</p>
              <div className={styles.highlights}>
                {interview.highlights.map((highlight) => (
                  <section key={highlight.theme}>
                    <h3>{highlight.theme}</h3>
                    <p>{highlight.description}</p>
                  </section>
                ))}
              </div>
              <p className={styles.conclusion}>{interview.conclusion}</p>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default InterviewsPage;