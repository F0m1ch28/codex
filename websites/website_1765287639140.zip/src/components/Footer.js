import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={styles.grid}>
        <div>
          <h3 className={styles.title}>Historic Streets of France Review</h3>
          <p className={styles.text}>
            Publication dédiée à l’étude des rues historiques françaises, à l’urbanisme patrimonial et aux transformations sociales des espaces publics.
          </p>
        </div>
        <div>
          <h4 className={styles.heading}>Navigation</h4>
          <ul className={styles.list}>
            <li><Link to="/articles" className={styles.link}>Articles</Link></li>
            <li><Link to="/interviews" className={styles.link}>Interviews</Link></li>
            <li><Link to="/archives" className={styles.link}>Archives</Link></li>
            <li><Link to="/a-propos" className={styles.link}>À propos</Link></li>
            <li><Link to="/contact" className={styles.link}>Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.heading}>Références juridiques</h4>
          <ul className={styles.list}>
            <li><Link to="/politique-de-confidentialite" className={styles.link}>Politique de confidentialité</Link></li>
            <li><Link to="/conditions-d-utilisation" className={styles.link}>Conditions d’utilisation</Link></li>
            <li><Link to="/politique-de-cookies" className={styles.link}>Politique de cookies</Link></li>
          </ul>
        </div>
        <div>
          <h4 className={styles.heading}>Contact rédaction</h4>
          <address className={styles.address}>
            <a href="mailto:redaction@historicstreetsfrance.review" className={styles.link}>redaction@historicstreetsfrance.review</a>
            <span>Historic Streets of France Review</span>
            <span>BP 101</span>
            <span>75001 Paris, France</span>
          </address>
        </div>
      </div>
      <div className={styles.bottom}>
        © {currentYear} Historic Streets of France Review. Tous droits réservés.
      </div>
    </footer>
  );
};

export default Footer;