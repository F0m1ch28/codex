import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <div className={styles.branding}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu}>
            Historic Streets of France Review
          </NavLink>
        </div>
        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Navigation principale">
          <NavLink to="/" end className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Accueil
          </NavLink>
          <NavLink to="/articles" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Articles
          </NavLink>
          <NavLink to="/interviews" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Interviews
          </NavLink>
          <NavLink to="/archives" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Archives
          </NavLink>
          <NavLink to="/a-propos" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            À propos
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)} onClick={closeMenu}>
            Contact
          </NavLink>
        </nav>
        <div className={styles.actions}>
          <button className={styles.langButton} type="button" aria-label="Changer de langue (indisponible)">
            FR
          </button>
          <button className={styles.searchButton} type="button" aria-label="Ouvrir la recherche">
            <span aria-hidden="true">🔍</span>
          </button>
          <button
            className={styles.menuButton}
            type="button"
            onClick={toggleMenu}
            aria-expanded={menuOpen}
            aria-controls="navigation"
            aria-label="Basculer le menu"
          >
            <span className={styles.menuIcon} />
            <span className={styles.menuIcon} />
            <span className={styles.menuIcon} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;