import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('hsfr-cookie-consent');
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem('hsfr-cookie-consent', choice);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.message}>
        Ce site utilise des cookies strictement nécessaires à son fonctionnement et pour analyser l’audience de manière anonyme. En continuant votre navigation, vous acceptez leur utilisation.
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.buttonSecondary} onClick={() => handleChoice('refused')}>
          Refuser
        </button>
        <Link to="/politique-de-cookies" className={styles.buttonLink}>
          Personnaliser
        </Link>
        <button type="button" className={styles.buttonPrimary} onClick={() => handleChoice('accepted')}>
          Accepter
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;