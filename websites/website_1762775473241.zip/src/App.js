import React from 'react';
import { Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Blog from './pages/Blog';
import PipelineRenewal from './pages/blog/PipelineRenewal';
import RefineryCoordination from './pages/blog/RefineryCoordination';
import StorageTopologies from './pages/blog/StorageTopologies';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const App = () => {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col">
      <Header />
      <AnimatePresence mode="wait">
        <main className="flex-1" key={location.pathname}>
          <Routes location={location}>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/systems" element={<Services />} />
            <Route path="/services" element={<Navigate to="/systems" replace />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/pipeline-renewal" element={<PipelineRenewal />} />
            <Route path="/blog/refinery-coordination" element={<RefineryCoordination />} />
            <Route path="/blog/storage-topologies" element={<StorageTopologies />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookie-policy" element={<CookiePolicy />} />
          </Routes>
        </main>
      </AnimatePresence>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </div>
  );
};

export default App;