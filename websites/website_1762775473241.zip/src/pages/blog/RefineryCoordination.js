import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const RefineryCoordination = () => (
  <>
    <Helmet>
      <title>Refinery Coordination in Canada | Petro Stratix Feature</title>
      <meta name="description" content="Petro Stratix explores how Canadian refineries coordinate maintenance, supply, and community communication to maintain consistent operations." />
      <link rel="canonical" href="https://www.petrostratix.ca/blog/refinery-coordination" />
    </Helmet>
    <article className="pt-24 pb-20 bg-slate-950 min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <header>
          <p className="text-xs uppercase tracking-[0.3em] text-blue-400">Refinery Coordination</p>
          <h1 className="mt-4 text-4xl font-semibold text-white">Aligning Turnarounds and Supply at Canadian Refineries</h1>
          <p className="mt-3 text-sm text-slate-300">April 12, 2024 • Petro Stratix Editorial Desk</p>
        </header>

        <div className="mt-10 space-y-6 text-sm text-slate-200 leading-relaxed">
          <p>Refinery coordination in Canada involves synchronising maintenance, feedstock delivery, and community communication. Operators rely on detailed turnaround roadmaps that integrate labour availability, contractor scheduling, and spare parts logistics. These plans are shared with supply partners to ensure downstream terminals have clarity on product flow adjustments.</p>
          <p>Turnaround windows are increasingly co-ordinated across neighbouring facilities to minimize simultaneous downtime. Supply planners review regional demand, pipeline capacity, and storage inventory before approving schedules. This collaborative approach supports stability for retail and industrial customers across provinces.</p>
          <p>Feedstock planning now folds in diversified crude and condensate blends, especially as new production basins come online. Refinery labs test blends for compatibility with existing process units, ensuring catalytic performance and emissions control remain within regulatory bounds during adjustments.</p>
          <p>Maintenance crews deploy predictive analytics to anticipate component replacement before a scheduled shutdown. Vibration monitoring, infrared inspection, and process historian data identify emerging issues so crews can stage resources efficiently. This reduces unplanned downtime and maintains safe operating conditions.</p>
          <p>The coordination extends beyond the fence line. Municipal emergency services and provincial regulators receive regular briefings on turnaround activities. Open communication channels allow for rapid updates if schedules change, preventing misinformation and reinforcing trust within surrounding communities.</p>
          <p>Transparency is reinforced through curated public dashboards. These dashboards present high-level information on upcoming maintenance, emission reporting, and community initiatives. By sharing consistent data, refineries demonstrate their commitment to environmental stewardship and operational accountability.</p>
          <p>Workforce considerations are integral. Skilled trades programs collaborate with refineries to prepare apprentices and technicians for upcoming turnaround seasons. Training emphasizes safety, process familiarization, and collaboration with Indigenous contractors to reflect Canada’s diverse communities.</p>
          <p>
            <q className="italic text-slate-300">Coordinated turnarounds show that reliability is a shared responsibility, stretching from the control room to community halls.</q>
          </p>
          <p>Cross-border supply coordination remains vital. Refineries liaise with US partners to align product exchanges and manage pipeline reversals when necessary. This ensures Canadian markets receive steady supply even when local units undergo extended maintenance.</p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <motion.figure whileHover={{ y: -4 }} className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg shadow-slate-900/35">
            <img src="https://picsum.photos/800/600?random=51" alt="Visualization of refinery coordination timeline." className="w-full h-56 object-cover" />
            <figcaption className="p-4 text-xs text-slate-300">Figure 1. Timeline showing aligned turnaround milestones across neighbouring refineries.</figcaption>
          </motion.figure>
          <motion.figure whileHover={{ y: -4 }} className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg shadow-slate-900/35">
            <img src="https://picsum.photos/800/600?random=52" alt="Process diagram of refinery supply coordination." className="w-full h-56 object-cover" />
            <figcaption className="p-4 text-xs text-slate-300">Figure 2. Process diagram linking feedstock planning, maintenance crews, and community communication nodes.</figcaption>
          </motion.figure>
        </div>
      </div>
    </article>
  </>
);

export default RefineryCoordination;