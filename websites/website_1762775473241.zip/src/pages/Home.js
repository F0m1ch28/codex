import React, { useMemo, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion, useInView, animate } from 'framer-motion';
import { useRef } from 'react';

const statsData = [
  { label: 'Documented Assets', value: 287, suffix: '+', description: 'Pipelines, refineries, terminals, and storage hubs under continuous review.' },
  { label: 'Field Notes Logged', value: 962, suffix: '', description: 'Verified observations pulled from public filings and site monitoring.' },
  { label: 'Regional Profiles', value: 39, suffix: '', description: 'Provincial and territorial snapshots tracking infrastructure evolution.' }
];

const energySignals = [
  {
    title: 'Transmission Flow',
    description: 'We capture directional flow patterns across major Canadian pipelines to illuminate upstream dispatch and downstream supply alignment.',
    insight: 'Weekly flow shifts are compared with regulatory filings and maintenance bulletins for context.'
  },
  {
    title: 'Refinery Cadence',
    description: 'Refinery outage profiles, throughput expectations, and crude blends are mapped to evaluate operational pacing.',
    insight: 'Updates are corroborated with provincial notice systems and independent monitoring feeds.'
  },
  {
    title: 'Storage Balance',
    description: 'Inventory levels at underground and above-ground storage facilities reveal seasonal readiness and contingency margins.',
    insight: 'Storage signals incorporate satellite-derived observations and commercial disclosures.'
  }
];

const infrastructureHighlights = [
  {
    title: 'Northern Gateway Corridor',
    body: 'A layered view of westbound crude capacity, environmental monitoring, and coastal terminal readiness. Petro Stratix tracks engineering updates, Indigenous consultations, and shipping protocols to document progress and alignment with regulatory frameworks.',
    image: 'https://picsum.photos/960/640?random=12',
    alt: 'Abstract rendering of a pipeline corridor with layered data overlays.'
  },
  {
    title: 'Prairie Processing Loop',
    body: 'An integrated loop of gas processing nodes, liquids fractionation, and collection hubs across the prairie provinces. Our coverage captures seasonal demand swings, maintenance scheduling, and cross-border interconnections in neutral technical terms.',
    image: 'https://picsum.photos/960/640?random=13',
    alt: 'Conceptual map of processing facilities connected by flow lines.'
  },
  {
    title: 'Atlantic Terminal Constellation',
    body: 'Multiple marine terminals along the Atlantic coast are profiled for inbound shipments, storage rotation, and product blending facilities. Petro Stratix aggregates open data with port authority releases to sustain clarity on coastal energy logistics.',
    image: 'https://picsum.photos/960/640?random=14',
    alt: 'Illustration showing coastal energy terminals and shipping routes.'
  },
  {
    title: 'Arctic Resilience Study',
    body: 'We are cataloguing modular storage and micro-refinery concepts being piloted in northern communities. The program emphasizes reliability, cold-weather engineering, and collaboration with local leadership to match fuel stewardship requirements.',
    image: 'https://picsum.photos/960/640?random=15',
    alt: 'Visualization of modular energy infrastructure suitable for Arctic conditions.'
  }
];

const processingModules = [
  {
    title: 'Upgrading and Conversion',
    detail: 'Canadian upgrading facilities transform bitumen into synthetic crude while balancing emission controls and hydrogen availability. Petro Stratix documents process improvements, heat recovery units, and catalyst cycles that keep facilities responsive to market signals.'
  },
  {
    title: 'Fractionation Intelligence',
    detail: 'Fractionation towers separating natural gas liquids are tracked for throughput consistency, refrigerant performance, and downstream blending. Our reporting references regulator filings, operator briefings, and academic studies without promotional framing.'
  },
  {
    title: 'Strategic Storage Integration',
    detail: 'Salt caverns, tank farms, and rail-connected depots are mapped as part of an integrated resilience narrative. We assess security measures, inspection intervals, and emergency response coordination in an impartial, technically grounded format.'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Source Validation',
    copy: 'Each field report begins with source triangulation across regulatory filings, engineering documentation, and local consultations. We maintain an audit trail that confirms the origin and context of every data point.'
  },
  {
    step: '02',
    title: 'Geospatial Layering',
    copy: 'Our analysts overlay pipeline alignments, refinery footprints, and storage siting with environmental and community data sets. The layering process highlights spatial dependencies and informs targeted follow-up queries.'
  },
  {
    step: '03',
    title: 'Scenario Assessment',
    copy: 'We model routine operations, scheduled maintenance, and unforeseen disruptions using neutral, outcome-based scenarios. This approach allows stakeholders to appreciate potential pressure points without commentary or advocacy.'
  },
  {
    step: '04',
    title: 'Editorial Review',
    copy: 'Before publication, each piece undergoes multi-stage editorial review focusing on technical accuracy, neutrality, and accessibility. Terminology is calibrated for an informed readership while maintaining clarity.'
  }
];

const testimonials = [
  {
    quote: 'Petro Stratix helped our team reconcile production forecasts with pipeline availability through grounded infrastructural analysis. Their editorial discipline kept the conversation focused on verifiable facts.',
    name: 'Mira Desjardins',
    title: 'Operations Planner, Western Canada'
  },
  {
    quote: 'The level of technical detail in Petro Stratix reports lets us cross-check regional maintenance schedules with municipal planning. Their measured tone makes it easy to integrate findings into our oversight documents.',
    name: 'Thomas Kendry',
    title: 'Provincial Energy Secretariat'
  },
  {
    quote: 'We value how Petro Stratix documents storage topologies with clear schematics and citation-rich commentary. It gives our academic team a reliable launch point for deeper studies.',
    name: 'Dr. Eveline Tran',
    title: 'Research Fellow, Energy Systems Lab'
  }
];

const teamProfiles = [
  {
    name: 'Lena Morin',
    role: 'Managing Editor',
    bio: 'Former infrastructure journalist with 15 years tracking Canadian pipelines, regulatory hearings, and environmental stewardship initiatives.',
    image: 'https://picsum.photos/320/320?random=21',
    alt: 'Portrait of Lena Morin'
  },
  {
    name: 'Rajesh Nayar',
    role: 'Systems Analyst',
    bio: 'Mechanical engineer focused on refinery optimisation and process safety benchmarking across Alberta and Ontario facilities.',
    image: 'https://picsum.photos/320/320?random=22',
    alt: 'Portrait of Rajesh Nayar'
  },
  {
    name: 'Claire Dumont',
    role: 'Data Cartographer',
    bio: 'Geospatial specialist mapping pipeline corridors, buffer zones, and emergency response linkages using open geodata.',
    image: 'https://picsum.photos/320/320?random=23',
    alt: 'Portrait of Claire Dumont'
  }
];

const faqItems = [
  {
    question: 'How does Petro Stratix choose topics for coverage?',
    answer: 'Topics are prioritized based on infrastructure significance, regulatory developments, and public data availability. We avoid commercial promotion and focus on assets that influence Canada’s broader energy systems.'
  },
  {
    question: 'What sources support Petro Stratix reporting?',
    answer: 'Reports draw from regulatory filings, public hearings, satellite imagery, academic publications, and community consultations. Each feature includes citations so readers can retrace the information pathway.'
  },
  {
    question: 'Can organisations submit clarification or updates?',
    answer: 'Yes. We maintain an open corrections and clarifications channel through our contact form. Submissions are reviewed by the editorial desk and noted in update logs where applicable.'
  },
  {
    question: 'Does Petro Stratix publish commercial forecasts?',
    answer: 'No. Petro Stratix prioritises descriptive analysis and scenario planning. We do not publish forecasts, marketing content, or promotional projections.'
  }
];

const blogPreview = [
  {
    title: 'Pipeline Renewal: Coordinating Modern Upgrades',
    link: '/blog/pipeline-renewal',
    date: 'May 2, 2024',
    description: 'Nine sections examining refurbishment strategy, regulatory pacing, and community coordination for Canadian pipeline renewal programs.'
  },
  {
    title: 'Refinery Coordination: Aligning Turnarounds and Supply',
    link: '/blog/refinery-coordination',
    date: 'April 12, 2024',
    description: 'A detailed look at refinery coordination, maintenance cycles, and supply balancing across provincial systems.'
  },
  {
    title: 'Storage Topologies: Designing Resilient Inventories',
    link: '/blog/storage-topologies',
    date: 'March 28, 2024',
    description: 'Exploring storage topology, cavern integrity, and scheduling frameworks that underpin reliable Canadian inventories.'
  }
];

const projectGallery = [
  {
    id: 1,
    category: 'Pipelines',
    title: 'Foothills Expansion Series',
    description: 'Tracking flow assurance retrofits and valve automation upgrades along the Foothills corridor.',
    image: 'https://picsum.photos/800/600?random=31',
    alt: 'Pipeline stretching across foothills at dusk.'
  },
  {
    id: 2,
    category: 'Refinery',
    title: 'Midland Turnaround Synchro',
    description: 'Documenting multi-operator coordination for a synchronized turnaround in Southern Alberta.',
    image: 'https://picsum.photos/800/600?random=32',
    alt: 'Refinery complex with process units and lights.'
  },
  {
    id: 3,
    category: 'Storage',
    title: 'Lakehead Cavern Mapping',
    description: 'Assessing salt cavern monitoring instrumentation and emergency readiness tests.',
    image: 'https://picsum.photos/800/600?random=33',
    alt: 'Storage facility with large tanks under cloudy sky.'
  },
  {
    id: 4,
    category: 'Pipelines',
    title: 'Maritime Spur Assessment',
    description: 'Reviewing stakeholder submissions on a proposed maritime feeder spur servicing coastal terminals.',
    image: 'https://picsum.photos/800/600?random=34',
    alt: 'Coastal pipeline infrastructure with ocean backdrop.'
  },
  {
    id: 5,
    category: 'Refinery',
    title: 'Hydrogen Integration Pilot',
    description: 'Analyzing early-stage blending of low-carbon hydrogen into existing refinery operations.',
    image: 'https://picsum.photos/800/600?random=35',
    alt: 'Illustration of hydrogen integration within refinery units.'
  },
  {
    id: 6,
    category: 'Storage',
    title: 'Prairie Tank Integrity Review',
    description: 'Evaluating tank inspection intervals, cathodic protection upgrades, and remote sensing deployments.',
    image: 'https://picsum.photos/800/600?random=36',
    alt: 'Aerial view of tank farm with sensors overlay.'
  }
];

const StatsCounter = ({ value, suffix, label, description }) => {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-100px' });
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (inView) {
      const controls = animate(0, value, {
        duration: 1.6,
        ease: 'easeOut',
        onUpdate: (v) => setDisplayValue(Math.round(v))
      });
      return () => controls.stop();
    }
  }, [inView, value]);

  return (
    <div ref={ref} className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-[0_20px_40px_-30px_rgba(37,99,235,0.8)] hover:border-blue-600 transition">
      <p className="text-5xl font-semibold text-white tracking-tight">{displayValue}{suffix}</p>
      <p className="mt-2 text-sm uppercase tracking-[0.18em] text-blue-400">{label}</p>
      <p className="mt-3 text-sm text-slate-300 leading-relaxed">{description}</p>
    </div>
  );
};

const Home = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'All') return projectGallery;
    if (activeCategory === 'Pipelines') return projectGallery.filter((item) => item.category === 'Pipelines');
    if (activeCategory === 'Refinery') return projectGallery.filter((item) => item.category === 'Refinery');
    if (activeCategory === 'Storage') return projectGallery.filter((item) => item.category === 'Storage');
    return projectGallery;
  }, [activeCategory]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Helmet>
        <title>Petro Stratix | Understanding Canada&apos;s Energy Systems</title>
        <meta name="description" content="Petro Stratix delivers impartial coverage of Canadian energy infrastructure, pipeline renewal, refinery coordination, and storage topology." />
        <link rel="canonical" href="https://www.petrostratix.ca/" />
        <meta name="keywords" content="Canadian energy infrastructure, refinery coordination, pipeline renewal, storage topology, industrial deployment observation" />
      </Helmet>
      <div className="pt-16">
        <section className="relative overflow-hidden bg-slate-950">
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Industrial energy infrastructure silhouetted at dawn."
            className="absolute inset-0 w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-900/90 to-slate-900"></div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-36">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="max-w-3xl"
            >
              <p className="text-sm uppercase tracking-[0.4em] text-blue-400 mb-6">Understanding Canada&apos;s Energy Systems</p>
              <h1 className="font-headline text-4xl sm:text-5xl lg:text-6xl font-semibold text-white leading-tight">
                Documentation for a balanced view of Canadian energy infrastructure.
              </h1>
              <p className="mt-6 text-lg text-slate-300 leading-relaxed">
                Petro Stratix is a Canadian editorial platform that examines pipelines, refineries, and storage assets through verifiable data and on-the-ground observation. Our journalists and analysts trace operational shifts, scenario planning, and community dialogues to help readers interpret how energy infrastructure is evolving.
              </p>
              <p className="mt-4 text-lg text-slate-300 leading-relaxed">
                We operate on a mobile-first publishing stack, enabling timely, accessible coverage for decision-makers, researchers, and community stakeholders. Each report we publish is supported by citations, geospatial context, and neutral commentary.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Link
                  to="/systems"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-blue-600 text-white font-semibold shadow-lg shadow-blue-900/50 hover:bg-blue-500 transition focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-slate-900"
                >
                  Explore Systems Coverage
                </Link>
                <Link
                  to="/blog"
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full border border-slate-600 text-slate-200 font-semibold hover:border-blue-400 hover:text-blue-300 transition"
                >
                  Latest Field Notes
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="relative -mt-12">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-6 md:grid-cols-3">
            {statsData.map((stat) => (
              <StatsCounter key={stat.label} {...stat} />
            ))}
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-4">
              <h2 className="text-3xl font-semibold text-white">Energy Signals We Monitor</h2>
              <p className="text-sm text-slate-400 max-w-xl">
                Our monitoring suite brings together pipeline telemetry, refinery maintenance notifications, and storage inventories, enabling cross-referenced insight across Canada.
              </p>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {energySignals.map((signal) => (
                <motion.div
                  key={signal.title}
                  whileHover={{ y: -6 }}
                  className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-900/40 transition"
                >
                  <p className="text-xs uppercase tracking-[0.3em] text-blue-400">Signal</p>
                  <h3 className="mt-3 text-xl font-semibold text-white">{signal.title}</h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">{signal.description}</p>
                  <p className="mt-4 text-sm text-slate-400 border-t border-slate-800 pt-4">{signal.insight}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24 bg-slate-950/60">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-4">
              <h2 className="text-3xl font-semibold text-white">Infrastructure Highlights</h2>
              <p className="text-sm text-slate-400 max-w-xl">
                Modular dossiers summarise the assets shaping Canada’s energy systems. Each highlight is refreshed as new documentation and field notes become available.
              </p>
            </div>
            <div className="mt-10 grid gap-6 lg:grid-cols-2">
              {infrastructureHighlights.map((item) => (
                <motion.article
                  key={item.title}
                  whileHover={{ y: -5 }}
                  className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg shadow-slate-900/35"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img src={item.image} alt={item.alt} className="h-full w-full object-cover transition-transform duration-500 hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-white">{item.title}</h3>
                    <p className="mt-3 text-sm text-slate-300 leading-relaxed">{item.body}</p>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col gap-4">
              <p className="text-sm uppercase tracking-[0.3em] text-blue-400">Processing & Storage Modules</p>
              <h2 className="text-3xl font-semibold text-white">Processing and Storage Under the Lens</h2>
              <p className="text-sm text-slate-400">
                Petro Stratix modular reports help readers interpret facility upgrades, inspection cycles, and integration between infrastructure segments.
              </p>
            </div>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {processingModules.map((module) => (
                <motion.div
                  key={module.title}
                  whileHover={{ y: -4 }}
                  className="bg-slate-900 rounded-3xl border border-slate-800 p-6 shadow-lg shadow-slate-900/30"
                >
                  <h3 className="text-lg font-semibold text-white">{module.title}</h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">{module.detail}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24 bg-gradient-to-b from-slate-950 via-slate-950 to-slate-900">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <p className="text-sm uppercase tracking-[0.3em] text-blue-400">Workflow</p>
                <h2 className="text-3xl font-semibold text-white">From field signal to published report</h2>
              </div>
              <p className="text-sm text-slate-400 max-w-xl">
                Our process integrates verification, mapping, scenario planning, and editorial review. Each stage has documented criteria so readers can trust the published outcome.
              </p>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-2">
              {processSteps.map((step) => (
                <motion.div
                  key={step.title}
                  whileHover={{ y: -6 }}
                  className="relative bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-900/40 overflow-hidden"
                >
                  <span className="absolute top-4 right-6 text-5xl font-bold text-slate-800">{step.step}</span>
                  <h3 className="text-xl font-semibold text-white">{step.title}</h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">{step.copy}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div>
                <p className="text-sm uppercase tracking-[0.3em] text-blue-400">Projects</p>
                <h2 className="text-3xl font-semibold text-white">Field Projects Under Review</h2>
              </div>
              <div className="flex flex-wrap gap-3">
                {['All', 'Pipelines', 'Refinery', 'Storage'].map((category) => (
                  <button
                    key={category}
                    onClick={() => setActiveCategory(category)}
                    className={`px-4 py-2 rounded-full text-sm font-medium border transition ${
                      activeCategory === category
                        ? 'border-blue-500 bg-blue-600 text-white'
                        : 'border-slate-700 text-slate-300 hover:border-blue-500 hover:text-blue-300'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-10 grid gap-6 lg:grid-cols-3">
              {filteredProjects.map((project) => (
                <motion.article
                  key={project.id}
                  layout
                  className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg shadow-slate-900/35"
                >
                  <div className="relative h-48">
                    <img src={project.image} alt={project.alt} className="h-full w-full object-cover" />
                    <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-slate-950/80 text-xs uppercase tracking-[0.3em] text-blue-300">
                      {project.category}
                    </span>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-white">{project.title}</h3>
                    <p className="mt-3 text-sm text-slate-300 leading-relaxed">{project.description}</p>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24 bg-slate-950/50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p className="text-sm uppercase tracking-[0.3em] text-blue-400">Testimonials</p>
            <h2 className="mt-4 text-3xl font-semibold text-white">Reader perspectives on Petro Stratix</h2>
            <div className="relative mt-10">
              <motion.div
                key={testimonialIndex}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-lg shadow-slate-900/40"
              >
                <p className="text-lg text-slate-200 leading-relaxed italic">&ldquo;{testimonials[testimonialIndex].quote}&rdquo;</p>
                <div className="mt-6 text-sm text-slate-400">
                  <p className="font-semibold text-slate-200">{testimonials[testimonialIndex].name}</p>
                  <p>{testimonials[testimonialIndex].title}</p>
                </div>
              </motion.div>
              <div className="flex justify-center gap-2 mt-6">
                {testimonials.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setTestimonialIndex(idx)}
                    className={`h-2 w-6 rounded-full transition ${idx === testimonialIndex ? 'bg-blue-500' : 'bg-slate-600 hover:bg-blue-400'}`}
                    aria-label={`Show testimonial ${idx + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-8 lg:grid-cols-3">
              {teamProfiles.map((member) => (
                <motion.article
                  key={member.name}
                  whileHover={{ y: -6 }}
                  className="group bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg shadow-slate-900/35"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img src={member.image} alt={member.alt} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4">
                      <p className="text-lg font-semibold text-white">{member.name}</p>
                      <p className="text-xs uppercase tracking-[0.3em] text-blue-400">{member.role}</p>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-sm text-slate-300 leading-relaxed">{member.bio}</p>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24 bg-slate-950/60">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-6 md:grid-cols-2">
              {faqItems.map((item, idx) => (
                <details
                  key={item.question}
                  className="group bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-900/30"
                >
                  <summary className="flex items-center justify-between cursor-pointer">
                    <span className="text-base font-semibold text-white">{item.question}</span>
                    <span className="text-blue-400 text-xl group-open:rotate-45 transition-transform">+</span>
                  </summary>
                  <p className="mt-4 text-sm text-slate-300 leading-relaxed">{item.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
              <div>
                <p className="text-sm uppercase tracking-[0.3em] text-blue-400">Recommended Reading</p>
                <h2 className="text-3xl font-semibold text-white">Latest insights from the Petro Stratix blog</h2>
              </div>
              <Link to="/blog" className="text-sm font-semibold text-blue-400 hover:text-blue-300 uppercase tracking-[0.2em]">View all posts</Link>
            </div>
            <div className="mt-10 grid gap-6 lg:grid-cols-3">
              {blogPreview.map((post) => (
                <motion.article
                  key={post.title}
                  whileHover={{ y: -6 }}
                  className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-900/35"
                >
                  <p className="text-xs uppercase tracking-[0.3em] text-slate-500">{post.date}</p>
                  <h3 className="mt-3 text-lg font-semibold text-white">{post.title}</h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">{post.description}</p>
                  <Link to={post.link} className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-blue-400 hover:text-blue-300">
                    Read more
                    <svg className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 12h13.5M12 5.25L18.75 12 12 18.75" />
                    </svg>
                  </Link>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-24 bg-gradient-to-r from-blue-600 to-blue-500">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-semibold text-white">Subscribe to Petro Stratix dispatches</h2>
            <p className="mt-4 text-slate-100 text-sm leading-relaxed">
              Receive quarterly dispatches covering pipeline renewal, refinery coordination tactics, and storage topology research. We send concise digests without promotional messaging.
            </p>
            <form className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <label htmlFor="newsletter-email" className="sr-only">Email address</label>
              <input
                id="newsletter-email"
                type="email"
                placeholder="Email address"
                required
                className="w-full sm:w-80 px-4 py-3 rounded-full border border-white/30 bg-white/10 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-slate-900 text-white font-semibold shadow-lg shadow-slate-900/40 hover:bg-slate-800 transition focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-blue-600 focus:ring-white"
              >
                Join Dispatch List
              </button>
            </form>
          </div>
        </section>

        <section className="py-12">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-sm text-slate-500 leading-relaxed">
            <p>
              Disclaimer: Petro Stratix provides descriptive analysis of energy infrastructure in Canada. The platform does not offer commercial advice, trading recommendations, or promotional forecasts. Readers should consult official regulatory filings and stakeholders for operational decisions.
            </p>
          </div>
        </section>
      </div>
    </>
  );
};

export default Home;