import React from 'react';
import { Helmet } from 'react-helmet';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Petro Stratix</title>
      <meta name="description" content="Learn how Petro Stratix uses cookies for functionality and anonymized analytics, plus how to manage your preferences." />
      <link rel="canonical" href="https://www.petrostratix.ca/cookie-policy" />
    </Helmet>
    <section className="pt-24 pb-20 bg-slate-950">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-sm text-slate-300 leading-relaxed space-y-6">
        <h1 className="text-3xl font-semibold text-white">Cookie Policy</h1>
        <p>Petro Stratix uses cookies to maintain site functionality and gather anonymized analytics. This policy describes the categories of cookies we use and options available to visitors.</p>
        <p><strong>Essential Cookies.</strong> These cookies are necessary for the site to function, enabling navigation, session continuity, and security features. Essential cookies cannot be disabled through the site interface but can be blocked at the browser level.</p>
        <p><strong>Analytics Cookies.</strong> We use privacy-conscious analytics tools to understand aggregated site usage. Data collected includes page visits, device types, and general geographic indicators. Analytics cookies do not track individual behaviour across websites and are anonymized.</p>
        <p><strong>Preference Management.</strong> Visitors can manage consent through the cookie banner or adjust browser settings. Declining analytics cookies does not limit site access. Changes may take effect after page reload.</p>
        <p><strong>Third-Party Services.</strong> If embedded content is introduced, the provider may set additional cookies. Petro Stratix evaluates third-party tools for privacy alignment and provides notice when they are used.</p>
        <p><strong>Updates.</strong> This cookie policy may change to reflect new technologies or regulatory expectations. Updates will be posted with revised effective dates.</p>
        <p>Questions about cookie usage can be directed to the Petro Stratix editorial office through the contact form. We appreciate feedback that helps maintain transparent data practices.</p>
      </div>
    </section>
  </>
);

export default CookiePolicy;