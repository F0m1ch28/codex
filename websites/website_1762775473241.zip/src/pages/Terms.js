import React from 'react';
import { Helmet } from 'react-helmet';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use | Petro Stratix</title>
      <meta name="description" content="Review the Petro Stratix terms of use covering access, content usage, trademarks, and disclaimers." />
      <link rel="canonical" href="https://www.petrostratix.ca/terms" />
    </Helmet>
    <section className="pt-24 pb-20 bg-slate-950">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-sm text-slate-300 leading-relaxed space-y-6">
        <h1 className="text-3xl font-semibold text-white">Terms of Use</h1>
        <p>These Terms of Use govern access to Petro Stratix digital properties. By visiting or using the site, you acknowledge and agree to these terms. If you do not agree, please discontinue use.</p>
        <p><strong>Content Ownership.</strong> All articles, graphics, logos, and design elements are the property of Petro Stratix unless otherwise noted. Content may be referenced for informational purposes with appropriate attribution. Reproduction for commercial distribution is prohibited without written consent.</p>
        <p><strong>Editorial Independence.</strong> Petro Stratix maintains editorial independence. Information is provided for general informational purposes and should not be interpreted as legal, financial, or engineering advice. Readers should consult qualified professionals for project-specific decisions.</p>
        <p><strong>User Conduct.</strong> Users agree not to interfere with site operations or attempt unauthorized access to systems supporting Petro Stratix. Any misuse may result in restricted access and reporting to relevant authorities.</p>
        <p><strong>External Links.</strong> The site may contain links to third-party resources. Petro Stratix is not responsible for the content or practices of external sites. Inclusion of a link does not imply endorsement.</p>
        <p><strong>Liability Limitation.</strong> Petro Stratix is not liable for damages resulting from reliance on information available through the site. Access is provided on an “as is” basis without warranties of any kind, express or implied.</p>
        <p><strong>Governing Law.</strong> These terms are governed by the laws of the Province of Alberta and the federal laws of Canada. Any disputes will be handled in Alberta courts.</p>
        <p><strong>Updates.</strong> Petro Stratix may update these terms at any time. Changes take effect upon posting. Continued use after updates constitutes acceptance.</p>
        <p>For questions regarding these terms, please contact the editorial office through the contact page.</p>
      </div>
    </section>
  </>
);

export default Terms;