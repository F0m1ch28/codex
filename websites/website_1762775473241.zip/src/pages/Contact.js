import React, { useState } from 'react';
import { Helmet } from 'react-helmet';

const Contact = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!formState.name.trim()) newErrors.name = 'Please enter your name.';
    if (!formState.email.trim()) newErrors.email = 'Email is required.';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email.trim())) newErrors.email = 'Enter a valid email.';
    if (!formState.message.trim()) newErrors.message = 'Message cannot be empty.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormState((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      setSubmitted(true);
      setFormState({ name: '', email: '', message: '' });
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact Petro Stratix | Editorial Desk</title>
        <meta name="description" content="Reach the Petro Stratix editorial team in Calgary for inquiries, clarifications, or collaboration on Canadian energy infrastructure studies." />
        <link rel="canonical" href="https://www.petrostratix.ca/contact" />
      </Helmet>
      <section className="pt-24 pb-12 bg-slate-950">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white">Contact Petro Stratix</h1>
          <p className="mt-4 text-sm text-slate-300 leading-relaxed">
            The Petro Stratix editorial desk welcomes clarifications, data contributions, and collaboration ideas related to Canadian energy infrastructure. Please allow two business days for a response.
          </p>
        </div>
      </section>
      <section className="pb-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 grid gap-10 lg:grid-cols-[1.2fr_1fr]">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-lg shadow-slate-900/30">
            <form onSubmit={handleSubmit} noValidate>
              <div className="space-y-5">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-slate-200">Name</label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    value={formState.name}
                    onChange={handleChange}
                    className={`mt-2 w-full rounded-xl border bg-slate-950/60 px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.name ? 'border-red-400' : 'border-slate-700'}`}
                    placeholder="Your name"
                    required
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                  />
                  {errors.name && <p id="name-error" className="mt-1 text-xs text-red-400">{errors.name}</p>}
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-slate-200">Email</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={formState.email}
                    onChange={handleChange}
                    className={`mt-2 w-full rounded-xl border bg-slate-950/60 px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.email ? 'border-red-400' : 'border-slate-700'}`}
                    placeholder="you@example.com"
                    required
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                  />
                  {errors.email && <p id="email-error" className="mt-1 text-xs text-red-400">{errors.email}</p>}
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-slate-200">Message</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formState.message}
                    onChange={handleChange}
                    className={`mt-2 w-full rounded-xl border bg-slate-950/60 px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 h-36 resize-none ${errors.message ? 'border-red-400' : 'border-slate-700'}`}
                    placeholder="Share your inquiry or context"
                    required
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'message-error' : undefined}
                  />
                  {errors.message && <p id="message-error" className="mt-1 text-xs text-red-400">{errors.message}</p>}
                </div>
              </div>
              <button
                type="submit"
                className="mt-8 inline-flex items-center justify-center px-6 py-3 rounded-full bg-blue-600 text-white font-semibold shadow-lg shadow-blue-900/40 hover:bg-blue-500 transition focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-slate-900"
              >
                Submit
              </button>
              {submitted && (
                <div className="mt-4 text-sm text-green-400">
                  Thank you for reaching out. Our editorial team will respond shortly.
                </div>
              )}
            </form>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-lg shadow-slate-900/30 space-y-4">
            <h2 className="text-lg font-semibold text-white">Editorial contact</h2>
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-blue-400">Address</p>
              <p className="text-sm text-slate-300 mt-2 leading-relaxed">Petro Stratix<br />400 5 Ave SW<br />Calgary, AB T2P 0L6<br />Canada</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-blue-400">Telephone</p>
              <p className="text-sm text-slate-300 mt-2">+1 (587) 555-4732</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-blue-400">Email</p>
              <p className="text-sm text-slate-300 mt-2">Email address available through the contact form</p>
            </div>
            <p className="pt-4 text-sm text-slate-400 leading-relaxed">
              The Petro Stratix team responds to editorial inquiries, data verification requests, and collaboration opportunities respecting our neutrality policy. For media statements, please include timing requirements within your message.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;