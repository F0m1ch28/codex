import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';

const posts = [
  {
    title: 'Pipeline Renewal: Coordinating Modern Upgrades',
    excerpt: 'A comprehensive review of pipeline renewal programs covering engineering, regulatory pacing, and stakeholder coordination across Canada.',
    date: 'May 2, 2024',
    link: '/blog/pipeline-renewal'
  },
  {
    title: 'Refinery Coordination: Aligning Turnarounds and Supply',
    excerpt: 'How Canadian refineries synchronize maintenance windows, product slates, and community communication to maintain stability.',
    date: 'April 12, 2024',
    link: '/blog/refinery-coordination'
  },
  {
    title: 'Storage Topologies: Designing Resilient Inventories',
    excerpt: 'Investigating storage topology, cavern integrity, and the scheduling frameworks that underpin resilient Canadian inventories.',
    date: 'March 28, 2024',
    link: '/blog/storage-topologies'
  }
];

const Blog = () => (
  <>
    <Helmet>
      <title>Petro Stratix Blog | Canadian Energy Infrastructure Analysis</title>
      <meta name="description" content="Read Petro Stratix articles about Canadian energy infrastructure, pipeline renewal, refinery coordination, and storage topology." />
      <link rel="canonical" href="https://www.petrostratix.ca/blog" />
    </Helmet>
    <section className="pt-24 pb-12 bg-slate-950">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-semibold text-white">Blog</h1>
        <p className="mt-4 text-sm text-slate-300 leading-relaxed">
          Petro Stratix publishes modular articles featuring verifiable data, neutral commentary, and scenario analysis on Canada’s energy systems.
        </p>
      </div>
    </section>
    <section className="pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {posts.map((post) => (
          <article key={post.link} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-lg shadow-slate-900/30">
            <p className="text-xs uppercase tracking-[0.3em] text-blue-400">{post.date}</p>
            <h2 className="mt-3 text-2xl font-semibold text-white">{post.title}</h2>
            <p className="mt-3 text-sm text-slate-300 leading-relaxed">{post.excerpt}</p>
            <Link to={post.link} className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-blue-400 hover:text-blue-300">
              Read article
              <svg className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 12h13.5M12 5.25L18.75 12 12 18.75" />
              </svg>
            </Link>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Blog;