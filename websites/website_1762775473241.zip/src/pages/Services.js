import React from 'react';
import { Helmet } from 'react-helmet';

const clusters = [
  {
    name: 'Pipelines',
    paragraphs: [
      'Canada’s pipeline corridors span thousands of kilometres, connecting resource basins with refining hubs and export terminals. Petro Stratix analyses valve automation, inspection cycles, and capacity adjustments to understand how transmission flow adapts to evolving demand.',
      'We monitor regulatory filings, Indigenous consultations, and environmental assessments to identify how pipeline renewal programs address safety and stewardship. Each dossier highlights alignment with national and provincial oversight frameworks.',
      'Coverage also includes emergency response coordination, highlighting inter-agency communication drills and cross-border preparedness initiatives that keep communities informed.'
    ],
    links: [
      { label: 'Canada Energy Regulator Infrastructure Map', url: 'https://www.cer-rec.gc.ca/en/data-analysis/facilities-we-regulate/index.html' },
      { label: 'Trans Mountain Filing Library', url: 'https://www.cer-rec.gc.ca/en/applications-hearings/submit-applications-documents/applications-filing/trans-mountain-index.html' },
      { label: 'National Energy Board Pipeline Safety', url: 'https://www.cer-rec.gc.ca/en/safety-environment/index.html' },
      { label: 'Indigenous Advisory and Monitoring Committee', url: 'https://iamc-tmx.com' }
    ]
  },
  {
    name: 'Refineries',
    paragraphs: [
      'Canadian refineries manage crude blends, turnaround scheduling, and product slates tailored to provincial consumption. Petro Stratix studies coordination between operations teams, regulators, and supply networks to outline how facilities maintain reliability.',
      'Reports explore hydrogen integration, emissions control retrofits, and workforce planning that underpin refinery cadence. We maintain a neutral, evidence-based tone supported by public filings and cross-checked interviews.',
      'Our refinery coverage also follows interconnections with petrochemical plants and fuel distribution assets, mapping system dependencies that support domestic energy security.'
    ],
    links: [
      { label: 'Natural Resources Canada Refining Sector', url: 'https://natural-resources.canada.ca' },
      { label: 'Government of Alberta Industrial Heartland', url: 'https://www.alberta.ca' },
      { label: 'Ontario Energy Board Publications', url: 'https://www.oeb.ca' },
      { label: 'Canadian Fuels Association Data Centre', url: 'https://canadianfuels.ca' }
    ]
  },
  {
    name: 'Storage',
    paragraphs: [
      'Storage assets across Canada include salt caverns, tank farms, LNG terminals, and modular storage systems supporting remote communities. Petro Stratix documents inventory management, inspection regimes, and technological upgrades sustaining readiness.',
      'We profile how storage operators collaborate with municipalities and emergency management agencies to rehearse response plans and ensure transparent communication.',
      'Spatial analysis helps readers interpret how storage pneumatics, rail connectivity, and marine logistics align with national energy resilience strategies.'
    ],
    links: [
      { label: 'Energy Storage Canada Knowledge Hub', url: 'https://energystoragecanada.org' },
      { label: 'Ontario Underground Storage Registry', url: 'https://www.ontario.ca' },
      { label: 'Government of British Columbia Emergency Management', url: 'https://www2.gov.bc.ca' },
      { label: 'CSA Group Standards for Storage Tanks', url: 'https://www.csagroup.org' }
    ]
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Systems Coverage | Petro Stratix Pipeline, Refinery, and Storage Insights</title>
      <meta name="description" content="Explore Petro Stratix coverage across pipeline systems, refinery coordination, and storage infrastructure with reference resources and neutral analysis." />
      <link rel="canonical" href="https://www.petrostratix.ca/systems" />
    </Helmet>
    <section className="pt-24 pb-16 bg-slate-950">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-semibold text-white">Systems Coverage</h1>
        <p className="mt-4 text-sm text-slate-300 leading-relaxed">
          Petro Stratix organises coverage into three core clusters: pipelines, refineries, and storage. Each cluster combines operational narratives, regulatory context, and references to public resources so readers can conduct deeper analysis.
        </p>
      </div>
    </section>
    <section className="pb-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {clusters.map((cluster) => (
          <article key={cluster.name} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-lg shadow-slate-900/30">
            <h2 className="text-2xl font-semibold text-white">{cluster.name}</h2>
            <div className="mt-4 space-y-4">
              {cluster.paragraphs.map((paragraph, idx) => (
                <p key={idx} className="text-sm text-slate-300 leading-relaxed">{paragraph}</p>
              ))}
            </div>
            <div className="mt-6">
              <p className="text-xs uppercase tracking-[0.3em] text-blue-400">Public resources</p>
              <ul className="mt-3 grid gap-3 md:grid-cols-2 text-sm text-blue-300">
                {cluster.links.map((link) => (
                  <li key={link.url}>
                    <a href={link.url} target="_blank" rel="noreferrer" className="hover:text-blue-200 underline">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default Services;