import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const team = [
  {
    name: 'Lena Morin',
    role: 'Managing Editor',
    bio: 'Lena began her career documenting pipeline hearings and infrastructure assessments for regional newspapers in Saskatchewan. She leads Petro Stratix editorial operations, ensuring content is substantiated, neutral in tone, and accessible for a wide readership.'
  },
  {
    name: 'Rajesh Nayar',
    role: 'Systems Analyst',
    bio: 'Rajesh is a mechanical engineer with extensive refinery optimisation experience across Alberta and Ontario. He translates complex process developments into precise narratives grounded in engineering evidence.'
  },
  {
    name: 'Claire Dumont',
    role: 'Data Cartographer',
    bio: 'Claire fuses geospatial analysis with infrastructure reporting. Her mapping work overlays pipeline alignments, buffer zones, and emergency response corridors to contextualise evolving energy systems.'
  },
  {
    name: 'Simon Aglukkaq',
    role: 'Northern Correspondent',
    bio: 'Simon documents energy infrastructure adaptations in Arctic and sub-Arctic communities. His field reporting brings forward the voices of local leaders navigating energy resilience.'
  }
];

const About = () => (
  <>
    <Helmet>
      <title>About Petro Stratix | Editorial Origins and Team</title>
      <meta name="description" content="Discover Petro Stratix origins, editorial position, source model, neutrality policy, and the team documenting Canadian energy infrastructure." />
      <link rel="canonical" href="https://www.petrostratix.ca/about" />
    </Helmet>
    <section className="pt-24 pb-20 bg-slate-950">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-semibold text-white">About Petro Stratix</h1>
        <p className="mt-4 text-sm uppercase tracking-[0.3em] text-blue-400">Origins</p>
        <p className="mt-4 text-sm text-slate-300 leading-relaxed">
          Petro Stratix was founded in Calgary to document Canada’s energy infrastructure with a transparent methodology. The platform grew from a collaboration between reporters, engineers, and community researchers who wanted to bridge technical discourse with everyday accessibility. Early coverage focused on pipeline hearings, refinery maintenance cycles, and the logistics shaping energy transition conversations.
        </p>
        <p className="mt-4 text-sm text-slate-300 leading-relaxed">
          As readership expanded, Petro Stratix adopted a mobile-first and modular publishing model. Our newsroom remains independent, funded by institutional subscriptions and research partnerships that respect editorial boundaries. We continue to publish in English (Canada) while amplifying regional perspectives from coast to coast to coast.
        </p>

        <p className="mt-10 text-sm uppercase tracking-[0.3em] text-blue-400">Editorial position</p>
        <p className="mt-4 text-sm text-slate-300 leading-relaxed">
          Petro Stratix focuses on descriptive analysis rather than advocacy. Articles emphasise operational context, citing regulator updates, community insights, and engineering documentation. Language is calibrated to remain neutral, ensuring the platform can be referenced by public institutions, industry actors, academics, and community groups alike.
        </p>

        <p className="mt-10 text-sm uppercase tracking-[0.3em] text-blue-400">Source model</p>
        <p className="mt-4 text-sm text-slate-300 leading-relaxed">
          Source material includes regulatory filings, technical studies, public hearings, open geodata, satellite imagery, and first-hand interviews. We maintain citation logs for every article and invite scrutiny through transparent update notes. Contributors undergo verification to ensure they are speaking from documented expertise or direct experience.
        </p>

        <p className="mt-10 text-sm uppercase tracking-[0.3em] text-blue-400">Neutrality policy</p>
        <p className="mt-4 text-sm text-slate-300 leading-relaxed">
          Neutrality is central to Petro Stratix. We decline promotional material, avoid speculative pricing commentary, and do not accept paid editorial placements. Corrections are logged openly, and readers are encouraged to provide context or clarifications through our contact channel. Editorial decisions are reviewed collectively to prevent single-source bias.
        </p>

        <p className="mt-12 text-sm uppercase tracking-[0.3em] text-blue-400">Editorial team</p>
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          {team.map((member) => (
            <motion.div
              key={member.name}
              whileHover={{ y: -4 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-lg shadow-slate-900/30"
            >
              <h3 className="text-lg font-semibold text-white">{member.name}</h3>
              <p className="text-xs uppercase tracking-[0.2em] text-blue-400">{member.role}</p>
              <p className="mt-3 text-sm text-slate-300 leading-relaxed">{member.bio}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default About;