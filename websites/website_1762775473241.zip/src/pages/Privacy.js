import React from 'react';
import { Helmet } from 'react-helmet';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Petro Stratix</title>
      <meta name="description" content="Understand how Petro Stratix collects, stores, and protects personal information in compliance with Canadian privacy standards." />
      <link rel="canonical" href="https://www.petrostratix.ca/privacy" />
    </Helmet>
    <section className="pt-24 pb-20 bg-slate-950">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-sm text-slate-300 leading-relaxed space-y-6">
        <h1 className="text-3xl font-semibold text-white">Privacy Policy</h1>
        <p>Petro Stratix respects your privacy and follows applicable Canadian privacy legislation. This policy explains how we collect, use, and safeguard personal information.</p>
        <p><strong>Information Collection.</strong> We collect personal data when you submit forms, subscribe to updates, or correspond with our editorial team. Typical data includes name, email address, organisation, and message content. We also collect limited technical data such as browser type and anonymized analytics metrics.</p>
        <p><strong>Use of Information.</strong> Personal information is used to respond to inquiries, deliver requested communications, and improve site functionality. Petro Stratix does not sell or lease personal data to third parties.</p>
        <p><strong>Data Storage.</strong> Data is stored on secure servers located in Canada with access limited to authorized personnel. We employ safeguards including encryption in transit, access logging, and periodic security assessments.</p>
        <p><strong>Cookies and Analytics.</strong> Functional cookies support navigation and session quality. Optional analytics cookies measure aggregated usage trends. Users may opt out via browser settings or the cookie preferences banner.</p>
        <p><strong>Third-Party Services.</strong> Petro Stratix may use third-party service providers for email distribution or analytics. Providers must adhere to privacy standards compatible with Canadian legislation and are restricted from using personal data for unrelated purposes.</p>
        <p><strong>Your Rights.</strong> You may request access to your personal information, seek corrections, or withdraw consent by contacting the editorial office. We will respond within a reasonable timeframe as required by law.</p>
        <p><strong>Policy Updates.</strong> This policy may change to reflect operational updates or regulatory requirements. Revisions will be posted on this page with an updated effective date.</p>
        <p>For privacy inquiries, please reach out through the contact page. Petro Stratix will address questions in accordance with Canadian privacy legislation.</p>
      </div>
    </section>
  </>
);

export default Privacy;