import React, { useState, useEffect } from 'react';

const STORAGE_KEY = 'petro-stratix-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem(STORAGE_KEY, 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-4">
      <div className="max-w-4xl mx-auto bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl shadow-slate-900/60 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-white">Cookie preferences</h2>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              Petro Stratix uses functional cookies to maintain session quality and to understand aggregated traffic patterns. Analytical cookies are anonymized and never used for profiling.
              Review our <a href="/cookie-policy" className="text-blue-400 underline">cookie policy</a> for details.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 shrink-0 w-full sm:w-auto">
            <button
              onClick={declineCookies}
              className="px-4 py-2 text-sm font-semibold border border-slate-600 rounded-full text-slate-200 hover:bg-slate-800 transition"
            >
              Decline
            </button>
            <button
              onClick={acceptCookies}
              className="px-4 py-2 text-sm font-semibold rounded-full bg-blue-600 text-white hover:bg-blue-500 transition focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-slate-900"
            >
              Accept
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;