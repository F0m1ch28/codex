import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-full bg-blue-600 flex items-center justify-center text-lg font-semibold">PS</div>
              <div>
                <p className="font-semibold text-lg tracking-wide text-white">Petro Stratix</p>
                <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Editorial Platform</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-slate-400 leading-relaxed">
              Petro Stratix traces the evolution of Canadian energy infrastructure with balanced reporting, verified data, and field-grounded observation.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-300">Navigation</h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-400">
              <li><Link to="/" className="hover:text-blue-400 transition">Home</Link></li>
              <li><Link to="/about" className="hover:text-blue-400 transition">About</Link></li>
              <li><Link to="/systems" className="hover:text-blue-400 transition">Systems</Link></li>
              <li><Link to="/blog" className="hover:text-blue-400 transition">Blog</Link></li>
              <li><Link to="/contact" className="hover:text-blue-400 transition">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-300">Governance</h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-400">
              <li><Link to="/terms" className="hover:text-blue-400 transition">Terms of Use</Link></li>
              <li><Link to="/privacy" className="hover:text-blue-400 transition">Privacy Policy</Link></li>
              <li><Link to="/cookie-policy" className="hover:text-blue-400 transition">Cookie Policy</Link></li>
              <li>
                <a href="https://www.canada.ca/en.html" target="_blank" rel="noreferrer" className="hover:text-blue-400 transition">
                  Government of Canada Energy Resources
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-300">Contact</h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-400">
              <li>400 5 Ave SW, Calgary, AB T2P 0L6</li>
              <li>+1 (587) 555-4732</li>
              <li><Link to="/contact" className="hover:text-blue-400 transition">Send a message</Link></li>
            </ul>
            <p className="mt-6 text-xs text-slate-500 leading-relaxed">
              Content is published in English (Canada). Petro Stratix maintains neutral editorial standards and does not provide commercial endorsement.
            </p>
          </div>
        </div>
        <div className="border-t border-slate-800 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-500">&copy; {new Date().getFullYear()} Petro Stratix. All rights reserved.</p>
          <p className="text-xs text-slate-600">Industrial deployment observation across Canadian energy corridors.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;