document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('active');
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('[data-cookie-accept]');
    const declineBtn = document.querySelector('[data-cookie-decline]');
    const cookiePreference = localStorage.getItem('nogoarohjx_cookie_consent');

    if (cookieBanner && acceptBtn && declineBtn) {
        if (cookiePreference === 'accepted' || cookiePreference === 'declined') {
            cookieBanner.classList.add('hidden');
        }

        acceptBtn.addEventListener('click', () => {
            localStorage.setItem('nogoarohjx_cookie_consent', 'accepted');
            cookieBanner.classList.add('hidden');
        });

        declineBtn.addEventListener('click', () => {
            localStorage.setItem('nogoarohjx_cookie_consent', 'declined');
            cookieBanner.classList.add('hidden');
        });
    }
});