document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
            if (navMenu.classList.contains('active')) {
                navMenu.style.display = 'flex';
            } else if (window.innerWidth < 768) {
                navMenu.style.display = 'none';
            }
        });

        window.addEventListener('resize', function () {
            if (window.innerWidth >= 768) {
                navMenu.style.display = 'flex';
                navToggle.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            } else if (!navMenu.classList.contains('active')) {
                navMenu.style.display = 'none';
            }
        });

        document.addEventListener('click', function (event) {
            if (window.innerWidth < 768) {
                if (!navMenu.contains(event.target) && !navToggle.contains(event.target)) {
                    navMenu.classList.remove('active');
                    navMenu.style.display = 'none';
                    navToggle.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('transinkokCookieConsent');
        if (storedPreference) {
            cookieBanner.classList.add('hidden');
        }

        cookieBanner.addEventListener('click', function (event) {
            const target = event.target;
            if (target instanceof HTMLElement && target.dataset.cookieAction) {
                if (target.dataset.cookieAction === 'accept') {
                    localStorage.setItem('transinkokCookieConsent', 'accepted');
                } else if (target.dataset.cookieAction === 'decline') {
                    localStorage.setItem('transinkokCookieConsent', 'declined');
                }
                cookieBanner.classList.add('hidden');
            }
        });
    }
});