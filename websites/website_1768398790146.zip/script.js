document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!isExpanded));
            siteNav.classList.toggle('is-open');
        });

        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                siteNav.classList.remove('is-open');
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieAccept = document.querySelector('.cookie-btn.accept');
    const cookieDecline = document.querySelector('.cookie-btn.decline');
    const storageKey = 'occultuxmz_cookie_consent';

    const hideBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.add('hidden');
        }
    };

    try {
        const storedConsent = localStorage.getItem(storageKey);
        if (!storedConsent && cookieBanner) {
            cookieBanner.classList.remove('hidden');
        } else if (storedConsent && cookieBanner) {
            hideBanner();
        }
    } catch (error) {
        // localStorage unavailable; banner will remain visible
    }

    const handleConsent = (event, value) => {
        if (event) {
            event.preventDefault();
        }
        try {
            localStorage.setItem(storageKey, value);
        } catch (error) {
            // fail silently
        }
        hideBanner();
    };

    if (cookieAccept) {
        cookieAccept.addEventListener('click', event => handleConsent(event, 'accepted'));
    }

    if (cookieDecline) {
        cookieDecline.addEventListener('click', event => handleConsent(event, 'declined'));
    }
});