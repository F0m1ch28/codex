document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var siteNav = document.querySelector('.site-nav');
    var cookieBanner = document.getElementById('cookie-banner');
    var currentYearEl = document.getElementById('current-year');

    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            var expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navToggle.classList.toggle('is-active');
            siteNav.classList.toggle('is-open');
        });

        siteNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.classList.remove('is-active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner) {
        var consent = localStorage.getItem('eathedscx_cookie_consent');
        if (!consent) {
            cookieBanner.classList.add('is-visible');
        }

        cookieBanner.addEventListener('click', function (event) {
            var action = event.target.getAttribute('data-cookie-action');
            if (!action) return;

            if (action === 'accept') {
                localStorage.setItem('eathedscx_cookie_consent', 'accepted');
                cookieBanner.classList.remove('is-visible');
            }

            if (action === 'decline') {
                localStorage.setItem('eathedscx_cookie_consent', 'declined');
                cookieBanner.classList.remove('is-visible');
            }

            if (action === 'customize') {
                window.location.href = 'cookies.html';
            }
        });
    }
});