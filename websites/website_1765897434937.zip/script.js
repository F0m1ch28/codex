document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.getElementById('navToggle');
    const primaryNav = document.getElementById('primaryNav');
    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            primaryNav.classList.toggle('is-open');
            const expanded = primaryNav.classList.contains('is-open');
            navToggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        });
        primaryNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                primaryNav.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieDecline = document.getElementById('cookieDecline');
    if (cookieBanner && cookieAccept && cookieDecline) {
        const preference = localStorage.getItem('icewind_cookie_preference');
        if (!preference) {
            cookieBanner.classList.remove('is-hidden');
            cookieBanner.classList.add('is-visible');
        } else {
            cookieBanner.classList.add('is-hidden');
        }
        const setPreference = function (value) {
            localStorage.setItem('icewind_cookie_preference', value);
            cookieBanner.classList.remove('is-visible');
            cookieBanner.classList.add('is-hidden');
        };
        cookieAccept.addEventListener('click', function () {
            setPreference('accepted');
        });
        cookieDecline.addEventListener('click', function () {
            setPreference('declined');
        });
    }
});