```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const Privacy = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Tu Progreso Hoy</title>
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Privacy Policy</h1>
          <p>
            Tu Progreso Hoy safeguards your personal data with transparent practices aligned with Argentine regulations and international best practices.
          </p>
        </div>
      </section>

      <section className="section legal-text">
        <h2>1. Who we are</h2>
        <p>
          Tu Progreso Hoy is an educational platform operated from Buenos Aires, Argentina. We deliver argentina inflation insights and personal finance education.
          You can reach us at hola@tuprogresohoy.com or Av. 9 de Julio 1000, C1043 Buenos Aires.
        </p>

        <h2>2. Information we collect</h2>
        <ul>
          <li>Contact information such as name and email when you opt into communications or register for the course.</li>
          <li>Usage analytics captured through optional cookies (only when you consent via the cookie banner).</li>
          <li>Support correspondences and survey responses you provide voluntarily.</li>
        </ul>

        <h2>3. Legal basis &amp; purposes</h2>
        <p>
          We rely on your consent to send educational content and marketing updates. Contractual necessity covers access to paid programs.
          Legitimate interest applies to essential communications related to system maintenance and legal compliance.
        </p>

        <h2>4. Double opt-in</h2>
        <p>
          Subscriptions follow a double opt-in mechanism. After submitting your email, you must confirm via a follow-up message before any campaign starts.
          This ensures control and traceability of your consent.
        </p>

        <h2>5. Data sharing</h2>
        <p>
          We do not sell personal data. Trusted service providers (such as email delivery platforms and analytics tools)
          operate under confidentiality agreements and only process data for the purposes we define.
        </p>

        <h2>6. International transfers</h2>
        <p>
          When data is stored outside Argentina, we ensure adequate safeguards through Standard Contractual Clauses or equivalent protections.
        </p>

        <h2>7. Your rights</h2>
        <ul>
          <li>Access, rectify, or erase your personal information.</li>
          <li>Withdraw consent at any time without affecting previous lawful processing.</li>
          <li>Port your data or object to certain processing activities.</li>
        </ul>

        <h2>8. Data retention</h2>
        <p>
          Records are kept for as long as necessary to provide services and comply with legal obligations. Inactive subscribers are removed after 24 months without engagement.
        </p>

        <h2>9. Security</h2>
        <p>
          We implement technical and organizational measures such as encryption in transit, role-based access controls, and regular audits.
        </p>

        <h2>10. Updates</h2>
        <p>
          This policy may be updated to reflect new regulations or product features. We will inform you via email or platform notice.
        </p>
      </section>
    </>
  );
};

export default Privacy;
```