```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const Sitemap = () => {
  const baseUrl = 'https://www.tuprogresohoy.com';
  const lastmod = new Date().toISOString().split('T')[0];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}/</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>1.00</priority>
  </url>
  <url>
    <loc>${baseUrl}/inflation</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.90</priority>
  </url>
  <url>
    <loc>${baseUrl}/course</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.85</priority>
  </url>
  <url>
    <loc>${baseUrl}/resources</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${baseUrl}/contact</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.80</priority>
  </url>
  <url>
    <loc>${baseUrl}/thank-you</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.70</priority>
  </url>
  <url>
    <loc>${baseUrl}/privacy</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.60</priority>
  </url>
  <url>
    <loc>${baseUrl}/cookies</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.60</priority>
  </url>
  <url>
    <loc>${baseUrl}/terms</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.60</priority>
  </url>
  <url>
    <loc>${baseUrl}/faq</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.60</priority>
  </url>
  <url>
    <loc>${baseUrl}/robots.txt</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.40</priority>
  </url>
  <url>
    <loc>${baseUrl}/sitemap.xml</loc>
    <lastmod>${lastmod}</lastmod>
    <priority>0.40</priority>
  </url>
</urlset>`;

  return (
    <>
      <Helmet>
        <title>Sitemap | Tu Progreso Hoy</title>
      </Helmet>
      <pre className="plain-output" aria-label="Sitemap XML document">{xml}</pre>
    </>
  );
};

export default Sitemap;
```