```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const resourceList = [
  {
    title: 'Argentina inflation glossary / Glosario de inflación argentina',
    description: 'Bilingual terminology guide covering CPI, FX, and budgeting concepts used in our course materials.',
    link: 'https://www.indec.gob.ar/indec/web/Nivel3-Tema-3-5',
    type: 'Glossary',
    language: 'EN / ES'
  },
  {
    title: 'Budgeting essentials for Argentina (EN)',
    description: 'Article exploring realistic budgeting tactics when inflation is volatile, with examples from Buenos Aires.',
    link: 'https://www.argentina.gob.ar/economia/finanzas/inclusion-financiera',
    type: 'Article',
    language: 'English'
  },
  {
    title: 'Guía rápida: cómo leer el tipo de cambio (ES)',
    description: 'Explicación clara sobre los distintos tipos de cambio en Argentina y cuándo se aplican.',
    link: 'https://www.bcra.gob.ar/Noticias/Glosario.asp',
    type: 'Guía',
    language: 'Español'
  },
  {
    title: 'Economic trends tracker (EN/ES)',
    description: 'Curated list of public dashboards following inflation, employment, and wage updates.',
    link: 'https://datos.gob.ar/',
    type: 'Dashboard',
    language: 'EN / ES'
  }
];

const Resources = () => {
  return (
    <>
      <Helmet>
        <title>Resources | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Curated resources and glossaries in English and Spanish about argentina inflation, ARS to USD trends, and responsible personal finance."
        />
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Resource library</h1>
          <p>
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera. Explore bilingual glossaries,
            guides, and datasets to complement the Tu Progreso Hoy experience.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <h2>Articles &amp; Glossaries</h2>
          <p>
            We continuously update this selection to keep your learning journey refreshed with argentina inflation insights
            and responsible budgeting tactics.
          </p>
        </div>
        <div className="resource-grid">
          {resourceList.map((resource) => (
            <article className="resource-card" key={resource.title}>
              <span className="badge">{resource.type}</span>
              <h3>{resource.title}</h3>
              <p>{resource.description}</p>
              <p className="resource-meta">{resource.language}</p>
              <a className="btn ghost" href={resource.link} target="_blank" rel="noreferrer">
                Open resource
              </a>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Resources;
```