```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useLocation } from 'react-router-dom';

const ThankYou = () => {
  const location = useLocation();
  const email = location.state?.email;

  return (
    <>
      <Helmet>
        <title>Thank You | Tu Progreso Hoy</title>
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Thank you for joining</h1>
          <p>
            We sent a confirmation email{email ? ` to ${email}` : ''}. Please confirm your subscription to complete the double opt-in process.
          </p>
          <p className="smallprint">
            Revisa tu bandeja de entrada y confirma para recibir materiales y actualizaciones. Si no aparece, verifica tu carpeta de spam o promociones.
          </p>
          <Link className="btn primary" to="/">Back to home</Link>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <h2>What happens next</h2>
          <p>
            Once you confirm, you’ll receive the welcome lesson, access instructions, and recommended Argentina inflation readings.
          </p>
        </div>
        <div className="resource-grid">
          <article className="resource-card">
            <h3>Step 1</h3>
            <p>Confirm the email titled <em>“Tu Progreso Hoy: Please confirm your address”</em>.</p>
          </article>
          <article className="resource-card">
            <h3>Step 2</h3>
            <p>Add our address to your safe sender list so you never miss updates or live session invites.</p>
          </article>
          <article className="resource-card">
            <h3>Step 3</h3>
            <p>Download the welcome kit with inflation primers, budgeting worksheets, and bilingual glossary.</p>
          </article>
        </div>
      </section>
    </>
  );
};

export default ThankYou;
```