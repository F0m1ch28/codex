```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const Course = () => {
  return (
    <>
      <Helmet>
        <title>Personal Finance Course | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Discover Tu Progreso Hoy personal finance starter course for Argentina. Syllabus, modules, and anchored CTA to join the learning community."
        />
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Personal Finance Starter Course</h1>
          <p>
            A blended learning experience designed in Buenos Aires for people who want to navigate argentina inflation,
            organize budgets, and cultivate resilient habits.
          </p>
          <a className="btn primary" href="/#course-overview">Go to course overview</a>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <h2>Syllabus structure</h2>
          <p>
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Each chapter combines data
            drills, reflection practices, and storytelling to keep you engaged.
          </p>
        </div>
        <div className="syllabus-grid">
          <article className="syllabus-card">
            <h3>Week 1 · Foundations</h3>
            <p>
              Orientation, inflation primer, and tools tour. You profile your income, spending, and obligations.
            </p>
            <ul>
              <li>Argentina inflation context — bilingual briefing</li>
              <li>Budgeting frameworks with localized templates</li>
              <li>Group discussion en español y en inglés</li>
            </ul>
          </article>
          <article className="syllabus-card">
            <h3>Week 2 · Forecast ranges</h3>
            <p>
              Learn to build optimistic, base, and conservative projections using available inflation and FX data.
            </p>
            <ul>
              <li>Scenario builder lab</li>
              <li>Saving and spending checkpoint</li>
              <li>Peer feedback with moderated session</li>
            </ul>
          </article>
          <article className="syllabus-card">
            <h3>Week 3 · Implementation</h3>
            <p>
              Convert insights into routines: calendarize bill reviews, track ARS → USD triggers, and define evaluation metrics.
            </p>
            <ul>
              <li>Habit loop workshop</li>
              <li>Accountability frameworks</li>
              <li>Optional family budgeting toolkit</li>
            </ul>
          </article>
          <article className="syllabus-card">
            <h3>Week 4 · Integration</h3>
            <p>
              Reflect on progress, update your playbook, and set a quarterly review cycle supported by the Tu Progreso Hoy data hub.
            </p>
            <ul>
              <li>Community presentation</li>
              <li>Mentor office hours</li>
              <li>Post-course resource pack</li>
            </ul>
          </article>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <h2>Who joins the course</h2>
          <p>
            Built for professionals, freelancers, and students in Argentina who seek structure to make measured decisions.
          </p>
        </div>
        <div className="audience-grid">
          <div className="audience-card">
            <h3>Emerging professionals</h3>
            <p>
              Align first salaries with savings goals and plan milestone purchases responsibly.
            </p>
          </div>
          <div className="audience-card">
            <h3>Independent workers</h3>
            <p>
              Manage variable income, align invoices with inflation, and set aside tax contributions.
            </p>
          </div>
          <div className="audience-card">
            <h3>Household planners</h3>
            <p>
              Develop family budgets, track school expenses, and discuss financial decisions with clarity.
            </p>
          </div>
        </div>
      </section>

      <section className="section gradient-section">
        <div className="section-heading centered">
          <h2>Course resources</h2>
          <p>
            Your enrollment includes live facilitation, curated readings, bilingual glossaries, and ongoing access to the inflation dashboard.
          </p>
        </div>
        <div className="resource-grid">
          <div className="resource-card">
            <h3>Live sessions</h3>
            <p>Weekly 90-minute workshops with recordings subtitled in Spanish and English.</p>
          </div>
          <div className="resource-card">
            <h3>Data hub access</h3>
            <p>Real-time ARS → USD analytics within the Tu Progreso Hoy platform.</p>
          </div>
          <div className="resource-card">
            <h3>Community channels</h3>
            <p>Slack and Telegram spaces moderated for inclusive, respectful dialogue.</p>
          </div>
          <div className="resource-card">
            <h3>Mentor clinics</h3>
            <p>Optional one-to-one check-ins to review progress and adjust your action plan.</p>
          </div>
        </div>
        <div className="centered">
          <a className="btn primary" href="/#cta-title">Join the next cohort</a>
        </div>
      </section>
    </>
  );
};

export default Course;
```