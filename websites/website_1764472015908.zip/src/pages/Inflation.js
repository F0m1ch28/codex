```javascript
import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import useInView from '../hooks/useInView';

const Inflation = () => {
  const cpiTrend = useMemo(() => [
    { month: 'Aug 23', value: 12.4 },
    { month: 'Sep 23', value: 12.7 },
    { month: 'Oct 23', value: 8.3 },
    { month: 'Nov 23', value: 12.8 },
    { month: 'Dec 23', value: 25.5 },
    { month: 'Jan 24', value: 20.6 },
    { month: 'Feb 24', value: 13.2 }
  ], []);

  const categories = useMemo(() => [
    { label: 'Food & beverages', weight: 23.0, yoy: 211, note: 'Staple goods and fresh produce from major chains.' },
    { label: 'Transportation', weight: 14.8, yoy: 167, note: 'Fuel, ride-hailing, public transit adjustments.' },
    { label: 'Housing & utilities', weight: 13.9, yoy: 146, note: 'Energy tariffs, rent references, maintenance.' },
    { label: 'Health', weight: 9.0, yoy: 189, note: 'Medications, prepaid plans, clinical services.' },
    { label: 'Education', weight: 5.6, yoy: 165, note: 'Tuition, school supplies, extracurricular activities.' },
    { label: 'Recreation & culture', weight: 6.2, yoy: 153, note: 'Leisure, streaming, cultural events.' }
  ], []);

  const [methodRef, methodVisible] = useInView();
  const [chartRef, chartVisible] = useInView();

  const maxVal = Math.max(...cpiTrend.map((d) => d.value));
  const minVal = Math.min(...cpiTrend.map((d) => d.value));
  const range = maxVal - minVal || 1;
  const chartWidth = 300;
  const chartHeight = 100;
  const xPadding = 30;
  const yPadding = 20;
  const step = cpiTrend.length > 1 ? chartWidth / (cpiTrend.length - 1) : chartWidth;

  const points = cpiTrend.map((point, index) => {
    const x = xPadding + index * step;
    const y = yPadding + (chartHeight - ((point.value - minVal) / range) * chartHeight);
    return { x, y, label: point.month, value: point.value };
  });

  const cpiPath = points.map((point, index) => `${index === 0 ? 'M' : 'L'}${point.x},${point.y}`).join(' ');

  return (
    <>
      <Helmet>
        <title>Inflation Methodology | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Argentina inflation methodology, CPI breakdown, ARS to USD context, and FAQ for the Tu Progreso Hoy educational platform."
        />
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Argentina inflation methodology &amp; FX context</h1>
          <p>
            We connect official sources, field research, and transparent adjustments so you interpret inflation with nuance
            and apply it to your budgeting decisions con responsabilidad.
          </p>
          <p className="smallprint">
            Análisis transparentes y datos de mercado para decidir con seguridad.
          </p>
        </div>
      </section>

      <section className={`section ${methodVisible ? 'is-visible' : ''}`} ref={methodRef}>
        <div className="section-heading">
          <h2>Methodology layers</h2>
          <p>
            Our stack blends public datasets with curated private indexes to reflect argentina inflation realities.
          </p>
        </div>
        <div className="method-grid">
          <article className="method-card reveal">
            <h3>Official CPI anchors</h3>
            <p>
              Instituto Nacional de Estadística y Censos (INDEC) releases monthly CPI by region. We process microdata,
              extract the Metropolitan Buenos Aires basket, and reconcile it with national averages.
            </p>
            <ul>
              <li>Monthly updates in Spanish &amp; English summaries</li>
              <li>Seasonality adjustments using five-year history</li>
              <li>Household size calibration for 2- and 4-person families</li>
            </ul>
          </article>
          <article className="method-card reveal">
            <h3>High-frequency signals</h3>
            <p>
              Retail scanner data, wholesale price indicators, and curated marketplace samples feed our weekly nowcast to
              anticipate CPI surprises.
            </p>
            <ul>
              <li>Eight retail chains sampled from Buenos Aires, Córdoba, Rosario</li>
              <li>FX parallel references from regulated brokers</li>
              <li>Utility tariffs and transport updates tracked daily</li>
            </ul>
          </article>
          <article className="method-card reveal">
            <h3>FX context integration</h3>
            <p>
              ARS → USD references follow official rates, MEP, and blue-chip swap spreads. The dashboard lets you visualize
              how exchange dynamics influence planned purchases.
            </p>
            <ul>
              <li>Alerts when FX gap exceeds 20% weekly change</li>
              <li>Context notes about policy announcements</li>
              <li>Suggested readings to deepen understanding</li>
            </ul>
          </article>
        </div>
      </section>

      <section className={`section ${chartVisible ? 'is-visible' : ''}`} ref={chartRef}>
        <div className="section-heading">
          <h2>CPI trajectory</h2>
          <p>
            Month-over-month CPI percent change, seasonally adjusted. Use this trajectory to map your budgeting cycle to inflation realities.
          </p>
        </div>
        <div className={`chart-card reveal ${chartVisible ? 'is-visible' : ''}`}>
          <svg className="cpi-chart" viewBox="0 0 360 160" role="img" aria-label="Monthly CPI percent change line chart">
            <path d={cpiPath} fill="none" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
            {points.map((point) => (
              <g key={point.label}>
                <circle cx={point.x} cy={point.y} r="4" fill="#1F3A6F" />
                <text x={point.x} y={150} textAnchor="middle" className="chart-label">{point.label}</text>
              </g>
            ))}
          </svg>
          <ul className="chart-summary">
            <li><strong>Peak:</strong> {maxVal.toFixed(1)}% monthly</li>
            <li><strong>Latest:</strong> {points[points.length - 1].value.toFixed(1)}% monthly</li>
            <li><strong>FX gap watch:</strong> 18.2% (MEP vs Oficial, last update)</li>
          </ul>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <h2>Basket composition snapshot</h2>
          <p>
            Reference weights by category help you align personal expenditure with national averages while adapting to your context.
          </p>
        </div>
        <div className="table-wrapper">
          <table>
            <caption>Argentina CPI basket — selected categories</caption>
            <thead>
              <tr>
                <th scope="col">Category</th>
                <th scope="col">Weight (%)</th>
                <th scope="col">YoY change (%)</th>
                <th scope="col">Notes</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((row) => (
                <tr key={row.label}>
                  <th scope="row">{row.label}</th>
                  <td>{row.weight}</td>
                  <td>{row.yoy}</td>
                  <td>{row.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section faq-section">
        <div className="section-heading">
          <h2>Inflation FAQ</h2>
          <p>
            Your most common questions about argentina inflation, ARS/USD movements, and our educational approach.
          </p>
        </div>
        <div className="faq-grid">
          <details>
            <summary>How frequently is inflation data updated?</summary>
            <p>
              Official CPI is incorporated within 24 hours of INDEC releases. High-frequency prices refresh twice per week,
              with notifications in Spanish and English.
            </p>
          </details>
          <details>
            <summary>Do you forecast inflation levels?</summary>
            <p>
              We provide scenario ranges instead of point forecasts. The goal is to encourage responsible planning, not speculation.
            </p>
          </details>
          <details>
            <summary>Why include multiple FX rates?</summary>
            <p>
              Argentina operates with diverse FX references. Understanding their spread prepares you to interpret payment terms and supplier adjustments responsibly.
            </p>
          </details>
          <details>
            <summary>Can I request raw data?</summary>
            <p>
              Yes. Subscribers can export CSV summaries and read full methodology documentation in both English and Spanish.
            </p>
          </details>
        </div>
      </section>
    </>
  );
};

export default Inflation;
```