```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const Faq = () => {
  return (
    <>
      <Helmet>
        <title>FAQ | Tu Progreso Hoy</title>
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Frequently Asked Questions</h1>
          <p>
            Discover how Tu Progreso Hoy combines argentina inflation analytics with personal finance education in English and Spanish.
          </p>
        </div>
      </section>

      <section className="section legal-text">
        <div className="faq-grid">
          <details>
            <summary>Is the platform available in both English and Spanish?</summary>
            <p>
              Yes. Core dashboards, glossaries, and course materials are bilingual (EN/ES). Live sessions alternate languages and include summaries for easy follow-up.
            </p>
          </details>
          <details>
            <summary>Do you provide financial advice?</summary>
            <p>
              No. We share educational content to help you interpret data and make informed decisions. For personalized advice consult a licensed professional.
            </p>
          </details>
          <details>
            <summary>How often are dashboards updated?</summary>
            <p>
              FX and high-frequency indicators refresh automatically multiple times per day. Official CPI values are integrated after each INDEC publication.
            </p>
          </details>
          <details>
            <summary>What does double opt-in mean for me?</summary>
            <p>
              After submitting your email you will receive a confirmation message. Only when you confirm do we start sending materials. This protects your privacy and avoids unwanted emails.
            </p>
          </details>
          <details>
            <summary>Can my organization host a private cohort?</summary>
            <p>
              Yes. Contact us to design a tailored track using our argentina inflation analytics and course framework. Custom agreements outline scope, pricing, and confidentiality.
            </p>
          </details>
          <details>
            <summary>How is data accuracy ensured?</summary>
            <p>
              Datos verificados para planificar tu presupuesto. We cross-check sources, run quality controls, and publish methodology notes so you can review the evidence.
            </p>
          </details>
        </div>
      </section>
    </>
  );
};

export default Faq;
```