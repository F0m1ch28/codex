```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const Robots = () => {
  const content = `User-agent: *
Allow: /
Sitemap: https://www.tuprogresohoy.com/sitemap.xml
`;

  return (
    <>
      <Helmet>
        <title>Robots.txt | Tu Progreso Hoy</title>
      </Helmet>
      <pre className="plain-output" aria-label="Robots.txt rules">{content}</pre>
    </>
  );
};

export default Robots;
```