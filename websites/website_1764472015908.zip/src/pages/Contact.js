```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';

const Contact = () => {
  const [status, setStatus] = useState('idle');
  const [feedback, setFeedback] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('submitting');
    setFeedback('Sending your message…');
    setTimeout(() => {
      setStatus('success');
      setFeedback('Thank you! We will respond within two business days. ¡Gracias por contactarnos!');
    }, 900);
  };

  return (
    <>
      <Helmet>
        <title>Contact | Tu Progreso Hoy</title>
        <meta
          name="description"
          content="Contact Tu Progreso Hoy in Buenos Aires for argentina inflation insights and personal finance course information."
        />
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Contact Tu Progreso Hoy</h1>
          <p>
            We are based in Buenos Aires and respond in English and Spanish. Reach out for platform questions, course
            details, or collaboration opportunities.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="contact-grid">
          <div className="contact-card">
            <h2>Direct contact</h2>
            <p>
              Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina<br />
              <a href="tel:+541155551234">+54 11 5555-1234</a><br />
              <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
            </p>
            <p>
              Office hours: Monday to Friday, 9:00–18:00 (ART). We answer emails within two business days.
            </p>
            <div className="social-links">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer">X</a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer">YouTube</a>
            </div>
          </div>

          <div className="contact-card">
            <h2>Message us</h2>
            <form className="contact-form" onSubmit={handleSubmit}>
              <div className="form-field">
                <label htmlFor="contact-name">Full name / Nombre completo</label>
                <input id="contact-name" name="name" type="text" required />
              </div>
              <div className="form-field">
                <label htmlFor="contact-email">Email</label>
                <input id="contact-email" name="email" type="email" required />
              </div>
              <div className="form-field">
                <label htmlFor="contact-language">Preferred language</label>
                <select id="contact-language" name="language" defaultValue="English">
                  <option>English</option>
                  <option>Español</option>
                  <option>Bilingual (EN/ES)</option>
                </select>
              </div>
              <div className="form-field">
                <label htmlFor="contact-message">Message</label>
                <textarea id="contact-message" name="message" rows="4" required></textarea>
              </div>
              <button type="submit" className="btn primary" disabled={status === 'submitting'}>
                {status === 'submitting' ? 'Sending…' : 'Send message'}
              </button>
              {feedback && <p className="form-message">{feedback}</p>}
            </form>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="map-wrapper">
          <h2>Visit us in Buenos Aires</h2>
          <p>Our office is near iconic Avenida 9 de Julio. Meetings by appointment only.</p>
          <iframe
            title="Tu Progreso Hoy location in Buenos Aires"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.727972019259!2d-58.38159202402999!3d-34.61087925874425!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccadcba1f1d1b%3A0x8f0cf3c6d53295d!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
            width="100%"
            height="320"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </section>
    </>
  );
};

export default Contact;
```