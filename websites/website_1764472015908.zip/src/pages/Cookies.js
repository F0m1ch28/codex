```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const Cookies = () => {
  return (
    <>
      <Helmet>
        <title>Cookies | Tu Progreso Hoy</title>
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Cookie Policy</h1>
          <p>
            This page explains how Tu Progreso Hoy uses cookies and similar technologies to enhance your learning experience responsibly.
          </p>
        </div>
      </section>

      <section className="section legal-text">
        <h2>What are cookies?</h2>
        <p>
          Cookies are small text files stored on your device when you visit a website. They help remember your preferences and provide
          aggregated analytics so we can improve argentina inflation dashboards and course delivery.
        </p>

        <h2>Types of cookies we use</h2>
        <ul>
          <li><strong>Essential:</strong> Required for core functionality such as authentication and language preferences.</li>
          <li><strong>Analytics (optional):</strong> Help us understand how visitors interact with pages. These are only activated when you click “Accept” in the cookie banner.</li>
          <li><strong>Functional:</strong> Remember your settings, such as preferred language (English or Español).</li>
        </ul>

        <h2>Managing your preferences</h2>
        <p>
          You can accept or decline optional cookies through the banner displayed on your first visit. You may also clear or block cookies
          using your browser settings. Declining optional cookies does not limit access to the tuition-free areas of the platform.
        </p>

        <h2>Third-party services</h2>
        <p>
          We may use privacy-minded analytics providers and email platforms that place their own cookies. These partners adhere to contractual
          obligations to process data solely on our behalf.
        </p>

        <h2>Updates to this policy</h2>
        <p>
          Any changes will be posted on this page with a revised date. Significant updates will be communicated via email or in-app notice.
        </p>
      </section>
    </>
  );
};

export default Cookies;
```