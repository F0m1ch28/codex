```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';

const Terms = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service | Tu Progreso Hoy</title>
      </Helmet>
      <section className="page-hero parallax">
        <div className="page-hero-inner">
          <h1>Terms of Service</h1>
          <p>
            These terms govern your use of Tu Progreso Hoy, including dashboards, content, and personal finance learning experiences.
          </p>
        </div>
      </section>

      <section className="section legal-text">
        <h2>1. Acceptance of terms</h2>
        <p>
          By accessing our website, creating an account, or participating in the course you agree to these Terms of Service and our Privacy and Cookie Policies.
        </p>

        <h2>2. Service description</h2>
        <p>
          Tu Progreso Hoy provides educational content focused on argentina inflation, ARS → USD analytics, and personal finance best practices.
          Plataforma educativa con datos esenciales, sin asesoría financiera directa. We do not manage funds, execute trades, or provide individualized investment recommendations.
        </p>

        <h2>3. Eligibility</h2>
        <p>
          You must be at least 18 years old or have parental consent to use the platform. By enrolling, you confirm that the information you provide is accurate and complete.
        </p>

        <h2>4. User responsibilities</h2>
        <ul>
          <li>Use the materials solely for personal learning or internal business training.</li>
          <li>Respect intellectual property and do not redistribute course materials without permission.</li>
          <li>Maintain the confidentiality of your login credentials.</li>
        </ul>

        <h2>5. Payments and refunds</h2>
        <p>
          If you enroll in a paid cohort, payment terms will be shared during checkout. Refund requests are handled case by case
          and may require completion of onboarding activities to evaluate eligibility.
        </p>

        <h2>6. Limitation of liability</h2>
        <p>
          Tu Progreso Hoy shall not be liable for losses derived from financial or business decisions made by users. Content is provided for educational purposes only.
        </p>

        <h2>7. Modifications</h2>
        <p>
          We may update these terms to reflect new features or legal requirements. Continued use after changes constitutes acceptance of the revised terms.
        </p>

        <h2>8. Termination</h2>
        <p>
          We reserve the right to suspend or terminate access when users violate community guidelines, misuse data, or engage in unlawful behavior.
        </p>

        <h2>9. Governing law</h2>
        <p>
          These terms are governed by the laws of the Argentine Republic. Any dispute shall be resolved in the competent courts of Buenos Aires City.
        </p>

        <h2>10. Contact</h2>
        <p>
          For questions about these terms, contact hola@tuprogresohoy.com or write to Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina.
        </p>
      </section>
    </>
  );
};

export default Terms;
```