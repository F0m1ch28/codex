```javascript
import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import useInView from '../hooks/useInView';

const Home = () => {
  const [rate, setRate] = useState(null);
  const [rateLoading, setRateLoading] = useState(true);
  const [rateError, setRateError] = useState('');
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [formStatus, setFormStatus] = useState('idle');
  const [formMessage, setFormMessage] = useState('');
  const navigate = useNavigate();

  const history = useMemo(() => ([
    { month: 'Aug', value: 0.0036 },
    { month: 'Sep', value: 0.0038 },
    { month: 'Oct', value: 0.0039 },
    { month: 'Nov', value: 0.0041 },
    { month: 'Dec', value: 0.0043 },
    { month: 'Jan', value: 0.0044 },
    { month: 'Feb', value: 0.0045 }
  ]), []);

  const sparklinePath = useMemo(() => {
    if (!history.length) return '';
    const maxVal = Math.max(...history.map((d) => d.value));
    const minVal = Math.min(...history.map((d) => d.value));
    const range = maxVal - minVal || 1;
    const height = 80;
    const width = 320;
    const step = history.length > 1 ? width / (history.length - 1) : width;
    return history.map((point, index) => {
      const x = index * step;
      const y = height - ((point.value - minVal) / range) * height;
      return `${index === 0 ? 'M' : 'L'}${x},${y}`;
    }).join(' ');
  }, [history]);

  const latestValue = history[history.length - 1]?.value || 0;
  const firstValue = history[0]?.value || 1;
  const change = latestValue - firstValue;
  const changePercentage = firstValue ? (change / firstValue) * 100 : 0;
  const trendDirection = change > 0 ? 'up' : change < 0 ? 'down' : 'flat';

  useEffect(() => {
    let isMounted = true;

    const fetchRate = async () => {
      try {
        const response = await fetch('https://api.exchangerate.host/latest?base=ARS&symbols=USD');
        if (!response.ok) {
          throw new Error('Network response error');
        }
        const data = await response.json();
        if (isMounted && data?.rates?.USD) {
          setRate(parseFloat(data.rates.USD));
          setRateError('');
        }
      } catch (error) {
        if (isMounted) {
          setRateError('Live data temporarily unavailable. Showing reference trend.');
        }
      } finally {
        if (isMounted) {
          setRateLoading(false);
        }
      }
    };

    fetchRate();
    const interval = setInterval(fetchRate, 120000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setFormStatus('submitting');
    setFormMessage('Preparing double opt-in confirmation…');
    setTimeout(() => {
      setFormStatus('success');
      setFormMessage('Check your inbox to confirm your subscription. Revisa tu correo y confirma tu interés (doble confirmación).');
      setTimeout(() => {
        navigate('/thank-you', { state: { email: formData.email } });
      }, 1800);
    }, 900);
  };

  const [heroRef, heroVisible] = useInView();
  const [insightRef, insightVisible] = useInView();
  const [courseRef, courseVisible] = useInView();
  const [testimonialsRef, testimonialsVisible] = useInView();
  const [ctaRef, ctaVisible] = useInView();

  return (
    <>
      <Helmet>
        <title>Tu Progreso Hoy | Argentina Inflation Insights & Personal Finance Course</title>
      </Helmet>
      <section className={`hero parallax ${heroVisible ? 'is-visible' : ''}`} ref={heroRef}>
        <div className="hero-content">
          <div className="hero-text reveal">
            <span className="eyebrow">Argentina • Educación financiera consciente</span>
            <h1>
              Insights claros sobre inflación argentina y aprendizaje esencial en finanzas personales.
            </h1>
            <p className="lead">
              Datos verificados para planificar tu presupuesto. Información confiable que respalda elecciones responsables sobre tu dinero.
            </p>
            <ul className="hero-list">
              <li>Conocimiento financiero impulsado por tendencias.</li>
              <li>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</li>
              <li>Pasos acertados hoy, mejor futuro mañana.</li>
            </ul>
            <div className="hero-actions">
              <a className="btn primary" href="#course-overview">Explore the course itinerary</a>
              <a className="btn ghost" href="/inflation">See inflation methodology</a>
            </div>
            <p className="hero-subfoot">
              Decisiones responsables, objetivos nítidos. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
            </p>
          </div>
          <div className="hero-card reveal">
            <h2>ARS → USD Spotlight</h2>
            <p>
              Current tracker aligns with economic trends to help you observe market signals without speculation.
            </p>
            <div className="hero-stat">
              <span className="hero-stat-label">Live reference</span>
              <span className="hero-stat-value">
                {rateLoading ? 'Loading…' : rate ? `1 ARS = ${rate.toFixed(4)} USD` : '0.0000 USD'}
              </span>
            </div>
            {rateError && <p className="alert">{rateError}</p>}
            <div className={`trend trend-${trendDirection}`}>
              <span aria-hidden="true">{trendDirection === 'up' ? '▲' : trendDirection === 'down' ? '▼' : '■'}</span>
              <span>{changePercentage.toFixed(2)}% variation over the last 7 months.</span>
            </div>
            <p className="smallprint">
              Análisis transparentes y datos de mercado para decidir con seguridad.
            </p>
          </div>
        </div>
      </section>

      <section className="section exchange-section" aria-labelledby="exchange-title">
        <div className="section-heading">
          <h2 id="exchange-title">Argentina Inflation &amp; ARS to USD Tracker</h2>
          <p>
            Argentina inflation signals are processed daily to align budgeting guidance with updated FX references.
          </p>
        </div>
        <div className="exchange-grid">
          <div
            className={`exchange-card reveal ${insightVisible ? 'is-visible' : ''}`}
            ref={insightRef}
          >
            <div className="exchange-card-header">
              <h3>Monthly ARS → USD Tendency</h3>
              <span className="badge">Data Lens</span>
            </div>
            <svg className="sparkline" viewBox="0 0 320 80" role="img" aria-label="ARS to USD trend line over seven months">
              <path d={sparklinePath} fill="none" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
              <linearGradient id="sparkGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="rgba(37,99,235,0.35)" />
                <stop offset="100%" stopColor="rgba(15,23,42,0)" />
              </linearGradient>
              <path
                d={`${sparklinePath} L320,80 L0,80 Z`}
                fill="url(#sparkGradient)"
                opacity="0.6"
              />
            </svg>
            <div className="history-grid">
              {history.map((entry) => (
                <div key={entry.month} className="history-item">
                  <span className="history-month">{entry.month}</span>
                  <span className="history-value">{entry.value.toFixed(4)}</span>
                </div>
              ))}
            </div>
            <p>
              This trend contextualizes consumer price momentum so you can plan savings goals with realistic conversions.
            </p>
          </div>
          <div className="exchange-insights">
            <article className="insight-card">
              <h3>Why it matters</h3>
              <p>
                Argentina inflation, currency controls, and seasonal forces shift the ARS purchasing power every week.
                Our insights layer translates macro movements into clear checkpoints for your everyday budgeting.
              </p>
              <ul>
                <li>High-frequency CPI references aligned with local context.</li>
                <li>Consumption baskets tailored to Buenos Aires and regional averages.</li>
                <li>Context on policy announcements and their potential household impact.</li>
              </ul>
            </article>
            <article className="insight-card">
              <h3>Responsible learning journey</h3>
              <p>
                De la información al aprendizaje: fortalece tu criterio financiero paso a paso. Each module combines
                data exploration with reflective exercises so you define priorities anchored in evidence.
              </p>
              <p>
                Información confiable que respalda elecciones responsables sobre tu dinero.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section
        className={`section gradient-section ${courseVisible ? 'is-visible' : ''}`}
        id="course-overview"
        ref={courseRef}
      >
        <div className="section-heading centered">
          <h2>Personal Finance Starter Course for Argentina</h2>
          <p>
            Built for salaried professionals, freelancers, and students who want tools to navigate inflation with calm,
            while honoring personal values and community commitments.
          </p>
        </div>
        <div className="course-grid">
          <div className={`module-card reveal ${courseVisible ? 'is-visible' : ''}`}>
            <h3>Module 1 · Defining your baseline</h3>
            <p>
              Map your earnings, essential spending, and savings anchors against current CPI movements.
            </p>
            <ul>
              <li>Household budget storyboard (EN/ES)</li>
              <li>ARS → USD sensitivity lab</li>
              <li>Mindful priorities canvas</li>
            </ul>
          </div>
          <div className={`module-card reveal ${courseVisible ? 'is-visible' : ''}`}>
            <h3>Module 2 · Inflation-aware decisions</h3>
            <p>
              Learn to evaluate price shifts, payment terms, and subscription renewals using updated data points.
            </p>
            <ul>
              <li>Scenario planner with adjustable inflation bands</li>
              <li>Local financial vocabulary essential glossary</li>
              <li>Community discussion in Spanish/English</li>
            </ul>
          </div>
          <div className={`module-card reveal ${courseVisible ? 'is-visible' : ''}`}>
            <h3>Module 3 · Savings narratives</h3>
            <p>
              Build habits and rituals that protect your goals while staying flexible in a shifting economy.
            </p>
            <ul>
              <li>Short and medium term action map</li>
              <li>FX tracking rituals &amp; alerts</li>
              <li>Reflection prompts grounded in wellbeing</li>
            </ul>
          </div>
        </div>
        <div className="course-info">
          <div className="course-info-card">
            <h3>Learning experience</h3>
            <p>
              Weekly bilingual live sessions, micro videos (subtitled EN/ES), and practical labs inside an accessible dashboard.
            </p>
          </div>
          <div className="course-info-card">
            <h3>Tools included</h3>
            <p>
              Inflation dashboards, budgeting templates, and contextual guides focused on argentina inflation and economic trends.
            </p>
          </div>
        </div>
      </section>

      <section className={`section ${testimonialsVisible ? 'is-visible' : ''}`} ref={testimonialsRef}>
        <div className="section-heading">
          <h2>Community feedback</h2>
          <p>
            Learners from Buenos Aires, Córdoba, and Mendoza incorporate the data hub and course to refine day-to-day decisions.
          </p>
        </div>
        <div className="testimonial-grid">
          <figure className="testimonial-card reveal">
            <blockquote>
              “Los escenarios y el seguimiento ARS → USD me ayudaron a reorganizar mi presupuesto sin ansiedad.”
            </blockquote>
            <figcaption>Lucía — Diseñadora UX, Buenos Aires</figcaption>
          </figure>
          <figure className="testimonial-card reveal">
            <blockquote>
              “Appreciated the bilingual explanations. I could share lessons with my family y alinear prioridades juntos.”
            </blockquote>
            <figcaption>Manuel — Ingeniero industrial, Córdoba</figcaption>
          </figure>
          <figure className="testimonial-card reveal">
            <blockquote>
              “The dashboards keep me focused on what I can control. Pasos acertados hoy, mejor futuro mañana.”
            </blockquote>
            <figcaption>Sara — Emprendedora social, Mendoza</figcaption>
          </figure>
        </div>
      </section>

      <section className={`section cta-section ${ctaVisible ? 'is-visible' : ''}`} ref={ctaRef} aria-labelledby="cta-title">
        <div className={`cta-card reveal ${ctaVisible ? 'is-visible' : ''}`}>
          <h2 id="cta-title">Start your learning sprint</h2>
          <p>
            Conocimiento financiero impulsado por tendencias. Join a double opt-in list and receive a curated introductory lesson plus calendar of live experiences.
          </p>
          <form className="cta-form" onSubmit={handleSubmit}>
            <div className="form-field">
              <label htmlFor="name">Full name / Nombre completo</label>
              <input
                id="name"
                name="name"
                type="text"
                required
                value={formData.name}
                onChange={handleInputChange}
                autoComplete="name"
              />
            </div>
            <div className="form-field">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleInputChange}
                autoComplete="email"
              />
            </div>
            <button type="submit" className="btn primary" disabled={formStatus === 'submitting'}>
              {formStatus === 'submitting' ? 'Sending…' : 'Получить бесплатный пробный урок'}
            </button>
            {formMessage && <p className="form-message">{formMessage}</p>}
          </form>
          <p className="smallprint">
            We operate under a double opt-in system to respect consent. Correo de confirmación requerido antes de recibir acceso.
          </p>
        </div>
      </section>
    </>
  );
};

export default Home;
```