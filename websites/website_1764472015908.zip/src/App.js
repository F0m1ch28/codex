```javascript
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { HelmetProvider, Helmet } from 'react-helmet-async';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import DisclaimerModal from './components/DisclaimerModal';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import Inflation from './pages/Inflation';
import Course from './pages/Course';
import Resources from './pages/Resources';
import Contact from './pages/Contact';
import ThankYou from './pages/ThankYou';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import Terms from './pages/Terms';
import Faq from './pages/Faq';
import Sitemap from './pages/Sitemap';
import Robots from './pages/Robots';

import './styles/global.css';

function App() {
  return (
    <HelmetProvider>
      <Router>
        <ScrollToTop />
        <div className="app-shell">
          <Helmet>
            <html lang="en" />
            <link rel="alternate" href="https://www.tuprogresohoy.com/" hrefLang="en" />
            <link rel="alternate" href="https://www.tuprogresohoy.com/es-AR" hrefLang="es-AR" />
            <title>Tu Progreso Hoy | Inflation Intelligence & Personal Finance Learning</title>
            <meta
              name="description"
              content="Tu Progreso Hoy delivers argentina inflation insights, ARS to USD analytics, and a personal finance starter course designed for responsible budgeting in Argentina."
            />
            <meta
              name="keywords"
              content="argentina inflation, ars usd, finanzas personales, budgeting argentina, curso finanzas, economic trends, datos confiables"
            />
          </Helmet>
          <a className="skip-link" href="#mainContent">Skip to main content</a>
          <Header />
          <main id="mainContent" tabIndex="-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/inflation" element={<Inflation />} />
              <Route path="/course" element={<Course />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/thank-you" element={<ThankYou />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/cookies" element={<Cookies />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/faq" element={<Faq />} />
              <Route path="/sitemap.xml" element={<Sitemap />} />
              <Route path="/robots.txt" element={<Robots />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
          <Footer />
          <CookieBanner />
          <DisclaimerModal />
        </div>
      </Router>
    </HelmetProvider>
  );
}

export default App;
```