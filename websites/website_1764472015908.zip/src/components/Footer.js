```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="site-footer" role="contentinfo">
      <div className="footer-grid">
        <div>
          <h3 className="footer-heading">Tu Progreso Hoy</h3>
          <p>Datos verificados para planificar tu presupuesto.</p>
          <p>Decisiones responsables, objetivos nítidos.</p>
          <p className="footer-disclaimer">
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
          </p>
        </div>
        <div>
          <h4>Explore</h4>
          <ul>
            <li><NavLink to="/inflation">Inflation Dashboard</NavLink></li>
            <li><NavLink to="/course">Personal Finance Course</NavLink></li>
            <li><NavLink to="/resources">Resources</NavLink></li>
            <li><NavLink to="/faq">FAQ</NavLink></li>
          </ul>
        </div>
        <div>
          <h4>Legal</h4>
          <ul>
            <li><NavLink to="/privacy">Privacy Policy</NavLink></li>
            <li><NavLink to="/cookies">Cookies</NavLink></li>
            <li><NavLink to="/terms">Terms</NavLink></li>
            <li><NavLink to="/robots.txt">Robots.txt</NavLink></li>
            <li><NavLink to="/sitemap.xml">Sitemap</NavLink></li>
          </ul>
        </div>
        <div>
          <h4>Contact</h4>
          <address>
            Av. 9 de Julio 1000<br />
            C1043 Buenos Aires, Argentina<br />
            <a href="tel:+541155551234">+54 11 5555-1234</a>
          </address>
          <p>
            <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
          </p>
          <div className="social-links" aria-label="Social media">
            <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
            <a href="https://twitter.com" target="_blank" rel="noreferrer">X</a>
            <a href="https://www.youtube.com" target="_blank" rel="noreferrer">YouTube</a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>Análisis transparentes y datos de mercado para decidir con seguridad.</p>
        <p>© {currentYear} Tu Progreso Hoy. Buenos Aires, Argentina.</p>
      </div>
    </footer>
  );
};

export default Footer;
```