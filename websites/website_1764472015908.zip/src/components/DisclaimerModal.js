```javascript
import React, { useEffect, useState } from 'react';

const STORAGE_KEY = 'tph-disclaimer-ack';

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setOpen(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    localStorage.setItem(STORAGE_KEY, 'acknowledged');
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="modal-card">
        <h2 id="disclaimer-title">Important</h2>
        <p>Мы не предоставляем финансовые услуги.</p>
        <p>We do not provide financial services.</p>
        <p>No brindamos servicios financieros.</p>
        <p className="smallprint">
          Tu Progreso Hoy es un entorno educativo. La información se ofrece para tu aprendizaje personal
          y nunca reemplaza asesoramiento profesional.
        </p>
        <button className="btn primary" onClick={handleClose}>
          Understood
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;
```