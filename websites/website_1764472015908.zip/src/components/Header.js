```javascript
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/inflation', label: 'Inflation' },
    { path: '/course', label: 'Course' },
    { path: '/resources', label: 'Resources' },
    { path: '/contact', label: 'Contact' },
    { path: '/faq', label: 'FAQ' }
  ];

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header" role="banner">
      <div className="header-inner">
        <div className="brand-block">
          <NavLink to="/" className="brand" onClick={closeMenu}>
            <span className="brand-mark" aria-hidden="true">TPH</span>
            <span className="brand-text">
              Tu Progreso Hoy
              <span className="brand-sub">Argentina • Insights & Learning</span>
            </span>
          </NavLink>
        </div>
        <button
          className="menu-toggle"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
        >
          <span className="sr-only">{menuOpen ? 'Close menu' : 'Open menu'}</span>
          <span className="menu-icon" aria-hidden="true"></span>
        </button>
        <nav
          id="primary-navigation"
          className={`primary-nav ${menuOpen ? 'open' : ''}`}
          aria-label="Primary navigation"
        >
          <ul>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) => (isActive ? 'active' : undefined)}
                  onClick={closeMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
          <div className="language-note" aria-label="Languages">
            <span className="language-badge">EN</span>
            <span className="language-badge secondary">ES</span>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
```