```javascript
import React, { useEffect, useState } from 'react';

const STORAGE_KEY = 'tph-cookie-consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div>
        <h4>Cookies & Preferences</h4>
        <p>
          We use analytical cookies to understand argentina inflation interests and improve the course experience.
          Please choose whether we can enable optional analytics.
        </p>
      </div>
      <div className="cookie-actions">
        <button type="button" className="btn secondary" onClick={() => handleConsent('declined')}>
          Decline
        </button>
        <button type="button" className="btn primary" onClick={() => handleConsent('accepted')}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;
```