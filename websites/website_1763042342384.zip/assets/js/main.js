document.addEventListener('DOMContentLoaded', () => {
    window.scrollTo(0, 0);

    const navToggle = document.querySelector('.nav-toggle');
    const mainNavigation = document.querySelector('.main-navigation');
    const navLinks = document.querySelectorAll('.main-navigation a');
    const scrollTopBtn = document.getElementById('scrollTopBtn');
    const contactForm = document.getElementById('contactForm');
    const formFeedback = document.querySelector('.form-feedback');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const yearSpan = document.getElementById('year');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && mainNavigation) {
        navToggle.addEventListener('click', () => {
            mainNavigation.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            mainNavigation.classList.remove('open');
        });
    });

    window.addEventListener('scroll', () => {
        if (window.scrollY > 200) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (contactForm && formFeedback) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const values = Object.fromEntries(formData.entries());

            if (!values.name || !values.email || !values.message) {
                formFeedback.textContent = 'Bitte füllen Sie alle Felder aus.';
                formFeedback.style.color = '#C62828';
                return;
            }

            contactForm.reset();
            formFeedback.textContent = 'Vielen Dank! Wir melden uns mit neuen Möglichkeiten für Ihre Zukunft.';
            formFeedback.style.color = '#1B5E20';
        });
    }

    if (cookieBanner && acceptCookiesBtn) {
        const cookieConsent = localStorage.getItem('eltravaCookieConsent');

        if (!cookieConsent) {
            cookieBanner.classList.add('active');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('eltravaCookieConsent', 'accepted');
            cookieBanner.classList.remove('active');
        });
    }
});