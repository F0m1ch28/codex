import { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import ProductCard from '../components/ProductCard';
import styles from './CatalogPage.module.css';

const bannerItems = [
  {
    id: 1,
    category: 'Баннер',
    title: 'Шапка YouTube-канала с адаптивной сеткой',
    subtitle: 'Выверенные зоны безопасности и вариативность слоганов для разных кампаний.',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80',
    alt: 'Шапка YouTube-канала',
    description:
      'Разработана под канал, освещающий технологические тренды. Есть адаптации для смартфонов, планшетов и ТВ.',
  },
  {
    id: 2,
    category: 'Баннер',
    title: 'Промо-баннер для стримингового марафона',
    subtitle: 'Неоновые акценты, таймер и блок партнёров для Twitch и Discord.',
    image: 'https://images.unsplash.com/photo-1520072959219-c595dc870360?auto=format&fit=crop&w=900&q=80',
    alt: 'Промо баннер стримов',
    description:
      'Сериализованный пакет для серии трансляций. Включены вариации для социальных сетей, экранов ожидания и офлайн-печати.',
  },
  {
    id: 3,
    category: 'Баннер',
    title: 'Корпоративный баннер для LinkedIn и VK',
    subtitle: 'Структурированный лейаут с акцентом на ценностное предложение.',
    image: 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=900&q=80',
    alt: 'Корпоративный баннер',
    description:
      'Помогает выделить команду и описать ключевые услуги. Поддерживает смену текстовых блоков без изменения композиции.',
  },
  {
    id: 4,
    category: 'Баннер',
    title: 'Комплект графики для Twitch-канала',
    subtitle: 'Экран ожидания, переходы и панель донатов в едином стиле.',
    image: 'https://images.unsplash.com/photo-1573496774426-fe3db3dd1736?auto=format&fit=crop&w=900&q=80',
    alt: 'Графика Twitch канала',
    description:
      'Содержит статичные и анимированные версии. Проект создан для киберспортивного студийного шоу с расписанием.',
  },
  {
    id: 5,
    category: 'Баннер',
    title: 'Баннер для Telegram-канала бренда',
    subtitle: 'Мягкие градиенты, иллюстрации и отдельные адаптации для постов.',
    image: 'https://images.unsplash.com/photo-1526481280695-3c46977dda98?auto=format&fit=crop&w=900&q=80',
    alt: 'Баннер для Telegram',
    description:
      'Разработан для digital-продукта. В комплекте есть версии для закреплённого сообщения и превью в веб-версии.',
  },
  {
    id: 6,
    category: 'Баннер',
    title: 'Баннер для афиши онлайн-конференции',
    subtitle: 'Инфографика, коллаж спикеров и визуализированный таймлайн событий.',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=900&q=80',
    alt: 'Баннер онлайн конференции',
    description:
      'Комплекс адаптаций для сайтов, социальных сетей и email-рассылок. Легко обновляется под новые даты и спикеров.',
  },
];

const BannersPage = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  return (
    <>
      <PageHelmet
        title="Баннеры и шапки | DigitalCover"
        description="Баннеры и шапки для YouTube, Twitch и соцсетей. Визуальная айдентика, адаптивные сетки и поддержка DigitalCover."
      />
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Баннеры и шапки</h1>
          <p>
            Создаём кроссплатформенные баннеры и шапки, которые корректно отображаются на любых
            устройствах. Добавляем графику для акций, расписания и партнёрских интеграций.
          </p>
        </header>
        <div className={styles.grid}>
          {bannerItems.map((product) => (
            <ProductCard key={product.id} product={product} onMore={setSelectedProduct} />
          ))}
        </div>
      </div>
      {selectedProduct && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true">
          <div className={styles.modal}>
            <h2>{selectedProduct.title}</h2>
            <p>{selectedProduct.description}</p>
            <button type="button" onClick={() => setSelectedProduct(null)}>
              Закрыть
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default BannersPage;