import { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import ProductCard from '../components/ProductCard';
import styles from './CatalogPage.module.css';

const videoCovers = [
  {
    id: 1,
    category: 'YouTube',
    title: 'Кинематографичная обложка для документалистики',
    subtitle: 'Глубокий светотеневой контраст, драматические заголовки и аккуратный тейпинг.',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80',
    alt: 'Кинематографичная обложка для документального видео',
    description:
      'Обложка, созданная для сериала про путешествия. Акцент на крупном портрете и драматичном освещении, что усиливает чувство присутствия и интригу.',
  },
  {
    id: 2,
    category: 'YouTube',
    title: 'Геймерская обложка с неоновыми акцентами',
    subtitle: 'Маскотный герой, динамические линии и яркая неоновая палитра.',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80',
    alt: 'Неоновая игровая обложка',
    description:
      'Подходит для игровых роликов и обзоров. Мы используем фирменные цвета канала и добавляем внимание к читабельности заголовков.',
  },
  {
    id: 3,
    category: 'YouTube',
    title: 'Минималистичная обложка для образовательного контента',
    subtitle: 'Чёткая типографика и спокойные цветовые акценты для подчёркивания экспертности.',
    image: 'https://images.unsplash.com/photo-1522199755839-a2bacb67c546?auto=format&fit=crop&w=900&q=80',
    alt: 'Минималистичная образовательная обложка',
    description:
      'Разработана для курса по аналитике. В фокусе — структурированная подача и ясный визуальный язык, который соответствует бренду клиента.',
  },
  {
    id: 4,
    category: 'YouTube',
    title: 'Обложка для интервью с динамичным коллажем',
    subtitle: 'Комбинация нескольких портретов, геометрии и градиентов для привлечения внимания.',
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80',
    alt: 'Динамичная обложка для интервью',
    description:
      'Дизайн рассчитан на форматы интервью и подкастов. Включает вариативность расположения объектов под гостей выпуска.',
  },
  {
    id: 5,
    category: 'YouTube',
    title: 'Серия обложек для travel-блога',
    subtitle: 'Воздушные градиенты, крупные географические подписи и атмосферные кадры.',
    image: 'https://images.unsplash.com/photo-1531498860502-7c67cf02f77b?auto=format&fit=crop&w=900&q=80',
    alt: 'Обложка для travel видео',
    description:
      'Мы используем фирменный сет из трёх цветовых настроений, чтобы выпускать серии роликов и сохранять визуальную целостность.',
  },
  {
    id: 6,
    category: 'YouTube',
    title: 'Экспертный обзор с акцентом на продукт',
    subtitle: 'Чистый фон, крупные рендеры продукта и понятные маркеры преимуществ.',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80',
    alt: 'Обложка для обзора продукта',
    description:
      'Дизайн создан для технологичного канала. Включает брендинг клиента и адаптивен для разных цветовых решений.',
  },
];

const VideoCoversPage = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  return (
    <>
      <PageHelmet
        title="Каталог обложек для видео | DigitalCover"
        description="Коллекция обложек для YouTube и других платформ. Создано DigitalCover для привлечения внимания и повышения CTR."
      />
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Обложки для видео</h1>
          <p>
            Выберите дизайн из готовой коллекции или закажите индивидуальную серию. Мы адаптируем
            композиции под тематику канала, добавим фирменную графику и подготовим шаблоны для
            дальнейшего использования.
          </p>
        </header>
        <div className={styles.grid}>
          {videoCovers.map((product) => (
            <ProductCard key={product.id} product={product} onMore={setSelectedProduct} />
          ))}
        </div>
      </div>
      {selectedProduct && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true">
          <div className={styles.modal}>
            <h2>{selectedProduct.title}</h2>
            <p>{selectedProduct.description}</p>
            <button type="button" onClick={() => setSelectedProduct(null)}>
              Закрыть
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default VideoCoversPage;