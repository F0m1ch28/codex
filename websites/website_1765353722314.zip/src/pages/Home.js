import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import styles from './Home.module.css';

const HomePage = () => {
  const [activeProjectFilter, setActiveProjectFilter] = useState('all');
  const [activeFaq, setActiveFaq] = useState(null);
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const categories = useMemo(
    () => [
      {
        id: 'video',
        title: 'Обложки для видео',
        description: 'Создаём кликабельные обложки для YouTube, Rutube и других платформ.',
        link: '/catalog/video-covers',
        image: 'https://images.unsplash.com/photo-1526481280695-3c46977dda98?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 'avatars',
        title: 'Аватарки',
        description: 'Персональные и командные аватарки с профессиональной ретушью и графикой.',
        link: '/catalog/avatars',
        image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 'banners',
        title: 'Баннеры для соцсетей',
        description: 'Шапки каналов, баннеры для Twitch и промо-ленты социальных сетей.',
        link: '/catalog/banners',
        image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=900&q=80',
      },
    ],
    []
  );

  const galleryItems = useMemo(
    () => [
      {
        id: 1,
        label: 'YouTube Gaming',
        image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 2,
        label: 'Подкаст',
        image: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 3,
        label: 'Twitch Overlay',
        image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 4,
        label: 'Instagram Reel',
        image: 'https://images.unsplash.com/photo-1526318896980-cf78c088247c?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 5,
        label: 'Promo Banner',
        image: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 6,
        label: 'Streaming Cover',
        image: 'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 7,
        label: 'Event Branding',
        image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=900&q=80',
      },
      {
        id: 8,
        label: 'Esports Team',
        image: 'https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&w=900&q=80',
      },
    ],
    []
  );

  const stats = useMemo(
    () => [
      { id: 1, value: '1200+', label: 'выполненных проектов для блогеров и брендов' },
      { id: 2, value: '48 ч', label: 'среднее время на разработку готового дизайна' },
      { id: 3, value: '5.0', label: 'оценка клиентов по внутренним опросам' },
      { id: 4, value: '24/7', label: 'поддержка и сопровождение заказов' },
    ],
    []
  );

  const benefitItems = useMemo(
    () => [
      {
        id: 1,
        icon: '✨',
        title: 'Уникальный почерк',
        text: 'Каждая работа проходит индивидуальную художественную обработку и проверку арт-директором.',
      },
      {
        id: 2,
        icon: '⚡',
        title: 'Сжатые сроки',
        text: 'Работаем без выходных и привлекаем дополнительную команду для срочных проектов.',
      },
      {
        id: 3,
        icon: '💬',
        title: 'Диалог с дизайнером',
        text: 'Вы общаетесь напрямую с дизайнером, чтобы оперативно вносить корректировки.',
      },
      {
        id: 4,
        icon: '🧩',
        title: 'Готовность к редактированию',
        text: 'Все исходники поставляются в удобных форматах и слоях для дальнейшего обновления.',
      },
    ],
    []
  );

  const processSteps = useMemo(
    () => [
      {
        id: 1,
        title: 'Выберите дизайн',
        description:
          'Просмотрите каталоги, добавьте понравившиеся макеты в заявку или отправьте референсы своего стиля.',
      },
      {
        id: 2,
        title: 'Оформите заказ',
        description:
          'Оставьте контактные данные и получите персональную консультацию менеджера в течение часа.',
      },
      {
        id: 3,
        title: 'Получите файлы',
        description:
          'Мы готовим финальные версии в PNG, JPG и исходниках PSD/Figma. Передача происходит по защищённой ссылке.',
      },
    ],
    []
  );

  const projectItems = useMemo(
    () => [
      {
        id: 1,
        category: 'YouTube',
        tag: 'YouTube',
        title: 'Серия обложек для документального канала “Сфера”',
        description: 'Цель — повысить CTR и подчеркнуть глубину сюжетов. Использованы драматичные композиции.',
        image: 'https://images.unsplash.com/photo-1522199997018-9f42d4180c4b?auto=format&fit=crop&w=1100&q=80',
      },
      {
        id: 2,
        category: 'Twitch',
        tag: 'Twitch',
        title: 'Фирменный стиль стримера NiteWave',
        description: 'Разработали динамичный пакет: шапка, экран ожидания и виджеты для донатов.',
        image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1100&q=80',
      },
      {
        id: 3,
        category: 'Social',
        tag: 'Social',
        title: 'Баннеры для марафона по фитнесу “Restart”',
        description: 'Серия баннеров для VK и Telegram с анимационными вариантами для сторис.',
        image: 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1100&q=80',
      },
      {
        id: 4,
        category: 'YouTube',
        tag: 'YouTube',
        title: 'Обновление визуала игрового канала LevelBoost',
        description: 'Контрастные неоновые акценты и узнаваемая маскотная графика.',
        image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=1100&q=80',
      },
      {
        id: 5,
        category: 'Social',
        tag: 'Social',
        title: 'Серия превью для Reels бренда косметики Aurora',
        description: 'Нежная градиентная палитра и интеграция 3D-элементов для привлечения внимания.',
        image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=1100&q=80',
      },
      {
        id: 6,
        category: 'Twitch',
        tag: 'Twitch',
        title: 'Анимационный пакет трансляций для киберспортивной студии',
        description: 'Создали унифицированный стиль для матчей и аналитических шоу.',
        image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1100&q=80',
      },
    ],
    []
  );

  const testimonials = useMemo(
    () => [
      {
        id: 1,
        quote:
          'Благодаря DigitalCover мы обновили весь визуал за одну неделю. Команда предложила смелые решения и быстро реагировала на фидбек.',
        author: 'Анна Мельникова',
        role: 'Продюсер канала “Умный Разговор”',
        avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80',
      },
      {
        id: 2,
        quote:
          'CTR вырос почти вдвое после редизайна обложек. Отдельное спасибо за подробные инструкции по самостоятельному обновлению слоёв.',
        author: 'Дмитрий Корнеев',
        role: 'Автор канала “TechSense”',
        avatar: 'https://images.unsplash.com/photo-1554151228-14d9def656e4?auto=format&fit=crop&w=200&q=80',
      },
      {
        id: 3,
        quote:
          'Мы получили полностью готовый бренд-пак для Twitch: интро, переходы, кастомные алерты. Всё соответствует нашему гайдлайну.',
        author: 'Instream Studio',
        role: 'Команда продюсеров стримингов',
        avatar: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80',
      },
    ],
    []
  );

  const faqs = useMemo(
    () => [
      {
        id: 1,
        question: 'Какие материалы нужны для старта работы?',
        answer:
          'Достаточно краткого описания задач, желаемых платформ и референсов. Мы сами предложим несколько стилистик и согласуем финальную концепцию.',
      },
      {
        id: 2,
        question: 'Можно ли адаптировать дизайн под разные языки?',
        answer:
          'Да, мы заранее делаем текстовые слои гибкими, чтобы вы могли легко переводить подписи и заменять контент без потери качества.',
      },
      {
        id: 3,
        question: 'Как происходит передача исходников?',
        answer:
          'Все файлы загружаются в защищённое облако с доступом по ссылке. Вы получаете исходники, готовые форматы и инструкцию по применению.',
      },
      {
        id: 4,
        question: 'Есть ли поддержка после завершения проекта?',
        answer:
          'Мы остаёмся на связи и помогаем с небольшими доработками в течение 14 дней после сдачи проекта. Долгосрочная поддержка оговаривается отдельно.',
      },
    ],
    []
  );

  const visibleProjects = projectItems.filter(
    (project) => activeProjectFilter === 'all' || project.category === activeProjectFilter
  );

  const handleNextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
  };

  const handlePrevTestimonial = () => {
    setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <>
      <PageHelmet
        title="DigitalCover — профессиональные обложки, аватарки и баннеры для контента"
        description="DigitalCover создаёт обложки для видео, аватарки и баннеры для YouTube, Twitch и социальных сетей. Уникальный дизайн, быстрая доставка и поддержка 24/7."
      />
      <div className={styles.page}>
        <section className={styles.hero}>
          <div className={styles.heroGlow} aria-hidden="true" />
          <div className={styles.heroInner}>
            <div className={styles.heroContent}>
              <span className={styles.heroBadge}>DigitalCover Studio</span>
              <h1>Профессиональный дизайн для вашего контента</h1>
              <p>
                Разрабатываем обложки, аватарки и баннеры, которые повышают вовлечённость аудитории и
                формируют узнаваемый образ бренда. Доверьте визуал команде, работающей с ведущими
                блогерами и студиями.
              </p>
              <div className={styles.heroActions}>
                <Link to="/catalog/video-covers" className="ctaButton">
                  Смотреть каталог
                </Link>
                <Link to="/how-it-works" className="ctaButton" style={{ background: 'rgba(248,249,250,0.2)' }}>
                  Как мы работаем
                </Link>
              </div>
            </div>
            <div className={styles.heroImageWrap}>
              <img
                src="https://images.unsplash.com/photo-1522008342704-8f23fd107a3d?auto=format&fit=crop&w=1400&q=80"
                alt="Коллаж с яркими цифровыми обложками и баннерами"
              />
            </div>
          </div>
        </section>

        <section className={styles.categories} aria-labelledby="categories-title">
          <h2 id="categories-title" className="sectionTitle">
            Категории цифровых работ
          </h2>
          <p className="sectionSubtitle">
            Смотрите готовые решения и заказывайте индивидуальные макеты под ваши каналы, стримы или
            рекламные кампании.
          </p>
          <div className={styles.categoryGrid}>
            {categories.map((item) => (
              <Link key={item.id} to={item.link} className={styles.categoryCard}>
                <img src={item.image} alt={`Превью категории ${item.title}`} loading="lazy" />
                <div className={styles.categoryContent}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                  <span className={styles.categoryLink}>
                    Открыть <span aria-hidden="true">→</span>
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className={styles.gallery} aria-labelledby="gallery-title">
          <div className={styles.galleryInner}>
            <h2 id="gallery-title" className="sectionTitle">
              Популярные работы
            </h2>
            <p className="sectionSubtitle">
              Подборка свежих проектов из каталога DigitalCover — от мощных обложек для видеороликов до
              баннеров для стриминговых студий.
            </p>
            <div className={styles.galleryGrid}>
              {galleryItems.map((item) => (
                <figure key={item.id} className={styles.galleryItem}>
                  <img src={item.image} alt={`Пример дизайна: ${item.label}`} loading="lazy" />
                  <span>{item.label}</span>
                </figure>
              ))}
            </div>
          </div>
        </section>

        <section className={styles.stats} aria-labelledby="stats-title">
          <h2 id="stats-title" className="sectionTitle">
            DigitalCover в цифрах
          </h2>
          <p className="sectionSubtitle">
            Мы соединяем творческую свободу и выстроенные процессы, чтобы каждый проект был выполнен в
            срок и без компромиссов.
          </p>
          <div className={styles.statsGrid}>
            {stats.map((item) => (
              <article key={item.id} className={styles.statCard}>
                <strong className={styles.statValue}>{item.value}</strong>
                <span className={styles.statLabel}>{item.label}</span>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.benefits} aria-labelledby="benefits-title">
          <h2 id="benefits-title" className="sectionTitle">
            Почему клиенты выбирают нас
          </h2>
          <div className={styles.benefitsGrid}>
            {benefitItems.map((item) => (
              <article key={item.id} className={styles.benefitCard}>
                <span className={styles.benefitIcon} aria-hidden="true">
                  {item.icon}
                </span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.process} aria-labelledby="process-title">
          <h2 id="process-title" className="sectionTitle">
            Как это работает
          </h2>
          <div className={styles.processSteps}>
            {processSteps.map((step) => (
              <article key={step.id} className={styles.processStep}>
                <span>Шаг {step.id}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.projects} aria-labelledby="projects-title">
          <h2 id="projects-title" className="sectionTitle">
            Проекты DigitalCover
          </h2>
          <div className={styles.projectFilters}>
            {[
              { label: 'Все', value: 'all' },
              { label: 'YouTube', value: 'YouTube' },
              { label: 'Twitch', value: 'Twitch' },
              { label: 'Соцсети', value: 'Social' },
            ].map((filter) => (
              <button
                type="button"
                key={filter.value}
                className={`${styles.filterButton} ${
                  activeProjectFilter === filter.value ? styles.filterActive : ''
                }`}
                onClick={() => setActiveProjectFilter(filter.value)}
              >
                {filter.label}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {visibleProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectTag}>{project.tag}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.testimonials} aria-labelledby="testimonials-title">
          <h2 id="testimonials-title" className="sectionTitle">
            Отзывы партнёров
          </h2>
          <div className={styles.testimonialInner}>
            <blockquote className={styles.testimonialQuote}>
              “{testimonials[testimonialIndex].quote}”
            </blockquote>
            <div className={styles.testimonialAuthor}>
              <div className={styles.testimonialAvatar}>
                <img
                  src={testimonials[testimonialIndex].avatar}
                  alt={`Фото: ${testimonials[testimonialIndex].author}`}
                  loading="lazy"
                />
              </div>
              <div>
                <strong>{testimonials[testimonialIndex].author}</strong>
                <p>{testimonials[testimonialIndex].role}</p>
              </div>
            </div>
            <div className={styles.testimonialControls}>
              <button type="button" className={styles.controlButton} onClick={handlePrevTestimonial}>
                ←
              </button>
              <button type="button" className={styles.controlButton} onClick={handleNextTestimonial}>
                →
              </button>
            </div>
          </div>
        </section>

        <section className={styles.faq} aria-labelledby="faq-title">
          <h2 id="faq-title" className="sectionTitle">
            Вопросы и ответы
          </h2>
          <p className="sectionSubtitle">
            Если вы не нашли нужной информации, напишите нам в поддержку — мы ответим в течение 15
            минут.
          </p>
          <div>
            {faqs.map((item) => (
              <div key={item.id} className={styles.faqItem}>
                <div className={styles.faqHeader}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    aria-expanded={activeFaq === item.id}
                    onClick={() => setActiveFaq((prev) => (prev === item.id ? null : item.id))}
                  >
                    {item.question}
                  </button>
                  <span aria-hidden="true">{activeFaq === item.id ? '–' : '+'}</span>
                </div>
                {activeFaq === item.id && <p className={styles.faqBody}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </section>

        <section className={styles.blog} aria-labelledby="blog-title">
          <h2 id="blog-title" className="sectionTitle">
            Полезные материалы
          </h2>
          <div className={styles.blogGrid}>
            {[
              {
                id: 1,
                tag: 'Статья',
                title: '7 приёмов, которые увеличивают CTR обложек YouTube',
                image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80',
              },
              {
                id: 2,
                tag: 'Гайд',
                title: 'Как подготовить техническое задание для дизайна Twitch-канала',
                image: 'https://images.unsplash.com/photo-1526991772501-b98c1e04ed15?auto=format&fit=crop&w=900&q=80',
              },
              {
                id: 3,
                tag: 'Интервью',
                title: 'Как мы создавали визуал для онлайн-шоу с прямыми эфирами',
                image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=900&q=80',
              },
            ].map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <span className={styles.blogTag}>{post.tag}</span>
                  <h3>{post.title}</h3>
                  <p>Короткий обзор с практическими рекомендациями для авторов и продюсеров.</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.cta} aria-labelledby="cta-title">
          <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1600&q=80" alt="" aria-hidden="true" />
          <div className={styles.ctaInner}>
            <h2 id="cta-title">Начните выделяться уже сегодня</h2>
            <p>
              Оставьте заявку на консультацию и получите подборку концепций, которые точно попадут к вам в
              сердечные рекомендации. Мы подготовим три стилистических направления в течение суток.
            </p>
            <Link to="/contacts" className="ctaButton">
              Связаться с нами
            </Link>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;