import PageHelmet from '../components/PageHelmet';
import styles from './About.module.css';

const AboutPage = () => (
  <>
    <PageHelmet
      title="О компании DigitalCover"
      description="DigitalCover — команда дизайнеров, создающих цифровые обложки, аватарки и баннеры для международных брендов и авторов."
    />
    <div className={styles.page}>
      <section className={styles.intro} aria-labelledby="about-title">
        <h1 id="about-title">DigitalCover — команда визуальных стратегов</h1>
        <p>
          Мы объединяем дизайнеров, иллюстраторов, motion-artist и редакторов, чтобы создавать
          цифровой контент, который выделяет бренды и авторов на международной арене. За пять лет мы
          сформировали глубокую экспертизу в оформлении видеоконтента, стримингов и социальных сетей.
        </p>
      </section>

      <section aria-labelledby="about-values">
        <h2 id="about-values" className="sectionTitle">
          Что лежит в основе нашей работы
        </h2>
        <div className={styles.values}>
          <article className={styles.valueCard}>
            <strong>Дизайн, опирающийся на аналитику</strong>
            <p>
              Мы анализируем поведение аудитории и тренды площадок, чтобы каждый визуал решал конкретную
              задачу: рост просмотров, удержание или узнаваемость.
            </p>
          </article>
          <article className={styles.valueCard}>
            <strong>Партнёрский подход</strong>
            <p>
              Вы получаете команду, которая знает тонкости платформ и берёт ответственность за весь цикл:
              от концепции до финальной выдачи.
            </p>
          </article>
          <article className={styles.valueCard}>
            <strong>Международный фокус</strong>
            <p>
              Мы работаем с клиентами из СНГ, Европы и США. Владеем английским и испанским для комфортной
              коммуникации с международными командами.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.timeline} aria-labelledby="timeline-title">
        <h2 id="timeline-title">История DigitalCover</h2>
        <div className={styles.timelineItem}>
          <span>2018</span>
          <p>Основание студии и первые проекты для авторов YouTube.</p>
        </div>
        <div className={styles.timelineItem}>
          <span>2020</span>
          <p>Запуск собственного каталога готовых решений и расширение команды до 12 специалистов.</p>
        </div>
        <div className={styles.timelineItem}>
          <span>2021</span>
          <p>Выход на международный рынок: сотрудничество с подкастами и игровыми студиями из США.</p>
        </div>
        <div className={styles.timelineItem}>
          <span>2023</span>
          <p>Создание закрытого клуба для авторов с ежемесячными визуальными обновлениями.</p>
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-title">
        <h2 id="team-title" className="sectionTitle">
          Команда DigitalCover
        </h2>
        <div className={styles.teamGrid}>
          {[
            {
              id: 1,
              name: 'Кира Осипова',
              role: 'Арт-директор',
              bio: 'Руководит визуальными стратегиями, курирует качество финальных макетов.',
              image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
            },
            {
              id: 2,
              name: 'Лео Громов',
              role: 'Lead Designer',
              bio: 'Специалист по YouTube- и Twitch-дизайну. Настраивает адаптивные сетки и анимацию.',
              image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=600&q=80',
            },
            {
              id: 3,
              name: 'Соня Мельникова',
              role: 'Иллюстратор',
              bio: 'Создаёт ручные иллюстрации, маскоты и пакет эмоутов для комьюнити.',
              image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=600&q=80',
            },
            {
              id: 4,
              name: 'Марк Власов',
              role: 'Motion-дизайнер',
              bio: 'Отвечает за анимированные заставки, переходы и интерактивные элементы.',
              image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=600&q=80',
            },
          ].map((member) => (
            <article key={member.id} className={styles.teamCard}>
              <img src={member.image} alt={member.name} loading="lazy" />
              <strong>{member.name}</strong>
              <span className={styles.teamRole}>{member.role}</span>
              <p className={styles.teamBio}>{member.bio}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.vision} aria-labelledby="vision-title">
        <h2 id="vision-title">Наше видение</h2>
        <p>
          Мы верим, что визуальная идентичность — это залог долгосрочного успеха бренда. DigitalCover
          продолжит развивать экосистему сервисов, чтобы обеспечить авторов и компании полным циклом
          визуального сопровождения, включая анализ, стратегию и поддержку комьюнити.
        </p>
      </section>
    </div>
  </>
);

export default AboutPage;