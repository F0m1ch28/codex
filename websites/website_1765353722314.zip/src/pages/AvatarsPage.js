import { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import ProductCard from '../components/ProductCard';
import styles from './CatalogPage.module.css';

const avatarItems = [
  {
    id: 1,
    category: 'Аватарка',
    title: 'Портретная аватарка в неоновой стилистике',
    subtitle: 'Световые акценты и геометрия вокруг персонажа для геймеров и стримеров.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=900&q=80',
    alt: 'Неоновая портретная аватарка',
    description:
      'Проработали персональные черты заказчика и интегрировали фирменный цвет канала, чтобы создать мгновенно узнаваемый образ.',
  },
  {
    id: 2,
    category: 'Аватарка',
    title: 'Минималистичная аватарка для бренда',
    subtitle: 'Чистая типографика и логотип в динамичной рамке для социальных сетей.',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=900&q=80',
    alt: 'Минималистичный брендовый логотип',
    description:
      'Созданная для образовательного проекта. В комплект входит набор из цветной и монохромной версии для разных платформ.',
  },
  {
    id: 3,
    category: 'Аватарка',
    title: 'Командный знак для киберспортивной студии',
    subtitle: 'Детализированный маскот и комплект фоновых паттернов.',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=900&q=80',
    alt: 'Командный знак с маскотом',
    description:
      'Маскот разработан с нуля по описанию команды. В комплект включены шевроны, иконки и различные адаптации.',
  },
  {
    id: 4,
    category: 'Аватарка',
    title: 'Иллюстрированная аватарка для подкаста',
    subtitle: 'Тёплые оттенки, иллюстрация ведущего и узнаваемые элементы шоу.',
    image: 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=900&q=80',
    alt: 'Иллюстрированная аватарка для подкаста',
    description:
      'Идеально подходит для подкастов и онлайн-шоу. Мы подготавливаем версии для квадратных и круглых размещений.',
  },
  {
    id: 5,
    category: 'Аватарка',
    title: 'Pixel-art аватарка для Twitch',
    subtitle: 'Ретро-пиксельный стиль с ограниченной палитрой и яркой подсветкой.',
    image: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&w=900&q=80',
    alt: 'Pixel-art портрет',
    description:
      'Для канала с ретро-стримами. Подготовлена анимированная версия и набор эмоутов в том же стиле.',
  },
  {
    id: 6,
    category: 'Аватарка',
    title: 'Фотографская аватарка с серийной обработкой',
    subtitle: 'Профессиональная ретушь, градиентные подсветки и фирменный фон.',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80',
    alt: 'Фотографская аватарка',
    description:
      'Подходит для экспертов и личных брендов. Создаём атмосферу доверия, добавляя мягкие градиенты и деликатную подсветку.',
  },
];

const AvatarsPage = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  return (
    <>
      <PageHelmet
        title="Каталог аватарок | DigitalCover"
        description="Персональные аватарки и логотипы для социальных сетей, стримеров и команд. DigitalCover — ваш визуальный стиль."
      />
      <div className={styles.page}>
        <header className={styles.header}>
          <h1>Аватарки и логотипы</h1>
          <p>
            Подчеркните индивидуальность или корпоративный стиль. Мы создаём аватарки на базе
            иллюстраций, фотоколлажа или пиксель-арта и адаптируем их под требования площадок.
          </p>
        </header>
        <div className={styles.grid}>
          {avatarItems.map((product) => (
            <ProductCard key={product.id} product={product} onMore={setSelectedProduct} />
          ))}
        </div>
      </div>
      {selectedProduct && (
        <div className={styles.modalOverlay} role="dialog" aria-modal="true">
          <div className={styles.modal}>
            <h2>{selectedProduct.title}</h2>
            <p>{selectedProduct.description}</p>
            <button type="button" onClick={() => setSelectedProduct(null)}>
              Закрыть
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default AvatarsPage;