import { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Contacts.module.css';

const ContactsPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Введите ваше имя.';
    if (!formData.email.trim()) {
      newErrors.email = 'Укажите email для обратной связи.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(formData.email)) {
      newErrors.email = 'Проверьте корректность email.';
    }
    if (!formData.message.trim() || formData.message.trim().length < 10) {
      newErrors.message = 'Расскажите подробнее о задаче (минимум 10 символов).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((state) => ({ ...state, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <>
      <PageHelmet
        title="Контакты DigitalCover"
        description="Связаться с DigitalCover: email, телефон, адрес. Оставьте заявку на дизайн обложек, аватарок и баннеров."
      />
      <div className={styles.page}>
        <section className={styles.intro} aria-labelledby="contacts-title">
          <h1 id="contacts-title">Свяжитесь с DigitalCover</h1>
          <p>
            Мы ответим на заявку в течение 15 минут в рабочее время и предложим удобный формат
            взаимодействия — письмо, звонок или чат в мессенджере.
          </p>
        </section>

        <div className={styles.content}>
          <section className={styles.details} aria-labelledby="contacts-details">
            <h2 id="contacts-details">Контактная информация</h2>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Email</span>
              <span>support@digitalcover.ru</span>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Телефон</span>
              <span>+7 (495) 123-45-67</span>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Адрес</span>
              <span>123456, г. Москва, ул. Цифровая, д. 1, офис 10</span>
            </div>
            <div className={styles.detailItem}>
              <span className={styles.detailLabel}>Часы поддержки</span>
              <span>Пн–Вс, 10:00–22:00 (MSK)</span>
            </div>
          </section>

          <section aria-labelledby="contacts-form" className={styles.form}>
            <h2 id="contacts-form">Оставьте заявку</h2>
            <form noValidate onSubmit={handleSubmit}>
              <div className={styles.field}>
                <label htmlFor="name">Имя</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Как к вам обращаться?"
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="example@mail.com"
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Сообщение</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Опишите проект, ссылку на канал или желаемую стилистику."
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className={styles.submit}>
                Отправить
              </button>
              {submitted && (
                <div className={styles.success}>
                  Спасибо! Мы получили вашу заявку и вскоре свяжемся с вами.
                </div>
              )}
            </form>
          </section>
        </div>
      </div>
    </>
  );
};

export default ContactsPage;