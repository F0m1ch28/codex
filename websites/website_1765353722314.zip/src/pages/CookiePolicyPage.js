import PageHelmet from '../components/PageHelmet';
import styles from './LegalPage.module.css';

const CookiePolicyPage = () => (
  <>
    <PageHelmet
      title="Политика cookie | DigitalCover"
      description="Политика использования cookie-файлов на сайте DigitalCover. Узнайте, какие технологии мы применяем."
    />
    <article className={styles.page}>
      <header>
        <h1>Политика использования cookie</h1>
        <p>
          DigitalCover использует cookie-файлы и аналогичные технологии для обеспечения корректной работы
          сайта, анализа и персонализации сервисов.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Что такое cookie</h2>
        <p>
          Cookie — это небольшие файлы, которые сохраняются на вашем устройстве при посещении сайта. Они
          помогают запомнить ваши настройки и улучшить удобство использования.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Какие cookie мы используем</h2>
        <ul>
          <li>Технические — обеспечивают стабильную работу сайта и безопасность.</li>
          <li>Аналитические — помогают понять, как пользователи взаимодействуют с контентом.</li>
          <li>Функциональные — запоминают ваши предпочтения для персонализации.</li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2>Как управлять cookie</h2>
        <p>
          Вы можете отключить или ограничить использование cookie в настройках браузера. Учтите, что некоторые
          функции сайта могут работать некорректно без cookie.
        </p>
      </section>
    </article>
  </>
);

export default CookiePolicyPage;