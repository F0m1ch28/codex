import PageHelmet from '../components/PageHelmet';
import styles from './LegalPage.module.css';

const PrivacyPage = () => (
  <>
    <PageHelmet
      title="Политика конфиденциальности | DigitalCover"
      description="Политика конфиденциальности DigitalCover описывает обработку персональных данных и меры безопасности."
    />
    <article className={styles.page}>
      <header>
        <h1>Политика конфиденциальности DigitalCover</h1>
        <p>
          Мы заботимся о безопасности персональных данных и используем информацию пользователей строго в
          рамках действующего законодательства.
        </p>
      </header>

      <section className={styles.section}>
        <h2>Какие данные мы собираем</h2>
        <ul>
          <li>Контактная информация: имя, email, номер телефона.</li>
          <li>Данные о проекте: ссылки на каналы, описания задач, референсы.</li>
          <li>Технические данные: cookies, IP-адрес, данные о браузере и устройстве.</li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2>Цели обработки</h2>
        <ul>
          <li>Ответ на запросы клиентов и предоставление услуг.</li>
          <li>Анализ и улучшение качества сервиса.</li>
          <li>Информирование о новых продуктах и обновлениях при наличии согласия.</li>
        </ul>
      </section>

      <section className={styles.section}>
        <h2>Защита данных</h2>
        <p>
          Мы используем современные средства защиты и ограничиваем доступ к данным сотрудников, для
          которых они необходимы. Передача данных третьим лицам возможна только по закону или с согласия
          пользователя.
        </p>
      </section>

      <section className={styles.section}>
        <h2>Обратная связь</h2>
        <p>
          По вопросам обработки данных свяжитесь с нами: support@digitalcover.ru. Мы ответим в течение 10
          рабочих дней.
        </p>
      </section>
    </article>
  </>
);

export default PrivacyPage;