import PageHelmet from '../components/PageHelmet';
import styles from './Services.module.css';

const ServicesPage = () => (
  <>
    <PageHelmet
      title="Сервисы DigitalCover"
      description="Комплексные сервисы DigitalCover: дизайн пакеты, сопровождение каналов и стратегические консультации."
    />
    <div className={styles.page}>
      <section className={styles.intro} aria-labelledby="services-title">
        <h1 id="services-title">Сервисы DigitalCover</h1>
        <p>
          Мы помогаем авторам и брендам развивать визуальную платформу на постоянной основе. Вы можете
          выбрать отдельные услуги или заказать комплексное сопровождение.
        </p>
      </section>

      <section aria-labelledby="services-grid">
        <h2 id="services-grid" className="sectionTitle">
          Основные направления
        </h2>
        <div className={styles.servicesGrid}>
          {[
            {
              icon: '🎨',
              title: 'Пакетное оформление канала',
              text: 'Обложки, шапка, аватарка, миниатюры для плейлистов и инфографика для видео.',
            },
            {
              icon: '📦',
              title: 'Готовые коллекции',
              text: 'Каталог готовых дизайнов с возможностью индивидуальной доработки под ваш бренд.',
            },
            {
              icon: '🧭',
              title: 'Аналитика и стратегия',
              text: 'Аудит текущего визуала, рекомендации по улучшению и план оптимизаций.',
            },
            {
              icon: '🎬',
              title: 'Motion-сопровождение',
              text: 'Анимационные заставки, переходы, интро и аутро для роликов и стримов.',
            },
          ].map((service) => (
            <article key={service.title} className={styles.serviceCard}>
              <span className={styles.serviceIcon} aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.bundle} aria-labelledby="bundle-title">
        <h2 id="bundle-title">Комплексное сопровождение бренда</h2>
        <p>
          Клиент получает выделенную команду, персонального менеджера и ежемесячный пакет обновлений.
          Мы отслеживаем метрики и адаптируем визуал под реакцию аудитории.
        </p>
        <ul className={styles.bundleItems}>
          <li>Ежемесячные обновления обложек и баннеров.</li>
          <li>Настройка визуала под специальные проекты и интеграции.</li>
          <li>Доступ к библиотеке шаблонов DigitalCover.</li>
          <li>Приоритетная поддержка и быстрые итерации.</li>
        </ul>
      </section>

      <section className={styles.support} aria-labelledby="support-title">
        <h2 id="support-title">Техническая поддержка</h2>
        <p>
          Мы остаёмся с вами на связи после завершения проекта. Поддерживаем визуал в актуальном
          состоянии, обновляем тексты и изображения, консультируем редакторов.
        </p>
        <div className={styles.supportGrid}>
          <div className={styles.supportCard}>
            <strong>24/7</strong>
            <p>Готовность ответить в любое время — учитываем часовые пояса клиентов.</p>
          </div>
          <div className={styles.supportCard}>
            <strong>Обучение команды</strong>
            <p>Проводим разборы и мастер-классы для ваших дизайнеров и монтажёров.</p>
          </div>
          <div className={styles.supportCard}>
            <strong>Гарантия качества</strong>
            <p>Пересматриваем архивные файлы и обновляем их под требования новых платформ.</p>
          </div>
        </div>
      </section>
    </div>
  </>
);

export default ServicesPage;