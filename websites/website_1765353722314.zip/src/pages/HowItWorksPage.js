import PageHelmet from '../components/PageHelmet';
import styles from './HowItWorks.module.css';

const HowItWorksPage = () => (
  <>
    <PageHelmet
      title="Как работает DigitalCover"
      description="Пошаговый процесс создания обложек, аватарок и баннеров в DigitalCover: от заявки до передачи файлов."
    />
    <div className={styles.page}>
      <section className={styles.intro} aria-labelledby="process-intro">
        <h1 id="process-intro">Процесс работы DigitalCover</h1>
        <p>
          Мы выстроили процесс так, чтобы каждый этап был прозрачным и предсказуемым. Вы всегда
          знаете, на какой стадии находится проект, и можете влиять на результат.
        </p>
      </section>

      <section className={styles.steps} aria-labelledby="steps-title">
        <h2 id="steps-title" className="sectionTitle">
          Шаги сотрудничества
        </h2>
        {[
          {
            id: 1,
            title: 'Заявка и бриф',
            text: 'Вы заполняете короткий бриф, отправляете референсы или ссылки на текущие материалы. Менеджер уточняет детали.',
          },
          {
            id: 2,
            title: 'Концепция и предварительные варианты',
            text: 'Дизайнеры готовят 2-3 варианта концепции. Обсуждаем правки, выбираем направление и утверждаем визуальный язык.',
          },
          {
            id: 3,
            title: 'Производство финальных макетов',
            text: 'Создаём финальные версии, подготавливаем адаптации и тестируем отображение на нужных устройствах.',
          },
          {
            id: 4,
            title: 'Передача исходников и поддержка',
            text: 'Выгружаем итоговые файлы, даём инструкции и остаёмся на связи для адаптаций или новых задач.',
          },
        ].map((step) => (
          <article key={step.id} className={styles.step}>
            <div className={styles.stepHeader}>
              <span className={styles.stepNumber}>{step.id}</span>
              <h3>{step.title}</h3>
            </div>
            <p>{step.text}</p>
          </article>
        ))}
      </section>

      <section className={styles.timeline} aria-labelledby="timeline-process">
        <h2 id="timeline-process">Сроки и взаимодействие</h2>
        <div className={styles.timelineRow}>
          <strong>До 24 часов:</strong>
          <span>Первая связь, уточнение брифа, старт работы над концепциями.</span>
        </div>
        <div className={styles.timelineRow}>
          <strong>2–4 дня:</strong>
          <span>Подготовка превью и обсуждение правок, подтверждение финального направления.</span>
        </div>
        <div className={styles.timelineRow}>
          <strong>5–7 дней:</strong>
          <span>Сдача готовых макетов, согласование адаптаций и подготовка исходников.</span>
        </div>
      </section>

      <section aria-labelledby="extra-support">
        <h2 id="extra-support" className="sectionTitle">
          Дополнительные услуги
        </h2>
        <div className={styles.extras}>
          <article className={styles.extraCard}>
            <h3>Контент-план визуала</h3>
            <p>Составим расписание обновлений, чтобы вы всегда публиковали свежие обложки и баннеры.</p>
          </article>
          <article className={styles.extraCard}>
            <h3>Motion-графика</h3>
            <p>Анимированные заставки, переходы и экраны ожидания для прямых эфиров и роликов.</p>
          </article>
          <article className={styles.extraCard}>
            <h3>Гайд по стилю</h3>
            <p>Документируем визуальный язык, цветовую палитру и типографику для масштабирования бренда.</p>
          </article>
        </div>
      </section>
    </div>
  </>
);

export default HowItWorksPage;