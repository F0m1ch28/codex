import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTopButton, { RouteScrollRestoration } from './components/ScrollToTop';
import HomePage from './pages/Home';
import VideoCoversPage from './pages/VideoCoversPage';
import AvatarsPage from './pages/AvatarsPage';
import BannersPage from './pages/BannersPage';
import AboutPage from './pages/AboutPage';
import HowItWorksPage from './pages/HowItWorksPage';
import ServicesPage from './pages/ServicesPage';
import ContactsPage from './pages/ContactsPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';

function App() {
  return (
    <div className="app">
      <RouteScrollRestoration />
      <Header />
      <main className="mainContent" role="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/catalog/video-covers" element={<VideoCoversPage />} />
          <Route path="/catalog/avatars" element={<AvatarsPage />} />
          <Route path="/catalog/banners" element={<BannersPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/how-it-works" element={<HowItWorksPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/contacts" element={<ContactsPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTopButton />
      <CookieBanner />
    </div>
  );
}

export default App;