import PropTypes from 'prop-types';
import styles from './ProductCard.module.css';

const ProductCard = ({ product, onMore }) => (
  <article className={styles.card}>
    <div className={styles.imageWrapper}>
      <img src={product.image} alt={product.alt} loading="lazy" />
    </div>
    <div className={styles.content}>
      <span className={styles.category}>{product.category}</span>
      <h3 className={styles.title}>{product.title}</h3>
      <p>{product.subtitle}</p>
      <button type="button" className={styles.button} onClick={() => onMore(product)}>
        Подробнее
      </button>
    </div>
  </article>
);

ProductCard.propTypes = {
  product: PropTypes.shape({
    image: PropTypes.string,
    alt: PropTypes.string,
    category: PropTypes.string,
    title: PropTypes.string,
    subtitle: PropTypes.string,
  }).isRequired,
  onMore: PropTypes.func.isRequired,
};

export default ProductCard;