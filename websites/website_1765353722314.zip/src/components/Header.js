import { useState, useRef, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [catalogOpen, setCatalogOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setCatalogOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [mobileOpen]);

  return (
    <header className={styles.header} role="banner">
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} aria-label="DigitalCover — на главную">
          <span className={styles.logoBadge}>DC</span>
          <span>DigitalCover</span>
        </Link>
        <nav className={styles.nav} aria-label="Основная навигация">
          <ul className={styles.navList}>
            <li className={styles.navItem}>
              <NavLink
                to="/"
                end
                className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              >
                Главная
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <div
                className={styles.dropdownWrapper}
                ref={dropdownRef}
                onMouseEnter={() => setCatalogOpen(true)}
                onMouseLeave={() => setCatalogOpen(false)}
              >
                <button
                  className={styles.dropdownToggle}
                  type="button"
                  aria-haspopup="true"
                  aria-expanded={catalogOpen}
                  onClick={() => setCatalogOpen((prev) => !prev)}
                >
                  Каталоги
                  <span aria-hidden="true">▾</span>
                </button>
                <div className={`${styles.dropdownMenu} ${catalogOpen ? styles.dropdownOpen : ''}`}>
                  <NavLink
                    to="/catalog/video-covers"
                    className={({ isActive }) =>
                      `${styles.dropdownLink} ${isActive ? styles.active : ''}`
                    }
                  >
                    Обложки для видео
                  </NavLink>
                  <NavLink
                    to="/catalog/avatars"
                    className={({ isActive }) =>
                      `${styles.dropdownLink} ${isActive ? styles.active : ''}`
                    }
                  >
                    Аватарки
                  </NavLink>
                  <NavLink
                    to="/catalog/banners"
                    className={({ isActive }) =>
                      `${styles.dropdownLink} ${isActive ? styles.active : ''}`
                    }
                  >
                    Баннеры и шапки
                  </NavLink>
                </div>
              </div>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/about"
                className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              >
                О нас
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/how-it-works"
                className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              >
                Как это работает
              </NavLink>
            </li>
            <li className={styles.navItem}>
              <NavLink
                to="/contacts"
                className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              >
                Контакты
              </NavLink>
            </li>
          </ul>
        </nav>
        <div className={styles.actions}>
          <button className={styles.iconButton} type="button" aria-label="Перейти в корзину">
            🛒
          </button>
          <button className={styles.iconButton} type="button" aria-label="Открыть профиль">
            👤
          </button>
        </div>
        <button
          className={styles.mobileToggle}
          type="button"
          aria-label="Меню"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((prev) => !prev)}
        >
          {mobileOpen ? '✕' : '☰'}
        </button>
      </div>
      {mobileOpen && (
        <div className={styles.mobileMenu} role="dialog" aria-label="Мобильное меню">
          <NavLink to="/" end onClick={() => setMobileOpen(false)}>
            Главная
          </NavLink>
          <button type="button" onClick={() => setCatalogOpen((prev) => !prev)}>
            Каталоги {catalogOpen ? '▲' : '▼'}
          </button>
          {catalogOpen && (
            <div className={styles.mobileDropdownGroup}>
              <NavLink to="/catalog/video-covers" onClick={() => setMobileOpen(false)}>
                Обложки для видео
              </NavLink>
              <NavLink to="/catalog/avatars" onClick={() => setMobileOpen(false)}>
                Аватарки
              </NavLink>
              <NavLink to="/catalog/banners" onClick={() => setMobileOpen(false)}>
                Баннеры и шапки
              </NavLink>
            </div>
          )}
          <NavLink to="/about" onClick={() => setMobileOpen(false)}>
            О нас
          </NavLink>
          <NavLink to="/how-it-works" onClick={() => setMobileOpen(false)}>
            Как это работает
          </NavLink>
          <NavLink to="/contacts" onClick={() => setMobileOpen(false)}>
            Контакты
          </NavLink>
          <NavLink to="/services" onClick={() => setMobileOpen(false)}>
            Сервисы
          </NavLink>
        </div>
      )}
    </header>
  );
};

export default Header;