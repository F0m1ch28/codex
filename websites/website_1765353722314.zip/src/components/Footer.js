import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.inner}>
      <div className={styles.top}>
        <div className={styles.brand}>
          <div className={styles.brandTitle}>
            <span>DC</span>
            DigitalCover
          </div>
          <p>
            Цифровой магазин готовых и кастомных визуальных решений для видео, стримингов и
            социальных сетей. Мы помогаем создателям контента выделяться и удерживать внимание.
          </p>
          <div className={styles.socials} aria-label="Социальные сети">
            <a className={styles.socialButton} href="https://vk.com" target="_blank" rel="noreferrer">
              VK
            </a>
            <a className={styles.socialButton} href="https://t.me" target="_blank" rel="noreferrer">
              TG
            </a>
            <a className={styles.socialButton} href="https://behance.net" target="_blank" rel="noreferrer">
              Be
            </a>
          </div>
        </div>
        <div>
          <h4 className={styles.groupTitle}>Навигация</h4>
          <ul className={styles.linkList}>
            <li>
              <Link to="/">Главная</Link>
            </li>
            <li>
              <Link to="/about">О компании</Link>
            </li>
            <li>
              <Link to="/services">Сервисы</Link>
            </li>
            <li>
              <Link to="/how-it-works">Как это работает</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.groupTitle}>Каталоги</h4>
          <ul className={styles.linkList}>
            <li>
              <Link to="/catalog/video-covers">Обложки для видео</Link>
            </li>
            <li>
              <Link to="/catalog/avatars">Аватарки</Link>
            </li>
            <li>
              <Link to="/catalog/banners">Баннеры и шапки</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.groupTitle}>Контакты</h4>
          <div className={styles.contacts}>
            <span>support@digitalcover.ru</span>
            <span>+7 (495) 123-45-67</span>
            <span>123456, г. Москва, ул. Цифровая, д. 1, офис 10</span>
          </div>
          <h4 className={styles.groupTitle}>Документы</h4>
          <ul className={styles.linkList}>
            <li>
              <Link to="/terms">Условия использования</Link>
            </li>
            <li>
              <Link to="/privacy">Политика конфиденциальности</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Политика cookie</Link>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} DigitalCover. Все права защищены.</span>
        <span>Создано с вниманием к деталям для создателей контента.</span>
      </div>
    </div>
  </footer>
);

export default Footer;