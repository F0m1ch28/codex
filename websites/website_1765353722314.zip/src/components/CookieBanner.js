import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('digitalcover-cookie-accepted');
    if (!accepted) {
      const timer = setTimeout(() => setVisible(true), 900);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('digitalcover-cookie-accepted', 'true');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Используя сайт DigitalCover, вы соглашаетесь с обработкой cookie-файлов для улучшения
        персонализации и аналитики. Подробнее — в нашей{' '}
        <Link className={styles.link} to="/cookie-policy">
          политике cookie
        </Link>
        .
      </p>
      <div className={styles.actions}>
        <button type="button" className={styles.acceptButton} onClick={handleAccept}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;