document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('primary-navigation');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navToggle.classList.toggle('active');
      nav.classList.toggle('open');
    });

    const navLinks = nav.querySelectorAll('a');
    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768 && nav.classList.contains('open')) {
          nav.classList.remove('open');
          navToggle.classList.remove('active');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const storedConsent = localStorage.getItem('aflCookieConsent');
    if (storedConsent) {
      cookieBanner.setAttribute('hidden', '');
    }
    const acceptBtn = cookieBanner.querySelector('[data-cookie-consent="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie-consent="decline"]');

    const handleConsent = (value) => {
      localStorage.setItem('aflCookieConsent', value);
      cookieBanner.setAttribute('hidden', '');
    };

    if (acceptBtn) {
      acceptBtn.addEventListener('click', () => handleConsent('accepted'));
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', () => handleConsent('declined'));
    }
  }
});