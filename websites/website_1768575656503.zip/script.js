document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            navLinks.classList.toggle("active");
        });

        navLinks.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navToggle.classList.remove("active");
                navLinks.classList.remove("active");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");
    const consentKey = "wherevmbigCookieConsent";

    if (cookieBanner && acceptBtn && declineBtn) {
        const consent = localStorage.getItem(consentKey);
        if (!consent) {
            cookieBanner.classList.add("active");
        }

        acceptBtn.addEventListener("click", () => {
            localStorage.setItem(consentKey, "accepted");
            cookieBanner.classList.remove("active");
        });

        declineBtn.addEventListener("click", () => {
            localStorage.setItem(consentKey, "declined");
            cookieBanner.classList.remove("active");
        });
    }
});