document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.getAttribute('data-open') === 'true';
      nav.setAttribute('data-open', !isOpen);
      navToggle.setAttribute('aria-expanded', String(!isOpen));
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.setAttribute('data-open', 'false');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('[data-year]').forEach(el => {
    el.textContent = new Date().getFullYear();
  });

  const banner = document.getElementById('cookie-banner');
  const consentKey = 'rbl_cookie_consent';
  const storedConsent = localStorage.getItem(consentKey);

  const showBanner = () => {
    if (banner) {
      banner.classList.add('visible');
    }
  };

  if (!storedConsent && banner) {
    setTimeout(showBanner, 600);
  } else if (banner) {
    banner.classList.remove('visible');
  }

  if (banner) {
    banner.addEventListener('click', event => {
      const action = event.target.getAttribute('data-cookie-action');
      if (!action) return;
      localStorage.setItem(consentKey, action);
      banner.classList.remove('visible');
    });
  }

  const form = document.getElementById('contact-form');
  if (form) {
    const message = form.querySelector('.form-message');
    const fields = Array.from(form.querySelectorAll('input, textarea'));
    const setError = (field, text) => {
      field.classList.add('input-error');
      if (message) {
        message.textContent = text;
        message.style.color = '#e11d48';
      }
    };
    const clearError = field => {
      field.classList.remove('input-error');
      if (message) {
        message.textContent = '';
      }
    };
    fields.forEach(field => {
      field.addEventListener('input', () => clearError(field));
    });
    form.addEventListener('submit', evt => {
      evt.preventDefault();
      if (message) {
        message.textContent = '';
      }
      let valid = true;
      fields.forEach(field => field.classList.remove('input-error'));

      const requiredFields = ['name', 'email', 'company', 'message'];
      for (const name of requiredFields) {
        const field = form.elements[name];
        if (field && !field.value.trim()) {
          setError(field, `Please complete the ${field.previousElementSibling?.textContent.toLowerCase()}.`);
          field.focus();
          valid = false;
          break;
        }
      }
      if (!valid) return;

      const emailField = form.elements.email;
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (emailField && !emailPattern.test(emailField.value.trim())) {
        setError(emailField, 'Please enter a valid email address.');
        emailField.focus();
        return;
      }

      if (message) {
        message.textContent = 'Thank you. Your message has been sent and we will respond shortly.';
        message.style.color = '#0f766e';
      }
      form.reset();
    });
  }
});