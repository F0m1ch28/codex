import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <Helmet>
      <title>Cookie Policy | Muejpi IT Academy</title>
    </Helmet>
    <section className="sectionPadding">
      <div className="container">
        <div className={styles.legalWrapper}>
          <h1>Cookie Policy</h1>
          <p>Last updated: May 2024</p>

          <h2>1. What are cookies?</h2>
          <p>
            Cookies are small text files stored on your device when you visit our website. They help us enhance functionality,
            tailor content, and understand how visitors interact with our pages.
          </p>

          <h2>2. Types of cookies we use</h2>
          <ul>
            <li><strong>Essential cookies:</strong> Required for core site functionality, such as navigation and form submission.</li>
            <li><strong>Analytics cookies:</strong> Provide insights into site usage to improve user experience.</li>
            <li><strong>Preference cookies:</strong> Remember your settings and preferences.</li>
          </ul>

          <h2>3. Managing cookies</h2>
          <p>
            You can manage or disable cookies through your browser settings. Be aware that blocking certain cookies may impact site functionality.
          </p>

          <h2>4. Updates</h2>
          <p>
            We may update this policy to reflect changes in technology or regulation. Updated versions will be posted on this page.
          </p>

          <h2>5. Contact</h2>
          <p>
            For questions about this policy, contact us at Slovenska cesta 56, 1000 Ljubljana, Slovenia, or call +386 1 234 5678.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default CookiePolicy;