import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>Terms of Use | Muejpi IT Academy</title>
    </Helmet>
    <section className="sectionPadding">
      <div className="container">
        <div className={styles.legalWrapper}>
          <h1>Terms of Use</h1>
          <p>Last updated: May 2024</p>

          <h2>1. Acceptance of terms</h2>
          <p>
            By accessing the Muejpi IT Academy website, you agree to comply with these Terms of Use and all applicable regulations.
            If you do not agree, please discontinue use of the site.
          </p>

          <h2>2. Intellectual property</h2>
          <p>
            All materials, including text, graphics, logos, and media, remain the property of Muejpi IT Academy or its content providers.
            You may not copy, reproduce, or distribute content without written permission.
          </p>

          <h2>3. User responsibilities</h2>
          <p>
            You agree to use the site for lawful purposes only. Activities that compromise security or disrupt services are strictly prohibited.
          </p>

          <h2>4. Third-party links</h2>
          <p>
            Our site may contain links to external resources. Muejpi IT Academy is not responsible for the content or practices of third-party websites.
          </p>

          <h2>5. Changes to terms</h2>
          <p>
            We may update these terms periodically. Continued use of the site constitutes acceptance of the revised terms.
          </p>

          <h2>6. Contact</h2>
          <p>
            For questions about these terms, please contact us at Slovenska cesta 56, 1000 Ljubljana, Slovenia, or call +386 1 234 5678.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Terms;