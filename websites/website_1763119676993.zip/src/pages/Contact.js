import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    message: ''
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.fullName.trim()) newErrors.fullName = 'Please enter your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide an email address.';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!formData.message.trim()) newErrors.message = 'Please share your goals or questions.';
    return newErrors;
  };

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData({ fullName: '', email: '', phone: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contact | Muejpi IT Academy</title>
      </Helmet>
      <section className={`${styles.hero} sectionPadding`}>
        <div className="container">
          <h1>Contact Muejpi IT Academy</h1>
          <p>
            Ready to reimagine your career in technology? Reach out to our team for program details, cohort start dates, and partnership opportunities.
          </p>
        </div>
      </section>

      <section className="sectionPadding" aria-labelledby="contact-form">
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.formWrapper}>
              <h2 id="contact-form">Send us a message</h2>
              <form className={styles.form} onSubmit={handleSubmit} noValidate>
                <label htmlFor="fullName">
                  Full name <span aria-hidden="true">*</span>
                </label>
                <input
                  id="fullName"
                  name="fullName"
                  type="text"
                  value={formData.fullName}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.fullName)}
                  aria-describedby={errors.fullName ? 'name-error' : undefined}
                  required
                />
                {errors.fullName && <span id="name-error" className={styles.error}>{errors.fullName}</span>}

                <label htmlFor="email">
                  Email <span aria-hidden="true">*</span>
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                  required
                />
                {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}

                <label htmlFor="phone">Phone</label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="+386 ..."
                />

                <label htmlFor="message">
                  How can we help? <span aria-hidden="true">*</span>
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  required
                />
                {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}

                <button type="submit" className="btnPrimary">Submit</button>
              </form>
              {submitted && (
                <div className={styles.success} role="status">
                  Thank you for contacting Muejpi IT Academy. Our admissions team will reply shortly.
                </div>
              )}
            </div>
            <div className={styles.info}>
              <h2>Visit us</h2>
              <p>
                Slovenska cesta 56<br />
                1000 Ljubljana, Slovenia
              </p>
              <p><strong>Phone:</strong> <a href="tel:+38612345678">+386 1 234 5678</a></p>
              <p><strong>Email:</strong> [будет добавлен позже]</p>
              <p><strong>Geography:</strong> Slovenia</p>
              <div className={styles.mapWrapper} aria-label="Map showing Ljubljana location">
                <iframe
                  title="Muejpi IT Academy Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2763.8473684222404!2d14.5033071!3d46.0547181!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47652d65e0905487%3A0x66ab0dd5229c6923!2sSlovenska%20cesta%2056%2C%201000%20Ljubljana%2C%20Slovenia!5e0!3m2!1sen!2ssi!4v1687612345678"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;