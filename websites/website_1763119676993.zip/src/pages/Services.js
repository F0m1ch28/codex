import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Corporate Upskilling Labs',
    description:
      'Co-create training with your engineering and data teams. We align workshops to ongoing initiatives so skills are applied immediately.',
    benefits: ['Custom curriculum design', 'Hands-on labs led by experts', 'Post-training impact reviews']
  },
  {
    title: 'Talent Academy Programs',
    description:
      'Kick-start graduate programs with our blended learning tracks. We train new hires in agile delivery, secure coding, and collaborative workflows.',
    benefits: ['Tailored onboarding journeys', 'Mentor pairing and coaching', 'Portfolio-ready project outcomes']
  },
  {
    title: 'Innovation Sprints',
    description:
      'Prototype new solutions in our design-build labs. Cross-functional teams collaborate on ideas, validate assumptions, and deliver proofs of concept.',
    benefits: ['Design thinking facilitation', 'Access to tech stacks and mentors', 'Executive showcases and retrospectives']
  },
  {
    title: 'Career Transition Support',
    description:
      'Support professionals shifting into technology. From foundational bootcamps to advanced specialisations, we provide a clear development roadmap.',
    benefits: ['Skills gap assessment', 'Personal mentorship', 'Career coaching and community']
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Services | Muejpi IT Academy</title>
    </Helmet>
    <section className={`${styles.hero} sectionPadding`}>
      <div className="container">
        <h1>Services tailored to accelerate your teams</h1>
        <p>
          Beyond individual learners, Muejpi IT Academy partners with organisations to build high-performing technology teams.
          We craft programs that deliver measurable skill growth and innovation outcomes.
        </p>
      </div>
    </section>

    <section className="sectionPadding" aria-labelledby="services-title">
      <div className="container">
        <h2 id="services-title" className={styles.sectionTitle}>What we deliver</h2>
        <div className={styles.servicesGrid}>
          {services.map(service => (
            <article key={service.title} className={styles.serviceCard}>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <ul>
                {service.benefits.map(benefit => (
                  <li key={benefit}>{benefit}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="workflow-title">
      <div className="container">
        <h2 id="workflow-title" className={styles.sectionTitle}>Engagement workflow</h2>
        <div className={styles.workflow}>
          <div>
            <h3>1. Discovery and alignment</h3>
            <p>We collaborate with stakeholders to understand goals, current capabilities, and success metrics.</p>
          </div>
          <div>
            <h3>2. Program design</h3>
            <p>Our team builds a roadmap, learning outcomes, and assessment methods tailored to your needs.</p>
          </div>
          <div>
            <h3>3. Delivery and coaching</h3>
            <p>Seasoned instructors facilitate experiential learning, provide feedback, and monitor progress.</p>
          </div>
          <div>
            <h3>4. Impact measurement</h3>
            <p>We capture learner feedback, performance data, and ongoing support opportunities.</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Services;