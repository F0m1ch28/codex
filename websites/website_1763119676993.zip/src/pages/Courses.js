import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Courses.module.css';

const courses = [
  {
    name: 'Programming',
    focus: 'Master the building blocks of modern software engineering.',
    stack: ['Python fundamentals & data structures', 'Java and C++ systems programming', 'JavaScript and TypeScript ecosystems', 'Testing, refactoring, and design patterns']
  },
  {
    name: 'Cybersecurity',
    focus: 'Defend organisations with proactive and reactive security skills.',
    stack: ['Threat modelling and secure architecture', 'Offensive security tactics and red teaming', 'Security operations centre workflows', 'Incident response, digital forensics, governance']
  },
  {
    name: 'Data Science',
    focus: 'Turn raw data into strategic decisions.',
    stack: ['Exploratory data analysis and visual storytelling', 'Machine learning pipelines and evaluation', 'Responsible AI and bias mitigation', 'Data engineering foundations and ML Ops']
  },
  {
    name: 'Cloud Computing',
    focus: 'Architect scalable, resilient, and observable systems.',
    stack: ['AWS, Azure, and Google Cloud fundamentals', 'Infrastructure as code and automation', 'Container orchestration with Kubernetes', 'Observability, monitoring, and FinOps principles']
  },
  {
    name: 'Web Development',
    focus: 'Build accessible, performant, and delightful web experiences.',
    stack: ['Frontend frameworks: React, Vue, Next.js', 'APIs, GraphQL, and progressive web apps', 'Design systems and accessibility reviews', 'Deployment pipelines and quality assurance']
  },
  {
    name: 'DevOps',
    focus: 'Integrate development and operations for rapid delivery.',
    stack: ['Continuous integration and delivery', 'Automation with pipelines and scripting', 'Site reliability engineering practices', 'Security automation and compliance tooling']
  }
];

const Courses = () => (
  <>
    <Helmet>
      <title>Courses | Muejpi IT Academy</title>
      <meta
        name="description"
        content="Discover detailed course outlines across programming, cybersecurity, data science, cloud, web development, and DevOps at Muejpi IT Academy."
      />
    </Helmet>
    <section className={`${styles.hero} sectionPadding`}>
      <div className="container">
        <h1>Programs designed for real-world impact</h1>
        <p>
          Every course combines hands-on labs, collaborative sprints, and reflective practice. You will learn by building,
          deploying, and iterating on meaningful projects guided by expert mentors.
        </p>
      </div>
    </section>

    <section className="sectionPadding" aria-labelledby="course-list">
      <div className="container">
        <h2 id="course-list" className={styles.sectionTitle}>Course catalog</h2>
        <div className={styles.courseGrid}>
          {courses.map(course => (
            <article key={course.name} className={styles.courseCard}>
              <h3>{course.name}</h3>
              <p className={styles.focus}>{course.focus}</p>
              <ul>
                {course.stack.map(item => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Courses;