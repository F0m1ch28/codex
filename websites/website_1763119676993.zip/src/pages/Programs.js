import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const tracks = [
  {
    title: 'Software Engineering Track',
    duration: '24 weeks',
    modules: ['Foundations & algorithms', 'Microservices and APIs', 'Frontend architectures', 'Capstone: scalable web application']
  },
  {
    title: 'Cybersecurity Track',
    duration: '20 weeks',
    modules: ['Security fundamentals', 'Offensive and defensive labs', 'Governance, risk & compliance', 'Capstone: security operations blueprint']
  },
  {
    title: 'Data Science Track',
    duration: '22 weeks',
    modules: ['Data wrangling & visualisation', 'Machine learning & model operations', 'Business communication', 'Capstone: analytics product delivery']
  },
  {
    title: 'Cloud & DevOps Track',
    duration: '20 weeks',
    modules: ['Cloud architecture essentials', 'Automation & CI/CD pipelines', 'Observability & resilience', 'Capstone: infrastructure modernisation']
  }
];

const certifications = [
  { name: 'AWS Certified Cloud Practitioner readiness', detail: 'Guidance sessions and mock exams included.' },
  { name: 'CompTIA Security+ fundamentals', detail: 'Cybersecurity track aligns with core exam objectives.' },
  { name: 'Certified Kubernetes Administrator preparation', detail: 'DevOps learners practise with real cluster challenges.' }
];

const Programs = () => (
  <>
    <Helmet>
      <title>Programs | Muejpi IT Academy</title>
    </Helmet>
    <section className={`${styles.hero} sectionPadding`}>
      <div className="container">
        <h1>Program structure & outcomes</h1>
        <p>
          Our programs are carefully sequenced to balance theory, lab practice, and collaborative projects.
          Each track culminates in a capstone experience evaluated by industry mentors.
        </p>
      </div>
    </section>

    <section className="sectionPadding" aria-labelledby="track-title">
      <div className="container">
        <h2 id="track-title" className={styles.sectionTitle}>Program tracks</h2>
        <div className={styles.trackGrid}>
          {tracks.map(track => (
            <article key={track.title} className={styles.trackCard}>
              <div className={styles.trackHeader}>
                <h3>{track.title}</h3>
                <span>{track.duration}</span>
              </div>
              <ul>
                {track.modules.map(module => (
                  <li key={module}>{module}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="cert-title">
      <div className="container">
        <h2 id="cert-title" className={styles.sectionTitle}>Certifications & milestones</h2>
        <div className={styles.certifications}>
          {certifications.map(cert => (
            <article key={cert.name}>
              <h3>{cert.name}</h3>
              <p>{cert.detail}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Programs;