import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

const statsData = [
  { label: 'Learners empowered', value: 3200 },
  { label: 'Industry mentors', value: 45 },
  { label: 'Capstone projects', value: 210 },
  { label: 'Career-ready rate', value: 92, suffix: '%' }
];

const courseHighlights = [
  {
    title: 'Programming Foundations',
    description: 'Python, Java, JavaScript, and C++ labs with pair-programming, code reviews, and automation exercises.',
    icon: '👩‍💻'
  },
  {
    title: 'Cybersecurity Operations',
    description: 'Threat modelling, SOC scenarios, ethical hacking simulations, and response automation.',
    icon: '🛡️'
  },
  {
    title: 'Data Science Studio',
    description: 'Machine learning pipelines, data storytelling, and experimental notebooks with live datasets.',
    icon: '📊'
  },
  {
    title: 'Cloud & DevOps',
    description: 'Container workflows, infrastructure as code, resilience testing, and multi-cloud orchestration.',
    icon: '☁️'
  },
  {
    title: 'Web Engineering',
    description: 'Modern frontend frameworks, design systems, accessibility audits, and API-driven development.',
    icon: '🌐'
  }
];

const processSteps = [
  { step: '01', title: 'Discover', text: 'Assess your goals with our mentors and map a personalised learning journey.' },
  { step: '02', title: 'Design', text: 'Craft a modular study path blending core skills, electives, and passion projects.' },
  { step: '03', title: 'Build', text: 'Collaborate in sprints, ship production-ready features, and document your work.' },
  { step: '04', title: 'Launch', text: 'Prepare for interviews with coaching, portfolios, and career immersions.' }
];

const testimonialsData = [
  {
    name: 'Lea Novak',
    role: 'Cloud Engineer at Triglav',
    quote:
      'Muejpi IT Academy transformed the way I approach complex infrastructure. The instructors demanded excellence while providing relentless support.',
    project: 'Hybrid cloud automation initiative'
  },
  {
    name: 'Matej Skubic',
    role: 'Security Analyst at Telekom Slovenije',
    quote:
      'Hands-on cyber labs and blue team simulations gave me the confidence to lead incident response within weeks of graduating.',
    project: 'SOC threat signal detection dashboard'
  },
  {
    name: 'Jana Perko',
    role: 'Data Scientist at Outfit7',
    quote:
      'We worked with real streaming data, delivered insights to stakeholders, and learned how to communicate outcomes clearly.',
    project: 'Predictive analytics for user engagement'
  }
];

const teamSpotlight = [
  {
    name: 'Anja Kranjc',
    role: 'Lead Full-Stack Instructor',
    expertise: 'React, Node.js, Systems Architecture',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Niko Hribar',
    role: 'Cybersecurity Coach',
    expertise: 'SOC Automation, Pen Testing, Zero Trust',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Eva Mlakar',
    role: 'Data Science Mentor',
    expertise: 'ML Ops, NLP, Responsible AI',
    image: 'https://picsum.photos/400/400?random=33'
  }
];

const projectsData = [
  {
    id: 1,
    title: 'AI-Powered Campus Navigator',
    category: 'Web Development',
    description: 'Progressive web app integrating geolocation and predictive routing for university campuses.',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    id: 2,
    title: 'Security Incident Playbook',
    category: 'Cybersecurity',
    description: 'Interactive incident response toolkit with automation scripts and compliance tracking.',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    id: 3,
    title: 'Predictive Demand Analytics',
    category: 'Data Science',
    description: 'Machine learning pipeline forecasting sales trends with explainable AI visualisations.',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    id: 4,
    title: 'Cloud-Native DevOps Toolkit',
    category: 'DevOps',
    description: 'Kubernetes deployment manager with CI/CD templates and observability dashboards.',
    image: 'https://picsum.photos/1200/800?random=44'
  },
  {
    id: 5,
    title: 'Secure Payment Gateway Prototype',
    category: 'Programming',
    description: 'High-availability microservice with tokenisation, rate limiting, and audit logging.',
    image: 'https://picsum.photos/1200/800?random=45'
  }
];

const faqData = [
  {
    question: 'How is the curriculum kept aligned with industry needs?',
    answer:
      'We collaborate with technology partners quarterly, analyse job market data, and run advisory panels with alumni to continuously refresh modules.'
  },
  {
    question: 'Can I balance work and study?',
    answer:
      'Yes. Flexible evening sessions, modular tracks, and mentoring clinics make it possible to learn alongside professional commitments.'
  },
  {
    question: 'Do I need prior experience?',
    answer:
      'A curious mindset is the main requirement. Preparatory bridge sessions cover core concepts so that diverse learners can thrive together.'
  },
  {
    question: 'What projects will I complete?',
    answer:
      'Every pathway includes capstone initiatives: building microservices, defending security scenarios, shipping data products, or architecting cloud systems.'
  }
];

const blogPosts = [
  {
    title: 'Inside the SOC: How Learners Master Live Threat Response',
    excerpt: 'Step into our cyber range, where students triage attacks, learn escalation protocols, and practise mission-critical communication.',
    date: 'June 2024',
    link: '/programs'
  },
  {
    title: 'Designing Data Pipelines for Real-World Impact',
    excerpt: 'From raw ingestion to stakeholder-ready dashboards, discover how learners architect resilient analytics workflows.',
    date: 'May 2024',
    link: '/courses'
  },
  {
    title: 'Mentor Spotlight: Building Inclusive Tech Communities',
    excerpt: 'Lead instructor Anja Kranjc shares how collaborative studios empower learners to break into advanced engineering roles.',
    date: 'April 2024',
    link: '/about'
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('All');
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [loadedImages, setLoadedImages] = useState({});
  const statsRef = useRef(null);
  const observerRef = useRef(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setCounters(statsData.map(stat => stat.value));
            observerRef.current.disconnect();
          }
        });
      },
      { threshold: 0.35 }
    );

    if (statsRef.current) {
      observerRef.current.observe(statsRef.current);
    }

    return () => observerRef.current && observerRef.current.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial(prev => (prev + 1) % testimonialsData.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'All') return projectsData;
    return projectsData.filter(project => project.category === activeFilter);
  }, [activeFilter]);

  const handleImageLoaded = id => {
    setLoadedImages(prev => ({ ...prev, [id]: true }));
  };

  return (
    <>
      <Helmet>
        <title>Muejpi IT Academy | Master IT Skills, Build Your Future</title>
      </Helmet>
      <section
        className={`${styles.hero} sectionPadding`}
        style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=11)' }}
      >
        <div className={styles.heroOverlay} />
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.tagline}>Master IT Skills, Build Your Future</span>
            <h1 className={styles.heroTitle}>
              Become the technologist who leads transformation across cloud, data, security, and engineering.
            </h1>
            <p className={styles.heroText}>
              At Muejpi IT Academy, you will immerse yourself in collaborative studios, deploy production-grade solutions, and
              graduate with a portfolio that speaks for itself.
            </p>
            <div className={styles.heroButtons}>
              <Link to="/courses" className="btnPrimary">Explore Courses</Link>
              <Link to="/contact" className="btnSecondary">Enroll Today</Link>
            </div>
          </div>
        </div>
      </section>

      <section ref={statsRef} className="sectionPadding">
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.stat} aria-label={stat.label}>
                <span className={styles.statValue}>
                  {counters[index]}
                  {stat.suffix || '+'}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="sectionPadding" aria-labelledby="intro-title">
        <div className="container">
          <div className={styles.intro}>
            <div>
              <h2 id="intro-title" className={styles.sectionTitle}>Where curious minds become confident technologists</h2>
              <p className={styles.sectionText}>
                Located in vibrant Ljubljana, Muejpi IT Academy blends rigorous instruction with studio-style collaboration. Our community
                draws learners from across Slovenia and beyond who are eager to build resilient systems, unlock data, and secure digital ecosystems.
              </p>
            </div>
            <div className={styles.introCard}>
              <h3>Learning Method</h3>
              <ul>
                <li>Guided by expert instructors with deep industry experience.</li>
                <li>Project-based milestones aligned with real business contexts.</li>
                <li>Continuous feedback loops and reflective practice.</li>
                <li>Career coaching from day one to graduation and beyond.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="courses-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="courses-title" className={styles.sectionTitle}>Our Courses</h2>
            <p className={styles.sectionText}>
              Build strong fundamentals, explore emerging technologies, and deliver compelling portfolio projects across our core disciplines.
            </p>
          </div>
          <div className={styles.coursesGrid}>
            {courseHighlights.map(course => (
              <article key={course.title} className={styles.courseCard}>
                <span className={styles.courseIcon} aria-hidden="true">{course.icon}</span>
                <h3>{course.title}</h3>
                <p>{course.description}</p>
                <Link to="/courses" className={styles.linkArrow} aria-label={`Learn more about ${course.title}`}>
                  Learn more <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="sectionPadding" aria-labelledby="why-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="why-title" className={styles.sectionTitle}>Why Choose Muejpi IT Academy?</h2>
            <p className={styles.sectionText}>
              We combine human-centered mentoring with enterprise-grade tooling, ensuring every learner gains practical insights and leadership capability.
            </p>
          </div>
          <div className={styles.whyGrid}>
            <div className={styles.whyCard}>
              <h3>High-impact projects</h3>
              <p>Design solutions using cloud-native, data-centric, and secure architectures that mirror industry challenges.</p>
            </div>
            <div className={styles.whyCard}>
              <h3>Mentors on demand</h3>
              <p>Our instructors support you through code reviews, design clinics, and weekly office hours focused on growth.</p>
            </div>
            <div className={styles.whyCard}>
              <h3>Career launchpad</h3>
              <p>Career advisors help craft your portfolio, practise storytelling, and connect you with hiring partners.</p>
            </div>
            <div className={styles.whyCard}>
              <h3>Inclusive community</h3>
              <p>Collaborate with peers from diverse backgrounds, share perspectives, and learn in a supportive environment.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="process-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="process-title" className={styles.sectionTitle}>Learning Process</h2>
            <p className={styles.sectionText}>
              Our method ensures you move from theory to implementation with clarity, support, and measurable milestones.
            </p>
          </div>
          <div className={styles.processSteps}>
            {processSteps.map(item => (
              <div key={item.step} className={styles.step}>
                <span className={styles.stepNumber}>{item.step}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="sectionPadding" aria-labelledby="stories-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="stories-title" className={styles.sectionTitle}>Graduate Success Stories</h2>
            <p className={styles.sectionText}>
              Explore how our alumni turned classroom experiences into impactful roles across Slovenia and the wider region.
            </p>
          </div>
          <div className={styles.stories}>
            {testimonialsData.map(story => (
              <article key={story.name} className={styles.storyCard}>
                <h3>{story.name}</h3>
                <p className={styles.storyRole}>{story.role}</p>
                <p className={styles.storyQuote}>“{story.quote}”</p>
                <p className={styles.storyProject}><strong>Flagship project:</strong> {story.project}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} sectionPadding`} aria-labelledby="testimonial-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="testimonial-title" className={styles.sectionTitle}>Testimonials</h2>
            <p className={styles.sectionText}>
              Voices from our alumni community showcase the confidence and resilience gained through our programs.
            </p>
          </div>
          <div className={styles.testimonialCard}>
            {testimonialsData.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`${styles.testimonial} ${index === activeTestimonial ? styles.testimonialActive : ''}`}
                role="tabpanel"
                hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
                <p className={styles.testimonialAuthor}>{testimonial.name}</p>
                <p className={styles.testimonialRole}>{testimonial.role}</p>
              </div>
            ))}
            <div className={styles.testimonialNav} role="tablist" aria-label="Testimonials navigation">
              {testimonialsData.map((testimonial, index) => (
                <button
                  key={testimonial.name}
                  className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                  aria-label={`View testimonial from ${testimonial.name}`}
                  aria-selected={index === activeTestimonial}
                  onClick={() => setActiveTestimonial(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="team-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="team-title" className={styles.sectionTitle}>Mentor Spotlight</h2>
            <p className={styles.sectionText}>
              Experienced instructors bring real-world challenges into every cohort, inspiring learners to deliver with confidence.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamSpotlight.map(member => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img
                    src={member.image}
                    alt={`${member.name} - ${member.role}`}
                    onLoad={() => handleImageLoaded(member.name)}
                    className={`${styles.teamImage} ${loadedImages[member.name] ? styles.imageLoaded : styles.imageLoading}`}
                  />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p className={styles.teamExpertise}>{member.expertise}</p>
                  <Link to="/instructors" className={styles.linkArrow} aria-label={`Meet ${member.name}`}>
                    Meet instructor <span aria-hidden="true">→</span>
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="sectionPadding" aria-labelledby="projects-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="projects-title" className={styles.sectionTitle}>Projects Gallery</h2>
            <p className={styles.sectionText}>
              Filter recent capstone projects to explore the diverse solutions built by our talented learners.
            </p>
          </div>
          <div className={styles.filterBar} role="tablist" aria-label="Project filters">
            {['All', 'Programming', 'Cybersecurity', 'Data Science', 'DevOps', 'Web Development'].map(category => (
              <button
                key={category}
                className={`${styles.filterButton} ${activeFilter === category ? styles.filterActive : ''}`}
                onClick={() => setActiveFilter(category)}
                role="tab"
                aria-selected={activeFilter === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map(project => (
              <article key={project.id} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={project.image}
                    alt={`${project.title} showcase`}
                    className={`${styles.projectImage} ${loadedImages[project.id] ? styles.imageLoaded : styles.imageLoading}`}
                    onLoad={() => handleImageLoaded(project.id)}
                  />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="faq-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="faq-title" className={styles.sectionTitle}>Frequently Asked Questions</h2>
            <p className={styles.sectionText}>
              We are here to help you navigate your learning journey. Browse the most common questions below.
            </p>
          </div>
          <div className={styles.faq}>
            {faqData.map(item => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="sectionPadding" aria-labelledby="blog-title">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog-title" className={styles.sectionTitle}>Latest Insights</h2>
            <p className={styles.sectionText}>
              Stay ahead with fresh perspectives from our instructors, learners, and partners.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map(post => (
              <article key={post.title} className={styles.blogCard}>
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className={styles.linkArrow}>
                  Continue reading <span aria-hidden="true">→</span>
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} sectionPadding`} style={{ backgroundImage: 'url(https://picsum.photos/1600/900?random=12)' }}>
        <div className={styles.ctaOverlay} />
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Start crafting your future in technology today</h2>
            <p>
              Join Muejpi IT Academy to learn from industry leaders, build real products, and become part of a supportive community that celebrates your progress.
            </p>
            <div className={styles.heroButtons}>
              <Link to="/contact" className="btnPrimary">Enroll Today</Link>
              <Link to="/career" className="btnSecondary">Career Support</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;