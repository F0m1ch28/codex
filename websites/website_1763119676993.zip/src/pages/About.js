import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const timeline = [
  {
    year: '2015',
    title: 'Academy founded',
    description: 'Muejpi IT Academy opens its doors in Ljubljana, welcoming the first cohort of aspiring developers.'
  },
  {
    year: '2017',
    title: 'Curriculum expansion',
    description: 'Cybersecurity and cloud-native programs launch with new labs and multi-week simulation weeks.'
  },
  {
    year: '2019',
    title: 'Partner network',
    description: 'Strategic collaborations with regional technology companies strengthen project authenticity and mentorship.'
  },
  {
    year: '2022',
    title: 'Global classrooms',
    description: 'Hybrid delivery allows learners from across Europe to join immersive remote labs with on-site meetups.'
  }
];

const values = [
  { title: 'Human-first learning', text: 'We champion empathy, mentorship, and psychological safety to let curiosity thrive.' },
  { title: 'Rigorous practice', text: 'Studios are built around real backlogs, measurable deliverables, and constructive feedback loops.' },
  { title: 'Sustainable progress', text: 'We promote continuous improvement, reflective thinking, and healthy pacing to support long-term careers.' },
  { title: 'Inclusive community', text: 'Our doors are open to diverse voices, backgrounds, and perspectives that advance technology for all.' }
];

const partnerships = [
  'Zavarovalnica Triglav',
  'Petrol',
  'Telekom Slovenije',
  'Outfit7',
  'Comtrade Digital Services'
];

const About = () => (
  <>
    <Helmet>
      <title>About Muejpi IT Academy | Our Story & Philosophy</title>
    </Helmet>
    <section className={`${styles.hero} sectionPadding`}>
      <div className="container">
        <div className={styles.heroContent}>
          <h1>Driven by passion, united by technology</h1>
          <p>
            Muejpi IT Academy was created to bridge the gap between academic theory and the competencies required in today’s technology teams.
            We believe in collaborative learning, real-world problem solving, and continuous mentorship.
          </p>
        </div>
      </div>
    </section>

    <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="history-title">
      <div className="container">
        <h2 id="history-title" className={styles.sectionTitle}>Our Journey</h2>
        <div className={styles.timeline}>
          {timeline.map(event => (
            <div key={event.year} className={styles.timelineItem}>
              <span className={styles.timelineYear}>{event.year}</span>
              <h3>{event.title}</h3>
              <p>{event.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className="sectionPadding" aria-labelledby="philosophy-title">
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2 id="philosophy-title" className={styles.sectionTitle}>Teaching Philosophy</h2>
          <p>
            We design every learning experience with purpose: to elevate your technical, collaborative, and leadership skills.
            Our mentors facilitate, challenge, and support you at every step.
          </p>
        </div>
        <div className={styles.valuesGrid}>
          {values.map(value => (
            <article key={value.title} className={styles.valueCard}>
              <h3>{value.title}</h3>
              <p>{value.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.sectionLight} sectionPadding`} aria-labelledby="team-title">
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2 id="team-title" className={styles.sectionTitle}>Our Instructor Team</h2>
          <p>
            We bring together senior engineers, data scientists, and security specialists who thrive on teaching and coaching.
            Each mentor has led major industry initiatives and understands the demands of high-performing teams.
          </p>
        </div>
        <ul className={styles.teamList}>
          <li><strong>Anja Kranjc</strong> — Lead Full-Stack Instructor, specialising in design systems, microservices, and frontend leadership.</li>
          <li><strong>Niko Hribar</strong> — Cybersecurity Coach with expertise in SOC automation, risk mitigation, and governance frameworks.</li>
          <li><strong>Eva Mlakar</strong> — Data Science Mentor focused on ML Ops, responsible AI, and storytelling with stakeholders.</li>
          <li><strong>Gregor Pivec</strong> — DevOps Advisor guiding Kubernetes, observability, and infrastructure as code practices.</li>
          <li><strong>Klara Zupan</strong> — Career Strategist supporting interview readiness, portfolio positioning, and leadership growth.</li>
        </ul>
      </div>
    </section>

    <section className="sectionPadding" aria-labelledby="partnerships-title">
      <div className="container">
        <div className={styles.sectionHeader}>
          <h2 id="partnerships-title" className={styles.sectionTitle}>Partnerships & Accreditations</h2>
          <p>
            Collaborating with trusted organisations keeps our programs aligned with emerging standards and technologies.
            We partner with leaders across finance, telecoms, mobility, and software innovation.
          </p>
        </div>
        <div className={styles.partners}>
          {partnerships.map(partner => (
            <span key={partner}>{partner}</span>
          ))}
        </div>
        <div className={styles.accreditations}>
          <h3>Accreditations</h3>
          <ul>
            <li>Registered professional training provider in Slovenia.</li>
            <li>ISO-aligned quality assurance for education delivery.</li>
            <li>Curricula validated by industry advisory councils.</li>
          </ul>
        </div>
      </div>
    </section>
  </>
);

export default About;