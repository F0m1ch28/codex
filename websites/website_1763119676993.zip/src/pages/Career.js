import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Career.module.css';

const supportItems = [
  {
    title: 'Career coaching sessions',
    description: 'One-to-one coaching covering positioning, storytelling, and interview preparation.'
  },
  {
    title: 'Portfolio curation',
    description: 'Build a compelling portfolio with GitHub reviews, case study templates, and demo day feedback.'
  },
  {
    title: 'Employer partnerships',
    description: 'Connect with our network of hiring partners, attend talent showcases, and gain exposure to open roles.'
  },
  {
    title: 'Alumni community',
    description: 'Stay engaged through monthly meetups, knowledge sharing, and ongoing mentorship opportunities.'
  }
];

const Career = () => (
  <>
    <Helmet>
      <title>Career Support | Muejpi IT Academy</title>
    </Helmet>
    <section className={`${styles.hero} sectionPadding`}>
      <div className="container">
        <h1>Career support that champions your next role</h1>
        <p>
          From day one, our career team works with you to articulate goals, build confidence, and connect you with industry professionals.
          We focus on both the human and technical skills recruiters value.
        </p>
      </div>
    </section>

    <section className="sectionPadding" aria-labelledby="support-title">
      <div className="container">
        <h2 id="support-title" className={styles.sectionTitle}>How we support you</h2>
        <div className={styles.supportGrid}>
          {supportItems.map(item => (
            <article key={item.title} className={styles.supportCard}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
        <div className={styles.statement}>
          <p>
            Our graduates step into roles such as software engineer, data analyst, cloud specialist, and security analyst across Slovenia and Europe.
            We remain your ally long after graduation with continued mentorship.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Career;