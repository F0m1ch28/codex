import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Instructors.module.css';

const instructors = [
  {
    name: 'Anja Kranjc',
    role: 'Lead Full-Stack Instructor',
    experience: '12 years building design systems, scalable web platforms, and frontend guilds.',
    specialty: 'React, TypeScript, UX engineering, mentoring',
    image: 'https://picsum.photos/500/500?random=51'
  },
  {
    name: 'Niko Hribar',
    role: 'Cybersecurity Coach',
    experience: 'Former SOC lead specialising in detection engineering and rapid response.',
    specialty: 'Threat intelligence, blue team automation, secure architecture',
    image: 'https://picsum.photos/500/500?random=52'
  },
  {
    name: 'Eva Mlakar',
    role: 'Data Science Mentor',
    experience: 'Delivered machine learning products for healthcare and entertainment sectors.',
    specialty: 'ML Ops, natural language processing, responsible AI',
    image: 'https://picsum.photos/500/500?random=53'
  },
  {
    name: 'Gregor Pivec',
    role: 'DevOps Advisor',
    experience: 'Architected cloud-native systems for high-traffic platforms across Europe.',
    specialty: 'Kubernetes, observability, automation pipelines',
    image: 'https://picsum.photos/500/500?random=54'
  },
  {
    name: 'Klara Zupan',
    role: 'Career Strategist',
    experience: 'Guided hundreds of learners into technology roles with tailored coaching.',
    specialty: 'Career storytelling, interview preparation, leadership development',
    image: 'https://picsum.photos/500/500?random=55'
  }
];

const Instructors = () => (
  <>
    <Helmet>
      <title>Instructors | Muejpi IT Academy</title>
    </Helmet>
    <section className={`${styles.hero} sectionPadding`}>
      <div className="container">
        <h1>Meet the mentors guiding your journey</h1>
        <p>
          Our instructional team combines seasoned industry experience with a passion for teaching.
          They provide the mentorship, challenges, and encouragement that help you reach your goals.
        </p>
      </div>
    </section>

    <section className="sectionPadding" aria-labelledby="instructors-grid">
      <div className="container">
        <h2 id="instructors-grid" className={styles.sectionTitle}>Instructor profiles</h2>
        <div className={styles.grid}>
          {instructors.map(instructor => (
            <article key={instructor.name} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={instructor.image} alt={`${instructor.name} portrait`} loading="lazy" />
              </div>
              <div className={styles.content}>
                <h3>{instructor.name}</h3>
                <p className={styles.role}>{instructor.role}</p>
                <p className={styles.experience}>{instructor.experience}</p>
                <p className={styles.specialty}><strong>Specialty:</strong> {instructor.specialty}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default Instructors;