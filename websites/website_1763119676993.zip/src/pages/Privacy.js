import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Privacy Policy | Muejpi IT Academy</title>
    </Helmet>
    <section className="sectionPadding">
      <div className="container">
        <div className={styles.legalWrapper}>
          <h1>Privacy Policy</h1>
          <p>Last updated: May 2024</p>

          <h2>1. Data controller</h2>
          <p>
            Muejpi IT Academy, Slovenska cesta 56, 1000 Ljubljana, Slovenia, is the data controller responsible for safeguarding your personal data.
          </p>

          <h2>2. Data we collect</h2>
          <p>
            We collect information you provide through forms, event registrations, or communications.
            This may include your name, contact details, professional background, and learning preferences.
          </p>

          <h2>3. How we use your data</h2>
          <ul>
            <li>To respond to inquiries and provide program information.</li>
            <li>To deliver learning services and manage enrolments.</li>
            <li>To send updates, invitations, and relevant educational content.</li>
            <li>To analyse site usage and improve our offerings.</li>
          </ul>

          <h2>4. GDPR rights</h2>
          <p>
            In accordance with GDPR, you may request access, correction, deletion, or restriction of your personal data.
            You also have the right to data portability and to object to certain processing activities.
          </p>

          <h2>5. Data retention</h2>
          <p>
            We retain personal data only for as long as necessary to deliver services, meet legal obligations, or resolve disputes.
          </p>

          <h2>6. Security</h2>
          <p>
            We implement technical and organisational measures to protect your data from unauthorised access, alteration, or disclosure.
          </p>

          <h2>7. Contact</h2>
          <p>
            For privacy-related requests, please write to Slovenska cesta 56, 1000 Ljubljana, Slovenia, or call +386 1 234 5678.
          </p>
        </div>
      </div>
    </section>
  </>
);

export default Privacy;