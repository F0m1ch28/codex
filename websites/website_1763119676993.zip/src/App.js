import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Courses from './pages/Courses';
import Programs from './pages/Programs';
import Instructors from './pages/Instructors';
import Career from './pages/Career';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import CookiePolicy from './pages/CookiePolicy';

const App = () => (
  <>
    <Helmet>
      <title>Muejpi IT Academy | Elevate Your Tech Future</title>
      <meta
        name="description"
        content="Muejpi IT Academy in Ljubljana empowers learners with cutting-edge IT training across software engineering, security, cloud, and data disciplines."
      />
    </Helmet>
    <Header />
    <main className="appMain">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/programs" element={<Programs />} />
        <Route path="/instructors" element={<Instructors />} />
        <Route path="/career" element={<Career />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/cookie-policy" element={<CookiePolicy />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTop />
  </>
);

export default App;