import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('muejpi-cookie-consent');
    if (!consent) {
      setTimeout(() => setVisible(true), 1200);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('muejpi-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4 className={styles.title}>Cookie Notice</h4>
        <p className={styles.description}>
          We use cookies to personalise learning content, tailor analytics, and improve your browsing experience. By continuing, you agree to our{' '}
          <a href="/cookie-policy">Cookie Policy</a>.
        </p>
      </div>
      <button className={styles.button} onClick={handleAccept} aria-label="Accept cookies">
        Accept
      </button>
    </div>
  );
};

export default CookieBanner;