import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/about', label: 'About' },
  { path: '/courses', label: 'Courses' },
  { path: '/programs', label: 'Programs' },
  { path: '/instructors', label: 'Instructors' },
  { path: '/career', label: 'Career' },
  { path: '/services', label: 'Services' },
  { path: '/contact', label: 'Contact' }
];

const Header = () => {
  const [isSticky, setIsSticky] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.body.classList.add('menu-open');
    } else {
      document.body.classList.remove('menu-open');
    }
  }, [isOpen]);

  const closeMenu = () => setIsOpen(false);

  return (
    <header className={`${styles.header} ${isSticky ? styles.sticky : ''}`} aria-label="Primary">
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} onClick={closeMenu} aria-label="Muejpi IT Academy home">
            <span className={styles.logoMark}>Muejpi</span>
            <span className={styles.logoText}>IT Academy</span>
          </NavLink>
          <button
            className={styles.toggle}
            aria-expanded={isOpen}
            aria-controls="primary-navigation"
            onClick={() => setIsOpen(prev => !prev)}
          >
            <span className={styles.toggleBar} />
            <span className={styles.toggleBar} />
            <span className={styles.toggleBar} />
            <span className="sr-only">{isOpen ? 'Close navigation' : 'Open navigation'}</span>
          </button>
          <nav
            id="primary-navigation"
            className={`${styles.nav} ${isOpen ? styles.navOpen : ''}`}
            aria-label="Main navigation"
          >
            <ul className={styles.navList}>
              {navLinks.map(link => (
                <li key={link.path} className={styles.navItem}>
                  <NavLink
                    to={link.path}
                    end={link.path === '/'}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                    }
                    onClick={closeMenu}
                  >
                    {link.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;