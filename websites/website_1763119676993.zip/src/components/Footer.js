import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.brandBlock}>
            <div className={styles.brand}>
              <span className={styles.brandMark}>Muejpi</span>
              <span className={styles.brandText}>IT Academy</span>
            </div>
            <p className={styles.brandDescription}>
              We shape confident technology professionals through collaborative, project-driven learning in the heart of Ljubljana.
            </p>
            <div className={styles.socials} aria-label="Social links">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <span>in</span>
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
                <span>yt</span>
              </a>
              <a href="https://www.twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter">
                <span>tw</span>
              </a>
            </div>
          </div>
          <div>
            <h3 className={styles.widgetTitle}>Explore</h3>
            <ul className={styles.linkList}>
              <li><Link to="/about">About</Link></li>
              <li><Link to="/courses">Courses</Link></li>
              <li><Link to="/programs">Programs</Link></li>
              <li><Link to="/instructors">Instructors</Link></li>
              <li><Link to="/career">Career Support</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.widgetTitle}>Policies</h3>
            <ul className={styles.linkList}>
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/terms">Terms of Use</Link></li>
              <li><Link to="/cookie-policy">Cookie Policy</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.widgetTitle}>Contact</h3>
            <ul className={styles.contactList}>
              <li>
                <strong>Address:</strong> Slovenska cesta 56, 1000 Ljubljana, Slovenia
              </li>
              <li>
                <strong>Phone:</strong> <a href="tel:+38612345678">+386 1 234 5678</a>
              </li>
              <li>
                <strong>Email:</strong> [будет добавлен позже]
              </li>
              <li>
                <strong>Geography:</strong> Slovenia
              </li>
            </ul>
          </div>
        </div>
        <div className={styles.bottomBar}>
          <p>© {currentYear} Muejpi IT Academy. All rights reserved.</p>
          <p className={styles.location}>Based in Ljubljana, Slovenia.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;