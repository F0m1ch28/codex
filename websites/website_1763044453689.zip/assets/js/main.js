document.addEventListener("DOMContentLoaded", () => {
    // Mobile navigation
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.querySelector(".main-nav");

    if (navToggle && nav) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
            navToggle.setAttribute("aria-expanded", !expanded);
            nav.classList.toggle("open");
        });

        nav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                nav.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener("click", e => {
            const targetId = anchor.getAttribute("href").substring(1);
            const targetEl = document.getElementById(targetId);
            if (targetEl) {
                e.preventDefault();
                targetEl.scrollIntoView({ behavior: "smooth" });
                history.replaceState(null, "", `#${targetId}`);
            }
        });
    });

    // Scroll to top button
    const scrollBtn = document.getElementById("scrollToTop");
    if (scrollBtn) {
        window.addEventListener("scroll", () => {
            scrollBtn.style.display = window.scrollY > 320 ? "flex" : "none";
        });

        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    // Cookie banner
    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.getElementById("acceptCookies");
    const cookieKey = "nexvoroCookieConsent";

    if (cookieBanner && acceptBtn) {
        const consent = localStorage.getItem(cookieKey);
        if (!consent) {
            cookieBanner.style.display = "block";
        }

        acceptBtn.addEventListener("click", () => {
            localStorage.setItem(cookieKey, "accepted");
            cookieBanner.style.display = "none";
        });
    }
});