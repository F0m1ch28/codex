import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const navRef = React.useRef(null);

  const toggleMenu = () => setMenuOpen(prev => !prev);

  React.useEffect(() => {
    const handleOutside = (event) => {
      if (navRef.current && !navRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  React.useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 1024) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header className={styles.header} aria-label="Barra de navegación principal">
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="Orientavellio Inicio">
          <span className={styles.logoIcon} role="img" aria-hidden="true">🧭</span>
          <span className={styles.logoText}>Orientavellio</span>
        </Link>
        <button
          className={`${styles.menuToggle} ${menuOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          aria-label="Alternar menú"
          aria-expanded={menuOpen}
          aria-controls="main-navigation"
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="main-navigation"
          ref={navRef}
          className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}
        >
          <NavLink onClick={() => setMenuOpen(false)} to="/" end>
            Inicio
          </NavLink>
          <NavLink onClick={() => setMenuOpen(false)} to="/metodologia">
            Metodología
          </NavLink>
          <NavLink onClick={() => setMenuOpen(false)} to="/recursos">
            Recursos
          </NavLink>
          <NavLink onClick={() => setMenuOpen(false)} to="/blog">
            Blog
          </NavLink>
          <NavLink onClick={() => setMenuOpen(false)} to="/contacto">
            Contacto
          </NavLink>
        </nav>
      </div>
    </header>
  );
};

export default Header;