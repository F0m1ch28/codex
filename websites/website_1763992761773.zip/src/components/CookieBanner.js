import React from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const stored = localStorage.getItem('orientavellio_cookie_consent');
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('orientavellio_cookie_consent', 'accepted');
    setVisible(false);
  };

  const rejectCookies = () => {
    localStorage.setItem('orientavellio_cookie_consent', 'rejected');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Aviso de cookies">
      <div className={styles.content}>
        <h3>Navegación consciente de cookies</h3>
        <p>
          Utilizamos cookies esenciales para mejorar la experiencia, analizar hábitos de estudio y ofrecer contenidos relevantes.
          Puedes aceptar o administrar tus preferencias.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={rejectCookies} className={styles.secondary}>
            Rechazar
          </button>
          <button type="button" onClick={acceptCookies} className={styles.primary}>
            Aceptar cookies
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;