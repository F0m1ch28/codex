import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-label="Pie de página">
    <div className={styles.container}>
      <div className={styles.brand}>
        <span className={styles.logo} aria-label="Orientavellio logo">🧭</span>
        <p>
          Orientavellio impulsa estrategias personales con perspectiva mexicana,
          combinando autoconocimiento, planeación y acompañamiento para construir un futuro con propósito.
        </p>
      </div>
      <div className={styles.links}>
        <h4>Navegación</h4>
        <ul>
          <li><Link to="/">Inicio</Link></li>
          <li><Link to="/metodologia">Metodología</Link></li>
          <li><Link to="/recursos">Recursos</Link></li>
          <li><Link to="/blog">Blog</Link></li>
          <li><Link to="/contacto">Contacto</Link></li>
        </ul>
      </div>
      <div className={styles.legal}>
        <h4>Legal</h4>
        <ul>
          <li><Link to="/terminos">Términos de uso</Link></li>
          <li><Link to="/privacidad">Aviso de privacidad</Link></li>
          <li><Link to="/cookies">Política de cookies</Link></li>
        </ul>
      </div>
      <div className={styles.cta}>
        <h4>Recibe inspiración estratégica</h4>
        <p>Suscríbete para recibir ideas de planificación y hábitos conscientes.</p>
        <form className={styles.form} aria-label="Formulario de suscripción">
          <label htmlFor="footer-email" className="sr-only">Correo electrónico</label>
          <input type="email" id="footer-email" placeholder="Tu correo" aria-required="true" />
          <button type="submit" aria-label="Suscribirse al boletín">Unirme</button>
        </form>
      </div>
    </div>
    <div className={styles.bottom}>
      <p>© {new Date().getFullYear()} Orientavellio. Visión que traza caminos.</p>
    </div>
  </footer>
);

export default Footer;