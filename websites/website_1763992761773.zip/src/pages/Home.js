import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  const [stats, setStats] = React.useState({ personas: 0, planes: 0, talleres: 0 });
  const [visibleIndex, setVisibleIndex] = React.useState(0);
  const [selectedFilter, setSelectedFilter] = React.useState('todos');

  const testimonials = [
    {
      quote: 'El roadmap que diseñé con Orientavellio me dio claridad para alinear mi carrera con mi propósito.',
      name: 'María Fernanda Ruiz',
      role: 'Consultora de innovación',
      state: 'CDMX'
    },
    {
      quote: 'Implementé la metodología de revisión trimestral y mi balance vida-trabajo cambió por completo.',
      name: 'Luis Eduardo Chávez',
      role: 'Gerente de mercadotecnia',
      state: 'Guadalajara'
    },
    {
      quote: 'Aprendí a transformar metas difusas en objetivos SMART con hitos alcanzables.',
      name: 'Patricia Álvarez',
      role: 'Emprendedora social',
      state: 'Oaxaca'
    }
  ];

  const projects = [
    { id: 1, title: 'Mapa de carrera STEM', category: 'carrera', image: 'https://picsum.photos/1200/800?random=10', description: 'Diseño de ruta profesional para perfiles tecnológicos con foco en innovación mexicana.' },
    { id: 2, title: 'Plan financiero familiar', category: 'finanzas', image: 'https://picsum.photos/1200/800?random=11', description: 'Framework para planificar ahorro, educación y patrimonio con horizontes de 5 años.' },
    { id: 3, title: 'Rutina de aprendizaje continuo', category: 'aprendizaje', image: 'https://picsum.photos/1200/800?random=12', description: 'Sistema de hábitos de estudio mensual para mantener habilidades relevantes.' },
    { id: 4, title: 'Guía de bienestar integral', category: 'bienestar', image: 'https://picsum.photos/1200/800?random=13', description: 'Hitos para balancear salud, relaciones y propósito en tu visión personal.' }
  ];

  React.useEffect(() => {
    let frame = 0;
    const interval = setInterval(() => {
      frame += 1;
      setStats(prev => ({
        personas: Math.min(3200, prev.personas + Math.ceil((3200 - prev.personas) / 12)),
        planes: Math.min(840, prev.planes + Math.ceil((840 - prev.planes) / 14)),
        talleres: Math.min(145, prev.talleres + Math.ceil((145 - prev.talleres) / 16))
      }));
      if (frame > 32) clearInterval(interval);
    }, 80);
    return () => clearInterval(interval);
  }, []);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setVisibleIndex(prev => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const filteredProjects = selectedFilter === 'todos'
    ? projects
    : projects.filter(project => project.category === selectedFilter);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Orientavellio | Estrategia Personal a 3–5 Años</title>
        <meta
          name="description"
          content="Descubre cómo crear una estrategia personal integral con Orientavellio. Metodología, recursos y comunidad mexicana para proyectar tu visión a 3–5 años."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>
            Estrategia Personal a 3–5 Años:
            <span> diseña tu horizonte con claridad y propósito.</span>
          </h1>
          <p>
            En Orientavellio te guiamos para convertir tus sueños en un roadmap accionable.
            Conecta tus metas profesionales, financieras y de vida con una visión integral.
          </p>
          <div className={styles.heroActions}>
            <Link className={styles.primary} to="/metodologia">Explorar metodología</Link>
            <Link className={styles.secondary} to="/recursos">Ver recursos educativos</Link>
          </div>
          <ul className={styles.heroHighlights}>
            <li>Metas SMART con perspectiva mexicana</li>
            <li>Revisión trimestral y hábitos productivos</li>
            <li>Equilibrio vida-trabajo con sentido</li>
          </ul>
        </div>
        <div className={styles.heroImageWrapper}>
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Profesionales colaborando en un plan estratégico"
            loading="lazy"
          />
          <div className={styles.heroBadge}>
            <strong>Roadmap Personal</strong>
            <span>Define tu ruta 2024-2029</span>
          </div>
        </div>
      </section>

      <section className={styles.stats} aria-label="Indicadores de impacto">
        <div className={styles.statCard}>
          <span>{stats.personas.toLocaleString('es-MX')}</span>
          <p>Personas mexicanas han trazado su visión</p>
        </div>
        <div className={styles.statCard}>
          <span>{stats.planes.toLocaleString('es-MX')}</span>
          <p>Planes de vida y carrera estructurados</p>
        </div>
        <div className={styles.statCard}>
          <span>{stats.talleres.toLocaleString('es-MX')}</span>
          <p>Talleres de planeación impartidos</p>
        </div>
      </section>

      <section className={styles.mission}>
        <div className={styles.missionText}>
          <h2>Una plataforma educativa con propósito mexicano</h2>
          <p>
            Nuestra misión es ayudarte a diseñar una estrategia personal sostenible que
            honre tu identidad, tus prioridades familiares y tus aspiraciones profesionales.
          </p>
          <p>
            Integramos metodologías de planificación a largo plazo, autoconocimiento y gestión del tiempo
            para generar claridad, enfoque y decisiones coherentes con tu visión.
          </p>
          <Link to="/blog" className={styles.link}>Conoce historias de transformación</Link>
        </div>
        <div className={styles.missionVisual}>
          <img
            src="https://picsum.photos/800/600?random=2"
            alt="Mapa estratégico con hitos y metas personales"
            loading="lazy"
          />
          <div className={styles.timeline}>
            <h3>Timeline 3–5 años</h3>
            <ul>
              <li>
                <span>2024</span>
                Básicos de autoconocimiento y hábitos productivos.
              </li>
              <li>
                <span>2025</span>
                Consolidación de metas SMART y roadmap financiero.
              </li>
              <li>
                <span>2026</span>
                Iteración de estrategia profesional y aprendizaje continuo.
              </li>
              <li>
                <span>2027</span>
                Expansión de proyectos personales y propósito social.
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section className={styles.domains} aria-labelledby="titulo-dominios">
        <h2 id="titulo-dominios">Cuatro esferas clave para un plan integral</h2>
        <div className={styles.domainGrid}>
          <article>
            <span role="img" aria-hidden="true">💼</span>
            <h3>Carrera</h3>
            <p>Define hitos de crecimiento profesional, redes de apoyo y competencias estratégicas.</p>
          </article>
          <article>
            <span role="img" aria-hidden="true">💰</span>
            <h3>Finanzas</h3>
            <p>Crea metas financieras sostenibles con ahorros, educación y bienestar en mente.</p>
          </article>
          <article>
            <span role="img" aria-hidden="true">📚</span>
            <h3>Aprendizaje</h3>
            <p>Integra hábitos de estudio, certificaciones y prácticas de actualización continua.</p>
          </article>
          <article>
            <span role="img" aria-hidden="true">❤️</span>
            <h3>Vida personal</h3>
            <p>Cultiva relaciones, salud y propósito para un equilibrio auténtico.</p>
          </article>
        </div>
      </section>

      <section className={styles.process}>
        <div className={styles.processIntro}>
          <h2>Metodología Orientavellio paso a paso</h2>
          <p>
            Guiamos tu visión con un proceso colaborativo que transforma ideas en decisiones.
            Cada fase tiene herramientas prácticas, rituales de revisión y acompañamiento autodirigido.
          </p>
        </div>
        <div className={styles.steps}>
          <div className={styles.step}>
            <span>1</span>
            <h3>Exploración de autoconocimiento</h3>
            <p>
              Diagnóstico integral de valores, talentos, motivadores y contexto de vida.
            </p>
          </div>
          <div className={styles.step}>
            <span>2</span>
            <h3>Visión y prioridades</h3>
            <p>
              Definición de visión a 5 años, roles clave y prioridades por esfera de vida.
            </p>
          </div>
          <div className={styles.step}>
            <span>3</span>
            <h3>Roadmap personal</h3>
            <p>
              Construcción de objetivos SMART, hitos trimestrales y mapa de decisiones.
            </p>
          </div>
          <div className={styles.step}>
            <span>4</span>
            <h3>Revisión consciente</h3>
            <p>
              Rituales de seguimiento, ajustes ágiles y aprendizaje de retroalimentación.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.benefits}>
        <div className={styles.benefitsContent}>
          <h2>Beneficios que transforman tu visión en acción</h2>
          <ul>
            <li>
              <h3>Claridad de visión</h3>
              <p>Articula una narrativa personal coherente con tus metas a 3–5 años.</p>
            </li>
            <li>
              <h3>Objetivos concretos</h3>
              <p>Conviertes ideas abstractas en objetivos SMART con métricas y hitos.</p>
            </li>
            <li>
              <h3>Revisión continua</h3>
              <p>Adopta prácticas de seguimiento trimestral y ajustes conscientes.</p>
            </li>
          </ul>
        </div>
        <div className={styles.callout}>
          <h3>Toolkit estratégico</h3>
          <p>
            Mapas mentales, plantillas de hábitos, tableros de prioridad y guías de reflexión
            diseñadas para tu contexto mexicano.
          </p>
          <Link to="/recursos" className={styles.link}>Descargar herramientas</Link>
        </div>
      </section>

      <section className={styles.materials}>
        <h2>Contenido educativo disponible en Orientavellio</h2>
        <div className={styles.materialGrid}>
          <article>
            <h3>Microlecciones</h3>
            <p>Videos y lecturas cortas sobre enfoque, hábitos productivos y gestión del tiempo.</p>
          </article>
          <article>
            <h3>Plantillas</h3>
            <p>Formatos descargables para diseñar tu roadmap, definir OKRs y priorizar tareas.</p>
          </article>
          <article>
            <h3>Rutas guiadas</h3>
            <p>Programas temáticos para metas financieras, movilidad laboral y bienestar.</p>
          </article>
          <article>
            <h3>Comunidad</h3>
            <p>Sesiones en vivo y foros para compartir avances, aprendizajes y ajustes.</p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Testimonios">
        <div className={styles.testimonialsHeader}>
          <h2>Historias reales de visión en movimiento</h2>
          <p>
            Voces de profesionales mexicanos que transformaron su estrategia personal con la metodología Orientavellio.
          </p>
        </div>
        <div className={styles.carousel}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonial} ${index === visibleIndex ? styles.active : ''}`}
              aria-hidden={index !== visibleIndex}
            >
              <p className={styles.quote}>"{testimonial.quote}"</p>
              <div className={styles.person}>
                <h3>{testimonial.name}</h3>
                <span>{testimonial.role} · {testimonial.state}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team}>
        <h2>Equipo Orientavellio</h2>
        <div className={styles.teamGrid}>
          <article>
            <img src="https://picsum.photos/400/400?random=3" alt="Directora estratégica de Orientavellio" loading="lazy" />
            <h3>Regina Lozano</h3>
            <p>Directora estratégica</p>
            <span>Especialista en planeación a largo plazo y liderazgo con propósito.</span>
          </article>
          <article>
            <img src="https://picsum.photos/401/401?random=14" alt="Coach de desarrollo profesional" loading="lazy" />
            <h3>Héctor Palacios</h3>
            <p>Coach de desarrollo profesional</p>
            <span>Acompaña procesos de crecimiento y transición de carrera.</span>
          </article>
          <article>
            <img src="https://picsum.photos/402/402?random=15" alt="Mentora de hábitos productivos" loading="lazy" />
            <h3>Ana Sofía Beltrán</h3>
            <p>Mentora de hábitos</p>
            <span>Diseña rituales y sistemas productivos alineados a tu visión.</span>
          </article>
        </div>
      </section>

      <section className={styles.projects}>
        <div className={styles.projectsHeader}>
          <h2>Casos prácticos y roadmaps inspiradores</h2>
          <div className={styles.filters}>
            <button
              type="button"
              className={selectedFilter === 'todos' ? styles.activeFilter : ''}
              onClick={() => setSelectedFilter('todos')}
            >
              Todos
            </button>
            <button
              type="button"
              className={selectedFilter === 'carrera' ? styles.activeFilter : ''}
              onClick={() => setSelectedFilter('carrera')}
            >
              Carrera
            </button>
            <button
              type="button"
              className={selectedFilter === 'finanzas' ? styles.activeFilter : ''}
              onClick={() => setSelectedFilter('finanzas')}
            >
              Finanzas
            </button>
            <button
              type="button"
              className={selectedFilter === 'aprendizaje' ? styles.activeFilter : ''}
              onClick={() => setSelectedFilter('aprendizaje')}
            >
              Aprendizaje
            </button>
            <button
              type="button"
              className={selectedFilter === 'bienestar' ? styles.activeFilter : ''}
              onClick={() => setSelectedFilter('bienestar')}
            >
              Bienestar
            </button>
          </div>
        </div>
        <div className={styles.projectGrid} role="list">
          {filteredProjects.map(project => (
            <article key={project.id} role="listitem">
              <figure>
                <img src={project.image} alt={project.title} loading="lazy" />
              </figure>
              <div className={styles.projectBody}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq}>
        <h2>Preguntas frecuentes</h2>
        <div className={styles.accordion}>
          <details>
            <summary>¿Cómo inicio mi plan de vida con Orientavellio?</summary>
            <p>
              Inscríbete a la ruta de autoconocimiento, completa el diagnóstico inicial y descubre recomendaciones personalizadas.
            </p>
          </details>
          <details>
            <summary>¿Qué herramientas se incluyen?</summary>
            <p>
              Plantillas de objetivos SMART, tableros trimestrales, mapas de hábitos y guías para organizar tu tiempo con intención.
            </p>
          </details>
          <details>
            <summary>¿Cada cuánto reviso mis metas?</summary>
            <p>
              Te proponemos ciclos trimestrales con checkpoints mensuales para evaluar avances, aprendizajes y ajustes estratégicos.
            </p>
          </details>
          <details>
            <summary>¿La metodología contempla equilibrio vida-trabajo?</summary>
            <p>
              Sí, integramos esferas personales, relacionales y de bienestar para crear un plan integral que honre tu energía y tus prioridades.
            </p>
          </details>
        </div>
      </section>

      <section className={styles.blogPreview}>
        <div className={styles.blogIntro}>
          <h2>Últimas ideas en el blog</h2>
          <p>
            Conecta con insights, historias y recursos que impulsan tu enfoque y autogestión.
          </p>
          <Link to="/blog" className={styles.link}>Visitar blog completo</Link>
        </div>
        <div className={styles.blogGrid}>
          <article>
            <h3>Objetivos SMART con sabor mexicano</h3>
            <p>Aprende a contextualizar tus metas en tu realidad cultural y familiar.</p>
            <time dateTime="2024-04-02">2 abril 2024</time>
          </article>
          <article>
            <h3>Hábitos productivos para balancear tu energía</h3>
            <p>Diseña rutinas que respeten tus ritmos personales y ciclos trimestrales.</p>
            <time dateTime="2024-03-18">18 marzo 2024</time>
          </article>
          <article>
            <h3>Revisión estratégica: ritual mensual</h3>
            <p>Guía paso a paso para evaluar progreso y resetear prioridades.</p>
            <time dateTime="2024-03-01">1 marzo 2024</time>
          </article>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Traza tu roadmap personal con Orientavellio</h2>
          <p>
            Empieza hoy a diseñar una estrategia personal con visión, enfoque y hábitos conscientes.
            Descubre cómo cada decisión puede alinear tu futuro con tu propósito.
          </p>
          <Link to="/contacto" className={styles.primary}>Agendar una conversación</Link>
        </div>
      </section>
    </div>
  );
};

export default Home;