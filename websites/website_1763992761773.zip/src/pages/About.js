import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Metodología Orientavellio | Estrategia Personal Integral</title>
      <meta
        name="description"
        content="Conoce la metodología Orientavellio para diseñar estrategias personales a 3-5 años. Diagnóstico, visión, roadmap y revisión consciente."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Metodología Orientavellio</h1>
      <p>
        Combinamos introspección, planeación estratégica y acción consciente para que construyas
        un plan de vida robusto con un horizonte de 3 a 5 años.
      </p>
    </section>

    <section className={styles.framework}>
      <h2>Un marco metodológico que conecta visión y hábitos</h2>
      <p>
        Nuestro enfoque se inspira en metodologías de diseño de futuros, planeación estratégica y coaching ontológico,
        adaptadas al contexto mexicano. Cada etapa está diseñada para ayudarte a descubrir fortalezas, priorizar y ejecutar.
      </p>
      <div className={styles.grid}>
        <article>
          <h3>1. Exploración profunda</h3>
          <p>
            Instrumentos de autoconocimiento, evaluación de energía, análisis de roles y conversaciones clave.
          </p>
        </article>
        <article>
          <h3>2. Visión sistémica</h3>
          <p>
            Definición de narrativa personal, mapa de relaciones, escenarios posibles y propósito de largo plazo.
          </p>
        </article>
        <article>
          <h3>3. Roadmap personal</h3>
          <p>
            Objetivos SMART, hitos trimestrales, tableros de prioridades y criterios de decisión para cada esfera.
          </p>
        </article>
        <article>
          <h3>4. Integración de hábitos</h3>
          <p>
            Ritualizar prácticas semanalmente, gestionar energía y diseñar rutinas de aprendizaje continuo.
          </p>
        </article>
        <article>
          <h3>5. Revisión consciente</h3>
          <p>
            Ciclos mensuales y trimestrales con indicadores clave, storytelling de aprendizajes y ajustes ágiles.
          </p>
        </article>
        <article>
          <h3>6. Comunidad y retroalimentación</h3>
          <p>
            Espacios para compartir avances, recibir perspectivas y fortalecer la rendición de cuentas.
          </p>
        </article>
      </div>
    </section>

    <section className={styles.timeline}>
      <h2>Ruta sugerida para tus primeros seis meses</h2>
      <ol>
        <li>
          <strong>Mes 1:</strong> Diagnóstico integral y declaración de visión.
        </li>
        <li>
          <strong>Mes 2:</strong> Diseño de objetivos SMART y plan financiero base.
        </li>
        <li>
          <strong>Mes 3:</strong> Implementación de hábitos productivos y sistema de revisión semanal.
        </li>
        <li>
          <strong>Mes 4:</strong> Retroalimentación con mentores y ajustes a roadmap profesional.
        </li>
        <li>
          <strong>Mes 5:</strong> Integración de aprendizajes y expansión de proyectos personales.
        </li>
        <li>
          <strong>Mes 6:</strong> Revisión trimestral, storytelling de avances y próximos retos.
        </li>
      </ol>
    </section>

    <section className={styles.values}>
      <h2>Principios que guían nuestra metodología</h2>
      <div className={styles.valuesGrid}>
        <article>
          <h3>Autenticidad</h3>
          <p>Respetamos tu historia y contexto; la estrategia se construye desde tus valores.</p>
        </article>
        <article>
          <h3>Intencionalidad</h3>
          <p>Todo plan se alinea con metas claras, priorizadas y factibles.</p>
        </article>
        <article>
          <h3>Adaptabilidad</h3>
          <p>El plan evoluciona con tus aprendizajes, circunstancias y descubrimientos.</p>
        </article>
        <article>
          <h3>Balance</h3>
          <p>Cada esfera de tu vida tiene espacio y atención consciente.</p>
        </article>
      </div>
    </section>
  </div>
);

export default About;