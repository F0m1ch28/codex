import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Recursos Orientavellio | Herramientas y Rutas de Estrategia Personal</title>
      <meta
        name="description"
        content="Explora recursos educativos de Orientavellio: kits de planificación, plantillas, rutas guiadas y comunidad para tu estrategia personal."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Recursos para impulsar tu estrategia personal</h1>
      <p>
        Descarga herramientas, sigue rutas guiadas y accede a contenidos diseñados para consolidar tu roadmap personal.
      </p>
    </section>

    <section className={styles.catalogue}>
      <article>
        <h3>Kit de inicio estratégico</h3>
        <p>
          Plantillas para diagnóstico, definición de visión, mapa de roles y design sprint personal.
        </p>
      </article>
      <article>
        <h3>Rutas temáticas</h3>
        <p>
          Programas curados para metas financieras, desarrollo profesional, aprendizaje y bienestar integral.
        </p>
      </article>
      <article>
        <h3>Biblioteca Orientavellio</h3>
        <p>
          Guías descargables, podcasts, infografías y playlists que acompañan tu proceso día a día.
        </p>
      </article>
      <article>
        <h3>Cuaderno de hábitos</h3>
        <p>
          Estructura semanal para seguimiento de hábitos productivos, energéticos y de reflexión.
        </p>
      </article>
      <article>
        <h3>Tableros digitales</h3>
        <p>
          Templates en Notion y Trello para centralizar objetivos SMART, hitos y revisiones.
        </p>
      </article>
      <article>
        <h3>Mentorías grupales</h3>
        <p>
          Sesiones colaborativas con facilitadores y comunidad para resolver dudas y ajustar tu plan.
        </p>
      </article>
    </section>

    <section className={styles.resources}>
      <h2>Cómo aprovechar los recursos</h2>
      <ul>
        <li><strong>Diagnóstico:</strong> inicia con la autoevaluación y define tu visión.</li>
        <li><strong>Planificación:</strong> usa los tableros para estructurar objetivos y proyectos.</li>
        <li><strong>Hábitos:</strong> integra el cuaderno de hábitos en tus rutinas diarias.</li>
        <li><strong>Revisión:</strong> agenda tu revisión mensual con nuestra guía paso a paso.</li>
        <li><strong>Comunidad:</strong> comparte avances y aprende de otras experiencias mexicanas.</li>
      </ul>
    </section>
  </div>
);

export default Services;