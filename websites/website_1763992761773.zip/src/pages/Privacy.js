import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Aviso de Privacidad | Orientavellio</title>
      <meta
        name="description"
        content="Aviso de privacidad de Orientavellio: datos recopilados, finalidades, derechos ARCO y protección de información personal."
      />
    </Helmet>
    <section>
      <h1>Aviso de Privacidad</h1>
      <p>Última actualización: 1 abril 2024</p>
      <h2>1. Responsable</h2>
      <p>
        Orientavellio es responsable del tratamiento de tus datos personales y protege tu información conforme a la normativa mexicana.
      </p>
      <h2>2. Datos recabados</h2>
      <p>
        Recopilamos nombre, correo y metas declaradas para proveer recursos personalizados y comunicación relevante.
      </p>
      <h2>3. Finalidades</h2>
      <p>
        Utilizamos tus datos para ofrecer servicios educativos, analizar mejoras y enviar comunicación sobre planificación estratégica.
      </p>
      <h2>4. Derechos ARCO</h2>
      <p>
        Puedes acceder, rectificar, cancelar u oponerte al tratamiento de tus datos escribiendo a privacidad@orientavellio.site.
      </p>
      <h2>5. Transferencias</h2>
      <p>
        No compartimos tus datos con terceros sin tu consentimiento, salvo obligaciones legales.
      </p>
      <h2>6. Cambios al aviso</h2>
      <p>
        Las actualizaciones se publicarán en este sitio. Mantente al tanto de la versión vigente.
      </p>
    </section>
  </div>
);

export default Privacy;