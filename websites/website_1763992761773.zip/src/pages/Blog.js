import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Cómo construir una visión personal inspiradora',
    excerpt: 'Explora ejercicios de reflexión y técnicas de storytelling para articular tu visión a 5 años.',
    date: '12 abril 2024',
    readTime: '7 min de lectura'
  },
  {
    title: 'Diseña objetivos SMART que conecten con tus valores',
    excerpt: 'Convierte deseos en metas concretas utilizando criterios medibles y relevantes.',
    date: '5 abril 2024',
    readTime: '6 min de lectura'
  },
  {
    title: 'Rituales de revisión trimestral',
    excerpt: 'Aprende a revisar tus metas con preguntas poderosas y datos significativos.',
    date: '27 marzo 2024',
    readTime: '5 min de lectura'
  },
  {
    title: 'Guía para tu plan financiero a 5 años',
    excerpt: 'Estructura metas de ahorro, inversión responsable y protección familiar.',
    date: '18 marzo 2024',
    readTime: '8 min de lectura'
  },
  {
    title: 'Hábitos productivos para mantener el enfoque',
    excerpt: 'Diseña rutinas diarias que sostengan tu energía y objetivos.',
    date: '10 marzo 2024',
    readTime: '6 min de lectura'
  },
  {
    title: 'Aprendizaje continuo en la economía del conocimiento',
    excerpt: 'Construye un itinerario de aprendizaje relevante y actualizado.',
    date: '2 marzo 2024',
    readTime: '7 min de lectura'
  }
];

const Blog = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Blog Orientavellio | Ideas para tu Estrategia Personal</title>
      <meta
        name="description"
        content="Lee artículos del blog Orientavellio sobre estrategia personal, planificación a largo plazo, hábitos y metas SMART."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Ideas frescas para tu estrategia personal</h1>
      <p>
        Historias, herramientas y perspectivas para nutrir tu plan de vida, equilibrar prioridades y ejercitar tu visión.
      </p>
    </section>
    <section className={styles.grid}>
      {posts.map(post => (
        <article key={post.title}>
          <h2>{post.title}</h2>
          <p>{post.excerpt}</p>
          <div className={styles.meta}>
            <span>{post.date}</span>
            <span>{post.readTime}</span>
          </div>
          <button type="button" aria-label={`Continuar leyendo: ${post.title}`}>Seguir leyendo</button>
        </article>
      ))}
    </section>
  </div>
);

export default Blog;