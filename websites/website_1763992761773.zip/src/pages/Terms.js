import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Términos de Uso | Orientavellio</title>
      <meta
        name="description"
        content="Consulta los términos de uso de Orientavellio. Reglas de acceso, responsabilidades y propiedad intelectual de la plataforma."
      />
    </Helmet>
    <section>
      <h1>Términos de Uso</h1>
      <p>Última actualización: 1 abril 2024</p>
      <h2>1. Aceptación</h2>
      <p>
        Al acceder a orientavellio.site aceptas los presentes términos y te comprometes a utilizarlos conforme a la ley mexicana y buenas prácticas.
      </p>
      <h2>2. Uso de la plataforma</h2>
      <p>
        Los recursos se proporcionan con fines educativos. Las decisiones derivadas de la metodología son responsabilidad del usuario.
      </p>
      <h2>3. Propiedad intelectual</h2>
      <p>
        El contenido, imágenes, textos y herramientas pertenecen a Orientavellio. No se autoriza su reproducción sin consentimiento.
      </p>
      <h2>4. Limitación de responsabilidad</h2>
      <p>
        Orientavellio no se responsabiliza por resultados específicos; ofrecemos lineamientos y buenas prácticas para tu estrategia personal.
      </p>
      <h2>5. Modificaciones</h2>
      <p>
        Podemos actualizar estos términos en cualquier momento. Las modificaciones entrarán en vigor al publicarse en el sitio.
      </p>
    </section>
  </div>
);

export default Terms;