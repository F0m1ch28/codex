import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Cookies.module.css';

const Cookies = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Política de Cookies | Orientavellio</title>
      <meta
        name="description"
        content="Política de cookies de Orientavellio: uso de cookies esenciales y analíticas, opciones de gestión y almacenamiento."
      />
    </Helmet>
    <section>
      <h1>Política de Cookies</h1>
      <p>Última actualización: 1 abril 2024</p>
      <h2>¿Qué son las cookies?</h2>
      <p>
        Son archivos pequeños que se almacenan en tu dispositivo para recordar preferencias, analizar navegación y mejorar tu experiencia.
      </p>
      <h2>Tipos de cookies utilizadas</h2>
      <ul>
        <li><strong>Esenciales:</strong> permiten el funcionamiento del sitio y la gestión de sesiones.</li>
        <li><strong>Analíticas:</strong> nos ayudan a comprender el uso de recursos y optimizar contenidos.</li>
      </ul>
      <h2>Gestión de cookies</h2>
      <p>
        Puedes aceptar o rechazar cookies desde nuestro banner o configurarlas en tu navegador en cualquier momento.
      </p>
      <h2>Actualizaciones</h2>
      <p>
        Revisaremos esta política periódicamente para reflejar cambios tecnológicos o regulatorios.
      </p>
    </section>
  </div>
);

export default Cookies;