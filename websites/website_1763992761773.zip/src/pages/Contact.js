import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = React.useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Ingresa tu nombre completo.';
    if (!form.email.trim()) {
      newErrors.email = 'Ingresa tu correo.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(form.email)) {
      newErrors.email = 'Correo inválido.';
    }
    if (!form.message.trim()) newErrors.message = 'Cuéntanos sobre tu objetivo.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setForm({ name: '', email: '', message: '' });
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contacto Orientavellio | Diseñemos tu Estrategia Personal</title>
        <meta
          name="description"
          content="Escríbenos para iniciar tu estrategia personal. Orientavellio responde dudas sobre planificación, recursos y acompañamiento."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Conversemos sobre tu estrategia</h1>
        <p>
          Cuéntanos tus metas, contextos y retos. Diseñemos juntos un plan que refleje tu esencia y proyección.
        </p>
      </section>
      <section className={styles.formSection}>
        <form onSubmit={handleSubmit} aria-label="Formulario de contacto Orientavellio">
          <div className={styles.field}>
            <label htmlFor="name">Nombre completo</label>
            <input
              type="text"
              id="name"
              name="name"
              value={form.name}
              onChange={handleChange}
              aria-invalid={!!errors.name}
              aria-describedby={errors.name ? 'error-name' : undefined}
            />
            {errors.name && <span id="error-name" className={styles.error}>{errors.name}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Correo electrónico</label>
            <input
              type="email"
              id="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              aria-invalid={!!errors.email}
              aria-describedby={errors.email ? 'error-email' : undefined}
            />
            {errors.email && <span id="error-email" className={styles.error}>{errors.email}</span>}
          </div>
          <div className={styles.field}>
            <label htmlFor="message">Mensaje</label>
            <textarea
              id="message"
              name="message"
              value={form.message}
              onChange={handleChange}
              rows="5"
              aria-invalid={!!errors.message}
              aria-describedby={errors.message ? 'error-message' : undefined}
            />
            {errors.message && <span id="error-message" className={styles.error}>{errors.message}</span>}
          </div>
          <button type="submit">Enviar mensaje</button>
          {submitted && <p className={styles.success}>Gracias por tu mensaje. Nos pondremos en contacto contigo.</p>}
        </form>
        <aside className={styles.info}>
          <h2>Información de contacto</h2>
          <p>Email: hola@orientavellio.site</p>
          <p>CDMX · Consultoría digital y sesiones híbridas</p>
          <ul>
            <li>Planeación estratégica personalizada</li>
            <li>Mentorías grupales y talleres</li>
            <li>Recursos descargables y comunidad</li>
          </ul>
        </aside>
      </section>
    </div>
  );
};

export default Contact;