document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const isOpen = navLinks.getAttribute('data-open') === 'true';
      navLinks.setAttribute('data-open', (!isOpen).toString());
      navLinks.style.display = isOpen ? 'none' : 'flex';
    });
  }

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('[data-cookie-accept]');
  const declineBtn = document.querySelector('[data-cookie-decline]');
  const consentKey = 'pic-cookie-consent';

  if (banner && acceptBtn && declineBtn) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      banner.classList.add('active');
    }

    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'accepted');
      banner.classList.remove('active');
    });

    declineBtn.addEventListener('click', () => {
      localStorage.setItem(consentKey, 'declined');
      banner.classList.remove('active');
    });
  }

  const complexityRange = document.querySelector('#complexityRange');
  const complexityValue = document.querySelector('#complexityValue');
  const matrixNodes = document.querySelectorAll('[data-node-threshold]');

  if (complexityRange && complexityValue && matrixNodes.length) {
    const updateNodes = () => {
      const currentValue = parseInt(complexityRange.value, 10);
      complexityValue.textContent = currentValue;

      matrixNodes.forEach((node) => {
        const threshold = parseInt(node.dataset.nodeThreshold, 10);
        if (currentValue >= threshold) {
          node.classList.add('active');
        } else {
          node.classList.remove('active');
        }
      });
    };

    complexityRange.addEventListener('input', updateNodes);
    updateNodes();
  }

  const sandboxButtons = document.querySelectorAll('[data-code-target]');
  sandboxButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetId = btn.dataset.codeTarget;
      const target = document.getElementById(targetId);
      if (target) {
        target.classList.toggle('active');
        btn.classList.toggle('btn-primary');
      }
    });
  });
});