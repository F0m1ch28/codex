```javascript
import { useEffect } from "react";
import { useLanguage } from "../contexts/LanguageContext";

export const usePageTitle = (titleEn, titleEs) => {
  const { language } = useLanguage();
  useEffect(() => {
    document.title = language === "en" ? `${titleEn} | Tu Progreso Hoy` : `${titleEs} | Tu Progreso Hoy`;
  }, [language, titleEn, titleEs]);
};
```