```javascript
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

const LanguageContext = createContext();

const STORAGE_KEY = "tph-lang";

const strings = {
  en: {
    nav: {
      home: "Home",
      inflation: "Inflation Insights",
      course: "Course",
      resources: "Resources",
      contact: "Contact"
    },
    heroTitle: "Financial learning for resilient Argentines",
    heroSubtitle:
      "Build confident decisions with transparent data, longitudinal CPI insights, and curated learning pathways designed for Argentina's economy.",
    heroSecondary:
      "Bilingual guidance, updated market narratives, and exercises that strengthen decision-making without promising outcomes.",
    currencyLabel: "ARS ➔ USD rate (1 ARS)",
    currencyUpdated: "Last update",
    insightsTitle: "Learning powered by insights",
    courseTitle: "Course overview at a glance",
    testimonialsTitle: "Voices from our community",
    formTitle: "Start your data-driven learning journey",
    formSubtitle:
      "Complete the form to receive a double opt-in email with your access instructions for the free trial lesson.",
    name: "Full name",
    email: "Email",
    phone: "Phone (optional)",
    languagePreference: "Preferred language for communications",
    message: "Message",
    submit: "Submit",
    confirmOptIn:
      "I agree to receive the double opt-in email and confirm that Tu Progreso Hoy provides education, not financial services.",
    thankYouTitle: "Thank you for confirming interest",
    thankYouBody:
      "We have sent a confirmation email. Please check your inbox and confirm your subscription. Once confirmed, you will receive the link to your free trial lesson.",
    backHome: "Return to Home",
    privacyTitle: "Privacy Notice",
    cookiesTitle: "Cookies Policy",
    termsTitle: "Terms of Use",
    inflationTitle: "Inflation methodology and context",
    coursePageTitle: "Syllabus and modules",
    resourcesTitle: "Resource library",
    contactTitle: "Contact Tu Progreso Hoy",
    faqTitle: "Frequently Asked Questions",
    contactSuccess:
      "Thank you for reaching out. We operate with a double opt-in to protect your preferences. Please check your email to confirm."
  },
  es: {
    nav: {
      home: "Inicio",
      inflation: "Inflación",
      course: "Curso",
      resources: "Recursos",
      contact: "Contacto"
    },
    heroTitle: "Aprendizaje financiero para personas resilientes",
    heroSubtitle:
      "Toma decisiones conscientes con datos transparentes, análisis de IPC y rutas educativas adaptadas a la economía argentina.",
    heroSecondary:
      "Guía bilingüe, narrativas actualizadas y ejercicios que fortalecen tu criterio sin prometer resultados.",
    currencyLabel: "Tasa ARS ➔ USD (1 ARS)",
    currencyUpdated: "Última actualización",
    insightsTitle: "Aprendizaje impulsado por insights",
    courseTitle: "Resumen del curso",
    testimonialsTitle: "Voces de la comunidad",
    formTitle: "Comienza tu recorrido guiado por datos",
    formSubtitle:
      "Completa el formulario para recibir el correo de doble confirmación con las instrucciones de tu clase gratuita.",
    name: "Nombre completo",
    email: "Correo electrónico",
    phone: "Teléfono (opcional)",
    languagePreference: "Idioma preferido para comunicarnos",
    message: "Mensaje",
    submit: "Enviar",
    confirmOptIn:
      "Acepto recibir el correo de doble confirmación y comprendo que Tu Progreso Hoy brinda educación, no servicios financieros.",
    thankYouTitle: "Gracias por confirmar tu interés",
    thankYouBody:
      "Te enviamos un correo de confirmación. Revisa tu bandeja de entrada y confirma tu suscripción. Una vez confirmada, recibirás el enlace a tu clase gratuita.",
    backHome: "Volver al inicio",
    privacyTitle: "Aviso de Privacidad",
    cookiesTitle: "Política de Cookies",
    termsTitle: "Términos de Uso",
    inflationTitle: "Metodología e indicadores",
    coursePageTitle: "Programa y módulos",
    resourcesTitle: "Repositorio de recursos",
    contactTitle: "Contacto Tu Progreso Hoy",
    faqTitle: "Preguntas frecuentes",
    contactSuccess:
      "Gracias por tu mensaje. Trabajamos con doble opt-in para proteger tus preferencias. Revisa tu correo y confirma."
  }
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState("en");

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem(STORAGE_KEY) : null;
    if (stored && (stored === "en" || stored === "es")) {
      setLanguage(stored);
    }
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, language);
    }
  }, [language]);

  const value = useMemo(
    () => ({
      language,
      setLanguage,
      t: strings[language]
    }),
    [language]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};

export const useLanguage = () => useContext(LanguageContext);
```