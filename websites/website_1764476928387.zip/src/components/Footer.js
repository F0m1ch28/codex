```javascript
import React from "react";
import { Link } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";

const Footer = () => {
  const { language } = useLanguage();

  const address = "Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina";
  const phone = "+54 11 5555-1234";

  return (
    <footer>
      <div className="container">
        <div className="footer-grid">
          <div>
            <h3 style={{ fontFamily: "var(--font-heading)", marginTop: 0 }}>Tu Progreso Hoy</h3>
            <p style={{ maxWidth: 260 }}>
              Bilingual financial education rooted in Argentina’s data reality. Datos verificados para planificar tu presupuesto.
            </p>
            <p className="small-print">
              Мы не предоставляем финансовые услуги. / We do not provide financial services. / No brindamos servicios financieros.
            </p>
          </div>
          <div>
            <h4>{language === "en" ? "Explore" : "Explorar"}</h4>
            <ul style={{ flexDirection: "column", gap: "8px" }}>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/inflation">Inflation insights</Link>
              </li>
              <li>
                <Link to="/course">Course</Link>
              </li>
              <li>
                <Link to="/resources">Resources</Link>
              </li>
            </ul>
          </div>
          <div>
            <h4>{language === "en" ? "Policies" : "Políticas"}</h4>
            <ul style={{ flexDirection: "column", gap: "8px" }}>
              <li>
                <Link to="/privacy">Privacy</Link>
              </li>
              <li>
                <Link to="/cookies">Cookies</Link>
              </li>
              <li>
                <Link to="/terms">Terms</Link>
              </li>
              <li>
                <a href="/sitemap.xml">Sitemap</a>
              </li>
              <li>
                <a href="/robots.txt">Robots</a>
              </li>
            </ul>
          </div>
          <div>
            <h4>{language === "en" ? "Contact" : "Contacto"}</h4>
            <p>{address}</p>
            <p>
              <a href="tel:+541155551234" style={{ color: "white" }}>
                {phone}
              </a>
            </p>
            <div className="social-links" aria-label="Social media">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer noopener">
                LinkedIn
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer noopener">
                YouTube
              </a>
              <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <p>
            &copy; {new Date().getFullYear()} Tu Progreso Hoy. {language === "en" ? "All rights reserved." : "Todos los derechos reservados."}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
```