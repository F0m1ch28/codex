```javascript
import React, { useEffect, useState } from "react";

const STORAGE_KEY = "tph-disclaimer-ack";

const DisclaimerModal = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        const timer = setTimeout(() => setOpen(true), 500);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const close = () => {
    setOpen(false);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, "acknowledged");
    }
  };

  if (!open) return null;

  return (
    <div className="disclaimer-modal" role="dialog" aria-modal="true" aria-labelledby="disclaimer-title">
      <div className="disclaimer-content">
        <h3 id="disclaimer-title">Disclaimer</h3>
        <p>
          Мы не предоставляем финансовые услуги. / We do not provide financial services. / No brindamos servicios financieros.
        </p>
        <p className="small-print">
          Tu Progreso Hoy delivers educational content supported by public and proprietary datasets. Decisions remain your responsibility. Review the Terms for more details.
        </p>
        <button onClick={close} className="cta-button" style={{ padding: "12px 24px" }}>
          OK
        </button>
      </div>
    </div>
  );
};

export default DisclaimerModal;
```