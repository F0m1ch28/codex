```javascript
import React, { useEffect, useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";

const CurrencyTracker = () => {
  const { t, language } = useLanguage();
  const [rate, setRate] = useState(null);
  const [updated, setUpdated] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const controller = new AbortController();

    const fetchRate = async () => {
      try {
        const response = await fetch("https://api.exchangerate.host/latest?base=ARS&symbols=USD", {
          signal: controller.signal
        });
        if (!response.ok) throw new Error("Network response was not ok");
        const data = await response.json();
        const value = data?.rates?.USD;
        if (value) {
          setRate(value);
          setUpdated(new Date(data.date || Date.now()).toLocaleString(language === "en" ? "en-GB" : "es-AR", {
            year: "numeric",
            month: "short",
            day: "numeric"
          }));
        } else {
          throw new Error("Missing rate");
        }
      } catch (err) {
        if (err.name !== "AbortError") {
          setError(language === "en" ? "Live rate temporarily unavailable" : "Tasa en vivo no disponible por el momento");
        }
      }
    };

    fetchRate();

    const interval = setInterval(fetchRate, 1000 * 60 * 30);
    return () => {
      controller.abort();
      clearInterval(interval);
    };
  }, [language]);

  return (
    <div className="currency-card" aria-live="polite">
      <span className="badge-secondary">{t.currencyLabel}</span>
      {rate ? (
        <strong>USD {rate.toFixed(4)}</strong>
      ) : (
        <strong>{error ? "—" : "…"}</strong>
      )}
      <span style={{ fontSize: "0.85rem" }}>
        {error ? error : `${t.currencyUpdated}: ${updated || (language === "en" ? "loading…" : "cargando…")}`}
      </span>
    </div>
  );
};

export default CurrencyTracker;
```