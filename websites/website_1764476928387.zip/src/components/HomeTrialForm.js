```javascript
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";

const HomeTrialForm = () => {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    preference: "en",
    consent: false
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = language === "en" ? "Name is required" : "El nombre es obligatorio";
    if (!formData.email.trim()) newErrors.email = language === "en" ? "Email is required" : "El correo es obligatorio";
    if (!formData.consent) newErrors.consent = language === "en" ? "Consent is required" : "Debes aceptar";
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      navigate("/thank-you", {
        state: {
          source: "home-form",
          email: formData.email,
          language: formData.preference
        }
      });
    }
  };

  return (
    <div className="form-card" id="trial-form">
      <h3 style={{ fontFamily: "var(--font-heading)", marginTop: 0 }}>{t.formTitle}</h3>
      <p className="small-print">{t.formSubtitle}</p>
      <form onSubmit={handleSubmit} noValidate>
        <div>
          <label htmlFor="trial-name">{t.name}</label>
          <input
            id="trial-name"
            name="name"
            value={formData.name}
            onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "error-name" : undefined}
          />
          {errors.name && (
            <span className="small-print" id="error-name" role="alert">
              {errors.name}
            </span>
          )}
        </div>
        <div>
          <label htmlFor="trial-email">{t.email}</label>
          <input
            id="trial-email"
            type="email"
            name="email"
            value={formData.email}
            onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "error-email" : undefined}
          />
          {errors.email && (
            <span className="small-print" id="error-email" role="alert">
              {errors.email}
            </span>
          )}
        </div>
        <div>
          <label htmlFor="trial-phone">{t.phone}</label>
          <input
            id="trial-phone"
            name="phone"
            value={formData.phone}
            onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
          />
        </div>
        <div>
          <label htmlFor="trial-language">{t.languagePreference}</label>
          <select
            id="trial-language"
            name="preference"
            value={formData.preference}
            onChange={(e) => setFormData((prev) => ({ ...prev, preference: e.target.value }))}
          >
            <option value="en">English</option>
            <option value="es">Español</option>
          </select>
        </div>
        <div className="checkbox">
          <input
            id="trial-consent"
            type="checkbox"
            checked={formData.consent}
            onChange={(e) => setFormData((prev) => ({ ...prev, consent: e.target.checked }))}
          />
          <label htmlFor="trial-consent">
            {t.confirmOptIn}
          </label>
        </div>
        {errors.consent && (
          <span className="small-print" id="error-consent" role="alert">
            {errors.consent}
          </span>
        )}
        <button type="submit" className="cta-button" aria-label="Submit to receive free trial lesson confirmation">
          Получить бесплатный пробный урок
        </button>
        <p className="small-print">
          {language === "en"
            ? "Double opt-in in effect: you will only receive materials after confirming your email."
            : "Doble opt-in activo: solo recibirás materiales tras confirmar tu correo."}
        </p>
      </form>
    </div>
  );
};

export default HomeTrialForm;
```