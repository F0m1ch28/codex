```javascript
import React from "react";
import { Link, NavLink } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import LanguageSwitcher from "./LanguageSwitcher";

const Header = () => {
  const { t } = useLanguage();

  return (
    <header className="header" role="banner">
      <div className="notice-banner">
        Plataforma educativa con datos esenciales, sin asesoría financiera directa.
      </div>
      <div className="container inner">
        <Link to="/" className="logo" aria-label="Tu Progreso Hoy Home">
          Tu Progreso Hoy
        </Link>
        <nav aria-label="Main navigation">
          <ul>
            <li>
              <NavLink to="/">{t.nav.home}</NavLink>
            </li>
            <li>
              <NavLink to="/inflation">{t.nav.inflation}</NavLink>
            </li>
            <li>
              <NavLink to="/course">{t.nav.course}</NavLink>
            </li>
            <li>
              <NavLink to="/resources">{t.nav.resources}</NavLink>
            </li>
            <li>
              <NavLink to="/contact">{t.nav.contact}</NavLink>
            </li>
          </ul>
        </nav>
        <LanguageSwitcher />
      </div>
    </header>
  );
};

export default Header;
```