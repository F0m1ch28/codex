```javascript
import React, { useEffect, useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";

const COOKIE_KEY = "tph-cookie-consent";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const { language } = useLanguage();

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = window.localStorage.getItem(COOKIE_KEY);
      if (!stored) {
        const timer = setTimeout(() => setVisible(true), 800);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const handleChoice = (status) => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(COOKIE_KEY, status);
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-modal="false" aria-live="polite">
      <p>
        {language === "en"
          ? "We use analytical cookies to understand how our learning resources are used. No advertising cookies are set. You can accept or decline."
          : "Utilizamos cookies analíticas para comprender cómo se usan nuestros recursos. No empleamos cookies publicitarias. Podés aceptar o rechazar."}
      </p>
      <div className="cookie-actions">
        <button className="primary" onClick={() => handleChoice("accepted")}>
          {language === "en" ? "Accept analytical cookies" : "Aceptar cookies analíticas"}
        </button>
        <button className="secondary" onClick={() => handleChoice("declined")}>
          {language === "en" ? "Decline" : "Rechazar"}
        </button>
        <a href="/cookies" style={{ fontSize: "0.85rem" }}>
          {language === "en" ? "Review policy" : "Ver política"}
        </a>
      </div>
    </div>
  );
};

export default CookieBanner;
```