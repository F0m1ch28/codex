```javascript
import React from "react";
import { Helmet } from "react-helmet-async";

const BASE_URL = "https://www.tuprogresohoy.com";

const SEO = ({ title, description, path = "/" }) => {
  const url = `${BASE_URL}${path === "/" ? "" : path}`;
  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={url} />
      <link rel="alternate" hrefLang="en" href={url} />
      <link rel="alternate" hrefLang="es-AR" href={url} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={url} />
      <meta property="og:type" content="website" />
      <meta property="og:locale" content="en_US" />
      <meta property="og:locale:alternate" content="es_AR" />
    </Helmet>
  );
};

export default SEO;
```