```javascript
import React from "react";
import { Link } from "react-router-dom";
import CurrencyTracker from "../components/CurrencyTracker";
import HomeTrialForm from "../components/HomeTrialForm";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const HomePage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Home", "Inicio");

  return (
    <>
      <SEO
        title="Tu Progreso Hoy | Financial Learning for Argentina"
        description="Transparent inflation analysis, insights and bilingual courses built for Argentina. Datos verificados para planificar tu presupuesto."
        path="/"
      />
      <section className="hero">
        <div className="container hero-content">
          <div>
            <span className="badge">Buenos Aires · Argentina</span>
            <h1>{t.heroTitle}</h1>
            <p>{t.heroSubtitle}</p>
            <p>
              {t.heroSecondary}{" "}
              <strong>
                Decisiones responsables, objetivos nítidos. Conocimiento financiero impulsado por tendencias.
              </strong>
            </p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "16px", alignItems: "center" }}>
              <CurrencyTracker />
              <Link to="/course" className="cta-button">
                {language === "en" ? "Discover the syllabus" : "Descubre el programa"}
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container">
          <h2>{t.insightsTitle}</h2>
          <p>
            Información confiable que respalda elecciones responsables sobre tu dinero. Pasos acertados hoy, mejor futuro mañana.
          </p>
          <div className="promise-grid">
            <div className="promise-card">
              <span className="tag">Insight</span>
              <h3>Datos verificados para planificar tu presupuesto.</h3>
              <p>
                We prioritise verifiable datasets from Banco Central, INDEC, and private sector monitors. Each dataset is cross-examined to help you adapt budgets to evolving realities.
              </p>
            </div>
            <div className="promise-card">
              <span className="tag">Context</span>
              <h3>Análisis transparentes y datos de mercado para decidir con seguridad.</h3>
              <p>
                Every dashboard blends CPI, FX, and wage data to show the full panorama behind inflationary trends, enabling informed judgement instead of assumptions.
              </p>
            </div>
            <div className="promise-card">
              <span className="tag">Learning</span>
              <h3>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</h3>
              <p>
                Weekly prompts help you practice scenario planning, spot liquidity signals, and design your own decision frameworks anchored in reality.
              </p>
            </div>
            <div className="promise-card">
              <span className="tag">Growth</span>
              <h3>De la información al aprendizaje: fortalece tu criterio financiero paso a paso.</h3>
              <p>
                Structured lessons accompany each dataset so you transform raw information into meaningful knowledge, always respecting your personal risk profile.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-light">
        <div className="container grid-2" style={{ alignItems: "center" }}>
          <div>
            <h2>{t.courseTitle}</h2>
            <p>
              The Tu Progreso Hoy course is designed for people in Argentina seeking clarity amid volatility. Plataforma educativa con datos esenciales, sin asesoría financiera directa.
            </p>
            <div className="timeline">
              <div className="timeline-item">
                <h4>Módulo 1 · Inflation Signals</h4>
                <p>
                  Understand CPI methodologies, base effects, and basket adjustments. Practice building personal inflation trackers.
                </p>
              </div>
              <div className="timeline-item">
                <h4>Módulo 2 · Income & Expenditure Alignment</h4>
                <p>
                  Align salaries, fees, and savings plans with accurate projections. Analyse household budgets using AR data.
                </p>
              </div>
              <div className="timeline-item">
                <h4>Módulo 3 · FX & Liquidity Context</h4>
                <p>
                  Compare official, MEP, and blue rates. Learn techniques to stress-test strategies when exchange gaps widen.
                </p>
              </div>
              <div className="timeline-item">
                <h4>Módulo 4 · Scenario Planning</h4>
                <p>
                  Build short and medium-term roadmaps with data-driven checkpoints and responsible decision milestones.
                </p>
              </div>
            </div>
            <div style={{ marginTop: "24px" }}>
              <a href="#trial-form" className="cta-button">
                {language === "en" ? "Reserve your free trial lesson" : "Reserva tu clase gratuita"}
              </a>
            </div>
          </div>
          <div className="card">
            <h3 style={{ fontFamily: "var(--font-heading)" }}>What you will gain</h3>
            <ul style={{ paddingLeft: "18px" }}>
              <li>Weekly dashboards with INDEC CPI breakdowns and provincial comparisons.</li>
              <li>Contextual explainers on fiscal policy, wage agreements, and FX regimes.</li>
              <li>Guided exercises with templates to translate data into actionable decisions.</li>
              <li>Community access for bilingual Q&A and peer feedback.</li>
            </ul>
            <p className="small-print">
              Conocimiento financiero impulsado por tendencias. Decisions remain yours; we provide the context.
            </p>
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container">
          <h2>{t.testimonialsTitle}</h2>
          <div className="grid-3">
            <div className="card testimonial">
              <p>
                “Tu Progreso Hoy gave me a structure to analyse inflation without panic. The exercises helped me reframe my monthly budget.”
              </p>
              <span className="tag">Mariana · Buenos Aires</span>
            </div>
            <div className="card testimonial">
              <p>
                “The bilingual resources let my team align on the same numbers. Información confiable que respalda elecciones responsables sobre tu dinero.”
              </p>
              <span className="tag">Diego · Córdoba</span>
            </div>
            <div className="card testimonial">
              <p>
                “Having CPI, FX, and wage agreements in one place saves time. The transparency keeps us grounded in facts.”
              </p>
              <span className="tag">Lucía · Mendoza</span>
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-light">
        <div className="container grid-2" style={{ alignItems: "start" }}>
          <HomeTrialForm />
          <div className="card">
            <h3 style={{ fontFamily: "var(--font-heading)" }}>Why double opt-in?</h3>
            <p>
              Double opt-in protects your inbox and ensures you genuinely want our materials. After submitting, you will receive an email asking you to confirm your interest.
            </p>
            <p>
              Once confirmed, the free lesson link and supporting dataset will be delivered within minutes. Pasos acertados hoy, mejor futuro mañana.
            </p>
            <blockquote>
              Decisiones responsables, objetivos nítidos.
            </blockquote>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;
```