```javascript
import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const resources = [
  {
    titleEn: "Argentina CPI glossary",
    titleEs: "Glosario del IPC argentino",
    summaryEn: "Clarifies key CPI terms, index structures, and methodological notes from INDEC releases.",
    summaryEs: "Aclara términos claves del IPC, estructuras de índices y notas metodológicas de los informes del INDEC.",
    language: "Bilingual",
    link: "#"
  },
  {
    titleEn: "FX regime explainer",
    titleEs: "Explicador de regímenes cambiarios",
    summaryEn: "Compares official, MEP, and cash with settlement rates with historical spreads.",
    summaryEs: "Compara tipo oficial, MEP y contado con liquidación con diferenciales históricos.",
    language: "EN / ES",
    link: "#"
  },
  {
    titleEn: "Household budgeting template",
    titleEs: "Plantilla presupuestaria para hogares",
    summaryEn: "Interactive sheet to align income, inflation updates, and short-term priorities.",
    summaryEs: "Hoja interactiva para alinear ingresos, actualización inflacionaria y prioridades de corto plazo.",
    language: "Bilingual",
    link: "#"
  }
];

const ResourcesPage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Resources", "Recursos");

  return (
    <>
      <SEO
        title="Resources Library | Tu Progreso Hoy"
        description="Download bilingual articles, glossaries, and templates focused on Argentina's economic context."
        path="/resources"
      />
      <section className="section bg-white">
        <div className="container">
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>
            {t.resourcesTitle}
          </h1>
          <p>
            Our resources blend English explanations with Spanish examples to ensure clarity. Información confiable que respalda elecciones responsables sobre tu dinero.
          </p>

          <div className="resources-list">
            {resources.map((item) => (
              <article key={item.titleEn} className="resources-item">
                <h3>
                  {language === "en" ? item.titleEn : item.titleEs}
                </h3>
                <p>{language === "en" ? item.summaryEn : item.summaryEs}</p>
                <div className="resources-meta">
                  <span className="badge-secondary">{item.language}</span>
                  <span>{language === "en" ? "Updated quarterly" : "Actualizado trimestralmente"}</span>
                </div>
                <a href={item.link} className="cta-button" style={{ width: "fit-content", padding: "10px 18px" }}>
                  {language === "en" ? "Preview resource" : "Ver recurso"}
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default ResourcesPage;
```