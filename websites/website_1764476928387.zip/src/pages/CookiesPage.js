```javascript
import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const CookiesPage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Cookies", "Cookies");

  return (
    <>
      <SEO
        title="Cookies Policy | Tu Progreso Hoy"
        description="Learn about Tu Progreso Hoy cookie practices and how to manage your preferences."
        path="/cookies"
      />
      <section className="section bg-white">
        <div className="container">
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>{t.cookiesTitle}</h1>
          <p>
            {language === "en"
              ? "Tu Progreso Hoy uses essential cookies for site functionality and optional analytical cookies to improve our educational content."
              : "Tu Progreso Hoy utiliza cookies esenciales para el funcionamiento del sitio y cookies analíticas opcionales para mejorar nuestros contenidos."}
          </p>
          <h2>{language === "en" ? "Categories" : "Categorías"}</h2>
          <ul style={{ paddingLeft: "20px" }}>
            <li>
              <strong>{language === "en" ? "Essential" : "Esenciales"}:</strong>{" "}
              {language === "en"
                ? "Required for authentication and language settings."
                : "Necesarias para autenticación y configuración de idioma."}
            </li>
            <li>
              <strong>{language === "en" ? "Analytical (opt-in)" : "Analíticas (con consentimiento)"}:</strong>{" "}
              {language === "en"
                ? "Help us measure engagement with dashboards and learning materials."
                : "Nos ayudan a medir el uso de paneles y materiales educativos."}
            </li>
          </ul>
          <h2>{language === "en" ? "Managing preferences" : "Gestión de preferencias"}</h2>
          <p>
            {language === "en"
              ? "Use the cookie banner to provide or withdraw consent. You can also clear stored cookies via your browser."
              : "Utiliza el banner de cookies para otorgar o retirar tu consentimiento. También podés eliminar las cookies desde tu navegador."}
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiesPage;
```