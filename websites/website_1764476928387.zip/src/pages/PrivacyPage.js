```javascript
import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const PrivacyPage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Privacy", "Privacidad");

  return (
    <>
      <SEO
        title="Privacy Policy | Tu Progreso Hoy"
        description="Understand how Tu Progreso Hoy handles your personal data with transparency and compliance."
        path="/privacy"
      />
      <section className="section bg-white">
        <div className="container">
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>{t.privacyTitle}</h1>
          <p>
            Tu Progreso Hoy processes personal data in accordance with Argentine Law 25.326 and GDPR principles for EU-based users. Мы не предоставляем финансовые услуги.
          </p>
          <h2>{language === "en" ? "Information collected" : "Información recolectada"}</h2>
          <ul style={{ paddingLeft: "20px" }}>
            <li>{language === "en" ? "Contact details provided via forms." : "Datos de contacto provistos mediante formularios."}</li>
            <li>{language === "en" ? "Usage patterns from analytical cookies (opt-in)." : "Patrones de uso a través de cookies analíticas (con consentimiento)."}</li>
            <li>{language === "en" ? "Course participation metrics to improve learning." : "Métricas de participación para mejorar el aprendizaje."}</li>
          </ul>
          <h2>{language === "en" ? "Data usage" : "Uso de datos"}</h2>
          <p>
            {language === "en"
              ? "We use your information to deliver educational materials, manage your learning journey, and comply with legal obligations."
              : "Utilizamos tu información para entregar materiales educativos, gestionar tu recorrido de aprendizaje y cumplir obligaciones legales."}
          </p>
          <h2>{language === "en" ? "Your rights" : "Tus derechos"}</h2>
          <p>
            {language === "en"
              ? "You may request access, rectification, or deletion by emailing hola@tuprogresohoy.com."
              : "Podés solicitar acceso, rectificación o eliminación enviando un correo a hola@tuprogresohoy.com."}
          </p>
        </div>
      </section>
    </>
  );
};

export default PrivacyPage;
```