```javascript
import React, { useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const ContactPage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Contact", "Contacto");

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
    consent: false
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <>
      <SEO
        title="Contact Tu Progreso Hoy"
        description="Contact the Tu Progreso Hoy team in Buenos Aires. Educational platform with transparent data insights."
        path="/contact"
      />
      <section className="section bg-white">
        <div className="container">
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>
            {t.contactTitle}
          </h1>
          <div className="grid-2" style={{ alignItems: "start" }}>
            <div className="contact-card">
              <h3 style={{ marginTop: 0 }}>{language === "en" ? "Reach out" : "Contactanos"}</h3>
              <p>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</p>
              <p>
                <a href="tel:+541155551234">+54 11 5555-1234</a>
              </p>
              <p>
                <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
              </p>
              <p className="small-print">
                Мы не предоставляем финансовые услуги. This channel is for educational support only.
              </p>
              <form onSubmit={handleSubmit} noValidate>
                <div>
                  <label htmlFor="contact-name">{t.name}</label>
                  <input
                    id="contact-name"
                    value={formData.name}
                    onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="contact-email">{t.email}</label>
                  <input
                    id="contact-email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="contact-message">{t.message}</label>
                  <textarea
                    id="contact-message"
                    rows="4"
                    value={formData.message}
                    onChange={(e) => setFormData((prev) => ({ ...prev, message: e.target.value }))}
                  />
                </div>
                <div className="checkbox">
                  <input
                    id="contact-consent"
                    type="checkbox"
                    checked={formData.consent}
                    onChange={(e) => setFormData((prev) => ({ ...prev, consent: e.target.checked }))}
                    required
                  />
                  <label htmlFor="contact-consent">{t.confirmOptIn}</label>
                </div>
                <button type="submit" className="cta-button">
                  {t.submit}
                </button>
                <p className="small-print">
                  {language === "en"
                    ? "We will send a confirmation email to complete the double opt-in process."
                    : "Enviaremos un correo de confirmación para completar el doble opt-in."}
                </p>
                {submitted && <div className="alert">{t.contactSuccess}</div>}
              </form>
            </div>
            <div className="map-wrapper" role="region" aria-label="Map of Tu Progreso Hoy location">
              <iframe
                title="Tu Progreso Hoy location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.894227445828!2d-58.38155942425989!3d-34.60368435746043!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95a3352eed9f161b%3A0xc1aed1fdfd5f3c61!2sAv.%209%20de%20Julio%201000%2C%20C1043%20CABA%2C%20Argentina!5e0!3m2!1sen!2sar!4v1700000000000!5m2!1sen!2sar"
                width="100%"
                height="480"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;
```