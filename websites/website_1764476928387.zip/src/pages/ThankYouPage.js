```javascript
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const ThankYouPage = () => {
  const { t } = useLanguage();
  const location = useLocation();
  usePageTitle("Thank You", "Gracias");
  const email = location?.state?.email;

  return (
    <>
      <SEO
        title="Thank You | Tu Progreso Hoy"
        description="Thank you for subscribing to Tu Progreso Hoy. Please confirm via the double opt-in email."
        path="/thank-you"
      />
      <section className="section bg-light">
        <div className="container card" style={{ marginTop: "40px" }}>
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>{t.thankYouTitle}</h1>
          <p>{t.thankYouBody}</p>
          {email && (
            <p className="small-print">
              {email}
            </p>
          )}
          <p>
            Мы не предоставляем финансовые услуги. Our educational team is available to support you with the onboarding steps.
          </p>
          <Link to="/" className="cta-button" style={{ width: "fit-content", marginTop: "24px" }}>
            {t.backHome}
          </Link>
        </div>
      </section>
    </>
  );
};

export default ThankYouPage;
```