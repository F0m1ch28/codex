```javascript
import React from "react";
import SEO from "../components/SEO";

const RobotsPage = () => {
  const text = `User-agent: *
Allow: /
Sitemap: https://www.tuprogresohoy.com/sitemap.xml`;

  return (
    <>
      <SEO
        title="Robots.txt | Tu Progreso Hoy"
        description="Robots directives for Tu Progreso Hoy."
        path="/robots.txt"
      />
      <section className="section bg-white">
        <div className="container">
          <pre className="plain-text" aria-label="robots.txt">
            {text}
          </pre>
        </div>
      </section>
    </>
  );
};

export default RobotsPage;
```