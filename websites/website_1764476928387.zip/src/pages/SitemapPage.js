```javascript
import React from "react";
import SEO from "../components/SEO";

const SitemapPage = () => {
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://www.tuprogresohoy.com/</loc><priority>1.0</priority><changefreq>weekly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/inflation</loc><priority>0.8</priority><changefreq>weekly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/course</loc><priority>0.8</priority><changefreq>monthly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/resources</loc><priority>0.7</priority><changefreq>weekly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/contact</loc><priority>0.6</priority><changefreq>monthly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/thank-you</loc><priority>0.5</priority><changefreq>monthly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/privacy</loc><priority>0.3</priority><changefreq>yearly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/cookies</loc><priority>0.3</priority><changefreq>yearly</changefreq></url>
  <url><loc>https://www.tuprogresohoy.com/terms</loc><priority>0.3</priority><changefreq>yearly</changefreq></url>
</urlset>`;

  return (
    <>
      <SEO
        title="Sitemap | Tu Progreso Hoy"
        description="XML sitemap for Tu Progreso Hoy."
        path="/sitemap.xml"
      />
      <section className="section bg-white">
        <div className="container">
          <pre className="plain-text" aria-label="XML sitemap">
            {xml}
          </pre>
        </div>
      </section>
    </>
  );
};

export default SitemapPage;
```