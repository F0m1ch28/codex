```javascript
import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const modules = [
  {
    title: "Module 1 · Understanding CPI",
    description:
      "Dissect CPI weights, measure base effects, and evaluate provincial divergences. Includes guided spreadsheets and interactive dashboards."
  },
  {
    title: "Module 2 · Budget alignment",
    description:
      "Build resilient spending plans linked to salary adjustments, inflation-linked contracts, and household essentials."
  },
  {
    title: "Module 3 · FX ecosystem",
    description:
      "Analyse official, MEP, blue-chip swap, and blue rates with liquidity notes. Translate spreads into practical planning."
  },
  {
    title: "Module 4 · Future pacing",
    description:
      "Craft scenarios with decision checkpoints, resilience metrics, and habit-building exercises to respond to volatility responsibly."
  }
];

const targetAudience = [
  "Households recalibrating monthly budgets.",
  "SMB owners who need bilingual financial dashboards.",
  "Professionals planning medium-term financial goals in pesos and dollars.",
  "Students and educators seeking data-backed case studies."
];

const CoursePage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Course", "Curso");

  return (
    <>
      <SEO
        title="Course Syllabus | Tu Progreso Hoy"
        description="Explore the Tu Progreso Hoy bilingual syllabus. De la información al aprendizaje: fortalece tu criterio financiero paso a paso."
        path="/course"
      />
      <section className="section bg-white">
        <div className="container">
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>
            {t.coursePageTitle}
          </h1>
          <p>
            {language === "en"
              ? "The Tu Progreso Hoy course blends structured lessons with real-time datasets to strengthen financial interpretation."
              : "El curso de Tu Progreso Hoy combina lecciones estructuradas y datasets en tiempo real para fortalecer la interpretación financiera."}{" "}
            De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
          </p>
          <div className="grid-2" style={{ marginTop: "32px" }}>
            {modules.map((module) => (
              <div key={module.title} className="card">
                <h3 style={{ marginTop: 0 }}>{module.title}</h3>
                <p>{module.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-light" id="audience">
        <div className="container grid-2" style={{ alignItems: "start" }}>
          <div>
            <h2>{language === "en" ? "Who benefits?" : "¿A quién beneficia?"}</h2>
            <ul style={{ paddingLeft: "20px" }}>
              {targetAudience.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <p>
              Each module includes bilingual glossaries, case studies, and formative assessments to ensure knowledge retention without promising results.
            </p>
          </div>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>{language === "en" ? "Course format" : "Formato del curso"}</h3>
            <ul style={{ paddingLeft: "20px" }}>
              <li>{language === "en" ? "Weekly live sessions (recorded) and asynchronous exercises." : "Sesiones semanales en vivo (grabadas) y ejercicios asincrónicos."}</li>
              <li>{language === "en" ? "Bilingual resources delivered in English and Spanish." : "Recursos bilingües en inglés y español."}</li>
              <li>{language === "en" ? "Peer discussion forum moderated by facilitators." : "Foro de discusión moderado por facilitadores."}</li>
              <li>{language === "en" ? "Access to inflation dashboards and FX notebooks." : "Acceso a paneles de inflación y cuadernos cambiarios."}</li>
            </ul>
            <a href="#trial-form" className="cta-button">
              {language === "en" ? "Anchor to free trial form" : "Ir al formulario de prueba gratuita"}
            </a>
            <p className="small-print">
              Мы не предоставляем финансовые услуги. This is an educational program grounded in data.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default CoursePage;
```