```javascript
import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const TermsPage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Terms", "Términos");

  return (
    <>
      <SEO
        title="Terms of Use | Tu Progreso Hoy"
        description="Understand the terms governing your use of Tu Progreso Hoy's educational platform."
        path="/terms"
      />
      <section className="section bg-white">
        <div className="container">
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>{t.termsTitle}</h1>
          <p>
            {language === "en"
              ? "By using Tu Progreso Hoy you agree to these terms. The platform provides educational content and does not constitute financial advice."
              : "Al utilizar Tu Progreso Hoy aceptás estos términos. La plataforma brinda contenido educativo y no constituye asesoramiento financiero."}
          </p>
          <h2>{language === "en" ? "Use of content" : "Uso del contenido"}</h2>
          <p>
            {language === "en"
              ? "Materials are for personal or organisational learning. Redistribution requires written permission."
              : "Los materiales son para aprendizaje personal u organizacional. La redistribución requiere autorización por escrito."}
          </p>
          <h2>{language === "en" ? "User responsibilities" : "Responsabilidades del usuario"}</h2>
          <p>
            {language === "en"
              ? "You remain responsible for decisions based on the content. We encourage independent verification."
              : "Las decisiones basadas en el contenido son responsabilidad del usuario. Recomendamos la verificación independiente."}
          </p>
          <h2>{language === "en" ? "Limitation of liability" : "Limitación de responsabilidad"}</h2>
          <p>
            {language === "en"
              ? "Tu Progreso Hoy is not liable for financial outcomes derived from the use of the platform."
              : "Tu Progreso Hoy no se hace responsable de resultados financieros derivados del uso de la plataforma."}
          </p>
        </div>
      </section>
    </>
  );
};

export default TermsPage;
```