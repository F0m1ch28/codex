```javascript
import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { usePageTitle } from "../hooks/usePageTitle";
import SEO from "../components/SEO";

const InflationPage = () => {
  const { t, language } = useLanguage();
  usePageTitle("Inflation Insights", "Inflación");

  const methodology = [
    {
      title: language === "en" ? "Data ingestion" : "Ingesta de datos",
      detail:
        language === "en"
          ? "Daily extraction from INDEC CPI microdata, supplemented with provincial and private sector indices for cross-validation."
          : "Extracción diaria de microdatos del IPC del INDEC, con índices provinciales y privados para la validación cruzada."
    },
    {
      title: language === "en" ? "Basket adjustments" : "Ajustes de canasta",
      detail:
        language === "en"
          ? "We document changes in the CPI basket composition and price weighting adjustments to understand volatility."
          : "Documentamos cambios en la composición de la canasta del IPC y ponderaciones para comprender la volatilidad."
    },
    {
      title: language === "en" ? "Scenario modelling" : "Modelado de escenarios",
      detail:
        language === "en"
          ? "Simulations include exchange rate bands, energy subsidies, and wage negotiations to stress-test budgets."
          : "Las simulaciones incluyen bandas cambiarias, subsidios energéticos y paritarias para testear los presupuestos."
    }
  ];

  const cpiData = [
    { month: "Jan 2024", inflation: 20.6, fx: 840 },
    { month: "Feb 2024", inflation: 13.2, fx: 860 },
    { month: "Mar 2024", inflation: 11.5, fx: 870 },
    { month: "Apr 2024", inflation: 8.8, fx: 890 },
    { month: "May 2024", inflation: 7.7, fx: 910 }
  ];

  return (
    <>
      <SEO
        title="Inflation Methodology | Tu Progreso Hoy"
        description="Detailed inflation methodology for Argentina, connecting CPI, FX and household context. Datos verificados para planificar tu presupuesto."
        path="/inflation"
      />
      <section className="section bg-white">
        <div className="container">
          <h1 style={{ fontFamily: "var(--font-heading)", color: "var(--color-navy)" }}>
            {t.inflationTitle}
          </h1>
          <p>
            We align inflation narratives with verifiable metrics to empower Argentines to interpret official releases alongside on-the-ground reality.
            Conocimiento financiero impulsado por tendencias.
          </p>
          <div className="grid-3" style={{ marginTop: "32px" }}>
            {methodology.map((item) => (
              <div key={item.title} className="card">
                <h3 style={{ marginTop: 0 }}>{item.title}</h3>
                <p>{item.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-light">
        <div className="container">
          <h2>Monthly CPI & FX context</h2>
          <div style={{ overflowX: "auto", marginBottom: "24px" }}>
            <table className="context-table">
              <thead>
                <tr>
                  <th>{language === "en" ? "Month" : "Mes"}</th>
                  <th>{language === "en" ? "CPI month-on-month %" : "% IPC mensual"}</th>
                  <th>{language === "en" ? "Official FX ARS/USD" : "Tipo de cambio oficial"}</th>
                </tr>
              </thead>
              <tbody>
                {cpiData.map((row) => (
                  <tr key={row.month}>
                    <td>{row.month}</td>
                    <td>{row.inflation}%</td>
                    <td>{row.fx}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="small-print">
            Datos verificados para planificar tu presupuesto. We track revisions and publish context notes each time the methodology changes.
          </p>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container">
          <h2>{t.faqTitle}</h2>
          <div className="details-group">
            <details>
              <summary>{language === "en" ? "How often is the dashboard updated?" : "¿Con qué frecuencia se actualiza el panel?"}</summary>
              <p>
                {language === "en"
                  ? "We update daily for FX movements and weekly for CPI, wage agreements, and tariff announcements."
                  : "Actualizamos a diario para los movimientos cambiarios y semanalmente para IPC, paritarias y anuncios tarifarios."}
              </p>
            </details>
            <details>
              <summary>{language === "en" ? "What sources are used?" : "¿Qué fuentes se utilizan?"}</summary>
              <p>
                INDEC, Banco Central de la República Argentina, Ministerio de Economía, consultoras privadas y datasets aportados por usuarios corporativos.
              </p>
            </details>
            <details>
              <summary>{language === "en" ? "Do you issue recommendations?" : "¿Dan recomendaciones?"}</summary>
              <p>
                We do not. Мы не предоставляем финансовые услуги. Our role is to guide you through data interpretation so you can make decisions responsibly.
              </p>
            </details>
            <details>
              <summary>{language === "en" ? "How is accuracy enforced?" : "¿Cómo aseguran la precisión?"}</summary>
              <p>
                Cross-validation scripts detect anomalies. Any divergences trigger manual review and notes in the platform.
              </p>
            </details>
          </div>
        </div>
      </section>
    </>
  );
};

export default InflationPage;
```