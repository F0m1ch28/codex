```javascript
import React from "react";
import { Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import DisclaimerModal from "./components/DisclaimerModal";
import ScrollToTop from "./components/ScrollToTop";

import HomePage from "./pages/HomePage";
import InflationPage from "./pages/InflationPage";
import CoursePage from "./pages/CoursePage";
import ResourcesPage from "./pages/ResourcesPage";
import ContactPage from "./pages/ContactPage";
import ThankYouPage from "./pages/ThankYouPage";
import PrivacyPage from "./pages/PrivacyPage";
import CookiesPage from "./pages/CookiesPage";
import TermsPage from "./pages/TermsPage";
import SitemapPage from "./pages/SitemapPage";
import RobotsPage from "./pages/RobotsPage";

function App() {
  return (
    <>
      <Header />
      <ScrollToTop />
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/inflation" element={<InflationPage />} />
          <Route path="/course" element={<CoursePage />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/thank-you" element={<ThankYouPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/cookies" element={<CookiesPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/sitemap.xml" element={<SitemapPage />} />
          <Route path="/robots.txt" element={<RobotsPage />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <DisclaimerModal />
    </>
  );
}

export default App;
```