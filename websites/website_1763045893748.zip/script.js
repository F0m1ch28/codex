document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const toTopBtn = document.getElementById('toTop');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAcceptBtn = document.getElementById('cookie-accept');
    const contactForm = document.getElementById('contact-form');
    const feedbackField = document.getElementById('contact-feedback');
    const yearField = document.getElementById('year');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isOpen = navMenu.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', isOpen.toString());
        });
    }

    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu && navMenu.classList.contains('open')) {
                navMenu.classList.remove('open');
                navToggle?.setAttribute('aria-expanded', 'false');
            }
        });
    });

    const scrollLinks = document.querySelectorAll('a[data-scroll="true"]');
    scrollLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (!href || !href.includes('#')) return;

        link.addEventListener('click', event => {
            const [pathPart, hash] = href.split('#');
            if (!hash) return;

            const currentPath = window.location.pathname.split('/').pop() || 'index.html';
            const normalizedPath = pathPart && pathPart.length > 0 ? pathPart : currentPath;

            if (normalizedPath === currentPath) {
                event.preventDefault();
                const target = document.getElementById(hash);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                    history.replaceState(null, '', `#${hash}`);
                }
            } else {
                window.scrollTo({ top: 0, behavior: 'auto' });
            }
        });
    });

    if (toTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                toTopBtn.classList.add('visible');
            } else {
                toTopBtn.classList.remove('visible');
            }
        });

        toTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookieStorageKey = 'mevaltoCookiesAccepted';
    if (cookieBanner) {
        if (localStorage.getItem(cookieStorageKey) === 'true') {
            cookieBanner.classList.add('hidden');
        } else {
            cookieBanner.classList.add('show');
        }

        cookieAcceptBtn?.addEventListener('click', () => {
            localStorage.setItem(cookieStorageKey, 'true');
            cookieBanner.classList.remove('show');
            cookieBanner.classList.add('hidden');
        });
    }

    if (contactForm && feedbackField) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name') || 'Danke';

            feedbackField.textContent = `${name}, vielen Dank für deine Nachricht! Wir melden uns, sobald wir deine Impulse gelesen haben.`;
            contactForm.reset();
        });
    }

    if (yearField) {
        yearField.textContent = new Date().getFullYear();
    }
});