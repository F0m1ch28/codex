import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import Layout from "./components/Layout.jsx";
import Home from "./pages/Home.jsx";
import Services from "./pages/Services.jsx";
import About from "./pages/About.jsx";
import Contacts from "./pages/Contacts.jsx";
import FAQ from "./pages/FAQ.jsx";
import Terms from "./pages/Terms.jsx";
import Privacy from "./pages/Privacy.jsx";
import ScrollToTop from "./components/ScrollToTop.jsx";

export default function App() {
  const location = useLocation();

  return (
    <>
      <ScrollToTop />
      <Layout>
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<Home />} />
            <Route path="/uslugi" element={<Services />} />
            <Route path="/o-nas" element={<About />} />
            <Route path="/kontakty" element={<Contacts />} />
            <Route path="/faq" element={<FAQ />} />
            <Route path="/usloviya" element={<Terms />} />
            <Route path="/politika-konfidencialnosti" element={<Privacy />} />
          </Routes>
        </AnimatePresence>
      </Layout>
    </>
  );
}