import { useEffect, useState } from "react";

export default function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const saved = localStorage.getItem("fortisguard-cookie-consent");
    if (!saved) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleChoice = (value) => {
    localStorage.setItem("fortisguard-cookie-consent", value);
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-banner__content">
        <h4>Мы используем cookies</h4>
        <p>
          FortisGuard применяет cookies для оптимизации работы сайта, персонализации
          сервисов и аналитики. Вы можете принять или отклонить использование
          необязательных cookies.
        </p>
        <div className="cookie-banner__actions">
          <button
            type="button"
            className="btn btn--primary"
            onClick={() => handleChoice("accepted")}
          >
            Принять
          </button>
          <button
            type="button"
            className="btn btn--ghost"
            onClick={() => handleChoice("declined")}
          >
            Отклонить
          </button>
        </div>
      </div>
    </div>
  );
}