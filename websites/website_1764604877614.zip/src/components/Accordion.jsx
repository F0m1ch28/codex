import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Accordion({ items }) {
  const [active, setActive] = useState(null);

  const handleToggle = (index) => {
    setActive((prev) => (prev === index ? null : index));
  };

  return (
    <div className="accordion">
      {items.map((item, index) => {
        const isOpen = active === index;
        return (
          <div className={`accordion__item ${isOpen ? "is-open" : ""}`} key={item.question}>
            <button
              type="button"
              className="accordion__trigger"
              onClick={() => handleToggle(index)}
              aria-expanded={isOpen}
            >
              <span>{item.question}</span>
              <span className="accordion__icon">{isOpen ? "−" : "+"}</span>
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  className="accordion__panel"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <p>{item.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}