import { NavLink } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <div className="footer__brand-name">FortisGuard</div>
          <p className="footer__brand-tagline">
            Комплексные решения по безопасности, соответствующие международным
            стандартам и ожиданиям премиальных клиентов.
          </p>
        </div>
        <div className="footer__column">
          <h4>Навигация</h4>
          <NavLink to="/">Главная</NavLink>
          <NavLink to="/uslugi">Услуги</NavLink>
          <NavLink to="/o-nas">О компании</NavLink>
          <NavLink to="/kontakty">Контакты</NavLink>
          <NavLink to="/faq">FAQ</NavLink>
        </div>
        <div className="footer__column">
          <h4>Правовая информация</h4>
          <NavLink to="/usloviya">Условия обслуживания</NavLink>
          <NavLink to="/politika-konfidencialnosti">
            Политика конфиденциальности
          </NavLink>
        </div>
        <div className="footer__column">
          <h4>Контакты</h4>
          <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          <a href="mailto:info@fortisguard.ru">info@fortisguard.ru</a>
          <p>Москва, Пресненская набережная, 12</p>
        </div>
      </div>
      <div className="footer__bottom">
        <span>© {new Date().getFullYear()} FortisGuard. Все права защищены.</span>
      </div>
    </footer>
  );
}