import { useState } from "react";
import { motion } from "framer-motion";

export default function ContactForm({ variant = "dark" }) {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <motion.form
      className={`contact-form contact-form--${variant}`}
      onSubmit={handleSubmit}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 0.5 }}
      aria-live="polite"
      noValidate
    >
      <div className="contact-form__row">
        <label>
          Имя
          <input type="text" name="name" placeholder="Иван Иванов" required />
        </label>
        <label>
          Телефон
          <input type="tel" name="phone" placeholder="+7 (___) ___-__-__" required />
        </label>
      </div>
      <label>
        Email
        <input type="email" name="email" placeholder="example@fortisguard.ru" required />
      </label>
      <label>
        Запрос
        <textarea name="message" rows="4" placeholder="Опишите ваши задачи по безопасности" required />
      </label>
      <button type="submit" className="btn btn--primary btn--wide">
        Отправить запрос
      </button>
      {isSubmitted && (
        <p className="contact-form__success">
          Благодарим за обращение! Наш эксперт свяжется с вами в течение 15 минут.
        </p>
      )}
      <p className="contact-form__privacy">
        Отправляя форму, вы соглашаетесь с{" "}
        <a href="/politika-konfidencialnosti">Политикой конфиденциальности</a>.
      </p>
    </motion.form>
  );
}