import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useTheme } from "../context/ThemeContext.jsx";

const navItems = [
  { path: "/", label: "Главная" },
  { path: "/uslugi", label: "Услуги" },
  { path: "/o-nas", label: "О нас" },
  { path: "/kontakty", label: "Контакты" },
  { path: "/faq", label: "FAQ" }
];

export default function Header() {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const handleToggle = () => setIsMobileOpen((prev) => !prev);

  return (
    <header className="header">
      <div className="container header__inner">
        <div className="header__logo">
          <span className="header__logo-mark">FortisGuard</span>
          <span className="header__logo-caption">Премиальная безопасность</span>
        </div>
        <nav className={`header__nav ${isMobileOpen ? "is-open" : ""}`}>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                isActive ? "nav-link is-active" : "nav-link"
              }
              onClick={() => setIsMobileOpen(false)}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="header__actions">
          <button
            type="button"
            className="theme-toggle"
            onClick={toggleTheme}
            aria-label="Переключение темы"
          >
            {theme === "dark" ? "🌙" : "☀️"}
          </button>
          <a className="header__cta" href="tel:+74951234567">
            +7 (495) 123-45-67
          </a>
          <button
            type="button"
            className={`burger ${isMobileOpen ? "is-active" : ""}`}
            onClick={handleToggle}
            aria-expanded={isMobileOpen}
            aria-label="Меню"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
}