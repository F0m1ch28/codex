import Header from "./Header.jsx";
import Footer from "./Footer.jsx";
import CookieBanner from "./CookieBanner.jsx";

export default function Layout({ children }) {
  return (
    <div className="app-shell">
      <Header />
      <main className="page-content">{children}</main>
      <Footer />
      <CookieBanner />
    </div>
  );
}