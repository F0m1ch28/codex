import { motion } from "framer-motion";
import SectionTitle from "../components/SectionTitle.jsx";

const timeline = [
  {
    year: "2006",
    title: "Основание FortisGuard",
    text: "Команда из офицеров спецслужб и экспертов по корпоративной безопасности запустила агентство с миссией защищать стратегические активы бизнеса."
  },
  {
    year: "2012",
    title: "Международная экспансия",
    text: "Открытие подразделений в Санкт-Петербурге и Владивостоке, сопровождение проектов в Европе и Юго-Восточной Азии."
  },
  {
    year: "2017",
    title: "Цифровая трансформация",
    text: "Запуск собственного центра кибербезопасности, внедрение платформы FortisGuard Insight и ситуационных центров нового поколения."
  },
  {
    year: "2023",
    title: "Статус премиального провайдера",
    text: "Получение ISO 18788, включение в топ-5 охранных агентств по версии консорциума Security Excellence, расширение пула международных клиентов."
  }
];

export default function About() {
  return (
    <motion.div
      className="page page-about"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0.4 }}
      transition={{ duration: 0.6 }}
    >
      <section className="page-hero page-hero--with-image">
        <div className="container page-hero__grid">
          <div className="page-hero__content">
            <span className="page-hero__eyebrow">О компании</span>
            <h1>FortisGuard — архитекторы безопасности с человеческим лицом</h1>
            <p>
              Мы строим доверие на основе прозрачности, дисциплины и инноваций. FortisGuard
              внедряет лучшие мировые практики управления безопасностью, обеспечивая
              стратегическую стабильность бизнеса и спокойствие для клиентов.
            </p>
          </div>
          <div className="page-hero__image" aria-hidden="true" />
        </div>
      </section>

      <section className="container section-dense">
        <SectionTitle
          eyebrow="Наш подход"
          title="Стратегия FortisGuard основана на трех принципах"
        />
        <div className="approach-grid">
          <motion.div
            className="approach-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.5 }}
          >
            <h3>Предиктивная аналитика</h3>
            <p>
              Искусственный интеллект и OSINT-аналитика помогают прогнозировать угрозы,
              предлагать превентивные меры и создавать сценарные карты реагирования.
            </p>
          </motion.div>
          <motion.div
            className="approach-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h3>Синергия людей и технологий</h3>
            <p>
              Сотрудники FortisGuard проходят регулярные обучения, используют AR/VR-тренажеры
              и управляют цифровой инфраструктурой безопасности из единого центра.
            </p>
          </motion.div>
          <motion.div
            className="approach-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h3>Корпоративная этика</h3>
            <p>
              Прозрачность, охрана конфиденциальных данных и строгий комплаенс с требованиями
              российского и международного законодательства.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section-timeline">
        <div className="container">
          <SectionTitle
            eyebrow="Наша история"
            title="Делаем безопасность безупречной более 18 лет"
            align="center"
          />
          <div className="timeline">
            {timeline.map((item) => (
              <motion.div
                key={item.year}
                className="timeline__item"
                initial={{ opacity: 0, x: -40 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.4 }}
              >
                <span className="timeline__year">{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-values">
        <div className="container section-values__grid">
          <div>
            <SectionTitle
              eyebrow="Ценности"
              title="Этика, ответственность и непрерывное развитие"
              description="Мы придерживаемся строгих стандартов в работе с конфиденциальными данными, поддерживаем культуру командной ответственности и инвестируем в постоянное обучение сотрудников."
            />
          </div>
          <ul className="values-list">
            <li>
              <strong>Ответственность</strong>
              <p>Каждый сотрудник несет персональную ответственность за действия команды и клиента.</p>
            </li>
            <li>
              <strong>Доверие</strong>
              <p>Прозрачные отчеты, контроль доступов и независимый аудит качества услуг.</p>
            </li>
            <li>
              <strong>Инновации</strong>
              <p>Инвестиции в R&D, пилоты с нейросетями и беспилотными системами наблюдения.</p>
            </li>
          </ul>
        </div>
      </section>
    </motion.div>
  );
}