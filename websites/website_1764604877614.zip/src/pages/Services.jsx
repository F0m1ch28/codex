import { motion } from "framer-motion";
import SectionTitle from "../components/SectionTitle.jsx";

const services = [
  {
    title: "Охрана объектов и инфраструктуры",
    description:
      "Многоуровневая охрана офисных центров, логистических комплексов, промышленных объектов. Построение периметров, контроль доступа, реагирование групп быстрого реагирования.",
    details: [
      "Инженерно-техническая укрепленность и видеоналитика",
      "Постовые службы, мобильные патрули, кинологические группы",
      "Диспетчерские центры с резервированием каналов связи"
    ]
  },
  {
    title: "Персональная безопасность и сопровождение",
    description:
      "Защитные протоколы для первой лиц, семей и высокопоставленных гостей. Маршрутное планирование, обеспечение безопасности в путешествиях, бронированный транспорт.",
    details: [
      "Персональные телохранители, прошедшие подготовку в ГШ СЗР",
      "Управление мобильными кортежами и авиационная координация",
      "Ситуационный мониторинг и разведка угроз"
    ]
  },
  {
    title: "Кибербезопасность и защита данных",
    description:
      "Комплексная защита цифровых активов, мониторинг DarkNet, построение SOC и реагирование на инциденты. Конфиденциальность корпоративных и персональных данных клиентов.",
    details: [
      "Аудит информационной безопасности и penetration testing",
      "Внедрение SIEM, SOAR и DLP-систем",
      "Форензика и расследование инцидентов"
    ]
  },
  {
    title: "Стратегическое управление рисками",
    description:
      "OSINT-исследования, геополитический анализ, сопровождение M&A-сделок, due diligence партнёров. Управление операционной непрерывностью в условиях кризисов.",
    details: [
      "Матрицы угроз и сценарное моделирование кризисов",
      "Бизнес-симуляции и тренировки руководителей",
      "Разработка планов Business Continuity и Disaster Recovery"
    ]
  },
  {
    title: "Интегрированные системы безопасности",
    description:
      "Проектирование, внедрение и обслуживание интегрированных систем безопасности: видеонаблюдение, контроль доступа, пожарная безопасность, автоматизация ситуационных центров.",
    details: [
      "Проектирование с BIM-моделированием и цифровыми двойниками",
      "Интеграция ACS, CCTV, APS, AOP, BMS на единой платформе",
      "Постгарантийная поддержка 24/7/365"
    ]
  }
];

export default function Services() {
  return (
    <motion.div
      className="page page-services"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0.4 }}
      transition={{ duration: 0.6 }}
    >
      <section className="page-hero">
        <div className="container page-hero__content">
          <span className="page-hero__eyebrow">Премиальный сервис</span>
          <h1>Экосистема охранных услуг FortisGuard</h1>
          <p>
            Мы создаем комплексные архитектуры безопасности, объединяя физическую охрану,
            цифровые технологии и стратегическую аналитику. Каждый проект адаптирован
            под регуляторные требования и корпоративную культуру клиента.
          </p>
        </div>
      </section>

      <section className="container section-dense">
        <SectionTitle
          eyebrow="Матрица решений"
          title="Синергия технологий и человеческого фактора"
          description="Гибридная модель безопасности FortisGuard использует уникальные алгоритмы оценки рисков, цифровые двойники объектов и единую платформу управления событиями."
        />
        <div className="service-detailed">
          {services.map((service) => (
            <motion.article
              key={service.title}
              className="service-detailed__item"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5 }}
            >
              <div className="service-detailed__header">
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </div>
              <ul>
                {service.details.map((detail) => (
                  <li key={detail}>{detail}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section-highlight">
        <div className="container section-highlight__grid">
          <div>
            <SectionTitle
              eyebrow="Гарантия качества"
              title="Прозрачность, контроль и инновации в одном окне"
              description="FortisGuard управляет проектами через Command Center с биометрической аутентификацией, интеграцией с МВД и резервированными каналами связи. Отчётность доступна клиентам в режиме реального времени."
            />
          </div>
          <div className="highlight-box">
            <div>
              <strong>Dedicated Security Manager</strong>
              <p>Личный куратор безопасности, доступный 24/7, который координирует все службы.</p>
            </div>
            <div>
              <strong>FortisGuard Insight</strong>
              <p>Цифровая платформа с аналитикой KPI, отчетами SLA и интеграцией BI.</p>
            </div>
            <div>
              <strong>Zero Incident Protocol</strong>
              <p>Многоуровневая система контроля качества и обязательная сертификация сотрудников.</p>
            </div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}