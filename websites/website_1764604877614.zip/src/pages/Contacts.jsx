import { motion } from "framer-motion";
import ContactForm from "../components/ContactForm.jsx";

export default function Contacts() {
  return (
    <motion.div
      className="page page-contacts"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0.4 }}
      transition={{ duration: 0.6 }}
    >
      <section className="page-hero">
        <div className="container page-hero__content">
          <span className="page-hero__eyebrow">Контакты</span>
          <h1>Свяжитесь с FortisGuard</h1>
          <p>
            Наши аналитики доступны 24/7. Мы проведем экспресс-консультацию, назначим встречу
            и предложим индивидуальное решение. Для срочных вопросов звоните по телефону.
          </p>
        </div>
      </section>

      <section className="container section-contacts">
        <div className="contacts__info">
          <div className="contacts__card">
            <h3>Штаб-квартира</h3>
            <p>Москва, Пресненская набережная, 12, башня «Империя», 41 этаж</p>
          </div>
          <div className="contacts__card">
            <h3>Каналы связи</h3>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
            <a href="mailto:info@fortisguard.ru">info@fortisguard.ru</a>
            <p>Secure Line для клиентов: +7 (495) 555-11-00</p>
          </div>
          <div className="contacts__card">
            <h3>Часы работы</h3>
            <p>Командный центр: круглосуточно</p>
            <p>Офис: 09:00–20:00 (понедельник–суббота)</p>
          </div>
        </div>
        <ContactForm variant="dark" />
      </section>

      <section className="section-map">
        <div className="container">
          <iframe
            title="FortisGuard на карте"
            src="https://yandex.ru/map-widget/v1/?um=constructor%3A2fd51b9d852f67ff2238d33b4b20e0ede7e13b8f4e1b8c54d4c35b4c70538ca5&amp;source=constructor"
            allowFullScreen
            loading="lazy"
          />
        </div>
      </section>
    </motion.div>
  );
}