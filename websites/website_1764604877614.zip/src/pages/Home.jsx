import { motion } from "framer-motion";
import SectionTitle from "../components/SectionTitle.jsx";
import ContactForm from "../components/ContactForm.jsx";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <motion.div
      className="page page-home"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0.4 }}
      transition={{ duration: 0.6 }}
    >
      <section className="hero">
        <div className="container hero__grid">
          <motion.div
            className="hero__content"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="hero__eyebrow">Премиальная безопасность 24/7</span>
            <h1>FortisGuard — стратегический щит вашей компании и семьи</h1>
            <p>
              Мы объединяем передовые технологии, элитную охранную подготовку и
              комплексную аналитику рисков. FortisGuard — выбор лидеров бизнеса,
              резидентов премиум-класса и международных корпораций, которым
              требуется безупречная защита.
            </p>
            <div className="hero__actions">
              <Link to="/uslugi" className="btn btn--primary">
                Решения для бизнеса
              </Link>
              <a href="#contact" className="btn btn--ghost">
                Связаться с аналитиком
              </a>
            </div>
            <div className="hero__trust">
              <div>
                <span>18+</span>
                <p>лет защищаем инфраструктуру и людей</p>
              </div>
              <div>
                <span>0</span>
                <p>инцидентов по вине FortisGuard</p>
              </div>
              <div>
                <span>ISO</span>
                <p>Сертификаты 9001, 18788, 31000</p>
              </div>
            </div>
          </motion.div>
          <motion.div
            className="hero__visual"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.2 }}
          >
            <div className="hero__card">
              <span>Эксперт на объекте</span>
              <strong>Сопровождение VIP</strong>
              <p>Диспетчерский контроль, биометрия доступа, оперативное реагирование.</p>
            </div>
            <div className="hero__image" aria-hidden="true" />
          </motion.div>
        </div>
      </section>

      <section className="section-services">
        <div className="container">
          <SectionTitle
            eyebrow="Комплексные услуги"
            title="Особое внимание к деталям безопасности"
            description="FortisGuard проектирует индивидуальные протоколы защиты с учетом уникального профиля угроз для вашего бизнеса или персональной безопасности."
            align="center"
          />
          <div className="service-cards">
            <motion.article
              className="service-card"
              whileHover={{ y: -8 }}
              transition={{ duration: 0.3 }}
            >
              <div className="service-card__icon">🛡️</div>
              <h3>Охрана объектов класса А+</h3>
              <p>
                Премиальное физическое патрулирование, посты реагирования, контрольные
                центры и электронные системы безопасности по стандартам Grade 4.
              </p>
              <Link to="/uslugi" className="service-card__link">
                Подробнее
              </Link>
            </motion.article>
            <motion.article
              className="service-card"
              whileHover={{ y: -8 }}
              transition={{ duration: 0.3 }}
            >
              <div className="service-card__icon">🎯</div>
              <h3>Персональная защита и сопровождение</h3>
              <p>
                Персональные телохранители с международными сертификациями, бронированный
                транспорт, круглосуточный мониторинг маршрутов и ситуационное планирование.
              </p>
              <Link to="/uslugi" className="service-card__link">
                Подробнее
              </Link>
            </motion.article>
            <motion.article
              className="service-card"
              whileHover={{ y: -8 }}
              transition={{ duration: 0.3 }}
            >
              <div className="service-card__icon">🧠</div>
              <h3>Интеллектуальная аналитика угроз</h3>
              <p>
                Центр оценки рисков, OSINT-исследования, сценарное моделирование кризисов и
                создание планов непрерывности бизнеса для мультинациональных групп.
              </p>
              <Link to="/uslugi" className="service-card__link">
                Подробнее
              </Link>
            </motion.article>
          </div>
        </div>
      </section>

      <section className="section-advantages">
        <div className="container section-advantages__grid">
          <div className="advantages__summary">
            <SectionTitle
              eyebrow="Почему FortisGuard"
              title="От стратегической оценки до оперативного реагирования"
              description="Наша философия — предугадывать и предотвращать угрозы до того,
              как они возникнут. Мы управляем безопасностью по принципам военной дисциплины
              и корпоративной прозрачности."
            />
            <ul className="advantages__list">
              <li>
                <span>01</span>
                Инновационный командный центр: аналитика в реальном времени, интеграция CCTV,
                IoT и BI-платформ.
              </li>
              <li>
                <span>02</span>
                Персонал с опытом работы в спецслужбах и международных миссиях безопасности.
              </li>
              <li>
                <span>03</span>
                Стандарты безопасности ESG: конфиденциальность, репутационная защита,
                комплаенс.
              </li>
            </ul>
          </div>
          <div className="advantages__metrics">
            <div className="metric-card">
              <strong>900+</strong>
              <p>объектов под круглосуточным мониторингом FortisGuard</p>
            </div>
            <div className="metric-card">
              <strong>15 мин</strong>
              <p>среднее время прибытия мобильных групп реагирования в Москве</p>
            </div>
            <div className="metric-card">
              <strong>5 уровней</strong>
              <p>внутреннего контроля качества и регулярные стресс-тесты персонала</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section-team">
        <div className="container">
          <SectionTitle
            eyebrow="Команда"
            title="Элита профессионалов, объединенных миссией безопасности"
            description="Каждый руководитель подразделения FortisGuard имеет подтвержденный опыт реализации проектов высокой степени риска и профильные международные сертификации."
            align="center"
          />
          <div className="team-grid">
            <motion.div
              className="team-card"
              whileHover={{ translateY: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div
                className="team-card__photo"
                style={{
                  backgroundImage:
                    "url('https://images.pexels.com/photos/8386964/pexels-photo-8386964.jpeg?auto=compress&cs=tinysrgb&w=800')"
                }}
              />
              <h3>Сергей Волков</h3>
              <p>Генеральный директор, эксперт по корпоративной безопасности</p>
              <span>Ex-FSB | ASIS CPP | MBA</span>
            </motion.div>
            <motion.div
              className="team-card"
              whileHover={{ translateY: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div
                className="team-card__photo"
                style={{
                  backgroundImage:
                    "url('https://images.pexels.com/photos/8427418/pexels-photo-8427418.jpeg?auto=compress&cs=tinysrgb&w=800')"
                }}
              />
              <h3>Екатерина Миронова</h3>
              <p>Директор по аналитике и управлению рисками</p>
              <span>OSINT Analyst | CISSP | ISO 31000 Lead</span>
            </motion.div>
            <motion.div
              className="team-card"
              whileHover={{ translateY: -10 }}
              transition={{ duration: 0.3 }}
            >
              <div
                className="team-card__photo"
                style={{
                  backgroundImage:
                    "url('https://images.pexels.com/photos/7620201/pexels-photo-7620201.jpeg?auto=compress&cs=tinysrgb&w=800')"
                }}
              />
              <h3>Алексей Субботин</h3>
              <p>Руководитель оперативного реагирования</p>
              <span>SWAT | Тактическая медицина | IAHSS</span>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section-testimonials">
        <div className="container section-testimonials__grid">
          <SectionTitle
            eyebrow="Отзывы клиентов"
            title="Нам доверяют лидеры отраслей"
            description="FortisGuard сопровождает инвестиционные фонды, девелоперские компании, медицинские холдинги и представителей частных семейных офисов."
          />
          <div className="testimonials">
            <motion.blockquote
              className="testimonial-card"
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.25 }}
            >
              <p>
                «FortisGuard за три месяца провела тотальное обновление протоколов безопасности
                нашего холдинга. Благодаря их аналитике мы снизили операционные риски и
                ускорили процессы аккредитаций на международных площадках.»
              </p>
              <footer>
                <strong>Наталья Кашина</strong>
                <span>CEO, K-Group Investment</span>
              </footer>
            </motion.blockquote>
            <motion.blockquote
              className="testimonial-card"
              whileHover={{ scale: 1.01 }}
              transition={{ duration: 0.25 }}
            >
              <p>
                «Оперативные группы FortisGuard сопровождали нашу экспедицию на Дальний Восток.
                Команда обеспечила непрерывную безопасность, авиационное сопровождение и
                санитарно-медицинский контроль на высшем уровне.»
              </p>
              <footer>
                <strong>Илья Романов</strong>
                <span>Директор проектного офиса, GeoTech</span>
              </footer>
            </motion.blockquote>
          </div>
        </div>
      </section>

      <section className="section-cta" id="contact">
        <div className="container section-cta__grid">
          <div className="cta__content">
            <SectionTitle
              eyebrow="Круглосуточная поддержка"
              title="Запросите стратегическую сессию с аналитиком FortisGuard"
              description="Мы подготовим комплексный аудит безопасности, проведем анализ уязвимостей
              и разработаем дорожную карту повышения защиты ваших активов."
            />
            <ul className="cta__list">
              <li>Экспресс-аудит текущих протоколов</li>
              <li>Персональная команда для VIP-клиентов</li>
              <li>Гарантированная конфиденциальность данных</li>
            </ul>
          </div>
          <ContactForm variant="light" />
        </div>
      </section>
    </motion.div>
  );
}