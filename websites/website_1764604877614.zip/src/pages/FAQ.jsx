import { motion } from "framer-motion";
import Accordion from "../components/Accordion.jsx";
import SectionTitle from "../components/SectionTitle.jsx";

const faqItems = [
  {
    question: "Как FortisGuard обеспечивает конфиденциальность клиентов?",
    answer:
      "Мы применяем строгие протоколы доступа к информации, криптографию уровня военных стандартов и сегментацию данных. Все сотрудники подписывают NDA, проходят проверки службы безопасности и ежегодное обучение по защите информации."
  },
  {
    question: "Можно ли подключить FortisGuard к уже существующим системам безопасности?",
    answer:
      "Да, наша команда интегрирует существующую инфраструктуру в платформу FortisGuard Insight. Мы выполняем аудит, составляем карту систем и осуществляем подключение к единому ситуационному центру без остановки процессов."
  },
  {
    question: "Какие форматы сотрудничества доступны?",
    answer:
      "Мы предлагаем проектные решения, абонентское обслуживание, выделенные мобильные группы реагирования и размещение сотрудников на объекте клиента. Для VIP-клиентов доступна услуга Private Security Concierge."
  },
  {
    question: "Сколько времени требуется на запуск охраны объекта?",
    answer:
      "Подготовка включает аудит, разработку протоколов и обучение персонала. Для объектов до 10 000 м² старт занимает 7–14 дней, комплексные проекты промышленного масштаба — до 45 дней."
  },
  {
    question: "Работаете ли вы за пределами России?",
    answer:
      "FortisGuard имеет партнерскую сеть в Европе, Азии и на Ближнем Востоке. Мы сопровождаем клиентов при международных перелетах, командировках и реализации проектов за рубежом."
  },
  {
    question: "Как поддерживается качество и контроль персонала?",
    answer:
      "Мы внедрили пятиуровневую систему контроля: отбор, обучение, аттестация, полевые аудиты и цифровой мониторинг KPI. Каждое подразделение проходит внезапные проверки и стресс-тесты."
  }
];

export default function FAQ() {
  return (
    <motion.div
      className="page page-faq"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0.4 }}
      transition={{ duration: 0.6 }}
    >
      <section className="page-hero">
        <div className="container page-hero__content">
          <span className="page-hero__eyebrow">FAQ</span>
          <h1>Ответы на ключевые вопросы</h1>
          <p>
            Здесь собраны ответы на наиболее частые вопросы о наших услугах и процедурах.
            Если вы не нашли нужной информации — свяжитесь с нами, и мы предоставим
            персональную консультацию.
          </p>
        </div>
      </section>

      <section className="container section-dense">
        <SectionTitle
          eyebrow="Подробно"
          title="Прозрачность и понимание процессов FortisGuard"
        />
        <Accordion items={faqItems} />
      </section>

      <section className="section-cta">
        <div className="container section-cta__grid">
          <div className="cta__content">
            <SectionTitle
              eyebrow="Нужна консультация"
              title="Получите индивидуальное предложение"
              description="Наши специалисты оценят ваши потребности и подготовят стратегию защиты, учитывая отраслевые риски и стандарт безопасности."
            />
          </div>
          <div className="cta__actions">
            <a className="btn btn--primary btn--wide" href="tel:+74951234567">
              Позвонить сейчас
            </a>
            <a className="btn btn--ghost btn--wide" href="mailto:info@fortisguard.ru">
              Написать на почту
            </a>
          </div>
        </div>
      </section>
    </motion.div>
  );
}