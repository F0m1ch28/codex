document.addEventListener("DOMContentLoaded", function () {
  const currentYearEl = document.getElementById("currentYear");
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  const navToggle = document.getElementById("navToggle");
  const primaryNav = document.getElementById("primaryNav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNav.classList.toggle("active");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const acceptBtn = document.getElementById("cookieAccept");
  const declineBtn = document.getElementById("cookieDecline");
  const cookieKey = "bf_cookie_preference";

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedPreference = localStorage.getItem(cookieKey);
    if (!storedPreference) {
      cookieBanner.classList.add("active");
    }
    const handleChoice = (value) => {
      localStorage.setItem(cookieKey, value);
      cookieBanner.classList.remove("active");
    };
    acceptBtn.addEventListener("click", () => handleChoice("accepted"));
    declineBtn.addEventListener("click", () => handleChoice("declined"));
  }

  const fadeInElements = document.querySelectorAll(".fade-in");
  if (fadeInElements.length) {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    fadeInElements.forEach((el) => observer.observe(el));
  }

  const forms = document.querySelectorAll("form[data-form]");
  forms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      showToast("Message received. Redirecting...");
      setTimeout(() => {
        window.location.href = form.getAttribute("action");
      }, 1200);
    });
  });

  function showToast(message) {
    let toast = document.querySelector(".toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "toast";
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    requestAnimationFrame(() => {
      toast.classList.add("visible");
    });
    setTimeout(() => {
      toast.classList.remove("visible");
    }, 4000);
  }
});