document.addEventListener('DOMContentLoaded', function () {
    const yearEls = document.querySelectorAll('#current-year');
    const currentYear = new Date().getFullYear();
    yearEls.forEach(function (el) {
        el.textContent = currentYear;
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('ccwCookiePreference');
        if (!storedPreference) {
            cookieBanner.classList.add('active');
        }

        cookieBanner.addEventListener('click', function (event) {
            const target = event.target.closest('.cookie-btn');
            if (!target) return;

            event.preventDefault();
            const action = target.dataset.action;
            if (action === 'accept') {
                localStorage.setItem('ccwCookiePreference', 'accepted');
            } else if (action === 'decline') {
                localStorage.setItem('ccwCookiePreference', 'declined');
            }
            cookieBanner.classList.remove('active');
        });
    }

    const filterButtons = document.querySelectorAll('.filter-button');
    const searchInput = document.querySelector('.search-input');
    const articles = document.querySelectorAll('.article-list .story-card');

    function filterArticles() {
        const activeCategory = document.querySelector('.filter-button.active')?.dataset.filter || 'all';
        const searchTerm = searchInput ? searchInput.value.trim().toLowerCase() : '';

        articles.forEach(function (article) {
            const category = article.dataset.category;
            const title = article.dataset.title.toLowerCase();
            const matchesCategory = activeCategory === 'all' || category === activeCategory;
            const matchesSearch = !searchTerm || title.includes(searchTerm);
            if (matchesCategory && matchesSearch) {
                article.style.display = '';
            } else {
                article.style.display = 'none';
            }
        });
    }

    filterButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            filterButtons.forEach(function (btn) {
                btn.classList.remove('active');
            });
            button.classList.add('active');
            filterArticles();
        });
    });

    if (searchInput) {
        searchInput.addEventListener('input', filterArticles);
    }
});