document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.getElementById('navToggle');
    const nav = document.getElementById('primaryNav');

    if (navToggle && nav) {
        navToggle.addEventListener('click', function () {
            const isOpen = nav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', String(isOpen));
        });

        nav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                nav.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    if (cookieBanner) {
        const storedConsent = localStorage.getItem('cycloskjlzCookieConsent');
        if (!storedConsent) {
            requestAnimationFrame(function () {
                cookieBanner.classList.add('is-visible');
            });
        }

        cookieBanner.querySelectorAll('[data-consent]').forEach(function (button) {
            button.addEventListener('click', function () {
                const choice = button.getAttribute('data-consent') || 'decline';
                localStorage.setItem('cycloskjlzCookieConsent', choice);
                cookieBanner.classList.remove('is-visible');
            });
        });
    }
});