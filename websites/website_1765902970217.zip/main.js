document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      primaryNav.classList.toggle("is-open", !expanded);
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptCookiesButton = document.querySelector("[data-cookie-accept]");
  const declineCookiesButton = document.querySelector("[data-cookie-decline]");
  const cookiePreferenceKey = "fluxgrid-cookie-preference";

  const hideCookieBanner = () => {
    if (cookieBanner) {
      cookieBanner.setAttribute("hidden", "true");
    }
  };

  if (cookieBanner) {
    const storedPreference = localStorage.getItem(cookiePreferenceKey);
    if (!storedPreference) {
      cookieBanner.removeAttribute("hidden");
    } else {
      hideCookieBanner();
    }
  }

  if (acceptCookiesButton) {
    acceptCookiesButton.addEventListener("click", () => {
      localStorage.setItem(cookiePreferenceKey, "accepted");
      hideCookieBanner();
    });
  }

  if (declineCookiesButton) {
    declineCookiesButton.addEventListener("click", () => {
      localStorage.setItem(cookiePreferenceKey, "declined");
      hideCookieBanner();
    });
  }

  const contactForm = document.querySelector('form[data-form="contact"]');
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!contactForm.checkValidity()) {
        contactForm.reportValidity();
        return;
      }
      window.location.href = "thanks.html";
    });
  }
});