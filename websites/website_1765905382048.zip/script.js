document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('is-active');
      siteNav.classList.toggle('is-open');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptButton = document.querySelector('.cookie-accept');
  const declineButton = document.querySelector('.cookie-decline');
  const cookiePreference = localStorage.getItem('gesCookiePreference');

  if (!cookiePreference && cookieBanner) {
    cookieBanner.classList.add('is-visible');
  }

  function setCookiePreference(value) {
    localStorage.setItem('gesCookiePreference', value);
    if (cookieBanner) {
      cookieBanner.classList.remove('is-visible');
    }
  }

  if (acceptButton) {
    acceptButton.addEventListener('click', () => {
      setCookiePreference('accepted');
    });
  }

  if (declineButton) {
    declineButton.addEventListener('click', () => {
      setCookiePreference('declined');
    });
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const name = contactForm.querySelector('#name');
      const email = contactForm.querySelector('#email');
      const message = contactForm.querySelector('#message');
      const feedback = contactForm.querySelector('.form-message');

      let hasError = false;
      if (feedback) {
        feedback.textContent = '';
      }

      [name, email, message].forEach((field) => {
        field.classList.remove('has-error');
        if (!field.value.trim()) {
          field.classList.add('has-error');
          hasError = true;
        }
      });

      if (email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        hasError = true;
        if (feedback) {
          feedback.textContent = 'Please provide a valid email address.';
        }
      }

      if (!hasError) {
        window.location.href = 'thanks.html';
      } else if (feedback && !feedback.textContent) {
        feedback.textContent = 'Please complete all fields before submitting.';
      }
    });
  }

  const searchInput = document.getElementById('post-search');
  const categorySelect = document.getElementById('category-filter');
  const postCards = document.querySelectorAll('[data-post]');

  function filterPosts() {
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    const category = categorySelect ? categorySelect.value : 'all';

    postCards.forEach((card) => {
      const title = card.querySelector('.post-card__title')?.textContent.toLowerCase() || '';
      const excerpt = card.querySelector('.post-card__excerpt')?.textContent.toLowerCase() || '';
      const categories = card.getAttribute('data-categories') || '';
      const matchesQuery = !query || title.includes(query) || excerpt.includes(query);
      const matchesCategory = category === 'all' || categories.split(',').map((item) => item.trim()).includes(category);

      if (matchesQuery && matchesCategory) {
        card.removeAttribute('hidden');
      } else {
        card.setAttribute('hidden', 'hidden');
      }
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterPosts);
  }

  if (categorySelect) {
    categorySelect.addEventListener('change', filterPosts);
  }

  const paginationButtons = document.querySelectorAll('[data-page]');
  if (paginationButtons.length > 0) {
    paginationButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const targetPage = button.getAttribute('data-page');
        paginationButtons.forEach((btn) => btn.classList.remove('is-active'));
        button.classList.add('is-active');
        postCards.forEach((card) => {
          if (targetPage === 'all' || card.getAttribute('data-page') === targetPage) {
            card.removeAttribute('hidden');
          } else {
            card.setAttribute('hidden', 'hidden');
          }
        });
        filterPosts();
      });
    });
  }

  const shareButtons = document.querySelectorAll('[data-share]');
  shareButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const network = button.getAttribute('data-share');
      const url = encodeURIComponent(window.location.href);
      const title = encodeURIComponent(document.title);
      let shareUrl = '';
      if (network === 'twitter') {
        shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
      } else if (network === 'linkedin') {
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
      } else if (network === 'email') {
        shareUrl = `mailto:?subject=${title}&body=${url}`;
      }
      if (shareUrl) {
        window.open(shareUrl, '_blank', 'noopener,noreferrer,width=600,height=540');
      }
    });
  });
});