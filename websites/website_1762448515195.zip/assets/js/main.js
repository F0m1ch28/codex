document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.getElementById('primaryNav');
    const scrollTopBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteNav.classList.toggle('open');
        });

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                siteNav.classList.remove('open');
                window.scrollTo({ top: 0, behavior: 'instant' });
            });
        });
    }

    if (scrollTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 400) {
                scrollTopBtn.classList.add('show');
            } else {
                scrollTopBtn.classList.remove('show');
            }
        });

        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    document.querySelectorAll('form.contact-form').forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();
            form.reset();
            const response = form.querySelector('.form-response');
            if (response) {
                response.textContent = 'Thank you for reaching out. Our strategists will respond within one business day.';
            }
        });
    });

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem('cn_cookie_consent');
        if (consent !== 'true') {
            cookieBanner.classList.add('show');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('cn_cookie_consent', 'true');
            cookieBanner.classList.remove('show');
        });
    }
});