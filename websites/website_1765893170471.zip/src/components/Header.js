import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => {
    setMenuOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className={styles.header} aria-label="Main navigation">
      <div className={styles.wrapper}>
        <Link to="/" className={styles.logo} onClick={closeMenu}>
          TalentScope Diagnostics
        </Link>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`}>
          <NavLink to="/about" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            About
          </NavLink>
          <NavLink to="/services" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Services
          </NavLink>
          <NavLink to="/solutions" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Solutions
          </NavLink>
          <NavLink to="/case-studies" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Case Studies
          </NavLink>
          <NavLink to="/contact" onClick={closeMenu} className={({ isActive }) => (isActive ? styles.active : '')}>
            Contact
          </NavLink>
        </nav>
        <button
          type="button"
          className={styles.menuButton}
          onClick={handleToggle}
          aria-label="Toggle navigation"
          aria-expanded={menuOpen}
        >
          <span className={styles.menuIcon} />
        </button>
      </div>
    </header>
  );
};

export default Header;