import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Site footer">
      <div className={styles.container}>
        <div className={styles.brandBlock}>
          <h2 className={styles.title}>TalentScope Diagnostics</h2>
          <p className={styles.caption}>
            Workforce development diagnostics Canada, training needs analysis, and employee retention insights crafted for resilient teams.
          </p>
          <div className={styles.contactDetails}>
            <p>123 Scope St, Edmonton, AB T5J 3R8, Canada</p>
            <p>Phone: <a href="tel:+17805557890">+1 780 555 7890</a></p>
            <p>Email: <a href="mailto:info@talentscopediagnostics.ca">info@talentscopediagnostics.ca</a></p>
          </div>
        </div>
        <div className={styles.linkGroups}>
          <div>
            <h3 className={styles.groupTitle}>Explore</h3>
            <ul>
              <li><Link to="/about">About</Link></li>
              <li><Link to="/services">Services</Link></li>
              <li><Link to="/solutions">Solutions</Link></li>
              <li><Link to="/case-studies">Case Studies</Link></li>
            </ul>
          </div>
          <div>
            <h3 className={styles.groupTitle}>Governance</h3>
            <ul>
              <li><Link to="/privacy-policy">Privacy Policy</Link></li>
              <li><Link to="/cookie-policy">Cookie Policy</Link></li>
              <li><Link to="/terms-of-use">Terms of Use</Link></li>
            </ul>
          </div>
        </div>
      </div>
      <p className={styles.bottomNote}>
        &copy; {new Date().getFullYear()} TalentScope Diagnostics. All rights reserved.
      </p>
    </footer>
  );
};

export default Footer;