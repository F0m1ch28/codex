import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

const ServicesPage = () => {
  return (
    <>
      <Helmet>
        <title>Services | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Discover TalentScope Diagnostics services including workforce development diagnostics, training needs analysis, and retention monitoring tailored for Canadian organizations."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/services" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Services crafted for lasting workforce strength</h1>
        <p>
          We pair strategic analysis with compassionate facilitation to create insight that encourages meaningful action.
        </p>
      </section>

      <section className={styles.serviceSection}>
        <article>
          <h2>Workforce Development Diagnostics</h2>
          <p>
            Comprehensive diagnostics provide a panoramic view of current workforce capabilities, patterns in collaboration, and readiness for future roles. We integrate surveys, interviews, policy reviews, and workforce performance assessment dashboards to ground recommendations in evidence.
          </p>
          <p>
            Deliverables include capability heatmaps, cross-functional insight summaries, and a prioritized roadmap that supports staff skill evaluation across departments.
          </p>
        </article>
        <article>
          <h2>Training Needs Analysis</h2>
          <p>
            Our training needs analysis blends competency frameworks with voice-of-employee narratives. We identify knowledge depth, skill adjacency, and learning preferences to design development pathways that resonate with diverse teams.
          </p>
          <p>
            The outcome ensures training resources align with talent development compliance requirements while supporting continuous professional growth monitoring.
          </p>
        </article>
        <article>
          <h2>Retention Monitoring</h2>
          <p>
            TalentScope Diagnostics builds retention monitoring programs that surface engagement drivers, sense of belonging indicators, and emerging career aspirations. We partner with HR and operational leaders to co-create recurring check-ins and responsive action plans.
          </p>
          <p>
            Insights address employee retention insights, career progression diagnostics, and targeted interventions that honour unique team contexts.
          </p>
        </article>
      </section>
    </>
  );
};

export default ServicesPage;