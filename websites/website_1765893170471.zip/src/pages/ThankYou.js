import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './ThankYou.module.css';

const ThankYouPage = () => {
  return (
    <>
      <Helmet>
        <title>Thank You | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Thank you for contacting TalentScope Diagnostics. We will respond shortly."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/thank-you" />
      </Helmet>
      <section className={styles.wrapper}>
        <h1>Thank you</h1>
        <p>
          We have received your message and a member of the TalentScope Diagnostics team will be in touch soon to discuss your workforce priorities.
        </p>
        <Link to="/" className={styles.link}>
          Return to homepage
        </Link>
      </section>
    </>
  );
};

export default ThankYouPage;