import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CaseStudies.module.css';

const CaseStudiesPage = () => {
  return (
    <>
      <Helmet>
        <title>Case Studies | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Review TalentScope Diagnostics case studies highlighting workforce diagnostics, training needs analysis, and retention engagement projects across Canada."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/case-studies" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Case Studies</h1>
        <p>
          A glimpse into how TalentScope Diagnostics partners with organizations to achieve clarity and momentum.
        </p>
      </section>

      <section className={styles.gallery}>
        <article className={styles.card}>
          <img
            src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80"
            alt="Team workshop"
          />
          <h2>National Transportation Cooperative</h2>
          <p>
            Conducted workforce development diagnostics to unify standards across regional hubs, introducing shared metrics for staff skill evaluation and hybrid onboarding.
          </p>
        </article>
        <article className={styles.card}>
          <img
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=80"
            alt="Executive presentation"
          />
          <h2>Energy Innovation Council</h2>
          <p>
            Delivered employee retention insights highlighting progression roadmaps and mentoring pilots that improved continuity during a large transformation program.
          </p>
        </article>
        <article className={styles.card}>
          <img
            src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80"
            alt="Digital collaboration"
          />
          <h2>Technology Incubator Network</h2>
          <p>
            Enabled professional growth monitoring through analytics dashboards that illuminated training needs analysis priorities for emerging roles.
          </p>
        </article>
      </section>
    </>
  );
};

export default CaseStudiesPage;