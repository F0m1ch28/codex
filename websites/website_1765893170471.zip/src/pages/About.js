import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About TalentScope Diagnostics | Workforce Insight Partners</title>
        <meta
          name="description"
          content="Learn about the mission, team, and milestones of TalentScope Diagnostics, supporting Canadian organizations with workforce diagnostics and staff development insights."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/about" />
      </Helmet>
      <section className={styles.hero}>
        <h1>About TalentScope Diagnostics</h1>
        <p>
          We help organizations decode workforce signals with empathy, analytics, and collaborative planning.
        </p>
      </section>

      <section className={styles.mission}>
        <h2>Mission</h2>
        <p>
          Our mission is to empower Canadian organizations with transparent workforce development diagnostics that respect employees, honour regional regulations, and cultivate thriving workplaces. We believe that strategic talent decisions emerge from listening to people, interpreting data responsibly, and translating insights into supportive action.
        </p>
      </section>

      <section className={styles.team}>
        <h2>Team</h2>
        <div className={styles.teamGrid}>
          <article>
            <img
              src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=500&q=80"
              alt="Portrait of Maya Chen"
            />
            <h3>Maya Chen</h3>
            <p>Managing Director</p>
            <p>
              Maya leads enterprise engagements, ensuring every workforce performance assessment aligns with organizational culture and Canadian workplace standards.
            </p>
          </article>
          <article>
            <img
              src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=500&q=80"
              alt="Portrait of Liam Dupont"
            />
            <h3>Liam Dupont</h3>
            <p>Principal Data Strategist</p>
            <p>
              Liam designs the analytics frameworks that inform training needs analysis, talent development compliance, and progression measurement.
            </p>
          </article>
          <article>
            <img
              src="https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=500&q=80"
              alt="Portrait of Anika Patel"
            />
            <h3>Anika Patel</h3>
            <p>Engagement Lead</p>
            <p>
              Anika coordinates stakeholder workshops, facilitating honest conversation and ensuring every voice is represented throughout the diagnostic journey.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.timeline}>
        <h2>Milestones</h2>
        <ul>
          <li>
            <span className={styles.year}>2016</span>
            Founded in Edmonton to address emerging workforce development diagnostics Canada needs in energy and technology sectors.
          </li>
          <li>
            <span className={styles.year}>2018</span>
            Introduced blended training needs analysis combining human-centred design with quantitative benchmarking.
          </li>
          <li>
            <span className={styles.year}>2020</span>
            Expanded employee retention insights programs to support distributed teams responding to rapid change.
          </li>
          <li>
            <span className={styles.year}>2023</span>
            Launched national partnerships focused on career progression diagnostics for inclusive work environments.
          </li>
        </ul>
      </section>
    </>
  );
};

export default AboutPage;