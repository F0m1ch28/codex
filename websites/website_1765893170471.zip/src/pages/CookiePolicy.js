import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

const CookiePolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Learn about the cookies used by TalentScope Diagnostics and how you can manage them."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/cookie-policy" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Cookie Policy</h1>
        <p>Effective date: January 1, 2024</p>
      </section>

      <section className={styles.content}>
        <h2>What are cookies?</h2>
        <p>
          Cookies are small text files stored on your device to improve the experience of visiting our website. They help remember preferences and support analytical insight.
        </p>

        <h2>How we use cookies</h2>
        <ul>
          <li>Essential cookies maintain core site functionality.</li>
          <li>Analytics cookies help us understand page usage and measure interest in our workforce development diagnostics Canada resources.</li>
        </ul>

        <h2>Managing cookies</h2>
        <p>
          You can adjust browser settings to refuse cookies or notify you when cookies are sent. If you disable cookies, some features may not function as intended.
        </p>

        <h2>More information</h2>
        <p>
          For questions about this policy, contact <a href="mailto:info@talentscopediagnostics.ca">info@talentscopediagnostics.ca</a>.
        </p>
      </section>
    </>
  );
};

export default CookiePolicyPage;