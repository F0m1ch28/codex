import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './PrivacyPolicy.module.css';

const PrivacyPolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Read the TalentScope Diagnostics privacy policy describing how personal data is collected, used, and safeguarded."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/privacy-policy" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Privacy Policy</h1>
        <p>Effective date: January 1, 2024</p>
      </section>

      <section className={styles.content}>
        <h2>Overview</h2>
        <p>
          TalentScope Diagnostics respects your privacy. This policy outlines how we handle personal information gathered through our website or direct communication.
        </p>

        <h2>Information collection</h2>
        <p>
          We collect information that you voluntarily provide, such as contact details submitted through forms or email, along with technical data automatically supplied by your browser.
        </p>

        <h2>Use of information</h2>
        <p>
          Collected information is used to respond to inquiries, share relevant updates about workforce development diagnostics Canada engagements, and maintain quality assurance. We do not sell personal information.
        </p>

        <h2>Data retention</h2>
        <p>
          We retain personal information only for as long as necessary to fulfill the purposes described in this policy or as required by Canadian regulations.
        </p>

        <h2>Third-party services</h2>
        <p>
          We may use trusted third-party tools for secure data storage, analytics, or communication. These providers are required to protect personal information in line with applicable laws.
        </p>

        <h2>Your rights</h2>
        <p>
          You may request access, correction, or deletion of your personal information by contacting us at <a href="mailto:info@talentscopediagnostics.ca">info@talentscopediagnostics.ca</a>.
        </p>

        <h2>Updates</h2>
        <p>
          We may update this policy periodically. Changes will be posted on this page with a revised effective date.
        </p>
      </section>
    </>
  );
};

export default PrivacyPolicyPage;