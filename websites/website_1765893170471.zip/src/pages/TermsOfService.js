import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './TermsOfService.module.css';

const TermsOfServicePage = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Use | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Review the Terms of Use governing the TalentScope Diagnostics website and services."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/terms-of-use" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Terms of Use</h1>
        <p>Effective date: January 1, 2024</p>
      </section>

      <section className={styles.content}>
        <h2>Acceptance</h2>
        <p>
          By accessing the TalentScope Diagnostics website, you agree to comply with these Terms of Use. If you do not agree, please refrain from using the site.
        </p>

        <h2>Use of content</h2>
        <p>
          Content provided through this site is for informational purposes related to workforce diagnostics, training needs analysis, and professional growth monitoring. You may not reproduce, modify, or distribute content without prior written permission.
        </p>

        <h2>Intellectual property</h2>
        <p>
          All trademarks, graphics, and materials on this site are the property of TalentScope Diagnostics unless otherwise noted.
        </p>

        <h2>Limitation of liability</h2>
        <p>
          TalentScope Diagnostics is not responsible for any indirect or consequential damages arising from the use of this website. We aim to keep information accurate but cannot guarantee completeness or timeliness.
        </p>

        <h2>External links</h2>
        <p>
          Our site may contain links to third-party resources. We are not responsible for content or policies of external sites.
        </p>

        <h2>Changes</h2>
        <p>
          We may update these terms periodically. Continued use of the website following updates indicates acceptance of the revised terms.
        </p>

        <h2>Contact</h2>
        <p>
          For questions about these terms, contact <a href="mailto:info@talentscopediagnostics.ca">info@talentscopediagnostics.ca</a>.
        </p>
      </section>
    </>
  );
};

export default TermsOfServicePage;