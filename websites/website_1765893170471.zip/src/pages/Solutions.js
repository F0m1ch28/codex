import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Solutions.module.css';

const SolutionsPage = () => {
  return (
    <>
      <Helmet>
        <title>Solutions | TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Explore TalentScope Diagnostics solutions, including visual frameworks, diagrams, and use cases that showcase our workforce diagnostics methodology."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/solutions" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Solutions that translate insight into action</h1>
        <p>
          Our frameworks are designed to embed workforce knowledge into daily decision-making, helping teams stay adaptive and informed.
        </p>
      </section>

      <section className={styles.layoutShowcase}>
        <div className={styles.diagramCard}>
          <img
            src="https://images.unsplash.com/photo-1582719478400-771c1ff6781c?auto=format&fit=crop&w=800&q=80"
            alt="Layered workforce diagnostic diagram"
          />
          <div>
            <h2>Integrated Diagnostic Model</h2>
            <p>
              This model connects workforce development diagnostics Canada requirements with organizational capability maps, enabling leaders to identify leverage points for staff skill evaluation.
            </p>
          </div>
        </div>
        <div className={styles.diagramCard}>
          <img
            src="https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?auto=format&fit=crop&w=800&q=80"
            alt="Stakeholder workshop illustration"
          />
          <div>
            <h2>Stakeholder Alignment Journeys</h2>
            <p>
              We facilitate collaborative workshops that guide cross-functional teams through shared insight, translating employee retention insights into achievable commitments.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.useCases}>
        <h2>Use cases</h2>
        <div className={styles.useCaseGrid}>
          <article>
            <h3>Operational transformation</h3>
            <p>
              Align workforce performance assessment findings with evolving operational models, prioritizing reskilling initiatives that support emerging services.
            </p>
          </article>
          <article>
            <h3>Leadership development</h3>
            <p>
              Equip managers with professional growth monitoring scorecards to track coaching conversations, development milestones, and internal mobility aspirations.
            </p>
          </article>
          <article>
            <h3>Compliance evolution</h3>
            <p>
              Maintain talent development compliance through refreshed competency standards and transparent progress tracking across regions.
            </p>
          </article>
          <article>
            <h3>Hybrid workforce alignment</h3>
            <p>
              Support hybrid and remote teams with diagnostics that visualize collaboration patterns and ensure equitable access to training resources.
            </p>
          </article>
        </div>
      </section>
    </>
  );
};

export default SolutionsPage;