import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  message: ''
};

const ContactPage = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please provide your name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide an email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.company.trim()) newErrors.company = 'Please provide your company or organization.';
    if (!formData.message.trim()) newErrors.message = 'Please include a short message.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setFormData(initialState);
    navigate('/thank-you');
  };

  return (
    <>
      <Helmet>
        <title>Contact TalentScope Diagnostics</title>
        <meta
          name="description"
          content="Contact TalentScope Diagnostics in Edmonton for workforce development diagnostics, training needs analysis, and employee retention insights."
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/contact" />
      </Helmet>
      <section className={styles.hero}>
        <h1>Contact TalentScope Diagnostics</h1>
        <p>
          We are ready to support your workforce development diagnostics, training needs analysis, and professional growth monitoring initiatives.
        </p>
      </section>

      <section className={styles.contactSection}>
        <div className={styles.details}>
          <h2>Connect with us</h2>
          <p><strong>Address:</strong> 123 Scope St, Edmonton, AB T5J 3R8, Canada</p>
          <p><strong>Phone:</strong> <a href="tel:+17805557890">+1 780 555 7890</a></p>
          <p><strong>Email:</strong> <a href="mailto:info@talentscopediagnostics.ca">info@talentscopediagnostics.ca</a></p>
          <p>
            Share a few details about your objectives, and our advisory team will arrange a discovery call to learn more about your workforce performance assessment priorities.
          </p>
          <img
            src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80"
            alt="Canadian office building"
            className={styles.detailImage}
          />
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Send a message</h2>
          <label htmlFor="name">Name</label>
          <input
            id="name"
            name="name"
            type="text"
            value={formData.name}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={errors.name ? 'true' : 'false'}
          />
          {errors.name && <span className={styles.error} role="alert">{errors.name}</span>}

          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={errors.email ? 'true' : 'false'}
          />
          {errors.email && <span className={styles.error} role="alert">{errors.email}</span>}

          <label htmlFor="company">Company</label>
          <input
            id="company"
            name="company"
            type="text"
            value={formData.company}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={errors.company ? 'true' : 'false'}
          />
          {errors.company && <span className={styles.error} role="alert">{errors.company}</span>}

          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            rows="5"
            value={formData.message}
            onChange={handleChange}
            aria-required="true"
            aria-invalid={errors.message ? 'true' : 'false'}
          />
          {errors.message && <span className={styles.error} role="alert">{errors.message}</span>}

          <button type="submit" className={styles.submitButton}>
            Submit
          </button>
        </form>
      </section>

      <section className={styles.mapSection}>
        <h2>Our Edmonton location</h2>
        <img
          src="https://via.placeholder.com/1200x400.png?text=Map+Placeholder+-+Edmonton"
          alt="Map placeholder showing Edmonton, Alberta"
        />
      </section>
    </>
  );
};

export default ContactPage;