import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>TalentScope Diagnostics | Workforce Development Diagnostics Canada</title>
        <meta
          name="description"
          content="TalentScope Diagnostics supports Canadian organizations with workforce development diagnostics, training needs analysis, employee retention insights, and professional growth monitoring."
        />
        <meta
          name="keywords"
          content="workforce development diagnostics Canada, training needs analysis, employee retention insights, professional growth monitoring, staff skill evaluation, workforce performance assessment, talent development compliance, career progression diagnostics"
        />
        <link rel="canonical" href="https://www.talentscopediagnostics.ca/" />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.preTitle}>Insight-driven workforce intelligence</p>
          <h1>TalentScope Diagnostics</h1>
          <p className={styles.heroText}>
            Illuminate workforce development diagnostics in Canada with data-grounded insight, thoughtful training needs analysis, and continuous professional growth monitoring designed for changing workplaces.
          </p>
          <Link to="/contact" className={styles.heroButton}>
            Start a conversation
          </Link>
        </div>
        <div className={styles.heroVisual} role="presentation">
          <img
            src="https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=900&q=80"
            alt="Team reviewing workforce analytics"
          />
        </div>
      </section>

      <section className={styles.intro}>
        <div className={styles.introText}>
          <h2>Purpose-built diagnostics for workforce clarity</h2>
          <p>
            TalentScope Diagnostics partners with Canadian employers to discover workforce performance assessment insights across departments and locations. We combine qualitative interviews, pulse surveys, and data modelling to surface actionable trends on training readiness, staff skill evaluation, and talent development compliance.
          </p>
        </div>
        <div className={styles.introCards}>
          <article className={styles.introCard}>
            <img
              src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=600&q=80"
              alt="Analyst reviewing reports"
            />
            <h3>Evidence-first approach</h3>
            <p>
              Every recommendation is grounded in carefully validated workforce indicators aligned with Canadian labour standards and organizational culture.
            </p>
          </article>
          <article className={styles.introCard}>
            <img
              src="https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=600&q=80"
              alt="Collaborative meeting in office"
            />
            <h3>Collaborative engagement</h3>
            <p>
              We co-create frameworks with internal stakeholders, building a shared understanding of capability gaps and retention signals.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.services}>
        <h2>Three core services for sustainable talent decisions</h2>
        <div className={styles.serviceGrid}>
          <article className={styles.serviceCard}>
            <h3>Training Needs Analysis</h3>
            <p>
              Diagnose current competencies through skill inventories, job task mapping, and learner experience interviews to prioritize the most relevant development pathways.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <h3>Employee Retention Insights</h3>
            <p>
              Identify engagement drivers, progression bottlenecks, and attrition indicators with qualitative and quantitative workforce performance assessment dashboards.
            </p>
          </article>
          <article className={styles.serviceCard}>
            <h3>Professional Growth Monitoring</h3>
            <p>
              Build a continuous feedback loop that tracks progression across new capabilities, talent development compliance, and future-ready role transitions.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.differentiators}>
        <div className={styles.diffContent}>
          <h2>Why organizations choose TalentScope Diagnostics</h2>
          <ul>
            <li>End-to-end diagnostics tailored to Canadian governance and sector benchmarks.</li>
            <li>Modern reporting dashboards that translate complex data into understandable narratives.</li>
            <li>Dedicated advisors who guide implementation phases and support internal communications.</li>
            <li>Ethical data stewardship with transparent methodologies and inclusive stakeholder engagement.</li>
          </ul>
        </div>
        <div className={styles.diffVisual}>
          <img
            src="https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&w=700&q=80"
            alt="Dashboard showing workforce metrics"
          />
        </div>
      </section>

      <section className={styles.testimonials}>
        <h2>Voices from Canadian workplaces</h2>
        <div className={styles.testimonialGrid}>
          <blockquote className={styles.testimonialCard}>
            <p>
              “TalentScope Diagnostics gave our leadership team clearer visibility into workforce development diagnostics Canada requirements and surfaced opportunities we had not yet explored.”
            </p>
            <cite>Director of People &amp; Culture, Northern Ventures</cite>
          </blockquote>
          <blockquote className={styles.testimonialCard}>
            <p>
              “The employee retention insights and career progression diagnostics shaped an internal program that now keeps colleagues engaged through meaningful learning cycles.”
            </p>
            <cite>HR Business Partner, Prairie Manufacturing Cooperative</cite>
          </blockquote>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Ready to advance workforce clarity?</h2>
          <p>
            Connect with TalentScope Diagnostics to explore tailored diagnostics, training plans, and ongoing professional growth monitoring.
          </p>
          <Link to="/contact" className={styles.ctaButton}>
            Schedule a discovery call
          </Link>
        </div>
      </section>

      <section className={styles.contactStrip} aria-label="Contact information preview">
        <div>
          <h3>Visit</h3>
          <p>123 Scope St, Edmonton, AB T5J 3R8, Canada</p>
        </div>
        <div>
          <h3>Call</h3>
          <p><a href="tel:+17805557890">+1 780 555 7890</a></p>
        </div>
        <div>
          <h3>Email</h3>
          <p><a href="mailto:info@talentscopediagnostics.ca">info@talentscopediagnostics.ca</a></p>
        </div>
      </section>
    </>
  );
};

export default HomePage;