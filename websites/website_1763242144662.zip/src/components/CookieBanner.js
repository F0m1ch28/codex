import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('gt-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem('gt-cookie-consent', value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <h4>Wir verwenden Cookies</h4>
        <p>
          Wir nutzen Cookies, um Ihr Nutzererlebnis zu verbessern und unsere Services zu optimieren. Weitere Informationen
          finden Sie in unserer <Link to="/cookie-richtlinie">Cookie-Richtlinie</Link>.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondary} onClick={() => handleConsent('declined')}>
          Ablehnen
        </button>
        <button type="button" className={styles.primary} onClick={() => handleConsent('accepted')}>
          Akzeptieren
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;