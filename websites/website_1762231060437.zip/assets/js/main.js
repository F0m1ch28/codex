document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menuToggle');
    const primaryNav = document.getElementById('primary-navigation');

    if (menuToggle && primaryNav) {
        menuToggle.addEventListener('click', () => {
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
            menuToggle.setAttribute('aria-expanded', String(!expanded));
            primaryNav.classList.toggle('open');
        });
    }

    const navLinks = document.querySelectorAll('a[data-scroll-top]');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (primaryNav && primaryNav.classList.contains('open')) {
                primaryNav.classList.remove('open');
                menuToggle && menuToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    const currentPage = document.body.dataset.page;
    if (currentPage) {
        const activeLink = document.querySelector(`a[data-page="${currentPage}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }
    }

    const scrollTopBtn = document.getElementById('scrollTopBtn');

    const toggleScrollButton = () => {
        if (!scrollTopBtn) return;
        if (window.scrollY > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    };

    window.addEventListener('scroll', toggleScrollButton);

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    toggleScrollButton();

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');

    if (cookieBanner && acceptCookies) {
        const consent = localStorage.getItem('novalineCookiesAccepted');
        if (!consent) {
            cookieBanner.classList.add('show');
        }
        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('novalineCookiesAccepted', 'true');
            cookieBanner.classList.remove('show');
        });
    }

    const yearEl = document.getElementById('currentYear');
    if (yearEl) {
        yearEl.textContent = new Date().getFullYear();
    }
});