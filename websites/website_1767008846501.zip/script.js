(function () {
  const navToggle = document.getElementById("menu-toggle");
  const navMenu = document.getElementById("site-nav");
  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      navMenu.classList.toggle("open");
      navToggle.classList.toggle("active");
    });
  }

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const consentKey = "superludoCookieConsent";

  function hideBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove("active");
    }
  }

  function showBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("active");
    }
  }

  function setConsent(value) {
    try {
      localStorage.setItem(consentKey, value);
    } catch (error) {
      console.warn("Cookie consent could not be stored:", error);
    }
  }

  function getConsent() {
    try {
      return localStorage.getItem(consentKey);
    } catch (error) {
      console.warn("Consent retrieval failed:", error);
      return null;
    }
  }

  const storedConsent = getConsent();
  if (!storedConsent) {
    showBanner();
  }

  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      setConsent("accepted");
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      setConsent("declined");
      hideBanner();
    });
  }
})();