document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.getElementById('nav-toggle');
    const navigation = document.getElementById('primary-navigation');
    const banner = document.getElementById('cookie-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const declineBtn = document.getElementById('cookie-decline');
    const consentKey = 'dot-cookie-consent';

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navigation.classList.toggle('open');
        });

        navigation.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navigation.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    if (banner && acceptBtn && declineBtn) {
        const storedConsent = localStorage.getItem(consentKey);

        if (!storedConsent) {
            banner.classList.add('active');
        }

        const handleConsent = (value) => {
            localStorage.setItem(consentKey, value);
            banner.classList.remove('active');
        };

        acceptBtn.addEventListener('click', () => handleConsent('accepted'));
        declineBtn.addEventListener('click', () => handleConsent('declined'));
    }
});