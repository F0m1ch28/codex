document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.primary-navigation');
    const headerLinks = document.querySelectorAll('.primary-navigation a');
    const headerLogo = document.querySelector('.logo');
    const footerLinks = document.querySelectorAll('.footer-sitemap a');
    const scrollTopButton = document.querySelector('.scroll-top');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieAcceptButton = document.getElementById('cookie-accept');
    const contactForm = document.querySelector('.contact-form');
    const newsletterForm = document.querySelector('.newsletter-form');

    // Mobile navigation toggle
    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navigation.classList.toggle('is-open');
        });

        headerLinks.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                navigation.classList.remove('is-open');
            });
        });
    }

    // Scroll to top button visibility
    const handleScroll = () => {
        if (!scrollTopButton) return;
        if (window.scrollY > 250) {
            scrollTopButton.classList.add('is-visible');
        } else {
            scrollTopButton.classList.remove('is-visible');
        }
    };
    window.addEventListener('scroll', handleScroll);
    handleScroll();

    // Scroll to top action
    if (scrollTopButton) {
        scrollTopButton.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Reset scroll on navigation clicks
    const resetScrollTargets = [...headerLinks, ...footerLinks];
    if (headerLogo) resetScrollTargets.push(headerLogo);
    resetScrollTargets.forEach(link => {
        link.addEventListener('click', () => {
            window.scrollTo({ top: 0 });
        });
    });

    // Cookie banner logic
    const COOKIE_STORAGE_KEY = 'canadiCookieAccepted';
    if (cookieBanner && cookieAcceptButton) {
        const isAccepted = localStorage.getItem(COOKIE_STORAGE_KEY) === 'true';
        if (!isAccepted) {
            cookieBanner.classList.add('is-visible');
        }

        cookieAcceptButton.addEventListener('click', () => {
            localStorage.setItem(COOKIE_STORAGE_KEY, 'true');
            cookieBanner.classList.remove('is-visible');
        });
    }

    // Contact form handler
    if (contactForm) {
        const contactMessage = contactForm.querySelector('[data-form="contact"]');
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name')?.trim();
            const email = formData.get('email')?.trim();
            const message = formData.get('message')?.trim();

            if (!name || !email || !message) {
                if (contactMessage) {
                    contactMessage.textContent = 'Будь ласка, заповніть обов’язкові поля.';
                    contactMessage.style.color = '#c8102e';
                }
                return;
            }

            contactForm.reset();
            if (contactMessage) {
                contactMessage.textContent = 'Дякуємо! Ваше повідомлення надіслано. Редакція відповість найближчим часом.';
                contactMessage.style.color = '#0b8e35';
            }
        });
    }

    // Newsletter form handler
    if (newsletterForm) {
        const newsletterMessage = newsletterForm.querySelector('[data-form="newsletter"]');
        newsletterForm.addEventListener('submit', event => {
            event.preventDefault();
            const emailField = newsletterForm.querySelector('input[name="email"]');
            if (!emailField || !emailField.value.trim()) {
                if (newsletterMessage) {
                    newsletterMessage.textContent = 'Введіть коректну електронну адресу.';
                    newsletterMessage.style.color = '#c8102e';
                }
                return;
            }
            newsletterForm.reset();
            if (newsletterMessage) {
                newsletterMessage.textContent = 'Підписку оформлено. Перевірте пошту для підтвердження.';
                newsletterMessage.style.color = '#0b8e35';
            }
        });
    }
});