document.addEventListener("DOMContentLoaded", function () {
    const banner = document.querySelector(".cookie-banner");
    if (!banner) {
        return;
    }
    const storedChoice = localStorage.getItem("materiyjxh-cookie-choice");
    if (storedChoice) {
        banner.classList.add("is-hidden");
        return;
    }
    const actions = banner.querySelectorAll(".cookie-action");
    actions.forEach((action) => {
        action.addEventListener("click", function (event) {
            event.preventDefault();
            const decision = this.classList.contains("accept") ? "accepted" : "declined";
            localStorage.setItem("materiyjxh-cookie-choice", decision);
            banner.classList.add("is-hidden");
            const targetLink = this.getAttribute("href");
            if (targetLink) {
                setTimeout(() => {
                    window.location.href = targetLink;
                }, 150);
            }
        });
    });
});