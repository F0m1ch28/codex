```javascript
document.addEventListener('DOMContentLoaded', () => {
  const banner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  const yearSpan = document.getElementById('currentYear');

  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  if (!banner) return;

  const storedChoice = localStorage.getItem('qnm_cookie_choice');
  if (!storedChoice) {
    banner.classList.add('show');
  }

  const handleChoice = (choice) => {
    localStorage.setItem('qnm_cookie_choice', choice);
    banner.classList.remove('show');
  };

  acceptBtn?.addEventListener('click', () => handleChoice('accepted'));
  declineBtn?.addEventListener('click', () => handleChoice('declined'));
});
```