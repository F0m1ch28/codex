document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menuToggle');
    const primaryNav = document.getElementById('primaryNav');
    const navLinks = document.querySelectorAll('.nav-link');
    const backToTop = document.getElementById('backToTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    const contactForm = document.getElementById('contactForm');
    const formMessage = document.getElementById('formMessage');
    const currentYear = document.getElementById('currentYear');

    // Mobile navigation toggle
    if (menuToggle && primaryNav) {
        menuToggle.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('open');
            menuToggle.classList.toggle('open', isOpen);
            menuToggle.setAttribute('aria-expanded', isOpen);
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (primaryNav && primaryNav.classList.contains('open')) {
                primaryNav.classList.remove('open');
                menuToggle.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // Back to top button
    if (backToTop) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 350) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        });

        backToTop.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    if (cookieBanner && acceptCookies) {
        const consent = localStorage.getItem('nigCookieConsent');
        if (!consent) {
            cookieBanner.classList.add('active');
        }

        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('nigCookieConsent', 'accepted');
            cookieBanner.classList.remove('active');
        });
    }

    // Contact form handling
    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const message = formData.get('message');

            if (!name || !email || !message) {
                formMessage.textContent = 'Please complete the required fields.';
                formMessage.className = 'form-message error';
                return;
            }

            // Simulated submission success
            formMessage.textContent = 'Thank you. Our advisory team will contact you shortly.';
            formMessage.className = 'form-message success';
            contactForm.reset();
        });
    }

    // Footer year
    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }
});