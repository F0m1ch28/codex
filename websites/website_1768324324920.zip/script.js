document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".main-nav");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navMenu.classList.toggle("active");
            document.body.classList.toggle("nav-open");
        });

        navMenu.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navMenu.classList.remove("active");
                document.body.classList.remove("nav-open");
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptAllBtn = document.querySelector(".cookie-accept-all");
    const acceptNecessaryBtn = document.querySelector(".cookie-accept-necessary");
    const declineBtn = document.querySelector(".cookie-decline");
    const cookiePreference = localStorage.getItem("pinna_cookie_preference");

    if (!cookiePreference && cookieBanner) {
        cookieBanner.style.display = "flex";
    }

    const setPreference = (value) => {
        localStorage.setItem("pinna_cookie_preference", value);
        if (cookieBanner) {
            cookieBanner.style.display = "none";
        }
    };

    if (acceptAllBtn) {
        acceptAllBtn.addEventListener("click", () => setPreference("all"));
    }

    if (acceptNecessaryBtn) {
        acceptNecessaryBtn.addEventListener("click", () => setPreference("necessary"));
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", () => setPreference("declined"));
    }
});