document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');
    const siteNav = document.querySelector('.site-nav');

    if (navToggle && navLinks && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            navToggle.classList.toggle('is-active');
            navLinks.classList.toggle('is-open');
            siteNav.classList.toggle('is-open');
        });
    }

    const filterButtons = document.querySelectorAll('[data-filter]');
    const filterCards = document.querySelectorAll('[data-category]');
    if (filterButtons.length && filterCards.length) {
        filterButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const targetFilter = button.dataset.filter;
                filterButtons.forEach((btn) => btn.classList.remove('is-active'));
                button.classList.add('is-active');
                filterCards.forEach((card) => {
                    const categories = card.dataset.category.split(',').map((value) => value.trim());
                    if (targetFilter === 'all' || categories.includes(targetFilter)) {
                        card.classList.remove('is-hidden');
                    } else {
                        card.classList.add('is-hidden');
                    }
                });
            });
        });
    }

    const forumToggles = document.querySelectorAll('.forum-thread-toggle');
    forumToggles.forEach((toggle) => {
        toggle.addEventListener('click', () => {
            const targetId = toggle.getAttribute('aria-controls');
            const target = document.getElementById(targetId);
            const isExpanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', (!isExpanded).toString());
            if (target) {
                target.classList.toggle('is-collapsed');
            }
        });
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedChoice = localStorage.getItem('gcqgCookieChoice');
        if (storedChoice) {
            cookieBanner.classList.add('cookie-banner--hidden');
        } else {
            cookieBanner.classList.remove('cookie-banner--hidden');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-button');
        cookieButtons.forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const choice = button.dataset.choice || 'undecided';
                localStorage.setItem('gcqgCookieChoice', choice);
                cookieBanner.classList.add('cookie-banner--hidden');
                const href = button.getAttribute('href');
                if (href) {
                    window.open(href, '_blank');
                }
            });
        });
    }
});