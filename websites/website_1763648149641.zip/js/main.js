```javascript
document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.getElementById("primary-navigation");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      navToggle.classList.toggle("is-active");
      siteNav.classList.toggle("open");
    });

    siteNav.querySelectorAll(".nav-link").forEach((link) => {
      link.addEventListener("click", () => {
        if (siteNav.classList.contains("open")) {
          siteNav.classList.remove("open");
          navToggle.classList.remove("is-active");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  const pageKey = document.body.dataset.page;
  if (pageKey) {
    document.querySelectorAll(".nav-link").forEach((link) => {
      if (link.dataset.page === pageKey) {
        link.classList.add("active");
      }
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const targetId = anchor.getAttribute("href").substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        event.preventDefault();
        const headerOffset = 88;
        const elementPosition = target.getBoundingClientRect().top + window.scrollY;
        const offsetPosition = elementPosition - headerOffset;

        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    });
  });

  const cookieBanner = document.getElementById("cookie-banner");
  const acceptBtn = document.getElementById("cookie-accept");
  const declineBtn = document.getElementById("cookie-decline");
  const storedConsent = localStorage.getItem("cookieConsent");

  if (cookieBanner) {
    if (!storedConsent) {
      setTimeout(() => {
        cookieBanner.classList.add("show");
      }, 600);
    }

    const handleConsent = (value) => {
      localStorage.setItem("cookieConsent", value);
      cookieBanner.classList.remove("show");
    };

    acceptBtn?.addEventListener("click", () => handleConsent("accepted"));
    declineBtn?.addEventListener("click", () => handleConsent("declined"));
  }

  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const requiredFields = contactForm.querySelectorAll("input[required], textarea[required]");
      let isValid = true;

      requiredFields.forEach((field) => {
        const inputGroup = field.closest(".input-group");
        const errorSpan = inputGroup?.querySelector(".error-message");
        if (errorSpan) errorSpan.textContent = "";
        field.classList.remove("error");

        if (!field.value.trim()) {
          isValid = false;
          field.classList.add("error");
          if (errorSpan) errorSpan.textContent = "This field is required.";
        } else if (field.type === "email") {
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(field.value.trim())) {
            isValid = false;
            field.classList.add("error");
            if (errorSpan) errorSpan.textContent = "Enter a valid email address.";
          }
        }
      });

      const status = contactForm.querySelector(".form-status");
      if (status) status.textContent = "";

      if (isValid) {
        if (status) status.textContent = "Thank you! Our team will reach out within one business day.";
        contactForm.reset();
      }
    });
  }
});
```