import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.column}>
        <div className={styles.brand}>🎨 Сколько вариантов сайта создать?</div>
        <p className={styles.text}>
          Креативное агентство полного цикла. Создаём несколько концепций, чтобы вместе выбрать идеальную и запустить сайт,
          который работает на задачи вашего бизнеса.
        </p>
        <div className={styles.socials} aria-label="Социальные сети">
          <a href="https://behance.net" target="_blank" rel="noopener noreferrer" aria-label="Behance" className={styles.socialIcon}>Bē</a>
          <a href="https://dribbble.com" target="_blank" rel="noopener noreferrer" aria-label="Dribbble" className={styles.socialIcon}>Db</a>
          <a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Telegram" className={styles.socialIcon}>TG</a>
        </div>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Навигация</h3>
        <nav className={styles.nav} aria-label="Быстрые ссылки">
          <Link to="/" className={styles.link}>Главная</Link>
          <Link to="/uslugi" className={styles.link}>Услуги</Link>
          <Link to="/portfolio" className={styles.link}>Портфолио</Link>
          <Link to="/process" className={styles.link}>Процесс</Link>
          <Link to="/o-nas" className={styles.link}>О нас</Link>
          <Link to="/blog" className={styles.link}>Блог</Link>
          <Link to="/kontakty" className={styles.link}>Контакты</Link>
        </nav>
      </div>
      <div className={styles.column}>
        <h3 className={styles.heading}>Контакты</h3>
        <address className={styles.address}>
          <span>г. Москва, ул. Тверская, д. 7</span>
          <a href="tel:+74951234567" className={styles.contact}>+7 (495) 123-45-67</a>
          <a href="mailto:info@skolko-variantov.ru" className={styles.contact}>info@skolko-variantov.ru</a>
        </address>
        <div className={styles.legal}>
          <Link to="/terms">Условия использования</Link>
          <Link to="/privacy">Политика конфиденциальности</Link>
          <Link to="/cookie-policy">Политика cookie</Link>
        </div>
      </div>
    </div>
    <div className={styles.bottom}>
      <span>© {new Date().getFullYear()} «Сколько вариантов сайта создать?»</span>
      <span>Создано с вниманием к деталям</span>
    </div>
  </footer>
);

export default Footer;