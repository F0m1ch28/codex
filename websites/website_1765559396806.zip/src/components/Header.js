import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { path: '/', label: 'Главная' },
  { path: '/uslugi', label: 'Услуги' },
  { path: '/portfolio', label: 'Портфолио' },
  { path: '/process', label: 'Процесс' },
  { path: '/o-nas', label: 'О нас' },
  { path: '/blog', label: 'Блог' },
  { path: '/kontakty', label: 'Контакты' },
];

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          🎨 Сколько вариантов сайта создать?
        </NavLink>
        <button
          type="button"
          className={styles.burger}
          aria-label="Переключить навигацию"
          aria-expanded={isOpen}
          onClick={toggleMenu}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`${styles.nav} ${isOpen ? styles.open : ''}`} aria-label="Главное меню">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => (isActive ? `${styles.link} ${styles.active}` : styles.link)}
              onClick={closeMenu}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;