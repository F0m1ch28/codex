import { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'sv-cookie-consent';

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <strong>Мы используем cookies.</strong>
        <p>
          Они помогают анализировать трафик и улучшать ваш опыт работы с сайтом. Никаких лишних уведомлений — только полезные данные.
        </p>
      </div>
      <button type="button" onClick={handleAccept} className={styles.button}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;