import PageHelmet from '../components/PageHelmet';
import styles from './About.module.css';

const team = [
  {
    name: 'Екатерина Орлова',
    role: 'Креативный директор',
    description: 'Работает с брендами с 2012 года, курирует концепции и визуальные стратегии.',
    image: 'https://picsum.photos/400/400?random=128',
  },
  {
    name: 'Илья Михайлов',
    role: 'Руководитель разработки',
    description: 'Строит архитектуру проектов, отвечает за техническое качество и интеграции.',
    image: 'https://picsum.photos/400/400?random=129',
  },
  {
    name: 'Мария Воронова',
    role: 'Lead UX-исследователь',
    description: 'Погружает команды в запросы пользователей, строит CJM и проводит тесты.',
    image: 'https://picsum.photos/400/400?random=130',
  },
  {
    name: 'Антон Гусев',
    role: 'Проджект-лид',
    description: 'Организует процессы, планирует спринты и следит за прозрачностью этапов.',
    image: 'https://picsum.photos/400/400?random=131',
  },
];

const About = () => (
  <>
    <PageHelmet
      title="О нас — «Сколько вариантов сайта создать?»"
      description="Команда дизайнеров, исследователей и разработчиков, которая создаёт несколько вариантов и вместе с клиентом выбирает лучший."
    />
    <section className={styles.hero}>
      <h1>Команда, которая ищет варианты</h1>
      <p>
        Мы собрали дизайнеров, исследователей и разработчиков, которые любят задавать вопросы и находить нестандартные решения.
        Каждый проект — это коллаборация с командой клиента и совместный выбор лучшего сценария.
      </p>
    </section>

    <section className={styles.values} aria-labelledby="values-title">
      <div className={styles.valuesContent}>
        <h2 id="values-title">Что нас объединяет</h2>
        <p>
          Мы верим в силу вариативности. Анализируем гипотезы, создаём альтернативы и доводим выбранный вариант до блеска.
          Работаем прозрачно, делимся знаниями и остаёмся рядом после релиза.
        </p>
        <ul>
          <li>Прозрачные процессы, чтобы команда клиента понимала каждый этап.</li>
          <li>Системный подход: от исследования до внедрения и роста продукта.</li>
          <li>Внимание к деталям: качество важнее скорости ради скорости.</li>
        </ul>
      </div>
      <img src="https://picsum.photos/900/600?random=132" alt="Команда агентства на стратегической сессии" className={styles.valuesImage} />
    </section>

    <section className={styles.team} aria-labelledby="team-title">
      <h2 id="team-title">Команда практиков</h2>
      <p>
        Мы работали с проектами из EdTech, e-commerce, событийной индустрии, культуры и B2B — знаем нюансы каждой сферы и делимся экспертизой.
      </p>
      <div className={styles.teamGrid}>
        {team.map((member) => (
          <article key={member.name} className={styles.card}>
            <img src={member.image} alt={member.name} />
            <div>
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  </>
);

export default About;