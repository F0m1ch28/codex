import { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Contacts.module.css';

const Contacts = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Укажите имя';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Нужен email для обратной связи';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/u.test(formData.email)) {
      newErrors.email = 'Введите корректный email';
    }
    if (!formData.message.trim()) {
      newErrors.message = 'Расскажите коротко о задаче';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStatus('Сообщение отправлено! Мы свяжемся с вами в течение рабочего дня.');
    setFormData({ name: '', email: '', message: '' });
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <>
      <PageHelmet
        title="Контакты — «Сколько вариантов сайта создать?»"
        description="Свяжитесь с нами: г. Москва, ул. Тверская, д. 7, +7 (495) 123-45-67, info@skolko-variantov.ru."
      />
      <section className={styles.hero}>
        <h1>Контакты</h1>
        <p>Расскажите нам о ваших целях, а мы предложим несколько сценариев, как их воплотить в цифровом продукте.</p>
      </section>

      <section className={styles.grid}>
        <div className={styles.info}>
          <div className={styles.infoBlock}>
            <h2>Офис</h2>
            <p>г. Москва, ул. Тверская, д. 7</p>
          </div>
          <div className={styles.infoBlock}>
            <h2>Телефон</h2>
            <a href="tel:+74951234567">+7 (495) 123-45-67</a>
          </div>
          <div className={styles.infoBlock}>
            <h2>Email</h2>
            <a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a>
          </div>
          <div className={styles.mapWrapper}>
            <iframe
              title="Офис агентства в Москве"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.3524837168166!2d37.60557437667098!3d55.760087273145876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a53fa52b481%3A0x72d8b9df0fa68f74!2z0KLQtdC-0YHRgdC40Y8g0YPQuy4sIDcsIE1vc2NvdywgUnVzc2lh!5e0!3m2!1sru!2sru!4v1700000000000!5m2!1sru!2sru"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>

        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Опишите задачу</h2>
          <p>Мы подготовим несколько вариантов структуры и визуала и обсудим их на встрече.</p>
          <label htmlFor="name">
            Имя
            <input
              id="name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'name-error' : undefined}
            />
            {errors.name && <span id="name-error" className={styles.error}>{errors.name}</span>}
          </label>
          <label htmlFor="email">
            Email
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'email-error' : undefined}
            />
            {errors.email && <span id="email-error" className={styles.error}>{errors.email}</span>}
          </label>
          <label htmlFor="message">
            Задача или идея
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              aria-invalid={Boolean(errors.message)}
              aria-describedby={errors.message ? 'message-error' : undefined}
            />
            {errors.message && <span id="message-error" className={styles.error}>{errors.message}</span>}
          </label>
          <button type="submit">Отправить</button>
          {status && <div className={styles.status} role="status">{status}</div>}
        </form>
      </section>
    </>
  );
};

export default Contacts;