import { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Services.module.css';

const services = [
  {
    id: 'strategy',
    title: 'Цифровая стратегия и аналитика',
    summary: 'Исследуем аудиторию, карты пути, конкурентную среду и формируем гипотезы роста.',
    description: 'Проводим интервью, анализируем метрики, создаём CJM и карту контента. Определяем ключевые точки контакта и строим сценарии, которые ведут пользователя к нужному действию.',
    bullets: ['UX-исследования и глубинные интервью', 'Настройка аналитики и дашбордов', 'Продуктовые гипотезы и бэклог развития'],
    image: 'https://picsum.photos/900/600?random=113',
  },
  {
    id: 'design',
    title: 'Дизайн и прототипирование',
    summary: 'Готовим до четырёх концепций визуального и UX-решения, чтобы вы могли выбрать лучший путь.',
    description: 'Создаем модульную дизайн-систему, интерактивные прототипы и собираем UI-kit. Работаем в Figma, организуем дизайн-ревью и обеспечиваем адаптивность на всех экранах.',
    bullets: ['Интерактивные прототипы и UX-воркшопы', 'UI-kit и гайдлайны для команды', 'Микроанимации и визуальные сценарии'],
    image: 'https://picsum.photos/900/600?random=114',
  },
  {
    id: 'development',
    title: 'Разработка и интеграции',
    summary: 'Собираем производительные сайты и веб-приложения, подключаем CRM, платежи и сторонние сервисы.',
    description: 'Используем современный стек, пишем чистый код, проводим автоматизированное и ручное тестирование. Конфигурируем CMS под задачи проекта.',
    bullets: ['Frontend и backend разработка', 'CI/CD и автоматизация процессов', 'Интеграции с CRM, ERP, платежными системами'],
    image: 'https://picsum.photos/900/600?random=115',
  },
  {
    id: 'support',
    title: 'Поддержка и развитие продукта',
    summary: 'Следим за метриками, обновляем контент, внедряем новые функции и обучаем команду клиента.',
    description: 'На старте создаём roadmap на несколько спринтов вперёд. Проводим аудит, обновляем SEO-структуру, тестируем гипотезы с A/B и проводим регулярные ретро.',
    bullets: ['Контентная поддержка и SEO-оптимизация', 'А/Б тестирование и аналитика', 'Обучение команды и knowledge base'],
    image: 'https://picsum.photos/900/600?random=116',
  },
];

const Services = () => {
  const [activeService, setActiveService] = useState(services[0]);

  return (
    <>
      <PageHelmet
        title="Услуги агентства «Сколько вариантов сайта создать?»"
        description="Комплексный подход: стратегия, UX/UI-дизайн, разработка, интеграции и поддержка цифровых продуктов."
      />
      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <span className={styles.heroTag}>Услуги агентства</span>
          <h1>Комплексные решения: от идеи до роста</h1>
          <p>
            Мы строим работу вокруг выбора. Каждая команда клиента получает несколько вариантов дизайна, прозрачный процесс и поддержку на всех этапах.
          </p>
        </div>
        <img src="https://picsum.photos/1200/800?random=117" alt="Обсуждение концепций на рабочей сессии" className={styles.heroImage} />
      </section>

      <section className={styles.grid}>
        <aside className={styles.menu} aria-label="Список услуг">
          {services.map((service) => (
            <button
              key={service.id}
              type="button"
              className={`${styles.menuItem} ${activeService.id === service.id ? styles.menuItemActive : ''}`}
              onClick={() => setActiveService(service)}
            >
              <span>{service.title}</span>
              <small>{service.summary}</small>
            </button>
          ))}
        </aside>
        <article className={styles.details}>
          <div className={styles.detailsHeader}>
            <h2>{activeService.title}</h2>
            <p>{activeService.description}</p>
          </div>
          <ul className={styles.detailsList}>
            {activeService.bullets.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <div className={styles.detailsImageWrapper}>
            <img src={activeService.image} alt={activeService.title} />
          </div>
        </article>
      </section>
    </>
  );
};

export default Services;