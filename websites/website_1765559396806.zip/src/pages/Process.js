import PageHelmet from '../components/PageHelmet';
import styles from './Process.module.css';

const phases = [
  {
    title: 'Погружение и стратегия',
    description: 'Совместная discovery-сессия, аудиты, анализ бизнес-целей, формирование структуры сайта и сценариев.',
    image: 'https://picsum.photos/900/600?random=124',
    deliverables: ['Discovery-воркшоп', 'Артефакты аудитории', 'Mindmap и структура'],
  },
  {
    title: 'Дизайн-концепции и прототипы',
    description: 'Готовим несколько вариантов визуального языка, а также интерактивные прототипы ключевых сценариев.',
    image: 'https://picsum.photos/900/600?random=125',
    deliverables: ['3-4 варианта визуала', 'Интерактивные прототипы', 'UI-kit и библиотека компонентов'],
  },
  {
    title: 'Разработка и тестирование',
    description: 'Верстаем адаптивные страницы, пишем функционал, подключаем CRM/Nav и проводим тестирование на устройствах.',
    image: 'https://picsum.photos/900/600?random=126',
    deliverables: ['Адаптивный фронтенд', 'Интеграции и автоматизация', 'QA отчет и регрессы'],
  },
  {
    title: 'Запуск и рост',
    description: 'Публикуем сайт, настраиваем аналитику, обучаем команду, формируем бэклог и регулярно обновляем продукт.',
    image: 'https://picsum.photos/900/600?random=127',
    deliverables: ['План релиза', 'Настроенная аналитика', 'Roadmap улучшений'],
  },
];

const Process = () => (
  <>
    <PageHelmet
      title="Процесс работы — «Сколько вариантов сайта создать?»"
      description="Прозрачный процесс: discovery, несколько дизайн-концепций, разработка, запуск и постоянное развитие."
    />
    <section className={styles.hero}>
      <h1>Как мы работаем</h1>
      <p>
        Процесс строим вокруг совместного выбора. На каждом этапе показываем варианты и объясняем, как они влияют на продукт и бизнес-показатели.
      </p>
    </section>

    <section className={styles.timeline}>
      {phases.map((phase) => (
        <article key={phase.title} className={styles.card}>
          <img src={phase.image} alt={phase.title} />
          <div className={styles.content}>
            <h2>{phase.title}</h2>
            <p>{phase.description}</p>
            <ul>
              {phase.deliverables.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default Process;