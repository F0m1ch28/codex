import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';
import styles from './Home.module.css';

const Home = () => {
  const serviceCards = [
    {
      title: 'Стратегический веб-дизайн',
      description: 'Прорабатываем визуальную концепцию и пользовательские сценарии на основе аналитики и ваших целей.',
      image: 'https://picsum.photos/600/400?random=101',
    },
    {
      title: 'Разработка и интеграции',
      description: 'Создаём адаптивные сайты на современных технологиях, подключаем CRM и внешние сервисы.',
      image: 'https://picsum.photos/600/400?random=102',
    },
    {
      title: 'UX-исследования и тестирование',
      description: 'Проводим интервью, CJM и юзер-тесты, чтобы продукт был понятен, быстрый и удобный.',
      image: 'https://picsum.photos/600/400?random=103',
    },
    {
      title: 'Поддержка и развитие',
      description: 'Обновляем контент, развиваем функциональность, анализируем метрики и оптимизируем конверсию.',
      image: 'https://picsum.photos/600/400?random=104',
    },
  ];

  const portfolioPreview = [
    {
      title: 'Экомаркет Flow',
      description: 'Платформа для продаж экотоваров с индивидуальным маршрутом пользователя и калькулятором подборов.',
      image: 'https://picsum.photos/900/600?random=105',
    },
    {
      title: 'Образовательный центр Shift',
      description: 'Лендинг и личный кабинет для студии карьерных консультаций с интеграцией CRM и расписания.',
      image: 'https://picsum.photos/900/600?random=106',
    },
    {
      title: 'Digital-фестиваль Aurora',
      description: 'Мультимедийный сайт с вариативными концептами, промо-роликами и интерактивным расписанием.',
      image: 'https://picsum.photos/900/600?random=107',
    },
  ];

  const timeline = [
    { step: 'Обсуждение', text: 'Погружаемся в контекст, составляем карту болей и задач, фиксируем критерии успеха.' },
    { step: 'Дизайн', text: 'Готовим несколько визуальных направлений, тестируем гипотезы и согласуем финальный стиль.' },
    { step: 'Разработка', text: 'Собираем адаптивный фронт и бэк, подключаем аналитику, тестируем на всех устройствах.' },
    { step: 'Запуск и рост', text: 'Помогаем с релизом, обучаем команду, отслеживаем метрики и развиваем проект.' },
  ];

  const testimonials = [
    {
      quote: 'Команда предложила три разные концепции, и каждая была не похожа на предыдущую. В итоге выбрали микс идей и получили лучший релиз года.',
      author: 'Марина Лебедева',
      role: 'Основательница бренда Flow',
      image: 'https://picsum.photos/200/200?random=108',
    },
    {
      quote: 'Структура, аналитика, дизайн — всё продумано. Понравилось, как ребята объясняют сложные решения и показывают прототипы.',
      author: 'Дмитрий Соколов',
      role: 'Директор по развитию Shift',
      image: 'https://picsum.photos/200/200?random=109',
    },
    {
      quote: 'Удивили вниманием к деталям. Даже мелкие анимации были обсуждены заранее, а запуск прошёл без задержек.',
      author: 'Анна Громова',
      role: 'Продюсер фестиваля Aurora',
      image: 'https://picsum.photos/200/200?random=110',
    },
  ];

  return (
    <>
      <PageHelmet
        title="Креативное агентство «Сколько вариантов сайта создать?» — создаём уникальные веб-проекты"
        description="Проектируем и разрабатываем яркие сайты, готовим несколько концепций и запускаем цифровые продукты, которые отвечают на потребности бизнеса."
      />

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroTag}>Несколько концепций. Один идеальный результат.</span>
          <h1>Создаём сайты, которые работают и вдохновляют</h1>
          <p>
            Мы предлагаем до четырёх вариантов дизайна, тестируем гипотезы и собираем цифровую экосистему, которая растёт вместе с вашими задачами.
          </p>
          <div className={styles.heroActions}>
            <Link to="/kontakty" className={styles.heroPrimary}>Обсудить проект</Link>
            <Link to="/portfolio" className={styles.heroSecondary}>Посмотреть кейсы</Link>
          </div>
        </div>
        <div className={styles.heroCard}>
          <img src="https://picsum.photos/1600/900?random=111" alt="Команда работает над дизайном сайта" />
        </div>
      </section>

      <section className={styles.services} aria-labelledby="services-title">
        <div className={styles.sectionHeader}>
          <h2 id="services-title">Ключевые направления</h2>
          <p>Мы объединяем стратегию, дизайн и технологическую реализацию, чтобы продукт выглядел и ощущался целостно.</p>
        </div>
        <div className={styles.serviceGrid}>
          {serviceCards.map((card) => (
            <article key={card.title} className={styles.serviceCard}>
              <img src={card.image} alt={card.title} />
              <div>
                <h3>{card.title}</h3>
                <p>{card.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.difference} aria-labelledby="difference-title">
        <div className={styles.sectionHeader}>
          <h2 id="difference-title">Наше отличие</h2>
          <p>Каждый проект начинается с вариативности: от стратегической сессии до финальных пикселей мы ищем лучшие решения.</p>
        </div>
        <div className={styles.differenceContent}>
          <ul className={styles.differenceList}>
            <li>
              <span>3–4 концепции</span>
              <p>Готовим несколько визуальных направлений, чтобы найти идеальный баланс между эстетикой и бизнес-целями.</p>
            </li>
            <li>
              <span>Совместная работа</span>
              <p>Прозрачные процессы, открытые бэклоги и еженедельные созвоны — вы всегда в курсе прогресса.</p>
            </li>
            <li>
              <span>Метрики и рост</span>
              <p>После запуска делимся аналитикой, формируем roadmap улучшений и поддерживаем команду на каждом шаге.</p>
            </li>
          </ul>
          <div className={styles.stats}>
            <div>
              <strong>28</strong>
              <span>успешных запусков за последние два года</span>
            </div>
            <div>
              <strong>19%</strong>
              <span>средний рост конверсии после редизайна</span>
            </div>
            <div>
              <strong>5</strong>
              <span>отраслей, в которых мы глубоко разбираемся</span>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.portfolio} aria-labelledby="portfolio-title">
        <div className={styles.sectionHeader}>
          <h2 id="portfolio-title">Избранные работы</h2>
          <p>Каждый проект — это выбор из нескольких вариантов. Мы показываем команду и пользователю разные сценарии, чтобы найти лучший.</p>
        </div>
        <div className={styles.portfolioGrid}>
          {portfolioPreview.map((project) => (
            <article key={project.title} className={styles.portfolioCard}>
              <img src={project.image} alt={project.title} />
              <div className={styles.portfolioContent}>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <Link to="/portfolio" className={styles.portfolioLink}>Подробнее о проекте</Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-title">
        <div className={styles.sectionHeader}>
          <h2 id="process-title">Процесс работы</h2>
          <p>Построенный на прозрачности и сценариях A/B, наш процесс помогает принимать решения вместе с командой клиента.</p>
        </div>
        <div className={styles.timeline}>
          {timeline.map((item) => (
            <div key={item.step} className={styles.timelineItem}>
              <span className={styles.timelineStep}>{item.step}</span>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-title">
        <div className={styles.sectionHeader}>
          <h2 id="testimonials-title">Отзывы партнёров</h2>
          <p>Мы ценим доверие и строим долгосрочные отношения. Вот что говорят команды, с которыми работаем.</p>
        </div>
        <div className={styles.testimonialGrid}>
          {testimonials.map((testimonial) => (
            <figure key={testimonial.author} className={styles.testimonialCard}>
              <blockquote>{testimonial.quote}</blockquote>
              <figcaption>
                <img src={testimonial.image} alt={testimonial.author} />
                <div>
                  <strong>{testimonial.author}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.cta} aria-labelledby="cta-title">
        <div className={styles.ctaContent}>
          <h2 id="cta-title">Давайте обсудим ваш идеальный сценарий</h2>
          <p>
            Подготовим варианты структуры, соберём гипотезы и покажем, как будут выглядеть разные направления дизайна. Начнём с короткого звонка.
          </p>
          <Link to="/kontakty" className={styles.ctaButton}>Назначить встречу</Link>
        </div>
        <div className={styles.ctaIllustration}>
          <img src="https://picsum.photos/800/600?random=112" alt="Командная работа над проектом" />
        </div>
      </section>
    </>
  );
};

export default Home;