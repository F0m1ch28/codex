import PageHelmet from '../components/PageHelmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Как подготовить команду к работе с несколькими концепциями',
    excerpt: 'Делимся чек-листом, который помогает быстро принимать решения и избегать «замыливания» взгляда.',
    image: 'https://picsum.photos/900/600?random=133',
    date: '12 апреля 2024',
    topic: 'Процесс',
  },
  {
    title: 'Вариативность дизайна: зачем показывать 3-4 решения',
    excerpt: 'Рассказываем, как количество вариантов помогает увидеть продукт с разных сторон и выбрать сильный фокус.',
    image: 'https://picsum.photos/900/600?random=134',
    date: '28 марта 2024',
    topic: 'Дизайн',
  },
  {
    title: 'Опыт внедрения A/B-тестов после релиза',
    excerpt: 'Как мы строим дорожную карту улучшений и собираем гипотезы вместе с командой клиента.',
    image: 'https://picsum.photos/900/600?random=135',
    date: '14 марта 2024',
    topic: 'Развитие продукта',
  },
];

const Blog = () => (
  <>
    <PageHelmet
      title="Блог агентства «Сколько вариантов сайта создать?»"
      description="Практические материалы о дизайне, разработке и запуске цифровых продуктов с вариативным подходом."
    />
    <section className={styles.hero}>
      <h1>Блог</h1>
      <p>Истории, исследования и практики, которые помогают строить цифровые продукты осознанно и вариативно.</p>
    </section>

    <section className={styles.grid}>
      {posts.map((post) => (
        <article key={post.title} className={styles.card}>
          <img src={post.image} alt={post.title} />
          <div className={styles.cardContent}>
            <span className={styles.topic}>{post.topic}</span>
            <h2>{post.title}</h2>
            <p>{post.excerpt}</p>
            <span className={styles.date}>{post.date}</span>
          </div>
        </article>
      ))}
    </section>
  </>
);

export default Blog;