import { useState } from 'react';
import PageHelmet from '../components/PageHelmet';
import styles from './Portfolio.module.css';

const projects = [
  {
    title: 'Flow — маркетплейс устойчивых брендов',
    description: 'E-commerce платформа с индивидуальными подборками и модульным UI.',
    category: 'E-commerce',
    image: 'https://picsum.photos/900/600?random=118',
  },
  {
    title: 'Shift — платформа карьерных консультаций',
    description: 'Личный кабинет, расписание и интеграция с онлайн-оплатой.',
    category: 'EdTech',
    image: 'https://picsum.photos/900/600?random=119',
  },
  {
    title: 'Aurora Festival',
    description: 'Сайт-манифест с анимациями и интерактивным расписанием.',
    category: 'Event',
    image: 'https://picsum.photos/900/600?random=120',
  },
  {
    title: 'Nord Analytics',
    description: 'Корпоративный портал с закрытой аналитикой для партнёров.',
    category: 'B2B',
    image: 'https://picsum.photos/900/600?random=121',
  },
  {
    title: 'Musea',
    description: 'Виртуальная галерея с подборками мультимедийных экспонатов.',
    category: 'Culture',
    image: 'https://picsum.photos/900/600?random=122',
  },
  {
    title: 'GreenUp',
    description: 'Сайт городского проекта с картой инициатив и возможностью присоединиться.',
    category: 'Non-profit',
    image: 'https://picsum.photos/900/600?random=123',
  },
];

const categories = ['Все проекты', ...new Set(projects.map((project) => project.category))];

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState('Все проекты');

  const filteredProjects =
    activeCategory === 'Все проекты'
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  return (
    <>
      <PageHelmet
        title="Портфолио агентства «Сколько вариантов сайта создать?»"
        description="Посмотрите проекты, где мы предлагали несколько концепций дизайна и успешно запускали цифровые продукты."
      />
      <section className={styles.hero}>
        <h1>Портфолио</h1>
        <p>
          Мы убеждены, что сильное решение рождается из вариативности. Для каждого проекта команда готовит несколько концепций и тестирует, чтобы выбрать лучшую.
        </p>
      </section>

      <section className={styles.filters} aria-label="Фильтр проектов">
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            className={`${styles.filterButton} ${activeCategory === category ? styles.filterButtonActive : ''}`}
            onClick={() => setActiveCategory(category)}
          >
            {category}
          </button>
        ))}
      </section>

      <section className={styles.grid} aria-live="polite">
        {filteredProjects.map((project) => (
          <article key={project.title} className={styles.card}>
            <img src={project.image} alt={project.title} />
            <div className={styles.cardContent}>
              <span className={styles.cardTag}>{project.category}</span>
              <h2>{project.title}</h2>
              <p>{project.description}</p>
            </div>
          </article>
        ))}
      </section>
    </>
  );
};

export default Portfolio;