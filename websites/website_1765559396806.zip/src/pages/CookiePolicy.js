import PageHelmet from '../components/PageHelmet';
import styles from './Legal.module.css';

const CookiePolicy = () => (
  <>
    <PageHelmet
      title="Политика использования файлов cookie — «Сколько вариантов сайта создать?»"
      description="Узнайте, какие файлы cookie используются на сайте агентства «Сколько вариантов сайта создать?»."
    />
    <section className={styles.wrapper}>
      <h1>Политика использования файлов cookie</h1>
      <p>Последнее обновление: 10 апреля 2024 года</p>

      <h2>1. Что такое cookie</h2>
      <p>
        Cookie — это небольшие файлы, которые сохраняются в браузере для улучшения работы сайта и анализа анонимных действий пользователей.
      </p>

      <h2>2. Какие cookie мы используем</h2>
      <ul>
        <li>Технические cookie — обеспечивают стабильную работу сайта.</li>
        <li>Аналитические cookie — помогают понять, какие страницы и сценарии наиболее востребованы.</li>
      </ul>

      <h2>3. Управление cookie</h2>
      <p>
        Вы можете отключить cookie в настройках браузера. В этом случае некоторые функции сайта могут работать ограниченно.
      </p>

      <h2>4. Контакты</h2>
      <p>
        Если у вас есть вопросы, напишите на <a href="mailto:info@skolko-variantov.ru">info@skolko-variantov.ru</a>.
      </p>
    </section>
  </>
);

export default CookiePolicy;