import React, { useState, useEffect } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  return (
    <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
      <div className="container header-container">
        <Link to="/" className="logo">
          <span className="logo-mark">A</span>
          <span className="logo-text">
            Apex <span>Synergy</span>
          </span>
        </Link>
        <nav className={`nav ${menuOpen ? "nav--open" : ""}`}>
          <NavLink end to="/" className="nav-link">
            Home
          </NavLink>
          <NavLink to="/about" className="nav-link">
            About
          </NavLink>
          <NavLink to="/services" className="nav-link">
            Services
          </NavLink>
          <NavLink to="/contact" className="nav-link">
            Contact
          </NavLink>
          <a href="#insights" className="nav-link nav-link--anchor">
            Insights
          </a>
          <Link to="/contact" className="nav-cta">
            Book a Consultation
          </Link>
        </nav>
        <button
          className={`menu-toggle ${menuOpen ? "menu-toggle--active" : ""}`}
          aria-label="Toggle navigation"
          onClick={() => setMenuOpen((prev) => !prev)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;