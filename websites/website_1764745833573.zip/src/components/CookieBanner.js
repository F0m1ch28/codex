import React, { useState, useEffect } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("apex-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("apex-cookie-consent", "accepted");
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem("apex-cookie-consent", "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner">
      <div className="cookie-content">
        <h4>We value your privacy</h4>
        <p>
          We use essential cookies to enhance your experience, analyze site
          traffic, and deliver tailored content. Manage your preferences anytime
          in our privacy policy.
        </p>
      </div>
      <div className="cookie-actions">
        <button onClick={acceptCookies} className="btn btn-primary">
          Accept
        </button>
        <button onClick={declineCookies} className="btn btn-outline">
          Decline
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;