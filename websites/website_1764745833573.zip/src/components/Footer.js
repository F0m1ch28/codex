import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="logo footer-logo">
            <span className="logo-mark">A</span>
            <span className="logo-text">
              Apex <span>Synergy</span>
            </span>
          </div>
          <p>
            Guiding ambitious organizations through transformative growth with
            strategic insight, digital acceleration, and human-centered design.
          </p>
        </div>
        <div className="footer-col">
          <h4>Company</h4>
          <ul>
            <li>
              <Link to="/about">Who We Are</Link>
            </li>
            <li>
              <Link to="/services">Our Expertise</Link>
            </li>
            <li>
              <a href="#projects">Case Studies</a>
            </li>
            <li>
              <a href="#faq">FAQs</a>
            </li>
          </ul>
        </div>
        <div className="footer-col">
          <h4>Resources</h4>
          <ul>
            <li>
              <a href="#insights">Insights &amp; Reports</a>
            </li>
            <li>
              <a href="#process">Engagement Model</a>
            </li>
            <li>
              <Link to="/contact">Support</Link>
            </li>
            <li>
              <Link to="/contact">Careers</Link>
            </li>
          </ul>
        </div>
        <div className="footer-col">
          <h4>Contact</h4>
          <ul>
            <li>
              <span>hello@apexsynergy.co</span>
            </li>
            <li>
              <span>+1 (415) 555-0128</span>
            </li>
            <li>
              <span>600 Market Street, Suite 2100</span>
            </li>
            <li>
              <span>San Francisco, CA 94105</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; {currentYear} Apex Synergy Consulting. All rights reserved.</p>
        <div className="footer-bottom-links">
          <Link to="/privacy">Privacy Policy</Link>
          <Link to="/terms">Terms of Service</Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;