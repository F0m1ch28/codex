import React, { useState } from "react";

const Contact = () => {
  const initialForm = { name: "", email: "", company: "", message: "" };
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Please enter your full name.";
    if (!formData.company.trim())
      newErrors.company = "Please enter your company.";
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email address.";
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = "Please share at least 10 characters.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitted(true);
    setFormData(initialForm);
  };

  return (
    <div className="page contact-page">
      <section className="page-hero">
        <div className="container">
          <span className="eyebrow">Contact Us</span>
          <h1>Let’s shape the next era of your organization together.</h1>
          <p>
            Share a few details and our advisors will reach out within one
            business day to schedule a discovery session tailored to your goals.
          </p>
        </div>
      </section>

      <section className="contact-content">
        <div className="container contact-grid">
          <div className="contact-info">
            <h2>How we can help</h2>
            <p>
              Whether you’re exploring a strategic initiative or need a partner
              to accelerate delivery, we’re ready to collaborate.
            </p>
            <div className="contact-info-box">
              <h3>Global Offices</h3>
              <ul>
                <li>San Francisco · London · Singapore · São Paulo</li>
              </ul>
            </div>
            <div className="contact-info-box">
              <h3>Contact</h3>
              <ul>
                <li>hello@apexsynergy.co</li>
                <li>+1 (415) 555-0128</li>
              </ul>
            </div>
          </div>

          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <h2>Tell us about your initiative</h2>
            {submitted && (
              <div className="form-success">
                Thank you for reaching out. Our advisory team will connect with
                you shortly.
              </div>
            )}
            <div className="form-group">
              <label htmlFor="name">Full name*</label>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Alex Morgan"
                value={formData.name}
                onChange={handleChange}
              />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Work email*</label>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="alex.morgan@company.com"
                value={formData.email}
                onChange={handleChange}
              />
              {errors.email && (
                <span className="form-error">{errors.email}</span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="company">Company*</label>
              <input
                id="company"
                name="company"
                type="text"
                placeholder="Company name"
                value={formData.company}
                onChange={handleChange}
              />
              {errors.company && (
                <span className="form-error">{errors.company}</span>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="message">Project details*</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Share your objectives, challenges, and timeline..."
                value={formData.message}
                onChange={handleChange}
              />
              {errors.message && (
                <span className="form-error">{errors.message}</span>
              )}
            </div>
            <button type="submit" className="btn btn-primary btn-large">
              Submit Inquiry
            </button>
            <p className="form-footer">
              By submitting this form, you agree to our privacy policy and allow
              Apex Synergy Consulting to contact you regarding your request.
            </p>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;