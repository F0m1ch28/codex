import React from "react";

const About = () => {
  return (
    <div className="page about-page">
      <section className="page-hero">
        <div className="container">
          <span className="eyebrow">Who We Are</span>
          <h1>Blending strategic rigor with human-centered innovation.</h1>
          <p>
            Apex Synergy Consulting is a collective of strategists, designers,
            technologists, and change leaders with a shared mission: help
            ambitious organizations reinvent how they create value. From
            inception, we've focused on building resilient partnerships that
            translate vision into measurable impact.
          </p>
        </div>
      </section>

      <section className="about-overview">
        <div className="container about-grid">
          <div className="about-card">
            <h2>Our mission</h2>
            <p>
              Empower leaders to reimagine their businesses for what’s next,
              while elevating the human experience for customers, employees, and
              communities. We thrive on complexity, distilling clarity and
              confidence in moments of transformation.
            </p>
          </div>
          <div className="about-card">
            <h2>Our approach</h2>
            <p>
              We orchestrate integrated teams and tools around your goals.
              Through sprints, immersive workshops, and data-driven decision
              frameworks, we convert strategy into sustained execution.
            </p>
          </div>
          <div className="about-card">
            <h2>Global reach</h2>
            <p>
              With hubs in San Francisco, London, Singapore, and São Paulo, we
              partner with organizations across five continents, adapting to
              local markets while maintaining global alignment.
            </p>
          </div>
        </div>
      </section>

      <section className="about-image">
        <div className="container about-image-wrapper">
          <img
            src="https://picsum.photos/1200/700?random=113"
            alt="Apex Synergy team collaborating in workshop"
          />
        </div>
      </section>

      <section className="about-timeline">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">Our Journey</span>
              <h2>Elevating organizations through purposeful milestones.</h2>
            </div>
            <p>
              From boutique consultancy to global innovation partner, our
              evolution reflects our clients' growth stories and the measurable
              outcomes we've co-created.
            </p>
          </div>
          <div className="timeline">
            <div className="timeline-item">
              <span className="timeline-year">2013</span>
              <div>
                <h3>Founded with a mission to transform experience.</h3>
                <p>
                  Apex Synergy emerged from a group of Fortune 500 leaders
                  seeking agile, design-led transformation for organizations of
                  all sizes.
                </p>
              </div>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2016</span>
              <div>
                <h3>Expanded digital studio and analytics practice.</h3>
                <p>
                  Integrated data science, product design, and engineering to
                  accelerate digital platform launches and innovation sprints.
                </p>
              </div>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2019</span>
              <div>
                <h3>Global footprint across four strategic hubs.</h3>
                <p>
                  Established regional teams to deliver cross-market strategies
                  and localized deployment without compromising quality.
                </p>
              </div>
            </div>
            <div className="timeline-item">
              <span className="timeline-year">2023</span>
              <div>
                <h3>Launched venture lab and sustainability accelerator.</h3>
                <p>
                  Partnered with clients and startups to build new venture
                  models and ESG initiatives with measurable community impact.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="values">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">Our Values</span>
              <h2>Principles guiding every partnership and decision.</h2>
            </div>
            <p>
              We believe in purpose, transparency, and shared accountability.
              These values underpin how we collaborate and deliver outcomes.
            </p>
          </div>
          <div className="values-grid">
            <div className="value-card">
              <h3>Empathy at the core</h3>
              <p>
                Understanding the needs of people we design for and with helps
                us deliver solutions that create lasting change.
              </p>
            </div>
            <div className="value-card">
              <h3>Impact measured</h3>
              <p>
                We embed analytics and feedback loops to ensure every initiative
                delivers tangible business and human outcomes.
              </p>
            </div>
            <div className="value-card">
              <h3>Adaptive mindset</h3>
              <p>
                Embracing change enables us to pivot quickly, experiment
                responsibly, and help our clients outpace disruption.
              </p>
            </div>
            <div className="value-card">
              <h3>Inclusive collaboration</h3>
              <p>
                Diverse teams unlock more inventive solutions. We create
                environments where every voice contributes to success.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;