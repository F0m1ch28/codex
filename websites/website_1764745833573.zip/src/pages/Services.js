import React from "react";
import { Link } from "react-router-dom";

const Services = () => {
  const serviceDetails = [
    {
      title: "Strategy & Transformation",
      summary:
        "Align leadership, define the future state vision, and craft actionable roadmaps anchored in data-driven insights.",
      bullets: [
        "Enterprise vision & scenario planning",
        "Operating model design",
        "Portfolio prioritization",
        "Change management & enablement",
      ],
    },
    {
      title: "Digital Acceleration",
      summary:
        "Reimagine customer and employee experiences through modern platforms and cross-channel orchestration.",
      bullets: [
        "Product discovery & experience design",
        "Technology architecture & integration",
        "Agile delivery & PMO",
        "Platform modernization",
      ],
    },
    {
      title: "Analytics & AI",
      summary:
        "Unlock intelligence with advanced analytics, AI-driven operations, and responsible data governance.",
      bullets: [
        "Data strategy & governance",
        "Predictive modeling & insights",
        "Automation and AI enablement",
        "Data literacy programs",
      ],
    },
    {
      title: "Innovation Lab",
      summary:
        "Build new ventures, test business models, and accelerate time-to-market with venture design and incubation.",
      bullets: [
        "Innovation sprints & co-creation",
        "Rapid prototyping & validation",
        "Partner ecosystem development",
        "Scaling playbooks & KPI frameworks",
      ],
    },
  ];

  return (
    <div className="page services-page">
      <section className="page-hero">
        <div className="container">
          <span className="eyebrow">Our Services</span>
          <h1>
            Integrated capabilities designed for transformation, growth, and
            operational excellence.
          </h1>
          <p>
            We tailor multi-disciplinary teams around your priorities, blending
            strategy, design, technology, and change to deliver momentum and
            measurable value.
          </p>
        </div>
      </section>

      <section className="services-detail">
        <div className="container">
          {serviceDetails.map((service) => (
            <article className="service-detail-card" key={service.title}>
              <div className="service-detail-header">
                <h2>{service.title}</h2>
                <p>{service.summary}</p>
              </div>
              <ul className="service-detail-list">
                {service.bullets.map((bullet) => (
                  <li key={bullet}>{bullet}</li>
                ))}
              </ul>
              <div className="service-detail-actions">
                <Link to="/contact" className="btn btn-outline">
                  Request capability deck
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="services-cta">
        <div className="container cta-grid">
          <div>
            <h2>Need a custom engagement?</h2>
            <p>
              Our advisors collaborate with your stakeholders to design bespoke
              programs that align resources, timelines, and measurable impact.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn-primary btn-large">
              Connect with our team
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;