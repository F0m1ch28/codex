import React from "react";

const Privacy = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container">
          <span className="eyebrow">Privacy Policy</span>
          <h1>Your privacy matters. Here’s how we handle your data.</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container legal-text">
          <h2>1. Overview</h2>
          <p>
            Apex Synergy Consulting (“we”, “us”, “our”) is committed to
            protecting your privacy. This policy describes how we collect, use,
            share, and safeguard personal information.
          </p>

          <h2>2. Information we collect</h2>
          <p>
            We may collect personal details you provide, such as name, email,
            company, and message content. We also gather usage data through
            analytics tools to improve our services.
          </p>

          <h2>3. How we use information</h2>
          <p>
            Personal data is used to respond to inquiries, deliver services,
            send relevant updates, and meet legal obligations. We do not sell
            personal information.
          </p>

          <h2>4. Cookies and tracking</h2>
          <p>
            We use cookies to enhance user experience and analyze website
            traffic. You can control cookie preferences through your browser
            settings. Essential cookies are required for site functionality.
          </p>

          <h2>5. Data sharing</h2>
          <p>
            We may share information with trusted partners assisting in service
            delivery under confidentiality agreements. We may also disclose data
            when required by law or to protect our rights.
          </p>

          <h2>6. Data security</h2>
          <p>
            We implement administrative, technical, and physical safeguards to
            protect personal information. While no system is completely secure,
            we strive to maintain industry best practices.
          </p>

          <h2>7. International transfers</h2>
          <p>
            Data may be processed in countries where we operate. We maintain
            safeguards to ensure compliance with applicable data protection laws
            in each jurisdiction.
          </p>

          <h2>8. Your rights</h2>
          <p>
            Depending on your location, you may have rights to access, correct,
            delete, or restrict processing of your personal information. Contact
            us to exercise these rights.
          </p>

          <h2>9. Children’s privacy</h2>
          <p>
            Our services are not directed to individuals under 16. We do not
            knowingly collect personal information from children.
          </p>

          <h2>10. Contact</h2>
          <p>
            For questions about this policy or to request data access, contact
            privacy@apexsynergy.co.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Privacy;