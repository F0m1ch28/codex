import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: "Projects Delivered", value: 240, suffix: "+" },
      { label: "Client Satisfaction", value: 98, suffix: "%" },
      { label: "Markets Expanded", value: 36, suffix: "+" },
      { label: "ROI Improvement", value: 230, suffix: "%" },
    ],
    []
  );

  const [animatedValues, setAnimatedValues] = useState(
    statsData.map(() => 0)
  );
  const statsRef = useRef(null);
  const [statsVisible, setStatsVisible] = useState(false);

  useEffect(() => {
    const section = statsRef.current;
    if (!section) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStatsVisible(true);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.4 }
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!statsVisible) return;
    const intervals = statsData.map((stat, index) => {
      const duration = 1800;
      const frameRate = 20;
      const totalFrames = Math.round(duration / frameRate);
      let frame = 0;
      return setInterval(() => {
        frame += 1;
        const progress = Math.min(frame / totalFrames, 1);
        const value = Math.floor(stat.value * progress);
        setAnimatedValues((prev) => {
          const updated = [...prev];
          updated[index] = progress === 1 ? stat.value : value;
          return updated;
        });
        if (progress === 1) {
          clearInterval(intervals[index]);
        }
      }, frameRate);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsVisible, statsData]);

  const services = [
    {
      title: "Strategy & Transformation",
      description:
        "Blueprint future-ready strategies with data-backed market intelligence and leadership alignment.",
      icon: "🧭",
    },
    {
      title: "Digital Acceleration",
      description:
        "Modernize products and platforms with human-centered design, rapid prototyping, and agile delivery.",
      icon: "⚡",
    },
    {
      title: "Operational Excellence",
      description:
        "Re-engineer processes, optimize technology investments, and build high-performing ecosystems.",
      icon: "📈",
    },
    {
      title: "Innovation Lab",
      description:
        "Launch new ventures faster with venture design sprints, experimentation, and scalable growth models.",
      icon: "🚀",
    },
  ];

  const processSteps = [
    {
      step: "01",
      title: "Discover",
      description:
        "In-depth stakeholder interviews, data diagnostics, and vision alignment workshops.",
    },
    {
      step: "02",
      title: "Design",
      description:
        "Roadmap creation, opportunity prioritization, and rapid experience prototyping.",
    },
    {
      step: "03",
      title: "Deliver",
      description:
        "Integrated execution across technology, change management, and capability building.",
    },
    {
      step: "04",
      title: "Scale",
      description:
        "Measure impact, embed continuous improvement, and expand success across teams and regions.",
    },
  ];

  const testimonials = [
    {
      quote:
        "Apex Synergy guided our global digital transformation. Their partnership mindset and execution rigor accelerated our roadmap by 18 months.",
      name: "Allison Grant",
      role: "Chief Digital Officer, Horizon Retail Group",
    },
    {
      quote:
        "The team delivered measurable ROI with a seamless process. We unlocked new markets and a 220% increase in pipeline in under a year.",
      name: "Luis Martínez",
      role: "VP Strategy, NovaTech Industries",
    },
    {
      quote:
        "They helped us reimagine customer journeys and re-platform our core services. Employee adoption soared and NPS increased to 74.",
      name: "Priya Desai",
      role: "Head of Experience, Cirrus Financial",
    },
  ];

  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const teamMembers = [
    {
      name: "Jordan Blake",
      role: "Managing Partner",
      image: "https://picsum.photos/400/400?random=103",
      bio: "Former Fortune 100 strategist scaling cross-functional innovation.",
    },
    {
      name: "Camila Chen",
      role: "Director of Digital",
      image: "https://picsum.photos/400/400?random=104",
      bio: "Leads digital product reinvention and experience design programs.",
    },
    {
      name: "Elias Porter",
      role: "Head of Analytics",
      image: "https://picsum.photos/400/400?random=105",
      bio: "Data science leader specializing in predictive growth modeling.",
    },
    {
      name: "Renee Patel",
      role: "Transformation Lead",
      image: "https://picsum.photos/400/400?random=106",
      bio: "Drives change enablement and new ways of working at scale.",
    },
  ];

  const projects = [
    {
      id: 1,
      title: "Global Commerce Replatform",
      category: "Digital",
      image: "https://picsum.photos/1200/800?random=107",
    },
    {
      id: 2,
      title: "Smart Operations Dashboard",
      category: "Operations",
      image: "https://picsum.photos/1200/800?random=108",
    },
    {
      id: 3,
      title: "Customer Journey Redesign",
      category: "Experience",
      image: "https://picsum.photos/1200/800?random=109",
    },
    {
      id: 4,
      title: "Clean Energy Market Entry",
      category: "Strategy",
      image: "https://picsum.photos/1200/800?random=110",
    },
    {
      id: 5,
      title: "AI-Powered Service Platform",
      category: "Digital",
      image: "https://picsum.photos/1200/800?random=111",
    },
    {
      id: 6,
      title: "Supply Chain Resilience",
      category: "Operations",
      image: "https://picsum.photos/1200/800?random=112",
    },
  ];

  const projectCategories = ["All", "Strategy", "Digital", "Operations", "Experience"];
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects =
    activeCategory === "All"
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const faqItems = [
    {
      question: "Which industries do you specialize in?",
      answer:
        "We work across financial services, retail, technology, healthcare, energy, and manufacturing. Our scalable methodology adapts to the unique needs of each sector.",
    },
    {
      question: "How quickly can a project get started?",
      answer:
        "Our discovery sprint can begin within two weeks. We align stakeholders, define success metrics, and build a delivery plan ready for execution in 30 days.",
    },
    {
      question: "Do you provide ongoing support?",
      answer:
        "Yes. We embed enablement programs, governance frameworks, and data tracking to ensure sustainable results with options for long-term partnership.",
    },
    {
      question: "What is your pricing model?",
      answer:
        "Engagements are scoped based on outcomes and team composition. We offer fixed-fee diagnostic sprints, retainer-based partnerships, and co-invested ventures.",
    },
  ];
  const [activeFaq, setActiveFaq] = useState(null);

  const blogPosts = [
    {
      title: "Designing Resilient Enterprises for Market Disruption",
      date: "April 12, 2024",
      excerpt:
        "Discover a step-by-step framework to build resilience into your operating model and unlock adaptive growth.",
      link: "#insights",
    },
    {
      title: "The 2024 Digital Leadership Playbook",
      date: "March 28, 2024",
      excerpt:
        "We outline the capabilities, mindsets, and metrics winning digital leaders are prioritizing this year.",
      link: "#insights",
    },
    {
      title: "Operational Excellence in a Hybrid Future",
      date: "March 9, 2024",
      excerpt:
        "See how global organizations are orchestrating data, talent, and automation for continuous performance.",
      link: "#insights",
    },
  ];

  return (
    <div className="home-page">
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="eyebrow">Strategic Innovation Partners</span>
            <h1>
              Build resilient, future-ready enterprises with Apex Synergy
              Consulting.
            </h1>
            <p>
              We align leadership, technology, and culture to unlock measurable
              growth. From transformation strategy to scaled delivery, our teams
              design human-centered solutions that outpace disruption.
            </p>
            <div className="hero-actions">
              <Link to="/contact" className="btn btn-primary">
                Start a Project
              </Link>
              <a href="#services" className="btn btn-outline">
                Explore Services
              </a>
            </div>
            <div className="hero-stats">
              <div>
                <strong>11+</strong>
                <span>Years orchestrating transformation</span>
              </div>
              <div>
                <strong>Global</strong>
                <span>Partner network across 5 continents</span>
              </div>
            </div>
          </div>
          <div className="hero-media">
            <div className="hero-image">
              <img
                src="https://picsum.photos/1600/900?random=101"
                alt="Business leaders collaborating on strategy"
              />
              <div className="hero-badge">
                <span>Certified</span>
                <strong>Strategy &amp; Innovation Advisors</strong>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stats" ref={statsRef}>
        <div className="container stats-grid">
          {statsData.map((stat, index) => (
            <div className="stat-card" key={stat.label}>
              <span className="stat-value">
                {animatedValues[index]}
                {stat.suffix}
              </span>
              <span className="stat-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="services" id="services">
        <div className="container section-header">
          <div>
            <span className="eyebrow">Our Expertise</span>
            <h2>Delivering clarity, momentum, and measurable outcomes.</h2>
          </div>
          <p>
            We bring together strategists, designers, technologists, and change
            leaders to orchestrate end-to-end transformation tailored to your
            ambition.
          </p>
        </div>
        <div className="container services-grid">
          {services.map((service) => (
            <div className="service-card" key={service.title}>
              <span className="service-icon" aria-hidden="true">
                {service.icon}
              </span>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <Link to="/services" className="service-link">
                Learn more
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="process" id="process">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">Engagement Model</span>
              <h2>Collaborative workflows architected for velocity.</h2>
            </div>
            <p>
              Our methodology is grounded in transparency, co-creation, and
              continuous measurement. We integrate your teams every step of the
              way to sustain success.
            </p>
          </div>
          <div className="process-timeline">
            {processSteps.map((step) => (
              <div className="process-step" key={step.step}>
                <span className="process-number">{step.step}</span>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="testimonials">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">Client Stories</span>
              <h2>Trusted to deliver impact where it matters most.</h2>
            </div>
            <p>
              Our partnerships are anchored in measurable outcomes and lasting
              capability-building. Hear what executives say about working with
              Apex Synergy.
            </p>
          </div>
          <div className="testimonial-slider">
            {testimonials.map((testimonial, index) => (
              <article
                className={`testimonial ${
                  index === activeTestimonial ? "testimonial--active" : ""
                }`}
                key={testimonial.name}
              >
                <p className="testimonial-quote">“{testimonial.quote}”</p>
                <div className="testimonial-meta">
                  <span className="testimonial-name">{testimonial.name}</span>
                  <span className="testimonial-role">{testimonial.role}</span>
                </div>
              </article>
            ))}
            <div className="testimonial-controls">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`dot ${
                    index === activeTestimonial ? "dot--active" : ""
                  }`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`View testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="team" id="team">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">Leadership Team</span>
              <h2>Seasoned advisors who thrive on complex challenges.</h2>
            </div>
            <p>
              We combine industry depth with creative problem solving to guide
              organizations through transformation with confidence and agility.
            </p>
          </div>
          <div className="team-grid">
            {teamMembers.map((member) => (
              <div className="team-card" key={member.name}>
                <div className="team-image">
                  <img src={member.image} alt={`${member.name} portrait`} />
                </div>
                <div className="team-info">
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                  <a href="#contact" className="team-link">
                    Connect
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="projects" id="projects">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">Case Studies</span>
              <h2>Bringing bold ideas to life with cross-functional delivery.</h2>
            </div>
            <p>
              Explore highlights from our portfolio, spanning digital product
              launches, operating model redesigns, and global market expansion.
            </p>
          </div>
          <div className="project-filters">
            {projectCategories.map((category) => (
              <button
                key={category}
                className={`filter-button ${
                  activeCategory === category ? "filter-button--active" : ""
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="project-grid">
            {filteredProjects.map((project) => (
              <article className="project-card" key={project.id}>
                <div className="project-image">
                  <img src={project.image} alt={`${project.title} showcase`} />
                </div>
                <div className="project-content">
                  <span className="project-category">{project.category}</span>
                  <h3>{project.title}</h3>
                  <Link to="/services" className="project-link">
                    View details
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="insights" id="insights">
        <div className="container">
          <div className="section-header">
            <div>
              <span className="eyebrow">Latest Insights</span>
              <h2>Actionable intelligence for forward-thinking leaders.</h2>
            </div>
            <p>
              Stay ahead with deep dives on strategy, digital trends, operating
              models, and innovation playbooks from our subject-matter experts.
            </p>
          </div>
          <div className="blog-grid">
            {blogPosts.map((post) => (
              <article className="blog-card" key={post.title}>
                <span className="blog-date">{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <a href={post.link} className="blog-link">
                  Continue reading
                </a>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="faq" id="faq">
        <div className="container">
          <div className="faq-grid">
            <div className="faq-intro">
              <span className="eyebrow">FAQ</span>
              <h2>Answers to common questions about working with us.</h2>
              <p>
                Need more context? Reach out to our advisory team for tailored
                guidance and a roadmap designed for your goals.
              </p>
              <Link to="/contact" className="btn btn-primary">
                Talk to an Advisor
              </Link>
            </div>
            <div className="faq-list">
              {faqItems.map((item, index) => (
                <div
                  className={`faq-item ${
                    activeFaq === index ? "faq-item--open" : ""
                  }`}
                  key={item.question}
                >
                  <button
                    className="faq-question"
                    onClick={() =>
                      setActiveFaq((prev) => (prev === index ? null : index))
                    }
                  >
                    {item.question}
                    <span>{activeFaq === index ? "−" : "+"}</span>
                  </button>
                  <div className="faq-answer">
                    <p>{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container cta-grid">
          <div>
            <h2>Ready to architect your next wave of growth?</h2>
            <p>
              Let's co-create a roadmap that transforms complexity into
              competitive advantage. Speak with our advisors about your
              opportunity and we will curate a strategy session.
            </p>
          </div>
          <div className="cta-actions">
            <Link to="/contact" className="btn btn-primary btn-large">
              Schedule a Strategy Call
            </Link>
            <a href="#services" className="btn btn-outline btn-large">
              View Capabilities
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;