import React from "react";

const Terms = () => {
  return (
    <div className="page legal-page">
      <section className="page-hero">
        <div className="container">
          <span className="eyebrow">Terms of Service</span>
          <h1>Engagement terms governing your use of Apex Synergy Consulting.</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="legal-content">
        <div className="container legal-text">
          <h2>1. Acceptance of terms</h2>
          <p>
            By accessing or using the services of Apex Synergy Consulting (“we”,
            “us”, “our”), you agree to be bound by these Terms of Service.
            Please read them carefully. If you do not agree with any part of the
            terms, you may not engage with our services.
          </p>

          <h2>2. Services</h2>
          <p>
            We provide strategic consulting, digital transformation, innovation,
            and related advisory services. Scope, deliverables, and timelines
            will be defined within a mutually executed statement of work (SOW)
            or master services agreement (MSA).
          </p>

          <h2>3. Client responsibilities</h2>
          <p>
            Clients agree to provide accurate information, timely feedback, and
            necessary resources to enable the delivery of services. Delays
            resulting from lack of access or information may impact timelines
            and fees.
          </p>

          <h2>4. Fees and payment</h2>
          <p>
            Fees are detailed in the relevant SOW or MSA. Unless otherwise
            stated, invoices are due within 30 days. Late payments may accrue
            interest at 1.5% per month or the maximum allowed by law.
          </p>

          <h2>5. Confidentiality</h2>
          <p>
            Both parties agree to protect confidential information disclosed
            during the engagement and to use it solely for the purpose of
            fulfilling their obligations. Confidentiality obligations survive
            termination of the agreement.
          </p>

          <h2>6. Intellectual property</h2>
          <p>
            Pre-existing intellectual property remains the property of the
            originating party. Unless otherwise specified, deliverables created
            by us during the engagement are assigned to the client upon receipt
            of full payment.
          </p>

          <h2>7. Limitation of liability</h2>
          <p>
            To the maximum extent permitted by law, neither party shall be liable
            for indirect, incidental, or consequential damages. Our aggregate
            liability shall not exceed the fees paid by the client in the six
            months preceding the claim.
          </p>

          <h2>8. Termination</h2>
          <p>
            Either party may terminate the engagement with written notice subject
            to the terms in the applicable SOW or MSA. Fees for work completed up
            to the termination date remain payable by the client.
          </p>

          <h2>9. Governing law</h2>
          <p>
            These terms are governed by the laws of the State of California,
            without regard to its conflict of law principles.
          </p>

          <h2>10. Contact</h2>
          <p>
            For questions regarding these Terms of Service, contact us at
            legal@apexsynergy.co.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Terms;