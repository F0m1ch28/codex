document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = navToggle.classList.toggle('nav-open');
      primaryNav.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navToggle.classList.remove('nav-open');
          primaryNav.classList.remove('nav-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const yearSpans = document.querySelectorAll('.current-year');
  const currentYear = new Date().getFullYear();
  yearSpans.forEach(span => {
    span.textContent = currentYear;
  });

  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll('.reveal').forEach(section => observer.observe(section));

  const toast = document.createElement('div');
  toast.className = 'toast-message';
  toast.setAttribute('role', 'status');
  document.body.appendChild(toast);

  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const message = form.dataset.toast || 'Bedankt voor uw bericht / Thank you for your message.';
      toast.textContent = message;
      toast.classList.add('show');
      setTimeout(() => {
        toast.classList.remove('show');
      }, 2000);
      setTimeout(() => {
        window.location.href = form.getAttribute('action');
      }, 1200);
    });
  });

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const storedChoice = localStorage.getItem('mm8w8-cookie-choice');
    if (storedChoice) {
      cookieBanner.classList.add('hidden');
    } else {
      cookieBanner.querySelectorAll('button[data-choice]').forEach(button => {
        button.addEventListener('click', () => {
          const choice = button.dataset.choice;
          localStorage.setItem('mm8w8-cookie-choice', choice);
          cookieBanner.classList.add('hide');
          setTimeout(() => cookieBanner.classList.add('hidden'), 450);
        });
      });
    }
  }
});