document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navLinks = document.querySelector(".nav-links");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            navLinks.classList.toggle("open");
        });

        navLinks.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.classList.remove("active");
                navLinks.classList.remove("open");
            });
        });
    }

    const yearSpan = document.getElementById("currentYear");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    if (cookieBanner) {
        const accepted = localStorage.getItem("vrhCookieChoice");
        if (!accepted) {
            cookieBanner.classList.add("active");
        }

        const acceptBtn = cookieBanner.querySelector(".cookie-accept");
        const declineBtn = cookieBanner.querySelector(".cookie-decline");

        if (acceptBtn) {
            acceptBtn.addEventListener("click", () => {
                localStorage.setItem("vrhCookieChoice", "accepted");
                cookieBanner.classList.remove("active");
            });
        }

        if (declineBtn) {
            declineBtn.addEventListener("click", () => {
                localStorage.setItem("vrhCookieChoice", "declined");
                cookieBanner.classList.remove("active");
            });
        }
    }

    const postsContainer = document.querySelector("[data-posts]");
    if (postsContainer) {
        const searchInput = document.querySelector("[data-search]");
        const filterButtons = document.querySelectorAll("[data-filter]");
        const postCards = postsContainer.querySelectorAll("[data-category]");

        const applyFilters = () => {
            const query = searchInput ? searchInput.value.toLowerCase().trim() : "";
            const activeFilter = document.querySelector("[data-filter].active");
            const category = activeFilter ? activeFilter.getAttribute("data-filter") : "toate";

            postCards.forEach(card => {
                const cardCategory = card.getAttribute("data-category");
                const title = card.querySelector(".card-title").textContent.toLowerCase();
                const excerpt = card.querySelector(".card-text").textContent.toLowerCase();

                const matchesCategory = category === "toate" || cardCategory === category;
                const matchesSearch = title.includes(query) || excerpt.includes(query);

                if (matchesCategory && matchesSearch) {
                    card.style.display = "";
                } else {
                    card.style.display = "none";
                }
            });
        };

        filterButtons.forEach(btn => {
            btn.addEventListener("click", () => {
                filterButtons.forEach(button => button.classList.remove("active"));
                btn.classList.add("active");
                applyFilters();
            });
        });

        if (searchInput) {
            searchInput.addEventListener("input", applyFilters);
        }
    }
});