(function () {
    var banner = document.getElementById("cookieBanner");
    var acceptBtn = document.getElementById("acceptCookies");
    var declineBtn = document.getElementById("declineCookies");
    var storageKey = "guardvxsr_cookie_consent";

    function setConsent(value) {
        if (typeof window.localStorage !== "undefined") {
            localStorage.setItem(storageKey, value);
        }
    }

    function getConsent() {
        if (typeof window.localStorage !== "undefined") {
            return localStorage.getItem(storageKey);
        }
        return null;
    }

    function hideBanner() {
        if (banner) {
            banner.classList.remove("active");
        }
    }

    function showBanner() {
        if (banner && !banner.classList.contains("active")) {
            banner.classList.add("active");
        }
    }

    if (!getConsent()) {
        showBanner();
    }

    if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
            setConsent("accepted");
            hideBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", function (event) {
            event.preventDefault();
            setConsent("declined");
            hideBanner();
            window.location.href = declineBtn.getAttribute("href");
        });
    }
})();