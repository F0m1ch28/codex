document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('.main-nav');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookies = document.getElementById('acceptCookies');
    const declineCookies = document.getElementById('declineCookies');
    const currentYearSpan = document.getElementById('current-year');

    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

    if (menuToggle && nav) {
        menuToggle.addEventListener('click', () => {
            const expanded = menuToggle.getAttribute('aria-expanded') === 'true' || false;
            menuToggle.setAttribute('aria-expanded', !expanded);
            nav.classList.toggle('open');
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                menuToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    window.addEventListener('scroll', () => {
        if (window.scrollY > 200) {
            scrollBtn.classList.add('visible');
        } else {
            scrollBtn.classList.remove('visible');
        }
    });

    scrollBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const consentKey = 'novateriumCookieConsent';
    const consent = localStorage.getItem(consentKey);

    if (!consent && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    const setConsent = (value) => {
        localStorage.setItem(consentKey, value);
        cookieBanner.classList.remove('active');
    };

    if (acceptCookies) {
        acceptCookies.addEventListener('click', () => {
            setConsent('accepted');
        });
    }

    if (declineCookies) {
        declineCookies.addEventListener('click', () => {
            setConsent('declined');
        });
    }
});