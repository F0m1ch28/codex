document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.getElementById('site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');
    const scrollTopBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const contactForm = document.getElementById('contact-form');
    const formStatus = document.getElementById('form-status');
    const yearSpan = document.getElementById('current-year');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            siteNav.classList.toggle('is-open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', event => {
            const href = link.getAttribute('href');
            if (href && href.startsWith('#')) {
                event.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                } else {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                }
                if (siteNav && siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                }
                if (navToggle) {
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            }
        });
    });

    const toggleScrollTop = () => {
        if (window.scrollY > 400) {
            scrollTopBtn?.classList.add('show');
        } else {
            scrollTopBtn?.classList.remove('show');
        }
    };

    window.addEventListener('scroll', toggleScrollTop);
    toggleScrollTop();

    scrollTopBtn?.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const cookieKey = 'qevanelryxa-cookie-consent';

    if (cookieBanner && acceptCookiesBtn) {
        const consent = localStorage.getItem(cookieKey);
        if (!consent) {
            cookieBanner.classList.add('show');
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem(cookieKey, 'accepted');
            cookieBanner.classList.remove('show');
        });
    }

    if (contactForm && formStatus) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            formStatus.textContent = 'Vielen Dank für die Nachricht. Wir melden uns, sobald wir sie gelesen haben.';
            contactForm.reset();
        });
    }
});