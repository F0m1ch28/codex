document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            siteNav.classList.toggle("nav-open");
            const expanded = navToggle.classList.contains("active");
            navToggle.setAttribute("aria-expanded", expanded);
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieActions = document.querySelectorAll(".cookie-action");
    const consentKey = "unsylldvfeConsent";

    const hideBanner = () => {
        if (cookieBanner) {
            cookieBanner.classList.remove("active");
        }
    };

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            setTimeout(() => cookieBanner.classList.add("active"), 600);
        }
    }

    if (cookieActions.length) {
        cookieActions.forEach((link) => {
            link.addEventListener("click", (event) => {
                event.preventDefault();
                const consentValue = link.dataset.consent || "unknown";
                localStorage.setItem(consentKey, consentValue);
                hideBanner();
                window.location.href = link.getAttribute("href");
            });
        });
    }
});