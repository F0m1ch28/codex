document.addEventListener('DOMContentLoaded', () => {
  const currentYearEl = document.getElementById('current-year');
  if (currentYearEl) {
    currentYearEl.textContent = new Date().getFullYear();
  }

  // Mobile navigation toggle
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');

  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const isOpen = navList.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    navList.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (navList.classList.contains('is-open')) {
          navList.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  // Cookie banner
  const cookieBanner = document.querySelector('.cookie-banner');
  if (!cookieBanner) return;

  const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
  const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');

  const setBannerVisibility = (visible) => {
    if (visible) {
      cookieBanner.classList.add('is-visible');
    } else {
      cookieBanner.classList.remove('is-visible');
    }
  };

  const getConsent = () => {
    try {
      return localStorage.getItem('ndc-cookie-consent');
    } catch (error) {
      return null;
    }
  };

  const setConsent = (value) => {
    try {
      localStorage.setItem('ndc-cookie-consent', value);
    } catch (error) {
      // no-op if storage unavailable
    }
  };

  if (!getConsent()) {
    setBannerVisibility(true);
  }

  acceptBtn?.addEventListener('click', () => {
    setConsent('accepted');
    setBannerVisibility(false);
  });

  declineBtn?.addEventListener('click', () => {
    setConsent('declined');
    setBannerVisibility(false);
  });
});