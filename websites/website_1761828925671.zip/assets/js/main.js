document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".site-nav a");
  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptCookiesBtn = document.querySelector("#acceptCookies");
  const contactForm = document.querySelector("#contactForm");
  const sections = document.querySelectorAll(".fade-section");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true" || false;
      navToggle.setAttribute("aria-expanded", !expanded);
      nav.classList.toggle("open");
    });

    navLinks.forEach(link => {
      link.addEventListener("click", () => {
        if (nav.classList.contains("open")) {
          nav.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
        }
      });
    });
  }

  if (sections.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });

    sections.forEach(section => observer.observe(section));
  }

  if (cookieBanner && acceptCookiesBtn) {
    const cookiesAccepted = localStorage.getItem("petroitaliaCookiesAccepted");
    if (!cookiesAccepted) {
      cookieBanner.classList.add("active");
    }

    acceptCookiesBtn.addEventListener("click", () => {
      localStorage.setItem("petroitaliaCookiesAccepted", "true");
      cookieBanner.classList.remove("active");
    });
  }

  if (contactForm) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const response = contactForm.querySelector(".form-response");
      const formData = new FormData(contactForm);
      const name = formData.get("name")?.trim();
      const email = formData.get("email")?.trim();
      const message = formData.get("message")?.trim();
      const privacy = contactForm.querySelector("#privacy").checked;

      if (!name || !email || !message || !privacy) {
        response.textContent = "Compila tutti i campi obbligatori e accetta l'informativa.";
        response.style.color = "#f0b37e";
        return;
      }

      response.textContent = "Grazie! Il tuo messaggio è stato inviato. Ti ricontatteremo al più presto.";
      response.style.color = "#7cd67c";
      contactForm.reset();
    });
  }
});