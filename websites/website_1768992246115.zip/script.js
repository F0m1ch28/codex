document.addEventListener('DOMContentLoaded', function () {
  var navToggle = document.querySelector('.nav-toggle');
  var navMenu = document.querySelector('.primary-nav');
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      var expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navToggle.classList.toggle('nav-open');
      navMenu.classList.toggle('nav-open');
    });
    var navLinks = navMenu.querySelectorAll('a');
    navLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        navToggle.classList.remove('nav-open');
        navToggle.setAttribute('aria-expanded', 'false');
        navMenu.classList.remove('nav-open');
      });
    });
  }
  var cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    var storedChoice = localStorage.getItem('afl_cookie_choice');
    if (storedChoice) {
      cookieBanner.classList.add('hidden');
    }
    var acceptBtn = cookieBanner.querySelector('.cookie-accept');
    var declineBtn = cookieBanner.querySelector('.cookie-decline');
    var handleChoice = function (value) {
      localStorage.setItem('afl_cookie_choice', value);
      cookieBanner.classList.add('hidden');
    };
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        handleChoice('accepted');
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        handleChoice('declined');
      });
    }
  }
});