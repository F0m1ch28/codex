import React from 'react';
import PageHelmet from '../components/PageHelmet';

const AboutPage = () => (
  <>
    <PageHelmet
      title="Sobre GridFlow Energy Systems | Ingeniería de Redes Inteligentes"
      description="Conoce la misión, visión y equipo de GridFlow Energy Systems, especialistas en redes inteligentes, balanceo de red y analítica energética en España."
      keywords="GridFlow, redes inteligentes, plataforma energética, misión, visión, equipo, ingeniería de red, analítica energética"
    />
    <section className="page-hero">
      <div className="container narrow">
        <h1>Sobre GridFlow Energy Systems</h1>
        <p>
          Aceleramos la transformación digital de la infraestructura eléctrica con un enfoque integral que combina ingeniería, analítica avanzada y colaboración sectorial.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container two-columns">
        <div>
          <h2>Misión</h2>
          <p>
            Nuestra misión es suministrar herramientas inteligentes que permitan a operadores y gestores energéticos comprender, anticipar y optimizar cada componente de la red eléctrica. Buscamos facilitar un sistema eléctrico seguro, flexible y capaz de absorber el crecimiento renovable.
          </p>
        </div>
        <div>
          <h2>Visión</h2>
          <p>
            Aspiramos a que la red eléctrica europea funcione como un organismo digital interconectado: transparente, resiliente y alineado con objetivos climáticos. GridFlow impulsa esta visión mediante plataformas abiertas, interoperables y adaptadas al contexto español.
          </p>
        </div>
      </div>
    </section>

    <section className="section grey">
      <div className="container">
        <div className="section-header">
          <h2>Valores que guían nuestro trabajo</h2>
        </div>
        <div className="values-grid">
          <div className="value-card">
            <h3>Rigor técnico</h3>
            <p>Metodologías basadas en estándares europeos y colaboración con universidades e institutos tecnológicos.</p>
          </div>
          <div className="value-card">
            <h3>Transparencia</h3>
            <p>Datos trazables, paneles claros y comunicación continua con los equipos de operación y planificación.</p>
          </div>
          <div className="value-card">
            <h3>Sostenibilidad</h3>
            <p>Priorizamos la integración de energías limpias, eficiencia energética y reducción de pérdidas en red.</p>
          </div>
          <div className="value-card">
            <h3>Co-creación</h3>
            <p>Programas piloto con distribuidoras, plataformas de innovación abierta y comunidades energéticas.</p>
          </div>
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container story-grid">
        <div>
          <h2>Historia</h2>
          <p>
            GridFlow nació en Madrid como respuesta a la creciente necesidad de coordinar recursos renovables distribuidos con una red eléctrica compleja y exigente. Nuestro equipo fundacional, compuesto por ingenieros eléctricos, científicos de datos y especialistas en ciberseguridad, apostó por un enfoque modular capaz de integrarse con sistemas existentes.
          </p>
          <p>
            Desde entonces, hemos impulsado proyectos pioneros en España, Portugal y el sur de Francia, colaborando con utilities, operadores de microrredes y consorcios industriales. La experiencia acumulada alimenta nuestro roadmap tecnológico y fortalece la comunidad de partners.
          </p>
        </div>
        <div>
          <img src="https://picsum.photos/800/600?random=32" alt="Equipo de GridFlow colaborando en un centro de control de red" loading="lazy" />
        </div>
      </div>
    </section>

    <section className="section grey">
      <div className="container">
        <div className="section-header">
          <h2>Equipo directivo</h2>
          <p>Liderazgo técnico y estratégico con amplia trayectoria en redes inteligentes.</p>
        </div>
        <div className="team-grid">
          {[
            {
              name: 'Isabel Rubio',
              role: 'Consejera Delegada',
              bio: 'Ingeniera industrial con 18 años de experiencia en modernización de redes y proyectos europeos de smart grid.',
              image: 'https://picsum.photos/400/400?random=33'
            },
            {
              name: 'Miguel Herrera',
              role: 'Director de Tecnología',
              bio: 'Especialista en plataformas de tiempo real, IoT industrial y analítica avanzada aplicada a energía.',
              image: 'https://picsum.photos/400/400?random=34'
            },
            {
              name: 'Laura Crespo',
              role: 'Directora de Operaciones',
              bio: 'Coordina despliegues multinodo, gestión del cambio y soporte operativo a centros de control.',
              image: 'https://picsum.photos/400/400?random=35'
            }
          ].map(member => (
            <article key={member.name} className="team-card">
              <img src={member.image} alt={`Retrato de ${member.name}`} loading="lazy" />
              <h3>{member.name}</h3>
              <p className="team-role">{member.role}</p>
              <p>{member.bio}</p>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container narrow">
        <h2>Colaboraciones estratégicas</h2>
        <p>
          Participamos en grupos de trabajo con Red Eléctrica de España, asociaciones de comunidades energéticas,
          clústeres industriales y universidades. Estas alianzas nos permiten validar soluciones, compartir conocimiento y acelerar estándares de interoperabilidad.
        </p>
        <p>
          Además, contribuimos a iniciativas de investigación europeas relacionadas con flexibilidad, digitalización de subestaciones y coordinación de recursos distribuidos.
        </p>
      </div>
    </section>
  </>
);

export default AboutPage;