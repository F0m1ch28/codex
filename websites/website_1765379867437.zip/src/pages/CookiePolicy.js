import React from 'react';
import PageHelmet from '../components/PageHelmet';

const CookiePolicyPage = () => (
  <>
    <PageHelmet
      title="Política de Cookies | GridFlow Energy Systems"
      description="Política de cookies de GridFlow Energy Systems: tipos de cookies utilizadas y opciones de gestión."
      keywords="política de cookies, gridflow, cookies analíticas"
    />
    <section className="page-hero">
      <div className="container narrow">
        <h1>Política de Cookies</h1>
      </div>
    </section>
    <section className="section legal-text">
      <div className="container narrow">
        <h2>¿Qué son las cookies?</h2>
        <p>
          Las cookies son pequeños archivos que se almacenan en tu dispositivo con el fin de recordar información y mejorar la experiencia de navegación. Utilizamos cookies necesarias y analíticas para entender el uso del sitio.
        </p>

        <h2>Tipos de cookies que utilizamos</h2>
        <ul>
          <li><strong>Cookies necesarias:</strong> Garantizan el funcionamiento básico del sitio.</li>
          <li><strong>Cookies analíticas:</strong> Permiten medir el rendimiento y mejorar los contenidos.</li>
        </ul>

        <h2>Gestión de cookies</h2>
        <p>
          Puedes administrar las cookies desde tu navegador. En la mayoría de navegadores podrás bloquear o eliminar las cookies en cualquier momento. Ten en cuenta que algunas funcionalidades pueden verse afectadas si se bloquean las cookies necesarias.
        </p>

        <h2>Actualizaciones</h2>
        <p>
          Esta política puede actualizarse en función de cambios normativos o técnicos. Te recomendamos consultarla periódicamente.
        </p>

        <h2>Contacto</h2>
        <p>
          Para cualquier consulta relacionada con esta política, contáctanos en <a href="mailto:info@gridflowtech.com">info@gridflowtech.com</a> o por teléfono en <a href="tel:+34915427319">+34 915 42 73 19</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;