import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import PageHelmet from '../components/PageHelmet';

const HomePage = () => {
  const stats = [
    { label: 'Nodos monitorizados en Iberia', value: 120, suffix: '+' },
    { label: 'Modelos predictivos en operación', value: 34, suffix: '' },
    { label: 'MW integrados en tiempo real', value: 950, suffix: '' },
    { label: 'Alertas inteligentes resueltas', value: 8700, suffix: '+' }
  ];

  const [displayStats, setDisplayStats] = useState(stats.map(() => 0));

  useEffect(() => {
    const intervals = stats.map((stat, index) => {
      const increment = Math.max(1, Math.ceil(stat.value / 50));
      return setInterval(() => {
        setDisplayStats(prev => {
          const updated = [...prev];
          if (updated[index] < stat.value) {
            updated[index] = Math.min(updated[index] + increment, stat.value);
          }
          return updated;
        });
      }, 30);
    });

    return () => intervals.forEach(clearInterval);
  }, [stats]);

  const services = [
    {
      title: 'Smart Grid Technology',
      description: 'Diseñamos arquitecturas de red inteligentes con sensores interoperables, visibilidad granular y control distribuido de activos críticos.',
      image: 'https://picsum.photos/600/400?random=11'
    },
    {
      title: 'Distribución Renovable',
      description: 'Orquestamos la integración solar-fotovoltaica y eólica con herramientas de previsión, curtailment dinámico y coordinación bidireccional.',
      image: 'https://picsum.photos/600/400?random=12'
    },
    {
      title: 'Balanceo y Estabilidad',
      description: 'Implementamos algoritmos de demanda-respuesta, compensación reactiva y gestión de flexibilidad para mantener la estabilidad del sistema.',
      image: 'https://picsum.photos/600/400?random=13'
    },
    {
      title: 'Infraestructura Digital & Analytics',
      description: 'Analítica avanzada, gemelos digitales y visualización en tiempo real para operadores, ingenieros de red y equipos de planificación.',
      image: 'https://picsum.photos/600/400?random=14'
    }
  ];

  const processSteps = [
    {
      title: 'Evaluación de red',
      description: 'Inventario digital de activos, mapeo de flujos y priorización de nodos con impacto crítico.',
      icon: '①'
    },
    {
      title: 'Modelado y simulación',
      description: 'Gemelos digitales, escenarios de contingencia y simulaciones multi-horarias de carga y generación.',
      icon: '②'
    },
    {
      title: 'Implementación iterativa',
      description: 'Integración modular, APIs abiertas y despliegue seguro en entornos híbridos.',
      icon: '③'
    },
    {
      title: 'Optimización continua',
      description: 'Analítica predictiva, alertas inteligentes y mejora continua con datos en vivo.',
      icon: '④'
    }
  ];

  const testimonials = [
    {
      quote: 'GridFlow ha preparado nuestra red para un crecimiento renovable acelerado. La visibilidad granular y las recomendaciones automáticas han reducido tiempos de reacción operativa.',
      name: 'Lucía Fernández',
      role: 'Directora de Operación de Redes, EnergiMadrid',
      image: 'https://picsum.photos/200/200?random=15'
    },
    {
      quote: 'La plataforma de analítica permitió coordinar generación distribuida y demanda flexible con precisión. La capacidad de simular contingencias nos aporta confianza operativa.',
      name: 'Javier Hidalgo',
      role: 'Responsable de Innovación, Consorcio Solar Iberia',
      image: 'https://picsum.photos/200/200?random=16'
    },
    {
      quote: 'La integración con nuestros sistemas SCADA fue fluida y segura. Ahora contamos con indicadores predictivos y rutas de resolución claras para cada incidencia.',
      name: 'María León',
      role: 'Gestora de Redes Inteligentes, Red Urbana Norte',
      image: 'https://picsum.photos/200/200?random=17'
    }
  ];
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const projects = [
    {
      id: 1,
      title: 'Microred urbana resiliente',
      category: 'Microredes',
      description: 'Monitorización de activos y respuesta dinámica en distritos energéticos con almacenamiento distribuido.',
      image: 'https://picsum.photos/1200/800?random=18'
    },
    {
      id: 2,
      title: 'Hibridación solar-eólica',
      category: 'Integración Renovable',
      description: 'Coordinación bidireccional de parques híbridos con previsión meteorológica y control curtailment.',
      image: 'https://picsum.photos/1200/800?random=19'
    },
    {
      id: 3,
      title: 'Analítica predictiva de cargas',
      category: 'Analítica Predictiva',
      description: 'Modelos de demanda-respuesta para redes industriales con gestión de flexibilidad en tiempo real.',
      image: 'https://picsum.photos/1200/800?random=20'
    },
    {
      id: 4,
      title: 'Operación distribuida atlántica',
      category: 'Microredes',
      description: 'Arquitectura de control distribuido para islas conectadas con monitoreo IoT y ciberseguridad reforzada.',
      image: 'https://picsum.photos/1200/800?random=21'
    }
  ];
  const categories = ['Todas', 'Microredes', 'Integración Renovable', 'Analítica Predictiva'];
  const [activeCategory, setActiveCategory] = useState('Todas');
  const filteredProjects =
    activeCategory === 'Todas' ? projects : projects.filter(project => project.category === activeCategory);

  const faqData = [
    {
      question: '¿Cómo se integra GridFlow con sistemas existentes?',
      answer:
        'Trabajamos con APIs abiertas, buses de datos estandarizados y conectores para SCADA, GIS y plataformas de telemetría. Diseñamos la integración sin interrumpir la operación diaria.'
    },
    {
      question: '¿Qué nivel de personalización ofrece la plataforma?',
      answer:
        'Cada módulo se adapta a los requisitos de la red: definimos umbrales, reglas de automatización y paneles específicos para operación, planificación y mantenimiento.'
    },
    {
      question: '¿Qué metodologías utilizáis para la analítica?',
      answer:
        'Combinamos modelos estadísticos, machine learning y simulaciones físico-eléctricas. Los modelos se recalibran constantemente con nuevos datos y validaciones de campo.'
    },
    {
      question: '¿Cómo gestionáis la ciberseguridad de la infraestructura digital?',
      answer:
        'Aplicamos controles de acceso de múltiples capas, cifrado extremo a extremo, monitoreo continuo de anomalías y pruebas de intrusión periódicas alineadas con normas europeas.'
    }
  ];
  const [activeQuestion, setActiveQuestion] = useState(0);

  return (
    <>
      <PageHelmet
        title="GridFlow Energy Systems | Redes Inteligentes y Analítica Energética"
        description="GridFlow Energy Systems transforma la infraestructura eléctrica con tecnología de redes inteligentes, balanceo avanzado e integración renovable en España."
        keywords="smart grid, redes inteligentes, balanceo de red, gestión energética, integración renovable, transformación digital, infraestructura eléctrica, grid analytics, demanda respuesta, redes bidireccionales"
      />
      <section
        className="hero"
        style={{ backgroundImage: 'url("https://picsum.photos/1600/900?random=22")' }}
      >
        <div className="container hero-content">
          <p className="hero-badge">GridFlow Energy Systems</p>
          <h1>Transformando la Red Eléctrica con Inteligencia</h1>
          <p className="hero-subtitle">
            Plataforma de ingeniería y analítica que impulsa redes inteligentes, integra energías renovables y equilibra la red con decisiones basadas en datos.
          </p>
          <div className="hero-actions">
            <Link to="/plataforma" className="primary-btn">Descubre Nuestra Plataforma</Link>
            <Link to="/contacto" className="secondary-btn">Agenda una conversación técnica</Link>
          </div>
        </div>
      </section>

      <section className="section stats-section">
        <div className="container">
          <div className="section-header">
            <h2>Impacto medible en redes inteligentes</h2>
            <p>
              Consolidamos datos críticos, automatizamos decisiones y sincronizamos la infraestructura eléctrica con la transición energética.
            </p>
          </div>
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <div key={stat.label} className="stat-card">
                <span className="stat-value">
                  {displayStats[index]}
                  {stat.suffix}
                </span>
                <span className="stat-label">{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section about-section">
        <div className="container about-grid">
          <div className="about-text">
            <h2>Quiénes somos</h2>
            <p>
              GridFlow Energy Systems es una plataforma española especializada en tecnología de redes inteligentes, distribución de energía renovable y balanceo de red. Exploramos sistemas de gestión energética avanzada, integración bidireccional solar-eólica y soluciones de estabilidad mediante innovación digital y optimización algorítmica.
            </p>
            <p>
              Acompañamos a operadores, utilities y consorcios energéticos a modernizar su infraestructura, con herramientas de analítica profunda, supervisión modular y automatización segura.
            </p>
            <div className="about-highlights">
              <div>
                <strong>Enfoque integral</strong>
                <p>Ingeniería, datos y operación conectados en un único hub digital.</p>
              </div>
              <div>
                <strong>Experiencia local</strong>
                <p>Proyectos en redes urbanas, rurales e insulares de España y Europa.</p>
              </div>
            </div>
          </div>
          <div className="about-media">
            <img src="https://picsum.photos/800/600?random=23" alt="Ingeniera monitorizando panel de control de red inteligente" />
          </div>
        </div>
      </section>

      <section className="section services-section">
        <div className="container">
          <div className="section-header">
            <h2>Áreas clave de la plataforma</h2>
            <p>
              Integración modular diseñada para aportar visibilidad, resiliencia y eficiencia a cada segmento de la red eléctrica.
            </p>
          </div>
          <div className="services-grid">
            {services.map(service => (
              <article className="service-card" key={service.title}>
                <img src={service.image} alt={`Ilustración de ${service.title}`} loading="lazy" />
                <div className="service-content">
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <Link to="/plataforma" className="text-link">Explorar módulo</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section tech-section">
        <div className="container tech-grid">
          <div>
            <h2>Analítica avanzada y automatización inteligente</h2>
            <p>
              Ejecutamos modelos de grid analytics en tiempo real que combinan telemetría IoT, datos meteorológicos y escenarios de demanda-respuesta para anticipar comportamientos de la red.
            </p>
            <ul className="tech-list">
              <li>Gemelos digitales para simular contingencias y maniobras.</li>
              <li>Algoritmos de optimización para balanceo de tensión y frecuencia.</li>
              <li>Paneles inmersivos con indicadores clave y trazabilidad completa.</li>
              <li>APIs seguras para interoperabilidad con sistemas corporativos.</li>
            </ul>
            <Link to="/innovacion" className="secondary-btn">Conoce el hub de innovación</Link>
          </div>
          <div className="tech-media">
            <img src="https://picsum.photos/800/600?random=24" alt="Visualización digital de datos energéticos en tiempo real" loading="lazy" />
          </div>
        </div>
      </section>

      <section className="section approach-section">
        <div className="container">
          <div className="section-header">
            <h2>Nuestro enfoque</h2>
            <p>
              Alineamos la operación de la red con objetivos de sostenibilidad, flexibilidad y resiliencia.
            </p>
          </div>
          <div className="approach-grid">
            <div className="approach-card">
              <h3>Innovación continua</h3>
              <p>Actualizaciones incrementales basadas en feedback de operadores y datos en vivo.</p>
            </div>
            <div className="approach-card">
              <h3>Sostenibilidad integrada</h3>
              <p>Priorizamos la integración de recursos energéticos distribuídos y renovables.</p>
            </div>
            <div className="approach-card">
              <h3>Seguridad de extremo a extremo</h3>
              <p>Protocolos cifrados, autenticación robusta y monitorización de amenazas 24/7.</p>
            </div>
            <div className="approach-card">
              <h3>Colaboración abierta</h3>
              <p>Clústeres de innovación, programas piloto y co-creación con ingenierías locales.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section process-section">
        <div className="container">
          <div className="section-header">
            <h2>Metodología GridFlow</h2>
            <p>Implementamos proyectos de forma iterativa, segura y medible.</p>
          </div>
          <div className="process-grid">
            {processSteps.map(step => (
              <div className="process-card" key={step.title}>
                <span className="process-icon" aria-hidden>{step.icon}</span>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section projects-section">
        <div className="container">
          <div className="section-header">
            <h2>Casos de referencia</h2>
            <p>Selección de iniciativas que demuestran la versatilidad de nuestra plataforma.</p>
          </div>
          <div className="project-filters" role="group" aria-label="Filtros de proyectos">
            {categories.map(category => (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                className={`filter-btn ${activeCategory === category ? 'active' : ''}`}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="projects-grid">
            {filteredProjects.map(project => (
              <article className="project-card" key={project.id}>
                <img src={project.image} alt={`Proyecto ${project.title}`} loading="lazy" />
                <div className="project-content">
                  <span className="project-tag">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section testimonials-section">
        <div className="container">
          <div className="section-header">
            <h2>Lo que comentan nuestros colaboradores</h2>
            <p>Relaciones de confianza basadas en resultados tangibles.</p>
          </div>
          <div className="testimonial-card" aria-live="polite">
            <button
              type="button"
              className="carousel-btn prev"
              onClick={() => setCurrentTestimonial((currentTestimonial - 1 + testimonials.length) % testimonials.length)}
              aria-label="Testimonio anterior"
            >
              ‹
            </button>
            <div className="testimonial-content">
              <img src={testimonials[currentTestimonial].image} alt={`Retrato de ${testimonials[currentTestimonial].name}`} loading="lazy" />
              <blockquote>“{testimonials[currentTestimonial].quote}”</blockquote>
              <p className="testimonial-author">{testimonials[currentTestimonial].name}</p>
              <p className="testimonial-role">{testimonials[currentTestimonial].role}</p>
            </div>
            <button
              type="button"
              className="carousel-btn next"
              onClick={() => setCurrentTestimonial((currentTestimonial + 1) % testimonials.length)}
              aria-label="Testimonio siguiente"
            >
              ›
            </button>
          </div>
          <div className="carousel-indicators" role="tablist">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`indicator ${currentTestimonial === index ? 'active' : ''}`}
                aria-label={`Ver testimonio ${index + 1}`}
                onClick={() => setCurrentTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section team-section">
        <div className="container">
          <div className="section-header">
            <h2>Equipo técnico</h2>
            <p>Ingeniería especializada en redes inteligentes, datos y automatización energética.</p>
          </div>
          <div className="team-grid">
            {[
              {
                name: 'Ana Gutiérrez',
                role: 'Directora de Ingeniería de Redes',
                bio: 'Especialista en arquitectura de redes y modernización de subestaciones digitales.',
                image: 'https://picsum.photos/400/400?random=25'
              },
              {
                name: 'Carlos Ortega',
                role: 'Líder de Grid Analytics',
                bio: 'Desarrolla modelos predictivos y gemelos digitales para operación segura.',
                image: 'https://picsum.photos/400/400?random=26'
              },
              {
                name: 'Elena Marqués',
                role: 'Responsable de Integración Renovable',
                bio: 'Coordina proyectos de hibridación solar-eólica y flexibilidad distribuida.',
                image: 'https://picsum.photos/400/400?random=27'
              },
              {
                name: 'Jordi Martín',
                role: 'Experto en Ciberseguridad OT',
                bio: 'Protege infraestructuras críticas con estrategias de defensa multicapa.',
                image: 'https://picsum.photos/400/400?random=28'
              }
            ].map(member => (
              <article key={member.name} className="team-card">
                <img src={member.image} alt={`Retrato de ${member.name}`} loading="lazy" />
                <h3>{member.name}</h3>
                <p className="team-role">{member.role}</p>
                <p>{member.bio}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section faq-section">
        <div className="container faq-grid">
          <div className="section-header">
            <h2>Preguntas frecuentes</h2>
            <p>Resolvemos dudas habituales antes de iniciar nuevos proyectos.</p>
          </div>
          <div className="faq-items">
            {faqData.map((item, index) => (
              <div className={`faq-item ${activeQuestion === index ? 'active' : ''}`} key={item.question}>
                <button
                  type="button"
                  className="faq-question"
                  aria-expanded={activeQuestion === index}
                  onClick={() => setActiveQuestion(activeQuestion === index ? null : index)}
                >
                  {item.question}
                  <span>{activeQuestion === index ? '−' : '+'}</span>
                </button>
                {activeQuestion === index && <p className="faq-answer">{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section blog-section">
        <div className="container">
          <div className="section-header">
            <h2>Últimas perspectivas</h2>
            <p>Análisis sobre redes inteligentes, digitalización energética y metodologías GridFlow.</p>
          </div>
          <div className="blog-grid">
            {[
              {
                title: 'Gestión de flexibilidad en redes urbanas densas',
                excerpt: 'Claves para sincronizar recursos distribuidos, almacenamiento y demanda-respuesta en centros urbanos.',
                image: 'https://picsum.photos/800/600?random=29',
                link: '/innovacion'
              },
              {
                title: 'Gemelos digitales para resiliencia eléctrica',
                excerpt: 'Cómo modelar contingencias y priorizar inversiones en refuerzos de red con simulaciones avanzadas.',
                image: 'https://picsum.photos/800/600?random=30',
                link: '/plataforma'
              },
              {
                title: 'Arquitectura interoperable para operadores españoles',
                excerpt: 'Buenas prácticas para conectar sistemas legados, IoT y analítica avanzada con ciberseguridad reforzada.',
                image: 'https://picsum.photos/800/600?random=31',
                link: '/soluciones'
              }
            ].map(post => (
              <article className="blog-card" key={post.title}>
                <img src={post.image} alt={`Ilustración del artículo ${post.title}`} loading="lazy" />
                <div className="blog-content">
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className="text-link">Ampliar análisis</Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section cta-section">
        <div className="container cta-container">
          <div>
            <h2>¿Listo para modernizar tu red?</h2>
            <p>
              Colaboremos en un roadmap que una modernización digital, integración renovable y estabilidad operacional. Nuestro equipo está preparado para analizar tu infraestructura y definir el siguiente paso.
            </p>
          </div>
          <Link to="/contacto" className="primary-btn">Contactar con GridFlow</Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;