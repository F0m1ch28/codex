import React from 'react';
import PageHelmet from '../components/PageHelmet';

const TermsPage = () => (
  <>
    <PageHelmet
      title="Aviso Legal | GridFlow Energy Systems"
      description="Aviso legal de GridFlow Energy Systems, información corporativa y condiciones de uso del sitio web."
      keywords="aviso legal, gridflow, condiciones de uso, información corporativa"
    />
    <section className="page-hero">
      <div className="container narrow">
        <h1>Aviso Legal</h1>
      </div>
    </section>
    <section className="section legal-text">
      <div className="container narrow">
        <h2>Identificación</h2>
        <p>
          GridFlow Energy Systems (gridflowtech.com) es una plataforma operada desde Calle Princesa 31, 28008 Madrid, Spain.
          Contacto: <a href="mailto:info@gridflowtech.com">info@gridflowtech.com</a>, Tel: <a href="tel:+34915427319">+34 915 42 73 19</a>.
        </p>

        <h2>Condiciones de uso</h2>
        <p>
          El acceso y uso del sitio web implica la aceptación de estas condiciones. El usuario se compromete a hacer un uso responsable, a no realizar actividades contrarias a la legislación vigente y a respetar los derechos de propiedad intelectual.
        </p>

        <h2>Propiedad intelectual</h2>
        <p>
          Los contenidos, textos, imágenes, diseños y código fuente pertenecen a GridFlow Energy Systems o a terceros autorizados. Queda prohibida la reproducción o distribución sin autorización expresa.
        </p>

        <h2>Responsabilidad</h2>
        <p>
          GridFlow Energy Systems no se responsabiliza de posibles daños derivados del uso de la información del sitio, interrupciones del servicio o accesos a enlaces externos. Se implementan medidas técnicas para reducir riesgos y mantener la disponibilidad del sitio.
        </p>

        <h2>Legislación aplicable</h2>
        <p>
          Este aviso legal se rige por la normativa española. Cualquier controversia se resolverá en los juzgados de Madrid, salvo disposición legal en contrario.
        </p>
      </div>
    </section>
  </>
);

export default TermsPage;