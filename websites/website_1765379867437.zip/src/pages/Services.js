import React from 'react';
import PageHelmet from '../components/PageHelmet';

const ServicesPage = () => (
  <>
    <PageHelmet
      title="Soluciones GridFlow | Smart Grid, Renovables, Balanceo y Analítica"
      description="Soluciones de GridFlow Energy Systems: tecnología smart grid, distribución renovable, balanceo de red e infraestructura digital con analítica avanzada."
      keywords="soluciones smart grid, distribución renovable, balanceo de red, infraestructura digital, analítica energética"
    />
    <section className="page-hero">
      <div className="container narrow">
        <h1>Soluciones GridFlow</h1>
        <p>
          Un portafolio integrado que aborda los retos de redes inteligentes, integración renovable y operación digital.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container solutions-grid">
        <article className="solution-card">
          <img src="https://picsum.photos/800/600?random=37" alt="Centro de control de red inteligente con paneles especializados" loading="lazy" />
          <div>
            <h2>Smart Grid Technology</h2>
            <p>
              Digitalizamos la red con sensores, automatismos y análisis en tiempo real. Nuestras soluciones optimizan la visibilidad y coordinación de subestaciones, líneas y activos distribuidos, garantizando capacidad de respuesta ante cualquier contingencia.
            </p>
            <ul>
              <li>Automatización de subestaciones y control remoto.</li>
              <li>Telemetría avanzada y alarmas inteligentes.</li>
              <li>Gestión de activos con análisis de estado y vida útil.</li>
            </ul>
          </div>
        </article>

        <article className="solution-card reverse">
          <img src="https://picsum.photos/800/600?random=38" alt="Parque solar y eólico integrado en red inteligente" loading="lazy" />
          <div>
            <h2>Distribución de Energía Renovable</h2>
            <p>
              Facilitamos la integración de recursos renovables con algoritmos de previsión y control de potencia. Coordinamos flujos bidireccionales, puntos de conexión y almacenamiento distribuido para maximizar la aportación de generación limpia.
            </p>
            <ul>
              <li>Previsión meteorológica y de potencia en múltiples horizontes.</li>
              <li>Gestión de puntos de inyección y limitaciones de red.</li>
              <li>Sincronización con sistemas de almacenamiento y movilidad eléctrica.</li>
            </ul>
          </div>
        </article>

        <article className="solution-card">
          <img src="https://picsum.photos/800/600?random=39" alt="Tablero con datos de balanceo energético" loading="lazy" />
          <div>
            <h2>Balanceo de Red y Estabilidad</h2>
            <p>
              Automatizamos decisiones de balanceo con algoritmos de demanda-respuesta, control de tensión y redistribución de cargas. Nuestro enfoque minimiza congestiones, pérdidas y riesgos de desconexión.
            </p>
            <ul>
              <li>Módulos de demanda-respuesta con segmentación avanzada.</li>
              <li>Gestión de tensión y potencia reactiva en subestaciones.</li>
              <li>Planes de acción para contingencias y mantenimiento preventivo.</li>
            </ul>
          </div>
        </article>

        <article className="solution-card reverse">
          <img src="https://picsum.photos/800/600?random=40" alt="Interfaz digital con analítica de red eléctrica" loading="lazy" />
          <div>
            <h2>Infraestructura Digital & Grid Analytics</h2>
            <p>
              Un hub de analítica y datos que potencia la toma de decisiones. Visualizaciones interactivas, informes, alertas contextualizadas y herramientas colaborativas diseñadas para equipos técnicos y directivos.
            </p>
            <ul>
              <li>Dashboards multidisciplinarios con indicadores clave.</li>
              <li>Modelos predictivos y machine learning integrados.</li>
              <li>Reportes automatizados y trazabilidad completa de eventos.</li>
            </ul>
          </div>
        </article>
      </div>
    </section>

    <section className="section grey">
      <div className="container narrow">
        <h2>Capacidades complementarias</h2>
        <p>
          Ofrecemos asesoría en diseño de microrredes, auditorías digitales, simulaciones de resiliencia, programas de formación técnica y soporte continuo con equipos a demanda.
        </p>
      </div>
    </section>
  </>
);

export default ServicesPage;