import React from 'react';
import PageHelmet from '../components/PageHelmet';

const InnovationPage = () => (
  <>
    <PageHelmet
      title="Innovación GridFlow | Investigación y Optimización Algorítmica"
      description="Descubre la innovación de GridFlow: R&D en algoritmos de optimización, digitalización de redes eléctricas y transformación energética."
      keywords="innovación energética, I+D smart grid, optimización algorítmica, transformación digital energía"
    />
    <section className="page-hero">
      <div className="container narrow">
        <h1>Innovación GridFlow</h1>
        <p>
          Investigación aplicada y desarrollo de algoritmos para anticipar, optimizar y automatizar la operación de redes inteligentes.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container innovation-grid">
        <div className="innovation-card">
          <h2>Optimización algorítmica</h2>
          <p>
            Desarrollamos modelos que equilibran potencia activa y reactiva, calculan rutas óptimas para maniobras y asignan recursos flexibles con criterios multicriterio. Cada algoritmo pasa por fases de validación en laboratorio y pruebas controladas.
          </p>
        </div>
        <div className="innovation-card">
          <h2>Laboratorio de simulación</h2>
          <p>
            Disponemos de un laboratorio donde replicamos condiciones de red, perturbaciones y escenarios climáticos extremos. Esto permite entrenar modelos y validar protocolos antes de desplegarlos en campo.
          </p>
        </div>
        <div className="innovation-card">
          <h2>Programas piloto</h2>
          <p>
            Trabajamos con partners para diseñar pilotos de microrredes, comunidades energéticas y hubs industriales, evaluando indicadores de resiliencia, estabilidad y eficiencia energética.
          </p>
        </div>
        <div className="innovation-card">
          <h2>Colaboración abierta</h2>
          <p>
            Participamos en consorcios europeos, compartimos datasets anonimizados y publicamos hallazgos técnicos para impulsar estándares de interoperabilidad y seguridad.
          </p>
        </div>
      </div>
    </section>

    <section className="section grey">
      <div className="container two-columns">
        <div>
          <h2>Programas de transferencia tecnológica</h2>
          <p>
            Convertimos avances de la investigación en soluciones operativas: desde modelos de predicción híperlocal hasta asistentes cognitivos para centros de control. Acompañamos a los equipos de nuestros clientes en todo el ciclo de adopción.
          </p>
        </div>
        <div>
          <img src="https://picsum.photos/800/600?random=41" alt="Investigadores trabajando en laboratorio de energía digital" loading="lazy" />
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container narrow">
        <h2>Próximas líneas de trabajo</h2>
        <ul className="innovation-list">
          <li>Integración de redes bidireccionales con sistemas de movilidad eléctrica.</li>
          <li>Algoritmos de ciber-resiliencia con detección temprana de intrusiones OT.</li>
          <li>Modelos de gestión de flexibilidad para comunidades energéticas locales.</li>
          <li>Uso de datos satelitales y LIDAR para supervisión de infraestructuras críticas.</li>
        </ul>
      </div>
    </section>
  </>
);

export default InnovationPage;