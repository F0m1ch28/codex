import React from 'react';
import PageHelmet from '../components/PageHelmet';

const PrivacyPage = () => (
  <>
    <PageHelmet
      title="Política de Privacidad | GridFlow Energy Systems"
      description="Política de privacidad de GridFlow Energy Systems sobre tratamiento de datos personales y derechos de los usuarios."
      keywords="política de privacidad, protección de datos, gridflow"
    />
    <section className="page-hero">
      <div className="container narrow">
        <h1>Política de Privacidad</h1>
      </div>
    </section>
    <section className="section legal-text">
      <div className="container narrow">
        <h2>Responsable del tratamiento</h2>
        <p>
          GridFlow Energy Systems, con domicilio en Calle Princesa 31, 28008 Madrid, Spain, es responsable de los datos personales recabados a través de este sitio. Contacto: <a href="mailto:info@gridflowtech.com">info@gridflowtech.com</a>.
        </p>

        <h2>Finalidad</h2>
        <p>
          Los datos se recaban para responder consultas, gestionar relaciones profesionales y enviar comunicaciones técnicas relacionadas con nuestros servicios de redes inteligentes. No se utilizan para otros fines sin consentimiento previo.
        </p>

        <h2>Legitimación</h2>
        <p>
          La base legal principal es el consentimiento otorgado por la persona usuaria al completar los formularios. Se aplican medidas de seguridad técnicas y organizativas para proteger la información.
        </p>

        <h2>Destinatarios</h2>
        <p>
          No se ceden datos a terceros salvo obligación legal o necesidad operativa vinculada a la prestación del servicio. En caso de utilizar proveedores, se firman acuerdos de encargo de tratamiento conforme al RGPD.
        </p>

        <h2>Derechos</h2>
        <p>
          Puedes ejercer los derechos de acceso, rectificación, supresión, oposición, limitación y portabilidad escribiendo a <a href="mailto:info@gridflowtech.com">info@gridflowtech.com</a>. También tienes derecho a presentar reclamación ante la Agencia Española de Protección de Datos.
        </p>

        <h2>Conservación</h2>
        <p>
          Los datos se conservarán mientras exista relación profesional o hasta que se solicite su supresión. Superado este periodo, se eliminarán aplicando los plazos legales.
        </p>
      </div>
    </section>
  </>
);

export default PrivacyPage;