import React from 'react';
import PageHelmet from '../components/PageHelmet';

const PlatformPage = () => (
  <>
    <PageHelmet
      title="Plataforma Tecnológica GridFlow | Hub de Analítica de Red"
      description="Descubre la plataforma tecnológica de GridFlow: módulos de grid analytics, gemelos digitales, control distribuido y orquestación de recursos renovables."
      keywords="plataforma grid, hub analítica energética, gemelos digitales, control distribuido, smart grid technology"
    />
    <section className="page-hero">
      <div className="container narrow">
        <h1>Plataforma Tecnológica GridFlow</h1>
        <p>
          Una arquitectura modular que unifica datos, modelos y operaciones para redes eléctricas inteligentes.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container platform-grid">
        <div className="platform-card">
          <h2>Arquitectura de datos</h2>
          <p>
            Ingesta en tiempo real desde medidores inteligentes, SCADA, sensores IoT y fuentes meteorológicas. Motor de datos escalable con normalización contextual y almacenamiento seguro en la nube o en instalaciones propias.
          </p>
          <ul>
            <li>Conectores OPC-UA, Modbus, IEC 61850.</li>
            <li>Data lake estructurado con historiales y eventos.</li>
            <li>Monitorización de calidad de datos y trazabilidad total.</li>
          </ul>
        </div>
        <div className="platform-card">
          <h2>Motor analítico</h2>
          <p>
            Algoritmos de predicción, optimización y detección de anomalías diseñados para responder con rapidez a variaciones de la red y al comportamiento renovable.
          </p>
          <ul>
            <li>Pronóstico de generación y demanda multi-horaria.</li>
            <li>Detección temprana de congestiones y pérdidas técnicas.</li>
            <li>Simulaciones de contingencia y secuencias de maniobras.</li>
          </ul>
        </div>
        <div className="platform-card">
          <h2>Interfaz operativa</h2>
          <p>
            Paneles adaptados a ingeniería, planificación y operación. Visualizaciones geoespaciales, flujos en directo, alertas jerarquizadas y rutas de resolución guiadas.
          </p>
          <ul>
            <li>Dashboards personalizables y widgets colaborativos.</li>
            <li>Alertas inteligentes con prioridades y acciones sugeridas.</li>
            <li>Gestión de tickets y bitácoras integradas.</li>
          </ul>
        </div>
        <div className="platform-card">
          <h2>Orquestación automatizada</h2>
          <p>
            Capas de control que facilitan decisiones automáticas o asistidas para balanceo de carga, reparto de recursos y coordinación de activos distribuidos.
          </p>
          <ul>
            <li>Demand Response y agregación de flexibilidad.</li>
            <li>Control de almacenamiento y microredes.</li>
            <li>Protocolos de actuación configurables por escenario.</li>
          </ul>
        </div>
      </div>
    </section>

    <section className="section grey">
      <div className="container two-columns">
        <div>
          <h2>Gemelo digital de red</h2>
          <p>
            Replicamos el comportamiento eléctrico de la red en un entorno virtual que permite probar maniobras, evaluar contingencias y diseñar escenarios futuros. Las simulaciones se sincronizan con datos reales para mantener la coherencia.
          </p>
          <p>
            El gemelo digital facilita tareas de planificación, mantenimiento y diagnóstico, reduciendo tiempos de respuesta ante incidencias y mejorando la coordinación entre equipos.
          </p>
        </div>
        <div>
          <img src="https://picsum.photos/800/600?random=36" alt="Representación digital de una red eléctrica" loading="lazy" />
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container platform-details">
        <div className="section-header">
          <h2>Características clave</h2>
        </div>
        <div className="details-grid">
          <div className="detail-card">
            <h3>Seguridad y cumplimiento</h3>
            <p>Controles de acceso granular, auditorías continuas y alineación con normativas europeas de protección de infraestructuras críticas.</p>
          </div>
          <div className="detail-card">
            <h3>Escalabilidad modular</h3>
            <p>Despliegue por fases: desde pilotos en subestaciones concretas hasta cobertura regional o nacional.</p>
          </div>
          <div className="detail-card">
            <h3>Interoperabilidad</h3>
            <p>APIs REST, soporte para estándares CIM y conectores específicos para plataformas corporativas.</p>
          </div>
          <div className="detail-card">
            <h3>Analítica colaborativa</h3>
            <p>Espacios compartidos para equipos de ingeniería, planificación y operación con anotaciones y versionado.</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default PlatformPage;