import React, { useState } from 'react';
import PageHelmet from '../components/PageHelmet';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = event => {
    const { name, value } = event.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Introduce tu nombre.';
    if (!formData.email.trim()) {
      newErrors.email = 'Introduce tu correo electrónico.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Introduce un correo electrónico válido.';
    }
    if (!formData.message.trim()) newErrors.message = 'Describe tu consulta.';
    return newErrors;
  };

  const handleSubmit = event => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setSubmitted(false), 5000);
    }
  };

  return (
    <>
      <PageHelmet
        title="Contacto GridFlow Energy Systems"
        description="Contacta con GridFlow Energy Systems para proyectos de redes inteligentes, balanceo de red y analítica energética en España."
        keywords="contacto GridFlow, smart grid España, analítica de red, ingeniería energética Madrid"
      />
      <section className="page-hero">
        <div className="container narrow">
          <h1>Contacto</h1>
          <p>Comparte los retos de tu red y diseñaremos juntos la siguiente fase de modernización energética.</p>
        </div>
      </section>

      <section className="section contact-section">
        <div className="container contact-grid">
          <div className="contact-info">
            <h2>Información de contacto</h2>
            <p>Calle Princesa 31<br />28008 Madrid, Spain</p>
            <p>Teléfono: <a href="tel:+34915427319">+34 915 42 73 19</a></p>
            <p>Email: <a href="mailto:info@gridflowtech.com">info@gridflowtech.com</a></p>
            <p>Horario de atención: lunes a viernes de 9:00 a 18:00 CET.</p>
            <div className="contact-highlight">
              <h3>¿Qué podemos tratar?</h3>
              <ul>
                <li>Evaluación de modernización de red y smart grid.</li>
                <li>Integración de renovables y flexibilidad distribuida.</li>
                <li>Proyectos piloto, I+D y analítica energética.</li>
              </ul>
            </div>
          </div>
          <form className="contact-form" onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Nombre y apellidos</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                aria-invalid={errors.name ? 'true' : 'false'}
                required
              />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Correo electrónico</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                aria-invalid={errors.email ? 'true' : 'false'}
                required
              />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="message">Mensaje</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={formData.message}
                onChange={handleChange}
                aria-invalid={errors.message ? 'true' : 'false'}
                required
              />
              {errors.message && <span className="form-error">{errors.message}</span>}
            </div>
            <button type="submit" className="primary-btn">Enviar consulta</button>
            {submitted && <p className="form-success">Gracias por tu mensaje. Nos pondremos en contacto contigo muy pronto.</p>}
          </form>
        </div>
      </section>
    </>
  );
};

export default ContactPage;