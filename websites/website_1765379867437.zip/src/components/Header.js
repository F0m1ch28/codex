import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className={`site-header ${menuOpen ? 'menu-open' : ''}`}>
      <div className="container header-container">
        <Link to="/" className="logo" onClick={closeMenu} aria-label="Inicio">
          <span className="logo-mark">{'{'}</span>
          <span className="logo-text">GridFlow</span>
          <span className="logo-mark">{'}'}</span>
        </Link>
        <button
          className="menu-toggle"
          aria-label={menuOpen ? 'Cerrar menú' : 'Abrir menú'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav className={`main-nav ${menuOpen ? 'active' : ''}`} aria-label="Principal">
          <NavLink to="/" onClick={closeMenu} className={({ isActive }) => (isActive ? 'active' : '')}>
            Inicio
          </NavLink>
          <NavLink to="/sobre-nosotros" onClick={closeMenu} className={({ isActive }) => (isActive ? 'active' : '')}>
            Sobre Nosotros
          </NavLink>
          <NavLink to="/plataforma" onClick={closeMenu} className={({ isActive }) => (isActive ? 'active' : '')}>
            Plataforma Tecnológica
          </NavLink>
          <NavLink to="/soluciones" onClick={closeMenu} className={({ isActive }) => (isActive ? 'active' : '')}>
            Soluciones
          </NavLink>
          <NavLink to="/innovacion" onClick={closeMenu} className={({ isActive }) => (isActive ? 'active' : '')}>
            Innovación
          </NavLink>
          <Link to="/contacto" className="cta-link" onClick={closeMenu}>
            Contacto
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;