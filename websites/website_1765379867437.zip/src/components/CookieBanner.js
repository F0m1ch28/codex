import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('gridflow_cookie_consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('gridflow_cookie_consent', 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-text">
        <p>
          Utilizamos cookies para analizar el rendimiento de nuestra plataforma y ofrecerte una experiencia optimizada.
          Consulta la <Link to="/politica-cookies">Política de Cookies</Link> para más detalles.
        </p>
      </div>
      <button type="button" onClick={acceptCookies} className="primary-btn">
        Aceptar
      </button>
    </div>
  );
};

export default CookieBanner;