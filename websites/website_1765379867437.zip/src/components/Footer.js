import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="site-footer" aria-label="Pie de página">
      <div className="container footer-grid">
        <div>
          <div className="footer-logo">
            <span className="logo-mark">{'<'}</span>
            <span className="logo-text">GridFlow Energy Systems</span>
            <span className="logo-mark">{'/>'}</span>
          </div>
          <p className="footer-description">
            Ingeniería de redes inteligentes y analítica energética para una infraestructura eléctrica resiliente y conectada.
          </p>
        </div>
        <div>
          <h4>Navegación</h4>
          <ul>
            <li><Link to="/">Inicio</Link></li>
            <li><Link to="/sobre-nosotros">Sobre Nosotros</Link></li>
            <li><Link to="/plataforma">Plataforma Tecnológica</Link></li>
            <li><Link to="/soluciones">Soluciones</Link></li>
            <li><Link to="/innovacion">Innovación</Link></li>
            <li><Link to="/contacto">Contacto</Link></li>
          </ul>
        </div>
        <div>
          <h4>Contacto</h4>
          <p>Calle Princesa 31<br />28008 Madrid, Spain</p>
          <p>Tel: <a href="tel:+34915427319">+34 915 42 73 19</a></p>
          <p>Email: <a href="mailto:info@gridflowtech.com">info@gridflowtech.com</a></p>
        </div>
        <div>
          <h4>Legal</h4>
          <ul>
            <li><Link to="/aviso-legal">Aviso Legal</Link></li>
            <li><Link to="/politica-privacidad">Política de Privacidad</Link></li>
            <li><Link to="/politica-cookies">Política de Cookies</Link></li>
          </ul>
          <p className="footer-copy">© {new Date().getFullYear()} GridFlow Energy Systems. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;