import { useEffect } from 'react';

const PageHelmet = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    if (description) {
      const descriptionTag = document.querySelector('meta#page-description');
      if (descriptionTag) {
        descriptionTag.setAttribute('content', description);
      }
    }
    if (keywords) {
      const keywordsTag = document.querySelector('meta#page-keywords');
      if (keywordsTag) {
        keywordsTag.setAttribute('content', keywords);
      }
    }
  }, [title, description, keywords]);

  return null;
};

export default PageHelmet;