document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isOpen = navMenu.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        document.addEventListener('click', function (event) {
            if (!navMenu.contains(event.target) && event.target !== navToggle && !navToggle.contains(event.target)) {
                navMenu.classList.remove('is-open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('.cookie-accept');
    const declineButton = document.querySelector('.cookie-decline');
    const customizeButton = document.querySelector('.cookie-customize');

    if (cookieBanner) {
        const consent = localStorage.getItem('nipaunxjCookieConsent');
        if (!consent) {
            cookieBanner.classList.add('is-visible');
        }

        if (acceptButton) {
            acceptButton.addEventListener('click', function () {
                localStorage.setItem('nipaunxjCookieConsent', 'accepted');
                cookieBanner.classList.remove('is-visible');
            });
        }

        if (declineButton) {
            declineButton.addEventListener('click', function () {
                localStorage.setItem('nipaunxjCookieConsent', 'declined');
                cookieBanner.classList.remove('is-visible');
            });
        }

        if (customizeButton) {
            customizeButton.addEventListener('click', function () {
                localStorage.setItem('nipaunxjCookieConsent', 'customize');
            });
        }
    }
});