document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  const body = document.body;

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = body.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (body.classList.contains('nav-open')) {
          body.classList.remove('nav-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const banner = document.querySelector('.cookie-banner');
  if (banner) {
    const storedConsent = localStorage.getItem('msa-cookie-consent');
    if (!storedConsent) {
      banner.classList.add('is-visible');
    }

    banner.addEventListener('click', event => {
      const button = event.target.closest('button[data-cookie]');
      if (!button) return;

      const action = button.getAttribute('data-cookie');
      localStorage.setItem('msa-cookie-consent', action);
      banner.classList.remove('is-visible');
    });
  }
});