document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");
  const body = document.body;

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
      if (isOpen) {
        body.classList.add("no-scroll");
      } else {
        body.classList.remove("no-scroll");
      }
    });

    window.addEventListener("resize", () => {
      if (window.matchMedia("(min-width: 768px)").matches) {
        primaryNav.classList.remove("is-open");
        body.classList.remove("no-scroll");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const currentPage = body.dataset.page;
  if (currentPage) {
    document.querySelectorAll(".primary-nav a").forEach((link) => {
      if (link.dataset.page === currentPage) {
        link.classList.add("is-active");
      }
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const consent = localStorage.getItem("rbl-cookie-consent");
    if (!consent) {
      requestAnimationFrame(() => {
        cookieBanner.dataset.visible = "true";
      });
    }

    cookieBanner.addEventListener("click", (event) => {
      const target = event.target.closest("[data-action]");
      if (!target) return;

      const action = target.dataset.action;
      if (action === "accept") {
        localStorage.setItem("rbl-cookie-consent", "accepted");
      } else if (action === "decline") {
        localStorage.setItem("rbl-cookie-consent", "declined");
      }
      cookieBanner.dataset.visible = "false";
    });
  }

  document.querySelectorAll(".faq-item button").forEach((button) => {
    const parent = button.closest(".faq-item");
    const content = button.nextElementSibling;

    button.addEventListener("click", () => {
      const isExpanded = button.getAttribute("aria-expanded") === "true";
      button.setAttribute("aria-expanded", String(!isExpanded));
      parent.classList.toggle("is-open", !isExpanded);

      if (!isExpanded) {
        content.style.maxHeight = content.scrollHeight + "px";
      } else {
        content.style.maxHeight = null;
      }
    });

    button.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        button.click();
      }
    });
  });

  const contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    const messageElement = contactForm.querySelector(".form-message");
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const errors = [];

      const name = formData.get("name")?.trim();
      const email = formData.get("email")?.trim();
      const company = formData.get("company")?.trim();
      const message = formData.get("message")?.trim();

      if (!name) errors.push("Укажите ваше имя.");
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push("Введите корректный адрес электронной почты.");
      }
      if (!company) errors.push("Укажите компанию или организацию.");
      if (!message || message.length < 10) {
        errors.push("Сообщение должно содержать минимум 10 символов.");
      }

      if (errors.length) {
        messageElement.textContent = errors.join(" ");
        messageElement.classList.remove("success");
        messageElement.classList.add("error");
      } else {
        messageElement.textContent = "Спасибо! Мы уже получили ваше сообщение и ответим в течение рабочего дня.";
        messageElement.classList.remove("error");
        messageElement.classList.add("success");
        contactForm.reset();
      }
    });
  }
});