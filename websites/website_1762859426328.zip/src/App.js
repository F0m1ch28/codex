```javascript
import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';

import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Program from './pages/Program';
import Specialists from './pages/Specialists';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';

function AppLayout() {
  const location = useLocation();

  return (
    <>
      <Helmet htmlAttributes={{ lang: 'ru' }}>
        <meta
          name="keywords"
          content="курсы для семей Европа, семейная психология онлайн, отношения в паре, воспитание детей, семейная динамика, Braventy Family Academy"
        />
      </Helmet>
      <Header />
      <main id="main-content" className="main-content" tabIndex="-1">
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/o-nas" element={<About />} />
          <Route path="/kursy" element={<Services />} />
          <Route path="/programma" element={<Program />} />
          <Route path="/specialisty" element={<Specialists />} />
          <Route path="/kontakty" element={<Contact />} />
          <Route path="/usloviya" element={<Terms />} />
          <Route path="/konfidentsialnost" element={<Privacy />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
      <ScrollToTop />
    </>
  );
}

export default AppLayout;
```