```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

const About = () => (
  <>
    <Helmet>
      <title>О нас — Braventy Family Academy</title>
      <meta
        name="description"
        content="Узнайте историю Braventy Family Academy, познакомьтесь с командой психологов и философией обучения, основанной на уважении, эмпатии и европейской экспертизе."
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="container">
        <span className="section-kicker">О нас</span>
        <h1 className="section-title">История создания и наша философия</h1>
        <p className={styles.lead}>
          Braventy Family Academy появилась как ответ на запрос семей, проживающих в Европе и
          ищущих поддержку на русском языке. Мы объединяем практику семейной психологии,
          современные исследования и тёплую атмосферу, чтобы укреплять связи между близкими.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.grid}>
          <article className={styles.card}>
            <h2>От вдохновения к академии</h2>
            <p>
              Идея академии родилась в Берлине, где многие семьи сталкиваются с культурной адаптацией,
              сменой ритма жизни и необходимостью искать новые способы общения. Мы начали с небольших
              групповых встреч и поняли, как важна поддержка на родном языке, учитывающая европейский контекст.
            </p>
            <p>
              Сегодня Braventy — это комплексная платформа, объединяющая курсы, мастерские, консультации и
              международное сообщество семей, которые выбирают осознанность и заботу.
            </p>
          </article>

          <article className={styles.card}>
            <h2>Философия и принципы</h2>
            <ul className={styles.list}>
              <li>
                <strong>Уважение к уникальности.</strong> Каждая семья строит собственную систему ценностей.
              </li>
              <li>
                <strong>Безопасность и эмпатия.</strong> Мы создаём пространство для искренних диалогов.
              </li>
              <li>
                <strong>Основанность на исследованиях.</strong> Используем проверенные методики психологии.
              </li>
              <li>
                <strong>Практичность.</strong> Все инструменты адаптированы к реальной жизни в Европе.
              </li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section className={`${styles.teamSection} section`}>
      <div className="container">
        <div className="section-head">
          <span className="section-kicker">Команда</span>
          <h2 className="section-title">Специалисты, которые вдохновляют</h2>
          <p>
            Наши психологи, коучи и фасилитаторы работают с парами, родителями и детьми, поддерживая
            мультикультурные семьи в разных странах ЕС.
          </p>
        </div>
        <div className={styles.teamGrid}>
          {[
            {
              name: 'Даниэла Шнайдер',
              role: 'Основательница, семейный психолог',
              bio: '12 лет практики в Германии и Австрии. Специализация — семейные системы и адаптация к изменениям.',
              image: 'https://picsum.photos/400/400?random=61'
            },
            {
              name: 'Игорь Белявский',
              role: 'Психотерапевт, эксперт по кризисам',
              bio: 'Сопровождает семьи в периоды переездов, смены школы и профессиональных вызовов.',
              image: 'https://picsum.photos/400/400?random=62'
            },
            {
              name: 'Нора Крамер',
              role: 'Коуч по коммуникации',
              bio: 'Помогает парам и родителям выстраивать конструктивные диалоги и ритуалы поддержки.',
              image: 'https://picsum.photos/400/400?random=63'
            }
          ].map((member) => (
            <article key={member.name} className={styles.member}>
              <div className={styles.photoWrapper}>
                <img src={member.image} alt={member.name} loading="lazy" />
              </div>
              <div className={styles.memberBody}>
                <h3>{member.name}</h3>
                <p className={styles.role}>{member.role}</p>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.timeline}>
          <div>
            <h2 className="section-title">Этапы развития</h2>
            <p>
              Мы постоянно расширяем спектр программ и форматов. Слушаем запросы семей и внедряем новые
              форматы, чтобы поддерживать вас в самых разных ситуациях.
            </p>
          </div>
          <ul className={styles.timelineList}>
            <li>
              <span className={styles.year}>2018</span>
              <p>Первые семейные мастерские в Берлине и онлайн-группа для родителей.</p>
            </li>
            <li>
              <span className={styles.year}>2020</span>
              <p>Запуск платформы с модулями, живыми сессиями и библиотекой материалов.</p>
            </li>
            <li>
              <span className={styles.year}>2022</span>
              <p>Программы для пар, проживающих в разных странах, и мобильное приложение.</p>
            </li>
            <li>
              <span className={styles.year}>2024</span>
              <p>Расширение команды специалистов и запуск международного сообщества выпускников.</p>
            </li>
          </ul>
        </div>
      </div>
    </section>

    <section className={`${styles.cta} section`}>
      <div className="container">
        <div className={styles.ctaInner}>
          <div>
            <h2>Хотите узнать больше?</h2>
            <p>
              Мы с радостью поделимся подробностями о подходе академии, обсудим ваш запрос и предложим
              программу, которая будет созвучна вашей семье.
            </p>
          </div>
          <a className="btn btn-primary" href="/kontakty">
            Назначить созвон
          </a>
        </div>
      </div>
    </section>
  </>
);

export default About;
```