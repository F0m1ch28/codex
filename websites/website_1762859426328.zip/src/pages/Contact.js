```javascript
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ContactPage.module.css';

const initialForm = {
  name: '',
  email: '',
  familyContext: '',
  message: ''
};

const Contact = () => {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!form.name.trim()) newErrors.name = 'Пожалуйста, укажите имя.';
    if (!form.email.trim()) {
      newErrors.email = 'Введите адрес электронной почты.';
    } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      newErrors.email = 'Проверьте корректность email.';
    }
    if (!form.familyContext.trim()) newErrors.familyContext = 'Опишите состав семьи.';
    if (!form.message.trim()) newErrors.message = 'Напишите ваш запрос.';
    return newErrors;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitted(true);
      setForm(initialForm);
    }
  };

  return (
    <>
      <Helmet>
        <title>Контакты — Braventy Family Academy</title>
        <meta
          name="description"
          content="Свяжитесь с Braventy Family Academy: адрес в Берлине, телефон, карта, форма записи на консультацию для семей."
        />
      </Helmet>
      <section className={`${styles.hero} section`}>
        <div className="container">
          <span className="section-kicker">Контакты</span>
          <h1 className="section-title">Мы рядом, чтобы поддержать вашу семью</h1>
          <p className={styles.lead}>
            Напишите нам о цели вашего обращения. Координатор свяжется с вами в течение одного рабочего дня,
            чтобы назначить встречу и рассказать о дальнейших шагах.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.card}>
              <h2>Контактные данные</h2>
              <ul className={styles.contactList}>
                <li>
                  <strong>Адрес:</strong>
                  <span>Kurfürstendamm 156, 10709 Berlin, Germany</span>
                </li>
                <li>
                  <strong>Телефон:</strong>
                  <a href="tel:+493056789012">+49 30 5678 9012</a>
                </li>
                <li>
                  <strong>Email:</strong>
                  <a href="mailto:info@braventyfamilyacademy.com">info@braventyfamilyacademy.com</a>
                </li>
              </ul>
              <div className={styles.mapWrapper} aria-label="Карта расположения офиса в Берлине">
                <iframe
                  title="Braventy Family Academy Berlin"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2428.350369564647!2d13.301791777146748!3d52.4995742395107!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47a850db498f8f1d%3A0xd3af69d196d8bafb!2sKurfürstendamm%20156%2C%2010709%20Berlin!5e0!3m2!1sru!2sde!4v1700000000000!5m2!1sru!2sde"
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>

            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Записаться на консультацию</h2>
              <p className={styles.formIntro}>
                Расскажите немного о себе и вашей семье, чтобы мы могли подготовиться к разговору.
              </p>

              <label htmlFor="name">Ваше имя</label>
              <input
                type="text"
                id="name"
                name="name"
                placeholder="Например, Ольга"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                aria-invalid={errors.name ? 'true' : 'false'}
              />
              {errors.name && <span className={styles.error}>{errors.name}</span>}

              <label htmlFor="email">Электронная почта</label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="family@example.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                aria-invalid={errors.email ? 'true' : 'false'}
              />
              {errors.email && <span className={styles.error}>{errors.email}</span>}

              <label htmlFor="familyContext">Состав семьи и возраст детей</label>
              <input
                type="text"
                id="familyContext"
                name="familyContext"
                placeholder="Например, пара и дочь 8 лет"
                value={form.familyContext}
                onChange={(e) => setForm({ ...form, familyContext: e.target.value })}
                aria-invalid={errors.familyContext ? 'true' : 'false'}
              />
              {errors.familyContext && (
                <span className={styles.error}>{errors.familyContext}</span>
              )}

              <label htmlFor="message">Опишите ваш запрос</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Что хочется изменить или поддержать?"
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                aria-invalid={errors.message ? 'true' : 'false'}
              />
              {errors.message && <span className={styles.error}>{errors.message}</span>}

              <button type="submit" className="btn btn-primary">
                Отправить заявку
              </button>

              {submitted && (
                <p className={styles.success} role="status">
                  Спасибо! Мы получили вашу заявку и скоро свяжемся с вами.
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
```