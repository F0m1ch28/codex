```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './SpecialistsPage.module.css';

const specialists = [
  {
    name: 'Людмила Краузе',
    role: 'Семейный психолог, МА',
    experience: '12 лет практики, системная терапия, автор программ для пар с разным культурным фоном.',
    education: 'Берлинский институт семейной психотерапии, курсы Мюнхенского университета.',
    image: 'https://picsum.photos/400/400?random=71'
  },
  {
    name: 'Оливер Фишер',
    role: 'Консультант по эмоциональному развитию детей',
    experience: 'Работает с родителями дошкольников и младших школьников, развивает навыки эмоционального интеллекта.',
    education: 'Университет Потсдама, сертификаты по игротерапии.',
    image: 'https://picsum.photos/400/400?random=72'
  },
  {
    name: 'Вероника Мюллер',
    role: 'Психотерапевт, специалист по кризисным состояниям',
    experience: 'Поддержка семей в период перемен, программирование ритуалов безопасности.',
    education: 'Гамбургский университет, курсы кризисной терапии в Вене.',
    image: 'https://picsum.photos/400/400?random=73'
  },
  {
    name: 'Андрей Литвин',
    role: 'Супервизор, коуч по коммуникации',
    experience: 'Помогает парам выстраивать диалог, справляться с эмоциональными перегрузками и договариваться о ценностях.',
    education: 'Высшая школа психологии Праги, обучение NVC.',
    image: 'https://picsum.photos/400/400?random=74'
  }
];

const Specialists = () => (
  <>
    <Helmet>
      <title>Специалисты — Braventy Family Academy</title>
      <meta
        name="description"
        content="Познакомьтесь со специалистами Braventy Family Academy: семейные психологи, эксперты по воспитанию и кризисной поддержке с опытом работы в Европе."
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="container">
        <span className="section-kicker">Команда</span>
        <h1 className="section-title">Наши специалисты</h1>
        <p className={styles.lead}>
          Мы объединяем профессионалов, которые видят семью как живую систему и поддерживают её в каждом шаге.
          Эксперты работают на русском и английском языках, адаптируя подход к культурному контексту.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.grid}>
          {specialists.map((specialist) => (
            <article key={specialist.name} className={styles.card}>
              <div className={styles.photo}>
                <img src={specialist.image} alt={specialist.name} loading="lazy" />
              </div>
              <div className={styles.info}>
                <h2>{specialist.name}</h2>
                <p className={styles.role}>{specialist.role}</p>
                <p>{specialist.experience}</p>
                <p className={styles.education}>
                  <strong>Образование:</strong> {specialist.education}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.promise} section`}>
      <div className="container">
        <div className={styles.promiseGrid}>
          <div>
            <h2 className="section-title">Наш подход к работе со специалистами</h2>
            <p>
              Каждый эксперт проходит регулярную супервизию, участвует во внутренних исследованиях и обновляет знания.
              Мы бережно относимся к семейным историям и обеспечиваем конфиденциальность каждого обращения.
            </p>
          </div>
          <div className={styles.promiseList}>
            <div>
              <h3>Профессиональная этика</h3>
              <p>Все специалисты следуют европейскому кодексу психолога и проходят регулярную аттестацию.</p>
            </div>
            <div>
              <h3>Командная работа</h3>
              <p>Психологи взаимодействуют между собой, чтобы выстроить интегрированное сопровождение семей.</p>
            </div>
            <div>
              <h3>Непрерывное развитие</h3>
              <p>Мы инвестируем время в обучение, конференции и исследовательские проекты, чтобы предлагать лучшее.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default Specialists;
```