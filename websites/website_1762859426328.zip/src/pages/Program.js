```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ProgramPage.module.css';

const modules = [
  {
    title: 'Модуль 1. Основания',
    duration: '2 недели',
    content: [
      'Диагностика семейных запросов и целей',
      'Введение в эмоциональную грамотность',
      'Настройка безопасной коммуникации'
    ]
  },
  {
    title: 'Модуль 2. Коммуникация',
    duration: '3 недели',
    content: [
      'Навыки активного слушания',
      'Методы согласования ожиданий',
      'Практика «пятиминутных диалогов»'
    ]
  },
  {
    title: 'Модуль 3. Совместные практики',
    duration: '3 недели',
    content: [
      'Семейные ритуалы и поддерживающие привычки',
      'Работа с конфликтами и стрессом',
      'Укрепление ресурсного состояния'
    ]
  },
  {
    title: 'Модуль 4. Закрепление и рост',
    duration: '2 недели',
    content: [
      'План развития на 3–6 месяцев',
      'Системы поддержки и сообщество',
      'Итоговая сессия с психологом'
    ]
  }
];

const Program = () => (
  <>
    <Helmet>
      <title>Программа обучения — Braventy Family Academy</title>
      <meta
        name="description"
        content="Структура программы Braventy Family Academy: модули, продолжительность, форматы, практические задания и сертификаты для семей."
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="container">
        <span className="section-kicker">Программа</span>
        <h1 className="section-title">Структура обучения и сопровождение</h1>
        <p className={styles.lead}>
          Программы построены в модульном формате. Вы двигаетесь шаг за шагом, закрепляете навыки,
          обсуждаете результаты со специалистами и получаете поддержку в удобном темпе.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.timeline}>
          {modules.map((module) => (
            <article key={module.title} className={styles.moduleCard}>
              <div className={styles.moduleHead}>
                <h2>{module.title}</h2>
                <span className={styles.duration}>{module.duration}</span>
              </div>
              <ul>
                {module.content.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.extras} section`}>
      <div className="container">
        <div className="section-head">
          <span className="section-kicker">Дополнительные элементы</span>
          <h2 className="section-title">Что помогает закрепить результат</h2>
        </div>
        <div className={styles.extraGrid}>
          <div className={styles.extraCard}>
            <h3>Супервизии и поддержка</h3>
            <p>
              Индивидуальные консультации с супервизором помогают увидеть прогресс, скорректировать фокус и поддержать мотивацию.
            </p>
          </div>
          <div className={styles.extraCard}>
            <h3>Практические упражнения</h3>
            <p>
              Вы получаете задания в формате чек-листов, аудиопрактик и совместных тренингов, чтобы применять навыки сразу после их изучения.
            </p>
          </div>
          <div className={styles.extraCard}>
            <h3>Сертификат участия</h3>
            <p>
              По завершении программы мы выдаём сертификат Braventy Family Academy с рекомендациями для дальнейшей работы.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section className={`${styles.cta} section`}>
      <div className="container">
        <div className={styles.ctaInner}>
          <div>
            <h2>Хотите начать или задать вопросы?</h2>
            <p>
              Мы ответим на любые уточнения, подберём удобный график и расскажем, как подготовиться к старту программы.
            </p>
          </div>
          <a className="btn btn-primary" href="/kontakty">
            Связаться с координатором
          </a>
        </div>
      </div>
    </section>
  </>
);

export default Program;
```