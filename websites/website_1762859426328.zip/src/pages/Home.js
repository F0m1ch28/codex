```javascript
import React, { useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import styles from './Home.module.css';

const statsData = [
  { label: 'Семей прошли программу', value: 840 },
  { label: 'Средняя оценка удовлетворённости', value: 4.8, suffix: '/5' },
  { label: 'Стран Европы в сообществе', value: 17 },
  { label: 'Онлайн-сессий в месяц', value: 120 }
];

const services = [
  {
    title: 'Отношения в паре',
    description:
      'Поддержка доверия, работа с ожиданиями и развитие осознанного диалога между партнёрами.',
    image: 'https://picsum.photos/800/600?random=21'
  },
  {
    title: 'Воспитание детей',
    description:
      'Практики позитивного воспитания, эмоциональная грамотность и семейные ритуалы.',
    image: 'https://picsum.photos/800/600?random=22'
  },
  {
    title: 'Коммуникация в семье',
    description:
      'Эффективное обсуждение сложных тем, предотвращение конфликтов и выстраивание поддержки.',
    image: 'https://picsum.photos/800/600?random=23'
  }
];

const testimonials = [
  {
    name: 'Марина и Томас из Гамбурга',
    quote:
      'После курса по семейной коммуникации мы научились слышать друг друга даже в напряжённые моменты. Атмосфера обучения тёплая и профессиональная.',
    role: 'Молодая семья, 2 ребёнка'
  },
  {
    name: 'Анна и Лео из Вены',
    quote:
      'Программа помогла создать ритуалы, которые сближают. Особенно понравились практические задания и поддержка кураторов.',
    role: 'Пара, 8 лет вместе'
  },
  {
    name: 'София и Давид из Берлина',
    quote:
      'Мы освоили инструменты эмоционального интеллекта для всей семьи. Дети стали открыто говорить о чувствах, а мы — мягче реагировать.',
    role: 'Семья с подростками'
  }
];

const teamMembers = [
  {
    name: 'Елена Маркович',
    role: 'Семейный терапевт, супервизор',
    bio: '15 лет поддержки семей с различным культурным контекстом в Европе.',
    image: 'https://picsum.photos/400/400?random=31'
  },
  {
    name: 'Лукас Рот',
    role: 'Детский психолог, игротерапевт',
    bio: 'Создаёт практики для развития эмоционального интеллекта у детей.',
    image: 'https://picsum.photos/400/400?random=32'
  },
  {
    name: 'Алина Ланге',
    role: 'Эксперт по коммуникации',
    bio: 'Обучает гибким стратегиям диалога и согласованию семейных ценностей.',
    image: 'https://picsum.photos/400/400?random=33'
  }
];

const projects = [
  {
    title: 'Воркшоп «Семейные разговоры»',
    category: 'Коммуникация',
    image: 'https://picsum.photos/1200/800?random=41'
  },
  {
    title: 'Онлайн-марафон «Родительская эмпатия»',
    category: 'Воспитание',
    image: 'https://picsum.photos/1200/800?random=42'
  },
  {
    title: 'Ретрит «Пара в ресурсе»',
    category: 'Отношения',
    image: 'https://picsum.photos/1200/800?random=43'
  },
  {
    title: 'Антикризисные встречи',
    category: 'Кризисы',
    image: 'https://picsum.photos/1200/800?random=44'
  }
];

const faqItems = [
  {
    question: 'Подходит ли программа для семей из разных стран?',
    answer:
      'Да, наши специалисты работают с многоязычными семьями по всей Европе, учитывая культурный контекст и индивидуальные особенности.'
  },
  {
    question: 'Можно ли совмещать обучение с плотным графиком?',
    answer:
      'Мы строим обучение в гибком формате: короткие видео, интерактивные встречи и домашние задания, которые легко адаптируются под ваш ритм.'
  },
  {
    question: 'Как подключиться к живым сессиям?',
    answer:
      'После регистрации вы получите доступ в личный кабинет с расписанием, ссылками на сессии и рекомендациями по подготовке.'
  },
  {
    question: 'Есть ли поддержка после завершения курса?',
    answer:
      'Да, мы предлагаем закрытое сообщество выпускников, ежемесячные встречи и дополнительные материалы для продолжения работы.'
  }
];

const blogPosts = [
  {
    title: 'Как договориться о семейных правилах и сохранить тёплые отношения',
    date: '12 апреля 2024',
    image: 'https://picsum.photos/800/600?random=51'
  },
  {
    title: 'Пять практик для мягкого перехода детей к подростковому возрасту',
    date: '28 марта 2024',
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    title: 'Ритуалы поддержки: что помогает парам в условиях нагрузки',
    date: '15 марта 2024',
    image: 'https://picsum.photos/800/600?random=53'
  }
];

const Home = () => {
  const [counts, setCounts] = useState(statsData.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const statsRef = useRef(null);
  const observer = useRef(null);

  useEffect(() => {
    observer.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            statsData.forEach((stat, index) => {
              const duration = 1600;
              const frameRate = 16;
              const totalFrames = duration / frameRate;
              let frame = 0;
              const counter = setInterval(() => {
                frame += 1;
                const progress = Math.min(frame / totalFrames, 1);
                const currentValue = Math.round(stat.value * progress * 10) / 10;
                setCounts((prev) => {
                  const next = [...prev];
                  next[index] = currentValue;
                  return next;
                });
                if (progress === 1) clearInterval(counter);
              }, frameRate);
            });
            observer.current.disconnect();
          }
        });
      },
      { threshold: 0.3 }
    );
    if (statsRef.current) {
      observer.current.observe(statsRef.current);
    }
    return () => observer.current && observer.current.disconnect();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const filteredProjects =
    selectedCategory === 'Все'
      ? projects
      : projects.filter((project) => project.category === selectedCategory);

  return (
    <>
      <Helmet>
        <title>Braventy Family Academy — строим крепкие семейные связи</title>
        <meta
          name="description"
          content="Braventy Family Academy помогает семьям в Европе укреплять отношения, развивать навыки общения и заботиться о ребёнке с поддержкой психологов и тёплой методики."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <motion.span
                className={styles.heroEyebrow}
                initial={{ opacity: 0, y: -12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                Для семей, которые ценят близость
              </motion.span>
              <motion.h1
                className={styles.heroTitle}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.1 }}
              >
                Строим крепкие семейные связи
              </motion.h1>
              <motion.p
                className={styles.heroSubtitle}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, delay: 0.2 }}
              >
                Онлайн-академия для пар и семей в Европе. Мы соединяем научно
                обоснованную психологию с тёплой, заботливой атмосферой,
                чтобы вы могли развивать отношения уже сегодня.
              </motion.p>
              <motion.div
                className={styles.heroActions}
                initial={{ opacity: 0, y: 28 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.3 }}
              >
                <a className="btn btn-primary" href="#programs">
                  Присоединиться к курсу
                </a>
                <a className="btn btn-ghost" href="#stories">
                  Истории семей
                </a>
              </motion.div>
            </div>
            <motion.div
              className={styles.heroImageWrapper}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
            >
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Семья, обнимающаяся в уютной гостиной"
                className={styles.heroImage}
                loading="lazy"
              />
              <div className={styles.heroBadge}>
                <span>Психологи с европейской практикой</span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className={`${styles.intro} section`}>
        <div className="container">
          <div className={styles.introGrid}>
            <div>
              <h2 className="section-title">Braventy Family Academy</h2>
              <p>
                Мы создаём пространство, где каждая семья может безопасно обсудить значимые темы,
                освоить новые инструменты и почувствовать поддержку специалистов. Наши программы
                ведут семейные психологи с опытом работы в мультикультурной Европе.
              </p>
              <p>
                Академия объединяет онлайн-сессии, практические упражнения, интерактивные материалы
                и живое сообщество семей, которые ценят уважение, эмпатию и совместное развитие.
              </p>
            </div>
            <div className={styles.introCard}>
              <h3>Сферы внимания</h3>
              <ul>
                <li>Согласование семейных ценностей</li>
                <li>Работа с эмоциями и стрессом</li>
                <li>Переходные периоды и кризисы</li>
                <li>Ресурсные ритуалы и поддержка</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section ref={statsRef} className={`${styles.stats} section`}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {counts[index]}
                  {stat.suffix || ''}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="programs" className={`${styles.services} section`}>
        <div className="container">
          <div className="section-head">
            <span className="section-kicker">Наши программы</span>
            <h2 className="section-title">Забота о каждом аспекте семейной жизни</h2>
            <p>
              Подберите направление, которое поможет вашей семье почувствовать уверенность,
              наладить диалог и укрепить взаимную поддержку.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div className={styles.serviceImageWrapper}>
                  <img
                    src={service.image}
                    alt={`Курс: ${service.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.serviceBody}>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <a href="/kursy" className={styles.serviceLink}>
                    Узнать больше
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.process} section`}>
        <div className="container">
          <div className="section-head">
            <span className="section-kicker">Как проходит обучение</span>
            <h2 className="section-title">Методология Braventy</h2>
            <p>
              Мы соединяем глубокую психологическую экспертизу, живое общение и практические задания,
              чтобы поддержать устойчивый результат.
            </p>
          </div>
          <div className={styles.processGrid}>
            {[
              {
                step: '01',
                title: 'Диагностика запросов',
                text: 'Стартовая консультация и анализ семейного контекста.'
              },
              {
                step: '02',
                title: 'Интерактивные модули',
                text: 'Видео, подкасты, упражнения и живые встречи.'
              },
              {
                step: '03',
                title: 'Практика и обратная связь',
                text: 'Домашние задания с комментариями специалистов.'
              },
              {
                step: '04',
                title: 'Поддержка после курса',
                text: 'Сообщество и дополнительные материалы для закрепления.'
              }
            ].map((item) => (
              <div key={item.step} className={styles.processCard}>
                <span className={styles.processStep}>{item.step}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.why} section`}>
        <div className="container">
          <div className={styles.whyGrid}>
            <div>
              <span className="section-kicker">Почему выбирают нас</span>
              <h2 className="section-title">Поддержка, которой можно доверять</h2>
              <p>
                Команда Braventy Family Academy помогает семьям находить решения,
                сохраняя уважение к индивидуальности каждого участника и уникальному опыту.
              </p>
            </div>
            <ul className={styles.whyList}>
              <li>
                <h3>Европейская экспертиза</h3>
                <p>Сертифицированные психологи и терапевты с международным опытом.</p>
              </li>
              <li>
                <h3>Гибкие форматы</h3>
                <p>Онлайн-встречи, самостоятельные задания и поддержка в удобное время.</p>
              </li>
              <li>
                <h3>Тёплая атмосфера</h3>
                <p>Безопасное пространство для обсуждения чувств и поиска решений.</p>
              </li>
              <li>
                <h3>Практичность</h3>
                <p>Понятные инструменты, которые легко внедрить в семейную жизнь уже сейчас.</p>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section id="stories" className={`${styles.testimonials} section`}>
        <div className="container">
          <div className="section-head">
            <span className="section-kicker">Истории семей</span>
            <h2 className="section-title">Тёплые отзывы наших участников</h2>
          </div>
          <div className={styles.testimonialWrapper}>
            {testimonials.map((testimonial, index) => (
              <div
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.active : ''
                }`}
                aria-hidden={index !== activeTestimonial}
              >
                <p className={styles.testimonialQuote}>“{testimonial.quote}”</p>
                <div>
                  <p className={styles.testimonialName}>{testimonial.name}</p>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </div>
              </div>
            ))}
          </div>
          <div className={styles.testimonialControls}>
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.testimonialDot} ${
                  index === activeTestimonial ? styles.dotActive : ''
                }`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Показать отзыв №${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.team} section`}>
        <div className="container">
          <div className="section-head">
            <span className="section-kicker">Наша команда</span>
            <h2 className="section-title">Люди, которые сопровождают ваш путь</h2>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img
                    src={member.image}
                    alt={`Психолог ${member.name}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.teamBody}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p className={styles.teamBio}>{member.bio}</p>
                  <a href="/specialisty" className={styles.teamLink}>
                    Подробнее о специалистах
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.projects} section`}>
        <div className="container">
          <div className="section-head">
            <span className="section-kicker">Практики и события</span>
            <h2 className="section-title">Совместные проекты для семей</h2>
            <p>
              Выбирайте формат, который откликается вашей семье: от тёплых онлайн-встреч до глубинных ретритов.
            </p>
          </div>
          <div className={styles.projectFilters}>
            {['Все', 'Коммуникация', 'Воспитание', 'Отношения', 'Кризисы'].map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterButton} ${
                  selectedCategory === category ? styles.filterActive : ''
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img
                  src={project.image}
                  alt={`${project.category}: ${project.title}`}
                  loading="lazy"
                />
                <div className={styles.projectBody}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.faq} section`}>
        <div className="container">
          <div className="section-head">
            <span className="section-kicker">FAQ</span>
            <h2 className="section-title">Частые вопросы</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>+</span>
                </summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blog} section`}>
        <div className="container">
          <div className="section-head">
            <span className="section-kicker">Блог академии</span>
            <h2 className="section-title">Новые материалы и инсайты</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img
                  src={post.image}
                  alt={post.title}
                  loading="lazy"
                />
                <div className={styles.blogBody}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <a href="/programma" className={styles.blogLink}>
                    Читать дальше
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.cta} section`}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Готовы сделать следующий шаг?</h2>
              <p>
                Расскажите нам о вашей семье, и мы подберём программу, которая поможет укрепить отношения,
                наполнить ежедневное общение смыслом и создать пространство заботы.
              </p>
            </div>
            <a className="btn btn-primary" href="/kontakty">
              Записаться на консультацию
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
```