```javascript
import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ServicesPage.module.css';

const courseCategories = [
  {
    title: 'Отношения в паре',
    description:
      'Работа над доверием, выстраивание эмоциональной близости, поддержка в периоды изменений и переездов.',
    modules: ['Совместное планирование', 'Язык эмоций', 'Ритуалы поддержки']
  },
  {
    title: 'Воспитание детей',
    description:
      'Методики позитивного воспитания, эмоциональная грамотность, настройка семейных правил.',
    modules: ['Возрастные особенности', 'Диалог с подростком', 'Тон и границы']
  },
  {
    title: 'Семейная динамика',
    description:
      'Создание общих ценностей, распределение ролей, работа с семейной историей и ресурсами.',
    modules: ['Семейная карта ресурсов', 'Переосмысление традиций', 'Командные решения']
  },
  {
    title: 'Кризисные ситуации',
    description:
      'Поддержка в стрессовых периодах: переезды, новые жизненные этапы, профессиональные вызовы.',
    modules: ['Стратегии восстановления', 'Практики стабильности', 'Антикризисные встречи']
  }
];

const Services = () => (
  <>
    <Helmet>
      <title>Курсы для семей — Braventy Family Academy</title>
      <meta
        name="description"
        content="Выберите курс Braventy Family Academy: отношения в паре, воспитание детей, семейная динамика, поддержка в кризисных ситуациях. Онлайн программы для семей в Европе."
      />
    </Helmet>
    <section className={`${styles.hero} section`}>
      <div className="container">
        <span className="section-kicker">Курсы</span>
        <h1 className="section-title">Программы, которые поддерживают семью</h1>
        <p className={styles.lead}>
          Каждый курс строится на сочетании теории, практических упражнений и живого общения с
          психологами. Мы адаптируем программу под контекст семьи и сопровождаем на каждом этапе.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container">
        <div className={styles.categoryGrid}>
          {courseCategories.map((category) => (
            <article key={category.title} className={styles.categoryCard}>
              <h2>{category.title}</h2>
              <p>{category.description}</p>
              <ul>
                {category.modules.map((module) => (
                  <li key={module}>{module}</li>
                ))}
              </ul>
              <a href="/programma" className={styles.link}>
                Познакомиться со структурой
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.features} section`}>
      <div className="container">
        <div className="section-head">
          <span className="section-kicker">Формат</span>
          <h2 className="section-title">Что входит в каждую программу</h2>
        </div>
        <div className={styles.featuresGrid}>
          {[
            {
              title: 'Личные консультации',
              text: 'Регулярные встречи с психологом для обсуждения прогресса и адаптации заданий.'
            },
            {
              title: 'Онлайн-лаборатории',
              text: 'Групповые интерактивы, где семьи делятся опытом и поддержкой.'
            },
            {
              title: 'Домашние практики',
              text: 'Пошаговые упражнения, которые помогают внедрять изменения в повседневность.'
            },
            {
              title: 'Ресурсная библиотека',
              text: 'Видео, подкасты и чек-листы, доступные в личном кабинете 24/7.'
            }
          ].map((item) => (
            <div key={item.title} className={styles.featureCard}>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className={`${styles.cta} section`}>
      <div className="container">
        <div className={styles.ctaInner}>
          <div>
            <h2>Нужна помощь в выборе программы?</h2>
            <p>
              Оставьте заявку, и мы подберём курс, который поможет вашей семье чувствовать устойчивость и вдохновение.
            </p>
          </div>
          <a className="btn btn-secondary" href="/kontakty">
            Связаться с нами
          </a>
        </div>
      </div>
    </section>
  </>
);

export default Services;
```