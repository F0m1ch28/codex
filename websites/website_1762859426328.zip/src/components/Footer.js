```javascript
import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className="container">
      <div className={styles.grid}>
        <div>
          <h4 className={styles.title}>Braventy Family Academy</h4>
          <p className={styles.description}>
            Партнёр в развитии семейного благополучия, основанный на современной психологии,
            эмпатии и практических инструментах для ежедневной жизни.
          </p>
        </div>
        <div>
          <h5 className={styles.subtitle}>Навигация</h5>
          <ul className={styles.list}>
            <li><NavLink to="/o-nas">О нас</NavLink></li>
            <li><NavLink to="/kursy">Курсы</NavLink></li>
            <li><NavLink to="/programma">Программа</NavLink></li>
            <li><NavLink to="/specialisty">Специалисты</NavLink></li>
            <li><NavLink to="/kontakty">Контакты</NavLink></li>
          </ul>
        </div>
        <div>
          <h5 className={styles.subtitle}>Правовая информация</h5>
          <ul className={styles.list}>
            <li><NavLink to="/usloviya">Пользовательское соглашение</NavLink></li>
            <li><NavLink to="/konfidentsialnost">Политика конфиденциальности</NavLink></li>
          </ul>
        </div>
        <div>
          <h5 className={styles.subtitle}>Контакты</h5>
          <ul className={styles.contactList}>
            <li>
              <span className={styles.contactLabel}>Адрес:</span>
              <span>Kurfürstendamm 156, 10709 Berlin, Germany</span>
            </li>
            <li>
              <span className={styles.contactLabel}>Телефон:</span>
              <a href="tel:+493056789012">+49 30 5678 9012</a>
            </li>
            <li>
              <span className={styles.contactLabel}>Email:</span>
              <a href="mailto:info@braventyfamilyacademy.com">info@braventyfamilyacademy.com</a>
            </li>
          </ul>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} Braventy Family Academy. Все права защищены.</p>
        <p className={styles.made}>
          Создано с заботой о семьях в Европе.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;
```