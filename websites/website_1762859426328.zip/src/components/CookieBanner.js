```javascript
import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('bfa_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('bfa_cookie_consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('bfa_cookie_consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <aside className={styles.banner} role="dialog" aria-live="polite">
      <div className="container">
        <div className={styles.content}>
          <p className={styles.text}>
            Мы используем файлы cookies, чтобы сделать обучение комфортным и безопасным.
            Продолжая пользоваться сайтом, вы соглашаетесь с нашей политикой конфиденциальности.
          </p>
          <div className={styles.actions}>
            <button className="btn btn-primary" onClick={handleAccept}>
              Принять
            </button>
            <button className="btn btn-ghost" onClick={handleDecline}>
              Настроить позже
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default CookieBanner;
```