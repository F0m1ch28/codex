document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("primary-navigation");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", String(!expanded));
      nav.classList.toggle("open");
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector(".cookie-accept");
  const declineBtn = document.querySelector(".cookie-decline");
  const consentKey = "gesCookieConsent";

  if (cookieBanner && acceptBtn && declineBtn) {
    const consentValue = localStorage.getItem(consentKey);
    if (!consentValue) {
      setTimeout(() => cookieBanner.classList.add("visible"), 600);
    }

    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      cookieBanner.classList.remove("visible");
    });

    declineBtn.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      cookieBanner.classList.remove("visible");
    });
  }

  const postList = document.getElementById("post-list");
  const searchInput = document.getElementById("post-search");
  const filterButtons = document.querySelectorAll(".filter-tags button");

  function filterPosts() {
    if (!postList) return;
    const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
    let activeCategory = "all";
    filterButtons.forEach((btn) => {
      if (btn.classList.contains("active")) {
        activeCategory = btn.dataset.filter;
      }
    });

    const posts = postList.querySelectorAll(".card");
    posts.forEach((post) => {
      const category = post.dataset.category;
      const keywords = post.dataset.keywords || "";
      const matchesCategory = activeCategory === "all" || category === activeCategory;
      const matchesQuery = !query || post.textContent.toLowerCase().includes(query) || keywords.includes(query);
      if (matchesCategory && matchesQuery) {
        post.style.display = "";
      } else {
        post.style.display = "none";
      }
    });
  }

  if (filterButtons.length > 0) {
    filterButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        filterButtons.forEach((button) => button.classList.remove("active"));
        btn.classList.add("active");
        filterPosts();
      });
    });
  }

  if (searchInput) {
    searchInput.addEventListener("input", filterPosts);
  }

  const contactForm = document.getElementById("contactForm");
  const formFeedback = document.getElementById("formFeedback");

  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const name = contactForm.querySelector("#name");
      const email = contactForm.querySelector("#email");
      const message = contactForm.querySelector("#message");

      let valid = true;
      if (!name.value.trim()) {
        valid = false;
      }
      if (!email.value.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        valid = false;
      }
      if (!message.value.trim()) {
        valid = false;
      }

      if (valid) {
        if (formFeedback) {
          formFeedback.textContent = "";
        }
        window.location.href = "thanks.html";
      } else {
        if (formFeedback) {
          formFeedback.textContent = "Please complete all fields with valid information before submitting.";
        }
      }
    });
  }
});