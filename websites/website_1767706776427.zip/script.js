(function () {
    const consentKey = "cachedkugConsent";
    const banner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-accept");
    const declineBtn = document.querySelector(".cookie-decline");

    function hideBanner() {
        if (banner) {
            banner.classList.remove("active");
        }
    }

    function showBanner() {
        if (banner) {
            banner.classList.add("active");
        }
    }

    if (!localStorage.getItem(consentKey)) {
        showBanner();
    }

    if (acceptBtn) {
        acceptBtn.addEventListener("click", function () {
            localStorage.setItem(consentKey, "accepted");
            hideBanner();
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener("click", function () {
            localStorage.setItem(consentKey, "declined");
            hideBanner();
        });
    }

    const dataButtons = document.querySelectorAll("[data-scenario]");
    const dataRows = document.querySelectorAll("[data-metric]");
    const metricDetails = {
        portugal: {
            resilience: 78,
            sustainability: 82,
            innovation: 69,
            infrastructure: 74
        },
        germany: {
            resilience: 88,
            sustainability: 91,
            innovation: 85,
            infrastructure: 90
        },
        netherlands: {
            resilience: 84,
            sustainability: 89,
            innovation: 88,
            infrastructure: 86
        },
        france: {
            resilience: 81,
            sustainability: 87,
            innovation: 82,
            infrastructure: 83
        }
    };

    function updateMetrics(region) {
        dataRows.forEach(function (row) {
            const metric = row.getAttribute("data-metric");
            const value = metricDetails[region][metric];
            const bar = row.querySelector(".chart-bar");
            const label = row.querySelector("small");
            if (bar) {
                bar.style.width = value + "%";
            }
            if (label) {
                label.textContent = value + " / 100";
            }
        });
    }

    if (dataButtons.length) {
        dataButtons.forEach(function (btn) {
            btn.addEventListener("click", function () {
                const region = btn.getAttribute("data-scenario");
                dataButtons.forEach(function (el) { el.classList.remove("active"); });
                btn.classList.add("active");
                updateMetrics(region);
            });
        });
        const firstButton = dataButtons[0];
        if (firstButton) {
            firstButton.classList.add("active");
            updateMetrics(firstButton.getAttribute("data-scenario"));
        }
    }

    const filters = document.querySelectorAll("[data-filter]");
    const tableRows = document.querySelectorAll("[data-region]");
    if (filters.length) {
        filters.forEach(function (filter) {
            filter.addEventListener("click", function () {
                const target = filter.getAttribute("data-filter");
                filters.forEach(function (el) { el.classList.remove("active"); });
                filter.classList.add("active");
                tableRows.forEach(function (row) {
                    const region = row.getAttribute("data-region");
                    if (target === "all" || region === target) {
                        row.style.display = "";
                    } else {
                        row.style.display = "none";
                    }
                });
            });
        });
    }

    const accordions = document.querySelectorAll(".accordion-header");
    accordions.forEach(function (header) {
        header.addEventListener("click", function () {
            const content = header.nextElementSibling;
            const isActive = header.classList.contains("active");
            accordions.forEach(function (other) {
                other.classList.remove("active");
                const otherContent = other.nextElementSibling;
                if (otherContent) {
                    otherContent.style.maxHeight = null;
                }
            });
            if (!isActive && content) {
                header.classList.add("active");
                content.style.maxHeight = content.scrollHeight + "px";
            }
        });
    });

    const heroPanel = document.querySelector(".hero-data-panel");
    if (heroPanel) {
        setTimeout(function () {
            heroPanel.style.transform = "translateY(0)";
            heroPanel.style.opacity = "1";
        }, 200);
    }

    window.addEventListener("load", function () {
        document.body.classList.add("page-loaded");
    });
})();