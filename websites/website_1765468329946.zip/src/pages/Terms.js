```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

function Terms() {
  return (
    <>
      <SEO
        title="Terms of Service"
        description="Terms of Service for IT Learning Hub, outlining usage guidelines and learner responsibilities."
      />
      <section className={styles.wrapper}>
        <div className="container">
          <h1 className={styles.title}>Terms of Service</h1>
          <p className={styles.updated}>Last updated: 15 April 2024</p>
          <div className={styles.section}>
            <h2>1. Overview</h2>
            <p>
              IT Learning Hub (&ldquo;we&rdquo;, &ldquo;us&rdquo;) delivers IT education programmes from our headquarters in
              Brussels. By accessing our website, enrolling in any programme, or engaging with our services, you agree to these
              Terms of Service.
            </p>
          </div>
          <div className={styles.section}>
            <h2>2. Eligibility</h2>
            <p>
              You must be at least 18 years old or have consent from a legal guardian to participate in our programmes. You
              agree to provide accurate information during registration and to keep your details up to date.
            </p>
          </div>
          <div className={styles.section}>
            <h2>3. Learning materials</h2>
            <p>
              Learning materials, including videos, texts, slides, and project briefs, are provided for personal learning only.
              You may not reproduce, distribute, or publicly display our materials without written permission.
            </p>
          </div>
          <div className={styles.section}>
            <h2>4. Conduct</h2>
            <ul>
              <li>Engage respectfully with instructors, mentors, and peers.</li>
              <li>Uphold academic integrity by submitting original work and acknowledging contributions from others.</li>
              <li>Comply with Belgian laws and regulations when using our services.</li>
            </ul>
          </div>
          <div className={styles.section}>
            <h2>5. Liability</h2>
            <p>
              We aim to deliver accurate content and supportive services. However, outcomes such as employment opportunities
              depend on multiple factors. We do not guarantee specific career results.
            </p>
          </div>
          <div className={styles.section}>
            <h2>6. Contact</h2>
            <p>
              Questions about these terms can be directed to <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Terms;
```