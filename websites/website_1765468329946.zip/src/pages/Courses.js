```javascript
import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Courses.module.css';

const COURSES = [
  {
    name: 'Frontend Engineering',
    duration: '12 weeks | Part-time or immersive',
    focus: ['React & ecosystem', 'Design systems', 'Accessibility', 'Testing & QA'],
    outcomes: [
      'Design and ship accessible interfaces aligned with EU standards',
      'Architect component-driven codebases that scale',
      'Automate regression testing pipelines with modern tooling'
    ],
    image: 'https://picsum.photos/800/600?random=51'
  },
  {
    name: 'Backend Engineering',
    duration: '14 weeks | Hybrid delivery',
    focus: ['Node.js & TypeScript', 'Microservices', 'Databases', 'Cloud deployment'],
    outcomes: [
      'Design resilient APIs with strong documentation',
      'Implement asynchronous patterns and message queues',
      'Deploy and monitor services across European regions'
    ],
    image: 'https://picsum.photos/800/600?random=52'
  },
  {
    name: 'Data Science & AI',
    duration: '16 weeks | Project-led',
    focus: ['Python & statistics', 'ML modelling', 'MLOps', 'Ethical AI'],
    outcomes: [
      'Build end-to-end data pipelines with reproducibility',
      'Deliver interpretable insights using advanced visualisation techniques',
      'Deploy models responsibly with monitoring and governance guardrails'
    ],
    image: 'https://picsum.photos/800/600?random=53'
  },
  {
    name: 'DevOps & Cloud Automation',
    duration: '10 weeks | On-campus + remote',
    focus: ['CI/CD', 'Infrastructure as Code', 'Observability', 'SRE practices'],
    outcomes: [
      'Automate environments with Terraform and Kubernetes',
      'Create CI/CD workflows with strong quality gates',
      'Implement observability dashboards for proactive incident response'
    ],
    image: 'https://picsum.photos/800/600?random=54'
  },
  {
    name: 'Cybersecurity Engineering',
    duration: '14 weeks | Scenario-based',
    focus: ['Threat detection', 'Security operations', 'Governance', 'Incident response'],
    outcomes: [
      'Develop blue-team playbooks for critical infrastructure',
      'Conduct security assessments aligned with EU regulations',
      'Coordinate incident simulations with cross-functional teams'
    ],
    image: 'https://picsum.photos/800/600?random=55'
  }
];

function Courses() {
  const [selected, setSelected] = useState(0);

  return (
    <>
      <SEO
        title="Courses"
        description="Explore IT Learning Hub courses covering frontend, backend, data science, DevOps, and cybersecurity with practical, career-focused outcomes."
      />
      <section className={styles.hero}>
        <div className="container">
          <div>
            <h1>Courses engineered for real teams, real projects, and real impact.</h1>
            <p>
              Our programmes balance strategic depth and hands-on execution. Choose the track that aligns with your ambitions
              and learn from mentors who actively deliver in Belgian tech organisations.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.courses}>
        <div className="container">
          <div className={styles.selector}>
            <div className={styles.courseList} role="tablist" aria-label="Course selection">
              {COURSES.map((course, index) => (
                <button
                  key={course.name}
                  type="button"
                  role="tab"
                  aria-selected={selected === index}
                  className={`${styles.courseTab} ${selected === index ? styles.active : ''}`}
                  onClick={() => setSelected(index)}
                >
                  {course.name}
                </button>
              ))}
            </div>
            <article className={styles.courseCard}>
              <img
                src={COURSES[selected].image}
                alt={`${COURSES[selected].name} course illustration`}
                loading="lazy"
              />
              <div className={styles.courseContent}>
                <p className={styles.duration}>{COURSES[selected].duration}</p>
                <h2>{COURSES[selected].name}</h2>
                <div className={styles.focus}>
                  <h3>Competency pillars</h3>
                  <ul>
                    {COURSES[selected].focus.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div className={styles.outcomes}>
                  <h3>What you accomplish</h3>
                  <ul>
                    {COURSES[selected].outcomes.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </article>
          </div>
        </div>
      </section>
    </>
  );
}

export default Courses;
```