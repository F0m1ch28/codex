```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Career.module.css';

const SERVICES = [
  {
    title: 'Career strategy labs',
    detail:
      'Work with career strategists to position your experience, clarify your value proposition, and map interview targets.',
    icon: '🧭'
  },
  {
    title: 'Portfolio & code reviews',
    detail:
      'Receive structured feedback on your repositories, case studies, and storytelling so recruiters immediately see your impact.',
    icon: '🗂️'
  },
  {
    title: 'Interview preparation',
    detail:
      'Participate in technical and behavioural mock interviews with real practitioners, complete with detailed scorecards.',
    icon: '🎤'
  },
  {
    title: 'Hiring network access',
    detail:
      'Engage with partner companies through demo days, talent showcases, and alumni introductions throughout Belgium.',
    icon: '🤝'
  }
];

const SUCCESS = [
  { metric: '82%', text: 'of learners transition into a new role or promotion within six months of graduation.' },
  { metric: '4.7 / 5', text: 'average rating for our job-search support from alumni across all pathways.' },
  { metric: '140+', text: 'partner hiring managers who trust IT Learning Hub talent pipelines.' }
];

function Career() {
  return (
    <>
      <SEO
        title="Career Support"
        description="IT Learning Hub offers career coaching, portfolio reviews, interview practice, and talent network access to launch your tech career."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Career support designed for Belgium&apos;s evolving tech roles.</h1>
          <p>
            From day one, your learning roadmap includes career milestones. We believe in aligning your skill development with a
            clear market narrative, giving you confidence when speaking to employers.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.cards}>
            {SERVICES.map((service) => (
              <article key={service.title} className={styles.card}>
                <span aria-hidden="true">{service.icon}</span>
                <h2>{service.title}</h2>
                <p>{service.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.success}>
        <div className="container">
          <div className={styles.successGrid}>
            {SUCCESS.map((item) => (
              <div key={item.metric} className={styles.successCard}>
                <span>{item.metric}</span>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Career;
```