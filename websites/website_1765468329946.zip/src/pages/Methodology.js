```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Methodology.module.css';

const STAGES = [
  {
    title: 'Discover & personalise',
    description:
      'Analyse individual goals, map transferable skills, and co-create a learning path with measurable milestones.',
    detail: 'We deliver diagnostic assessments and onboarding sessions involving your mentors and our coaching team.'
  },
  {
    title: 'Experience & iterate',
    description:
      'Engage in weekly sprints with real project briefs. Receive structured feedback to help you iterate towards excellence.',
    detail: 'Peer reviews, mentor walkthroughs, and learning journals ensure you internalise feedback and progress steadily.'
  },
  {
    title: 'Showcase & storytell',
    description:
      'Translate projects into compelling narratives that highlight impact, decision-making, and collaboration.',
    detail:
      'Career strategists help refine portfolios, Git repositories, and presentation skills to impress hiring panels.'
  },
  {
    title: 'Launch & sustain',
    description:
      'Leverage our talent network and alumni community, and continue skill maintenance with advanced clinics.',
    detail:
      'We organise hiring events, mentorship circles, and refresh modules so you stay relevant after programme completion.'
  }
];

const PILLARS = [
  {
    heading: 'Human-centered mentorship',
    text: 'Every learner has a dedicated mentor, plus a supporting cast of instructors who review work asynchronously.'
  },
  {
    heading: 'Industry-grade tooling',
    text: 'Work within the toolchains used by engineering and data teams across Belgium, from GitLab to Azure and Databricks.'
  },
  {
    heading: 'Evidence-based feedback',
    text: 'Rubrics are aligned with role expectations, giving you clarity on how to elevate your craft with each submission.'
  },
  {
    heading: 'Career immersion',
    text: 'Mock interviews, demo days, and partner events simulate the pressure and nuance of real hiring conversations.'
  }
];

function Methodology() {
  return (
    <>
      <SEO
        title="Our Methodology"
        description="Discover the learning methodology at IT Learning Hub, combining personalised coaching, industry projects, and career immersion."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>We teach the way modern tech teams work: collaboratively, iteratively, and with purpose.</h1>
          <p>
            Our methodology is anchored in continuous feedback and practical accountability. Learners build real products,
            analyse real datasets, and manage real incidents within a psychologically safe environment guided by experts.
          </p>
        </div>
      </section>

      <section className={styles.pillars}>
        <div className="container">
          <h2>Our core principles</h2>
          <div className={styles.pillarGrid}>
            {PILLARS.map((pillar) => (
              <article key={pillar.heading} className={styles.pillarCard}>
                <h3>{pillar.heading}</h3>
                <p>{pillar.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.stages}>
        <div className="container">
          <h2>Stage-by-stage journey</h2>
          <div className={styles.stageList}>
            {STAGES.map((stage, index) => (
              <article key={stage.title} className={styles.stageItem}>
                <div className={styles.stageNumber}>{index + 1}</div>
                <div>
                  <h3>{stage.title}</h3>
                  <p>{stage.description}</p>
                  <span>{stage.detail}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Methodology;
```