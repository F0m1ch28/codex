```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './About.module.css';

const VALUES = [
  {
    title: 'Learner-first mindset',
    description:
      'We obsess over how people learn, applying cognitive science and continuous feedback to design experiences that stick.',
    image: 'https://picsum.photos/600/400?random=41'
  },
  {
    title: 'Cross-functional collaboration',
    description:
      'We create interdisciplinary cohorts where developers, analysts, and strategists learn to collaborate effectively.',
    image: 'https://picsum.photos/600/400?random=42'
  },
  {
    title: 'Inclusive Belgian community',
    description:
      'Our learners represent over 30 nationalities living in Belgium. We cultivate an environment where every voice is valued.',
    image: 'https://picsum.photos/600/400?random=43'
  }
];

const TIMELINE = [
  {
    year: '2016',
    milestone: 'Founded in Brussels',
    description:
      'Created by Belgian engineers and educators to close the gap between academic theory and workplace expectations.'
  },
  {
    year: '2018',
    milestone: 'Expanded across Belgium',
    description:
      'Opened satellite hubs in Antwerp and Ghent, enabling hybrid delivery and deeper regional partnerships.'
  },
  {
    year: '2020',
    milestone: 'Launched remote labs',
    description:
      'Introduced live virtual labs and remote-ready collaboration spaces while maintaining immersive coaching quality.'
  },
  {
    year: '2023',
    milestone: 'Recognised by industry bodies',
    description:
      'Honoured by Agoria for advancing digital talent and partnered with the Flemish AI Center on specialised initiatives.'
  }
];

function About() {
  return (
    <>
      <SEO
        title="About Us"
        description="Learn about IT Learning Hub, Belgium's dedicated partner for industry-aligned IT education, mentorship, and career transformation."
      />
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <h1>Our mission is to unlock confident, job-ready tech professionals in Belgium.</h1>
            <p>
              IT Learning Hub is a Brussels-based education company focused on building practical skills and resilient careers.
              We design every programme in collaboration with industry partners who understand the challenges of modern tech
              teams. Our community thrives on curiosity, inclusivity, and lifelong learning.
            </p>
          </div>
          <div className={styles.heroImage}>
            <img
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1400&q=80"
              alt="IT Learning Hub campus in Brussels"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Our DNA</p>
            <h2 className="section-title">We combine rigorous learning design with real-world expectations</h2>
            <p className="section-subtitle">
              Our team blends educators, engineers, data scientists, and career strategists. Together, we design and refine
              programmes that align to Belgium&apos;s tech landscape.
            </p>
          </header>
          <div className={styles.valuesGrid}>
            {VALUES.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <img src={value.image} alt={value.title} loading="lazy" />
                <div>
                  <h3>{value.title}</h3>
                  <p>{value.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.timelineSection}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Our story</p>
            <h2 className="section-title">Growing with Belgium&apos;s bold tech ambitions</h2>
          </header>
          <div className={styles.timeline}>
            {TIMELINE.map((item) => (
              <div key={item.year} className={styles.timelineItem}>
                <div className={styles.year}>{item.year}</div>
                <div>
                  <h3>{item.milestone}</h3>
                  <p>{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.impact}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Impact across Belgium</p>
            <h2 className="section-title">A community spanning industries, languages, and experiences</h2>
          </header>
          <div className={styles.impactGrid}>
            <div className={styles.impactCard}>
              <span>65%</span>
              <p>Participants identify as career changers embarking on their second or third professional chapter.</p>
            </div>
            <div className={styles.impactCard}>
              <span>52%</span>
              <p>Learners collaborate in both English and French, reflecting Belgium&apos;s dynamic tech culture.</p>
            </div>
            <div className={styles.impactCard}>
              <span>90%</span>
              <p>Graduates highlight mentorship quality as the differentiator in their learning experience.</p>
            </div>
            <div className={styles.impactCard}>
              <span>30+</span>
              <p>Industry partners contribute briefs, mentorship, and interview opportunities every quarter.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;
```