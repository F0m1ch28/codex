```javascript
import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import styles from './Home.module.css';

const STATS = [
  { label: 'Learners supported', value: 1200 },
  { label: 'Industry mentors', value: 85 },
  { label: 'Career pathways', value: 14 },
  { label: 'Live project labs per year', value: 50 }
];

const BENEFITS = [
  {
    title: 'Practical-first curriculum',
    description:
      'Each module pivots around real case studies sourced from Belgian companies, ensuring immediate applicability.',
    icon: '🧠'
  },
  {
    title: 'Mentors from leading teams',
    description:
      'Skilled practitioners from Brussels, Antwerp, and Ghent guide you through modern toolchains and proven workflows.',
    icon: '🤝'
  },
  {
    title: 'Career acceleration',
    description:
      'Dedicated career strategists tailor your portfolio, interview narrative, and networking plan for the Benelux market.',
    icon: '🚀'
  },
  {
    title: 'Flexible delivery',
    description:
      'Blend immersive on-campus weekends in Brussels with polished live online labs to match your schedule.',
    icon: '🎯'
  }
];

const TRACKS = [
  {
    title: 'Frontend Engineering',
    category: 'Web',
    tag: 'React, UX, Testing',
    description:
      'Design responsive interfaces, master modern React patterns, and ship production-ready frontends aligned with Belgian accessibility standards.',
    modules: ['Design systems & accessibility', 'Advanced React architecture', 'Automated UI testing', 'Web performance clinics'],
    image: 'https://images.unsplash.com/photo-1523475472560-d2df97ec485c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Backend Engineering',
    category: 'Web',
    tag: 'Node.js, APIs, Cloud',
    description:
      'Build reliable APIs, integrate microservices, and deploy to European cloud regions with strong observability practices.',
    modules: ['API design sprints', 'Database optimisation', 'Cloud-native deployment', 'Secure coding workshops'],
    image: 'https://images.unsplash.com/photo-1518779578993-ec3579fee39f?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Data Science & AI',
    category: 'Data',
    tag: 'Python, ML, Analytics',
    description:
      'Analyse complex datasets, design end-to-end pipelines, and operationalise models with ethical, transparent approaches.',
    modules: ['Data storytelling', 'Machine learning labs', 'MLOps foundations', 'Responsible AI in the EU'],
    image: 'https://images.unsplash.com/photo-1517433456452-f9633a875f6f?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'DevOps & Cloud Automation',
    category: 'Infrastructure',
    tag: 'CI/CD, IaC, SRE',
    description:
      'Champion reliability by automating infrastructure, implementing CI/CD, and managing resilient platforms used in Belgium’s scale-ups.',
    modules: ['Infrastructure as Code', 'Observability toolchain', 'Platform reliability', 'Incident response simulations'],
    image: 'https://images.unsplash.com/photo-1517519014922-8fc06b81424b?auto=format&fit=crop&w=1200&q=80'
  },
  {
    title: 'Cybersecurity Engineering',
    category: 'Security',
    tag: 'Blue Team, Governance',
    description:
      'Secure complex environments, run live defence drills, and align practices with EU regulatory frameworks.',
    modules: ['Threat modelling studios', 'Security operations', 'Governance & compliance', 'Red vs blue exercises'],
    image: 'https://images.unsplash.com/photo-1510511459019-5dda7724fd87?auto=format&fit=crop&w=1200&q=80'
  }
];

const PROJECTS = [
  {
    title: 'Smart Mobility Analytics Lab',
    description:
      'Students processed Brussels mobility datasets to optimise traffic flows using predictive analytics dashboards.',
    image: 'https://picsum.photos/1200/800?random=14'
  },
  {
    title: 'Green Energy Cloud Platform',
    description:
      'A DevOps cohort automated deployment pipelines for a sustainable energy marketplace running on European cloud regions.',
    image: 'https://picsum.photos/1200/800?random=15'
  },
  {
    title: 'Healthcare Security Simulation',
    description:
      'Cybersecurity learners designed resilient hospital infrastructure with full incident response documentation.',
    image: 'https://picsum.photos/1200/800?random=16'
  }
];

const PARTNERS = [
  { name: 'Agoria', logo: 'https://picsum.photos/160/60?random=21' },
  { name: 'Microsoft Belgium', logo: 'https://picsum.photos/160/60?random=22' },
  { name: 'Flemish AI Center', logo: 'https://picsum.photos/160/60?random=23' },
  { name: 'AWS Benelux', logo: 'https://picsum.photos/160/60?random=24' }
];

const TESTIMONIALS = [
  {
    quote:
      'The personalised mentorship and rigorous feedback loops helped me move from support engineer into a platform role within three months.',
    name: 'Lena Martens',
    title: 'Platform Engineer, Antwerp'
  },
  {
    quote:
      'IT Learning Hub connected me with Brussels-based data leaders and helped me design a portfolio that reflects business impact.',
    name: 'Jean-Pierre Dubois',
    title: 'Data Scientist, Brussels'
  },
  {
    quote:
      'The cybersecurity simulations mirrored the real pressure of a live incident. I felt genuinely prepared for the interviews that followed.',
    name: 'Aisha Idrissi',
    title: 'Security Analyst, Liège'
  }
];

const FAQ = [
  {
    question: 'Are the courses suitable for working professionals?',
    answer:
      'Yes. Each pathway combines flexible live online sessions with intentional weekend intensives in Brussels, allowing you to balance work commitments with deep learning.'
  },
  {
    question: 'Do I need prior experience?',
    answer:
      'We offer foundation modules and bridging resources for career changers. A learning advisor will guide you to the pathway that matches your background.'
  },
  {
    question: 'What language are the sessions delivered in?',
    answer:
      'Our core delivery language is English, complemented by optional coaching sessions in French or Dutch depending on learner preference.'
  }
];

const INSIGHTS = [
  {
    title: 'Navigating the Belgian tech talent landscape in 2024',
    summary: 'Key hiring insights from Brussels, Antwerp, and Ghent with recommendations for emerging professionals.',
    image: 'https://picsum.photos/800/600?random=31',
    url: '/career'
  },
  {
    title: 'How to build cloud-native apps with a security-first mindset',
    summary: 'Practical guardrails for DevOps teams scaling across European regions while meeting regulatory requirements.',
    image: 'https://picsum.photos/800/600?random=32',
    url: '/methodology'
  },
  {
    title: 'From data curiosity to delivering AI value in 90 days',
    summary: 'A roadmap for analytical thinkers to develop production-ready ML solutions with ethical checkpoints.',
    image: 'https://picsum.photos/800/600?random=33',
    url: '/courses'
  }
];

function Home() {
  const [displayedStats, setDisplayedStats] = useState(STATS.map(() => 0));
  const [activeFilter, setActiveFilter] = useState('All');
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [openFAQ, setOpenFAQ] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setDisplayedStats((prev) =>
        prev.map((value, index) => {
          const target = STATS[index].value;
          if (value >= target) return target;
          const increment = Math.ceil(target / 40);
          return value + increment;
        })
      );
    }, 60);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 5000);
    return () => clearInterval(rotation);
  }, []);

  const filteredTracks = useMemo(() => {
    if (activeFilter === 'All') return TRACKS;
    return TRACKS.filter((track) => track.category === activeFilter);
  }, [activeFilter]);

  return (
    <>
      <SEO
        title="Home"
        description="IT Learning Hub delivers immersive IT training, practical mentorship, and career acceleration for learners across Belgium."
        keywords="IT education Belgium, tech courses Brussels, coding bootcamp Belgium"
      />
      <section
        className={styles.hero}
        aria-labelledby="hero-heading"
      >
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <p className="section-heading">Belgium’s home for progressive IT education</p>
            <h1 id="hero-heading">
              Gain future-proof tech skills, build confidence, and accelerate your career across Belgium&apos;s innovation hubs.
            </h1>
            <p>
              Join multidisciplinary cohorts led by practicing engineers and strategists. We blend collaborative labs, live
              coaching, and career immersion so you can deliver impact from day one.
            </p>
            <div className={styles.heroActions}>
              <Link to="/courses" className={styles.primaryButton}>
                Explore Pathways
              </Link>
              <Link to="/methodology" className={styles.secondaryButton}>
                Discover our approach
              </Link>
            </div>
            <div className={styles.heroStats}>
              {STATS.map((stat, index) => (
                <div key={stat.label}>
                  <span>{displayedStats[index]}+</span>
                  <p>{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
          <div className={styles.heroMedia}>
            <div className={styles.heroCard}>
              <img
                src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1400&q=80"
                alt="Learners collaborating during an IT workshop"
                loading="lazy"
              />
              <div className={styles.heroBadge}>
                <p>Live project studios every week</p>
                <span>Coached by Belgian tech leaders</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.benefitsSection}`}>
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Why learners choose us</p>
            <h2 className="section-title">Practical learning experiences guided by real-world expectations</h2>
            <p className="section-subtitle">
              Every pathway is engineered with industry partners, ensuring you can adapt, collaborate, and deliver in any team
              across Belgium&apos;s tech ecosystem.
            </p>
          </header>
          <div className={styles.benefitsGrid}>
            {BENEFITS.map((benefit) => (
              <article key={benefit.title} className={styles.benefitCard}>
                <span aria-hidden="true">{benefit.icon}</span>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.tracksSection}`} aria-labelledby="tracks-heading">
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Popular pathways</p>
            <h2 id="tracks-heading" className="section-title">
              Curated courses that transition you into high-demand roles
            </h2>
            <p className="section-subtitle">
              Select the track that resonates with your aspirations. Each pathway combines live instruction, hands-on labs, and
              curated expert sessions.
            </p>
          </header>
          <div className={styles.filters}>
            {['All', 'Web', 'Data', 'Infrastructure', 'Security'].map((filter) => (
              <button
                key={filter}
                type="button"
                onClick={() => setActiveFilter(filter)}
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
                aria-pressed={activeFilter === filter}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.trackGrid}>
            {filteredTracks.map((track) => (
              <article key={track.title} className={styles.trackCard}>
                <div className={styles.trackMedia}>
                  <img src={track.image} alt={`${track.title} course`} loading="lazy" />
                  <span className={styles.trackTag}>{track.tag}</span>
                </div>
                <div className={styles.trackBody}>
                  <h3>{track.title}</h3>
                  <p>{track.description}</p>
                  <ul>
                    {track.modules.map((module) => (
                      <li key={module}>{module}</li>
                    ))}
                  </ul>
                  <Link to="/contact" className={styles.trackLink}>
                    Talk to a learning advisor ↗
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.journeySection}`} aria-labelledby="journey-heading">
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Learning journey</p>
            <h2 id="journey-heading" className="section-title">
              A structured journey that keeps you building, iterating, and progressing
            </h2>
          </header>
          <div className={styles.timeline}>
            <div className={styles.timelineItem}>
              <div className={styles.timelineNumber}>01</div>
              <div className={styles.timelineContent}>
                <h3>Personalised onboarding</h3>
                <p>
                  Assess your skill baseline, craft a tailored growth plan, and match with mentors specialising in your target
                  role.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelineNumber}>02</div>
              <div className={styles.timelineContent}>
                <h3>Immersive labs &amp; sprints</h3>
                <p>
                  Work on peer-reviewed assignments, commit code, and receive iterative feedback until your work meets industry
                  expectations.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelineNumber}>03</div>
              <div className={styles.timelineContent}>
                <h3>Professional storytelling</h3>
                <p>
                  Translate your projects into compelling narratives that resonate with talent managers and technical interviewers.
                </p>
              </div>
            </div>
            <div className={styles.timelineItem}>
              <div className={styles.timelineNumber}>04</div>
              <div className={styles.timelineContent}>
                <h3>Career launchpad</h3>
                <p>
                  Access curated opportunities, hiring events, and alumni communities based across Brussels, Ghent, Antwerp, and
                  beyond.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.projectsSection}`} aria-labelledby="projects-heading">
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Real-world impact</p>
            <h2 id="projects-heading" className="section-title">
              Projects, partners, and certifications that validate your expertise
            </h2>
          </header>
          <div className={styles.projectGrid}>
            {PROJECTS.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.partners}>
            <h3>Trusted by leading Belgian innovators</h3>
            <ul className={styles.partnerList}>
              {PARTNERS.map((partner) => (
                <li key={partner.name}>
                  <img src={partner.logo} alt={`${partner.name} logo`} loading="lazy" />
                </li>
              ))}
            </ul>
            <p>
              Earn globally recognised certifications and badges as you progress, including Azure, AWS, and Linux Foundation
              credentials.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.testimonialsSection}`} aria-labelledby="testimonials-heading">
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Learner perspectives</p>
            <h2 id="testimonials-heading" className="section-title">
              Voices from professionals who transformed their careers
            </h2>
          </header>
          <div className={styles.testimonialWrapper}>
            {TESTIMONIALS.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${index === testimonialIndex ? styles.testimonialActive : ''}`}
                aria-hidden={index !== testimonialIndex}
              >
                <p className={styles.testimonialQuote}>&ldquo;{testimonial.quote}&rdquo;</p>
                <p className={styles.testimonialAuthor}>{testimonial.name}</p>
                <span className={styles.testimonialRole}>{testimonial.title}</span>
              </article>
            ))}
          </div>
          <div className={styles.testimonialDots} role="tablist" aria-label="Testimonials">
            {TESTIMONIALS.map((_, index) => (
              <button
                key={index}
                type="button"
                onClick={() => setTestimonialIndex(index)}
                className={`${styles.dot} ${index === testimonialIndex ? styles.dotActive : ''}`}
                aria-label={`Show testimonial ${index + 1}`}
                aria-selected={index === testimonialIndex}
              ></button>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.faqSection}`} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.faqGrid}>
            <div>
              <header className={styles.sectionHeader}>
                <p className="section-heading">FAQ</p>
                <h2 id="faq-heading" className="section-title">
                  Answers to common questions about joining IT Learning Hub
                </h2>
                <p className="section-subtitle">
                  Our learner success team is based in Brussels and ready to help you choose the pathway that aligns with your
                  goals.
                </p>
                <Link to="/contact" className={styles.primaryButton}>
                  Speak with us
                </Link>
              </header>
            </div>
            <div className={styles.faqList}>
              {FAQ.map((item, index) => (
                <div key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    onClick={() => setOpenFAQ(openFAQ === index ? -1 : index)}
                    aria-expanded={openFAQ === index}
                  >
                    <span>{item.question}</span>
                    <span>{openFAQ === index ? '−' : '+'}</span>
                  </button>
                  {openFAQ === index && <p>{item.answer}</p>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.section} ${styles.insightsSection}`} aria-labelledby="insights-heading">
        <div className="container">
          <header className={styles.sectionHeader}>
            <p className="section-heading">Insights &amp; resources</p>
            <h2 id="insights-heading" className="section-title">
              Keep your knowledge sharp with perspectives from our instructors and partners
            </h2>
          </header>
          <div className={styles.insightsGrid}>
            {INSIGHTS.map((insight) => (
              <article key={insight.title} className={styles.insightCard}>
                <img src={insight.image} alt={insight.title} loading="lazy" />
                <div>
                  <h3>{insight.title}</h3>
                  <p>{insight.summary}</p>
                  <Link to={insight.url}>Read more ↗</Link>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.cta}>
            <div className={styles.ctaInner}>
              <h3>Ready to reimagine your career in tech?</h3>
              <p>
                Book a personalised consultation with a learning strategist. We&apos;ll map out the right pathway, schedule, and
                career game plan for you.
              </p>
              <div className={styles.ctaActions}>
                <Link to="/contact" className={styles.primaryButton}>
                  Plan your roadmap
                </Link>
                <Link to="/about" className={styles.secondaryButtonLight}>
                  Learn about IT Learning Hub
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;
```