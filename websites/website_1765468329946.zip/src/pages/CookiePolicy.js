```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

function CookiePolicy() {
  return (
    <>
      <SEO
        title="Cookie Policy"
        description="Cookie Policy for IT Learning Hub describing the use of cookies and how to manage your preferences."
      />
      <section className={styles.wrapper}>
        <div className="container">
          <h1 className={styles.title}>Cookie Policy</h1>
          <p className={styles.updated}>Last updated: 15 April 2024</p>
          <div className={styles.section}>
            <h2>1. What are cookies?</h2>
            <p>
              Cookies are small text files placed on your device when visiting our website. They help us remember your
              preferences and understand how the site is used to improve your experience.
            </p>
          </div>
          <div className={styles.section}>
            <h2>2. Types of cookies we use</h2>
            <ul>
              <li>
                <strong>Essential cookies:</strong> Required for basic website functions such as navigation and secure access.
              </li>
              <li>
                <strong>Analytics cookies:</strong> Help us measure engagement and optimise content. We use aggregated, anonymous
                data.
              </li>
              <li>
                <strong>Preference cookies:</strong> Remember language and form inputs to simplify your next visit.
              </li>
            </ul>
          </div>
          <div className={styles.section}>
            <h2>3. Managing cookies</h2>
            <p>
              You can manage cookie preferences using your browser settings. You may also decline optional cookies through the
              banner displayed on our website. Essential cookies cannot be disabled as they are necessary for core functionality.
            </p>
          </div>
          <div className={styles.section}>
            <h2>4. Updates</h2>
            <p>
              We may update this policy to reflect changes in technology or regulation. We encourage you to review it regularly.
            </p>
          </div>
          <div className={styles.section}>
            <h2>5. Contact</h2>
            <p>
              Questions about our use of cookies can be sent to{' '}
              <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;
```