```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Legal.module.css';

function Privacy() {
  return (
    <>
      <SEO
        title="Privacy Policy"
        description="Privacy Policy for IT Learning Hub outlining how we handle personal information and data protection commitments."
      />
      <section className={styles.wrapper}>
        <div className="container">
          <h1 className={styles.title}>Privacy Policy</h1>
          <p className={styles.updated}>Last updated: 15 April 2024</p>
          <div className={styles.section}>
            <h2>1. Data controller</h2>
            <p>
              IT Learning Hub, Avenue de la Toison d&apos;Or 56, 1050 Brussels, Belgium, acts as the data controller for
              personal data collected through our programmes and website.
            </p>
          </div>
          <div className={styles.section}>
            <h2>2. Information we collect</h2>
            <ul>
              <li>Contact details submitted via forms (name, email, phone).</li>
              <li>Professional information shared during onboarding assessments.</li>
              <li>Usage analytics collected through cookies and similar technologies.</li>
            </ul>
          </div>
          <div className={styles.section}>
            <h2>3. How we use your data</h2>
            <p>We process personal data for the following purposes:</p>
            <ul>
              <li>To communicate about programmes, schedules, and learning support.</li>
              <li>To tailor educational content and mentoring experiences.</li>
              <li>To provide career services and connect you with partners upon your request.</li>
              <li>To secure our digital platforms and ensure compliance with legal requirements.</li>
            </ul>
          </div>
          <div className={styles.section}>
            <h2>4. Data sharing</h2>
            <p>
              We share personal data with trusted service providers (e.g., learning platforms, communication tools) under strict
              contractual agreements. We may share relevant information with partner companies only when you give explicit
              consent.
            </p>
          </div>
          <div className={styles.section}>
            <h2>5. Your rights</h2>
            <p>
              Under GDPR, you have the right to access, correct, delete, or restrict processing of your personal data. To
              exercise these rights, contact <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>.
            </p>
          </div>
          <div className={styles.section}>
            <h2>6. Retention</h2>
            <p>
              We retain personal data for as long as necessary to deliver our services and comply with legal obligations. You
              may request deletion of your data at any time.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Privacy;
```