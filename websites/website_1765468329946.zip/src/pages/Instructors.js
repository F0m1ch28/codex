```javascript
import React from 'react';
import SEO from '../components/SEO';
import styles from './Instructors.module.css';

const INSTRUCTORS = [
  {
    name: 'Sofia Luyten',
    role: 'Lead Frontend Mentor',
    background:
      'Former engineering manager at a Brussels fintech where she scaled design systems across multilingual teams.',
    focus: 'Advanced React patterns, accessibility, design systems',
    image: 'https://picsum.photos/400/400?random=61',
    quote:
      'Technology should adapt to diverse audiences. I mentor learners to build inclusive products that deliver joy.'
  },
  {
    name: 'Thomas Verbeek',
    role: 'Principal Cloud Architect',
    background:
      'Helps Belgian scale-ups migrate to cloud-native architectures. Speaks regularly at DevOps Europe conferences.',
    focus: 'Cloud architecture, DevOps culture, site reliability engineering',
    image: 'https://picsum.photos/400/400?random=62',
    quote:
      'Operational excellence is achievable when teams understand the story behind every pipeline and metric.'
  },
  {
    name: 'Maya Patel',
    role: 'Data Science Coach',
    background:
      'Leads analytics teams across healthcare and mobility startups, specialising in responsible AI practices.',
    focus: 'Machine learning, data ethics, storytelling',
    image: 'https://picsum.photos/400/400?random=63',
    quote:
      'Clarity matters more than complexity. I help learners translate models into insight that stakeholders understand.'
  },
  {
    name: 'Jeroen Janssens',
    role: 'Cybersecurity Strategist',
    background:
      'Former CSIRT leader in Antwerp, now guiding enterprise security programmes across the Benelux region.',
    focus: 'Security operations, governance, incident response',
    image: 'https://picsum.photos/400/400?random=64',
    quote:
      'Security thrives when teams rehearse together. We run immersive simulations that build muscle memory.'
  }
];

function Instructors() {
  return (
    <>
      <SEO
        title="Instructors"
        description="Meet IT Learning Hub's instructors—practitioners from Belgian and European tech companies dedicated to mentoring the next generation."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Meet the expert mentors guiding your transformation.</h1>
          <p>
            Our instructors are active practitioners who allocate time each week to teach, mentor, and challenge you. They bring
            stories from current projects, ensuring your learning reflects how modern teams operate.
          </p>
        </div>
      </section>

      <section className={styles.gridSection}>
        <div className="container">
          <div className={styles.grid}>
            {INSTRUCTORS.map((instructor) => (
              <article key={instructor.name} className={styles.card}>
                <div className={styles.photo}>
                  <img src={instructor.image} alt={instructor.name} loading="lazy" />
                </div>
                <div className={styles.info}>
                  <h2>{instructor.name}</h2>
                  <p className={styles.role}>{instructor.role}</p>
                  <p>{instructor.background}</p>
                  <p className={styles.focus}><strong>Focus:</strong> {instructor.focus}</p>
                  <blockquote>“{instructor.quote}”</blockquote>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Instructors;
```