```javascript
import React, { useState } from 'react';
import SEO from '../components/SEO';
import styles from './Contact.module.css';

const INITIAL_STATE = {
  name: '',
  email: '',
  phone: '',
  interest: '',
  message: ''
};

function Contact() {
  const [formData, setFormData] = useState(INITIAL_STATE);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Please enter your full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address.';
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/i.test(formData.email)) {
      newErrors.email = 'Please enter a valid email.';
    }
    if (formData.phone && !/^\+?[0-9\s-]{7,}$/i.test(formData.phone)) {
      newErrors.phone = 'Please enter a valid phone number.';
    }
    if (!formData.message.trim()) newErrors.message = 'Please share a message so we can assist you.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((previous) => ({ ...previous, [name]: value }));
    if (errors[name]) {
      setErrors((previous) => ({ ...previous, [name]: undefined }));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormData(INITIAL_STATE);
  };

  return (
    <>
      <SEO
        title="Contact Us"
        description="Reach IT Learning Hub in Brussels for course inquiries, partnership discussions, and campus visits."
      />
      <section className={styles.hero}>
        <div className="container">
          <h1>Let’s design your personalised learning journey.</h1>
          <p>
            Our learner success team is based in Brussels and ready to help. Share your goals and we&apos;ll arrange a 30-minute
            consultation to discuss the best pathway for you.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <article className={styles.card}>
              <h2>Talk with us</h2>
              <form onSubmit={handleSubmit} noValidate>
                <label className={styles.field}>
                  <span>Full name *</span>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={Boolean(errors.name)}
                  />
                  {errors.name && <small>{errors.name}</small>}
                </label>
                <label className={styles.field}>
                  <span>Email *</span>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    aria-required="true"
                    aria-invalid={Boolean(errors.email)}
                  />
                  {errors.email && <small>{errors.email}</small>}
                </label>
                <label className={styles.field}>
                  <span>Phone</span>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    aria-invalid={Boolean(errors.phone)}
                  />
                  {errors.phone && <small>{errors.phone}</small>}
                </label>
                <label className={styles.field}>
                  <span>Area of interest</span>
                  <select name="interest" value={formData.interest} onChange={handleChange}>
                    <option value="">Select a pathway</option>
                    <option value="frontend">Frontend Engineering</option>
                    <option value="backend">Backend Engineering</option>
                    <option value="data">Data Science &amp; AI</option>
                    <option value="devops">DevOps &amp; Cloud Automation</option>
                    <option value="cybersecurity">Cybersecurity Engineering</option>
                    <option value="other">I am exploring options</option>
                  </select>
                </label>
                <label className={styles.field}>
                  <span>Your message *</span>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows="5"
                    aria-required="true"
                    aria-invalid={Boolean(errors.message)}
                  ></textarea>
                  {errors.message && <small>{errors.message}</small>}
                </label>
                <button type="submit">Send message</button>
                {submitted && <p className={styles.success}>Thanks! We will reach out within one business day.</p>}
              </form>
            </article>
            <aside className={styles.info}>
              <div className={styles.infoCard}>
                <h2>Visit us in Brussels</h2>
                <p>
                  IT Learning Hub <br />
                  Avenue de la Toison d&apos;Or 56 <br />
                  1050 Brussels, Belgium
                </p>
                <p>
                  Phone: <a href="tel:+3221234567">+32 2 123 45 67</a>
                  <br />
                  Email: <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
                </p>
              </div>
              <div className={styles.mapWrapper}>
                <iframe
                  title="IT Learning Hub location in Brussels"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2518.745885306646!2d4.355707977239162!3d50.836750559714816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c3c47ac236723d%3A0x6b984d4e2c7f9873!2sAvenue%20de%20la%20Toison%20d&#39;Or%2056%2C%201050%20Bruxelles%2C%20Belgium!5e0!3m2!1sen!2sbe!4v1712727560000!5m2!1sen!2sbe"
                  width="100%"
                  height="280"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;
```