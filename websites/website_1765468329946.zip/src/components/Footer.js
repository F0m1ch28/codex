```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className="container">
        <div className={styles.grid}>
          <div>
            <h2 id="footer-heading" className={styles.brand}>
              IT Learning Hub
            </h2>
            <p className={styles.description}>
              Cutting-edge IT education crafted in Belgium. We help learners gain practical experience, build professional
              networks, and launch resilient careers in technology.
            </p>
            <div className={styles.contactBlock}>
              <span>Avenue de la Toison d&apos;Or 56</span>
              <span>1050 Brussels, Belgium</span>
              <a href="tel:+3221234567">+32 2 123 45 67</a>
              <a href="mailto:info@itlearninghub.be">info@itlearninghub.be</a>
            </div>
          </div>
          <div>
            <h3 className={styles.heading}>Explore</h3>
            <ul className={styles.links}>
              <li>
                <Link to="/about">About Us</Link>
              </li>
              <li>
                <Link to="/courses">Courses</Link>
              </li>
              <li>
                <Link to="/methodology">Our Methodology</Link>
              </li>
              <li>
                <Link to="/instructors">Instructors</Link>
              </li>
              <li>
                <Link to="/career">Career Support</Link>
              </li>
              <li>
                <Link to="/contact">Contact Us</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Policies</h3>
            <ul className={styles.links}>
              <li>
                <Link to="/terms">Terms of Service</Link>
              </li>
              <li>
                <Link to="/privacy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Cookie Policy</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.heading}>Connect</h3>
            <ul className={styles.socials}>
              <li>
                <a href="https://www.linkedin.com" target="_blank" rel="noreferrer noopener" aria-label="LinkedIn">
                  LinkedIn ↗
                </a>
              </li>
              <li>
                <a href="https://www.twitter.com" target="_blank" rel="noreferrer noopener" aria-label="Twitter">
                  X (Twitter) ↗
                </a>
              </li>
              <li>
                <a href="https://www.youtube.com" target="_blank" rel="noreferrer noopener" aria-label="YouTube">
                  YouTube ↗
                </a>
              </li>
            </ul>
            <p className={styles.note}>
              Dedicated to sustainable talent development in Belgium&apos;s thriving tech ecosystem.
            </p>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {year} IT Learning Hub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
```