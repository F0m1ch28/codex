```javascript
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'ilh-cookie-consent';

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setIsVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setIsVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem(STORAGE_KEY, 'declined');
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <h2>Cookies &amp; Experience</h2>
        <p>
          We use essential and analytics cookies to enhance your learning experience and understand how our site is used.
          You can learn more in our{' '}
          <Link to="/cookie-policy" className={styles.link}>
            Cookie Policy
          </Link>
          .
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className={styles.secondary} onClick={handleDecline}>
          Decline
        </button>
        <button type="button" className={styles.primary} onClick={handleAccept}>
          Accept
        </button>
      </div>
    </div>
  );
}

export default CookieBanner;
```