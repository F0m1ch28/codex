document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('.site-header');
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieChoices = document.querySelectorAll('.cookie-choice');

    const handleScroll = () => {
        if (!header) return;
        if (window.scrollY > 10) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll);

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });
    }

    navLinks.forEach((link) => {
        link.addEventListener('click', () => {
            if (!navMenu || !navToggle) return;
            if (navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
                document.body.classList.remove('menu-open');
            }
        });
    });

    if (cookieBanner) {
        const storedChoice = localStorage.getItem('genus-cookie-consent');
        if (storedChoice) {
            cookieBanner.classList.add('hidden');
        }

        cookieChoices.forEach((choice) => {
            choice.addEventListener('click', (event) => {
                event.preventDefault();
                const decision = choice.dataset.choice || 'undecided';
                localStorage.setItem('genus-cookie-consent', decision);
                cookieBanner.classList.add('hidden');
                window.open('cookies.html', '_blank', 'noopener');
            });
        });
    }
});