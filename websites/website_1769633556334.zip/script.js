document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const navList = document.querySelector(".nav-list");
  const focusableSelectors = ["a", "button", "input", "select", "textarea"];

  if (navToggle && navList) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", (!expanded).toString());
      document.body.classList.toggle("nav-open");
      navList.classList.toggle("nav-list-open");
      if (!expanded) {
        navList.querySelector("a")?.focus({ preventScroll: true });
      } else {
        navToggle.focus({ preventScroll: true });
      }
    });

    navList.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        document.body.classList.remove("nav-open");
        navList.classList.remove("nav-list-open");
      });
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && document.body.classList.contains("nav-open")) {
        navToggle.setAttribute("aria-expanded", "false");
        document.body.classList.remove("nav-open");
        navList.classList.remove("nav-list-open");
        navToggle.focus({ preventScroll: true });
      }
      if (event.key === "Tab" && document.body.classList.contains("nav-open")) {
        const focusableItems = Array.from(navList.querySelectorAll(focusableSelectors.join(",")));
        if (focusableItems.length === 0) return;
        const firstItem = focusableItems[0];
        const lastItem = focusableItems[focusableItems.length - 1];
        if (!event.shiftKey && document.activeElement === lastItem) {
          event.preventDefault();
          firstItem.focus();
        } else if (event.shiftKey && document.activeElement === firstItem) {
          event.preventDefault();
          lastItem.focus();
        }
      }
    });
  }
});