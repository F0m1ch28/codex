document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteMenu = document.querySelector('.site-menu');
    const scrollButton = document.getElementById('scroll-top');
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookies = document.getElementById('accept-cookies');
    const contactForm = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');

    // Mobile navigation toggle
    if (navToggle && siteMenu) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteMenu.classList.toggle('open');
        });

        siteMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                siteMenu.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Scroll to top button
    if (scrollButton) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 320) {
                scrollButton.style.display = 'flex';
            } else {
                scrollButton.style.display = 'none';
            }
        });

        scrollButton.addEventListener('click', (event) => {
            event.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    if (cookieBanner && acceptCookies) {
        const consent = localStorage.getItem('nbcCookieConsent');
        if (consent === 'true') {
            cookieBanner.style.display = 'none';
        }

        acceptCookies.addEventListener('click', () => {
            localStorage.setItem('nbcCookieConsent', 'true');
            cookieBanner.style.display = 'none';
        });
    }

    // Update footer year
    const yearSpan = document.getElementById('year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    // Contact form handler
    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            formMessage.textContent = 'Thank you for reaching out. Our team will get back to you soon.';
            contactForm.reset();
        });
    }

    // Ensure navigation resets scroll position
    document.querySelectorAll('a.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });
});