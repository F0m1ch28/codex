```javascript
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import HomePage from "./pages/HomePage";
import AboutPage from "./pages/AboutPage";
import ServicesPage from "./pages/ServicesPage";
import BreedPage from "./pages/BreedPage";
import ContactsPage from "./pages/ContactsPage";
import TermsPage from "./pages/TermsPage";
import PrivacyPage from "./pages/PrivacyPage";
import CookiePolicyPage from "./pages/CookiePolicyPage";

function App() {
  return (
    <Router>
      <div className="app">
        <Header />
        <ScrollToTop />
        <main className="mainContent" id="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/pro-nas" element={<AboutPage />} />
            <Route path="/posluhy" element={<ServicesPage />} />
            <Route path="/pro-porodu" element={<BreedPage />} />
            <Route path="/kontakty" element={<ContactsPage />} />
            <Route path="/umovy-vykorystannia" element={<TermsPage />} />
            <Route
              path="/polityka-konfidentsiinosti"
              element={<PrivacyPage />}
            />
            <Route path="/polityka-cookie" element={<CookiePolicyPage />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </Router>
  );
}

export default App;
```