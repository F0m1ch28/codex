```javascript
import React, { useState } from "react";
import Seo from "../components/Seo";
import styles from "./ServicesPage.module.css";

const services = [
  {
    title: "ОКД — Основний курс слухняності",
    description:
      "Створюємо базу послуху: команди поряд, поруч, до мене, витримка, робота без повідка. Враховуємо характер вівчарки, щоб уникнути перевантаження.",
    outcomes: [
      "Стабільні команди навіть у людних місцях",
      "Відпрацьований контакт з провідником",
      "Збережена мотивація собаки під час тренувань",
    ],
  },
  {
    title: "ЗКС — Захисно-караульна служба",
    description:
      "Контролюємо силу та швидкість реакції, вчимо переходити з оборони у спокій. Працюємо зі сценаріями, що відповідають вашим задачам.",
    outcomes: [
      "Контрольована охорона території та провідника",
      "Відпрацьовані команди припинення та відпуску",
      "Безпечні укуси з чітким сигналом завершення",
    ],
  },
  {
    title: "Соціалізація у місті",
    description:
      "Поступово адаптуємо до транспорту, шуму, натовпу. Вчимо фокусуватися на провіднику, не реагувати на провокації.",
    outcomes: [
      "Спокійна поведінка у метро та транспорті",
      "Зменшення реактивності на інших собак",
      "Відпрацьовані ритуали спілкування з людьми",
    ],
  },
  {
    title: "Підготовка цуценят",
    description:
      "З перших місяців формуємо правильні звички, контакти, переводимо ігрову мотивацію у навчання та контроль.",
    outcomes: [
      "Швидке засвоєння команд базового рівня",
      "Правильний підхід до гри та мотивації",
      "Превенція небажаних звичок",
    ],
  },
  {
    title: "Поведінкові консультації",
    description:
      "Розбираємо складні випадки: агресія, ресурсна охорона, страхи. Створюємо план змін з поетапним контролем.",
    outcomes: [
      "Перехід від хаотичних реакцій до керованих",
      "Робота з тригерами та їх нейтралізація",
      "Покрокова підтримка власника",
    ],
  },
];

const addons = [
  {
    title: "Виїзні тренування",
    text: "Працюємо на території клієнта або у потрібних локаціях міста, щоб відразу адаптувати навички.",
  },
  {
    title: "Відеоаналіз",
    text: "Отримуєте розбір домашніх завдань з поправками від інструктора, щоб закріпити результат між сесіями.",
  },
  {
    title: "Підготовка до змагань",
    text: "Фокусуємося на вимогах IPO/IGP, готуємо до стартів та директив суддів.",
  },
];

function ServicesPage() {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Seo
        title="Послуги дресирування | Німецькі вівчарки Варшава та Краків"
        description="ОКД, ЗКС, соціалізація, поведінкові консультації та підготовка цуценят. Професійне дресирування німецьких вівчарок у Варшаві та Кракові."
        keywords="послуги дресирування собак, ОКД, ЗКС, соціалізація, поведінковий кінолог, Варшава, Краків"
        image="https://picsum.photos/1200/800?random=12"
        url="https://www.dresirovanie-psiv.pl/posluhy"
      />
      <section className={`${styles.hero} section`}>
        <div className="container">
          <div className={styles.heroContent}>
            <div>
              <p className="sectionLabel">Послуги</p>
              <h1 className="sectionTitle">
                Повний цикл підготовки німецької вівчарки
              </h1>
            </div>
            <p>
              Від базового послуху до складних охоронних сценаріїв. Ми працюємо
              тільки з німецькими вівчарками, тому продумали протоколи для
              кожного етапу — від цуценяти до професійного охоронця.
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.tabs}>
            <div className={styles.tabList} role="tablist">
              {services.map((service, index) => (
                <button
                  key={service.title}
                  className={`${styles.tabButton} ${
                    activeIndex === index ? styles.tabButtonActive : ""
                  }`}
                  onClick={() => setActiveIndex(index)}
                  type="button"
                  role="tab"
                  aria-selected={activeIndex === index}
                >
                  {service.title}
                </button>
              ))}
            </div>
            <div className={styles.tabPanel} role="tabpanel">
              <h2>{services[activeIndex].title}</h2>
              <p>{services[activeIndex].description}</p>
              <ul className={styles.outcomes}>
                {services[activeIndex].outcomes.map((outcome) => (
                  <li key={outcome}>{outcome}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.addonsSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Додаткові модулі</p>
            <h2 className="sectionTitle">
              Щоб навчання вписувалося у ваш ритм життя
            </h2>
          </div>
          <div className={styles.addonsGrid}>
            {addons.map((addon) => (
              <article key={addon.title}>
                <h3>{addon.title}</h3>
                <p>{addon.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.supportSection} section`}>
        <div className="container">
          <div className={styles.supportGrid}>
            <div>
              <p className="sectionLabel">Підтримка</p>
              <h2 className="sectionTitle">Ми поруч на кожному кроці</h2>
              <p>
                Після кожного тренування ви отримуєте план домашньої роботи,
                відеозапис ключових моментів та можливість оперативно поставити
                питання. Так ви не губитеся між сесіями та рухаєтеся впевнено.
              </p>
            </div>
            <div className={styles.supportCard}>
              <ul>
                <li>📌 Щотижневі звіти про прогрес</li>
                <li>🎬 Відеоаналіз від інструктора</li>
                <li>📘 Методички з вправами та іграми</li>
                <li>🗓️ Гнучкий графік занять Варшава/Краків</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default ServicesPage;
```