```javascript
import React from "react";
import Seo from "../components/Seo";
import styles from "./AboutPage.module.css";

const teamMembers = [
  {
    name: "Олександр Жуковський",
    role: "Головний кінолог, експерт з ЗКС",
    description:
      "12 років у службовій кінології. Працював з підрозділами поліції Варшави, сертифікований інструктор IPO.",
    image: "https://picsum.photos/400/400?random=3",
  },
  {
    name: "Марія Левицька",
    role: "Спеціалістка з поведінки та соціалізації",
    description:
      "Поведінковий консультант, розробляє програми для міських умов. Адаптувала понад 70 собак до життя в центрі.",
    image: "https://picsum.photos/400/400?random=10",
  },
  {
    name: "Пйотр Новак",
    role: "Інструктор ОКД та робочих випробувань",
    description:
      "Майстер спорту PZŁ, готував команди до національних чемпіонатів. Фокусується на бездоганному послуху.",
    image: "https://picsum.photos/400/400?random=11",
  },
];

const timeline = [
  {
    year: "2012",
    title: "Запуск у Варшаві",
    text: "Організували перші групи для службових собак та запустили індивідуальні програми.",
  },
  {
    year: "2016",
    title: "Розширення у Кракові",
    text: "Відкрили майданчик у Кракові та почали виїзні тренування для сімейних вівчарок.",
  },
  {
    year: "2019",
    title: "Міжнародні сертифікації",
    text: "Отримали сертифікати IPO/IGP, почали готувати собак до міжнародних іспитів.",
  },
  {
    year: "2023",
    title: "Комплексні програми",
    text: "Запустили повні курси — від соціалізації цуценят до професійної охорони та спорту.",
  },
];

function AboutPage() {
  return (
    <>
      <Seo
        title="Про нас | Професійне дресирування собак Варшава • Краків"
        description="Команда кінологів зі службовим досвідом: дресирування німецьких вівчарок, ОКД, ЗКС та поведінкові програми у Варшаві та Кракові."
        keywords="про нас, кінолог, команда кінологів, Варшава, Краків, дресирування німецьких вівчарок"
        image="https://picsum.photos/1200/800?random=4"
        url="https://www.dresirovanie-psiv.pl/pro-nas"
      />
      <section className="section">
        <div className="container">
          <div className={styles.intro}>
            <div>
              <p className="sectionLabel">Команда</p>
              <h1 className="sectionTitle">
                Професіонали, які живуть кінологією щодня
              </h1>
            </div>
            <p>
              Ми створили сервіс, де кожен етап навчання німецької вівчарки
              базується на реальних сценаріях — від життя у квартирі до
              високонавантажених охоронних завдань. Наша мета — передати вам
              навички керування собакою, а не просто навчити команд.
            </p>
          </div>

          <div className={styles.valuesGrid}>
            <article>
              <h3>Глибока діагностика</h3>
              <p>
                Перед стартом курсу ми оцінюємо темперамент, мотивацію та
                взаємодію з провідником. Це дозволяє будувати програму без
                ризику перевантаження або втрати інтересу.
              </p>
            </article>
            <article>
              <h3>Партнерство з власником</h3>
              <p>
                Ви тренуєтеся разом з нами — отримуєте чек-листи, відеоаналіз і
                домашні завдання. Це формує стабільну звичку слухняності.
              </p>
            </article>
            <article>
              <h3>Фокус на безпеку</h3>
              <p>
                Навіть у курсах ЗКС вчимо собаку швидко перемикатися між
                обороною та спокоєм, щоб ви могли повністю контролювати її
                реакції.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.timelineSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Етапи розвитку</p>
            <h2 className="sectionTitle">Від невеликого майданчика до мережі</h2>
          </div>
          <div className={styles.timelineGrid}>
            {timeline.map((item) => (
              <article key={item.year} className={styles.timelineCard}>
                <span className={styles.timelineYear}>{item.year}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.teamSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Команда кінологів</p>
            <h2 className="sectionTitle">
              Люди, які відповідають за успіх вашої собаки
            </h2>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={member.name} />
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <p className={styles.teamRole}>{member.role}</p>
                  <p>{member.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.missionSection} section`}>
        <div className="container">
          <div className={styles.missionWrapper}>
            <div>
              <p className="sectionLabel">Місія</p>
              <h2 className="sectionTitle">
                Ми допомагаємо вівчаркам реалізувати потенціал, а людям —
                відчути силу партнерства
              </h2>
            </div>
            <p>
              Кожна німецька вівчарка має колосальні здібності до охорони,
              пошуку, спорту. Наш виклик — показати, як зробити цю силу
              керованою, безпечною та радісною для обох сторін. Ми працюємо з
              емоціями, мотивацією, вмінням відмовлятися від команди, щоб
              послух був усвідомленим.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.partnersSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Партнерства</p>
            <h2 className="sectionTitle">
              Співпраця з клубами та службами Польщі
            </h2>
          </div>
          <div className={styles.partnersGrid}>
            <article>
              <h3>Клуб власників вівчарок Варшава</h3>
              <p>
                Регулярно проводимо спільні тренування, обмінюємося досвідом з
                підготовки до старта IPO та рятувальних робіт.
              </p>
            </article>
            <article>
              <h3>Польська асоціація кінології (PZŁ)</h3>
              <p>
                Модеруємо семінари для інструкторів, ділимося кейсами з
                поведінкової корекції робочих собак.
              </p>
            </article>
            <article>
              <h3>Безпекові служби</h3>
              <p>
                Допомагаємо відбирати та готувати собак до служби у приватних
                охоронних структурах і муніципальних підрозділах.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
}

export default AboutPage;
```