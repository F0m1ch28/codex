```javascript
import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Seo from "../components/Seo";
import styles from "./HomePage.module.css";

const statsData = [
  { label: "Років досвіду з вівчарками", value: 12 },
  { label: "Підготовлених собак-охоронців", value: 180 },
  { label: "Сертифікацій ОКД/ЗКС", value: 95 },
  { label: "Власників з повторними програмами", value: 68 },
];

const servicesPreview = [
  {
    title: "Підготовка до ОКД",
    description:
      "Відпрацьовуємо послух, витримку та точність виконання команд із фокусом на міське середовище.",
    icon: "🎯",
  },
  {
    title: "ЗКС та охорона",
    description:
      "Програмуємо контрольовану силу, захист провідника і території, підтримуючи стабільну психіку собаки.",
    icon: "🛡️",
  },
  {
    title: "Соціалізація у місті",
    description:
      "Навчаємо взаємодії у транспорті, парках та людних місцях Варшави й Кракова.",
    icon: "🚇",
  },
  {
    title: "Курс для власників",
    description:
      "Допомагаємо впевнено керувати собакою, читати її сигнали та закріплювати командну роботу.",
    icon: "👥",
  },
];

const advantages = [
  {
    title: "Індивідуальні траєкторії",
    text: "Плануємо заняття з урахуванням віку, характеру та вашої ролі у житті собаки.",
  },
  {
    title: "Польська та міжнародна сертифікація",
    text: "Працюємо відповідно до стандартів PZŁ та FCI, готуємо до змагань і службової роботи.",
  },
  {
    title: "Командна увага",
    text: "Ви тренуєтеся разом: провідник, кінолог і собака — постійний зв’язок без стресу.",
  },
  {
    title: "Зручна логістика",
    text: "Відпрацьовуємо у Варшаві та Кракові: майданчики, парки, виїзди до об’єктів.",
  },
];

const processSteps = [
  {
    title: "Діагностика потенціалу",
    text: "Оцінюємо нервову систему, драйв, реакцію на подразники і життєвий досвід собаки.",
    number: "01",
  },
  {
    title: "Створення плану",
    text: "Вибудовуємо програму, де поєднані тренування на майданчику, у місті та вдома.",
    number: "02",
  },
  {
    title: "Польові тренування",
    text: "Проводимо практику на реальних сценаріях: охорона, робота у групі, відпрацювання команд.",
    number: "03",
  },
  {
    title: "Оцінка та підтримка",
    text: "Фіксуємо прогрес, коригуємо план, підтримуємо власника методичними матеріалами.",
    number: "04",
  },
];

const projects = [
  {
    id: 1,
    category: "ОКД",
    title: "Поліцейська вівчарка Bruno — підготовка до IPO-VO",
    description:
      "Побудували стійкі команди для роботи у міських умовах, зміцнили витримку та інстинкт хапання.",
    image: "https://picsum.photos/1200/800?random=4",
  },
  {
    id: 2,
    category: "Соціалізація",
    title: "Лайма — адаптація до життя в центрі Варшави",
    description:
      "Розробили програму звикання до шуму метро та людей, прибрали реактивний гавкіт.",
    image: "https://picsum.photos/1200/800?random=5",
  },
  {
    id: 3,
    category: "ЗКС",
    title: "Thor — охорона приватного будинку під Краковом",
    description:
      "Відпрацювали сценарії проникнення, контроль укусу та перехід у стан спокою за командою.",
    image: "https://picsum.photos/1200/800?random=6",
  },
];

const testimonials = [
  {
    quote:
      "Після курсу ЗКС наша вівчарка працює впевнено й без зайвої агресії. Тренери детально пояснювали кожен крок.",
    author: "Анна, Варшава",
  },
  {
    quote:
      "Дуже сподобалось, що нас вчили читати собаку. Тепер прогулянки Краковом — задоволення, а не випробування.",
    author: "Міколай, Краків",
  },
  {
    quote:
      "Підготовка до ОКД пройшла на відмінно, інструктор завжди був на зв’язку, допомагав з домашніми завданнями.",
    author: "Ірина, Варшава",
  },
];

const faqItems = [
  {
    question: "Скільки часу триває базовий курс для німецької вівчарки?",
    answer:
      "Середній курс стартує з 8 тижнів, однак тривалість визначаємо після діагностики. Важливо якісно закріпити команди та сформувати звичку взаємодії.",
  },
  {
    question: "Чи можна поєднувати ОКД та ЗКС у одній програмі?",
    answer:
      "Так, поєднуємо. Ми чергуємо блоки послуху та захисних дій, щоб собака залишалась керованою в будь-якому стані.",
  },
  {
    question: "Де проводяться тренування у Варшаві та Кракові?",
    answer:
      "Маємо власні майданчики та тренувальні зали, а також виїжджаємо на приватні території або до міських локацій, щоб відпрацьовувати реальні сценарії.",
  },
];

const blogPreview = [
  {
    title: "Перші 30 днів із робочою вівчаркою: план адаптації",
    excerpt:
      "Розповідаємо, як структурувати режим, щоб собака не втрачала драйв, але залишалася керованою вдома.",
    link: "/pro-porodu",
    image: "https://picsum.photos/800/600?random=7",
  },
  {
    title: "Як підготувати вівчарку до життя в мегаполісі",
    excerpt:
      "Комплекс вправ і вправ із десенсибілізації, які допомагають уникнути стресу від транспорту й натовпу.",
    link: "/posluhy",
    image: "https://picsum.photos/800/600?random=8",
  },
  {
    title: "5 ознак, що вашій собаці потрібна програма ЗКС",
    excerpt:
      "Коли варто розпочати захисний курс і як не пропустити важливих сигналів від собаки.",
    link: "/posluhy",
    image: "https://picsum.photos/800/600?random=9",
  },
];

function HomePage() {
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [activeProjectCategory, setActiveProjectCategory] = useState("Усі");
  const [testimonialIndex, setTestimonialIndex] = useState(0);
  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [formErrors, setFormErrors] = useState({});
  const [formStatus, setFormStatus] = useState("");

  useEffect(() => {
    const intervals = statsData.map((stat, index) => {
      const step = Math.ceil(stat.value / 40);
      return setInterval(() => {
        setCounters((prev) => {
          const next = [...prev];
          if (next[index] < stat.value) {
            next[index] = Math.min(next[index] + step, stat.value);
          }
          return next;
        });
      }, 50);
    });
    return () => intervals.forEach((interval) => clearInterval(interval));
  }, []);

  useEffect(() => {
    const rotation = setInterval(() => {
      setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(rotation);
  }, []);

  const filteredProjects = useMemo(() => {
    if (activeProjectCategory === "Усі") return projects;
    return projects.filter(
      (project) => project.category === activeProjectCategory
    );
  }, [activeProjectCategory]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formValues.name.trim()) {
      errors.name = "Вкажіть, будь ласка, ім’я.";
    }
    if (!formValues.email.trim()) {
      errors.email = "Нам потрібен ваш email для відповіді.";
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      errors.email = "Перевірте правильність email.";
    }
    if (!formValues.message.trim()) {
      errors.message = "Коротко опишіть запит або ситуацію.";
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validateForm()) {
      setFormStatus("Перевірте форму та спробуйте ще раз.");
      return;
    }
    setTimeout(() => {
      setFormStatus("Дякуємо! Ми зв’яжемося з вами протягом робочого дня.");
      setFormValues({ name: "", email: "", message: "" });
      setFormErrors({});
    }, 600);
  };

  return (
    <>
      <Seo
        title="Професійне дресирування собак | Варшава та Краків"
        description="Експерти з дресирування німецьких вівчарок: ОКД, ЗКС, соціалізація та індивідуальні програми у Варшаві та Кракові."
        keywords="дресирування собак, навчання собак, німецька вівчарка, кінолог, послуги кінолога, Варшава, Краків, собака-охоронець, ОКД, ЗКС"
        image="https://picsum.photos/1600/900?random=1"
        url="https://www.dresirovanie-psiv.pl/"
      />
      <section className={styles.hero}>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroText}>
            <div className="badge">
              <span role="img" aria-hidden="true">
                ⭐
              </span>
              Варшава • Краків
            </div>
            <h1>
              Професійне дресирування німецьких вівчарок з реальними
              результатами
            </h1>
            <p>
              Ми створюємо стабільних, керованих і енергійних партнерів.
              Власники, які співпрацюють з нами, отримують не просто слухняну
              собаку — вони впевнено керують будь-якою ситуацією.
            </p>
            <div className={styles.heroActions}>
              <a className="btnPrimary" href="tel:+48123456789">
                Записатися на консультацію
              </a>
              <Link className="btnSecondary" to="/posluhy">
                Дослідити програми
              </Link>
            </div>
            <div className={styles.heroMeta}>
              <span>ОКД • ЗКС • Соціалізація • Робочі випробування</span>
            </div>
          </div>
          <div className={styles.heroVisual} role="presentation" />
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className={styles.aboutIntro}>
            <div>
              <p className="sectionLabel">Про нас коротко</p>
              <h2 className="sectionTitle">
                Досвідчена команда кінологів зі службовим бекграундом
              </h2>
            </div>
            <p>
              Ми працюємо із німецькими вівчарками понад 12 років, поєднуючи
              стандарти службової підготовки з гнучким підходом до сімейних
              собак. Реалії Варшави та Кракова вимагають адаптивних програм, і
              саме це ми втілюємо для кожної пари «людина-собака».
            </p>
          </div>
        </div>
      </section>

      <section className={styles.statsSection}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue}>{counters[index]}+</span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Наші переваги</p>
            <h2 className="sectionTitle">Чому власники обирають саме нас</h2>
            <p className="sectionDescription">
              Ми поєднуємо методики службового дресирування з сучасними
              підходами до поведінкової корекції. Програма завжди починається з
              глибокого аналізу вашої вівчарки та ваших цілей.
            </p>
          </div>
          <div className={styles.advantagesGrid}>
            {advantages.map((item) => (
              <article key={item.title} className={styles.advCard}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.servicesPreview} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Послуги</p>
            <h2 className="sectionTitle">
              Програми підготовки, заточені під німецьку вівчарку
            </h2>
          </div>
          <div className={styles.servicesGrid}>
            {servicesPreview.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon}>{service.icon}</span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/posluhy" className={styles.moreLink}>
                  Детальніше
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.processSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Як ми працюємо</p>
            <h2 className="sectionTitle">Чітка структура до результату</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.number} className={styles.processCard}>
                <span className={styles.processNumber}>{step.number}</span>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.breedSection} section`}>
        <div className={`container ${styles.breedWrapper}`}>
          <div className={styles.breedText}>
            <p className="sectionLabel">Чому німецька вівчарка</p>
            <h2 className="sectionTitle">
              Інтелект, драйв і відповідальність, які потрібно направляти
            </h2>
            <p>
              Вівчарка — робоча собака, що вимагає чіткого менеджменту енергії,
              контролю емоцій та ясних правил. Ми допомагаємо зберегти природний
              потенціал і створюємо сценарії, де вона реалізує себе щодня.
            </p>
            <Link className="btnSecondary" to="/pro-porodu">
              Дізнатися про особливості породи
            </Link>
          </div>
          <div className={styles.breedVisual}>
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Німецька вівчарка на тренуванні"
            />
          </div>
        </div>
      </section>

      <section className={`${styles.geoSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Географія роботи</p>
            <h2 className="sectionTitle">Варшава та Краків без компромісів</h2>
          </div>
          <div className={styles.geoGrid}>
            <article className={styles.cityCard}>
              <div className={styles.cityIcon}>🌆</div>
              <h3>Варшава</h3>
              <p>
                Тренування на лівому та правому березі, виїзди до службових
                об’єктів, адаптація до ритму мегаполісу, робота в метро.
              </p>
            </article>
            <article className={styles.cityCard}>
              <div className={styles.cityIcon}>🏰</div>
              <h3>Краків</h3>
              <p>
                Майданчики у передмісті, робота у старому місті, підготовка до
                охорони приватних маєтків і туристичних об’єктів.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.projectsSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Кейси</p>
            <h2 className="sectionTitle">Проєкти, якими ми пишаємося</h2>
          </div>
          <div className={styles.filterBar} role="tablist">
            {["Усі", "ОКД", "ЗКС", "Соціалізація"].map((category) => (
              <button
                type="button"
                key={category}
                className={`${styles.filterButton} ${
                  activeProjectCategory === category ? styles.filterActive : ""
                }`}
                onClick={() => setActiveProjectCategory(category)}
                role="tab"
                aria-selected={activeProjectCategory === category}
              >
                {category}
              </button>
            ))}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} />
                <div className={styles.projectBadge}>{project.category}</div>
                <div className={styles.projectContent}>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonialsSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Відгуки</p>
            <h2 className="sectionTitle">Що кажуть власники вівчарок</h2>
          </div>
          <div className={styles.testimonialCard} aria-live="polite">
            <p className={styles.testimonialQuote}>
              “{testimonials[testimonialIndex].quote}”
            </p>
            <p className={styles.testimonialAuthor}>
              {testimonials[testimonialIndex].author}
            </p>
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  type="button"
                  key={`dot-${index}`}
                  aria-label={`Перейти до відгуку ${index + 1}`}
                  className={`${styles.testimonialDot} ${
                    testimonialIndex === index ? styles.testimonialDotActive : ""
                  }`}
                  onClick={() => setTestimonialIndex(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.faqSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Питання та відповіді</p>
            <h2 className="sectionTitle">Важливі нюанси тренувального процесу</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blogSection} section`}>
        <div className="container">
          <div className="sectionHeader">
            <p className="sectionLabel">Блог</p>
            <h2 className="sectionTitle">Останні нотатки для власників вівчарок</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPreview.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <img src={post.image} alt={post.title} />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>
                    Продовжити читання →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} section`}>
        <div className="container">
          <div className={styles.ctaWrapper}>
            <div>
              <h2>Готові розкрити потенціал вашої німецької вівчарки?</h2>
              <p>
                Розкажіть нам про свої цілі — ми підготуємо план діагностики та
                перший блок тренувань у Варшаві або Кракові.
              </p>
            </div>
            <a className="btnPrimary" href="tel:+48123456789">
              Обговорити тренування
            </a>
          </div>
        </div>
      </section>

      <section className={`${styles.contactSection} section`}>
        <div className="container">
          <div className={styles.contactWrapper}>
            <div className={styles.contactInfo}>
              <p className="sectionLabel">Зв’яжіться з нами</p>
              <h2 className="sectionTitle">
                Перший крок — коротка консультація з кінологом
              </h2>
              <p>
                Заповніть форму: вкажіть вік собаки, досвід, чого прагнете.
                Відповімо протягом робочого дня, щоб узгодити час діагностики
                або онлайн-обговорення плану.
              </p>
              <ul className={styles.contactList}>
                <li>📞 +48 123 456 789</li>
                <li>✉️ info@dresirovanie-psiv.pl</li>
                <li>
                  📍 Варшава, вул. Собача, 15 / Краків, вул. Кінологічна, 8
                </li>
              </ul>
            </div>
            <form
              className={styles.contactForm}
              onSubmit={handleSubmit}
              noValidate
            >
              <label htmlFor="home-name">Ім’я</label>
              <input
                id="home-name"
                name="name"
                type="text"
                value={formValues.name}
                onChange={handleInputChange}
                aria-invalid={Boolean(formErrors.name)}
              />
              {formErrors.name && (
                <span className={styles.errorMessage}>{formErrors.name}</span>
              )}

              <label htmlFor="home-email">Email</label>
              <input
                id="home-email"
                name="email"
                type="email"
                value={formValues.email}
                onChange={handleInputChange}
                aria-invalid={Boolean(formErrors.email)}
              />
              {formErrors.email && (
                <span className={styles.errorMessage}>{formErrors.email}</span>
              )}

              <label htmlFor="home-message">Повідомлення</label>
              <textarea
                id="home-message"
                name="message"
                rows="4"
                value={formValues.message}
                onChange={handleInputChange}
                aria-invalid={Boolean(formErrors.message)}
              />
              {formErrors.message && (
                <span className={styles.errorMessage}>
                  {formErrors.message}
                </span>
              )}

              <button type="submit" className={styles.submitBtn}>
                Надіслати запит
              </button>
              {formStatus && (
                <p className={styles.formStatus} role="status">
                  {formStatus}
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </>
  );
}

export default HomePage;
```