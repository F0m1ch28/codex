```javascript
import React from "react";
import Seo from "../components/Seo";
import styles from "./LegalPage.module.css";

function CookiePolicyPage() {
  return (
    <>
      <Seo
        title="Політика щодо файлів cookie | Професійне дресирування собак"
        description="Дізнайтеся, як ми використовуємо файли cookie на сайті Професійне дресирування собак."
        keywords="cookie, політика cookie"
        url="https://www.dresirovanie-psiv.pl/polityka-cookie"
      />
      <section className="section">
        <div className="container">
          <div className={styles.legalWrapper}>
            <h1>Політика щодо файлів cookie</h1>
            <p>
              Файли cookie допомагають нам забезпечувати коректну роботу сайту
              та розуміти, як відвідувачі взаємодіють з контентом.
            </p>

            <h2>1. Які cookie ми використовуємо</h2>
            <p>
              <strong>Необхідні cookie:</strong> гарантують роботу форм та
              навігації.<br />
              <strong>Аналітичні cookie:</strong> допомагають бачити відвідуваність
              сайту та покращувати сервіс. Ці файли активуються лише після вашої
              згоди.
            </p>

            <h2>2. Керування cookie</h2>
            <p>
              Ви можете змінити налаштування браузера або скористатися
              відповідними кнопками у банері, що з’являється під час першого
              відвідування. Відмова від аналітичних cookie не впливає на
              можливість користуватися сайтом.
            </p>

            <h2>3. Зберігання даних</h2>
            <p>
              Ми не зберігаємо персональні дані у cookie. Аналітична інформація
              агрегована і не дозволяє ідентифікувати користувачів.
            </p>

            <h2>4. Контакт</h2>
            <p>
              Питання щодо cookie можна надсилати за адресою{" "}
              <a href="mailto:info@dresirovanie-psiv.pl">
                info@dresirovanie-psiv.pl
              </a>
              .
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default CookiePolicyPage;
```