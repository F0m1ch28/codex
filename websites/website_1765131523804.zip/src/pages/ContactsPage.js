```javascript
import React, { useState } from "react";
import Seo from "../components/Seo";
import styles from "./ContactsPage.module.css";

function ContactsPage() {
  const [formValues, setFormValues] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [formStatus, setFormStatus] = useState("");
  const [errors, setErrors] = useState({});

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formValues.name.trim()) newErrors.name = "Вкажіть ім’я.";
    if (!formValues.email.trim()) {
      newErrors.email = "Email є обов’язковим.";
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      newErrors.email = "Email має бути у форматі name@example.com.";
    }
    if (!formValues.message.trim()) {
      newErrors.message = "Опишіть ваш запит.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) {
      setFormStatus("Будь ласка, виправте помилки у формі.");
      return;
    }
    setTimeout(() => {
      setFormStatus(
        "Дякуємо за звернення! Ми відповімо на ваш запит якнайшвидше."
      );
      setFormValues({ name: "", email: "", phone: "", message: "" });
      setErrors({});
    }, 700);
  };

  return (
    <>
      <Seo
        title="Контакти | Професійне дресирування собак"
        description="Зв’яжіться з нами: Варшава, вул. Собача, 15 / Краків, вул. Кінологічна, 8. Телефон +48 123 456 789, email info@dresirovanie-psiv.pl."
        keywords="контакти кінолога, дресирування собак Варшава, дресирування собак Краків"
        image="https://picsum.photos/1200/800?random=15"
        url="https://www.dresirovanie-psiv.pl/kontakty"
      />
      <section className="section">
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <p className="sectionLabel">Контакти</p>
              <h1 className="sectionTitle">Плануйте тренування вже сьогодні</h1>
              <p>
                Напишіть нам чи зателефонуйте, щоб узгодити діагностику та
                стартове заняття у Варшаві або Кракові. Ми працюємо щоденно,
                графік підбираємо під ваш ритм життя.
              </p>
              <div className={styles.contactList}>
                <div>
                  <span className={styles.contactLabel}>Телефон</span>
                  <a href="tel:+48123456789">+48 123 456 789</a>
                </div>
                <div>
                  <span className={styles.contactLabel}>Email</span>
                  <a href="mailto:info@dresirovanie-psiv.pl">
                    info@dresirovanie-psiv.pl
                  </a>
                </div>
                <div>
                  <span className={styles.contactLabel}>Адреси майданчиків</span>
                  <p>
                    Варшава, вул. Собача, 15 <br />
                    Краків, вул. Кінологічна, 8
                  </p>
                </div>
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <label htmlFor="contact-name">Ім’я *</label>
              <input
                id="contact-name"
                name="name"
                type="text"
                value={formValues.name}
                onChange={handleChange}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name && (
                <span className={styles.error}>{errors.name}</span>
              )}

              <label htmlFor="contact-email">Email *</label>
              <input
                id="contact-email"
                name="email"
                type="email"
                value={formValues.email}
                onChange={handleChange}
                aria-invalid={Boolean(errors.email)}
              />
              {errors.email && (
                <span className={styles.error}>{errors.email}</span>
              )}

              <label htmlFor="contact-phone">Телефон (необов’язково)</label>
              <input
                id="contact-phone"
                name="phone"
                type="tel"
                value={formValues.phone}
                onChange={handleChange}
              />

              <label htmlFor="contact-message">Повідомлення *</label>
              <textarea
                id="contact-message"
                name="message"
                rows="5"
                value={formValues.message}
                onChange={handleChange}
                aria-invalid={Boolean(errors.message)}
              />
              {errors.message && (
                <span className={styles.error}>{errors.message}</span>
              )}

              <button type="submit" className={styles.submit}>
                Надіслати
              </button>
              {formStatus && (
                <p className={styles.status} role="status">
                  {formStatus}
                </p>
              )}
            </form>
          </div>

          <div className={styles.mapWrapper} aria-hidden="true">
            <img
              src="https://picsum.photos/1200/500?random=16"
              alt="Карта локацій Варшави та Кракова"
            />
          </div>
        </div>
      </section>
    </>
  );
}

export default ContactsPage;
```