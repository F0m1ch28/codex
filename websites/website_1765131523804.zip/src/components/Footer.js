```javascript
import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

function Footer() {
  return (
    <footer className={styles.footer} role="contentinfo">
      <div className={`container ${styles.footerInner}`}>
        <div className={styles.column}>
          <div className={styles.brand}>
            <span className={styles.brandIcon}>🐕</span>
            <div>
              <p className={styles.brandName}>Професійне дресирування собак</p>
              <p className={styles.brandTagline}>
                Партнер для вашої німецької вівчарки у Варшаві та Кракові.
              </p>
            </div>
          </div>
          <div className={styles.addressBlock}>
            <span className={styles.addressLabel}>Адреса:</span>
            <p>
              Варшава, вул. Собача, 15 <br /> Краків, вул. Кінологічна, 8
            </p>
          </div>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Навігація</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/">Головна</Link>
            </li>
            <li>
              <Link to="/pro-nas">Про нас</Link>
            </li>
            <li>
              <Link to="/posluhy">Послуги</Link>
            </li>
            <li>
              <Link to="/pro-porodu">Про породу</Link>
            </li>
            <li>
              <Link to="/kontakty">Контакти</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Правова інформація</h3>
          <ul className={styles.list}>
            <li>
              <Link to="/umovy-vykorystannia">Умови використання</Link>
            </li>
            <li>
              <Link to="/polityka-konfidentsiinosti">
                Політика конфіденційності
              </Link>
            </li>
            <li>
              <Link to="/polityka-cookie">Політика щодо файлів cookie</Link>
            </li>
          </ul>
        </div>
        <div className={styles.column}>
          <h3 className={styles.columnTitle}>Зв’язок</h3>
          <ul className={styles.list}>
            <li>
              <a href="tel:+48123456789">+48 123 456 789</a>
            </li>
            <li>
              <a href="mailto:info@dresirovanie-psiv.pl">
                info@dresirovanie-psiv.pl
              </a>
            </li>
          </ul>
          <div className={styles.socials}>
            <a href="#!" aria-label="Facebook" className={styles.socialLink}>
              <span aria-hidden="true"></span>
            </a>
            <a href="#!" aria-label="Instagram" className={styles.socialLink}>
              <span aria-hidden="true"></span>
            </a>
            <a href="#!" aria-label="YouTube" className={styles.socialLink}>
              <span aria-hidden="true"></span>
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <div className="container">
          <p>© {new Date().getFullYear()} Професійне дресирування собак</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
```