```javascript
import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import styles from "./Header.module.css";

const navLinks = [
  { to: "/", label: "Головна" },
  { to: "/pro-nas", label: "Про нас" },
  { to: "/posluhy", label: "Послуги" },
  { to: "/pro-porodu", label: "Про породу" },
  { to: "/kontakty", label: "Контакти" },
];

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleToggle = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);

  return (
    <header className={styles.header} role="banner">
      <div className={`container ${styles.headerInner}`}>
        <Link to="/" className={styles.logo} aria-label="Перейти на головну">
          <span className={styles.logoMark}>🐾</span>
          <span className={styles.logoText}>Професійне дресирування собак</span>
        </Link>
        <nav className={styles.desktopNav} aria-label="Головна навігація">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                isActive
                  ? `${styles.navLink} ${styles.navLinkActive}`
                  : styles.navLink
              }
              onClick={closeMenu}
            >
              {link.label}
            </NavLink>
          ))}
          <a className={styles.phoneLink} href="tel:+48123456789">
            +48 123 456 789
          </a>
        </nav>
        <button
          type="button"
          className={styles.menuToggle}
          onClick={handleToggle}
          aria-expanded={isMenuOpen}
          aria-controls="mobile-navigation"
          aria-label="Переключити меню"
        >
          <span className={styles.menuIcon} />
          <span className="sr-only">Меню</span>
        </button>
      </div>
      <div
        id="mobile-navigation"
        className={`${styles.mobileNav} ${isMenuOpen ? styles.mobileNavOpen : ""}`}
      >
        {navLinks.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              isActive
                ? `${styles.mobileLink} ${styles.mobileLinkActive}`
                : styles.mobileLink
            }
            onClick={closeMenu}
          >
            {link.label}
          </NavLink>
        ))}
        <a className={styles.mobilePhone} href="tel:+48123456789">
          +48 123 456 789
        </a>
      </div>
    </header>
  );
}

export default Header;
```