```javascript
import { useEffect } from "react";

const Seo = ({ title, description, keywords, image, url }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
      updateMeta("property", "og:title", title);
    }
    if (description) {
      updateMeta("name", "description", description);
      updateMeta("property", "og:description", description);
      updateMeta("name", "twitter:description", description);
    }
    if (keywords) {
      updateMeta("name", "keywords", keywords);
    }
    if (image) {
      updateMeta("property", "og:image", image);
      updateMeta("name", "twitter:image", image);
    }
    if (url) {
      updateMeta("property", "og:url", url);
      updateLink("canonical", url);
    }
  }, [title, description, keywords, image, url]);

  const updateMeta = (attr, name, content) => {
    if (!content) return;
    let metaTag = document.querySelector(`meta[${attr}="${name}"]`);
    if (!metaTag) {
      metaTag = document.createElement("meta");
      metaTag.setAttribute(attr, name);
      document.head.appendChild(metaTag);
    }
    metaTag.setAttribute("content", content);
  };

  const updateLink = (rel, href) => {
    if (!href) return;
    let linkTag = document.querySelector(`link[rel="${rel}"]`);
    if (!linkTag) {
      linkTag = document.createElement("link");
      linkTag.setAttribute("rel", rel);
      document.head.appendChild(linkTag);
    }
    linkTag.setAttribute("href", href);
  };

  return null;
};

export default Seo;
```