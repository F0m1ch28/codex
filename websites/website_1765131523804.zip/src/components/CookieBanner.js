```javascript
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const STORAGE_KEY = "cookie-consent";

function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ essential: true, analytics: true })
    );
    setIsVisible(false);
  };

  const handlePreferences = () => {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ essential: true, analytics: false })
    );
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.text}>
          Ми використовуємо cookie для забезпечення стабільної роботи сайту та
          аналізу відвідуваності. Детальніше в{" "}
          <Link to="/polityka-cookie">Політиці щодо файлів cookie</Link>.
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.secondary}
            onClick={handlePreferences}
          >
            Лише необхідні
          </button>
          <button
            type="button"
            className={styles.primary}
            onClick={handleAccept}
          >
            Погоджуюсь
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;
```