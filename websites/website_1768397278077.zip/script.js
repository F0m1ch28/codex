document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const cookieBanner = document.getElementById('cookie-banner');
    const cookieButtons = document.querySelectorAll('.cookie-btn');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            const isOpen = siteNav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        const navLinks = siteNav.querySelectorAll('a');
        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (siteNav.classList.contains('is-open')) {
                    siteNav.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem('albatrCookieConsent');
        if (storedConsent) {
            cookieBanner.classList.add('hidden');
        }

        cookieButtons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                const action = button.dataset.action || 'reviewed';
                localStorage.setItem('albatrCookieConsent', action);
                cookieBanner.classList.add('hidden');
                const href = button.getAttribute('href');
                if (href) {
                    window.location.href = href;
                }
            });
        });
    }
});