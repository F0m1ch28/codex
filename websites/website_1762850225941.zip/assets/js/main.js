document.addEventListener('DOMContentLoaded', () => {
    const nav = document.querySelector('.primary-nav');
    const toggle = document.getElementById('mobile-toggle');
    const navLinks = document.querySelectorAll('.primary-nav a');
    const scrollBtn = document.querySelector('.scroll-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const cookieButton = document.getElementById('accept-cookies');
    const contactForm = document.getElementById('contact-form');
    const formStatus = document.getElementById('form-status');

    if (toggle && nav) {
        toggle.addEventListener('click', () => {
            const expanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', String(!expanded));
            nav.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (nav && nav.classList.contains('open')) {
                nav.classList.remove('open');
                toggle && toggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    if (scrollBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 350) {
                scrollBtn.classList.add('is-visible');
            } else {
                scrollBtn.classList.remove('is-visible');
            }
        });

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieButton) {
        const isAccepted = localStorage.getItem('polarCookiesAccepted');
        if (!isAccepted) {
            cookieBanner.classList.add('is-visible');
        }
        cookieButton.addEventListener('click', () => {
            localStorage.setItem('polarCookiesAccepted', 'true');
            cookieBanner.classList.remove('is-visible');
        });
    }

    if (contactForm && formStatus) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const requiredFields = ['name', 'company', 'email', 'topic', 'message'];
            const missing = requiredFields.some(field => !formData.get(field));

            if (missing || !contactForm.cons
ent.checked) {
                formStatus.textContent = 'Проверьте корректность заполнения обязательных полей и согласие на обработку данных.';
                formStatus.style.color = '#d9534f';
                return;
            }

            formStatus.textContent = 'Спасибо! Ваш запрос отправлен. Мы свяжемся с вами в ближайшее время.';
            formStatus.style.color = '#2e7d32';
            contactForm.reset();
        });
    }
});