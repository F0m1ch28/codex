import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className="container">
        <div className={styles.grid}>
          <div>
            <h2 id="footer-heading" className={styles.title}>
              Aurion Energy Advisory
            </h2>
            <p className={styles.description}>
              Engineering insight for complex energy systems across Canada and beyond. We bring integrated consulting and on-site execution together to accelerate responsible energy projects.
            </p>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Visit Us</h3>
            <address className={styles.address}>
              460 Bay St<br />
              Toronto, ON M5H 2Y4<br />
              Canada
            </address>
            <p className={styles.contactLine}>
              <span className={styles.contactLabel}>Phone:</span> +1 (416) 792-4583
            </p>
            <p className={styles.contactLine}>
              <span className={styles.contactLabel}>Email:</span>{' '}
              <a href="mailto:info@aurionenergy.ca" className={styles.emailLink}>
                info@aurionenergy.ca
              </a>
            </p>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Explore</h3>
            <nav className={styles.footerNav} aria-label="Footer">
              <Link to="/about">About</Link>
              <Link to="/services">Services</Link>
              <Link to="/projects">Projects</Link>
              <Link to="/team">Team</Link>
              <Link to="/contact">Contact</Link>
            </nav>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Legal</h3>
            <nav className={styles.footerNav} aria-label="Legal">
              <Link to="/terms">Terms of Use</Link>
              <Link to="/privacy">Privacy Policy</Link>
              <Link to="/cookie-policy">Cookie Policy</Link>
            </nav>
            <p className={styles.copyNote}>
              © {new Date().getFullYear()} Aurion Energy Advisory. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;