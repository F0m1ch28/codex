import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { path: '/about', label: 'About' },
  { path: '/services', label: 'Services' },
  { path: '/projects', label: 'Projects' },
  { path: '/team', label: 'Team' },
  { path: '/contact', label: 'Contact' }
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleToggle = () => setMenuOpen((prev) => !prev);
  const handleClose = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.logo} onClick={handleClose}>
            <span className={styles.logoMark}>Aurion</span>
            <span className={styles.logoText}>Energy Advisory</span>
          </Link>
          <button
            className={styles.menuButton}
            onClick={handleToggle}
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
          >
            <span className={styles.menuIcon} />
          </button>
          <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`}>
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.active : ''}`
                }
                onClick={handleClose}
              >
                {link.label}
              </NavLink>
            ))}
            <Link to="/contact" className={styles.ctaLink} onClick={handleClose}>
              Partner with Aurion
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;