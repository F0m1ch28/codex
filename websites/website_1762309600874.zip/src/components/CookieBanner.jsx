import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'aurion-cookie-consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.message}>
          We use cookies to understand site traffic and improve your browsing experience. By continuing, you consent to our cookie policy.
        </p>
        <div className={styles.actions}>
          <a href="/cookie-policy" className={styles.link}>
            Learn more
          </a>
          <button type="button" onClick={handleAccept} className={styles.button}>
            Accept
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;