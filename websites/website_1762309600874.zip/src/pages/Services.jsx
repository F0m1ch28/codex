import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    title: 'Energy Consulting',
    description:
      'Strategic advisory for upstream, midstream, and downstream operations with scenario modelling, regulatory alignment, and stakeholder mapping.',
    points: [
      'Energy transition roadmaps',
      'Infrastructure modernization strategies',
      'Stakeholder engagement planning'
    ],
    image:
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Oilfield Research',
    description:
      'Integrated geoscience and reservoir analytics to derisk exploration and optimize production planning.',
    points: [
      'Seismic evaluation and reservoir simulation',
      'Core sampling and lab analytics',
      'Regulatory documentation and reporting'
    ],
    image:
      'https://images.unsplash.com/photo-1584634731339-252c581abfcf?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Installation & Commissioning',
    description:
      'Full-spectrum field execution, equipment installation, and commissioning backed by digital oversight and logistics support.',
    points: [
      'Heavy lift planning and rigging design',
      'Instrumentation and control integration',
      'Performance testing and handover protocols'
    ],
    image:
      'https://images.unsplash.com/photo-1502791451862-7bd8c1df43a7?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Environmental Assessment',
    description:
      'Holistic environmental evaluations and mitigation strategies to meet provincial, federal, and international expectations.',
    points: [
      'Baseline studies and ecological monitoring',
      'Air, water, and soil impact assessments',
      'Adaptive management frameworks'
    ],
    image:
      'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1400&q=80'
  },
  {
    title: 'Project Management',
    description:
      'Integrated project controls, schedule stewardship, and digital collaboration to align teams from concept through completion.',
    points: [
      'PMO-as-a-service for energy portfolios',
      'Risk mitigation and change management',
      'Field reporting dashboards and KPIs'
    ],
    image:
      'https://images.unsplash.com/photo-1581090124544-45488982515a?auto=format&fit=crop&w=1400&q=80'
  }
];

function Services() {
  return (
    <>
      <Helmet>
        <title>Services | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Aurion Energy Advisory delivers consulting, research, installation, environmental assessment, and project management services for the energy sector."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>Services</h1>
          <p>
            Integrated consulting and engineering services tailored to the realities of modern energy operations.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <div
                  className={styles.serviceImage}
                  style={{ backgroundImage: `url(${service.image})` }}
                  aria-hidden="true"
                />
                <div className={styles.serviceContent}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                  <ul>
                    {service.points.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;