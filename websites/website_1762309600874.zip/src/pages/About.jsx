import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <>
      <Helmet>
        <title>About Aurion Energy Advisory | Engineering Leadership</title>
        <meta
          name="description"
          content="Discover Aurion Energy Advisory's history, leadership, mission, and commitment to safe, sustainable energy engineering solutions."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>About Aurion Energy Advisory</h1>
          <p>
            Built in Toronto, operating across North America, and collaborating globally to reimagine the future of energy infrastructure.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.history}>
            <div>
              <h2 className="sectionTitle">Our Story</h2>
              <p>
                Aurion Energy Advisory emerged in 2011 when engineers, geoscientists, and policy advisors saw a need for a partner that could navigate both the technical and human dimensions of energy transformation. We began with upstream development programs in the Prairies, expanding into integrated project delivery for industrial facilities, and today serve clients across the energy ecosystem.
              </p>
              <p>
                Our multidisciplinary teams combine field-proven experience with cutting-edge analytics to help organizations reduce environmental impact, modernize assets, and deliver resilient energy supply to communities.
              </p>
            </div>
            <div className={styles.historyImage} aria-hidden="true" />
          </div>
        </div>
      </section>

      <section className={`${styles.missionSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.missionGrid}>
            <article>
              <h3>Mission</h3>
              <p>
                To empower energy leaders with actionable insight, collaborative engineering, and accountable execution that respects communities and ecosystems.
              </p>
            </article>
            <article>
              <h3>Vision</h3>
              <p>
                A future where energy systems are resilient, data informed, and aligned with the climate ambitions of the regions they serve.
              </p>
            </article>
            <article>
              <h3>Values</h3>
              <ul className={styles.valueList}>
                <li>Integrity in every technical recommendation</li>
                <li>Respect for people and the environment</li>
                <li>Curiosity that drives innovation</li>
                <li>Accountability for measurable outcomes</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section className="sectionSpacing" aria-labelledby="leadership-heading">
        <div className="container">
          <h2 id="leadership-heading" className="sectionTitle">
            Leadership Team
          </h2>
          <div className={styles.leadershipGrid}>
            <article className={styles.leaderCard}>
              <div className={styles.leaderImageOne} aria-hidden="true" />
              <div className={styles.leaderContent}>
                <h3>Martina Desrosiers, P.Eng.</h3>
                <p className={styles.role}>Founder & Principal Engineer</p>
                <p>
                  With two decades in upstream development and facility design, Martina leads Aurion’s engineering practice and fosters partnerships with Indigenous communities to co-create energy solutions that reflect local priorities.
                </p>
              </div>
            </article>
            <article className={styles.leaderCard}>
              <div className={styles.leaderImageTwo} aria-hidden="true" />
              <div className={styles.leaderContent}>
                <h3>Dr. Joel Hart</h3>
                <p className={styles.role}>Director of Applied Research</p>
                <p>
                  Joel oversees our geoscience and analytics teams, translating seismic interpretation, reservoir simulation, and lab studies into field-ready strategies for clients across the continent.
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.commitments} sectionSpacing`}>
        <div className="container">
          <div className={styles.commitmentsGrid}>
            <article>
              <h3>Safety Culture</h3>
              <p>
                Safety is engineered into our workflows, from digital permitting to real-time hazard identification. Every Aurion professional is empowered to pause work and re-evaluate conditions.
              </p>
            </article>
            <article>
              <h3>Sustainability</h3>
              <p>
                We apply lifecycle thinking, low-carbon design, and environmental monitoring to ensure projects balance energy resiliency with climate responsibility.
              </p>
            </article>
            <article>
              <h3>Community Alignment</h3>
              <p>
                Aurion builds trust through transparent communication, localized training programs, and long-term partnerships with community leaders.
              </p>
            </article>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;