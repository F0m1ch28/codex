import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

function Terms() {
  return (
    <>
      <Helmet>
        <title>Terms of Use | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Review the terms governing use of the Aurion Energy Advisory website and related digital services."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>Terms of Use</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.content}>
            <h2>1. Acceptance of Terms</h2>
            <p>
              By accessing or using the Aurion Energy Advisory website, you acknowledge that you have read, understood, and agree to be bound by these terms. If you do not agree, please discontinue use of the site.
            </p>

            <h2>2. Intellectual Property</h2>
            <p>
              All content, including graphics, text, images, and trademarks, is owned by Aurion Energy Advisory or its licensors and is protected under applicable laws. You may not copy, modify, distribute, or create derivative works without written permission.
            </p>

            <h2>3. Use of Information</h2>
            <p>
              The information provided on this site is for general informational purposes only. While we strive for accuracy, we do not represent that the content is complete or up-to-date. Decisions should not be made solely on the basis of site content and should be supported by professional consultation.
            </p>

            <h2>4. Third-Party Links</h2>
            <p>
              This website may contain links to external websites maintained by third parties. Aurion Energy Advisory is not responsible for the content or practices of such third-party sites.
            </p>

            <h2>5. Limitation of Liability</h2>
            <p>
              Aurion Energy Advisory shall not be liable for any direct or indirect damages arising from the use or inability to use this website. You agree to use the site at your own discretion and responsibility.
            </p>

            <h2>6. Changes to Terms</h2>
            <p>
              We may update these terms from time to time. Continued use of the website after changes are posted signifies acceptance of the updated terms.
            </p>

            <h2>7. Governing Law</h2>
            <p>
              These terms are governed by the laws of the Province of Ontario and the federal laws of Canada applicable therein.
            </p>

            <h2>8. Contact</h2>
            <p>
              Questions about these terms may be directed to <a href="mailto:info@aurionenergy.ca">info@aurionenergy.ca</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Terms;