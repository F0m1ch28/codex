import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Understand how Aurion Energy Advisory collects, uses, and protects personal information on our website."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.content}>
            <h2>1. Overview</h2>
            <p>
              Aurion Energy Advisory respects your privacy and is committed to safeguarding personal information collected through this website.
            </p>

            <h2>2. Information We Collect</h2>
            <p>
              We may collect personal information that you voluntarily provide, such as your name, email address, company, and message details when you submit forms or contact us.
            </p>

            <h2>3. Use of Information</h2>
            <p>
              Personal information is used to respond to inquiries, provide requested services, and improve our website experience. We may also use aggregated data to understand site usage.
            </p>

            <h2>4. Cookies and Analytics</h2>
            <p>
              We use cookies and similar technologies to enhance site functionality and gather analytics. You may adjust browser settings to disable cookies; however, certain features may not operate as intended.
            </p>

            <h2>5. Sharing of Information</h2>
            <p>
              We do not sell or rent personal information. We may share data with trusted service providers who support our operations, provided they maintain similar privacy safeguards.
            </p>

            <h2>6. Data Security</h2>
            <p>
              We implement reasonable administrative, technical, and physical measures to protect personal information from unauthorized access or disclosure.
            </p>

            <h2>7. Data Retention</h2>
            <p>
              Personal information is retained only as long as necessary to fulfill the purposes outlined in this policy or to comply with legal obligations.
            </p>

            <h2>8. Your Rights</h2>
            <p>
              You may contact us to request access to, correction of, or deletion of your personal information, subject to applicable law.
            </p>

            <h2>9. Updates</h2>
            <p>
              We may update this policy periodically. Changes will be posted on this page with a revised effective date.
            </p>

            <h2>10. Contact</h2>
            <p>
              For privacy inquiries, please email <a href="mailto:info@aurionenergy.ca">info@aurionenergy.ca</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Privacy;