import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Team.module.css';

const teamMembers = [
  {
    name: 'Martina Desrosiers, P.Eng.',
    role: 'Founder & Principal Engineer',
    bio: 'Leads complex facility upgrades, heavy-lift operations, and safety-first engineering programs throughout Canada and the North Atlantic.',
    image:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80'
  },
  {
    name: 'Dr. Joel Hart',
    role: 'Director of Applied Research',
    bio: 'Guides seismic interpretation, reservoir simulation, and data science teams to deliver exploration intelligence.',
    image:
      'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=900&q=80'
  },
  {
    name: 'Sarah Menon',
    role: 'VP, Project Delivery',
    bio: 'Oversees integrated project management offices, schedule assurance, and collaborative delivery across multi-year programs.',
    image:
      'https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=900&q=80'
  },
  {
    name: 'Elias Thompson',
    role: 'Senior Field Engineer',
    bio: 'Specializes in instrumentation, commissioning, and remote operations support for oilfield and renewable deployments.',
    image:
      'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=900&q=80'
  },
  {
    name: 'Amelia Chong',
    role: 'Environmental Lead',
    bio: 'Develops environmental assessments, ecological monitoring strategies, and carbon reduction action plans.',
    image:
      'https://images.unsplash.com/photo-1525134479668-1bee5c7c8848?auto=format&fit=crop&w=900&q=80'
  },
  {
    name: 'Victor Rousseau',
    role: 'Logistics & Marine Engineer',
    bio: 'Designs marine transport plans, modular fabrication workflows, and offshore installation methods.',
    image:
      'https://images.unsplash.com/photo-1603415526960-f7e0328c63b1?auto=format&fit=crop&w=900&q=80'
  }
];

function Team() {
  return (
    <>
      <Helmet>
        <title>Team | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Meet Aurion Energy Advisory's consultants, engineers, and specialists dedicated to delivering resilient energy solutions."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>Our Team</h1>
          <p>
            Specialists, strategists, and engineers united by a shared commitment to responsible energy innovation.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.grid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.card}>
                <div
                  className={styles.image}
                  style={{ backgroundImage: `url(${member.image})` }}
                  aria-hidden="true"
                />
                <div className={styles.cardBody}>
                  <h2>{member.name}</h2>
                  <p className={styles.role}>{member.role}</p>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Team;