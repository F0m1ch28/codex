import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

function Contact() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
    setFormState({
      name: '',
      email: '',
      company: '',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>Contact | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Contact Aurion Energy Advisory for energy consulting, engineering, and project collaboration. Visit our Toronto office or send a message."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>Contact Us</h1>
          <p>
            Ready to advance your next energy initiative? Connect with our consultants and engineering teams to explore how we can help.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.details}>
              <h2 className="sectionTitle">Aurion Energy Advisory</h2>
              <p>
                460 Bay St<br />
                Toronto, ON M5H 2Y4<br />
                Canada
              </p>
              <p>
                <strong>Phone:</strong> +1 (416) 792-4583
              </p>
              <p>
                <strong>Email:</strong>{' '}
                <a href="mailto:info@aurionenergy.ca">info@aurionenergy.ca</a>
              </p>
              <div className={styles.mapWrapper}>
                <iframe
                  title="Aurion Energy Advisory Toronto Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.4425564842206!2d-79.38204792363032!3d43.65177137110115!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b34cdf7eb3df5%3A0xace6f3df06f7c163!2s460%20Bay%20St%2C%20Toronto%2C%20ON%20M5H%202Y4%2C%20Canada!5e0!3m2!1sen!2sca!4v1706370940000!5m2!1sen!2sca"
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
            <div className={styles.formCard}>
              <h2 className="sectionTitle">Send a Message</h2>
              <form onSubmit={handleSubmit} className={styles.form}>
                <label htmlFor="name">Full Name</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  value={formState.name}
                  onChange={handleChange}
                  placeholder="Your name"
                />

                <label htmlFor="email">Email Address</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={formState.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                />

                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formState.company}
                  onChange={handleChange}
                  placeholder="Your organization"
                />

                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  required
                  value={formState.message}
                  onChange={handleChange}
                  placeholder="How can we assist?"
                />

                <button type="submit" className={styles.submitButton}>
                  Submit Inquiry
                </button>
                {submitted && (
                  <p role="status" className={styles.successMessage}>
                    Thank you. Our team will respond shortly.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;