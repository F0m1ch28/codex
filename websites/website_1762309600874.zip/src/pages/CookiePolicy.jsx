import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="Learn how Aurion Energy Advisory uses cookies and related technologies to enhance user experience on this website."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>Effective date: January 1, 2024</p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.content}>
            <h2>1. What Are Cookies</h2>
            <p>
              Cookies are small text files stored on your device when you visit a website. They help us recognize your device and tailor the site to your preferences.
            </p>

            <h2>2. Types of Cookies We Use</h2>
            <ul>
              <li>
                <strong>Essential Cookies:</strong> Required for core site functionality, such as page navigation and secure access.
              </li>
              <li>
                <strong>Analytics Cookies:</strong> Help us understand how visitors interact with the site so we can improve performance and usability.
              </li>
              <li>
                <strong>Preference Cookies:</strong> Remember your choices, such as language or cookie consent settings.
              </li>
            </ul>

            <h2>3. Managing Cookies</h2>
            <p>
              Most browsers allow you to control cookies through their settings. You can delete existing cookies or configure your browser to refuse cookies altogether. Please note that disabling cookies may affect the site experience.
            </p>

            <h2>4. Third-Party Cookies</h2>
            <p>
              We may use trusted third-party providers for analytics or embedded services. These providers may set their own cookies subject to their respective policies.
            </p>

            <h2>5. Updates to This Policy</h2>
            <p>
              We may revise this policy periodically. Any updates will be posted on this page with the updated effective date.
            </p>

            <h2>6. Contact</h2>
            <p>
              For questions about our use of cookies, please contact <a href="mailto:info@aurionenergy.ca">info@aurionenergy.ca</a>.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;