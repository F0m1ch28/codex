import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Projects.module.css';

const projects = [
  {
    name: 'Northern Basin Wellness Retrofit',
    description:
      'Upgraded an existing processing facility with improved heat recovery systems, digital monitoring, and adaptive control logic to align with new environmental performance targets.',
    location: 'Fort St. John, British Columbia',
    image:
      'https://images.unsplash.com/photo-1513682121497-80211f36a0f4?auto=format&fit=crop&w=1400&q=80'
  },
  {
    name: 'Atlantic Offshore Expansion',
    description:
      'Provided deck layout redesign, heavy lift engineering, and marine logistics coordination for an offshore platform expansion adding subsea tiebacks.',
    location: 'St. John’s, Newfoundland and Labrador',
    image:
      'https://images.unsplash.com/photo-1582719478540-3b1c09954dda?auto=format&fit=crop&w=1400&q=80'
  },
  {
    name: 'Prairie Carbon Intelligence Program',
    description:
      'Built a data platform integrating emissions measurement, satellite imagery, and predictive analytics to guide carbon reduction actions on multiple sites.',
    location: 'Regina, Saskatchewan',
    image:
      'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1400&q=80'
  },
  {
    name: 'Urban Microgrid Integration',
    description:
      'Engineered the integration of solar arrays, battery storage, and grid controls for an industrial campus seeking resilient energy backup.',
    location: 'Hamilton, Ontario',
    image:
      'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1400&q=80'
  },
  {
    name: 'Arctic Logistics Hub',
    description:
      'Coordinated modular assembly, cold-weather protocols, and indigenous workforce programs for a remote logistics hub supporting northern exploration.',
    location: 'Inuvik, Northwest Territories',
    image:
      'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1400&q=80'
  },
  {
    name: 'Coastal LNG Readiness Study',
    description:
      'Conducted readiness assessments, marine interface modelling, and permitting documentation for a potential coastal LNG facility.',
    location: 'Prince Rupert, British Columbia',
    image:
      'https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1400&q=80'
  }
];

function Projects() {
  return (
    <>
      <Helmet>
        <title>Projects | Aurion Energy Advisory</title>
        <meta
          name="description"
          content="See how Aurion Energy Advisory delivers complex energy projects including retrofits, offshore expansions, microgrids, and logistics hubs."
        />
      </Helmet>
      <section className={styles.pageHero}>
        <div className="container">
          <h1>Project Highlights</h1>
          <p>
            Field-tested solutions designed to withstand harsh environments, strict regulations, and evolving stakeholder expectations.
          </p>
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.grid}>
            {projects.map((project) => (
              <article key={project.name} className={styles.card}>
                <div
                  className={styles.image}
                  style={{ backgroundImage: `url(${project.image})` }}
                  aria-hidden="true"
                />
                <div className={styles.cardBody}>
                  <h2>{project.name}</h2>
                  <p className={styles.location}>{project.location}</p>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Projects;