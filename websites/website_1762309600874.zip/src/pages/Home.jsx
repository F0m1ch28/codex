import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import styles from './Home.module.css';

function Home() {
  return (
    <>
      <Helmet>
        <title>Aurion Energy Advisory | Engineering the Future of Energy</title>
        <meta
          name="description"
          content="Aurion Energy Advisory blends strategy, engineering, and execution to modernize energy infrastructure with resilient and sustainable solutions."
        />
      </Helmet>
      <section className={styles.hero} role="banner">
        <div className={`container ${styles.heroContainer}`}>
          <div className={styles.heroContent}>
            <p className={styles.overline}>Canadian Consulting & Engineering</p>
            <h1 className={styles.heroTitle}>Engineering the Future of Energy</h1>
            <p className={styles.heroSubtitle}>
              Aurion Energy Advisory partners with operators to deliver reliable, low-carbon energy projects through integrated consulting, research, and field execution.
            </p>
            <div className={styles.heroActions}>
              <Link to="/services" className={styles.primaryBtn}>
                Explore Services
              </Link>
              <Link to="/projects" className={styles.secondaryBtn}>
                View Projects
              </Link>
            </div>
          </div>
          <div className={styles.heroVisual} aria-hidden="true" />
        </div>
      </section>

      <section className="sectionSpacing">
        <div className="container">
          <div className={styles.intro}>
            <h2 className="sectionTitle">Who We Are</h2>
            <p className="sectionSubtitle">
              Aurion Energy Advisory is a Toronto-based consulting and engineering firm helping energy leaders navigate complex infrastructure demands with clarity, rigour, and actionable insight.
            </p>
          </div>
        </div>
      </section>

      <section className={`${styles.expertise} sectionSpacing`} aria-labelledby="expertise-heading">
        <div className="container">
          <h2 id="expertise-heading" className="sectionTitle">
            Our Expertise
          </h2>
          <div className={styles.expertiseGrid}>
            <article className={styles.card}>
              <h3>Strategic Consulting</h3>
              <p>
                Scenario planning, regulatory alignment, and stakeholder engagement strategies that keep major energy initiatives on a predictable path.
              </p>
            </article>
            <article className={styles.card}>
              <h3>Applied Research</h3>
              <p>
                Reservoir modelling, seismic analysis, and field data validation to inform precise decision making for exploration programs.
              </p>
            </article>
            <article className={styles.card}>
              <h3>Installation & Commissioning</h3>
              <p>
                Multidisciplinary engineering teams delivering heavy-lift operations, control systems, and commissioning for onshore facilities.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.featureSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.featureGrid}>
            <div>
              <h2 className="sectionTitle">Oilfield Research</h2>
              <p className="sectionSubtitle">
                From exploratory mapping to compliance-ready documentation, our specialists equip drilling programs with precise subsurface intelligence.
              </p>
              <ul className={styles.featureList}>
                <li>Seismic interpretation and basin modelling</li>
                <li>Regulatory submissions and audit-ready reporting</li>
                <li>Digital twins of field assets for predictive analysis</li>
              </ul>
            </div>
            <div className={styles.featureImage} role="presentation" />
          </div>
        </div>
      </section>

      <section className={`${styles.featureSectionAlt} sectionSpacing`}>
        <div className="container">
          <div className={styles.featureGridAlt}>
            <div className={styles.featureImageCranes} role="presentation" />
            <div>
              <h2 className="sectionTitle">Engineering Solutions</h2>
              <p className="sectionSubtitle">
                Heavy lift logistics, modular fabrication, and real-time operations support keep complex installations moving safely and on schedule.
              </p>
              <ul className={styles.featureList}>
                <li>Rig upgrade programs and hoisting engineering</li>
                <li>Digital monitoring dashboards for field crews</li>
                <li>Integrated logistics for remote operations</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.sustainability} sectionSpacing`}>
        <div className="container">
          <div className={styles.sustainabilityContent}>
            <h2 className="sectionTitle">Sustainability in Action</h2>
            <p className="sectionSubtitle">
              We embed carbon-aware design principles, circular materials planning, and community dialogue into every stage of the energy value chain.
            </p>
            <div className={styles.sustainabilityGrid}>
              <article>
                <h3>Emissions Roadmaps</h3>
                <p>
                  Benchmarking current operations, defining reduction milestones, and translating commitments into measurable metrics.
                </p>
              </article>
              <article>
                <h3>Renewable Integration</h3>
                <p>
                  Hybrid systems for microgrids and industrial sites pairing conventional assets with solar, wind, and battery storage.
                </p>
              </article>
              <article>
                <h3>Community Stewardship</h3>
                <p>
                  Collaboration with Indigenous communities and civic partners to align energy projects with local priorities.
                </p>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.projects} sectionSpacing`} aria-labelledby="projects-heading">
        <div className="container">
          <h2 id="projects-heading" className="sectionTitle">
            Recent Projects
          </h2>
          <div className={styles.projectsGrid}>
            <article className={styles.projectCard}>
              <div className={styles.projectImageOne} aria-hidden="true" />
              <div>
                <h3>Arctic Pipeline Digitization</h3>
                <p>
                  Designed a digital command centre providing pipeline integrity data, predictive maintenance alerts, and stakeholder reporting for a northern operator.
                </p>
              </div>
            </article>
            <article className={styles.projectCard}>
              <div className={styles.projectImageTwo} aria-hidden="true" />
              <div>
                <h3>Carbon-Aware Refinery Retrofit</h3>
                <p>
                  Delivered engineering packages for heat integration, flare optimization, and control upgrades, cutting emissions intensity while maintaining throughput.
                </p>
              </div>
            </article>
            <article className={styles.projectCard}>
              <div className={styles.projectImageThree} aria-hidden="true" />
              <div>
                <h3>Offshore Logistics Program</h3>
                <p>
                  Coordinated modular fabrication, marine transport, and heavy lift sequences for an offshore platform expansion in the Atlantic.
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} sectionSpacing`} aria-labelledby="testimonials-heading">
        <div className="container">
          <h2 id="testimonials-heading" className="sectionTitle">
            Voices From the Field
          </h2>
          <div className={styles.testimonialsGrid}>
            <blockquote className={styles.testimonial}>
              <p>
                “Aurion reframed our growth strategy with data-rich insights and clear execution steps. Their engineering teams reinforced confidence across every stakeholder touchpoint.”
              </p>
              <footer>
                <span className={styles.clientName}>Lena McAllister</span>
                <span className={styles.clientRole}>Director, Northern Basin Operations</span>
              </footer>
            </blockquote>
            <blockquote className={styles.testimonial}>
              <p>
                “From feasibility through commissioning, Aurion’s collaboration and discipline kept our infrastructure upgrade aligned with new environmental expectations.”
              </p>
              <footer>
                <span className={styles.clientName}>Jonah Li</span>
                <span className={styles.clientRole}>VP Engineering, Continental Energy Stewardship</span>
              </footer>
            </blockquote>
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} sectionSpacing`}>
        <div className="container">
          <div className={styles.ctaCard}>
            <h2>Partner with Aurion</h2>
            <p>
              Let’s map your next energy milestone together—from visionary planning to detailed engineering and on-site execution.
            </p>
            <Link to="/contact" className={styles.ctaButton}>
              Start the Conversation
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Home;