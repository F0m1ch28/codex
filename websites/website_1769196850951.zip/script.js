document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.getElementById('navToggle');
  const primaryNav = document.getElementById('primaryNav');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', function () {
      const isOpen = primaryNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  const yearElement = document.getElementById('currentYear');
  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));

  const cookieBanner = document.getElementById('cookieBanner');
  const acceptBtn = document.getElementById('cookieAccept');
  const declineBtn = document.getElementById('cookieDecline');
  const cookieKey = 'hpCookieChoice';

  function hideBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove('active');
    }
  }

  if (cookieBanner && !localStorage.getItem(cookieKey)) {
    cookieBanner.classList.add('active');
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', function () {
      localStorage.setItem(cookieKey, 'accepted');
      hideBanner();
    });
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', function () {
      localStorage.setItem(cookieKey, 'declined');
      hideBanner();
    });
  }

  const formToast = document.getElementById('formToast');
  const forms = document.querySelectorAll('form[data-form]');
  forms.forEach((form) => {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      if (formToast) {
        formToast.classList.add('visible');
        setTimeout(() => {
          formToast.classList.remove('visible');
          window.location.href = form.getAttribute('action') || 'thank-you.html';
        }, 1800);
      } else {
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }
    });
  });
});