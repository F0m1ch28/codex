import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}
      aria-label="Hauptnavigation"
    >
      <div className={styles.inner}>
        <Link to="/" className={styles.brand} aria-label="Silaventino Startseite">
          <span className={styles.logoMark}>S</span>
          <span className={styles.logoText}>Silaventino</span>
        </Link>
        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Navigation umschalten"
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="primary-navigation"
          className={`${styles.nav} ${menuOpen ? styles.open : ''}`}
          aria-label="Primäre Navigation"
        >
          <NavLink to="/" className={({ isActive }) => (isActive ? styles.active : undefined)} end>
            Startseite
          </NavLink>
          <NavLink to="/guide" className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Leitfaden
          </NavLink>
          <NavLink
            to="/programs"
            className={({ isActive }) => (isActive ? styles.active : undefined)}
          >
            Programme
          </NavLink>
          <NavLink to="/tools" className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Tools
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Blog
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Angebote
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? styles.active : undefined)}>
            Über uns
          </NavLink>
          <Link to="/contact" className={`${styles.ctaLink} buttonPrimary`}>
            Kontakt
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;