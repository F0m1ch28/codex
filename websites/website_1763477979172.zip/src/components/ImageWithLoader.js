import React, { useState } from 'react';
import styles from './ImageWithLoader.module.css';

const ImageWithLoader = ({ src, alt }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <div className={styles.wrapper} aria-busy={!loaded}>
      {!loaded && <div className={styles.loader} aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        className={`${styles.image} ${loaded ? styles.visible : ''}`}
        onLoad={() => setLoaded(true)}
      />
    </div>
  );
};

export default ImageWithLoader;