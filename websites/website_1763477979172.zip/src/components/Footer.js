import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Seitenende">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <span className={styles.logo}>S</span>
          <div>
            <p className={styles.title}>Silaventino</p>
            <p className={styles.subtitle}>Kommunikation, die verbindet.</p>
          </div>
        </div>
        <div className={styles.columns}>
          <div>
            <h3>Navigation</h3>
            <ul>
              <li>
                <Link to="/">Startseite</Link>
              </li>
              <li>
                <Link to="/guide">Leitfaden</Link>
              </li>
              <li>
                <Link to="/programs">Programme</Link>
              </li>
              <li>
                <Link to="/tools">Tools</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3>Unternehmen</h3>
            <ul>
              <li>
                <Link to="/about">Über uns</Link>
              </li>
              <li>
                <Link to="/services">Angebote</Link>
              </li>
              <li>
                <Link to="/blog">Blog</Link>
              </li>
              <li>
                <Link to="/contact">Kontakt</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3>Rechtliches</h3>
            <ul>
              <li>
                <Link to="/legal">AGB</Link>
              </li>
              <li>
                <Link to="/privacy">Datenschutz</Link>
              </li>
              <li>
                <Link to="/imprint">Impressum</Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {currentYear} Silaventino. Alle Rechte vorbehalten.</p>
      </div>
    </footer>
  );
};

export default Footer;