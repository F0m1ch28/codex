import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('silaventino_cookie_consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('silaventino_cookie_consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem('silaventino_cookie_consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div>
        <h2>Cookies für ein besseres Erlebnis</h2>
        <p>
          Wir verwenden Cookies, um dir eine angenehme Nutzung zu ermöglichen und anonyme
          Statistiken zu verstehen. Du entscheidest, was für dich passt.
        </p>
      </div>
      <div className={styles.actions}>
        <button type="button" className="buttonSecondary" onClick={handleDecline}>
          Ablehnen
        </button>
        <button type="button" className="buttonPrimary" onClick={handleAccept}>
          Zustimmen
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;