import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // Optional: Logging einfügen
    console.error('Fehler im UI:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            maxWidth: '720px',
            margin: '6rem auto',
            padding: '3rem',
            textAlign: 'center',
            background: '#fff',
            borderRadius: '24px',
            boxShadow: '0 28px 64px rgba(15, 23, 42, 0.08)',
          }}
        >
          <h1 style={{ fontSize: '2rem', marginBottom: '1rem', color: '#2D3748' }}>
            Etwas ist schiefgelaufen
          </h1>
          <p style={{ color: '#4A5568', lineHeight: 1.6 }}>
            Bitte lade die Seite neu oder versuche es später noch einmal. Wenn das Problem bestehen
            bleibt, melde dich gerne bei uns.
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;