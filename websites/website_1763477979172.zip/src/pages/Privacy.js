import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Privacy.module.css';

const Privacy = () => (
  <>
    <Helmet>
      <title>Datenschutz – Silaventino</title>
      <meta
        name="description"
        content="Datenschutzhinweise von Silaventino. Erfahre, wie wir mit deinen Daten umgehen und sie schützen."
      />
    </Helmet>
    <section className={styles.container}>
      <h1>Datenschutzerklärung</h1>
      <p className={styles.updated}>Stand: Januar 2025</p>

      <h2>1. Verantwortliche Stelle</h2>
      <p>
        Silaventino · Musterstraße 12, 10115 Berlin · E-Mail:{' '}
        <a href="mailto:info@silaventino.site">info@silaventino.site</a>
      </p>

      <h2>2. Verarbeitung personenbezogener Daten</h2>
      <p>
        Wir verarbeiten personenbezogene Daten nur, wenn du uns diese freiwillig zur Verfügung
        stellst, z. B. durch Nachrichten über das Kontaktformular oder die Anmeldung zu Programmen.
      </p>

      <h2>3. Zwecke</h2>
      <p>
        Daten werden ausschließlich zur Bearbeitung deiner Anfrage, zur Bereitstellung digitaler
        Angebote und zur technischen Administration genutzt. Eine Weitergabe findet nicht statt, es
        sei denn, wir sind rechtlich dazu verpflichtet.
      </p>

      <h2>4. Rechtsgrundlage</h2>
      <p>
        Grundlage der Verarbeitung sind Art. 6 Abs. 1 lit. a (Einwilligung) und lit. b (Vertragserfüllung)
        DSGVO.
      </p>

      <h2>5. Speicherdauer</h2>
      <p>
        Wir speichern deine Daten nur so lange, wie es für die genannten Zwecke erforderlich ist oder
        gesetzliche Aufbewahrungspflichten bestehen.
      </p>

      <h2>6. Deine Rechte</h2>
      <p>
        Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch und
        Datenübertragbarkeit. Wende dich dazu an{' '}
        <a href="mailto:info@silaventino.site">info@silaventino.site</a>.
      </p>

      <h2>7. Cookies</h2>
      <p>
        Wir verwenden Cookies, um die Nutzung der Website zu verbessern. Du kannst dem zustimmen oder
        widersprechen. Details findest du im Cookie-Banner.
      </p>

      <h2>8. Sicherheit</h2>
      <p>
        Wir setzen technische und organisatorische Maßnahmen ein, um deine Daten gegen Verlust,
        Manipulation oder unbefugten Zugriff zu schützen.
      </p>
    </section>
  </>
);

export default Privacy;