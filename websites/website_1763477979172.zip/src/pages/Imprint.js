import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Imprint.module.css';

const Imprint = () => (
  <>
    <Helmet>
      <title>Impressum – Silaventino</title>
      <meta
        name="description"
        content="Impressum von Silaventino. Rechtliche Angaben und Kontaktinformationen."
      />
    </Helmet>
    <section className={styles.container}>
      <h1>Impressum</h1>

      <h2>Angaben gemäß § 5 TMG</h2>
      <p>
        Silaventino<br />
        Musterstraße 12<br />
        10115 Berlin
      </p>

      <h2>Kontakt</h2>
      <p>
        Telefon: +49 (0)30 12345678<br />
        E-Mail: <a href="mailto:info@silaventino.site">info@silaventino.site</a>
      </p>

      <h2>Vertreten durch</h2>
      <p>Lea Carstens</p>

      <h2>Umsatzsteuer-ID</h2>
      <p>Gemäß § 19 UStG wird keine Umsatzsteuer ausgewiesen.</p>

      <h2>Haftung für Inhalte</h2>
      <p>
        Wir erstellen die Inhalte dieser Seite mit großer Sorgfalt. Für die Aktualität, Vollständigkeit
        und Richtigkeit können wir dennoch keine Gewähr übernehmen. Verbindliche Beratung bieten wir
        nicht an.
      </p>

      <h2>Haftung für Links</h2>
      <p>
        Externe Links prüfen wir sorgfältig. Für Inhalte verlinkter Seiten sind jedoch ausschließlich
        deren Betreiber verantwortlich.
      </p>

      <h2>Urheberrecht</h2>
      <p>
        Inhalte und Werke auf dieser Website unterliegen dem deutschen Urheberrecht. Vervielfältigung,
        Bearbeitung oder Verbreitung bedürfen unserer schriftlichen Zustimmung.
      </p>
    </section>
  </>
);

export default Imprint;