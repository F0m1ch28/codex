import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Tools.module.css';

const Tools = () => {
  const tools = [
    {
      title: 'Gesprächs-Vorbereitungsbogen',
      description:
        'Strukturiere Anliegen, Ziele und mögliche Reaktionen, bevor du startest. Mit Platz für Notizen.',
      format: 'PDF & interaktive Version',
    },
    {
      title: 'Ich-Botschaften-Formulierungshilfe',
      description:
        'Finde Worte, die klar sind und trotzdem Nähe herstellen. Mit Beispielen für Alltag, Familie und Job.',
      format: 'Vorlage + Audio-Impulse',
    },
    {
      title: 'Checkliste für schwierige Gespräche',
      description:
        'Ein sicherer Rahmen für heikle Situationen – von der Einladung bis zum Follow-up.',
      format: 'Checkliste + Fragenkatalog',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Tools & Checklisten – Sofort anwendbar</title>
        <meta
          name="description"
          content="Nutze die Tools von Silaventino: Vorbereitungsbogen, Ich-Botschaften-Hilfe und Checklisten für schwierige Gespräche."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Tools, die dich begleiten</h1>
        <p>
          Lade dir Vorlagen herunter, die dich bei Vorbereitung, Struktur und Reflexion unterstützen
          – jederzeit griffbereit.
        </p>
      </section>
      <section className={styles.grid} aria-labelledby="tools-list-heading">
        <h2 id="tools-list-heading" className="sr-only">
          Übersicht Tools
        </h2>
        {tools.map((tool) => (
          <article key={tool.title} className={styles.card}>
            <h3>{tool.title}</h3>
            <p>{tool.description}</p>
            <p className={styles.format}>{tool.format}</p>
            <div className={styles.actions}>
              <button type="button" className="buttonPrimary">
                Download
              </button>
              <button type="button" className="buttonOutline">
                Online ansehen
              </button>
            </div>
          </article>
        ))}
      </section>
    </>
  );
};

export default Tools;