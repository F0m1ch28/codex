import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Blog.module.css';

const posts = [
  {
    title: 'Wertschätzende Kommunikation im hektischen Alltag',
    category: 'Alltag',
    time: '5 Min Lesezeit',
    excerpt:
      'Fünf kleine Rituale, mit denen du Wertschätzung zeigst – selbst wenn der Terminkalender voll ist.',
  },
  {
    title: 'Konflikte im Team souverän entschärfen',
    category: 'Team',
    time: '7 Min Lesezeit',
    excerpt:
      'So bereitest du ein Konfliktgespräch vor, in dem alle auf Augenhöhe sprechen.',
  },
  {
    title: 'Grenzen setzen ohne schlechtes Gewissen',
    category: 'Persönlich',
    time: '6 Min Lesezeit',
    excerpt:
      'Klare Ich-Botschaften, mit denen du bleibst, wer du bist – ohne dich zu verbiegen.',
  },
  {
    title: 'Feedback geben, das ankommt',
    category: 'Führung',
    time: '8 Min Lesezeit',
    excerpt:
      'Ein dreiteiliger Aufbau, der Feedback fair, konkret und entwicklungsorientiert macht.',
  },
];

const Blog = () => (
  <>
    <Helmet>
      <title>Blog – Impulse für wertschätzende Kommunikation</title>
      <meta
        name="description"
        content="Der Silaventino Blog liefert dir Impulse für Kommunikation, Konfliktlösung und respektvolle Gespräche im Alltag und im Team."
      />
    </Helmet>
    <section className={styles.hero}>
      <h1>Silaventino Impulse</h1>
      <p>Wissen, Inspiration und Übungen für Gespräche, die verbinden.</p>
    </section>
    <section className={styles.grid} aria-label="Blogartikel">
      {posts.map((post) => (
        <article key={post.title} className={styles.card}>
          <p className={styles.meta}>
            {post.category} · {post.time}
          </p>
          <h2>{post.title}</h2>
          <p>{post.excerpt}</p>
          <button type="button" className={styles.readMore}>
            Beitrag lesen
          </button>
        </article>
      ))}
    </section>
  </>
);

export default Blog;