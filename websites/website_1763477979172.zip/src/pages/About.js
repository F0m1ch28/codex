import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import ImageWithLoader from '../components/ImageWithLoader';
import styles from './About.module.css';

const teamMembers = [
  {
    name: 'Lea Carstens',
    role: 'Gründerin & Kommunikationstrainerin',
    bio: 'Lea entwickelt praxistaugliche Leitfäden und moderiert Workshops in Unternehmen, Schulen und Familiennetzwerken.',
    focus: 'Stärkenorientierte Gesprächsführung, Konfliktmoderation, Team-Feedback',
    image: 'https://picsum.photos/400/400?random=21',
  },
  {
    name: 'Jonas Reuter',
    role: 'Programmgestaltung & Community',
    bio: 'Jonas sorgt dafür, dass unsere Programme leicht zugänglich sind und begleitet dich in der Community.',
    focus: 'Digitale Lernreisen, Community-Begleitung, Gamification',
    image: 'https://picsum.photos/400/400?random=22',
  },
  {
    name: 'Merve Aydin',
    role: 'Content & Sprache',
    bio: 'Merve übersetzt komplexe Themen in klare, warmherzige Texte und Checklisten.',
    focus: 'Storytelling, Dialoggestaltung, Diversity-sensitive Sprache',
    image: 'https://picsum.photos/400/400?random=23',
  },
];

const About = () => {
  const [activeMember, setActiveMember] = useState(teamMembers[0]);

  return (
    <>
      <Helmet>
        <title>Über Silaventino – Kommunikation, die verbindet</title>
        <meta
          name="description"
          content="Silaventino unterstützt Menschen in Deutschland dabei, respektvoll zu kommunizieren. Erfahre mehr über Mission, Werte und das Team."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.kicker}>Unsere Mission</p>
          <h1>Wir machen gute Gespräche selbstverständlich.</h1>
          <p>
            Silaventino steht für Kommunikation, die klar, langsam genug und respektvoll ist. Wir
            begleiten dich, damit aus Konflikten Chancen werden und Gespräche nicht mehr
            erschrecken, sondern verbinden.
          </p>
        </div>
        <div className={styles.heroImage}>
          <ImageWithLoader
            src="https://picsum.photos/800/600?random=24"
            alt="Team arbeitet gemeinsam an Kommunikationskonzepten"
          />
        </div>
      </section>

      <section className={styles.values} aria-labelledby="values-heading">
        <div className="section-heading">
          <h2 id="values-heading">Werte, die wir leben</h2>
          <p>Unsere Haltung prägt jedes Tool und jede Empfehlung, die du bei Silaventino findest.</p>
        </div>
        <div className={styles.valueGrid}>
          {[
            {
              title: 'Respekt & Zugewandtheit',
              text: 'Wir sehen den Menschen hinter jeder Position und fördern eine Kommunikation, die Beziehung stärkt.',
            },
            {
              title: 'Klarheit & Struktur',
              text: 'Wir liefern dir gut aufbereitete Methoden, damit du auch in schwierigen Momenten den Überblick behältst.',
            },
            {
              title: 'Eigenverantwortung',
              text: 'Wir unterstützen dich dabei, bewusst zu handeln – ohne zu bewerten oder Druck auszuüben.',
            },
            {
              title: 'Seriosität & Datenschutz',
              text: 'Deine Daten und deine Gesprächsinhalte bleiben geschützt. Wir arbeiten transparent und DSGVO-konform.',
            },
          ].map((value) => (
            <article className={styles.valueCard} key={value.title}>
              <h3>{value.title}</h3>
              <p>{value.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.team} aria-labelledby="team-heading">
        <div className="section-heading">
          <h2 id="team-heading">Das Team hinter Silaventino</h2>
          <p>
            Wir vereinen Kommunikationswissenschaft, Moderation, digitale Bildung und viel Herz für
            Menschen, die sich ehrlich begegnen wollen.
          </p>
        </div>
        <div className={styles.teamLayout}>
          <div className={styles.memberList}>
            {teamMembers.map((member) => (
              <button
                key={member.name}
                type="button"
                onClick={() => setActiveMember(member)}
                className={`${styles.memberButton} ${
                  activeMember.name === member.name ? styles.memberActive : ''
                }`}
                aria-pressed={activeMember.name === member.name}
              >
                <span>{member.name}</span>
                <small>{member.role}</small>
              </button>
            ))}
          </div>
          <div className={styles.memberDetail}>
            <ImageWithLoader src={activeMember.image} alt={activeMember.name} />
            <div className={styles.memberInfo}>
              <h3>{activeMember.name}</h3>
              <p className={styles.memberRole}>{activeMember.role}</p>
              <p className={styles.memberBio}>{activeMember.bio}</p>
              <p className={styles.memberFocus}>
                <strong>Schwerpunkte:</strong> {activeMember.focus}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.promise} aria-labelledby="promise-heading">
        <div className={styles.promiseCard}>
          <h2 id="promise-heading">Was du von uns erwarten kannst</h2>
          <ul>
            <li>Alltagstaugliche Impulse, die du in deinem Tempo nutzt.</li>
            <li>Kein Therapieversprechen, keine Rechtsberatung – dafür echte Orientierung.</li>
            <li>Transparente Kommunikation und ein respektvoller Umgang miteinander.</li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default About;