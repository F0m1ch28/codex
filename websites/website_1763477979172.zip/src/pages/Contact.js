import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ loading: false, success: null });

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Bitte gib deinen Namen ein.';
    if (!formData.email.trim()) {
      newErrors.email = 'Bitte gib deine E-Mail-Adresse ein.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    }
    if (!formData.message.trim()) newErrors.message = 'Was möchtest du uns mitteilen?';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    setStatus({ loading: true, success: null });
    setTimeout(() => {
      setStatus({ loading: false, success: true });
      setFormData({ name: '', email: '', message: '' });
    }, 1200);
  };

  return (
    <>
      <Helmet>
        <title>Kontakt – Silaventino</title>
        <meta
          name="description"
          content="Nimm Kontakt zu Silaventino auf. Wir freuen uns auf deine Fragen, Anliegen und Anregungen."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Lass uns sprechen</h1>
        <p>
          Du hast Fragen, möchtest ein Programm buchen oder brauchst Orientierung? Schreib uns –
          wir antworten in der Regel innerhalb von zwei Werktagen.
        </p>
      </section>
      <section className={styles.content}>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <h2>Schreib uns eine Nachricht</h2>
          <label htmlFor="name">
            Name
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Dein Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              aria-invalid={Boolean(errors.name)}
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </label>
          <label htmlFor="email">
            E-Mail
            <input
              id="email"
              name="email"
              type="email"
              placeholder="deine@mail.de"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              aria-invalid={Boolean(errors.email)}
            />
            {errors.email && <span className={styles.error}>{errors.email}</span>}
          </label>
          <label htmlFor="message">
            Nachricht
            <textarea
              id="message"
              name="message"
              placeholder="Worum geht es dir?"
              rows="6"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              aria-invalid={Boolean(errors.message)}
            />
            {errors.message && <span className={styles.error}>{errors.message}</span>}
          </label>
          <button type="submit" className="buttonPrimary" disabled={status.loading}>
            {status.loading ? 'Wird gesendet…' : 'Nachricht senden'}
          </button>
          {status.success && (
            <p className={styles.success}>Danke! Wir melden uns so schnell wie möglich bei dir.</p>
          )}
        </form>
        <div className={styles.info}>
          <h2>Kontaktinformationen</h2>
          <ul>
            <li>
              <strong>Adresse:</strong> Musterstraße 12, 10115 Berlin
            </li>
            <li>
              <strong>E-Mail:</strong> info@silaventino.site
            </li>
            <li>
              <strong>Telefon:</strong> +49 (0)30 12345678
            </li>
          </ul>
          <p>
            Wir bieten keine psychotherapeutische oder rechtliche Beratung. Wenn du Unterstützung in
            diesen Bereichen brauchst, wende dich bitte an entsprechende Fachstellen.
          </p>
        </div>
      </section>
    </>
  );
};

export default Contact;