import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import ImageWithLoader from '../components/ImageWithLoader';
import styles from './Home.module.css';

const Home = () => {
  const stats = useMemo(
    () => [
      { label: 'Reflektierte Gespräche', value: 1500 },
      { label: 'Teams begleitet', value: 120 },
      { label: 'Impulse pro Monat', value: 45 },
    ],
    []
  );
  const [counters, setCounters] = useState(stats.map(() => 0));
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Alle');
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounters((prev) =>
        prev.map((count, index) => {
          if (count >= stats[index].value) return stats[index].value;
          const increment = Math.ceil(stats[index].value / 60);
          return Math.min(count + increment, stats[index].value);
        })
      );
    }, 40);
    return () => clearInterval(interval);
  }, [stats]);

  const testimonials = [
    {
      quote:
        'Ich hätte nicht gedacht, dass ein paar klare Schritte so viel Ruhe in unsere Familiengespräche bringen. Endlich hört sich jeder wirklich zu.',
      name: 'Stefanie M., Köln',
      role: 'Mutter & Projektmanagerin',
    },
    {
      quote:
        'Der Leitfaden hilft mir, auch in stressigen Team-Meetings sachlich und gleichzeitig empathisch zu bleiben. Unsere Runde ist spürbar konstruktiver.',
      name: 'Tobias L., Hamburg',
      role: 'Teamleiter IT',
    },
    {
      quote:
        'Besonders die Vorbereitungstools sind Gold wert. Ich gehe jetzt sicherer in schwierige Gespräche und verliere nicht den roten Faden.',
      name: 'Mona M., München',
      role: 'HR Business Partner',
    },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const projects = [
    {
      id: 1,
      title: 'Familienrat ohne Schuldzuweisungen',
      category: 'Familie',
      description:
        'Strukturierte Gesprächsführung für ein entspanntes Wochenende mit allen Generationen.',
      image: 'https://picsum.photos/1200/800?random=41',
    },
    {
      id: 2,
      title: 'Feedbackroutine im Projektteam',
      category: 'Job',
      description:
        'Monatliche Feedbackgespräche, die Klarheit bringen und Motivation stärken.',
      image: 'https://picsum.photos/1200/800?random=42',
    },
    {
      id: 3,
      title: 'Konfliktklärungsraum im Kollegium',
      category: 'Job',
      description:
        'Etablierung von Check-ins, um Spannungen früh zu erkennen und lösungsorientiert zu bleiben.',
      image: 'https://picsum.photos/1200/800?random=43',
    },
    {
      id: 4,
      title: 'Freundschaft erhalten trotz Meinungsunterschieden',
      category: 'Freundeskreis',
      description:
        'Ein Leitfaden für respektvolle Diskussionen, wenn Werte aufeinanderprallen.',
      image: 'https://picsum.photos/1200/800?random=44',
    },
  ];

  const filters = ['Alle', 'Familie', 'Job', 'Freundeskreis'];

  const filteredProjects =
    activeFilter === 'Alle'
      ? projects
      : projects.filter((project) => project.category === activeFilter);

  const faqs = [
    {
      question: 'Für wen ist Silaventino gedacht?',
      answer:
        'Silaventino richtet sich an Menschen, die Kommunikation bewusst gestalten möchten – im Alltag, in der Familie, in der Partnerschaft oder im Job. Unsere Inhalte sind leicht zugänglich und ohne Vorkenntnisse nutzbar.',
    },
    {
      question: 'Wie schnell sehe ich Veränderungen?',
      answer:
        'Die ersten Aha-Momente kommen oft schon nach wenigen Tagen. Entscheidend ist, dass du dranbleibst und die Impulse ausprobierst. Unsere Programme helfen dir mit kleinen Schritten.',
    },
    {
      question: 'Brauche ich dafür viel Zeit?',
      answer:
        'Nein. Viele Impulse dauern nur wenige Minuten am Tag. Du kannst selbst entscheiden, wie intensiv du einsteigen möchtest.',
    },
    {
      question: 'Ist das eine Therapie oder Rechtsberatung?',
      answer:
        'Nein. Wir geben dir keine psychotherapeutische oder rechtliche Beratung. Silaventino bietet praxisnahe Kommunikations-Impulse für deinen Alltag.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Silaventino – Besser reden. Konflikte fair lösen.</title>
        <meta
          name="description"
          content="Silaventino unterstützt dich mit Leitfäden, Programmen und Tools für klare Gespräche und respektvolle Konfliktlösung – im Alltag, Beruf und in Beziehungen."
        />
        <meta property="og:title" content="Silaventino – Besser reden. Konflikte fair lösen." />
        <meta
          property="og:description"
          content="Entdecke Tools, Programme und Leitfäden für eine Kommunikation, die verbindet und Konflikte fair löst."
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <p className={styles.heroTag}>Kommunikation, die Verständigung schafft</p>
          <h1>Besser reden. Konflikte fair lösen.</h1>
          <p className={styles.heroText}>
            Silaventino begleitet dich dabei, Gespräche klar, respektvoll und wirksam zu führen –
            damit du in Alltag, Familie, Partnerschaft und Job sicher auftrittst und Missverständnisse
            rechtzeitig entschärfst.
          </p>
          <div className={styles.heroActions}>
            <Link to="/guide" className="buttonPrimary">
              Jetzt starten
            </Link>
            <Link to="/services" className="buttonOutline">
              Kommunikation stärken
            </Link>
          </div>
          <div className={styles.heroStats} aria-label="Ergebnisse in Zahlen">
            {stats.map((item, index) => (
              <div key={item.label}>
                <span>{counters[index]}+</span>
                <p>{item.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroImage}>
          <ImageWithLoader
            src="https://picsum.photos/1600/900?random=11"
            alt="Professionelles Gespräch in entspannter Atmosphäre"
          />
        </div>
      </section>

      <section className={styles.benefits} aria-labelledby="benefits-heading">
        <div className="section-heading">
          <h2 id="benefits-heading">Weniger Missverständnisse, mehr Verbindung</h2>
          <p>
            Unsere Impulse helfen dir, Gespräche gelassen zu führen – mit klarer Struktur und
            empathischer Haltung.
          </p>
        </div>
        <div className={styles.benefitGrid}>
          {[
            {
              title: 'Weniger Streit',
              text: 'Du lernst, Eskalationen früh zu erkennen und Spannungen in ruhige Bahnen zu lenken.',
            },
            {
              title: 'Mehr Verständnis',
              text: 'Aktives Zuhören und klare Nachfragen sorgen dafür, dass alle Perspektiven gehört werden.',
            },
            {
              title: 'Klarere Gespräche',
              text: 'Strukturierte Leitfäden helfen dir, Gespräche zielgerichtet aufzubauen.',
            },
            {
              title: 'Sicher auftreten',
              text: 'Du findest Worte für deine Anliegen, ohne andere zu verletzen oder dich kleinzumachen.',
            },
          ].map((benefit) => (
            <article className={styles.benefitCard} key={benefit.title}>
              <h3>{benefit.title}</h3>
              <p>{benefit.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.topics} aria-labelledby="topics-heading">
        <div className="section-heading">
          <h2 id="topics-heading">Deine Themen – unsere Schwerpunkte</h2>
          <p>
            Ob Alltag, Familie, Partnerschaft oder Team: Wir zeigen dir Wege, wie Gespräche fair
            bleiben und Lösungen entstehen.
          </p>
        </div>
        <div className={styles.topicGrid}>
          {[
            {
              title: 'Gespräche im Alltag',
              text: 'Schnelle Tools für mehr Klarheit in kurzen Alltagsmomenten.',
            },
            {
              title: 'Familie & Partnerschaft',
              text: 'Rituale und Gesprächsbögen, damit Nähe und Respekt wachsen.',
            },
            {
              title: 'Job & Team',
              text: 'Strategien für Feedback, Meetings und Konfliktklärungen im Team.',
            },
            {
              title: 'Schwierige Situationen',
              text: 'Roter Faden für heikle Gespräche, wenn viel auf dem Spiel steht.',
            },
          ].map((topic) => (
            <article className={styles.topicCard} key={topic.title}>
              <h3>{topic.title}</h3>
              <p>{topic.text}</p>
              <Link to="/programs" className={styles.topicLink}>
                Mehr erfahren →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.process} aria-labelledby="process-heading">
        <div className="section-heading">
          <h2 id="process-heading">So begleitet dich Silaventino Schritt für Schritt</h2>
          <p>
            Unsere Methode verbindet Reflexion, konkrete Gesprächsstruktur und eine Haltung, die
            Verbindung schafft. Du setzt direkt um.
          </p>
        </div>
        <div className={styles.processSteps}>
          {[
            {
              step: '01',
              title: 'Selbstreflexion',
              text: 'Du erkennst Muster, Trigger und Bedürfnisse – die Grundlage für Veränderung.',
            },
            {
              step: '02',
              title: 'Zuhören & Spiegeln',
              text: 'Du trainierst aktives Zuhören und spiegelst das Gehörte ohne Bewertung.',
            },
            {
              step: '03',
              title: 'Ich-Botschaften',
              text: 'Du formulierst klar, wie es dir geht, und bleibst dabei respektvoll.',
            },
            {
              step: '04',
              title: 'Grenzen wahren',
              text: 'Du kommunizierst Grenzen, ohne Druck auszuüben – freundlich und bestimmt.',
            },
            {
              step: '05',
              title: 'Lösungen finden',
              text: 'Du leitest einen Dialog, der tragfähige Lösungen sichtbar macht.',
            },
          ].map((item) => (
            <article className={styles.processCard} key={item.step}>
              <span>{item.step}</span>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.why} aria-labelledby="why-heading">
        <div className="section-heading">
          <h2 id="why-heading">Warum Silaventino?</h2>
          <p>
            Weil du Werkzeuge brauchst, die funktionieren – nicht nur in der Theorie, sondern mitten
            im echten Leben.
          </p>
        </div>
        <div className={styles.whyGrid}>
          {[
            {
              title: 'Alltagstauglich & klar',
              text: 'Unsere Impulse sind kompakt, leicht zu verstehen und sofort anwendbar.',
            },
            {
              title: 'Deutschsprachig & nah dran',
              text: 'Entwickelt für den Alltag in Deutschland, mit kulturellem Fingerspitzengefühl.',
            },
            {
              title: 'Ethisch & seriös',
              text: 'Wir arbeiten transparent, verantwortungsvoll und ohne unrealistische Versprechen.',
            },
            {
              title: 'Flexibel nutzbar',
              text: 'Passe die Tools an deine Situation an – ob Solo oder gemeinsam im Team.',
            },
          ].map((item) => (
            <article className={styles.whyCard} key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-heading">
        <div className="section-heading">
          <h2 id="testimonials-heading">Stimmen aus der Silaventino-Community</h2>
          <p>
            Menschen aus ganz Deutschland setzen unsere Impulse ein – von der WG-Küche bis zum
            Führungsteam.
          </p>
        </div>
        <div className={styles.testimonialSlider}>
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.name}
              className={`${styles.testimonialCard} ${
                index === activeTestimonial ? styles.testimonialActive : ''
              }`}
              aria-hidden={index !== activeTestimonial}
            >
              <p className={styles.quote}>“{testimonial.quote}”</p>
              <div className={styles.person}>
                <p className={styles.name}>{testimonial.name}</p>
                <p className={styles.role}>{testimonial.role}</p>
              </div>
            </article>
          ))}
          <div className={styles.dots} role="tablist" aria-label="Testimonials auswählen">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                className={`${styles.dot} ${
                  index === activeTestimonial ? styles.dotActive : ''
                }`}
                onClick={() => setActiveTestimonial(index)}
                aria-label={`Testimonial ${index + 1} anzeigen`}
                aria-selected={index === activeTestimonial}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects} aria-labelledby="projects-heading">
        <div className="section-heading">
          <h2 id="projects-heading">Anwendungsbeispiele aus der Praxis</h2>
          <p>
            Lass dich inspirieren, wie andere Silaventino nutzen, um gute Gespräche anzustoßen und
            Lösungen zu gestalten.
          </p>
        </div>
        <div className={styles.filterBar} role="tablist" aria-label="Filter für Projekte">
          {filters.map((filter) => (
            <button
              key={filter}
              type="button"
              className={`${styles.filterButton} ${
                activeFilter === filter ? styles.filterActive : ''
              }`}
              onClick={() => setActiveFilter(filter)}
              aria-pressed={activeFilter === filter}
            >
              {filter}
            </button>
          ))}
        </div>
        <div className={styles.projectGrid}>
          {filteredProjects.map((project) => (
            <article className={styles.projectCard} key={project.id}>
              <ImageWithLoader src={project.image} alt={`Projekt: ${project.title}`} />
              <div className={styles.projectContent}>
                <span>{project.category}</span>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.blogPreview} aria-labelledby="blog-preview-heading">
        <div className="section-heading">
          <h2 id="blog-preview-heading">Aktuelle Impulse aus dem Blog</h2>
          <p>Frische Gedanken, konkrete Übungen und Tipps, die dich sofort weiterbringen.</p>
        </div>
        <div className={styles.blogGrid}>
          {[
            {
              title: 'Wertschätzende Kommunikation im hektischen Alltag',
              category: 'Alltag',
              time: '5 Min',
              excerpt:
                'Wie du kurze Momente nutzt, um Wertschätzung zu zeigen – auch wenn der Tag voll ist.',
            },
            {
              title: 'Konflikte im Team entschärfen',
              category: 'Team',
              time: '7 Min',
              excerpt:
                'Checkliste für Meetings, in denen du Spannungen ansprichst, ohne Fronten zu bauen.',
            },
            {
              title: 'Grenzen setzen ohne schlechtes Gewissen',
              category: 'Persönlich',
              time: '6 Min',
              excerpt:
                'Vier Formulierungen, mit denen du klar bleibst und trotzdem Verbindung hältst.',
            },
          ].map((post) => (
            <article className={styles.blogCard} key={post.title}>
              <p className={styles.blogMeta}>
                {post.category} · {post.time}
              </p>
              <h3>{post.title}</h3>
              <p>{post.excerpt}</p>
              <Link to="/blog" className={styles.blogLink}>
                Zum Beitrag →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faq} aria-labelledby="faq-heading">
        <div className="section-heading">
          <h2 id="faq-heading">Häufige Fragen</h2>
          <p>
            Hier findest du schnelle Antworten. Wenn noch etwas offen bleibt, schreib uns jederzeit.
          </p>
        </div>
        <div className={styles.faqList}>
          {faqs.map((item, index) => (
            <article key={item.question} className={styles.faqItem}>
              <button
                className={styles.faqToggle}
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
                aria-expanded={openFaq === index}
              >
                <span>{item.question}</span>
                <span aria-hidden="true">{openFaq === index ? '–' : '+'}</span>
              </button>
              {openFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
            </article>
          ))}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaCard}>
          <h2>Bereit für Gespräche, die verbinden?</h2>
          <p>
            Starte heute mit dem Leitfaden oder tauche in eines unserer Programme ein. Silaventino
            begleitet dich Schritt für Schritt.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/programs" className="buttonPrimary">
              Programm wählen
            </Link>
            <Link to="/contact" className="buttonOutline">
              Fragen stellen
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;