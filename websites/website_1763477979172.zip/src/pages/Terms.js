import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Terms.module.css';

const Terms = () => (
  <>
    <Helmet>
      <title>AGB – Silaventino</title>
      <meta
        name="description"
        content="Allgemeine Geschäftsbedingungen von Silaventino. Transparente und faire Rahmenbedingungen."
      />
    </Helmet>
    <section className={styles.container}>
      <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
      <p className={styles.updated}>Stand: Januar 2025</p>

      <h2>1. Geltungsbereich</h2>
      <p>
        Diese AGB gelten für alle digitalen Angebote, Programme und Tools von Silaventino. Abweichende
        Vereinbarungen gelten nur, wenn sie schriftlich bestätigt wurden.
      </p>

      <h2>2. Leistungen</h2>
      <p>
        Silaventino stellt digitale Inhalte bereit, die der Reflexion und Verbesserung von
        Kommunikation dienen. Es handelt sich nicht um psychotherapeutische, medizinische oder
        rechtliche Beratung.
      </p>

      <h2>3. Nutzung</h2>
      <p>
        Die Nutzung der Inhalte erfolgt eigenverantwortlich. Du verpflichtest dich, Zugangsdaten nicht
        an Dritte weiterzugeben und Urheberrechte zu respektieren.
      </p>

      <h2>4. Haftung</h2>
      <p>
        Für Schäden aus einfacher Fahrlässigkeit haftet Silaventino nur bei Verletzung wesentlicher
        Vertragspflichten. Für indirekte Schäden oder entgangenen Gewinn wird keine Haftung übernommen.
      </p>

      <h2>5. Widerruf</h2>
      <p>
        Bei digitalen Produkten, die unmittelbar zur Verfügung gestellt werden, erlischt das
        Widerrufsrecht, sobald du ausdrücklich zustimmst, dass wir mit der Ausführung vor Ablauf der
        Widerrufsfrist beginnen.
      </p>

      <h2>6. Änderungen</h2>
      <p>
        Wir können diese AGB anpassen. Über wesentliche Änderungen informieren wir dich rechtzeitig.
      </p>

      <h2>7. Kontakt</h2>
      <p>
        Fragen zu diesen AGB? Schreib an <a href="mailto:info@silaventino.site">info@silaventino.site</a>.
      </p>
    </section>
  </>
);

export default Terms;