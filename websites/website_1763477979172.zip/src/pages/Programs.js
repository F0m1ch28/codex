import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Programs.module.css';

const Programs = () => {
  const programs = [
    {
      title: '7-Tage-Respektvoll-reden',
      duration: '7 Tage',
      level: 'Einsteiger:innen',
      focus: 'Ruhig bleiben, Klartext sprechen, neue Rituale etablieren.',
      result: 'Du reagierst gelassener und findest Worte, die verbinden.',
    },
    {
      title: 'Konfliktgespräche vorbereiten',
      duration: '5 Module',
      level: 'Fortgeschrittene',
      focus: 'Analysiere Konflikte, plane den Gesprächsverlauf und sichere Nachbereitung.',
      result: 'Du startest schwierige Gespräche sicher und bleibst souverän.',
    },
    {
      title: '30 Tage bewusster zuhören',
      duration: '30 Tage',
      level: 'Alle Level',
      focus: 'Aktives Zuhören, Spiegeln, Empathie zeigen, ohne dich zu verlieren.',
      result: 'Du wirst zu einer Person, der andere sich gerne anvertrauen.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Programme – Deine Reise zu klarer Kommunikation</title>
        <meta
          name="description"
          content="Wähle das passende Programm von Silaventino: Respektvolle Gespräche führen, Konfliktgespräche vorbereiten oder bewusster zuhören."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Programme, die dich begleiten</h1>
        <p>
          Jedes Programm verbindet Reflexion, konkrete Übungen und Micro-Learnings. Du entscheidest,
          wann und wie du deine Kommunikationsskills ausbaust.
        </p>
      </section>
      <section className={styles.programs} aria-labelledby="programs-heading">
        <div className="section-heading">
          <h2 id="programs-heading">Unsere Lernreisen</h2>
          <p>Alles digital, flexibel und mit viel Herz entwickelt.</p>
        </div>
        <div className={styles.programGrid}>
          {programs.map((program) => (
            <article key={program.title} className={styles.programCard}>
              <h3>{program.title}</h3>
              <ul className={styles.meta}>
                <li>
                  <strong>Dauer:</strong> {program.duration}
                </li>
                <li>
                  <strong>Niveau:</strong> {program.level}
                </li>
              </ul>
              <p className={styles.focus}>{program.focus}</p>
              <p className={styles.result}>{program.result}</p>
              <button type="button" className="buttonOutline">
                Programm starten
              </button>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};

export default Programs;