import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Guide.module.css';

const Guide = () => {
  const steps = [
    {
      title: 'Eigene Muster erkennen',
      points: [
        'Was triggert dich? Notiere typische Situationen.',
        'Welche Gedanken laufen dabei ab?',
        'Welche Bedürfnisse stecken hinter deiner Reaktion?',
      ],
    },
    {
      title: 'Aktiv zuhören',
      points: [
        'Lass dein Gegenüber ausreden, ohne zu unterbrechen.',
        'Spiegele das Gehörte in deinen Worten.',
        'Frag nach, ob du richtig verstanden hast.',
      ],
    },
    {
      title: 'Ich-Botschaften nutzen',
      points: [
        'Beschreibe deine Wahrnehmung ohne Vorwurf.',
        'Benenne deine Gefühle und Bedürfnisse.',
        'Sag, was du dir konkret wünschst.',
      ],
    },
    {
      title: 'Grenzen respektvoll ausdrücken',
      points: [
        'Formuliere klar, was für dich nicht möglich ist.',
        'Bleib bei dir, anstatt andere zu bewerten.',
        'Biete Alternativen oder Lösungen an.',
      ],
    },
    {
      title: 'Gemeinsame Lösungen finden',
      points: [
        'Sammle Ideen, ohne sie sofort zu bewerten.',
        'Prüft, was für alle umsetzbar ist.',
        'Legt fest, wie ihr die Vereinbarung überprüft.',
      ],
    },
  ];

  return (
    <>
      <Helmet>
        <title>Silaventino Leitfaden – Schritt für Schritt zu guten Gesprächen</title>
        <meta
          name="description"
          content="Der Silaventino Leitfaden zeigt dir fünf Schritte für klare und respektvolle Kommunikation. Starte deine Reise zu besseren Gesprächen."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Der Silaventino-Leitfaden</h1>
        <p>
          Fünf Schritte, die dich durch jedes Gespräch tragen – von der ersten Reflexion bis zur
          gemeinsamen Lösung.
        </p>
      </section>
      <section className={styles.steps} aria-labelledby="guide-heading">
        <div className="section-heading">
          <h2 id="guide-heading">Schritt für Schritt</h2>
          <p>Arbeitest du einen Schritt nach dem anderen? Großartig. Springst du hin und her? Auch gut.</p>
        </div>
        <div className={styles.stepList}>
          {steps.map((step, index) => (
            <article className={styles.stepCard} key={step.title}>
              <span className={styles.stepNumber}>{index + 1}</span>
              <h3>{step.title}</h3>
              <ul>
                {step.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className={styles.cta}>
          <Link to="/programs" className="buttonPrimary">
            Nächsten Schritt ansehen
          </Link>
          <Link to="/contact" className="buttonOutline">
            Frage stellen
          </Link>
        </div>
      </section>
    </>
  );
};

export default Guide;