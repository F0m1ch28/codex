import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const Services = () => {
  const offers = [
    {
      title: '7-Tage-Respektvoll-reden',
      description:
        'Ein fokussiertes Programm mit täglichen Mikro-Übungen, um ruhig zu bleiben und Klartext zu sprechen.',
      duration: '7 Tage',
      audience: 'Für Paare, Familien und Freund:innen, die neue Routinen suchen.',
      link: '/programs',
    },
    {
      title: 'Konfliktgespräche vorbereiten',
      description:
        'Strukturierter Leitfaden, der dich Schritt für Schritt zu einem sicheren Gesprächsstart führt.',
      duration: '5 Module',
      audience: 'Für Führungskräfte, Teamleads und alle, die Gespräche moderieren.',
      link: '/tools',
    },
    {
      title: '30 Tage bewusster zuhören',
      description:
        'Du trainierst Zuhören, Spiegeln und Nachfragen mit Reflexionsimpulsen und Audio-Inputs.',
      duration: '30 Tage',
      audience: 'Für alle, die Beziehungen stärken möchten – beruflich wie privat.',
      link: '/programs',
    },
  ];

  const toolkits = [
    {
      title: 'Gesprächs-Vorbereitungsbogen',
      text: 'Sortiere Gedanken, Ziele und mögliche Reaktionen, bevor du startest.',
    },
    {
      title: 'Ich-Botschaften-Formulierungshilfe',
      text: 'Finde Worte, die klar sind – ohne Vorwürfe oder Druck.',
    },
    {
      title: 'Checkliste für schwierige Gespräche',
      text: 'Ein sicherer Rahmen, damit du an alles Wichtige denkst.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Silaventino Angebote – Programme & Tools für klare Kommunikation</title>
        <meta
          name="description"
          content="Entdecke die Programme und Tools von Silaventino. Von 7-Tage-Challenges bis zu Gesprächs-Checklisten – alles für deine Kommunikation."
        />
      </Helmet>
      <section className={styles.hero}>
        <h1>Angebote, die dich in Bewegung bringen</h1>
        <p>
          Wähle deinen Einstieg: Kompakte Challenges, tiefgehende Programme oder punktgenaue Tools.
          Alles gestaltet, damit du ins Tun kommst.
        </p>
      </section>

      <section className={styles.offers} aria-labelledby="offers-heading">
        <div className="section-heading">
          <h2 id="offers-heading">Programme & Challenges</h2>
          <p>Konkrete Lernreisen mit klarer Struktur, Reflexion und Praxisübungen.</p>
        </div>
        <div className={styles.offerGrid}>
          {offers.map((offer) => (
            <article key={offer.title} className={styles.offerCard}>
              <h3>{offer.title}</h3>
              <p>{offer.description}</p>
              <ul>
                <li>
                  <strong>Dauer:</strong> {offer.duration}
                </li>
                <li>
                  <strong>Für wen:</strong> {offer.audience}
                </li>
              </ul>
              <Link to={offer.link} className="buttonOutline">
                Mehr erfahren
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.tools} aria-labelledby="tools-heading">
        <div className="section-heading">
          <h2 id="tools-heading">Toolkits für deinen Alltag</h2>
          <p>Direkt einsetzbare Vorlagen, die dich Schritt für Schritt begleiten.</p>
        </div>
        <div className={styles.toolGrid}>
          {toolkits.map((tool) => (
            <article key={tool.title} className={styles.toolCard}>
              <h3>{tool.title}</h3>
              <p>{tool.text}</p>
              <Link to="/tools" className={styles.toolLink}>
                Jetzt nutzen →
              </Link>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaCard}>
          <h2>Nicht sicher, womit du starten willst?</h2>
          <p>
            Melde dich bei uns. Wir hören zu, sortieren mit dir und empfehlen dir den passenden
            nächsten Schritt.
          </p>
          <Link to="/contact" className="buttonPrimary">
            Persönlich sprechen
          </Link>
        </div>
      </section>
    </>
  );
};

export default Services;