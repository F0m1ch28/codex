import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import ErrorBoundary from './components/ErrorBoundary';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Guide from './pages/Guide';
import Programs from './pages/Programs';
import Tools from './pages/Tools';
import Blog from './pages/Blog';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Imprint from './pages/Imprint';
import styles from './App.module.css';

const NotFound = () => (
  <div className={styles.notFound}>
    <h1>Seite nicht gefunden</h1>
    <p>Die aufgerufene Seite existiert leider nicht.</p>
  </div>
);

function App() {
  return (
    <ErrorBoundary>
      <ScrollToTop />
      <div className={styles.app}>
        <Header />
        <main className={styles.mainContent} role="main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/guide" element={<Guide />} />
            <Route path="/programs" element={<Programs />} />
            <Route path="/tools" element={<Tools />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/legal" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/imprint" element={<Imprint />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
      </div>
    </ErrorBoundary>
  );
}

export default App;