document.addEventListener('DOMContentLoaded', function () {
  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('.cookie-accept');
    const declineBtn = cookieBanner.querySelector('.cookie-decline');
    const consent = localStorage.getItem('cookieConsent');

    if (!consent) {
      cookieBanner.classList.add('is-visible');
      cookieBanner.setAttribute('aria-hidden', 'false');
    }

    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        localStorage.setItem('cookieConsent', 'accepted');
        cookieBanner.classList.remove('is-visible');
        cookieBanner.setAttribute('aria-hidden', 'true');
      });
    }

    if (declineBtn) {
      declineBtn.addEventListener('click', function () {
        localStorage.setItem('cookieConsent', 'declined');
        cookieBanner.classList.remove('is-visible');
        cookieBanner.setAttribute('aria-hidden', 'true');
      });
    }
  }

  const contactForm = document.querySelector('#contact-form');
  if (contactForm) {
    const alertBox = contactForm.querySelector('.form-alert');
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const name = contactForm.querySelector('[name="name"]');
      const email = contactForm.querySelector('[name="email"]');
      const phone = contactForm.querySelector('[name="phone"]');
      const topic = contactForm.querySelector('[name="topic"]');
      const message = contactForm.querySelector('[name="message"]');

      const errors = [];

      if (!name.value.trim()) {
        errors.push('Атыңызды енгізіңіз.');
      }
      const emailValue = email.value.trim();
      if (!emailValue) {
        errors.push('Электрондық поштаны енгізіңіз.');
      } else {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailValue)) {
          errors.push('Электрондық поштаның форматы дұрыс емес.');
        }
      }
      if (!phone.value.trim()) {
        errors.push('Байланыс нөміріңізді көрсетіңіз.');
      }
      if (!topic.value) {
        errors.push('Тақырыпты таңдаңыз.');
      }
      if (!message.value.trim() || message.value.trim().length < 20) {
        errors.push('Хабарлама кемінде 20 таңбадан тұруы қажет.');
      }

      if (alertBox) {
        alertBox.classList.remove('is-visible', 'error', 'success');
      }

      if (errors.length > 0) {
        if (alertBox) {
          alertBox.textContent = errors.join(' ');
          alertBox.classList.add('is-visible', 'error');
        }
        return;
      }

      if (alertBox) {
        alertBox.textContent = 'Рақмет! Сіздің өтінішіңіз қабылданды. Менеджеріміз 24 сағат ішінде хабарласады.';
        alertBox.classList.add('is-visible', 'success');
      }
      contactForm.reset();
    });
  }
});