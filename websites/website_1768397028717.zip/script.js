document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navMenu.classList.toggle("active");
        });

        navMenu.querySelectorAll("a").forEach(function (link) {
            link.addEventListener("click", function () {
                if (window.innerWidth < 768 && navMenu.classList.contains("active")) {
                    navMenu.classList.remove("active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieButtons = document.querySelectorAll(".cookie-button");
    const storageKey = "explicbgkvCookieChoice";

    if (cookieBanner) {
        const storedDecision = localStorage.getItem(storageKey);
        if (storedDecision) {
            cookieBanner.classList.add("cookie-banner--hidden");
        } else {
            cookieBanner.classList.remove("cookie-banner--hidden");
        }

        cookieButtons.forEach(function (button) {
            button.addEventListener("click", function (event) {
                event.preventDefault();
                const decision = button.dataset.decision || "accept";
                localStorage.setItem(storageKey, decision);
                cookieBanner.classList.add("cookie-banner--hidden");
                const href = button.getAttribute("href");
                if (href) {
                    window.location.href = href;
                }
            });
        });
    }
});