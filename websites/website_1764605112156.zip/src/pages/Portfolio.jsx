import { motion } from "framer-motion";
import PageTransition from "../components/PageTransition.jsx";

const Portfolio = () => {
  return (
    <PageTransition>
      <section className="section portfolio-hero">
        <div className="section-header">
          <div className="badge">Портфолио</div>
          <h1 className="section-title">Проекты, трансформирующие отрасли и задающие стандарты качества</h1>
          <p className="section-subtitle">
            Мы сопровождаем наших клиентов от стратегической идеи до запуска и масштабирования, обеспечивая высокий уровень сервиса, прозрачность и управляемую скорость.
          </p>
        </div>
        <div className="portfolio-grid">
          {projects.map((project) => (
            <motion.article key={project.title} className="portfolio-card glass-card" whileHover={{ translateY: -8, scale: 1.01 }}>
              <div className="portfolio-image">
                <img src={project.image} alt={project.title} loading="lazy" />
              </div>
              <div className="portfolio-body">
                <div className="portfolio-meta">
                  <span>{project.industry}</span>
                  <span>{project.timeline}</span>
                </div>
                <h3>{project.title}</h3>
                <p>{project.description}</p>
                <ul>
                  {project.results.map((res) => (
                    <li key={res}>{res}</li>
                  ))}
                </ul>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section portfolio-cta">
        <div className="cta-card glass-card">
          <div>
            <div className="badge">Хотите обсудить проект?</div>
            <h2>Мы готовы подключить к вашей задаче профильную команду и разработать стратегию вывода продукта</h2>
          </div>
          <a className="cta-button" href="/contacts">
            Связаться с экспертами
          </a>
        </div>
      </section>
    </PageTransition>
  );
};

const projects = [
  {
    title: "Платформа умного страхования «SecureLife»",
    industry: "InsurTech",
    timeline: "12 месяцев",
    description: "Реализовали цифровую платформу для управления страховыми продуктами с персонализацией и автоматизацией выплат.",
    results: ["Рост продаж онлайн +188%", "Автоматизация обработки заявок на 80%", "Снижение случаев мошенничества на 27%"],
    image: "https://images.pexels.com/photos/6476587/pexels-photo-6476587.jpeg?auto=compress&cs=tinysrgb&w=1200"
  },
  {
    title: "B2B-маркетплейс промышленного оборудования",
    industry: "Marketplace",
    timeline: "16 месяцев",
    description: "Создали платформу с унифицированным каталогом, системой рейтингов, логистикой и интеграцией ERP-заказчиков.",
    results: ["GMV за год 3.4 млрд ₽", "Средний чек +52%", "Сокращение time-to-quote до 20 минут"],
    image: "https://images.pexels.com/photos/3184636/pexels-photo-3184636.jpeg?auto=compress&cs=tinysrgb&w=1200"
  },
  {
    title: "Digital Workplace для девелоперской компании",
    industry: "PropTech",
    timeline: "8 месяцев",
    description: "Разработали цифровое рабочее пространство с документооборотом, календарем, BI-панелями и HR-модулями.",
    results: ["Экономия 1 200 часов/мес", "Снижение ошибок в документах на 68%", "Удовлетворенность сотрудников 4.8/5"],
    image: "https://images.pexels.com/photos/260689/pexels-photo-260689.jpeg?auto=compress&cs=tinysrgb&w=1200"
  },
  {
    title: "Мобильный банковский суперприложение",
    industry: "FinTech",
    timeline: "10 месяцев",
    description: "Интегрировали платежи, инвестиции, маркетплейс услуг и персональные финансовые рекомендации.",
    results: ["MAU +240%", "Рост точности рекомендаций до 92%", "Увеличение cross-sales на 35%"],
    image: "https://images.pexels.com/photos/4065158/pexels-photo-4065158.jpeg?auto=compress&cs=tinysrgb&w=1200"
  }
];

export default Portfolio;