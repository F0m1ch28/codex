import { useState } from "react";
import PageTransition from "../components/PageTransition.jsx";

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <PageTransition>
      <section className="section faq">
        <div className="section-header">
          <div className="badge">FAQ</div>
          <h1 className="section-title">Часто задаваемые вопросы</h1>
          <p className="section-subtitle">
            Если вы не нашли ответ на свой вопрос, свяжитесь с нами через форму обратной связи — мы с удовольствием предоставим подробную информацию.
          </p>
        </div>
        <div className="faq-grid">
          {faq.map((item, index) => (
            <div key={item.question} className={`faq-item glass-card ${openIndex === index ? "open" : ""}`}>
              <button
                className="faq-trigger"
                onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
                aria-expanded={openIndex === index}
              >
                <span>{item.question}</span>
                <span className="faq-icon">{openIndex === index ? "−" : "+"}</span>
              </button>
              <div className="faq-content">
                <p>{item.answer}</p>
                {item.list && (
                  <ul>
                    {item.list.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>
    </PageTransition>
  );
};

const faq = [
  {
    question: "Какой формат сотрудничества вы рекомендуете для старта?",
    answer: "Мы начинаем с Discovery-этапа: проводим интервью, исследуем процессы и формируем дорожную карту. Это позволяет согласовать цели, сроки и бюджет до запуска разработки."
  },
  {
    question: "Сколько длится запуск комплексного проекта?",
    answer: "Срок зависит от масштаба. В среднем Discovery занимает 4–6 недель, MVP от 10 до 16 недель, масштабирование — 3–6 месяцев. Мы предоставляем план и контрольные точки до подписания договора."
  },
  {
    question: "Работаете ли вы с существующей командой клиента?",
    answer: "Да. Мы интегрируемся в смешанные команды, обеспечиваем обмен знаниями, модерируем процессы и формируем единые стандарты. Возможна передача компетенций по мере завершения проекта."
  },
  {
    question: "Как вы обеспечиваете безопасность данных?",
    answer: "Мы внедрили ISO 27001, используем DevSecOps-подход, шифрование, контроль доступа и аудит. Все сотрудники подписывают NDA. Проводим регулярные тесты на проникновение.",
    list: ["Шифрование данных в движении и покое", "Регулярные бэкапы", "Мониторинг и аудит безопасности"]
  },
  {
    question: "Какие технологии вы используете?",
    answer: "Мы работаем с облачными платформами (AWS, Azure, GCP), микросервисной архитектурой, React, Kotlin, Swift, Python, .NET, внедряем аналитические инструменты и AI-модели."
  },
  {
    question: "Можете ли вы сопровождать продукт после запуска?",
    answer: "Да, мы предоставляем SLA-поддержку 24/7, развиваем продукт по roadmap, проводим аналитику и предлагаем новые гипотезы роста."
  }
];

export default FAQ;