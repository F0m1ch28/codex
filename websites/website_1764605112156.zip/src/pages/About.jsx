import { motion } from "framer-motion";
import PageTransition from "../components/PageTransition.jsx";

const About = () => {
  return (
    <PageTransition>
      <section className="section about-intro">
        <div className="section-header">
          <div className="badge">О компании</div>
          <h1 className="section-title">Мы строим цифровую инфраструктуру, которая помогает бизнесу расти быстрее рынка</h1>
          <p className="section-subtitle">
            Сайт компании — партнер, который соединяет стратегический взгляд, технологическую экспертизу и культуру постоянных улучшений. Наша команда консультантов, дизайнеров, аналитиков и инженеров работает синхронно как единая команда с клиентом.
          </p>
        </div>
        <div className="about-grid">
          {aboutFacts.map((fact) => (
            <motion.article key={fact.title} className="glass-card" whileHover={{ translateY: -8 }}>
              <h3>{fact.title}</h3>
              <p>{fact.description}</p>
              <ul>
                {fact.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section mission">
        <div className="mission-grid glass-card">
          <div>
            <h2>Миссия</h2>
            <p>
              Развивать сильные бренды через технологическое превосходство и стратегические инсайты, создавая решения, устойчивые к изменениям рынка и ожиданиям клиентов.
            </p>
          </div>
          <div>
            <h2>Видение</h2>
            <p>
              Быть экосистемным партнером, который задает стандарты качества, помогает компаниям внедрять инновации и формирует культуру ответственности в цифровой среде.
            </p>
          </div>
        </div>
      </section>

      <section className="section timeline">
        <div className="section-header">
          <div className="badge">Динамика развития</div>
          <h2 className="section-title">Путь роста и ключевые этапы трансформации</h2>
        </div>
        <div className="timeline-grid">
          {timeline.map((item) => (
            <motion.div key={item.year} className="timeline-item glass-card" whileHover={{ scale: 1.02 }}>
              <span>{item.year}</span>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="section values">
        <div className="section-header">
          <div className="badge">Ценности</div>
          <h2 className="section-title">Принципы, которые отражаются в каждой совместной победе</h2>
        </div>
        <div className="values-grid">
          {values.map((value) => (
            <motion.article key={value.title} className="value-card glass-card" whileHover={{ translateY: -6 }}>
              <div className="value-icon">{value.icon}</div>
              <h3>{value.title}</h3>
              <p>{value.description}</p>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section partners">
        <div className="section-header">
          <div className="badge">Партнерская экосистема</div>
          <h2 className="section-title">Сотрудничаем с глобальными технологическими лидерами</h2>
          <p className="section-subtitle">
            Используем проверенные платформы и инструменты, чтобы гарантировать высокую надежность и масштабируемость решений.
          </p>
        </div>
        <div className="partner-logos">
          {partners.map((partner) => (
            <motion.div key={partner} className="partner glass-card" whileHover={{ translateY: -4 }}>
              <span>{partner}</span>
            </motion.div>
          ))}
        </div>
      </section>
    </PageTransition>
  );
};

const aboutFacts = [
  {
    title: "Синергия экспертизы",
    description: "Комбинируем стратегию, исследование, продуктовый менеджмент и инжиниринг в одной команде.",
    points: ["Сертифицированные эксперты PMI, SAFe, AWS", "Резерв компетенций для масштабирования", "Прозрачная коммуникация с клиентом"]
  },
  {
    title: "Сильная инженерная культура",
    description: "Следуем принципам чистой архитектуры, автоматизации и контроля качества на каждом этапе.",
    points: ["Многократные релизы в неделю", "DevSecOps и система мониторинга", "Доступность 99,95% SLA"]
  },
  {
    title: "Фокус на результате",
    description: "Работаем в связке с бизнес-целями клиента, обеспечивая измеримый эффект внедрений.",
    points: ["Data-driven OKR", "Обязательные KPI по проекту", "Регулярная оценка ROI"]
  }
];

const timeline = [
  {
    year: "2012",
    title: "Основание и первые стратегические проекты",
    description: "Запустили практику продуктовой разработки и стратегического консалтинга в области цифровых сервисов."
  },
  {
    year: "2016",
    title: "Международное признание",
    description: "Получили первые награды за UX-дизайн и автоматизацию процессов. Расширили команду до 100 экспертов."
  },
  {
    year: "2019",
    title: "Собственная R&D лаборатория",
    description: "Открыли исследовательский центр по AI решений, IoT и кибербезопасности. Инвестируем 15% оборота в инновации."
  },
  {
    year: "2023",
    title: "Экосистема премиальных сервисов",
    description: "Сформировали партнерскую сеть с ведущими поставщиками технологий, реализовали 40+ комплексных проектов."
  }
];

const values = [
  {
    icon: "🎯",
    title: "Ответственность за результат",
    description: "Мы измеряем успех метриками клиента и берем ответственность за достижение целевых показателей."
  },
  {
    icon: "🤝",
    title: "Партнерство и доверие",
    description: "Прозрачность процессов, совместное принятие решений и долгосрочное сотрудничество — основа наших отношений."
  },
  {
    icon: "🚀",
    title: "Инновационное мышление",
    description: "Мы тестируем гипотезы в режиме реального времени, быстро масштабируем успешные решения и непрерывно совершенствуемся."
  },
  {
    icon: "🛡️",
    title: "Безопасность и комплаенс",
    description: "Соблюдаем международные стандарты безопасности, повышаем устойчивость и надежность IT-ландшафта."
  }
];

const partners = ["Microsoft Azure", "Amazon Web Services", "Google Cloud Platform", "Snowflake", "Miro Partner", "Atlassian Solution"];

export default About;