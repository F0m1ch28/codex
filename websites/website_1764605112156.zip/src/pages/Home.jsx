import { motion } from "framer-motion";
import PageTransition from "../components/PageTransition.jsx";

const Home = () => {
  return (
    <PageTransition>
      <section className="hero section">
        <div className="hero-grid">
          <motion.div
            className="hero-copy glass-card"
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
          >
            <div className="badge">Цифровая экосистема будущего</div>
            <h1>
              Превращаем сложные вызовы в масштабируемые бизнес-решения с фокусом на ценность и результат.
            </h1>
            <p>
              Сайт компании помогает лидерам рынка ускорять инновации, выстраивать устойчивые процессы и выводить продукты на новые рынки. Мы объединяем стратегию, дизайн и технологии в единую экосистему.
            </p>
            <div className="hero-actions">
              <a className="cta-button" href="/services">
                Исследовать услуги
              </a>
              <a className="cta-button secondary" href="/portfolio">
                Портфолио проектов
              </a>
            </div>
            <div className="hero-stats">
              <div>
                <span>12+</span>
                <p>Лет экспертизы в цифровой трансформации</p>
              </div>
              <div>
                <span>140+</span>
                <p>Запущенных продуктов и платформ</p>
              </div>
              <div>
                <span>98%</span>
                <p>Клиентов продлевают сотрудничество</p>
              </div>
            </div>
          </motion.div>
          <motion.div
            className="hero-visual"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <div className="hero-image">
              <img
                src="https://images.pexels.com/photos/5473953/pexels-photo-5473953.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Команда специалистов за работой"
              />
              <div className="floating-card">
                <span>AI Driven Decisions</span>
                <p>Интеграция аналитики и машинного обучения для масштабируемого роста.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section compact">
        <div className="section-header">
          <div className="badge">Наш подход</div>
          <h2 className="section-title">Комплексные бизнес-решения с фокусом на ROI и устойчивость</h2>
          <p className="section-subtitle">
            Мы создаем кастомизированные цифровые платформы и сервисы, которые укрепляют позиции бренда, улучшают пользовательский опыт и обеспечивают предсказуемый рост.
          </p>
        </div>
        <div className="grid three">
          {approach.map((item) => (
            <motion.article
              key={item.title}
              className="glass-card"
              whileHover={{ translateY: -8 }}
              transition={{ duration: 0.35, ease: [0.65, 0, 0.35, 1] }}
            >
              <div className="card-icon">{item.icon}</div>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
              <ul>
                {item.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-header">
          <div className="badge">Отраслевой фокус</div>
          <h2 className="section-title">Мы усиливаем лидеров в ключевых высококонкурентных сегментах</h2>
        </div>
        <div className="industries">
          {industries.map((industry) => (
            <motion.div
              key={industry.title}
              className="industry-card glass-card"
              whileHover={{ scale: 1.04 }}
              transition={{ duration: 0.35, ease: [0.65, 0, 0.35, 1] }}
            >
              <div className="industry-head">
                <h3>{industry.title}</h3>
                <span>{industry.tag}</span>
              </div>
              <p>{industry.description}</p>
              <div className="chips">
                {industry.chips.map((chip) => (
                  <span key={chip}>{chip}</span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="section compact case-preview">
        <div className="section-header">
          <div className="badge">Проверенные результаты</div>
          <h2 className="section-title">От идеи до масштабирования. Мы сопровождаем на каждом этапе</h2>
        </div>
        <div className="case-grid">
          {cases.map((item) => (
            <motion.article
              key={item.title}
              className="case-card glass-card"
              whileHover={{ translateY: -10 }}
              transition={{ duration: 0.35, ease: [0.65, 0, 0.35, 1] }}
            >
              <img src={item.image} alt={item.title} />
              <div className="case-body">
                <span>{item.industry}</span>
                <h3>{item.title}</h3>
                <p>{item.summary}</p>
                <ul>
                  {item.results.map((res) => (
                    <li key={res}>{res}</li>
                  ))}
                </ul>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section testimonials">
        <div className="section-header">
          <div className="badge">Отзывы клиентов</div>
          <h2 className="section-title">Высокая скорость, прозрачность процессов и управляемое качество</h2>
        </div>
        <div className="testimonial-grid">
          {testimonials.map((testimonial) => (
            <motion.blockquote
              key={testimonial.name}
              className="testimonial glass-card"
              whileHover={{ translateY: -6 }}
              transition={{ duration: 0.35 }}
            >
              <p>{testimonial.quote}</p>
              <div className="testimonial-meta">
                <div className="avatar">
                  <img src={testimonial.avatar} alt={testimonial.name} loading="lazy" />
                </div>
                <div>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </div>
            </motion.blockquote>
          ))}
        </div>
      </section>

      <section className="section cta">
        <div className="cta-card glass-card">
          <div>
            <div className="badge">Готовы к следующему шагу?</div>
            <h2>Давайте обсудим амбиции вашего бизнеса и разработаем стратегию роста</h2>
            <p>
              Проведем стратегическую сессию, оценим потенциал и предложим дорожную карту трансформации, основанную на данных, экспертизе и лучшем мировом опыте.
            </p>
          </div>
          <div className="cta-actions">
            <a className="cta-button" href="/contacts">
              Назначить консультацию
            </a>
            <a className="cta-button secondary" href="/services">
              Смотреть услуги
            </a>
          </div>
        </div>
      </section>
    </PageTransition>
  );
};

const approach = [
  {
    icon: "🔍",
    title: "Стратегия и исследование",
    description: "Глубокая аналитика, выявление инсайтов и формирование целостной цифровой стратегии.",
    points: ["Аудит бизнес-процессов", "Customer Journey Mapping", "Data-driven гипотезы"]
  },
  {
    icon: "🧭",
    title: "Дизайн и опыт",
    description: "Создаем премиальный UX/UI, фокусируясь на повышении конверсии и удержания пользователей.",
    points: ["Design System 2.0", "Прототипирование и тестирование", "Доступность WCAG AA"]
  },
  {
    icon: "🚀",
    title: "Инжиниринг и масштабирование",
    description: "Модульная архитектура, DevOps практики и непрерывное развитие продукта.",
    points: ["Микросервисы и API", "CI/CD и автоматизация", "AI & ML интеграции"]
  }
];

const industries = [
  {
    title: "Финансовый сектор",
    tag: "FinTech",
    description: "Платежные платформы, цифровые банки, инвестиционные сервисы с высочайшими требованиями к безопасности.",
    chips: ["KYC/AML", "Платёжные шлюзы", "Управление рисками"]
  },
  {
    title: "Промышленность и логистика",
    tag: "Industry 4.0",
    description: "Цифровые двойники, системы мониторинга и оптимизация цепочек поставок в режиме реального времени.",
    chips: ["IoT", "SCM", "BI-аналитика"]
  },
  {
    title: "Ритейл и eCommerce",
    tag: "Retail Tech",
    description: "Внедряем омниканальные платформы, персонализацию и интеллектуальную аналитику спроса.",
    chips: ["Marketplace", "CDP", "Dynamic Pricing"]
  },
  {
    title: "Healthcare & Wellness",
    tag: "MedTech",
    description: "Цифровые медицинские сервисы, дистанционная диагностика и защищенный обмен данными.",
    chips: ["Telemed", "HL7/FHIR", "Compliance"]
  }
];

const cases = [
  {
    title: "Экосистема цифрового банка «FuturePay»",
    industry: "FinTech",
    summary: "Запустили полный цикл банка в мобильном сценарии за 8 месяцев, обеспечив onboarding без посещения офиса и выпуск виртуальных карт за 3 минуты.",
    results: ["Рост активных пользователей +210%", "NPS 72 в первые 90 дней", "Сокращение операционных затрат на 35%"],
    image: "https://images.pexels.com/photos/4386374/pexels-photo-4386374.jpeg?auto=compress&cs=tinysrgb&w=1200"
  },
  {
    title: "Цифровой контур производственного холдинга",
    industry: "Industry 4.0",
    summary: "Развернули облачную платформу для мониторинга заводов, прогнозной аналитики и планирования ресурсов.",
    results: ["Сокращение простоев на 28%", "Оптимизация запасов на 19%", "Прогнозирование спроса с точностью 93%"],
    image: "https://images.pexels.com/photos/3730760/pexels-photo-3730760.jpeg?auto=compress&cs=tinysrgb&w=1200"
  },
  {
    title: "Омниканальный ритейл «Nova Store»",
    industry: "Retail Tech",
    summary: "Объединили онлайн и офлайн каналы в единую платформу, внедрив персонализацию покупок на основе AI.",
    results: ["LTV клиентов +2,6 раза", "Conversion Rate +34%", "Время обработки заказов -45%"],
    image: "https://images.pexels.com/photos/4386324/pexels-photo-4386324.jpeg?auto=compress&cs=tinysrgb&w=1200"
  }
];

const testimonials = [
  {
    name: "Елена Кузнецова",
    role: "CEO, FuturePay",
    quote: "Команда Сайт компании создала стратегию, которая преобразила наш продукт. Процессы стали прозрачными, решения — обоснованными, а запуск прошел быстрее планируемых сроков.",
    avatar: "https://images.pexels.com/photos/5474055/pexels-photo-5474055.jpeg?auto=compress&cs=tinysrgb&w=200"
  },
  {
    name: "Артём Леонов",
    role: "CDO, Global Manufacturing Group",
    quote: "Мы получили не просто IT-продукт, а полноценную экосистему принятия решений. Метрики эффективности производства выросли сразу после внедрения.",
    avatar: "https://images.pexels.com/photos/5324857/pexels-photo-5324857.jpeg?auto=compress&cs=tinysrgb&w=200"
  },
  {
    name: "Мария Власова",
    role: "CMO, Nova Store",
    quote: "Детальная аналитика, гибкая команда и премиальный пользовательский опыт. Сотрудничество с Сайт компании — это сочетание стратегии и безупречного исполнения.",
    avatar: "https://images.pexels.com/photos/3774661/pexels-photo-3774661.jpeg?auto=compress&cs=tinysrgb&w=200"
  }
];

export default Home;