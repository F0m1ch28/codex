import { useState } from "react";
import { motion } from "framer-motion";
import PageTransition from "../components/PageTransition.jsx";

const Contacts = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <PageTransition>
      <section className="section contacts-hero" id="contact-form">
        <div className="contacts-grid">
          <motion.div className="glass-card contact-info" initial={{ opacity: 0, x: -24 }} animate={{ opacity: 1, x: 0 }}>
            <div className="badge">Контакты</div>
            <h1>Свяжитесь с нами и получите индивидуальное предложение</h1>
            <p>
              Мы ответим на запрос в течение рабочего дня, подготовим предварительную оценку и предложим эффективный формат сотрудничества.
            </p>
            <div className="contact-details">
              <div>
                <span>Электронная почта</span>
                <a href="mailto:hello@company.ru">hello@company.ru</a>
              </div>
              <div>
                <span>Телефон</span>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </div>
              <div>
                <span>Офис</span>
                <p>Москва, Пресненская набережная, 12, башня «Цифровая»</p>
              </div>
            </div>
            <div className="contact-highlights">
              <div>
                <strong>4</strong>
                <span>Глобальных хаба разработки</span>
              </div>
              <div>
                <strong>24/7</strong>
                <span>Гибкая поддержка клиентов</span>
              </div>
              <div>
                <strong>ISO</strong>
                <span>Зарегистрированная система менеджмента</span>
              </div>
            </div>
          </motion.div>

          <motion.form
            className="glass-card contact-form"
            onSubmit={handleSubmit}
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h2>Опишите задачу</h2>
            <p>Мы проанализируем запрос и подготовим предложение, основанное на ваших приоритетах.</p>
            <div className="form-grid">
              <label>
                Имя и фамилия
                <input type="text" name="name" required placeholder="Алексей Иванов" />
              </label>
              <label>
                Электронная почта
                <input type="email" name="email" required placeholder="name@company.ru" />
              </label>
              <label>
                Компания
                <input type="text" name="company" placeholder="Company LLC" />
              </label>
              <label>
                Телефон
                <input type="tel" name="phone" placeholder="+7 (999) 000-00-00" />
              </label>
              <label className="wide">
                Направление интереса
                <select name="service">
                  <option>Стратегия и консалтинг</option>
                  <option>Product Discovery</option>
                  <option>Разработка платформ</option>
                  <option>Интеграции и DevOps</option>
                  <option>Сопровождение и рост</option>
                </select>
              </label>
              <label className="wide">
                Детали проекта
                <textarea name="details" rows="4" placeholder="Опишите текущую задачу, сроки и ожидания" />
              </label>
            </div>
            <label className="consent">
              <input type="checkbox" required /> Я согласен(а) с{" "}
              <a href="/privacy" target="_blank" rel="noopener noreferrer">
                политикой обработки персональных данных
              </a>
              .
            </label>
            <button type="submit" className="cta-button">
              Отправить запрос
            </button>
            {submitted && <div className="form-success">Спасибо! Мы свяжемся с вами в ближайшее время.</div>}
          </motion.form>
        </div>
      </section>

      <section className="section map-section">
        <div className="section-header">
          <div className="badge">Как нас найти</div>
          <h2 className="section-title">Встречаемся лично или в цифровой среде</h2>
          <p className="section-subtitle">
            Ведем проекты в формате hybrid-first, организуем стратегические сессии и воркшопы в удобном для вас формате.
          </p>
        </div>
        <div className="map-wrapper glass-card">
          <iframe
            title="Офис Сайт компании"
            src="https://yandex.ru/map-widget/v1/?um=constructor%3A4a4efa5060e90a795d626477245dbea502883e60bd7bbb5174d4a3f9565bbd79&amp;source=constructor"
            width="100%"
            height="400"
            frameBorder="0"
            style={{ borderRadius: "24px" }}
            aria-label="Карта расположения офиса"
          />
        </div>
      </section>
    </PageTransition>
  );
};

export default Contacts;