import { motion } from "framer-motion";
import PageTransition from "../components/PageTransition.jsx";

const Services = () => {
  return (
    <PageTransition>
      <section className="section services-hero">
        <div className="section-header">
          <div className="badge">Экспертиза</div>
          <h1 className="section-title">Комплексные услуги для ускорения цифровой трансформации</h1>
          <p className="section-subtitle">
            Мы сочетает стратегические консультации, креативный дизайн и высокотехнологичную разработку, чтобы помогать компаниям создавать конкурентные продукты и улучшать операционную эффективность.
          </p>
        </div>
        <div className="services-grid">
          {services.map((service) => (
            <motion.article key={service.title} className="glass-card service-card" whileHover={{ translateY: -10 }}>
              <div className="service-head">
                <span>{service.category}</span>
                <h3>{service.title}</h3>
              </div>
              <p>{service.description}</p>
              <ul>
                {service.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="section process">
        <div className="section-header">
          <div className="badge">Методология</div>
          <h2 className="section-title">Слаженный процесс, который обеспечивает предсказуемый результат</h2>
        </div>
        <div className="process-grid">
          {process.map((step, index) => (
            <motion.div
              key={step.title}
              className="process-step glass-card"
              whileHover={{ scale: 1.03 }}
              transition={{ duration: 0.35 }}
            >
              <div className="step-index">{index + 1}</div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="section guarantee">
        <div className="section-header">
          <div className="badge">Гарантии</div>
          <h2 className="section-title">Мы отвечаем за результат и прозрачность на протяжении всего проекта</h2>
        </div>
        <div className="guarantee-grid">
          {guarantees.map((item) => (
            <motion.article key={item.title} className="glass-card" whileHover={{ translateY: -8 }}>
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </motion.article>
          ))}
        </div>
      </section>
    </PageTransition>
  );
};

const services = [
  {
    category: "Стратегия",
    title: "Цифровая стратегия и консалтинг",
    description: "Помогаем определить стратегические приоритеты, оценить зрелость процессов и разработать дорожную карту трансформации.",
    points: ["Аналитика рынка и конкурентов", "Аудит цифрового ландшафта", "Стратегические сессии и OKR", "План внедрения инноваций"]
  },
  {
    category: "Продукт",
    title: "Product Discovery и дизайн",
    description: "Исследуем потребности пользователей, тестируем гипотезы и создаем премиальную дизайн-систему для масштабирования.",
    points: ["Customer Development", "UX-исследования и прототипы", "UI-дизайн и анимация", "DesignOps и дизайн-система"]
  },
  {
    category: "Разработка",
    title: "Инженерия и интеграции",
    description: "Реализуем технологические решения с упором на безопасность, скорость и надежность.",
    points: ["Web и Mobile разработка", "Микросервисы, API, интеграции", "AI/ML и RPA решения", "DevSecOps и автоматизация тестирования"]
  },
  {
    category: "Гибридные проекты",
    title: "Управление продуктом и рост",
    description: "Берем на себя развитие продукта и помогаем командам клиента быстрее достигать KPI.",
    points: ["Product Management as a Service", "Аналитика и BI", "Growth-маркетинг", "Поддержка и развитие 24/7"]
  }
];

const process = [
  {
    title: "Диагностика и цели",
    description: "Собираем данные, формулируем бизнес-задачи, определяем KPI и составляем гипотезы."
  },
  {
    title: "Концепция и прототипирование",
    description: "Создаем дизайн-концепты, прототипы, проводим юзабилити-тестирования и согласовываем гипотезы."
  },
  {
    title: "Инжиниринг и внедрение",
    description: "Разрабатываем архитектуру, внедряем функционал итерациями, подключаем DevSecOps практики."
  },
  {
    title: "Масштабирование и рост",
    description: "Фокусируемся на оптимизации, аналитике, новых гипотезах и развитии продукта."
  }
];

const guarantees = [
  {
    title: "Гибкие модели сотрудничества",
    description: "Fixed price, T&M, Managed Service, гибридные модели — выбираем оптимальный формат под задачи клиента."
  },
  {
    title: "Прозрачная отчетность",
    description: "Еженедельные стутус-сессии, доступ к Jira, Confluence и мониторинг в режиме 24/7."
  },
  {
    title: "Безопасность и комплаенс",
    description: "Соответствие требованиям ISO 27001, GDPR, PCI DSS и локальных регуляторов."
  },
  {
    title: "Экономика проекта под контролем",
    description: "Прогнозируем и управляем бюджетом, обеспечивая финансовую эффективность каждого этапа."
  }
];

export default Services;