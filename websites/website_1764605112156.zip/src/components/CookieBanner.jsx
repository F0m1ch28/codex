import { useEffect, useState } from "react";

const STORAGE_KEY = "cookie-consent-state";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <div className="cookie-content">
        <h3>Мы уважаем вашу приватность</h3>
        <p>
          Используем cookies для персонализации контента, аналитики и повышения качества сервиса. Вы можете принять или отклонить обработку данных. Подробнее —{" "}
          <a href="/privacy">Политика конфиденциальности</a>.
        </p>
        <div className="cookie-actions">
          <button className="cta-button secondary" onClick={() => handleConsent("declined")}>
            Отклонить
          </button>
          <button className="cta-button" onClick={() => handleConsent("accepted")}>
            Принять
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;