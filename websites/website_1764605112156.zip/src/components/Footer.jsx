import { NavLink } from "react-router-dom";
import { motion } from "framer-motion";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-grid">
        <div className="footer-brand glass-card">
          <div className="badge">Сайт компании</div>
          <p>
            Создаем премиальные цифровые продукты, которые помогают бизнесу уверенно масштабироваться, усиливать конкурентоспособность и формировать устойчивую экосистему вокруг бренда.
          </p>
          <div className="footer-meta">
            <span>© {new Date().getFullYear()} Сайт компании</span>
            <span>Все права защищены</span>
          </div>
        </div>
        <div className="footer-nav">
          <h4>Страницы</h4>
          <nav>
            <NavLink to="/">Главная</NavLink>
            <NavLink to="/about">О компании</NavLink>
            <NavLink to="/services">Услуги</NavLink>
            <NavLink to="/portfolio">Портфолио</NavLink>
            <NavLink to="/contacts">Контакты</NavLink>
            <NavLink to="/faq">FAQ</NavLink>
          </nav>
        </div>
        <div className="footer-legal">
          <h4>Правовая информация</h4>
          <nav>
            <NavLink to="/terms">Условия использования</NavLink>
            <NavLink to="/privacy">Политика конфиденциальности</NavLink>
          </nav>
        </div>
        <motion.div
          className="footer-newsletter glass-card"
          whileHover={{ translateY: -4 }}
          transition={{ duration: 0.35, ease: [0.65, 0, 0.35, 1] }}
        >
          <h4>Подписка на инсайты</h4>
          <p>Получайте аналитические обзоры, тренды и практические рекомендации по цифровой трансформации бизнеса.</p>
          <form className="footer-form">
            <label htmlFor="newsletter-email" className="sr-only">
              Электронная почта
            </label>
            <input type="email" id="newsletter-email" placeholder="Введите e-mail" required />
            <button type="submit">Подписаться</button>
          </form>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;