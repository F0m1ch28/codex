import { useState } from "react";
import { NavLink } from "react-router-dom";
import { useTheme } from "../context/ThemeContext.jsx";
import ThemeToggle from "./ThemeToggle.jsx";

const navLinks = [
  { to: "/", label: "Главная" },
  { to: "/about", label: "О компании" },
  { to: "/services", label: "Услуги" },
  { to: "/portfolio", label: "Портфолио" },
  { to: "/contacts", label: "Контакты" },
  { to: "/faq", label: "FAQ" }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const { theme } = useTheme();

  return (
    <header className="header">
      <div className="header-inner">
        <NavLink to="/" className="logo" aria-label="Перейти на главную страницу">
          <span className="logo-icon">◎</span>
          <div className="logo-text">
            <span>Сайт компании</span>
            <small>Цифровые бизнес-решения</small>
          </div>
        </NavLink>
        <nav className={`nav ${menuOpen ? "open" : ""}`}>
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className="header-actions">
          <ThemeToggle />
          <a className="cta-button small" href="#contact-form">
            Связаться
          </a>
          <button
            className={`menu-toggle ${menuOpen ? "active" : ""}`}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-label="Открыть меню"
            aria-expanded={menuOpen}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
      <div className={`glass-blur ${theme}`} />
    </header>
  );
};

export default Header;