import { useTheme } from "../context/ThemeContext.jsx";
import { motion } from "framer-motion";

const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <motion.button
      className="theme-toggle"
      onClick={toggleTheme}
      aria-label="Переключить тему"
      whileTap={{ scale: 0.92 }}
      transition={{ duration: 0.2 }}
    >
      <span className="toggle-track">
        <span className={`toggle-thumb ${theme}`} />
      </span>
      <span className="toggle-label">{theme === "light" ? "Светлая" : "Тёмная"}</span>
    </motion.button>
  );
};

export default ThemeToggle;