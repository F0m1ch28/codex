document.addEventListener('DOMContentLoaded', () => {
  const gameRoot = document.getElementById('game-root');
  if (!gameRoot) {
    return;
  }

  const queryElement = document.getElementById('game-query');
  const optionsContainer = document.getElementById('game-options');
  const feedbackElement = document.getElementById('game-feedback');
  const progressBar = document.getElementById('game-progress-bar');
  const nextButton = document.getElementById('game-next');
  const roundBadge = document.getElementById('game-round');
  const summaryBlock = document.getElementById('game-summary');
  const summaryText = document.getElementById('game-summary-text');

  const scoreElement = document.getElementById('stat-score');
  const accuracyElement = document.getElementById('stat-accuracy');
  const streakElement = document.getElementById('stat-streak');

  const scenarios = [
    {
      query: 'кот не кушает второй день что делать',
      options: [
        { text: 'советы ветеринара если кот не ест', isCorrect: true, explanation: 'Создаёт релевантный совет по здоровью питомца, что ожидает пользователь.' },
        { text: 'купить новый корм для кота дешево', isCorrect: false, explanation: 'Интент о покупке, а не помощь.' },
        { text: 'котики смешные видео', isCorrect: false, explanation: 'Комическая выдача не решает запрос.' }
      ]
    },
    {
      query: 'яндекс навигатор не говорит что делать',
      options: [
        { text: 'как включить голос в яндекс навигаторе инструкция', isCorrect: true, explanation: 'Прямой ответ на проблему пользователя.' },
        { text: 'скачать голосовые пакеты навигатора бесплатно', isCorrect: false, explanation: 'Низшая релевантность, возможно нерелевантные материалы.' },
        { text: 'почему молчит телефон', isCorrect: false, explanation: 'Слишком общий запрос.' }
      ]
    },
    {
      query: 'самолет нижний новгород москва завтра вечер',
      options: [
        { text: 'авиабилеты нижний новгород москва на завтра вечер', isCorrect: true, explanation: 'Соответствует путешественическому запросу с датой.' },
        { text: 'расписание автобусов нижний новгород москва', isCorrect: false, explanation: 'Не тот вид транспорта.' },
        { text: 'погода в москве завтра вечером', isCorrect: false, explanation: 'Отклонение от намерения.' }
      ]
    },
    {
      query: 'как включить темную тему как вы яндексе',
      options: [
        { text: 'инструкция включить темную тему яндекс браузер', isCorrect: true, explanation: 'Определяет продукт (браузер) и намерение пользователя.' },
        { text: 'темные обои на рабочий стол', isCorrect: false, explanation: 'Пользователь искал тему интерфейса, а не обои.' },
        { text: 'ночной режим телефон общий', isCorrect: false, explanation: 'Слишком общий ответ.' }
      ]
    },
    {
      query: 'яблоки купить рядом доставка за час',
      options: [
        { text: 'доставка продуктов яблоки за час рядом', isCorrect: true, explanation: 'Коммерческое намерение с гео — точное совпадение.' },
        { text: 'садоводство выращивание яблок', isCorrect: false, explanation: 'Не соответствует цели покупки.' },
        { text: 'рецепты штруделя яблочного', isCorrect: false, explanation: 'Контент не об этом.' }
      ]
    },
    {
      query: 'кроссовки как у курьера яндекс еда',
      options: [
        { text: 'купить кроссовки яндекс еда черные', isCorrect: true, explanation: 'Понимает, что нужен мерч в стиле сервиса.' },
        { text: 'форма курьера яндекс еды работа', isCorrect: false, explanation: 'Уводит в трудоустройство.' },
        { text: 'яркие кроссовки доставка', isCorrect: false, explanation: 'Слишком общий запрос.' }
      ]
    },
    {
      query: 'мне скучно что посмотреть смешного',
      options: [
        { text: 'подборка смешных видео яндекс эфир', isCorrect: true, explanation: 'Соответствует развлекательному намерению.' },
        { text: 'как бороться со скукой научно', isCorrect: false, explanation: 'Знания — но не развлечение.' },
        { text: 'купить настольные игры', isCorrect: false, explanation: 'Это товарный интент.' }
      ]
    },
    {
      query: 'яндекс музыка семейная подписка цена',
      options: [
        { text: 'яндекс музыка семейная подписка стоимость 2024', isCorrect: true, explanation: 'Дает актуальный ответ с годом.' },
        { text: 'бесплатная музыка скачать mp3', isCorrect: false, explanation: 'Не соответствует запросу о подписке.' },
        { text: 'подписка apple music семейная', isCorrect: false, explanation: 'Не тот сервис.' }
      ]
    },
    {
      query: 'что подарить ребенку на 8 лет идеи яндекс',
      options: [
        { text: 'идеи подарков ребенку 8 лет яндекс маркет', isCorrect: true, explanation: 'Сервис с подборками подарков — то, что нужно.' },
        { text: 'как научиться дарить подарки', isCorrect: false, explanation: 'Лайфхаки, но не конкретные предложения.' },
        { text: 'задачи по математике 2 класс', isCorrect: false, explanation: 'Совсем другая тематика.' }
      ]
    },
    {
      query: 'почему яндекс браузер медленно работает',
      options: [
        { text: 'яндекс браузер тормозит как ускорить', isCorrect: true, explanation: 'Решает техническую проблему пользователя.' },
        { text: 'скачать другой браузер', isCorrect: false, explanation: 'Алгоритм сначала поможет пользователю, а не убежит.' },
        { text: 'новости технологий сегодня', isCorrect: false, explanation: 'Не относится к вопросу.' }
      ]
    }
  ];

  let shuffledScenarios = [];
  let currentIndex = 0;
  let score = 0;
  let correctAnswers = 0;
  let streak = 0;
  let bestStreak = 0;
  let startTime = Date.now();

  function shuffle(array) {
    return array
      .map((item) => ({ item, sort: Math.random() }))
      .sort((a, b) => a.sort - b.sort)
      .map(({ item }) => item);
  }

  function updateScoreboard() {
    if (scoreElement) {
      scoreElement.textContent = score;
    }
    const accuracy = currentIndex === 0 ? 0 : Math.round((correctAnswers / currentIndex) * 100);
    if (accuracyElement) {
      accuracyElement.textContent = `${accuracy}%`;
    }
    if (streakElement) {
      streakElement.textContent = bestStreak;
    }
  }

  function renderScenario() {
    const total = shuffledScenarios.length;
    const current = shuffledScenarios[currentIndex];
    const progressPercent = Math.round((currentIndex / total) * 100);

    queryElement.textContent = current.query;
    optionsContainer.innerHTML = '';
    feedbackElement.textContent = 'Выберите трактовку, которая даст лучшую выдачу.';
    progressBar.style.width = `${progressPercent}%`;
    nextButton.disabled = true;
    roundBadge.textContent = `Раунд ${currentIndex + 1} из ${total}`;

    current.options.forEach((option) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'game-option';
      button.textContent = option.text;
      button.dataset.correct = String(option.isCorrect);
      button.addEventListener('click', () => handleAnswer(button, option));
      optionsContainer.appendChild(button);
    });
  }

  function handleAnswer(button, option) {
    const isCorrect = option.isCorrect;
    const allButtons = optionsContainer.querySelectorAll('.game-option');

    allButtons.forEach((btn) => {
      btn.classList.add('is-disabled');
      if (btn.dataset.correct === 'true') {
        btn.classList.add('is-correct');
      }
    });

    if (isCorrect) {
      button.classList.add('is-correct');
      feedbackElement.textContent = `Красота! ${option.explanation}`;
      score += 120;
      streak += 1;
      correctAnswers += 1;
      if (streak > bestStreak) {
        bestStreak = streak;
      }
    } else {
      button.classList.add('is-wrong');
      feedbackElement.textContent = `Алгоритм бы возразил: ${option.explanation}`;
      streak = 0;
    }

    currentIndex += 1;
    updateScoreboard();
    progressBar.style.width = `${Math.round((currentIndex / shuffledScenarios.length) * 100)}%`;

    if (currentIndex >= shuffledScenarios.length) {
      nextButton.textContent = 'Завершить серию';
    } else {
      nextButton.textContent = 'Следующий запрос';
    }

    nextButton.disabled = false;
  }

  function finishGame() {
    const total = shuffledScenarios.length;
    const accuracy = Math.round((correctAnswers / total) * 100);
    const durationSeconds = Math.round((Date.now() - startTime) / 1000);

    feedbackElement.textContent = 'Серия завершена! Проверьте статистику ниже.';
    summaryBlock.classList.add('is-visible');
    summaryText.textContent = `Вы набрали ${score} очков, точность ${accuracy}%, лучшая серия ${bestStreak}. На это ушло ${durationSeconds} секунд. Попробуете побить рекорд?`;

    nextButton.textContent = 'Играть ещё раз';
    nextButton.disabled = false;

    const consent = localStorage.getItem('iky_cookieConsent');
    if (consent === 'accepted') {
      const attempt = {
        nickname: 'Вы',
        score,
        accuracy,
        streak: bestStreak,
        createdAt: new Date().toISOString()
      };
      localStorage.setItem('iky_lastScore', JSON.stringify(attempt));
    } else {
      alert('Cookie отключены — результат не попадёт в рейтинг. Разрешите cookie, чтобы сохранить рекорд.');
    }
  }

  function resetGame() {
    shuffledScenarios = shuffle(scenarios).slice(0, 10);
    currentIndex = 0;
    score = 0;
    correctAnswers = 0;
    streak = 0;
    bestStreak = 0;
    startTime = Date.now();
    summaryBlock.classList.remove('is-visible');
    nextButton.textContent = 'Следующий запрос';
    updateScoreboard();
    renderScenario();
  }

  nextButton.addEventListener('click', () => {
    if (currentIndex >= shuffledScenarios.length) {
      resetGame();
      return;
    }
    renderScenario();
  });

  resetGame();
});