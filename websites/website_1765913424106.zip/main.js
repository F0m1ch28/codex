document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');

  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      navList.classList.toggle('is-open');
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');

  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineButton = cookieBanner.querySelector('[data-cookie="decline"]');
    const consent = localStorage.getItem('iky_cookieConsent');

    if (!consent) {
      cookieBanner.classList.add('is-visible');
    }

    if (acceptButton) {
      acceptButton.addEventListener('click', () => {
        localStorage.setItem('iky_cookieConsent', 'accepted');
        cookieBanner.classList.remove('is-visible');
      });
    }

    if (declineButton) {
      declineButton.addEventListener('click', () => {
        localStorage.setItem('iky_cookieConsent', 'declined');
        cookieBanner.classList.remove('is-visible');
        alert('Без cookie рейтинг и прогресс не сохранятся, но играть можно.');
      });
    }
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const response = document.getElementById('contact-response');
      if (response) {
        response.textContent = 'Спасибо! Мы получили ваше сообщение и ответим в течение 12 часов.';
      }
      contactForm.reset();
    });
  }

  const ratingTableBody = document.getElementById('rating-table-body');
  let leaderboardDataset = null;

  if (ratingTableBody) {
    const baseLeaderboard = [
      { nickname: 'CatCoder', score: 1980, accuracy: 96, streak: 18, source: 'Команда аналитики' },
      { nickname: 'MatrixGuru', score: 1875, accuracy: 94, streak: 16, source: 'YaCamp' },
      { nickname: 'ЗапросоФил', score: 1760, accuracy: 92, streak: 14, source: 'Сообщество' },
      { nickname: 'Поисковая_Пчела', score: 1680, accuracy: 91, streak: 13, source: 'Фрилансеры' },
      { nickname: 'TurboHint', score: 1595, accuracy: 90, streak: 12, source: 'Турнир пятницы' }
    ];

    const storedResult = localStorage.getItem('iky_lastScore');
    if (storedResult) {
      try {
        const parsed = JSON.parse(storedResult);
        baseLeaderboard.push({
          nickname: parsed.nickname || 'Вы',
          score: parsed.score || 0,
          accuracy: parsed.accuracy || 0,
          streak: parsed.streak || 0,
          source: 'Ваш последний запуск',
          highlight: true
        });
      } catch (error) {
        console.warn('Не удалось прочитать локальный результат рейтинга', error);
      }
    }

    leaderboardDataset = baseLeaderboard.sort((a, b) => b.score - a.score);
    ratingTableBody.innerHTML = '';

    leaderboardDataset.forEach((player, index) => {
      const row = document.createElement('tr');
      if (player.highlight) {
        row.classList.add('highlight');
      }
      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${player.nickname}</td>
        <td>${player.score}</td>
        <td>${player.accuracy}%</td>
        <td>${player.streak}</td>
        <td>${player.source}</td>
      `;
      ratingTableBody.appendChild(row);
    });
  }

  const ratingSummary = document.getElementById('rating-summary');
  if (ratingSummary && leaderboardDataset) {
    const top = leaderboardDataset[0];
    const averageAccuracy = Math.round(
      leaderboardDataset.reduce((sum, player) => sum + player.accuracy, 0) / leaderboardDataset.length
    );
    ratingSummary.textContent = `Лидер сейчас — ${top.nickname} с ${top.score} очками. Средняя точность топа: ${averageAccuracy}%.`;
  }
});