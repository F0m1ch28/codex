document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var primaryNav = document.querySelector('.primary-nav');

    if (navToggle && primaryNav) {
        navToggle.addEventListener('click', function () {
            primaryNav.classList.toggle('open');
        });

        primaryNav.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                primaryNav.classList.remove('open');
            });
        });
    }

    var cookieBanner = document.querySelector('.cookie-banner');
    var cookieAccept = document.getElementById('cookie-accept');

    if (cookieBanner && cookieAccept) {
        var consent = localStorage.getItem('nippinyurgCookieConsent');

        if (consent === 'accepted') {
            cookieBanner.classList.add('hidden');
        }

        cookieAccept.addEventListener('click', function () {
            localStorage.setItem('nippinyurgCookieConsent', 'accepted');
            cookieBanner.classList.add('hidden');
        });
    }
});