document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('.site-header');
    const mobileToggle = document.querySelector('.mobile-toggle');
    const nav = document.querySelector('.main-nav');
    const scrollBtn = document.getElementById('scrollTopBtn');
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const contactForm = document.getElementById('contactForm');
    const feedback = document.getElementById('formFeedback');

    // Mobile navigation toggle
    if (mobileToggle && nav) {
        mobileToggle.addEventListener('click', () => {
            const expanded = mobileToggle.getAttribute('aria-expanded') === 'true';
            mobileToggle.setAttribute('aria-expanded', !expanded);
            nav.classList.toggle('open');
        });

        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                nav.classList.remove('open');
                mobileToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    // Scroll effects
    const handleScroll = () => {
        const scrolled = window.scrollY;
        if (scrolled > 10) {
            header.classList.add('is-scrolled');
        } else {
            header.classList.remove('is-scrolled');
        }

        if (scrollBtn) {
            if (scrolled > 350) {
                scrollBtn.classList.add('show');
            } else {
                scrollBtn.classList.remove('show');
            }
        }
    };

    window.addEventListener('scroll', handleScroll);

    if (scrollBtn) {
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Cookie banner
    if (cookieBanner && acceptCookiesBtn) {
        const cookieConsent = localStorage.getItem('petroCookiesAccepted');
        if (!cookieConsent) {
            setTimeout(() => cookieBanner.classList.add('show'), 800);
        }

        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('petroCookiesAccepted', 'true');
            cookieBanner.classList.remove('show');
        });
    }

    // Contact form submission feedback
    if (contactForm && feedback) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            feedback.textContent = `Grazie ${name}, la tua richiesta è stata ricevuta. Ti ricontatteremo entro 24 ore lavorative.`;
            feedback.style.color = '#0C1B2C';
            contactForm.reset();
        });
    }
});