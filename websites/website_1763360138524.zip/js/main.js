document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('nav-toggle');
  const siteNav = document.getElementById('site-nav');
  const cookieBanner = document.getElementById('cookieBanner');
  const acceptCookies = document.getElementById('acceptCookies');
  const forms = document.querySelectorAll('#heroForm, #ctaForm');
  const currentYear = new Date().getFullYear();

  const yearElements = [
    document.getElementById('currentYear'),
    document.getElementById('currentYearTerms'),
    document.getElementById('currentYearPrivacy')
  ];
  yearElements.forEach(el => {
    if (el) el.textContent = currentYear;
  });

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      siteNav.classList.toggle('open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => siteNav.classList.remove('open'));
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (event) => {
      const targetId = anchor.getAttribute('href').substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        event.preventDefault();
        const yOffset = -60;
        const y = target.getBoundingClientRect().top + window.pageYOffset + yOffset;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }
    });
  });

  if (cookieBanner && acceptCookies) {
    const cookieConsent = localStorage.getItem('swiftlaunch_cookie_consent');
    if (cookieConsent === 'accepted') {
      cookieBanner.style.display = 'none';
    }
    acceptCookies.addEventListener('click', () => {
      localStorage.setItem('swiftlaunch_cookie_consent', 'accepted');
      cookieBanner.style.display = 'none';
    });
  }

  forms.forEach(form => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      const emailInput = form.querySelector('input[type="email"]');
      if (!emailInput.value) return;

      button.disabled = true;
      button.textContent = 'Sending...';

      setTimeout(() => {
        button.disabled = false;
        button.textContent = 'Start Free Trial';
        emailInput.value = '';
        alert('Thanks! Check your inbox for SwiftLaunch access instructions.');
      }, 800);
    });
  });
});