document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');
  const navLinks = document.querySelectorAll('.site-nav a');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = document.body.classList.toggle('nav-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        if (document.body.classList.contains('nav-open')) {
          document.body.classList.remove('nav-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const cookieActionButtons = document.querySelectorAll('[data-cookie-action]');
  const cookiePreference = localStorage.getItem('tt-cookie-choice');

  if (cookieBanner && !cookiePreference) {
    cookieBanner.classList.add('show');
  }

  cookieActionButtons.forEach((button) => {
    button.addEventListener('click', (event) => {
      const action = button.getAttribute('data-cookie-action');
      if (action === 'accept' || action === 'decline') {
        localStorage.setItem('tt-cookie-choice', action);
        cookieBanner.classList.remove('show');
      }
      event.preventDefault();
    });
  });
});