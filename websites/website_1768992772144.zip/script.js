document.addEventListener("DOMContentLoaded", function () {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      const isOpen = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    document.addEventListener("click", function (event) {
      if (!siteNav.contains(event.target) && !navToggle.contains(event.target)) {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
    window.addEventListener("resize", function () {
      if (window.innerWidth >= 768) {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector("[data-cookie-accept]");
    const declineBtn = cookieBanner.querySelector("[data-cookie-decline]");
    const consentStatus = localStorage.getItem("shieldCookieConsent");

    if (consentStatus === "accepted" || consentStatus === "declined") {
      cookieBanner.classList.add("hidden");
    }

    const hideBanner = (status) => {
      localStorage.setItem("shieldCookieConsent", status);
      cookieBanner.classList.add("hidden");
    };

    if (acceptBtn) {
      acceptBtn.addEventListener("click", function () {
        hideBanner("accepted");
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", function () {
        hideBanner("declined");
      });
    }
  }
});