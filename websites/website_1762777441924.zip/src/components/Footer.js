import React, { useState } from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    if (email.trim()) {
      setSubmitted(true);
    }
  };

  return (
    <footer className="bg-dark text-slate-200 pt-12 pb-8 mt-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center space-x-3">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white text-xl font-heading font-semibold">
                FK
              </span>
              <div>
                <p className="text-xl font-heading font-semibold">FinanzKompass DE</p>
                <p className="text-sm text-slate-400">
                  Klarheit für deine privaten Finanzen.
                </p>
              </div>
            </div>
            <p className="mt-6 text-sm leading-relaxed text-slate-400">
              Budget-Workflows, Analysen und praktische Templates für Singles,
              Paare und Familien in Deutschland.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-300">
              Navigation
            </h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <Link className="hover:text-white transition" to="/">
                  Start
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/services#leitfaden">
                  Leitfaden
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/services#rechner">
                  Rechner
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/services#blog">
                  Blog & Updates
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/about">
                  Über uns
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/contact">
                  Kontakt
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-300">
              Rechtliches
            </h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <Link className="hover:text-white transition" to="/terms">
                  Nutzungsbedingungen
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/policy">
                  Datenschutz
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/policy#cookies">
                  Cookie-Richtlinie
                </Link>
              </li>
              <li>
                <Link className="hover:text-white transition" to="/contact#impressum">
                  Impressum
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-300">
              Newsletter
            </h3>
            <p className="mt-4 text-sm text-slate-400">
              Einmal im Monat Benchmarks, Vorlagen und neue Tools für deine
              Finanzroutine.
            </p>
            <form className="mt-5 space-y-3" onSubmit={handleSubmit}>
              <label htmlFor="newsletter-email" className="sr-only">
                E-Mail Adresse
              </label>
              <input
                id="newsletter-email"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="E-Mail Adresse"
                className="w-full rounded-lg border border-slate-600 bg-slate-800 px-4 py-3 text-sm placeholder:text-slate-500 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/50"
                required
              />
              <button
                type="submit"
                className="inline-flex w-full items-center justify-center rounded-lg bg-brand px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-brand/30 transition hover:-translate-y-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
              >
                Jetzt abonnieren
              </button>
              {submitted && (
                <p className="text-xs text-green-300">
                  Danke! Wir bestätigen deine Anmeldung per E-Mail.
                </p>
              )}
            </form>
          </div>
        </div>

        <div className="mt-10 border-t border-slate-700 pt-6 flex flex-col md:flex-row items-center justify-between text-xs text-slate-500">
          <p>© {new Date().getFullYear()} FinanzKompass DE. Alle Rechte vorbehalten.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a
              href="https://www.linkedin.com"
              className="hover:text-white transition"
              aria-label="LinkedIn"
            >
              LinkedIn
            </a>
            <a
              href="https://www.xing.com"
              className="hover:text-white transition"
              aria-label="XING"
            >
              XING
            </a>
            <a
              href="mailto:hallo@finanzkompass.de"
              className="hover:text-white transition"
              aria-label="E-Mail an FinanzKompass DE"
            >
              hallo@finanzkompass.de
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;