import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("finanzkompass-cookie");
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("finanzkompass-cookie", "accepted");
    setIsVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem("finanzkompass-cookie", "declined");
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <aside
      className="fixed bottom-4 left-1/2 z-50 w-[calc(100%-2rem)] max-w-3xl -translate-x-1/2 rounded-2xl border border-slate-200 bg-white px-6 py-5 shadow-2xl shadow-slate-900/10"
      role="region"
      aria-label="Cookie Hinweis"
    >
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-y-0 md:space-x-6">
        <div className="flex-1">
          <p className="text-sm font-semibold text-dark">
            Cookies für fundierte Analysen
          </p>
          <p className="mt-1 text-sm text-slate-600">
            Wir nutzen Cookies für Statistiken und um Services wie Rechner und
            Vorlagen stabil zu liefern. Du kannst jederzeit widersprechen.
          </p>
          <a
            className="mt-2 inline-block text-sm font-medium text-brand underline underline-offset-4"
            href="/policy#cookies"
          >
            Details zur Cookie-Richtlinie
          </a>
        </div>
        <div className="flex flex-col space-y-3 md:flex-row md:space-y-0 md:space-x-3">
          <button
            type="button"
            onClick={handleDecline}
            className="rounded-full border border-slate-200 px-5 py-2 text-sm font-semibold text-slate-600 transition hover:border-slate-400"
          >
            Ablehnen
          </button>
          <button
            type="button"
            onClick={handleAccept}
            className="rounded-full bg-brand px-5 py-2 text-sm font-semibold text-white shadow-md shadow-brand/30 transition hover:-translate-y-0.5"
          >
            Akzeptieren
          </button>
        </div>
      </div>
    </aside>
  );
};

export default CookieBanner;