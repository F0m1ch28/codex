import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { FiMenu, FiX } from "react-icons/fi";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: "Start", path: "/" },
    { label: "Leitfaden", path: "/services#leitfaden" },
    { label: "Rechner", path: "/services#rechner" },
    { label: "Vorlagen", path: "/services#vorlagen" },
    { label: "Blog", path: "/services#blog" },
    { label: "Über uns", path: "/about" },
    { label: "Kontakt", path: "/contact" }
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-slate-100 shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-4">
          <Link
            to="/"
            className="flex items-center space-x-2"
            aria-label="FinanzKompass DE Startseite"
          >
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-brand text-white font-heading font-semibold">
              FK
            </span>
            <span className="flex flex-col leading-tight">
              <span className="text-lg font-heading font-semibold text-dark">
                FinanzKompass DE
              </span>
              <span className="text-xs text-slate-500">
                Klarheit für deine Finanzroutine
              </span>
            </span>
          </Link>

          <nav className="hidden lg:flex items-center space-x-8 font-medium">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `transition-colors duration-200 hover:text-brand ${
                    isActive ? "text-brand font-semibold" : "text-slate-600"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}

            <Link
              to="/contact"
              className="inline-flex items-center rounded-full bg-brand px-5 py-2 text-white font-semibold shadow-lg shadow-brand/30 transition-transform duration-200 hover:-translate-y-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
            >
              Finanz-Check buchen
            </Link>
          </nav>

          <button
            type="button"
            className="lg:hidden inline-flex items-center justify-center rounded-md p-2 text-slate-600 hover:bg-slate-100 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand"
            onClick={() => setIsOpen(!isOpen)}
            aria-expanded={isOpen}
            aria-controls="mobile-nav"
            aria-label="Navigation umschalten"
          >
            {isOpen ? <FiX className="h-6 w-6" /> : <FiMenu className="h-6 w-6" />}
          </button>
        </div>

        {isOpen && (
          <div
            id="mobile-nav"
            className="lg:hidden pb-6 animate-slide-down origin-top"
          >
            <nav className="flex flex-col space-y-4 text-base text-slate-700">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) =>
                    `px-4 py-2 rounded-lg hover:bg-slate-100 transition ${
                      isActive ? "bg-brand/10 text-brand font-semibold" : ""
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <Link
                to="/contact"
                onClick={() => setIsOpen(false)}
                className="inline-flex items-center justify-center rounded-full bg-brand px-5 py-3 text-white font-semibold shadow-md transition hover:-translate-y-0.5"
              >
                Finanz-Check buchen
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;