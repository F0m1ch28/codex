import React from "react";
import { Helmet } from "react-helmet";

const Services = () => {
  const serviceModules = [
    {
      id: "leitfaden",
      title: "6-Schritte-Leitfaden",
      description:
        "Kompakter Workflow mit Checklisten für Status, Ziele, Budget, Automatisierung, Check-in und Optimierung.",
      deliverables: ["Workbook (PDF)", "Notion-Board", "Video-Erklärungen"],
      investment: "Kostenlos"
    },
    {
      id: "rechner",
      title: "Rechner & Analyzer",
      description:
        "Fixkostenquote, Sparrate, Schuldentilgung, Zinsrechner und Kindergeld-Planer – optimiert für deutsche Haushalte.",
      deliverables: ["Google-Sheets", "CSV-Export", "Benchmark-Vergleich"],
      investment: "ab 39 €"
    },
    {
      id: "vorlagen",
      title: "Budget-Vorlagen",
      description:
        "Templates für Haushaltsbuch, Monatsabschluss, Zieltracking und Rücklagenplanung.",
      deliverables: ["Google Sheets", "Excel", "Notion Template"],
      investment: "ab 19 €"
    },
    {
      id: "coaching",
      title: "Budget-Coaching",
      description:
        "Individuelle Sessions mit Finanzplaner:innen für Paare, Familien oder Solo-Haushalte.",
      deliverables: ["90-Minuten-Session", "Aktionsplan", "Follow-up"],
      investment: "ab 179 €"
    },
    {
      id: "navigator",
      title: "Budget Navigator",
      description:
        "Dein persönliches Finanzcockpit mit Kennzahlen, Szenarien und Forecasts – inkl. Setup-Unterstützung.",
      deliverables: ["Dashboard", "Workflows", "KPI-Framework"],
      investment: "ab 249 €"
    },
    {
      id: "blog",
      title: "Insights & Benchmarks",
      description:
        "Regelmäßige Artikel, Reports und Priorisierungs-Guides für Versicherungen & Haushaltsentscheidungen.",
      deliverables: ["Monatsbericht", "Benchmark-Sammlung", "Priorisierungshilfen"],
      investment: "inklusive"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <Helmet>
        <title>Services von FinanzKompass DE – Workflows & Tools</title>
        <meta
          name="description"
          content="Entdecke Budget-Leitfaden, Rechner, Vorlagen und Coaching von FinanzKompass DE für deutsche Haushalte."
        />
        <meta property="og:title" content="Services von FinanzKompass DE" />
        <meta
          property="og:description"
          content="Budget-Workflows, Benchmarks und Tools – modular kombinierbar für deinen Finanzplan."
        />
        <meta property="og:image" content="https://picsum.photos/1200/800?random=42" />
      </Helmet>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <h1 className="section-title">Services & Module</h1>
          <p className="section-lead">
            Kombiniere Leitfaden, Rechner und Coaching nach deinem Bedarf. Alle Module sind
            DSGVO-konform, praxisnah und unterstützen dich beim Aufbau stabiler Routinen.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {serviceModules.map((service) => (
            <article key={service.id} id={service.id} className="service-card">
              <span className="text-xs uppercase font-semibold text-brand tracking-wide">
                Modul
              </span>
              <h2 className="mt-2 text-xl font-heading font-semibold text-dark">
                {service.title}
              </h2>
              <p className="mt-3 text-sm text-slate-600">{service.description}</p>
              <ul className="mt-5 space-y-2 text-sm text-slate-600">
                {service.deliverables.map((item) => (
                  <li key={item} className="flex items-start space-x-2">
                    <span className="text-brand mt-0.5">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-sm font-semibold text-dark">
                Investition: {service.investment}
              </p>
              <a
                href="#contact"
                className="mt-6 inline-flex items-center text-sm font-semibold text-brand hover:text-brand/70"
              >
                Modul anfragen →
              </a>
            </article>
          ))}
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-2">
          <article className="card">
            <h2 className="text-xl font-heading font-semibold text-dark">
              Wie läuft die Zusammenarbeit ab?
            </h2>
            <ol className="mt-5 list-decimal space-y-3 pl-6 text-sm text-slate-600">
              <li>Kurzes Erstgespräch zur Bedarfsklärung.</li>
              <li>Zusammenstellung der Module und Tools.</li>
              <li>Kick-off mit klaren Zielen & KPI-Definition.</li>
              <li>Regelmäßige Check-ins & Optimierung.</li>
            </ol>
          </article>

          <article className="card">
            <h2 className="text-xl font-heading font-semibold text-dark">
              Für wen eignen sich die Module?
            </h2>
            <ul className="mt-5 space-y-3 text-sm text-slate-600">
              <li>• Solo-Haushalte mit Fokus auf Cashflow & Rücklagen.</li>
              <li>• Paare, die gemeinsame Ziele und Budgets strukturieren möchten.</li>
              <li>• Familien mit Blick auf Betreuungskosten, Bildung und Sicherheit.</li>
              <li>• Selbstständige, die variable Einnahmen ausgleichen.</li>
            </ul>
          </article>
        </div>
      </div>
    </section>
  );
};

export default Services;