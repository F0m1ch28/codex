import React from "react";
import { Helmet } from "react-helmet";

const Privacy = () => {
  return (
    <section className="py-20 bg-white" id="cookies">
      <Helmet>
        <title>Datenschutz & Cookies – FinanzKompass DE</title>
        <meta
          name="description"
          content="Informationen zum Datenschutz und zur Verwendung von Cookies bei FinanzKompass DE."
        />
      </Helmet>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl space-y-6">
          <h1 className="section-title">Datenschutzerklärung</h1>
          <p className="text-sm text-slate-600">Stand: 1. März 2024</p>

          <div className="card space-y-6 text-sm text-slate-600">
            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                Verantwortliche Stelle
              </h2>
              <p className="mt-3">
                FinanzKompass DE GmbH · Hohenzollernring 62 · 50672 Köln · E-Mail:
                datenschutz@finanzkompass.de
              </p>
            </section>

            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                Verarbeitung personenbezogener Daten
              </h2>
              <p className="mt-3">
                Wir verarbeiten personenbezogene Daten (Name, E-Mail, Anfrageinhalte) nur zur
                Bearbeitung deiner Anfrage oder zum Versand des Newsletters. Eine Weitergabe
                erfolgt nicht ohne deine ausdrückliche Zustimmung.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                Newsletter
              </h2>
              <p className="mt-3">
                Für den Versand nutzen wir das Double-Opt-In-Verfahren. Du kannst dich
                jederzeit über den Abmeldelink abmelden.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                Analysen & Cookies
              </h2>
              <p className="mt-3">
                Wir verwenden Cookies zur anonymisierten Analyse und zur Bereitstellung
                unserer Service-Funktionen. Du kannst die Nutzung über das Cookie-Banner
                steuern.
              </p>
            </section>

            <section id="cookies">
              <h2 className="text-lg font-heading font-semibold text-dark">
                Cookie-Richtlinie
              </h2>
              <p className="mt-3">
                Essenzielle Cookies stellen den Betrieb sicher. Statistik-Cookies helfen uns,
                Inhalte zu verbessern. Du kannst deine Einwilligung jederzeit über die
                Browsereinstellungen widerrufen.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                Rechte der Betroffenen
              </h2>
              <p className="mt-3">
                Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der
                Verarbeitung, Datenübertragbarkeit sowie Widerspruch. Wende dich dazu an
                datenschutz@finanzkompass.de.
              </p>
            </section>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Privacy;