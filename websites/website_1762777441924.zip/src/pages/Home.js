import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Helmet } from "react-helmet";

const Home = () => {
  const [stats, setStats] = useState([
    { label: "Haushalte begleitet", value: 0, target: 1250, suffix: "+" },
    { label: "Ø Fixkostenquote", value: 0, target: 48, suffix: "%" },
    { label: "Monatsabschlüsse", value: 0, target: 6400, suffix: "+" },
    { label: "Budget-Workflows", value: 0, target: 6, suffix: "" }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((current) =>
        current.map((item) => {
          if (item.value >= item.target) return item;
          const increment = Math.ceil(item.target / 40);
          return { ...item, value: Math.min(item.value + increment, item.target) };
        })
      );
    }, 60);

    return () => clearInterval(interval);
  }, []);

  const testimonials = useMemo(
    () => [
      {
        name: "Miriam & Daniel K.",
        role: "Familie aus Köln",
        quote:
          "Mit FinanzKompass DE haben wir klare Routinen für unsere Haushaltsplanung gefunden. Die Fixkosten-Analyse und die Check-ins sorgen für echte Sicherheit.",
        image: "https://picsum.photos/120/120?random=21"
      },
      {
        name: "Lea W.",
        role: "Selbstständige Designerin, Hamburg",
        quote:
          "Der Leitfaden hat mir geholfen, variable Einnahmen planbar zu machen. Die Automatisierung der Sparrate nimmt mir viel Stress aus dem Monatsabschluss.",
        image: "https://picsum.photos/120/120?random=22"
      },
      {
        name: "Alex & Jonas R.",
        role: "Digital Professionals, Berlin",
        quote:
          "Wir nutzen die Vorlagen für gemeinsame Ziele und Rücklagen. Die Benchmarks für Fixkosten und Versicherungen sind Gold wert.",
        image: "https://picsum.photos/120/120?random=23"
      }
    ],
    []
  );

  const [testimonialIndex, setTestimonialIndex] = useState(0);

  useEffect(() => {
    const change = setInterval(() => {
      setTestimonialIndex((index) => (index + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(change);
  }, [testimonials.length]);

  const budgetData = [
    { name: "Wohnen", Wert: 38 },
    { name: "Mobilität", Wert: 11 },
    { name: "Lebensmittel", Wert: 16 },
    { name: "Insurance", Wert: 9 },
    { name: "Freizeit", Wert: 13 },
    { name: "Sparen", Wert: 13 }
  ];

  const pieData = [
    { name: "Notgroschen", value: 35 },
    { name: "Urlaub & Freizeit", value: 20 },
    { name: "Altersvorsorge", value: 25 },
    { name: "Bildung & Kinder", value: 20 }
  ];

  const pieColors = ["#2563EB", "#F59E0B", "#111827", "#4F46E5"];

  const steps = [
    {
      title: "Status erfassen",
      description:
        "Einnahmen, Ausgaben, Dispo und Verträge transparent machen – inklusive Konto-Mapping.",
      icon: "🧭"
    },
    {
      title: "Ziele definieren",
      description:
        "Kurz-, Mittel- und Langfristziele mit realistischer Timeline und passenden Budgets festlegen.",
      icon: "🎯"
    },
    {
      title: "Budget aufsetzen",
      description:
        "Fixkostenquoten optimieren, variable Kategorien definieren und Rücklagen-Slots einplanen.",
      icon: "🧮"
    },
    {
      title: "Automatisieren",
      description:
        "Smartes Konto-System, Daueraufträge und Sparpläne für zuverlässige Routinen konfigurieren.",
      icon: "⚙️"
    },
    {
      title: "Check-in etablieren",
      description:
        "Monatlicher Abschluss mit Benchmarks, Abweichungsanalyse und Forecast für den nächsten Monat.",
      icon: "📆"
    },
    {
      title: "Optimieren & skalieren",
      description:
        "Haushaltsdaten auswerten, Entscheidungen datenbasiert treffen und Szenarien simulieren.",
      icon: "📈"
    }
  ];

  const services = [
    {
      title: "Budget Navigator",
      description:
        "Personalisierte Workflows für Haushaltsbudget, Cashflow-Management und Rücklagen.",
      link: "/services#navigator"
    },
    {
      title: "Fixkosten Radar",
      description:
        "Vergleich deiner Fixkostenquote mit deutschen Benchmarks und individuellem Sparpotenzial.",
      link: "/services#fixkosten"
    },
    {
      title: "Lebensphasen Coaching",
      description:
        "Finanzplanung für Paare, junge Familien und Solo-Haushalte mit passenden Templates.",
      link: "/services#coaching"
    }
  ];

  const projects = [
    {
      title: "Haushalts-Performance Dashboard",
      category: "Familien",
      description:
        "Live-Dashboard für Rücklagen, Betreuungskosten und Bildungsbudgets in NRW.",
      result: "Fixkostenquote um 6 Prozentpunkte gesenkt.",
      image: "https://picsum.photos/600/400?random=31"
    },
    {
      title: "Cashflow Map für Gründer:innen",
      category: "Singles",
      description:
        "Segmentiertes Budget mit Quartals-Vorratsplanung und Liquiditätspuffer.",
      result: "3-Monats-Notgroschen in 8 Monaten aufgebaut.",
      image: "https://picsum.photos/600/400?random=32"
    },
    {
      title: "Familienziel-Tracking",
      category: "Paare",
      description:
        "Zielportfolio für Elterngeld, Renovierung und Ferien mit gemeinsamem Dashboard.",
      result: "Automatisierte Sparrate von 18 % etabliert.",
      image: "https://picsum.photos/600/400?random=33"
    }
  ];

  const [activeCategory, setActiveCategory] = useState("Alle");

  const filteredProjects =
    activeCategory === "Alle"
      ? projects
      : projects.filter((project) => project.category === activeCategory);

  const faqItems = [
    {
      question: "Wie starte ich mit dem 6-Schritte-Leitfaden?",
      answer:
        "Unser kostenloser Leitfaden führt dich Schritt für Schritt von der Bestandsaufnahme bis zur Optimierung. Du erhältst Checklisten, Benchmarks und Vorlagen für jede Phase."
    },
    {
      question: "Welche Daten brauche ich für die Budget-Analyse?",
      answer:
        "Für einen ersten Überblick reichen Kontoauszüge der letzten drei Monate, Verträge für Fixkosten sowie bestehende Spar- und Investmentpläne."
    },
    {
      question: "Gibt es individuelle Beratung?",
      answer:
        "Ja, unser Team bietet Sessions für Singles, Paare und Familien an. Wir entwickeln eine maßgeschneiderte Strategie und liefern passende Tools."
    },
    {
      question: "Wie sicher sind meine Daten?",
      answer:
        "Wir arbeiten DSGVO-konform, speichern keine Bankzugänge und hosten alle Daten in deutschen Rechenzentren."
    }
  ];

  const schemaArticle = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: "Dein Kompass für klare Finanzen",
    description:
      "FinanzKompass DE liefert praxisnahe Budget-Workflows, Benchmarks und Tools für Singles, Paare und Familien in Deutschland.",
    image: "https://picsum.photos/1600/900?random=1",
    author: {
      "@type": "Organization",
      name: "FinanzKompass DE"
    },
    publisher: {
      "@type": "Organization",
      name: "FinanzKompass DE",
      logo: {
        "@type": "ImageObject",
        url: "https://picsum.photos/300/300?random=7"
      }
    },
    url: "https://www.finanzkompass.de",
    datePublished: "2024-01-15",
    dateModified: "2024-03-01"
  };

  const schemaHowTo = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    name: "Budget-Workflow in sechs Schritten",
    description:
      "Ein strukturierter Prozess, um Haushaltsfinanzen in Deutschland zu erfassen, zu planen und zu optimieren.",
    totalTime: "P6W",
    step: steps.map((step, index) => ({
      "@type": "HowToStep",
      position: index + 1,
      name: step.title,
      text: step.description
    }))
  };

  return (
    <>
      <Helmet>
        <title>FinanzKompass DE – Dein Kompass für klare Finanzen</title>
        <meta
          name="description"
          content="FinanzKompass DE begleitet dich mit Budget-Workflows, Benchmarks und Tools für klare Finanzentscheidungen."
        />
        <meta
          name="keywords"
          content="Finanzplanung, Budget-Workflow, Fixkostenquote, Monatsabschluss, Benchmarks, Haushaltsplan, Zieltracking, Familienbudget, Rücklagenplanung"
        />
        <meta property="og:title" content="FinanzKompass DE – Dein Kompass für klare Finanzen" />
        <meta
          property="og:description"
          content="Nutze datenbasierte Budget-Routinen, smarte Rechner und Templates für deine Finanzstrategie."
        />
        <meta property="og:image" content="https://picsum.photos/1600/900?random=1" />
        <meta property="og:url" content="https://www.finanzkompass.de" />
        <meta name="twitter:title" content="FinanzKompass DE – Klarheit für deine Finanzen" />
        <meta
          name="twitter:description"
          content="Budget-Workflows und Benchmarks, die in deutschen Haushalten funktionieren."
        />
        <script type="application/ld+json">{JSON.stringify(schemaArticle)}</script>
        <script type="application/ld+json">{JSON.stringify(schemaHowTo)}</script>
      </Helmet>

      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800 text-white">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/1600/900?random=1"
            alt="Professionelles Finanzteam in Deutschland"
            className="h-full w-full object-cover opacity-40"
            loading="lazy"
          />
        </div>
        <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <div>
              <span className="inline-flex items-center rounded-full bg-brand/20 px-4 py-1 text-sm font-semibold text-brand">
                Praxisnah & datenbasiert
              </span>
              <h1 className="mt-6 text-4xl sm:text-5xl font-heading font-extrabold leading-tight">
                Dein Kompass für klare Finanzen
              </h1>
              <p className="mt-5 text-lg text-slate-200">
                FinanzKompass DE liefert dir stabile Budget-Workflows, Benchmarks für
                Fixkosten und automatisierte Routinen – abgestimmt auf Singles,
                Paare und Familien in Deutschland.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row sm:items-center sm:space-x-5 space-y-4 sm:space-y-0">
                <Link
                  to="/services#leitfaden"
                  className="inline-flex items-center justify-center rounded-full bg-brand px-7 py-3 text-base font-semibold text-white shadow-lg shadow-brand/40 transition hover:-translate-y-1"
                >
                  Leitfaden starten
                </Link>
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center rounded-full border border-white/40 px-7 py-3 text-base font-semibold text-white transition hover:bg-white/10"
                >
                  Beratung anfragen
                </Link>
              </div>
            </div>

            <div className="relative">
              <div className="rounded-3xl bg-white/10 p-6 backdrop-blur shadow-2xl">
                <div className="grid gap-6 sm:grid-cols-2 text-slate-900">
                  {stats.map((stat) => (
                    <div
                      key={stat.label}
                      className="rounded-2xl bg-white/90 p-6 text-center shadow-lg shadow-brand/10"
                    >
                      <p className="text-sm font-semibold text-brand uppercase tracking-wide">
                        {stat.label}
                      </p>
                      <p className="mt-3 text-3xl font-heading font-bold text-dark">
                        {stat.value}
                        <span className="text-brand">{stat.suffix}</span>
                      </p>
                      <div className="mt-2 h-1.5 rounded-full bg-slate-200">
                        <div
                          className="h-full rounded-full bg-brand transition-all duration-500"
                          style={{ width: `${Math.min((stat.value / stat.target) * 100, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="mt-6 text-sm text-slate-200">
                  Maßgebliche KPIs aus deutschen Haushalten – validiert durch monatliche
                  Benchmarks und Community-Insights.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute -bottom-16 left-1/2 h-32 w-[120%] -translate-x-1/2 rounded-full bg-slate-50 blur-3xl opacity-40"></div>
      </section>

      <section className="py-16 sm:py-20 bg-slate-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="section-title">Warum Budgetierung jetzt zählt</h2>
              <p className="section-lead">
                Die Kombination aus Inflation, Energiekosten und neuen Lebensphasen
                verlangt nach einem klaren System. Wir helfen dir, deine Zahlen zu kennen,
                bewusst zu planen und Spielräume zu schaffen – ohne Verzichtsrhetorik.
              </p>
              <ul className="mt-8 space-y-4">
                <li className="feature-list">
                  <span>✔</span>
                  <div>
                    <p className="text-base font-semibold">Fixkosten verstehen & optimieren</p>
                    <p className="text-sm text-slate-600">
                      Analysen mit deutschen Benchmarks für Miete, Versicherungen, Mobilität.
                    </p>
                  </div>
                </li>
                <li className="feature-list">
                  <span>✔</span>
                  <div>
                    <p className="text-base font-semibold">
                      Flexible Budgets für variable Ausgaben
                    </p>
                    <p className="text-sm text-slate-600">
                      Ernährung, Freizeit und Bildung mit realistischen Grenzen und Puffern.
                    </p>
                  </div>
                </li>
                <li className="feature-list">
                  <span>✔</span>
                  <div>
                    <p className="text-base font-semibold">Rücklagen zielgerichtet aufbauen</p>
                    <p className="text-sm text-slate-600">
                      Ob Notgroschen, Urlaub oder Familienplanung – klare Prioritäten mit Plan.
                    </p>
                  </div>
                </li>
              </ul>
              <Link
                to="/services"
                className="mt-8 inline-flex items-center rounded-full bg-dark px-6 py-3 text-sm font-semibold text-white transition hover:bg-brand"
              >
                Alle Services entdecken
              </Link>
            </div>
            <div className="relative">
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Haushalt plant Finanzen am Küchentisch in Deutschland"
                className="rounded-3xl shadow-2xl"
                loading="lazy"
              />
              <div className="absolute -bottom-8 -left-8 w-48 rounded-2xl bg-white p-4 shadow-xl">
                <p className="text-xs uppercase tracking-wide text-brand font-semibold">
                  Haushaltsplan
                </p>
                <p className="mt-2 text-lg font-heading font-bold text-dark">
                  1.200+ Haushalte
                </p>
                <p className="text-sm text-slate-500">verfolgen Ziele mit FinanzKompass DE.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h2 className="section-title">Budgetdaten visualisieren</h2>
            <p className="section-lead">
              Nutze Dashboards und Visualisierungen, um deine Finanzentscheidungen
              datenbasiert zu treffen. Responsive Recharts geben dir Überblick über
              Cashflow, Fixkostenquote und Zielerreichung.
            </p>
          </div>

          <div className="mt-12 grid gap-10 lg:grid-cols-2">
            <div className="card">
              <h3 className="text-lg font-semibold text-dark">
                Fixkostenquote nach Kategorien
              </h3>
              <div className="mt-6 h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={budgetData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#CBD5F5" />
                    <XAxis dataKey="name" stroke="#64748B" />
                    <YAxis stroke="#64748B" />
                    <Tooltip
                      cursor={{ fill: "rgba(37, 99, 235, 0.1)" }}
                      contentStyle={{ borderRadius: "12px", borderColor: "#E2E8F0" }}
                    />
                    <Bar dataKey="Wert" fill="#2563EB" radius={[10, 10, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="card">
              <h3 className="text-lg font-semibold text-dark">Rücklagen nach Zweck</h3>
              <div className="mt-6 h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={entry.name} fill={pieColors[index % pieColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ borderRadius: "12px", borderColor: "#E2E8F0" }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-slate-900 text-white" id="leitfaden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h2 className="section-title text-white">Der Workflow: Schritt für Schritt</h2>
            <p className="section-lead text-slate-300">
              Unser Leitfaden orientiert sich an den Bedürfnissen deutscher Haushalte.
              Jede Phase beinhaltet Checklisten, Benchmarks und Tools, die sofort
              einsetzbar sind.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {steps.map((step, index) => (
              <div key={step.title} className="process-card">
                <span className="text-4xl">{step.icon}</span>
                <div>
                  <p className="text-sm font-semibold uppercase tracking-wide text-brand">
                    Schritt {index + 1}
                  </p>
                  <h3 className="mt-2 text-xl font-heading font-semibold text-white">
                    {step.title}
                  </h3>
                  <p className="mt-3 text-sm text-slate-300">{step.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 flex flex-col md:flex-row md:items-center md:justify-between md:space-x-6 space-y-4 md:space-y-0">
            <Link
              to="/services"
              className="inline-flex items-center rounded-full bg-white px-6 py-3 text-sm font-semibold text-dark shadow-lg shadow-black/20 transition hover:-translate-y-1"
            >
              Alle Details im Service-Bereich
            </Link>
            <p className="text-sm text-slate-300">
              Enthalten: CSV-Sheets, Google Sheets, Notion-Templates & Videowalkthrough.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-slate-50" id="services">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h2 className="section-title">Services & Tools</h2>
            <p className="section-lead">
              Wähle das passende Modul für deinen Haushalt. Alle Services können
              individuell kombiniert oder als Paket gebucht werden.
            </p>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {services.map((service) => (
              <article
                key={service.title}
                className="service-card"
              >
                <h3 className="text-lg font-heading font-semibold text-dark">
                  {service.title}
                </h3>
                <p className="mt-3 text-sm text-slate-600">{service.description}</p>
                <Link
                  to={service.link}
                  className="mt-6 inline-flex items-center text-sm font-semibold text-brand hover:text-brand/80"
                >
                  Mehr erfahren →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white" id="testimonials">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h2 className="section-title">Stimmen aus der Community</h2>
            <p className="section-lead">
              Haushalte aus ganz Deutschland teilen ihre Erfahrungen mit dem
              FinanzKompass-DE-Prozess.
            </p>
          </div>

          <div className="mt-12 grid gap-12 lg:grid-cols-[1.2fr_0.8fr] items-center">
            <div className="testimonial-card">
              <img
                src={testimonials[testimonialIndex].image}
                alt={`Portrait von ${testimonials[testimonialIndex].name}`}
                className="h-20 w-20 rounded-full object-cover border-4 border-brand/40"
              />
              <p className="mt-6 text-lg text-slate-700 leading-relaxed">
                “{testimonials[testimonialIndex].quote}”
              </p>
              <p className="mt-4 font-semibold text-dark">
                {testimonials[testimonialIndex].name}
              </p>
              <p className="text-sm text-slate-500">
                {testimonials[testimonialIndex].role}
              </p>
              <div className="mt-6 flex space-x-3">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    type="button"
                    className={`h-2.5 w-8 rounded-full transition ${
                      testimonialIndex === index ? "bg-brand" : "bg-slate-200"
                    }`}
                    onClick={() => setTestimonialIndex(index)}
                    aria-label={`Testimonial ${index + 1} anzeigen`}
                  ></button>
                ))}
              </div>
            </div>

            <div className="rounded-3xl bg-slate-50 p-8 shadow-lg">
              <h3 className="text-lg font-heading font-semibold text-dark">
                Wirkung nach 12 Wochen
              </h3>
              <ul className="mt-6 space-y-4 text-sm text-slate-600">
                <li>• Transparente Haushaltsplanung mit klaren Rücklagenzielen</li>
                <li>• Monatliche Check-ins inkl. Abweichungsanalyse</li>
                <li>• Automatisierte Spar- und Investmentroutinen</li>
                <li>• Gemeinsames Finanz-Mindset für Paare & Familien</li>
              </ul>
              <Link
                to="/contact"
                className="mt-6 inline-flex items-center rounded-full bg-brand px-5 py-2 text-sm font-semibold text-white hover:-translate-y-0.5"
              >
                Individuelles Erstgespräch
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div className="max-w-2xl">
              <h2 className="section-title">Ausgewählte Projekte</h2>
              <p className="section-lead">
                Von Budget-Dashboards bis hin zu Familienzielen – unsere Lösungen
                schaffen Klarheit und Sicherheit.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              {["Alle", "Singles", "Paare", "Familien"].map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                    activeCategory === category
                      ? "bg-brand text-white"
                      : "bg-white text-slate-600 hover:bg-slate-100"
                  }`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {filteredProjects.map((project) => (
              <article key={project.title} className="project-card">
                <div className="overflow-hidden rounded-xl">
                  <img
                    src={project.image}
                    alt={`Projektbeispiel: ${project.title}`}
                    className="h-48 w-full object-cover transition duration-500 hover:scale-105"
                    loading="lazy"
                  />
                </div>
                <div className="mt-5">
                  <span className="text-xs uppercase font-semibold text-brand">
                    {project.category}
                  </span>
                  <h3 className="mt-2 text-lg font-heading font-semibold text-dark">
                    {project.title}
                  </h3>
                  <p className="mt-3 text-sm text-slate-600">{project.description}</p>
                  <p className="mt-4 text-sm font-medium text-dark">
                    Ergebnis: {project.result}
                  </p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white" id="faq">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 className="section-title">Häufige Fragen</h2>
              <p className="section-lead">
                Transparente Antworten auf die wichtigsten Fragen rund um Budgetplanung,
                Tools und Zusammenarbeit.
              </p>
              <Link
                to="/contact"
                className="mt-6 inline-flex items-center text-sm font-semibold text-brand hover:text-brand/80"
              >
                Weitere Frage? Schreib uns →
              </Link>
            </div>
            <div className="space-y-4">
              {faqItems.map((faq, index) => (
                <details key={faq.question} className="faq-item">
                  <summary className="cursor-pointer text-base font-semibold text-dark">
                    {faq.question}
                  </summary>
                  <p className="mt-3 text-sm text-slate-600">{faq.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-brand text-white" id="blog">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
            <div className="max-w-2xl">
              <h2 className="section-title text-white">Aktuelle Insights & Benchmarks</h2>
              <p className="section-lead text-slate-100">
                Monatliche Checklisten, Benchmark-Reports und Versicherungs-Priorisierung
                im Kontext deutscher Haushalte.
              </p>
            </div>
            <Link
              to="/services#blog"
              className="inline-flex items-center rounded-full border border-white px-6 py-3 text-sm font-semibold text-white transition hover:bg-white hover:text-brand"
            >
              Zum Blog-Bereich
            </Link>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {[
              {
                title: "Monatsabschluss-Checkliste",
                description:
                  "Strukturierter Monatsabschluss mit Kennzahlen, Kontenabgleich und Forecast.",
                link: "/services#monatsabschluss"
              },
              {
                title: "Fixkosten-Benchmarks DE",
                description:
                  "Vergleichswerte für Miete, Energie, Versicherungen in deutschen Städten.",
                link: "/services#benchmarks"
              },
              {
                title: "Versicherungen priorisieren",
                description:
                  "Wie du Pflicht, sollte und kann-Policen sauber sortierst.",
                link: "/services#versicherungen"
              }
            ].map((article) => (
              <article key={article.title} className="blog-card">
                <span className="text-xs uppercase font-semibold tracking-wide text-white/70">
                  Update
                </span>
                <h3 className="mt-3 text-lg font-heading font-semibold">
                  {article.title}
                </h3>
                <p className="mt-3 text-sm text-white/80">{article.description}</p>
                <Link
                  to={article.link}
                  className="mt-6 inline-flex items-center text-sm font-semibold text-white"
                >
                  Weiterlesen →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-slate-900 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 md:grid-cols-2 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-heading font-bold">
                Bereit für klare Finanzentscheidungen?
              </h2>
              <p className="mt-5 text-lg text-slate-300">
                Buche einen unverbindlichen Finanz-Check und erhalte deinen individuellen
                6-Schritte-Plan plus Analyzer für Fixkosten, Sparrate und Rücklagen.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-4 sm:space-y-0">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center rounded-full bg-brand px-7 py-3 text-base font-semibold text-white shadow-lg shadow-brand/30 transition hover:-translate-y-1"
                >
                  Erstgespräch sichern
                </Link>
                <a
                  href="#leitfaden"
                  className="inline-flex items-center justify-center rounded-full border border-white/40 px-7 py-3 text-base font-semibold text-white transition hover:bg-white/10"
                >
                  Leitfaden ansehen
                </a>
              </div>
            </div>
            <div className="rounded-3xl bg-white/10 p-8 shadow-2xl">
              <h3 className="text-lg font-heading font-semibold text-white">
                Finanz-Check Highlights
              </h3>
              <ul className="mt-4 space-y-3 text-sm text-slate-200">
                <li>• Individuelle Analyse deiner Fixkostenquote & Sparrate</li>
                <li>• Szenarien für Familienplanung, Immobilien oder Selbstständigkeit</li>
                <li>• Zugriff auf Templates, Checklisten und Benchmarks</li>
                <li>• DSGVO-konforme Dokumentation & klare nächste Schritte</li>
              </ul>
              <p className="mt-6 text-sm text-slate-300">
                Termin innerhalb von 7 Tagen verfügbar – digital oder in Köln / Düsseldorf.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;