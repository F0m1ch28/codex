import React from "react";
import { Helmet } from "react-helmet";

const About = () => {
  return (
    <section className="py-20 bg-slate-50">
      <Helmet>
        <title>Über FinanzKompass DE – Team & Mission</title>
        <meta
          name="description"
          content="Das Team von FinanzKompass DE kombiniert Finanzexpertise und datengetriebene Tools, um Haushalte nachhaltig zu begleiten."
        />
        <meta property="og:title" content="Über FinanzKompass DE – Team & Mission" />
        <meta
          property="og:description"
          content="Lerne das Team kennen, das Budget-Workflows, Benchmarks und Tools für deutsche Haushalte entwickelt."
        />
        <meta property="og:image" content="https://picsum.photos/1200/800?random=41" />
      </Helmet>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <h1 className="section-title">Über FinanzKompass DE</h1>
          <p className="section-lead">
            Wir sind eine unabhängige Finanzplattform aus Köln. Unser Team verbindet
            Finanzplanung, Behavioural Finance und Produktentwicklung, um Haushalten
            Sicherheit und Souveränität bei Geldentscheidungen zu geben.
          </p>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          <article className="card">
            <h2 className="text-xl font-heading font-semibold text-dark">
              Unsere Mission
            </h2>
            <p className="mt-4 text-sm text-slate-600">
              Klarheit in privaten Finanzen ist kein Luxus, sondern die Basis für
              Lebensentscheidungen. Wir entwickeln Workflows, die funktionieren –
              unabhängig davon, ob du dein erstes Gehalt strukturierst oder Familienziele
              planst.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-600">
              <li>• Praxisorientierte Frameworks statt theoretischer Ratgeber.</li>
              <li>• Benchmarks, die auf deutschen Haushaltsdaten basieren.</li>
              <li>• Tools, die sich in deinen Alltag integrieren lassen.</li>
            </ul>
          </article>

          <article className="card">
            <h2 className="text-xl font-heading font-semibold text-dark">
              Unser Ansatz
            </h2>
            <p className="mt-4 text-sm text-slate-600">
              In iterativen Sprints entwickeln wir Content, Templates und Tools. Jede
              Veröffentlichung wird mit der Community getestet und anhand von Feedback
              optimiert.
            </p>
            <ol className="mt-5 list-decimal space-y-2 pl-6 text-sm text-slate-600">
              <li>Research & Datenvalidierung</li>
              <li>Konzeption & Prototyping</li>
              <li>Testen mit Haushalten</li>
              <li>Rollout & kontinuierliches Monitoring</li>
            </ol>
          </article>
        </div>

        <div className="mt-16">
          <h2 className="text-2xl font-heading font-semibold text-dark">
            Das Team hinter FinanzKompass DE
          </h2>
          <p className="mt-3 text-sm text-slate-600">
            Interdisziplinär, praxisnah, fokussiert auf Wirkung.
          </p>

          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {[
              {
                name: "Nadine Fischer",
                role: "Finanzplanerin (CFP®)",
                focus: "Haushaltsanalysen, Lebensphasenplanung",
                image: "https://picsum.photos/400/400?random=3"
              },
              {
                name: "Roman Adler",
                role: "Data Strategist",
                focus: "Benchmarks, Visualisierung, KPI-Modelle",
                image: "https://picsum.photos/400/400?random=34"
              },
              {
                name: "Clara Mertens",
                role: "Content & Enablement",
                focus: "Guides, Workshops, Community",
                image: "https://picsum.photos/400/400?random=35"
              }
            ].map((member) => (
              <article key={member.name} className="team-card">
                <div className="relative h-56 overflow-hidden rounded-2xl">
                  <img
                    src={member.image}
                    alt={`Teammitglied ${member.name}`}
                    className="h-full w-full object-cover transition duration-500 hover:scale-110"
                    loading="lazy"
                  />
                </div>
                <div className="mt-4">
                  <h3 className="text-lg font-heading font-semibold text-dark">
                    {member.name}
                  </h3>
                  <p className="text-sm font-medium text-brand">{member.role}</p>
                  <p className="mt-3 text-sm text-slate-600">{member.focus}</p>
                </div>
              </article>
            ))}
          </div>
        </div>

        <div className="mt-16 card">
          <h2 className="text-xl font-heading font-semibold text-dark">
            Zusammenarbeit & Werte
          </h2>
          <ul className="mt-5 grid gap-4 sm:grid-cols-2 text-sm text-slate-600">
            <li className="rounded-2xl bg-slate-100 p-4">
              <p className="font-semibold text-dark">Transparenz</p>
              <p className="mt-2">
                Keine versteckten Agenda, kein Produktverkauf, keine leeren Versprechen.
              </p>
            </li>
            <li className="rounded-2xl bg-slate-100 p-4">
              <p className="font-semibold text-dark">Datenbasierte Entscheidungen</p>
              <p className="mt-2">
                Wir nutzen aktuelle Haushaltsstatistiken, um sinnvolle Empfehlungen zu geben.
              </p>
            </li>
            <li className="rounded-2xl bg-slate-100 p-4">
              <p className="font-semibold text-dark">Empowerment</p>
              <p className="mt-2">
                Unsere Tools machen dich unabhängiger von Zufall und Bauchgefühl.
              </p>
            </li>
            <li className="rounded-2xl bg-slate-100 p-4">
              <p className="font-semibold text-dark">Langfristiger Fokus</p>
              <p className="mt-2">
                Programme für nachhaltige Routinen statt kurzfristiger Hacks.
              </p>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default About;