import React from "react";
import { Helmet } from "react-helmet";

const Terms = () => {
  return (
    <section className="py-20 bg-slate-50">
      <Helmet>
        <title>Nutzungsbedingungen – FinanzKompass DE</title>
        <meta
          name="description"
          content="Nutzungsbedingungen für den Zugang und die Verwendung der Inhalte von FinanzKompass DE."
        />
      </Helmet>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl space-y-6">
          <h1 className="section-title">Nutzungsbedingungen</h1>
          <p className="text-sm text-slate-600">
            Stand: 1. März 2024
          </p>
          <div className="card space-y-6 text-sm text-slate-600">
            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                1. Geltungsbereich
              </h2>
              <p className="mt-3">
                Diese Nutzungsbedingungen regeln die Nutzung sämtlicher Inhalte und Services
                von FinanzKompass DE. Mit dem Zugriff erkennst du die Bedingungen an.
              </p>
            </section>
            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                2. Inhalte & Haftung
              </h2>
              <p className="mt-3">
                Alle Inhalte sind sorgfältig erstellt, ersetzen jedoch keine individuelle
                Steuer- oder Rechtsberatung. Entscheidungen triffst du eigenverantwortlich.
              </p>
            </section>
            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                3. Nutzung der Tools
              </h2>
              <p className="mt-3">
                Die bereitgestellten Rechner, Vorlagen und Workflows dürfen ausschließlich
                privat genutzt und nicht weiterverkauft werden.
              </p>
            </section>
            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                4. Haftung für Links
              </h2>
              <p className="mt-3">
                Für Inhalte externer Seiten übernehmen wir keine Haftung. Verantwortlich ist
                jeweils der Betreiber.
              </p>
            </section>
            <section>
              <h2 className="text-lg font-heading font-semibold text-dark">
                5. Schlussbestimmungen
              </h2>
              <p className="mt-3">
                Es gilt deutsches Recht. Gerichtsstand ist Köln. Sollten einzelne Regelungen
                unwirksam sein, berührt dies nicht die Wirksamkeit der übrigen Bestimmungen.
              </p>
            </section>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Terms;