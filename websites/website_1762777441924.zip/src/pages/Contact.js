import React, { useState } from "react";
import { Helmet } from "react-helmet";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    topic: "",
    message: ""
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const nextErrors = {};
    if (!formData.name.trim()) nextErrors.name = "Bitte einen Namen eingeben.";
    if (!formData.email.trim()) {
      nextErrors.email = "E-Mail Adresse bitte angeben.";
    } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      nextErrors.email = "Bitte eine gültige E-Mail nutzen.";
    }
    if (!formData.topic.trim()) nextErrors.topic = "Bitte ein Thema auswählen.";
    if (!formData.message.trim() || formData.message.length < 20) {
      nextErrors.message = "Nachricht bitte mit mindestens 20 Zeichen beschreiben.";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setSubmitted(true);
    }
  };

  return (
    <section className="py-20 bg-white" id="contact">
      <Helmet>
        <title>Kontakt – FinanzKompass DE</title>
        <meta
          name="description"
          content="Kontaktiere FinanzKompass DE für Budget-Coaching, Workflows und individuelle Finanzplanung in Deutschland."
        />
        <meta property="og:title" content="Kontakt – FinanzKompass DE" />
        <meta
          property="og:description"
          content="Buche ein Erstgespräch oder stelle Fragen zu Modulen, Vorlagen und Rechnern."
        />
        <meta property="og:image" content="https://picsum.photos/1200/800?random=43" />
      </Helmet>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <h1 className="section-title">Kontakt aufnehmen</h1>
          <p className="section-lead">
            Du möchtest den Budget-Workflow für deinen Haushalt nutzen oder ein Coaching
            buchen? Schreib uns – wir melden uns innerhalb von 48 Stunden.
          </p>
        </div>

        <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_0.65fr]">
          <form className="card space-y-6" onSubmit={handleSubmit} noValidate>
            <div>
              <label htmlFor="name" className="form-label">
                Name*
              </label>
              <input
                id="name"
                type="text"
                className={`form-input ${errors.name ? "form-input-error" : ""}`}
                placeholder="Vor- und Nachname"
                value={formData.name}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, name: event.target.value }))
                }
                aria-invalid={Boolean(errors.name)}
                required
              />
              {errors.name && <p className="form-error">{errors.name}</p>}
            </div>

            <div>
              <label htmlFor="email" className="form-label">
                E-Mail*
              </label>
              <input
                id="email"
                type="email"
                className={`form-input ${errors.email ? "form-input-error" : ""}`}
                placeholder="name@email.de"
                value={formData.email}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, email: event.target.value }))
                }
                aria-invalid={Boolean(errors.email)}
                required
              />
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>

            <div>
              <label htmlFor="topic" className="form-label">
                Thema*
              </label>
              <select
                id="topic"
                className={`form-input ${errors.topic ? "form-input-error" : ""}`}
                value={formData.topic}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, topic: event.target.value }))
                }
                aria-invalid={Boolean(errors.topic)}
                required
              >
                <option value="">Bitte auswählen</option>
                <option value="Leitfaden">Leitfaden & Vorlagen</option>
                <option value="Rechner">Rechner & Benchmarks</option>
                <option value="Coaching">Coaching & Beratung</option>
                <option value="Workshop">Workshop & Team-Formate</option>
              </select>
              {errors.topic && <p className="form-error">{errors.topic}</p>}
            </div>

            <div>
              <label htmlFor="message" className="form-label">
                Nachricht*
              </label>
              <textarea
                id="message"
                className={`form-input h-32 ${errors.message ? "form-input-error" : ""}`}
                placeholder="Beschreibe dein Anliegen"
                value={formData.message}
                onChange={(event) =>
                  setFormData((prev) => ({ ...prev, message: event.target.value }))
                }
                aria-invalid={Boolean(errors.message)}
                required
              />
              {errors.message && <p className="form-error">{errors.message}</p>}
            </div>

            <button
              type="submit"
              className="inline-flex items-center justify-center rounded-full bg-brand px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-brand/30 transition hover:-translate-y-1"
            >
              Nachricht senden
            </button>

            {submitted && (
              <p className="rounded-xl bg-green-50 px-4 py-3 text-sm font-semibold text-green-700">
                Danke für deine Nachricht! Wir melden uns schnellstmöglich.
              </p>
            )}
          </form>

          <aside className="card space-y-6">
            <div>
              <h2 className="text-lg font-heading font-semibold text-dark">
                Erreichbarkeit
              </h2>
              <p className="mt-2 text-sm text-slate-600">
                FinanzKompass DE GmbH<br />
                Hohenzollernring 62 · 50672 Köln
              </p>
            </div>

            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wide text-brand">
                Kontakt
              </h3>
              <p className="mt-2 text-sm text-slate-600">
                Telefon: <a href="tel:+4922112345678" className="text-brand">+49 221 123 456 78</a>
                <br />
                E-Mail: <a href="mailto:hallo@finanzkompass.de" className="text-brand">hallo@finanzkompass.de</a>
              </p>
            </div>

            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wide text-brand">
                Sprechzeiten
              </h3>
              <p className="mt-2 text-sm text-slate-600">
                Montag – Freitag: 09:00 – 18:00 Uhr<br />
                Samstag: nach Vereinbarung<br />
                Termine vor Ort in Köln & Düsseldorf, digital deutschlandweit.
              </p>
            </div>

            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wide text-brand">
                Impressum
              </h3>
              <p className="mt-2 text-xs text-slate-500" id="impressum">
                FinanzKompass DE GmbH · Geschäftsführer: Nadine Fischer · HRB 123456 AG Köln ·
                USt-ID: DE123456789
              </p>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
};

export default Contact;