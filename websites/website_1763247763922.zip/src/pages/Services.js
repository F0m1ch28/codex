import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const servicesData = [
  {
    title: 'Аналитика и консалтинг',
    description:
      'Диагностика цифровой зрелости, аудит архитектуры и рекомендация стратегии развития продуктов.',
    details: [
      'Исследование пользователей и бизнес-процессов',
      'Аудит кода, инфраструктуры и безопасности',
      'Создание продуктовой дорожной карты'
    ]
  },
  {
    title: 'Разработка веб-решений',
    description:
      'Создаём высоконагруженные веб-приложения, порталы и платформы с современной архитектурой.',
    details: [
      'Микросервисная архитектура и API-first подход',
      'Frontend на React, TypeScript, Next.js',
      'Backend на Node.js, Python и современных фреймворках'
    ]
  },
  {
    title: 'Мобильная разработка',
    description:
      'Проектируем мобильные приложения с нативным UX и надёжным бэкендом.',
    details: [
      'iOS и Android, React Native и Flutter',
      'UX-исследования и удобные сценарии использования',
      'Интеграция с корпоративными системами и аналитикой'
    ]
  },
  {
    title: 'Корпоративные решения',
    description:
      'Помогаем модернизировать внутренние системы, создаём единые цифровые экосистемы.',
    details: [
      'Интеграция ERP, CRM, BI-систем',
      'Разработка интранетов и порталов самообслуживания',
      'Настройка обмена данными и API-шлюзов'
    ]
  },
  {
    title: 'DevOps и поддержка',
    description:
      'Обеспечиваем стабильность и масштабируемость: от CI/CD до мониторинга и SLA.',
    details: [
      'Автоматизация релизов и инфраструктуры',
      'Непрерывный мониторинг и алертинг',
      'Команда поддержки 24/7 и управление инцидентами'
    ]
  }
];

const Services = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Услуги — ТехноИнновации</title>
        <meta
          name="description"
          content="Комплексные услуги по разработке программного обеспечения: аналитика и консалтинг, веб и мобильная разработка, внедрение корпоративных систем, DevOps и поддержка."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <span className="badge">Услуги</span>
            <h1>Полный цикл создания цифровых продуктов</h1>
            <p>
              Берём на себя все этапы — от исследования и разработки до запуска и сопровождения.
              Работая с нами, вы получаете команду с отлаженными процессами и прозрачной коммуникацией.
            </p>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.servicesLayout}>
            <div className={styles.list}>
              {servicesData.map((service, index) => (
                <button
                  type="button"
                  key={service.title}
                  className={`${styles.listItem} ${
                    activeIndex === index ? styles.active : ''
                  }`}
                  onClick={() => setActiveIndex(index)}
                  aria-expanded={activeIndex === index}
                >
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                </button>
              ))}
            </div>
            <div className={styles.details} aria-live="polite">
              <h2>{servicesData[activeIndex].title}</h2>
              <p>{servicesData[activeIndex].description}</p>
              <ul>
                {servicesData[activeIndex].details.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.approach}>
        <div className="container">
          <div className={styles.approachInner}>
            <h2>Как мы работаем</h2>
            <div className={styles.approachGrid}>
              <div>
                <h3>1. Диагностика и план</h3>
                <p>
                  Проводим интервью, анализируем процессы, определяем метрики успеха и фиксируем
                  ожидания команды.
                </p>
              </div>
              <div>
                <h3>2. Проектирование</h3>
                <p>
                  Создаём архитектуру, UX-концепцию, прототипы и готовим техническую документацию.
                </p>
              </div>
              <div>
                <h3>3. Реализация</h3>
                <p>
                  Команда разработчиков, тестировщиков и DevOps реализует продукт спринтами,
                  предоставляя прозрачные отчёты.
                </p>
              </div>
              <div>
                <h3>4. Запуск и масштабирование</h3>
                <p>
                  Проводим обучение, внедряем аналитику, запускаем обновления и поддерживаем
                  стабильность сервиса.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;