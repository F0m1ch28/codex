import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', company: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const nextErrors = {};
    if (!form.name.trim()) nextErrors.name = 'Введите имя';
    if (!form.email.trim()) {
      nextErrors.email = 'Введите email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      nextErrors.email = 'Некорректный email';
    }
    if (!form.message.trim()) nextErrors.message = 'Расскажите о задаче';
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setStatus('');
    if (!validate()) return;
    setTimeout(() => {
      setStatus('Спасибо! Мы свяжемся с вами в ближайшее время.');
      setForm({ name: '', email: '', company: '', message: '' });
    }, 700);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Контакты — ТехноИнновации</title>
        <meta
          name="description"
          content="Свяжитесь с ТехноИнновациями: адрес в Москве, телефон, email. Отправьте форму и получите консультацию по разработке программного обеспечения."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Свяжитесь с нами</h1>
          <p>
            Расскажите о проекте, и мы подготовим предложение, познакомим вас с командой и определим
            сроки запуска пилота.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.layout}>
            <div className={styles.info}>
              <h2>Контактные данные</h2>
              <ul>
                <li>
                  <strong>Адрес:</strong> г. Москва, ул. Ленинградский проспект, д. 39, стр. 14
                </li>
                <li>
                  <strong>Телефон:</strong> <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@technoinnovations.ru">info@technoinnovations.ru</a>
                </li>
              </ul>
              <div className={styles.mapWrapper} aria-label="Карта офиса">
                <iframe
                  title="Офис ТехноИнновации, Москва"
                  src="https://yandex.ru/map-widget/v1/?um=constructor%3A3f2a8d688a4e93d5c0bc7a229ad3bfa42a7adf03dd23db77ba316aa1aa6d592b&amp;source=constructor"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <h2>Форма обратной связи</h2>
              <label>
                <span>Имя</span>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  aria-invalid={!!errors.name}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </label>
              <label>
                <span>Email</span>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </label>
              <label>
                <span>Компания</span>
                <input
                  type="text"
                  name="company"
                  value={form.company}
                  onChange={handleChange}
                />
              </label>
              <label>
                <span>Сообщение</span>
                <textarea
                  name="message"
                  rows="5"
                  value={form.message}
                  onChange={handleChange}
                  aria-invalid={!!errors.message}
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </label>
              <button type="submit" className="btnPrimary">
                Отправить
              </button>
              {status && (
                <p className={styles.status} role="status">
                  {status}
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;