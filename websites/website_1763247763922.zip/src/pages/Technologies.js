import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './Technologies.module.css';

const categories = [
  {
    title: 'Frontend',
    items: ['React', 'TypeScript', 'Next.js', 'Redux Toolkit', 'Progressive Web Apps']
  },
  {
    title: 'Backend',
    items: ['Node.js', 'NestJS', 'Python', 'Django', 'FastAPI', 'GraphQL', 'gRPC']
  },
  {
    title: 'Инфраструктура',
    items: ['Docker', 'Kubernetes', 'Terraform', 'AWS', 'Azure', 'Yandex Cloud']
  },
  {
    title: 'Data & AI',
    items: ['PostgreSQL', 'ClickHouse', 'MongoDB', 'Airflow', 'Apache Kafka', 'MLflow']
  },
  {
    title: 'Дизайн и исследования',
    items: ['Figma', 'Maze', 'UXPressia', 'Design Systems', 'A/B Testing']
  },
  {
    title: 'Качество и процессы',
    items: ['Cypress', 'Playwright', 'Jest', 'Storybook', 'SonarQube', 'Sentry']
  }
];

const Technologies = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Технологии — ТехноИнновации</title>
      <meta
        name="description"
        content="Мы используем современные технологии: React, TypeScript, Node.js, Python, Kubernetes, PostgreSQL, ClickHouse, облака и инструменты DevOps."
      />
    </Helmet>

    <section className={styles.hero}>
      <div className="container">
        <h1>Технологии и инструментариум</h1>
        <p>
          Выбираем технологический стек, который соответствует целям продукта, требованиям к
          безопасности и масштабируемости. Объединяем гибкость и надежность.
        </p>
      </div>
    </section>

    <section className={styles.categories}>
      <div className="container">
        <div className={styles.grid}>
          {categories.map((category) => (
            <article key={category.title} className={styles.card}>
              <h2>{category.title}</h2>
              <ul>
                {category.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>

    <section className={styles.integration}>
      <div className="container">
        <div className={styles.integrationCard}>
          <h2>Интеграции и API</h2>
          <p>
            Интегрируем решения с внутренними и внешними системами. Строим API-ориентированную
            архитектуру, документируем процессы и обеспечиваем безопасность данных.
          </p>
          <ul>
            <li>REST и GraphQL API</li>
            <li>Корпоративные шины данных и брокеры сообщений</li>
            <li>OAuth 2.0, OpenID Connect, SSO</li>
            <li>CI/CD конвейеры и инфраструктура как код</li>
          </ul>
        </div>
      </div>
    </section>
  </div>
);

export default Technologies;