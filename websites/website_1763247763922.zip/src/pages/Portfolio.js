import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Portfolio.module.css';

const projects = [
  {
    title: 'Digital Supply Chain',
    sector: 'Логистика',
    category: 'Корпоративные платформы',
    description:
      'Система управления цепочкой поставок с аналитикой в реальном времени и прогнозом спроса.',
    image: 'https://picsum.photos/1000/700?random=61'
  },
  {
    title: 'HealthConnect App',
    sector: 'Медицина',
    category: 'Мобильные решения',
    description:
      'Мобильное приложение для телемедицины с интеграцией электронных карт и мониторинга данных.',
    image: 'https://picsum.photos/1000/700?random=62'
  },
  {
    title: 'Retail Intelligence Hub',
    sector: 'Ритейл',
    category: 'Цифровые платформы',
    description:
      'Платформа управления ассортиментом и ценообразованием для федеральной сети магазинов.',
    image: 'https://picsum.photos/1000/700?random=63'
  },
  {
    title: 'SmartCity Control',
    sector: 'Умный город',
    category: 'IoT и интеграции',
    description:
      'Единый центр управления городскими сервисами с интеграцией датчиков, транспортных систем и аналитики.',
    image: 'https://picsum.photos/1000/700?random=64'
  },
  {
    title: 'EdTech Universe',
    sector: 'Образование',
    category: 'Платформы обучения',
    description:
      'Образовательная платформа с адаптивными сценариями, LMS и аналитикой вовлеченности студентов.',
    image: 'https://picsum.photos/1000/700?random=65'
  }
];

const filters = ['Все', 'Корпоративные платформы', 'Мобильные решения', 'Цифровые платформы', 'IoT и интеграции', 'Платформы обучения'];

const Portfolio = () => {
  const [activeFilter, setActiveFilter] = useState('Все');

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Все') {
      return projects;
    }
    return projects.filter((project) => project.category === activeFilter);
  }, [activeFilter]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Портфолио — ТехноИнновации</title>
        <meta
          name="description"
          content="Узнайте о реализованных проектах ТехноИнновации: цифровые платформы, мобильные приложения и корпоративные решения для разных отраслей."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <h1>Портфолио проектов</h1>
          <p>
            Мы запускаем цифровые продукты для компаний в сферах логистики, медицины, образования,
            ритейла и городских сервисов. Каждый кейс — это измеримый результат и устойчивое решение.
          </p>
        </div>
      </section>

      <section className={styles.gallery}>
        <div className="container">
          <div className={styles.filters} role="tablist" aria-label="Фильтр портфолио">
            {filters.map((filter) => (
              <button
                key={filter}
                type="button"
                role="tab"
                aria-selected={activeFilter === filter}
                className={`${styles.filterButton} ${
                  activeFilter === filter ? styles.active : ''
                }`}
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={styles.grid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.card}>
                <div className={styles.imageWrapper}>
                  <img
                    src={project.image}
                    alt={`Проект ${project.title} для сектора ${project.sector}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.content}>
                  <span className={styles.category}>{project.category}</span>
                  <h2>{project.title}</h2>
                  <span className={styles.sector}>{project.sector}</span>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Portfolio;