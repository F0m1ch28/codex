import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const Home = () => {
  const statsData = useMemo(
    () => [
      { label: 'Успешных проектов', value: 120 },
      { label: 'Экспертов в команде', value: 85 },
      { label: 'Лет на рынке', value: 12 },
      { label: 'Довольных клиентов', value: 60 }
    ],
    []
  );

  const services = useMemo(
    () => [
      {
        title: 'Разработка цифровых платформ',
        description:
          'Создаём масштабируемые веб-платформы и SaaS-решения с архитектурой, готовой к росту.',
        icon: '💡'
      },
      {
        title: 'Мобильные приложения',
        description:
          'Проектируем нативные и кроссплатформенные приложения с фокусом на пользовательский опыт.',
        icon: '📱'
      },
      {
        title: 'Корпоративные системы',
        description:
          'Интегрируем ERP, CRM и BI-инструменты в экосистему компании, ускоряя бизнес-процессы.',
        icon: '🏢'
      },
      {
        title: 'Сопровождение и DevOps',
        description:
          'Обеспечиваем надежную инфраструктуру, CI/CD и мониторинг для бесперебойной работы сервисов.',
        icon: '⚙️'
      }
    ],
    []
  );

  const advantages = useMemo(
    () => [
      {
        title: 'Глубокая экспертиза',
        description: 'Команда сертифицированных аналитиков, архитекторов и инженеров.'
      },
      {
        title: 'Прозрачные процессы',
        description: 'Гибкая методология и понятная коммуникация на каждом этапе.'
      },
      {
        title: 'Фокус на результате',
        description: 'Доставка продукта, который решает задачи и приносит измеримую пользу.'
      }
    ],
    []
  );

  const techStack = useMemo(
    () => [
      'React', 'TypeScript', 'Node.js', 'Python', 'Django', 'GraphQL', 'Kubernetes', 'Docker',
      'AWS', 'PostgreSQL', 'MongoDB', 'Figma'
    ],
    []
  );

  const process = useMemo(
    () => [
      {
        step: '01',
        title: 'Исследование и стратегия',
        description: 'Проводим интервью, формируем гипотезы и план цифровой трансформации.'
      },
      {
        step: '02',
        title: 'Проектирование решения',
        description: 'Создаём пользовательские сценарии, архитектуру и дизайн продукта.'
      },
      {
        step: '03',
        title: 'Разработка и интеграция',
        description: 'Реализуем функционал, проводим тестирование и подключаем сторонние сервисы.'
      },
      {
        step: '04',
        title: 'Запуск и поддержка',
        description: 'Обеспечиваем релиз, обучение команды и техническое сопровождение.'
      }
    ],
    []
  );

  const clients = useMemo(
    () => ['InnovaTech', 'DigitalCore', 'SmartCity Lab', 'FutureRetail', 'MedTech Group', 'EduNext'],
    []
  );

  const testimonials = useMemo(
    () => [
      {
        quote:
          'ТехноИнновации разработали для нас платформу аналитики, которая объединила разрозненные данные и сократила подготовку отчетов вдвое.',
        name: 'Антон Воробьёв',
        role: 'Руководитель цифровых проектов, FutureRetail'
      },
      {
        quote:
          'Команда показала высокий уровень вовлеченности, предлагала идеи и помогла трансформировать нашу внутреннюю экосистему.',
        name: 'Екатерина Кузнецова',
        role: 'Директор по развитию, SmartCity Lab'
      },
      {
        quote:
          'Мы ценим гибкость и техническую экспертизу. Решение, внедрённое ТехноИнновациями, стало ключевым продуктом в портфеле.',
        name: 'Михаил Громов',
        role: 'CEO, InnovaTech'
      }
    ],
    []
  );

  const team = useMemo(
    () => [
      {
        name: 'Марина Орлова',
        position: 'Руководитель проектов',
        bio: '15 лет в управлении проектами и запуске цифровых сервисов.',
        image: 'https://picsum.photos/400/400?random=31'
      },
      {
        name: 'Илья Котов',
        position: 'Технический директор',
        bio: 'Эксперт по архитектуре и высоконагруженным системам.',
        image: 'https://picsum.photos/400/400?random=32'
      },
      {
        name: 'Анна Сергеева',
        position: 'UX-стратег',
        bio: 'Создаёт архитектуру пользовательских впечатлений и бизнес-ценность.',
        image: 'https://picsum.photos/400/400?random=33'
      },
      {
        name: 'Павел Смирнов',
        position: 'Лид разработчик',
        bio: 'Объединяет команды фронтенда и бэкенда в единый поток.',
        image: 'https://picsum.photos/400/400?random=34'
      }
    ],
    []
  );

  const projects = useMemo(
    () => [
      {
        title: 'Платформа цифровой логистики',
        category: 'Корпоративные системы',
        description:
          'Интеллектуальная платформа распределения заказов с интеграцией IoT-датчиков и прогнозной аналитикой.',
        image: 'https://picsum.photos/1200/800?random=41'
      },
      {
        title: 'Мобильное приложение для телемедицины',
        category: 'Мобильные приложения',
        description:
          'Решение для консультаций, мониторинга показателей и взаимодействия врачей с пациентами.',
        image: 'https://picsum.photos/1200/800?random=42'
      },
      {
        title: 'Data-driven платформа ритейла',
        category: 'Цифровые платформы',
        description:
          'SaaS для управления ассортиментом, прогнозирования спроса и автоматизации закупок.',
        image: 'https://picsum.photos/1200/800?random=43'
      },
      {
        title: 'Портал цифрового образования',
        category: 'Цифровые платформы',
        description:
          'Интерактивные курсы, адаптивные сценарии обучения и аналитика вовлеченности студентов.',
        image: 'https://picsum.photos/1200/800?random=44'
      }
    ],
    []
  );

  const faqList = useMemo(
    () => [
      {
        question: 'Как начинается сотрудничество?',
        answer:
          'Мы начинаем с консультации и проектной сессии, чтобы зафиксировать цели и ожидания, определить ключевые метрики и предложить стратегию.'
      },
      {
        question: 'Какие методологии вы используете?',
        answer:
          'Для разработки применяем Agile-подходы: Scrum или Kanban в зависимости от масштаба. Для исследований и дизайна используем Double Diamond.'
      },
      {
        question: 'Как организована поддержка?',
        answer:
          'После запуска продукта мы предоставляем SLA, мониторинг, регулярные обновления и выделенную команду для оперативного реагирования.'
      }
    ],
    []
  );

  const blogPosts = useMemo(
    () => [
      {
        title: 'Как подготовиться к цифровой трансформации компании',
        excerpt:
          'Разбираем ключевые этапы, метрики успеха и то, как построить команду изменений внутри организации.',
        date: '12 марта 2024',
        image: 'https://picsum.photos/800/600?random=21'
      },
      {
        title: 'Оптимизация DevOps-процессов в распределённых командах',
       excerpt:
          'Практические рекомендации, как настроить CI/CD, систему мониторинга и культуру DevOps в распределённых командах.',
        date: '29 февраля 2024',
        image: 'https://picsum.photos/800/600?random=22'
      },
      {
        title: 'UX-инструменты, которые повышают конверсию',
        excerpt:
          'Подборка практик и методик, которые помогают создавать удобные цифровые продукты и повышать показатели вовлеченности.',
        date: '15 февраля 2024',
        image: 'https://picsum.photos/800/600?random=23'
      }
    ],
    []
  );

  const [statValues, setStatValues] = useState(statsData.map(() => 0));
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [activeProjectCategory, setActiveProjectCategory] = useState('Все');
  const [faqOpenIndex, setFaqOpenIndex] = useState(null);
  const [heroLoaded, setHeroLoaded] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formErrors, setFormErrors] = useState({});
  const [formStatus, setFormStatus] = useState('');

  useEffect(() => {
    const start = performance.now();
    const duration = 1500;
    let animationFrameId;

    const animate = (time) => {
      const elapsed = time - start;
      const progress = Math.min(elapsed / duration, 1);
      const updated = statsData.map((item) =>
        Math.floor(item.value * progress)
      );
      setStatValues(updated);
      if (progress < 1) {
        animationFrameId = requestAnimationFrame(animate);
      }
    };

    animationFrameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrameId);
  }, [statsData]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [testimonials.length]);

  const filteredProjects =
    activeProjectCategory === 'Все'
      ? projects
      : projects.filter((proj) => proj.category === activeProjectCategory);

  const handleFaqToggle = (index) => {
    setFaqOpenIndex((prev) => (prev === index ? null : index));
  };

  const handleFormChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = 'Введите имя';
    }
    if (!formData.email.trim()) {
      errors.email = 'Введите email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Укажите корректный email';
    }
    if (!formData.message.trim()) {
      errors.message = 'Напишите кратко о задаче';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    setFormStatus('');
    if (!validateForm()) {
      return;
    }
    setTimeout(() => {
      setFormStatus('Спасибо! Мы свяжемся с вами в течение рабочего дня.');
      setFormData({ name: '', email: '', message: '' });
    }, 600);
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>ТехноИнновации — цифровые решения и разработка ПО</title>
        <meta
          name="description"
          content="ТехноИнновации разрабатывает программное обеспечение, цифровые платформы и мобильные приложения. Помогаем компаниям из Москвы и всей России ускорять цифровую трансформацию."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroContent}>
            <span className="badge">IT-компания из Москвы</span>
            <h1 className={styles.heroTitle}>
              Комплексные{' '}
              <span className={styles.highlight}>IT-решения</span> для цифровой
              трансформации вашего бизнеса
            </h1>
            <p className={styles.heroSubtitle}>
              Создаём программные продукты, которые ускоряют процессы, помогают
              принимать решения на основе данных и создают новые цифровые сервисы.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className="btnPrimary">
                Обсудить проект
              </Link>
              <Link to="/portfolio" className="btnSecondary">
                Смотреть кейсы
              </Link>
            </div>
            <div className={styles.heroStats}>
              {statsData.map((item, index) => (
                <div key={item.label} className={styles.heroStatCard}>
                  <span className={styles.heroStatValue}>
                    {statValues[index]}+
                  </span>
                  <span className={styles.heroStatLabel}>{item.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className={styles.heroMedia}>
            <div className={styles.heroImageWrapper}>
              <img
                src="https://picsum.photos/1600/900?random=11"
                alt="Команда ТехноИнновации работает над цифровым проектом"
                className={`${styles.heroImage} ${heroLoaded ? styles.heroImageVisible : ''}`}
                onLoad={() => setHeroLoaded(true)}
                loading="lazy"
              />
            </div>
            <div className={styles.heroBadgeCard}>
              <span>ISO 9001</span>
              <p>Система менеджмента качества</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className="sectionHeading">
            <h2 className="sectionTitle">Наши ключевые услуги</h2>
            <p className="sectionSubtitle">
              Покрываем полный цикл разработки и внедрения программного обеспечения — от идеи до поддержки.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {services.map((service) => (
              <article className={styles.serviceCard} key={service.title}>
                <div className={styles.serviceIcon}>{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className={styles.serviceLink}>
                  Подробнее
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantages}>
        <div className="container">
          <div className={styles.advantagesInner}>
            <div className={styles.advantagesContent}>
              <h2 className="sectionTitle">Почему выбирают ТехноИнновации</h2>
              <p className="sectionSubtitle">
                Мы объединяем стратегию, дизайн и инженерию, чтобы создавать решения, которые масштабируются вместе с вашим бизнесом.
              </p>
            </div>
            <div className={styles.advantagesList}>
              {advantages.map((item) => (
                <div key={item.title} className={styles.advantageCard}>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.techStack}>
        <div className="container">
          <h2 className="sectionTitle">Технологический стек</h2>
          <p className="sectionSubtitle">
            Используем проверенные технологии и современные инструменты, чтобы создавать устойчивые и безопасные решения.
          </p>
          <div className={styles.techGrid}>
            {techStack.map((tech) => (
              <span key={tech} className={styles.techItem}>
                {tech}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <h2 className="sectionTitle">Процесс сотрудничества</h2>
          <div className={styles.processGrid}>
            {process.map((item) => (
              <div key={item.step} className={styles.processCard}>
                <span className={styles.processStep}>{item.step}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.clients}>
        <div className="container">
          <div className={styles.clientsInner}>
            <div>
              <h2 className="sectionTitle">Нам доверяют</h2>
              <p className="sectionSubtitle">
                Мы строим долгосрочные партнёрства и помогаем лидерам отрасли внедрять инновации.
              </p>
            </div>
            <div className={styles.clientsLogos}>
              {clients.map((client) => (
                <span key={client} className={styles.clientLogo} aria-label={`Партнер ${client}`}>
                  {client}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={styles.testimonials}>
        <div className="container">
          <div className="sectionHeading">
            <h2 className="sectionTitle">Отзывы клиентов</h2>
            <p className="sectionSubtitle">
              Мы ценим доверие и строим сотрудничество на прозрачности, скорости и результате.
            </p>
          </div>
          <div className={styles.testimonialWrapper} aria-live="polite">
            <div className={styles.testimonialCard}>
              <p className={styles.quote}>
                “{testimonials[currentTestimonial].quote}”
              </p>
              <div className={styles.testimonialAuthor}>
                <span>{testimonials[currentTestimonial].name}</span>
                <span className={styles.testimonialRole}>
                  {testimonials[currentTestimonial].role}
                </span>
              </div>
            </div>
          </div>
          <div className={styles.testimonialDots} role="tablist" aria-label="Переключение отзывов">
            {testimonials.map((_, index) => (
              <button
                key={index}
                type="button"
                aria-label={`Показать отзыв ${index + 1}`}
                className={`${styles.testimonialDot} ${
                  currentTestimonial === index ? styles.activeDot : ''
                }`}
                onClick={() => setCurrentTestimonial(index)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className="sectionHeading">
            <h2 className="sectionTitle">Команда лидеров изменений</h2>
            <p className="sectionSubtitle">
              Объединяем компетенции аналитики, дизайна, разработки и сопровождения.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img
                    src={member.image}
                    alt={`${member.name} — ${member.position}`}
                    loading="lazy"
                  />
                  <div className={styles.teamOverlay}>
                    <p>{member.bio}</p>
                  </div>
                </div>
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.position}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className="sectionHeading">
            <h2 className="sectionTitle">Избранные проекты</h2>
            <p className="sectionSubtitle">
              Создаём решения, в которых сочетаются надёжная архитектура, удобство и измеримый эффект.
            </p>
          </div>
          <div className={styles.projectFilters} role="tablist" aria-label="Фильтр проектов">
            {['Все', 'Цифровые платформы', 'Мобильные приложения', 'Корпоративные системы'].map(
              (category) => (
                <button
                  key={category}
                  type="button"
                  className={`${styles.filterButton} ${
                    activeProjectCategory === category ? styles.filterButtonActive : ''
                  }`}
                  onClick={() => setActiveProjectCategory(category)}
                  role="tab"
                  aria-selected={activeProjectCategory === category}
                >
                  {category}
                </button>
              )
            )}
          </div>
          <div className={styles.projectGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img
                    src={project.image}
                    alt={`Проект: ${project.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/portfolio" className={styles.projectLink}>
                    Изучить кейс
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className="sectionHeading">
            <h2 className="sectionTitle">Частые вопросы</h2>
            <p className="sectionSubtitle">
              Ответы на вопросы, с которых начинается наше сотрудничество.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqList.map((item, index) => {
              const isOpen = faqOpenIndex === index;
              return (
                <div key={item.question} className={styles.faqItem}>
                  <button
                    type="button"
                    className={styles.faqButton}
                    onClick={() => handleFaqToggle(index)}
                    aria-expanded={isOpen}
                  >
                    <span>{item.question}</span>
                    <span className={styles.faqToggle}>{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && <p className={styles.faqContent}>{item.answer}</p>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className="sectionHeading">
            <h2 className="sectionTitle">Экспертиза и инсайты</h2>
            <p className="sectionSubtitle">
              Делимся опытом цифровой трансформации, разработки и построения продуктовых команд.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImageWrapper}>
                  <img
                    src={post.image}
                    alt={`Статья: ${post.title}`}
                    loading="lazy"
                  />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/about" className={styles.blogLink}>
                    Читать больше
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaInner}>
            <div>
              <h2>Готовы к следующему шагу в цифровой трансформации?</h2>
              <p>
                Обсудим вашу идею, составим дорожную карту и сформируем команду под задачу.
              </p>
            </div>
            <div className={styles.ctaActions}>
              <Link to="/contact" className="btnPrimary">
                Назначить встречу
              </Link>
              <Link to="/services" className="btnSecondary">
                Посмотреть услуги
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.contactFormSection}>
        <div className="container">
          <div className={styles.contactCard}>
            <div className={styles.contactInfo}>
              <h2 className="sectionTitle">Расскажите о проекте</h2>
              <p className="sectionSubtitle">
                Присылайте бриф или краткое описание задачи — мы подготовим предложение и согласуем план действий.
              </p>
              <ul className={styles.contactDetails}>
                <li>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@technoinnovations.ru">info@technoinnovations.ru</a>
                </li>
                <li>
                  <strong>Телефон:</strong>{' '}
                  <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  <strong>Адрес:</strong> г. Москва, ул. Ленинградский проспект, д. 39, стр. 14
                </li>
              </ul>
            </div>
            <form
              className={styles.contactForm}
              onSubmit={handleFormSubmit}
              noValidate
            >
              <label className={styles.field}>
                <span>Имя</span>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleFormChange}
                  placeholder="Ваше имя"
                  aria-invalid={!!formErrors.name}
                  aria-describedby={formErrors.name ? 'home-name-error' : undefined}
                />
                {formErrors.name && (
                  <span className={styles.error} id="home-name-error">
                    {formErrors.name}
                  </span>
                )}
              </label>
              <label className={styles.field}>
                <span>Email</span>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleFormChange}
                  placeholder="name@company.ru"
                  aria-invalid={!!formErrors.email}
                  aria-describedby={formErrors.email ? 'home-email-error' : undefined}
                />
                {formErrors.email && (
                  <span className={styles.error} id="home-email-error">
                    {formErrors.email}
                  </span>
                )}
              </label>
              <label className={styles.field}>
                <span>Сообщение</span>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleFormChange}
                  placeholder="Кратко опишите задачу или проект"
                  rows="4"
                  aria-invalid={!!formErrors.message}
                  aria-describedby={formErrors.message ? 'home-message-error' : undefined}
                />
                {formErrors.message && (
                  <span className={styles.error} id="home-message-error">
                    {formErrors.message}
                  </span>
                )}
              </label>
              <button type="submit" className="btnPrimary">
                Отправить заявку
              </button>
              {formStatus && (
                <p className={styles.success} role="status">
                  {formStatus}
                </p>
              )}
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;