import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './CookiePolicy.module.css';

const CookiePolicy = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Политика использования cookies — ТехноИнновации</title>
      <meta
        name="description"
        content="Политика использования файлов cookie компании ТехноИнновации. Узнайте, какие файлы cookie мы применяем и для чего."
      />
    </Helmet>

    <div className="container">
      <h1>Политика использования cookies</h1>
      <p>Дата обновления: 1 марта 2024 года</p>

      <section>
        <h2>1. Что такое cookies</h2>
        <p>
          Cookies — это небольшие файлы, которые сохраняются на устройстве пользователя при
          посещении сайта. Они помогают улучшить работу сайта и анализировать взаимодействие.
        </p>
      </section>

      <section>
        <h2>2. Какие cookies мы используем</h2>
        <p>
          Функциональные cookies обеспечивают корректную работу сайта. Аналитические cookies
          помогают понимать, как посетители взаимодействуют с контентом.
        </p>
      </section>

      <section>
        <h2>3. Управление cookies</h2>
        <p>
          Вы можете настроить использование cookies через параметры браузера. Ограничение файлов
          cookie может повлиять на функциональность сайта.
        </p>
      </section>

      <section>
        <h2>4. Обратная связь</h2>
        <p>
          Если у вас есть вопросы о политике cookies, напишите нам на info@technoinnovations.ru.
        </p>
      </section>
    </div>
  </div>
);

export default CookiePolicy;