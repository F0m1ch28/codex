import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setVisible(false);
  };

  const declineCookies = () => {
    localStorage.setItem('cookieConsent', 'declined');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div
      className={styles.banner}
      role="dialog"
      aria-live="assertive"
      aria-label="Информация об использовании файлов cookie"
    >
      <p className={styles.text}>
        Мы используем файлы cookie для улучшения работы сайта и анализа взаимодействия.
        Продолжая пользоваться сайтом, вы принимаете Политику использования cookies.
      </p>
      <div className={styles.actions}>
        <button type="button" className="btnSecondary" onClick={declineCookies}>
          Отклонить
        </button>
        <button type="button" className="btnPrimary" onClick={acceptCookies}>
          Принять
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;