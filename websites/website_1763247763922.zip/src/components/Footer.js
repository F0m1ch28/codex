import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer} aria-labelledby="footer-heading">
    <div className="container">
      <div className={styles.top}>
        <div className={styles.brand}>
          <span className={styles.logo}>TI</span>
          <div>
            <h2 className={styles.name} id="footer-heading">
              ТехноИнновации
            </h2>
            <p className={styles.tagline}>
              Цифровые решения и программные продукты для ускорения бизнеса.
            </p>
          </div>
        </div>
        <div className={styles.linksGrid}>
          <div>
            <h3 className={styles.columnTitle}>Компания</h3>
            <ul className={styles.linkList}>
              <li>
                <Link to="/about">О компании</Link>
              </li>
              <li>
                <Link to="/services">Услуги</Link>
              </li>
              <li>
                <Link to="/portfolio">Портфолио</Link>
              </li>
              <li>
                <Link to="/technologies">Технологии</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Документы</h3>
            <ul className={styles.linkList}>
              <li>
                <Link to="/terms">Условия использования</Link>
              </li>
              <li>
                <Link to="/privacy">Политика конфиденциальности</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Cookies</Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className={styles.columnTitle}>Контакты</h3>
            <ul className={styles.linkList}>
              <li>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>
                <a href="mailto:info@technoinnovations.ru">
                  info@technoinnovations.ru
                </a>
              </li>
              <li>
                г. Москва, ул. Ленинградский проспект, д. 39, стр. 14
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <p>© {new Date().getFullYear()} ТехноИнновации. Все права защищены.</p>
        <div className={styles.socials} aria-label="Социальные сети">
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noreferrer"
            aria-label="LinkedIn ТехноИнновации"
          >
            LinkedIn
          </a>
          <a
            href="https://t.me"
            target="_blank"
            rel="noreferrer"
            aria-label="Telegram ТехноИнновации"
          >
            Telegram
          </a>
          <a
            href="https://vk.com"
            target="_blank"
            rel="noreferrer"
            aria-label="VK ТехноИнновации"
          >
            VK
          </a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;