import React, { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 32);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setMobileOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setMobileOpen(false);
  };

  const navLinkClass = ({ isActive }) =>
    `${styles.navLink} ${isActive ? styles.active : ''}`;

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          <Link
            to="/"
            className={styles.logo}
            aria-label="Главная страница ТехноИнновации"
            onClick={closeMenu}
          >
            <span className={styles.logoMark}>TI</span>
            <span className={styles.logoText}>ТехноИнновации</span>
          </Link>
          <button
            type="button"
            className={styles.menuButton}
            aria-controls="primary-navigation"
            aria-expanded={mobileOpen}
            onClick={toggleMenu}
          >
            <span className={styles.menuIcon} />
          </button>
          <nav
            id="primary-navigation"
            className={`${styles.nav} ${mobileOpen ? styles.open : ''}`}
            aria-label="Основная навигация сайта"
          >
            <NavLink to="/" className={navLinkClass} onClick={closeMenu}>
              Главная
            </NavLink>
            <NavLink to="/services" className={navLinkClass} onClick={closeMenu}>
              Услуги
            </NavLink>
            <NavLink
              to="/technologies"
              className={navLinkClass}
              onClick={closeMenu}
            >
              Технологии
            </NavLink>
            <NavLink
              to="/portfolio"
              className={navLinkClass}
              onClick={closeMenu}
            >
              Портфолио
            </NavLink>
            <NavLink to="/about" className={navLinkClass} onClick={closeMenu}>
              О компании
            </NavLink>
            <NavLink to="/contact" className={styles.ctaLink} onClick={closeMenu}>
              Связаться
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;