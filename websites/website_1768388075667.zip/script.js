document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
        });

        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu.classList.contains('active')) {
                    navMenu.classList.remove('active');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const cookieChoices = document.querySelectorAll('.cookie-choice');
    if (cookieBanner && cookieChoices.length) {
        const storedChoice = localStorage.getItem('facsimpbmeCookieChoice');
        if (storedChoice) {
            cookieBanner.classList.add('hidden');
        }
        cookieChoices.forEach(choice => {
            choice.addEventListener('click', () => {
                const value = choice.dataset.choice || 'undecided';
                localStorage.setItem('facsimpbmeCookieChoice', value);
                cookieBanner.classList.add('hidden');
            });
        });
    }

    const filterButtons = document.querySelectorAll('.filter-button');
    const postCards = document.querySelectorAll('[data-category]');
    const searchField = document.getElementById('postsSearch');

    const applyFilters = () => {
        const activeButton = document.querySelector('.filter-button.active');
        const activeCategory = activeButton ? activeButton.dataset.filter : 'all';
        const searchTerm = searchField ? searchField.value.trim().toLowerCase() : '';

        postCards.forEach(card => {
            const cardCategory = card.dataset.category;
            const title = card.querySelector('h3') ? card.querySelector('h3').textContent.toLowerCase() : '';
            const summary = card.querySelector('p') ? card.querySelector('p').textContent.toLowerCase() : '';

            const matchesCategory = activeCategory === 'all' || cardCategory === activeCategory;
            const matchesSearch = title.includes(searchTerm) || summary.includes(searchTerm);

            if (matchesCategory && matchesSearch) {
                card.classList.remove('hidden');
                card.style.display = '';
            } else {
                card.classList.add('hidden');
                card.style.display = 'none';
            }
        });
    };

    if (filterButtons.length) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                applyFilters();
            });
        });
    }

    if (searchField) {
        searchField.addEventListener('input', () => {
            applyFilters();
        });
    }
});