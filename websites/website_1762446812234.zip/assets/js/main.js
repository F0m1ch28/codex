document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.getElementById('primary-navigation');
  const scrollBtn = document.getElementById('scrollTopBtn');
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptCookiesBtn = document.getElementById('accept-cookies');
  const contactForm = document.getElementById('contact-form');
  const currentYearSpans = document.querySelectorAll('.current-year');

  if (currentYearSpans.length) {
    const year = new Date().getFullYear();
    currentYearSpans.forEach(span => {
      span.textContent = year;
    });
  }

  const closeNav = () => {
    if (navToggle && primaryNav) {
      navToggle.setAttribute('aria-expanded', 'false');
      primaryNav.classList.remove('open');
    }
  };

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('open');
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        closeNav();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });

    document.addEventListener('keyup', (event) => {
      if (event.key === 'Escape') {
        closeNav();
      }
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) {
        closeNav();
      }
    });
  }

  if (scrollBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 320) {
        scrollBtn.classList.add('show');
      } else {
        scrollBtn.classList.remove('show');
      }
    });

    scrollBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  if (cookieBanner) {
    const consent = localStorage.getItem('pls_cookie_consent');
    if (consent === 'accepted') {
      cookieBanner.classList.add('hidden');
    } else {
      cookieBanner.classList.add('show');
    }

    if (acceptCookiesBtn) {
      acceptCookiesBtn.addEventListener('click', () => {
        localStorage.setItem('pls_cookie_consent', 'accepted');
        cookieBanner.classList.remove('show');
        cookieBanner.classList.add('hidden');
      });
    }
  }

  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const status = contactForm.querySelector('.form-status');
      if (status) {
        status.textContent = 'Thank you for reaching out. A member of our advisory team will respond within one business day.';
      }
      contactForm.reset();
    });
  }
});