import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem("eipr-cookie-consent");
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("eipr-cookie-consent", "accepted");
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <p className={styles.text}>
        Le site utilise des cookies techniques pour garantir une navigation
        optimale et des mesures d’audience internes. Pour en savoir plus, la
        politique dédiée est disponible{" "}
        <Link to="/politique-de-cookies">sur cette page</Link>.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Accepter
      </button>
    </div>
  );
};

export default CookieBanner;