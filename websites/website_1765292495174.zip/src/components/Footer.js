import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer} aria-label="Pied de page">
      <div className={styles.grid}>
        <div>
          <h3 className={styles.title}>Education in Paris Review</h3>
          <p className={styles.description}>
            Revue de recherche dédiée à l&apos;analyse des structures,
            dynamiques et innovations du paysage éducatif parisien. Les enquêtes
            croisent données, terrain et regards disciplinaires pour documenter
            l&apos;évolution du système.
          </p>
        </div>
        <div>
          <h4 className={styles.sectionTitle}>Navigation</h4>
          <ul className={styles.list}>
            <li>
              <NavLink to="/">Accueil</NavLink>
            </li>
            <li>
              <NavLink to="/a-propos">À propos</NavLink>
            </li>
            <li>
              <NavLink to="/themes-recherche">Thèmes de recherche</NavLink>
            </li>
            <li>
              <NavLink to="/archives">Archives</NavLink>
            </li>
            <li>
              <NavLink to="/equipe">Équipe</NavLink>
            </li>
            <li>
              <NavLink to="/contact">Contact</NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.sectionTitle}>Informations</h4>
          <ul className={styles.list}>
            <li>
              <NavLink to="/conditions-generales">
                Conditions générales
              </NavLink>
            </li>
            <li>
              <NavLink to="/politique-de-confidentialite">
                Politique de confidentialité
              </NavLink>
            </li>
            <li>
              <NavLink to="/politique-de-cookies">
                Politique de cookies
              </NavLink>
            </li>
          </ul>
        </div>
        <div>
          <h4 className={styles.sectionTitle}>Rédaction</h4>
          <address className={styles.address}>
            Paris, France
            <br />
            <a href="mailto:redaction@education-paris-review.fr">
              redaction@education-paris-review.fr
            </a>
            <br />
            <a href="tel:+33100000000">+33 (0)1 XX XX XX XX</a>
          </address>
        </div>
      </div>
      <p className={styles.copy}>
        © {new Date().getFullYear()} Education in Paris Review. Tous droits
        réservés.
      </p>
    </footer>
  );
};

export default Footer;