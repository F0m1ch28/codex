import { useEffect } from "react";

const MetaTags = ({ title, description, keywords }) => {
  useEffect(() => {
    if (title) {
      document.title = title;
      updateMetaTag("property", "og:title", title);
    }
    if (description) {
      updateMetaTag("name", "description", description);
      updateMetaTag("property", "og:description", description);
    }
    if (keywords) {
      updateMetaTag("name", "keywords", keywords);
    }
  }, [title, description, keywords]);

  const updateMetaTag = (attribute, key, value) => {
    if (!value) return;
    let meta = document.querySelector(`meta[${attribute}='${key}']`);
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute(attribute, key);
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", value);
  };

  return null;
};

export default MetaTags;