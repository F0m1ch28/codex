import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import MetaTags from "../components/MetaTags";
import { articles } from "../data/articles";
import styles from "./ArticlesPage.module.css";

const ArticlesPage = () => {
  const categories = useMemo(() => {
    const unique = Array.from(new Set(articles.map((item) => item.category)));
    return ["Toutes les catégories", ...unique];
  }, []);

  const [activeCategory, setActiveCategory] = useState(categories[0]);

  const filteredArticles = useMemo(() => {
    if (activeCategory === "Toutes les catégories") {
      return articles;
    }
    return articles.filter(
      (article) => article.category === activeCategory
    );
  }, [activeCategory]);

  return (
    <>
      <MetaTags
        title="Archives — Education in Paris Review"
        description="Accès aux articles, enquêtes et entretiens publiés par Education in Paris Review."
        keywords="archives, articles éducation, enquêtes Paris"
      />
      <article className={styles.page}>
        <header className={styles.header}>
          <h1>Archives des analyses</h1>
          <p>
            Les archives rassemblent les dossiers publiés depuis la création de
            la revue. Chaque article comprend une introduction, un développement
            détaillé et une conclusion neutre.
          </p>
        </header>

        <div className={styles.filters} role="group" aria-label="Filtrer par catégorie">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => setActiveCategory(category)}
              className={`${styles.filterButton} ${
                activeCategory === category ? styles.active : ""
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <section className={styles.grid} aria-label="Liste des articles archivés">
          {filteredArticles.map((article) => (
            <article key={article.id} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={article.image} alt={article.imageAlt} loading="lazy" />
              </div>
              <div className={styles.cardContent}>
                <span className={styles.category}>{article.category}</span>
                <h2>{article.title}</h2>
                <p>{article.subtitle}</p>
                <p className={styles.date}>
                  Publié le{" "}
                  {new Date(article.publishedAt).toLocaleDateString("fr-FR", {
                    year: "numeric",
                    month: "long",
                    day: "numeric"
                  })}
                </p>
                <Link to={`/article/${article.slug}`} className={styles.link}>
                  Consulter l&apos;article
                </Link>
              </div>
            </article>
          ))}
        </section>
      </article>
    </>
  );
};

export default ArticlesPage;