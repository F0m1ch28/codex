import React from "react";
import { Link } from "react-router-dom";
import MetaTags from "../components/MetaTags";
import styles from "./NotFoundPage.module.css";

const NotFoundPage = () => {
  return (
    <>
      <MetaTags
        title="Page indisponible — Education in Paris Review"
        description="La page recherchée est introuvable. Consultez le plan du site pour poursuivre votre navigation."
        keywords="404, page non trouvée"
      />
      <section className={styles.page}>
        <h1>Page non trouvée</h1>
        <p>
          La ressource demandée n’existe pas ou a été déplacée. Pour poursuivre
          votre navigation, rendez-vous sur la page{" "}
          <Link to="/">d’accueil</Link> ou consultez les{" "}
          <Link to="/archives">archives</Link>.
        </p>
      </section>
    </>
  );
};

export default NotFoundPage;