import React from "react";
import { Link, useParams } from "react-router-dom";
import MetaTags from "../components/MetaTags";
import { articles } from "../data/articles";
import styles from "./ArticlePage.module.css";

const ArticlePage = () => {
  const { slug } = useParams();
  const article = articles.find((item) => item.slug === slug);

  if (!article) {
    return (
      <section className={styles.notFound}>
        <p>
          L’article recherché n’existe pas dans les archives. Rendez-vous sur la
          page <Link to="/archives">Archives</Link> pour consulter les analyses
          disponibles.
        </p>
      </section>
    );
  }

  const publicationDate = new Date(article.publishedAt).toLocaleDateString(
    "fr-FR",
    { year: "numeric", month: "long", day: "numeric" }
  );

  return (
    <>
      <MetaTags
        title={`${article.title} — Education in Paris Review`}
        description={article.subtitle}
        keywords={`éducation Paris, ${article.category}, analyse`}
      />
      <article className={styles.page}>
        <header className={styles.hero}>
          <div className={styles.heroImage}>
            <img src={article.image} alt={article.imageAlt} />
          </div>
          <div className={styles.heroContent}>
            <span className={styles.category}>{article.category}</span>
            <h1>{article.title}</h1>
            <p className={styles.subtitle}>{article.subtitle}</p>
            <p className={styles.date}>Publié le {publicationDate}</p>
          </div>
        </header>

        <section className={styles.body}>
          <p className={styles.introduction}>{article.introduction}</p>
          {article.body.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
          <p className={styles.conclusion}>{article.conclusion}</p>
        </section>

        <aside className={styles.backlink}>
          <Link to="/archives">Retour aux archives</Link>
        </aside>
      </article>
    </>
  );
};

export default ArticlePage;