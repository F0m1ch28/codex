import React, { useState } from "react";
import MetaTags from "../components/MetaTags";
import styles from "./ContactPage.module.css";

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    organisation: "",
    subject: "",
    message: ""
  });
  const [status, setStatus] = useState("");

  const handleChange = (event) => {
    setFormData((current) => ({
      ...current,
      [event.target.name]: event.target.value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (
      !formData.name.trim() ||
      !formData.email.trim() ||
      !formData.subject.trim() ||
      !formData.message.trim()
    ) {
      setStatus("Merci de remplir l’ensemble des champs requis.");
      return;
    }
    const emailRegex =
      /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
    if (!emailRegex.test(formData.email)) {
      setStatus(
        "L’adresse électronique indiquée ne correspond pas au format attendu."
      );
      return;
    }
    setStatus(
      "Le message a été pris en compte. La rédaction répondra dans les meilleurs délais."
    );
    setFormData({
      name: "",
      email: "",
      organisation: "",
      subject: "",
      message: ""
    });
  };

  return (
    <>
      <MetaTags
        title="Contact — Education in Paris Review"
        description="Coordonnées de la rédaction et formulaire de contact d'Education in Paris Review."
        keywords="contact, rédaction, éducation Paris"
      />
      <article className={styles.page}>
        <header className={styles.header}>
          <h1>Contact rédactionnel</h1>
          <p>
            La rédaction centralise les propositions d’enquête, demandes de
            précision et propositions de collaboration grâce au formulaire ci-dessous.
          </p>
        </header>

        <section className={styles.grid}>
          <div className={styles.card}>
            <h2>Coordonnées</h2>
            <p>Adresse : Paris, France</p>
            <p>
              Courriel :{" "}
              <a href="mailto:redaction@education-paris-review.fr">
                redaction@education-paris-review.fr
              </a>
            </p>
            <p>
              Téléphone :{" "}
              <a href="tel:+33100000000">+33 (0)1 XX XX XX XX</a>
            </p>
            <p>
              Les demandes d’interview et de partenariat sont étudiées chaque
              semaine lors de la conférence éditoriale.
            </p>
          </div>

          <form onSubmit={handleSubmit} className={styles.form}>
            <div className={styles.field}>
              <label htmlFor="name">Nom et prénom *</label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="email">Adresse électronique *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="organisation">Organisation</label>
              <input
                id="organisation"
                name="organisation"
                type="text"
                value={formData.organisation}
                onChange={handleChange}
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="subject">Objet *</label>
              <input
                id="subject"
                name="subject"
                type="text"
                value={formData.subject}
                onChange={handleChange}
                required
              />
            </div>
            <div className={styles.field}>
              <label htmlFor="message">Message détaillé *</label>
              <textarea
                id="message"
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                required
              />
            </div>
            <button type="submit">Transmettre le message</button>
            {status && <p className={styles.status}>{status}</p>}
          </form>
        </section>
      </article>
    </>
  );
};

export default ContactPage;