import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import MetaTags from "../components/MetaTags";
import { articles } from "../data/articles";
import { topics } from "../data/topics";
import { teamMembers } from "../data/team";
import styles from "./HomePage.module.css";

const statsConfig = [
  { label: "Études de cas documentées", target: 36 },
  { label: "Entretiens menés en 2024", target: 128 },
  { label: "Arrondissements analysés", target: 20 }
];

const HomePage = () => {
  const [stats, setStats] = useState(statsConfig.map(() => 0));
  const [email, setEmail] = useState("");
  const [newsletterStatus, setNewsletterStatus] = useState("");

  const latestArticles = useMemo(() => {
    return [...articles]
      .sort(
        (a, b) =>
          new Date(b.publishedAt).getTime() -
          new Date(a.publishedAt).getTime()
      )
      .slice(0, 3);
  }, []);

  const highlightedTopics = useMemo(() => topics.slice(0, 6), []);

  useEffect(() => {
    let raf;
    const start = performance.now();
    const duration = 1600;

    const animate = (time) => {
      const progress = Math.min((time - start) / duration, 1);
      setStats(
        statsConfig.map((item) =>
          Math.round(item.target * progress)
        )
      );
      if (progress < 1) {
        raf = requestAnimationFrame(animate);
      }
    };

    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, []);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!email.trim()) {
      setNewsletterStatus(
        "Merci d’indiquer une adresse électronique valide."
      );
      return;
    }
    const emailRegex =
      /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
    if (!emailRegex.test(email)) {
      setNewsletterStatus(
        "Le format de l’adresse électronique ne correspond pas aux standards attendus."
      );
      return;
    }
    setNewsletterStatus(
      "L’adresse a été enregistrée pour les prochaines diffusions d’analyses."
    );
    setEmail("");
  };

  return (
    <>
      <MetaTags
        title="Education in Paris Review — Analyses sur l'éducation parisienne"
        description="Revue de recherche consacrée à l'étude des établissements, des politiques et des innovations éducatives à Paris."
        keywords="éducation Paris, recherche éducative, lycées parisiens, politiques éducatives"
      />
      <article className={styles.page}>
        <section className={styles.hero}>
          <div className={styles.heroBackdrop} aria-hidden="true" />
          <div className={styles.heroContent}>
            <p className={styles.kicker}>Revue de recherche indépendante</p>
            <h1 className={styles.heroTitle}>
              Observer, contextualiser et documenter l&apos;éducation à Paris
            </h1>
            <p className={styles.heroSubtitle}>
              Education in Paris Review rassemble enquêtes de terrain,
              visualisations de données et perspectives historiques pour
              comprendre la diversité des parcours éducatifs dans la capitale.
              Les dossiers publiés s&apos;appuient sur des sources vérifiées et
              sur des collaborations avec des chercheurs, des responsables
              d&apos;établissements et des acteurs culturels.
            </p>
            <p className={styles.heroLinkSentence}>
              Les analyses récentes sont consultables dans la section{" "}
              <Link to="/archives">Archives</Link>.
            </p>
          </div>
        </section>

        <section className={styles.statsSection} aria-label="Indicateurs 2024">
          <div className={styles.sectionHeader}>
            <h2>Repères chiffrés de la veille 2024</h2>
            <p>
              Les indicateurs ci-dessous synthétisent la couverture éditoriale
              réalisée par la rédaction depuis le début de l&apos;année.
            </p>
          </div>
          <div className={styles.statsGrid}>
            {statsConfig.map((item, index) => (
              <div key={item.label} className={styles.statCard}>
                <span className={styles.statValue}>
                  {stats[index].toLocaleString("fr-FR")}
                </span>
                <span className={styles.statLabel}>{item.label}</span>
                <span className={styles.statAccent} aria-hidden="true" />
              </div>
            ))}
          </div>
        </section>

        <section className={styles.articlesSection}>
          <div className={styles.sectionHeader}>
            <h2>Dernières analyses publiées</h2>
            <p>
              Chaque article propose une lecture contextualisée des dynamiques
              éducatives parisiennes, complétée par des données et des témoignages.
            </p>
          </div>
          <div className={styles.articlesGrid}>
            {latestArticles.map((article) => (
              <article key={article.id} className={styles.articleCard}>
                <div className={styles.articleImageWrapper}>
                  <img
                    src={article.image}
                    alt={article.imageAlt}
                    loading="lazy"
                  />
                </div>
                <div className={styles.articleContent}>
                  <span className={styles.articleCategory}>
                    {article.category}
                  </span>
                  <h3>{article.title}</h3>
                  <p>{article.subtitle}</p>
                  <Link
                    to={`/article/${article.slug}`}
                    className={styles.articleLink}
                  >
                    Lire l’analyse complète
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.topicsSection}>
          <div className={styles.sectionHeader}>
            <h2>Axes de recherche prioritaire</h2>
            <p>
              Les terrains d&apos;investigation couvrent la pluralité des
              établissements, des publics et des partenariats qui composent
              l&apos;éducation parisienne.
            </p>
          </div>
          <div className={styles.topicsGrid}>
            {highlightedTopics.map((topic) => (
              <div key={topic.id} className={styles.topicCard}>
                <h3>{topic.title}</h3>
                <p>{topic.description}</p>
              </div>
            ))}
          </div>
          <p className={styles.moreTopics}>
            L’ensemble des thématiques est détaillé dans la page{" "}
            <Link to="/themes-recherche">Thèmes de recherche</Link>.
          </p>
        </section>

        <section className={styles.methodSection}>
          <div className={styles.sectionHeader}>
            <h2>Méthodologie et rigueur éditoriale</h2>
            <p>
              L&apos;équipe articule plusieurs approches pour rendre compte des
              réalités éducatives parisiennes.
            </p>
          </div>
          <div className={styles.methodGrid}>
            <div className={styles.methodCard}>
              <h3>Sources croisées</h3>
              <p>
                Rapports institutionnels, bases de données publiques, archives
                municipales et documents de travail des établissements sont
                systématiquement confrontés afin de sécuriser l’information.
              </p>
            </div>
            <div className={styles.methodCard}>
              <h3>Enquêtes qualitatives</h3>
              <p>
                Entretiens semi-directifs, observations de terrain et ateliers
                d’écoute permettent de restituer les pratiques pédagogiques au
                plus près des réalités quotidiennes.
              </p>
            </div>
            <div className={styles.methodCard}>
              <h3>Analyse collaborative</h3>
              <p>
                Les productions sont relues par un comité scientifique composé
                de chercheurs et de praticiens, garantissant la solidité des
                interprétations proposées.
              </p>
            </div>
          </div>
        </section>

        <section className={styles.quoteSection} aria-label="Citation d'expert">
          <figure className={styles.quoteFigure}>
            <blockquote>
              « Les établissements parisiens expérimentent une variété de
              dispositifs impressionnante. Ce foisonnement s&apos;accompagne
              d&apos;un besoin de mise en cohérence et de partage d&apos;outils
              d&apos;évaluation. Les travaux d&apos;Education in Paris Review
              offrent justement cette vue d&apos;ensemble. »
            </blockquote>
            <figcaption>
              Dr Claire Lenoir — Sociologue, Université Paris Nanterre
            </figcaption>
          </figure>
        </section>

        <section className={styles.teamSection}>
          <div className={styles.sectionHeader}>
            <h2>Regards croisés de la rédaction</h2>
            <p>
              La revue s&apos;appuie sur une équipe pluridisciplinaire réunissant
              journalistes, chercheurs et spécialistes des politiques éducatives.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.slice(0, 3).map((member) => (
              <article key={member.id} className={styles.teamCard}>
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={member.imageAlt} loading="lazy" />
                </div>
                <h3>{member.name}</h3>
                <p className={styles.teamRole}>{member.role}</p>
                <p className={styles.teamBio}>{member.expertise}</p>
              </article>
            ))}
          </div>
          <p className={styles.moreTeam}>
            Le profil complet de la rédaction est présenté dans la page{" "}
            <Link to="/equipe">Équipe</Link>.
          </p>
        </section>

        <section className={styles.newsletterSection}>
          <div className={styles.newsletterInner}>
            <div>
              <h2>Recevoir les mises à jour de recherche</h2>
              <p>
                Ce formulaire permet de recevoir les synthèses mensuelles des
                études publiées et les annonces de prochains dossiers thématiques.
              </p>
            </div>
            <form onSubmit={handleNewsletterSubmit} className={styles.form}>
              <label htmlFor="newsletter-email" className="sr-only">
                Adresse électronique
              </label>
              <input
                id="newsletter-email"
                type="email"
                value={email}
                placeholder="adresse@example.fr"
                onChange={(event) => setEmail(event.target.value)}
                aria-describedby="newsletter-aide"
              />
              <button type="submit">Enregistrer l’adresse</button>
              <span id="newsletter-aide" className={styles.helperText}>
                Les courriels envoyés se limitent aux synthèses éditoriales.
              </span>
              {newsletterStatus && (
                <p className={styles.status}>{newsletterStatus}</p>
              )}
            </form>
          </div>
        </section>
      </article>
    </>
  );
};

export default HomePage;