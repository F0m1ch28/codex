import React from "react";
import MetaTags from "../components/MetaTags";
import { topics } from "../data/topics";
import styles from "./TopicsPage.module.css";

const TopicsPage = () => {
  return (
    <>
      <MetaTags
        title="Thèmes de recherche — Education in Paris Review"
        description="Présentation des thématiques explorées par Education in Paris Review : établissements parisiens, inclusion, politiques éducatives et innovations."
        keywords="thèmes de recherche, éducation Paris, inclusion scolaire, politiques locales"
      />
      <article className={styles.page}>
        <header className={styles.header}>
          <h1>Thèmes de recherche</h1>
          <p>
            La rédaction explore un ensemble structuré de thématiques afin de
            rendre compte de la diversité du système éducatif parisien. Chaque
            dossier peut croiser plusieurs de ces axes selon les besoins de
            l&apos;enquête.
          </p>
        </header>
        <section className={styles.grid} aria-label="Liste des thèmes">
          {topics.map((topic) => (
            <article key={topic.id} className={styles.card}>
              <h2>{topic.title}</h2>
              <p>{topic.description}</p>
            </article>
          ))}
        </section>
      </article>
    </>
  );
};

export default TopicsPage;