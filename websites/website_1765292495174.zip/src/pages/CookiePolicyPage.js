import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./CookiePolicyPage.module.css";

const CookiePolicyPage = () => {
  return (
    <>
      <MetaTags
        title="Politique de cookies — Education in Paris Review"
        description="Information sur l'utilisation des cookies sur le site Education in Paris Review."
        keywords="cookies, politique, navigation"
      />
      <article className={styles.page}>
        <h1>Politique de cookies</h1>

        <section>
          <h2>1. Définition</h2>
          <p>
            Un cookie est un fichier texte susceptible d’être enregistré sur
            votre terminal lors de la consultation du site. Il permet de conserver
            des informations temporaires pour faciliter la navigation.
          </p>
        </section>

        <section>
          <h2>2. Cookies utilisés</h2>
          <ul>
            <li>
              Cookies techniques indispensables : ils garantissent le
              fonctionnement du site et ne peuvent être désactivés.
            </li>
            <li>
              Cookies de mesure d’audience interne : ils permettent d’analyser
              la fréquentation de manière anonyme afin d’améliorer les contenus.
            </li>
          </ul>
        </section>

        <section>
          <h2>3. Gestion des cookies</h2>
          <p>
            En poursuivant la navigation, l’utilisateur accepte l’utilisation
            des cookies décrits ci-dessus. Il peut configurer son navigateur pour
            les refuser. Dans ce cas, certaines fonctionnalités peuvent être
            altérées.
          </p>
        </section>

        <section>
          <h2>4. Durée de conservation</h2>
          <p>
            Les cookies techniques sont supprimés à la fermeture du navigateur.
            Les cookies de mesure d’audience sont conservés pour une durée
            maximale de treize mois.
          </p>
        </section>

        <section>
          <h2>5. Contact</h2>
          <p>
            Pour toute question relative aux cookies, il est possible de
            contacter la rédaction : redaction@education-paris-review.fr.
          </p>
        </section>
      </article>
    </>
  );
};

export default CookiePolicyPage;