import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./TermsOfServicePage.module.css";

const TermsOfServicePage = () => {
  return (
    <>
      <MetaTags
        title="Conditions générales d’utilisation — Education in Paris Review"
        description="Conditions générales d'utilisation du site Education in Paris Review."
        keywords="conditions générales, usage du site"
      />
      <article className={styles.page}>
        <h1>Conditions générales d’utilisation</h1>

        <section>
          <h2>1. Objet</h2>
          <p>
            Les présentes conditions générales d’utilisation définissent les
            modalités d’accès et d’usage du site Education in Paris Review. En
            consultant le site, l’utilisateur accepte les présentes dispositions.
          </p>
        </section>

        <section>
          <h2>2. Accès au contenu</h2>
          <p>
            Les articles, dossiers et ressources sont proposés à titre
            informatif. Ils ne constituent pas des recommandations officielles.
            L’accès au site est libre et gratuit. L’utilisateur s’assure de la
            compatibilité de ses équipements et logiciels.
          </p>
        </section>

        <section>
          <h2>3. Propriété intellectuelle</h2>
          <p>
            L’ensemble des contenus (textes, visuels, infographies, sons) est
            protégé par le droit de la propriété intellectuelle. Toute reprise
            doit mentionner la source et faire l’objet d’une autorisation écrite
            préalable de la rédaction.
          </p>
        </section>

        <section>
          <h2>4. Responsabilité</h2>
          <p>
            La rédaction veille à la fiabilité des informations publiées. Elle ne
            saurait être tenue responsable d’un usage inapproprié des contenus ou
            de décisions prises sans vérification complémentaire. Les liens
            hypertextes vers des sites externes n’engagent pas la responsabilité
            de la revue.
          </p>
        </section>

        <section>
          <h2>5. Contributions extérieures</h2>
          <p>
            Les propositions d’articles ou de tribunes font l’objet d’une
            évaluation par le comité éditorial. La rédaction se réserve le droit
            de refuser toute contribution ne respectant pas la charte éditoriale.
          </p>
        </section>

        <section>
          <h2>6. Modification des conditions</h2>
          <p>
            La rédaction peut mettre à jour les présentes conditions afin de
            s’adapter aux évolutions légales ou techniques. Les utilisateurs
            sont invités à les consulter régulièrement.
          </p>
        </section>
      </article>
    </>
  );
};

export default TermsOfServicePage;