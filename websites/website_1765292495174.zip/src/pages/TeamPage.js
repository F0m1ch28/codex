import React from "react";
import MetaTags from "../components/MetaTags";
import { teamMembers } from "../data/team";
import styles from "./TeamPage.module.css";

const TeamPage = () => {
  return (
    <>
      <MetaTags
        title="Équipe — Education in Paris Review"
        description="Présentation des membres de la rédaction, de leurs spécialisations et de leurs parcours professionnels."
        keywords="équipe rédactionnelle, journalistes éducation, chercheurs"
      />
      <article className={styles.page}>
        <header className={styles.header}>
          <h1>L’équipe rédactionnelle et scientifique</h1>
          <p>
            Education in Paris Review rassemble des professionnels aux
            compétences complémentaires : analyses de données, enquêtes de
            terrain, histoire de l’éducation, suivi des politiques publiques et
            production multimédia.
          </p>
        </header>
        <section className={styles.grid} aria-label="Membres de l'équipe">
          {teamMembers.map((member) => (
            <article key={member.id} className={styles.card}>
              <div className={styles.imageWrapper}>
                <img src={member.image} alt={member.imageAlt} loading="lazy" />
              </div>
              <div>
                <h2>{member.name}</h2>
                <p className={styles.role}>{member.role}</p>
                <p className={styles.expertise}>{member.expertise}</p>
                <p className={styles.bio}>{member.bio}</p>
              </div>
            </article>
          ))}
        </section>
      </article>
    </>
  );
};

export default TeamPage;