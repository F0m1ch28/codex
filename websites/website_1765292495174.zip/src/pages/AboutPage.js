import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./AboutPage.module.css";

const AboutPage = () => {
  return (
    <>
      <MetaTags
        title="À propos — Education in Paris Review"
        description="Présentation de la mission, de l'équipe éditoriale et de la démarche méthodologique d'Education in Paris Review."
        keywords="à propos, méthodologie, mission éditoriale, éducation Paris"
      />
      <article className={styles.page}>
        <header className={styles.header}>
          <h1>Mission éditoriale et démarche de recherche</h1>
          <p>
            Education in Paris Review est un média neutre consacré à l’étude des
            trajectoires éducatives parisiennes. La revue documente les politiques
            publiques, les initiatives pédagogiques et les dynamiques sociales en
            s’appuyant sur des méthodes de recherche rigoureuses et sur un comité
            de lecture pluridisciplinaire.
          </p>
        </header>

        <section className={styles.section}>
          <h2>Origine de la revue</h2>
          <p>
            Fondée par un collectif de journalistes spécialisés et de chercheurs
            en sciences sociales, Education in Paris Review répond à un besoin de
            contextualisation des données éducatives. La rédaction s&apos;est
            constituée après plusieurs collaborations dans des think tanks et des
            institutions publiques, avec la volonté de proposer un espace d’analyse
            accessible aux professionnels comme aux citoyens intéressés.
          </p>
        </section>

        <section className={`${styles.section} ${styles.grid}`}>
          <div>
            <h2>Principes fondateurs</h2>
            <ul className={styles.list}>
              <li>
                <strong>Neutralité analytique :</strong> chaque publication repose
                sur des sources vérifiables, la confrontation des points de vue et
                une relecture par un comité scientifique externe.
              </li>
              <li>
                <strong>Perspective longue :</strong> les enquêtes intègrent des
                éléments historiques afin de situer les évolutions actuelles dans
                des trajectoires plus larges.
              </li>
              <li>
                <strong>Coopération avec le terrain :</strong> enseignants,
                personnels d&apos;encadrement, chercheurs et associations sont
                régulièrement sollicités pour partager leur expertise.
              </li>
            </ul>
          </div>
          <div>
            <h2>Processus éditorial</h2>
            <p>
              Chaque dossier suit un cycle comprenant définition du sujet,
              collecte documentaire, enquêtes de terrain, analyses statistiques,
              rédaction collective et validation finale. Les corrections sont
              publiées en transparence lorsque des compléments d&apos;information
              sont nécessaires.
            </p>
            <p>
              Les entretiens sont systématiquement relus par les personnes
              interrogées afin de garantir la fidélité des propos. Les données
              quantitatives utilisées sont accompagnées de notes méthodologiques,
              mentionnant sources, dates et méthodologies de calcul.
            </p>
          </div>
        </section>

        <section className={styles.section}>
          <h2>Engagements vis-à-vis des lecteurs</h2>
          <p>
            La revue met à disposition des synthèses claires, des infographies et
            des dossiers approfondis sans recourir à des expressions sensations
            ou à des titres à caractère alarmiste. Les lecteurs bénéficient d’un
            suivi longitudinal des sujets : inclusion, transition écologique,
            innovations pédagogiques, partenariats culturels, évolution des
            établissements supérieurs.
          </p>
        </section>

        <section className={styles.section}>
          <h2>Comité scientifique consultatif</h2>
          <p>
            Un comité consultatif composé de spécialistes de sociologie de
            l’éducation, d’histoire, de sciences politiques et d’économie de
            l’éducation accompagne la revue. Ce comité n’intervient pas dans la
            sélection des sujets, mais apporte un regard critique sur les
            méthodes mobilisées et propose des pistes de comparaison internationale.
          </p>
        </section>
      </article>
    </>
  );
};

export default AboutPage;