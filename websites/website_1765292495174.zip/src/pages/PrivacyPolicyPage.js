import React from "react";
import MetaTags from "../components/MetaTags";
import styles from "./PrivacyPolicyPage.module.css";

const PrivacyPolicyPage = () => {
  return (
    <>
      <MetaTags
        title="Politique de confidentialité — Education in Paris Review"
        description="Information sur la protection des données personnelles collectées par Education in Paris Review."
        keywords="politique de confidentialité, données personnelles"
      />
      <article className={styles.page}>
        <h1>Politique de confidentialité</h1>

        <section>
          <h2>1. Principes généraux</h2>
          <p>
            Education in Paris Review respecte la réglementation relative à la
            protection des données personnelles. Les informations nominatives
            collectées via les formulaires sont utilisées exclusivement pour le
            suivi des demandes et la diffusion des synthèses éditoriales.
          </p>
        </section>

        <section>
          <h2>2. Données collectées</h2>
          <p>
            Les données susceptibles d’être collectées sont le nom, le prénom,
            l’adresse électronique, l’organisation de rattachement et le contenu
            du message. Aucune donnée sensible n’est sollicitée.
          </p>
        </section>

        <section>
          <h2>3. Finalités</h2>
          <p>
            Les données servent à répondre aux sollicitations, gérer les listes
            d’envoi des synthèses et établir des statistiques anonymes sur
            l’utilisation du site. Aucune donnée n’est cédée à des tiers.
          </p>
        </section>

        <section>
          <h2>4. Durée de conservation</h2>
          <p>
            Les messages sont conservés pendant une durée maximale de vingt-quatre
            mois. Les inscriptions à la lettre d’information peuvent être
            supprimées à tout moment sur simple demande.
          </p>
        </section>

        <section>
          <h2>5. Droits des personnes</h2>
          <p>
            Conformément au règlement général sur la protection des données, toute
            personne peut accéder, rectifier ou supprimer ses informations en
            écrivant à l’adresse redaction@education-paris-review.fr.
          </p>
        </section>

        <section>
          <h2>6. Sécurité</h2>
          <p>
            Des mesures techniques et organisationnelles raisonnables sont
            mises en place pour préserver la confidentialité des données. Les
            accès sont réservés aux personnes habilitées de la rédaction.
          </p>
        </section>
      </article>
    </>
  );
};

export default PrivacyPolicyPage;