export const topics = [
  {
    id: 1,
    title: "Éducation à Paris",
    description:
      "Analyse globale des trajectoires scolaires, des politiques publiques et des dynamiques territoriales propres à la capitale."
  },
  {
    id: 2,
    title: "Écoles publiques et privées",
    description:
      "Étude comparative des organisations pédagogiques, des infrastructures et des collaborations entre secteurs public et privé."
  },
  {
    id: 3,
    title: "Établissements internationaux",
    description:
      "Cartographie des écoles à programme étranger, de leur attractivité et de leur articulation avec le paysage éducatif local."
  },
  {
    id: 4,
    title: "Lycées parisiens renommés",
    description:
      "Retour historique et contemporain sur les établissements emblématiques, leurs filières et leurs évolutions pédagogiques."
  },
  {
    id: 5,
    title: "Universités et grandes écoles",
    description:
      "Observation des stratégies universitaires parisiennes autour de l'interdisciplinarité, de l'ouverture sociale et de la recherche."
  },
  {
    id: 6,
    title: "Classes préparatoires",
    description:
      "Analyse des pratiques d'accompagnement, des profils d'étudiants et des mutations en cours dans les CPGE parisiennes."
  },
  {
    id: 7,
    title: "Pédagogies innovantes",
    description:
      "Inventaire des expérimentations menées dans les écoles, collèges et lycées : pédagogie de projet, laboratoires, hybridations."
  },
  {
    id: 8,
    title: "Politiques éducatives locales",
    description:
      "Suivi des plans municipaux, des investissements infra-structurels et des concertations entre Ville de Paris et académie."
  },
  {
    id: 9,
    title: "Inclusion scolaire",
    description:
      "Focus sur les dispositifs d'accueil des élèves à besoins éducatifs particuliers et sur les pratiques de coéducation."
  },
  {
    id: 10,
    title: "Diversité socio-économique",
    description:
      "Études quantitatives et qualitatives sur la mixité, la sectorisation et les trajectoires d'élèves dans les quartiers parisiens."
  },
  {
    id: 11,
    title: "Enseignement supérieur",
    description:
      "Observation des cursus, des partenariats de recherche et des mobilités étudiantes au sein des universités parisiennes."
  },
  {
    id: 12,
    title: "Recherche académique à Paris",
    description:
      "Point sur les laboratoires, centres d'études et think tanks contribuant à l'analyse des politiques éducatives."
  },
  {
    id: 13,
    title: "Mobilité étudiante",
    description:
      "Enquête sur les flux intra-métropolitains et internationaux des étudiants, ainsi que sur leurs conditions de vie."
  },
  {
    id: 14,
    title: "Ressources pédagogiques",
    description:
      "Inventaire des bibliothèques, plateformes numériques et outils mis à disposition des professionnels de l'éducation."
  },
  {
    id: 15,
    title: "Défis de l'éducation urbaine",
    description:
      "Analyse des enjeux liés à la densité, à la transition écologique et aux transformations du cadre bâti scolaire."
  },
  {
    id: 16,
    title: "Répartition des établissements",
    description:
      "Cartographie des établissements dans les vingt arrondissements et réflexion sur les équilibres à atteindre."
  },
  {
    id: 17,
    title: "Histoire de l'enseignement à Paris",
    description:
      "Exploration des archives pour comprendre les continuités et ruptures du système éducatif parisien."
  },
  {
    id: 18,
    title: "Institutions culturelles et éducation",
    description:
      "Étude des partenariats entre musées, théâtres, bibliothèques et établissements scolaires."
  },
  {
    id: 19,
    title: "Partenariats éducatifs",
    description:
      "Suivi des collaborations entre établissements, associations, entreprises et collectivités."
  },
  {
    id: 20,
    title: "Numérique et transformation pédagogique",
    description:
      "Analyse des usages numériques, de l'équipement des établissements et de la formation des équipes."
  }
];