export const teamMembers = [
  {
    id: 1,
    name: "Hélène Marchand",
    role: "Rédactrice en chef",
    expertise:
      "Politiques éducatives, gouvernance territoriale, enquêtes qualitatives",
    bio:
      "Ancienne responsable d'étude au ministère de l'Éducation nationale, Hélène Marchand coordonne les dossiers de fond et supervise la ligne éditoriale de la revue.",
    image:
      "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=400&q=80",
    imageAlt: "Portrait de Hélène Marchand, rédactrice en chef"
  },
  {
    id: 2,
    name: "Aurélien Dubois",
    role: "Journaliste data",
    expertise:
      "Analyse statistique, cartographie, visualisation de données éducatives",
    bio:
      "Spécialiste des données publiques, Aurélien Dubois conçoit des cartes, tableaux et analyses quantitatives pour éclairer les dynamiques scolaires parisiennes.",
    image:
      "https://images.unsplash.com/photo-1504593811423-6dd665756598?auto=format&fit=crop&w=400&q=80",
    imageAlt: "Portrait d'Aurélien Dubois, journaliste data"
  },
  {
    id: 3,
    name: "Sonia Benali",
    role: "Reporter terrain",
    expertise:
      "Enquêtes de terrain, inclusion scolaire, rapports entre écoles et quartiers",
    bio:
      "Journaliste depuis quinze ans, Sonia Benali mène des enquêtes de proximité auprès des équipes pédagogiques, des associations et des familles.",
    image:
      "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80",
    imageAlt: "Portrait de Sonia Benali, reporter terrain"
  },
  {
    id: 4,
    name: "Mathieu Garnier",
    role: "Chercheur associé",
    expertise:
      "Histoire de l'éducation, institutions scolaires, archives parisiennes",
    bio:
      "Docteur en histoire contemporaine, Mathieu Garnier met en perspective les enquêtes actuelles en les reliant aux archives des lycées et universités de la capitale.",
    image:
      "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=400&q=80",
    imageAlt: "Portrait de Mathieu Garnier, chercheur associé"
  },
  {
    id: 5,
    name: "Clara Nguyen",
    role: "Responsable multimédia",
    expertise:
      "Narration visuelle, podcasts, valorisation des témoignages éducatifs",
    bio:
      "Clara Nguyen développe les formats audio et vidéo de la revue afin de restituer les voix des acteurs éducatifs parisiens.",
    image:
      "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80",
    imageAlt: "Portrait de Clara Nguyen, responsable multimédia"
  },
  {
    id: 6,
    name: "Youssef Aït Ali",
    role: "Analyste politiques locales",
    expertise:
      "Suivi des budgets municipaux, concertations territoriales, inclusion",
    bio:
      "Ancien chargé de mission dans une collectivité francilienne, Youssef Aït Ali décrypte les orientations des politiques éducatives locales.",
    image:
      "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80",
    imageAlt: "Portrait de Youssef Aït Ali, analyste politiques locales"
  }
];