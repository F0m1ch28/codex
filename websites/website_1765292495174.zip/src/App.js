import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import ScrollToTopButton from "./components/ScrollToTopButton";
import HomePage from "./pages/HomePage";
import AboutPage from "./pages/AboutPage";
import TopicsPage from "./pages/TopicsPage";
import ArticlesPage from "./pages/ArticlesPage";
import ArticlePage from "./pages/ArticlePage";
import TeamPage from "./pages/TeamPage";
import ContactPage from "./pages/ContactPage";
import TermsOfServicePage from "./pages/TermsOfServicePage";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import CookiePolicyPage from "./pages/CookiePolicyPage";
import NotFoundPage from "./pages/NotFoundPage";

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="appLayout">
        <Header />
        <main className="mainContent" id="contenu-principal">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/a-propos" element={<AboutPage />} />
            <Route path="/themes-recherche" element={<TopicsPage />} />
            <Route path="/archives" element={<ArticlesPage />} />
            <Route
              path="/article/:slug"
              element={<ArticlePage />}
            />
            <Route path="/equipe" element={<TeamPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route
              path="/conditions-generales"
              element={<TermsOfServicePage />}
            />
            <Route
              path="/politique-de-confidentialite"
              element={<PrivacyPolicyPage />}
            />
            <Route
              path="/politique-de-cookies"
              element={<CookiePolicyPage />}
            />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
      <CookieBanner />
      <ScrollToTopButton />
    </Router>
  );
}

export default App;