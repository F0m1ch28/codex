document.addEventListener('DOMContentLoaded', function () {
    var navToggle = document.querySelector('.nav-toggle');
    var siteNav = document.getElementById('siteNav');

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', function () {
            var isOpen = siteNav.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    }

    var cookieBanner = document.getElementById('cookieBanner');
    var acceptButton = document.getElementById('cookieAccept');
    var declineButton = document.getElementById('cookieDecline');

    if (cookieBanner && acceptButton && declineButton) {
        var consent = localStorage.getItem('fes-cookie-consent');

        if (!consent) {
            cookieBanner.classList.add('is-visible');
        }

        var hideBanner = function () {
            cookieBanner.classList.remove('is-visible');
        };

        acceptButton.addEventListener('click', function () {
            localStorage.setItem('fes-cookie-consent', 'accepted');
            hideBanner();
        });

        declineButton.addEventListener('click', function () {
            localStorage.setItem('fes-cookie-consent', 'declined');
            hideBanner();
        });
    }
});