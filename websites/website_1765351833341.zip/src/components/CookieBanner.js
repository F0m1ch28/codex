import React, { useState, useEffect } from 'react';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'videocoverspro_cookie_consent';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Уведомление об использовании cookies">
      <p className={styles.message}>
        Мы используем cookies, чтобы анализировать трафик и предлагать актуальный контент. Продолжая пользоваться сайтом, вы соглашаетесь с политикой обработки данных.
      </p>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Согласен
      </button>
    </div>
  );
};

export default CookieBanner;