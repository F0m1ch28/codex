import { useEffect } from 'react';

const MetaTags = ({ title, description }) => {
  useEffect(() => {
    const previousTitle = document.title;
    if (title) {
      document.title = title;
    }

    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }

    if (description) {
      metaDescription.setAttribute('content', description);
    }

    return () => {
      if (title) {
        document.title = previousTitle;
      }
    };
  }, [title, description]);

  return null;
};

export default MetaTags;