import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleNewsletterSubmit = (event) => {
    event.preventDefault();
    if (!email.trim()) return;
    setSubmitted(true);
    setEmail('');
  };

  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.brand}>
          <div className={styles.logo}>
            <span className={styles.logoMark}>VC</span>
            <span className={styles.logoText}>VideoCoversPro</span>
          </div>
          <p className={styles.tagline}>
            Профессиональные обложки, аватарки и баннеры для YouTube, Twitch, VK и других платформ.
            Мы создаем визуальную идентичность, которая выделяет вас среди конкурентов.
          </p>
          <div className={styles.contact}>
            <span className={styles.contactLabel}>Email:</span>
            <a href="mailto:support@videocoverspro.com" className={styles.contactLink}>
              support@videocoverspro.com
            </a>
          </div>
        </div>

        <div className={styles.linksBlock}>
          <h3 className={styles.columnTitle}>Навигация</h3>
          <Link to="/" className={styles.link}>Главная</Link>
          <Link to="/catalog" className={styles.link}>Каталог</Link>
          <Link to="/catalog/video-covers" className={styles.link}>Обложки для видео</Link>
          <Link to="/catalog/avatars" className={styles.link}>Аватарки и иконки</Link>
          <Link to="/catalog/stream-banners" className={styles.link}>Баннеры для стримов</Link>
        </div>

        <div className={styles.linksBlock}>
          <h3 className={styles.columnTitle}>Компания</h3>
          <Link to="/services" className={styles.link}>Индивидуальные решения</Link>
          <Link to="/about" className={styles.link}>О нас</Link>
          <Link to="/contact" className={styles.link}>Контакты</Link>
          <Link to="/terms" className={styles.link}>Лицензионное соглашение</Link>
          <Link to="/privacy" className={styles.link}>Политика конфиденциальности</Link>
          <Link to="/cookie-policy" className={styles.link}>Политика cookies</Link>
        </div>

        <div className={styles.newsletter}>
          <h3 className={styles.columnTitle}>Будьте в курсе</h3>
          <p className={styles.newsletterText}>
            Подпишитесь на дайджест обновлений каталога и рекомендаций по улучшению визуала.
          </p>
          <form onSubmit={handleNewsletterSubmit} className={styles.form}>
            <label className="visuallyHidden" htmlFor="footer-email">
              Email для подписки
            </label>
            <input
              id="footer-email"
              type="email"
              name="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@example.com"
              className={styles.input}
              required
            />
            <button type="submit" className={styles.button}>
              Получать апдейты
            </button>
          </form>
          {submitted && (
            <p className={styles.confirmation}>
              Спасибо! Мы свяжемся с вами по электронной почте.
            </p>
          )}
        </div>
      </div>

      <div className={styles.bottom}>
        <p className={styles.copy}>
          © {new Date().getFullYear()} VideoCoversPro. Все права защищены.
        </p>
        <p className={styles.note}>
          Создано для авторов контента, стримеров и digital-сообществ по всему миру.
        </p>
      </div>
    </footer>
  );
};

export default Footer;