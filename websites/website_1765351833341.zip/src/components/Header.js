import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import styles from './Header.module.css';

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    { to: '/', label: 'Главная' },
    { to: '/catalog', label: 'Каталог' },
    { to: '/services', label: 'Услуги' },
    { to: '/about', label: 'О нас' },
    { to: '/contact', label: 'Контакты' }
  ];

  const handleToggle = () => setMenuOpen((prev) => !prev);
  const handleClose = () => setMenuOpen(false);

  return (
    <header className={styles.header}>
      <div className={styles.inner}>
        <Link to="/" className={styles.logo} onClick={handleClose} aria-label="VideoCoversPro — переход на главную">
          <span className={styles.logoMark}>VC</span>
          <span className={styles.logoText}>VideoCoversPro</span>
        </Link>

        <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Основная навигация">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              className={({ isActive }) =>
                isActive ? `${styles.navLink} ${styles.active}` : styles.navLink
              }
              onClick={handleClose}
            >
              {link.label}
            </NavLink>
          ))}
          <Link to="/catalog/video-covers" className={`${styles.navLink} ${styles.highlight}`} onClick={handleClose}>
            Подборки
          </Link>
        </nav>

        <button
          type="button"
          className={styles.mobileToggle}
          onClick={handleToggle}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Открыть меню"
        >
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
          <span className={styles.toggleBar} />
        </button>
      </div>
    </header>
  );
};

export default Header;