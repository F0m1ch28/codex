import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import ScrollToTopButton from './components/ScrollToTopButton';
import HomePage from './pages/Home';
import CatalogPage from './pages/CatalogPage';
import VideoCoversPage from './pages/VideoCoversPage';
import AvatarsPage from './pages/AvatarsPage';
import StreamBannersPage from './pages/StreamBannersPage';
import ServicesPage from './pages/ServicesPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import CookiePolicyPage from './pages/CookiePolicyPage';
import styles from './App.module.css';

const App = () => (
  <div className={styles.app}>
    <Header />
    <ScrollToTop />
    <main className={styles.main}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/catalog" element={<CatalogPage />} />
        <Route path="/catalog/video-covers" element={<VideoCoversPage />} />
        <Route path="/catalog/avatars" element={<AvatarsPage />} />
        <Route path="/catalog/stream-banners" element={<StreamBannersPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/cookie-policy" element={<CookiePolicyPage />} />
      </Routes>
    </main>
    <Footer />
    <CookieBanner />
    <ScrollToTopButton />
  </div>
);

export default App;