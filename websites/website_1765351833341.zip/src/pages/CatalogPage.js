import React from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './CatalogPage.module.css';

const CatalogPage = () => {
  const categories = [
    {
      title: 'Обложки для видео',
      description:
        'Коллекции превью для YouTube, Rutube и Shorts. Актуальные тренды, яркие заголовки и проработанные композиции.',
      features: ['Шаблоны PSD/PNG', 'Работа с текстовыми блоками', 'Версии для вертикальных форматов'],
      link: '/catalog/video-covers',
      image: 'https://picsum.photos/800/560?random=301'
    },
    {
      title: 'Аватарки и иконки',
      description:
        'Выразительные аватары для блогеров, стримеров и брендов. Вариации по настроению, цветам и контенту.',
      features: ['Файлы в высоком разрешении', 'Готовые фоновые вариации', 'Цветовые палитры в комплекте'],
      link: '/catalog/avatars',
      image: 'https://picsum.photos/800/560?random=302'
    },
    {
      title: 'Баннеры и оверлеи',
      description:
        'Профессиональные комплекты для Twitch, Kick и YouTube Live. Экраны паузы, панели донатов, оверлеи и алерты.',
      features: ['PSD и PNG слои', 'Инструкции по сборке', 'Совместимость с OBS и Streamlabs'],
      link: '/catalog/stream-banners',
      image: 'https://picsum.photos/800/560?random=303'
    }
  ];

  return (
    <>
      <MetaTags
        title="Каталог графики — VideoCoversPro"
        description="Просмотрите каталог готовых обложек, аватарок и баннеров для YouTube, Twitch, VK и других платформ."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Каталог готовых коллекций</h1>
          <p>
            Сотни готовых дизайнов для авторов, стримеров и SMM-команд. Используйте умные фильтры по жанрам, настроению,
            цветовым палитрам и платформам.
          </p>
          <div className={styles.heroHighlights}>
            <span>Актуальные тренды</span>
            <span>Регулярные обновления</span>
            <span>Файлы в слоях</span>
          </div>
        </div>
      </section>

      <section className={styles.categories}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2>Выберите направление</h2>
            <p>
              Каждый набор включает подробное описание, рекомендации по адаптации и структурированные файлы для удобной работы.
            </p>
          </div>
          <div className={styles.grid}>
            {categories.map((category) => (
              <article key={category.title} className={styles.card}>
                <img src={category.image} alt={category.title} loading="lazy" />
                <div className={styles.cardContent}>
                  <h3>{category.title}</h3>
                  <p>{category.description}</p>
                  <ul>
                    {category.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                  <Link to={category.link} className={styles.cardLink}>
                    Перейти к коллекции →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.callout}>
        <div className={styles.calloutContent}>
          <h2>Нужен подбор под конкретную тематику?</h2>
          <p>
            Напишите нам и получите персональный набор дизайнов, подобранный куратором VideoCoversPro под формат проекта,
            аудиторию и tone of voice.
          </p>
          <Link to="/contact" className={styles.calloutButton}>
            Оставить запрос
          </Link>
        </div>
      </section>
    </>
  );
};

export default CatalogPage;