import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './CookiePolicyPage.module.css';

const CookiePolicyPage = () => (
  <>
    <MetaTags
      title="Политика использования cookies — VideoCoversPro"
      description="Информация о том, как VideoCoversPro использует cookies и похожие технологии."
    />
    <section className={styles.page}>
      <div className="container">
        <h1>Политика использования cookies</h1>
        <p className={styles.update}>Последнее обновление: 12 апреля 2024 года</p>

        <h2>1. Что такое cookies</h2>
        <p>
          Cookies — это небольшие текстовые файлы, которые сохраняются в браузере пользователя для обеспечения
          корректной работы сайта и персонализации сервиса.
        </p>

        <h2>2. Какие cookies мы используем</h2>
        <ul>
          <li><strong>Функциональные:</strong> обеспечивают авторизацию и сохранение настроек пользователя.</li>
          <li><strong>Аналитические:</strong> помогают анализировать посещаемость и улучшать функциональность платформы.</li>
        </ul>

        <h2>3. Управление cookies</h2>
        <p>
          Вы можете отключить cookies в настройках браузера. Однако это может повлиять на работу некоторых функций сайта.
          Используя сайт, вы соглашаетесь с нашей политикой cookies.
        </p>

        <h2>4. Контакты</h2>
        <p>
          По вопросам использования cookies пишите на{' '}
          <a href="mailto:support@videocoverspro.com">support@videocoverspro.com</a>.
        </p>
      </div>
    </section>
  </>
);

export default CookiePolicyPage;