import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './AvatarsPage.module.css';

const AvatarsPage = () => {
  const avatars = [
    {
      title: 'Neon Streamer',
      description: 'Неоновые градиенты и динамические обводки для каналов киберспортивной тематики.',
      image: 'https://picsum.photos/800/800?random=341',
      palette: ['#06b6d4', '#9333ea', '#fbbf24']
    },
    {
      title: 'Minimal Creator',
      description: 'Минималистичные решения для блогеров, которые ценят чистоту и спокойствие.',
      image: 'https://picsum.photos/800/800?random=342',
      palette: ['#0f172a', '#cbd5f5', '#06b6d4']
    },
    {
      title: 'Podcast Mood',
      description: 'Аудиоволны, крупная типографика и атмосферные фоны для подкастеров и интервью.',
      image: 'https://picsum.photos/800/800?random=343',
      palette: ['#1e293b', '#22d3ee', '#f472b6']
    },
    {
      title: 'Artistic Touch',
      description: 'Скетчевые и акварельные текстуры для творческих каналов и художников.',
      image: 'https://picsum.photos/800/800?random=344',
      palette: ['#0f172a', '#f97316', '#facc15']
    }
  ];

  return (
    <>
      <MetaTags
        title="Аватарки и иконки — VideoCoversPro"
        description="Выразительные аватары и иконки для YouTube, Twitch, VK и Telegram. Современные стили и гибкая настройка."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Аватарки и иконки</h1>
          <p>
            Сильная визуальная идентичность начинается с аватара. Выберите стиль, который подчеркнет характер бренда,
            и адаптируйте под любой формат — от квадратного до круглого.
          </p>
        </div>
      </section>

      <section className={styles.gallery}>
        <div className="container">
          <div className={styles.grid}>
            {avatars.map((avatar) => (
              <article key={avatar.title} className={styles.card}>
                <img src={avatar.image} alt={`Аватарка: ${avatar.title}`} loading="lazy" />
                <div className={styles.content}>
                  <h2>{avatar.title}</h2>
                  <p>{avatar.description}</p>
                  <div className={styles.palette}>
                    {avatar.palette.map((color) => (
                      <span key={color} style={{ backgroundColor: color }} />
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.tip}>
        <div className={styles.tipContent}>
          <h2>Соберите единый стиль для всех площадок</h2>
          <p>
            В комплект аватарок входят готовые адаптации для YouTube, Twitch, Discord, VK и Telegram, а также рекомендации
            по применению на темных и светлых фонах.
          </p>
        </div>
      </section>
    </>
  );
};

export default AvatarsPage;