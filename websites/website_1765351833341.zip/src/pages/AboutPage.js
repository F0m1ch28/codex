import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './AboutPage.module.css';

const AboutPage = () => {
  const team = [
    {
      name: 'Ольга Клейн',
      role: 'Креативный директор',
      bio: 'Отвечает за развитие стилевых направлений, тренды и качество визуальных решений.',
      image: 'https://picsum.photos/400/400?random=401'
    },
    {
      name: 'Дмитрий Назаров',
      role: 'Lead-дизайнер',
      bio: 'Куратор коллекций для YouTube и Twitch, управляет командой иллюстраторов и моушн-дизайнеров.',
      image: 'https://picsum.photos/400/400?random=402'
    },
    {
      name: 'Анна Федосеева',
      role: 'Продакт-менеджер',
      bio: 'Организует исследования аудитории, запускает обновления каталога и поддерживает качество сервиса.',
      image: 'https://picsum.photos/400/400?random=403'
    }
  ];

  const milestones = [
    {
      year: '2019',
      title: 'Запуск VideoCoversPro',
      description: 'Команда из 3 дизайнеров создала первую коллекцию обложек для YouTube-геймеров.'
    },
    {
      year: '2020',
      title: 'Расширение до международного рынка',
      description: 'Появились адаптации на английском, испанском и немецком языках, клиенты из 15 стран.'
    },
    {
      year: '2022',
      title: 'Интеграция со стриминговыми платформами',
      description: 'Выпустили комплекты баннеров, анимаций и виджетов для Twitch и Kick.'
    },
    {
      year: '2023',
      title: 'Собственная команда кураторов',
      description: 'Создали отдел проверки качества и запуска еженедельных релизов коллекций.'
    }
  ];

  const values = [
    {
      title: 'Нетривиальные решения',
      text: 'Мы анализируем лучшие практики в дизайне и адаптируем их под задачи блогеров и стримеров.'
    },
    {
      title: 'Фокус на эффективности',
      text: 'Каждый макет тестируется на читаемость, CTR и соответствие требованиям платформ.'
    },
    {
      title: 'Прозрачная коммуникация',
      text: 'Работаем в тесной связке с авторами: прислушиваемся к обратной связи и быстро реагируем на запросы.'
    }
  ];

  return (
    <>
      <MetaTags
        title="О компании — VideoCoversPro"
        description="Команда VideoCoversPro создает графику для видеоблогеров и стримеров. Узнайте больше о нас и наших ценностях."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>VideoCoversPro</h1>
          <p>
            Мы помогаем авторам контента, стримерам и digital-агентствам выстраивать визуальное присутствие,
            которое усиливает доверие аудитории и выделяет бренд среди конкурентов.
          </p>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <div className={styles.valuesGrid}>
            {values.map((value) => (
              <article key={value.title} className={styles.valueCard}>
                <h2>{value.title}</h2>
                <p>{value.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.milestones}>
        <div className="container">
          <h2>Как мы развивались</h2>
          <div className={styles.timeline}>
            {milestones.map((milestone) => (
              <div key={milestone.year} className={styles.timelineItem}>
                <span className={styles.year}>{milestone.year}</span>
                <h3>{milestone.title}</h3>
                <p>{milestone.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team}>
        <div className="container">
          <div className={styles.teamHeader}>
            <h2>Команда VideoCoversPro</h2>
            <p>
              Мы объединяем дизайнеров, иллюстраторов, моушн-специалистов и менеджеров проектов, чтобы запускать новые коллекции быстро и качественно.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {team.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <img src={member.image} alt={member.name} loading="lazy" />
                <div className={styles.teamContent}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;