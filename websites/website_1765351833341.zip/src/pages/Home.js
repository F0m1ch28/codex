import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './Home.module.css';

const HomePage = () => {
  const categories = [
    {
      title: 'Обложки для видео',
      description: 'Разработанные дизайнерами превью для YouTube и других платформ с акцентом на кликабельность и идентичность.',
      image: 'https://picsum.photos/600/400?random=201',
      link: '/catalog/video-covers'
    },
    {
      title: 'Аватарки и иконки',
      description: 'Уникальные аватары для каналов, сообществ и профилей, подчеркивающие вашу индивидуальность.',
      image: 'https://picsum.photos/600/400?random=202',
      link: '/catalog/avatars'
    },
    {
      title: 'Баннеры для стримов',
      description: 'Комплекты визуала для Twitch и YouTube Live: заставки, шапки, оверлеи и плашки.',
      image: 'https://picsum.photos/600/400?random=203',
      link: '/catalog/stream-banners'
    },
    {
      title: 'Графика для соцсетей',
      description: 'Адаптированные шаблоны для VK, Telegram, Instagram и других площадок.',
      image: 'https://picsum.photos/600/400?random=204',
      link: '/catalog'
    }
  ];

  const statsConfig = [
    { id: 'projects', label: 'готовых макетов', value: 1250 },
    { id: 'creators', label: 'авторов и каналов', value: 540 },
    { id: 'platforms', label: 'популярных платформ', value: 12 },
    { id: 'rating', label: 'рейтинг по отзывам', value: 4.9, suffix: '/5' }
  ];

  const processSteps = [
    {
      title: 'Выбираете стиль',
      description: 'Соберите подборку дизайнов по цвету, платформе и жанру контента. Подробные теги помогут сориентироваться.'
    },
    {
      title: 'Получаете файлы моментально',
      description: 'После оформления вы мгновенно загружаете архивы с PSD, PNG и инструкциями по адаптации.'
    },
    {
      title: 'Адаптируете под себя',
      description: 'Используйте готовые слои или обратитесь к нашей команде за кастомными правками.'
    },
    {
      title: 'Запускаете обновленный бренд',
      description: 'Свежее оформление повышает доверие зрителей и CTR карточек видео и стримов.'
    }
  ];

  const galleryItems = [
    { id: 1, title: 'Sci-Fi обзоры', image: 'https://picsum.photos/900/600?random=211' },
    { id: 2, title: 'Музыкальные подкасты', image: 'https://picsum.photos/900/600?random=212' },
    { id: 3, title: 'Киберспорт Twitch', image: 'https://picsum.photos/900/600?random=213' },
    { id: 4, title: 'Telegram дайджесты', image: 'https://picsum.photos/900/600?random=214' },
    { id: 5, title: 'Lifestyle-блог', image: 'https://picsum.photos/900/600?random=215' },
    { id: 6, title: 'Tech-разборы', image: 'https://picsum.photos/900/600?random=216' }
  ];

  const testimonials = [
    {
      id: 1,
      name: 'Мария Левченко',
      role: 'Автор канала о дизайне',
      quote:
        'Видеообложки от VideoCoversPro дали резкий рост кликов и подписок. Очень нравится внимание к деталям и трендовым цветовым решениям.',
      avatar: 'https://picsum.photos/200/200?random=221'
    },
    {
      id: 2,
      name: 'Алексей Воронов',
      role: 'Стример по шутерам',
      quote:
        'Комплект баннеров для Twitch оказался продуманным: оверлеи, экраны паузы, алерты. Легко адаптировал под свой бренд.',
      avatar: 'https://picsum.photos/200/200?random=222'
    },
    {
      id: 3,
      name: 'Катя Миронова',
      role: 'SMM-редактор',
      quote:
        'Экономит массу времени при запуске новых рубрик. Файлы аккуратно структурированы и готовы к работе в Figma и Photoshop.',
      avatar: 'https://picsum.photos/200/200?random=223'
    }
  ];

  const advantages = [
    {
      title: 'Файлы в слоях',
      description: 'Каждый шаблон содержит структурированные слои и стили для быстрой кастомизации.',
      icon: '🎨'
    },
    {
      title: 'Уникальные коллекции',
      description: 'Новые подборки публикуются еженедельно: сезонные кампании, музыкальные шоу, IRL-стримы.',
      icon: '🗂️'
    },
    {
      title: 'Команда кураторов',
      description: 'Редакторы проверяют каждый макет на читаемость, тренды и универсальность.',
      icon: '👥'
    },
    {
      title: 'Поддержка 24/7',
      description: 'Отвечаем на вопросы по настройке, рендеру и адаптации дизайнов под разные разрешения.',
      icon: '⚡'
    }
  ];

  const projectItems = [
    {
      id: 1,
      title: 'YouTube «Технологии будущего»',
      description: 'Динамичные превью с акцентом на хай-тек и инфографику.',
      category: 'YouTube',
      image: 'https://picsum.photos/1200/800?random=231'
    },
    {
      id: 2,
      title: 'Twitch «Night Raid»',
      description: 'Футуристичные оверлеи и лейаут для соревновательных стримов.',
      category: 'Twitch',
      image: 'https://picsum.photos/1200/800?random=232'
    },
    {
      id: 3,
      title: 'VK сообщество «Музыка без границ»',
      description: 'Шаблоны постов и сторис для продвижения новых релизов.',
      category: 'VK',
      image: 'https://picsum.photos/1200/800?random=233'
    },
    {
      id: 4,
      title: 'Telegram «Product Arena»',
      description: 'Постеры и карточки для экспертных подборок и объявлений.',
      category: 'Telegram',
      image: 'https://picsum.photos/1200/800?random=234'
    },
    {
      id: 5,
      title: 'YouTube Shorts «Quick Tips»',
      description: 'Мини-превью для вертикального контента с высокой читаемостью.',
      category: 'YouTube',
      image: 'https://picsum.photos/1200/800?random=235'
    }
  ];

  const faqItems = [
    {
      question: 'Какие форматы файлов входят в наборы?',
      answer:
        'В каждый комплект включены PSD/PSB, PNG в высоком разрешении, а также дополнительные пресеты для социальных сетей. В описании продукта указаны точные размеры и рекомендации.'
    },
    {
      question: 'Можно ли заказать индивидуальную адаптацию?',
      answer:
        'Да, мы предлагаем индивидуальные правки: замена текстов, шрифтов, цветов, добавление логотипов. Для этого заполните форму на странице контактов или оформите заявку в разделе «Услуги».'
    },
    {
      question: 'Как часто обновляется каталог?',
      answer:
        'Новые подборки добавляются каждую неделю. Подпишитесь на рассылку внизу сайта, чтобы получать уведомления о свежих релизах и трендовых коллекциях.'
    },
    {
      question: 'Есть ли ограничения по использованию?',
      answer:
        'Лицензия разрешает использование в личных и коммерческих проектах, но запрещает перепродажу и перераспределение файлов. Полные условия описаны в лицензионном соглашении.'
    }
  ];

  const blogPosts = [
    {
      id: 1,
      title: 'Как повысить CTR обложек на YouTube в 2024',
      excerpt:
        'Разбираем психологию цвета, композицию и работу с крупными заголовками на примерах популярных каналов.',
      image: 'https://picsum.photos/800/600?random=241'
    },
    {
      id: 2,
      title: 'Гайд по оформлению стримов: от оверлеев до донат-виджетов',
      excerpt:
        'Пошаговое руководство по созданию атмосферы канала, подбору шрифтов и настройке экранов перехода.',
      image: 'https://picsum.photos/800/600?random=242'
    },
    {
      id: 3,
      title: 'Визуальная идентичность для Telegram-сообщества',
      excerpt:
        'Как поддерживать единый стиль карточек и сторис, чтобы укреплять узнаваемость бренда и удержание аудитории.',
      image: 'https://picsum.photos/800/600?random=243'
    }
  ];

  const [statValues, setStatValues] = useState(() =>
    statsConfig.reduce((acc, stat) => ({ ...acc, [stat.id]: 0 }), {})
  );
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Все');
  const [openedFaq, setOpenedFaq] = useState(null);

  useEffect(() => {
    let animationFrame;
    const duration = 1600;
    const start = performance.now();

    const animate = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const updated = statsConfig.reduce((acc, stat) => {
        const value = stat.value;
        const currentValue = stat.id === 'rating'
          ? (value * progress).toFixed(1)
          : Math.floor(value * progress);
        acc[stat.id] = progress === 1 ? value : currentValue;
        return acc;
      }, {});
      setStatValues(updated);
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  const filteredProjects = useMemo(() => {
    if (activeFilter === 'Все') return projectItems;
    return projectItems.filter((project) => project.category === activeFilter);
  }, [activeFilter, projectItems]);

  const heroImageStyle = {
    backgroundImage:
      'linear-gradient(180deg, rgba(15, 23, 42, 0.35), rgba(15, 23, 42, 0.92)), url("https://picsum.photos/1600/900?random=101")'
  };

  const handleFaqToggle = (index) => {
    setOpenedFaq((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <MetaTags
        title="VideoCoversPro — Премиальные обложки, аватарки и баннеры"
        description="Готовые наборы графики для YouTube, Twitch, VK и Telegram. Обложки, аватарки и баннеры, созданные командой VideoCoversPro."
      />
      <div className={styles.hero} style={heroImageStyle}>
        <div className={styles.heroContent}>
          <div className={styles.heroBadge}>Каталог цифрового дизайна</div>
          <h1 className={styles.heroTitle}>
            Создайте запоминающуюся визуальную идентичность для видео и стримов
          </h1>
          <p className={styles.heroSubtitle}>
            Подберите обложки, аватарки и баннеры, разработанные экспертами VideoCoversPro.
            Современный дизайн, структурированные файлы и поддержка на каждом этапе.
          </p>
          <div className={styles.heroActions}>
            <Link to="/catalog" className={styles.primaryButton}>
              Перейти в каталог
            </Link>
            <Link to="/services" className={styles.secondaryButton}>
              Индивидуальные решения
            </Link>
          </div>
          <div className={styles.heroDetails}>
            <span>Файлы в PSD/PNG</span>
            <span>Совместимо с Photoshop &amp; Figma</span>
            <span>Подходит для YouTube, Twitch, VK, Telegram</span>
          </div>
        </div>
      </div>

      <section className={styles.statsSection} aria-label="Статистика платформы">
        <div className={styles.statsGrid}>
          {statsConfig.map((stat) => (
            <div key={stat.id} className={styles.statCard}>
              <div className={styles.statValue}>
                {stat.id === 'rating'
                  ? `${statValues[stat.id]}${stat.suffix}`
                  : `${statValues[stat.id]}${stat.suffix || ''}`}
              </div>
              <div className={styles.statLabel}>{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      <section className={styles.categoriesSection} aria-labelledby="categories-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="categories-heading" className={styles.sectionTitle}>
              Категории каталога
            </h2>
            <p className={styles.sectionDescription}>
              Библиотека готовых решений для видеоблогеров, стримеров и digital-сообществ. Используйте фильтры по жанрам, цветам и платформам.
            </p>
          </div>
          <div className={styles.categoryGrid}>
            {categories.map((category) => (
              <article key={category.title} className={styles.categoryCard}>
                <img src={category.image} alt={category.title} className={styles.categoryImage} loading="lazy" />
                <div className={styles.categoryContent}>
                  <h3 className={styles.categoryTitle}>{category.title}</h3>
                  <p className={styles.categoryText}>{category.description}</p>
                  <Link to={category.link} className={styles.categoryLink}>
                    Смотреть подборку →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.processSection} aria-labelledby="process-heading">
        <div className="container">
          <div className={styles.sectionHeaderCentered}>
            <h2 id="process-heading" className={styles.sectionTitle}>
              Как работает VideoCoversPro
            </h2>
            <p className={styles.sectionDescriptionCentered}>
              От подбора коллекции до запуска обновленного визуала — все этапы настроены на удобство авторов и команд.
            </p>
          </div>
          <div className={styles.processTimeline}>
            {processSteps.map((step, index) => (
              <div key={step.title} className={styles.processCard}>
                <div className={styles.processStep}>0{index + 1}</div>
                <h3 className={styles.processTitle}>{step.title}</h3>
                <p className={styles.processText}>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.gallerySection} aria-labelledby="gallery-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="gallery-heading" className={styles.sectionTitle}>
              Популярные работы недели
            </h2>
            <p className={styles.sectionDescription}>
              Актуальные обложки и баннеры, которые уже используют авторы каналов и сообществ.
            </p>
          </div>
          <div className={styles.galleryGrid}>
            {galleryItems.map((item) => (
              <figure key={item.id} className={styles.galleryCard}>
                <img src={item.image} alt={`Пример дизайна: ${item.title}`} loading="lazy" />
                <figcaption>{item.title}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.advantagesSection} aria-labelledby="advantages-heading">
        <div className="container">
          <div className={styles.sectionHeaderCentered}>
            <h2 id="advantages-heading" className={styles.sectionTitle}>
              Почему выбирают VideoCoversPro
            </h2>
            <p className={styles.sectionDescriptionCentered}>
              Мы создаем дизайн-решения, которые работают на рост охватов и помогут вашему бренду выделиться в информационном шуме.
            </p>
          </div>
          <div className={styles.advantagesGrid}>
            {advantages.map((item) => (
              <div key={item.title} className={styles.advantageCard}>
                <div className={styles.advantageIcon} aria-hidden="true">
                  {item.icon}
                </div>
                <h3 className={styles.advantageTitle}>{item.title}</h3>
                <p className={styles.advantageText}>{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-labelledby="testimonials-heading">
        <div className="container">
          <div className={styles.testimonialsWrapper}>
            <div className={styles.sectionHeader}>
              <h2 id="testimonials-heading" className={styles.sectionTitle}>
                Отзывы авторов и команд
              </h2>
              <p className={styles.sectionDescription}>
                Вдохновляемся обратной связью и продолжаем развивать каталог, учитывая требования к современному контенту.
              </p>
            </div>
            <div className={styles.testimonialCard} aria-live="polite">
              <div className={styles.testimonialHeader}>
                <img
                  src={testimonials[activeTestimonial].avatar}
                  alt={`Фото клиента ${testimonials[activeTestimonial].name}`}
                  className={styles.testimonialAvatar}
                  loading="lazy"
                />
                <div>
                  <span className={styles.testimonialName}>{testimonials[activeTestimonial].name}</span>
                  <span className={styles.testimonialRole}>{testimonials[activeTestimonial].role}</span>
                </div>
              </div>
              <p className={styles.testimonialQuote}>“{testimonials[activeTestimonial].quote}”</p>
              <div className={styles.testimonialControls}>
                <button
                  type="button"
                  className={styles.controlButton}
                  onClick={() =>
                    setActiveTestimonial(
                      (activeTestimonial - 1 + testimonials.length) % testimonials.length
                    )
                  }
                  aria-label="Предыдущий отзыв"
                >
                  ←
                </button>
                <button
                  type="button"
                  className={styles.controlButton}
                  onClick={() =>
                    setActiveTestimonial((activeTestimonial + 1) % testimonials.length)
                  }
                  aria-label="Следующий отзыв"
                >
                  →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.projectsSection} aria-labelledby="projects-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="projects-heading" className={styles.sectionTitle}>
              Кейсы и подборки
            </h2>
            <p className={styles.sectionDescription}>
              Фильтруйте проекты по платформам и жанрам, чтобы увидеть, как наши коллекции помогают брендам расти.
            </p>
          </div>

          <div className={styles.filterBar} role="tablist" aria-label="Фильтр по платформам">
            {['Все', 'YouTube', 'Twitch', 'VK', 'Telegram'].map((filter) => (
              <button
                key={filter}
                type="button"
                role="tab"
                aria-selected={activeFilter === filter}
                className={`${styles.filterButton} ${activeFilter === filter ? styles.filterActive : ''}`}
                onClick={() => setActiveFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>

          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.id} className={styles.projectCard}>
                <img src={project.image} alt={project.title} loading="lazy" />
                <div className={styles.projectContent}>
                  <span className={styles.projectTag}>{project.category}</span>
                  <h3 className={styles.projectTitle}>{project.title}</h3>
                  <p className={styles.projectText}>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq-heading">
        <div className="container">
          <div className={styles.sectionHeaderCentered}>
            <h2 id="faq-heading" className={styles.sectionTitle}>
              Ответы на популярные вопросы
            </h2>
            <p className={styles.sectionDescriptionCentered}>
              Если не нашли нужную информацию — напишите нам, и команда поддержки подскажет оптимальное решение.
            </p>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <div key={item.question} className={styles.faqItem}>
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={openedFaq === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{openedFaq === index ? '−' : '+'}</span>
                </button>
                {openedFaq === index && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blogSection} aria-labelledby="blog-heading">
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 id="blog-heading" className={styles.sectionTitle}>
              Гайды и практические материалы
            </h2>
            <p className={styles.sectionDescription}>
              Подборка статей о визуальной коммуникации, трендах стриминга и оптимизации контента под разные платформы.
            </p>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.id} className={styles.blogCard}>
                <img src={post.image} alt={post.title} loading="lazy" />
                <div className={styles.blogContent}>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to="/services" className={styles.blogLink}>
                    Читать рекомендации →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Готовы обновить визуал канала?</h2>
          <p>
            Выберите коллекцию из каталога или запросите индивидуальную подборку. Команда VideoCoversPro подготовит дизайн, который усилит ваш бренд.
          </p>
          <div className={styles.ctaActions}>
            <Link to="/contact" className={styles.primaryButton}>
              Связаться с нами
            </Link>
            <Link to="/catalog" className={styles.secondaryButton}>
              Смотреть каталог
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;