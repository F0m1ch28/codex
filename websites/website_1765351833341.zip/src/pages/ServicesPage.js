import React from 'react';
import { Link } from 'react-router-dom';
import MetaTags from '../components/MetaTags';
import styles from './ServicesPage.module.css';

const ServicesPage = () => {
  const services = [
    {
      title: 'Полный визуальный ребрендинг',
      description:
        'Аудит текущего оформления, разработка обновленных обложек, баннеров, аватарок и пакетов для соцсетей в едином стиле.',
      deliverables: ['Moodboard и концепция', 'Обложки для 5 серий', 'Пакет статичных и анимированных баннеров'],
      image: 'https://picsum.photos/900/600?random=381'
    },
    {
      title: 'Стартовый комплект стримера',
      description:
        'Готовим уникальный набор оверлеев, экранов, панелей и алертов под вашу тематику и технические требования.',
      deliverables: ['Оверлеи для 3 сцен', 'Интерактивные плашки', 'Настройки OBS/Streamlabs'],
      image: 'https://picsum.photos/900/600?random=382'
    },
    {
      title: 'SMM-пакет для соцсетей',
      description:
        'Создаем адаптированные шаблоны для VK, Telegram и Instagram, учитывая tone of voice и визуальные особенности бренда.',
      deliverables: ['Шаблоны постов и сторис', 'Анимация для Reels', 'Гайд по использованию'],
      image: 'https://picsum.photos/900/600?random=383'
    }
  ];

  return (
    <>
      <MetaTags
        title="Индивидуальные услуги — VideoCoversPro"
        description="Закажите индивидуальные дизайн-пакеты: ребрендинг, оверлеи для стримов, комплект графики для соцсетей."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Индивидуальные дизайн-услуги</h1>
          <p>
            Когда стандартных шаблонов недостаточно, команда VideoCoversPro подготовит дизайн, созданный специально под ваш бренд.
            Мы учитываем стратегию контента, целевую аудиторию и технические требования платформ.
          </p>
        </div>
      </section>

      <section className={styles.services}>
        <div className="container">
          <div className={styles.grid}>
            {services.map((service) => (
              <article key={service.title} className={styles.card}>
                <img src={service.image} alt={service.title} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{service.title}</h2>
                  <p>{service.description}</p>
                  <ul>
                    {service.deliverables.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className={styles.ctaContent}>
          <h2>Расскажите о своем проекте</h2>
          <p>
            Опишите тематику канала, желаемые форматы и дедлайны — мы подберем команду дизайнеров и предложим план запуска с этапами и контрольными точками.
          </p>
          <Link to="/contact" className={styles.ctaButton}>
            Заполнить бриф
          </Link>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;