import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './VideoCoversPage.module.css';

const VideoCoversPage = () => {
  const items = [
    {
      title: 'Tech Pulse',
      description: 'Контрастные превью с инфографикой и яркими CTA для обзоров гаджетов и технологий.',
      image: 'https://picsum.photos/900/600?random=321',
      tags: ['YouTube', 'Технологии', 'Обзоры']
    },
    {
      title: 'Cinema Stories',
      description: 'Кинематографичные обложки с драматичными переходами и типографикой для рецензий и аналитики.',
      image: 'https://picsum.photos/900/600?random=322',
      tags: ['YouTube', 'Кино', 'Подборки']
    },
    {
      title: 'Gaming Momentum',
      description: 'Динамичные обложки с игровым UI, glow-эффектами и акцентом на персонажей.',
      image: 'https://picsum.photos/900/600?random=323',
      tags: ['YouTube', 'Игры', 'Трансляции']
    },
    {
      title: 'Edu Talks',
      description: 'Минималистичные превью для образовательных роликов, интервью и подкастов.',
      image: 'https://picsum.photos/900/600?random=324',
      tags: ['YouTube', 'Образование', 'Интервью']
    },
    {
      title: 'Lifestyle Motion',
      description: 'Яркие обложки для vlog-контента и рубрик о путешествиях, стиле жизни и мотивации.',
      image: 'https://picsum.photos/900/600?random=325',
      tags: ['YouTube', 'Lifestyle', 'Vlog']
    },
    {
      title: 'Shorts Impact',
      description: 'Вертикальные превью для Shorts и Reels с крупной типографикой и акцентом на внимание.',
      image: 'https://picsum.photos/900/600?random=326',
      tags: ['Shorts', 'Reels', 'Вертикальный формат']
    }
  ];

  return (
    <>
      <MetaTags
        title="Обложки для видео — VideoCoversPro"
        description="Готовые обложки для YouTube, Shorts и Rutube. Премиальные коллекции с акцентом на кликабельность и тренды."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Обложки для видео</h1>
          <p>
            Структурированные наборы превью для YouTube и других платформ. Мы выделяем ключевые элементы ролика,
            поддерживаем ваш брендбук и создаем дизайн, который мотивирует зрителя кликнуть.
          </p>
        </div>
      </section>

      <section className={styles.catalog}>
        <div className="container">
          <div className={styles.grid}>
            {items.map((item) => (
              <article key={item.title} className={styles.card}>
                <img src={item.image} alt={`Обложка: ${item.title}`} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{item.title}</h2>
                  <p>{item.description}</p>
                  <div className={styles.tags}>
                    {item.tags.map((tag) => (
                      <span key={tag}>{tag}</span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.note}>
        <div className={styles.noteContent}>
          <h2>Индивидуальная адаптация под ваш канал</h2>
          <p>
            Нужны уникальные обложки с интеграцией логотипа, сложной композиции или серийного дизайна? Свяжитесь с нами,
            и мы подготовим индивидуальный пакет с учетом тематики, графика публикаций и tone of voice.
          </p>
        </div>
      </section>
    </>
  );
};

export default VideoCoversPage;