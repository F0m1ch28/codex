import React, { useState } from 'react';
import MetaTags from '../components/MetaTags';
import styles from './ContactPage.module.css';

const ContactPage = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    platform: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const nextErrors = {};
    if (!form.name.trim()) nextErrors.name = 'Введите ваше имя или название проекта.';
    if (!form.email.trim()) {
      nextErrors.email = 'Укажите рабочий email.';
    } else if (!/^[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}$/.test(form.email)) {
      nextErrors.email = 'Введите корректный email.';
    }
    if (!form.message.trim()) nextErrors.message = 'Опишите задачу или запрос.';
    return nextErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmitted(true);
      setForm({
        name: '',
        email: '',
        platform: '',
        message: ''
      });
    }
  };

  return (
    <>
      <MetaTags
        title="Контакты — VideoCoversPro"
        description="Свяжитесь с командой VideoCoversPro для индивидуальных проектов или вопросов по каталогу."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Связаться с нами</h1>
          <p>
            Расскажите о проекте или задайте вопрос. Мы ответим на письмо в течение одного рабочего дня и предложим следующий шаг.
          </p>
        </div>
      </section>

      <section className={styles.contact}>
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate>
              <div className={styles.field}>
                <label htmlFor="name">Имя или название проекта</label>
                <input
                  id="name"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Например, канал TechLine"
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="email">Рабочий email</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>

              <div className={styles.field}>
                <label htmlFor="platform">Платформы</label>
                <input
                  id="platform"
                  name="platform"
                  value={form.platform}
                  onChange={handleChange}
                  placeholder="YouTube, Twitch, VK ..."
                />
              </div>

              <div className={styles.field}>
                <label htmlFor="message">Описание задачи</label>
                <textarea
                  id="message"
                  name="message"
                  rows={6}
                  value={form.message}
                  onChange={handleChange}
                  placeholder="Расскажите о цели проекта, дедлайне и желаемом стиле."
                />
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>

              <button type="submit" className={styles.button}>
                Отправить сообщение
              </button>

              {submitted && (
                <p className={styles.success}>
                  Спасибо! Мы получили ваше сообщение и ответим по адресу электронной почты.
                </p>
              )}
            </form>

            <aside className={styles.info}>
              <div className={styles.infoCard}>
                <h2>График поддержки</h2>
                <p>Понедельник — пятница, 09:00 – 21:00 (GMT+3)</p>
              </div>
              <div className={styles.infoCard}>
                <h2>Контакт по email</h2>
                <a href="mailto:support@videocoverspro.com" className={styles.email}>
                  support@videocoverspro.com
                </a>
              </div>
              <div className={styles.infoCard}>
                <h2>Чем мы можем помочь</h2>
                <ul>
                  <li>Подбор коллекций под тематику канала</li>
                  <li>Индивидуальные дизайн-проекты</li>
                  <li>Вопросы по лицензии и использованию</li>
                  <li>Техническая поддержка по шаблонам</li>
                </ul>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;