import React from 'react';
import MetaTags from '../components/MetaTags';
import styles from './StreamBannersPage.module.css';

const StreamBannersPage = () => {
  const kits = [
    {
      title: 'Cyber Arena',
      description: 'Полный набор для киберспортивных трансляций: стартовые экраны, счётчики и плашки спонсоров.',
      image: 'https://picsum.photos/900/600?random=361',
      includes: ['Панели Twitch', 'Starting soon', 'Оверлей чата']
    },
    {
      title: 'Cozy Stream',
      description: 'Теплые оттенки, иллюстрации и плавная типографика для ламповых стримов и IRL-каналов.',
      image: 'https://picsum.photos/900/600?random=362',
      includes: ['Ending soon', 'Alerts', 'Интермиссия']
    },
    {
      title: 'Neon Beat',
      description: 'Яркий неон и glitch-эффекты для музыкальных и DJ-стримов. Поддержка анимированных элементов.',
      image: 'https://picsum.photos/900/600?random=363',
      includes: ['Animated overlay', 'Плашки донатов', 'Паки иконок']
    }
  ];

  return (
    <>
      <MetaTags
        title="Баннеры и оверлеи для стримов — VideoCoversPro"
        description="Готовые оверлеи, баннеры и панели для Twitch, YouTube Live и Kick. Профессиональные комплекты с инструкциями."
      />
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Баннеры и оверлеи для стримов</h1>
          <p>
            Комбинируйте дизайнерские элементы, чтобы создать атмосферу канала. Мы готовим комплекты для Twitch, YouTube
            и других платформ, включая статичные и анимированные элементы.
          </p>
        </div>
      </section>

      <section className={styles.kits}>
        <div className="container">
          <div className={styles.grid}>
            {kits.map((kit) => (
              <article key={kit.title} className={styles.card}>
                <img src={kit.image} alt={`Баннеры: ${kit.title}`} loading="lazy" />
                <div className={styles.cardContent}>
                  <h2>{kit.title}</h2>
                  <p>{kit.description}</p>
                  <ul>
                    {kit.includes.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.support}>
        <div className={styles.supportContent}>
          <h2>Помогаем интегрировать дизайн в ваш стрим</h2>
          <p>
            Получите инструкции по настройке в OBS Studio и Streamlabs, рекомендации по сценам и чеклист готовности
            трансляции. Команда поддержки ответит на вопросы в течение 24 часов.
          </p>
        </div>
      </section>
    </>
  );
};

export default StreamBannersPage;