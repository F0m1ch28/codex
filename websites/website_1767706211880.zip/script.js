(function () {
    function qs(selector, scope) {
        return (scope || document).querySelector(selector);
    }
    function qsa(selector, scope) {
        return Array.prototype.slice.call((scope || document).querySelectorAll(selector));
    }

    document.addEventListener("DOMContentLoaded", function () {
        var navToggle = qs(".nav-toggle");
        var navMenu = qs(".main-nav");

        if (navToggle && navMenu) {
            navToggle.addEventListener("click", function () {
                var expanded = navToggle.getAttribute("aria-expanded") === "true";
                navToggle.setAttribute("aria-expanded", String(!expanded));
                navMenu.classList.toggle("active");
            });
        }

        var cookieBanner = qs("#cookie-banner");
        var acceptBtn = qs("#cookie-accept");
        var declineBtn = qs("#cookie-decline");
        var consentState = localStorage.getItem("ckg_cookie_consent");

        function hideBanner() {
            if (cookieBanner) {
                cookieBanner.classList.remove("active");
            }
        }

        if (cookieBanner) {
            if (!consentState) {
                cookieBanner.classList.add("active");
            }

            if (acceptBtn) {
                acceptBtn.addEventListener("click", function () {
                    localStorage.setItem("ckg_cookie_consent", "accepted");
                    hideBanner();
                });
            }

            if (declineBtn) {
                declineBtn.addEventListener("click", function () {
                    localStorage.setItem("ckg_cookie_consent", "declined");
                    hideBanner();
                });
            }
        }

        var faqButtons = qsa(".faq-item button");
        faqButtons.forEach(function (btn) {
            btn.addEventListener("click", function () {
                var expanded = btn.getAttribute("aria-expanded") === "true";
                faqButtons.forEach(function (other) {
                    if (other !== btn) {
                        other.setAttribute("aria-expanded", "false");
                        var otherContent = qs("#" + other.getAttribute("aria-controls"));
                        if (otherContent) {
                            otherContent.style.display = "none";
                        }
                    }
                });
                btn.setAttribute("aria-expanded", String(!expanded));
                var content = qs("#" + btn.getAttribute("aria-controls"));
                if (content) {
                    content.style.display = expanded ? "none" : "block";
                }
            });
        });

        var insightButtons = qsa(".insight-trigger button");
        var indicatorValue = qs("#indicator-value");
        var indicatorTitle = qs("#indicator-title");

        var dataset = {
            renewables: {
                label: "Renewable Capacity Allocation",
                value: "64% of new Iberian projects rated resilient, led by offshore integration corridors."
            },
            tourism: {
                label: "Tourism Resilience Outlook",
                value: "42% growth in premium hospitality pipelines anchored in Lisbon and Porto metropolitan zones."
            },
            technology: {
                label: "Technology Scaling Momentum",
                value: "Portugal-based scale-ups attract 28% annualised capital inflows from cross-border co-financing."
            }
        };

        insightButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                var key = button.getAttribute("data-key");
                if (dataset[key] && indicatorValue && indicatorTitle) {
                    indicatorTitle.textContent = dataset[key].label;
                    indicatorValue.textContent = dataset[key].value;
                }
                insightButtons.forEach(function (btn) {
                    btn.classList.remove("active");
                });
                button.classList.add("active");
            });
        });

        var contactForm = qs("#contact-form");
        if (contactForm) {
            contactForm.addEventListener("submit", function (e) {
                var nameField = qs("#name");
                var emailField = qs("#email");
                var messageField = qs("#message");
                var consentBox = qs("#consent");

                if (!nameField.value.trim()) {
                    alert("Please provide your full name.");
                    nameField.focus();
                    e.preventDefault();
                    return;
                }

                if (!emailField.value.trim()) {
                    alert("Please provide your email address.");
                    emailField.focus();
                    e.preventDefault();
                    return;
                }

                if (!/\S+@\S+\.\S+/.test(emailField.value)) {
                    alert("Kindly enter a valid email address.");
                    emailField.focus();
                    e.preventDefault();
                    return;
                }

                if (!messageField.value.trim()) {
                    alert("Please summarise your requirements.");
                    messageField.focus();
                    e.preventDefault();
                    return;
                }

                if (!consentBox.checked) {
                    alert("Please confirm consent to proceed.");
                    consentBox.focus();
                    e.preventDefault();
                }
            });
        }
    });
})();