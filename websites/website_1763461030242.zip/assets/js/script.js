document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.getElementById('nav-menu');
    const scrollBtn = document.getElementById('scrollToTop');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const contactForm = document.getElementById('contactForm');
    const formStatus = contactForm ? contactForm.querySelector('.form-status') : null;

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true' || false;
            navToggle.setAttribute('aria-expanded', !expanded);
            navMenu.classList.toggle('open');
        });
    }

    if (navMenu) {
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('open');
                if (navToggle) {
                    navToggle.setAttribute('aria-expanded', 'false');
                }
                window.scrollTo({ top: 0, behavior: 'instant' });
            });
        });
    }

    const handleScroll = () => {
        if (window.scrollY > 400) {
            scrollBtn.classList.add('show');
        } else {
            scrollBtn.classList.remove('show');
        }
    };

    window.addEventListener('scroll', handleScroll);

    scrollBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    const consent = localStorage.getItem('nvaCookieConsent');
    if (!consent && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('nvaCookieConsent', 'accepted');
            cookieBanner.classList.remove('active');
        });
    }

    const yearSpan = document.getElementById('currentYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (contactForm && formStatus) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const isValid = contactForm.checkValidity();
            if (!isValid) {
                contactForm.reportValidity();
                return;
            }
            formStatus.textContent = 'Thank you for reaching out. Our team will respond once contact details are finalized with the client.';
            contactForm.reset();
        });
    }
});