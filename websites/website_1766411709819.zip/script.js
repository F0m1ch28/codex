document.addEventListener('DOMContentLoaded', function () {
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('nav-open');
      menuToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (navLinks.classList.contains('nav-open')) {
          navLinks.classList.remove('nav-open');
          menuToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  const banner = document.querySelector('.cookie-banner');
  if (banner) {
    const acceptBtn = banner.querySelector('[data-consent="accept"]');
    const declineBtn = banner.querySelector('[data-consent="decline"]');
    const storageKey = 'assistaCookieConsent';
    const existing = localStorage.getItem(storageKey);

    if (existing) {
      banner.classList.add('hidden');
    }

    const setConsent = (value) => {
      localStorage.setItem(storageKey, value);
      banner.classList.add('hidden');
    };

    acceptBtn?.addEventListener('click', () => setConsent('accepted'));
    declineBtn?.addEventListener('click', () => setConsent('declined'));
  }
});