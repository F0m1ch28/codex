document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.getElementById('primary-nav');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.dataset.visible = String(!expanded);
    });
    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          navToggle.setAttribute('aria-expanded', 'false');
          primaryNav.dataset.visible = 'false';
        }
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (!cookieBanner) return;

  const acceptBtn = cookieBanner.querySelector('[data-cookie-accept]');
  const declineBtn = cookieBanner.querySelector('[data-cookie-decline]');
  const savedPreference = localStorage.getItem('alpha-cookie-preference');

  const hideBanner = () => {
    cookieBanner.dataset.visible = 'false';
    cookieBanner.style.pointerEvents = 'none';
  };

  if (!savedPreference) {
    requestAnimationFrame(() => {
      cookieBanner.dataset.visible = 'true';
    });
  } else {
    hideBanner();
  }

  acceptBtn?.addEventListener('click', () => {
    localStorage.setItem('alpha-cookie-preference', 'accepted');
    hideBanner();
  });

  declineBtn?.addEventListener('click', () => {
    localStorage.setItem('alpha-cookie-preference', 'declined');
    hideBanner();
  });
});