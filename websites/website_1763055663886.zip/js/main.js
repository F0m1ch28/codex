document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const mainNav = document.querySelector(".main-nav");

    if (navToggle) {
        navToggle.addEventListener("click", () => {
            const expanded = navToggle.getAttribute("aria-expanded") === "true";
            navToggle.setAttribute("aria-expanded", String(!expanded));
            navToggle.classList.toggle("open");
            mainNav.classList.toggle("open");
        });

        mainNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                navToggle.setAttribute("aria-expanded", "false");
                navToggle.classList.remove("open");
                mainNav.classList.remove("open");
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        });
    }

    const scrollBtn = document.getElementById("scrollTopBtn");
    if (scrollBtn) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 300) {
                scrollBtn.classList.add("show");
            } else {
                scrollBtn.classList.remove("show");
            }
        });

        scrollBtn.addEventListener("click", () => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const cookieAccept = document.getElementById("cookieAccept");
    const cookieDecline = document.getElementById("cookieDecline");
    const cookieConsent = localStorage.getItem("consonraCookieConsent");

    if (cookieBanner && !cookieConsent) {
        cookieBanner.classList.remove("hidden");
    } else if (cookieBanner) {
        cookieBanner.classList.add("hidden");
    }

    const closeBanner = (choice) => {
        localStorage.setItem("consonraCookieConsent", choice);
        cookieBanner.classList.add("hidden");
    };

    if (cookieAccept) {
        cookieAccept.addEventListener("click", () => closeBanner("accepted"));
    }

    if (cookieDecline) {
        cookieDecline.addEventListener("click", () => closeBanner("declined"));
    }

    const yearSpan = document.getElementById("year");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    const contactForm = document.getElementById("contactForm");
    const formResponse = document.getElementById("formResponse");
    if (contactForm) {
        contactForm.addEventListener("submit", (event) => {
            event.preventDefault();
            if (formResponse) {
                formResponse.textContent = "Thank you for reaching out. Our team will contact you shortly.";
            }
            contactForm.reset();
        });
    }
});