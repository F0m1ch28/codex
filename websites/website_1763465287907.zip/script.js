document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-navigation');
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      primaryNav.classList.toggle('is-visible');
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        primaryNav.classList.remove('is-visible');
      });
    });
  }

  const scrollBtn = document.getElementById('scrollTopBtn');
  if (scrollBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 300) {
        scrollBtn.classList.add('show');
      } else {
        scrollBtn.classList.remove('show');
      }
    });

    scrollBtn.addEventListener('click', event => {
      event.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptCookiesBtn = document.querySelector('#acceptCookies');

  if (cookieBanner && acceptCookiesBtn) {
    const consent = localStorage.getItem('borealCookieConsent');
    if (consent === 'accepted') {
      cookieBanner.classList.add('is-hidden');
    }

    acceptCookiesBtn.addEventListener('click', () => {
      localStorage.setItem('borealCookieConsent', 'accepted');
      cookieBanner.classList.add('is-hidden');
    });
  }

  const yearSpan = document.getElementById('currentYear');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
});