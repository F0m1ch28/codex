document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");

  if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const acceptCookies = document.getElementById("acceptCookies");
  const declineCookies = document.getElementById("declineCookies");
  const consentKey = "mei-cookie-consent";

  function hideBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add("hidden");
    }
  }

  function showBanner() {
    if (cookieBanner && !localStorage.getItem(consentKey)) {
      cookieBanner.classList.remove("hidden");
    }
  }

  if (acceptCookies) {
    acceptCookies.addEventListener("click", () => {
      localStorage.setItem(consentKey, "accepted");
      hideBanner();
    });
  }

  if (declineCookies) {
    declineCookies.addEventListener("click", () => {
      localStorage.setItem(consentKey, "declined");
      hideBanner();
    });
  }

  showBanner();

  const body = document.body;
  const currentPage = body.getAttribute("data-page");

  if (currentPage === "posts") {
    const searchInput = document.getElementById("searchPosts");
    const categoryFilter = document.getElementById("categoryFilter");
    const regionFilter = document.getElementById("regionFilter");
    const postsGrid = document.getElementById("postsGrid");
    const prevPageBtn = document.getElementById("prevPage");
    const nextPageBtn = document.getElementById("nextPage");
    const paginationInfo = document.getElementById("paginationInfo");
    const postsPerPage = 6;
    let currentPageIndex = 1;

    const allPosts = postsGrid ? Array.from(postsGrid.querySelectorAll(".post-card")) : [];

    function applyFilters() {
      const term = searchInput ? searchInput.value.trim().toLowerCase() : "";
      const category = categoryFilter ? categoryFilter.value : "all";
      const region = regionFilter ? regionFilter.value : "all";

      return allPosts.filter((card) => {
        const title = card.querySelector(".card-title") ? card.querySelector(".card-title").textContent.toLowerCase() : "";
        const excerpt = card.querySelector(".card-excerpt") ? card.querySelector(".card-excerpt").textContent.toLowerCase() : "";
        const matchesTerm = term === "" || title.includes(term) || excerpt.includes(term);
        const matchesCategory = category === "all" || card.dataset.category === category;
        const matchesRegion = region === "all" || card.dataset.region === region;
        return matchesTerm && matchesCategory && matchesRegion;
      });
    }

    function renderPosts() {
      const filteredPosts = applyFilters();
      const totalPages = Math.max(1, Math.ceil(filteredPosts.length / postsPerPage));
      if (currentPageIndex > totalPages) currentPageIndex = totalPages;

      allPosts.forEach((card) => {
        card.style.display = "none";
      });

      const start = (currentPageIndex - 1) * postsPerPage;
      const end = start + postsPerPage;
      const visiblePosts = filteredPosts.slice(start, end);
      visiblePosts.forEach((card) => {
        card.style.display = "";
      });

      if (prevPageBtn) prevPageBtn.disabled = currentPageIndex <= 1;
      if (nextPageBtn) nextPageBtn.disabled = currentPageIndex >= totalPages;
      if (paginationInfo) paginationInfo.textContent = `Page ${currentPageIndex} of ${totalPages}`;
    }

    if (searchInput) {
      searchInput.addEventListener("input", () => {
        currentPageIndex = 1;
        renderPosts();
      });
    }

    if (categoryFilter) {
      categoryFilter.addEventListener("change", () => {
        currentPageIndex = 1;
        renderPosts();
      });
    }

    if (regionFilter) {
      regionFilter.addEventListener("change", () => {
        currentPageIndex = 1;
        renderPosts();
      });
    }

    if (prevPageBtn) {
      prevPageBtn.addEventListener("click", () => {
        if (currentPageIndex > 1) {
          currentPageIndex--;
          renderPosts();
        }
      });
    }

    if (nextPageBtn) {
      nextPageBtn.addEventListener("click", () => {
        currentPageIndex++;
        renderPosts();
      });
    }

    renderPosts();
  }

  if (currentPage === "contact") {
    const form = document.getElementById("contactForm");
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const messageInput = document.getElementById("message");
    const nameError = document.getElementById("nameError");
    const emailError = document.getElementById("emailError");
    const messageError = document.getElementById("messageError");

    function validateEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    if (form) {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        let valid = true;

        if (nameInput && nameError) {
          if (nameInput.value.trim() === "") {
            nameError.classList.add("active");
            valid = false;
          } else {
            nameError.classList.remove("active");
          }
        }

        if (emailInput && emailError) {
          if (!validateEmail(emailInput.value.trim())) {
            emailError.classList.add("active");
            valid = false;
          } else {
            emailError.classList.remove("active");
          }
        }

        if (messageInput && messageError) {
          if (messageInput.value.trim() === "") {
            messageError.classList.add("active");
            valid = false;
          } else {
            messageError.classList.remove("active");
          }
        }

        if (valid) {
          window.location.href = "thanks.html";
        }
      });

      [nameInput, emailInput, messageInput].forEach((input) => {
        if (!input) return;
        input.addEventListener("input", () => {
          const errorElement = document.getElementById(`${input.id}Error`);
          if (errorElement && input.value.trim() !== "") {
            errorElement.classList.remove("active");
          }
        });
      });
    }
  }
});