...
```

Let's create.

Then proceed to components etc.

Now we must craft actual code for each file.

Let's design modules.

### Build components.

Let's start customizing.

**Header.js**.

Need to import NavLink. etc.

**Header.module.css**.

Define necessary.

**Footer**.

**CookieBanner**.

**ScrollToTop**.

**HomePage** etc.

Need to produce textual content.

While writing modules we need to ensure no banned words.

Also alt.

Let's craft abiding.

Will take time.

Let's craft each file one by one.

---

**Detailed content**:

Let's plan page content.

**HomePage**:

Add hero.

Set hero image constant:

`const heroImage = 'https://picsum.photos/1600/900?random=11';` etc.

Add arrays.

Examples:

```
const statsData = [
  { value: 1200, suffix: '+', label: 'Ore di laboratorio guidato' },
  { value: 150, suffix: '+', label: 'Partner e mentor coinvolti' },
  { value: 92, suffix: '%', label: 'Placement in aziende digitali' },
  { value: 18, suffix: '', label: 'Edizioni completate' }
];
```

Course cards:

```
const courseCards = [
 { title: 'Pubblicità Targetizzata', description: 'Struttura avanzata di campagne su Facebook, Instagram e Google Ads con focus su segmentazione e ottimizzazione dati.', icon: '🎯' },
 ...
]
```

Need to ensure we mention targeted.

Process steps data with step number etc.

Features (why choose us) maybe 4 features.

Testimonials array with quote etc.

Team preview with name, role, highlight.

Projects array.

```
const projects = [
 { id:1, category:'Pubblicità', title:'Campagna omnicanale per fashion brand', description:'Team studenti ha integrato analytics, creatività e marketing automation.', image:'https://picsum.photos/1200/800?random=41' },
 { id:2, category:'Coding', title:'Piattaforma web per eventi tech', description:'Progetto React con API headless e design system modulare.', image:'https://picsum.photos/1200/800?random=42' },
 { id:3, category:'Social Media', title:'Strategia contenuti per startup green', description:'Calendarizzazione, storytelling e misurazione KPI su Instagram e LinkedIn.', image:'https://picsum.photos/1200/800?random=43' },
 { id:4, category:'Coding', title:'Dashboard analytics marketing', description:'Visualizzazione dati real-time con integrazione BigQuery.', image:'https://picsum.photos/1200/800?random=44' },
 { id:5, category:'Pubblicità', title:'Ottimizzazione funnel e retargeting', ... random=45 }
]
```

Filters: `'Tutti', 'Pubblicità', 'Coding', 'Social Media'`.

FAQ data.

```
const faqData = [
 { question: 'Quanto tempo devo dedicare ogni settimana?', answer: 'Suggeriamo un impegno di 6-8 ore per seguire le lezioni live...' } etc.
```

Blog posts:

```
const blogPosts = [
 { id:1, title:'Trend ADV 2024', description:'', date:'Marzo 2024', image:'https://picsum.photos/800/600?random=51' } etc
]
```

Need to ensure text in Italian.

In CTA section final message.

Add button linking to /contatti.

Add "Inizia Oggi".

In hero there is CTA button.

Add Program? degrade.

Need to ensure `data-animate`.

Add hooking:

```
useEffect(() => {
  const elements = document.querySelectorAll('[data-animate]');
  ...
}, []);
```

But to avoid hooking multiple times when navigating? Should be fine.

Remember to cleanup.

Return overall.

Shots.

Ok.

**ChiSiamoPage**: Provide hero, mission, values etc.

**CorsiPage**: Provide details plus modules.

**ProgrammaPage**: Provide timeline.

**Docenti**: Provide list with details.

**Contatti**: Provide contact info and form.

**Termini** etc.

Need to create CSS modules for each.

### CSS modules styling.

Large abiding.

Need to ensure splitted.

Let's craft.

Given time, we must craft actual code.

Will proceed to produce final message with all code.

This is big but manageable.

Let's start writing final message carefully.

I'll rewrite entire final message to ensure no mistakes. Provide all files in order.

Let's start final message (complete). Need to ensure new final message includes all necessary.

Here we go.

(Remember to include correct App code etc). Ensure no duplicates.

Let's start.

```text