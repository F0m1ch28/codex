import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const STORAGE_KEY = 'gt-cookie-consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, 'accepted');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie consent banner">
      <div className={styles.content}>
        <p className={styles.message}>
          We use cookies to deliver a tailored experience, analyze traffic, and support our sustainability commitments.
          Review how we use cookies in our <Link to="/cookie-policy" className={styles.link}>Cookie Policy</Link>.
        </p>
        <div className={styles.actions}>
          <button className="btn-secondary" onClick={handleAccept}>
            Accept Cookies
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;