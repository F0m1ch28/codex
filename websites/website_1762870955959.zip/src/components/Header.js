import { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';
import logo from '../assets/logo.svg';

const navLinks = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  {
    label: 'Services',
    to: '/services',
    subLinks: [
      { label: 'Sustainable Solutions', to: '/sustainable-solutions' },
      { label: 'Energy Efficiency', to: '/energy-efficiency' },
      { label: 'Waste Management', to: '/waste-management' }
    ]
  },
  { label: 'Contact', to: '/contact' }
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setMenuOpen((prev) => !prev);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} aria-label="Primary navigation">
      <div className="container">
        <div className={styles.inner}>
          <Link to="/" className={styles.brand}>
            <img src={logo} alt="GreenTech Solutions logo" className={styles.logo} />
            <span className={styles.brandText}>
              <span className={styles.brandTitle}>GreenTech Solutions</span>
              <span className={styles.brandTagline}>Sustainable Technology Experts</span>
            </span>
          </Link>
          <nav className={`${styles.nav} ${menuOpen ? styles.navOpen : ''}`} aria-label="Main navigation">
            <ul className={styles.navList}>
              {navLinks.map((item) => (
                <li key={item.label} className={styles.navItem}>
                  {!item.subLinks ? (
                    <NavLink
                      to={item.to}
                      className={({ isActive }) =>
                        `${styles.navLink} ${isActive ? styles.active : ''}`
                      }
                    >
                      {item.label}
                    </NavLink>
                  ) : (
                    <div className={styles.dropdown}>
                      <NavLink
                        to={item.to}
                        className={({ isActive }) =>
                          `${styles.navLink} ${isActive ? styles.active : ''}`
                        }
                      >
                        {item.label}
                      </NavLink>
                      <ul className={styles.dropdownMenu}>
                        {item.subLinks.map((sub) => (
                          <li key={sub.to}>
                            <NavLink
                              to={sub.to}
                              className={({ isActive }) =>
                                `${styles.dropdownLink} ${isActive ? styles.active : ''}`
                              }
                            >
                              {sub.label}
                            </NavLink>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </li>
              ))}
            </ul>
            <Link to="/contact" className={`${styles.contactCta} btn-primary`}>
              Start a Project
            </Link>
          </nav>
          <button
            className={styles.burger}
            aria-label="Toggle navigation menu"
            aria-expanded={menuOpen}
            onClick={toggleMenu}
          >
            <span className={styles.burgerLine}></span>
            <span className={styles.burgerLine}></span>
            <span className={styles.burgerLine}></span>
          </button>
        </div>
      </div>
    </header>
  );
}

export default Header;