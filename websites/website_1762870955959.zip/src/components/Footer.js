import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className="container">
        <div className={styles.grid}>
          <div className={styles.column}>
            <h3 className={styles.title}>GreenTech Solutions</h3>
            <p className={styles.description}>
              Strategic partner for organizations seeking measurable sustainability gains,
              resilient infrastructure, and future-proof ecological innovation.
            </p>
            <p className={styles.contactItem}>
              <strong>Address:</strong> 123 Eco Avenue, Green City, GC 10101
            </p>
            <p className={styles.contactItem}>
              <strong>Phone:</strong>{' '}
              <a href="tel:+15551234567" className={styles.link}>
                +1 (555) 123-4567
              </a>
            </p>
            <p className={styles.contactItem}>
              <strong>Email:</strong>{' '}
              <a href="mailto:info@greentechsolutions.com" className={styles.link}>
                info@greentechsolutions.com
              </a>
            </p>
          </div>
          <div className={styles.column}>
            <h4 className={styles.subtitle}>Explore</h4>
            <ul className={styles.list}>
              <li><Link className={styles.link} to="/">Home</Link></li>
              <li><Link className={styles.link} to="/about">About</Link></li>
              <li><Link className={styles.link} to="/services">Services Overview</Link></li>
              <li><Link className={styles.link} to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4 className={styles.subtitle}>Solutions</h4>
            <ul className={styles.list}>
              <li><Link className={styles.link} to="/sustainable-solutions">Sustainable Technologies</Link></li>
              <li><Link className={styles.link} to="/energy-efficiency">Energy Efficiency</Link></li>
              <li><Link className={styles.link} to="/waste-management">Waste Management</Link></li>
              <li><a className={styles.link} href="#projects">Impact Projects</a></li>
            </ul>
          </div>
          <div className={styles.column}>
            <h4 className={styles.subtitle}>Policies</h4>
            <ul className={styles.list}>
              <li><Link className={styles.link} to="/terms">Terms of Use</Link></li>
              <li><Link className={styles.link} to="/privacy">Privacy Policy</Link></li>
              <li><Link className={styles.link} to="/cookie-policy">Cookie Policy</Link></li>
            </ul>
            <div className={styles.badge}>
              <span className={styles.badgeIcon} aria-hidden="true">🌿</span>
              <span>Certified Climate Impact Partner</span>
            </div>
          </div>
        </div>
        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} GreenTech Solutions. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;