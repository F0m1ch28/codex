import { Helmet } from 'react-helmet';
import styles from './About.module.css';

function About() {
  return (
    <>
      <Helmet>
        <title>About GreenTech Solutions | Sustainability Consultants</title>
        <meta
          name="description"
          content="Learn about GreenTech Solutions—our mission, leadership, and commitment to advancing sustainable technologies across North America."
        />
      </Helmet>
      <section className={`${styles.hero} section-spacing`}>
        <div className="container">
          <div className={styles.heroGrid}>
            <div>
              <span className="eyebrow">About us</span>
              <h1>Championing science-led sustainability since 2009</h1>
              <p>
                GreenTech Solutions is an interdisciplinary collective of engineers, strategists, and storytellers dedicated
                to helping organizations flourish in a low-carbon world. Our approach bridges technology with human-centered
                change so progress becomes momentum.
              </p>
            </div>
            <div className={styles.heroStats}>
              <div>
                <span>150+</span>
                <p>Sustainability experts across North America</p>
              </div>
              <div>
                <span>48</span>
                <p>Industry awards recognizing climate leadership</p>
              </div>
              <div>
                <span>9.6/10</span>
                <p>Average client experience score</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.mission} section-spacing`}>
        <div className="container">
          <div className={styles.zigzag}>
            <div className={styles.zigzagImage}>
              <img
                src="https://picsum.photos/900/700?random=501"
                alt="GreenTech consultants collaborating on sustainable planning"
                loading="lazy"
              />
            </div>
            <div className={styles.zigzagContent}>
              <h2>Our mission</h2>
              <p>
                We advance resilient futures by activating sustainable technologies that drive prosperity for people and the planet.
                Our teams translate complex challenges into navigable roadmaps grounded in data, community insight, and long-term stewardship.
              </p>
              <div className={styles.valuesGrid}>
                <div>
                  <h3>Integrity</h3>
                  <p>We prioritize transparency and accountability so every recommendation earns trust.</p>
                </div>
                <div>
                  <h3>Innovation</h3>
                  <p>We explore emerging technologies and policy trends to keep solutions adaptive.</p>
                </div>
                <div>
                  <h3>Impact</h3>
                  <p>We measure what matters, ensuring each milestone contributes to meaningful outcomes.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.timeline} section-spacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="eyebrow">Our journey</span>
            <h2>A timeline of sustained progress</h2>
          </div>
          <div className={styles.timelineGrid}>
            <div>
              <span className={styles.year}>2009</span>
              <p>Founded in Green City with a focus on industrial energy efficiency and carbon accounting.</p>
            </div>
            <div>
              <span className={styles.year}>2013</span>
              <p>Expanded into renewable integration and launched first microgrid deployments for remote facilities.</p>
            </div>
            <div>
              <span className={styles.year}>2017</span>
              <p>Introduced circular economy practice, partnering with manufacturers on zero-waste certification.</p>
            </div>
            <div>
              <span className={styles.year}>2021</span>
              <p>Established climate resilience lab, leveraging predictive analytics to protect critical infrastructure.</p>
            </div>
            <div>
              <span className={styles.year}>2024</span>
              <p>Recognized as a top sustainability consultancy across North America by EcoLeaders Index.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.team} section-spacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="eyebrow">Leadership circle</span>
            <h2>Guided by multidisciplinary experts</h2>
          </div>
          <div className={styles.teamGrid}>
            {[
              {
                name: 'Jordan Rivers',
                role: 'Chief Sustainability Officer',
                focus: 'Leads enterprise decarbonization strategies and climate disclosures.',
                image: 'https://picsum.photos/420/420?random=511'
              },
              {
                name: 'Priya Chen',
                role: 'Director of Energy Innovation',
                focus: 'Architects energy efficiency programs and smart infrastructure initiatives.',
                image: 'https://picsum.photos/420/420?random=512'
              },
              {
                name: 'Mateo Alvarez',
                role: 'Circular Economy Strategist',
                focus: 'Reimagines resource systems to minimize waste and maximize value.',
                image: 'https://picsum.photos/420/420?random=513'
              },
              {
                name: 'Sierra Morgan',
                role: 'Head of Community Partnerships',
                focus: 'Builds programs that empower local stakeholders and workforce transformation.',
                image: 'https://picsum.photos/420/420?random=514'
              }
            ].map((leader) => (
              <div key={leader.name} className={styles.teamCard}>
                <img src={leader.image} alt={`${leader.name}, ${leader.role}`} loading="lazy" />
                <h3>{leader.name}</h3>
                <span>{leader.role}</span>
                <p>{leader.focus}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.commitment} section-spacing`}>
        <div className="container">
          <div className={styles.commitmentGrid}>
            <div>
              <h2>Commitment to people and planet</h2>
              <p>
                Every engagement considers long-term resilience, community prosperity, and regenerative ecosystems. Our
                climate commitments include carbon neutrality in operations, equitable supplier partnerships, and ongoing
                education for the next generation of sustainability leaders.
              </p>
            </div>
            <div className={styles.commitmentList}>
              <div>
                <h3>Certified B Corporation</h3>
                <p>Third-party verification of social, environmental, and governance standards.</p>
              </div>
              <div>
                <h3>Science-Based Targets</h3>
                <p>Targets validated to align with the Paris Agreement and 1.5°C pathways.</p>
              </div>
              <div>
                <h3>Community Investment</h3>
                <p>Financial and volunteer support for grassroots resilience initiatives.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default About;