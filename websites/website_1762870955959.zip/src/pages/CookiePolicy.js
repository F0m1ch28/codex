import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | GreenTech Solutions</title>
      </Helmet>
      <section className={`${styles.section} section-spacing`}>
        <div className="container">
          <h1>Cookie Policy</h1>
          <p>Effective date: March 15, 2024</p>
          <h2>What are cookies?</h2>
          <p>
            Cookies are small text files stored on your device when you visit a website. They help us deliver an improved and
            tailored site experience.
          </p>
          <h2>Cookies we use</h2>
          <ul>
            <li><strong>Essential cookies:</strong> Required for website functionality and security.</li>
            <li><strong>Analytics cookies:</strong> Provide aggregated insights on site usage to improve content and performance.</li>
            <li><strong>Preference cookies:</strong> Remember settings such as language and consent elections.</li>
          </ul>
          <h2>Managing cookies</h2>
          <p>
            You can adjust cookie settings through your browser or by clearing your cache. Declining cookies may impact site functionality.
          </p>
          <h2>Contact</h2>
          <p>
            For questions about this policy, please email <a href="mailto:info@greentechsolutions.com">info@greentechsolutions.com</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default CookiePolicy;