import { Helmet } from 'react-helmet';
import styles from './Solutions.module.css';

function EnergyEfficiency() {
  return (
    <>
      <Helmet>
        <title>Energy Efficiency | GreenTech Solutions</title>
        <meta
          name="description"
          content="GreenTech Solutions delivers energy efficiency audits, smart building retrofits, and electrification roadmaps."
        />
      </Helmet>
      <section className={`${styles.hero} section-spacing`}>
        <div className="container">
          <span className="eyebrow">Energy efficiency</span>
          <h1>Optimize energy performance with precision</h1>
          <p>
            From advanced analytics to turnkey implementation, our engineers design efficiency pathways that cut costs,
            reduce emissions, and elevate occupant comfort across portfolios.
          </p>
        </div>
      </section>

      <section className={`${styles.content} section-spacing`}>
        <div className="container">
          <div className={`${styles.zigzag} ${styles.reverse}`}>
            <div className={styles.visual}>
              <img
                src="https://picsum.photos/880/640?random=602"
                alt="Engineers reviewing smart building analytics"
                loading="lazy"
              />
            </div>
            <div className={styles.text}>
              <h2>Energy services</h2>
              <ul>
                <li>ASHRAE-level energy audits and thermal modeling</li>
                <li>Smart building systems and automation deployment</li>
                <li>Electrification planning and renewable integration</li>
                <li>Measurement, verification, and performance dashboards</li>
                <li>Utility incentive sourcing and financing support</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.outcomes} section-spacing`}>
        <div className="container">
          <h2>Deliverables</h2>
          <div className={styles.outcomeGrid}>
            <div>
              <h3>Energy savings roadmap</h3>
              <p>Prioritized project pipeline with ROI modeling and operational guidance.</p>
            </div>
            <div>
              <h3>Integrated controls</h3>
              <p>Automated systems enabling proactive management and predictive maintenance.</p>
            </div>
            <div>
              <h3>Verified performance</h3>
              <p>Continuous monitoring and reporting that sustain results and compliance.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default EnergyEfficiency;