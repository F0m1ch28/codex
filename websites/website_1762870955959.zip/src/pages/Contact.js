import { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  company: '',
  phone: '',
  message: ''
};

function Contact() {
  const [formValues, setFormValues] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const currentErrors = {};
    if (!formValues.name.trim()) currentErrors.name = 'Name is required.';
    if (!formValues.email.trim()) {
      currentErrors.email = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formValues.email.trim())) {
      currentErrors.email = 'Please enter a valid email.';
    }
    if (!formValues.message.trim()) currentErrors.message = 'Please tell us how we can help.';
    return currentErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const currentErrors = validate();
    if (Object.keys(currentErrors).length > 0) {
      setErrors(currentErrors);
      return;
    }
    setSubmitted(true);
    setFormValues(initialState);
  };

  return (
    <>
      <Helmet>
        <title>Contact GreenTech Solutions | Start Your Project</title>
        <meta
          name="description"
          content="Contact GreenTech Solutions to discuss sustainable technologies, energy efficiency strategies, and waste management solutions."
        />
      </Helmet>
      <section className={`${styles.hero} section-spacing`}>
        <div className="container">
          <span className="eyebrow">Contact us</span>
          <h1>Let’s accelerate your sustainability agenda</h1>
          <p>
            Share a few details about your goals and our consultants will reach out to schedule a discovery conversation.
            We typically respond within one business day.
          </p>
        </div>
      </section>

      <section className="section-spacing">
        <div className="container">
          <div className={styles.grid}>
            <form className={styles.form} onSubmit={handleSubmit} noValidate aria-label="Contact GreenTech Solutions">
              <h2>Send us a message</h2>
              {submitted && (
                <div className={styles.success}>
                  Thank you for reaching out! We will connect with you shortly to discuss next steps.
                </div>
              )}
              <div className={styles.field}>
                <label htmlFor="name">Name *</label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formValues.name}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={!!errors.name}
                />
                {errors.name && <span className={styles.error}>{errors.name}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="email">Email *</label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formValues.email}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={!!errors.email}
                />
                {errors.email && <span className={styles.error}>{errors.email}</span>}
              </div>
              <div className={styles.field}>
                <label htmlFor="company">Organization</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  value={formValues.company}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="phone">Phone</label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formValues.phone}
                  onChange={handleChange}
                />
              </div>
              <div className={styles.field}>
                <label htmlFor="message">Message *</label>
                <textarea
                  id="message"
                  name="message"
                  rows="5"
                  value={formValues.message}
                  onChange={handleChange}
                  aria-required="true"
                  aria-invalid={!!errors.message}
                ></textarea>
                {errors.message && <span className={styles.error}>{errors.message}</span>}
              </div>
              <button type="submit" className="btn-primary">
                Submit
              </button>
              <p className={styles.disclaimer}>
                By submitting, you consent to our <a href="/privacy">Privacy Policy</a> and agree to receive relevant updates.
              </p>
            </form>

            <aside className={styles.sidebar}>
              <div className={styles.card}>
                <h2>Visit or call</h2>
                <p>123 Eco Avenue, Green City, GC 10101</p>
                <p>
                  <strong>Phone:</strong>{' '}
                  <a href="tel:+15551234567">+1 (555) 123-4567</a>
                </p>
                <p>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@greentechsolutions.com">info@greentechsolutions.com</a>
                </p>
              </div>
              <div className={styles.card}>
                <h2>Office hours</h2>
                <p>Monday – Friday: 8:30 AM – 6:00 PM</p>
                <p>Saturday: By appointment</p>
                <p>Sunday: Closed</p>
              </div>
              <div className={styles.mapWrapper} aria-label="GreenTech Solutions office location">
                <iframe
                  title="GreenTech Solutions – 123 Eco Avenue"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835434507739!2d144.95373531531574!3d-37.81627974201326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzfCsDQ5JzM4LjYiUyAxNDTCsDU3JzE0LjQiRQ!5e0!3m2!1sen!2sus!4v1618823456789!5m2!1sen!2sus"
                  loading="lazy"
                  allowFullScreen
                ></iframe>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
}

export default Contact;