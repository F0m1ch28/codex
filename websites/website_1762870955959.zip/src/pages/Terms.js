import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function Terms() {
  return (
    <>
      <Helmet>
        <title>Terms of Use | GreenTech Solutions</title>
      </Helmet>
      <section className={`${styles.section} section-spacing`}>
        <div className="container">
          <h1>Terms of Use</h1>
          <p>Last updated: March 15, 2024</p>
          <p>
            These Terms of Use govern your use of the GreenTech Solutions website. By accessing or using the site,
            you agree to these terms. If you do not agree, please do not use the site.
          </p>
          <h2>Use of site</h2>
          <p>
            Content is provided for informational purposes. You may not copy, modify, distribute, or exploit any content without
            written authorization. Unauthorized attempts to upload or change information are prohibited.
          </p>
          <h2>Intellectual property</h2>
          <p>
            All trademarks, logos, and service marks displayed are property of GreenTech Solutions or third parties. Use of these
            marks without prior consent is prohibited.
          </p>
          <h2>Limitation of liability</h2>
          <p>
            GreenTech Solutions is not liable for any damages arising from your use of this website or reliance on its content.
            We do not warrant that the site will be error-free or uninterrupted.
          </p>
          <h2>Governing law</h2>
          <p>
            These terms are governed by the laws of the Province of British Columbia and the laws of Canada applicable therein,
            without regard to conflict of law principles.
          </p>
          <h2>Contact</h2>
          <p>
            Questions about these terms may be directed to{' '}
            <a href="mailto:info@greentechsolutions.com">info@greentechsolutions.com</a>.
          </p>
        </div>
      </section>
    </>
  );
}

export default Terms;