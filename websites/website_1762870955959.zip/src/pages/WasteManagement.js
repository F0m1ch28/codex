import { Helmet } from 'react-helmet';
import styles from './Solutions.module.css';

function WasteManagement() {
  return (
    <>
      <Helmet>
        <title>Waste Management | GreenTech Solutions</title>
        <meta
          name="description"
          content="GreenTech Solutions designs circular waste management programs, zero-waste roadmaps, and resource recovery initiatives."
        />
      </Helmet>
      <section className={`${styles.hero} section-spacing`}>
        <div className="container">
          <span className="eyebrow">Waste management</span>
          <h1>Transform waste streams into resource opportunities</h1>
          <p>
            Our circular economy team redesigns material flows to minimize landfill impact, capture value, and foster
            responsible supply chain partnerships.
          </p>
        </div>
      </section>

      <section className={`${styles.content} section-spacing`}>
        <div className="container">
          <div className={styles.zigzag}>
            <div className={styles.text}>
              <h2>Program focus</h2>
              <ul>
                <li>Zero-waste audits, baseline analysis, and roadmap development</li>
                <li>Organics diversion, composting, and anaerobic digestion planning</li>
                <li>Reverse logistics, reuse systems, and product take-back programs</li>
                <li>Supplier engagement and responsible sourcing alignment</li>
                <li>Certification support (TRUE, ISO 14001, B Corp)</li>
              </ul>
            </div>
            <div className={styles.visual}>
              <img
                src="https://picsum.photos/880/640?random=603"
                alt="Team sorting recyclable materials for circular economy program"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.outcomes} section-spacing`}>
        <div className="container">
          <h2>Impact areas</h2>
          <div className={styles.outcomeGrid}>
            <div>
              <h3>Landfill diversion</h3>
              <p>Roadmaps targeting 90%+ waste diversion across facilities.</p>
            </div>
            <div>
              <h3>Resource recovery</h3>
              <p>Material marketplaces and processing partnerships to capture new value.</p>
            </div>
            <div>
              <h3>Stakeholder engagement</h3>
              <p>Training, communications, and dashboards that keep teams aligned.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default WasteManagement;