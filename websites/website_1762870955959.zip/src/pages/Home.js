import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';

const statsConfig = [
  { label: 'Metric tons of CO₂ mitigated', value: 128, suffix: 'K+' },
  { label: 'Facilities modernized', value: 420, suffix: '' },
  { label: 'Renewable projects delivered', value: 62, suffix: '' },
  { label: 'Client satisfaction score', value: 97, suffix: '%+' }
];

const servicesHighlights = [
  {
    title: 'Integrated Sustainability Roadmaps',
    description:
      'Align corporate goals with data-driven decarbonization strategies, lifecycle assessments, and resilient operations.',
    icon: '🌱'
  },
  {
    title: 'High-Performance Energy Systems',
    description:
      'Drive efficiency with smart building analytics, electrification planning, and renewable procurement modeling.',
    icon: '⚡'
  },
  {
    title: 'Circular Waste & Resource Loops',
    description:
      'Design zero-waste ecosystems, optimize diversion streams, and unlock value from secondary materials.',
    icon: '♻️'
  }
];

const processSteps = [
  {
    step: '01',
    title: 'Discover & Benchmark',
    detail: 'We gather operational data, benchmark current impact, and identify hidden sustainability potential.'
  },
  {
    step: '02',
    title: 'Design & Validate',
    detail: 'Our specialists create scenario models, validate technologies, and scope measurable interventions.'
  },
  {
    step: '03',
    title: 'Deploy & Educate',
    detail: 'We implement solutions, on-board teams, and monitor adoption with transparent dashboards.'
  },
  {
    step: '04',
    title: 'Optimize & Scale',
    detail: 'Continuous improvement ensures savings scale, compliance is maintained, and future goals stay on track.'
  }
];

const testimonials = [
  {
    quote:
      'GreenTech translated our sustainability ambitions into an actionable framework. Twelve months later, we have reduced emissions by 37% without sacrificing productivity.',
    name: 'Alexis Moore',
    role: 'VP Operations, Northern Grid Utilities'
  },
  {
    quote:
      'Their team embedded seamlessly with our facilities staff. Energy retrofits were completed ahead of schedule and the performance dashboards keep our executive team aligned.',
    name: 'Samuel Patel',
    role: 'Director of Sustainability, Cascade Health'
  },
  {
    quote:
      'From zero-waste audits to supplier engagement, GreenTech navigated every milestone with clarity and purpose. Our certification success speaks for itself.',
    name: 'Morgan Ellis',
    role: 'Chief Innovation Officer, TerraFoods'
  }
];

const faqItems = [
  {
    question: 'How does GreenTech Solutions measure sustainability impact?',
    answer:
      'We combine onsite audits, IoT-enabled monitoring, and lifecycle assessments to quantify emissions, waste reduction, and resource efficiencies. Each engagement includes custom dashboards for ongoing visibility.'
  },
  {
    question: 'What industries do you support?',
    answer:
      'Our specialists support manufacturing, healthcare, commercial real estate, higher education, and public agencies—any organization seeking resilient, low-carbon operations.'
  },
  {
    question: 'Do you provide guidance on funding and incentives?',
    answer:
      'Yes. We map financing options, utility incentives, and grants to ensure your project captures every possible benefit while accelerating return on investment.'
  },
  {
    question: 'Can you integrate with existing energy management systems?',
    answer:
      'Absolutely. We ensure interoperability with existing platforms, expand sensor coverage where needed, and streamline reporting to match internal governance standards.'
  }
];

const projectGallery = [
  {
    title: 'Solar Microgrid for Remote Healthcare Network',
    category: 'Renewable Energy',
    description: 'Hybrid solar-plus-storage infrastructure providing uninterrupted power and 68% emissions reduction.',
    image: 'https://picsum.photos/1200/800?random=401'
  },
  {
    title: 'Smart Building Retrofits for Corporate HQ',
    category: 'Energy Efficiency',
    description: 'Advanced controls, heat recovery, and demand analytics delivering 32% energy intensity reduction.',
    image: 'https://picsum.photos/1200/800?random=402'
  },
  {
    title: 'Closed-Loop Manufacturing Initiative',
    category: 'Circular Economy',
    description: 'Waste diversion roadmap enabling 94% material reuse across three production sites.',
    image: 'https://picsum.photos/1200/800?random=403'
  },
  {
    title: 'Resilient Water Stewardship Program',
    category: 'Sustainable Solutions',
    description: 'Rainwater harvesting, smart irrigation, and regenerative landscaping for arid campuses.',
    image: 'https://picsum.photos/1200/800?random=404'
  }
];

const blogPosts = [
  {
    title: 'Designing Carbon-Neutral Campuses With Smart Energy Insights',
    date: 'April 12, 2024',
    excerpt: 'A roadmap for higher education leaders to integrate electrification, renewables, and flexible load management.',
    link: '/energy-efficiency'
  },
  {
    title: 'Circular Waste Systems That Unlock New Revenue Streams',
    date: 'March 28, 2024',
    excerpt: 'How advanced material tracking transforms waste liabilities into enterprise-grade opportunities.',
    link: '/waste-management'
  },
  {
    title: 'Sustainable Infrastructure Trends Shaping 2025',
    date: 'March 05, 2024',
    excerpt: 'From green hydrogen pilots to AI-optimized maintenance, discover the technologies reshaping sustainability.',
    link: '/sustainable-solutions'
  }
];

function Home() {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [animatedStats, setAnimatedStats] = useState(statsConfig.map(() => 0));
  const [faqOpenIndex, setFaqOpenIndex] = useState(0);
  const [projectFilter, setProjectFilter] = useState('All');
  const statsRef = useRef(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasAnimated.current) {
            hasAnimated.current = true;
            const duration = 1400;
            const start = performance.now();
            const animate = (timestamp) => {
              const progress = Math.min((timestamp - start) / duration, 1);
              setAnimatedStats(
                statsConfig.map((stat) => Math.round(stat.value * progress))
              );
              if (progress < 1) requestAnimationFrame(animate);
            };
            requestAnimationFrame(animate);
          }
        });
      },
      { threshold: 0.45 }
    );
    if (statsRef.current) {
      observer.observe(statsRef.current);
    }
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const elements = document.querySelectorAll('[data-animate="fade"]');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.revealVisible);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const filteredProjects =
    projectFilter === 'All'
      ? projectGallery
      : projectGallery.filter((project) => project.category === projectFilter);

  const handleFaqToggle = (index) => {
    setFaqOpenIndex((prev) => (prev === index ? -1 : index));
  };

  return (
    <>
      <Helmet>
        <title>GreenTech Solutions | Sustainable Technologies & Ecological Consulting</title>
        <meta
          name="description"
          content="GreenTech Solutions guides organizations toward sustainable technologies, energy efficiency, and circular waste management with measurable impact."
        />
        <meta
          name="keywords"
          content="sustainable technologies, environmental consulting, energy efficiency, waste management, GreenTech Solutions"
        />
      </Helmet>
      <section className={styles.hero}>
        <div className={`${styles.heroInner} container`}>
          <div className={styles.heroContent} data-animate="fade">
            <span className="eyebrow">Future-Ready Sustainability</span>
            <h1>
              Accelerate Your Transition to <span className={styles.highlight}>Regenerative Operations</span>
            </h1>
            <p>
              GreenTech Solutions partners with forward-looking organizations to implement resilient technologies,
              unlock decarbonization pathways, and cultivate thriving, low-impact ecosystems.
            </p>
            <div className={styles.heroActions}>
              <Link to="/contact" className="btn-primary">
                Schedule a Strategy Session
              </Link>
              <Link to="/about" className="btn-secondary">
                Explore Our Mission
              </Link>
            </div>
            <div className={styles.heroStats}>
              <div>
                <span className={styles.heroStatNumber}>15+</span>
                <span>Years steering sustainability excellence</span>
              </div>
              <div>
                <span className={styles.heroStatNumber}>100%</span>
                <span>Projects aligned with UN SDGs</span>
              </div>
            </div>
          </div>
          <div className={styles.heroVisual} data-animate="fade">
            <img
              src="https://picsum.photos/1600/900?random=101"
              alt="Sustainable technology specialists collaborating in a modern office"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`${styles.statsSection} section-spacing`} ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsConfig.map((stat, index) => (
              <div key={stat.label} className={styles.statCard} data-animate="fade">
                <span className={styles.statNumber}>
                  {animatedStats[index]}
                  {stat.suffix}
                </span>
                <p>{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.aboutSection} section-spacing`} id="about">
        <div className="container">
          <div className={styles.zigzag}>
            <div className={styles.zigzagContent} data-animate="fade">
              <span className="eyebrow">Our Purpose</span>
              <h2>Elevating sustainability ambitions into measurable outcomes</h2>
              <p>
                We believe ecological and economic performance can reinforce one another. By connecting data, technology,
                and people, we orchestrate adaptive strategies that protect natural capital, empower communities, and
                future-proof business growth.
              </p>
              <ul className={styles.pillars}>
                <li>Science-based decision frameworks</li>
                <li>Cross-functional implementation expertise</li>
                <li>Transparent metrics and storytelling</li>
              </ul>
              <Link to="/about" className="btn-link">
                Discover our story →
              </Link>
            </div>
            <div className={styles.zigzagVisual} data-animate="fade">
              <img
                src="https://picsum.photos/800/600?random=202"
                alt="Engineers inspecting sustainable building infrastructure"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.servicesSection} section-spacing`} id="services">
        <div className="container">
          <div className={styles.sectionHeader} data-animate="fade">
            <span className="eyebrow">Core Services</span>
            <h2>Comprehensive sustainability solutions tailored to your operations</h2>
            <p>
              Our multidisciplinary teams combine environmental science, advanced analytics, and stakeholder engagement
              to design holistic programs that unlock resilient value.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesHighlights.map((service) => (
              <article key={service.title} className={styles.serviceCard} data-animate="fade">
                <div className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to="/services" className="btn-link">
                  View scope →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.zigzagSection} section-spacing`}>
        <div className="container">
          <div className={`${styles.zigzag} ${styles.reverse}`}>
            <div className={styles.zigzagContent} data-animate="fade">
              <span className="eyebrow">Why GreenTech</span>
              <h2>Empowering leaders with clarity, confidence, and climate resilience</h2>
              <div className={styles.advantages}>
                <div>
                  <h3>Holistic diagnostics</h3>
                  <p>Pinpoint priority actions with granular assessments across energy, water, waste, and emissions.</p>
                </div>
                <div>
                  <h3>Implementation depth</h3>
                  <p>Certified engineers and project managers guide every phase from design to commissioning.</p>
                </div>
                <div>
                  <h3>Actionable intelligence</h3>
                  <p>Real-time monitoring, ESG reporting, and change management align stakeholders with progress.</p>
                </div>
                <div>
                  <h3>Community impact</h3>
                  <p>Programs elevate workforce engagement, supply chain stewardship, and regional environmental goals.</p>
                </div>
              </div>
            </div>
            <div className={styles.zigzagVisual} data-animate="fade">
              <img
                src="https://picsum.photos/800/600?random=203"
                alt="Two sustainability strategists reviewing data dashboards"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.processSection} section-spacing`} id="process">
        <div className="container">
          <div className={styles.sectionHeader} data-animate="fade">
            <span className="eyebrow">Our Process</span>
            <h2>Collaborative partnership from discovery to continuous optimization</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step) => (
              <div key={step.step} className={styles.processCard} data-animate="fade">
                <span className={styles.processStep}>{step.step}</span>
                <h3>{step.title}</h3>
                <p>{step.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonialsSection} section-spacing`} id="testimonials">
        <div className="container">
          <div className={styles.sectionHeader} data-animate="fade">
            <span className="eyebrow">Voices from partners</span>
            <h2>Trusted by sustainability trailblazers</h2>
          </div>
          <div className={styles.testimonialCarousel} data-animate="fade" aria-live="polite">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`${styles.testimonialCard} ${
                  index === activeTestimonial ? styles.testimonialActive : ''
                }`}
              >
                <p className={styles.testimonialQuote}>{testimonial.quote}</p>
                <div className={styles.testimonialMeta}>
                  <span className={styles.testimonialName}>{testimonial.name}</span>
                  <span className={styles.testimonialRole}>{testimonial.role}</span>
                </div>
              </article>
            ))}
            <div className={styles.testimonialControls}>
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={`${styles.dot} ${index === activeTestimonial ? styles.dotActive : ''}`}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                ></button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.teamSection} section-spacing`} id="team">
        <div className="container">
          <div className={styles.sectionHeader} data-animate="fade">
            <span className="eyebrow">Leadership</span>
            <h2>Meet the experts guiding your sustainability transformation</h2>
          </div>
          <div className={styles.teamGrid}>
            {[
              {
                name: 'Jordan Rivers',
                role: 'Chief Sustainability Officer',
                image: 'https://picsum.photos/400/400?random=301',
                bio: 'Former climate policy advisor, spearheading regenerative initiatives across Fortune 500 portfolios.'
              },
              {
                name: 'Priya Chen',
                role: 'Director of Energy Innovation',
                image: 'https://picsum.photos/400/400?random=302',
                bio: 'Mechanical engineer leading electrification, smart grid integration, and demand management programs.'
              },
              {
                name: 'Mateo Alvarez',
                role: 'Circular Economy Strategist',
                image: 'https://picsum.photos/400/400?random=303',
                bio: 'Specialist in waste-to-resource strategies, supply chain collaboration, and certification pathways.'
              }
            ].map((member) => (
              <div key={member.name} className={styles.teamCard} data-animate="fade">
                <div className={styles.teamImageWrapper}>
                  <img src={member.image} alt={`${member.name}, ${member.role}`} loading="lazy" />
                  <div className={styles.teamOverlay}>
                    <p>{member.bio}</p>
                  </div>
                </div>
                <h3>{member.name}</h3>
                <span>{member.role}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.projectsSection} section-spacing`} id="projects">
        <div className="container">
          <div className={styles.sectionHeader} data-animate="fade">
            <span className="eyebrow">Impact portfolio</span>
            <h2>Projects that align profit with planetary health</h2>
          </div>
          <div className={styles.filters}>
            {['All', 'Renewable Energy', 'Energy Efficiency', 'Circular Economy', 'Sustainable Solutions'].map(
              (filter) => (
                <button
                  key={filter}
                  className={`${styles.filterButton} ${
                    projectFilter === filter ? styles.filterActive : ''
                  }`}
                  onClick={() => setProjectFilter(filter)}
                >
                  {filter}
                </button>
              )
            )}
          </div>
          <div className={styles.projectsGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard} data-animate="fade">
                <div className={styles.projectImage}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.faqSection} section-spacing`} id="faq">
        <div className="container">
          <div className={styles.sectionHeader} data-animate="fade">
            <span className="eyebrow">FAQ</span>
            <h2>Insights for sustainability decision-makers</h2>
          </div>
          <div className={styles.faqList}>
            {faqItems.map((item, index) => (
              <div
                key={item.question}
                className={`${styles.faqItem} ${faqOpenIndex === index ? styles.faqOpen : ''}`}
                data-animate="fade"
              >
                <button
                  className={styles.faqButton}
                  onClick={() => handleFaqToggle(index)}
                  aria-expanded={faqOpenIndex === index}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon} aria-hidden="true">
                    {faqOpenIndex === index ? '−' : '+'}
                  </span>
                </button>
                <div className={styles.faqContent}>
                  <p>{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.blogSection} section-spacing`} id="insights">
        <div className="container">
          <div className={styles.sectionHeader} data-animate="fade">
            <span className="eyebrow">Insights</span>
            <h2>Latest perspectives from the GreenTech team</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard} data-animate="fade">
                <span className={styles.blogDate}>{post.date}</span>
                <h3>{post.title}</h3>
                <p>{post.excerpt}</p>
                <Link to={post.link} className="btn-link">
                  Continue reading →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.ctaSection} section-spacing`} id="cta">
        <div className="container">
          <div className={styles.ctaGrid}>
            <div className={styles.ctaContent} data-animate="fade">
              <span className="eyebrow">Let’s build a climate-positive future</span>
              <h2>Ready to activate your sustainability roadmap?</h2>
              <p>
                Share your objectives and our consultants will craft a tailored engagement outline within two business days.
              </p>
              <ul className={styles.ctaList}>
                <li>Data-informed strategy alignment workshop</li>
                <li>Technology and infrastructure readiness assessment</li>
                <li>Roadmap with quick wins and long-term milestones</li>
              </ul>
            </div>
            <div className={styles.ctaFormWrapper} data-animate="fade">
              <ContactMiniForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function ContactMiniForm() {
  const initialState = { name: '', email: '', company: '', message: '' };
  const [formValues, setFormValues] = useState(initialState);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const currentErrors = {};
    if (!formValues.name.trim()) currentErrors.name = 'Please enter your name.';
    if (!formValues.email.trim()) {
      currentErrors.email = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formValues.email.trim())) {
      currentErrors.email = 'Enter a valid email address.';
    }
    if (!formValues.message.trim()) currentErrors.message = 'Please share a brief message.';
    return currentErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setSubmitted(true);
    setFormValues(initialState);
  };

  return (
    <form className={styles.ctaForm} onSubmit={handleSubmit} noValidate aria-label="Contact GreenTech Solutions">
      <h3>Request Your Strategy Session</h3>
      {submitted && <div className={styles.formSuccess}>Thank you! Our team will connect with you shortly.</div>}
      <label className={styles.formField}>
        <span>Name *</span>
        <input
          type="text"
          name="name"
          value={formValues.name}
          onChange={handleChange}
          aria-required="true"
          aria-invalid={!!errors.name}
          aria-describedby={errors.name ? 'cta-name-error' : undefined}
        />
        {errors.name && <span id="cta-name-error" className={styles.formError}>{errors.name}</span>}
      </label>
      <label className={styles.formField}>
        <span>Email *</span>
        <input
          type="email"
          name="email"
          value={formValues.email}
          onChange={handleChange}
          aria-required="true"
          aria-invalid={!!errors.email}
          aria-describedby={errors.email ? 'cta-email-error' : undefined}
        />
        {errors.email && <span id="cta-email-error" className={styles.formError}>{errors.email}</span>}
      </label>
      <label className={styles.formField}>
        <span>Organization</span>
        <input
          type="text"
          name="company"
          value={formValues.company}
          onChange={handleChange}
        />
      </label>
      <label className={styles.formField}>
        <span>How can we help? *</span>
        <textarea
          name="message"
          rows="4"
          value={formValues.message}
          onChange={handleChange}
          aria-required="true"
          aria-invalid={!!errors.message}
          aria-describedby={errors.message ? 'cta-message-error' : undefined}
        ></textarea>
        {errors.message && <span id="cta-message-error" className={styles.formError}>{errors.message}</span>}
      </label>
      <button type="submit" className="btn-primary">
        Submit Request
      </button>
      <p className={styles.formNote}>
        By submitting this form, you agree to our <Link to="/privacy">Privacy Policy</Link>.
      </p>
    </form>
  );
}

export default Home;