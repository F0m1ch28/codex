import { Helmet } from 'react-helmet';
import styles from './Solutions.module.css';

function SustainableSolutions() {
  return (
    <>
      <Helmet>
        <title>Sustainable Solutions | GreenTech Solutions</title>
        <meta
          name="description"
          content="GreenTech Solutions delivers sustainable technology roadmaps, climate resilience strategies, and regenerative design services."
        />
      </Helmet>
      <section className={`${styles.hero} section-spacing`}>
        <div className="container">
          <span className="eyebrow">Sustainable solutions</span>
          <h1>Build regenerative systems that endure</h1>
          <p>
            Our team aligns sustainability strategy with enterprise goals through climate analysis, stakeholder engagement,
            and implementation planning that equips your teams to lead boldly.
          </p>
        </div>
      </section>

      <section className={`${styles.content} section-spacing`}>
        <div className="container">
          <div className={styles.zigzag}>
            <div className={styles.text}>
              <h2>Strategic services</h2>
              <ul>
                <li>Climate risk and resilience assessment</li>
                <li>Science-based target development and validation</li>
                <li>Stakeholder workshops and ESG materiality mapping</li>
                <li>Regenerative design consulting and nature-based solutions</li>
                <li>Carbon disclosure, reporting, and communication strategies</li>
              </ul>
            </div>
            <div className={styles.visual}>
              <img
                src="https://picsum.photos/880/640?random=601"
                alt="City skyline with green infrastructure"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.outcomes} section-spacing`}>
        <div className="container">
          <h2>Outcomes you can expect</h2>
          <div className={styles.outcomeGrid}>
            <div>
              <h3>Resilient operations</h3>
              <p>Systems designed to anticipate climate risks and safeguard critical services.</p>
            </div>
            <div>
              <h3>Engaged stakeholders</h3>
              <p>Clear narratives and hands-on programming to align leadership, teams, and communities.</p>
            </div>
            <div>
              <h3>Transparent reporting</h3>
              <p>Streamlined data capture that meets investor expectations and regulatory requirements.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default SustainableSolutions;