import { Helmet } from 'react-helmet';
import styles from './Legal.module.css';

function Privacy() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | GreenTech Solutions</title>
      </Helmet>
      <section className={`${styles.section} section-spacing`}>
        <div className="container">
          <h1>Privacy Policy</h1>
          <p>Effective date: March 15, 2024</p>
          <h2>Information we collect</h2>
          <p>
            We collect personal information that you provide when submitting forms, including your name, email, company,
            and other voluntary details. We also collect limited technical data such as IP address, browser type, and referring pages.
          </p>
          <h2>How we use information</h2>
          <p>
            We use data to respond to inquiries, provide services, share relevant updates, and improve our website experience.
            We do not sell personal information.
          </p>
          <h2>Data retention</h2>
          <p>
            We retain information for as long as necessary to fulfill the purposes outlined in this policy, comply with legal obligations,
            and resolve disputes.
          </p>
          <h2>Your rights</h2>
          <p>
            You may request access, correction, or deletion of your personal information by contacting{' '}
            <a href="mailto:info@greentechsolutions.com">info@greentechsolutions.com</a>. We will respond in accordance with applicable privacy laws.
          </p>
          <h2>Cookies</h2>
          <p>
            Cookies support navigation, analytics, and personalization. Manage preferences using your browser settings or review our{' '}
            <a href="/cookie-policy">Cookie Policy</a>.
          </p>
          <h2>Updates</h2>
          <p>
            We may update this policy periodically. Any changes will be posted on this page with an updated effective date.
          </p>
        </div>
      </section>
    </>
  );
}

export default Privacy;