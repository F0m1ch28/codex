import { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './Services.module.css';

const services = [
  {
    category: 'Sustainable Solutions',
    summary: 'Strategy, assessments, and change programs to accelerate sustainability maturity.',
    details: [
      'Climate risk assessment and resiliency planning',
      'Lifecycle assessments and science-based target development',
      'Stakeholder engagement and sustainability reporting',
      'Regenerative design and nature-based solutions'
    ],
    link: '/sustainable-solutions',
    icon: '🌍'
  },
  {
    category: 'Energy Efficiency',
    summary: 'High-performance energy systems that balance reliability, savings, and decarbonization.',
    details: [
      'Energy audits, benchmarking, and thermal imaging',
      'HVAC optimization, building automation, and smart metering',
      'Electrification, microgrids, and renewable integration',
      'Ongoing measurement and verification programs'
    ],
    link: '/energy-efficiency',
    icon: '⚡'
  },
  {
    category: 'Waste Management',
    summary: 'Circular strategies that transform waste streams into sustainable resource flows.',
    details: [
      'Zero-waste roadmaps and materials flow modeling',
      'Extended producer responsibility compliance',
      'Organics diversion and composting systems',
      'Supplier collaboration and product stewardship programs'
    ],
    link: '/waste-management',
    icon: '♻️'
  }
];

const differentiators = [
  {
    title: 'Outcome-focused delivery',
    description:
      'Every engagement is benchmarked with actionable KPIs—energy intensity, emissions factors, landfill diversion—and tracked through intuitive dashboards.'
  },
  {
    title: 'Integrated expertise',
    description:
      'Certified energy auditors, LEED APs, data scientists, and change strategists collaborate under one roof to mobilize implementation quickly.'
  },
  {
    title: 'Human-centered change',
    description:
      'Culture is at the heart of sustainable transformation. We equip teams with training, communication assets, and ambassadors to sustain progress.'
  }
];

function Services() {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <>
      <Helmet>
        <title>Services | GreenTech Solutions</title>
        <meta
          name="description"
          content="Explore GreenTech Solutions services: sustainable technology roadmaps, energy efficiency programs, and circular waste management strategies."
        />
      </Helmet>
      <section className={`${styles.hero} section-spacing`}>
        <div className="container">
          <span className="eyebrow">Our services</span>
          <h1>Tailored programs built around your sustainability objectives</h1>
          <p>
            Whether you are launching your first climate action plan or scaling mature initiatives, GreenTech Solutions
            delivers the analysis, technology, and change management required to embed sustainability across your organization.
          </p>
        </div>
      </section>

      <section className={`${styles.tabsSection} section-spacing`}>
        <div className="container">
          <div className={styles.tabs}>
            {services.map((service, index) => (
              <button
                key={service.category}
                className={`${styles.tabButton} ${activeIndex === index ? styles.tabActive : ''}`}
                onClick={() => setActiveIndex(index)}
                aria-selected={activeIndex === index}
              >
                <span aria-hidden="true">{service.icon}</span> {service.category}
              </button>
            ))}
          </div>

          <div className={styles.tabContent}>
            <h2>{services[activeIndex].category}</h2>
            <p>{services[activeIndex].summary}</p>
            <ul>
              {services[activeIndex].details.map((detail) => (
                <li key={detail}>{detail}</li>
              ))}
            </ul>
            <a href={services[activeIndex].link} className="btn-primary">
              Discover more
            </a>
          </div>
        </div>
      </section>

      <section className={`${styles.features} section-spacing`}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className="eyebrow">Why it works</span>
            <h2>We blend strategic insight with technical execution</h2>
          </div>
          <div className={styles.featuresGrid}>
            {differentiators.map((item) => (
              <div key={item.title} className={styles.featureCard}>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;