const navToggle = document.getElementById('navToggle');
const navbar = document.getElementById('navbar');
const cookieBanner = document.getElementById('cookieBanner');
const cookieAccept = document.getElementById('cookieAccept');
const cookieDecline = document.getElementById('cookieDecline');

if (navToggle && navbar) {
    navToggle.addEventListener('click', () => {
        navbar.classList.toggle('open');
        navToggle.setAttribute('aria-expanded', navbar.classList.contains('open'));
    });
}

function handleCookieConsent(status) {
    localStorage.setItem('placedhnqf-cookie-consent', status);
    if (cookieBanner) {
        cookieBanner.classList.remove('active');
    }
}

if (cookieBanner && cookieAccept && cookieDecline) {
    const existingConsent = localStorage.getItem('placedhnqf-cookie-consent');
    if (!existingConsent) {
        cookieBanner.classList.add('active');
    }
    cookieAccept.addEventListener('click', () => handleCookieConsent('accepted'));
    cookieDecline.addEventListener('click', () => handleCookieConsent('declined'));
}