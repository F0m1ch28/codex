document.addEventListener('DOMContentLoaded', function () {
    const header = document.querySelector('.site-header');
    if (header) {
        const toggle = header.querySelector('.mobile-toggle');
        const nav = header.querySelector('.primary-nav');
        if (toggle && nav) {
            toggle.addEventListener('click', function () {
                nav.classList.toggle('open');
            });
        }
    }

    const banner = document.querySelector('.cookie-banner');
    if (!banner) {
        return;
    }
    const acceptBtn = banner.querySelector('.cookie-accept');
    const declineBtn = banner.querySelector('.cookie-decline');

    const status = localStorage.getItem('gavialckngCookieConsent');
    if (!status) {
        banner.classList.add('visible');
    }

    function handleConsent(state, anchor) {
        localStorage.setItem('gavialckngCookieConsent', state);
        banner.classList.remove('visible');
        window.open('cookies.html#' + anchor, '_blank');
    }

    if (acceptBtn) {
        acceptBtn.addEventListener('click', function () {
            handleConsent('accepted', 'accepted');
        });
    }

    if (declineBtn) {
        declineBtn.addEventListener('click', function () {
            handleConsent('declined', 'declined');
        });
    }
});