document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.getElementById('primary-navigation');
    const scrollTopBtn = document.querySelector('.scroll-top');
    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const quizForm = document.getElementById('quiz-form');
    const quizResult = document.getElementById('quiz-result');
    const contactForm = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');
    const yearSpan = document.getElementById('year');
    const navLinks = document.querySelectorAll('#primary-navigation a');

    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    if (navToggle && navigation) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
            navigation.classList.toggle('open');
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navigation.classList.contains('open')) {
                navigation.classList.remove('open');
                navToggle.setAttribute('aria-expanded', 'false');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });

    if (scrollTopBtn) {
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    const cookiePreference = localStorage.getItem('mfj_cookie_consent');
    if (!cookiePreference && cookieBanner) {
        cookieBanner.classList.add('active');
    }

    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', () => {
            localStorage.setItem('mfj_cookie_consent', 'accepted');
            cookieBanner.classList.remove('active');
        });
    }

    if (quizForm && quizResult) {
        quizForm.addEventListener('submit', event => {
            event.preventDefault();
            const butter = quizForm.querySelector('input[name="butter"]:checked');
            const ingredient = quizForm.querySelector('input[name="ingredient"]:checked');
            let score = 0;
            if (butter && butter.value === 'Ontario') score++;
            if (ingredient && ingredient.value === 'Birch syrup glaze') score++;

            if (score === 2) {
                quizResult.textContent = 'Brilliant! You’re swimming right alongside our editors.';
                quizResult.style.color = '#15803d';
            } else if (score === 1) {
                quizResult.textContent = 'Almost there. Revisit the stories and try again.';
                quizResult.style.color = '#ca8a04';
            } else {
                quizResult.textContent = 'No worries—dive back into the articles for sparkling hints.';
                quizResult.style.color = '#dc2626';
            }
        });
    }

    if (contactForm && formMessage) {
        contactForm.addEventListener('submit', event => {
            event.preventDefault();
            formMessage.textContent = 'Thank you! Your message has been received. Our editors will respond shortly.';
            formMessage.style.color = '#15803d';
            contactForm.reset();
        });
    }
});