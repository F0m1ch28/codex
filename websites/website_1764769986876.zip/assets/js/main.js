(() => {
  const storageKey = "petromantix-cookie-consent";
  const banner = document.querySelector("[data-cookie-banner]");
  if (banner) {
    const stored = localStorage.getItem(storageKey);
    if (!stored) {
      setTimeout(() => banner.setAttribute("data-visible", "true"), 600);
    }
    const acceptBtn = banner.querySelector("[data-accept]");
    const declineBtn = banner.querySelector("[data-decline]");
    const closeBanner = (value) => {
      localStorage.setItem(storageKey, value);
      banner.removeAttribute("data-visible");
    };
    if (acceptBtn) {
      acceptBtn.addEventListener("click", () => closeBanner("accepted"));
    }
    if (declineBtn) {
      declineBtn.addEventListener("click", () => closeBanner("declined"));
    }
  }

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const href = anchor.getAttribute("href");
      if (href && href.length > 1) {
        const target = document.querySelector(href);
        if (target) {
          event.preventDefault();
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          target.focus({ preventScroll: true });
        }
      }
    });
  });
})();