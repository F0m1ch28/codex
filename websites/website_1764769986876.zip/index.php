<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PetroMantix | Structural Diagnostics & Field Monitoring</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="PetroMantix delivers structural diagnostics, field monitoring, and integrity analysis for petroleum-support infrastructure across Canada.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'%3E%3Crect width='96' height='96' rx='18' fill='%23081522'/%3E%3Cpath d='M26 68L48 20l22 48h-9l-5-11H40l-5 11h-9zm20-18h12l-6-14-6 14z' fill='%23ffb703'/%3E%3C/svg%3E">
  <link rel="canonical" href="https://www.petromantix.ca/">
  <meta property="og:title" content="PetroMantix | Structural Diagnostics & Field Monitoring">
  <meta property="og:description" content="Canadian specialists in structural diagnostics, load analysis, and field monitoring for petroleum infrastructure.">
  <meta property="og:image" content="https://picsum.photos/1200/630?random=engineering">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.petromantix.ca/">
  <meta name="twitter:card" content="summary_large_image">
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": ["LocalBusiness", "EnergyService"],
    "name": "PetroMantix",
    "description": "Canadian technical organization providing structural diagnostics, field-condition monitoring, load and stress assessment, surface stability analysis, and environmental exposure evaluation for petroleum-support infrastructure.",
    "image": "https://picsum.photos/1200/630?random=engineering",
    "url": "https://www.petromantix.ca/",
    "telephone": "+1 587 555 4128",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "4280 Blackfoot Trail SE",
      "addressLocality": "Calgary",
      "addressRegion": "Alberta",
      "postalCode": "T2G 4E6",
      "addressCountry": "Canada"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 51.0189,
      "longitude": -114.0392
    },
    "areaServed": {
      "@type": "Country",
      "name": "Canada"
    },
    "openingHours": "Mo-Fr 08:00-18:00",
    "sameAs": [
      "https://www.linkedin.com/company/petromantix"
    ]
  }
  </script>
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to main content</a>
  <div class="site-wrapper">
    <header>
      <div class="header-inner">
        <a class="logo" href="index.php">
          <span class="logo__mark">PM</span>
          <span>PetroMantix</span>
        </a>
        <nav aria-label="Primary">
          <ul class="nav-list">
            <li><a href="index.php" aria-current="page">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="services.html">Services</a></li>
            <li><a href="solutions.html">Solutions</a></li>
            <li><a href="case-studies.html">Case Studies</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <main id="main-content" tabindex="-1">
      <section class="section">
        <div class="container hero">
          <div class="hero__content">
            <span class="hero__tagline">Structural intelligence for Canadian energy corridors</span>
            <h1>Diagnosing and tracking structural performance across petroleum-support infrastructure.</h1>
            <p class="lead">PetroMantix integrates advanced sensing, geospatial analytics, and engineering oversight to anticipate mechanical stress, terrain interaction, and environmental exposure throughout industrial and remote operations.</p>
            <div class="hero__grid">
              <div>
                <a class="btn" href="services.html">Explore our capabilities</a>
                <a class="btn btn--ghost" href="#contact">Schedule a diagnostic consult</a>
              </div>
              <div class="hero__metrics">
                <div class="metric">
                  <span class="metric__value">120+</span>
                  <span class="metric__label">Infrastructure assets monitored across Western Canada</span>
                </div>
                <div class="metric">
                  <span class="metric__value">24/7</span>
                  <span class="metric__label">Field data continuity with adaptive sensing frameworks</span>
                </div>
                <div class="metric">
                  <span class="metric__value">35%</span>
                  <span class="metric__label">Average reduction in unplanned structural downtime</span>
                </div>
              </div>
            </div>
          </div>
          <div class="hero__media">
            <img src="https://picsum.photos/900/640?random=petroleum" alt="Technicians reviewing structural monitoring dashboards" loading="lazy" width="900" height="640">
            <div class="hero__overlay" aria-live="polite">
              <h3>Live Integrity Feed</h3>
              <span>Pipeline span 14A · Stress variance: ±3.1%</span>
              <span>Support footings · Settlement drift: 2.4mm over 30 days</span>
              <span>Bridge deck · Vibration profile: Stable · Alert threshold clear</span>
            </div>
          </div>
        </div>
      </section>

      <section class="section section--tight" id="value">
        <div class="container">
          <div class="section__header">
            <h2>Field diagnostics built for petroleum infrastructure realities.</h2>
            <p class="section__intro">From the Alberta foothills to Arctic corridors, PetroMantix anchors decisions with sensor-driven insight, structural modelling, and field-ready engineering teams.</p>
          </div>
          <div class="grid grid--three">
            <article class="card">
              <span class="card__icon" aria-hidden="true">⛏️</span>
              <h3 class="card__title">Terrain-surface correlation</h3>
              <p>Digital terrain models linked with structural anchors to reveal susceptibility to frost heave, subsidence, and slope transition.</p>
              <ul class="list-inline">
                <li class="chip">LiDAR harmonization</li>
                <li class="chip">Frost index overlay</li>
              </ul>
            </article>
            <article class="card">
              <span class="card__icon" aria-hidden="true">🛰️</span>
              <h3 class="card__title">Adaptive monitoring stacks</h3>
              <p>Telemetered sensor suites with intelligent thresholds, tuned for remote assets and extended winter conditions.</p>
              <ul class="list-inline">
                <li class="chip">Fiber strain</li>
                <li class="chip">Acoustic sensing</li>
              </ul>
            </article>
            <article class="card">
              <span class="card__icon" aria-hidden="true">🧭</span>
              <h3 class="card__title">Actionable integrity analytics</h3>
              <p>Predictive models translating field inputs into practical reinforcement, remediation, and maintenance sequencing.</p>
              <ul class="list-inline">
                <li class="chip">Load envelopes</li>
                <li class="chip">Threshold deviation</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section class="section section--tight" id="diagnostics">
        <div class="container surface">
          <div class="grid grid--two">
            <div>
              <h2>Diagnostic framework overview</h2>
              <p>Our methodology lends transparency to structural response under fluctuating hydrocarbon throughput, dynamic loads, and climate extremes. Each assessment cycle integrates historical data, in-field verification, and real-time monitoring channels.</p>
              <table class="table" aria-label="Diagnostic cycle key metrics">
                <thead>
                  <tr>
                    <th scope="col">Phase</th>
                    <th scope="col">Focus</th>
                    <th scope="col">Deliverables</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Baseline capture</td>
                    <td>Material condition, load paths</td>
                    <td>Integrity map, strain profile</td>
                  </tr>
                  <tr>
                    <td>Monitoring design</td>
                    <td>Sensor placement, redundancy</td>
                    <td>Instrumentation schematic</td>
                  </tr>
                  <tr>
                    <td>Continuous review</td>
                    <td>Alert thresholds, anomalies</td>
                    <td>Insight dashboard, action log</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div>
              <img src="https://picsum.photos/760/520?random=monitoring" alt="Field engineer configuring monitoring equipment near pipeline supports" loading="lazy" width="760" height="520">
            </div>
          </div>
        </div>
      </section>

      <section class="section section--tight" id="integrity">
        <div class="container">
          <div class="grid grid--two">
            <div class="surface surface--frosted">
              <h2>Structural integrity checkpoints</h2>
              <p>Key focus areas ensuring mechanical resilience and service continuity.</p>
              <div class="grid grid--two">
                <div class="card">
                  <span class="card__icon" aria-hidden="true">📐</span>
                  <h3 class="card__title">Load-path modelling</h3>
                  <p>Finite element simulations tied to field-verified stiffness data for braces, saddles, and risers.</p>
                </div>
                <div class="card">
                  <span class="card__icon" aria-hidden="true">🌡️</span>
                  <h3 class="card__title">Thermal response</h3>
                  <p>Tracking differential expansion during throughput swings, limiting fatigue accumulation.</p>
                </div>
                <div class="card">
                  <span class="card__icon" aria-hidden="true">🛡️</span>
                  <h3 class="card__title">Corrosion defense</h3>
                  <p>Cathodic protection alignment with coating inspection and electrolyte characterization.</p>
                </div>
                <div class="card">
                  <span class="card__icon" aria-hidden="true">🧮</span>
                  <h3 class="card__title">Stress reconciliation</h3>
                  <p>Closed-loop between measured and modelled stress states for high-consequence components.</p>
                </div>
              </div>
            </div>
            <div class="surface">
              <h2>Environmental exposure synthesis</h2>
              <p>Integrated evaluation for assets exposed to complex terrains, permafrost zones, and marine climates.</p>
              <img src="https://picsum.photos/720/480?random=environment" alt="Structural supports across northern terrain under assessment" loading="lazy" width="720" height="480">
            </div>
          </div>
        </div>
      </section>

      <section class="section section--tight" id="diagrams">
        <div class="container">
          <div class="section__header">
            <h2>Visual intelligence layers</h2>
            <p class="section__intro">Interactive diagrams illustrate structural load distribution, stress zones, and terrain relationships powering PetroMantix dashboards.</p>
          </div>
          <div class="grid">
            <div class="diagram" role="img" aria-label="Stress-zone diagram">
              <h3>Stress-zone envelope</h3>
              <svg viewBox="0 0 360 180" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <defs>
                  <linearGradient id="grad" x1="0" x2="1" y1="0" y2="0">
                    <stop offset="0%" stop-color="#0c1320"/>
                    <stop offset="50%" stop-color="#ffb703"/>
                    <stop offset="100%" stop-color="#0c1320"/>
                  </linearGradient>
                </defs>
                <rect x="0" y="0" width="360" height="180" fill="url(#grad)" opacity="0.12"/>
                <polyline points="20,120 80,60 140,90 200,40 260,85 320,55" fill="none" stroke="#ffb703" stroke-width="4" stroke-linecap="round"/>
                <circle cx="80" cy="60" r="6" fill="#ffb703"/>
                <circle cx="200" cy="40" r="6" fill="#ffb703"/>
                <circle cx="260" cy="85" r="6" fill="#ffb703"/>
              </svg>
              <p>Priority stress zones flagged against design thresholds. Anomaly layers highlight progressive deviation in real time.</p>
            </div>
            <div class="diagram" role="img" aria-label="Terrain interaction map">
              <h3>Terrain-interaction map</h3>
              <svg viewBox="0 0 360 180" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <rect width="360" height="180" fill="#152032"/>
                <path d="M0 140 C60 80, 120 200, 180 120 S300 80, 360 140 L360 180 L0 180 Z" fill="rgba(255, 183, 3, 0.4)"/>
                <g fill="none" stroke="#e6f1ff" stroke-width="1" opacity="0.5">
                  <line x1="40" y1="20" x2="40" y2="160"/>
                  <line x1="120" y1="20" x2="120" y2="160"/>
                  <line x1="200" y1="20" x2="200" y2="160"/>
                  <line x1="280" y1="20" x2="280" y2="160"/>
                </g>
                <polyline points="20,100 120,70 220,110 320,80" fill="none" stroke="#ffb703" stroke-width="2"/>
              </svg>
              <p>Alignment of support foundations with micro-topography, permafrost depth, and hydrological flow vectors.</p>
            </div>
          </div>
        </div>
      </section>

      <section class="section section--tight" id="cta">
        <div class="container surface surface--frosted">
          <div class="grid grid--two">
            <div>
              <h2>Field-ready insight with PetroMantix.</h2>
              <p>Engineering teams deploy quickly with calibrated monitoring kits, remote dashboards, and on-call structural specialists. Whether you are preparing new infrastructure tie-ins or sustaining legacy corridors, we keep structural behaviour transparent.</p>
              <ul class="list-inline">
                <li class="chip">CSA Z662 alignment</li>
                <li class="chip">Digital reporting suites</li>
                <li class="chip">Field-certified engineers</li>
              </ul>
            </div>
            <div>
              <blockquote>“PetroMantix turned scattered sensor inputs into a cohesive structural narrative. We rely on their dashboards to plan reinforcement work and manage operating limits.”</blockquote>
            </div>
          </div>
        </div>
      </section>

      <section class="section section--tight" id="contact">
        <div class="container surface">
          <div class="section__header">
            <h2>Start a diagnostic engagement</h2>
            <p class="section__intro">Share project context and our Calgary-based coordination team will outline an instrumentation and analysis pathway within one business day.</p>
          </div>
          <form class="form" action="contact.php" method="post">
            <input type="hidden" name="origin" value="Homepage contact">
            <div class="form-grid form-grid--two">
              <div class="form-control">
                <label for="name">Full name</label>
                <input id="name" name="name" type="text" required autocomplete="name" placeholder="Jordan Smith">
              </div>
              <div class="form-control">
                <label for="email">Email</label>
                <input id="email" name="email" type="email" required autocomplete="email" placeholder="name@organization.ca">
              </div>
              <div class="form-control">
                <label for="organization">Organization</label>
                <input id="organization" name="organization" type="text" required placeholder="Operations or project team">
              </div>
              <div class="form-control">
                <label for="region">Primary region</label>
                <select id="region" name="region" required>
                  <option value="">Select region</option>
                  <option value="Alberta">Alberta</option>
                  <option value="British Columbia">British Columbia</option>
                  <option value="Saskatchewan">Saskatchewan</option>
                  <option value="Northern Territories">Northern Territories</option>
                  <option value="Atlantic Canada">Atlantic Canada</option>
                </select>
              </div>
            </div>
            <div class="form-control">
              <label for="message">Project scope &amp; timeline</label>
              <textarea id="message" name="message" required placeholder="Outline infrastructure, operational context, and timeline expectations."></textarea>
            </div>
            <div>
              <button class="btn" type="submit">Submit request</button>
            </div>
          </form>
        </div>
      </section>
    </main>

    <footer class="footer">
      <div class="footer__inner">
        <div class="footer__brand">
          <a class="logo" href="index.php">
            <span class="logo__mark">PM</span>
            <span>PetroMantix</span>
          </a>
          <p>Structural diagnostics, monitoring, and integrity analysis tailored to Canada's petroleum-support infrastructure.</p>
        </div>
        <div>
          <h3>Navigate</h3>
          <ul class="footer__list">
            <li><a href="about.html">About us</a></li>
            <li><a href="services.html">Services</a></li>
            <li><a href="solutions.html">Solutions</a></li>
            <li><a href="case-studies.html">Case studies</a></li>
          </ul>
        </div>
        <div>
          <h3>Standards &amp; Policies</h3>
          <ul class="footer__list">
            <li><a href="privacy.html">Privacy</a></li>
            <li><a href="cookies.html">Cookies</a></li>
            <li><a href="terms.html">Terms of use</a></li>
            <li><a href="sitemap.xml">Sitemap</a></li>
          </ul>
        </div>
        <div>
          <h3>Contact</h3>
          <address>
            4280 Blackfoot Trail SE<br>
            Calgary, Alberta, Canada<br>
            <a href="tel:+15875554128">+1 587 555 4128</a><br>
            <a href="mailto:engage@petromantix.ca">engage@petromantix.ca</a>
          </address>
        </div>
      </div>
      <div class="footer__bottom">
        <span>&copy; <?php echo date('Y'); ?> PetroMantix. All rights reserved.</span>
      </div>
    </footer>
  </div>

  <div class="cookie-banner" data-cookie-banner aria-live="polite">
    <h3>Cookie preferences</h3>
    <p>We use cookies to enhance monitoring dashboards and understand website interactions. You can manage your preferences below.</p>
    <div class="cookie-banner__actions">
      <button type="button" class="btn" data-accept>Accept</button>
      <button type="button" class="btn btn--ghost" data-decline>Decline</button>
      <a class="btn btn--ghost" href="cookies.html">Preferences</a>
    </div>
  </div>
  <script src="assets/js/main.js" defer></script>
</body>
</html>