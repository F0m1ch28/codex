<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You | PetroMantix</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Thank you page confirming PetroMantix has received your submission.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'%3E%3Crect width='96' height='96' rx='18' fill='%23081522'/%3E%3Cpath d='M26 68L48 20l22 48h-9l-5-11H40l-5 11h-9zm20-18h12l-6-14-6 14z' fill='%23ffb703'/%3E%3C/svg%3E">
  <link rel="canonical" href="https://www.petromantix.ca/thanks.php">
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to main content</a>
  <div class="site-wrapper">
    <header>
      <div class="header-inner">
        <a class="logo" href="index.php">
          <span class="logo__mark">PM</span>
          <span>PetroMantix</span>
        </a>
        <nav aria-label="Primary">
          <ul class="nav-list">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="services.html">Services</a></li>
            <li><a href="solutions.html">Solutions</a></li>
            <li><a href="case-studies.html">Case Studies</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </nav>
      </div>
    </header>

    <main id="main-content" tabindex="-1">
      <section class="section">
        <div class="container surface surface--frosted">
          <h1>Thank you for reaching out</h1>
          <p>Your submission has been received. A PetroMantix specialist will review the details and respond within one business day.</p>
          <p>If your request is urgent, please call <a href="tel:+15875554128">+1 587 555 4128</a>.</p>
          <a class="btn" href="index.php">Return to home</a>
        </div>
      </section>
    </main>

    <footer class="footer">
      <div class="footer__inner">
        <div class="footer__brand">
          <a class="logo" href="index.php">
            <span class="logo__mark">PM</span>
            <span>PetroMantix</span>
          </a>
          <p>Structural diagnostics, monitoring, and integrity analysis tailored to Canada's petroleum-support infrastructure.</p>
        </div>
        <div>
          <h3>Navigate</h3>
          <ul class="footer__list">
            <li><a href="about.html">About us</a></li>
            <li><a href="services.html">Services</a></li>
            <li><a href="solutions.html">Solutions</a></li>
            <li><a href="case-studies.html">Case studies</a></li>
          </ul>
        </div>
        <div>
          <h3>Standards &amp; Policies</h3>
          <ul class="footer__list">
            <li><a href="privacy.html">Privacy</a></li>
            <li><a href="cookies.html">Cookies</a></li>
            <li><a href="terms.html">Terms of use</a></li>
            <li><a href="sitemap.xml">Sitemap</a></li>
          </ul>
        </div>
        <div>
          <h3>Contact</h3>
          <address>
            4280 Blackfoot Trail SE<br>
            Calgary, Alberta, Canada<br>
            <a href="tel:+15875554128">+1 587 555 4128</a><br>
            <a href="mailto:engage@petromantix.ca">engage@petromantix.ca</a>
          </address>
        </div>
      </div>
      <div class="footer__bottom">
        <span>&copy; 2024 PetroMantix. All rights reserved.</span>
      </div>
    </footer>
  </div>

  <div class="cookie-banner" data-cookie-banner aria-live="polite">
    <h3>Cookie preferences</h3>
    <p>We use cookies to enhance monitoring dashboards and understand website interactions. You can manage your preferences below.</p>
    <div class="cookie-banner__actions">
      <button type="button" class="btn" data-accept>Accept</button>
      <button type="button" class="btn btn--ghost" data-decline>Decline</button>
      <a class="btn btn--ghost" href="cookies.html">Preferences</a>
    </div>
  </div>
  <script src="assets/js/main.js" defer></script>
</body>
</html>