import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="footer" aria-label="Футер сайта">
      <div className="container">
        <div className="footer-content">
          <div className="footer-brand">
            <span className="badge">Сайт компании</span>
            <strong style={{ fontSize: "22px" }}>
              Современные корпоративные решения
            </strong>
            <p style={{ color: "var(--color-text-muted)", lineHeight: 1.6 }}>
              Мы создаем цифровые продукты, которые соединяют стратегию,
              технологии и адаптивный дизайн. Инновации и ответственность —
              фундамент нашего подхода.
            </p>
          </div>
          <div className="footer-links" aria-label="Быстрые ссылки">
            <strong>Навигация</strong>
            <NavLink to="/">Главная</NavLink>
            <NavLink to="/about">О компании</NavLink>
            <NavLink to="/services">Услуги</NavLink>
            <NavLink to="/contact">Контакты</NavLink>
          </div>
          <div className="footer-links" aria-label="Правовые документы">
            <strong>Правовая информация</strong>
            <NavLink to="/terms">Пользовательское соглашение</NavLink>
            <NavLink to="/privacy">Политика конфиденциальности</NavLink>
            <NavLink to="/faq">Часто задаваемые вопросы</NavLink>
          </div>
        </div>
        <div className="footer-bottom">
          © {new Date().getFullYear()} Сайт компании. Все права защищены.
        </div>
      </div>
    </footer>
  );
};

export default Footer;