import { useEffect, useState } from "react";

const STORAGE_KEY = "cookie-consent-status";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const status = localStorage.getItem(STORAGE_KEY);
    if (!status) {
      const timeout = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(timeout);
    }
  }, []);

  if (!visible) return null;

  const handleConsent = (value) => {
    localStorage.setItem(STORAGE_KEY, value);
    setVisible(false);
  };

  return (
    <aside className="cookie-banner" role="dialog" aria-live="polite">
      <div>
        <strong>Использование файлов cookie</strong>
        <p style={{ marginTop: "8px", color: "var(--color-text-muted)", lineHeight: 1.5 }}>
          Мы применяем cookie, чтобы улучшить работу сервиса и персонализировать
          контент. Вы можете принять или отклонить использование cookie в любой момент.
        </p>
      </div>
      <div className="cookie-actions">
        <button
          type="button"
          className="primary-button"
          onClick={() => handleConsent("accepted")}
        >
          Принять
        </button>
        <button
          type="button"
          className="secondary-button decline"
          onClick={() => handleConsent("declined")}
        >
          Отклонить
        </button>
      </div>
    </aside>
  );
};

export default CookieBanner;