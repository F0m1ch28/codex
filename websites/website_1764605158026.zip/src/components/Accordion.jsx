import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

const AccordionItem = ({ question, answer, isOpen, onToggle }) => (
  <div className="accordion-item">
    <button
      type="button"
      className="accordion-header"
      onClick={onToggle}
      aria-expanded={isOpen}
    >
      <span>{question}</span>
      <motion.span
        className="accordion-icon"
        animate={{ rotate: isOpen ? 180 : 0 }}
        transition={{ duration: 0.3 }}
      >
        ⌄
      </motion.span>
    </button>
    <AnimatePresence initial={false}>
      {isOpen && (
        <motion.div
          className="accordion-content"
          initial="collapsed"
          animate="open"
          exit="collapsed"
          variants={{
            open: { opacity: 1, height: "auto" },
            collapsed: { opacity: 0, height: 0 },
          }}
          transition={{ duration: 0.35, ease: [0.04, 0.62, 0.23, 0.98] }}
        >
          <div>{answer}</div>
        </motion.div>
      )}
    </AnimatePresence>
  </div>
);

const Accordion = ({ items }) => {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <div className="accordion">
      {items.map((item, idx) => (
        <AccordionItem
          key={item.question}
          question={item.question}
          answer={item.answer}
          isOpen={openIndex === idx}
          onToggle={() => setOpenIndex(openIndex === idx ? -1 : idx)}
        />
      ))}
    </div>
  );
};

export default Accordion;