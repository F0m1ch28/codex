import { useTheme } from "../contexts/ThemeContext.jsx";

const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <button
      type="button"
      className="theme-toggle"
      onClick={toggleTheme}
      aria-label="Переключение темы оформления"
    >
      <span
        aria-hidden="true"
        style={{ fontSize: "18px" }}
      >
        {isDark ? "🌙" : "☀️"}
      </span>
      <span style={{ fontSize: "14px", fontWeight: 600 }}>
        {isDark ? "Ночь" : "День"}
      </span>
    </button>
  );
};

export default ThemeToggle;