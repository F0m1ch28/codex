import { useState } from "react";
import { NavLink } from "react-router-dom";
import ThemeToggle from "./ThemeToggle.jsx";

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { label: "Главная", to: "/" },
    { label: "О компании", to: "/about" },
    { label: "Услуги", to: "/services" },
    { label: "Контакты", to: "/contact" },
  ];

  const toggleMenu = () => setMenuOpen((prev) => !prev);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 999,
        backdropFilter: "blur(28px)",
        background: "rgba(17, 24, 42, 0.18)",
        borderBottom: "1px solid rgba(255,255,255,0.12)",
      }}
      aria-label="Главная панель навигации"
    >
      <div
        className="container"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: "var(--header-height)",
        }}
      >
        <NavLink
          to="/"
          className="brand-link"
          onClick={closeMenu}
          style={{
            fontWeight: 800,
            fontSize: "20px",
            letterSpacing: "-0.02em",
            display: "flex",
            alignItems: "center",
            gap: "12px",
          }}
        >
          <span
            style={{
              width: "42px",
              height: "42px",
              borderRadius: "14px",
              background:
                "linear-gradient(135deg, rgba(91,225,255,0.28), rgba(31,58,147,0.4))",
              display: "grid",
              placeItems: "center",
              fontSize: "20px",
              fontWeight: 700,
            }}
          >
            СК
          </span>
          <span>Сайт компании</span>
        </NavLink>

        <nav
          aria-label="Основное меню"
          style={{
            display: menuOpen ? "flex" : undefined,
            flexDirection: menuOpen ? "column" : undefined,
            position: menuOpen ? "absolute" : undefined,
            top: menuOpen ? "calc(var(--header-height) + 14px)" : undefined,
            right: menuOpen ? "24px" : undefined,
            background: menuOpen ? "var(--color-surface)" : "transparent",
            padding: menuOpen ? "20px 24px" : undefined,
            borderRadius: menuOpen ? "24px" : undefined,
            border: menuOpen ? "var(--glass-border)" : undefined,
            backdropFilter: menuOpen ? "blur(22px)" : undefined,
            boxShadow: menuOpen ? "var(--shadow-soft)" : undefined,
          }}
        >
          <ul
            style={{
              margin: 0,
              padding: 0,
              listStyle: "none",
              display: "flex",
              alignItems: "center",
              gap: "26px",
              flexDirection: menuOpen ? "column" : "row",
            }}
          >
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  onClick={closeMenu}
                  style={({ isActive }) => ({
                    padding: "10px 18px",
                    borderRadius: "999px",
                    fontWeight: 600,
                    color: isActive ? "#fff" : "inherit",
                    background: isActive ? "var(--gradient-brand)" : "transparent",
                    boxShadow: isActive ? "var(--shadow-soft)" : "none",
                    transition: "background 0.3s ease, color 0.3s ease, transform 0.3s ease",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "10px",
                  })}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
            <li>
              <ThemeToggle />
            </li>
          </ul>
        </nav>

        <button
          type="button"
          className="mobile-nav-toggle"
          aria-label={menuOpen ? "Закрыть меню" : "Открыть меню"}
          aria-expanded={menuOpen}
          onClick={toggleMenu}
        >
          <span style={{ fontSize: "22px", fontWeight: 700 }}>
            {menuOpen ? "✕" : "☰"}
          </span>
        </button>
      </div>
    </header>
  );
};

export default Header;