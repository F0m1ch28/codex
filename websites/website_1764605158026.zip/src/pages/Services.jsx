import { motion } from "framer-motion";

const Services = () => {
  const services = [
    {
      title: "Корпоративные сайты и порталы",
      description:
        "Проектируем и развиваем сложные экосистемы с учетом внутренних процессов, интеграций и требований к безопасности.",
      benefits: [
        "Индивидуальная дизайн-система",
        "Интеграции с CRM/ERP/HRM",
        "Управляемая модульная архитектура",
        "Полная аналитика и мониторинг SLA",
      ],
    },
    {
      title: "Цифровая стратегия и консалтинг",
      description:
        "Исследуем бизнес-процессы, формируем дорожные карты, внедряем единые стандарты CX/UX и измеримую систему KPI.",
      benefits: [
        "Анализ текущей цифровой зрелости",
        "Интервью с заинтересованными сторонами",
        "Проектирование целевой модели взаимодействий",
        "План трансформации и внедрения",
      ],
    },
    {
      title: "Автоматизация и интеграции",
      description:
        "Соединяем разрозненные системы и данные в единую платформу, обеспечивая стабильный обмен информацией.",
      benefits: [
        "API-first подход",
        "Low-code/No-code модули",
        "Собственные коннекторы и шины данных",
        "Автоматизация отчетности и документооборота",
      ],
    },
    {
      title: "Сопровождение и развитие",
      description:
        "Обеспечиваем поддержку 24/7, регулярные обновления, аудит производительности и защиту от угроз.",
      benefits: [
        "Центр компетенций и службы поддержки",
        "Регулярные обновления и UX-исследования",
        "Настройка отказоустойчивости",
        "Обучение внутренним командам",
      ],
    },
  ];

  return (
    <div className="page">
      <section className="glass-panel">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <span className="badge">Услуги</span>
          <h1 className="section-title">Комплексные решения для бизнеса</h1>
          <p className="section-subtitle">
            Мы создаем экосистемы, которые объединяют цифровые каналы, внутренние сервисы и
            клиентский experience. Сайт компании сопровождает клиентов на всех этапах — от идеи до
            масштабирования.
          </p>
        </motion.div>
      </section>

      <section className="service-grid">
        {services.map((service) => (
          <motion.article
            key={service.title}
            className="service-card"
            initial={{ opacity: 0, y: 22 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.55 }}
          >
            <h3 style={{ fontSize: "22px", marginBottom: "8px" }}>{service.title}</h3>
            <p style={{ color: "var(--color-text-muted)", lineHeight: 1.6 }}>
              {service.description}
            </p>
            <ul>
              {service.benefits.map((benefit) => (
                <li key={benefit}>{benefit}</li>
              ))}
            </ul>
            <button type="button" className="secondary-button" style={{ marginTop: "auto" }}>
              Запросить подробности
            </button>
          </motion.article>
        ))}
      </section>

      <section className="highlight-card">
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.55 }}
        >
          <h2 className="section-title">Как мы работаем</h2>
          <p className="section-subtitle" style={{ margin: "0 auto" }}>
            Исследование аудитории, прототипирование, дизайн-спринты, agile-разработка, контроль
            качества и запуск. Каждый шаг сопровождается прозрачной отчетностью и поддержкой.
          </p>
        </motion.div>
      </section>
    </div>
  );
};

export default Services;