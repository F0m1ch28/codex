import { motion } from "framer-motion";

const About = () => {
  return (
    <div className="page">
      <section className="glass-panel">
        <motion.div
          initial={{ opacity: 0, y: 26 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
        >
          <span className="badge">О компании</span>
          <h1 className="section-title">Эксперты по созданию цифровых сервисов</h1>
          <p className="section-subtitle">
            Сайт компании — команда стратегов, дизайнеров, аналитиков и разработчиков,
            объединенных миссией создавать технологические продукты, которые трансформируют бизнес
            и усиливают конкурентные преимущества клиентов. Мы опираемся на глубокие исследования,
            четкую методологию и прозрачную коммуникацию.
          </p>
        </motion.div>
      </section>

      <section>
        <h2 className="section-title">Наши ценности и подход</h2>
        <div className="feature-grid">
          {[
            {
              title: "Ответственность",
              description:
                "Мы берем на себя ответственность за результат на каждом этапе проекта, обеспечивая устойчивую работу цифровых решений.",
            },
            {
              title: "Инновации",
              description:
                "Внедряем новые технологии и подходы, создавая долгосрочные конкурентные преимущества для наших клиентов.",
            },
            {
              title: "Партнерство",
              description:
                "Работаем как единая команда с заказчиком, выстраивая прозрачный диалог и долгосрочные отношения.",
            },
            {
              title: "Безопасность",
              description:
                "Соблюдаем требования российского и международного законодательства, обеспечиваем непрерывность бизнес-процессов.",
            },
          ].map((item) => (
            <motion.div
              key={item.title}
              className="feature-card"
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5 }}
            >
              <h3>{item.title}</h3>
              <p>{item.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="glass-panel">
        <h2 className="section-title">Этапы развития</h2>
        <div className="timeline">
          {[
            {
              year: "2012",
              title: "Основание и первые проекты",
              description:
                "Фокус на корпоративных сайтах и интранет-платформах, создание собственной дизайн-системы.",
            },
            {
              year: "2016",
              title: "Цифровая трансформация",
              description:
                "Расширение компетенций: интеграции с CRM/ERP, аналитика и автоматизация процессов.",
            },
            {
              year: "2019",
              title: "Команда R&D",
              description:
                "Запуск исследовательского центра, внедрение машинного обучения и модульных архитектур.",
            },
            {
              year: "2023",
              title: "360° digital",
              description:
                "Комплексные решения: стратегия, CX, данные, омниканальныя коммуникации и поддержка.",
            },
          ].map((item) => (
            <motion.article
              key={item.year}
              className="timeline-item"
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.45 }}
            >
              <h4>
                {item.title}
                <time>{item.year}</time>
              </h4>
              <p>{item.description}</p>
            </motion.article>
          ))}
        </div>
      </section>

      <section>
        <motion.div
          className="highlight-card"
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="section-title">Миссия</h2>
          <p className="section-subtitle" style={{ margin: "0 auto" }}>
            Мы помогаем компаниям строить цифровые продукты, которые усиливают доверие, ускоряют
            внедрение инноваций и открывают новые источники роста. Сайт компании — это синергия
            лидерства, технологий и дизайна.
          </p>
        </motion.div>
      </section>
    </div>
  );
};

export default About;