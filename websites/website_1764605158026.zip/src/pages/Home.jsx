import { motion } from "framer-motion";
import { NavLink } from "react-router-dom";

const Home = () => {
  return (
    <div className="page home-page">
      <section className="hero">
        <motion.div
          className="hero-content"
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 0.84, 0.44, 1] }}
        >
          <span className="badge">Сайт компании</span>
          <h1>
            Цифровая экосистема для <span style={{ color: "var(--color-primary)" }}>вашего бизнеса</span>
          </h1>
          <p>
            Сайт компании формирует единый центр управления корпоративными данными,
            ускоряет принятие решений и обеспечивает безупречный клиентский опыт.
            Мы объединяем стратегию, дизайн и технологии, чтобы создавать продукты,
            которые работают сегодня и масштабируются завтра.
          </p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
            <NavLink to="/services" className="primary-button">
              Изучить услуги
            </NavLink>
            <NavLink to="/about" className="secondary-button">
              О компании
            </NavLink>
          </div>
        </motion.div>
        <motion.div
          className="hero-visual"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, ease: [0.19, 1, 0.22, 1] }}
        >
          <motion.img
            src="https://cdn.pixabay.com/photo/2018/01/23/13/28/architecture-3105564_1280.jpg"
            alt="Современное корпоративное пространство"
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          />
          <motion.img
            src="https://cdn.pixabay.com/photo/2017/08/01/08/29/people-2567566_1280.jpg"
            alt="Команда специалистов, обсуждающих стратегию"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            style={{ width: "70%", justifySelf: "end", marginTop: "-40px" }}
          />
        </motion.div>
      </section>

      <section className="glass-panel">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55 }}
        >
          <h2 className="section-title">Интеллектуальная платформа для роста</h2>
          <p className="section-subtitle">
            Сайт компании — это связующее звено между стратегическими целями,
            операционной эффективностью и ожиданиями клиентов. Мы проектируем
            уникальные решения, ориентируясь на качество, безопасность и скорость работы.
          </p>
        </motion.div>

        <div className="feature-grid">
          {[
            {
              title: "Дизайн нового поколения",
              description:
                "Продуманные интерфейсы с микровзаимодействиями, анимацией и стеклянным эффектом создают ощущение премиального продукта.",
            },
            {
              title: "Интеграции без границ",
              description:
                "Объединяем CRM, ERP, BI и кастомные сервисы в единую цифровую экосистему без рисков для устойчивости.",
            },
            {
              title: "Скорость и безопасность",
              description:
                "Адаптивная архитектура, оптимизация производительности, защита данных и соответствие требованиям российского законодательства.",
            },
            {
              title: "Команда экспертов",
              description:
                "Мы сопровождаем проект на всех этапах: от исследования и концепции до внедрения и поддержки.",
            },
          ].map((feature) => (
            <motion.div
              key={feature.title}
              className="feature-card"
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.55 }}
            >
              <h3>{feature.title}</h3>
              <p>{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <motion.section
        className="stat-strip"
        initial={{ opacity: 0, y: 22 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5 }}
      >
        {[
          { label: "лет экспертизы", value: "12+" },
          { label: "успешных проектов", value: "350" },
          { label: "уровень удовлетворенности", value: "98%" },
          { label: "время вывода решений", value: "30 дней" },
        ].map((stat) => (
          <div className="stat" key={stat.label}>
            <strong>{stat.value}</strong>
            <span>{stat.label}</span>
          </div>
        ))}
      </motion.section>

      <section>
        <motion.div
          className="highlight-card"
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.6 }}
        >
          <span className="badge">Цифровая трансформация</span>
          <h2 className="section-title">Мы проектируем корпоративный опыт будущего</h2>
          <p className="section-subtitle" style={{ margin: "0 auto" }}>
            Сайт компании сочетает аналитический подход, глубокое понимание индустрий
            и современные UI-паттерны. Мы создаем решения, которые повышают эффективность,
            вдохновляют сотрудников и расширяют доверие клиентов.
          </p>
          <div style={{ display: "flex", justifyContent: "center", gap: "16px", flexWrap: "wrap" }}>
            <NavLink to="/contact" className="primary-button">
              Запросить консультацию
            </NavLink>
            <NavLink to="/faq" className="secondary-button">
              Частые вопросы
            </NavLink>
          </div>
        </motion.div>
      </section>
    </div>
  );
};

export default Home;