import { motion } from "framer-motion";

const Contact = () => {
  return (
    <div className="page">
      <section className="glass-panel">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <span className="badge">Контакты</span>
          <h1 className="section-title">Свяжитесь с командой Сайт компании</h1>
          <p className="section-subtitle">
            Мы внимательно изучим задачу, предложим оптимальную дорожную карту и согласуем формат
            сотрудничества. Контактная информация будет уточнена пользователем.
          </p>
        </motion.div>
      </section>

      <section className="contact-wrapper">
        <motion.div
          className="contact-card"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55 }}
        >
          <h2 style={{ margin: 0 }}>Давайте обсудим проект</h2>
          <p style={{ color: "var(--color-text-muted)", lineHeight: 1.6 }}>
            Оставьте заявку, и мы подготовим персональную консультацию, предложим формат
            сотрудничества и обсудим сроки. Контактная информация будет уточнена пользователем.
          </p>
          <div className="contact-details">
            <div>
              <strong>Режим работы</strong>
              <div>Пн–Пт, 10:00–19:00 (Мск)</div>
            </div>
            <div>
              <strong>Адрес</strong>
              <div>Данные адреса требуют уточнения от пользователя</div>
            </div>
            <div>
              <strong>Телефон</strong>
              <div>Номер телефона будет предоставлен пользователем</div>
            </div>
            <div>
              <strong>Электронная почта</strong>
              <div>Адрес электронной почты требует уточнения</div>
            </div>
          </div>
        </motion.div>

        <motion.form
          className="contact-card contact-form"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55 }}
          aria-label="Форма обратной связи"
        >
          <div>
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Ваше имя"
              required
            />
          </div>
          <div>
            <label htmlFor="company">Компания</label>
            <input
              id="company"
              name="company"
              type="text"
              placeholder="Название компании"
            />
          </div>
          <div>
            <label htmlFor="email">Электронная почта</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@example.ru"
              required
            />
          </div>
          <div>
            <label htmlFor="phone">Телефон</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              placeholder="+7 (___) ___-__-__"
            />
          </div>
          <div>
            <label htmlFor="message">Кратко опишите задачу</label>
            <textarea
              id="message"
              name="message"
              placeholder="Опишите проект, сроки и ожидания"
              required
            />
          </div>
          <button type="submit" className="primary-button">
            Отправить запрос
          </button>
        </motion.form>
      </section>

      <section className="highlight-card">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.45 }}
        >
          <h2 className="section-title">Персональная презентация</h2>
          <p className="section-subtitle" style={{ margin: "0 auto" }}>
            Мы подготовим презентацию Сайт компании с примерами релевантных кейсов, адаптированную
            под отрасль и специфику вашей компании. Свяжитесь с нами и получите индивидуальное
            предложение.
          </p>
        </motion.div>
      </section>
    </div>
  );
};

export default Contact;