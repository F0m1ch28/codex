import React, { useEffect, useState, useRef } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import styles from "./Home.module.css";

const heroImage = "https://picsum.photos/1600/900?random=101";

const statsData = [
  { label: "Лет в индустрии", value: 8, suffix: "+" },
  { label: "Запущенных проектов", value: 240, suffix: "+" },
  { label: "Международных клиентов", value: 18, suffix: "" },
  { label: "Наград за дизайн", value: 32, suffix: "" },
];

const servicesData = [
  {
    title: "Цифровой продукт",
    description: "Создание сайтов и веб-платформ с акцентом на продуктивность и эмоциональный визуал.",
    icon: "🖥️",
    link: "/uslugi",
  },
  {
    title: "Айдентика бренда",
    description: "Выстраиваем визуальный язык, который демонстрирует характер компании и раскрывает ценности.",
    icon: "✨",
    link: "/uslugi",
  },
  {
    title: "UI/UX дизайн",
    description: "Исследуем аудиторию, строим сценарии и создаём интерфейсы, которые любят пользователи.",
    icon: "🎯",
    link: "/uslugi",
  },
];

const processSteps = [
  {
    title: "Аналитика",
    description: "Изучаем аудиторию, рынок и визуальные ориентиры, чтобы точно определить фокус будущего дизайна.",
    number: "01",
  },
  {
    title: "Концепция",
    description: "Формируем визуальную систему, moodboard и дизайн-направление для согласования с командой клиента.",
    number: "02",
  },
  {
    title: "Дизайн и прототипы",
    description: "Разрабатываем страницы, интерфейсы и графику. Тестируем сценарии и адаптивы.",
    number: "03",
  },
  {
    title: "Запуск и поддержка",
    description: "Передаём гайдлайны, сопровождаем внедрение и готовим материал для маркетинга.",
    number: "04",
  },
];

const testimonialData = [
  {
    quote:
      "Команда Creative Design Studio помогла нам полностью переосмыслить бренд. Их внимание к деталям и понимание бизнеса впечатляет.",
    author: "Екатерина Смирнова",
    position: "Маркетинг-директор, Fintech One",
  },
  {
    quote:
      "Мы получили интерфейс, который не только выглядит современно, но и повысил конверсию на 35%. Работать с ними — одно удовольствие.",
    author: "Алексей Громов",
    position: "СЕО, Nova Logistics",
  },
  {
    quote:
      "CDS создали для нас глобальную идентику, которую теперь узнают на трёх континентах. Четкий процесс и блестящий результат.",
    author: "Мария Власова",
    position: "Основатель, Eco Beauty Global",
  },
];

const teamMembers = [
  {
    name: "Анна Кузнецова",
    role: "Креативный директор",
    image: "https://picsum.photos/400/400?random=301",
    bio: "Разрабатывает стратегию бренда и курирует все визуальные направления студии.",
  },
  {
    name: "Илья Петров",
    role: "UX-стратег",
    image: "https://picsum.photos/400/400?random=302",
    bio: "Отвечает за исследования аудитории и создает удобные пользовательские сценарии.",
  },
  {
    name: "Марина Литвинова",
    role: "Арт-директор",
    image: "https://picsum.photos/400/400?random=303",
    bio: "Фокусируется на визуальных концепциях и геометрической точности решений.",
  },
  {
    name: "Дмитрий Орлов",
    role: "Ведущий UI-дизайнер",
    image: "https://picsum.photos/400/400?random=304",
    bio: "Создает адаптивные интерфейсы и настраивает дизайн-системы для масштабирования.",
  },
];

const faqData = [
  {
    question: "Как строится работа над проектом?",
    answer:
      "Мы начинаем с аналитики и воркшопа с вашей командой, затем утверждаем концепцию, переходим к дизайну и тестированию, а на финальном этапе сопровождаем запуск.",
  },
  {
    question: "Работаете ли вы с международными компаниями?",
    answer:
      "Да, у нас есть опыт сотрудничества с брендами из Европы, США и Азии. Мы выстраиваем процессы с учетом часовых поясов и культурных особенностей.",
  },
  {
    question: "Сколько времени занимает бренд-проект?",
    answer:
      "В среднем от 6 до 10 недель в зависимости от объема материалов и количества точек контакта, которые необходимо разработать.",
  },
  {
    question: "Можно ли поручить команде поддерживающий дизайн?",
    answer:
      "Мы предлагаем формат дизайн-партнёрства — подключаем dedicated команду для ежемесячной работы над вашими задачами.",
  },
];

const blogPosts = [
  {
    title: "Как геометрия в дизайне усиливает восприятие бренда",
    image: "https://picsum.photos/800/600?random=801",
    excerpt: "Рассматриваем принципы композиций и геометрических акцентов, которые помогают брендам показать характер.",
    date: "15 апреля 2024",
    link: "/blog",
  },
  {
    title: "UX-стратегия для международного e-commerce проекта",
    image: "https://picsum.photos/800/600?random=802",
    excerpt: "Какие исследования, CJM и метрики закладываем в основу масштабных платформ.",
    date: "3 апреля 2024",
    link: "/blog",
  },
  {
    title: "Как построить дизайн-систему для SaaS продукта",
    image: "https://picsum.photos/800/600?random=803",
    excerpt: "Делимся опытом создания гибкой UI-библиотеки, которая облегчает разработку и ускоряет релизы.",
    date: "21 марта 2024",
    link: "/blog",
  },
];

const portfolioProjects = [
  {
    title: "Quantum Finance Platform",
    category: "web",
    image: "https://picsum.photos/1200/800?random=401",
    description: "Цифровой банкинг-сервис с адаптивной системой дашбордов.",
  },
  {
    title: "Hillcrest Branding",
    category: "branding",
    image: "https://picsum.photos/1200/800?random=402",
    description: "Айдентика девелоперского бренда с модульной геометрией.",
  },
  {
    title: "Synthesis Health App",
    category: "uiux",
    image: "https://picsum.photos/1200/800?random=403",
    description: "Мобильный сервис телемедицины с индивидуальными сценариями.",
  },
  {
    title: "Aurora Tech Website",
    category: "web",
    image: "https://picsum.photos/1200/800?random=404",
    description: "Корпоративный сайт для международной технологической группы.",
  },
  {
    title: "Linea Cosmetics",
    category: "branding",
    image: "https://picsum.photos/1200/800?random=405",
    description: "Глобальная визуальная система для косметического бренда.",
  },
  {
    title: "Flow ERP Dashboard",
    category: "uiux",
    image: "https://picsum.photos/1200/800?random=406",
    description: "Дизайн комплексного ERP-интерфейса с аналитикой в реальном времени.",
  },
];

const Home = () => {
  const [heroOffset, setHeroOffset] = useState(0);
  const [activeCategory, setActiveCategory] = useState("all");
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [stats, setStats] = useState(statsData.map(() => 0));
  const [statsAnimated, setStatsAnimated] = useState(false);
  const statsRef = useRef(null);
  const heroMediaRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      setHeroOffset(window.scrollY);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial(
        (prev) => (prev + 1) % testimonialData.length
      );
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !statsAnimated) {
            setStatsAnimated(true);
          }
        });
      },
      { threshold: 0.4 }
    );
    if (statsRef.current) observer.observe(statsRef.current);
    return () => {
      if (statsRef.current) observer.unobserve(statsRef.current);
    };
  }, [statsAnimated]);

  useEffect(() => {
    if (!statsAnimated) return;

    const intervals = statsData.map((stat, index) => {
      let start = 0;
      const duration = 1600;
      const stepTime = Math.max(Math.floor(duration / stat.value), 20);
      return setInterval(() => {
        start += 1;
        setStats((prev) => {
          const updated = [...prev];
          updated[index] = Math.min(start, stat.value);
          return updated;
        });
        if (start >= stat.value) {
          clearInterval(intervals[index]);
        }
      }, stepTime);
    });

    return () => intervals.forEach((interval) => clearInterval(interval));
  }, [statsAnimated]);

  const filteredProjects =
    activeCategory === "all"
      ? portfolioProjects
      : portfolioProjects.filter((project) => project.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Creative Design Studio — Дизайн брендов и цифровых продуктов</title>
        <meta
          name="description"
          content="Creative Design Studio создаёт выразительный веб- и графический дизайн, поддерживает бренды и запускает цифровые продукты по всему миру."
        />
      </Helmet>

      <section className={styles.hero}>
        <div
          className={styles.heroMedia}
          ref={heroMediaRef}
          style={{ transform: `translateY(${heroOffset * 0.2}px)` }}
        >
          <img src={heroImage} alt="Команда дизайн-студии за работой" loading="lazy" />
        </div>
        <div className="container">
          <div className={styles.heroContent}>
            <span className={styles.heroTag}>Дизайн-студия нового поколения</span>
            <h1 className={styles.heroTitle}>
              Создаём дизайн, который помогает бизнесу уверенно расти.
            </h1>
            <p className={styles.heroSubtitle}>
              От айдентики до масштабных веб-платформ — мы проектируем визуальные системы, которые точно передают ДНК бренда и обеспечивают выдающиеся пользовательские сценарии.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryBtn}>
                Обсудить проект
              </Link>
              <Link to="/portfolio" className={styles.secondaryBtn}>
                Смотреть проекты
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.stats} ref={statsRef}>
        <div className="container">
          <div className={styles.statsGrid}>
            {statsData.map((stat, index) => (
              <div key={stat.label} className={styles.statCard}>
                <span className={styles.statValue} aria-live="polite">
                  {stats[index]}
                  {stat.suffix}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.services} id="services">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Услуги</span>
            <h2>Комплексный дизайн и бренд-опыт</h2>
            <p>
              Мы соединяем стратегию, эстетику и технологии, чтобы создавать решения, которые работают и выглядят безупречно на любой платформе.
            </p>
          </div>
          <div className={styles.servicesGrid}>
            {servicesData.map((service) => (
              <article key={service.title} className={styles.serviceCard}>
                <span className={styles.serviceIcon} aria-hidden="true">
                  {service.icon}
                </span>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
                <Link to={service.link} className={styles.serviceLink}>
                  Подробнее →
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.portfolio}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Портфолио</span>
            <h2>Проекты, которые выделяют бренды</h2>
          </div>
          <div className={styles.filter}>
            <button
              type="button"
              className={`${styles.filterBtn} ${activeCategory === "all" ? styles.filterActive : ""}`}
              onClick={() => setActiveCategory("all")}
            >
              Все
            </button>
            <button
              type="button"
              className={`${styles.filterBtn} ${activeCategory === "web" ? styles.filterActive : ""}`}
              onClick={() => setActiveCategory("web")}
            >
              Веб-дизайн
            </button>
            <button
              type="button"
              className={`${styles.filterBtn} ${activeCategory === "branding" ? styles.filterActive : ""}`}
              onClick={() => setActiveCategory("branding")}
            >
              Брендинг
            </button>
            <button
              type="button"
              className={`${styles.filterBtn} ${activeCategory === "uiux" ? styles.filterActive : ""}`}
              onClick={() => setActiveCategory("uiux")}
            >
              UI/UX
            </button>
          </div>
          <div className={styles.portfolioGrid}>
            {filteredProjects.map((project) => (
              <article key={project.title} className={styles.projectCard}>
                <div className={styles.projectImageWrapper}>
                  <img src={project.image} alt={`Проект: ${project.title}`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className={styles.projectCategory}>{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.portfolioCTA}>
            <Link to="/portfolio" className={styles.primaryBtn}>
              Все кейсы студии
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.process}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Процесс</span>
            <h2>Прозрачность на каждом этапе</h2>
          </div>
          <div className={styles.processTimeline}>
            {processSteps.map((step) => (
              <div key={step.number} className={styles.processStep}>
                <span className={styles.processNumber}>{step.number}</span>
                <div className={styles.processContent}>
                  <h3>{step.title}</h3>
                  <p>{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.testimonials} aria-label="Отзывы клиентов">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Отзывы</span>
            <h2>Нам доверяют лидеры индустрий</h2>
          </div>
          <div className={styles.testimonialSlider}>
            {testimonialData.map((testimonial, index) => (
              <figure
                key={testimonial.author}
                className={`${styles.testimonialCard} ${
                  currentTestimonial === index ? styles.testimonialActive : ""
                }`}
                aria-hidden={currentTestimonial !== index}
              >
                <blockquote>{testimonial.quote}</blockquote>
                <figcaption>
                  <span className={styles.testimonialAuthor}>{testimonial.author}</span>
                  <span className={styles.testimonialPosition}>{testimonial.position}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.team} id="team">
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Команда</span>
            <h2>Эксперты своего дела</h2>
            <p>
              Разнообразный опыт в брендинге, продуктовом дизайне и креативных стратегиях помогает нам собирать сильные междисциплинарные команды.
            </p>
          </div>
          <div className={styles.teamGrid}>
            {teamMembers.map((member) => (
              <article key={member.name} className={styles.teamCard}>
                <div className={styles.teamImage}>
                  <img src={member.image} alt={member.name} loading="lazy" />
                </div>
                <div className={styles.teamInfo}>
                  <h3>{member.name}</h3>
                  <span>{member.role}</span>
                  <p>{member.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.faq}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>FAQ</span>
            <h2>Часто задаваемые вопросы</h2>
          </div>
          <div className={styles.faqList}>
            {faqData.map((item, index) => (
              <details key={item.question} className={styles.faqItem}>
                <summary>{item.question}</summary>
                <p>{item.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.blog}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <span className={styles.kicker}>Блог</span>
            <h2>Последние инсайты студии</h2>
          </div>
          <div className={styles.blogGrid}>
            {blogPosts.map((post) => (
              <article key={post.title} className={styles.blogCard}>
                <div className={styles.blogImage}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <span className={styles.blogDate}>{post.date}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <Link to={post.link} className={styles.blogLink}>
                    Читать →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.cta}>
        <div className="container">
          <div className={styles.ctaContent}>
            <h2>Готовы усилить бренд и продукт?</h2>
            <p>
              Проведём бесплатную консультацию: разберём задачу, сформируем гипотезы и предложим план дальнейших шагов.
            </p>
            <div className={styles.heroActions}>
              <Link to="/kontakty" className={styles.primaryBtn}>
                Назначить созвон
              </Link>
              <Link to="/uslugi" className={styles.secondaryBtn}>
                Узнать больше
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;