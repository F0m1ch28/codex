import React from "react";
import { Helmet } from "react-helmet";
import styles from "./CookiePolicy.module.css";

const CookiePolicy = () => {
  return (
    <>
      <Helmet>
        <title>Политика cookies | Creative Design Studio</title>
      </Helmet>

      <section className={styles.section}>
        <div className="container">
          <h1>Политика использования cookies</h1>
          <p>Дата обновления: 5 апреля 2024 года</p>

          <h2>Что такое cookies</h2>
          <p>
            Cookies — это небольшие файлы, сохраняемые на вашем устройстве при посещении сайта. Они помогают нам анализировать трафик и улучшать сервис.
          </p>

          <h2>Как мы используем cookies</h2>
          <p>
            Мы используем cookies для аналитики посещаемости, запоминания ваших предпочтений и ускорения работы сайта.
          </p>

          <h2>Как управлять cookies</h2>
          <p>
            Вы можете настроить использование cookies в настройках браузера. Обратите внимание, что отключение некоторых файлов может повлиять на функциональность сайта.
          </p>

          <h2>Связь с нами</h2>
          <p>
            Вопросы по cookies можно направить на hello@creativedesign.ru.
          </p>
        </div>
      </section>
    </>
  );
};

export default CookiePolicy;