import React from "react";
import { Helmet } from "react-helmet";
import styles from "./About.module.css";

const storyImage = "https://picsum.photos/1200/800?random=502";
const cultureImage = "https://picsum.photos/1200/800?random=503";

const About = () => {
  return (
    <>
      <Helmet>
        <title>О студии | Creative Design Studio</title>
        <meta
          name="description"
          content="Creative Design Studio — команда стратегов, дизайнеров и исследователей, создающих уникальные бренды и цифровые продукты."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <span className={styles.kicker}>О студии</span>
          <h1>Мы строим дизайн-стратегии, которые повышают ценность бизнеса.</h1>
          <p>
            С 2016 года Creative Design Studio помогает компаниям из России, Европы, США и Азии создавать яркие бренды и сервисы. Мы верим в силу визуального языка, основанного на данных и внимании к деталям.
          </p>
        </div>
      </section>

      <section className={styles.story}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.textBlock}>
              <h2>История студии</h2>
              <p>
                Creative Design Studio родилась как независимая команда из трёх дизайнеров, которые хотели создавать честный дизайн без шаблонов. Сегодня мы — международная команда стратегов, дизайнеров, продюсеров и исследователей, работающих в гибридном формате.
              </p>
              <p>
                Мы фокусируемся на глубоких исследованиях и выстраиваем прозрачные процессы: от discovery-сессий до передачи гайдлайнов и сопровождения внедрения. Каждый проект возглавляет кросс-функциональная команда, ориентированная на конкретные KPI клиента.
              </p>
            </div>
            <div className={styles.imageBlock}>
              <img src={storyImage} alt="Команда Creative Design Studio на воркшопе" loading="lazy" />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.values}>
        <div className="container">
          <h2>Наши ценности</h2>
          <div className={styles.valuesGrid}>
            <article>
              <h3>Синергия данных и эстетики</h3>
              <p>Дизайн опирается на аналитические инсайты и проверяется реальными сценариями пользователей.</p>
            </article>
            <article>
              <h3>Прозрачность и диалог</h3>
              <p>Мы вовлекаем клиентов в процесс, делимся промежуточными результатами и вместе принимаем ключевые решения.</p>
            </article>
            <article>
              <h3>Геометрия и структурность</h3>
              <p>Геометрические акценты и модульные сетки помогают создавать визуально сильные и узнаваемые решения.</p>
            </article>
          </div>
        </div>
      </section>

      <section className={styles.culture}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.imageBlock}>
              <img src={cultureImage} alt="Дизайнеры студии обсуждают проект" loading="lazy" />
            </div>
            <div className={styles.textBlock}>
              <h2>Культура и команда</h2>
              <p>
                Мы создаём пространство, где каждый дизайнер участвует в стратегии и исследовании, а не только в визуализации. Команда всегда работает в связке с аналитиками, проджект-менеджерами и экспертами по брендингу.
              </p>
              <ul className={styles.list}>
                <li>Собственные воркшопы и дизайн-спринты.</li>
                <li>Внутренняя академия по работе с международными клиентами.</li>
                <li>Поддержка дизайн-систем и участие в релизах продуктов.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.metrics}>
        <div className="container">
          <h2>Факты о Creative Design Studio</h2>
          <div className={styles.metricsGrid}>
            <div>
              <span>75%</span>
              <p>клиентов приходят по рекомендациям</p>
            </div>
            <div>
              <span>5</span>
              <p>отраслей, в которых мы особенно сильны: финтех, SaaS, девелопмент, медиа, образование</p>
            </div>
            <div>
              <span>12</span>
              <p>дизайн-наград международных конкурсов за последние 3 года</p>
            </div>
            <div>
              <span>24/7</span>
              <p>поддержка и сопровождение запусков в ключевые фазы проекта</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;