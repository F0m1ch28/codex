import React from "react";
import { Helmet } from "react-helmet";
import ContactForm from "../components/ContactForm";
import styles from "./Contact.module.css";

const Contact = () => {
  return (
    <>
      <Helmet>
        <title>Контакты | Creative Design Studio</title>
        <meta
          name="description"
          content="Свяжитесь с Creative Design Studio: консультации по дизайну, брендингу и цифровым продуктам."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <span className={styles.kicker}>Контакты</span>
          <h1>Расскажите о задаче — мы предложим решение.</h1>
          <p>Опишите цели, сроки и желаемый формат работы. Мы подготовим план действий и обсудим его с вами на консультации.</p>
        </div>
      </section>

      <section className={styles.content}>
        <div className="container">
          <div className={styles.grid}>
            <div className={styles.info}>
              <h2>Связаться напрямую</h2>
              <ul>
                <li>
                  Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a>
                </li>
                <li>
                  Email: <a href="mailto:hello@creativedesign.ru">hello@creativedesign.ru</a>
                </li>
                <li>Адрес: Москва, ул. Тверская, д. 15, офис 304</li>
              </ul>
              <div className={styles.time}>
                <h3>Время работы</h3>
                <p>Пн — Пт: 10:00 — 19:00 (MSK)</p>
                <p>Сб — Вс: по предварительной записи</p>
              </div>
            </div>
            <div className={styles.formWrapper}>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      <section className={styles.mapSection} aria-label="Карта офиса">
        <iframe
          title="Creative Design Studio на карте Москвы"
          src="https://yandex.ru/map-widget/v1/?um=constructor%3A1aa1d9bd1f717a8ba4a8988e85b2e1fa05f7f96e65e6a85cc16bc9d88f5602d8&amp;source=constructor"
          width="100%"
          height="420"
          frameBorder="0"
          allowFullScreen
        />
      </section>
    </>
  );
};

export default Contact;