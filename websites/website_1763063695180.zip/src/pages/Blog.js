import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Blog.module.css";

const posts = [
  {
    title: "Микровзаимодействия: как небольшие детали меняют восприятие продукта",
    image: "https://picsum.photos/900/600?random=901",
    excerpt: "Разбираем лучшие практики анимаций и микроинтеракций, которые повышают доверие пользователей.",
    date: "5 апреля 2024",
  },
  {
    title: "Создаём геометричный брендинг для B2B компаний",
    image: "https://picsum.photos/900/600?random=902",
    excerpt: "Почему строгие сетки, чёткие паттерны и правильная типографика помогают B2B-бизнесу быть заметным.",
    date: "29 марта 2024",
  },
  {
    title: "UX-исследования: как мы тестируем решения до запуска",
    image: "https://picsum.photos/900/600?random=903",
    excerpt: "Методы интервью, прототипирования и аналитики, которые мы внедряем на этапах discovery и design.",
    date: "18 марта 2024",
  },
  {
    title: "Фреймворк визуальной консистентности для SaaS",
    image: "https://picsum.photos/900/600?random=904",
    excerpt: "О структуре дизайн-системы, модульном подходе и поддержке больших продуктовых команд.",
    date: "7 марта 2024",
  },
  {
    title: "Как выбрать цветовую палитру для международного бренда",
    image: "https://picsum.photos/900/600?random=905",
    excerpt: "Говорим об ассоциациях, контрастах и культурных кодах при работе с глобальными аудиториями.",
    date: "27 февраля 2024",
  },
  {
    title: "Дизайн-ревью: пошаговый процесс студии",
    image: "https://picsum.photos/900/600?random=906",
    excerpt: "Показываем, как мы проводим аудит продукта и формируем actionable рекомендации.",
    date: "15 февраля 2024",
  },
];

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Блог | Creative Design Studio</title>
        <meta
          name="description"
          content="Инсайты и статьи Creative Design Studio про брендинг, UX-исследования, дизайн-системы и визуальные тренды."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <span className={styles.kicker}>Блог студии</span>
          <h1>Исследуем, тестируем, делимся опытом.</h1>
          <p>
            Мы регулярно публикуем заметки о том, как строим стратегию, прорабатываем визуальные концепции и запускаем продукты.
          </p>
        </div>
      </section>

      <section className={styles.posts}>
        <div className="container">
          <div className={styles.grid}>
            {posts.map((post) => (
              <article key={post.title} className={styles.card}>
                <div className={styles.image}>
                  <img src={post.image} alt={post.title} loading="lazy" />
                </div>
                <div className={styles.content}>
                  <span>{post.date}</span>
                  <h2>{post.title}</h2>
                  <p>{post.excerpt}</p>
                  <button type="button" className={styles.readMore}>
                    Читать статью
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Blog;