import React, { useState } from "react";
import { Helmet } from "react-helmet";
import styles from "./Portfolio.module.css";

const projects = [
  {
    title: "Aerolite Aerospace",
    category: "Брендинг",
    image: "https://picsum.photos/1200/800?random=701",
    description: "Айдентика для компании, создающей спутниковые системы и автономные модули.",
  },
  {
    title: "Atlas Insurance Platform",
    category: "UI/UX",
    image: "https://picsum.photos/1200/800?random=702",
    description: "Комплексный портал страхования с персонализированным дашбордом.",
  },
  {
    title: "Carbon Studio Website",
    category: "Веб-дизайн",
    image: "https://picsum.photos/1200/800?random=703",
    description: "Сайт студии архитектуры с интерактивными 3D-элементами и лаконичной композицией.",
  },
  {
    title: "Deepwave Analytics",
    category: "UI/UX",
    image: "https://picsum.photos/1200/800?random=704",
    description: "Панель аналитики для анализа данных в режиме реального времени.",
  },
  {
    title: "Nova Residential",
    category: "Брендинг",
    image: "https://picsum.photos/1200/800?random=705",
    description: "Айдентика девелоперского бренда с модульным паттерном и строгой типографикой.",
  },
  {
    title: "Sfera Culture Hub",
    category: "Веб-дизайн",
    image: "https://picsum.photos/1200/800?random=706",
    description: "Платформа культурных мероприятий с системой бронирования и личным кабинетом.",
  },
];

const categories = ["Все", "Брендинг", "Веб-дизайн", "UI/UX"];

const Portfolio = () => {
  const [active, setActive] = useState("Все");
  const filtered =
    active === "Все" ? projects : projects.filter((project) => project.category === active);

  return (
    <>
      <Helmet>
        <title>Портфолио | Creative Design Studio</title>
        <meta
          name="description"
          content="Избранные проекты Creative Design Studio: брендинг, веб-дизайн и интерфейсы для международных компаний."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <span className={styles.kicker}>Кейсы</span>
          <h1>Каждый проект — история о сильном бренде.</h1>
          <p>
            Мы работаем с международными компаниями, технологическими стартапами и креативными предпринимателями. Здесь — часть проектов, которыми мы гордимся.
          </p>
        </div>
      </section>

      <section className={styles.projects}>
        <div className="container">
          <div className={styles.filters}>
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className={`${styles.filterBtn} ${category === active ? styles.active : ""}`}
                onClick={() => setActive(category)}
              >
                {category}
              </button>
            ))}
          </div>

          <div className={styles.grid}>
            {filtered.map((project) => (
              <article key={project.title} className={styles.card}>
                <div className={styles.image}>
                  <img src={project.image} alt={project.title} loading="lazy" />
                </div>
                <div className={styles.content}>
                  <span>{project.category}</span>
                  <h2>{project.title}</h2>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Portfolio;