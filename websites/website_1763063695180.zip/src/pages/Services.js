import React from "react";
import { Helmet } from "react-helmet";
import styles from "./Services.module.css";

const servicesDetails = [
  {
    title: "Бренд-стратегия и айдентика",
    description:
      "Исследуем позиционирование, создаём tone of voice, визуальный язык, гайдлайны, ключевые графические элементы и пакеты презентационных материалов.",
    points: [
      "Стратегические воркшопы и исследование аудитории",
      "Moodboard, визуальные концепции, манифест бренда",
      "Дизайн логотипа, шрифт, цветовая система, сетки",
      "Brand book, гайд по коммуникациям, social media toolkit",
    ],
    image: "https://picsum.photos/1000/700?random=610",
  },
  {
    title: "Веб-дизайн и разработка",
    description:
      "Проектируем сайты и landing pages, которые конвертируют аудиторию в лиды, визуально раскрывают продукт и корректно масштабируются.",
    points: [
      "Информационная архитектура, CJM и прототипы",
      "UI-дизайн на основе дизайн-системы и адаптивных сеток",
      "Анимации, микровзаимодействия, подготовка к разработке",
      "Сопровождение внедрения, контроль качества",
    ],
    image: "https://picsum.photos/1000/700?random=611",
  },
  {
    title: "UI/UX для цифровых продуктов",
    description:
      "Создаём продуктовые интерфейсы для SaaS, ERP и мобильных приложений. Опираемся на бизнес-метрики и повышаем удобство использования.",
    points: [
      "Product discovery и анализ конкурентов",
      "Карта пользовательских сценариев и фич-листы",
      "Высокоточные прототипы и тестирование",
      "Передача дизайн-системы и UI kit разработчикам",
    ],
    image: "https://picsum.photos/1000/700?random=612",
  },
];

const Services = () => {
  return (
    <>
      <Helmet>
        <title>Услуги | Creative Design Studio</title>
        <meta
          name="description"
          content="Комплексные услуги Creative Design Studio: брендинг, веб-дизайн, UI/UX, стратегические воркшопы и сопровождение запусков."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className="container">
          <span className={styles.kicker}>Услуги студии</span>
          <h1>Гармония стратегии, визуала и технологий.</h1>
          <p>
            Мы проектируем дизайн-системы, которые усиливают бизнес-результаты: повышают узнаваемость, улучшают конверсию и помогают масштабировать продукты.
          </p>
        </div>
      </section>

      <section className={styles.servicesList}>
        <div className="container">
          {servicesDetails.map((service, index) => (
            <article
              key={service.title}
              className={`${styles.serviceItem} ${index % 2 === 1 ? styles.inverse : ""}`}
            >
              <div className={styles.text}>
                <h2>{service.title}</h2>
                <p>{service.description}</p>
                <ul>
                  {service.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
              <div className={styles.image}>
                <img src={service.image} alt={service.title} loading="lazy" />
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.partnership}>
        <div className="container">
          <div className={styles.partnershipContent}>
            <h2>Форматы сотрудничества</h2>
            <div className={styles.partnershipGrid}>
              <div>
                <h3>Проектная работа</h3>
                <p>Идеально подходит для создания нового бренда, запуска сайта или выпуска крупного продукта.</p>
              </div>
              <div>
                <h3>Дизайн-партнёрство</h3>
                <p>Поддерживаем вашу команду на постоянной основе: ежемесячные спринты, дизайн-система и быстрые релизы.</p>
              </div>
              <div>
                <h3>Дизайн ревью</h3>
                <p>Проводим аудит текущего продукта, выявляем точки роста, формируем рекомендации по улучшению UX и визуала.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;