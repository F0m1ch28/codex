import React from "react";
import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className="container">
        <div className={styles.grid}>
          <div>
            <Link to="/" className={styles.logo}>
              Creative Design <span>Studio</span>
            </Link>
            <p className={styles.description}>
              Мы создаём выразительные бренды, цифровые продукты и визуальные истории, которые выделяют бизнес на глобальном рынке.
            </p>
            <div className={styles.socials} aria-label="Социальные сети">
              <a href="https://www.behance.net" target="_blank" rel="noopener noreferrer" aria-label="Behance">
                <svg viewBox="0 0 24 24" role="img" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M3 6.75h4.394c2.707 0 4.407 1.263 4.399 3.738-.008 1.658-.697 2.692-2.121 3.25 1.761.472 2.622 1.635 2.606 3.436-.03 2.72-1.848 4.326-4.966 4.326H3V6.75zm4.032 5.605c1.29 0 1.962-.58 1.962-1.76 0-1.086-.715-1.624-2.046-1.624H5.16v3.384h1.872zm.319 6.11c1.41 0 2.173-.605 2.173-1.87 0-1.234-.834-1.836-2.37-1.836H5.16v3.706h2.191zM14.73 12.36c.162-1.986 1.8-3.3 4.06-3.3 2.435 0 4.018 1.4 3.98 3.454l-.008.383h-6.074c.168 1.368 1.024 2.106 2.31 2.106.953 0 1.64-.392 1.97-1.071h1.703c-.492 1.702-1.936 2.73-3.926 2.73-2.422 0-4.09-1.528-4.09-3.98zm6.065-.933c-.135-1.155-.918-1.822-2.022-1.822-1.127 0-1.94.71-2.101 1.822h4.123zM14.4 7.2h5.64v1.35H14.4V7.2z"
                  />
                </svg>
              </a>
              <a href="https://www.dribbble.com" target="_blank" rel="noopener noreferrer" aria-label="Dribbble">
                <svg viewBox="0 0 24 24" role="img" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M12 2C6.475 2 2 6.477 2 12s4.475 10 10 10 10-4.477 10-10S17.525 2 12 2zm6.744 5.46c1.078 1.32 1.707 3 1.707 4.82 0 .216-.008.43-.025.642-2.901-.606-5.282-.334-7.103.255-.138-.334-.27-.654-.404-.966 2.974-1.357 4.7-3.146 5.825-4.751zm-1.57-1.621c-.957 1.34-2.583 2.96-5.37 4.165-.976-1.795-2.01-3.329-3.016-4.603 1.041-.455 2.192-.708 3.412-.708 1.859 0 3.566.614 4.974 1.146zm-9.25-.082c1.05 1.306 2.092 2.844 3.135 4.66-2.807.85-5.79.98-8.004.947.29-2.845 2.303-5.222 4.87-5.607zm-4.862 6.66v-.059c2.437.043 5.75-.108 8.85-1.114.147.3.294.613.438.94-3.086.97-5.142 3.02-6.298 5.98A7.94 7.94 0 0 1 3.062 12.417zM12 20.94c-1.833 0-3.526-.604-4.897-1.624 1.003-2.582 2.73-4.53 5.408-5.356.867 2.17 1.515 4.542 2.036 6.942-0.817.252-1.685.395-2.547.395zm4.528-1.304c-.46-2.025-.997-3.948-1.635-5.673 1.594-.427 3.44-.512 5.57-.161-.74 2.48-2.599 4.527-3.935 5.834z"
                  />
                </svg>
              </a>
              <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                <svg viewBox="0 0 24 24" role="img" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M20.447 20.452H16.89v-4.997c0-1.19-.024-2.719-1.658-2.719-1.66 0-1.914 1.296-1.914 2.633v5.083H9.761V9h3.41v1.561h.047c.476-.9 1.637-1.848 3.37-1.848 3.602 0 4.268 2.37 4.268 5.455v6.284zM5.337 7.433c-1.097 0-1.988-.895-1.988-1.996 0-1.102.89-1.996 1.988-1.996 1.095 0 1.986.894 1.986 1.996 0 1.101-.89 1.996-1.986 1.996zM6.814 20.452H3.857V9h2.957v11.452zM22.225 0H1.771C.792 0 0 .771 0 1.723v20.553C0 23.228.792 24 1.771 24h20.451C23.2 24 24 23.228 24 22.276V1.724C24 .771 23.2 0 22.225 0z"
                  />
                </svg>
              </a>
            </div>
          </div>

          <div className={styles.column}>
            <h3 className={styles.title} id="footer-heading">
              Навигация
            </h3>
            <ul className={styles.links}>
              <li>
                <Link to="/o-studio">О студии</Link>
              </li>
              <li>
                <Link to="/uslugi">Услуги</Link>
              </li>
              <li>
                <Link to="/portfolio">Портфолио</Link>
              </li>
              <li>
                <Link to="/blog">Блог</Link>
              </li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.title}>Правовая информация</h3>
            <ul className={styles.links}>
              <li>
                <Link to="/privacy-policy">Политика конфиденциальности</Link>
              </li>
              <li>
                <Link to="/terms-of-use">Условия использования</Link>
              </li>
              <li>
                <Link to="/cookie-policy">Политика cookies</Link>
              </li>
            </ul>
          </div>

          <div className={styles.column}>
            <h3 className={styles.title}>Контакты</h3>
            <ul className={styles.contacts}>
              <li>
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>
                <a href="mailto:hello@creativedesign.ru">hello@creativedesign.ru</a>
              </li>
              <li>
                Москва, ул. Тверская, д. 15, офис 304
              </li>
            </ul>
          </div>
        </div>

        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} Creative Design Studio. Все права защищены.</p>
          <p className={styles.tagline}>Создаём дизайн, который двигает бизнес вперёд.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;