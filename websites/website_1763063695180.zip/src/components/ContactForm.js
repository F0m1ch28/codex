import React, { useState } from "react";
import styles from "./ContactForm.module.css";

const initialState = {
  name: "",
  email: "",
  company: "",
  message: "",
};

const ContactForm = () => {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Пожалуйста, укажите ваше имя.";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Введите актуальный email.";
    } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/i.test(formData.email)) {
      newErrors.email = "Проверьте корректность email.";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Расскажите немного о проекте.";
    }
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length) {
      setErrors(validationErrors);
      return;
    }
    setIsSubmitted(true);
    setFormData(initialState);
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit} noValidate>
      <div className={styles.row}>
        <label className={styles.field}>
          <span>Имя *</span>
          <input
            type="text"
            name="name"
            placeholder="Иван Иванов"
            value={formData.name}
            onChange={handleChange}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "name-error" : undefined}
          />
          {errors.name && (
            <span id="name-error" className={styles.error}>
              {errors.name}
            </span>
          )}
        </label>

        <label className={styles.field}>
          <span>Email *</span>
          <input
            type="email"
            name="email"
            placeholder="hello@company.com"
            value={formData.email}
            onChange={handleChange}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "email-error" : undefined}
          />
          {errors.email && (
            <span id="email-error" className={styles.error}>
              {errors.email}
            </span>
          )}
        </label>
      </div>

      <label className={styles.field}>
        <span>Компания</span>
        <input
          type="text"
          name="company"
          placeholder="Название вашей компании"
          value={formData.company}
          onChange={handleChange}
        />
      </label>

      <label className={styles.field}>
        <span>Сообщение *</span>
        <textarea
          name="message"
          rows="5"
          placeholder="Поделитесь деталями задачи, сроками и целями."
          value={formData.message}
          onChange={handleChange}
          aria-invalid={Boolean(errors.message)}
          aria-describedby={errors.message ? "message-error" : undefined}
        />
        {errors.message && (
          <span id="message-error" className={styles.error}>
            {errors.message}
          </span>
        )}
      </label>

      <button type="submit" className={styles.submit}>
        Отправить запрос
      </button>

      {isSubmitted && (
        <div className={styles.success} role="status">
          Спасибо! Мы свяжемся с вами в течение одного рабочего дня.
        </div>
      )}
    </form>
  );
};

export default ContactForm;