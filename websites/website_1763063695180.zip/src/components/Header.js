import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import styles from "./Header.module.css";

const navItems = [
  { path: "/", label: "Главная" },
  { path: "/o-studio", label: "О студии" },
  { path: "/uslugi", label: "Услуги" },
  { path: "/portfolio", label: "Портфолио" },
  { path: "/blog", label: "Блог" },
  { path: "/kontakty", label: "Контакты" },
];

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [isMenuOpen]);

  return (
    <header className={`${styles.header} ${isScrolled ? styles.scrolled : ""}`}>
      <div className="container">
        <div className={styles.inner}>
          <NavLink to="/" className={styles.logo} aria-label="Creative Design Studio">
            <span className={styles.logoMark}>CDS</span>
            <span className={styles.logoText}>Creative Design Studio</span>
          </NavLink>

          <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ""}`} aria-label="Основная навигация">
            <ul className={styles.navList}>
              {navItems.map((item) => (
                <li key={item.path} className={styles.navItem}>
                  <NavLink
                    to={item.path}
                    className={({ isActive }) =>
                      `${styles.navLink} ${isActive ? styles.active : ""}`
                    }
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>

          <a className={styles.contactBtn} href="tel:+74951234567">
            Позвонить
          </a>

          <button
            className={`${styles.burger} ${isMenuOpen ? styles.burgerActive : ""}`}
            type="button"
            aria-label="Меню"
            aria-expanded={isMenuOpen}
            onClick={toggleMenu}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;