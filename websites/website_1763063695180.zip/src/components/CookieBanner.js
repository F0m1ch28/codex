import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import styles from "./CookieBanner.module.css";

const CookieBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem("cds_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem("cds_cookie_consent", "accepted");
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.text}>
        Мы используем cookies, чтобы сделать сервис удобнее и безопаснее. Продолжая пользоваться сайтом, вы принимаете{" "}
        <Link to="/cookie-policy">политику cookies</Link>.
      </div>
      <button className={styles.button} type="button" onClick={handleAccept}>
        Принять
      </button>
    </div>
  );
};

export default CookieBanner;