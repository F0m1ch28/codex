import React, { useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import styles from './Header.module.css';

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={"${styles.header} ${scrolled ? styles.scrolled : ''}"}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo} aria-label="blhank homepage">
          blhank
        </Link>
        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen((prev) => !prev)}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Toggle navigation menu"
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="primary-navigation"
          className={"${styles.nav} ${menuOpen ? styles.open : ''}"}
        >
          <NavLink to="/" className={({ isActive }) => (isActive ? styles.active : '')}>
            Home
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => (isActive ? styles.active : '')}>
            About
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => (isActive ? styles.active : '')}>
            Services
          </NavLink>
          <NavLink to="/cases" className={({ isActive }) => (isActive ? styles.active : '')}>
            Cases
          </NavLink>
          <NavLink to="/blog" className={({ isActive }) => (isActive ? styles.active : '')}>
            Blog
          </NavLink>
          <NavLink to="/careers" className={({ isActive }) => (isActive ? styles.active : '')}>
            Careers
          </NavLink>
          <NavLink to="/contacts" className={({ isActive }) => (isActive ? styles.active : '')}>
            Contact
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default Header;