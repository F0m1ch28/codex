import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const COOKIE_KEY = 'blhank-cookie-consent';

function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem(COOKIE_KEY);
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleChoice = (value) => {
    window.localStorage.setItem(COOKIE_KEY, value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p>
          We use cookies to personalize experiences and analyze traffic. Learn more in our{' '}
          <Link to="/cookie-policy">Cookie Policy</Link>.
        </p>
        <div className={styles.actions}>
          <button type="button" onClick={() => handleChoice('accepted')}>
            Accept
          </button>
          <button type="button" onClick={() => handleChoice('declined')}>
            Decline
          </button>
        </div>
      </div>
    </div>
  );
}

export default CookieBanner;