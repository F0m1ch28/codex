import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

function Footer() {
  const currentYear = new Date().getFullYear();
  return (
    <footer className={styles.footer} aria-label="Footer">
      <div className={styles.container}>
        <div className={styles.brand}>
          <Link to="/" className={styles.logo}>
            blhank
          </Link>
          <p>
            Independent banking strategies crafted for resilient institutions and the communities
            behind them.
          </p>
        </div>
        <div className={styles.links}>
          <h4>Navigate</h4>
          <ul>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/services">Services</Link>
            </li>
            <li>
              <Link to="/cases">Cases</Link>
            </li>
            <li>
              <Link to="/blog">Blog</Link>
            </li>
            <li>
              <Link to="/careers">Careers</Link>
            </li>
          </ul>
        </div>
        <div className={styles.links}>
          <h4>Legal</h4>
          <ul>
            <li>
              <Link to="/privacy-policy">Privacy Policy</Link>
            </li>
            <li>
              <Link to="/terms-conditions">Terms &amp; Conditions</Link>
            </li>
            <li>
              <Link to="/disclaimer">Disclaimer</Link>
            </li>
            <li>
              <Link to="/cookie-policy">Cookie Policy</Link>
            </li>
          </ul>
        </div>
        <div className={styles.contact}>
          <h4>Contact</h4>
          <p>Itech Us Inc</p>
          <p>20 Kimball Ave #303n, South Burlington, VT 05403</p>
          <p>
            <Link to="/contacts">+1 802-383-1500</Link>
          </p>
          <p>
            <Link to="/contacts">info@blhank.pro</Link>
          </p>
          <div className={styles.social}>
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              in
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="X Twitter"
            >
              x
            </a>
            <a
              href="https://www.youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
            >
              yt
            </a>
          </div>
        </div>
      </div>
      <div className={styles.bottomBar}>
        <p>© {currentYear} blhank. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;