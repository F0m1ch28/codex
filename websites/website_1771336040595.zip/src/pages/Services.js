import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Services.module.css';

function ServicesPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Services | Independent Banking Solutions by blhank</title>
        <meta
          name="description"
          content="Explore blhank services for independent banks: strategy, digital modernization, risk management, and experience design."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Independent Banking Services</h1>
        <p>
          Purpose-built services that help banks modernize, grow, and safeguard their independence
          without compromising on compliance or culture.
        </p>
      </header>

      <section className={styles.section} aria-labelledby="strategy-heading">
        <div className={styles.sectionHeader}>
          <h2 id="strategy-heading">Strategic Advisory &amp; Transformation</h2>
          <p>
            Connect board-level vision with go-to-market execution to accelerate growth while
            maintaining the heart of your institution.
          </p>
        </div>
        <div className={styles.cardGrid}>
          <article>
            <h3>Enterprise Roadmapping</h3>
            <p>
              Facilitate cross-functional planning to align technology, product, and operations on a
              shared transformation agenda.
            </p>
          </article>
          <article>
            <h3>Merger &amp; Partnership Readiness</h3>
            <p>
              Evaluate partnership opportunities with a lens on cultural fit, regulatory alignment,
              and member impact.
            </p>
          </article>
          <article>
            <h3>Change Enablement</h3>
            <p>
              Equip teams with communication plans, training, and success metrics to adopt new
              solutions confidently.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="digital-heading">
        <div className={styles.sectionHeader}>
          <h2 id="digital-heading">Digital Platforms &amp; Technology</h2>
          <p>
            Modernize infrastructure with composable architectures that scale, interoperate, and
            stay resilient under pressure.
          </p>
        </div>
        <div className={styles.cardGrid}>
          <article>
            <h3>Core &amp; Cloud Modernization</h3>
            <p>
              Assess existing cores, design cloud-native layers, and execute phased migrations to
              reduce risk and maintain uptime.
            </p>
          </article>
          <article>
            <h3>API &amp; Integration Strategy</h3>
            <p>
              Build secure frameworks that connect legacy systems with fintech partners, ensuring
              compliance and performance.
            </p>
          </article>
          <article>
            <h3>Data Intelligence</h3>
            <p>
              Implement governance, analytics, and AI/ML pilots to provide actionable insights across
              lending, deposits, and experience.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="risk-heading">
        <div className={styles.sectionHeader}>
          <h2 id="risk-heading">Risk, Compliance &amp; Resilience</h2>
          <p>
            Navigate regulatory change with proactive frameworks that protect members, assets, and
            brand reputation.
          </p>
        </div>
        <div className={styles.cardGrid}>
          <article>
            <h3>Operational Resilience</h3>
            <p>
              Build resiliency playbooks that coordinate business continuity, third-party risk, and
              incident response.
            </p>
          </article>
          <article>
            <h3>Cybersecurity Programs</h3>
            <p>
              Launch maturity assessments, zero-trust roadmaps, and awareness programs tailored to
              your risk appetite.
            </p>
          </article>
          <article>
            <h3>Regulatory Reporting</h3>
            <p>
              Automate data collection and submission processes to stay ahead of audit requests and
              evolving regulations.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.section} aria-labelledby="experience-heading">
        <div className={styles.sectionHeader}>
          <h2 id="experience-heading">Customer &amp; Employee Experience</h2>
          <p>
            Craft experiences that honor local relationships while matching the convenience of
            national players.
          </p>
        </div>
        <div className={styles.cardGrid}>
          <article>
            <h3>Journey Design</h3>
            <p>
              Map and optimize member journeys—from account opening to servicing—to reveal moments
              that matter.
            </p>
          </article>
          <article>
            <h3>Service Blueprinting</h3>
            <p>
              Align front-stage and back-stage operations for consistent, frictionless interactions
              across channels.
            </p>
          </article>
          <article>
            <h3>Employee Enablement</h3>
            <p>
              Implement knowledge bases, coaching, and workflow tools that empower teams to deliver
              empathetic service at scale.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.cta}>
        <div>
          <h2>Co-create your independent banking roadmap</h2>
          <p>
            Schedule a strategy session with blhank to uncover growth opportunities, mitigate risk,
            and energize your teams.
          </p>
        </div>
        <a className={styles.ctaButton} href="/contacts">
          Connect with us
        </a>
      </section>
    </div>
  );
}

export default ServicesPage;