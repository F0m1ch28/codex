import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Disclaimer.module.css';

function DisclaimerPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Disclaimer | blhank</title>
        <meta
          name="description"
          content="Read the disclaimer for blhank and Itech Us Inc regarding website information and professional advice."
        />
      </Helmet>

      <h1>Disclaimer</h1>
      <p>Last updated: January 1, 2024</p>

      <section>
        <h2>General Information</h2>
        <p>
          The information provided by Itech Us Inc (“blhank”) on this website is for general
          informational purposes only. All information on the Site is provided in good faith; however,
          we make no representation or warranty of any kind regarding accuracy, adequacy, validity,
          reliability, availability, or completeness.
        </p>
      </section>

      <section>
        <h2>Professional Advice</h2>
        <p>
          The Site does not provide legal, financial, or regulatory advice. You should consult
          appropriate professionals before taking action based on any information found on the Site or
          in our publications.
        </p>
      </section>

      <section>
        <h2>External Links</h2>
        <p>
          The Site may contain links to third-party websites or content belonging to or originating
          from third parties. Such links are not investigated, monitored, or checked for accuracy by
          us. We do not guarantee the offerings of any third-party providers.
        </p>
      </section>

      <section>
        <h2>Liability</h2>
        <p>
          Under no circumstance shall Itech Us Inc be liable for any loss or damage of any kind incurred
          as a result of using the Site or relying on any information provided on the Site.
        </p>
      </section>

      <section>
        <h2>Contact</h2>
        <p>
          If you have questions about this Disclaimer, contact us at info@blhank.pro or mail Itech Us
          Inc, 20 Kimball Ave #303n, South Burlington, VT 05403.
        </p>
      </section>
    </div>
  );
}

export default DisclaimerPage;