import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './ThankYou.module.css';

function ThankYouPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Thank You | blhank</title>
        <meta
          name="description"
          content="Thank you for reaching out to blhank. Our team will respond shortly."
        />
      </Helmet>
      <div className={styles.card}>
        <h1>Thank you!</h1>
        <p>
          We appreciate your interest in blhank. A member of our team will reach out shortly to
          continue the conversation.
        </p>
        <Link to="/" className={styles.button}>
          Return to homepage
        </Link>
      </div>
    </div>
  );
}

export default ThankYouPage;