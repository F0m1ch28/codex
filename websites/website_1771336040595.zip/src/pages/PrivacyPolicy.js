import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Privacy.module.css';

function PrivacyPolicyPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Privacy Policy | blhank</title>
        <meta
          name="description"
          content="Learn how blhank and Itech Us Inc collect, use, and protect personal information from clients and website visitors."
        />
      </Helmet>
      <h1>Privacy Policy</h1>
      <p>Effective date: January 1, 2024</p>

      <section>
        <h2>Scope</h2>
        <p>
          This Privacy Policy explains how Itech Us Inc (“blhank,” “we,” “us,” “our”) collects,
          uses, and protects personal information obtained through our website and professional
          services. By using the Site, you consent to the practices described herein.
        </p>
      </section>

      <section>
        <h2>Information We Collect</h2>
        <ul>
          <li>
            <strong>Contact Information:</strong> Such as name, email address, phone number, and
            company details provided through forms.
          </li>
          <li>
            <strong>Usage Data:</strong> Analytics about how visitors access and navigate the Site,
            including IP address, browser type, and pages viewed.
          </li>
          <li>
            <strong>Client Data:</strong> Information shared during engagements, subject to the
            applicable service agreement.
          </li>
        </ul>
      </section>

      <section>
        <h2>How We Use Information</h2>
        <ul>
          <li>Respond to inquiries and deliver requested services.</li>
          <li>Improve Site performance, user experience, and content relevance.</li>
          <li>Send updates, insights, and event invitations in accordance with communication
            preferences.</li>
          <li>Comply with legal obligations and protect our rights.</li>
        </ul>
      </section>

      <section>
        <h2>Cookies</h2>
        <p>
          We use cookies and similar technologies to understand Site usage and enhance functionality.
          You can manage cookie preferences through browser settings, though disabling cookies may
          limit some Site capabilities.
        </p>
      </section>

      <section>
        <h2>Data Sharing</h2>
        <p>
          We do not sell personal information. We may share data with trusted service providers who
          assist in operating the Site or delivering services, subject to confidentiality obligations.
          We may disclose information when required by law or to protect our legal rights.
        </p>
      </section>

      <section>
        <h2>Data Security</h2>
        <p>
          We implement administrative, technical, and physical safeguards to protect personal
          information. Despite our efforts, no method of transmission or storage is completely secure.
        </p>
      </section>

      <section>
        <h2>Data Retention</h2>
        <p>
          We retain personal information as long as necessary to fulfill the purposes outlined in
          this Policy, comply with legal requirements, and support legitimate business interests.
        </p>
      </section>

      <section>
        <h2>Your Rights</h2>
        <p>
          Depending on your jurisdiction, you may have rights to access, correct, delete, or restrict
          the processing of your personal information. To exercise these rights, contact us using the
          details below. We will respond in accordance with applicable law.
        </p>
      </section>

      <section>
        <h2>International Transfers</h2>
        <p>
          If you access the Site from outside the United States, be aware that information may be
          transferred to and processed in the United States, where data protection laws may differ
          from those in your jurisdiction.
        </p>
      </section>

      <section>
        <h2>Children’s Privacy</h2>
        <p>
          The Site is not intended for individuals under the age of 18, and we do not knowingly
          collect personal information from children.
        </p>
      </section>

      <section>
        <h2>Policy Updates</h2>
        <p>
          We may update this Policy periodically. The “Effective date” above indicates the latest
          revision. Material changes will be communicated via the Site or other appropriate channels.
        </p>
      </section>

      <section>
        <h2>Contact Us</h2>
        <p>
          For privacy questions or requests, contact us at info@blhank.pro or mail Itech Us Inc, 20
          Kimball Ave #303n, South Burlington, VT 05403.
        </p>
      </section>
    </div>
  );
}

export default PrivacyPolicyPage;