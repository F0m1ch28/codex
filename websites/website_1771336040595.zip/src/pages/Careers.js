import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Careers.module.css';

function CareersPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Careers | Join blhank</title>
        <meta
          name="description"
          content="Discover careers at blhank. Join a team that empowers independent banks with strategy, technology, and experience innovation."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Build the future of independent banking</h1>
        <p>
          Join a nationally distributed team of strategists, technologists, and designers committed to
          strengthening community-focused finance.
        </p>
      </header>

      <section className={styles.culture} aria-labelledby="culture-heading">
        <h2 id="culture-heading">Our culture</h2>
        <div className={styles.cultureGrid}>
          <article>
            <h3>Outcome obsessed</h3>
            <p>
              We prioritize measurable impact for clients and their communities, celebrating when teams
              win together.
            </p>
          </article>
          <article>
            <h3>Curious by design</h3>
            <p>
              Every engagement starts with questions. We encourage experimentation and knowledge
              sharing at every level.
            </p>
          </article>
          <article>
            <h3>Flexible work</h3>
            <p>
              With a hybrid Vermont hub and remote-first squads, we embrace flexible schedules and
              purposeful collaboration.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.openings} aria-labelledby="openings-heading">
        <h2 id="openings-heading">Open roles</h2>
        <ul className={styles.list}>
          <li>
            <h3>Independent Banking Strategist</h3>
            <p>
              Lead transformation programs, guide executives through roadmap design, and coach teams on
              change adoption.
            </p>
            <p className={styles.tags}>Hybrid · Vermont / Remote US</p>
          </li>
          <li>
            <h3>Cloud &amp; Integration Architect</h3>
            <p>
              Design secure cloud-native patterns, integrate fintech ecosystems, and steer modernization
              initiatives.
            </p>
            <p className={styles.tags}>Remote · United States</p>
          </li>
          <li>
            <h3>Experience Design Lead</h3>
            <p>
              Translate research into intuitive journeys and collaborate with cross-functional teams to
              launch human-centered solutions.
            </p>
            <p className={styles.tags}>Hybrid · South Burlington, VT</p>
          </li>
        </ul>
        <a className={styles.applyBtn} href="mailto:careers@blhank.pro">
          Share your resume
        </a>
      </section>

      <section className={styles.benefits} aria-labelledby="benefits-heading">
        <h2 id="benefits-heading">Benefits highlights</h2>
        <div className={styles.benefitGrid}>
          <article>
            <h3>Well-being</h3>
            <p>Comprehensive health coverage, wellness stipends, and generous paid time off.</p>
          </article>
          <article>
            <h3>Growth</h3>
            <p>Professional development allowances, mentorship circles, and conference opportunities.</p>
          </article>
          <article>
            <h3>Community</h3>
            <p>Volunteer days, community banking roundtables, and employee resource groups.</p>
          </article>
        </div>
      </section>
    </div>
  );
}

export default CareersPage;