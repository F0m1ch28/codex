import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Contact.module.css';

const initialState = {
  name: '',
  email: '',
  message: ''
};

function ContactsPage() {
  const [formData, setFormData] = useState(initialState);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your name.';
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Enter a valid email address.';
    }
    if (formData.message.trim().length < 10) {
      newErrors.message = 'Message should be at least 10 characters.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validate()) {
      setFormData(initialState);
      navigate('/thank-you');
    }
  };

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Contact blhank | Independent Banking Advisors</title>
        <meta
          name="description"
          content="Reach blhank at Itech Us Inc for independent banking strategies. Call +1 802-383-1500 or email info@blhank.pro."
        />
      </Helmet>

      <section className={styles.hero}>
        <h1>Let’s build your next independent advantage</h1>
        <p>
          Reach out to explore strategies, technology, and experiences that keep your institution
          independent and future ready.
        </p>
      </section>

      <section className={styles.contactInfo} aria-labelledby="contact-heading">
        <div>
          <h2 id="contact-heading">Contact Information</h2>
          <p>
            <strong>Company:</strong> Itech Us Inc
          </p>
          <p>
            <strong>Address:</strong> 20 Kimball Ave #303n, South Burlington, VT 05403
          </p>
          <p>
            <strong>Phone:</strong>{' '}
            <a href="tel:+18023831500" rel="noopener noreferrer">
              +1 802-383-1500
            </a>
          </p>
          <p>
            <strong>Email:</strong>{' '}
            <a href="mailto:info@blhank.pro" rel="noopener noreferrer">
              info@blhank.pro
            </a>
          </p>
        </div>
        <div className={styles.mapWrapper}>
          <iframe
            title="Itech Us Inc South Burlington VT"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2837.8724915593307!2d-73.13599892357551!3d44.47471550074056!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cca7b48694ad8dd%3A0x9d9424a530d0c88f!2s20%20Kimball%20Ave%20%23303n%2C%20South%20Burlington%2C%20VT%2005403!5e0!3m2!1sen!2sus!4v1700000000000"
            loading="lazy"
            allowFullScreen
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>

      <section className={styles.formSection} aria-labelledby="form-heading">
        <div className={styles.formIntro}>
          <h2 id="form-heading">Tell us about your priorities</h2>
          <p>
            Share a few details and our team will respond within one business day to schedule a
            conversation tailored to your goals.
          </p>
        </div>
        <form className={styles.form} onSubmit={handleSubmit} noValidate>
          <label htmlFor="name">Name</label>
          <input
            id="name"
            name="name"
            type="text"
            autoComplete="name"
            value={formData.name}
            onChange={handleChange}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? 'name-error' : undefined}
            required
          />
          {errors.name && (
            <p id="name-error" className={styles.error}>
              {errors.name}
            </p>
          )}

          <label htmlFor="email">Email</label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            value={formData.email}
            onChange={handleChange}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? 'email-error' : undefined}
            required
          />
          {errors.email && (
            <p id="email-error" className={styles.error}>
              {errors.email}
            </p>
          )}

          <label htmlFor="message">Message</label>
          <textarea
            id="message"
            name="message"
            rows="5"
            value={formData.message}
            onChange={handleChange}
            aria-invalid={Boolean(errors.message)}
            aria-describedby={errors.message ? 'message-error' : undefined}
            required
          />
          {errors.message && (
            <p id="message-error" className={styles.error}>
              {errors.message}
            </p>
          )}

          <button type="submit">Submit</button>
        </form>
      </section>
    </div>
  );
}

export default ContactsPage;