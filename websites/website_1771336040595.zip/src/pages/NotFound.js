import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './NotFound.module.css';

function NotFoundPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Page Not Found | blhank</title>
        <meta
          name="description"
          content="The page you are looking for cannot be found. Return to blhank homepage."
        />
      </Helmet>
      <h1>404</h1>
      <p>The page you are searching for might have been moved or no longer exists.</p>
      <Link to="/" className={styles.button}>
        Back to homepage
      </Link>
    </div>
  );
}

export default NotFoundPage;