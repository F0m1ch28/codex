import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Cases.module.css';

const cases = [
  {
    id: 1,
    title: 'Lakeview Cooperative Bank',
    challenge:
      'Legacy systems hindered omnichannel service delivery and restricted launch of new deposit products.',
    solution:
      'Designed a composable service architecture, implemented API gateways, and delivered employee training programs.',
    result:
      'Accelerated product launches from 9 months to 10 weeks and increased cross-sell conversions by 18%.',
    image: 'https://picsum.photos/seed/case-study1/720/480'
  },
  {
    id: 2,
    title: 'Northshore Trust & Savings',
    challenge:
      'Regulators demanded enhanced visibility into operational risk and third-party management routines.',
    solution:
      'Introduced risk dashboards, automated vendor assessments, and incident response simulations.',
    result:
      'Achieved top-tier exam ratings and decreased remediation cycles by 40% within the first year.',
    image: 'https://picsum.photos/seed/case-study2/720/480'
  },
  {
    id: 3,
    title: 'Summit Credit Union',
    challenge:
      'Member growth plateaued as digital channels lagged behind expectations of younger demographics.',
    solution:
      'Reimagined member journeys, launched mobile-first onboarding, and retrained branch ambassadors.',
    result:
      'Membership grew 22% year-over-year, with 70% of new accounts opened through digital channels.',
    image: 'https://picsum.photos/seed/case-study3/720/480'
  },
  {
    id: 4,
    title: 'Capital Ridge Community Bank',
    challenge:
      'Needed to diversify non-interest revenue while protecting community-focused identity.',
    solution:
      'Developed embedded finance partnerships with local businesses and created transparent governance.',
    result:
      'Generated seven new revenue streams and increased customer retention by 12% across segments.',
    image: 'https://picsum.photos/seed/case-study4/720/480'
  }
];

function CasesPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Case Studies | blhank Independent Banking Success</title>
        <meta
          name="description"
          content="See how blhank partners with independent banks to deliver measurable transformation and growth."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Independent banking in action</h1>
        <p>
          Explore how blhank helps financial institutions modernize core capabilities, unlock new
          revenue, and protect the trust of their communities.
        </p>
      </header>

      <section className={styles.grid} aria-label="Case studies">
        {cases.map((item) => (
          <article key={item.id} className={styles.card}>
            <img src={item.image} alt={item.title} />
            <div className={styles.cardBody}>
              <h2>{item.title}</h2>
              <h3>Challenge</h3>
              <p>{item.challenge}</p>
              <h3>Solution</h3>
              <p>{item.solution}</p>
              <h3>Result</h3>
              <p>{item.result}</p>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

export default CasesPage;