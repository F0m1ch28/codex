import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './About.module.css';

function AboutPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>About blhank | Our Independent Banking Story</title>
        <meta
          name="description"
          content="Discover the story, mission, and values behind blhank and Itech Us Inc, empowering independent banks across the United States."
        />
      </Helmet>

      <section className={styles.hero}>
        <div>
          <h1>Invested in Independent Banking Futures</h1>
          <p>
            blhank is the banking innovation practice of Itech Us Inc. From our home in South
            Burlington, Vermont, we partner with financial leaders who believe independence is a
            strength—not a limitation.
          </p>
        </div>
        <img src="https://picsum.photos/seed/about-hero/720/480" alt="South Burlington skyline" />
      </section>

      <section className={styles.story} aria-labelledby="story-heading">
        <h2 id="story-heading">Our story</h2>
        <p>
          Founded in 2001, Itech Us Inc has grown alongside the rapid digitization of financial
          services. We launched blhank to solve a persistent challenge for community and regional
          banks: retain independence while competing with scale. Today, our interdisciplinary team
          blends banking veterans, cloud architects, product strategists, and experience designers
          committed to practical innovation.
        </p>
        <p>
          From Vermont to California, we support executives and frontline teams who need a trusted
          partner to untangle complexity. Our studio culture is anchored in curiosity, transparency,
          and relentless respect for the people behind every balance sheet.
        </p>
      </section>

      <section className={styles.values} aria-labelledby="values-heading">
        <h2 id="values-heading">Values that guide every engagement</h2>
        <div className={styles.valuesGrid}>
          <article>
            <h3>Independence</h3>
            <p>
              We are fiercely vendor-neutral. Our recommendations are guided by your mission, not
              behind-the-scenes alliances.
            </p>
          </article>
          <article>
            <h3>Integrity</h3>
            <p>
              Transparent communication and measurable goals underpin every milestone, ensuring the
              trust of your board, regulators, and members.
            </p>
          </article>
          <article>
            <h3>Imagination</h3>
            <p>
              Banking is evolving quickly. We experiment responsibly, prototyping and pressure-testing
              ideas before scaling to production.
            </p>
          </article>
          <article>
            <h3>Impact</h3>
            <p>
              Success is defined by healthier communities and empowered employees. We build solutions
              that uplift both.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.photos} aria-labelledby="gallery-heading">
        <h2 id="gallery-heading">Life at our South Burlington hub</h2>
        <div className={styles.photoGrid}>
          <figure>
            <img src="https://picsum.photos/seed/office-exterior/720/480" alt="Exterior of South Burlington office building" />
            <figcaption>Our collaborative office overlooking the Green Mountains.</figcaption>
          </figure>
          <figure>
            <img src="https://picsum.photos/seed/office-collab/720/480" alt="Team collaboration inside Vermont office" />
            <figcaption>Cross-functional squads co-creating client journeys.</figcaption>
          </figure>
          <figure>
            <img src="https://picsum.photos/seed/team-culture1/720/480" alt="Team members in workshop" />
            <figcaption>Innovation workshops that spark new banking models.</figcaption>
          </figure>
          <figure>
            <img src="https://picsum.photos/seed/team-culture2/720/480" alt="Team photo outdoors" />
            <figcaption>Celebrating milestones with our growing national team.</figcaption>
          </figure>
        </div>
      </section>

      <section className={styles.mission} aria-labelledby="mission-heading">
        <h2 id="mission-heading">Mission and outlook</h2>
        <p>
          Our mission is to empower independent financial institutions to thrive through confident
          leadership, adaptive technology, and unforgettable customer experiences. Across strategy,
          operations, and change enablement, we champion teams that want to innovate on their own
          terms.
        </p>
        <p>
          Looking ahead, blhank is expanding research initiatives and partner ecosystems that bring
          experimental ideas to market faster. We remain anchored in Vermont while nurturing
          distributed talent across the United States.
        </p>
      </section>
    </div>
  );
}

export default AboutPage;