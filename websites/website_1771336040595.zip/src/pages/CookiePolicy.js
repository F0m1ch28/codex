import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './CookiePolicy.module.css';

function CookiePolicyPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Cookie Policy | blhank</title>
        <meta
          name="description"
          content="Understand how blhank uses cookies and similar technologies to deliver and improve website experiences."
        />
      </Helmet>

      <h1>Cookie Policy</h1>
      <p>Effective date: January 1, 2024</p>

      <section>
        <h2>What Are Cookies?</h2>
        <p>
          Cookies are small text files placed on your device by websites you visit. They are widely
          used to make websites work more efficiently and to provide information to the site owners.
        </p>
      </section>

      <section>
        <h2>Types of Cookies We Use</h2>
        <ul>
          <li>
            <strong>Essential Cookies:</strong> Required for the Site to function properly and to
            enable navigation.
          </li>
          <li>
            <strong>Performance Cookies:</strong> Collect information about how visitors use the Site
            to help us improve functionality and user experience.
          </li>
          <li>
            <strong>Functional Cookies:</strong> Remember your preferences to customize your experience.
          </li>
        </ul>
      </section>

      <section>
        <h2>Managing Cookies</h2>
        <p>
          You can control or delete cookies through browser settings. Disabling certain cookies may
          affect Site functionality. For more information, visit <a href="https://www.allaboutcookies.org" target="_blank" rel="noopener noreferrer">All About Cookies</a>.
        </p>
      </section>

      <section>
        <h2>Updates</h2>
        <p>
          We may update this Cookie Policy as necessary. Changes will be posted on this page with an
          updated effective date.
        </p>
      </section>

      <section>
        <h2>Contact</h2>
        <p>
          For questions about our cookie practices, email info@blhank.pro or mail Itech Us Inc, 20
          Kimball Ave #303n, South Burlington, VT 05403.
        </p>
      </section>
    </div>
  );
}

export default CookiePolicyPage;