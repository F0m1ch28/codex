import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Blog.module.css';

const posts = [
  {
    id: 1,
    title: 'Five Signals Your Bank Is Ready for Independent Core Transformation',
    date: 'March 8, 2024',
    excerpt:
      'Evaluate culture, risk appetite, and data readiness before embarking on a core transformation that keeps your institution in control.',
    image: 'https://picsum.photos/seed/blogpost1/640/420'
  },
  {
    id: 2,
    title: 'Leveraging Embedded Finance Without Losing Your Brand Identity',
    date: 'February 26, 2024',
    excerpt:
      'Independent banks can drive revenue with embedded partnerships while staying true to community values with the right governance.',
    image: 'https://picsum.photos/seed/blogpost2/640/420'
  },
  {
    id: 3,
    title: 'Humanizing AI in Relationship Banking',
    date: 'January 29, 2024',
    excerpt:
      'Practical frameworks for blending AI-powered decisioning with genuine human experiences that deepen trust with members.',
    image: 'https://picsum.photos/seed/blogpost3/640/420'
  },
  {
    id: 4,
    title: 'Building a Culture of Continuous Compliance',
    date: 'December 12, 2023',
    excerpt:
      'We outline how to embed compliance literacy into daily routines so your teams stay exam-ready year-round.',
    image: 'https://picsum.photos/seed/blogpost4/640/420'
  }
];

function BlogPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Blog | blhank Insights for Independent Banks</title>
        <meta
          name="description"
          content="Read blhank insights on independent banking strategy, technology, risk, and experience leadership."
        />
      </Helmet>

      <header className={styles.hero}>
        <h1>Independent Banking Insights</h1>
        <p>
          Actionable perspectives for leaders who believe independence fuels agility, innovation, and
          community prosperity.
        </p>
      </header>

      <section className={styles.grid} aria-label="Blog articles">
        {posts.map((post) => (
          <article key={post.id} className={styles.card}>
            <img src={post.image} alt={post.title} />
            <div className={styles.cardBody}>
              <p className={styles.date}>{post.date}</p>
              <h2>{post.title}</h2>
              <p>{post.excerpt}</p>
              <a href="/blog" aria-label={"Read more about ${post.title}"}>
                Read further →
              </a>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

export default BlogPage;