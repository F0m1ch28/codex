import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Terms.module.css';

function TermsConditionsPage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>Terms &amp; Conditions | blhank</title>
        <meta
          name="description"
          content="Review the terms and conditions governing the use of blhank services and website."
        />
      </Helmet>
      <h1>Terms &amp; Conditions</h1>
      <p>Last updated: January 1, 2024</p>

      <section>
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing or using the blhank website (the “Site”) operated by Itech Us Inc (“we,” “us,”
          or “our”), you agree to be bound by these Terms &amp; Conditions. If you do not agree with
          any part of these terms, you must not use the Site.
        </p>
      </section>

      <section>
        <h2>2. Use of the Site</h2>
        <p>
          You may use the Site solely for lawful purposes and in accordance with these Terms.
          Unauthorized use, including attempts to gain unauthorized access to the Site or related
          systems, is strictly prohibited.
        </p>
      </section>

      <section>
        <h2>3. Intellectual Property</h2>
        <p>
          All content, design elements, logos, and graphics on the Site are owned or licensed by
          Itech Us Inc and protected by intellectual property laws. You may not reproduce, distribute,
          or create derivative works without prior written consent.
        </p>
      </section>

      <section>
        <h2>4. Professional Services</h2>
        <p>
          Information on the Site is provided for informational purposes only and does not constitute
          professional advice or an offer to provide services. Engagements with blhank are governed by
          separate agreements negotiated with clients.
        </p>
      </section>

      <section>
        <h2>5. Third-Party Links</h2>
        <p>
          The Site may contain links to third-party websites for convenience. We do not endorse or
          assume responsibility for the content, policies, or practices of any third-party websites.
        </p>
      </section>

      <section>
        <h2>6. Limitation of Liability</h2>
        <p>
          To the fullest extent permitted by law, Itech Us Inc shall not be liable for any direct,
          indirect, incidental, special, or consequential damages arising out of or related to your
          use of the Site.
        </p>
      </section>

      <section>
        <h2>7. Indemnification</h2>
        <p>
          You agree to indemnify and hold harmless Itech Us Inc, its affiliates, employees, and
          contractors from any claims, damages, liabilities, and expenses arising from your use of
          the Site or violation of these Terms.
        </p>
      </section>

      <section>
        <h2>8. Privacy</h2>
        <p>
          Our collection and use of personal information are described in the blhank Privacy Policy.
          By using the Site, you consent to such processing and warrant that all data you provide is
          accurate.
        </p>
      </section>

      <section>
        <h2>9. Changes to Terms</h2>
        <p>
          We may update these Terms from time to time. Continued use of the Site after changes become
          effective constitutes acceptance of the revised Terms.
        </p>
      </section>

      <section>
        <h2>10. Governing Law</h2>
        <p>
          These Terms are governed by the laws of the State of Vermont, without regard to conflict of
          law provisions. Any disputes shall be resolved in state or federal courts located in
          Vermont.
        </p>
      </section>

      <section>
        <h2>11. Contact</h2>
        <p>
          For questions about these Terms &amp; Conditions, contact us at info@blhank.pro or write to
          Itech Us Inc, 20 Kimball Ave #303n, South Burlington, VT 05403.
        </p>
      </section>
    </div>
  );
}

export default TermsConditionsPage;