import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import styles from './Home.module.css';

function HomePage() {
  return (
    <div className={styles.page}>
      <Helmet>
        <title>blhank | Independent Banking Partners</title>
        <meta
          name="description"
          content="blhank empowers U.S. financial leaders with independent banking strategies, resilient technology, and customer-first operating models."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1>Bank Independent, Lead with Confidence</h1>
          <p>
            blhank helps regional banks and credit unions break free from legacy constraints through
            agile strategies, secure technology, and human-centered delivery.
          </p>
          <div className={styles.heroActions}>
            <Link to="/services" className={styles.primaryBtn}>
              Explore Services
            </Link>
            <Link to="/cases" className={styles.secondaryBtn}>
              View Success Stories
            </Link>
          </div>
        </div>
        <div className={styles.heroImage}>
          {/* Photo from picsum.photos */}
          <img src="https://picsum.photos/seed/finance-team/720/540" alt="Financial strategy team collaborating" />
        </div>
      </section>

      <section className={styles.trustPanel} aria-labelledby="trust-heading">
        <h2 id="trust-heading">Why financial innovators trust blhank</h2>
        <div className={styles.benefits}>
          <article>
            <img src="https://picsum.photos/seed/insights/160/160" alt="Data analytics illustration" />
            <h3>Independent Insight</h3>
            <p>
              We deliver bias-free advisory grounded in market analytics and sharp human judgment
              sharpened across U.S. financial ecosystems.
            </p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/security/160/160" alt="Cyber security illustration" />
            <h3>Secure Modernization</h3>
            <p>
              From core transformations to digital onboarding, our modular approach keeps your
              modernization journey secure and compliant.
            </p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/community/160/160" alt="Community banking illustration" />
            <h3>Community-Centered</h3>
            <p>
              We design with empathy for employees and members, ensuring a people-first culture that
              scales alongside technology.
            </p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/performance/160/160" alt="Performance metrics illustration" />
            <h3>Measurable Outcomes</h3>
            <p>
              Every initiative launches with transparent KPIs so leadership can steer toward growth,
              resiliency, and stakeholder impact.
            </p>
          </article>
        </div>
      </section>

      <section className={styles.servicesPreview} aria-labelledby="services-heading">
        <div className={styles.sectionHeader}>
          <h2 id="services-heading">Independent banking services tailored to you</h2>
          <p>
            We partner with executive, technology, and experience teams to modernize financial
            operations without trading independence for scale.
          </p>
        </div>
        <div className={styles.serviceGrid}>
          <article>
            <h3>Strategy &amp; Transformation</h3>
            <p>
              Align leadership around a future-ready operating model built on robust governance,
              change enablement, and data-fueled decisions.
            </p>
          </article>
          <article>
            <h3>Digital Platforms</h3>
            <p>
              Architect cloud-native, API-driven platforms that streamline onboarding, lending, and
              servicing without vendor lock-in.
            </p>
          </article>
          <article>
            <h3>Risk &amp; Compliance</h3>
            <p>
              Integrate cyber, regulatory, and operational risk management into everyday workflows
              to protect trust and capital.
            </p>
          </article>
          <article>
            <h3>Customer Experience</h3>
            <p>
              Build omnichannel journeys that delight members and power frontline employees with
              real-time intelligence.
            </p>
          </article>
        </div>
        <Link className={styles.linkArrow} to="/services">
          Dive into our services →
        </Link>
      </section>

      <section className={styles.casesPreview} aria-labelledby="cases-heading">
        <div className={styles.sectionHeader}>
          <h2 id="cases-heading">Recent wins with independent banks</h2>
          <p>Real-world momentum powered by blhank partnership.</p>
        </div>
        <div className={styles.caseGrid}>
          <article>
            <img src="https://picsum.photos/seed/case1/640/420" alt="Bank branch digital kiosk" />
            <div>
              <h3>Greenfield Digital Bank Launch</h3>
              <p>
                Built a compliant digital-first subsidiary for a Midwestern community bank, reaching
                60K accounts in the first year.
              </p>
            </div>
          </article>
          <article>
            <img src="https://picsum.photos/seed/case2/640/420" alt="Bank analytics dashboard" />
            <div>
              <h3>Risk 360 Visibility</h3>
              <p>
                Unified risk intelligence for a southeastern credit union to improve regulatory exam
                readiness and decision speed.
              </p>
            </div>
          </article>
          <article>
            <img src="https://picsum.photos/seed/case3/640/420" alt="Customer experience mapping workshop" />
            <div>
              <h3>Member Experience Reboot</h3>
              <p>
                Designed omnichannel member journeys and staff tooling, boosting NPS by double digits
                within six months.
              </p>
            </div>
          </article>
        </div>
        <Link className={styles.linkArrow} to="/cases">
          Explore more case studies →
        </Link>
      </section>

      <section className={styles.blogPreview} aria-labelledby="blog-heading">
        <div className={styles.sectionHeader}>
          <h2 id="blog-heading">Insights from the blhank blog</h2>
          <p>Ideas crafted for independent bank executives navigating accelerated change.</p>
        </div>
        <div className={styles.blogGrid}>
          <article>
            <img src="https://picsum.photos/seed/blog1/640/420" alt="Cloud architecture concept illustration" />
            <h3>Cloud-Native Core Banking Without Vendor Lock-In</h3>
            <p>
              Learn how modular cores and integration patterns help community banks maintain control
              while unlocking innovation velocity.
            </p>
            <Link to="/blog" aria-label="Read more about Cloud-Native Core Banking">
              Read more →
            </Link>
          </article>
          <article>
            <img src="https://picsum.photos/seed/blog2/640/420" alt="Customer using mobile banking app" />
            <h3>Designing Human Banking Journeys for Gen Z</h3>
            <p>
              Blend digital empathy and data cues to build loyalty with the fastest-growing segment
              of emerging depositors.
            </p>
            <Link to="/blog" aria-label="Read more about Human Banking Journeys">
              Read more →
            </Link>
          </article>
          <article>
            <img src="https://picsum.photos/seed/blog3/640/420" alt="Risk management team meeting" />
            <h3>Operational Resilience in a Volatile World</h3>
            <p>
              A pragmatic approach to stress testing, scenario planning, and cross-functional
              preparedness for independent banks.
            </p>
            <Link to="/blog" aria-label="Read more about Operational Resilience">
              Read more →
            </Link>
          </article>
        </div>
      </section>

      <section className={styles.teamSection} aria-labelledby="team-heading">
        <div className={styles.sectionHeader}>
          <h2 id="team-heading">Meet the change agents</h2>
          <p>
            The blhank team blends banking operators, technologists, and experience strategists who
            believe independence fuels community prosperity.
          </p>
        </div>
        <div className={styles.teamGrid}>
          <article>
            <img src="https://picsum.photos/seed/team1/320/320" alt="Portrait of CEO" />
            <h3>Jordan Reilly</h3>
            <p>Chief Executive Officer</p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/team2/320/320" alt="Portrait of strategy lead" />
            <h3>Aria Chen</h3>
            <p>Head of Strategy &amp; Innovation</p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/team3/320/320" alt="Portrait of technology leader" />
            <h3>Marcus Delgado</h3>
            <p>Chief Technology Architect</p>
          </article>
          <article>
            <img src="https://picsum.photos/seed/team4/320/320" alt="Portrait of experience design lead" />
            <h3>Priya Natarajan</h3>
            <p>Director of Experience Design</p>
          </article>
        </div>
      </section>

      <section className={styles.testimonials} aria-labelledby="testimonials-heading">
        <h2 id="testimonials-heading">Voices from visionary partners</h2>
        <div className={styles.testimonialGrid}>
          <blockquote>
            <img src="https://picsum.photos/seed/client1/96/96" alt="Client testimonial headshot" />
            <p>
              “blhank turned our multi-year roadmap into a living strategy that keeps us agile.
              Their independence is their advantage—and now ours.”
            </p>
            <cite>— Leslie McKnight, COO, Pioneer Mutual Bank</cite>
          </blockquote>
          <blockquote>
            <img src="https://picsum.photos/seed/client2/96/96" alt="Client testimonial headshot" />
            <p>
              “From cybersecurity to customer journeys, their team gives us the confidence to scale
              responsibly without diluting our member-first DNA.”
            </p>
            <cite>— Arturo Morales, CEO, Horizon Credit Union</cite>
          </blockquote>
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaContent}>
          <h2>Ready to champion your independent future?</h2>
          <p>
            Let’s co-create an adaptive banking ecosystem that earns loyalty, accelerates innovation,
            and fuels sustainable growth.
          </p>
          <Link to="/contacts" className={styles.primaryBtn}>
            Start the conversation
          </Link>
        </div>
      </section>
    </div>
  );
}

export default HomePage;