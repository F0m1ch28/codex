const products = [
  {
    id: 'dca-001',
    title: 'Неоновые искры',
    author: 'Studio Gamma',
    category: 'video-covers',
    tags: ['YouTube', 'Неон', 'Action'],
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-002',
    title: 'Ретро лучи',
    author: 'Lumos Lab',
    category: 'video-covers',
    tags: ['Retro', 'Bright', 'Gaming'],
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-003',
    title: 'Холодный стрит',
    author: 'North Design',
    category: 'stream-banners',
    tags: ['Twitch', 'Stream Starting', 'Urban'],
    image: 'https://images.unsplash.com/photo-1526481280695-3c4699dcd21c?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-004',
    title: 'Арт-тату',
    author: 'Pixel Wave',
    category: 'avatars',
    tags: ['Character', 'Illustration'],
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'dca-005',
    title: 'Световая дуга',
    author: 'Bold Motion',
    category: 'social-headers',
    tags: ['VK', 'Gradient', 'Minimal'],
    image: 'https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-006',
    title: 'Лунный спектр',
    author: 'Aurora Team',
    category: 'stream-banners',
    tags: ['Twitch', 'BRB', 'Cosmic'],
    image: 'https://images.unsplash.com/photo-1462332420958-a05d1e002413?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-007',
    title: 'Сияние пикселей',
    author: 'Digital Story',
    category: 'video-covers',
    tags: ['Science', 'Technology'],
    image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-008',
    title: 'Глитч-портрет',
    author: 'Spectrum Crew',
    category: 'avatars',
    tags: ['Glitch', 'Cyberpunk'],
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?auto=format&fit=crop&w=800&q=80&sat=-50'
  },
  {
    id: 'dca-009',
    title: 'Гранулы света',
    author: 'Future Grid',
    category: 'social-headers',
    tags: ['Telegram', 'Motion'],
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-010',
    title: 'Радио-пульс',
    author: 'Echo Studio',
    category: 'stream-banners',
    tags: ['Music', 'Podcast', 'Live'],
    image: 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-011',
    title: 'Дизайн энерго',
    author: 'Pixel Pulse',
    category: 'video-covers',
    tags: ['Energy', 'Fitness'],
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'dca-012',
    title: 'Сетевой ритм',
    author: 'Hyper Studio',
    category: 'social-headers',
    tags: ['Discord', 'Tech'],
    image: 'https://images.unsplash.com/photo-1535223289827-42f1e9919769?auto=format&fit=crop&w=1200&q=80'
  }
];

export default products;