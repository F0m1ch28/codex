const categories = [
  {
    id: 'video-covers',
    name: 'Обложки для видео',
    description: 'Динамичные композиции для YouTube, RuTube и других видеоплатформ.',
    link: '/catalog/video-covers'
  },
  {
    id: 'avatars',
    name: 'Аватарки и иконки',
    description: 'Выразительные аватары для блогеров, подкастов и сообществ.',
    link: '/catalog/avatars'
  },
  {
    id: 'stream-banners',
    name: 'Баннеры для стримов',
    description: 'Профессиональные заставки и паки для Twitch и Trovo.',
    link: '/catalog/stream-banners'
  },
  {
    id: 'social-headers',
    name: 'Шапки для соцсетей',
    description: 'Актуальные шапки для VK, Telegram, Discord и других платформ.',
    link: '/catalog/social-headers'
  }
];

export default categories;