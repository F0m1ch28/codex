import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import styles from './ContactsPage.module.css';

const ContactsPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus('Пожалуйста, заполните все поля перед отправкой.');
      return;
    }
    setStatus('Спасибо! Мы свяжемся с вами в ближайшее время.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Контакты — Digital Cover Art</title>
        <meta
          name="description"
          content="Свяжитесь с Digital Cover Art: поддержка клиентов, вопросы авторов и юридическая информация. Email, адрес и форма обратной связи."
        />
      </Helmet>

      <section className={styles.contacts}>
        <div className={styles.header}>
          <h1>Связаться с Digital Cover Art</h1>
          <p>
            Наша команда отвечает на вопросы о лицензиях, авторстве и технической поддержке в течение одного рабочего дня.
          </p>
        </div>

        <div className={styles.grid}>
          <div className={styles.info}>
            <h2>Контактные данные</h2>
            <ul>
              <li>
                Email поддержки:
                <a href="mailto:support@digitalcoverart.com">support@digitalcoverart.com</a>
              </li>
              <li>
                Email для авторов:
                <a href="mailto:authors@digitalcoverart.com">authors@digitalcoverart.com</a>
              </li>
              <li>
                Телефон:
                <a href="tel:+74951234567">+7 (495) 123-45-67</a>
              </li>
              <li>Адрес: 123456, г. Москва, ул. Цифровая, д. 7, офис 14</li>
            </ul>
          </div>

          <form className={styles.form} onSubmit={handleSubmit}>
            <h2>Напишите нам</h2>
            <label htmlFor="name">Имя</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Как к вам обращаться?"
              value={formData.name}
              onChange={handleChange}
            />

            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="name@example.com"
              value={formData.email}
              onChange={handleChange}
            />

            <label htmlFor="message">Сообщение</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              placeholder="Опишите ваш вопрос или запрос"
              value={formData.message}
              onChange={handleChange}
            />
            <button type="submit">Отправить</button>

            <p className={styles.status} aria-live="polite">
              {status}
            </p>
          </form>
        </div>
      </section>
    </>
  );
};

export default ContactsPage;