import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useSearchParams } from 'react-router-dom';
import products from '../data/products';
import categories from '../data/categories';
import styles from './CatalogPage.module.css';

const CatalogPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [filteredProducts, setFilteredProducts] = useState(products);
  const currentCategory = searchParams.get('category') || 'all';

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      if (currentCategory === 'all') {
        setFilteredProducts(products);
      } else {
        setFilteredProducts(products.filter((item) => item.category === currentCategory));
      }
      setLoading(false);
    }, 600);

    return () => clearTimeout(timer);
  }, [currentCategory]);

  const handleFilterChange = (categoryId) => {
    if (categoryId === 'all') {
      setSearchParams({});
    } else {
      setSearchParams({ category: categoryId });
    }
  };

  return (
    <>
      <Helmet>
        <title>Каталог цифровых обложек — Digital Cover Art</title>
        <meta
          name="description"
          content="Каталог Digital Cover Art: обложки для видео, аватарки, баннеры для стримов, шапки соцсетей. Фильтрация по категориям и тегам."
        />
      </Helmet>

      <section className={styles.catalog}>
        <div className={styles.header}>
          <h1>Каталог работ</h1>
          <p>
            Готовые дизайнерские решения для YouTube, Twitch, VK, Telegram и других площадок. Используйте фильтр
            по типу ассета и тегам, чтобы быстрее найти подходящий стиль.
          </p>
        </div>

        <div className={styles.filters} role="group" aria-label="Фильтр по категориям">
          <button
            type="button"
            onClick={() => handleFilterChange('all')}
            className={`${styles.filterButton} ${currentCategory === 'all' ? styles.filterActive : ''}`}
          >
            Все ассеты
          </button>
          {categories.map((category) => (
            <button
              type="button"
              key={category.id}
              onClick={() => handleFilterChange(category.id)}
              className={`${styles.filterButton} ${currentCategory === category.id ? styles.filterActive : ''}`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {loading ? (
          <div className={styles.loader} role="status" aria-live="polite">
            Загружаем подборку...
          </div>
        ) : (
          <div className={styles.grid}>
            {filteredProducts.map((product) => (
              <article key={product.id} className={styles.card}>
                <div className={styles.cardPreview}>
                  <img src={product.image} alt={`Превью работы "${product.title}"`} loading="lazy" />
                  <span className={styles.cardCategory}>
                    {categories.find((category) => category.id === product.category)?.name}
                  </span>
                </div>
                <div className={styles.cardBody}>
                  <h2>{product.title}</h2>
                  <p className={styles.cardAuthor}>Автор: {product.author}</p>
                  <ul className={styles.tags}>
                    {product.tags.map((tag) => (
                      <li key={tag}>{tag}</li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </>
  );
};

export default CatalogPage;