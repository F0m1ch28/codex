import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import categories from '../data/categories';
import styles from './HomePage.module.css';

const HomePage = () => {
  const [activeFaq, setActiveFaq] = useState(0);

  const worksOfWeek = [
    {
      id: 'week-1',
      title: 'Cyber Neon Stream',
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'
    },
    {
      id: 'week-2',
      title: 'Galaxy Overlay Pack',
      image: 'https://images.unsplash.com/photo-1483478550801-ceba5fe50e8e?auto=format&fit=crop&w=1200&q=80'
    },
    {
      id: 'week-3',
      title: 'Festival Motion Kit',
      image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80'
    },
    {
      id: 'week-4',
      title: 'Digital Waves Banner',
      image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=70&sat=-40'
    },
    {
      id: 'week-5',
      title: 'Electric Pulse Avatar',
      image: 'https://images.unsplash.com/photo-1526481280695-3c4699dcd21c?auto=format&fit=crop&w=900&q=80'
    }
  ];

  const testimonials = [
    {
      id: 'review-1',
      quote: 'Наш YouTube-канал вырос в подписках после обновления всех обложек. Digital Cover Art моментально передал характер контента.',
      author: 'Анна Орлова',
      role: 'Продюсер канала “Science Today”',
      avatar: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80'
    },
    {
      id: 'review-2',
      quote: 'Покупаем готовые сцен-паки для стримов каждую неделю. Работы авторов экономят часы подготовки и выглядят премиально.',
      author: 'Nikita Streams',
      role: 'Twitch-партнёр',
      avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=200&q=80'
    },
    {
      id: 'review-3',
      quote: 'Команда платформы быстро отвечает на вопросы, а лицензии прозрачные и понятные. Наконец-то нашёл единый дизайн-маркетплейс.',
      author: 'Михаил Романов',
      role: 'Креативный директор студии “Pulse Media”',
      avatar: 'https://images.unsplash.com/photo-1504593811423-6dd665756598?auto=format&fit=crop&w=200&q=80'
    }
  ];

  const faqs = [
    {
      question: 'Какие права даёт покупка цифровой обложки?',
      answer:
        'После покупки вы получаете лицензию на использование визуала в своём канале или проекте. Можно адаптировать дизайн под ваш бренд, но запрещено перепродавать файлы от своего имени.'
    },
    {
      question: 'Можно ли запросить индивидуальную доработку?',
      answer:
        'Да, на странице товара можно оставить заявку автору. Многие дизайнеры предлагают услуги кастомизации: смена цветов, логотипа, добавление текста или графики.'
    },
    {
      question: 'Как быстро доступен файл после оплаты?',
      answer:
        'Сразу же после подтверждения транзакции вы получаете доступ к ZIP-архиву в личном кабинете и на почту. Файл остаётся доступным в истории заказов.'
    },
    {
      question: 'Подходит ли платформа для начинающих авторов?',
      answer:
        'Да, мы предоставляем пошаговые гайды по подготовке файлов, шаблоны описаний и помощь модераторов. Достаточно загрузить несколько работ и пройти проверку портфолио.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Digital Cover Art — Магазин обложек для видео и аватарок</title>
        <meta
          name="description"
          content="Платформа Digital Cover Art предлагает обложки для видео, аватарки, баннеры для стримов и шапки социальных сетей. Готовые шаблоны для создателей контента."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <div className={styles.heroContent}>
            <div className={styles.heroBadge}>Новое поколение дизайна</div>
            <h1 className={styles.heroTitle}>Цифровое искусство для вашего контента</h1>
            <p className={styles.heroText}>
              Коллекция ярких обложек, аватарок и баннеров для видеоканалов, стрим-платформ и социальных сетей.
              Выбирайте стиль, скачивайте ассеты и обновляйте визуальную айдентику за считанные минуты.
            </p>
            <div className={styles.heroActions}>
              <Link to="/catalog" className={styles.heroPrimary}>
                Смотреть каталог
              </Link>
              <Link to="/for-authors" className={styles.heroSecondary}>
                Стать автором
              </Link>
            </div>
            <div className={styles.heroStats}>
              <div>
                <span>2 500+</span>
                <p>графических пакетов</p>
              </div>
              <div>
                <span>120</span>
                <p>дизайнеров по всему миру</p>
              </div>
              <div>
                <span>48 ч</span>
                <p>среднее время модерации</p>
              </div>
            </div>
          </div>
          <div className={styles.heroPreview} aria-hidden="true">
            <div className={styles.previewCard}>
              <img
                src="https://images.unsplash.com/photo-1526481280695-3c4699dcd21c?auto=format&fit=crop&w=900&q=80"
                alt="Превью цифровой обложки с неоновым эффектом"
              />
              <div className={styles.previewBadge}>Работа недели</div>
            </div>
            <div className={styles.previewGlow} />
          </div>
        </div>
      </section>

      <section className={styles.categoriesSection} aria-labelledby="popular-categories">
        <div className={styles.sectionHeader}>
          <div>
            <h2 id="popular-categories">Популярные категории</h2>
            <p>
              Подберите формат под свою платформу: от YouTube и Twitch до Telegram и подкастов. Каждая работа
              проходит ручную модерацию команды Digital Cover Art.
            </p>
          </div>
          <Link to="/catalog" className={styles.sectionLink}>
            Перейти в каталог
          </Link>
        </div>
        <div className={styles.categoriesGrid}>
          {categories.map((category) => (
            <Link key={category.id} to={category.link} className={styles.categoryCard}>
              <div className={styles.categoryIcon} aria-hidden="true">
                <span>✦</span>
              </div>
              <div>
                <h3>{category.name}</h3>
                <p>{category.description}</p>
              </div>
              <span className={styles.categoryAction}>Смотреть</span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.howSection} aria-labelledby="how-it-works-home">
        <h2 id="how-it-works-home">Как это работает</h2>
        <div className={styles.steps}>
          <div className={styles.stepCard}>
            <div className={styles.stepNumber}>01</div>
            <h3>Выберите визуал</h3>
            <p>Отфильтруйте коллекцию по типу платформы, цветовой палитре и жанру. Избранные работы сохраняйте в подборки.</p>
          </div>
          <div className={styles.stepCard}>
            <div className={styles.stepNumber}>02</div>
            <h3>Скачайте пакеты</h3>
            <p>Получите ZIP-архив с PSD/PNG-файлами, шрифтами и инструкцией по быстрому редактированию.</p>
          </div>
          <div className={styles.stepCard}>
            <div className={styles.stepNumber}>03</div>
            <h3>Примените на канале</h3>
            <p>Загрузите обновлённые обложки, баннеры и оверлеи. Соблюдайте рекомендации по разрешению и оптимизации.</p>
          </div>
        </div>
      </section>

      <section className={styles.whySection} aria-labelledby="why-choose-us">
        <div className={styles.whyContent}>
          <h2 id="why-choose-us">Почему выбирают Digital Cover Art</h2>
          <p>
            Мы заботимся о качестве фирменного стиля так же, как и вы о своём контенте. Каждая работа проверяется
            на уникальность, корректность лицензий и удобство применения.
          </p>
          <ul className={styles.whyList}>
            <li>
              <h3>Проверенное качество</h3>
              <p>Трёхуровневая модерация: автоматическая проверка, дизайнерская ревизия и финальный контроль.</p>
            </li>
            <li>
              <h3>Прозрачная лицензия</h3>
              <p>Одна лицензия покрывает использование на всех собственных площадках автора без ограничений по времени.</p>
            </li>
            <li>
              <h3>Поддержка 24/7</h3>
              <p>Эксперты поддержки и кураторы авторов оперативно отвечают в чате, почте и Telegram.</p>
            </li>
          </ul>
        </div>
        <div className={styles.whyStats}>
          <div>
            <span>98%</span>
            <p>клиентов готовы рекомендовать платформу коллегам</p>
          </div>
          <div>
            <span>3,4×</span>
            <p>средний рост CTR на видео после обновления обложек</p>
          </div>
          <div>
            <span>72 страны</span>
            <p>география авторов и покупателей</p>
          </div>
        </div>
      </section>

      <section className={styles.gallerySection} aria-labelledby="gallery-home">
        <div className={styles.sectionHeader}>
          <div>
            <h2 id="gallery-home">Работы недели</h2>
            <p>Свежие релизы, которые вдохновляют стримеров, блогеров и продюсеров.</p>
          </div>
          <Link to="/catalog" className={styles.sectionLink}>
            Смотреть все работы
          </Link>
        </div>
        <div className={styles.galleryGrid}>
          {worksOfWeek.map((work) => (
            <figure key={work.id} className={styles.galleryItem}>
              <img src={work.image} alt={`Превью проекта ${work.title}`} loading="lazy" />
              <figcaption>{work.title}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className={styles.testimonialsSection} aria-labelledby="testimonials-home">
        <h2 id="testimonials-home">Отзывы создателей</h2>
        <div className={styles.testimonialsGrid}>
          {testimonials.map((testimonial) => (
            <article key={testimonial.id} className={styles.testimonialCard}>
              <div className={styles.testimonialHeader}>
                <img src={testimonial.avatar} alt={`Автор отзыва ${testimonial.author}`} />
                <div>
                  <h3>{testimonial.author}</h3>
                  <span>{testimonial.role}</span>
                </div>
              </div>
              <p>“{testimonial.quote}”</p>
            </article>
          ))}
        </div>
      </section>

      <section className={styles.faqSection} aria-labelledby="faq-home">
        <h2 id="faq-home">Частые вопросы</h2>
        <div className={styles.faqList}>
          {faqs.map((item, index) => {
            const isActive = activeFaq === index;
            return (
              <div key={item.question} className={`${styles.faqItem} ${isActive ? styles.faqItemActive : ''}`}>
                <button
                  type="button"
                  className={styles.faqButton}
                  onClick={() => setActiveFaq((prev) => (prev === index ? -1 : index))}
                  aria-expanded={isActive}
                >
                  <span>{item.question}</span>
                  <span className={styles.faqIcon}>{isActive ? '−' : '+'}</span>
                </button>
                {isActive && <p className={styles.faqAnswer}>{item.answer}</p>}
              </div>
            );
          })}
        </div>
      </section>

      <section className={styles.ctaSection}>
        <div className={styles.ctaCard}>
          <h2>Готовы делиться своим стилем?</h2>
          <p>
            Присоединяйтесь к сообществу авторов Digital Cover Art. Загружайте работы, получайте роялти и развивайте
            личный бренд на международной площадке.
          </p>
          <Link to="/for-authors" className={styles.ctaButton}>
            Стать автором
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;