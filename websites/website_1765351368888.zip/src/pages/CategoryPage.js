import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import categories from '../data/categories';
import products from '../data/products';
import styles from './CategoryPage.module.css';

const CategoryPage = ({ categoryId }) => {
  const category = categories.find((item) => item.id === categoryId);
  const categoryProducts = products.filter((product) => product.category === categoryId);

  if (!category) {
    return null;
  }

  return (
    <>
      <Helmet>
        <title>{`${category.name} — Digital Cover Art`}</title>
        <meta
          name="description"
          content={`Категория ${category.name} на платформе Digital Cover Art. Готовые шаблоны и графические ассеты для создателей контента.`}
        />
      </Helmet>

      <section className={styles.category}>
        <div className={styles.header}>
          <span className={styles.breadcrumbs}>
            <Link to="/catalog">Каталог</Link> / <span>{category.name}</span>
          </span>
          <h1>{category.name}</h1>
          <p>{category.description}</p>
        </div>

        <div className={styles.products}>
          {categoryProducts.map((product) => (
            <article key={product.id} className={styles.card}>
              <img src={product.image} alt={`Превью ${product.title}`} loading="lazy" />
              <div className={styles.cardBody}>
                <h2>{product.title}</h2>
                <p>Автор: {product.author}</p>
                <ul className={styles.tags}>
                  {product.tags.map((tag) => (
                    <li key={tag}>{tag}</li>
                  ))}
                </ul>
              </div>
            </article>
          ))}
        </div>

        <div className={styles.cta}>
          <h2>Нужен другой формат?</h2>
          <p>
            Изучите полный <Link to="/catalog">каталог работ</Link> или оставьте заявку автору на индивидуальный дизайн,
            чтобы сохранить фирменный стиль вашего проекта.
          </p>
        </div>
      </section>
    </>
  );
};

export default CategoryPage;