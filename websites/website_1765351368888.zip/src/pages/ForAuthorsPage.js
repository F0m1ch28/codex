import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './ForAuthorsPage.module.css';

const ForAuthorsPage = () => (
  <>
    <Helmet>
      <title>Для авторов — Digital Cover Art</title>
      <meta
        name="description"
        content="Подключайтесь к Digital Cover Art как автор. Получайте роялти, участвуйте в образовательных программах и продавайте свои графические пакеты."
      />
    </Helmet>

    <section className={styles.wrapper}>
      <div className={styles.hero}>
        <h1>Присоединяйтесь к сообществу дизайнеров Digital Cover Art</h1>
        <p>
          Делитесь своими графическими стилями, продавайте готовые пакеты и зарабатывайте на творчестве. Мы поможем с
          модерацией, продвижением и аналитикой.
        </p>
        <a href="mailto:authors@digitalcoverart.com" className={styles.heroButton}>
          Отправить портфолио
        </a>
      </div>

      <div className={styles.perks}>
        <div>
          <h2>Что получает автор</h2>
          <ul>
            <li><strong>70% роялти</strong> с каждой продажи при эксклюзивном размещении.</li>
            <li><strong>Персональную витрину</strong> с подпиской на обновления и аналитикой продаж.</li>
            <li><strong>Поддержку наставника</strong> для улучшения пакетов и адаптации к трендам.</li>
            <li><strong>Участие в конкурсах</strong> и коллаборациях с крупными каналами.</li>
          </ul>
        </div>
        <div>
          <h2>Требования</h2>
          <ul>
            <li>Оригинальные работы с правами на использование шрифтов и изображений.</li>
            <li>Исходники в PSD, Figma, After Effects или другом редактируемом формате.</li>
            <li>Превью 1920×1080, 1080×1080 и вертикальные 1080×1920 при необходимости.</li>
            <li>Подробная инструкция для клиента — список слоёв, шрифтов и советов по адаптации.</li>
          </ul>
        </div>
      </div>

      <div className={styles.steps}>
        <h2>Путь автора на платформе</h2>
        <div className={styles.stepsGrid}>
          <div>
            <span>1</span>
            <h3>Заявка</h3>
            <p>Отправьте портфолио и заполните анкету. Среднее время ответа — 3 рабочих дня.</p>
          </div>
          <div>
            <span>2</span>
            <h3>Онбординг</h3>
            <p>Получите гайд по оформлению пакета, доступ к шаблонам превью и общему чату авторов.</p>
          </div>
          <div>
            <span>3</span>
            <h3>Публикация</h3>
            <p>После модерации работа попадает в каталог и участвует в подборках, рассылках и баннерах.</p>
          </div>
          <div>
            <span>4</span>
            <h3>Рост</h3>
            <p>Аналитика продаж, рекомендации по улучшению и участие в ко-брендинговых проектах.</p>
          </div>
        </div>
      </div>
    </section>
  </>
);

export default ForAuthorsPage;