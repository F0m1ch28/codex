import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './AboutPage.module.css';

const teamMembers = [
  {
    name: 'Марина Соколова',
    role: 'CEO и сооснователь',
    bio: '10 лет в индустрии креативных агентств, запустила более 200 кампаний для YouTube-проектов.',
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Игорь Чернов',
    role: 'Creative Director',
    bio: 'Специализируется на motion-дизайне и стрим-графике. Курирует авторов и стандарты качества.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Ли Сюан',
    role: 'Head of Community',
    bio: 'Развивает глобальное сообщество Digital Cover Art, организует обучающие сессии и конкурсы.',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80'
  }
];

const AboutPage = () => (
  <>
    <Helmet>
      <title>О компании Digital Cover Art</title>
      <meta
        name="description"
        content="Digital Cover Art — цифровая площадка для продажи обложек, аватарок и баннеров. Узнайте о миссии, команде и ценностях платформы."
      />
    </Helmet>

    <section className={styles.about}>
      <div className={styles.intro}>
        <h1>Digital Cover Art — место, где графика встречает контент</h1>
        <p>
          Мы создали глобальную платформу для создателей, которым важно визуальное качество так же, как и
          содержимое роликов и стримов. На Digital Cover Art встречаются дизайнеры из разных стран, чтобы делиться
          авторскими стилями и зарабатывать на творчестве.
        </p>
      </div>

      <div className={styles.mission}>
        <div className={styles.missionCard}>
          <h2>Наша миссия</h2>
          <p>
            Делать визуальную идентику доступной каждому создателю. Мы стремимся, чтобы блогеры, подкастеры,
            стримеры и команды из любых ниш могли быстро находить и адаптировать дизайн под свои задачи.
          </p>
        </div>
        <div className={styles.missionCard}>
          <h2>Ценности</h2>
          <ul>
            <li><strong>Авторство:</strong> только оригинальные работы, прозрачные лицензии и дорожная карта по защите прав.</li>
            <li><strong>Сообщество:</strong> регулярные вебинары, ревью и поддержка для авторов.</li>
            <li><strong>Инновации:</strong> инструменты предпросмотра, AI-подбор цвета и форматирование под платформы.</li>
          </ul>
        </div>
      </div>

      <div className={styles.timeline}>
        <h2>Как мы развивались</h2>
        <ul>
          <li>
            <span className={styles.year}>2020</span>
            <p>Запуск закрытой beta-площадки с 15 дизайнерами и фокусом на YouTube обложки.</p>
          </li>
          <li>
            <span className={styles.year}>2021</span>
            <p>Добавлены категории для Twitch и Telegram. Внедрён редактор предпросмотра с живой сменой цветов.</p>
          </li>
          <li>
            <span className={styles.year}>2023</span>
            <p>Выход на глобальный рынок и поддержка пяти языков интерфейса. Более 1000 работ в каталоге.</p>
          </li>
          <li>
            <span className={styles.year}>2024</span>
            <p>Интеграция с API видеоплатформ, аналитика эффективности дизайна и персональные рекомендации.</p>
          </li>
        </ul>
      </div>

      <div className={styles.team}>
        <h2>Команда Digital Cover Art</h2>
        <div className={styles.teamGrid}>
          {teamMembers.map((member) => (
            <article key={member.name} className={styles.memberCard}>
              <img src={member.avatar} alt={`Команда: ${member.name}`} loading="lazy" />
              <h3>{member.name}</h3>
              <span>{member.role}</span>
              <p>{member.bio}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  </>
);

export default AboutPage;