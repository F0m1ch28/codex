import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './LegalPage.module.css';

const CookiePolicyPage = () => (
  <>
    <Helmet>
      <title>Политика использования cookies — Digital Cover Art</title>
      <meta
        name="description"
        content="Политика использования файлов cookies на платформе Digital Cover Art: виды, цели и способы управления."
      />
    </Helmet>

    <section className={styles.legal}>
      <h1>Политика использования cookies</h1>
      <p className={styles.updated}>Последнее обновление: 15 февраля 2024 года</p>

      <h2>1. Что такое cookies</h2>
      <p>
        Cookies — небольшие текстовые файлы, которые сохраняются в браузере при посещении сайта. Они помогают запомнить
        настройки пользователя и анализировать работу сервиса.
      </p>

      <h2>2. Какие cookies мы используем</h2>
      <ul>
        <li><strong>Технические.</strong> Обеспечивают авторизацию, сохранение языка интерфейса и корректную работу форм.</li>
        <li><strong>Аналитические.</strong> Позволяют оценивать посещаемость и эффективность страниц (обезличенные данные).</li>
        <li><strong>Функциональные.</strong> Запоминают избранные товары и фильтры, чтобы ускорить повторные визиты.</li>
      </ul>

      <h2>3. Как управлять cookies</h2>
      <p>
        Вы можете изменить настройки браузера и отказаться от cookies. Однако часть функций сайта может работать
        некорректно. Удалить сохранённые файлы можно в настройках приватности браузера.
      </p>

      <h2>4. Контакты</h2>
      <p>
        По вопросам политики cookies пишите на <a href="mailto:support@digitalcoverart.com">support@digitalcoverart.com</a>.
      </p>
    </section>
  </>
);

export default CookiePolicyPage;