import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('dca-cookie-consent');
    if (!consent) {
      setVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('dca-cookie-consent', 'accepted');
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <strong className={styles.title}>Мы используем cookies</strong>
        <p className={styles.text}>
          Файлы cookies помогают нам анализировать трафик и улучшать интерфейс. Продолжая пользоваться сайтом,
          вы соглашаетесь с <Link to="/cookie-policy">политикой cookies</Link>.
        </p>
      </div>
      <button type="button" className={styles.button} onClick={handleAccept}>
        Согласен
      </button>
    </div>
  );
};

export default CookieBanner;