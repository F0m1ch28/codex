import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => (
  <footer className={styles.footer}>
    <div className={styles.container}>
      <div className={styles.brand}>
        <Link to="/" className={styles.logo}>
          <span className={styles.logoAccent}>Digital</span> Cover Art
        </Link>
        <p className={styles.text}>
          Глобальная платформа цифрового дизайна для создателей контента. Мы соединяем авторов и дизайнеров,
          чтобы каждый проект получил выразительный визуальный стиль.
        </p>
        <p className={styles.copy}>© {new Date().getFullYear()} Digital Cover Art. Все права защищены.</p>
      </div>

      <div className={styles.column}>
        <h4 className={styles.heading}>Навигация</h4>
        <ul className={styles.list}>
          <li><Link to="/about">О компании</Link></li>
          <li><Link to="/how-it-works">Как это работает</Link></li>
          <li><Link to="/for-authors">Для авторов</Link></li>
          <li><Link to="/contacts">Контакты</Link></li>
        </ul>
      </div>

      <div className={styles.column}>
        <h4 className={styles.heading}>Правовая информация</h4>
        <ul className={styles.list}>
          <li><Link to="/terms">Условия использования</Link></li>
          <li><Link to="/privacy">Политика конфиденциальности</Link></li>
          <li><Link to="/cookie-policy">Политика использования cookies</Link></li>
        </ul>
      </div>

      <div className={styles.contacts}>
        <h4 className={styles.heading}>Контакты</h4>
        <p className={styles.contactItem}>
          Email поддержки: <a href="mailto:support@digitalcoverart.com">support@digitalcoverart.com</a>
        </p>
        <p className={styles.contactItem}>
          Email для авторов: <a href="mailto:authors@digitalcoverart.com">authors@digitalcoverart.com</a>
        </p>
        <p className={styles.contactItem}>
          Телефон: <a href="tel:+74951234567">+7 (495) 123-45-67</a>
        </p>
        <p className={styles.contactItem}>
          Адрес: 123456, г. Москва, ул. Цифровая, д. 7, офис 14
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;