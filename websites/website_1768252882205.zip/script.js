document.addEventListener("DOMContentLoaded", function () {
    const cookieBanner = document.querySelector(".cookie-banner");
    if (!cookieBanner) {
        return;
    }

    const consentStatus = localStorage.getItem("removerloqCookiesAccepted");
    if (consentStatus === "true") {
        cookieBanner.classList.add("banner-hidden");
    } else {
        cookieBanner.style.display = "flex";
    }

    const acceptButton = cookieBanner.querySelector(".cookie-accept");
    if (acceptButton) {
        acceptButton.addEventListener("click", function () {
            localStorage.setItem("removerloqCookiesAccepted", "true");
            cookieBanner.classList.add("banner-hidden");
        });
    }
});