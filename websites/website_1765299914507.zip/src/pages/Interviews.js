```javascript
import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import InterviewCard from '../components/InterviewCard';
import interviewsData from '../data/interviews';
import styles from './Interviews.module.css';

const Interviews = () => {
  const interviews = useMemo(() => {
    return [...interviewsData].sort(
      (a, b) => new Date(b.publishedDate) - new Date(a.publishedDate)
    );
  }, []);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Interviews — French Equestrian Clubs Review</title>
        <meta
          name="description"
          content="Entretiens avec des responsables de clubs, vétérinaires, historiens et experts du monde équestre français."
        />
      </Helmet>

      <header className={styles.header}>
        <div className={styles.container}>
          <h1>Interviews</h1>
          <p>
            Les entretiens donnent la parole aux acteurs du terrain et aux
            chercheurs qui observent les clubs équestres. Ils éclairent les
            méthodes, les défis et les perspectives de chaque discipline.
          </p>
        </div>
      </header>

      <section className={styles.list}>
        <div className={styles.container}>
          <div className={styles.grid}>
            {interviews.map((interview) => (
              <InterviewCard key={interview.id} interview={interview} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Interviews;
```