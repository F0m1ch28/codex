```javascript
import React, { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import ArticleCard from '../components/ArticleCard';
import CategoryFilter from '../components/CategoryFilter';
import TagList from '../components/TagList';
import articlesData from '../data/articles';
import categories from '../data/categories';
import styles from './Articles.module.css';

const Articles = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const sortedArticles = useMemo(() => {
    return [...articlesData].sort(
      (a, b) => new Date(b.publishedDate) - new Date(a.publishedDate)
    );
  }, []);

  const filteredArticles = useMemo(() => {
    if (selectedCategory === 'all') {
      return sortedArticles;
    }
    return sortedArticles.filter(
      (article) => article.category === selectedCategory
    );
  }, [selectedCategory, sortedArticles]);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>Tous les Articles — French Equestrian Clubs Review</title>
        <meta
          name="description"
          content="Ensemble des études, enquêtes et analyses publiées par la rédaction sur les clubs équestres français."
        />
      </Helmet>

      <section className={styles.header}>
        <div className={styles.container}>
          <h1>Tous les articles</h1>
          <p>
            Les enquêtes proposées explorent la diversité des clubs équestres
            français, de leurs structures associatives à leurs pratiques
            pédagogiques. La sélection peut être filtrée par thématique.
          </p>
        </div>
      </section>

      <section className={styles.filters}>
        <div className={styles.container}>
          <CategoryFilter
            categories={categories}
            selected={selectedCategory}
            onChange={setSelectedCategory}
          />
          <TagList
            categories={categories}
            selected={selectedCategory}
            onSelect={setSelectedCategory}
          />
        </div>
      </section>

      <section className={styles.list}>
        <div className={styles.container}>
          {filteredArticles.length === 0 ? (
            <p className={styles.emptyState}>
              Aucun article ne correspond à cette catégorie pour le moment. La
              sélection sera enrichie prochainement.
            </p>
          ) : (
            <div className={styles.grid}>
              {filteredArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Articles;
```