```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Ressources.module.css';

const Ressources = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Ressources — French Equestrian Clubs Review</title>
      <meta
        name="description"
        content="Sélection de ressources documentaires, d’archives et de guides pour approfondir la connaissance des clubs équestres."
      />
    </Helmet>

    <header className={styles.header}>
      <div className={styles.container}>
        <h1>Ressources complémentaires</h1>
        <p>
          Cette sélection de ressources vise à enrichir les recherches des
          lecteurs : textes réglementaires, ouvrages de référence, bases
          iconographiques et supports pédagogiques.
        </p>
      </div>
    </header>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Institutions et cadres réglementaires</h2>
        <ul className={styles.list}>
          <li>
            Répertoire des statuts types pour les associations équestres, mis à
            jour annuellement par les fédérations territoriales.
          </li>
          <li>
            Guides ministériels concernant la sécurité des établissements
            recevant du public et la réglementation spécifique aux structures
            équestres.
          </li>
          <li>
            Publications de la Fédération Française d’Équitation relatives à la
            formation des encadrants et aux examens fédéraux.
          </li>
        </ul>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Archives et centres de documentation</h2>
        <ul className={styles.list}>
          <li>
            Inventaires départementaux des clubs hippiques disponibles dans les
            archives municipales et départementales.
          </li>
          <li>
            Fonds photographiques des années 1920-1980 consultables au sein des
            bibliothèques patrimoniales spécialisées.
          </li>
          <li>
            Plateformes universitaires diffusant des mémoires et thèses sur
            l’histoire du sport et la sociologie des loisirs.
          </li>
        </ul>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Outils pédagogiques</h2>
        <ul className={styles.list}>
          <li>
            Carnets d’observation pour les séances d’équitation scolaire,
            proposés en accès libre par plusieurs académies.
          </li>
          <li>
            Modules interactifs sur l’anatomie du cheval, développés par des
            écoles vétérinaires partenaires.
          </li>
          <li>
            Boîtes à outils destinées aux clubs souhaitant structurer des
            programmes d’inclusion et de médiation avec le cheval.
          </li>
        </ul>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Veille et actualisations</h2>
        <p>
          La rédaction tient à jour un répertoire de newsletters, de revues
          académiques et de podcasts consacrés à l’équitation. Les références
          sont actualisées deux fois par an et intégrées à chaque dossier pour
          encourager la consultation croisée des sources.
        </p>
      </div>
    </section>
  </div>
);

export default Ressources;
```