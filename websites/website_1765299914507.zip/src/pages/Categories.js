```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import categories from '../data/categories';
import styles from './Categories.module.css';

const Categories = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Catégories — French Equestrian Clubs Review</title>
      <meta
        name="description"
        content="Aperçu des thématiques couvertes par la rédaction : clubs hippiques, disciplines équestres, pédagogies et territoires."
      />
    </Helmet>

    <header className={styles.header}>
      <div className={styles.container}>
        <h1>Catégories éditoriales</h1>
        <p>
          Chaque catégorie rassemble des investigations axées sur une facette
          spécifique de la vie des clubs équestres : organisation, pédagogie,
          pratiques régionales ou encore rôle social.
        </p>
      </div>
    </header>

    <section className={styles.gridSection}>
      <div className={styles.container}>
        <div className={styles.grid}>
          {categories.map((category) => (
            <Link
              key={category.slug}
              to={`/categories/${category.slug}`}
              className={styles.card}
            >
              <figure className={styles.imageWrapper}>
                <img src={category.imageUrl} alt={category.name} />
              </figure>
              <div className={styles.cardContent}>
                <h2>{category.name}</h2>
                <p>{category.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default Categories;
```