```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Methodologie.module.css';

const Methodologie = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Méthodologie — French Equestrian Clubs Review</title>
      <meta
        name="description"
        content="Présentation détaillée de la méthodologie d’enquête, des outils de vérification et des protocoles rédactionnels."
      />
    </Helmet>

    <header className={styles.header}>
      <div className={styles.container}>
        <h1>Méthodologie</h1>
        <p>
          La méthodologie de French Equestrian Clubs Review repose sur un
          protocole commun à toutes les enquêtes. Elle articule collecte
          documentaire, observation directe, entretiens thématiques et travail
          d’édition collaboratif.
        </p>
      </div>
    </header>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Collecte documentaire initiale</h2>
        <p>
          Chaque sujet débute par une revue documentaire approfondie : textes
          réglementaires, archives de presse, publications scientifiques et
          rapports d’activités des structures concernées. Cette étape permet de
          poser un cadre factuel précis avant toute rencontre de terrain.
        </p>
        <p>
          Les sources sont recensées dans une base partagée et classées par
          thématique. Les rédacteurs s’appuient sur des grilles de lecture
          communes pour évaluer la fiabilité et la pertinence des documents
          collectés.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Observation et immersion</h2>
        <p>
          Les reporters se déplacent dans les clubs étudiés pour observer les
          séances, les infrastructures et les modes d’organisation. Ils
          renseignent des carnets d’observation qui décrivent le déroulé des
          journées, la circulation des acteurs et les dispositifs matériels mis
          en place.
        </p>
        <p>
          Un protocole d’immersion définit la durée minimale des visites et les
          éléments à documenter : espaces de travail, équipements, modalités de
          soins, interactions entre encadrants et cavaliers.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Entretiens et vérifications croisées</h2>
        <p>
          Les entretiens sont menés selon une grille semi-directive adaptée à
          chaque profil : dirigeants de club, enseignants, vétérinaires,
          historiens, élus locaux. Les propos sont enregistrés avec le
          consentement des personnes interrogées et retranscrits intégralement
          avant synthèse.
        </p>
        <p>
          Les affirmations sensibles sont systématiquement vérifiées auprès de
          plusieurs sources. Les contradictions éventuelles sont mentionnées
          pour refléter la diversité des points de vue.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Écriture et relecture</h2>
        <p>
          L’écriture des articles et des interviews s’effectue à quatre mains :
          un auteur principal et un relecteur garantissent la qualité
          rédactionnelle et la cohérence méthodologique. Une dernière vérification
          porte sur les citations, les chiffres et les dates mentionnés.
        </p>
        <p>
          Avant publication, un résumé des conclusions est transmis aux personnes
          interrogées afin de s’assurer de la fidélité des propos rapportés. Les
          corrections éventuelles sont intégrées et tracées dans le dossier de
          production.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Transparence et mises à jour</h2>
        <p>
          Chaque article précise les lieux et les périodes d’observation ainsi
          que les principaux interlocuteurs rencontrés. Les mises à jour sont
          indiquées en fin de texte, avec mention de la date et de la nature des
          corrections apportées.
        </p>
      </div>
    </section>
  </div>
);

export default Methodologie;
```