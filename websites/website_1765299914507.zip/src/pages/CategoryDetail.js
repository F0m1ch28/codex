```javascript
import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useParams } from 'react-router-dom';
import categories from '../data/categories';
import articlesData from '../data/articles';
import interviewsData from '../data/interviews';
import ArticleCard from '../components/ArticleCard';
import InterviewCard from '../components/InterviewCard';
import styles from './CategoryDetail.module.css';

const CategoryDetail = () => {
  const { categorySlug } = useParams();

  const category = categories.find((item) => item.slug === categorySlug);

  const relatedArticles = useMemo(
    () =>
      articlesData.filter((article) => article.category === categorySlug),
    [categorySlug]
  );

  const relatedInterviews = useMemo(
    () =>
      interviewsData.filter(
        (interview) => interview.category === categorySlug
      ),
    [categorySlug]
  );

  if (!category) {
    return (
      <div className={styles.notFound}>
        <h1>Catégorie introuvable</h1>
        <p>
          La catégorie demandée n’est pas disponible. Merci de consulter la
          liste principale pour accéder aux thématiques actives.
        </p>
        <Link to="/categories" className={styles.backLink}>
          Retourner aux catégories
        </Link>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Helmet>
        <title>
          {category.name} — French Equestrian Clubs Review
        </title>
        <meta name="description" content={category.description} />
      </Helmet>

      <header className={styles.header}>
        <div className={styles.container}>
          <p className={styles.kicker}>Catégorie</p>
          <h1>{category.name}</h1>
          <p className={styles.description}>{category.description}</p>
        </div>
      </header>

      <section className={styles.section}>
        <div className={styles.container}>
          <h2>Articles de référence</h2>
          {relatedArticles.length === 0 ? (
            <p className={styles.empty}>
              Aucun article n’est actuellement disponible dans cette catégorie.
              Les investigations sont en cours.
            </p>
          ) : (
            <div className={styles.grid}>
              {relatedArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className={styles.sectionAlt}>
        <div className={styles.container}>
          <h2>Entretiens associés</h2>
          {relatedInterviews.length === 0 ? (
            <p className={styles.empty}>
              Aucun entretien n’a encore été publié sur cette thématique.
            </p>
          ) : (
            <div className={styles.grid}>
              {relatedInterviews.map((interview) => (
                <InterviewCard key={interview.id} interview={interview} />
              ))}
            </div>
          )}
        </div>
      </section>

      <footer className={styles.footer}>
        <div className={styles.container}>
          <Link to="/categories" className={styles.backLink}>
            Explorer d’autres catégories
          </Link>
        </div>
      </footer>
    </div>
  );
};

export default CategoryDetail;
```