```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const PolitiqueConfidentialite = () => (
  <div className={styles.page}>
    <Helmet>
      <title>
        Politique de Confidentialité — French Equestrian Clubs Review
      </title>
      <meta
        name="description"
        content="Informations sur la gestion des données personnelles collectées via le site."
      />
    </Helmet>

    <header className={styles.header}>
      <div className={styles.container}>
        <h1>Politique de confidentialité</h1>
        <p>
          Cette politique décrit la manière dont French Equestrian Clubs Review
          traite les données personnelles collectées via ses formulaires.
        </p>
      </div>
    </header>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Données collectées</h2>
        <p>
          Seules les informations fournies via le formulaire de contact sont
          enregistrées : nom, adresse électronique, sujet et contenu du message.
          Ces données servent à répondre aux demandes adressées à la rédaction.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Durée de conservation</h2>
        <p>
          Les messages reçus sont conservés pour une durée maximale de douze
          mois, le temps d’assurer le suivi des échanges. Ils sont ensuite
          archivés ou supprimés selon leur pertinence documentaire.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Partage des informations</h2>
        <p>
          Les données ne sont pas transmises à des tiers. Seuls les membres
          habilités de la rédaction peuvent y accéder afin de traiter les
          demandes.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Droits des personnes</h2>
        <p>
          Toute personne peut demander l’accès, la rectification ou la
          suppression des données la concernant en adressant une requête via le
          formulaire de contact. La rédaction s’engage à répondre dans les
          meilleurs délais.
        </p>
      </div>
    </section>
  </div>
);

export default PolitiqueConfidentialite;
```