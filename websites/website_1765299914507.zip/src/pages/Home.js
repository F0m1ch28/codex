```javascript
import React, { useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import ArticleCard from '../components/ArticleCard';
import InterviewCard from '../components/InterviewCard';
import articlesData from '../data/articles';
import interviewsData from '../data/interviews';
import categories from '../data/categories';
import styles from './Home.module.css';

const focusAreas = [
  {
    title: 'Traditions',
    description:
      'Étude des rituels, des compétitions historiques et des transmissions mémorielles au sein des clubs.',
    icon: '📜'
  },
  {
    title: 'Organisation des clubs',
    description:
      'Analyse des modèles de gouvernance, des statuts associatifs et des relations avec les fédérations.',
    icon: '🏛️'
  },
  {
    title: 'Pédagogie',
    description:
      'Observation des méthodes d’apprentissage, des supports pédagogiques et des parcours diplômants.',
    icon: '🎓'
  },
  {
    title: 'Disciplines équestres',
    description:
      'Suivi des modalités d’entraînement, des innovations techniques et des tendances sportives.',
    icon: '🏇'
  },
  {
    title: 'Ancrages régionaux',
    description:
      'Cartographie des spécificités locales, des paysages traversés et des collaborations culturelles.',
    icon: '🗺️'
  },
  {
    title: 'Rôle social',
    description:
      'Compréhension des dispositifs d’inclusion, des partenariats éducatifs et des actions citoyennes.',
    icon: '🤝'
  }
];

const Home = () => {
  const latestItems = useMemo(() => {
    const combined = [...articlesData, ...interviewsData];
    return combined
      .sort(
        (a, b) => new Date(b.publishedDate) - new Date(a.publishedDate)
      )
      .slice(0, 4);
  }, []);

  const interviewALaUne = useMemo(() => {
    return [...interviewsData].sort(
      (a, b) => new Date(b.publishedDate) - new Date(a.publishedDate)
    )[0];
  }, []);

  return (
    <div className={styles.page}>
      <Helmet>
        <title>French Equestrian Clubs Review — Accueil</title>
        <meta
          name="description"
          content="Analyse indépendante des clubs équestres français, de leurs pratiques pédagogiques et de leur rôle culturel."
        />
      </Helmet>

      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <span className={styles.heroTagline}>
            Publication d’enquêtes culturelles
          </span>
          <h1 className={styles.heroTitle}>
            French Equestrian Clubs Review
          </h1>
          <p className={styles.heroSubtitle}>
            Une rédaction qui observe les clubs équestres de France, leurs
            traditions, leurs modes d’organisation et leur contribution à la vie
            sportive et rurale.
          </p>
          <div className={styles.heroLinks}>
            <Link to="/articles" className={styles.heroLink}>
              Parcourir les analyses
            </Link>
            <Link to="/interviews" className={styles.heroLinkSecondary}>
              Découvrir les entretiens
            </Link>
          </div>
        </div>
      </section>

      <section className={styles.introSection}>
        <div className={styles.container}>
          <h2 className={styles.sectionTitle}>Introduction</h2>
          <p className={styles.lead}>
            French Equestrian Clubs Review documente l’activité des clubs
            équestres français à travers des enquêtes de terrain, des analyses
            historiques et des entretiens approfondis. L’équipe privilégie un
            regard neutre, soucieux de contextualiser chaque témoignage et de
            croiser les sources disponibles.
          </p>
        </div>
      </section>

      <section className={styles.latestSection} aria-labelledby="latest-heading">
        <div className={styles.container}>
          <div className={styles.sectionHeader}>
            <h2 id="latest-heading" className={styles.sectionTitle}>
              Dernières publications
            </h2>
            <p className={styles.sectionDescription}>
              Sélection des articles et entretiens récemment publiés, couvrant
              des thématiques organisationnelles, pédagogiques et culturelles.
            </p>
          </div>
          <div className={styles.cardsGrid}>
            {latestItems.map((item) =>
              item.interviewee ? (
                <InterviewCard key={`${item.slug}-interview`} interview={item} />
              ) : (
                <ArticleCard key={`${item.slug}-article`} article={item} />
              )
            )}
          </div>
        </div>
      </section>

      <section
        className={styles.focusSection}
        aria-labelledby="focus-heading"
      >
        <div className={styles.container}>
          <h2 id="focus-heading" className={styles.sectionTitle}>
            Notre champ d’étude
          </h2>
          <div className={styles.focusGrid}>
            {focusAreas.map((area) => (
              <article key={area.title} className={styles.focusCard}>
                <span className={styles.focusIcon} aria-hidden="true">
                  {area.icon}
                </span>
                <h3 className={styles.focusTitle}>{area.title}</h3>
                <p className={styles.focusText}>{area.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {interviewALaUne && (
        <section
          className={styles.highlightSection}
          aria-labelledby="highlight-heading"
        >
          <div className={styles.container}>
            <div className={styles.highlightWrapper}>
              <div className={styles.highlightImageWrapper}>
                <img
                  src={interviewALaUne.imageUrl}
                  alt={interviewALaUne.title}
                  className={styles.highlightImage}
                />
              </div>
              <div className={styles.highlightContent}>
                <p className={styles.highlightTag}>Interview à la une</p>
                <h2
                  id="highlight-heading"
                  className={styles.highlightTitle}
                >
                  {interviewALaUne.title}
                </h2>
                <p className={styles.highlightMeta}>
                  {interviewALaUne.interviewee} — {interviewALaUne.role}
                </p>
                <p className={styles.highlightExcerpt}>
                  {interviewALaUne.excerpt}
                </p>
                <Link
                  to={`/interviews/${interviewALaUne.slug}`}
                  className={styles.highlightLink}
                >
                  Lire l’entretien en intégralité
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}

      <section
        className={styles.demarcheSection}
        aria-labelledby="demarche-heading"
      >
        <div className={styles.container}>
          <h2 id="demarche-heading" className={styles.sectionTitle}>
            Notre démarche
          </h2>
          <div className={styles.demarcheGrid}>
            <article className={styles.demarcheCard}>
              <h3>Neutralité rédactionnelle</h3>
              <p>
                Les analyses sont rédigées à partir de sources croisées et
                vérifiées. Le ton reste factuel, sans promotion ni jugement de
                valeur.
              </p>
            </article>
            <article className={styles.demarcheCard}>
              <h3>Expertises mobilisées</h3>
              <p>
                Chaque sujet bénéficie d’entretiens avec des spécialistes :
                responsables de clubs, vétérinaires, historiens et encadrants.
              </p>
            </article>
            <article className={styles.demarcheCard}>
              <h3>Observation de terrain</h3>
              <p>
                La rédaction sillonne les territoires, assiste aux séances et
                recueille des témoignages pour documenter les pratiques réelles.
              </p>
            </article>
            <article className={styles.demarcheCard}>
              <h3>Transparence documentaire</h3>
              <p>
                Les sources archivistiques, bibliographiques et statistiques
                sont systématiquement mentionnées afin de faciliter la
                vérification par les lecteurs.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section
        className={styles.explorerSection}
        aria-labelledby="explorer-heading"
      >
        <div className={styles.container}>
          <h2 id="explorer-heading" className={styles.sectionTitle}>
            Explorer par thème
          </h2>
          <div className={styles.categoryGrid}>
            {categories.map((category) => (
              <Link
                to={`/categories/${category.slug}`}
                key={category.slug}
                className={styles.categoryCard}
              >
                <div className={styles.categoryImageWrapper}>
                  <img
                    src={category.imageUrl}
                    alt={category.name}
                    className={styles.categoryImage}
                  />
                </div>
                <div className={styles.categoryContent}>
                  <h3>{category.name}</h3>
                  <p>{category.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
```