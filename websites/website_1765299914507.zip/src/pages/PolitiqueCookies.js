```javascript
import React from 'react';
import { Helmet } from 'react-helmet-async';
import styles from './Legal.module.css';

const PolitiqueCookies = () => (
  <div className={styles.page}>
    <Helmet>
      <title>Politique des Cookies — French Equestrian Clubs Review</title>
      <meta
        name="description"
        content="Informations sur l’usage des cookies nécessaires au fonctionnement du site."
      />
    </Helmet>

    <header className={styles.header}>
      <div className={styles.container}>
        <h1>Politique des cookies</h1>
        <p>
          French Equestrian Clubs Review utilise des cookies strictement
          nécessaires au bon fonctionnement du site et aux mesures de fréquentation
          anonymisées.
        </p>
      </div>
    </header>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Cookies nécessaires</h2>
        <p>
          Les cookies techniques garantissent l’accès aux contenus et la
          navigation entre les pages. Ils sont indispensables et ne stockent
          aucune information personnelle.
        </p>
      </div>
    </section>

    <section className={styles.sectionAlt}>
      <div className={styles.container}>
        <h2>Mesure d’audience</h2>
        <p>
          Des indicateurs anonymes, basés sur des cookies, permettent de
          comprendre la consultation des pages. Ces données servent uniquement
          à améliorer l’ergonomie du site.
        </p>
      </div>
    </section>

    <section className={styles.section}>
      <div className={styles.container}>
        <h2>Gestion des préférences</h2>
        <p>
          Le bandeau dédié permet d’accepter ou de refuser l’utilisation de
          cookies non essentiels. Les choix effectués peuvent être modifiés en
          vidant le stockage local du navigateur.
        </p>
      </div>
    </section>
  </div>
);

export default PolitiqueCookies;
```