```javascript
const interviews = [
  {
    id: 1,
    title:
      'Entretien avec Claire Dubreuil, vétérinaire spécialisée dans le suivi des chevaux de sport',
    slug: 'entretien-claire-dubreuil-suivi-sante',
    category: 'cavalerie-et-soins-des-chevaux',
    excerpt:
      'La vétérinaire détaille la coordination indispensable entre soignants, cavaliers et enseignants pour prévenir les blessures.',
    content: `Claire Dubreuil insiste d’abord sur la prévention : « L’observation quotidienne et la qualité des échanges entre grooms, cavaliers et enseignants restent les premières clés. Lorsque les informations remontent rapidement, la plupart des alertes peuvent être traitées tôt et sans lourdeur. » Elle souligne également l’importance d’une planification raisonnée entre les objectifs sportifs et les temps de récupération.

Elle évoque ensuite les outils qui se démocratisent : « Les mesureurs de fréquence cardiaque et les analyses de locomotion aident à repérer des variations infimes. Ils ne remplacent pas l’œil du praticien, mais ils offrent des indices complémentaires. » Les clubs qu’elle accompagne mettent en place des points sanitaires hebdomadaires pour partager ces données et ajuster les protocoles.

Enfin, Claire Dubreuil rappelle l’enjeu de la formation continue : « Les soignants comme les enseignants gagnent à se réunir plusieurs fois par an. On y confronte des cas concrets, on présente des retours d’expérience. Cela consolide une culture commune du soin, indispensable à la longévité des chevaux de club. »`,
    imageUrl:
      'https://images.unsplash.com/photo-1526312426976-f4d754fa9bd6?auto=format&fit=crop&w=1200&q=80',
    author: 'Propos recueillis par la rédaction',
    interviewee: 'Claire Dubreuil',
    role: 'Vétérinaire équine',
    publishedDate: '2024-02-08',
    readTime: '12 min'
  },
  {
    id: 2,
    title:
      'Discussion avec Marc Le Gall, responsable pédagogique d’un poney-club breton',
    slug: 'discussion-marc-le-gall-pedagogie',
    category: 'centres-equestres-et-poney-clubs',
    excerpt:
      'Le responsable pédagogique détaille l’articulation entre ludique, apprentissage et sensibilisation à l’environnement.',
    content: `Marc Le Gall décrit un parcours pédagogique où l’enfant découvre le poney par étapes. « Les premières séances privilégient la relation à pied, la compréhension du langage corporel et la découverte de l’écurie. À partir de là, on introduit progressivement l’équilibre et les aides, toujours avec des ateliers courts. » L’équipe pédagogique s’appuie sur des supports visuels adaptés à chaque tranche d’âge.

L’entretien met en lumière l’importance du collectif : « Les parents participent régulièrement aux ateliers. Ils observent les séances, notent les points clés et peuvent ensuite consolider les gestes appris lorsque leurs enfants reviennent en stage. » Le club propose également des temps de dialogue sur la gestion des poneys et la protection de l’environnement.

Enfin, Marc Le Gall insiste sur la formation des encadrants : « Nous organisons des sessions internes où chacun présente des exercices, partage des retours de terrain et propose des améliorations. Cette dynamique maintient une cohérence pédagogique et renforce l’identité du club. »`,
    imageUrl:
      'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
    author: 'Propos recueillis par la rédaction',
    interviewee: 'Marc Le Gall',
    role: 'Responsable pédagogique',
    publishedDate: '2024-01-18',
    readTime: '10 min'
  },
  {
    id: 3,
    title:
      'Regards croisés avec Jeanne Roussel, historienne des sports équestres',
    slug: 'regards-jeanne-roussel-histoire',
    category: 'histoire-et-evolution',
    excerpt:
      'L’historienne explore les archives régionales et la transmission des mémoires au sein des clubs.',
    content: `Jeanne Roussel rappelle que les archives locales regorgent de documents sur la vie des clubs. « Les bulletins municipaux, les programmes de fêtes hippiques et les correspondances privées renseignent les étapes de structuration. Ils permettent aussi de retrouver les voix des cavaliers amateurs, souvent absentes des récits plus officiels. » Son travail consiste à croiser ces sources avec des témoignages oraux.

L’historienne met aussi en valeur le rôle des clubs dans l’urbanisme des communes. « Les manèges couverts, les tribunes, les pistes extérieures influencent la manière dont les habitants se représentent leur territoire. Étudier ces lieux éclaire les choix politiques et économiques d’une époque. » Les clubs actuels redécouvrent cette mémoire pour mieux raconter leur ancrage.

Pour Jeanne Roussel, la transmission passe par une médiation active : « Des ateliers d’archives ouvertes aux licenciés, des expositions temporaires dans les club-houses ou des podcasts locaux permettent de faire circuler l’histoire. Cela nourrit le sentiment d’appartenance et donne du sens à l’engagement bénévole. »`,
    imageUrl:
      'https://images.unsplash.com/photo-1474674556023-efef86d83050?auto=format&fit=crop&w=1200&q=80',
    author: 'Propos recueillis par la rédaction',
    interviewee: 'Jeanne Roussel',
    role: 'Historienne des sports',
    publishedDate: '2023-12-18',
    readTime: '11 min'
  },
  {
    id: 4,
    title:
      'Dialogue avec Idriss Ben Amar, coordinateur de programmes équestres inclusifs',
    slug: 'dialogue-idriss-ben-amar-inclusion',
    category: 'role-social-et-culturel',
    excerpt:
      'Le coordinateur expose les conditions nécessaires pour accueillir des publics diversifiés en toute sérénité.',
    content: `Idriss Ben Amar décrit une méthodologie en trois temps. « D’abord, rencontrer les structures partenaires et comprendre leurs attentes. Ensuite, préparer les équipes internes au club : sensibilisation aux spécificités du public, adaptation des installations, clarification des responsabilités. Enfin, mettre en place des bilans réguliers pour ajuster le dispositif. » Cette approche graduée sécurise l’ensemble des acteurs.

Il souligne l’importance d’un langage partagé. « Les professionnels du secteur social n’utilisent pas forcément les mêmes termes que les enseignants d’équitation. Nous construisons un glossaire commun pour éviter les malentendus et poser des repères. » Les clubs impliqués bénéficient également d’un réseau de pairs pour échanger sur les situations rencontrées.

Le coordinateur observe un impact durable sur la vie associative. « Les bénévoles découvrent de nouvelles facettes du cheval médiateur, les cavaliers confirmés prennent part aux ateliers de tutorat, et la gouvernance du club s’ouvre à des profils variés. L’équitation devient ainsi un levier de dialogue territorial. »`,
    imageUrl:
      'https://images.unsplash.com/photo-1542574289-41d310aa5b7b?auto=format&fit=crop&w=1200&q=80',
    author: 'Propos recueillis par la rédaction',
    interviewee: 'Idriss Ben Amar',
    role: 'Coordinateur de programmes sociaux',
    publishedDate: '2024-02-01',
    readTime: '9 min'
  }
];

export default interviews;
```