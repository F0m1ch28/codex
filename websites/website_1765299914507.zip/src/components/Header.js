```javascript
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navLinks = [
  { to: '/', label: 'Accueil' },
  { to: '/a-propos', label: 'À Propos' },
  { to: '/methodologie', label: 'Méthodologie' },
  { to: '/articles', label: 'Articles' },
  { to: '/categories', label: 'Catégories' },
  { to: '/interviews', label: 'Interviews' },
  { to: '/ressources', label: 'Ressources' },
  { to: '/contact', label: 'Contact' }
];

const Header = () => {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => {
    setOpen((prev) => !prev);
  };

  const closeMenu = () => {
    setOpen(false);
  };

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.logo} onClick={closeMenu}>
          French Equestrian Clubs Review
        </NavLink>
        <button
          type="button"
          className={styles.menuButton}
          onClick={toggleMenu}
          aria-label="Ouvrir le menu de navigation"
          aria-controls="primary-navigation"
          aria-expanded={open}
        >
          <span className={styles.menuIcon} />
          <span className={styles.menuIcon} />
          <span className={styles.menuIcon} />
        </button>
        <nav
          className={`${styles.nav} ${open ? styles.navOpen : ''}`}
          id="primary-navigation"
        >
          <ul className={styles.navList}>
            {navLinks.map((link) => (
              <li key={link.to} className={styles.navItem}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    isActive
                      ? `${styles.navLink} ${styles.active}`
                      : styles.navLink
                  }
                  onClick={closeMenu}
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
```