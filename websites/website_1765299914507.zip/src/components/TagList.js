```javascript
import React from 'react';
import styles from './TagList.module.css';

const TagList = ({ categories, selected, onSelect }) => (
  <div className={styles.tags} role="list">
    <button
      type="button"
      className={`${styles.tag} ${selected === 'all' ? styles.active : ''}`}
      onClick={() => onSelect('all')}
      aria-pressed={selected === 'all'}
    >
      Toutes
    </button>
    {categories.map((category) => (
      <button
        type="button"
        key={category.slug}
        className={`${styles.tag} ${
          selected === category.slug ? styles.active : ''
        }`}
        onClick={() => onSelect(category.slug)}
        aria-pressed={selected === category.slug}
      >
        {category.name}
      </button>
    ))}
  </div>
);

export default TagList;
```