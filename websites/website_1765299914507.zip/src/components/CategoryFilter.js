```javascript
import React from 'react';
import styles from './CategoryFilter.module.css';

const CategoryFilter = ({ categories, selected, onChange }) => (
  <div className={styles.wrapper}>
    <label htmlFor="category-select" className={styles.label}>
      Filtrer par catégorie
    </label>
    <select
      id="category-select"
      className={styles.select}
      value={selected}
      onChange={(event) => onChange(event.target.value)}
    >
      <option value="all">Toutes les catégories</option>
      {categories.map((category) => (
        <option key={category.slug} value={category.slug}>
          {category.name}
        </option>
      ))}
    </select>
  </div>
);

export default CategoryFilter;
```