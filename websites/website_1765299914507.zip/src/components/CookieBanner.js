```javascript
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const storedConsent = window.localStorage.getItem('fec-cookie-consent');
    if (!storedConsent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, []);

  const handleConsent = (value) => {
    window.localStorage.setItem('fec-cookie-consent', value);
    setVisible(false);
  };

  if (!visible) {
    return null;
  }

  return (
    <div className={styles.banner} role="dialog" aria-live="polite">
      <div className={styles.content}>
        <p className={styles.message}>
          Ce site utilise des cookies strictement nécessaires au bon
          fonctionnement statistique. Pour en savoir davantage, consulter la{' '}
          <Link to="/politique-cookies" className={styles.link}>
            politique des cookies
          </Link>
          .
        </p>
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.secondaryButton}
            onClick={() => handleConsent('refused')}
          >
            Refuser
          </button>
          <button
            type="button"
            className={styles.primaryButton}
            onClick={() => handleConsent('accepted')}
          >
            Accepter
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
```