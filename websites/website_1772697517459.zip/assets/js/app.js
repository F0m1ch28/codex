document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.querySelector(".primary-nav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNav.classList.toggle("open");
      navToggle.classList.toggle("open", isOpen);
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    primaryNav.addEventListener("click", (event) => {
      if (event.target.closest("a") && window.innerWidth < 768) {
        primaryNav.classList.remove("open");
        navToggle.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.setAttribute("role", "status");
  toast.setAttribute("aria-live", "polite");
  document.body.appendChild(toast);

  const showToast = (message) => {
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => {
      toast.classList.remove("is-visible");
    }, 2800);
  };

  document.addEventListener("click", (event) => {
    const button = event.target.closest("[data-action='add-to-cart']");
    if (!button) return;
    event.preventDefault();
    const productName = button.dataset.productName || "Товар";
    showToast(`${productName} добавлен в корзину`);
    button.classList.add("in-cart");
    setTimeout(() => button.classList.remove("in-cart"), 1200);
  });

  document.querySelectorAll("[data-filter-form]").forEach((form) => {
    const targetSelector = form.dataset.target;
    if (!targetSelector) return;
    const cards = Array.from(document.querySelectorAll(targetSelector));
    if (!cards.length) return;

    const countLabel = form.querySelector("[data-filter-count]");
    const selectKeys = Array.from(form.querySelectorAll("select")).map(
      (select) => select.name
    );

    const applyFilters = () => {
      const formData = new FormData(form);
      const searchTerm = (formData.get("search") || "")
        .toString()
        .trim()
        .toLowerCase();

      let visibleCount = 0;

      cards.forEach((card) => {
        let visible = true;

        if (searchTerm) {
          const name = (card.dataset.name || "").toLowerCase();
          const features = (card.dataset.features || "").toLowerCase();
          if (!name.includes(searchTerm) && !features.includes(searchTerm)) {
            visible = false;
          }
        }

        selectKeys.forEach((key) => {
          if (!visible) return;
          const value = formData.get(key);
          if (!value || value === "all") return;
          const cardValue = card.dataset[key];

          switch (key) {
            case "price": {
              const cardPrice = Number(card.dataset.price || 0);
              if (value === "lt60000" && !(cardPrice <= 60000)) visible = false;
              if (value === "lt80000" && !(cardPrice <= 80000)) visible = false;
              if (value === "lt100000" && !(cardPrice <= 100000))
                visible = false;
              if (value === "gt100000" && !(cardPrice >= 100000))
                visible = false;
              break;
            }
            case "compatibility": {
              if (!cardValue) {
                visible = false;
                break;
              }
              const matches = cardValue
                .split(",")
                .map((item) => item.trim().toLowerCase());
              if (!matches.includes(value.toLowerCase())) visible = false;
              break;
            }
            default: {
              if (!cardValue || cardValue.toLowerCase() !== value.toLowerCase())
                visible = false;
            }
          }
        });

        card.hidden = !visible;
        if (visible) visibleCount += 1;
      });

      if (countLabel) {
        countLabel.textContent = `Найдено: ${visibleCount}`;
      }
    };

    form.addEventListener("input", applyFilters);
    form.addEventListener("change", applyFilters);
    form.addEventListener("reset", () => setTimeout(applyFilters, 0));
    applyFilters();
  });

  const cookieBanner = document.querySelector("[data-cookie-banner]");
  if (cookieBanner) {
    const acceptButton = cookieBanner.querySelector("[data-cookie-accept]");
    const declineButton = cookieBanner.querySelector("[data-cookie-decline]");
    const storedConsent = localStorage.getItem("ma_cookie_consent");

    const hideBanner = () => {
      cookieBanner.classList.remove("is-visible");
      setTimeout(() => {
        cookieBanner.hidden = true;
      }, 280);
    };

    if (!storedConsent) {
      cookieBanner.hidden = false;
      requestAnimationFrame(() => {
        cookieBanner.classList.add("is-visible");
      });
    }

    acceptButton?.addEventListener("click", () => {
      localStorage.setItem("ma_cookie_consent", "accepted");
      hideBanner();
    });

    declineButton?.addEventListener("click", () => {
      localStorage.setItem("ma_cookie_consent", "declined");
      hideBanner();
    });
  }
});