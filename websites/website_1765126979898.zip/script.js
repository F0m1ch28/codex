document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      siteNav.classList.toggle('is-open');
    });

    siteNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        siteNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  if (cookieBanner) {
    const acceptBtn = cookieBanner.querySelector('[data-cookie="accept"]');
    const declineBtn = cookieBanner.querySelector('[data-cookie="decline"]');
    const consent = localStorage.getItem('cookieConsent');

    if (!consent) {
      requestAnimationFrame(() => cookieBanner.classList.add('is-visible'));
    }

    const closeBanner = decision => {
      localStorage.setItem('cookieConsent', decision);
      cookieBanner.classList.remove('is-visible');
    };

    acceptBtn?.addEventListener('click', () => closeBanner('accepted'));
    declineBtn?.addEventListener('click', () => closeBanner('declined'));
  }

  const animateElements = document.querySelectorAll('[data-animate]');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });

    animateElements.forEach(el => observer.observe(el));
  } else {
    animateElements.forEach(el => el.classList.add('is-visible'));
  }

  const filterButtons = document.querySelectorAll('[data-filter]');
  const portfolioItems = document.querySelectorAll('[data-category]');
  if (filterButtons.length && portfolioItems.length) {
    filterButtons.forEach(button => {
      button.addEventListener('click', () => {
        const target = button.dataset.filter;
        filterButtons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');

        portfolioItems.forEach(item => {
          const category = item.dataset.category?.split(',');
          if (!category) return;
          if (target === 'all' || category.includes(target)) {
            item.classList.remove('is-hidden');
          } else {
            item.classList.add('is-hidden');
          }
        });
      });
    });
  }

  const contactForm = document.querySelector('[data-form="contact"]');
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      const formData = new FormData(contactForm);
      const errors = [];

      const name = formData.get('name')?.toString().trim() ?? '';
      const email = formData.get('email')?.toString().trim() ?? '';
      const message = formData.get('message')?.toString().trim() ?? '';

      if (!name) errors.push('Введите имя.');
      if (!email) {
        errors.push('Введите email.');
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        errors.push('Email указан некорректно.');
      }
      if (!message || message.length < 12) {
        errors.push('Расскажите подробнее о проекте (минимум 12 символов).');
      }

      const feedback = contactForm.querySelector('.form-feedback');
      if (feedback) {
        if (errors.length) {
          feedback.textContent = errors.join(' ');
          feedback.classList.remove('is-success');
          feedback.classList.add('is-error');
        } else {
          feedback.textContent = 'Спасибо! Мы свяжемся с вами в течение рабочего дня.';
          feedback.classList.remove('is-error');
          feedback.classList.add('is-success');
          contactForm.reset();
        }
      }
    });
  }
});