import React from "react";

const STORAGE_KEY = "heliosphera-cookie-consent";

const CookieBanner = () => {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const consent = window.localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-x-4 bottom-4 z-[60] rounded-2xl border border-brand-amber/30 bg-brand-midnight/95 p-4 text-sm text-slate-200 shadow-xl backdrop-blur md:inset-x-auto md:left-1/2 md:w-full md:max-w-2xl md:-translate-x-1/2">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <p>
          Utilizamos cookies analíticas para comprender mejor el rendimiento y
          mejorar la experiencia solar. Puedes ampliar información en nuestra{" "}
          <a href="/politica-cookies" className="text-brand-amber underline">
            Política de cookies
          </a>
          .
        </p>
        <div className="flex shrink-0 gap-2">
          <button
            type="button"
            onClick={handleDecline}
            className="rounded-full border border-slate-500 px-4 py-2 text-xs font-semibold uppercase tracking-widest text-slate-200 transition hover:border-brand-amber hover:text-brand-amber"
          >
            Rechazar
          </button>
          <button
            type="button"
            onClick={handleAccept}
            className="rounded-full bg-gradient-to-r from-brand-amber to-brand-orange px-4 py-2 text-xs font-semibold uppercase tracking-widest text-brand-midnight shadow-md transition hover:shadow-lg"
          >
            Aceptar
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;