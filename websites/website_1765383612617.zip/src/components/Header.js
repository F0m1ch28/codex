import React from "react";
import { NavLink } from "react-router-dom";

const navLinks = [
  { to: "/", label: "Inicio" },
  { to: "/mision", label: "Misión" },
  { to: "/tecnologias-fotovoltaicas", label: "Tecnologías" },
  { to: "/modelado-predictivo", label: "Modelado" },
  { to: "/instalaciones-referencia", label: "Referencias" },
  { to: "/laboratorio-virtual", label: "Laboratorio" },
  { to: "/blog", label: "Blog" },
  { to: "/conecta", label: "Conecta" }
];

const Header = () => {
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      document.body.classList.add("overflow-hidden");
    } else {
      document.body.classList.remove("overflow-hidden");
    }
  }, [open]);

  return (
    <header className="sticky top-0 z-50 bg-brand-midnight/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-brand-amber via-brand-orange to-brand-amber text-brand-midnight shadow-glow">
            <span className="font-mono text-lg font-semibold">HS</span>
          </div>
          <div>
            <span className="block text-sm uppercase tracking-widest text-brand-amber">
              HelioSphera Ibérica
            </span>
            <span className="text-xs text-slate-200">
              Inteligencia Fotovoltaica para España
            </span>
          </div>
        </div>
        <nav className="hidden items-center gap-6 lg:flex">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `text-sm font-medium transition-colors duration-200 ${
                  isActive
                    ? "text-brand-amber"
                    : "text-slate-200 hover:text-brand-amber"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <button
          type="button"
          className="inline-flex items-center justify-center rounded-md border border-slate-700 p-2 text-slate-200 lg:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Abrir menú de navegación"
        >
          <span className="sr-only">Menú</span>
          <div className="flex h-5 w-5 flex-col justify-between">
            <span
              className={`h-0.5 w-full transform bg-current transition duration-200 ${
                open ? "translate-y-2 rotate-45" : ""
              }`}
            />
            <span
              className={`h-0.5 w-full bg-current transition duration-200 ${
                open ? "opacity-0" : ""
              }`}
            />
            <span
              className={`h-0.5 w-full transform bg-current transition duration-200 ${
                open ? "-translate-y-2 -rotate-45" : ""
              }`}
            />
          </div>
        </button>
      </div>
      <div
        className={`lg:hidden ${open ? "max-h-screen opacity-100" : "max-h-0 opacity-0"} overflow-hidden border-t border-slate-800 bg-brand-midnight transition-all duration-300`}
      >
        <nav className="space-y-2 px-6 py-4">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `block rounded-md px-3 py-2 text-sm font-medium transition ${
                  isActive
                    ? "bg-brand-amber/20 text-brand-amber"
                    : "text-slate-200 hover:bg-brand-amber/10 hover:text-brand-amber"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;