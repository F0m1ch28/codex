import React from "react";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-brand-midnight text-slate-200">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-brand-amber via-brand-orange to-brand-amber text-brand-midnight shadow-glow">
                <span className="font-mono text-xl font-semibold">HS</span>
              </div>
              <div>
                <p className="text-sm uppercase tracking-widest text-brand-amber">
                  HelioSphera Ibérica
                </p>
                <p className="text-xs text-slate-400">
                  Inteligencia solar para entornos mediterráneos.
                </p>
              </div>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-slate-400">
              Plataforma de innovación y análisis fotovoltaico para proyectos
              punteros en España. Integramos datos, ingeniería y visión de
              largo plazo para capturar cada fotón útil.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-brand-amber">
              Navegación
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <NavLink className="hover:text-brand-amber" to="/">
                  Inicio
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/mision">
                  Misión
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/tecnologias-fotovoltaicas">
                  Tecnologías
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/modelado-predictivo">
                  Modelado
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/blog">
                  Blog
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/conecta">
                  Conecta
                </NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-brand-amber">
              Recursos
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <NavLink className="hover:text-brand-amber" to="/laboratorio-virtual">
                  Laboratorio virtual
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/instalaciones-referencia">
                  Instalaciones referencia
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/condiciones">
                  Condiciones de uso
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/privacidad">
                  Privacidad
                </NavLink>
              </li>
              <li>
                <NavLink className="hover:text-brand-amber" to="/politica-cookies">
                  Política de cookies
                </NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-brand-amber">
              Contacto
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-400">
              <li>Paseo de la Castellana 259D, 28046 Madrid</li>
              <li>Tel: +34 912 45 67 89</li>
              <li>Email: info@heliosphera.com</li>
            </ul>
            <div className="mt-6 flex gap-4">
              <a
                href="https://www.linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="text-slate-400 transition hover:text-brand-amber"
                aria-label="LinkedIn"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 0h-14c-2.76 0-5 2.24-5 5v14c0 2.76 2.24 5 5 5h14c2.77 0 5-2.24 5-5v-14c0-2.76-2.23-5-5-5zm-11 19H5V9h3v10zM6.5 7.75c-.97 0-1.75-.79-1.75-1.75S5.53 4.25 6.5 4.25 8.25 5.04 8.25 6 7.47 7.75 6.5 7.75zm12.5 11.25h-3v-5.4c0-1.29-.03-2.95-1.8-2.95-1.8 0-2.07 1.4-2.07 2.85v5.5h-3V9h2.88v1.37h.04c.4-.76 1.38-1.56 2.84-1.56 3.04 0 3.6 2 3.6 4.59v5.6z" />
                </svg>
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="text-slate-400 transition hover:text-brand-amber"
                aria-label="Twitter"
              >
                <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.633 7.997c.013.18.013.36.013.54 0 5.507-4.194 11.855-11.855 11.855-2.36 0-4.554-.69-6.398-1.877.328.038.643.051.984.051 1.953 0 3.75-.664 5.19-1.79a4.162 4.162 0 01-3.887-2.883c.257.038.515.064.785.064.38 0 .76-.051 1.115-.141a4.156 4.156 0 01-3.333-4.08v-.051c.554.308 1.19.49 1.866.515a4.146 4.146 0 01-1.85-3.456c0-.76.205-1.47.564-2.084a11.795 11.795 0 008.555 4.343 4.694 4.694 0 01-.103-.95 4.151 4.151 0 017.185-2.835 8.18 8.18 0 002.632-1.003 4.137 4.137 0 01-1.826 2.29 8.305 8.305 0 002.38-.63 8.876 8.876 0 01-2.08 2.153z" />
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-slate-800 pt-6 text-center text-xs text-slate-500">
          © {new Date().getFullYear()} HelioSphera Ibérica. Arquitectura solar con visión mediterránea.
        </div>
      </div>
    </footer>
  );
};

export default Footer;