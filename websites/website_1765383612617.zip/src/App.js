import React from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";

import HomePage from "./pages/Home";
import MissionPage from "./pages/Mission";
import TechnologiesPage from "./pages/Technologies";
import ModelingPage from "./pages/Modeling";
import ReferencePage from "./pages/Reference";
import LabPage from "./pages/Lab";
import BlogPage from "./pages/Blog";
import ContactPage from "./pages/Contact";
import TermsPage from "./pages/Terms";
import PrivacyPage from "./pages/Privacy";
import CookiePolicyPage from "./pages/CookiePolicy";

const AppContent = () => {
  const location = useLocation();

  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen flex-col bg-brand-cream">
      <Header />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/mision" element={<MissionPage />} />
          <Route path="/tecnologias-fotovoltaicas" element={<TechnologiesPage />} />
          <Route path="/modelado-predictivo" element={<ModelingPage />} />
          <Route path="/instalaciones-referencia" element={<ReferencePage />} />
          <Route path="/laboratorio-virtual" element={<LabPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/conecta" element={<ContactPage />} />
          <Route path="/condiciones" element={<TermsPage />} />
          <Route path="/privacidad" element={<PrivacyPage />} />
          <Route path="/politica-cookies" element={<CookiePolicyPage />} />
        </Routes>
      </main>
      <Footer />
      <ScrollToTop />
      <CookieBanner />
    </div>
  );
};

const App = () => <AppContent />;

export default App;