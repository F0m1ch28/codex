import React from "react";

const TermsPage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-semibold text-brand-midnight">Condiciones de Uso</h1>
        <p className="mt-6 text-sm text-slate-700">
          Bienvenido a HelioSphera Ibérica. El acceso y uso de este sitio implican la
          aceptación de las presentes condiciones. Si no estás de acuerdo con alguno
          de los puntos, te invitamos a no utilizar la plataforma.
        </p>

        <section className="mt-8 space-y-6 text-sm text-slate-700">
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">1. Identificación</h2>
            <p className="mt-2">
              HelioSphera Ibérica, con sede en Paseo de la Castellana 259D, 28046 Madrid,
              es responsable del sitio web y de los contenidos técnicos publicados.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">2. Uso permitido</h2>
            <p className="mt-2">
              El contenido se ofrece con fines informativos y técnicos. Queda prohibido
              el uso contrario a la legislación vigente o con fines ilícitos. El usuario
              se compromete a no alterar ni manipular las herramientas publicadas.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">3. Propiedad intelectual</h2>
            <p className="mt-2">
              Los textos, gráficos, modelos y recursos son propiedad de HelioSphera Ibérica
              o de sus colaboradores autorizados. No se permite su reproducción total o
              parcial sin consentimiento por escrito.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">4. Responsabilidad</h2>
            <p className="mt-2">
              Los cálculos y simulaciones ofrecidos son estimaciones técnicas basadas en
              datos disponibles. HelioSphera Ibérica no se responsabiliza de decisiones
              adoptadas exclusivamente en función de la información mostrada en la web.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">5. Enlaces</h2>
            <p className="mt-2">
              Enlazamos a recursos externos de terceros. No controlamos ni avalamos su
              contenido. Cualquier enlace externo será retirado en caso de detectar
              irregularidades.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">6. Modificaciones</h2>
            <p className="mt-2">
              Nos reservamos el derecho de modificar estas condiciones sin aviso previo.
              Los cambios se publicarán en este apartado y serán efectivos desde su
              publicación.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">7. Legislación aplicable</h2>
            <p className="mt-2">
              Estas condiciones se rigen por la legislación española. Cualquier disputa
              se someterá a los juzgados de Madrid, salvo normativa imperativa en
              contrario.
            </p>
          </article>
        </section>
      </section>
    </div>
  );
};

export default TermsPage;