import React from "react";

const MetricsPanel = () => {
  const canvasRef = React.useRef(null);

  React.useEffect(() => {
    if (!canvasRef.current || !window.Chart) return;

    const metricsChart = new window.Chart(canvasRef.current.getContext("2d"), {
      type: "bar",
      data: {
        labels: ["PERC", "HJT", "Tándem", "Bifacial", "Microinversor", "String Inverter"],
        datasets: [
          {
            label: "Eficiencia media (%)",
            data: [22, 24, 29, 23, 96, 98],
            backgroundColor: [
              "#FDB813",
              "#F97316",
              "#1A1F2E",
              "#FDB813",
              "#F97316",
              "#1A1F2E"
            ]
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#1A1F2E",
            titleColor: "#FDB813",
            bodyColor: "#FEFCE8"
          }
        },
        scales: {
          x: {
            ticks: { color: "#1A1F2E" },
            grid: { display: false }
          },
          y: {
            beginAtZero: true,
            ticks: { color: "#1A1F2E" },
            grid: { color: "rgba(26,31,46,0.08)" }
          }
        }
      }
    });

    return () => metricsChart.destroy();
  }, []);

  return <canvas ref={canvasRef} aria-label="Panel de métricas de tecnologías fotovoltaicas" />;
};

const TechnologiesPage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-100">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1920&q=80"
            alt="Filas de paneles fotovoltaicos al atardecer"
            className="h-full w-full object-cover opacity-30"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/90 to-brand-midnight/60" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white sm:text-5xl">
            Innovaciones Fotovoltaicas
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-slate-200">
            Seguimos de cerca el avance en células, módulos, electrónica de potencia
            y operaciones para desplegar soluciones con el mejor desempeño en cada
            emplazamiento español.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-16 px-4 py-16 sm:px-6 lg:px-8">
        <article className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-brand-orange">Células HJT</span>
            <h2 className="mt-3 text-3xl font-semibold text-brand-midnight">
              Heterounión con control de pasivación
            </h2>
            <p className="mt-4 text-lg text-slate-700">
              Evaluamos celas HJT de diversas casas con foco en degradación LID/PID,
              tolerancia térmica y compatibilidad con interconexiones sin plomo. Los
              modelos incluyen degradación inicial y escenarios de estrés por temperatura.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Pasivación dual optimizada para clima mediterráneo.</li>
              <li>• Coeficiente térmico bajo en comparación con PERC estándar.</li>
              <li>• Mayor respuesta en espectro difuso, ideal para otoño-invierno.</li>
            </ul>
          </div>
          <div className="overflow-hidden rounded-3xl">
            <img
              src="https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=1200&q=80"
              alt="Detalle de células solares de heterounión"
              className="h-full w-full object-cover"
            />
          </div>
        </article>

        <article className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="order-2 lg:order-1 overflow-hidden rounded-3xl">
            <img
              src="https://images.unsplash.com/photo-1497436072909-60f360e1d4b1?auto=format&fit=crop&w=1200&q=80"
              alt="Módulos bifaciales captando luz en ambos lados"
              className="h-full w-full object-cover"
            />
          </div>
          <div className="order-1 lg:order-2">
            <span className="text-xs uppercase tracking-[0.3em] text-brand-orange">Módulos bifaciales</span>
            <h2 className="mt-3 text-3xl font-semibold text-brand-midnight">
              Bifacialidad adaptada al terreno español
            </h2>
            <p className="mt-4 text-lg text-slate-700">
              Analizamos la ganancia por albedo según tipo de suelo, uso de cubiertas
              blancas y altura del módulo. Monitorizamos plantas reales para recalibrar
              los modelos con datos de campo y ajustar la estrategia de seguimiento.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Comparativa por tipo de tracker y orientación.</li>
              <li>• Sensores de irradiancia trasera integrados al SCADA.</li>
              <li>• Algoritmos para decisiones de limpieza selectiva.</li>
            </ul>
          </div>
        </article>

        <article className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-brand-orange">Seguimiento astronómico</span>
            <h2 className="mt-3 text-3xl font-semibold text-brand-midnight">
              Sistemas de seguimiento con lógica adaptativa
            </h2>
            <p className="mt-4 text-lg text-slate-700">
              Desarrollamos controladores con reflexión meteorológica en tiempo real
              para activar modos safe-stow, mitigar sombras y aprovechar la radiación
              difusa. El modelo astronómico se ajusta a cada latitud con precisión
              sub-grado.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Integración con plataformas SCADA existentes.</li>
              <li>• Protocolos de viento y nieve con aprendizaje histórico.</li>
              <li>• Auditorías de consumo energético propio del tracker.</li>
            </ul>
          </div>
          <div className="overflow-hidden rounded-3xl">
            <img
              src="https://images.unsplash.com/photo-1509395062183-67c5ad6faff9?auto=format&fit=crop&w=1200&q=80"
              alt="Seguidores solares alineados con el sol"
              className="h-full w-full object-cover"
            />
          </div>
        </article>

        <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-2xl font-semibold text-brand-midnight">
            Panel de métricas tecnológicas
          </h2>
          <p className="mt-4 text-sm text-slate-700">
            Comparamos tecnologías clave según rendimiento, eficiencia eléctrica y
            compatibilidad con climas cálidos. La gráfica se actualiza con ensayos
            propios y publicaciones científicas recientes.
          </p>
          <div className="mt-8 h-96 rounded-2xl border border-slate-100 bg-white/80 p-4">
            <MetricsPanel />
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-3">
          {[
            {
              title: "Electrónica: Microinversores",
              description:
                "Seguimiento MPPT por módulo, reducción de pérdidas por mismatch y telemetría granular."
            },
            {
              title: "Electrónica: String inverters",
              description:
                "Eficiencia europea verificada, rendimiento en temperaturas extremas y vida útil de condensadores."
            },
            {
              title: "Operaciones: Robotización",
              description:
                "Planificación de limpieza automatizada, rutas en plantas flotantes y control remoto."
            },
            {
              title: "Termografía avanzada",
              description:
                "Uso de drones y cámaras multispectrales para detectar puntos calientes y posibles microfisuras."
            },
            {
              title: "Seguimiento híbrido",
              description:
                "Simulación de seguimiento horizontal con correcciones de inclinación adaptativas en función de irradiancia difusa."
            },
            {
              title: "Monitorización de sensores",
              description:
                "Validación de sensores albedo, piranómetros y estación meteorológica para asegurar datos consistentes."
            }
          ].map((item) => (
            <article
              key={item.title}
              className="rounded-2xl border border-brand-orange/30 bg-brand-orange/10 p-6 shadow-sm"
            >
              <h3 className="text-lg font-semibold text-brand-midnight">{item.title}</h3>
              <p className="mt-4 text-sm text-slate-700">{item.description}</p>
            </article>
          ))}
        </section>
      </section>
    </div>
  );
};

export default TechnologiesPage;