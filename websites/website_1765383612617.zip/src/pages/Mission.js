import React from "react";

const MissionPage = () => {
  return (
    <div className="bg-brand-cream text-brand-midnight">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-200">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1505731132164-cca90383e1af?auto=format&fit=crop&w=1920&q=80"
            alt="Ingeniera solar evaluando módulos bajo el sol al amanecer"
            className="h-full w-full object-cover opacity-25"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/90 to-brand-midnight/70" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white sm:text-5xl">
            Maximizando Cada Fotón
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-slate-200">
            Nuestra misión es transformar la irradiancia ibérica en energía limpia,
            fiable y trazable. Combinamos rigor científico, ingeniería aplicada y una
            red de expertos para que cada proyecto solar alcance su máximo potencial.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-semibold text-brand-midnight">Visión</h2>
            <p className="mt-4 text-lg text-slate-700">
              Convertir a España en referencia de excelencia fotovoltaica en clima
              mediterráneo, con activos resilientes y digitales desde su fase de
              diseño. Trabajamos para que las decisiones estén apoyadas en datos
              transparentes, ingeniería y experiencia operativa colaborativa.
            </p>
          </div>
          <div>
            <h2 className="text-3xl font-semibold text-brand-midnight">Metodología</h2>
            <ul className="mt-4 space-y-4 text-sm text-slate-700">
              <li>
                <span className="font-semibold text-brand-orange">1. Evaluación holística:</span>{" "}
                Recopilamos datos satelitales, estaciones locales y modelados CFD
                para detectar microclimas.
              </li>
              <li>
                <span className="font-semibold text-brand-orange">2. Modelado iterativo:</span>{" "}
                Ajustamos escenarios con Machine Learning y reglas físicas para
                encontrar configuraciones óptimas.
              </li>
              <li>
                <span className="font-semibold text-brand-orange">3. Implementación ágil:</span>{" "}
                Acompañamos a EPCs con checklists técnicos y protocolos de calidad en
                campo.
              </li>
              <li>
                <span className="font-semibold text-brand-orange">4. Monitorización continua:</span>{" "}
                Supervisamos mediante dashboards e informes de desviaciones para
                anticipar acciones correctivas.
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-20 grid gap-10 lg:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h3 className="text-xl font-semibold text-brand-midnight">Trayectoria</h3>
            <p className="mt-4 text-sm text-slate-700">
              HelioSphera Ibérica nació en 2014 como una célula de innovación dentro
              de un cluster renovable. En 2018 lanzamos el primer atlas de irradiancia
              con resolución de 1 km² para la península. Desde 2020 hemos integrado
              sensores IoT, drones y modelado térmico en la cartera de servicios.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• 2015: Primer gemelo digital de parque solar en Castilla-La Mancha.</li>
              <li>• 2019: Creación de la red de expertos HelioSphera Lab.</li>
              <li>• 2022: Incorporación de algoritmos de seguimiento inteligente.</li>
            </ul>
          </div>
          <div className="rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-8 shadow-sm">
            <h3 className="text-xl font-semibold text-brand-midnight">Red de colaboradores</h3>
            <p className="mt-4 text-sm text-slate-700">
              Trabajamos con universidades, centros tecnológicos y empresas de
              sensórica para contrastar metodologías y acelerar la adopción de
              innovaciones. Nuestra red abarca climatología, ciencia de datos,
              ingeniería de materiales y especialistas SCADA.
            </p>
            <dl className="mt-6 grid grid-cols-1 gap-4 text-sm text-slate-700 sm:grid-cols-2">
              <div>
                <dt className="text-xs uppercase tracking-[0.3em] text-brand-orange">
                  Centros tecnológicos
                </dt>
                <dd className="mt-1">CENER, IREC, CIRCE</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-[0.3em] text-brand-orange">
                  Universidades
                </dt>
                <dd className="mt-1">UPM, UPC, Universidad de Sevilla</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-[0.3em] text-brand-orange">
                  Especialistas
                </dt>
                <dd className="mt-1">Meteorología, Data Science, Termografía</dd>
              </div>
              <div>
                <dt className="text-xs uppercase tracking-[0.3em] text-brand-orange">
                  Cobertura
                </dt>
                <dd className="mt-1">Toda España y Baleares</dd>
              </div>
            </dl>
          </div>
        </div>

        <div className="mt-20 grid gap-12 lg:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h3 className="text-xl font-semibold text-brand-midnight">Equipo técnico</h3>
            <p className="mt-4 text-sm text-slate-700">
              Unimos perfiles multidisciplinares para asegurar una visión completa del
              ciclo de vida solar. Ingenieros eléctricos, especialistas en materiales,
              meteorólogos y analistas de datos colaboran de manera integrada.
            </p>
            <div className="mt-6 grid gap-6 sm:grid-cols-2">
              {[
                {
                  name: "Laura Esquivel",
                  role: "Directora técnica",
                  bio: "Experta en diseño de plantas utility scale y estándares IEC."
                },
                {
                  name: "Daniel Paredes",
                  role: "Jefe de modelado",
                  bio: "Simulaciones heliodón y gemelos digitales para seguimiento solar."
                },
                {
                  name: "Noelia Garrido",
                  role: "Especialista en materiales",
                  bio: "Estudios de degradación PID, LID y estabilidad UV."
                },
                {
                  name: "Julián Ortega",
                  role: "Data lead",
                  bio: "Arquitectura de datos SCADA y analítica avanzada en cloud."
                }
              ].map((member) => (
                <article key={member.name} className="rounded-2xl border border-slate-100 p-4">
                  <h4 className="font-semibold text-brand-midnight">{member.name}</h4>
                  <p className="text-xs uppercase tracking-[0.3em] text-brand-orange">
                    {member.role}
                  </p>
                  <p className="mt-3 text-sm text-slate-700">{member.bio}</p>
                </article>
              ))}
            </div>
          </div>
          <div className="rounded-3xl border border-brand-midnight/10 bg-white p-8 shadow-xl shadow-brand-amber/10">
            <h3 className="text-xl font-semibold text-brand-midnight">
              Circularidad y reciclaje de módulos
            </h3>
            <p className="mt-4 text-sm text-slate-700">
              Diseñamos proyectos considerando el retorno de materiales y la
              reciclabilidad desde el principio. Colaboramos con plantas de
              tratamiento para asegurar un cierre de ciclo eficaz.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Auditoría de proveedores de vidrio y silicio reciclado.</li>
              <li>• Planes de desmontaje y logística inversa documentados.</li>
              <li>• Indicadores de circularidad incorporados al cuadro de mando.</li>
            </ul>
            <div className="mt-8 rounded-2xl border border-brand-orange/40 bg-brand-orange/10 p-6">
              <p className="text-sm text-brand-midnight">
                Cada contrato incluye una hoja de ruta de regeneración de módulos
                conforme a los últimos requisitos europeos y a la estrategia española
                de economía circular.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default MissionPage;