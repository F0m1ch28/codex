import React from "react";

const IrradianceChart = () => {
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!ref.current || !window.Chart) return;

    const gradient = ref.current.getContext("2d").createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, "rgba(249,115,22,0.4)");
    gradient.addColorStop(1, "rgba(26,31,46,0.05)");

    const chart = new window.Chart(ref.current.getContext("2d"), {
      type: "line",
      data: {
        labels: Array.from({ length: 12 }).map((_, i) => `Mes ${i + 1}`),
        datasets: [
          {
            label: "Modelo HelioSphera",
            data: [105, 120, 160, 200, 235, 260, 270, 250, 220, 180, 150, 110],
            borderColor: "#F97316",
            backgroundColor: gradient,
            fill: true,
            tension: 0.35
          },
          {
            label: "Medición estación",
            data: [98, 118, 150, 190, 230, 255, 265, 240, 210, 175, 148, 100],
            borderColor: "#1A1F2E",
            tension: 0.35
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            labels: { color: "#1A1F2E" }
          },
          tooltip: {
            backgroundColor: "#1A1F2E",
            titleColor: "#FDB813",
            bodyColor: "#FEFCE8"
          }
        },
        scales: {
          x: {
            ticks: { color: "#1A1F2E" },
            grid: { display: false }
          },
          y: {
            beginAtZero: false,
            ticks: { color: "#1A1F2E" },
            grid: { color: "rgba(26,31,46,0.1)" }
          }
        }
      }
    });

    return () => chart.destroy();
  }, []);

  return <canvas ref={ref} aria-label="Modelos de irradiancia comparados" />;
};

const IvCurveChart = () => {
  const ref = React.useRef(null);

  React.useEffect(() => {
    if (!ref.current || !window.Chart) return;

    const chart = new window.Chart(ref.current.getContext("2d"), {
      type: "line",
      data: {
        labels: Array.from({ length: 21 }).map((_, i) => i * 2),
        datasets: [
          {
            label: "25°C",
            data: [12, 12, 12, 11.9, 11.5, 11.2, 10.5, 9.7, 8.6, 7.2, 6.0, 4.5, 3.1, 2.0, 1.1, 0.5, 0.2, 0, 0, 0, 0],
            borderColor: "#FDB813",
            tension: 0.35
          },
          {
            label: "45°C",
            data: [12, 12, 11.8, 11.3, 10.9, 10.3, 9.6, 8.5, 7.3, 6.0, 4.7, 3.4, 2.3, 1.4, 0.8, 0.4, 0.1, 0, 0, 0, 0],
            borderColor: "#F97316",
            tension: 0.35
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#1A1F2E" } },
          tooltip: {
            backgroundColor: "#1A1F2E",
            titleColor: "#FDB813",
            bodyColor: "#FEFCE8"
          }
        },
        scales: {
          x: {
            title: { display: true, text: "Voltaje (V)", color: "#1A1F2E" },
            ticks: { color: "#1A1F2E" },
            grid: { display: false }
          },
          y: {
            title: { display: true, text: "Corriente (A)", color: "#1A1F2E" },
            ticks: { color: "#1A1F2E" },
            grid: { color: "rgba(26,31,46,0.08)" }
          }
        }
      }
    });

    return () => chart.destroy();
  }, []);

  return <canvas ref={ref} aria-label="Curvas IV bajo diferentes temperaturas" />;
};

const ModelingPage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-200">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1920&q=80"
            alt="Simulación solar digital en pantalla"
            className="h-full w-full object-cover opacity-25"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/85 to-brand-midnight/60" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white sm:text-5xl">
            Simulación &amp; Predicción
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-slate-200">
            Modelamos irradiancia, sombras, rendimiento eléctrico y degradación para
            anticipar escenarios de operación. Nuestro enfoque combina modelos
            físicos, machine learning y validación in situ.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-16 px-4 py-16 sm:px-6 lg:px-8">
        <article className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">
              Modelos de irradiancia con validación cruzada
            </h2>
            <p className="mt-4 text-sm text-slate-700">
              Combinamos datos satelitales, estaciones físicas y reanálisis climáticos
              para generar proyecciones con resolución horaria. El modelo aprende de
              cada planta para ajustar coeficientes locales.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Correcciones topográficas y efectos de costa.</li>
              <li>• Análisis de variabilidad interanual y percentiles P50-P90.</li>
              <li>• Integración con plan de mantenimiento preventivo.</li>
            </ul>
          </div>
          <div className="h-80 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
            <IrradianceChart />
          </div>
        </article>

        <article className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="order-2 lg:order-1 overflow-hidden rounded-3xl">
            <img
              src="https://images.unsplash.com/photo-1509395062183-67c5ad6faff9?auto=format&fit=crop&w=1200&q=80"
              alt="Análisis de sombras en planta fotovoltaica"
              className="h-full w-full object-cover"
            />
          </div>
          <div className="order-1 lg:order-2 rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">
              Análisis de sombras y degradación
            </h2>
            <p className="mt-4 text-sm text-slate-700">
              Modelos 3D con precisión centimétrica detectan puntos de sombra en
              periodos críticos. A esto sumamos simulaciones de degradación LID/PID y
              efecto de suciedad para prever pérdidas.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Mapas de sombreado horario y decisiones de poda.</li>
              <li>• Integración de sensores soiling para ajustar la limpieza.</li>
              <li>• Escenarios de degradación proyectada a 25 años.</li>
            </ul>
          </div>
        </article>

        <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-2xl font-semibold text-brand-midnight">
            Biblioteca de casos de modelado
          </h2>
          <div className="mt-8 grid gap-8 md:grid-cols-2">
            {[
              {
                title: "Autoconsumo industrial en Zaragoza",
                summary:
                  "Modelado de sombras por maquinaria alta, ajuste fino de inclinación y seguimiento semiautomático."
              },
              {
                title: "Parque en Almería con trackers",
                summary:
                  "Simulación de irradiancia con polvos saharianos, decisión de instalación de sensores soiling."
              },
              {
                title: "Agrovoltaica en Lleida",
                summary:
                  "Equilibrio entre sombra agrícola y producción eléctrica, uso de seguimiento adaptado."
              },
              {
                title: "Instalación flotante en Sevilla",
                summary:
                  "Modelado CFD para estudiar evaporación y disipación térmica, impacto en eficiencia."
              }
            ].map((item) => (
              <article key={item.title} className="rounded-2xl border border-slate-100 p-6">
                <h3 className="text-lg font-semibold text-brand-midnight">{item.title}</h3>
                <p className="mt-3 text-sm text-slate-700">{item.summary}</p>
                <button
                  type="button"
                  className="mt-4 text-xs font-semibold uppercase tracking-[0.3em] text-brand-orange"
                >
                  Ver detalles →
                </button>
              </article>
            ))}
          </div>
        </section>

        <section className="grid gap-10 lg:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">Curvas IV adaptativas</h2>
            <p className="mt-4 text-sm text-slate-700">
              Estudiamos el impacto de la temperatura y la degradación en curvas IV.
              La modelización se integra con datos de campo para detectar deriva y
              anticipar mantenimiento correctivo.
            </p>
            <div className="mt-6 h-80 rounded-2xl border border-slate-100 bg-white/80 p-4">
              <IvCurveChart />
            </div>
          </div>
          <div className="rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">
              Optimización de ángulo y azimut
            </h2>
            <p className="mt-4 text-sm text-slate-700">
              Utilizamos algoritmos de optimización multiobjetivo para definir
              inclinación y azimut por mes, integrando datos de viento y suciedad.
              El resultado es una matriz de ajuste estacional con retorno medible.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Simulaciones horarias con datos reales de producción.</li>
              <li>• Integración con sistemas de seguimiento manual y automático.</li>
              <li>• Reportes de sensibilidad para justificar decisiones al consejo técnico.</li>
            </ul>
          </div>
        </section>
      </section>
    </div>
  );
};

export default ModelingPage;