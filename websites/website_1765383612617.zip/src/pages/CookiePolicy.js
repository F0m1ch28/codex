import React from "react";

const CookiePolicyPage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-semibold text-brand-midnight">Política de Cookies</h1>
        <p className="mt-6 text-sm text-slate-700">
          Esta política explica qué son las cookies, qué tipos empleamos y cómo puedes
          gestionarlas desde tu navegador.
        </p>

        <section className="mt-8 space-y-6 text-sm text-slate-700">
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">1. ¿Qué son?</h2>
            <p className="mt-2">
              Las cookies son pequeños archivos que se almacenan en tu dispositivo al
              navegar por nuestro sitio. Permiten recordar preferencias y analizar el
              uso de la web de forma agregada.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">2. Tipos de cookies usadas</h2>
            <ul className="mt-2 space-y-3">
              <li>
                <strong>Esenciales:</strong> necesarias para el funcionamiento básico
                del sitio (por ejemplo, recordar el consentimiento de cookies).
              </li>
              <li>
                <strong>Analíticas:</strong> nos ayudan a comprender qué contenidos
                generan más interés para mejorar la experiencia general.
              </li>
            </ul>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">3. Gestión</h2>
            <p className="mt-2">
              Puedes aceptar o rechazar las cookies analíticas desde el banner
              inicial. También puedes configurar tu navegador para eliminarlas o
              impedir su instalación. Consulta la ayuda de Chrome, Firefox, Safari u
              otros para instrucciones específicas.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">4. Cambios</h2>
            <p className="mt-2">
              Revisamos periódicamente el listado de cookies para mantenerlo
              actualizado. Cualquier modificación relevante será comunicada en esta
              página.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">5. Contacto</h2>
            <p className="mt-2">
              Para resolver dudas sobre esta política, escribe a info@heliosphera.com.
            </p>
          </article>
        </section>
      </section>
    </div>
  );
};

export default CookiePolicyPage;