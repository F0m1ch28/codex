import React from "react";

const useAnimatedCounter = (targetValue, duration = 2200) => {
  const [value, setValue] = React.useState(0);

  React.useEffect(() => {
    let start = null;
    const increment = (timestamp) => {
      if (!start) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      setValue(Math.floor(progress * targetValue));
      if (progress < 1) {
        requestAnimationFrame(increment);
      }
    };
    const raf = requestAnimationFrame(increment);
    return () => cancelAnimationFrame(raf);
  }, [targetValue, duration]);

  return value;
};

const SolarAtlasChart = () => {
  const canvasRef = React.useRef(null);

  React.useEffect(() => {
    if (!canvasRef.current || !window.Chart) return;

    const ctx = canvasRef.current.getContext("2d");
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, "rgba(253,184,19,0.4)");
    gradient.addColorStop(1, "rgba(26,31,46,0.05)");

    const atlasChart = new window.Chart(ctx, {
      type: "line",
      data: {
        labels: [
          "Galicia",
          "Cantabria",
          "País Vasco",
          "Navarra",
          "Cataluña",
          "Valencia",
          "Murcia",
          "Andalucía",
          "Extremadura",
          "Madrid",
          "Castilla-La Mancha",
          "Canarias"
        ],
        datasets: [
          {
            label: "Irradiancia media anual (kWh/m²)",
            data: [1450, 1500, 1550, 1600, 1750, 1900, 2050, 2150, 2000, 1850, 1950, 2250],
            fill: true,
            tension: 0.35,
            borderColor: "#FDB813",
            backgroundColor: gradient,
            pointBackgroundColor: "#F97316"
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true,
            labels: {
              color: "#1A1F2E",
              font: { family: "Manrope", size: 12 }
            }
          },
          tooltip: {
            backgroundColor: "#1A1F2E",
            titleColor: "#FDB813",
            bodyColor: "#FEFCE8",
            cornerRadius: 8
          }
        },
        scales: {
          x: {
            ticks: {
              color: "#1A1F2E"
            },
            grid: {
              display: false
            }
          },
          y: {
            beginAtZero: false,
            ticks: {
              color: "#1A1F2E"
            },
            grid: {
              color: "rgba(26,31,46,0.08)"
            }
          }
        }
      }
    });

    return () => atlasChart.destroy();
  }, []);

  return <canvas ref={canvasRef} aria-label="Atlas solar interactivo de irradiancia en España" />;
};

const TrackerComparisonChart = () => {
  const canvasRef = React.useRef(null);

  React.useEffect(() => {
    if (!canvasRef.current || !window.Chart) return;

    const ctx = canvasRef.current.getContext("2d");
    const comparisonChart = new window.Chart(ctx, {
      type: "radar",
      data: {
        labels: ["Producción anual", "Complejidad", "Mantenimiento", "Seguridad", "Integración SCADA"],
        datasets: [
          {
            label: "Seguidor 1 eje",
            data: [90, 60, 55, 70, 80],
            borderColor: "#FDB813",
            backgroundColor: "rgba(253,184,19,0.3)"
          },
          {
            label: "Seguidor 2 ejes",
            data: [96, 80, 70, 75, 85],
            borderColor: "#F97316",
            backgroundColor: "rgba(249,115,22,0.25)"
          },
          {
            label: "Fijo optimizado",
            data: [75, 40, 35, 90, 60],
            borderColor: "#1A1F2E",
            backgroundColor: "rgba(26,31,46,0.15)"
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          r: {
            angleLines: { color: "rgba(26,31,46,0.1)" },
            grid: { color: "rgba(26,31,46,0.1)" },
            pointLabels: {
              color: "#1A1F2E",
              font: { family: "Manrope", size: 12 }
            },
            ticks: {
              display: false
            }
          }
        },
        plugins: {
          legend: {
            labels: {
              color: "#1A1F2E"
            }
          }
        }
      }
    });

    return () => comparisonChart.destroy();
  }, []);

  return <canvas ref={canvasRef} aria-label="Comparativa de sistemas de seguimiento solar" />;
};

const HomePage = () => {
  const metrosInstalados = useAnimatedCounter(1200);
  const gigavatiosSimulados = useAnimatedCounter(8);
  const casosAnalizados = useAnimatedCounter(186);

  const [irradiancia, setIrradiancia] = React.useState(1950);
  const [superficie, setSuperficie] = React.useState(5000);
  const [eficiencia, setEficiencia] = React.useState(20);
  const [resultado, setResultado] = React.useState(null);

  const calcularProduccion = (event) => {
    event.preventDefault();
    const energia = (irradiancia * superficie * (eficiencia / 100)) / 1000;
    setResultado(energia.toFixed(1));
  };

  React.useEffect(() => {
    setResultado(((irradiancia * superficie * (eficiencia / 100)) / 1000).toFixed(1));
  }, []);

  return (
    <div className="bg-brand-cream text-brand-midnight">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-100">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=1920&q=80"
            alt="Campo fotovoltaico iluminado por el sol mediterráneo"
            className="h-full w-full object-cover opacity-30"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/80 via-brand-midnight/70 to-brand-midnight/95" />
        <div className="relative mx-auto flex max-w-7xl flex-col gap-10 px-4 py-24 sm:px-6 lg:flex-row lg:items-center lg:py-32 lg:px-8">
          <div className="w-full lg:w-3/5">
            <span className="inline-flex items-center rounded-full border border-brand-amber/40 bg-brand-amber/10 px-4 py-1 text-xs font-semibold uppercase tracking-[0.35em] text-brand-amber">
              Capturando el Sol Mediterráneo
            </span>
            <h1 className="mt-6 text-4xl font-semibold leading-tight text-white sm:text-5xl lg:text-6xl">
              Inteligencia fotovoltaica para maximizar cada fotón en España
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-slate-200">
              HelioSphera Ibérica combina modelado avanzado, sensórica y datos de campo
              para diseñar, monitorizar y optimizar instalaciones solares estratégicas
              en todo el territorio. Entregamos claridad técnica para decisiones de
              alta exigencia.
            </p>
            <div className="mt-10 flex flex-col gap-4 sm:flex-row">
              <a
                href="#atlas"
                className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-brand-amber via-brand-orange to-brand-amber px-8 py-3 text-sm font-semibold uppercase tracking-widest text-brand-midnight shadow-lg transition hover:shadow-xl"
              >
                Explorar atlas solar
              </a>
              <a
                href="/conecta"
                className="inline-flex items-center justify-center rounded-full border border-brand-amber/60 px-8 py-3 text-sm font-semibold uppercase tracking-widest text-brand-amber transition hover:border-brand-orange hover:text-brand-orange"
              >
                Coordinar diagnóstico
              </a>
            </div>
            <dl className="mt-12 grid grid-cols-1 gap-6 text-sm sm:grid-cols-3">
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur">
                <dt className="text-xs uppercase tracking-[0.35em] text-brand-amber">MW simulados</dt>
                <dd className="mt-3 text-3xl font-semibold text-white">{gigavatiosSimulados} GWp</dd>
              </div>
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur">
                <dt className="text-xs uppercase tracking-[0.35em] text-brand-amber">Casos auditados</dt>
                <dd className="mt-3 text-3xl font-semibold text-white">{casosAnalizados}</dd>
              </div>
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur">
                <dt className="text-xs uppercase tracking-[0.35em] text-brand-amber">Hectáreas monitorizadas</dt>
                <dd className="mt-3 text-3xl font-semibold text-white">{metrosInstalados} ha</dd>
              </div>
            </dl>
          </div>
          <div className="w-full rounded-3xl border border-white/10 bg-white/10 p-8 backdrop-blur lg:w-2/5">
            <h2 className="text-sm font-semibold uppercase tracking-[0.3em] text-brand-amber">
              Radar de decisiones solares
            </h2>
            <p className="mt-4 text-sm text-slate-200">
              Visualiza en segundos cómo varía la irradiancia y el rendimiento
              potencial a lo largo de España. Datos validados con históricos satelitales
              y estaciones de referencia.
            </p>
            <div className="mt-6 h-64 rounded-2xl bg-white/5 p-4">
              <SolarAtlasChart />
            </div>
          </div>
        </div>
      </section>

      <section id="atlas" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="text-3xl font-semibold text-brand-midnight">
              Atlas solar interactivo para decisiones regionales
            </h2>
            <p className="mt-4 text-lg text-slate-700">
              Integramos sensores, satélite y proyecciones meteorológicas para construir
              mapas dinámicos de irradiancia útil. La capa de datos se actualiza con
              históricos de 15 años y estimaciones a 10 días.
            </p>
            <ul className="mt-6 space-y-4 text-sm text-slate-700">
              <li className="flex items-start gap-3">
                <span className="mt-1 h-2.5 w-2.5 rounded-full bg-brand-orange" />
                <span>
                  Módulo de variabilidad horaria con visualización de picos y
                  valles por provincia.
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="mt-1 h-2.5 w-2.5 rounded-full bg-brand-orange" />
                <span>
                  Exportación de capas en GeoJSON y acceso API para SCADA propios.
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="mt-1 h-2.5 w-2.5 rounded-full bg-brand-orange" />
                <span>
                  Indicadores de calidad de dato con trazabilidad por estación y
                  recalibraciones realizadas.
                </span>
              </li>
            </ul>
          </div>
          <div className="rounded-3xl border border-brand-midnight/10 bg-white p-6 shadow-xl shadow-brand-amber/10">
            <h3 className="text-sm font-semibold uppercase tracking-[0.25em] text-brand-orange">
              Calculadora de rendimiento anual
            </h3>
            <p className="mt-3 text-sm text-slate-600">
              Ajusta irradiancia, superficie y eficiencia para obtener una estimación
              de producción anual. Pensado para estudiar oportunidades desde fase
              conceptual hasta operación.
            </p>
            <form className="mt-6 space-y-4" onSubmit={calcularProduccion}>
              <label className="block text-sm font-medium text-slate-700">
                Irradiancia (kWh/m²·año)
                <input
                  type="number"
                  required
                  value={irradiancia}
                  onChange={(event) => setIrradiancia(Number(event.target.value))}
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-brand-midnight shadow-sm focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                />
              </label>
              <label className="block text-sm font-medium text-slate-700">
                Superficie activa (m²)
                <input
                  type="number"
                  required
                  value={superficie}
                  onChange={(event) => setSuperficie(Number(event.target.value))}
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-brand-midnight shadow-sm focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                />
              </label>
              <label className="block text-sm font-medium text-slate-700">
                Eficiencia del sistema (%)
                <input
                  type="number"
                  required
                  value={eficiencia}
                  onChange={(event) => setEficiencia(Number(event.target.value))}
                  className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-brand-midnight shadow-sm focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                />
              </label>
              <button
                type="submit"
                className="w-full rounded-full bg-gradient-to-r from-brand-amber to-brand-orange px-6 py-3 text-sm font-semibold uppercase tracking-widest text-brand-midnight shadow-lg transition hover:shadow-xl"
              >
                Calcular producción
              </button>
            </form>
            {resultado && (
              <div className="mt-6 rounded-2xl border border-brand-amber/40 bg-brand-amber/10 p-5 text-center">
                <p className="text-xs uppercase tracking-[0.35em] text-brand-orange">
                  Estimación anual
                </p>
                <p className="mt-3 text-3xl font-semibold text-brand-midnight">
                  {resultado} MWh
                </p>
                <p className="mt-2 text-xs text-slate-500">
                  Proyección bajo condiciones estándar y disponibilidad del 98%.
                </p>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-3xl font-semibold text-brand-midnight">
                Galería de tecnologías fotovoltaicas en exploración continua
              </h2>
              <p className="mt-4 text-lg text-slate-700">
                Actualizamos semanalmente nuestra matriz comparativa de células y
                componentes relevantes: PERC, heterounión, tándem con perovskitas,
                módulos bifaciales, microinversores y soluciones de limpieza
                robotizada.
              </p>
            </div>
            <div className="rounded-full border border-brand-orange/40 bg-brand-orange/10 px-6 py-3 text-sm uppercase tracking-[0.35em] text-brand-orange">
              Pipeline de I+D+i activo
            </div>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: "Células HJT con láminas TCO optimizadas",
                description:
                  "Integramos modelos de degradación LID/PID específicos y monitorizamos la homogeneidad de capa para reducir pérdidas eléctricas."
              },
              {
                title: "Configuraciones tándem",
                description:
                  "Análisis de apilamiento perovskita-cristalino y estudio de estabilidad térmica en zonas de alta irradiancia mediterránea."
              },
              {
                title: "Módulos bifaciales",
                description:
                  "Métricas comparadas con y sin seguimiento solar, optimizando altura y ancho para maximizar ganancias de albedo."
              },
              {
                title: "Seguidores astronómicos",
                description:
                  "Algoritmos de seguimiento con corrección por viento y modos safe-stow integrados en sistemas SCADA existentes."
              },
              {
                title: "Microinversores y string inverters",
                description:
                  "Simulaciones de parte-load, rendimiento a 45°C y curvas de eficiencia europea para definir arquitectura."
              },
              {
                title: "Operaciones robotizadas",
                description:
                  "Planificación de limpieza automática y termografía con drones para detectar anomalías de forma precoz."
              }
            ].map((item) => (
              <article
                key={item.title}
                className="group relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-2 hover:shadow-xl"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-brand-amber/0 via-brand-orange/0 to-brand-amber/10 opacity-0 transition group-hover:opacity-100" />
                <h3 className="text-lg font-semibold text-brand-midnight">{item.title}</h3>
                <p className="mt-4 text-sm text-slate-600">{item.description}</p>
                <div className="mt-6 text-xs font-semibold uppercase tracking-[0.3em] text-brand-orange">
                  Actualizado
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-start">
          <div className="rounded-3xl border border-brand-midnight/10 bg-white p-6 shadow-xl shadow-brand-amber/10">
            <h3 className="text-sm font-semibold uppercase tracking-[0.25em] text-brand-orange">
              Comparativa de sistemas de seguimiento
            </h3>
            <p className="mt-3 text-sm text-slate-600">
              Evaluamos producción, complejidad, estrategias de mantenimiento y nivel
              de integración digital entre sistemas fijos y seguidores. La matriz se
              actualiza con feedback operativo en parques existentes.
            </p>
            <div className="mt-6 h-80 rounded-2xl bg-white/80 p-4">
              <TrackerComparisonChart />
            </div>
          </div>
          <div className="space-y-6">
            <article className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex items-center gap-4">
                <img
                  src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=700&q=80"
                  alt="Equipo de ingenieros analizando datos solares en pantallas"
                  className="h-24 w-24 rounded-2xl object-cover"
                />
                <div>
                  <h3 className="text-lg font-semibold text-brand-midnight">
                    Casos reales analizados
                  </h3>
                  <p className="text-sm text-slate-600">
                    Aprendizajes en parques utility scale, autoconsumo industrial y
                    soluciones flotantes en el litoral.
                  </p>
                </div>
              </div>
              <ul className="mt-6 space-y-3 text-sm text-slate-600">
                <li>• Parque dual en Córdoba con bifacialidad del 77% medida.</li>
                <li>• Autoproducción textil en Terrassa con microinversores.</li>
                <li>• Plataforma flotante en embalse de Alqueva con sensores IoT.</li>
              </ul>
            </article>
            <article className="rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-brand-midnight">
                Únete a la bitácora fotovoltaica
              </h3>
              <p className="mt-4 text-sm text-slate-700">
                Recibe análisis técnicos mensuales: degradación en clima mediterráneo,
                nuevas normativas y tendencias en almacenamiento híbrido.
              </p>
              <form className="mt-6 flex flex-col gap-3 sm:flex-row">
                <label className="sr-only" htmlFor="newsletter-email">
                  Correo electrónico
                </label>
                <input
                  id="newsletter-email"
                  type="email"
                  required
                  placeholder="tu@correo.com"
                  className="w-full rounded-full border border-brand-orange/40 bg-white px-4 py-3 text-sm text-brand-midnight focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                />
                <button
                  type="submit"
                  className="inline-flex items-center justify-center rounded-full bg-brand-amber px-6 py-3 text-xs font-semibold uppercase tracking-[0.3em] text-brand-midnight transition hover:bg-brand-orange"
                >
                  Suscribirse
                </button>
              </form>
              <p className="mt-2 text-xs text-slate-500">
                Compartimos solo insights y datos prácticos. Puedes cancelar en cualquier momento.
              </p>
            </article>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;