import React from "react";

const ReferencePage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-200">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1489515217757-5fd1be406fef?auto=format&fit=crop&w=1920&q=80"
            alt="Gran planta solar vista desde el aire"
            className="h-full w-full object-cover opacity-20"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/85 to-brand-midnight/70" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white sm:text-5xl">
            Proyectos Fotovoltaicos
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-slate-200">
            Selección de instalaciones en las que hemos aportado modelado, auditoría y
            optimización. Desde parques utility scale hasta soluciones flotantes,
            industriales y agrovoltaicas.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-16 px-4 py-16 sm:px-6 lg:px-8">
        <section className="grid gap-10 lg:grid-cols-2">
          <article className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">Soluciones en campo abierto</h2>
            <p className="mt-4 text-sm text-slate-700">
              Parques solares de gran escala en Andalucía, Extremadura y Castilla-La
              Mancha. Intervenimos en análisis de irradiancia, definición de layout,
              seguimiento y ajuste de curvas IV.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Parque de 220 MWp en Córdoba con módulos bifaciales.</li>
              <li>• Instalación de 180 MWp en Badajoz con trackers 2 ejes.</li>
              <li>• Gemelo digital de planta en Guadalajara para EPC internacional.</li>
            </ul>
          </article>
          <article className="rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">Plantas flotantes</h2>
            <p className="mt-4 text-sm text-slate-700">
              Estudios hidrodinámicos, selección de equipos anti-corrosión y modelado
              de anclajes para plataformas solares en embalses de Andalucía y Castilla
              y León.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Instalación flotante de 12 MWp con análisis CFD.</li>
              <li>• Sensores para seguimiento de inclinación y torsión.</li>
              <li>• Plan de mantenimiento predictivo basado en vibraciones.</li>
            </ul>
          </article>
        </section>

        <section className="grid gap-10 lg:grid-cols-2">
          <article className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">Autoconsumo industrial</h2>
            <p className="mt-4 text-sm text-slate-700">
              Auditorías técnicas y diseño para centros logísticos, industria química
              y textil. Especial foco en integración con procesos térmicos y gestión
              energética global.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• 3 MWp en nave textil con microinversores en Terrassa.</li>
              <li>• Integración con almacenamiento térmico en planta química de Huelva.</li>
              <li>• Monitorización avanzada en fábrica automotriz de Navarra.</li>
            </ul>
          </article>
          <article className="rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">Agrovoltaica y comunidades energéticas</h2>
            <p className="mt-4 text-sm text-slate-700">
              Diseño de cubiertas fotovoltaicas ligeras, integración con cultivos y
              plataformas de datos para comunidades rurales.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• Agrovoltaica en Lleida con seguimiento adaptativo.</li>
              <li>• Comunidad energética en Burgos con balance compartido.</li>
              <li>• Monitorización agronómica y meteorológica en Murcia.</li>
            </ul>
          </article>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-2xl font-semibold text-brand-midnight">Mapa interactivo</h2>
          <p className="mt-4 text-sm text-slate-700">
            Visualiza la huella de HelioSphera Ibérica en todo el país. Cada punto
            incluye detalles de la instalación, tecnología y servicios prestados.
          </p>
          <div className="mt-6 overflow-hidden rounded-3xl border border-slate-200 shadow-md">
            <iframe
              title="Mapa de instalaciones de HelioSphera Ibérica"
              src="https://www.google.com/maps/d/embed?mid=1GGMP8PT5mVumZ1nKptipLTIs-fU-RcA&ehbc=2E312F"
              className="h-96 w-full"
              loading="lazy"
            />
          </div>
        </section>

        <section className="rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-8 shadow-sm">
          <h2 className="text-2xl font-semibold text-brand-midnight">Datos de producción destacados</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2">
            {[
              {
                label: "Factor de rendimiento medio",
                value: "83%",
                detail: "Parques utility scale auditados en 2023."
              },
              {
                label: "Horas solares útiles",
                value: "1.950 h",
                detail: "Media ponderada en instalaciones en la península."
              },
              {
                label: "Reducción de pérdidas por soiling",
                value: "-5.2%",
                detail: "Gracias a planes de limpieza robotizada y sensores."
              },
              {
                label: "Disponibilidad reportada",
                value: "98.6%",
                detail: "Tras implementación de mantenimiento predictivo."
              }
            ].map((item) => (
              <article key={item.label} className="rounded-2xl border border-brand-orange/40 bg-white/60 p-6">
                <p className="text-xs uppercase tracking-[0.3em] text-brand-orange">
                  {item.label}
                </p>
                <p className="mt-4 text-3xl font-semibold text-brand-midnight">{item.value}</p>
                <p className="mt-2 text-sm text-slate-700">{item.detail}</p>
              </article>
            ))}
          </div>
        </section>
      </section>
    </div>
  );
};

export default ReferencePage;