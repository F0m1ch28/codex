import React from "react";

const posts = [
  {
    title: "Pervoskitas en tándem: estabilidad bajo sol mediterráneo",
    summary:
      "Analizamos pruebas de estabilidad térmica y radiación UV en perovskitas unidas a silicio, con resultados prometedores tras 2.000 horas de ensayo.",
    image: "https://images.unsplash.com/photo-1497436072909-60f360e1d4b1?auto=format&fit=crop&w=1200&q=80",
    category: "innovación"
  },
  {
    title: "O&M crítico: sensores de soiling y algoritmos de limpieza",
    summary:
      "Comparativa de sensores de suciedad y estrategias de limpieza predictiva en zonas áridas del sureste español.",
    image: "https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=1200&q=80",
    category: "operación"
  },
  {
    title: "Novedades normativas para autoconsumo industrial en 2024",
    summary:
      "Resumen práctico de los cambios regulatorios y cómo impactan en la tramitación de proyectos de autoconsumo.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80",
    category: "normativa"
  },
  {
    title: "Agrovoltaica: balance hídrico y producción eléctrica",
    summary:
      "Estudio conjunto con universidades sobre optimización de sombra en cultivos y efecto en la producción solar.",
    image: "https://images.unsplash.com/photo-1509395062183-67c5ad6faff9?auto=format&fit=crop&w=1200&q=80",
    category: "agrovoltaica"
  }
];

const BlogPage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-200">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=1920&q=80"
            alt="Detalle de panel solar en laboratorio"
            className="h-full w-full object-cover opacity-25"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/85 to-brand-midnight/70" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white sm:text-5xl">
            Perspectivas Solares
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-slate-200">
            Informes técnicos, novedades en materiales y operación fotovoltaica en
            España, con foco en datos concretos y aplicaciones reales.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2">
          {posts.map((post) => (
            <article key={post.title} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
              <div className="h-56">
                <img
                  src={post.image}
                  alt={post.title}
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="p-6">
                <span className="text-xs uppercase tracking-[0.3em] text-brand-orange">
                  {post.category}
                </span>
                <h2 className="mt-3 text-2xl font-semibold text-brand-midnight">
                  {post.title}
                </h2>
                <p className="mt-4 text-sm text-slate-700">{post.summary}</p>
                <button
                  type="button"
                  className="mt-5 text-xs font-semibold uppercase tracking-[0.3em] text-brand-orange"
                >
                  Leer artículo →
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default BlogPage;