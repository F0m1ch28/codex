import React from "react";

const LabPage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-200">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1920&q=80"
            alt="Laboratorio tecnológico con pantallas y datos"
            className="h-full w-full object-cover opacity-20"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/85 to-brand-midnight/70" />
        <div className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white sm:text-5xl">
            Recursos de Ingeniería
          </h1>
          <p className="mt-6 max-w-3xl text-lg text-slate-200">
            El laboratorio virtual de HelioSphera condensa herramientas, estándares,
            datasets y conocimientos para acelerar proyectos fotovoltaicos de alta
            exigencia.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl space-y-16 px-4 py-16 sm:px-6 lg:px-8">
        <section className="grid gap-10 lg:grid-cols-2">
          <article className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">Calculadoras técnicas</h2>
            <ul className="mt-6 space-y-4 text-sm text-slate-700">
              <li>• Dimensionado de strings con límites de tensión y corriente.</li>
              <li>• Cálculo de pérdidas por temperatura con coeficientes reales.</li>
              <li>• Estimator de mismatch y degradación anual esperada.</li>
            </ul>
          </article>
          <article className="rounded-3xl border border-brand-orange/30 bg-brand-orange/10 p-8 shadow-sm">
            <h2 className="text-2xl font-semibold text-brand-midnight">Estándares IEC / UL</h2>
            <p className="mt-4 text-sm text-slate-700">
              Resumen actualizado de normas relevantes, requisitos de ensayo y checklists
              para aseguramiento de calidad en recepción de módulos, inversores y trackers.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              <li>• IEC 61215, 61730, 62109 explicadas con ejemplos prácticos.</li>
              <li>• Documentación UL 1741 para integración con almacenamiento.</li>
              <li>• Protocolos de verificación en campo y aceptación de lotes.</li>
            </ul>
          </article>
        </section>

        <section className="grid gap-10 lg:grid-cols-3">
          {[
            {
              title: "Webinars",
              description:
                "Sesiones mensuales sobre modelado predictivo, novedades regulatorias y operación avanzada."
            },
            {
              title: "Datasets abiertos",
              description:
                "Colecciones de irradiancia, producción y climatología para entrenar modelos propios."
            },
            {
              title: "Comparador de módulos",
              description:
                "Ficha técnica interactiva con parámetros eléctricos y de degradación recogidos de laboratorios."
            },
            {
              title: "Glosario técnico",
              description:
                "Definiciones claras de conceptos técnicos en fotovoltaica, redes, electrónica y data."
            },
            {
              title: "Casos de uso",
              description:
                "Documentos detallando aprendizajes y KPI de proyectos con seguimiento HelioSphera."
            },
            {
              title: "Guías rápidas",
              description:
                "Documentos descargables con checklists para etapas clave: EPC, O&M y auditorías."
            }
          ].map((item) => (
            <article
              key={item.title}
              className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
            >
              <h3 className="text-lg font-semibold text-brand-midnight">{item.title}</h3>
              <p className="mt-3 text-sm text-slate-700">{item.description}</p>
              <button
                type="button"
                className="mt-4 text-xs font-semibold uppercase tracking-[0.3em] text-brand-orange"
              >
                Acceder →
              </button>
            </article>
          ))}
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-2xl font-semibold text-brand-midnight">Sneak peek de próximos recursos</h2>
          <div className="mt-6 grid gap-8 md:grid-cols-2">
            <article className="rounded-2xl border border-brand-orange/30 bg-brand-orange/10 p-6">
              <h3 className="text-lg font-semibold text-brand-midnight">
                Gemelos digitales de O&M
              </h3>
              <p className="mt-3 text-sm text-slate-700">
                Estamos integrando datos SCADA, termografía y reportes técnicos en un
                gemelo digital con alarmas inteligentes.
              </p>
            </article>
            <article className="rounded-2xl border border-brand-orange/30 bg-brand-orange/10 p-6">
              <h3 className="text-lg font-semibold text-brand-midnight">
                API de irradiancia horaria
              </h3>
              <p className="mt-3 text-sm text-slate-700">
                Próximo lanzamiento de API con históricos y predicciones, pensada para
                integrarse en plataformas propietarias.
              </p>
            </article>
          </div>
        </section>
      </section>
    </div>
  );
};

export default LabPage;