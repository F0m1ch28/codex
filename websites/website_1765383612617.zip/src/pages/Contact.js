import React from "react";

const ContactPage = () => {
  const [formData, setFormData] = React.useState({
    name: "",
    email: "",
    phone: "",
    message: "",
    sector: "utility"
  });
  const [feedback, setFeedback] = React.useState(null);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((previous) => ({ ...previous, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setFeedback({
        type: "error",
        text: "Por favor, completa los campos obligatorios."
      });
      return;
    }
    setFeedback({
      type: "success",
      text: "Gracias por contactar. Responderemos en menos de 48 horas."
    });
    setFormData({
      name: "",
      email: "",
      phone: "",
      message: "",
      sector: "utility"
    });
  };

  return (
    <div className="bg-brand-cream">
      <section className="relative overflow-hidden bg-brand-midnight text-slate-200">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1452796658657-57e4464d94c5?auto=format&fit=crop&w=1920&q=80"
            alt="Vista aérea de Madrid con luz solar"
            className="h-full w-full object-cover opacity-25"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-brand-midnight/85 to-brand-midnight/70" />
        <div className="relative mx-auto max-w-5xl px-4 py-24 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-semibold text-white sm:text-5xl">Conecta con HelioSphera</h1>
          <p className="mt-6 max-w-3xl text-lg text-slate-200">
            Hablemos sobre tus retos solares. Diseñamos sesiones de diagnóstico a
            medida para parques utility, autoconsumo industrial, agrovoltaica o
            comunidades energéticas.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl -translate-y-16 px-4 pb-12 sm:px-6 lg:px-8">
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-xl shadow-brand-amber/10">
          <div className="grid gap-10 lg:grid-cols-2">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="text-sm font-medium text-slate-700">
                  Nombre
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    required
                    onChange={handleChange}
                    className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-brand-midnight focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                  />
                </label>
                <label className="text-sm font-medium text-slate-700">
                  Email
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    required
                    onChange={handleChange}
                    className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-brand-midnight focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                  />
                </label>
              </div>
              <label className="text-sm font-medium text-slate-700">
                Teléfono
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-brand-midnight focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                />
              </label>
              <label className="text-sm font-medium text-slate-700">
                Sector
                <select
                  name="sector"
                  value={formData.sector}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-brand-midnight focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                >
                  <option value="utility">Utility scale</option>
                  <option value="industrial">Industrial</option>
                  <option value="agrovoltaica">Agrovoltaica</option>
                  <option value="comunidad">Comunidad energética</option>
                  <option value="otros">Otros</option>
                </select>
              </label>
              <label className="text-sm font-medium text-slate-700">
                Mensaje
                <textarea
                  name="message"
                  value={formData.message}
                  required
                  rows={6}
                  onChange={handleChange}
                  className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-brand-midnight focus:border-brand-orange focus:outline-none focus:ring-2 focus:ring-brand-orange/30"
                />
              </label>
              <button
                type="submit"
                className="w-full rounded-full bg-gradient-to-r from-brand-amber to-brand-orange px-6 py-3 text-sm font-semibold uppercase tracking-[0.3em] text-brand-midnight shadow-lg transition hover:shadow-xl"
              >
                Enviar consulta
              </button>
              {feedback && (
                <p
                  className={`text-sm ${
                    feedback.type === "success" ? "text-brand-blue" : "text-red-600"
                  }`}
                >
                  {feedback.text}
                </p>
              )}
            </form>

            <div className="space-y-6">
              <div className="rounded-2xl border border-brand-orange/30 bg-brand-orange/10 p-6">
                <h2 className="text-lg font-semibold text-brand-midnight">Oficina Madrid</h2>
                <p className="mt-3 text-sm text-slate-700">
                  Paseo de la Castellana 259D, 28046 Madrid
                </p>
                <p className="mt-2 text-sm text-slate-700">Teléfono: +34 912 45 67 89</p>
                <p className="mt-2 text-sm text-slate-700">Email: info@heliosphera.com</p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-6">
                <h2 className="text-lg font-semibold text-brand-midnight">Agenda una sesión</h2>
                <p className="mt-3 text-sm text-slate-700">
                  Coordinamos sesiones de análisis técnico, revisión de layout o
                  auditoría de performance en menos de una semana.
                </p>
                <ul className="mt-4 space-y-2 text-sm text-slate-700">
                  <li>• Diagnóstico inicial en remoto.</li>
                  <li>• Taller de modelado predictivo.</li>
                  <li>• Auditoría de EPC u O&amp;M.</li>
                </ul>
              </div>
              <div className="overflow-hidden rounded-2xl border border-slate-200 shadow-md">
                <iframe
                  title="Ubicación HelioSphera Ibérica"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3037.6710894944034!2d-3.690084123389477!3d40.476100571418225!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd422f6d0c6f9d01%3A0x9d25958d36f02d19!2sPaseo%20de%20la%20Castellana%2C%20259D%2C%2028046%20Madrid!5e0!3m2!1ses!2ses!4v1691511112000!5m2!1ses!2ses"
                  className="h-64 w-full"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;