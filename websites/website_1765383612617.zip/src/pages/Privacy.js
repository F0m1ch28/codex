import React from "react";

const PrivacyPage = () => {
  return (
    <div className="bg-brand-cream">
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-semibold text-brand-midnight">Política de Privacidad</h1>
        <p className="mt-6 text-sm text-slate-700">
          En HelioSphera Ibérica tratamos los datos personales con transparencia y
          respeto. Esta política describe cómo recogemos, utilizamos y protegemos la
          información de quienes interactúan con nosotros.
        </p>

        <section className="mt-8 space-y-6 text-sm text-slate-700">
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">1. Responsable</h2>
            <p className="mt-2">
              HelioSphera Ibérica, Paseo de la Castellana 259D, 28046 Madrid. Email de
              contacto: info@heliosphera.com.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">2. Datos recopilados</h2>
            <p className="mt-2">
              Recopilamos nombre, correo electrónico, teléfono y sector profesional a
              través de formularios de contacto o suscripción. También utilizamos cookies
              analíticas para mejorar la experiencia de navegación.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">3. Finalidad</h2>
            <p className="mt-2">
              Los datos se emplean para responder consultas, enviar comunicaciones
              técnicas y gestionar la relación con nuestros visitantes. No se elaboran
              perfiles automatizados con efectos significativos para el usuario.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">4. Legitimación</h2>
            <p className="mt-2">
              El tratamiento se basa en el consentimiento del usuario y en el interés
              legítimo de proporcionar información técnica relevante a profesionales
              del sector fotovoltaico.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">5. Cesiones</h2>
            <p className="mt-2">
              No cedemos datos personales a terceros, salvo obligación legal o cuando
              sea necesario para prestar el servicio solicitado (por ejemplo, proveedores
              tecnológicos con contratos de confidencialidad).
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">6. Derechos</h2>
            <p className="mt-2">
              Puedes ejercer los derechos de acceso, rectificación, supresión,
              oposición, limitación y portabilidad enviando un correo a
              info@heliosphera.com. Responderemos en un plazo máximo de 30 días.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">7. Conservación</h2>
            <p className="mt-2">
              Los datos se conservan mientras exista relación con el usuario o durante
              el tiempo necesario para responder a las consultas. Una vez cumplido el
              plazo, se eliminarán o anonimizarán.
            </p>
          </article>
          <article>
            <h2 className="text-lg font-semibold text-brand-midnight">8. Seguridad</h2>
            <p className="mt-2">
              Aplicamos medidas técnicas y organizativas para proteger la información,
              incluyendo cifrado de comunicaciones (HTTPS) y controles de acceso.
            </p>
          </article>
        </section>
      </section>
    </div>
  );
};

export default PrivacyPage;