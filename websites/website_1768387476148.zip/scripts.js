const navToggles = document.querySelectorAll('.menu-toggle');
navToggles.forEach((toggle) => {
    const navList = toggle.parentElement.querySelector('.nav-list');
    toggle.addEventListener('click', () => {
        const isOpen = navList.classList.toggle('is-open');
        toggle.setAttribute('aria-expanded', String(isOpen));
    });
});

function hideCookieBanners() {
    document.querySelectorAll('[data-cookie-banner]').forEach((banner) => {
        banner.classList.add('is-hidden');
    });
}

(function manageCookieConsent() {
    const consent = localStorage.getItem('ric_cookie_consent');
    if (consent === 'accepted' || consent === 'declined') {
        hideCookieBanners();
        return;
    }
    document.querySelectorAll('[data-cookie-accept]').forEach((button) => {
        button.addEventListener('click', () => {
            localStorage.setItem('ric_cookie_consent', 'accepted');
            hideCookieBanners();
        });
    });
    document.querySelectorAll('[data-cookie-decline]').forEach((button) => {
        button.addEventListener('click', () => {
            localStorage.setItem('ric_cookie_consent', 'declined');
            hideCookieBanners();
        });
    });
})();

function validateEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function showFormError(form, message) {
    let alert = form.querySelector('.alert-error');
    if (!alert) {
        alert = document.createElement('div');
        alert.className = 'alert alert-error';
        form.insertBefore(alert, form.firstChild);
    }
    alert.textContent = message;
}

function clearFormError(form) {
    const alert = form.querySelector('.alert-error');
    if (alert) {
        alert.remove();
    }
}

function appendSuccessMessage(form, message) {
    let alert = form.querySelector('.alert-success');
    if (!alert) {
        alert = document.createElement('div');
        alert.className = 'alert alert-success';
        form.insertBefore(alert, form.firstChild);
    }
    alert.textContent = message;
}

function setUpFormValidation(selector, additionalCheck = () => true) {
    const form = document.querySelector(selector);
    if (!form) {
        return;
    }
    form.addEventListener('submit', (event) => {
        if (form.dataset.submitted === 'true') {
            return;
        }
        event.preventDefault();
        clearFormError(form);

        let isValid = true;
        form.querySelectorAll('[required]').forEach((field) => {
            if (!field.value.trim()) {
                isValid = false;
            }
            if (field.type === 'email' && !validateEmail(field.value.trim())) {
                isValid = false;
            }
        });

        if (!additionalCheck(form)) {
            isValid = false;
        }

        if (!isValid) {
            showFormError(form, 'Vă rugăm să completați corect toate câmpurile obligatorii.');
            return;
        }

        appendSuccessMessage(form, 'Datele au fost validate. Redirecționăm către pagina de confirmare...');
        form.dataset.submitted = 'true';
        setTimeout(() => {
            form.submit();
        }, 500);
    });
}

setUpFormValidation('[data-subscribe-form]');
setUpFormValidation('[data-briefing-form]');
setUpFormValidation('#contact-form');

const searchInput = document.getElementById('article-search');
const filterButtons = document.querySelectorAll('[data-filter]');
const articlesList = document.getElementById('articles-list');

function filterArticles() {
    if (!articlesList) {
        return;
    }
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const activeFilterButton = document.querySelector('[data-filter].is-active');
    const activeFilter = activeFilterButton ? activeFilterButton.getAttribute('data-filter') : 'toate';

    articlesList.querySelectorAll('.article-card').forEach((card) => {
        const categories = card.getAttribute('data-category') || '';
        const title = card.getAttribute('data-title') || '';
        const author = card.getAttribute('data-author') || '';
        const matchesQuery = !query || title.toLowerCase().includes(query) || author.toLowerCase().includes(query) || categories.toLowerCase().includes(query);
        const matchesFilter = activeFilter === 'toate' || categories.split(' ').includes(activeFilter);
        if (matchesQuery && matchesFilter) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}

if (searchInput && articlesList) {
    searchInput.addEventListener('input', () => {
        filterArticles();
    });
}

filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
        filterButtons.forEach((btn) => btn.classList.remove('is-active'));
        button.classList.add('is-active');
        filterArticles();
    });
});

filterArticles();