document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            navToggle.setAttribute('aria-expanded', navLinks.classList.contains('active'));
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                navToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    const cookieBanner = document.getElementById('cookieBanner');
    const acceptBtn = document.getElementById('cookieAccept');
    const declineBtn = document.getElementById('cookieDecline');

    if (cookieBanner && acceptBtn && declineBtn) {
        const cookieChoice = localStorage.getItem('energyTrackCookieConsent');

        if (!cookieChoice) {
            setTimeout(() => cookieBanner.classList.add('active'), 1200);
        }

        const handleChoice = (choice) => {
            localStorage.setItem('energyTrackCookieConsent', choice);
            cookieBanner.classList.remove('active');
        };

        acceptBtn.addEventListener('click', () => handleChoice('accepted'));
        declineBtn.addEventListener('click', () => handleChoice('declined'));
    }
});