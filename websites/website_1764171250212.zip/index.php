<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Energy Track | Real-Time Energy Monitoring & Predictive Analytics</title>
    <meta name="description" content="Energy Track provides real-time energy monitoring, AI-driven predictive maintenance, and digital twin simulations for the Canadian energy sector.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
</head>
<body>
<header class="site-header">
    <div class="container inner">
        <a class="branding" href="index.php">
            <span class="brand-mark">ET</span>
            <span>Energy Track</span>
        </a>
        <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
        <nav>
            <ul class="nav-links">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="solutions.html">Solutions</a></li>
                <li><a href="technology.html">Technology</a></li>
                <li><a href="case-studies.html">Case Studies</a></li>
                <li><a href="news.html">News</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="contact.php" class="btn btn-primary" style="color:#fff;">Contact</a></li>
            </ul>
        </nav>
    </div>
</header>

<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>Precision Energy Intelligence for High-Stakes Operations</h1>
            <p>Energy Track delivers real-time monitoring, AI-enabled predictive maintenance, and digital twin simulations designed for complex energy infrastructure across the Canadian market.</p>
            <div class="hero-cta">
                <a class="btn btn-primary" href="solutions.html">Explore Solutions</a>
                <a class="btn btn-secondary" href="contact.php">Schedule a Strategy Call</a>
            </div>
            <ul class="list-inline" style="margin-top:32px;">
                <li>Continuous pipeline oversight</li>
                <li>Cross-facility emissions visibility</li>
                <li>ML-driven asset reliability</li>
            </ul>
        </div>
        <div class="hero-stats">
            <div class="stat-card">
                <h3>99.1% uptime</h3>
                <p>Field-proven reliability across pipeline sensor networks.</p>
            </div>
            <div class="stat-card">
                <h3>28% faster</h3>
                <p>Corrective actions initiated using predictive alerts and diagnostics.</p>
            </div>
            <div class="stat-card">
                <h3>45% lower</h3>
                <p>Fugitive emissions using continuous monitoring dashboards.</p>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-header">
            <span class="section-headline">Real-Time Energy Monitoring</span>
            <h2 class="section-title">Visibility into Every Critical Asset</h2>
            <p class="section-description">Energy Track connects pipeline, processing, and downstream facilities into a unified intelligence layer. Operators interpret live KPIs, performance anomalies, and compliance status within a single analytical environment.</p>
        </div>
        <div class="grid grid-3">
            <div class="card">
                <span class="tag">Integrated Operations Center</span>
                <h3>Unified Control Dashboards</h3>
                <p>Live telemetry feeds capture pressure, temperature, vibration, and flow metrics for rapid cross-site diagnostics.</p>
                <ul>
                    <li>Adaptive alert thresholds based on asset criticality</li>
                    <li>Digital signage-ready visualizations for OCC environments</li>
                    <li>Data lineage tracking for regulatory validation</li>
                </ul>
            </div>
            <div class="card">
                <span class="tag">Field Intelligence</span>
                <h3>IoT Sensor Fusion</h3>
                <p>High-frequency sensors deliver multi-layered data coverage across pipelines, compressor stations, and pump systems.</p>
                <ul>
                    <li>LoRaWAN and LTE failover connectivity</li>
                    <li>Edge analytics for remote assets</li>
                    <li>Automated calibration diagnostics</li>
                </ul>
            </div>
            <div class="card">
                <span class="tag">Decision Support</span>
                <h3>Operational Workflows</h3>
                <p>Role-based dashboards prioritize the most material risks, ensuring shift teams execute data-backed interventions.</p>
                <ul>
                    <li>Work order activation via CMMS integrations</li>
                    <li>Automated compliance report creation</li>
                    <li>Built-in audit trail with timestamped actions</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background:var(--light-gray);">
    <div class="container">
        <div class="section-header">
            <span class="section-headline">AI Predictive Maintenance</span>
            <h2 class="section-title">Machine Learning That Anticipates Infrastructure Stress</h2>
            <p class="section-description">Advanced predictive models digest telemetry, weather, and historical maintenance records to diagnose anomalies before they impact production or safety.</p>
        </div>
        <div class="grid grid-2">
            <div class="card">
                <img src="https://picsum.photos/seed/predict/720/480" alt="Technicians collaborating with AI maintenance dashboard" loading="lazy">
                <h3>Failure Probability Forecasting</h3>
                <p>Scenario-based modelling quantifies probability of failure for compressors, pump sets, and rotating machinery, specifying the time window for intervention.</p>
                <ul class="check-list">
                    <li>Gradient boosted models with explainable outputs</li>
                    <li>Maintenance prioritization heat maps</li>
                    <li>Prescriptive recommendations with cost impact</li>
                </ul>
            </div>
            <div class="card">
                <h3>Risk-Based Maintenance Roadmaps</h3>
                <p>Energy Track converts insights into structured actions, aligning maintenance planners, field crews, and leadership teams under a single digital thread.</p>
                <div class="process">
                    <div class="process-step">
                        <div class="step-number">01</div>
                        <div>
                            <h4>Data Harmonization</h4>
                            <p>Integrates historian, ERP, and maintenance records, cleansing datasets for modelling accuracy.</p>
                        </div>
                    </div>
                    <div class="process-step">
                        <div class="step-number">02</div>
                        <div>
                            <h4>Predictive Insights</h4>
                            <p>Continuous ML retraining adapts to operating conditions, enabling real-time risk scores.</p>
                        </div>
                    </div>
                    <div class="process-step">
                        <div class="step-number">03</div>
                        <div>
                            <h4>Execution & Validation</h4>
                            <p>Closed-loop workflows capture actual maintenance outcomes to reinforce model precision.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-header">
            <span class="section-headline">Digital Twin Simulations</span>
            <h2 class="section-title">Simulate Complex Energy Scenarios with Confidence</h2>
            <p class="section-description">Energy Track crafts high-fidelity digital twins mirroring field assets, enabling operators to stress-test capacity, evaluate contingency plans, and monitor performance in silico.</p>
        </div>
        <div class="grid grid-3">
            <div class="card">
                <span class="tag">Facility Twins</span>
                <h3>Processing Facilities</h3>
                <p>Virtual replicas of processing trains assess throughput optimization, energy intensity, and potential downtime risks.</p>
                <blockquote>“Digital twins provide forecasting clarity and improved orchestration between operations and maintenance.”</blockquote>
            </div>
            <div class="card">
                <span class="tag">Pipeline Network Twins</span>
                <h3>Pipeline Systems</h3>
                <p>Dynamic hydraulic models evaluate pressure drops, integrity risk, and emergency response procedures across the network.</p>
                <ul class="check-list">
                    <li>Simulated leak detection and response timing</li>
                    <li>Capacity planning for peak flow windows</li>
                    <li>Cross-border compliance scenario testing</li>
                </ul>
            </div>
            <div class="card">
                <span class="tag">Scenario Lab</span>
                <h3>AI-Assisted Simulation</h3>
                <p>Predict loss events, optimize energy efficiency pathways, and quantify capital allocation alternatives based on simulated outcomes.</p>
                <div class="metrics-grid">
                    <div class="metric-card">
                        <h4>35%</h4>
                        <span>Reduction in unplanned downtime with proactive modelling.</span>
                    </div>
                    <div class="metric-card">
                        <h4>$4.2M</h4>
                        <span>Average annual savings realized from digital twin validation.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background:var(--white);">
    <div class="container">
        <div class="section-header">
            <span class="section-headline">Emissions Tracking & Reporting</span>
            <h2 class="section-title">Transparent Emissions Dashboards with Regulatory Alignment</h2>
            <p class="section-description">Energy Track equips asset teams with automated emissions inventory tracking to satisfy federal and provincial reporting frameworks while reducing carbon intensity.</p>
        </div>
        <div class="grid grid-2">
            <div class="card">
                <img src="https://picsum.photos/seed/emissions/720/480" alt="Emissions dashboard visualized on a modern display" loading="lazy">
                <h3>Continuous Emissions Monitoring</h3>
                <p>Automated measurement, reporting, and verification workflows produce auditable data sets with built-in quality controls.</p>
                <ul class="check-list">
                    <li>GHG equivalency modelling across Scope 1 and Scope 2</li>
                    <li>Leak detection correlation with drone and satellite feeds</li>
                    <li>Automated export to federal and provincial reporting formats</li>
                </ul>
            </div>
            <div class="card">
                <h3>Decarbonization Insights</h3>
                <p>Energy Track integrates emissions KPIs into financial and operational dashboards, ensuring leadership teams quantify decarbonization ROI.</p>
                <div class="stat-strip">
                    <div class="stat-item">
                        <h4>18%</h4>
                        <span>GHG reduction potential from optimization scenarios.</span>
                    </div>
                    <div class="stat-item">
                        <h4>4 hrs</h4>
                        <span>Time required to generate compliant monthly submissions.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background: var(--gradient-accent);">
    <div class="container">
        <div class="section-header">
            <span class="section-headline">Regional Case Studies</span>
            <h2 class="section-title">Operational Impact Across Alberta and Saskatchewan</h2>
            <p class="section-description">Energy Track partners with upstream, midstream, and downstream operators to drive measurable performance improvements across Western Canada.</p>
        </div>
        <div class="grid grid-2">
            <div class="card">
                <img src="https://picsum.photos/seed/alberta/720/480" alt="Pipeline operations in Alberta" loading="lazy">
                <span class="tag">Alberta</span>
                <h3>Oil Sands Energy Optimization</h3>
                <p>Integrated process data with predictive maintenance to increase throughput reliability by 12% while reducing energy intensity per barrel.</p>
                <ul class="check-list">
                    <li>Hybrid digital twin evaluating cogeneration assets</li>
                    <li>30% reduction in emergency maintenance incidents</li>
                    <li>Regulatory compliance improved with automated reporting</li>
                </ul>
            </div>
            <div class="card">
                <img src="https://picsum.photos/seed/saskatchewan/720/480" alt="Energy field in Saskatchewan" loading="lazy">
                <span class="tag">Saskatchewan</span>
                <h3>Gas Gathering Network Reliability</h3>
                <p>Compressor stations instrumented with IoT sensors to detect early-stage vibration anomalies, preventing costly equipment failures.</p>
                <ul class="check-list">
                    <li>Mean time between failures increased by 26%</li>
                    <li>Fugitive methane tracked with 24/7 monitoring</li>
                    <li>Dispatch efficiency improved via automated ticketing</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-header">
            <span class="section-headline">Expert Insights</span>
            <h2 class="section-title">Strategic Guidance from Energy Track Analysts</h2>
            <p class="section-description">Energy Track analysts synthesize data science, operational excellence, and regulatory expertise to support strategic decision making for energy executives.</p>
        </div>
        <div class="grid grid-3">
            <div class="card">
                <span class="tag">White Paper</span>
                <h3>Risk-Adjusted Asset Planning</h3>
                <p>Leverage predictive analytics to align capital planning with asset criticality, ensuring budgets reflect dynamic risk profiles.</p>
                <a class="btn btn-outline" href="news.html">Read Analysis</a>
            </div>
            <div class="card">
                <span class="tag">Webinar</span>
                <h3>Digital Twin Roadmap 2026</h3>
                <p>Energy Track shares its maturity model for digital twin deployment, including governance structures and data quality benchmarks.</p>
                <a class="btn btn-outline" href="technology.html">View Technology</a>
            </div>
            <div class="card">
                <span class="tag">Advisor Q&A</span>
                <h3>Emissions Policy Preparedness</h3>
                <p>Our regulatory specialists discuss forthcoming methane intensity standards and how operators can stay compliant.</p>
                <a class="btn btn-outline" href="news.html">Explore Updates</a>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background: var(--white);">
    <div class="container">
        <div class="newsletter">
            <div>
                <span class="section-headline">Newsletter</span>
                <h2 class="section-title">Stay Current with Energy Intelligence Briefings</h2>
                <p class="section-description">Receive curated insights on predictive maintenance, emissions compliance, and digital operations transformation. Energy Track briefs deliver the signals that matter.</p>
            </div>
            <form action="thanks.php" method="post">
                <label class="visually-hidden" for="newsletter-email">Newsletter Email</label>
                <input type="email" id="newsletter-email" name="email" placeholder="Enter your business email" required>
                <button class="btn btn-primary" type="submit">Subscribe</button>
            </form>
            <p style="font-size:14px; color:rgba(47,58,69,0.65);">By subscribing, you agree to the <a href="terms.html">Terms</a> and <a href="privacy.html">Privacy Policy</a>.</p>
        </div>
    </div>
</section>

<footer class="site-footer">
    <div class="container">
        <div class="footer-top">
            <div class="footer-brand">
                <h3>Energy Track</h3>
                <p>Energy Track empowers energy operators with precision monitoring, predictive analytics, and actionable intelligence from field to boardroom.</p>
                <div class="badge-list">
                    <span class="badge">24/7 Support</span>
                    <span class="badge">Canadian Market Focus</span>
                    <span class="badge">Data Assurance</span>
                </div>
            </div>
            <div class="footer-nav">
                <strong>Navigation</strong>
                <a href="index.php">Home</a>
                <a href="solutions.html">Solutions</a>
                <a href="technology.html">Technology</a>
                <a href="case-studies.html">Case Studies</a>
                <a href="news.html">News</a>
            </div>
            <div class="footer-legal">
                <strong>Policies</strong>
                <a href="privacy.html">Privacy Policy</a>
                <a href="terms.html">Terms & Conditions</a>
                <a href="faq.html">FAQ</a>
                <a href="contact.php">Contact</a>
                <a href="404.html">404 Page</a>
            </div>
            <div class="footer-contact">
                <strong>Contact</strong>
                <p>Email: insight@energytrack.ca</p>
                <p>Phone: +1 (604) 555-0186</p>
                <p>Address: 885 W Georgia St, Vancouver, BC</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© <?php echo date('Y'); ?> Energy Track. All rights reserved.</p>
        </div>
    </div>
</footer>

<div class="cookie-banner" id="cookieBanner">
    <h3>Cookie Preferences</h3>
    <p>Energy Track uses cookies to enhance performance analytics and remember user preferences. Manage your consent below.</p>
    <div class="cookie-actions">
        <button class="btn btn-primary" id="cookieAccept" type="button">Accept All</button>
        <button class="btn btn-outline" id="cookieDecline" type="button">Decline</button>
    </div>
    <p style="margin-top:12px; font-size:13px; color:rgba(47,58,69,0.6);">Review our <a href="privacy.html">Privacy Policy</a> for more details.</p>
</div>
</body>
</html>