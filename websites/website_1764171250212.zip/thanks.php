<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You | Energy Track</title>
    <meta name="description" content="Thank you for connecting with Energy Track. We will respond to your inquiry shortly.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
</head>
<body>
<header class="site-header">
    <div class="container inner">
        <a class="branding" href="index.php">
            <span class="brand-mark">ET</span>
            <span>Energy Track</span>
        </a>
        <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
        <nav>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="solutions.html">Solutions</a></li>
                <li><a href="technology.html">Technology</a></li>
                <li><a href="case-studies.html">Case Studies</a></li>
                <li><a href="news.html">News</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="contact.php" class="btn btn-primary" style="color:#fff;">Contact</a></li>
            </ul>
        </nav>
    </div>
</header>

<section class="section">
    <div class="container">
        <div class="card" style="text-align:center;">
            <h1 style="color:var(--navy);">Thank You</h1>
            <p>Your submission has been received. An Energy Track representative will reach out shortly.</p>
            <a class="btn btn-primary" href="index.php">Return to Homepage</a>
        </div>
    </div>
</section>

<footer class="site-footer">
    <div class="container">
        <div class="footer-top">
            <div class="footer-brand">
                <h3>Energy Track</h3>
                <p>Energy Track empowers energy operators with precision monitoring, predictive analytics, and actionable intelligence from field to boardroom.</p>
                <div class="badge-list">
                    <span class="badge">24/7 Support</span>
                    <span class="badge">Canadian Market Focus</span>
                    <span class="badge">Data Assurance</span>
                </div>
            </div>
            <div class="footer-nav">
                <strong>Navigation</strong>
                <a href="index.php">Home</a>
                <a href="solutions.html">Solutions</a>
                <a href="technology.html">Technology</a>
                <a href="case-studies.html">Case Studies</a>
                <a href="news.html">News</a>
            </div>
            <div class="footer-legal">
                <strong>Policies</strong>
                <a href="privacy.html">Privacy Policy</a>
                <a href="terms.html">Terms & Conditions</a>
                <a href="faq.html">FAQ</a>
                <a href="contact.php">Contact</a>
                <a href="404.html">404 Page</a>
            </div>
            <div class="footer-contact">
                <strong>Contact</strong>
                <p>Email: insight@energytrack.ca</p>
                <p>Phone: +1 (604) 555-0186</p>
                <p>Address: 885 W Georgia St, Vancouver, BC</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© <?php echo date('Y'); ?> Energy Track. All rights reserved.</p>
        </div>
    </div>
</footer>

<div class="cookie-banner" id="cookieBanner">
    <h3>Cookie Preferences</h3>
    <p>Energy Track uses cookies to enhance performance analytics and remember user preferences. Manage your consent below.</p>
    <div class="cookie-actions">
        <button class="btn btn-primary" id="cookieAccept" type="button">Accept All</button>
        <button class="btn btn-outline" id="cookieDecline" type="button">Decline</button>
    </div>
    <p style="margin-top:12px; font-size:13px; color:rgba(47,58,69,0.6);">Review our <a href="privacy.html">Privacy Policy</a> for more details.</p>
</div>
</body>
</html>