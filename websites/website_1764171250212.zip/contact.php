<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Energy Track | Vancouver Office</title>
    <meta name="description" content="Contact Energy Track’s Vancouver office. Submit inquiries via the contact form or connect by phone to discuss energy monitoring and predictive analytics solutions.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script defer src="script.js"></script>
</head>
<body>
<header class="site-header">
    <div class="container inner">
        <a class="branding" href="index.php">
            <span class="brand-mark">ET</span>
            <span>Energy Track</span>
        </a>
        <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
        <nav>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="solutions.html">Solutions</a></li>
                <li><a href="technology.html">Technology</a></li>
                <li><a href="case-studies.html">Case Studies</a></li>
                <li><a href="news.html">News</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="contact.php" class="active btn btn-primary" style="color:#fff;">Contact</a></li>
            </ul>
        </nav>
    </div>
</header>

<section class="hero-minor">
    <div class="container hero-align-left">
        <h1>Connect with Energy Track</h1>
        <p>Discuss your monitoring, predictive maintenance, and emissions strategies with our Vancouver-based team.</p>
        <div class="breadcrumb">Home • Contact</div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="contact-card">
            <div class="contact-info">
                <h2>Vancouver Office</h2>
                <p>885 W Georgia St, Suite 1200<br>Vancouver, BC V6C 3E8</p>
                <p><strong>Phone:</strong> +1 (604) 555-0186</p>
                <p><strong>Email:</strong> insight@energytrack.ca</p>
                <p>Monday – Friday, 8:00 AM – 6:00 PM PT</p>
                <div class="badge-list">
                    <span class="badge">Client Support</span>
                    <span class="badge">Project Inquiries</span>
                    <span class="badge">Media Contact</span>
                </div>
            </div>
            <div class="contact-form">
                <h2>Request a Consultation</h2>
                <form action="thanks.php" method="post">
                    <div class="form-row">
                        <div>
                            <label for="name">Full Name</label>
                            <input id="name" type="text" name="name" required placeholder="Jane Smith">
                        </div>
                        <div>
                            <label for="company">Company</label>
                            <input id="company" type="text" name="company" required placeholder="EnergyCo Ltd.">
                        </div>
                    </div>
                    <div class="form-row">
                        <div>
                            <label for="email">Email</label>
                            <input id="email" type="email" name="email" required placeholder="name@company.com">
                        </div>
                        <div>
                            <label for="phone">Phone</label>
                            <input id="phone" type="tel" name="phone" placeholder="+1 (555) 123-4567">
                        </div>
                    </div>
                    <div>
                        <label for="interest">Primary Interest</label>
                        <select id="interest" name="interest" required>
                            <option value="" disabled selected>Select an option</option>
                            <option value="monitoring">Real-Time Monitoring</option>
                            <option value="predictive">Predictive Maintenance</option>
                            <option value="digitaltwin">Digital Twin Simulations</option>
                            <option value="emissions">Emissions Tracking</option>
                            <option value="inspections">Automated Inspections</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div>
                        <label for="message">Project Overview</label>
                        <textarea id="message" name="message" required placeholder="Outline your objectives, timelines, and current technology stack."></textarea>
                    </div>
                    <button class="btn btn-primary" type="submit">Submit Inquiry</button>
                    <p style="font-size:13px; color:rgba(47,58,69,0.6);">By submitting, you agree to the <a href="terms.html">Terms</a> and acknowledge the <a href="privacy.html">Privacy Policy</a>.</p>
                </form>
            </div>
        </div>
        <div style="margin-top:48px;">
            <iframe class="map-frame" loading="lazy" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.412357759019!2d-123.12073712376061!3d49.28474697139485!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54867179e3950297%3A0xfdcb8f6f11bb1b56!2s885%20W%20Georgia%20St%2C%20Vancouver%2C%20BC!5e0!3m2!1sen!2sca!4v1700000000000!5m2!1sen!2sca"></iframe>
        </div>
    </div>
</section>

<footer class="site-footer">
    <div class="container">
        <div class="footer-top">
            <div class="footer-brand">
                <h3>Energy Track</h3>
                <p>Energy Track empowers energy operators with precision monitoring, predictive analytics, and actionable intelligence from field to boardroom.</p>
                <div class="badge-list">
                    <span class="badge">24/7 Support</span>
                    <span class="badge">Canadian Market Focus</span>
                    <span class="badge">Data Assurance</span>
                </div>
            </div>
            <div class="footer-nav">
                <strong>Navigation</strong>
                <a href="index.php">Home</a>
                <a href="solutions.html">Solutions</a>
                <a href="technology.html">Technology</a>
                <a href="case-studies.html">Case Studies</a>
                <a href="news.html">News</a>
            </div>
            <div class="footer-legal">
                <strong>Policies</strong>
                <a href="privacy.html">Privacy Policy</a>
                <a href="terms.html">Terms & Conditions</a>
                <a href="faq.html">FAQ</a>
                <a href="contact.php">Contact</a>
                <a href="404.html">404 Page</a>
            </div>
            <div class="footer-contact">
                <strong>Contact</strong>
                <p>Email: insight@energytrack.ca</p>
                <p>Phone: +1 (604) 555-0186</p>
                <p>Address: 885 W Georgia St, Vancouver, BC</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© <?php echo date('Y'); ?> Energy Track. All rights reserved.</p>
        </div>
    </div>
</footer>

<div class="cookie-banner" id="cookieBanner">
    <h3>Cookie Preferences</h3>
    <p>Energy Track uses cookies to enhance performance analytics and remember user preferences. Manage your consent below.</p>
    <div class="cookie-actions">
        <button class="btn btn-primary" id="cookieAccept" type="button">Accept All</button>
        <button class="btn btn-outline" id="cookieDecline" type="button">Decline</button>
    </div>
    <p style="margin-top:12px; font-size:13px; color:rgba(47,58,69,0.6);">Review our <a href="privacy.html">Privacy Policy</a> for more details.</p>
</div>
</body>
</html>