document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      navToggle.classList.toggle("is-active");
      siteNav.classList.toggle("is-open");
    });

    siteNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navToggle.classList.remove("is-active");
        siteNav.classList.remove("is-open");
      });
    });
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  const acceptBtn = document.querySelector("[data-cookie-accept]");
  const declineBtn = document.querySelector("[data-cookie-decline]");
  const storageKey = "bilimqala-cookie-consent";

  if (cookieBanner && acceptBtn && declineBtn) {
    const savedChoice = localStorage.getItem(storageKey);

    if (!savedChoice) {
      setTimeout(() => {
        cookieBanner.classList.add("is-visible");
      }, 600);
    }

    acceptBtn.addEventListener("click", () => {
      localStorage.setItem(storageKey, "accepted");
      cookieBanner.classList.remove("is-visible");
    });

    declineBtn.addEventListener("click", () => {
      localStorage.setItem(storageKey, "declined");
      cookieBanner.classList.remove("is-visible");
    });
  }
});