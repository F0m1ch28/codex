document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const nav = document.getElementById("primary-navigation");
    const navLinks = document.querySelectorAll(".site-nav a");

    if (navToggle && nav) {
        navToggle.addEventListener("click", function () {
            const isOpen = nav.classList.toggle("is-open");
            navToggle.setAttribute("aria-expanded", isOpen);
        });

        navLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                if (window.innerWidth < 768 && nav.classList.contains("is-open")) {
                    nav.classList.remove("is-open");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const acceptButton = document.getElementById("cookie-accept");
    const declineButton = document.getElementById("cookie-decline");
    const cookieChoice = localStorage.getItem("peniel_cookie_choice");

    if (cookieBanner) {
        if (!cookieChoice) {
            cookieBanner.classList.add("is-visible");
        }

        if (acceptButton) {
            acceptButton.addEventListener("click", function () {
                localStorage.setItem("peniel_cookie_choice", "accepted");
                cookieBanner.classList.remove("is-visible");
            });
        }

        if (declineButton) {
            declineButton.addEventListener("click", function () {
                localStorage.setItem("peniel_cookie_choice", "declined");
                cookieBanner.classList.remove("is-visible");
            });
        }
    }
});