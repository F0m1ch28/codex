document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            const isActive = navMenu.classList.toggle('active');
            navToggle.setAttribute('aria-expanded', isActive ? 'true' : 'false');
        });
    }

    const banner = document.getElementById('cookieBanner');
    if (banner) {
        const storedPreference = localStorage.getItem('ombgxyqCookieConsent');
        if (!storedPreference) {
            setTimeout(() => {
                banner.classList.add('is-visible');
            }, 600);
        }

        banner.querySelectorAll('.cookie-btn').forEach(function (btn) {
            btn.addEventListener('click', function (event) {
                event.preventDefault();
                const action = btn.dataset.action || 'custom';
                try {
                    localStorage.setItem('ombgxyqCookieConsent', action);
                } catch (error) {
                    console.warn('Cookie consent storage failed:', error);
                }
                banner.classList.remove('is-visible');
                setTimeout(() => {
                    banner.style.display = 'none';
                }, 400);
                const targetUrl = btn.getAttribute('href');
                if (targetUrl) {
                    window.open(targetUrl, '_blank', 'noopener');
                }
            });
        });
    }
});