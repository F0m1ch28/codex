document.addEventListener('DOMContentLoaded', function () {
    const body = document.body;
    const navToggle = document.querySelector('.nav-toggle');
    const primaryNavigation = document.querySelector('.primary-navigation');

    if (navToggle && primaryNavigation) {
        navToggle.addEventListener('click', function () {
            primaryNavigation.classList.toggle('open');
            body.classList.toggle('nav-open');
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', String(!expanded));
        });

        primaryNavigation.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 768) {
                    primaryNavigation.classList.remove('open');
                    body.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const yearElement = document.getElementById('current-year');
    if (yearElement) {
        yearElement.textContent = String(new Date().getFullYear());
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    const acceptButton = document.querySelector('[data-cookie-accept]');
    const declineButton = document.querySelector('[data-cookie-decline]');
    const consentKey = 'ok-cookie-consent';

    function hideCookieBanner() {
        if (cookieBanner) {
            cookieBanner.classList.remove('visible');
            setTimeout(function () {
                cookieBanner.classList.add('hidden');
            }, 400);
        }
    }

    if (cookieBanner) {
        const storedConsent = localStorage.getItem(consentKey);
        if (!storedConsent) {
            cookieBanner.classList.add('visible');
        } else {
            cookieBanner.classList.add('hidden');
        }

        if (acceptButton) {
            acceptButton.addEventListener('click', function () {
                localStorage.setItem(consentKey, 'accepted');
                hideCookieBanner();
            });
        }

        if (declineButton) {
            declineButton.addEventListener('click', function () {
                localStorage.setItem(consentKey, 'declined');
                hideCookieBanner();
            });
        }
    }
});