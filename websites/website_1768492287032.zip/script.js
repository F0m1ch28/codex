document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    const navLinks = document.querySelectorAll('.site-nav a');
    const body = document.body;

    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            const expanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!expanded).toString());
            siteNav.classList.toggle('is-open');
            body.classList.toggle('nav-open');
        });

        navLinks.forEach((link) => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    siteNav.classList.remove('is-open');
                    body.classList.remove('nav-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const cookieButtons = cookieBanner.querySelectorAll('.cookie-btn');
        const savedPreference = localStorage.getItem('rackantvrlCookiesChoice');
        if (!savedPreference) {
            cookieBanner.classList.add('is-visible');
        }

        cookieButtons.forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                const action = button.dataset.cookieAction || 'accept';
                localStorage.setItem('rackantvrlCookiesChoice', action);
                cookieBanner.classList.remove('is-visible');
                const destination = button.getAttribute('href');
                if (destination) {
                    window.open(destination, '_blank', 'noopener');
                }
            });
        });
    }
});