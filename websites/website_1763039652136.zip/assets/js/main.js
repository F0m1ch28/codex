document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.main-nav ul');
    const navLinks = document.querySelectorAll('.main-nav a');
    const scrollBtn = document.getElementById('scrollTop');
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const contactForm = document.getElementById('contactForm');
    const formFeedback = document.querySelector('.form-feedback');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            navToggle.setAttribute('aria-expanded', (!isExpanded).toString());
            navList.classList.toggle('show');
        });

        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navToggle.setAttribute('aria-expanded', 'false');
                navList.classList.remove('show');
            });
        });
    }

    const handleScrollBtn = () => {
        if (window.scrollY > 300) {
            scrollBtn.classList.add('show');
        } else {
            scrollBtn.classList.remove('show');
        }
    };

    if (scrollBtn) {
        window.addEventListener('scroll', handleScrollBtn);
        handleScrollBtn();

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    if (cookieBanner && cookieAccept) {
        const consentKey = 'mefanaltriaCookiesAccepted';
        const hasConsent = localStorage.getItem(consentKey);

        if (!hasConsent) {
            cookieBanner.classList.add('show');
        }

        cookieAccept.addEventListener('click', () => {
            localStorage.setItem(consentKey, 'yes');
            cookieBanner.classList.remove('show');
        });
    }

    if (contactForm && formFeedback) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const message = formData.get('message');

            if (!name || !email || !message) {
                formFeedback.textContent = 'Bitte fülle alle Pflichtfelder aus.';
                formFeedback.style.color = '#f59f00';
                return;
            }

            formFeedback.textContent = 'Vielen Dank! Deine Nachricht ist bei uns angekommen.';
            formFeedback.style.color = '#2f9e44';
            contactForm.reset();
        });
    }
});