<!DOCTYPE html>
<html lang="es">
<head>
  <!-- META TAGS -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sol Híbrido España | Contacto y Solicitud de Estudio Energético</title>
  <meta name="description" content="Contacta con Sol Híbrido España. Solicita un estudio energético para sistemas solares híbridos con almacenamiento y monitorización en tiempo real.">
  <link rel="canonical" href="https://www.solhibridoespana.com/contact.php">
  <meta property="og:title" content="Sol Híbrido España | Contacto y Solicitud de Estudio Energético">
  <meta property="og:description" content="Contacta para soluciones de autoconsumo energético, baterías inteligentes y paneles solares de alta eficiencia en España.">
  <meta property="og:type" content="article">
  <meta property="og:url" content="https://www.solhibridoespana.com/contact.php">
  <meta property="og:image" content="https://picsum.photos/1200/630?contacto">
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0%25' x2='100%25' y1='0%25' y2='100%25'%3E%3Cstop offset='0%25' stop-color='%230C8C68'/%3E%3Cstop offset='100%25' stop-color='%23F2A900'/%3E%3C/linearGradient%3E%3C/defs%3E%3Ccircle cx='32' cy='32' r='30' fill='url(%23g)'/%3E%3Cpath d='M32 14l8 14h-16zM24 32l8 14 8-14z' fill='%23fff'/%3E%3C/svg%3E">
  <style>
    :root{
      --color-primary:#0E9F6E;
      --color-secondary:#F2A900;
      --color-dark:#0B1E34;
      --color-light:#F5FBFF;
      --color-text:#1F2A37;
      --color-muted:#6B7A90;
      --radius-lg:24px;
      --radius-md:16px;
      --shadow-card:0 18px 38px rgba(11,30,52,0.12);
    }
    *{box-sizing:border-box;}
    body{
      margin:0;
      font-family:"Segoe UI","Helvetica Neue",Arial,sans-serif;
      background:#F1F6F4;
      color:var(--color-text);
      line-height:1.7;
    }
    a{text-decoration:none;color:inherit;}
    header{
      position:sticky;
      top:0;
      background:#fff;
      box-shadow:0 12px 32px rgba(11,30,52,0.15);
      z-index:998;
    }
    .container{width:min(1120px,90%);margin:0 auto;}
    .topbar{
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:1rem 0;
      gap:1.5rem;
    }
    .brand{
      font-weight:700;
      font-size:1.3rem;
      display:flex;
      align-items:center;
      gap:0.6rem;
      color:var(--color-dark);
    }
    .brand span{
      width:34px;height:34px;border-radius:50%;
      background:linear-gradient(135deg,var(--color-primary),var(--color-secondary));
      color:#fff;display:flex;align-items:center;justify-content:center;
    }
    .nav-toggle{
      display:none;
      border:1px solid rgba(14,159,110,0.2);
      background:var(--color-light);
      border-radius:50px;
      padding:0.5rem 0.75rem;
    }
    nav ul{
      list-style:none;
      display:flex;
      gap:1.5rem;
      margin:0;padding:0;
    }
    nav a{
      font-weight:600;
      color:var(--color-muted);
      position:relative;
    }
    nav a[aria-current="page"],nav a:hover{color:var(--color-dark);}
    nav a::after{
      content:"";
      position:absolute;
      left:0;bottom:-6px;width:100%;height:3px;
      background:linear-gradient(135deg,var(--color-primary),var(--color-secondary));
      transform:scaleX(0);
      transform-origin:left;
      transition:transform 0.3s ease;
    }
    nav a:hover::after,nav a[aria-current="page"]::after{transform:scaleX(1);}
    .hero{
      margin-top:2rem;
      background:#fff;
      padding:3.5rem;
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-card);
    }
    .hero h1{margin:0 0 1rem;font-size:2.6rem;}
    .hero p{margin:0;color:var(--color-muted);max-width:760px;}
    section{padding:3.5rem 0;}
    .grid{display:grid;gap:2rem;}
    .grid-2{grid-template-columns:repeat(2,minmax(0,1fr));}
    .card{
      background:#fff;
      border-radius:var(--radius-md);
      padding:2.5rem;
      box-shadow:var(--shadow-card);
    }
    label{font-weight:600;display:block;margin-bottom:0.4rem;}
    input,select,textarea{
      width:100%;
      padding:0.85rem 1rem;
      border-radius:12px;
      border:1px solid rgba(11,30,52,0.12);
      font:inherit;
    }
    input:focus,select:focus,textarea:focus{
      outline:none;
      border-color:var(--color-primary);
      box-shadow:0 0 0 4px rgba(14,159,110,0.15);
    }
    textarea{min-height:140px;resize:vertical;}
    .btn{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:0.5rem;
      padding:0.85rem 1.8rem;
      border-radius:50px;
      border:none;
      font-weight:600;
      background:linear-gradient(135deg,var(--color-primary),#0A7F56);
      color:#fff;
      cursor:pointer;
      box-shadow:0 15px 28px rgba(14,159,110,0.18);
    }
    .info{
      background:#fff;
      border-radius:var(--radius-md);
      padding:2rem;
      box-shadow:var(--shadow-card);
    }
    .info ul{
      list-style:none;
      margin:0;
      padding:0;
      display:grid;
      gap:1rem;
    }
    .mapa{
      border-radius:var(--radius-md);
      overflow:hidden;
      box-shadow:var(--shadow-card);
      border:0;
      width:100%;
      height:320px;
    }
    .cta{
      background:linear-gradient(135deg,var(--color-dark),#134663);
      color:#fff;
      padding:3rem;
      border-radius:var(--radius-lg);
      text-align:center;
      box-shadow:var(--shadow-card);
    }
    .cta a{
      display:inline-block;
      margin-top:1.5rem;
      padding:0.85rem 1.8rem;
      border-radius:50px;
      background:linear-gradient(135deg,var(--color-primary),#0A7F56);
      color:#fff;
      font-weight:600;
    }
    footer{
      background:#0A1725;
      color:#E5F3EF;
      padding:3rem 0;
    }
    .footer-grid{
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
      gap:2rem;
    }
    .footer-links{
      list-style:none;
      margin:0;padding:0;
      display:grid;
      gap:0.7rem;
    }
    .footer-links a{color:#B3C7D6;font-weight:600;}
    .footer-bottom{
      margin-top:2rem;
      padding-top:1.5rem;
      border-top:1px solid rgba(255,255,255,0.15);
      display:flex;
      gap:1rem;
      flex-wrap:wrap;
      justify-content:space-between;
      font-size:0.9rem;
    }
    .cookie-banner{
      position:fixed;
      bottom:20px;
      right:20px;
      max-width:320px;
      background:#fff;
      padding:1.5rem;
      border-radius:16px;
      box-shadow:0 15px 38px rgba(11,30,52,0.22);
      display:none;
      z-index:999;
    }
    .cookie-actions{display:flex;gap:0.75rem;}
    .btn-outline{
      background:transparent;
      border:1px solid rgba(11,30,52,0.2);
      color:var(--color-dark);
      border-radius:50px;
      padding:0.75rem 1.5rem;
      font-weight:600;
      cursor:pointer;
    }
    .btn-outline:hover{border-color:var(--color-primary);color:var(--color-primary);}
    @media(max-width:980px){
      .grid-2{grid-template-columns:1fr;}
    }
    @media(max-width:768px){
      nav{
        position:absolute;
        top:100%;
        right:20px;
        background:#fff;
        border-radius:18px;
        padding:1.25rem;
        width:220px;
        box-shadow:0 25px 60px rgba(11,30,52,0.16);
        opacity:0;
        pointer-events:none;
        transform:translateY(-10px);
        transition:opacity 0.3s ease,transform 0.3s ease;
      }
      nav.open{opacity:1;pointer-events:auto;transform:translateY(0);}
      nav ul{flex-direction:column;align-items:flex-start;}
      .nav-toggle{display:inline-flex;}
      .cookie-banner{left:20px;right:20px;}
      .footer-bottom{flex-direction:column;align-items:flex-start;}
    }
  </style>
</head>
<body>
  <header role="banner">
    <div class="container topbar">
      <a class="brand" href="index.html"><span>SE</span>Sol Híbrido España</a>
      <button class="nav-toggle" aria-expanded="false" aria-controls="nav">Menú</button>
      <nav id="nav" role="navigation" aria-label="Navegación principal">
        <ul>
          <li><a href="index.html">Inicio</a></li>
          <li><a href="empresa.html">Empresa</a></li>
          <li><a href="tecnologia.html">Tecnología</a></li>
          <li><a href="instalaciones.html">Instalaciones</a></li>
          <li><a href="ahorro.html">Ahorro</a></li>
          <li><a href="sostenibilidad.html">Sostenibilidad</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="contact.php" aria-current="page">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>
  <main>
    <section class="container hero">
      <h1>Contacto directo con Sol Híbrido España</h1>
      <p>Agenda un estudio energético personalizado y descubre cómo optimizar tu autoconsumo con sistemas solares híbridos y monitorización inteligente.</p>
    </section>

    <section>
      <div class="container grid grid-2">
        <div class="card" role="form" aria-labelledby="form-contacto">
          <h2 id="form-contacto">Formulario de contacto</h2>
          <form action="thanks.php" method="post">
            <div>
              <label for="nombre">Nombre completo</label>
              <input id="nombre" name="nombre" type="text" required placeholder="Tu nombre">
            </div>
            <div>
              <label for="email">Correo electrónico</label>
              <input id="email" name="email" type="email" required placeholder="tu@dominio.com">
            </div>
            <div>
              <label for="telefono">Teléfono</label>
              <input id="telefono" name="telefono" type="tel" required placeholder="+34 600 000 000">
            </div>
            <div>
              <label for="tipo">Tipo de proyecto</label>
              <select id="tipo" name="tipo" required>
                <option value="">Selecciona una opción</option>
                <option value="residencial">Residencial</option>
                <option value="empresarial">Empresarial</option>
                <option value="industrial">Industrial</option>
                <option value="comunidad">Comunidad energética</option>
              </select>
            </div>
            <div>
              <label for="mensaje">Mensaje</label>
              <textarea id="mensaje" name="mensaje" placeholder="Cuéntanos tus objetivos energéticos" required></textarea>
            </div>
            <button class="btn" type="submit">Enviar solicitud</button>
          </form>
        </div>
        <div class="info">
          <h2>Estamos a tu disposición</h2>
          <p>Te ayudamos a diseñar soluciones de energía sostenible con paneles solares de alta eficiencia y baterías inteligentes.</p>
          <ul>
            <li>📍 Torre Iberdrola, Plaza Euskadi 5, Planta 14, 48009 Bilbao, España</li>
            <li>📞 <a href="tel:+34944679312">+34 944 679 312</a></li>
            <li>✉️ <a href="mailto:contacto@solhibridoespana.com">contacto@solhibridoespana.com</a></li>
            <li>🕑 Lunes a viernes de 09:00 a 19:00</li>
          </ul>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="card">
          <h2>Visítanos en Bilbao</h2>
          <iframe class="mapa" src="https://www.openstreetmap.org/export/embed.html?bbox=-2.9385%2C43.266%2C-2.932%2C43.271&layer=mapnik&marker=43.2686%2C-2.9353" loading="lazy" aria-label="Mapa de ubicación de Sol Híbrido España"></iframe>
        </div>
      </div>
    </section>

    <section>
      <div class="container cta">
        <h2>Solicitar estudio energético</h2>
        <p>Evalúa tu potencial de autoconsumo energético con paneles solares de alta eficiencia, almacenamiento inteligente y monitorización en tiempo real.</p>
        <a href="contact.php">Iniciar solicitud</a>
      </div>
    </section>
  </main>

  <footer role="contentinfo">
    <div class="container footer-grid">
      <div>
        <strong>Sol Híbrido España</strong>
        <p>Soluciones integrales de energía sostenible con tecnología híbrida de última generación.</p>
      </div>
      <div>
        <h3>Secciones</h3>
        <ul class="footer-links">
          <li><a href="empresa.html">Empresa</a></li>
          <li><a href="tecnologia.html">Tecnología</a></li>
          <li><a href="instalaciones.html">Instalaciones</a></li>
        </ul>
      </div>
      <div>
        <h3>Legal</h3>
        <ul class="footer-links">
          <li><a href="privacy.html">Privacidad</a></li>
          <li><a href="cookies.html">Cookies</a></li>
          <li><a href="terms.html">Términos</a></li>
        </ul>
      </div>
      <div>
        <h3>Contacto</h3>
        <ul class="footer-links">
          <li>Plaza Euskadi 5, Torre Iberdrola, Planta 14, Bilbao</li>
          <li><a href="tel:+34944679312">+34 944 679 312</a></li>
          <li><a href="mailto:contacto@solhibridoespana.com">contacto@solhibridoespana.com</a></li>
        </ul>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>© <span id="year"></span> Sol Híbrido España</span>
      <div style="display:flex;gap:1rem;">
        <a href="robots.txt">robots.txt</a>
        <a href="sitemap.xml">sitemap.xml</a>
        <a href="404.html">404</a>
      </div>
    </div>
  </footer>

  <div class="cookie-banner" role="dialog" aria-live="polite">
    <p>Usamos cookies para optimizar el servicio. Consulta la <a href="cookies.html">política</a>.</p>
    <div class="cookie-actions">
      <button class="btn" id="cookie-accept">Aceptar</button>
      <button class="btn-outline" id="cookie-decline">Rechazar</button>
    </div>
  </div>

  <script>
    const navToggle=document.querySelector('.nav-toggle');
    const nav=document.getElementById('nav');
    navToggle.addEventListener('click',()=>{
      const expanded=navToggle.getAttribute('aria-expanded')==='true';
      navToggle.setAttribute('aria-expanded',String(!expanded));
      nav.classList.toggle('open');
    });
    document.getElementById('year').textContent=new Date().getFullYear();
    const cookieBanner=document.querySelector('.cookie-banner');
    const cookieKey='she_cookie_choice';
    function showCookie(){
      if(!localStorage.getItem(cookieKey)){
        cookieBanner.style.display='block';
      }
    }
    function setCookie(value){
      localStorage.setItem(cookieKey,value);
      cookieBanner.style.display='none';
    }
    document.getElementById('cookie-accept').addEventListener('click',()=>setCookie('accepted'));
    document.getElementById('cookie-decline').addEventListener('click',()=>setCookie('declined'));
    showCookie();
  </script>
</body>
</html>