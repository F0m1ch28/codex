document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', (!expanded).toString());
      mainNav.classList.toggle('is-open');
    });

    mainNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          mainNav.classList.remove('is-open');
          navToggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768) {
        mainNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  const banner = document.querySelector('.cookie-banner');
  const acceptBtn = banner?.querySelector('[data-cookie-accept]');
  const declineBtn = banner?.querySelector('[data-cookie-decline]');
  const storageKey = 'taied-cookie-choice';

  if (banner) {
    const showBanner = () => banner.setAttribute('data-visible', 'true');
    const hideBanner = () => banner.setAttribute('data-visible', 'false');

    try {
      const existingChoice = localStorage.getItem(storageKey);
      if (!existingChoice) {
        setTimeout(showBanner, 600);
      }
      acceptBtn?.addEventListener('click', () => {
        localStorage.setItem(storageKey, 'accepted');
        hideBanner();
      });
      declineBtn?.addEventListener('click', () => {
        localStorage.setItem(storageKey, 'declined');
        hideBanner();
      });
    } catch (error) {
      setTimeout(showBanner, 600);
      acceptBtn?.addEventListener('click', hideBanner);
      declineBtn?.addEventListener('click', hideBanner);
    }
  }
});