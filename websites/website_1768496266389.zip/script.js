document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('is-open');
            navToggle.setAttribute('aria-expanded', isOpen);
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (navLinks.classList.contains('is-open')) {
                    navLinks.classList.remove('is-open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    const accordionItems = document.querySelectorAll('.accordion-item');
    accordionItems.forEach(item => {
        const header = item.querySelector('.accordion-header');
        const panel = item.querySelector('.accordion-panel');
        if (header && panel) {
            header.addEventListener('click', () => {
                const isOpen = item.classList.toggle('is-open');
                accordionItems.forEach(other => {
                    if (other !== item) {
                        other.classList.remove('is-open');
                        const otherPanel = other.querySelector('.accordion-panel');
                        if (otherPanel) {
                            otherPanel.style.maxHeight = null;
                        }
                    }
                });
                if (isOpen) {
                    panel.style.maxHeight = panel.scrollHeight + 'px';
                } else {
                    panel.style.maxHeight = null;
                }
            });
        }
    });

    const cookieBanner = document.querySelector('.cookie-banner');
    if (cookieBanner) {
        const storedPreference = localStorage.getItem('shapinegcxCookiePreference');
        if (storedPreference) {
            cookieBanner.classList.add('is-hidden');
        }

        const cookieButtons = cookieBanner.querySelectorAll('.cookie-btn');
        cookieButtons.forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const action = button.dataset.action || 'accept';
                localStorage.setItem('shapinegcxCookiePreference', action);
                cookieBanner.classList.add('is-hidden');
                window.location.href = button.getAttribute('href');
            });
        });
    }
});