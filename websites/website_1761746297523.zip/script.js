document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const primaryNav = document.querySelector('.primary-navigation');
  const navLinks = document.querySelectorAll('.nav-list a');
  const cookieBanner = document.getElementById('cookie-banner');
  const cookieAccept = document.getElementById('cookie-accept');
  const contactForm = document.getElementById('contact-form');
  const formStatus = document.getElementById('form-status');
  const faqButtons = document.querySelectorAll('.faq-question');
  const yearEl = document.getElementById('current-year');

  // Mobile navigation toggle
  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      primaryNav.classList.toggle('open');
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        primaryNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Active navigation state
  const path = window.location.pathname.split('/').pop() || 'index.html';
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === path || (href === 'index.html' && path === '')) {
      link.classList.add('is-active');
      link.setAttribute('aria-current', 'page');
    }
  });

  // Intersection observer for reveal animations
  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.2 }
  );
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  // Contact form handling
  if (contactForm && formStatus) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      if (!contactForm.checkValidity()) {
        contactForm.reportValidity();
        formStatus.textContent = 'Please complete the required fields highlighted above.';
        formStatus.className = 'form-status error';
        return;
      }
      formStatus.textContent = 'Thank you! Your message has been received. We will respond within one business day.';
      formStatus.className = 'form-status success';
      contactForm.reset();
    });
  }

  // FAQ accordion
  faqButtons.forEach(button => {
    const answer = button.nextElementSibling;
    if (answer) {
      answer.hidden = true;
      button.addEventListener('click', () => {
        const expanded = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!expanded));
        answer.hidden = expanded;
      });
    }
  });

  // Cookie consent
  const cookieConsentKey = 'aurora-cookie-consent';
  const hasConsent = localStorage.getItem(cookieConsentKey);
  if (!hasConsent && cookieBanner) {
    cookieBanner.classList.add('show');
  }
  if (cookieAccept && cookieBanner) {
    cookieAccept.addEventListener('click', () => {
      localStorage.setItem(cookieConsentKey, 'accepted');
      cookieBanner.classList.remove('show');
    });
  }

  // Newsletter forms feedback (prevent actual submission for demo)
  document.querySelectorAll('.newsletter-form').forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const input = form.querySelector('input[type="email"]');
      if (input && input.value.trim() !== '') {
        const confirmation = document.createElement('div');
        confirmation.className = 'form-status success';
        confirmation.textContent = 'Subscribed! Check your inbox for confirmation.';
        form.after(confirmation);
        setTimeout(() => confirmation.remove(), 4000);
        form.reset();
      }
    });
  });

  // Set current year in footer
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});