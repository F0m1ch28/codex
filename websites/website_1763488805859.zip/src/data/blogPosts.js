const blogPosts = [
  {
    slug: 'lerntempo-verstehen',
    title: 'Dein Lerntempo verstehen und bewusst steuern',
    category: 'Lernpsychologie',
    readTime: '6 Min.',
    excerpt:
      'Erkenne Muster in deinem Lernverhalten und finde einen realistischen Rhythmus, der dich voranbringt ohne dich zu überfordern.',
    cover: 'https://picsum.photos/1200/800?random=11',
    content: [
      'Viele Lernende unterschätzen die Kraft von Rhythmen. Dein Gehirn liebt Wiederholungen, aber nur, wenn sie in einem Tempo stattfinden, das zu deiner Tagesform passt.',
      'Starte mit einem ehrlichen Status-Check: Zu welchen Tageszeiten fühlst du dich konzentriert? Welche Aufgaben kosten dich besonders viel Energie? Dokumentiere das eine Woche lang und du erkennst ein klares Muster.',
      'Passe anschließend deinen Lernplan so an, dass die anspruchsvollsten Aufgaben in deine Hochzeiten fallen. Routine-Aufgaben legst du in Phasen mit weniger Fokus.',
      'Denke daran: Tempo ist individuell. Du darfst langsam beginnen, solange du konsequent dranbleibst. Kleine, gut geplante Schritte schlagen hektische Marathons.'
    ]
  },
  {
    slug: 'habit-building-fuer-lernstrategien',
    title: 'Habit Building für Lernstrategien, die bleiben',
    category: 'Habit Building',
    readTime: '8 Min.',
    excerpt:
      'So baust du Routinen, die du wirklich durchhältst – mit Triggern, Mikro-Schritten und ehrlichem Feedback an dich selbst.',
    cover: 'https://picsum.photos/1200/800?random=12',
    content: [
      'Jede Lernroutine braucht einen klaren Auslöser: ein Zeitfenster, einen Ort oder ein Ritual, das den Lernmodus markiert.',
      'Setze deine Einstiegsschwelle minimal. Fünf Minuten bewusster Fokus reichen anfangs. Die Konstanz zählt mehr als die Dauer.',
      'Arbeite mit sichtbaren Trackern. Ein einfaches Wochen-Board oder ein digitales Häkchen sorgt für Momentum.',
      'Hol dir Feedback von dir selbst: Reflexionsfragen nach jeder Session helfen dir, deine Gewohnheiten zu justieren.'
    ]
  },
  {
    slug: 'feedback-und-reflexion',
    title: 'Feedback & Reflexion: Dein Turbo für Metaskills',
    category: 'Metaskills',
    readTime: '7 Min.',
    excerpt:
      'Regelmäßige Reflexion schafft Klarheit über Fortschritte, Engpässe und Prioritäten. Hier erfährst du, wie du sie alltagstauglich machst.',
    cover: 'https://picsum.photos/1200/800?random=13',
    content: [
      'Plane nach jeder Lern-Session drei Minuten für eine Kurzreflexion ein: Was lief gut? Was hat gebremst? Was nimmst du mit?',
      'Bitte eine vertraute Person um ehrliches Feedback zu deiner Lernstruktur. Außenperspektiven zeigen blinde Flecken.',
      'Nutze Checklisten, um Reflexion nicht dem Zufall zu überlassen. So findest du schneller Stellschrauben für Anpassungen.',
      'Reflexion ist kein Zusatz, sondern Teil des Lernens. Sie verwandelt Erlebnisse in Erkenntnisse.'
    ]
  }
];

export default blogPosts;