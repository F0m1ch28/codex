import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from './components/Header';
import Footer from './components/Footer';
import CookieBanner from './components/CookieBanner';
import ScrollToTop from './components/ScrollToTop';
import Home from './pages/Home';
import Guide from './pages/Guide';
import Programs from './pages/Programs';
import Tools from './pages/Tools';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Imprint from './pages/Imprint';

const App = () => {
  const location = useLocation();

  return (
    <>
      <Helmet>
        <html lang="de" />
        <title>Tiloravento | Schneller lernen. Klarer Fortschritt.</title>
        <meta
          name="description"
          content="Tiloravento hilft dir, schneller zu lernen, sinnvolle Lernroutinen zu entwickeln und Metaskills im Alltag aufzubauen."
        />
        <meta name="author" content="Tiloravento" />
        <meta property="og:title" content="Tiloravento | Schneller lernen" />
        <meta
          property="og:description"
          content="Praxisnahe Lernstrategien, klare Routinen und Metaskill-Training für deinen Alltag."
        />
        <meta property="og:type" content="website" />
      </Helmet>
      <ScrollToTop />
      <div className="appContainer">
        <Header />
        <main id="main-content" className="mainContent" tabIndex="-1">
          <Routes location={location}>
            <Route path="/" element={<Home />} />
            <Route path="/guide" element={<Guide />} />
            <Route path="/programs" element={<Programs />} />
            <Route path="/tools" element={<Tools />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/legal" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/imprint" element={<Imprint />} />
          </Routes>
        </main>
        <Footer />
      </div>
      <CookieBanner />
    </>
  );
};

export default App;