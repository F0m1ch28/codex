import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Header.module.css';

const navItems = [
  { label: 'Start', to: '/' },
  { label: 'Guide', to: '/guide' },
  { label: 'Programme', to: '/programs' },
  { label: 'Tools', to: '/tools' },
  { label: 'Blog', to: '/blog' },
  { label: 'Über uns', to: '/about' },
  { label: 'Leistungen', to: '/services' },
  { label: 'Kontakt', to: '/contact' }
];

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMenu = () => setMenuOpen((prev) => !prev);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [menuOpen]);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo} aria-label="Zur Startseite von Tiloravento">
          <span className={styles.logoMark}>T</span>
          <span className={styles.logoText}>Tiloravento</span>
        </NavLink>
        <nav className={`${styles.nav} ${menuOpen ? styles.open : ''}`} aria-label="Hauptnavigation">
          <ul>
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) => (isActive ? styles.active : '')}
                  onClick={() => setMenuOpen(false)}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <button
          className={`${styles.menuToggle} ${menuOpen ? styles.open : ''}`}
          onClick={toggleMenu}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          aria-label="Menü umschalten"
        >
          <span />
          <span />
          <span />
        </button>
      </div>
      {menuOpen && <div className={styles.backdrop} aria-hidden="true" onClick={toggleMenu} />}
    </header>
  );
};

export default Header;