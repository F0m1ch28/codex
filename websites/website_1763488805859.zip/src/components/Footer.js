import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer} aria-labelledby="footer-heading">
      <div className={styles.inner}>
        <div className={styles.brand}>
          <h2 id="footer-heading">Tiloravento</h2>
          <p>
            Deine Plattform für klaren Lernfortschritt, alltagstaugliche Routinen und den Aufbau von Metaskills.
          </p>
          <div className={styles.contact}>
            <p>Adresse: Musterweg 12, 10115 Berlin</p>
            <p>
              E-Mail:{' '}
              <a href="mailto:hallo@tiloravento.de" aria-label="E-Mail an Tiloravento senden">
                hallo@tiloravento.de
              </a>
            </p>
            <p>
              Telefon:{' '}
              <a href="tel:+493012345678" aria-label="Telefonnummer von Tiloravento">
                +49 30 123 456 78
              </a>
            </p>
          </div>
        </div>
        <div className={styles.links}>
          <div>
            <h3>Navigiere</h3>
            <ul>
              <li>
                <NavLink to="/">Start</NavLink>
              </li>
              <li>
                <NavLink to="/guide">Guide</NavLink>
              </li>
              <li>
                <NavLink to="/programs">Programme</NavLink>
              </li>
              <li>
                <NavLink to="/tools">Tools</NavLink>
              </li>
              <li>
                <NavLink to="/blog">Blog</NavLink>
              </li>
            </ul>
          </div>
          <div>
            <h3>Info</h3>
            <ul>
              <li>
                <NavLink to="/about">Über uns</NavLink>
              </li>
              <li>
                <NavLink to="/services">Leistungen</NavLink>
              </li>
              <li>
                <NavLink to="/legal">AGB</NavLink>
              </li>
              <li>
                <NavLink to="/privacy">Datenschutz</NavLink>
              </li>
              <li>
                <NavLink to="/imprint">Impressum</NavLink>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.bottom}>
        <span>© {new Date().getFullYear()} Tiloravento. Alle Rechte vorbehalten.</span>
      </div>
    </footer>
  );
};

export default Footer;