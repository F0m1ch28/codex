import React, { useEffect, useState } from 'react';
import styles from './CookieBanner.module.css';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = window.localStorage.getItem('tiloravento-cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    window.localStorage.setItem('tiloravento-cookie-consent', 'accepted');
    setVisible(false);
  };

  const handleDecline = () => {
    window.localStorage.setItem('tiloravento-cookie-consent', 'declined');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className={styles.banner} role="dialog" aria-live="polite" aria-label="Cookie-Hinweis">
      <div className={styles.content}>
        <strong>Cookies für bessere Lernerlebnisse</strong>
        <p>
          Wir nutzen Cookies, um dir eine reibungslose Nutzung der Plattform zu ermöglichen. Du kannst jederzeit auf
          unsere Datenschutzerklärung zugreifen, um mehr zu erfahren.
        </p>
        <div className={styles.actions}>
          <button type="button" className={styles.decline} onClick={handleDecline}>
            Ablehnen
          </button>
          <button type="button" className={styles.accept} onClick={handleAccept}>
            Zustimmen
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;