import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import styles from './Home.module.css';
import blogPosts from '../data/blogPosts';

const statsData = [
  { label: 'Fokussierte Sessions geplant', target: 1280 },
  { label: 'Lernroutinen etabliert', target: 740 },
  { label: 'Reflexions-Impulse geteilt', target: 920 }
];

const benefits = [
  {
    title: 'Metaskill: Lernen lernen',
    description:
      'Entschlüssle dein Lernverhalten, finde deine stärksten Lernzeiten und bring Struktur in deinen Alltag – Schritt für Schritt.'
  },
  {
    title: 'Greifbare Routinen',
    description:
      'Erstelle Lernblöcke, die in dein Leben passen. Keine Überforderung, sondern realistische, machbare Sequenzen.'
  },
  {
    title: 'Messbarer Fortschritt',
    description:
      'Tracke deine Lerngewohnheiten und erkenne Muster. Passe nach, bevor Frust entsteht.'
  },
  {
    title: 'Feedback & Reflexion',
    description:
      'Nutze klare Fragen, um dir selbst und anderen Feedback zu geben. So wächst deine Lernkompetenz konstant.'
  }
];

const topics = [
  { title: 'Fokus & Aufmerksamkeit', body: 'Trainiere deinen Einstieg in fokussierte Lern Sessions mit einfachen Triggern.' },
  { title: 'Lernstrategien', body: 'Teste verschiedene Lernformen, kombiniere aktiv und passiv und finde deine Mischung.' },
  { title: 'Üben & Wiederholen', body: 'Plane bewusst Wiederholungsfenster ein, um Wissen zu verankern und sicher abzurufen.' },
  { title: 'Feedback & Reflexion', body: 'Verwandle Erkenntnisse in neue Verhaltens-Schritte, ganz ohne Überforderung.' }
];

const processSteps = [
  { title: 'Status-Check', detail: 'Erkenne deine Lernmuster und Energiezyklen, ohne dich zu verurteilen.' },
  { title: 'Lernumfeld gestalten', detail: 'Ordne Material und Infos. Baue eine Umgebung, die dich einlädt, loszulegen.' },
  { title: 'Prinzipien definieren', detail: 'Klare Regeln schaffen Fokus: Was hat Priorität? Wie startest du? Wie schließt du ab?' },
  { title: 'Routine pflegen', detail: 'Mit Mini-Reviews bleibst du flexibel, ohne deinen Plan ständig umzuwerfen.' }
];

const testimonials = [
  {
    quote:
      'Mit Tiloravento habe ich zum ersten Mal verstanden, wie ich meinen Tag strukturieren kann, ohne mich zu verausgaben.',
    name: 'Kim, Masterstudentin',
    role: 'Schwerpunkt: Lernstrategien & Fokus'
  },
  {
    quote:
      'Die Reflexions-Checkliste nach jeder Session hat mir geholfen, schneller zu erkennen, wo ich festhänge.',
    name: 'Jonas, Product Designer',
    role: 'Schwerpunkt: Feedback & Metaskills'
  },
  {
    quote:
      'Ich mag die ehrliche Sprache. Kein Druck, sondern klare Schritte, die wirklich in meinen Alltag passen.',
    name: 'Lea, Berufsbegleitende Weiterbildung',
    role: 'Schwerpunkt: Routinen & Habit-Building'
  }
];

const faqs = [
  {
    question: 'Ist Tiloravento für Anfänger*innen geeignet?',
    answer:
      'Ja. Du startest mit einem Status-Check deiner Lerngewohnheiten und lernst Schritt für Schritt, wie du Routinen aufbaust. Keine Vorerfahrung nötig.'
  },
  {
    question: 'Brauche ich spezielle Tools?',
    answer:
      'Nein. Du kannst mit analogen oder digitalen Tools arbeiten. Wir zeigen dir einfache Templates, die du flexibel einsetzen kannst.'
  },
  {
    question: 'Wie schnell sehe ich Fortschritte?',
    answer:
      'Nach 10 Tagen erkennst du erste Muster. Nach vier Wochen hast du Routinen, die du bewusst steuerst. Kleine Schritte, täglich umgesetzt.'
  },
  {
    question: 'Gibt es persönliche Beratung?',
    answer:
      'Tiloravento ist keine individuelle Beratung. Du erhältst strukturierte Leitfäden, Reflexionsfragen und Tools, um selbstständig zu lernen.'
  }
];

const projectsData = [
  {
    id: 'focus',
    title: 'Deep-Work Sprint für Lernteams',
    category: 'Teamformat',
    description:
      'Moderiertes 4-Wochen-Format, in dem Teams fokussierte Lernblöcke etablieren und messbar machen.',
    image: 'https://picsum.photos/1200/800?random=21'
  },
  {
    id: 'habit',
    title: 'Habit-Lab für Selbstlernende',
    category: 'Solo',
    description:
      'Experimentiere mit Triggern, Mikro-Schritten und Journaling – live begleitet in einer Community.',
    image: 'https://picsum.photos/1200/800?random=22'
  },
  {
    id: 'reflection',
    title: 'Feedback-Canvas für Feedback-Loops',
    category: 'Workshop',
    description:
      'Erstelle eine persönliche Feedback-Landkarte und plane Reflexion bewusst in deinen Kalender ein.',
    image: 'https://picsum.photos/1200/800?random=23'
  }
];

const Home = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState('Alle');
  const [counters, setCounters] = useState(statsData.map(() => 0));
  const [expandedFaq, setExpandedFaq] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const durations = statsData.map((stat) => Math.floor(stat.target / 40));
    const intervals = statsData.map((stat) => Math.ceil(stat.target / 40));

    const timers = statsData.map((stat, index) =>
      setInterval(() => {
        setCounters((prev) => {
          const updated = [...prev];
          if (updated[index] < stat.target) {
            updated[index] = Math.min(updated[index] + intervals[index], stat.target);
          }
          return updated;
        });
      }, durations[index])
    );

    return () => timers.forEach((timer) => clearInterval(timer));
  }, []);

  const projects = useMemo(() => {
    if (projectFilter === 'Alle') return projectsData;
    return projectsData.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  return (
    <>
      <Helmet>
        <title>Tiloravento | Schneller lernen. Klarer Fortschritt.</title>
        <meta
          name="description"
          content="Entdecke Tiloravento – deine Plattform für schnelleres Lernen, klare Lernroutinen und Metaskill-Entwicklung mit Fokus auf Alltagstauglichkeit."
        />
      </Helmet>
      <section className={`${styles.hero} section`}>
        <div className={`${styles.heroInner} sectionInner`}>
          <div className={styles.heroContent}>
            <span className="badge fadeInUp" style={{ animationDelay: '0.1s' }}>
              Klarer Fokus statt Overload
            </span>
            <h1 className="fadeInUp" style={{ animationDelay: '0.2s' }}>
              Schneller lernen. Klarer Fortschritt.
            </h1>
            <p className="fadeInUp" style={{ animationDelay: '0.3s' }}>
              Tiloravento hilft dir, das Metaskill <strong>„Lernen lernen“</strong> im Alltag zu verankern. Wir kombinieren
              klare Routinen, ehrliche Reflexion und Tools, die dich nicht überfordern.
            </p>
            <div className={styles.heroActions}>
              <Link className="ctaButton fadeInUp" style={{ animationDelay: '0.4s' }} to="/programs">
                Jetzt starten
              </Link>
              <Link className="ctaButton secondary fadeInUp" style={{ animationDelay: '0.5s' }} to="/guide">
                Lernen lernen entdecken
              </Link>
            </div>
            <div className={`${styles.stats} fadeInUp`} style={{ animationDelay: '0.6s' }}>
              {statsData.map((stat, index) => (
                <div className={styles.statCard} key={stat.label}>
                  <span className={styles.statValue}>{counters[index]}+</span>
                  <span className={styles.statLabel}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className={`${styles.heroImage} fadeInUp`} style={{ animationDelay: '0.4s' }}>
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Fokussiertes Lernteam arbeitet gemeinsam an einem Projekt"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className="section">
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">Metaskill im Fokus</p>
            <h2 className="sectionTitle">Lernen lernen – dein Hebel für jede Herausforderung</h2>
            <p className="sectionSubtitle">
              Wir unterstützen dich dabei, Lernkompetenz bewusst zu trainieren. Kein Druck, keine Überforderung – nur
              klare Schritte, Tools und Feedback-Loops, die du direkt nutzen kannst.
            </p>
          </div>
          <div className={`${styles.benefits} grid desktopThree`}>
            {benefits.map((benefit, index) => (
              <article className="card fadeInUp" style={{ animationDelay: `${0.1 * index}s` }} key={benefit.title}>
                <h3 className="cardTitle">{benefit.title}</h3>
                <p className="cardDescription">{benefit.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.topics} section`}>
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">Themen, die dich voranbringen</p>
            <h2 className="sectionTitle">Fokusbereiche, die du schrittweise vertiefst</h2>
          </div>
          <div className={`${styles.topicGrid} grid tabletTwo`}>
            {topics.map((topic, index) => (
              <article className={`${styles.topicCard} card fadeInUp`} style={{ animationDelay: `${0.1 * index}s` }} key={topic.title}>
                <h3>{topic.title}</h3>
                <p>{topic.body}</p>
                <Link to="/guide" className={styles.topicLink}>
                  Mehr erfahren
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.why} section`}>
        <div className="sectionInner">
          <div className={styles.whyContent}>
            <div className="sectionHeader" style={{ textAlign: 'left' }}>
              <p className="badge">Warum Tiloravento</p>
              <h2 className="sectionTitle">Realistisch, strukturiert und alltagstauglich</h2>
              <p className="sectionSubtitle">
                Wir fokussieren uns auf kleine, machbare Schritte. Keine Versprechen, keine Abkürzungen – sondern
                Routinen, die halten. Unsere Plattform ist keine psychologische Beratung, sondern ein verlässlicher
                Begleiter für kontinuierliche Lernentwicklung.
              </p>
            </div>
            <ul className={styles.whyList}>
              <li>Klare Lernpfade statt überladener Aufgabenlisten</li>
              <li>Reflexions-Impulse, die aus Erfahrung sprechen</li>
              <li>Tools, die du sofort anwenden kannst – analog oder digital</li>
              <li>Community-Impulse, um dranzubleiben ohne Druck</li>
            </ul>
          </div>
          <div className={styles.whyImage}>
            <img
              src="https://picsum.photos/800/600?random=2"
              alt="Strukturiertes Lernsetup mit Notizbuch und Fokus-Timer"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      <section className={`${styles.process} section`}>
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">Unser Prozess</p>
            <h2 className="sectionTitle">So entsteht dein klares Lernsystem</h2>
          </div>
          <div className={styles.processGrid}>
            {processSteps.map((step, index) => (
              <div className={`${styles.processCard} card fadeInUp`} style={{ animationDelay: `${0.1 * index}s` }} key={step.title}>
                <span className={styles.processStep}>{`0${index + 1}`}</span>
                <h3>{step.title}</h3>
                <p>{step.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.services} section`}>
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">Leistungen</p>
            <h2 className="sectionTitle">Formate, die dich gezielt unterstützen</h2>
            <p className="sectionSubtitle">
              Von kompakten Bootcamps bis zu flexiblen Routinen – unsere Programme geben dir Struktur und Motivation.
            </p>
          </div>
          <div className={`${styles.serviceCards} grid tabletTwo`}>
            <article className="card fadeInUp" style={{ animationDelay: '0.1s' }}>
              <h3 className="cardTitle">10-Tage-Schneller-lernen-Bootcamp</h3>
              <p className="cardDescription">
                Tägliche Mikro-Aufgaben, Reflexion und Fokus-Sessions schaffen deinen Einstieg in konsequentes Lernen.
              </p>
              <div className="cardMeta">
                <span className="statusChip">Dauer: 10 Tage</span>
                <span>Für dich, wenn du deinen Startschuss brauchst.</span>
              </div>
              <Link to="/programs" className={styles.cardLink}>
                Programm entdecken →
              </Link>
            </article>
            <article className="card fadeInUp" style={{ animationDelay: '0.2s' }}>
              <h3 className="cardTitle">30-Minuten-Tieflern-Sessions</h3>
              <p className="cardDescription">
                Strukturiere deine Fokusphasen mit klaren Timern, Check-ins und verbindlichen Abschlüssen.
              </p>
              <div className="cardMeta">
                <span className="statusChip">Format: Flexibel</span>
                <span>Für fokussierte Selbstlernzeit.</span>
              </div>
              <Link to="/programs" className={styles.cardLink}>
                Jetzt anwenden →
              </Link>
            </article>
            <article className="card fadeInUp" style={{ animationDelay: '0.3s' }}>
              <h3 className="cardTitle">Feedback & Reflexion-Routine</h3>
              <p className="cardDescription">
                Erstelle dein persönliches Reflexions-Board und sichere dein Feedback nach jeder Session.
              </p>
              <div className="cardMeta">
                <span className="statusChip">Wiederholung: Wöchentlich</span>
                <span>Für kontinuierliche Lernentwicklung.</span>
              </div>
              <Link to="/programs" className={styles.cardLink}>
                Mehr erfahren →
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className={`${styles.projects} section`}>
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">Lernprojekte</p>
            <h2 className="sectionTitle">Formate aus der Praxis</h2>
          </div>
          <div className={styles.filter}>
            {['Alle', 'Teamformat', 'Solo', 'Workshop'].map((filter) => (
              <button
                key={filter}
                type="button"
                className={`${styles.filterButton} ${projectFilter === filter ? styles.filterActive : ''}`}
                onClick={() => setProjectFilter(filter)}
              >
                {filter}
              </button>
            ))}
          </div>
          <div className={`${styles.projectGrid} grid tabletTwo`}>
            {projects.map((project, index) => (
              <article className={`${styles.projectCard} card fadeInUp`} style={{ animationDelay: `${0.1 * index}s` }} key={project.id}>
                <div className={styles.projectImage}>
                  <img src={`${project.image}&${index}`} alt={`${project.title} Projektübersicht`} loading="lazy" />
                </div>
                <div className={styles.projectContent}>
                  <span className="statusChip">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className={`${styles.testimonials} section`}>
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">Ehrliche Stimmen</p>
            <h2 className="sectionTitle">Was Lernende über Tiloravento sagen</h2>
          </div>
          <div className={styles.carousel} role="region" aria-live="polite">
            {testimonials.map((testimonial, index) => (
              <blockquote
                className={`${styles.testimonialCard} ${index === activeTestimonial ? styles.active : ''}`}
                key={testimonial.name}
              >
                <p>{testimonial.quote}</p>
                <footer>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </footer>
              </blockquote>
            ))}
            <div className={styles.carouselControls}>
              {testimonials.map((_, index) => (
                <button
                  type="button"
                  key={index}
                  className={index === activeTestimonial ? styles.dotActive : ''}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Testimonial ${index + 1} anzeigen`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className={`${styles.faq} section`}>
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">FAQ</p>
            <h2 className="sectionTitle">Häufige Fragen</h2>
          </div>
          <div className={styles.accordion}>
            {faqs.map((faq, index) => {
              const isOpen = expandedFaq === index;
              return (
                <div className={`${styles.accordionItem} ${isOpen ? styles.open : ''}`} key={faq.question}>
                  <button
                    type="button"
                    className={styles.accordionTrigger}
                    aria-expanded={isOpen}
                    onClick={() => setExpandedFaq(isOpen ? null : index)}
                  >
                    {faq.question}
                    <span aria-hidden="true">{isOpen ? '−' : '+'}</span>
                  </button>
                  <div className={styles.accordionPanel} hidden={!isOpen}>
                    <p>{faq.answer}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className={`${styles.blogPreview} section`}>
        <div className="sectionInner">
          <div className="sectionHeader">
            <p className="badge">Insights</p>
            <h2 className="sectionTitle">Neu im Blog</h2>
            <p className="sectionSubtitle">
              Frische Perspektiven rund um Lernpsychologie, Metaskills und Habit Building – in klarer, direkter Sprache.
            </p>
          </div>
          <div className={`${styles.blogGrid} grid tabletTwo`}>
            {blogPosts.slice(0, 3).map((post, index) => (
              <article className={`${styles.blogCard} card fadeInUp`} style={{ animationDelay: `${0.1 * index}s` }} key={post.slug}>
                <div className={styles.blogImage}>
                  <img src={`${post.cover}&preview=${index}`} alt={`${post.title} Artikelbild`} loading="lazy" />
                </div>
                <div className={styles.blogContent}>
                  <span className="statusChip">{post.category}</span>
                  <h3>{post.title}</h3>
                  <p>{post.excerpt}</p>
                  <div className={styles.blogMeta}>
                    <span>{post.readTime} Lesezeit</span>
                    <Link to={`/blog/${post.slug}`} className={styles.blogLink}>
                      Weiterlesen →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
          <div className={styles.blogCta}>
            <Link to="/blog" className="ctaButton secondary">
              Weitere Artikel ansehen
            </Link>
          </div>
        </div>
      </section>

      <section className={`${styles.finalCta} section`}>
        <div className="sectionInner">
          <div className={styles.finalCard}>
            <div>
              <p className="badge">Bereit für Klarheit?</p>
              <h2>Sichere dir deine ersten 10 Lern-Tage</h2>
              <p>
                Starte mit einer realistischen Routine, die in deinen Alltag passt. Ohne Druck, aber mit klaren Impulsen
                und Feedback-Loops. Du entscheidest das Tempo – Tiloravento hält dich auf Kurs.
              </p>
            </div>
            <div className={styles.finalActions}>
              <Link to="/programs" className="ctaButton">
                Programm starten
              </Link>
              <Link to="/contact" className="ctaButton secondary">
                Fragen stellen
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;