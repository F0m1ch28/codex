document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const siteNav = document.querySelector(".site-nav");
  const navLinks = document.querySelectorAll(".nav-menu a");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", () => {
      const expanded = navToggle.getAttribute("aria-expanded") === "true";
      navToggle.setAttribute("aria-expanded", !expanded);
      siteNav.classList.toggle("open");
    });

    navLinks.forEach(link => {
      link.addEventListener("click", () => {
        navToggle.setAttribute("aria-expanded", "false");
        siteNav.classList.remove("open");
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    });
  }

  const scrollTopBtn = document.getElementById("scrollTopBtn");
  if (scrollTopBtn) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 300) {
        scrollTopBtn.classList.add("show");
      } else {
        scrollTopBtn.classList.remove("show");
      }
    });

    scrollTopBtn.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  const cookieBanner = document.getElementById("cookieBanner");
  const cookieAccept = document.getElementById("cookieAccept");
  if (cookieBanner && cookieAccept) {
    const consent = localStorage.getItem("pde_cookie_consent");
    if (!consent) {
      setTimeout(() => cookieBanner.classList.add("show"), 500);
    }
    cookieAccept.addEventListener("click", () => {
      localStorage.setItem("pde_cookie_consent", "accepted");
      cookieBanner.classList.remove("show");
    });
  }

  const contactForm = document.getElementById("contactForm");
  const contactStatus = document.getElementById("contactStatus");
  if (contactForm && contactStatus) {
    contactForm.addEventListener("submit", (event) => {
      event.preventDefault();
      contactStatus.textContent = "Thank you for reaching out. A member of our team will contact you within one business day.";
      contactForm.reset();
    });
  }

  const newsletterForm = document.querySelector(".newsletter-form");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", (event) => {
      event.preventDefault();
      alert("Thank you for subscribing. Please check your inbox to confirm your subscription.");
      newsletterForm.reset();
    });
  }
});