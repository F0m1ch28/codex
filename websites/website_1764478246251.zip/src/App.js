import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import ScrollToTop from "./components/ScrollToTop";
import Home from "./pages/Home";
import About from "./pages/About";
import Services from "./pages/Services";
import Resources from "./pages/Resources";
import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import Privacy from "./pages/Privacy";
import Cookies from "./pages/Cookies";
import Terms from "./pages/Terms";

const DisclaimerModal = () => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("tuprogreso_disclaimer");
    if (!stored) {
      setIsOpen(true);
    }
  }, []);

  const handleClose = () => {
    localStorage.setItem("tuprogreso_disclaimer", "acknowledged");
    setIsOpen(false);
  };

  if (!isOpen) return null;

  return (
    <div className="disclaimer-backdrop" role="dialog" aria-modal="true">
      <div className="disclaimer-modal">
        <h2>Important Notice</h2>
        <p className="disclaimer-text">
          Мы не предоставляем финансовые услуги. <br />
          We do not provide financial services. <br />
          No brindamos servicios financieros.
        </p>
        <p>
          Tu Progreso Hoy is a platform focused on education and insights. The
          content is informational and should not be considered as personalized
          financial advice.
        </p>
        <button className="btn secondary" onClick={handleClose}>
          I Understand
        </button>
      </div>
    </div>
  );
};

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="app-shell">
        <Header />
        <main className="main-content" id="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/inflation" element={<About />} />
            <Route path="/course" element={<Services />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank-you" element={<ThankYou />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/cookies" element={<Cookies />} />
            <Route path="/terms" element={<Terms />} />
          </Routes>
        </main>
        <Footer />
        <CookieBanner />
        <DisclaimerModal />
      </div>
    </Router>
  );
}

export default App;