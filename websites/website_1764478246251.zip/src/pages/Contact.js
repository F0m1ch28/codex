import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    topic: "",
    message: "",
    consent: false
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!formData.consent) return;
    setSubmitted(true);
  };

  return (
    <div className="page-shell">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Contact Tu Progreso Hoy</h1>
          <p>
            We’re here to support your financial learning journey. Reach out for
            partnerships, media inquiries, or custom workshops.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container grid-2 contact-grid">
          <div>
            <h2>Our hub in Buenos Aires</h2>
            <p>
              Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina <br />
              Phone: <a href="tel:+541155551234">+54 11 5555-1234</a> <br />
              Email: <a href="mailto:hola@tuprogresohoy.com">hola@tuprogresohoy.com</a>
            </p>
            <div className="map-wrapper">
              <iframe
                title="Tu Progreso Hoy office in Buenos Aires"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.824884724621!2d-58.38248748477007!3d-34.60809208045861!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccaca98bbfb3f%3A0xf9c8771dc0b1345c!2sAv.%209%20de%20Julio%201000%2C%20C1043%20AAT%2C%20Buenos%20Aires%2C%20Argentina!5e0!3m2!1sen!2sar!4v1697046400000!5m2!1sen!2sar"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
            <div className="contact-social">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
                LinkedIn
              </a>
              <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
                Twitter
              </a>
              <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
                YouTube
              </a>
            </div>
          </div>
          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="form-field">
              <label htmlFor="contact-name">Name</label>
              <input
                id="contact-name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-field">
              <label htmlFor="contact-email">Email</label>
              <input
                id="contact-email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-field">
              <label htmlFor="contact-topic">Topic</label>
              <select
                id="contact-topic"
                name="topic"
                value={formData.topic}
                onChange={handleChange}
                required
              >
                <option value="">Select topic</option>
                <option value="partnerships">Partnerships</option>
                <option value="media">Media / Press</option>
                <option value="education">Education enquiry</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="form-field">
              <label htmlFor="contact-message">Message</label>
              <textarea
                id="contact-message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows="5"
                required
              ></textarea>
            </div>
            <div className="form-checkbox">
              <input
                id="contact-consent"
                name="consent"
                type="checkbox"
                checked={formData.consent}
                onChange={handleChange}
                required
              />
              <label htmlFor="contact-consent">
                I consent to being contacted in response to this inquiry and agree to the{" "}
                <a href="/privacy">Privacy Notice</a>.
              </label>
            </div>
            <button type="submit" className="btn primary">
              Send message
            </button>
            {submitted && (
              <p className="success-message">
                Thank you! We received your message and will respond within two business days.
              </p>
            )}
          </form>
        </div>
      </section>
    </div>
  );
};

export default Contact;