import React from "react";

const Terms = () => (
  <div className="page-shell">
    <section className="page-hero">
      <div className="container narrow">
        <h1>Terms of Use</h1>
        <p>
          Please read these terms carefully. By using Tu Progreso Hoy you agree to the
          conditions below.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container narrow legal-text">
        <h2>Purpose of the platform</h2>
        <p>
          Tu Progreso Hoy provides educational content about inflation, FX, and personal
          finance in Argentina. We do not offer financial, investment, or legal advice.
        </p>

        <h2>User responsibilities</h2>
        <ul>
          <li>Use the platform for lawful purposes.</li>
          <li>Respect intellectual property and community guidelines.</li>
          <li>Evaluate decisions independently or with a qualified advisor.</li>
        </ul>

        <h2>Intellectual property</h2>
        <p>
          Content, graphics, and tools are owned by Tu Progreso Hoy unless otherwise
          credited. You may not reproduce or distribute materials without permission.
        </p>

        <h2>Disclaimers</h2>
        <p>
          We strive for accuracy but cannot guarantee completeness. Use insights at your
          own risk. Мы не предоставляем финансовые услуги.
        </p>

        <h2>Changes</h2>
        <p>
          We may update these terms. Continued use after changes constitute acceptance.
        </p>

        <h2>Contact</h2>
        <p>
          For questions about these terms, email{" "}
          <a href="mailto:legal@tuprogresohoy.com">legal@tuprogresohoy.com</a>.
        </p>
      </div>
    </section>
  </div>
);

export default Terms;