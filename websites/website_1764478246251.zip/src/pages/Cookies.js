import React from "react";

const Cookies = () => (
  <div className="page-shell">
    <section className="page-hero">
      <div className="container narrow">
        <h1>Cookies Policy</h1>
        <p>
          This policy outlines how Tu Progreso Hoy uses cookies to enhance your
          experience and respects your choices.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container narrow legal-text">
        <h2>What are cookies?</h2>
        <p>
          Cookies are small data files stored on your device. They help remember
          preferences and track anonymous usage statistics.
        </p>

        <h2>Types of cookies</h2>
        <ul>
          <li>
            <strong>Essential:</strong> Required for core functionality such as secure
            logins and language settings.
          </li>
          <li>
            <strong>Analytics (optional):</strong> Help us understand how learners use
            our resources so we can improve content.
          </li>
        </ul>

        <h2>Your choices</h2>
        <p>
          You can accept or decline non-essential cookies via our opt-in banner.
          Browser settings also let you manage cookie preferences.
        </p>

        <h2>Contact</h2>
        <p>
          Questions? Email <a href="mailto:privacy@tuprogresohoy.com">privacy@tuprogresohoy.com</a>.
        </p>
      </div>
    </section>
  </div>
);

export default Cookies;