import React from "react";
import { Link, useLocation } from "react-router-dom";

const ThankYou = () => {
  const location = useLocation();
  const email = location.state?.email;

  return (
    <div className="page-shell">
      <section className="page-hero">
        <div className="container narrow centered">
          <h1>Thank you!</h1>
          <p>
            Your free trial request is confirmed. We sent lesson access details to{" "}
            <strong>{email || "your inbox"}</strong>. Remember to save us to your
            safe-sender list.
          </p>
          <p>
            Pasos acertados hoy, mejor futuro mañana. Explore the full course anytime and
            keep an eye on our inflation insights.
          </p>
          <div className="thankyou-actions">
            <Link to="/course" className="btn primary">
              View course modules
            </Link>
            <Link to="/inflation" className="btn ghost">
              Review inflation dashboards
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ThankYou;