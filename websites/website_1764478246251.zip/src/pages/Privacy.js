import React from "react";

const Privacy = () => (
  <div className="page-shell">
    <section className="page-hero">
      <div className="container narrow">
        <h1>Privacy Notice</h1>
        <p>
          Tu Progreso Hoy respects your privacy. This notice explains what data we
          collect, how we use it, and the choices you have.
        </p>
      </div>
    </section>

    <section className="section">
      <div className="container narrow legal-text">
        <h2>Information we collect</h2>
        <p>
          We collect the data you provide via forms, subscriptions, and interactions
          with our learning platform. This includes name, email, contact preferences,
          and analytics on resource usage.
        </p>

        <h2>How we use data</h2>
        <ul>
          <li>Deliver educational content and course updates</li>
          <li>Provide inflation and FX alerts tailored to Argentina</li>
          <li>Improve platform performance and accessibility</li>
          <li>Comply with legal obligations</li>
        </ul>

        <h2>Data retention</h2>
        <p>
          We retain data while you maintain an active relationship with Tu Progreso Hoy
          and for a reasonable period afterward to comply with regulations.
        </p>

        <h2>Your rights</h2>
        <p>
          You may request access, correction, deletion, or restriction of your data by
          contacting <a href="mailto:privacy@tuprogresohoy.com">privacy@tuprogresohoy.com</a>.
        </p>

        <h2>Security</h2>
        <p>
          We implement appropriate technical and organizational measures to protect
          your information. No method is entirely risk-free; we encourage responsible
          digital habits.
        </p>

        <h2>Updates</h2>
        <p>
          We may modify this notice to reflect changes in law or our practices. We will
          notify you of significant updates.
        </p>
      </div>
    </section>
  </div>
);

export default Privacy;