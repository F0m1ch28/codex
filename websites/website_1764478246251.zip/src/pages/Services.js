import React from "react";
import { Link } from "react-router-dom";

const modules = [
  {
    title: "Module 1 · Inflation Basics",
    description:
      "Understand CPI components, ARS dynamics, and how to interpret official vs. informal rates.",
    outcomes: [
      "Recognize key inflation drivers in Argentina",
      "Map personal exposure to rising costs",
      "Set observation routines to stay informed"
    ]
  },
  {
    title: "Module 2 · Budget Foundations",
    description:
      "Build a resilient budget that adapts to volatility with bilingual templates and SMART goals.",
    outcomes: [
      "Prioritize spending essentials",
      "Create buffers and emergency funds",
      "Communicate goals with your household"
    ]
  },
  {
    title: "Module 3 · Income & Opportunity",
    description:
      "Identify income diversification pathways and evaluate gig or freelance opportunities responsibly.",
    outcomes: [
      "Assess skills and market demand",
      "Calculate pricing considering inflation",
      "Design sustainable action plans"
    ]
  },
  {
    title: "Module 4 · Savings & Protection",
    description:
      "Explore savings instruments available in Argentina, understand trade-offs, and design protective habits.",
    outcomes: [
      "Compare savings vehicles objectively",
      "Link savings to short- and medium-term goals",
      "Document decision criteria to revisit"
    ]
  },
  {
    title: "Module 5 · Debt & Credit Health",
    description:
      "Evaluate credit conditions, adjust repayment strategies, and talk to lenders with confidence.",
    outcomes: [
      "Map debt portfolio and interest benchmarks",
      "Choose repayment tactics aligned with cashflow",
      "Prepare negotiation scripts"
    ]
  },
  {
    title: "Module 6 · Implementation & Review",
    description:
      "Turn insights into routines with accountability trackers, community support, and check-ins.",
    outcomes: [
      "Build a financial dashboard tailored to you",
      "Schedule monthly reviews",
      "Celebrate milestones and adjust thoughtfully"
    ]
  }
];

const audiences = [
  "Young professionals beginning their financial journey",
  "Families seeking structured budgeting conversations",
  "Freelancers navigating irregular incomes and inflation impact",
  "Small-business owners aligning cashflow with ARS volatility",
  "Students building foundational financial literacy"
];

const Services = () => {
  return (
    <div className="page-shell">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Personal Finance Starter Course</h1>
          <p>
            Información confiable que respalda elecciones responsables sobre tu
            dinero. This course provides bilingual guidance, practical tools, and a
            supportive community to turn insight into meaningful progress.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container narrow">
          <h2>What you will learn</h2>
          <p>
            Each module combines concise lessons, interactive exercises, and community
            reflections. You receive downloadable templates, curated articles, and
            optional Q&A sessions.
          </p>
        </div>
      </section>

      <section className="section alt">
        <div className="container module-grid">
          {modules.map((module) => (
            <article key={module.title} className="module-card">
              <h3>{module.title}</h3>
              <p>{module.description}</p>
              <ul>
                {module.outcomes.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="container grid-2">
          <div>
            <h2>Is this course for you?</h2>
            <p>
              The syllabus is built for different entry points. Whether you are
              managing your first salary, navigating family expenses, or running a
              small business, you will find actionable frameworks.
            </p>
          </div>
          <ul className="audience-list">
            {audiences.map((audience) => (
              <li key={audience}>{audience}</li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section outcome">
        <div className="container narrow">
          <h2>Course experience</h2>
          <div className="experience-grid">
            <div>
              <h3>Flexible formats</h3>
              <p>
                Video micro-lessons, audio summaries, transcripts, and practical
                worksheets accessible on mobile or desktop.
              </p>
            </div>
            <div>
              <h3>Community check-ins</h3>
              <p>
                Optional discussion threads and monthly live sessions to share tactics
                and celebrate progress.
              </p>
            </div>
            <div>
              <h3>Guided reflections</h3>
              <p>
                Decisiones responsables, objetivos nítidos become documented action
                plans with prompts to revisit and refine choices.
              </p>
            </div>
            <div>
              <h3>Trusted context</h3>
              <p>
                We connect each lesson to Argentina’s economic reality, leveraging our
                inflation and FX insights for practical application.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section cta">
        <div className="container cta-card">
          <div>
            <h2>Secure your spot in the next cohort</h2>
            <p>
              Pasos acertados hoy, mejor futuro mañana. Complete the double opt-in
              process to access the free introductory lesson.
            </p>
          </div>
          <a className="btn secondary" href="/#free-trial">
            Jump to free trial
          </a>
        </div>
      </section>
    </div>
  );
};

export default Services;