import React from "react";

const chartData = [
  { label: "Food & Beverages", value: 72 },
  { label: "Housing & Utilities", value: 64 },
  { label: "Transport", value: 58 },
  { label: "Education", value: 41 },
  { label: "Healthcare", value: 33 }
];

const About = () => {
  return (
    <div className="page-shell">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Inflation & FX Methodology</h1>
          <p>
            Our methodology delivers Datos verificados para planificar tu
            presupuesto. We connect official CPI releases, high-frequency market
            trackers, and crowd-sourced signals reviewed by economists.
          </p>
          <p className="highlight">
            Conocimiento financiero impulsado por tendencias so you can evaluate
            action steps with confidence.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container narrow">
          <h2>How we collect and validate data</h2>
          <ol className="method-list">
            <li>
              <strong>Government releases:</strong> INDEC CPI data, BCRA reports,
              and Ministry of Economy bulletins, with transparent referencing.
            </li>
            <li>
              <strong>Market indicators:</strong> Blue-chip swap, official FX,
              futures curve, and commodity prices relevant to Argentina.
            </li>
            <li>
              <strong>Field sampling:</strong> Weekly price sampling in major
              cities to detect early price shifts in essentials.
            </li>
            <li>
              <strong>Cross-validation:</strong> AI-assisted anomaly detection and
              human oversight to ensure integrity and highlight caveats.
            </li>
          </ol>
        </div>
      </section>

      <section className="section alt">
        <div className="container grid-2">
          <div>
            <h2>CPI & FX context, simplified</h2>
            <p>
              Every dashboard balances macro and daily life context. Decisiones
              responsables, objetivos nítidos start with understanding why prices
              change, how the ARS reacts, and what metrics can anchor your planning.
            </p>
            <p>
              We release weekly “Market Pulse” notes in English and Español (AR) so
              you can share insights with family, colleagues, or clients.
            </p>
            <p>
              Pasos acertados hoy, mejor futuro mañana means documenting choices,
              trade-offs, and building resilience over time.
            </p>
          </div>
          <div>
            <div className="chart-card">
              <h3>12-Month CPI Heatmap</h3>
              <p>Share of categories driving headline inflation · Oct 2023 – Sep 2024</p>
              <div className="bar-chart" aria-hidden="true">
                {chartData.map((item) => (
                  <div key={item.label} className="bar-row">
                    <span>{item.label}</span>
                    <div className="bar">
                      <div style={{ width: `${item.value}%` }}></div>
                    </div>
                    <span className="value">{item.value}%</span>
                  </div>
                ))}
              </div>
              <p className="chart-caption">
                Source: INDEC + Tu Progreso Hoy estimates. Updated monthly with the
                latest public release.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container narrow">
          <h2>Contextual narratives</h2>
          <p>
            Inflation is more than a single headline number. We track how shifts
            affect different segments: households, freelancers, SMBs, and students.
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera
            with narratives grounded in Argentine reality.
          </p>
          <ul className="pill-list">
            <li>Weekly FX watcher with scenario planning</li>
            <li>Household essentials radar (food, transport, education)</li>
            <li>Debt and credit health indicators</li>
            <li>Regional comparisons within Argentina</li>
          </ul>
        </div>
      </section>

      <section className="section alt">
        <div className="container narrow">
          <h2>FAQ</h2>
          <div className="faq-list">
            <div>
              <h3>What sources do you use for FX data?</h3>
              <p>
                Official BCRA references, free-market indicators, and reputable data
                vendors. We highlight spreads and divergences so you can interpret
                scenarios realistically.
              </p>
            </div>
            <div>
              <h3>Is there guidance on how to apply this data?</h3>
              <p>
                Yes. We illustrate use cases with templates and stories, but decisions
                remain yours. Información confiable que respalda elecciones responsables
                sobre tu dinero, without promising outcomes.
              </p>
            </div>
            <div>
              <h3>How frequently are insights updated?</h3>
              <p>
                CPI dashboards refresh monthly, while FX and price trackers update
                multiple times per week. Alerts highlight notable shifts or emerging
                risks so you can adapt quickly.
              </p>
            </div>
            <div>
              <h3>Do you cover provincial differences?</h3>
              <p>
                We present aggregated national data and supplement it with focused
                deep-dives when provincial trends diverge significantly.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section cta">
        <div className="container cta-card">
          <div>
            <h2>Turn knowledge into proactive planning</h2>
            <p>
              Explore the personal finance starter course to apply these insights to
              your day-to-day decisions.
            </p>
          </div>
          <a className="btn secondary" href="/#free-trial">
            Start for free
          </a>
        </div>
      </section>
    </div>
  );
};

export default About;