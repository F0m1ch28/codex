import React from "react";

const resources = [
  {
    title: "CPI Release Walkthrough (October 2024)",
    description:
      "Understand the key drivers behind the latest CPI print and how they affect everyday spending.",
    language: "EN",
    link: "#"
  },
  {
    title: "Glosario esencial de finanzas personales",
    description:
      "Términos indispensables en español para hablar de presupuesto, inflación y decisiones financieras.",
    language: "ES",
    link: "#"
  },
  {
    title: "Guide: Setting Inflation-Adjusted Goals",
    description:
      "Craft goals that remain relevant even when the ARS shifts, with examples from Buenos Aires and Córdoba.",
    language: "EN",
    link: "#"
  },
  {
    title: "Checklist: Preparar la conversación familiar",
    description:
      "Pasos prácticos para alinear prioridades y responsabilidades en tu hogar sin tensiones innecesarias.",
    language: "ES",
    link: "#"
  },
  {
    title: "Blueprint: Freelancer Cashflow Resilience",
    description:
      "Templates to match project pipelines with living costs and emergency buffers.",
    language: "EN",
    link: "#"
  }
];

const Resources = () => {
  return (
    <div className="page-shell">
      <section className="page-hero">
        <div className="container narrow">
          <h1>Resource Library</h1>
          <p>
            Access bilingual articles, glossaries, and worksheets curated for Argentina.
            Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera
            con apoyo continuo.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container resource-grid">
          {resources.map((resource) => (
            <article key={resource.title} className="resource-card">
              <span className="tag">{resource.language}</span>
              <h3>{resource.title}</h3>
              <p>{resource.description}</p>
              <a href={resource.link} className="text-link">
                Access resource →
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="section cta">
        <div className="container cta-card">
          <div>
            <h2>Need tailored guidance for your team?</h2>
            <p>
              Connect with us to explore workshops, webinars, or custom toolkits for
              your organization in Argentina.
            </p>
          </div>
          <a className="btn secondary" href="/contact">
            Contact us
          </a>
        </div>
      </section>
    </div>
  );
};

export default Resources;