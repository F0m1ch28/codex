import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const statsData = [
  { id: 1, label: "Monthly CPI datapoints tracked", target: 180 },
  { id: 2, label: "Learners enrolled since launch", target: 1250 },
  { id: 3, label: "Practical exercises available", target: 48 },
  { id: 4, label: "Curated ARS → USD updates / month", target: 12 }
];

const testimonials = [
  {
    quote:
      "The inflation dashboards helped me set realistic savings milestones without panic-driven decisions.",
    name: "Marina S.",
    title: "Buenos Aires, Product Analyst"
  },
  {
    quote:
      "Conocimiento financiero impulsado por tendencias me dio argumentos sólidos para dialogar en casa sobre presupuesto.",
    name: "Diego L.",
    title: "Córdoba, Software Engineer"
  },
  {
    quote:
      "As a newcomer to finance, I appreciate how transparent the methodology is and how each module builds confidence.",
    name: "Lucía P.",
    title: "Rosario, UX Designer"
  }
];

const projects = [
  {
    id: 1,
    title: "Inflation Stress-Test Simulator",
    category: "Analytics",
    img: "https://picsum.photos/1200/800?random=4",
    description:
      "Scenario planning tool that layers CPI projections with ARS → USD sensitivities for weekly recalibration."
  },
  {
    id: 2,
    title: "Starter Budget Canvas",
    category: "Education",
    img: "https://picsum.photos/1200/800?random=5",
    description:
      "Step-by-step budgeting template integrating Datos verificados para planificar tu presupuesto."
  },
  {
    id: 3,
    title: "Exchange Rate Pulse",
    category: "Analytics",
    img: "https://picsum.photos/1200/800?random=6",
    description:
      "Real-time ticker with Decisiones responsables, objetivos nítidos for daily financial routines."
  }
];

const faqItems = [
  {
    q: "How often is the ARS → USD tracker refreshed?",
    a: "We refresh market data several times per day using transparent aggregator sources. When live feeds are unavailable, we reference the latest verified official update and clearly mark the timestamp."
  },
  {
    q: "Is Tu Progreso Hoy offering investment advice?",
    a: "No. Plataforma educativa con datos esenciales, sin asesoría financiera directa. Our role is to simplify information and learning."
  },
  {
    q: "Can I access materials in Spanish?",
    a: "Sí. Most dashboards and course notes offer bilingual toggles: English by default with Español (Argentina) secondary."
  },
  {
    q: "What makes this course different?",
    a: "Análisis transparentes y datos de mercado para decidir con seguridad, paired with practical checklists so you can apply concepts to your day-to-day budget."
  }
];

const Home = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState(statsData.map((item) => ({ ...item, value: 0 })));
  const [rate, setRate] = useState(null);
  const [rateError, setRateError] = useState("");
  const [rateTime, setRateTime] = useState("");
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [projectFilter, setProjectFilter] = useState("All");
  const [faqOpen, setFaqOpen] = useState(faqItems[0].q);
  const [formStep, setFormStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    confirm: "",
    consent: false,
    doubleOptIn: false
  });
  const [formErrors, setFormErrors] = useState({});
  const filteredProjects = useMemo(() => {
    if (projectFilter === "All") return projects;
    return projects.filter((project) => project.category === projectFilter);
  }, [projectFilter]);

  useEffect(() => {
    const fetchRate = async () => {
      try {
        const response = await fetch(
          "https://api.exchangerate.host/latest?base=ARS&symbols=USD"
        );
        const data = await response.json();
        if (data && data.rates && data.rates.USD) {
          setRate(1 / data.rates.USD);
          setRateTime(new Date(data.date).toLocaleString("en-AR"));
        } else {
          throw new Error("No rate data");
        }
      } catch (error) {
        setRate(0.0039);
        setRateTime(new Date().toLocaleString("en-AR"));
        setRateError("Live feed unavailable; showing latest verified value.");
      }
    };
    fetchRate();
    const interval = setInterval(fetchRate, 1000 * 60 * 30);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const intervals = statsData.map((item, index) => {
      return setInterval(() => {
        setStats((prev) => {
          const updated = [...prev];
          const current = updated[index];
          if (current.value < item.target) {
            updated[index] = {
              ...current,
              value: Math.min(current.value + Math.ceil(item.target / 60), item.target)
            };
          }
          return updated;
        });
      }, 40);
    });
    return () => intervals.forEach((i) => clearInterval(i));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const handleProjectFilter = (category) => {
    setProjectFilter(category);
  };

  const handleFaqToggle = (question) => {
    setFaqOpen((prev) => (prev === question ? "" : question));
  };

  const validateStep = () => {
    const errors = {};
    if (formStep === 1) {
      if (!formData.name.trim()) errors.name = "Name is required.";
      if (!formData.email.trim()) {
        errors.email = "Email is required.";
      } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(formData.email)) {
        errors.email = "Please provide a valid email.";
      }
      if (!formData.consent) {
        errors.consent = "Consent is required.";
      }
    }
    if (formStep === 2) {
      if (!formData.doubleOptIn) {
        errors.doubleOptIn = "Please confirm you verified the email.";
      }
      if (formData.confirm.trim().toUpperCase() !== "SI") {
        errors.confirm = "Type SI after confirming your inbox.";
      }
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    if (!validateStep()) return;
    if (formStep === 1) {
      setFormStep(2);
    } else {
      navigate("/thank-you", { state: { email: formData.email } });
    }
  };

  return (
    <div>
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="hero-kicker">Argentina · Financial Education</span>
            <h1>Navigate ARS → USD shifts with clarity and confidence</h1>
            <p>
              Análisis transparentes y datos de mercado para decidir con seguridad.
              Información confiable que respalda elecciones responsables sobre tu
              dinero. Pasos acertados hoy, mejor futuro mañana.
            </p>
            <div className="hero-actions">
              <Link className="btn primary" to="/inflation">
                Explore Inflation Insights
              </Link>
              <a className="btn ghost" href="/#free-trial">
                Получить бесплатный пробный урок
              </a>
            </div>
            <ul className="hero-promises">
              <li>Datos verificados para planificar tu presupuesto.</li>
              <li>Decisiones responsables, objetivos nítidos.</li>
              <li>Sigue las tendencias, identifica oportunidades y diseña tu ruta financiera.</li>
            </ul>
          </div>
          <div className="hero-visual">
            <div className="hero-flag-overlay" aria-hidden="true"></div>
            <img
              src="https://picsum.photos/1600/900?random=1"
              alt="Professional teamwork discussing financial charts"
              loading="lazy"
            />
            <div className="rate-card" role="status">
              <h3>ARS → USD Tracker</h3>
              <p className="rate-value">
                {rate ? rate.toFixed(4) : "..."} <span>USD</span>
              </p>
              <p className="rate-time">{rateTime}</p>
              {rateError && <p className="rate-error">{rateError}</p>}
            </div>
          </div>
        </div>
      </section>

      <section className="section stats">
        <div className="container">
          <div className="section-heading">
            <h2>Building financial confidence through transparent metrics</h2>
            <p>
              Conocimiento financiero impulsado por tendencias y práctica constante.
              De la información al aprendizaje: fortalece tu criterio financiero paso a paso.
            </p>
          </div>
          <div className="stats-grid">
            {stats.map((item) => (
              <article key={item.id} className="stat-card">
                <span className="stat-number">{item.value}</span>
                <span className="stat-label">{item.label}</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section insights">
        <div className="container grid-2">
          <div>
            <h2>Insight Engine crafted for Argentina</h2>
            <p>
              We contextualize inflation and FX signals in plain English and Español
              so you can monitor structural shifts, seasonal spikes, and consumer
              price expectations without overwhelming data dumps.
            </p>
            <ul className="check-list">
              <li>Weekly CPI context digest, ready to review in under five minutes.</li>
              <li>Scenario planning worksheets aligning lifestyle goals with ARS volatility.</li>
              <li>Easy-to-use dashboards for household budget, small business cashflow, and saving journeys.</li>
            </ul>
            <Link to="/inflation" className="text-link">
              Discover the methodology →
            </Link>
          </div>
          <div className="insight-cards">
            <article>
              <h3>Macro & Micro Blend</h3>
              <p>
                We combine macro drivers with everyday impact: grocery baskets,
                transport costs, and evolving purchasing power.
              </p>
            </article>
            <article>
              <h3>Community Signals</h3>
              <p>
                Real narratives from nuestra comunidad so you see how peers adapt,
                learn, and design resilient budgets.
              </p>
            </article>
            <article>
              <h3>Action Templates</h3>
              <p>
                Decisiones responsables, objetivos nítidos converging into checklists,
                conversation guides, and SMART goal trackers.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section process">
        <div className="container">
          <div className="section-heading centered">
            <h2>Your learning journey in four actionable stages</h2>
            <p>Pasos acertados hoy, mejor futuro mañana.</p>
          </div>
          <div className="process-grid">
            <article>
              <span className="step">01</span>
              <h3>Discover</h3>
              <p>
                Review ARS → USD shifts with historical context. Understand what each
                indicator is telling you and why it matters this week.
              </p>
            </article>
            <article>
              <span className="step">02</span>
              <h3>Diagnose</h3>
              <p>
                Use data-driven assessments to benchmark your current budget, savings,
                and exposure to inflation pressure.
              </p>
            </article>
            <article>
              <span className="step">03</span>
              <h3>Design</h3>
              <p>
                Translate insights into financial routines: priorities, buffers, and
                new opportunities that align with your goals.
              </p>
            </article>
            <article>
              <span className="step">04</span>
              <h3>Decide</h3>
              <p>
                Keep decision logs, evaluate options, and iterate with confidence
                using our feedback loops and community discussions.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section services">
        <div className="container">
          <div className="section-heading">
            <h2>Core pillars of Tu Progreso Hoy</h2>
            <p>
              Information confiable that supports responsible choices, designed for
              Argentina’s dynamic context.
            </p>
          </div>
          <div className="service-cards">
            <article>
              <h3>Inflation Pulseboards</h3>
              <p>
                Daily updates, CPI breakdowns, and time-saving commentary focusing on
                household impacts.
              </p>
              <Link to="/inflation" className="text-link">
                Learn more →
              </Link>
            </article>
            <article>
              <h3>Personal Finance Starter Course</h3>
              <p>
                6 modules guiding you from awareness to action with bilingual toolkits
                and real-life scenarios.
              </p>
              <Link to="/course" className="text-link">
                View syllabus →
              </Link>
            </article>
            <article>
              <h3>Resource Library</h3>
              <p>
                Articles, glossaries, and community Q&A curated to strengthen your
                decision-making muscle.
              </p>
              <Link to="/resources" className="text-link">
                Browse resources →
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section className="section testimonials">
        <div className="container">
          <div className="section-heading centered">
            <h2>Voices from our community</h2>
            <p>
              De la información al aprendizaje: fortalece tu criterio financiero paso
              a paso.
            </p>
          </div>
          <div className="testimonial-slider" role="region" aria-live="polite">
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.name}
                className={`testimonial-card ${
                  index === activeTestimonial ? "active" : ""
                }`}
              >
                <p className="quote">“{testimonial.quote}”</p>
                <div className="author">
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.title}</span>
                </div>
              </article>
            ))}
            <div className="slider-controls">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  className={index === activeTestimonial ? "active" : ""}
                  onClick={() => setActiveTestimonial(index)}
                  aria-label={`Show testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section team">
        <div className="container">
          <div className="section-heading">
            <h2>Meet the team designing your learning journey</h2>
            <p>
              A multi-disciplinary crew connecting economic signals with practical
              guidance for everyday decisions.
            </p>
          </div>
          <div className="team-grid">
            <article className="team-card">
              <img
                src="https://picsum.photos/400/400?random=3"
                alt="Team lead analyzing data trends"
                loading="lazy"
              />
              <h3>Camila Herrera</h3>
              <p>Lead Economist · Buenos Aires</p>
              <p className="team-bio">
                Former INDEC analyst translating macroeconomic datasets into digestible
                visuals that empower households to act thoughtfully.
              </p>
            </article>
            <article className="team-card">
              <img
                src="https://picsum.photos/400/400?random=7"
                alt="Learning designer sketching course modules"
                loading="lazy"
              />
              <h3>Mateo González</h3>
              <p>Learning Architect · Córdoba</p>
              <p className="team-bio">
                Passionate about inclusive pedagogy, Mateo ensures each module is
                bilingual, scenario-based, and friendly for first-time learners.
              </p>
            </article>
            <article className="team-card">
              <img
                src="https://picsum.photos/400/400?random=8"
                alt="Community manager hosting financial workshop"
                loading="lazy"
              />
              <h3>Fernanda Ruiz</h3>
              <p>Community & Research · Mendoza</p>
              <p className="team-bio">
                She captures real stories and strategies from nuestra comunidad to keep
                the platform grounded in daily realities.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section className="section projects">
        <div className="container">
          <div className="section-heading">
            <h2>Selected initiatives shaping proactive money habits</h2>
            <p>
              Explore how we convert trends into actionable frameworks suitable for
              Argentina’s evolving economy.
            </p>
          </div>
          <div className="project-filters">
            {["All", "Analytics", "Education"].map((category) => (
              <button
                key={category}
                className={`filter-btn ${
                  projectFilter === category ? "active" : ""
                }`}
                onClick={() => handleProjectFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="project-grid">
            {filteredProjects.map((project) => (
              <article key={project.id} className="project-card">
                <img
                  src={project.img}
                  alt={`${project.title} visualization`}
                  loading="lazy"
                />
                <div className="project-body">
                  <span className="tag">{project.category}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <Link to="/resources" className="text-link">
                    Explore related resources →
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section faq">
        <div className="container grid-2">
          <div>
            <h2>Frequently Asked Questions</h2>
            <p>
              Still curious? Find additional context on how Tu Progreso Hoy supports
              your learning path.
            </p>
            <Link to="/contact" className="btn ghost">
              Ask a question
            </Link>
          </div>
          <div className="accordion">
            {faqItems.map((item) => (
              <div
                key={item.q}
                className={`accordion-item ${
                  faqOpen === item.q ? "open" : ""
                }`}
              >
                <button
                  className="accordion-trigger"
                  onClick={() => handleFaqToggle(item.q)}
                  aria-expanded={faqOpen === item.q}
                >
                  {item.q}
                </button>
                <div className="accordion-content">
                  <p>{item.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section blog">
        <div className="container">
          <div className="section-heading">
            <h2>Latest insights & updates</h2>
            <p>
              Stay tuned with community stories, CPI briefs, and bilingual insights to
              guide your budget adjustments.
            </p>
          </div>
          <div className="blog-grid">
            <article className="blog-card">
              <img
                src="https://picsum.photos/800/600?random=2"
                alt="Notebook with inflation charts"
                loading="lazy"
              />
              <div className="blog-body">
                <span className="tag">EN</span>
                <h3>How to align monthly goals with inflation signals</h3>
                <p>
                  Use our short worksheet to prioritize spending, savings, and debt
                  payments amid price fluctuations.
                </p>
                <Link to="/resources" className="text-link">
                  Read more →
                </Link>
              </div>
            </article>
            <article className="blog-card">
              <img
                src="https://picsum.photos/800/600?random=9"
                alt="Team reviewing budget strategies"
                loading="lazy"
              />
              <div className="blog-body">
                <span className="tag">ES</span>
                <h3>
                  Tres formas de conversar sobre presupuesto familiar sin tensión
                </h3>
                <p>
                  Dialoga con empatía y enfoque compartido para alinear objetivos,
                  ingresos y gastos en tu hogar.
                </p>
                <Link to="/resources" className="text-link">
                  Leer más →
                </Link>
              </div>
            </article>
            <article className="blog-card">
              <img
                src="https://picsum.photos/800/600?random=10"
                alt="Laptop showing ARS to USD chart"
                loading="lazy"
              />
              <div className="blog-body">
                <span className="tag">EN</span>
                <h3>Understanding ARS devaluation scenarios</h3>
                <p>
                  Evaluate different exchange-rate trajectories and build buffers so
                  you're prepared for short-term volatility.
                </p>
                <Link to="/inflation" className="text-link">
                  Explore →
                </Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="section cta">
        <div className="container cta-card">
          <div>
            <h2>Ready to transform data into daily financial decisions?</h2>
            <p>
              Información confiable que respalda elecciones responsables sobre tu
              dinero. Start with our guided personal finance course, built for
              Argentina.
            </p>
          </div>
          <a className="btn secondary" href="/#free-trial">
            Join the next cohort
          </a>
        </div>
      </section>

      <section className="section free-trial" id="free-trial">
        <div className="container">
          <div className="section-heading centered">
            <h2>Получить бесплатный пробный урок</h2>
            <p>
              Complete the two-step process to access the introductory module and
              verify your subscription. Double opt-in ensures secure enrollment.
            </p>
          </div>
          <form className="free-trial-form" onSubmit={handleFormSubmit}>
            {formStep === 1 && (
              <>
                <div className="form-field">
                  <label htmlFor="trial-name">Full Name</label>
                  <input
                    id="trial-name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, name: e.target.value }))
                    }
                    required
                  />
                  {formErrors.name && <span className="error">{formErrors.name}</span>}
                </div>
                <div className="form-field">
                  <label htmlFor="trial-email">Email</label>
                  <input
                    id="trial-email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, email: e.target.value }))
                    }
                    required
                  />
                  {formErrors.email && <span className="error">{formErrors.email}</span>}
                </div>
                <div className="form-field">
                  <label htmlFor="trial-phone">Phone (optional)</label>
                  <input
                    id="trial-phone"
                    name="phone"
                    type="tel"
                    autoComplete="tel"
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, phone: e.target.value }))
                    }
                    placeholder="+54 ..."
                  />
                </div>
                <div className="form-checkbox">
                  <input
                    id="trial-consent"
                    name="consent"
                    type="checkbox"
                    checked={formData.consent}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        consent: e.target.checked
                      }))
                    }
                    required
                  />
                  <label htmlFor="trial-consent">
                    I agree to receive educational emails and acknowledge the{" "}
                    <Link to="/privacy">Privacy Notice</Link>.
                  </label>
                  {formErrors.consent && <span className="error">{formErrors.consent}</span>}
                </div>
                <button type="submit" className="btn primary full">
                  Step 1 · Request access
                </button>
              </>
            )}
            {formStep === 2 && (
              <>
                <p className="double-optin-message">
                  We sent a confirmation link to <strong>{formData.email}</strong>.
                  Open the email, click the confirmation button, then finish this step.
                </p>
                <div className="form-checkbox">
                  <input
                    id="trial-double"
                    name="doubleOptIn"
                    type="checkbox"
                    checked={formData.doubleOptIn}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        doubleOptIn: e.target.checked
                      }))
                    }
                    required
                  />
                  <label htmlFor="trial-double">
                    I have clicked the confirmation link in my email.
                  </label>
                  {formErrors.doubleOptIn && (
                    <span className="error">{formErrors.doubleOptIn}</span>
                  )}
                </div>
                <div className="form-field">
                  <label htmlFor="trial-confirm">
                    Type <strong>SI</strong> to complete the double opt-in
                  </label>
                  <input
                    id="trial-confirm"
                    name="confirm"
                    type="text"
                    value={formData.confirm}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, confirm: e.target.value }))
                    }
                    required
                  />
                  {formErrors.confirm && <span className="error">{formErrors.confirm}</span>}
                </div>
                <button type="submit" className="btn secondary full">
                  Step 2 · Unlock trial lesson
                </button>
              </>
            )}
          </form>
          <p className="trial-note">
            Plataforma educativa con datos esenciales, sin asesoría financiera directa.
            Мы не предоставляем финансовые услуги.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Home;