import React, { useEffect, useState } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);
  const [isAccepted, setIsAccepted] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem("tph_cookie_choice");
    if (!stored) {
      setVisible(true);
    } else {
      setIsAccepted(stored === "accepted");
    }
  }, []);

  const handleChoice = (choice) => {
    localStorage.setItem("tph_cookie_choice", choice);
    setIsAccepted(choice === "accepted");
    setVisible(false);
  };

  if (!visible || isAccepted !== null) return null;

  return (
    <div className="cookie-banner" role="dialog" aria-live="polite">
      <p>
        We use analytical cookies to understand engagement with our educational
        materials. Please choose if you consent to optional cookies.
      </p>
      <div className="cookie-actions">
        <button className="btn secondary" onClick={() => handleChoice("declined")}>
          Decline
        </button>
        <button className="btn primary" onClick={() => handleChoice("accepted")}>
          Accept
        </button>
      </div>
    </div>
  );
};

export default CookieBanner;