import React, { useState, useEffect } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";

const navItems = [
  { label: "Insights", path: "/inflation" },
  { label: "Course", path: "/course" },
  { label: "Resources", path: "/resources" },
  { label: "Contact", path: "/contact" }
];

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <header className="site-header">
      <div className="container header-container">
        <Link to="/" className="logo" aria-label="Tu Progreso Hoy home">
          <span className="logo-mark">TP</span>
          <span className="logo-text">Tu Progreso Hoy</span>
        </Link>
        <nav className={`nav ${isOpen ? "open" : ""}`} aria-label="Main menu">
          <ul>
            <li>
              <NavLink to="/" end>
                Home
              </NavLink>
            </li>
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink to={item.path}>{item.label}</NavLink>
              </li>
            ))}
            <li>
              <a href="/#free-trial" className="cta-link">
                Free Trial
              </a>
            </li>
          </ul>
        </nav>
        <button
          className={`menu-toggle ${isOpen ? "active" : ""}`}
          onClick={() => setIsOpen(!isOpen)}
          aria-expanded={isOpen}
          aria-controls="primary-navigation"
        >
          <span className="sr-only">Toggle navigation</span>
          <span className="menu-bar"></span>
          <span className="menu-bar"></span>
          <span className="menu-bar"></span>
        </button>
      </div>
    </header>
  );
};

export default Header;