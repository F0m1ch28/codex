import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="site-footer" aria-label="Footer">
      <div className="container footer-grid">
        <div className="footer-brand">
          <div className="logo-footer">
            <span className="logo-mark">TP</span>
            <span className="logo-text">Tu Progreso Hoy</span>
          </div>
          <p>
            Datos verificados para planificar tu presupuesto. Tu base de
            educación financiera responsable en Argentina.
          </p>
          <p className="footer-disclaimer">
            Plataforma educativa con datos esenciales, sin asesoría financiera
            directa.
          </p>
        </div>
        <div>
          <h3>Explore</h3>
          <ul>
            <li>
              <Link to="/inflation">Inflation Insights</Link>
            </li>
            <li>
              <Link to="/course">Course Overview</Link>
            </li>
            <li>
              <Link to="/resources">Resources</Link>
            </li>
            <li>
              <a href="/#free-trial">Try for Free</a>
            </li>
          </ul>
        </div>
        <div>
          <h3>Contact</h3>
          <ul>
            <li>Av. 9 de Julio 1000, C1043 Buenos Aires, Argentina</li>
            <li>
              Phone:{" "}
              <a href="tel:+541155551234" aria-label="Phone">
                +54 11 5555-1234
              </a>
            </li>
            <li>
              Email:{" "}
              <a href="mailto:hola@tuprogresohoy.com">
                hola@tuprogresohoy.com
              </a>
            </li>
            <li>
              <div className="footer-social">
                <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">
                  LinkedIn
                </a>
                <a href="https://www.twitter.com" target="_blank" rel="noreferrer">
                  Twitter
                </a>
                <a href="https://www.youtube.com" target="_blank" rel="noreferrer">
                  YouTube
                </a>
              </div>
            </li>
          </ul>
        </div>
        <div>
          <h3>Legal</h3>
          <ul>
            <li>
              <Link to="/privacy">Privacy Notice</Link>
            </li>
            <li>
              <Link to="/cookies">Cookies</Link>
            </li>
            <li>
              <Link to="/terms">Terms of Use</Link>
            </li>
            <li>
              <a href="/sitemap.xml">Sitemap</a>
            </li>
          </ul>
          <div className="footer-language">
            <span>EN</span> | <span>ES</span>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <small>&copy; {new Date().getFullYear()} Tu Progreso Hoy. All rights reserved.</small>
      </div>
    </footer>
  );
};

export default Footer;