document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.querySelector(".nav-menu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            navMenu.classList.toggle("active");
        });
    }

    const cookieBanner = document.querySelector(".cookie-banner");
    const acceptBtn = document.querySelector(".cookie-actions button.accept");
    const declineBtn = document.querySelector(".cookie-actions button.decline");
    const storedConsent = localStorage.getItem("cargolzsao_cookie_consent");

    function setConsent(status) {
        localStorage.setItem("cargolzsao_cookie_consent", status);
        if (cookieBanner) {
            cookieBanner.classList.add("hidden");
        }
        const anchor = status === "accepted" ? "#consent-accepted" : "#consent-declined";
        window.location.href = `cookies.html${anchor}`;
    }

    if (cookieBanner && storedConsent) {
        cookieBanner.classList.add("hidden");
    }

    if (cookieBanner && acceptBtn) {
        acceptBtn.addEventListener("click", () => setConsent("accepted"));
    }

    if (cookieBanner && declineBtn) {
        declineBtn.addEventListener("click", () => setConsent("declined"));
    }

    const contactForm = document.querySelector("#contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();
            const requiredFields = contactForm.querySelectorAll("[data-required]");
            let valid = true;

            requiredFields.forEach((field) => {
                if (!field.value.trim()) {
                    valid = false;
                    field.setAttribute("aria-invalid", "true");
                    field.classList.add("input-error");
                } else {
                    field.removeAttribute("aria-invalid");
                    field.classList.remove("input-error");
                }
            });

            if (valid) {
                window.location.href = "thanks.html";
            }
        });
    }

    const searchInput = document.querySelector("#post-search");
    const filterButtons = document.querySelectorAll("[data-filter]");
    const postCards = document.querySelectorAll("[data-category]");

    function filterPosts(criteria) {
        const query = searchInput ? searchInput.value.toLowerCase() : "";
        postCards.forEach((card) => {
            const category = card.getAttribute("data-category");
            const keywords = card.getAttribute("data-keywords") || "";
            const title = card.querySelector(".card-title") ? card.querySelector(".card-title").textContent.toLowerCase() : "";
            const textMatch = title.includes(query) || keywords.toLowerCase().includes(query);
            const categoryMatch = criteria === "all" || category === criteria;
            if (textMatch && categoryMatch) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", () => {
            const activeFilter = document.querySelector(".filter-button.active");
            const currentFilter = activeFilter ? activeFilter.getAttribute("data-filter") : "all";
            filterPosts(currentFilter);
        });
    }

    filterButtons.forEach((button) => {
        button.addEventListener("click", () => {
            filterButtons.forEach((btn) => btn.classList.remove("active"));
            button.classList.add("active");
            const criteria = button.getAttribute("data-filter");
            filterPosts(criteria);
        });
    });
});