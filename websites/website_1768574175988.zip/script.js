document.addEventListener('DOMContentLoaded', function () {
    const navToggle = document.querySelector('.nav-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navToggle.classList.toggle('is-active');
            navLinks.classList.toggle('is-open');
        });

        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navToggle.classList.remove('is-active');
                navLinks.classList.remove('is-open');
            });
        });
    }

    const banner = document.querySelector('.cookie-banner');
    const acceptBtn = document.querySelector('.cookie-btn.primary');
    const declineBtn = document.querySelector('.cookie-btn.secondary');
    const storageKey = 'nyquisegpf-cookie-choice';

    if (banner) {
        const decision = localStorage.getItem(storageKey);
        if (!decision) {
            banner.classList.add('is-visible');
        }

        const handleDecision = value => {
            localStorage.setItem(storageKey, value);
            banner.classList.remove('is-visible');
        };

        if (acceptBtn) {
            acceptBtn.addEventListener('click', () => handleDecision('accepted'));
        }
        if (declineBtn) {
            declineBtn.addEventListener('click', () => handleDecision('declined'));
        }
    }
});