const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');
const cookieBanner = document.querySelector('.cookie-banner');
const cookieButtons = document.querySelectorAll('.cookie-button');

if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', String(!expanded));
        navLinks.classList.toggle('is-open');
    });
}

function setActiveNav() {
    const path = window.location.pathname.split('/').pop() || 'index.html';
    const currentLink = document.querySelector(`a[href="${path}"]`);
    if (currentLink) {
        currentLink.setAttribute('aria-current', 'page');
    }
}
setActiveNav();

function handleCookieBanner() {
    if (!cookieBanner) return;
    const consent = localStorage.getItem('screwbjgel_cookie_consent');
    if (!consent) {
        cookieBanner.classList.add('is-visible');
    }
}
handleCookieBanner();

cookieButtons.forEach(button => {
    button.addEventListener('click', event => {
        event.preventDefault();
        const choice = button.dataset.choice;
        localStorage.setItem('screwbjgel_cookie_consent', choice);
        cookieBanner.classList.remove('is-visible');
        const target = button.getAttribute('href');
        if (target) {
            window.open(target, '_blank', 'noopener');
        }
    });
});