```javascript
document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const siteNav = document.querySelector('.site-nav');

  if (navToggle && siteNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = siteNav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
      document.body.classList.toggle('nav-open', isOpen);
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth >= 768 && siteNav.classList.contains('is-open')) {
        siteNav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('nav-open');
      }
    });
  }

  const cookieBanner = document.getElementById('cookieBanner');
  const consentKey = 'nmp-cookie-consent';

  if (cookieBanner) {
    const storedConsent = localStorage.getItem(consentKey);
    if (!storedConsent) {
      requestAnimationFrame(() => {
        cookieBanner.classList.add('is-visible');
      });
    }

    cookieBanner.querySelectorAll('[data-cookie-accept]').forEach((button) => {
      button.addEventListener('click', () => {
        localStorage.setItem(consentKey, 'accepted');
        cookieBanner.classList.remove('is-visible');
      });
    });

    cookieBanner.querySelectorAll('[data-cookie-decline]').forEach((button) => {
      button.addEventListener('click', () => {
        localStorage.setItem(consentKey, 'declined');
        cookieBanner.classList.remove('is-visible');
      });
    });
  }

  document.querySelectorAll('[data-tab-group]').forEach((group) => {
    const buttons = group.querySelectorAll('[data-tab-target]');
    const panels = group.querySelectorAll('[data-tab-panel]');

    buttons.forEach((button) => {
      button.addEventListener('click', () => {
        const targetId = button.dataset.tabTarget;
        buttons.forEach((btn) => btn.classList.remove('is-active'));
        panels.forEach((panel) => panel.classList.remove('is-active'));

        button.classList.add('is-active');
        const targetPanel = group.querySelector(`#${targetId}`);
        if (targetPanel) {
          targetPanel.classList.add('is-active');
        }
      });
    });
  });

  const kpiButtons = document.querySelectorAll('[data-kpi-target]');
  if (kpiButtons.length) {
    const panels = document.querySelectorAll('[data-kpi-panel]');
    kpiButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const target = button.dataset.kpiTarget;
        kpiButtons.forEach((btn) => btn.classList.remove('is-active'));
        panels.forEach((panel) => panel.classList.remove('is-active'));

        button.classList.add('is-active');
        const targetPanel = document.querySelector(`#${target}`);
        if (targetPanel) {
          targetPanel.classList.add('is-active');
        }
      });
    });
  }
});
```