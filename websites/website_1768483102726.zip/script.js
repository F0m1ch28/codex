document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            navToggle.classList.toggle("active");
            siteNav.classList.toggle("open");
        });
        siteNav.querySelectorAll("a").forEach(link => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("open")) {
                    siteNav.classList.remove("open");
                    navToggle.classList.remove("active");
                }
            });
        });
    }

    const backToTop = document.querySelector(".back-to-top");
    if (backToTop) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 600) {
                backToTop.classList.add("visible");
            } else {
                backToTop.classList.remove("visible");
            }
        });
    }

    const cookieBanner = document.getElementById("cookie-banner");
    const cookieAccept = document.getElementById("cookie-accept");
    const cookieDecline = document.getElementById("cookie-decline");
    const cookieConsent = localStorage.getItem("py_ai_consent");
    if (cookieConsent) {
        cookieBanner?.classList.add("hidden");
    } else {
        cookieBanner?.classList.remove("hidden");
    }
    cookieAccept?.addEventListener("click", () => {
        localStorage.setItem("py_ai_consent", "accepted");
        cookieBanner?.classList.add("hidden");
    });
    cookieDecline?.addEventListener("click", () => {
        localStorage.setItem("py_ai_consent", "declined");
        cookieBanner?.classList.add("hidden");
    });

    const modals = document.querySelectorAll("[data-modal]");
    const modalOverlays = {};
    document.querySelectorAll(".modal-overlay").forEach(modal => {
        modalOverlays[modal.id] = modal;
        const closeBtn = modal.querySelector(".modal-close");
        closeBtn?.addEventListener("click", () => {
            modal.classList.remove("active");
        });
        modal.addEventListener("click", event => {
            if (event.target === modal) {
                modal.classList.remove("active");
            }
        });
    });
    modals.forEach(trigger => {
        trigger.addEventListener("click", () => {
            const target = trigger.getAttribute("data-modal");
            if (modalOverlays[target]) {
                modalOverlays[target].classList.add("active");
            }
        });
    });

    const accordionHeaders = document.querySelectorAll(".accordion-header");
    accordionHeaders.forEach(header => {
        header.addEventListener("click", () => {
            const content = header.nextElementSibling;
            content.classList.toggle("open");
            const expanded = header.getAttribute("aria-expanded") === "true";
            header.setAttribute("aria-expanded", (!expanded).toString());
        });
    });
});