# Lumina Digital Lab Website

This repository contains the Lumina Digital Lab marketing site featuring multi-page content, responsive layouts, adaptive imagery, and an accessible cookie consent system.

## Structure

- `index.html` — Vision overview and primary landing page.
- `studio.html` — Culture, leadership, and studio rituals.
- `solutions.html` — Service clusters and process.
- `insights.html` — Research and editorial highlights.
- `policy.html` — Privacy policy.
- `terms.html` — Terms of service.
- `faq.html` — Frequently asked questions.
- `styles.css` — Global styling, responsive layout, and component rules.
- `script.js` — Cookie banner logic and utility helpers.
- `site.webmanifest`, `favicon.ico`, icons, assets, and data directories.
- `robots.txt`, `sitemap.xml` — SEO support.
- `assets/pattern.svg` — Background pattern asset.
- `data/testimonials.json` — Supplementary content data set.

## Development

Open `index.html` in a browser or serve via any static server. Update cookie preferences with the built-in banner to simulate consent flows. Replace placeholder icon files with production-ready art as needed.

## Licensing

All rights reserved © 2024 Lumina Digital Lab. Replace or update according to your organizational requirements.