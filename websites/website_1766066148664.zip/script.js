document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  const banner = document.querySelector('[data-js="cookies-banner"]');
  const modal = document.querySelector('[data-js="cookies-modal"]');
  const acceptBtn = document.querySelector('[data-js="accept-cookies"]');
  const rejectBtn = document.querySelector('[data-js="reject-cookies"]');
  const customizeBtn = document.querySelector('[data-js="customize-cookies"]');
  const closeModalBtn = document.querySelector('[data-js="close-cookies-modal"]');
  const saveBtn = document.querySelector('[data-js="save-cookies"]');
  const analyticsToggle = document.querySelector('[data-js="analytics-toggle"]');
  const marketingToggle = document.querySelector('[data-js="marketing-toggle"]');

  const defaultPreferences = {
    necessary: true,
    analytics: false,
    marketing: false
  };

  const getPreferences = () => {
    try {
      const data = localStorage.getItem('luminaCookiesPreferences');
      if (!data) return null;
      return JSON.parse(data);
    } catch (error) {
      console.warn('Unable to parse cookie preferences', error);
      return null;
    }
  };

  const savePreferences = (prefs) => {
    localStorage.setItem('luminaCookiesPreferences', JSON.stringify(prefs));
  };

  const applyPreferencesToUI = (prefs) => {
    if (!analyticsToggle || !marketingToggle) return;
    analyticsToggle.checked = Boolean(prefs.analytics);
    marketingToggle.checked = Boolean(prefs.marketing);
  };

  const showBanner = () => {
    if (banner) {
      banner.classList.add('is-visible');
    }
  };

  const hideBanner = () => {
    if (banner) {
      banner.classList.remove('is-visible');
    }
  };

  const openModal = () => {
    if (modal) {
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      document.body.classList.add('is-locked');
      const focusable = modal.querySelector('button, input, [href]');
      if (focusable) {
        focusable.focus();
      }
    }
  };

  const closeModal = () => {
    if (modal) {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('is-locked');
      if (customizeBtn) {
        customizeBtn.focus();
      }
    }
  };

  const storedPrefs = getPreferences();
  if (storedPrefs) {
    hideBanner();
    applyPreferencesToUI(storedPrefs);
  } else {
    showBanner();
    applyPreferencesToUI(defaultPreferences);
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => {
      const prefs = { necessary: true, analytics: true, marketing: true };
      savePreferences(prefs);
      applyPreferencesToUI(prefs);
      hideBanner();
      closeModal();
    });
  }

  if (rejectBtn) {
    rejectBtn.addEventListener('click', () => {
      const prefs = { necessary: true, analytics: false, marketing: false };
      savePreferences(prefs);
      applyPreferencesToUI(prefs);
      hideBanner();
      closeModal();
    });
  }

  if (customizeBtn) {
    customizeBtn.addEventListener('click', () => {
      const prefs = getPreferences() || defaultPreferences;
      applyPreferencesToUI(prefs);
      openModal();
    });
  }

  if (closeModalBtn) {
    closeModalBtn.addEventListener('click', () => {
      closeModal();
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      const prefs = {
        necessary: true,
        analytics: analyticsToggle ? analyticsToggle.checked : false,
        marketing: marketingToggle ? marketingToggle.checked : false
      };
      savePreferences(prefs);
      hideBanner();
      closeModal();
    });
  }

  if (modal) {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
        closeModal();
      }
    });
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && modal && modal.classList.contains('is-open')) {
      closeModal();
    }
  });
});