document.documentElement.classList.remove("no-js");

document.addEventListener("DOMContentLoaded", () => {
  const navToggle = document.querySelector(".nav-toggle");
  const primaryNav = document.getElementById("primary-navigation");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", () => {
      const isOpen = primaryNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen);
      document.body.classList.toggle("no-scroll", isOpen);
    });

    primaryNav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        primaryNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
        document.body.classList.remove("no-scroll");
      });
    });
  }

  const redirectMap = {
    "/history": "archives.html",
    "/history/": "archives.html",
    "/history.html": "archives.html",
    "/map": "maps.html",
    "/map/": "maps.html",
    "/signal-map": "maps.html",
    "/signal-map/": "maps.html",
    "/weak-signals": "signals.html",
    "/weak-signals/": "signals.html",
    "/glossary-a-z": "glossary.html"
  };

  const currentPath = window.location.pathname.replace(/\/\/+/g, "/");
  if (redirectMap[currentPath]) {
    window.location.replace(redirectMap[currentPath]);
  }

  const cookieBanner = document.querySelector(".cookie-banner");
  if (cookieBanner) {
    const storedConsent = localStorage.getItem("northlyxCookieConsent");
    if (!storedConsent) {
      cookieBanner.classList.add("is-visible");
    }

    cookieBanner.querySelectorAll("button").forEach((button) => {
      button.addEventListener("click", () => {
        const value = button.classList.contains("accept") ? "accepted" : "declined";
        localStorage.setItem("northlyxCookieConsent", value);
        cookieBanner.classList.remove("is-visible");
      });
    });
  }

  const canvas = document.getElementById("signalCanvas");
  if (canvas) {
    const ctx = canvas.getContext("2d");
    let width = 0;
    let height = 0;
    const pulses = Array.from({ length: 9 }, (_, index) => ({
      radius: 20 + index * 30,
      speed: 0.6 + Math.random() * 0.7,
      alpha: 0.2 + Math.random() * 0.4
    }));

    function resizeCanvas() {
      const parent = canvas.parentElement;
      width = parent.clientWidth - 2;
      height = Math.max(260, parent.clientWidth * 0.55);
      canvas.width = width * window.devicePixelRatio;
      canvas.height = height * window.devicePixelRatio;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    }

    function draw() {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = "rgba(7,11,20,0.9)";
      ctx.fillRect(0, 0, width, height);

      const centerX = width / 2;
      const centerY = height / 2;
      const maxRadius = Math.min(width, height) / 2 - 20;

      pulses.forEach((pulse) => {
        ctx.beginPath();
        ctx.arc(centerX, centerY, pulse.radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(56, 189, 248, ${pulse.alpha})`;
        ctx.lineWidth = 1.4;
        ctx.stroke();
        pulse.radius += pulse.speed;
        if (pulse.radius > maxRadius) {
          pulse.radius = 20;
          pulse.speed = 0.6 + Math.random() * 0.7;
          pulse.alpha = 0.2 + Math.random() * 0.4;
        }
      });

      const nodeCount = 14;
      for (let i = 0; i < nodeCount; i += 1) {
        const angle = (Math.PI * 2 * i) / nodeCount;
        const radius = 60 + (Math.sin(Date.now() / 1500 + i) + 1) * 80;
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;

        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(x, y);
        ctx.strokeStyle = "rgba(34, 197, 94, 0.25)";
        ctx.lineWidth = 0.8;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(x, y, 5 + Math.sin(Date.now() / 800 + i) * 1.5, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(168, 85, 247, 0.75)";
        ctx.fill();
      }

      requestAnimationFrame(draw);
    }

    resizeCanvas();
    draw();
    window.addEventListener("resize", resizeCanvas);
  }

  const layerButtons = document.querySelectorAll("[data-layer-toggle]");
  const svgLayers = document.querySelectorAll(".region-layer");
  if (layerButtons.length && svgLayers.length) {
    layerButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const target = button.getAttribute("data-layer-toggle");
        svgLayers.forEach((layer) => {
          if (target === "all" || layer.id === target) {
            layer.classList.add("is-active");
          } else {
            layer.classList.remove("is-active");
          }
        });
        layerButtons.forEach((btn) => btn.classList.remove("is-active"));
        button.classList.add("is-active");
      });
    });
  }

  const currentYearHolder = document.querySelectorAll("[data-current-year]");
  currentYearHolder.forEach((node) => {
    node.textContent = new Date().getFullYear();
  });
});