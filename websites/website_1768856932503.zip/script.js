document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            navList.classList.toggle('open');
        });

        navList.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navList.classList.remove('open');
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const cookiePreference = localStorage.getItem('ttt-cookie-preference');

    if (cookieBanner && !cookiePreference) {
        cookieBanner.classList.add('active');

        cookieBanner.querySelectorAll('[data-cookie-action]').forEach(button => {
            button.addEventListener('click', (event) => {
                const action = event.currentTarget.dataset.cookieAction;
                localStorage.setItem('ttt-cookie-preference', action);
                cookieBanner.classList.remove('active');
            });
        });
    }

    if (cookieBanner && cookiePreference) {
        cookieBanner.classList.remove('active');
    }
});