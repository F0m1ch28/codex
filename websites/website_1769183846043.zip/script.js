const header = document.querySelector('[data-header]');
const navToggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.primary-nav');
const toast = document.querySelector('[data-toast]');
const cookieBanner = document.querySelector('[data-cookie-banner]');
const acceptBtn = document.querySelector('[data-cookie-accept]');
const declineBtn = document.querySelector('[data-cookie-decline]');
const forms = document.querySelectorAll('form[data-form]');
const revealElements = document.querySelectorAll('.reveal');
const yearSpans = document.querySelectorAll('.js-current-year');

if (yearSpans.length) {
  const year = new Date().getFullYear();
  yearSpans.forEach((span) => {
    span.textContent = year;
  });
}

if (header) {
  const handleScroll = () => {
    if (window.scrollY > 10) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  };
  handleScroll();
  window.addEventListener('scroll', handleScroll);
}

if (navToggle && nav) {
  navToggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', isOpen.toString());
  });
  nav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      if (window.innerWidth < 768 && nav.classList.contains('open')) {
        nav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  });
}

if (revealElements.length) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  revealElements.forEach((el) => observer.observe(el));
}

const showToast = (message) => {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('visible');
  setTimeout(() => {
    toast.classList.remove('visible');
  }, 2600);
};

if (forms.length) {
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const action = form.getAttribute('action') || 'thank-you.html';
      showToast('Message envoyé | Message sent');
      setTimeout(() => {
        window.location.href = action;
      }, 1500);
    });
  });
}

if (cookieBanner) {
  const storageKey = 'alintaapparel_cookie_pref';
  const savedChoice = localStorage.getItem(storageKey);
  if (!savedChoice) {
    cookieBanner.classList.add('active');
  }

  const handleChoice = (value) => {
    localStorage.setItem(storageKey, value);
    cookieBanner.classList.remove('active');
    showToast(value === 'accept' ? 'Cookies analytiques activés' : 'Cookies analytiques désactivés');
  };

  if (acceptBtn) {
    acceptBtn.addEventListener('click', () => handleChoice('accept'));
  }
  if (declineBtn) {
    declineBtn.addEventListener('click', () => handleChoice('decline'));
  }
}