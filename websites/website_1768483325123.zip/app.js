document.addEventListener("DOMContentLoaded", function () {
    const navToggle = document.querySelector(".nav-toggle");
    const siteNav = document.querySelector(".site-nav");
    const navLinks = document.querySelectorAll(".nav-list a");
    const cookieBanner = document.getElementById("cookie-banner");
    const cookieButtons = document.querySelectorAll("[data-cookie-action]");
    const cookiePreference = localStorage.getItem("infantyktx-cookie-preference");

    if (navToggle && siteNav) {
        navToggle.addEventListener("click", () => {
            siteNav.classList.toggle("is-open");
            navToggle.classList.toggle("is-active");
            const expanded = navToggle.classList.contains("is-active");
            navToggle.setAttribute("aria-expanded", expanded);
        });

        navLinks.forEach((link) => {
            link.addEventListener("click", () => {
                if (siteNav.classList.contains("is-open")) {
                    siteNav.classList.remove("is-open");
                    navToggle.classList.remove("is-active");
                    navToggle.setAttribute("aria-expanded", "false");
                }
            });
        });
    }

    if (cookieBanner) {
        if (!cookiePreference) {
            cookieBanner.classList.add("is-visible");
        }

        cookieButtons.forEach((button) => {
            button.addEventListener("click", () => {
                const action = button.getAttribute("data-cookie-action");
                localStorage.setItem("infantyktx-cookie-preference", action);
                cookieBanner.classList.remove("is-visible");
            });
        });
    }
});