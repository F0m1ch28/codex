(function () {
  const body = document.body;
  const navToggle = document.querySelector('.nav-toggle');
  const navList = document.querySelector('.nav-list');
  if (navToggle && navList) {
    navToggle.addEventListener('click', () => {
      const expanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!expanded));
      body.classList.toggle('nav-open');
    });
    navList.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navToggle.setAttribute('aria-expanded', 'false');
        body.classList.remove('nav-open');
      });
    });
  }

  const animateTargets = document.querySelectorAll('[data-animate]');
  if (animateTargets.length > 0 && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.2 });
    animateTargets.forEach((el) => observer.observe(el));
  } else {
    animateTargets.forEach((el) => el.classList.add('is-visible'));
  }

  const cookieBanner = document.querySelector('.cookie-banner');
  const acceptBtn = document.querySelector('.cookie-accept');
  const declineBtn = document.querySelector('.cookie-decline');
  const COOKIE_KEY = 'bosmanCookieChoice';

  function hideCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.remove('is-active');
    }
  }

  function showCookieBanner() {
    if (cookieBanner) {
      cookieBanner.classList.add('is-active');
    }
  }

  if (cookieBanner && acceptBtn && declineBtn) {
    const storedChoice = localStorage.getItem(COOKIE_KEY);
    if (!storedChoice) {
      showCookieBanner();
    }
    acceptBtn.addEventListener('click', () => {
      localStorage.setItem(COOKIE_KEY, 'accepted');
      hideCookieBanner();
    });
    declineBtn.addEventListener('click', () => {
      localStorage.setItem(COOKIE_KEY, 'declined');
      hideCookieBanner();
    });
  }

  const yearSpan = document.getElementById('current-year');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  const toast = document.getElementById('global-toast');
  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    setTimeout(() => toast.classList.remove('is-visible'), 3200);
  }

  const forms = document.querySelectorAll('form[data-form="contact"]');
  forms.forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      showToast('Message submitted. Redirecting to confirmation.');
      setTimeout(() => {
        window.location.href = form.getAttribute('action') || 'thank-you.html';
      }, 1400);
    });
  });
})();